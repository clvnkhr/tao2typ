// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:36:44.914836+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254B, Notes 3: Quasirandom groups, expansion, and Selberg’s 3/16 theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254B, Notes 3: Quasirandom groups, expansion, and Selberg’s 3/16 theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 December 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/")[#text("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the ")#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/")[#text("previous set of notes")]#text(" we saw how a representation-theoretic property of groups, namely ")#link("http://en.wikipedia.org/wiki/Kazhdan%27s_property_(T)")[#text("Kazhdan’s property (T)")]#text(", could be used to demonstrate expansion in Cayley graphs. In this set of notes we discuss a different representation-theoretic property of groups, namely ")#emph[#text("quasirandomness")]#text(", which is also useful for demonstrating expansion in Cayley graphs, though in a somewhat different way to property (T). For instance, whereas property (T), being qualitative in nature, is only interesting for infinite groups such as ")#mi("{SL_d({\\bf Z})}")#text(" or ")#mi("{SL_d({\\bf R})}")#text(", and only creates Cayley graphs after passing to a finite quotient, quasirandomness is a quantitative property which is directly applicable to finite groups, and is able to deduce expansion in a Cayley graph, provided that random walks in that graph are known to become sufficiently “flat” in a certain sense.")

#text("The definition of quasirandomness is easy enough to state:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Quasirandom groups)")]#text(" Let ")#mi("{G}")#text(" be a finite group, and let ")#mi("{D \\geq 1}")#text(". We say that ")#mi("{G}")#text(" is ")#emph[#mi("{D}")#text("-quasirandom")]#text(" if all non-trivial unitary representations ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" of ")#mi("{G}")#text(" have dimension at least ")#mi("{D}")#text(". (Recall a representation is ")#emph[#text("trivial")]#text(" if ")#mi("{\\rho(g)}")#text(" is the identity for all ")#mi("{g \\in G}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Let ")#mi("{G}")#text(" be a finite group, and let ")#mi("{D \\geq 1}")#text(". A unitary representation ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" is said to be ")#emph[#text("irreducible")]#text(" if ")#mi("{H}")#text(" has no ")#mi("{G}")#text("-invariant subspaces other than ")#mi("{\\{0\\}}")#text(" and ")#mi("{H}")#text(". Show that ")#mi("{G}")#text(" is ")#mi("{D}")#text("-quasirandom if and only if every non-trivial irreducible representation of ")#mi("{G}")#text(" has dimension at least ")#mi("{D}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The terminology “quasirandom group” was introduced explicitly (though with slightly different notational conventions) by Gowers in 2008 in ")#link("http://www.ams.org/mathscinet-getitem?mr=2410393")[#text("his detailed study of the concept")]#text("; the name arises because dense Cayley graphs in quasirandom groups are quasirandom graphs in the ")#link("http://www.ams.org/mathscinet-getitem?mr=1054011")[#text("sense of Chung, Graham, and Wilson")]#text(", as we shall see below. This property had already been used implicitly to construct expander graphs ")#link("http://www.ams.org/mathscinet-getitem?mr=1131400")[#text("by Sarnak and Xue")]#text(" in 1991, and more recently ")#link("http://www.ams.org/mathscinet-getitem?mr=1900698")[#text("by Gamburd")]#text(" in 2002 and ")#link("http://www.ams.org/mathscinet-getitem?mr=2415383")[#text("by Bourgain and Gamburd")]#text(" in 2008. One can of course define quasirandomness for more general locally compact groups than the finite ones, but we will only need this concept in the finite case. (A ")#link("http://www.ams.org/mathscinet-getitem?mr=163988")[#text("paper of Kunze and Stein")]#text(" from 1960, for instance, exploits the quasirandomness properties of the locally compact group ")#mi("{SL_2({\\bf R})}")#text(" to obtain mixing estimates in that group.)")
]

#text("Quasirandomness behaves fairly well with respect to quotients and short exact sequences:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" ")#metadata(none) <tao-b8e838eebe593cbfb802>#text(" Let ")#mi("{0 \\rightarrow H \\rightarrow G \\rightarrow K \\rightarrow 0}")#text(" be a short exact sequence of finite groups ")#mi("{H,G,K}")#text(".")

#list(
[#text("(i) If ")#mi("{G}")#text(" is ")#mi("{D}")#text("-quasirandom, show that ")#mi("{K}")#text(" is ")#mi("{D}")#text("-quasirandom also. (Equivalently: any quotient of a ")#mi("{D}")#text("-quasirandom finite group is again a ")#mi("{D}")#text("-quasirandom finite group.)")],
[#text("(ii) Conversely, if ")#mi("{H}")#text(" and ")#mi("{K}")#text(" are both ")#mi("{D}")#text("-quasirandom, show that ")#mi("{G}")#text(" is ")#mi("{D}")#text("-quasirandom also. (In particular, the direct or semidirect product of two ")#mi("{D}")#text("-quasirandom finite groups is again a ")#mi("{D}")#text("-quasirandom finite group.)")]
)
]

#text("Informally, we will call ")#mi("{G}")#text(" ")#emph[#text("quasirandom")]#text(" if it is ")#mi("{D}")#text("-quasirandom for some “large” ")#mi("{D}")#text(", though the precise meaning of “large” will depend on context. For applications to expansion in Cayley graphs, “large” will mean “")#tao-math("{D \\geq \\left|G\\right|^c}", block: false)#text(" for some constant ")#mi("{c>0}")#text(" independent of the size of ")#mi("{G}")#text("“, but other regimes of ")#mi("{D}")#text(" are certainly of interest.")

#text("The way we have set things up, the trivial group ")#mi("{G = \\{1\\}}")#text(" is infinitely quasirandom (i.e. it is ")#mi("{D}")#text("-quasirandom for every ")#mi("{D}")#text("). This is however a degenerate case and will not be discussed further here. In the non-trivial case, a finite group can only be quasirandom if it is large and has no large subgroups:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" ")#metadata(none) <tao-1ef5890d626a5c79f9c6>#text(" Let ")#mi("{D \\geq 1}")#text(", and let ")#mi("{G}")#text(" be a finite ")#mi("{D}")#text("-quasirandom group.")

#list(
[#text("(i) Show that if ")#mi("{G}")#text(" is non-trivial, then ")#tao-math("{\\left|G\\right| \\geq D+1}", block: false)#text(". (")#emph[#text("Hint:")]#text(" use the mean zero component ")#mi("{\\tau\\downharpoonright_{\\ell^2(G)_0}}")#text(" of the ")#link("http://en.wikipedia.org/wiki/Regular_representation")[#text("regular representation")]#text(" ")#mi("{\\tau: G \\rightarrow U(\\ell^2(G))}")#text(".) In particular, non-trivial finite groups cannot be infinitely quasirandom.")],
[#text("(ii) Show that any proper subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" has index ")#mi("{[G:H] \\geq D+1}")#text(". (")#emph[#text("Hint:")]#text(" use the mean zero component of the ")#link("http://en.wikipedia.org/wiki/Quasiregular_representation")[#text("quasiregular representation")]#text(".)")]
)
]

#text("The following exercise shows that quasirandom groups have to be quite non-abelian, and in particular ")#link("http://en.wikipedia.org/wiki/Perfect_group")[#text("perfect")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4 (Quasirandomness, abelianness, and perfection)")]#text(" ")#metadata(none) <tao-052c4bed7c1f451e673b>#text(" Let ")#mi("{G}")#text(" be a finite group.")

#list(
[#text("(i) If ")#mi("{G}")#text(" is abelian and non-trivial, show that ")#mi("{G}")#text(" is not ")#mi("{2}")#text("-quasirandom. (")#emph[#text("Hint:")]#text(" use Fourier analysis or the ")#link("http://en.wikipedia.org/wiki/Finitely-generated_abelian_group#Classification")[#text("classification of finite abelian groups")]#text(".)")],
[#text("(ii) Show that ")#mi("{G}")#text(" is ")#mi("{2}")#text("-quasirandom if and only if it is ")#link("http://en.wikipedia.org/wiki/Perfect_group")[#text("perfect")]#text(", i.e. the ")#link("http://en.wikipedia.org/wiki/Commutator_subgroup")[#text("commutator group")]#text(" ")#mi("{[G,G]}")#text(" is equal to ")#mi("{G}")#text(". (Equivalently, ")#mi("{G}")#text(" is ")#mi("{2}")#text("-quasirandom if and only if it has no non-trivial abelian quotients.)")]
)
]

#text("Later on we shall see that there is a converse to the above two exercises; any non-trivial perfect finite group with no large subgroups will be quasirandom.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Let ")#mi("{G}")#text(" be a finite ")#mi("{D}")#text("-quasirandom group. Show that for any subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(", ")#mi("{G^{\\prime}}")#text(" is ")#mi("{D/[G:G^{\\prime}]}")#text("-quasirandom, where ")#tao-math("{[G:G^{\\prime}] := \\left|G\\right|/\\left|G^{\\prime}\\right|}", block: false)#text(" is the index of ")#mi("{G^{\\prime}}")#text(" in ")#mi("{G}")#text(". (")#emph[#text("Hint:")]#text(" use induced representations.)")
]

#text("Now we give an example of a more quasirandom group.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Frobenius lemma)")]#text(" ")#metadata(none) <tao-26b7c362884170e0ba38>#text(" If ")#mi("{F_p}")#text(" is a field of some prime order ")#mi("{p}")#text(", then ")#mi("{SL_2(F_p)}")#text(" is ")#mi("{\\frac{p-1}{2}}")#text("-quasirandom.")
]

#text("This should be compared with the cardinality ")#tao-math("{\\left|SL_2(F_p)\\right|}", block: false)#text(" of the special linear group, which is easily computed to be ")#mi("{(p^2-1) \\times p = p^3 - p}")#text(".")

#emph[#text("Proof:")]#text(" We may of course take ")#mi("{p}")#text(" to be odd. Suppose for contradiction that we have a non-trivial representation ")#mi("{\\rho: SL_2(F_p) \\rightarrow U_d({\\bf C})}")#text(" on a unitary group of some dimension ")#mi("{d}")#text(" with ")#mi("{d < \\frac{p-1}{2}}")#text(". Set ")#mi("{a}")#text(" to be the group element")

#align(center)[#tao-fit-display[#mitex("a := \\begin{pmatrix} 1 & 1 \\\\ 0 & 1 \\end{pmatrix},")]]

#text("and suppose first that ")#mi("{\\rho(a)}")#text(" is non-trivial. Since ")#mi("{a^p=1}")#text(", we have ")#mi("{\\rho(a)^p=1}")#text("; thus all the eigenvalues of ")#mi("{\\rho(a)}")#text(" are ")#mi("{p^{th}}")#text(" roots of unity. On the other hand, by conjugating ")#mi("{a}")#text(" by diagonal matrices in ")#mi("{SL_2(F_p)}")#text(", we see that ")#mi("{a}")#text(" is conjugate to ")#mi("{a^m}")#text(" (and hence ")#mi("{\\rho(a)}")#text(" conjugate to ")#mi("{\\rho(a)^m}")#text(") whenever ")#mi("{m}")#text(" is a quadratic residue mod ")#mi("{p}")#text(". As such, the eigenvalues of ")#mi("{\\rho(a)}")#text(" must be permuted by the operation ")#mi("{x \\mapsto x^m}")#text(" for any quadratic residue mod ")#mi("{p}")#text(". Since ")#mi("{\\rho(a)}")#text(" has at least one non-trivial eigenvalue, and there are ")#mi("{\\frac{p-1}{2}}")#text(" distinct quadratic residues, we conclude that ")#mi("{\\rho(a)}")#text(" has at least ")#mi("{\\frac{p-1}{2}}")#text(" distinct eigenvalues. But ")#mi("{\\rho(a)}")#text(" is a ")#mi("{d \\times d}")#text(" matrix with ")#mi("{d < \\frac{p-1}{2}}")#text(", a contradiction. Thus ")#mi("{a}")#text(" lies in the kernel of ")#mi("{\\rho}")#text(". By conjugation, we then see that this kernel contains all unipotent matrices. But these matrices generate ")#mi("{SL_2(F_p)}")#text(" (see exercise below), and so ")#mi("{\\rho}")#text(" is trivial, a contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Show that for any prime ")#mi("{p}")#text(", the unipotent matrices")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} 1 & t \\\\ 0 & 1 \\end{pmatrix}, \\begin{pmatrix} 1 & 0 \\\\ t & 1 \\end{pmatrix}")]]

#text("for ")#mi("{t}")#text(" ranging over ")#mi("{F_p}")#text(" generate ")#mi("{SL_2(F_p)}")#text(" as a group.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Let ")#mi("{G}")#text(" be a finite group, and let ")#mi("{D \\geq 1}")#text(". If ")#mi("{G}")#text(" is generated by a collection ")#mi("{G_1,\\ldots,G_k}")#text(" of ")#mi("{D}")#text("-quasirandom subgroups, show that ")#mi("{G}")#text(" is itself ")#mi("{D}")#text("-quasirandom.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Show that ")#mi("{SL_d(F_p)}")#text(" is ")#mi("{\\frac{p-1}{2}}")#text("-quasirandom for any ")#mi("{d \\geq 2}")#text(" and any prime ")#mi("{p}")#text(". (This is not sharp; the optimal bound here is ")#mi("{\\gg_d p^{d-1}}")#text(", which follows from the ")#link("http://www.ams.org/mathscinet-getitem?mr=360852")[#text("results of Landazuri and Seitz")]#text(".)")
]

#text("As a corollary of the above results and Exercise ")#link(<tao-b8e838eebe593cbfb802>)[#text("2")]#text(", we see that the ")#link("http://en.wikipedia.org/wiki/Projective_special_linear_group")[#text("projective special linear group")]#text(" ")#mi("{PSL_d(F_p)}")#text(" is also ")#mi("{\\frac{p-1}{2}}")#text("-quasirandom.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One can ask whether the bound ")#mi("{\\frac{p-1}{2}}")#text(" in Lemma ")#link(<tao-26b7c362884170e0ba38>)[#text("2")]#text(" is sharp, assuming of course that ")#mi("{p}")#text(" is odd. Noting that ")#mi("{SL_2(F_p)}")#text(" acts linearly on the plane ")#mi("{F_p^2}")#text(", we see that it also acts projectively on the projective line ")#mi("{PF_p^1 := (F_p^2 \\backslash \\{0\\}) / F_p^\\times}")#text(", which has ")#mi("{p+1}")#text(" elements. Thus ")#mi("{SL_2(F_p)}")#text(" acts via the quasiregular representation on the ")#mi("{p+1}")#text("-dimensional space ")#mi("{\\ell^2(PF_p^1)}")#text(", and also on the ")#mi("{p}")#text("-dimensional subspace ")#mi("{\\ell^2(PF_p^1)_0}")#text("; this latter representation (known as the ")#link("http://en.wikipedia.org/wiki/Steinberg_representation")[#text("Steinberg representation")]#text(") is irreducible. This shows that the ")#mi("{\\frac{p-1}{2}}")#text(" bound cannot be improved beyond ")#mi("{p}")#text(". More generally, given any character ")#mi("{\\chi: F_p^\\times \\rightarrow S^1}")#text(", ")#mi("{SL_2(F_p)}")#text(" acts on the ")#mi("{p+1}")#text("-dimensional space ")#mi("{V_\\chi}")#text(" of functions ")#mi("{f \\in \\ell^2( F_p^2 \\backslash \\{0\\} )}")#text(" that obey the twisted dilation invariance ")#mi("{f(tx) = \\chi(t) f(x)}")#text(" for all ")#mi("{t \\in F_p^\\times}")#text(" and ")#mi("{x \\in F_p^2 \\backslash \\{0\\}}")#text("; these are known as the ")#link("http://en.wikipedia.org/wiki/Principal_series_representation")[#text("principal series representations")]#text(". When ")#mi("{\\chi}")#text(" is the trivial character, this is the quasiregular representation discussed earlier. For most other characters, this is an irreducible representation, but it turns out that when ")#mi("{\\chi}")#text(" is the quadratic representation (thus taking values in ")#mi("{\\{-1,+1\\}}")#text(" while being non-trivial), the principal series representation splits into the direct sum of two ")#mi("{\\frac{p+1}{2}}")#text("-dimensional representations, which comes very close to matching the bound in Lemma ")#link(<tao-26b7c362884170e0ba38>)[#text("2")]#text(". There is a parallel series of representations to the principal series (known as the ")#link("http://en.wikipedia.org/wiki/Discrete_series_representation")[#text("discrete series")]#text(") which is more complicated to describe (roughly speaking, one has to embed ")#mi("{F_p}")#text(" in a quadratic extension ")#mi("{F_{p^2}}")#text(" and then use a rotated version of the above construction, to change a split torus into a non-split torus), but can generate irreducible representations of dimension ")#mi("{\\frac{p-1}{2}}")#text(", showing that the bound in Lemma ")#link(<tao-26b7c362884170e0ba38>)[#text("2")]#text(" is in fact exactly sharp. These constructions can be generalised to arbitrary finite groups of Lie type using ")#link("http://en.wikipedia.org/wiki/Deligne%E2%80%93Lusztig_theory")[#text("Deligne-Luzstig theory")]#text(", but this is beyond the scope of this course (and of my own knowledge in the subject).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Let ")#mi("{p}")#text(" be an odd prime. Show that for any ")#mi("{n \\geq p+2}")#text(", the ")#link("http://en.wikipedia.org/wiki/Alternating_group")[#text("alternating group")]#text(" ")#mi("{A_n}")#text(" is ")#mi("{p-1}")#text("-quasirandom. (")#emph[#text("Hint:")]#text(" show that all cycles of order ")#mi("{p}")#text(" in ")#mi("{A_n}")#text(" are conjugate to each other in ")#mi("{A_n}")#text(" (and not just in ")#mi("{S_n}")#text("); in particular, a cycle is conjugate to its ")#mi("{j^{th}}")#text(" power for all ")#mi("{j=1,\\ldots,p-1}")#text(". Also, as ")#mi("{n \\geq 5}")#text(", ")#mi("{A_n}")#text(" is simple, and so the cycles of order ")#mi("{p}")#text(" generate the entire group.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" By using more precise information on the representations of the alternating group (using the theory of ")#link("http://en.wikipedia.org/wiki/Specht_module")[#text("Specht modules")]#text(" and ")#link("http://en.wikipedia.org/wiki/Young_tableaux")[#text("Young tableaux")]#text("), one can show the slightly sharper statement that ")#mi("{A_n}")#text(" is ")#mi("{n-1}")#text("-quasirandom for ")#mi("{n \\geq 6}")#text(" (but is only ")#mi("{3}")#text("-quasirandom for ")#mi("{n=5}")#text(" due to ")#link("http://en.wikipedia.org/wiki/Icosahedral_symmetry")[#text("icosahedral symmetry")]#text(", and ")#mi("{1}")#text("-quasirandom for ")#mi("{n \\leq 4}")#text(" due to lack of perfectness). Using Exercise ")#link(<tao-1ef5890d626a5c79f9c6>)[#text("3")]#text(" with the index ")#mi("{n}")#text(" subgroup ")#mi("{A_{n-1}}")#text(", we see that the bound ")#mi("{n-1}")#text(" cannot be improved. Thus, ")#mi("{A_n}")#text(" (for large ")#mi("{n}")#text(") is not as quasirandom as the special linear groups ")#mi("{SL_d(F_p)}")#text(" (for ")#mi("{p}")#text(" large and ")#mi("{d}")#text(" bounded), because in the latter case the quasirandomness is as strong as a power of the size of the group, whereas in the former case it is only logarithmic in size.")

#text("If one replaces the alternating group ")#mi("{A_n}")#text(" with the slightly larger ")#link("http://en.wikipedia.org/wiki/Symmetric_group")[#text("symmetric group")]#text(" ")#mi("{S_n}")#text(", then quasirandomness is destroyed (since ")#mi("{S_n}")#text(", having the abelian quotient ")#mi("{S_n/A_n}")#text(", is not perfect); indeed, ")#mi("{S_n}")#text(" is ")#mi("{1}")#text("-quasirandom and no better.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" Thanks to the monumental achievement of the ")#link("http://en.wikipedia.org/wiki/Classification_of_finite_simple_groups")[#text("classification of finite simple groups")]#text(", we know that apart from a finite number (26, to be precise) of ")#link("http://en.wikipedia.org/wiki/Sporadic_group")[#text("sporadic exceptions")]#text(", all finite simple groups (up to isomorphism) are either a cyclic group ")#mi("{{\\bf Z}/p{\\bf Z}}")#text(", an alternating group ")#mi("{A_n}")#text(", or is a ")#link("http://en.wikipedia.org/wiki/Group_of_Lie_type")[#text("finite simple group of Lie type")]#text(" such as ")#mi("{PSL_d(F_p)}")#text(". (We will define the concept of a finite simple group of Lie type more precisely in later notes, but suffice to say for now that such groups are constructed from ")#link("http://en.wikipedia.org/wiki/Reductive_group")[#text("reductive algebraic groups")]#text(", for instance ")#mi("{PSL_d(F_p)}")#text(" is constructed from ")#mi("{SL_d}")#text(" in characteristic ")#mi("{p}")#text(".) In the case of finite simple groups ")#mi("{G}")#text(" of Lie type with bounded rank ")#mi("{r=O(1)}")#text(", it is known from the ")#link("http://www.ams.org/mathscinet-getitem?mr=360852")[#text("work of Landazuri and Seitz")]#text(" that such groups are ")#tao-math("{\\gg \\left|G\\right|^c}", block: false)#text("-quasirandom for some ")#mi("{c>0}")#text(" depending only on the rank. On the other hand, by the previous remark, the large alternating groups do not have this property, and one can show that the finite simple groups of Lie type with large rank also do not have this property. Thus, we see using the classification that if a finite simple group ")#mi("{G}")#text(" is ")#tao-math("{\\left|G\\right|^c}", block: false)#text("-quasirandom for some ")#mi("{c>0}")#text(" and ")#tao-math("{\\left|G\\right|}", block: false)#text(" is sufficiently large depending on ")#mi("{c}")#text(", then ")#mi("{G}")#text(" is a finite simple group of Lie type with rank ")#mi("{O_c(1)}")#text(". It would be of interest to see if there was an alternate way to establish this fact that did not rely on the classification, as it may lead to an alternate approach to proving the classification (or perhaps a weakened version thereof).")
]

#text("A key reason why quasirandomness is desirable for the purposes of demonstrating expansion is that quasirandom groups happen to be rapidly mixing at large scales, as we shall see below the fold. As such, quasirandomness is an important tool for demonstrating expansion in Cayley graphs, though because expansion is a phenomenon that must hold at all scales, one needs to supplement quasirandomness with some additional input that creates mixing at small or medium scales also before one can deduce expansion. As an example of this technique of combining quasirandomness with mixing at small and medium scales, we present a proof (due to ")#link("http://www.ams.org/mathscinet-getitem?mr=1131400")[#text("Sarnak-Xue")]#text(", and simplified ")#link("http://www.ams.org/mathscinet-getitem?mr=1900698")[#text("by Gamburd")]#text(") of a weak version of the famous ")#link("http://www.ams.org/mathscinet-getitem?mr=182610")[#text("“3/16 theorem” of Selberg")]#text(" on the least non-trivial eigenvalue of the Laplacian on a modular curve, which among other things can be used to construct a family of expander Cayley graphs in ")#mi("{SL_2({\\bf Z}/N{\\bf Z})}")#text(" (compare this with the property (T)-based methods in the previous notes, which could construct expander Cayley graphs in ")#mi("{SL_d({\\bf Z}/N{\\bf Z})}")#text(" for any fixed ")#mi("{d \\geq 3}")#text(").")

#metadata(none) <tao-7946826fd1ab416234cc>

#heading(level: 1)[#strong[#text(" — 1. Mixing in quasirandom groups — ")]]

#text("Let ")#mi("{G}")#text(" be a finite group. Given two functions ")#mi("{f, g \\in \\ell^2(G)}")#text(", we can define the ")#emph[#text("convolution")]#text(" ")#mi("{f*g \\in \\ell^2(G)}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("f*g(x) := \\sum_{y \\in G} f(y) g(y^{-1} x) = \\sum_{y \\in G} f(x y^{-1}) g(y).")]]

#text("This operation is bilinear and associative, but is not commutative unless ")#mi("{G}")#text(" is abelian. From the Cauchy-Schwarz inequality one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f*g\\right\\|_{\\ell^\\infty(G)} \\leq \\left\\|f\\right\\|_{\\ell^2(G)} \\left\\|g\\right\\|_{\\ell^2(G)}", block: true)]]

#text("and hence")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f*g\\right\\|_{\\ell^2(G)} \\leq \\left|G\\right|^{1/2} \\left\\|f\\right\\|_{\\ell^2(G)} \\left\\|g\\right\\|_{\\ell^2(G)}.", block: true)]]

#text("This inequality is sharp in the sense that if we set ")#mi("{f}")#text(" and ")#mi("{g}")#text(" to both be constant-valued, then the left-hand side and right-hand side match. For abelian groups, one can also see this example is sharp when ")#mi("{f}")#text(" and ")#mi("{g}")#text(" are multiples of the same character.")

#text("It turns out, though, that if one restricts one of ")#mi("{f}")#text(" or ")#mi("{g}")#text(" (or both) to be of mean zero, and ")#mi("{G}")#text(" is quasirandom, then one can improve this inequality, which first appeared explicitly in the ")#link("http://www.ams.org/mathscinet-getitem?mr=2485310")[#text("work of Babai, Nikolov, and Pyber")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Mixing inequality)")]#text(" ")#metadata(none) <tao-1b64e6e0abf6d3eaa61a>#text(" Let ")#mi("{G}")#text(" be a finite ")#mi("{D}")#text("-quasirandom group, and let ")#mi("{f, g \\in \\ell^2(G)}")#text(". If at least one of ")#mi("{f, g}")#text(" has mean zero, then")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f*g\\right\\|_{\\ell^2(G)} \\leq D^{-1/2} \\left|G\\right|^{1/2} \\left\\|f\\right\\|_{\\ell^2(G)} \\left\\|g\\right\\|_{\\ell^2(G)}.", block: true)]]
]

#emph[#text("Proof:")]#text(" By subtracting a constant from ")#mi("{f}")#text(" or ")#mi("{g}")#text(", we may assume that ")#mi("{f}")#text(" or ")#mi("{g}")#text(" both have mean zero.")

#text("Observe that ")#mi("{f*g}")#text(" (being a superposition of right-translates of ")#mi("{f}")#text(") also has mean zero. Thus, we see that we may define an operator ")#mi("{T_g: \\ell^2(G)_0 \\rightarrow \\ell^2(G)_0}")#text(" by setting ")#mi("{T_g f := f*g}")#text(". It thus suffices to show that the operator norm of ")#mi("{T_g}")#text(" is at most ")#tao-math("{D^{-1/2} \\left|G\\right|^{1/2} \\left\\|g\\right\\|_{\\ell^2(G)}}", block: false)#text(".")

#text("Fix ")#mi("{g}")#text(". We can view ")#mi("{T_g}")#text(" as a ")#tao-math("{\\left|G\\right|-1 \\times \\left|G\\right|-1}", block: false)#text(" matrix. We apply the ")#link("http://en.wikipedia.org/wiki/Singular_value_decomposition")[#text("singular value decomposition to this matrix")]#text(" to obtain singular values")

#align(center)[#tao-fit-display[#tao-math("\\sigma_1 \\geq \\ldots \\geq \\sigma_{\\left|G\\right|-1} \\geq 0", block: true)]]

#text("of ")#mi("{T_g}")#text(", together with associated singular vectors. The operator norm of ")#mi("{T_g}")#text(" is the largest singular value ")#mi("{\\sigma_1}")#text(". The operator ")#mi("{T_g^* T_g}")#text(" is then a self-adjoint operator (or matrix) with eigenvalues ")#tao-math("{\\sigma_1^2, \\ldots, \\sigma_{\\left|G\\right|-1}^2}", block: false)#text(". In particular, we have")

#align(center)[#tao-fit-display[#tao-math("\\text{tr} T_g^* T_g = \\sigma_1^2 + \\ldots + \\sigma_{\\left|G\\right|-1}^2.", block: true)]]

#text("Now, a short computation shows that ")#mi("{T_g^* T_g f = f * g * \\tilde g}")#text(", where ")#mi("{\\tilde g(x) := \\overline{g(x^{-1})}}")#text(", and (by embedding ")#mi("{\\ell^2(G)_0}")#text(" in ")#mi("{\\ell^2(G)}")#text(", and noting that ")#mi("{T_g^* T_g}")#text(" annihilates constants) the trace can computed as")

#align(center)[#tao-fit-display[#tao-math("\\text{tr} T_g^* T_g = \\left|G\\right| g * \\tilde g(0) = \\left|G\\right| \\left\\|g\\right\\|_{\\ell^2(G)}^2.", block: true)]]

#text("Thus, if ")#mi("{V}")#text(" is the eigenspace of ")#mi("{T_g^* T_g}")#text(" corresponding to the eigenvalue ")#mi("{\\sigma_1^2}")#text(" (so that the dimension of ")#mi("{V}")#text(" is the multiplicity of ")#mi("{\\sigma_1}")#text("), we have")

#align(center)[#tao-fit-display[#tao-math("\\text{dim}(V) \\sigma_1^2 \\leq \\left|G\\right| \\left\\|g\\right\\|_{\\ell^2(G)}^2.", block: true)]]

#text("Now observe that if ")#mi("{\\tau: G \\rightarrow U(\\ell^2(G)_0)}")#text(" is the left-regular representation (restricted to ")#mi("{\\ell^2(G)_0}")#text(") then")

#align(center)[#tao-fit-display[#mitex("T_g^* T_g \\tau(h) f = \\tau(h) T_g^* T_g f")]]

#text("for any ")#mi("{f \\in \\ell^2(G)_0}")#text(" and ")#mi("{h \\in G}")#text(" (this is a special case of the associativity of convolution). In particular, we see that ")#mi("{V}")#text(" is invariant under ")#mi("{\\tau}")#text(". Since ")#mi("{\\tau}")#text(" has no non-trivial invariant vectors in ")#mi("{\\ell^2(G)_0}")#text(", we conclude from quasirandomness that ")#mi("{V}")#text(" has dimension at least ")#mi("{D}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" One can also establish the above inequality using the nonabelian Fourier transform (which is based on the ")#link("http://en.wikipedia.org/wiki/Peter-Weyl_theorem")[#text("Peter-Weyl theorem")]#text(" combined with ")#link("http://en.wikipedia.org/wiki/Schur's_lemma")[#text("Schur’s lemma")]#text(", and is developed in ")#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/")[#text("this blog post")]#text("); we leave this as an exercise for the interested reader.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" ")#metadata(none) <tao-8f455bba4522752c63bb>#text(" Let ")#mi("{A, B, C}")#text(" be subsets of a finite ")#mi("{D}")#text("-quasirandom group ")#mi("{G}")#text(". Show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| 1_A * 1_B - \\frac{\\left|A\\right| \\left|B\\right|}{\\left|G\\right|} \\right\\|_{\\ell^2(G)} \\leq D^{-1/2} \\left|G\\right|^{1/2} \\left|A\\right|^{1/2} \\left|B\\right|^{1/2}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| 1_A * 1_B * 1_C - \\frac{\\left|A\\right| \\left|B\\right| \\left|C\\right|}{\\left|G\\right|} \\right\\|_{\\ell^\\infty(G)} \\leq D^{-1/2} \\left|G\\right|^{1/2} \\left|A\\right|^{1/2} \\left|B\\right|^{1/2} \\left|C\\right|^{1/2}.", block: true)]]

#text("Conclude in particular that")

#align(center)[#tao-fit-display[#tao-math("\\left|AB\\right| \\geq \\left|G\\right| - \\frac{\\left|G\\right|^3}{D\\left|A\\right| \\left|B\\right|},", block: true)]]

#text("and that ")#mi("{ABC=G}")#text(" whenever ")#tao-math("{\\left|A\\right| \\left|B\\right| \\left|C\\right| > \\left|G\\right|^3/D}", block: false)#text(". (The bounds here are not quite sharp, but are simpler than the optimal bounds, and suffice for most applications.)")
]

#text("Thus, for instance, if ")#mi("{A}")#text(" is a subset of a finite ")#mi("{D}")#text("-quasirandom group ")#mi("{G}")#text(" of density ")#tao-math("{\\left|A\\right|/\\left|G\\right|}", block: false)#text(" more than ")#mi("{D^{-1/3}}")#text(", then ")#mi("{A^2}")#text(" will be most of ")#mi("{G}")#text(" (with fewer than ")#tao-math("{\\left|A\\right|}", block: false)#text(" elements omitted), and ")#mi("{A^3}")#text(" will be all of ")#mi("{G}")#text("; thus large subsets of a quasirandom group rapidly expand to fill out the whole group. In the converse direction, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Let ")#mi("{D \\geq 1}")#text(", and let ")#mi("{G}")#text(" be a finite group which is ")#emph[#text("not")]#text(" ")#mi("{D}")#text("-quasirandom. Show that there exists a subset ")#mi("{A}")#text(" of ")#mi("{G}")#text(" with ")#tao-math("{\\left|A\\right|/\\left|G\\right| \\geq C^{-D}}", block: false)#text(" for some absolute constant ")#mi("{C > 1}")#text(", such that ")#mi("{A^3 \\subsetneq G}")#text(". (")#emph[#text("Hint:")]#text(" by hypothesis, one has a non-trivial unitary representation ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" of dimension at most ")#mi("{D}")#text(". Show that ")#mi("{\\rho(G)}")#text(" contains an element at distance ")#mi("{\\gg 1}")#text(" from the identity in operator norm, and take ")#mi("{A}")#text(" to be the preimage of a suitable ball around the identity in the operator norm.)")
]

#text("One can improve this result by using a quantitative form of ")#link("http://en.wikipedia.org/wiki/Jordan%E2%80%93Schur_theorem")[#text("Jordan’s theorem")]#text("; see the next section.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12 (Mixing inequality for actions)")]#text(" Let ")#mi("{G}")#text(" be a finite ")#mi("{D}")#text("-quasirandom group acting (on the left) on a discrete set ")#mi("{X}")#text(". Given functions ")#mi("{f \\in \\ell^2(G)}")#text(" and ")#mi("{g \\in\\ell^2(X)}")#text(", one can define the convolution ")#mi("{f*g \\in \\ell^2(X)}")#text(" in much the same way as before:")

#align(center)[#tao-fit-display[#mitex("f*g(x):=\\sum_{h \\in G} f(h) g(h^{-1} x).")]]

#text("Show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f*g\\right\\|_{\\ell^2(G)} \\leq D^{-1/2} \\left|G\\right|^{1/2} \\left\\|f\\right\\|_{\\ell^2(G)} \\left\\|g\\right\\|_{\\ell^2(G)}.", block: true)]]

#text("whenever ")#mi("{f}")#text(" has mean zero, or whenever ")#mi("{g}")#text(" has mean zero on every orbit of ")#mi("{G}")#text(".")
]

#text("One can use quasirandomness to show that Cayley graphs of very large degree ")#mi("{k}")#text(" in a quasirandom group are expanders:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Let ")#mi("{Cay(G,S)}")#text(" be a ")#mi("{k}")#text("-regular Cayley graph in a finite ")#mi("{D}")#text("-quasirandom group ")#mi("{G}")#text(" on ")#mi("{n}")#text(" vertices.")

#list(
[#text("(i) If ")#mi("{A}")#text(", ")#mi("{B}")#text(" are subsets of ")#mi("{G}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\left|E(A,B) - \\frac{k}{n} \\right|A\\left|\\left|B\\right|\\right| \\leq \\sqrt{ \\frac{kn \\left|A\\right|\\left|B\\right|}{D} }", block: true)]]

#text("(compare with the expander mixing lemma, Exercise 9 from ")#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/")[#text("Notes 1")]#text(").")],
[#text("(ii) Show that ")#mi("{Cay(G,S)}")#text(" is a two-sided ")#mi("{\\epsilon}")#text("-expander whenever")

#align(center)[#tao-fit-display[#mitex("\\epsilon \\leq 1 - \\sqrt{\\frac{n}{Dk}}.")]]]
)
]

#text("Unfortunately, the above result is only non-trivial in the regime ")#mi("{k \\gg n/D}")#text(", whereas for our applications we are interested instead in the regime when ")#mi("{k=O(1)}")#text(". We record a tool for this purpose.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (Using quasirandomness to demonstrate expansion)")]#text(" ")#metadata(none) <tao-88d464ffb6fcd3806d3b>#text(" Let ")#mi("{Cay(G,S)}")#text(" be a ")#mi("{k}")#text("-regular Cayley graph in a finite group ")#mi("{G}")#text(". Assume the following:")

#list(
[#text("(i) (Quasirandomness) ")#mi("{G}")#text(" is ")#tao-math("{c \\left|G\\right|^\\alpha}", block: false)#text("-quasirandom for some ")#mi("{c,\\alpha>0}")#text(".")],
[#text("(ii) (Flattening of random walk) One has ")#metadata(none) <tao-5dc27af287fa554aa10f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| \\mu^{*n} \\right\\|_{\\ell^2(G)} \\leq C \\left|G\\right|^{-1/2+\\beta}", block: true)]]

#text("for some ")#mi("{C, \\beta, n > 0}")#text(" with ")#mi("{\\beta < \\alpha/2}")#text(" and ")#tao-math("{n \\leq C \\log \\left|G\\right|}", block: false)#text(", where ")#tao-math("{\\mu := \\frac{1}{\\left|S\\right|} \\sum_{s \\in S} \\delta_s}", block: false)#text(" and ")#mi("{\\mu^{*n}}")#text(" is the ")#mi("{n}")#text("-fold convolution of ")#mi("{\\mu}")#text(".")]
)

#text("Then ")#mi("{G}")#text(" is a two-sided ")#mi("{\\epsilon}")#text("-expander for some ")#mi("{\\epsilon>0}")#text(" depending only on ")#mi("{c,\\alpha,C,\\beta,k}")#text(", if ")#tao-math("{\\left|G\\right|}", block: false)#text(" is sufficiently large depending on these quantities. If we replace ")#mi("{\\mu}")#text(" by ")#mi("{\\nu := \\frac{1}{2}\\delta_1 + \\frac{1}{2} \\mu}")#text(" in the flattening hypothesis, then ")#mi("{G}")#text(" is a one-sided ")#mi("{\\epsilon}")#text("-expander instead.")
]

#emph[#text("Proof:")]#text(" We allow implied constants to depend on ")#mi("{c, \\alpha, C, \\beta}")#text(". We will just prove the first claim, as the second claim is similar. By Exercise 5 from ")#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/")[#text("Notes 2")]#text(", it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mu^{*m} - \\frac{1}{\\left|G\\right|} \\right\\|_{\\ell^2(G)} \\ll \\left|G\\right|^{-1}", block: true)]]

#text("(say) for some ")#tao-math("{m = O(\\log \\left|G\\right|)}", block: false)#text(". But from Proposition ")#link(<tao-1b64e6e0abf6d3eaa61a>)[#text("3")]#text(" (with ")#tao-math("{f := \\mu^{*m}-\\frac{1}{\\left|G\\right|}}", block: false)#text(" and ")#mi("{g := \\mu^{*n}}")#text(") and the hypotheses we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mu^{*(m+n)} - \\frac{1}{\\left|G\\right|} \\right\\|_{\\ell^2(G)} \\ll \\left|G\\right|^{-\\alpha/2+\\beta} \\left\\| \\mu^{*m} - \\frac{1}{\\left|G\\right|} \\right\\|_{\\ell^2(G)}", block: true)]]

#text("for any ")#mi("{m \\geq 0}")#text(". Iterating this (starting from, say, ")#mi("{m=n}")#text(", and advancing in steps of ")#mi("{n}")#text(" ")#mi("{O(1)}")#text(" times) we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Obtain an alternate proof of the above result that proceeds directly from the spectral decomposition of the adjacency operator ")#mi("{Af := f * \\mu}")#text(" into eigenvalues and eigenvectors and quasirandomness, rather than through Exercise 5 from Notes 2 and Proposition ")#link(<tao-1b64e6e0abf6d3eaa61a>)[#text("3")]#text(". (This alternate approach is closer in spirit to the arguments of ")#link("http://www.ams.org/mathscinet-getitem?mr=1131400")[#text("Sarnak-Xue")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2415383")[#text("Bourgain-Gamburd")]#text(", though the two approaches are largely equivalent in the final analysis.)")
]

#text("Informally, the flattening hypothesis in Proposition ")#link(<tao-88d464ffb6fcd3806d3b>)[#text("4")]#text(" asserts that by time ")#tao-math("{O(\\log \\left|G\\right|)}", block: false)#text(", the random walk has expanded to the point where it is covering a large portion of the group ")#mi("{G}")#text(" (roughly speaking, it is spread out over a set of size at least ")#tao-math("{\\left|G\\right|^{1-2\\beta}}", block: false)#text("). The point is that the scale of this set is large enough for the quasirandomness properties of the group ")#mi("{G}")#text(" to then mix the random walk rapidly towards the uniform distribution. However, this proposition provides no tools with which to ")#emph[#text("prove")]#text(" this flattening property; this task will be a focus of subsequent notes.")

#text("The following exercise extends some of the above theory from quasirandom groups to “virtually quasirandom” groups, which have a bounded index subgroup that is quasirandom, but need not themselves be quasirandom.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Virtually quasirandom groups)")]#text(" Let ")#mi("{G}")#text(" be a finite group that contains a normal ")#mi("{D}")#text("-quasirandom subgroup ")#mi("{G^{\\prime}}")#text(" of index at most ")#mi("{K}")#text(".")

#list(
[#text("(i) If ")#mi("{f, g \\in \\ell^2(G)}")#text(", and at least one of ")#mi("{f, g}")#text(" has mean zero on every coset of ")#mi("{G^{\\prime}}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f*g\\right\\|_{\\ell^2(G)} \\leq D^{-1/2} \\left|G\\right|^{1/2} \\left\\|f\\right\\|_{\\ell^2(G)} \\left\\|g\\right\\|_{\\ell^2(G)}.", block: true)]]],
[#text("(ii) If ")#tao-math("{\\left|D\\right| \\geq c \\left|G\\right|^\\alpha}", block: false)#text(" for some ")#mi("{c,\\alpha > 0}")#text(", and ")#mi("{Cay(G,S)}")#text(" is a connected ")#mi("{k}")#text("-regular Cayley graph obeying ")#link(<tao-5dc27af287fa554aa10f>)[#text("(1)")]#text(" for some ")#mi("{C, \\beta, n > 0}")#text(" with ")#mi("{\\beta < \\alpha/2}")#text(" and ")#tao-math("{n \\leq C \\log \\left|G\\right|}", block: false)#text(", show that ")#mi("{G}")#text(" is a two-sided ")#mi("{\\epsilon}")#text("-expander for some ")#mi("{\\epsilon>0}")#text(" depending only on ")#mi("{c,\\alpha,C,\\beta,k,K}")#text(".")]
)
]

#heading(level: 1)[#strong[#text(" — 2. An algebraic description of quasirandomness (optional) — ")]]

#text("As defined above, quasirandomness is a property of representations. However, one can reformulate this property (at a qualitative level, at least) in a more algebraic fashion, by means of ")#link("http://en.wikipedia.org/wiki/Jordan%E2%80%93Schur_theorem")[#text("Jordan’s theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Jordan’s theorem)")]#text(" Let ")#mi("{G}")#text(" be a finite subgroup of ")#mi("{U_d({\\bf C})}")#text(" for some ")#mi("{d \\geq 1}")#text(". Then ")#mi("{G}")#text(" contains a normal abelian subgroup of index at most ")#mi("{K(d)}")#text(", where ")#mi("{K(d)}")#text(" depends only on ")#mi("{d}")#text(".")
]

#text("A proof of this theorem (giving a rather poor value of ")#mi("{K(d)}")#text(") may be found in this previous blog post. The optimal value of ")#mi("{K(d)}")#text(" is known for almost all ")#mi("{d}")#text(", thanks to the classification of finite simple groups: for instance, it is a result of Collins that ")#mi("{K(d)=(d+1)!}")#text(" for ")#mi("{d \\geq 71}")#text(" (which is attained with the example of the symmetric group ")#mi("{S_{d+1}}")#text(" which acts on the space ")#mi("{{\\bf C}^{d+1}_0}")#text(" of ")#mi("{d+1}")#text("-dimensional complex vectors whose coefficients sum to zero).")

#text("Jordan’s theorem can be used to give a qualitative description of quasirandomness, providing a converse to Exercises ")#link(<tao-1ef5890d626a5c79f9c6>)[#text("3")]#text(" and ")#link(<tao-052c4bed7c1f451e673b>)[#text("4")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Let ")#mi("{D>1}")#text(" be an integer. Let ")#mi("{G}")#text(" be a perfect finite group, with the property that all proper normal subgroups of ")#mi("{G}")#text(" have index greater than ")#mi("{K(D-1)}")#text(", where ")#mi("{K(D-1)}")#text(" is the quantity in Jordan’s theorem. Show that ")#mi("{G}")#text(" is ")#mi("{D}")#text("-quasirandom.")

#text("Conclude in particular that any finite simple nonabelian group of cardinality greater than ")#mi("{K(D-1)}")#text(" is ")#mi("{D}")#text("-quasirandom.")
]

#text("By using the classification of finite simple groups more carefully, ")#link("http://www.ams.org/mathscinet-getitem?mr=2800484")[#text("Nikolov and Pyber")]#text(" were able to replace ")#mi("{K(D-1)}")#text(" here by ")#mi("{10^{10} D^2}")#text(". Using related arguments, they also showed that if ")#mi("{G}")#text(" was not ")#mi("{D}")#text("-quasirandom, then there was a subset ")#mi("{A}")#text(" of ")#mi("{G}")#text(" with cardinality ")#tao-math("{\\gg \\left|G\\right|/D}", block: false)#text(" such that ")#mi("{A^3 \\neq G}")#text(", thus giving a reasonably tight converse to Exercise ")#link(<tao-8f455bba4522752c63bb>)[#text("10")]#text(".")

#heading(level: 1)[#strong[#text(" — 3. A weak form of Selberg’s 3/16 theorem (optional) — ")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" This section presumes some familiarity with Riemannian geometry, as well as the functional analysis of Sobolev spaces and distributions. See for instance ")#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/")[#text("this blog post")]#text(" for a very brief introduction to Riemannian geometry, and these ")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("two")]#text(" ")#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/")[#text("previous posts")]#text(" for an introduction to distributions and Sobolev spaces.")
]

#text("We now give an application of quasirandomness to establish the following result, first observed explicitly ")#link("http://www.ams.org/mathscinet-getitem?mr=963118")[#text("by Lubotsky, Phillips and Sarnak")]#text(" as a corollary of a famous ")#link("http://www.ams.org/mathscinet-getitem?mr=182610")[#text("theorem of Selberg")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Selberg’s expander construction)")]#text(" ")#metadata(none) <tao-ade534b1a10c41d6c2d7>#text(" If ")#mi("{S}")#text(" is a symmetric set of generators of ")#mi("{SL_2({\\bf Z})}")#text(" that does not contain the identity, then the Cayley graphs ")#mi("{Cay( SL_2(F_p), \\pi_p(S) )}")#text(" form a one-sided expander family, where ")#mi("{\\pi_p: SL_2({\\bf Z}) \\rightarrow SL_2(F_p)}")#text(" is the obvious projection homomorphism, and ")#mi("{p}")#text(" ranges over primes.")
]

#text("This is the ")#mi("{d=2}")#text(" analogue of Margulis’s expander construction (Corollary 13 from ")#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/")[#text("Notes 2")]#text("), except that the modulus ")#mi("{n}")#text(" has been restricted here to be prime. This restriction can be removed with some additional effort, but we will not discuss this issue here. The condition that ")#mi("{S}")#text(" generates the entire group ")#mi("{SL_2({\\bf Z})}")#text(" can be substantially relaxed; we will discuss this point in later notes.")

#text("In the property (T) approach to expansion, one passed from discrete groups such as ")#mi("{SL_d({\\bf Z})}")#text(" to continuous groups such as ")#mi("{SL_d({\\bf R})}")#text(", in order to take advantage of tools from analysis (such as limits). Similarly, to prove Theorem ")#link(<tao-ade534b1a10c41d6c2d7>)[#text("6")]#text(", we will pass from ")#mi("{SL_2({\\bf Z})}")#text(" to ")#mi("{SL_2({\\bf R})}")#text(". Actually, it will be convenient to work with the quotient space ")#mi("{{\\bf H} := SL_2({\\bf R})/SO_2({\\bf R})}")#text(", better known as the ")#link("http://en.wikipedia.org/wiki/Hyperbolic_geometry#Models_of_the_hyperbolic_plane")[#text("hyperbolic plane")]#text(". We will endow this plane with the structure of a ")#link("http://en.wikipedia.org/wiki/Riemannian_manifold")[#text("Riemannian manifold")]#text(", in order to access the ")#link("http://en.wikipedia.org/wiki/Laplace%E2%80%93Beltrami_operator")[#text("Laplace-Beltrami operator")]#text(" on that plane, which is a continuous analogue (after some renormalisation) of the adjacency operator of a Cayley graph, which enjoys some nice exact identities which are difficult to discern in the discrete world.")

#text("We now therefore digress from the topic of expansion to recall the geometry of the hyperbolic plane. It will be convenient to switch between a number of different coordinatisations of this plane. Our primary model will be the half-plane model:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 7 (Poincaré half-plane model)")]#text(" The ")#link("http://en.wikipedia.org/wiki/Poincar%C3%A9_half-plane_model")[#text("Poincaré half-plane")]#text(" is the upper half-plane ")#mi("{{\\bf H} := \\{ x+iy \\in {\\bf C}: y>0 \\}}")#text(" with the Riemannian metric ")#mi("{ds^2 := \\frac{dx^2 + dy^2}{y^2}}")#text(". The (left) action of ")#mi("{SL_2({\\bf R})}")#text(" on this half-plane is given by the formula")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} z := \\frac{az+b}{cz+d}.")]]

#text("One easily verifies that this gives an isometric action on ")#mi("{{\\bf H}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" Verify that ")#mi("{SL_2({\\bf R})}")#text(" acts isometrically and transitively on ")#mi("{{\\bf H}}")#text(", with stabiliser group isomorphic to ")#mi("{SO_2({\\bf R})}")#text("; thus ")#mi("{{\\bf H}}")#text(" is isomorphic (as an ")#mi("{SL_2({\\bf R})}")#text("-homogeneous space) to ")#mi("{SL_2({\\bf R})/SO_2({\\bf R})}")#text(".")
]

#text("Note that in some of the literature, a right action is used instead of a left action, leading to some reversals in the notational conventions used below, but this does not lead to any essential changes in the arguments or results.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" Show that the distance ")#mi("{d(z,w)}")#text(" between two points ")#mi("{z,w \\in {\\bf H}}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#tao-math("\\cosh d(z,w) = 1 + 2 \\frac{\\left|z-w\\right|^2}{4 \\text{Im}(z) \\text{Im}(w)}.", block: true)]]
]

#text("We can also use the model of the ")#link("http://en.wikipedia.org/wiki/Poincar%C3%A9_disk_model")[#text("Poincaré disk")]#text(" ")#mi("{{\\bf D} := \\{ a+ib \\in {\\bf C}: a^2+b^2 < 1 \\}}")#text(" with the Riemannian metric ")#mi("{ds^2 := 4 \\frac{da^2+db^2}{(1-a^2-b^2)^2}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Show that the ")#link("http://en.wikipedia.org/wiki/Cayley_transform")[#text("Cayley transform")]#text(" ")#mi("{z \\mapsto \\frac{z-i}{z+i}}")#text(" is an isometric isomorphism from the half-plane ")#mi("{{\\bf H}}")#text(" to the disk ")#mi("{{\\bf D}}")#text(".")
]

#text("Expressing an element ")#mi("{a+ib}")#text(" of the Poincaré disk in exponential polar coordinates as ")#mi("{\\tanh(\\rho/2) e^{i\\theta}}")#text(", we can also model the Poincaré disk (in slightly singular coordinates) as the half-cylinder ")#mi("{\\{ (\\rho,\\theta): \\rho \\in [0,+\\infty); \\theta \\in {\\bf R}/2\\pi{\\bf Z}\\}}")#text(" with metric ")#mi("{ds^2 = d\\rho^2 + \\sinh^2 \\rho d\\theta^2}")#text(". (Compare with the Euclidean plane in polar coordinates, which is similar but with the ")#mi("{\\sinh^2 \\rho}")#text(" factor replaced by ")#mi("{\\rho^2}")#text(", or the sphere in Euler coordinates, which is also similar but with ")#mi("{\\rho}")#text(" restricted to ")#mi("{[0,\\pi]}")#text(" and ")#mi("{\\sinh^2 \\rho}")#text(" replaced by ")#mi("{\\sin^2 \\rho}")#text(". This similarity reflects the fact that these three Riemannian surfaces have constant curvature ")#mi("{-1, 0, +1}")#text(" respectively.)")

#text("The action of ")#mi("{SL_2({\\bf R})}")#text(" can of course be described explicitly in the disk or half-plane models, but we will not need these explicit formulae here.")

#text("A Riemannian metric on a manifold always generates a measure ")#mi("{d\\mu}")#text(" on that manifold. For the Poincaré half-plane, the measure is ")#mi("{d\\mu = \\frac{dx dy}{y^2}}")#text(". For the Poincaré disk, it is ")#mi("{d\\mu = 4 \\frac{da db}{(1-a^2-b^2)^2}}")#text(". For the half-cylinder, it is ")#mi("{\\sinh \\rho\\ d \\rho d\\theta}")#text(". In all cases, the action of ")#mi("{SL_2({\\bf R})}")#text(" will preserve the measure, because it preserves the metric, thus one can view ")#mi("{d\\mu}")#text(" as a Haar measure on the hyperbolic plane.")

#text("A Riemannian metric also generates a Laplace-Beltrami operator ")#mi("{\\Delta}")#text(". In the Poincaré half-plane model, it is")

#align(center)[#tao-fit-display[#mitex("\\Delta = y^2 ( \\frac{\\partial^2}{\\partial x^2} + \\frac{\\partial^2}{\\partial y^2} );")]]

#text("in the Poincaré disk model, it is")

#align(center)[#tao-fit-display[#mitex("\\Delta = \\frac{(1-a^2-b^2)^2}{4} ( \\frac{\\partial^2}{\\partial a^2} + \\frac{\\partial^2}{\\partial b^2} );")]]

#text("and in the half-cylinder model, it is")

#align(center)[#tao-fit-display[#mitex("\\Delta = \\frac{\\partial^2}{\\partial \\rho^2} + \\frac{1}{\\sinh \\rho} \\frac{\\partial}{\\partial \\rho} + \\frac{1}{\\sinh^2 \\rho} \\frac{\\partial^2}{\\partial \\theta^2}.")]]

#text("Again, in all cases, the Laplacian will commute with the action of ")#mi("{SL_2({\\bf R})}")#text(", because this action preserves the metric.")

#text("The discrete group ")#mi("{SL_2({\\bf Z})}")#text(" acts on the hyperbolic plane, giving rise to a quotient ")#mi("{X(1) := SL_2({\\bf Z}) \\backslash {\\bf H}}")#text(", known as the ")#link("http://en.wikipedia.org/wiki/Modular_curve")[#text("principal modular curve")]#text(" of level ")#mi("{1}")#text(". This quotient can also be viewed by taking the (closure of a) ")#link("http://en.wikipedia.org/wiki/Fundamental_domain")[#text("fundamental domain")]

#align(center)[#tao-fit-display[#tao-math("\\Omega := \\{ z \\in {\\bf H}: \\left|\\text{Re}(z)\\right| \\leq 1/2; \\left|z\\right| \\geq 1 \\}", block: true)]]

#text("and then identifying ")#mi("{-1/2+it}")#text(" with ")#mi("{1/2+it}")#text(" on the left and right sides of this domain, and also identifying ")#mi("{z}")#text(" with ")#mi("{-1/z}")#text(" on the lower boundary of this domain. The quotient ")#mi("{X(1)}")#text(" is not compact, but it does have finite measure with respect to ")#mi("{\\mu}")#text("; indeed, outside of a compact set, ")#mi("{X(1)}")#text(" behaves like the ")#emph[#text("cusp")]#text(" ")#metadata(none) <tao-d60384034b77c13c2840>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\{ x+iy: -1/2 \\leq x \\leq 1/2; y > C \\}")]]



#text(" for any constant ")#mi("{C>1}")#text(", again identifying the ")#mi("{x=-1/2}")#text(" boundary with the ")#mi("{x=1/2}")#text(" boundary, and this strip has measure")

#align(center)[#tao-fit-display[#mitex("\\int_C^\\infty\\int_{-1/2}^{1/2} \\frac{dx dy}{y^2} < \\infty.")]]

#text("Thus ")#mi("{\\mu}")#text(" descends to a finite Haar measure on ")#mi("{X(1)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" One can interpret the modular curve geometrically as follows. As in the previous set of notes, one can think of ")#mi("{SL_2({\\bf R})}")#text(" as the space of all unimodular lattices in ")#mi("{{\\bf R}^2}")#text(" (or equivalently, in ")#mi("{{\\bf C}}")#text(") with two marked generators ")#mi("{z_1, z_2 \\in {\\bf C}}")#text(" with ")#mi("{\\text{Im}(\\overline{z_1} z_2)=1}")#text(". We can then map ")#mi("{SL_2({\\bf R})}")#text(" to the Poincaré half-plane ")#mi("{{\\bf H}}")#text(" by sending such a lattice with generators ")#mi("{z_1,z_2}")#text(" to the point ")#mi("{z_2/z_1}")#text("; note that the fibers of this map correspond to rotations of the lattice and marked generators, thus identifying ")#mi("{{\\bf H}}")#text(" with ")#mi("{SL_2({\\bf R})/SO_2({\\bf R})}")#text(". The action of ")#mi("{SL_2({\\bf Z})}")#text(" on ")#mi("{{\\bf H}}")#text(" corresponds to moving the generators around while keeping the lattice (or more precisely, the lattice modulo rotations) fixed. The (interior of the) fundamental domain ")#mi("{\\Omega}")#text(" then corresponds to the selection of generators given by setting ")#mi("{z_1}")#text(" to be the non-zero lattice element of smallest norm, and ")#mi("{z_2}")#text(" to be the generator whose ")#mi("{z_1}")#text(" component lies between ")#mi("{-z_1/2}")#text(" and ")#mi("{+z_1/2}")#text(".")
]

#text("The quotient ")#mi("{X(1)}")#text(" is not quite a smooth Riemannian manifold, due to the presence of partially fixed points of the ")#mi("{SL_2({\\bf Z})}")#text(" action at ")#mi("{+i}")#text(" and ")#mi("{\\pm 1/2 + \\sqrt{3}/2 i}")#text(" (of order ")#mi("{2}")#text(" and order ")#mi("{3}")#text(" respectively), and is thus technically an ")#link("http://en.wikipedia.org/wiki/Orbifold")[#text("orbifold")]#text(" rather than a manifold. However, this distinction turns out to not significantly affect the analysis and will be glossed over here.")

#text("The Laplace-Beltrami operator ")#mi("{\\Delta}")#text(" is defined on smooth compactly supported functions ")#mi("{f \\in C^\\infty_c({\\bf H})}")#text(" on ")#mi("{{\\bf H}}")#text(", and then descends to an operator on smooth compactly supported functions ")#mi("{f \\in C^\\infty_c(X(1))}")#text(" on ")#mi("{X(1)}")#text(". (Here, we use the smooth structure on ")#mi("{X(1)}")#text(" inherited from ")#mi("{{\\bf H}}")#text(", thus a function is smooth at a point in ")#mi("{X(1)}")#text(" if it lifts to a function smooth at the preimage of that point.) On ")#mi("{{\\bf H}}")#text(", we have the integration by parts formula")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf H} (-\\Delta f) g\\ d\\mu = \\int_{\\bf H} \\langle \\nabla f, \\nabla g \\rangle\\ d\\mu")]]

#text("where ")#mi("{\\nabla}")#text(" is the gradient with respect to the Riemannian metric, and ")#mi("{\\langle,\\rangle}")#text(" the inner product; in the half-plane coordinates, we have")

#align(center)[#tao-fit-display[#mitex("\\langle \\nabla f, \\nabla g \\rangle = y^2 (\\frac{\\partial f}{\\partial x} \\frac{\\partial g}{\\partial x} + \\frac{\\partial f}{\\partial y} \\frac{\\partial g}{\\partial y}),")]]

#text("in the disk model, it is")

#align(center)[#tao-fit-display[#mitex("\\langle \\nabla f, \\nabla g \\rangle = \\frac{(1-a^2-b^2)^2}{4} (\\frac{\\partial f}{\\partial a} \\frac{\\partial g}{\\partial a} + \\frac{\\partial f}{\\partial b} \\frac{\\partial g}{\\partial b})")]]

#text("and in the half-cylinder model, it is")

#align(center)[#tao-fit-display[#mitex("\\langle \\nabla f, \\nabla g \\rangle = \\frac{\\partial f}{\\partial \\rho} \\frac{\\partial g}{\\partial \\rho} + \\frac{1}{\\tanh^2 \\rho} \\frac{\\partial f}{\\partial \\theta} \\frac{\\partial g}{\\partial \\theta}.")]]

#text("In particular, we have the positive definiteness property")

#align(center)[#tao-fit-display[#tao-math("\\langle -\\Delta f, f \\rangle_{L^2({\\bf H}, \\mu)} = \\int_{\\bf H} \\left|\\nabla f\\right|^2\\ d\\mu \\geq 0", block: true)]]

#text("for all ")#mi("{f \\in C^\\infty_c({\\bf H})}")#text(". This descends to ")#mi("{X(1)}")#text(":")

#align(center)[#tao-fit-display[#tao-math("\\langle -\\Delta f, f \\rangle_{L^2(X(1), \\mu)} = \\int_{X(1)} \\left|\\nabla f\\right|^2\\ d\\mu \\geq 0", block: true)]]

#text("Thus ")#mi("{-\\Delta}")#text(" is a symmetric positive-definite densely-defined operator on ")#mi("{L^2(X(1),\\mu)}")#text(". One can in fact show (by solving some PDE, such as the wave equation or the resolvent equation, and exploiting at some point the fact that the Riemannian manifold ")#mi("{X(1)}")#text(" is ")#link("http://en.wikipedia.org/wiki/Geodesic_manifold")[#text("complete")]#text(") that ")#mi("{-\\Delta}")#text(" is ")#link("http://en.wikipedia.org/wiki/Self-adjoint_operator")[#text("essentially self-adjoint")]#text(" and is thus subject to the ")#link("http://en.wikipedia.org/wiki/Spectral_theorem")[#text("spectral theorem")]#text(", but we will avoid using the full force of spectral theory here.")

#text("Since ")#mi("{X(1)}")#text(" has finite measure and ")#mi("{\\Delta 1 = 0}")#text(", we see that ")#mi("{1 \\in L^2(X(1),\\mu)}")#text(" is an eigenfunction of ")#mi("{\\Delta}")#text(" (or ")#mi("{-\\Delta}")#text(") with eigenvalue zero. We eliminate this eigenfunction by working in the space ")#mi("{L^2(X(1))_0}")#text(" (or ")#mi("{C^\\infty_c(X(1))_0}")#text(") of functions in ")#mi("{L^2(X(1))}")#text(" (or ")#mi("{C^\\infty_c(X(1))}")#text(") of mean zero. Let us now define the ")#emph[#text("spectral gap")]#text(" ")#mi("{\\lambda_1(X(1))}")#text(" to be the quantity")

#align(center)[#tao-fit-display[#tao-math("\\lambda_1(X(1)) := \\inf \\{ \\int_{X(1)} \\left|\\nabla f\\right|^2\\ d\\mu: f \\in C^\\infty_c(X(1))_0; \\left\\|f\\right\\|_{L^2(X(1))} = 1 \\}.", block: true)]]

#text("Then ")#mi("{\\lambda_1(X(1)) \\geq 0}")#text(". Using the spectral theorem, one can interpret the spectral gap as the infimum of the spectrum ")#mi("{\\sigma(-\\Delta)}")#text(" of the (negative) Laplacian on ")#mi("{L^2(X(1))_0}")#text(". Note also that one can take ")#mi("{f}")#text(" to be either real or complex valued, as this will not affect the value of the spectral gap. Also by a truncation and mollification argument we may allow ")#mi("{f}")#text(" to range in ")#mi("{L^2(X(1))_0}")#text(" instead of ")#mi("{C^\\infty_c(X(1))_0}")#text(" here if desired.")

#text("We have the following bounds:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8 (Spectral gap of ")#mi("{X(1)}")#text(")")]#text(" ")#metadata(none) <tao-b00f8d905bef60171d59>#text(" We have ")#mi("{0 < \\lambda_1(X(1)) \\leq \\frac{1}{4}}")#text(".")
]

#emph[#text("Proof:")]#text(" We first establish the upper bound ")#mi("{\\lambda_1(X(1)) \\leq \\frac{1}{4}}")#text(". It will suffice to find non-zero functions ")#mi("{f \\in C^\\infty_c(X(1))_0}")#text(" whose Rayleigh quotient")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\int_{X(1)} \\left|\\nabla f\\right|^2\\ d\\mu}{\\int_{X(1)} \\left|f\\right|^2\\ d\\mu}", block: true)]]

#text("is arbitrarily close to ")#mi("{1/4}")#text(".")

#text("We will restrict attention to smooth compactly supported functions ")#mi("{f}")#text(" supported on the cusp ")#link(<tao-d60384034b77c13c2840>)[#text("(2)")]#text(" for a fixed ")#mi("{C}")#text(" (e.g. one can take ")#mi("{C=2}")#text("). In coordinates, the Raleigh quotient becomes")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\int_C^\\infty \\int_{-1/2}^{1/2} \\left|f_x\\right|^2 + \\left|f_y\\right|^2\\ dx dy}{\\int_C^\\infty \\int_{-1/2}^{1/2} \\frac{\\left|f\\right|^2}{y^2}\\ dx dy}", block: true)]]

#text("where we use subscripts to denote partial differentiation, while the mean zero condition becomes")

#align(center)[#tao-fit-display[#mitex("\\int_C^\\infty \\int_{-1/2}^{1/2} \\frac{f}{y^2}\\ dx dy = 0.")]]

#text("To build such functions, we select a large parameter ")#mi("{R \\gg C}")#text(", and choose a function ")#mi("{f(x,y) = f_R(y)}")#text(" that depends only on the ")#mi("{y}")#text(" variable, is supported on the region ")#mi("{\\{ C < y < 2R \\}}")#text(", and equals ")#mi("{y^{1/2}}")#text(" in the region ")#mi("{\\{ 2C \\leq y \\leq R \\}}")#text(" and is smoothly truncated in the intermediate region (assigning enough negative mass in the region ")#mi("{\\{ C < y \\leq 2C \\}}")#text(" to obtain the mean zero condition). A brief calculation shows that")

#align(center)[#tao-fit-display[#tao-math("\\int_C^\\infty \\int_{-1/2}^{1/2} \\frac{\\left|f\\right|^2}{y^2}\\ dx dy = \\log R + O(1)", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\int_C^\\infty \\int_{-1/2}^{1/2} \\left|f_x\\right|^2 + \\left|f_y\\right|^2\\ dx dy = \\frac{1}{4} \\log R + O(1)", block: true)]]

#text("(where the implied constant can depend on ")#mi("{C}")#text(" but not on ")#mi("{R}")#text("), and so the claim follows by sending ")#mi("{R \\rightarrow \\infty}")#text(".")

#text("Now we show the lower bound ")#mi("{\\lambda_1(X(1)) > 0}")#text(". Suppose this claim failed; then we may find a sequence of functions ")#mi("{f_n \\in C^\\infty_c(X(1))_0}")#text(" with ")#tao-math("{\\left\\|f_n\\right\\|_{L^2(X(1))}=1}", block: false)#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\int_{X(1)} \\left|\\nabla f_n\\right|^2\\ d\\mu= o(1)", block: true)]]

#text("where ")#mi("{o(1)}")#text(" denotes a quantity that goes to zero as ")#mi("{n \\rightarrow \\infty}")#text(". We can take the ")#mi("{f_n}")#text(" to be real valued.")

#text("To deal with the non-compact portion of ")#mi("{X(1)}")#text(" (i.e. the strip ")#link(<tao-d60384034b77c13c2840>)[#text("(2)")]#text(") we now use ")#link("http://en.wikipedia.org/wiki/Hardy%27s_inequality")[#text("Hardy’s inequality")]#text(". Observe that if ")#mi("{f}")#text(" is smooth, real-valued, and compactly supported on a cusp ")#link(<tao-d60384034b77c13c2840>)[#text("(2)")]#text(" for some ")#mi("{C}")#text(" (we can take ")#mi("{C=2}")#text(" as before), then by integration by parts")

#align(center)[#tao-fit-display[#mitex("\\int_C^\\infty \\int_{-1/2}^{1/2} \\frac{f f_y}{y}\\ dx dy = \\frac{1}{2} \\int_C^\\infty \\int_{-1/2}^{1/2} \\frac{f^2}{y^2}\\ dx dy")]]

#text("and hence by Cauchy-Schwarz")

#align(center)[#tao-fit-display[#tao-math("\\int_C^\\infty \\int_{-1/2}^{1/2} \\frac{\\left|f\\right|^2}{y^2}\\ dx dy \\leq 4 \\int_C^\\infty \\int_{-1/2}^{1/2} \\left|f_y\\right|^2\\ dx dy.", block: true)]]

#text("Applying this to a truncated version ")#mi("{f(x,y) = \\chi(y/R) f_n(x,y)}")#text(" of ")#mi("{f_n}")#text(" for some ")#mi("{R>C}")#text(" and some smooth cutoff ")#mi("{\\chi: {\\bf R}^+ \\rightarrow [0,1]}")#text(" supported on ")#mi("{[1,+\\infty)}")#text(" that equals one on ")#mi("{[2,+\\infty)}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\int_{R}^\\infty \\int_{-1/2}^{1/2} \\frac{\\left|f_n\\right|^2}{y^2}\\ dx dy \\leq 4 \\int_R^\\infty \\int_{-1/2}^{1/2}\\left|(f_n)_y\\right|^2\\ dx dy + O( \\int_R^{2R} \\frac{\\left|f_n\\right|^2}{y^2}\\ dx dy ).", block: true)]]

#text("For any ")#mi("{\\epsilon > 0}")#text(", one can use the pigeonhole principle to find an ")#mi("{R = O_\\epsilon(1)}")#text(" (depending on ")#mi("{n}")#text(") such that")

#align(center)[#tao-fit-display[#tao-math("\\int_R^{2R} \\frac{\\left|f_n\\right|^2}{y^2}\\ dx dy \\leq \\epsilon", block: true)]]

#text("and thus we see that")

#align(center)[#tao-fit-display[#tao-math("\\int_{R_\\epsilon}^\\infty \\int_{-1/2}^{1/2} \\frac{\\left|f_n\\right|^2}{y^2}\\ dx dy \\ll \\epsilon + o(1)", block: true)]]

#text("for some ")#mi("{R_\\epsilon}")#text(" depending only on ")#mi("{\\epsilon}")#text(". Thus, the probability measures ")#tao-math("{\\left|f_n\\right|^2\\ d\\mu}", block: false)#text(" form a ")#link("http://en.wikipedia.org/wiki/Tightness_of_measures")[#text("tight sequence of measures")]#text(" in ")#mi("{X(1)}")#text(". As the ")#mi("{f_n}")#text(" are also locally uniformly bounded in the Sobolev space ")#mi("{H^1(X(1))}")#text(", we conclude from the ")#link("http://en.wikipedia.org/wiki/Rellich%E2%80%93Kondrachov_theorem")[#text("Rellich compactness theorem")]#text(" (or the ")#link("http://en.wikipedia.org/wiki/Poincare_inequality")[#text("Poincaré inequality")]#text(") that after passing to a subsequence, the ")#mi("{f_n}")#text(" converge strongly in ")#mi("{L^2(X(1))}")#text(" to a limit ")#mi("{f}")#text(", which then has ")#mi("{L^2(X(1))}")#text(" norm one, mean zero, and ")#mi("{\\nabla f = 0}")#text(" in a distributional sense. But then by the ")#link("http://en.wikipedia.org/wiki/Poincare_inequality")[#text("Poincaré inequality")]#text(", ")#mi("{f}")#text(" is constant, which is absurd. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" One can in fact establish after some calculation using the theory of modular forms that ")#mi("{\\lambda_1(X(1))}")#text(" is exactly ")#mi("{1/4}")#text(", but we will not do so here. By modifying the above arguments, one can in fact show that ")#mi("{-\\Delta}")#text(" on ")#mi("{X(1)}")#text(" has absolutely continuous spectrum on ")#mi("{[1/4,+\\infty)}")#text(".")
]

#text("Now we move back towards the task of establishing expansion for the Cayley graphs ")#mi("{Cay( SL_2(F_p), \\pi_p(S) )}")#text(". Let ")#mi("{\\Gamma(p)}")#text(" denote the kernel of the projection map ")#mi("{\\pi_p}")#text("; this is the group of matrices in ")#mi("{SL_2({\\bf Z})}")#text(" that are equal to ")#mi("{1}")#text(" mod ")#mi("{p}")#text(", and is known as a ")#link("http://en.wikipedia.org/wiki/Congruence_subgroup")[#text("principal congruence subgroup")]#text(" of ")#mi("{SL_2({\\bf Z})}")#text(". It is a finite index normal subgroup of ")#mi("{SL_2({\\bf Z})}")#text(", and the quotient ")#mi("{SL_2({\\bf Z})/\\Gamma(p)}")#text(" can easily be seen to be isomorphic to ")#mi("{SL_2(F_p)}")#text(". In analogy with what we did for ")#mi("{X(1)}")#text(", we can then define the principal modular curve ")#mi("{X(p) := \\Gamma(p) \\backslash {\\bf H}}")#text(", and then define the Laplacian ")#mi("{\\Delta}")#text(" on this curve and the spectral gap ")#mi("{\\lambda_1(X(p))}")#text(". At a qualitative level, the geometry of ")#mi("{X(p)}")#text(" is similar to that of ")#mi("{X(1)}")#text(", except that instead of having just one cusp ")#link(<tao-d60384034b77c13c2840>)[#text("(2)")]#text(", there are now multiple cusps (which do not necessarily go to infinity as in ")#link(<tao-d60384034b77c13c2840>)[#text("(2)")]#text(", but may instead go to some other point on the boundary ")#mi("{{\\bf R} \\cup \\{\\infty\\}}")#text(" of the hyperbolic plane).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" One may think of ")#mi("{X(p)}")#text(" as being formed by cutting up a finite number of of ")#mi("{X(1)}")#text("‘s and then (pseudo-)randomly sowing them together to create a tangled orbifold that is a continuous analogue of an expander graph; see ")#link("http://www.ams.org/notices/199511/sarnak.pdf")[#text("this Notices article of Sarnak")]#text(" for more discussion of this perspective. Indeed, one can view ")#mi("{X(p)}")#text(" as a continuous analogue of the Cayley graph ")#mi("{Cay( PSL_2(F_p), \\pi^{\\prime}_p(S))}")#text(", where ")#mi("{S := \\{ \\begin{pmatrix} 1 & 1 \\\\ 0 & 1 \\end{pmatrix}, \\begin{pmatrix} 1 & -1 \\\\ 0 & 1 \\end{pmatrix}, \\begin{pmatrix} 1 & 1 \\\\ 0 & 1 \\end{pmatrix}, \\begin{pmatrix} 0 & -1 \\\\ 1 & 0 \\end{pmatrix} \\}}")#text(", and ")#mi("{\\pi^{\\prime}_p}")#text(" is the projection onto ")#mi("{PSL_2(F_p)}")#text(", with each vertex of the Cayley graph being replaced by a copy of the fundamental domain ")#mi("{\\Omega}")#text(" of ")#mi("{X(1)}")#text(", with these domains then being glued together along their edges as prescribed by the edges of the Cayley graph.")
]

#text("By a routine modification of Proposition ")#link(<tao-b00f8d905bef60171d59>)[#text("8")]#text(", one can show that")

#align(center)[#tao-fit-display[#mitex("0 < \\lambda_1(X(p)) \\leq \\frac{1}{4}.")]]

#text("(Note also that as ")#mi("{X(p)}")#text(" is a finite isometric cover of ")#mi("{X(1)}")#text(", we have the trivial bound ")#mi("{\\lambda_1(X(p)) \\leq \\lambda_1(X(1))}")#text(".) However, these arguments do not keep ")#mi("{\\lambda_1(X(p))}")#text(" ")#emph[#text("uniformly")]#text(" bounded away from zero. Much more is conjectured to be true:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 9 (Selberg’s conjecture)")]#text(" One has ")#mi("{\\lambda_1(X(p)) = \\frac{1}{4}}")#text(" for all ")#mi("{p}")#text(" (not necessarily prime).")
]

#text("This conjecture remains open (though it has been verified numerically for small values of ")#mi("{p}")#text(", in particular for all ")#mi("{p \\leq 857}")#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2338122")[#text("by Booker and Stromgbergsson")]#text("). On the other hand, we have the following celebrated ")#link("http://www.ams.org/mathscinet-getitem?mr=182610")[#text("result of Selberg")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 10 (Selberg’s 3/16 theorem)")]#text(" ")#metadata(none) <tao-257e203cadb786676f65>#text(" One has ")#mi("{\\lambda_1(X(p)) \\geq \\frac{3}{16}}")#text(" for all ")#mi("{p}")#text(" (not necessarily prime).")
]

#text("Selberg’s argument uses a serious amount of number-theoretic machinery (in particular, bounds for ")#link("http://en.wikipedia.org/wiki/Kloosterman_sum")[#text("Kloosterman sums")]#text(") and will not be reproduced here. The ")#mi("{\\frac{3}{16}}")#text(" bound has since been improved; the best bound currently known is ")#mi("{\\frac{975}{4096}}")#text(", due ")#link("http://www.ams.org/mathscinet-getitem?mr=1937203")[#text("to Kim and Sarnak")]#text(" and involving even more number-theoretic machinery (related to the ")#link("http://en.wikipedia.org/wiki/Langlands_program")[#text("Langlands conjectures")]#text("); this argument will also not be discussed further here.")

#text("In the papers of ")#link("http://www.ams.org/mathscinet-getitem?mr=1131400")[#text("by Sarnak and Xue")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1900698")[#text("by Gamburd")]#text(", an argument based primarily on quasirandomness that used only very elementary number theory was introduced, to obtain the following result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 11 (Weak Selberg theorem)")]#text(" ")#metadata(none) <tao-0611e5b49dde1e8c05a9>#text(" One has ")#mi("{\\lambda_1(X(p)) \\geq \\min( \\lambda_1(X(1)), \\frac{5}{36}-o(1) )}")#text(" for all primes ")#mi("{p}")#text(", where ")#mi("{o(1)}")#text(" goes to zero as ")#mi("{p \\rightarrow \\infty}")#text(".")
]

#text("In particular, one has a uniform lower bound ")#mi("{\\lambda_1(X(p)) \\geq c}")#text(" for some absolute constant ")#mi("{c>0}")#text(" (and, since one can compute that ")#mi("{\\lambda_1(X(1)) = \\frac{1}{4}}")#text(", one can in fact take ")#mi("{c=\\frac{5}{36}}")#text("). Despite giving a weaker result than Theorem ")#link(<tao-257e203cadb786676f65>)[#text("10")]#text(", the argument is more flexible and can be applied to other arithmetic surfaces than ")#mi("{X(p)}")#text(", for which the method of Selberg does not seem to apply; see the papers of Sarnak-Xue and Gamburd for further discussion.")

#text("We will not quite prove Theorem ")#link(<tao-0611e5b49dde1e8c05a9>)[#text("11")]#text(" here, but instead establish the following even weaker version which uses the same ideas, but in a slightly less computation-intensive fashion (at the cost of some efficiency in the argument):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 12 (Even weaker Selberg theorem)")]#text(" ")#metadata(none) <tao-fe825095b70929bb3a27>#text(" One has ")#mi("{\\lambda_1(X(p)) \\geq \\min( \\lambda_1(X(1)), \\frac{1}{12} - o(1) )}")#text(" for all primes ")#mi("{p}")#text(".")
]

#text("Of course, this result is still strong enough to supply a uniform lower bound on ")#mi("{\\lambda_1(X(p))}")#text(".")

#text("Before we prove Theorem ")#link(<tao-fe825095b70929bb3a27>)[#text("12")]#text(" (a spectral gap in the continuous world), let us show how it can be transferred to deduce Theorem ")#link(<tao-ade534b1a10c41d6c2d7>)[#text("6")]#text(" (a spectral gap in the discrete world). Suppose for contradiction that Theorem ")#link(<tao-ade534b1a10c41d6c2d7>)[#text("6")]#text(" failed. Then we can find a finite symmetric generating set ")#mi("{S}")#text(" for ")#mi("{SL_2({\\bf Z})}")#text(" (not containing the identity) and a sequence of primes ")#mi("{p_n}")#text(" going to infinity such that the one-sided expansion constant of ")#mi("{Cay( SL_2(F_{p_n}), \\pi_{p_n}(S) )}")#text(" goes to zero. Write ")#mi("{G_n := SL_2(F_{p_n})}")#text(". Applying the weak discrete Cheeger inequality (Exercise 3 from ")#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/")[#text("Notes 2")]#text("), we conclude that we can find non-empty subsets ")#mi("{E_n \\subset G_n}")#text(" of size ")#tao-math("{\\left|E_n\\right| \\leq \\frac{1}{2} \\left|G_n\\right|}", block: false)#text(" which are almost ")#mi("{\\pi_{p_n}(S)}")#text("-invariant in the sense that that ")#tao-math("{\\left|E_n \\pi_{p_n}(S)\\right| = 1+o(1) \\left|E_n\\right|}", block: false)#text(". Since ")#mi("{S}")#text(" generates ")#mi("{SL_2({\\bf Z})}")#text(", we conclude in particular that ")#metadata(none) <tao-d694d81e0716ed3837f3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|E_n \\pi_{p_n}(s) \\Delta E_n\\right| = o(\\left|E_n\\right|)", block: true)]]



#text(" for any ")#mi("{s \\in SL_2({\\bf Z})}")#text(" independent of ")#mi("{n}")#text(".")

#text("The idea now is to pass from this nearly-invariant discrete set ")#mi("{E_n}")#text(" to a nearly-invariant continuous analogue ")#mi("{f_n}")#text(" to which the uniform bound on the spectral gap can be applied to obtain a contradiction. (This argument is similar in spirit to Proposition 9 from ")#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/")[#text("Notes 2")]#text(".)")

#text("We turn to the details. Let ")#mi("{R \\geq 1}")#text(" be a large parameter (independent of ")#mi("{n}")#text(") to be chosen later, and let ")#mi("{z_0}")#text(" be a point on ")#mi("{X(p_n)}")#text(" (avoiding fixed points of the ")#mi("{G_n}")#text(" action); for sake of concretness we can take ")#mi("{z_0}")#text(" to be the projection of ")#mi("{2i \\in {\\bf H}}")#text(" to ")#mi("{X(p_n)}")#text(". Note that ")#mi("{G_n}")#text(" acts on ")#mi("{X(p_n)}")#text(". We consider the function ")#mi("{f_n: X(p_n) \\rightarrow [0,1]}")#text(" defined by the formula")

#align(center)[#tao-fit-display[#mitex("f_n(z) := \\max( \\min( 2 - \\frac{\\text{dist}(z, E_n z_0)}{R}, 1), 0).")]]

#text("This function equals ")#mi("{1}")#text(" when ")#mi("{z}")#text(" is within ")#mi("{R}")#text(" (in the hyperbolic metric) of a point in the orbit ")#mi("{E_n z_0}")#text(", and equals ")#mi("{0}")#text(" when ")#mi("{z}")#text(" is further than ")#mi("{2R}")#text(" of this orbit; in particular, it is compactly supported. The function is also Lipschitz with constant ")#mi("{O(1/R)}")#text(", so ")#tao-math("{\\left|\\nabla f_n\\right| \\leq 1/R}", block: false)#text(" (using a weak derivative).")

#text("The curve ")#mi("{X(p_n)}")#text(" is a ")#tao-math("{\\left|G_n\\right|}", block: false)#text("-fold cover of ")#mi("{X(1)}")#text(" and thus has volume ")#tao-math("{\\left|G_n\\right| \\mu(X(1))}", block: false)#text(". Observe that ")#mi("{f_n}")#text(" equals ")#mi("{1}")#text(" on the ")#mi("{R}")#text("-neighbourhood of any point in ")#mi("{E_n z_0}")#text(". As these points are separated from each other by a bounded distance (independent of ")#mi("{n}")#text(" and ")#mi("{R}")#text("), we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\mu( \\{ x \\in X(p_n): f_n(x)=1 \\} ) \\gg \\left|E_n\\right|,", block: true)]]

#text("where the bound is uniform in ")#mi("{R}")#text(". Conversely, if ")#mi("{\\gamma \\in G_n}")#text(" is not of the form ")#mi("{\\gamma = \\gamma_1 \\pi_{p_n}(\\gamma_2)}")#text(" for some ")#mi("{\\gamma_1 \\in E_n}")#text(" and some ")#mi("{\\gamma_2 \\in SL_2({\\bf Z})}")#text(" within distance ")#mi("{3R}")#text(" from the identity, we have ")#mi("{f_n}")#text(" equal to ")#mi("{0}")#text(" on the ")#mi("{R}")#text("-neighbourhood of ")#mi("{\\gamma z_0}")#text(". There are only ")#mi("{O_R(1)}")#text(" possible choices for ")#mi("{\\gamma_2}")#text("; since ")#mi("{R}")#text(" is independent of ")#mi("{n}")#text(", we conclude from ")#link(<tao-d694d81e0716ed3837f3>)[#text("(3)")]#text(" that all but ")#tao-math("{(1+o(1)) \\left|E_n\\right|}", block: false)#text(" ")#mi("{\\gamma}")#text(" in ")#mi("{G_n}")#text(" are of the form described above. Since ")#tao-math("{\\left|E_n\\right| \\leq \\left|G_n\\right|/2}", block: false)#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\mu( \\{ x \\in X(p_n): f_n(x)=0 \\} ) \\gg \\left|G_n\\right|", block: true)]]

#text("if ")#mi("{n}")#text(" is sufficiently large depending on ")#mi("{R}")#text(". As a consequence, if we let")

#align(center)[#tao-fit-display[#mitex("\\tilde f_n := f_n - \\frac{1}{\\mu(X(p_n))} \\int_{X(p_n)} f_n\\ d\\mu")]]

#text("be the mean-free component of ")#mi("{f_n}")#text(", we have the lower bound ")#metadata(none) <tao-2aba11a149b5001985bc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\| \\tilde f_n \\right\\|_{L^2(X(p_n),\\mu)} \\gg \\left|E_n\\right|^{1/2},", block: true)]]



#text(" for ")#mi("{n}")#text(" sufficiently large depending on ")#mi("{R}")#text(".")

#text("On the other hand, ")#mi("{\\nabla \\tilde f_n = \\nabla f_n}")#text(" is non-zero only at points which are at distance between ")#mi("{R}")#text(" and ")#mi("{2R}")#text(" of ")#mi("{E_n z_0}")#text(". Call the set of such points ")#mi("{A}")#text(". To estimate the volume ")#mi("{A}")#text(", we partition ")#mi("{X(p_n)}")#text(" into ")#tao-math("{\\left|G_n\\right|}", block: false)#text(" sets of the form ")#mi("{\\gamma \\Omega}")#text(", where ")#mi("{\\Omega}")#text(" is a fundamental domain of ")#mi("{X(1)}")#text(" (projected onto ")#mi("{X(p_n)}")#text(") and ")#mi("{\\gamma}")#text(" ranges over ")#mi("{G_n}")#text(". Because the ball of radius ")#mi("{2R}")#text(" centred at ")#mi("{z_0}")#text(" is precompact and thus meets only ")#mi("{O_R(1)}")#text(" of the translated domains ")#mi("{\\gamma \\Omega}")#text(", we see that the only ")#mi("{\\gamma}")#text(" for which ")#mi("{\\gamma \\Omega}")#text(" meets ")#mi("{A}")#text(" are of the form ")#mi("{\\gamma_1 \\pi_{p_n}(\\gamma_2)}")#text(", where ")#mi("{\\gamma_1}")#text(" lies in ")#mi("{E_n}")#text(" and ")#mi("{\\gamma_2}")#text(" lies in a subset of ")#mi("{SL_2({\\bf Z})}")#text(" of size ")#mi("{O_R(1)}")#text(" that is independent of ")#mi("{n}")#text(". From ")#link(<tao-d694d81e0716ed3837f3>)[#text("(3)")]#text(" we conclude that all but at most ")#tao-math("{o(\\left|E_n\\right|)}", block: false)#text(" of these ")#mi("{\\gamma}")#text(" thus lie in ")#mi("{E_n}")#text(", and so")

#align(center)[#tao-fit-display[#tao-math("\\mu(A) \\leq \\left|E_n\\right| + o(\\left|E_n\\right|).", block: true)]]

#text("Since ")#mi("{\\nabla \\tilde f_n = \\nabla f_n = O(1/R)}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nabla \\tilde f_n \\right\\|_{L^2(X(p_n),\\mu)} \\ll \\frac{1}{R} \\left|E_n\\right|^{1/2},", block: true)]]

#text("for ")#mi("{n}")#text(" sufficiently large depending on ")#mi("{R}")#text(". But this and ")#link(<tao-2aba11a149b5001985bc>)[#text("(4)")]#text(" contradict the uniform lower bound on the spectral gap ")#mi("{\\lambda_1(X(p_n))}")#text(" (after regularising ")#mi("{\\tilde f_n}")#text(" in a standard fashion to make it smooth rather than merely Lipschitz), giving the desired contradiction.")

#text("We now turn to the proof of Theorem ")#link(<tao-fe825095b70929bb3a27>)[#text("12")]#text(". The first step is to show that the only source of spectrum below ")#mi("{1/4}")#text(" is provided by eigenfunctions.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 13 (Discrete spectrum below ")#mi("{1/4}")#text(")")]#text(" Suppose that ")#mi("{\\lambda_1(X(p)) < 1/4}")#text(". Then there exists a non-zero ")#mi("{\\phi \\in L^2(X(p))}")#text(" such that ")#mi("{-\\Delta \\phi = \\lambda_1(X(p)) \\phi}")#text(" (in the distributional sense).")
]

#text("Note that while ")#mi("{\\phi}")#text(" is only initially in ")#mi("{L^2(X(p))}")#text(", it is a routine application of elliptic regularity (which we omit here) to show that ")#mi("{\\phi}")#text(" is necessarily smooth.")

#emph[#text("Proof:")]#text(" For notational simplicity, we will just prove the claim in the ")#mi("{p=1}")#text(" case, though the general case is similar. Write ")#mi("{\\lambda := \\lambda_1(X(p))}")#text(", so that ")#mi("{\\lambda < 1/4}")#text(". The argument will be similar in spirit to the proof of the lower bound ")#mi("{\\lambda > 0}")#text(". Indeed, by definition of ")#mi("{\\lambda}")#text(", we can find a sequence of functions ")#mi("{f_n \\in C^\\infty_c(X(1))_0}")#text(" with ")#tao-math("{\\left\\|f_n\\right\\|_{L^2(X(1))}=1}", block: false)#text(" such that ")#metadata(none) <tao-add1a0eb48c00f9ab032>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\int_{X(1)} \\left|\\nabla f_n\\right|^2\\ d\\mu= \\lambda+o(1).", block: true)]]



#text(" As before, we can take the ")#mi("{f_n}")#text(" to be real valued.")

#text("Using Hardy’s inequality as in the proof of Proposition ")#link(<tao-b00f8d905bef60171d59>)[#text("8")]#text(", we see that ")#metadata(none) <tao-48a1b00cc0118acc180f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\int_{R}^\\infty \\int_{-1/2}^{1/2} \\frac{\\left|f_n\\right|^2}{y^2}\\ dx dy \\leq 4 \\int_R^\\infty \\int_{-1/2}^{1/2} \\left|(f_n)_y\\right|^2\\ dx dy + O( \\int_R^{2R} \\frac{\\left|f_n\\right|^2}{y^2}\\ dx dy )", block: true)]]



#text(" for any ")#mi("{R>C}")#text(". For any ")#mi("{\\epsilon > 0}")#text(", one can use the pigeonhole principle to find an ")#mi("{R = O_\\epsilon(1)}")#text(" (depending on ")#mi("{n}")#text(") such that")

#align(center)[#tao-fit-display[#tao-math("\\int_R^{2R} \\frac{\\left|f_n\\right|^2}{y^2}\\ dx dy \\leq \\epsilon", block: true)]]

#text("and thus we see that")

#align(center)[#tao-fit-display[#tao-math("\\int_{R_\\epsilon}^\\infty \\int_{-1/2}^{1/2} \\frac{\\left|f_n\\right|^2}{y^2}\\ dx dy \\ll \\epsilon + 4\\lambda + o(1)", block: true)]]

#text("for some ")#mi("{R_\\epsilon}")#text(" depending only on ")#mi("{\\epsilon}")#text(". If ")#mi("{\\epsilon}")#text(" is small enough, ")#tao-math("{\\epsilon+4\\lambda < 1 = \\int_{X(1)} \\left|f_n\\right|^2\\ d\\mu}", block: false)#text(", and thus")

#align(center)[#tao-fit-display[#tao-math("\\int_{y \\leq R_\\epsilon} \\left|f_n\\right|^2\\ d\\mu \\gg 1", block: true)]]

#text("for all sufficiently large ")#mi("{n}")#text(". By ")#link(<tao-add1a0eb48c00f9ab032>)[#text("(5)")]#text(", ")#mi("{f_n}")#text(" is also uniformly bounded in ")#mi("{H^1}")#text(" norm. Thus by the Rellich compactness theorem, we may pass to a subsequence and assume that ")#mi("{f_n}")#text(" converges weakly in ")#mi("{L^2(X(1))}")#text(" and strongly in ")#mi("{L^2_{loc}}")#text(" to a limit ")#mi("{\\phi}")#text(", which is then non-zero. Also, from ")#link(<tao-48a1b00cc0118acc180f>)[#text("(6)")]#text(" we see that for each ")#mi("{\\epsilon, R_0}")#text(" and ")#mi("{n}")#text(" there is an ")#mi("{R_0 \\leq R = O_{R_0,\\epsilon}(1)}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\lambda \\int_{y>R} \\left|f_n\\right|^2\\ d\\mu \\leq \\int_{y > R} \\left|\\nabla f_n\\right|^2\\ d\\mu + O(\\epsilon)", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\lambda \\int_{y \\leq R} \\left|f_n\\right|^2\\ d\\mu \\geq \\int_{y \\leq R} \\left|\\nabla f_n\\right|^2\\ d\\mu + O(\\epsilon) + o(1).", block: true)]]

#text("Taking limits in weak ")#mi("{L^2}")#text(" (and strong ")#mi("{L^2_{loc}}")#text("), we conclude that for some ")#mi("{R = O_{\\epsilon,R_0}(1)}")#text(" larger than ")#mi("{R_0}")#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\lambda \\int_{y \\leq R} \\left|\\phi\\right|^2\\ d\\mu \\geq \\int_{y \\leq R} \\left|\\nabla \\phi\\right|^2\\ d\\mu + O(\\epsilon).", block: true)]]

#text("Sending ")#mi("{R_0 \\rightarrow \\infty}")#text(" using monotone convergence, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\lambda \\int_{X(1)} \\left|\\phi\\right|^2\\ d\\mu \\geq \\int_{X(1)} \\left|\\nabla \\phi\\right|^2\\ d\\mu + O(\\epsilon)", block: true)]]

#text("for any ")#mi("{\\epsilon}")#text("; by definition of ")#mi("{\\lambda}")#text(", we must then have")

#align(center)[#tao-fit-display[#tao-math("\\lambda \\int_{X(1)} \\left|\\phi\\right|^2\\ d\\mu = \\int_{X(1)} \\left|\\nabla \\phi\\right|^2\\ d\\mu.", block: true)]]

#text("Perturbing ")#mi("{\\phi}")#text(" in some test function direction ")#mi("{g \\in C^\\infty_c(X_1)}")#text(" of mean zero, and using the definition of ")#mi("{\\lambda}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\lambda \\int_{X(1)} \\langle \\phi, g \\rangle\\ d\\mu = \\int_{X(1)} \\langle \\nabla \\phi, \\nabla g \\rangle\\ d\\mu")]]

#text("for all such ")#mi("{g}")#text(". The mean zero condition on ")#mi("{g}")#text(" can be removed since both sides of this equation vanish when ")#mi("{g}")#text(" is constant. By duality we thus see that ")#mi("{- \\Delta \\phi = \\lambda \\phi}")#text(" in the sense of distributions, as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Establish the above proposition for general ")#mi("{p}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" ")#metadata(none) <tao-6acdc58a7e4d71e60933>#text(" Show that for any ")#mi("{\\lambda < 1/4}")#text(", the spectrum of ")#mi("{-\\Delta}")#text(" in ")#mi("{[0,\\lambda]}")#text(" on ")#mi("{X(p)}")#text(" is finite (and in particular consists only of eigenvalues), with each eigenvalue having finite multiplicity. (For this exercise you may use without proof the fact that ")#mi("{-\\Delta}")#text(" is essentially self-adjoint.)")
]

#text("We will also need a variant of the above proposition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 14 (Eigenfunctions do not concentrate in cusps)")]#text(" ")#metadata(none) <tao-09b908a70a0ba828f8d0>#text(" Let ")#mi("{\\lambda_0 < 1/4}")#text(". Then there is a compact subset ")#mi("{F}")#text(" of ")#mi("{X(1)}")#text(", such that for any ")#mi("{p}")#text(" and any eigenfunction ")#mi("{-\\Delta \\phi = \\lambda \\phi}")#text(" on ")#mi("{X(p)}")#text(" with some ")#mi("{\\lambda < \\lambda_0}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\eta_p^{-1}(F)} \\left|\\phi(x)\\right|^2\\ d\\mu(x) \\gg_{\\lambda_0} \\int_{X(p)} \\left|\\phi(x)\\right|^2\\ d\\mu(x)", block: true)]]

#text("where the implied constant is independent of ")#mi("{p}")#text(", ")#mi("{\\lambda}")#text(", and ")#mi("{\\phi}")#text(", and ")#mi("{\\eta_p: X(p) \\rightarrow X(1)}")#text(" is the covering map.")
]

#text("The lemma is basically proved by applying Hardy’s inequality to each cusp of ")#mi("{X(p)}")#text("; see the paper of Gamburd for details.")

#text("Now we can start using quasirandomness. Let ")#mi("{V \\subset L^2(X(p))_0}")#text(" be the space of all eigenfunctions of ")#mi("{-\\Delta}")#text(" of eigenvalue ")#mi("{\\lambda}")#text(":")

#align(center)[#tao-fit-display[#mitex("V := \\{ \\phi \\in L^2(X(p))_0: -\\Delta \\phi = \\lambda \\phi \\}.")]]

#text("By the above proposition, this is a non-trivial Hilbert space. From Exercise ")#link(<tao-6acdc58a7e4d71e60933>)[#text("21")]#text(", ")#mi("{V}")#text(" is finite-dimensional (though we do not really need to know this fact yet in the argument that follows, as it will be a consequence of the computations). Since ")#mi("{SL_2(F_p)}")#text(" acts isometrically on ")#mi("{X(p)}")#text(", it also acts on ")#mi("{V}")#text(". If ")#mi("{\\phi}")#text(" is a ")#mi("{SL_2(F_p)}")#text("-invariant vector in ")#mi("{V}")#text(", then it descends to a function on ")#mi("{L^2(X(1))_0}")#text(", which is impossible if ")#mi("{\\lambda < \\lambda_1(X(1))}")#text(". Applying the Frobenius lemma (Lemma ")#link(<tao-26b7c362884170e0ba38>)[#text("2")]#text("), we conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 15 (Quasirandomness)")]#text(" ")#metadata(none) <tao-2969e7b867c99c3a0942>#text(" If ")#mi("{\\lambda < \\lambda_1(X(1))}")#text(", then ")#mi("{V}")#text(" has dimension at least ")#mi("{\\frac{p-1}{2}}")#text(".")
]

#text("To complement this quasirandomness to get expansion, we need a flattening property, as in Proposition ")#link(<tao-88d464ffb6fcd3806d3b>)[#text("4")]#text(". In the discrete world, we applied a flattening property to the distribution ")#mi("{\\mu^{*m}}")#text(" of a long discrete random walk. The direct analogue of such a distribution would be a ")#link("http://en.wikipedia.org/wiki/Heat_kernel")[#text("heat kernel")]#text(" ")#mi("{e^{t\\Delta}}")#text(" of the Laplacian ")#mi("{\\Delta}")#text(", and this is what we shall use here. (It turns out that the heat kernel is not quite the most efficient object to analyse here; see Remark ")#link(<tao-a774e484f3848856eb8e>)[#text("12")]#text(" below.)")

#text("We first recall the formula for the heat kernel on the hyperbolic plane ")#mi("{{\\bf H}}")#text(" (which can be found in many places, such as ")#link("http://www.ams.org/mathscinet-getitem?mr=768584")[#text("this text of Chavel")]#text(", or ")#link("http://www.ams.org/mathscinet-getitem?mr=791406")[#text("this text of Terras")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Show that the heat operator ")#mi("{e^{t\\Delta}}")#text(" on test functions ")#mi("{f}")#text(" in ")#mi("{{\\bf H}}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#mitex("e^{t\\Delta} f(x) = \\int_{\\bf H} K_t( d(x,y) ) f(y)\\ d\\mu(y)")]]

#text("where ")#mi("{K_t}")#text(" is the kernel")

#align(center)[#tao-fit-display[#mitex("K_t(\\rho) := \\frac{\\sqrt{2}}{(4\\pi t)^{3/2}} e^{-t/4} \\int_{\\rho}^\\infty \\frac{ s e^{-s^2/4t}}{(\\cosh s - \\cosh \\rho)^{1/2}}\\ ds.")]]

#text("(")#emph[#text("Hint:")]#text(" There are two main computations. One is to show that ")#mi("{K_t(\\rho)}")#text(" obeys the heat equation, which in half-cylindrical coordinates means that one has to verify that ")#metadata(none) <tao-5a2a0ed9aa3ab7d82b53>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\frac{\\partial}{\\partial t} K_t(\\rho) = (\\frac{\\partial^2}{\\partial \\rho^2} + \\frac{1}{\\sinh \\rho} \\frac{\\partial}{\\partial \\rho}) K_t(\\rho).")]]



#text(" The other is to show that ")#mi("{K_t(\\rho)}")#text(" resembles the Euclidean heat kernel ")#mi("{\\frac{1}{4\\pi t} e^{-\\rho^2/4t}}")#text(" for small ")#mi("{t}")#text(". There are several other ways to derive this formula in terms of formulae for other operators (e.g. the wave propagator); see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=791406")[#text("Terras’s book")]#text(" for some discussion.)")
]

#text("For our purposes, we only need a crude upper bound on the heat kernel:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" ")#metadata(none) <tao-dcecdafc4272dc394998>#text(" With the notation of the preceding section, show that")

#align(center)[#tao-fit-display[#mitex("K_t(\\rho) \\ll (t+\\rho)^{O(1)} e^{-t/4} e^{-\\rho/2} e^{-\\rho^2/4t}.")]]

#text("when ")#mi("{t \\geq 1}")#text(" and ")#mi("{\\rho \\geq 0}")#text(".")
]

#text("In our applications, the polynomial factors ")#mi("{(t+\\rho)^{O(1)}}")#text(" will be negligible; only the exponential factors will be of importance. Note that if one integrates the above estimate against the measure ")#mi("{d\\mu = \\sinh \\rho d \\rho d \\theta}")#text(", one sees that ")#metadata(none) <tao-365678ac20a7dc8bf436>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\int_{\\bf H} K_t\\ d\\mu \\ll \\int_0^\\infty (t+\\rho)^{O(1)} e^{-t/4} e^{+\\rho/2} e^{-\\rho^2/4t} d \\rho.")]]



#text(" The right-hand side evaluates to ")#mi("{O(t^{O(1)})}")#text(". On the other hand, as the heat kernel is a probability measure, one has ")#mi("{\\int_{\\bf H} K_t\\ d\\mu= 1}")#text(". Thus, up to polynomial factors, the above estimate is quite tight.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 10")]#text(" From Exercise ")#link(<tao-dcecdafc4272dc394998>)[#text("23")]#text(", we see that the probability measure ")#mi("{K_t(\\rho) \\sinh \\rho d\\rho d\\theta}")#text(" concentrates around the region ")#mi("{\\rho = t+ O(\\sqrt{t})}")#text("; thus on the hyperbolic plane, Brownian motion moves “ballistically” away from its starting point at a unit speed, in contrast to the situation in Euclidean geometry, where after time ")#mi("{t}")#text(" a Brownian motion is only expected to move by a distance ")#mi("{O(\\sqrt{t})}")#text(". One can see this phenomenon also from the heat equation ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(7)")]#text(", which when expressed in terms of the probability density ")#mi("{u(\\rho) := K_t(\\rho) \\sinh \\rho}")#text(" becomes a ")#link("http://en.wikipedia.org/wiki/Fokker-planck_equation")[#text("Fokker-Planck equation")]

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial}{\\partial t} u(\\rho) = \\frac{\\partial^2}{\\partial \\rho^2} u(\\rho) - \\frac{\\partial}{\\partial \\rho}(\\frac{1}{\\tanh \\rho} u)(\\rho)")]]

#text("with unit diffusion and drift speed ")#mi("{\\frac{1}{\\tanh \\rho}}")#text(". Since ")#mi("{\\frac{1}{\\tanh \\rho}}")#text(" rapidly approaches ")#mi("{1}")#text(" when ")#mi("{\\rho}")#text(" becomes large, we thus expect ")#mi("{u}")#text(" to concentrate in the region ")#mi("{\\rho = t + O(\\sqrt{t})}")#text(", as is indeed the case.")
]

#text("We let ")#mi("{t \\geq 1}")#text(" be a parameter to optimise in later. The heat operator ")#mi("{e^{t\\Delta}}")#text(" on ")#mi("{{\\bf H}}")#text(" descends to a heat operator on the quotient ")#mi("{X(p)}")#text(", defined by the formula")

#align(center)[#tao-fit-display[#mitex("e^{t\\Delta} f(x) = \\int_{X(p)} \\sum_{z \\in \\Gamma(p) y} K_t(d(x,z)) f(y)\\ d\\mu(y)")]]

#text("for ")#mi("{f \\in C_c(X(p))}")#text("; note that the sum ")#mi("{\\sum_{z \\in \\Gamma(p) y} K_t(d(x,z))}")#text(" is ")#mi("{\\Gamma(p)}")#text("-invariant, and so makes sense for ")#mi("{x \\in X(p)}")#text(" and not just for ")#mi("{x \\in {\\bf H}}")#text(". When applied to an eigenfunction ")#mi("{\\phi \\in V}")#text(", one has ")#mi("{e^{t\\Delta} \\phi = e^{-t\\lambda} \\phi}")#text("; in particular, ")#mi("{e^{t\\Delta}}")#text(" preserves ")#mi("{V}")#text(", and thus also preserves the orthogonal complement of ")#mi("{V}")#text(". As ")#mi("{e^{t\\Delta}}")#text(" is positive semi-definite, it therefore splits as the sum of ")#mi("{e^{-t\\lambda} P_V}")#text(" and another positive semi-definite operator, where ")#mi("{P_V}")#text(" is the orthogonal projection to ")#mi("{V}")#text(". Note that ")#mi("{e^{-t\\lambda} P_V}")#text(" is an integral operator with kernel")

#align(center)[#tao-fit-display[#mitex("e^{-t\\lambda} \\sum_{i=1}^{\\text{dim}(V)} \\phi_i(x) \\overline{\\phi_i(y)}")]]

#text("where ")#mi("{\\phi_1,\\ldots,\\phi_{\\text{dim}(V)}}")#text(" is an orthonormal basis of ")#mi("{V}")#text(". (Here we use the fact that ")#mi("{V}")#text(" is finite dimensional, but if one does not want to use this fact yet, one can work instead with a finite-dimensional subspace of ")#mi("{V}")#text(" in the argument that follows.) Since positive semi-definite integral operators (with continuous kernel) are non-negative on the diagonal, we conclude the pointwise inequality")

#align(center)[#tao-fit-display[#tao-math("e^{-t\\lambda} \\sum_{i=1}^{\\text{dim}(V)} \\left|\\phi_i(x)\\right|^2 \\leq \\sum_{\\gamma \\in \\Gamma(p)} K_t(d(x,\\gamma x))", block: true)]]

#text("for all ")#mi("{x \\in X(p)}")#text(".")

#text("This will be our starting point to get a lower bound on ")#mi("{\\lambda}")#text(". But first we must deal with the other quantities ")#mi("{\\phi_i}")#text(", ")#mi("{K_t}")#text(" in this expression. A simple way to proceed here is to integrate out in ")#mi("{X(p)}")#text(" to exploit the ")#mi("{L^2}")#text(" normalisation of the ")#mi("{\\phi_i}")#text(":")

#align(center)[#tao-fit-display[#mitex("e^{-t\\lambda} \\text{dim}(V) \\leq \\int_{X(p)} \\sum_{\\gamma \\in \\Gamma(p)} K_t(d(x,\\gamma x))\\ d\\mu(x).")]]

#text("However, this turns out to be a little unfavourable because the integrand on the right-hand side does not behave well enough at cusps. However, if one uses Lemma ")#link(<tao-09b908a70a0ba828f8d0>)[#text("14")]#text(" first (assuming that ")#mi("{\\lambda \\leq 1/12}")#text("), and integrates over the resulting region ")#mi("{\\eta_p^{-1}(F)}")#text(", we can avoid the cusps:")

#align(center)[#tao-fit-display[#mitex("e^{-t\\lambda} \\text{dim}(V) \\ll \\int_{\\eta_p^{-1}(F)} \\sum_{\\gamma \\in \\Gamma(p)} K_t(d(x,\\gamma x))\\ d\\mu(x).")]]

#text("Because the sum here is ")#mi("{SL_2(F_p)}")#text("-invariant, we can descend from ")#mi("{X(p)}")#text(" to ")#mi("{X(1)}")#text(":")

#align(center)[#tao-fit-display[#tao-math("e^{-t\\lambda} \\text{dim}(V) \\ll \\left|SL_2(F_p)\\right| \\int_{F} \\sum_{\\gamma \\in \\Gamma(p)} K_t(d(x,\\gamma x))\\ d\\mu(x).", block: true)]]

#text("We now insert the bound in Exercise ")#link(<tao-dcecdafc4272dc394998>)[#text("23")]#text(", as well as the bound ")#tao-math("{\\left|SL_2(F_p)\\right| \\ll p^3}", block: false)#text(":")

#align(center)[#tao-fit-display[#mitex("e^{-t\\lambda} \\text{dim}(V) \\ll p^3 \\int_{F} \\sum_{\\gamma \\in \\Gamma(p)} (t + d(x,\\gamma x))^{O(1)} e^{-t/4} e^{-d(x,\\gamma x)/2} e^{-d(x,\\gamma x)^2/4t}\\ d\\mu(x).")]]

#text("Because ")#mi("{F}")#text(" is compact, we can get a good bound on ")#mi("{d(x,\\gamma x)}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]

#list(
[#text("(i) For any ")#mi("{\\gamma \\in SL_2({\\bf R})}")#text(", show that ")#tao-math("{d(i,\\gamma i) = 2 \\log \\left\\| \\gamma \\right\\| + O(1)}", block: false)#text(", where ")#tao-math("{\\left\\| \\gamma \\right\\| := (a^2+b^2+c^2+d^2)^{1/2}}", block: false)#text(" is the Frobenius norm of the matrix ")#mi("{\\gamma =: \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}}")#text(".")],
[#text("(ii) More generally, if ")#mi("{F}")#text(" is a compact subset of ")#mi("{X(1)}")#text(", show that ")#tao-math("{d(x,\\gamma x) \\leq C_F \\log \\left\\|\\gamma \\right\\| + C_F}", block: false)#text(" for some constant ")#mi("{C_F}")#text(" depending only on ")#mi("{F}")#text(".")]
)
]

#text("Inserting these bounds, we obtain")

#align(center)[#tao-fit-display[#tao-math("e^{-t\\lambda} \\text{dim}(V) \\ll p^3 \\sum_{\\gamma \\in \\Gamma(p)} (t + \\log \\left\\|\\gamma\\right\\|)^{O(1)} e^{-t/4} e^{-\\log \\left\\| \\gamma \\right\\|} e^{-(\\log \\left\\|\\gamma\\right\\| + O(1))^2/t}.", block: true)]]

#text("Decomposing according to the integer part ")#mi("{R}")#text(" of ")#mi("{\\log \\gamma + O(1)}")#text(", we thus have ")#metadata(none) <tao-6e9b1a2f2503b517e10d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("e^{-t\\lambda} \\text{dim}(V) \\ll p^3 \\sum_{R=1}^\\infty (t+R)^{O(1)} e^{-t/4} e^{-R} e^{-R^2 / t} N_p(e^{R+O(1)})")]]



#text(" where ")#mi("{N_p(T)}")#text(" is the counting function")

#align(center)[#tao-fit-display[#tao-math("N_p(T) := |\\{ \\gamma \\in \\Gamma(p): \\left\\|\\gamma\\right\\| \\leq T \\}.", block: true)]]

#text("So one is left with the purely number-theoretic task of estimating ")#mi("{N_p(T)}")#text(". This is basically the number of points of ")#mi("{\\Gamma(p) i}")#text(" in the ball of radius ")#mi("{2 \\log T}")#text(" in ")#mi("{{\\bf H}}")#text(". From the half-cylinder model, we see that the measure of this ball is ")#mi("{O( e^{2\\log T} ) = O(T^2)}")#text(". On the other hand, ")#mi("{\\Gamma(p)}")#text(" has index ")#tao-math("{\\left|SL_2(F_p)\\right| \\sim p^3}", block: false)#text(" in ")#mi("{\\Gamma(1)}")#text(", which has bounded covolume in ")#mi("{{\\bf H}}")#text(". We thus heuristically expect ")#mi("{N_p(T)}")#text(" to be ")#mi("{O(T^2/p^3)}")#text(". If this were the truth, then the right-hand side of ")#link(<tao-6e9b1a2f2503b517e10d>)[#text("(9)")]#text(" would be ")#mi("{O(t^{O(1)})}")#text(" (cf. the evaluation of ")#link(<tao-365678ac20a7dc8bf436>)[#text("(8)")]#text("), which when combined with quasirandomness (Lemma ")#link(<tao-2969e7b867c99c3a0942>)[#text("15")]#text(") would give a lower bound of ")#mi("{\\lambda}")#text(", that would be particularly strong when ")#mi("{t}")#text(" was small.")

#text("The key is then the following “flattening lemma”, that shows that ")#mi("{N_p(T)}")#text(" is indeed roughly of the order of ")#mi("{O(T^2/p^3)}")#text(" when ")#mi("{T}")#text(" is large, and is the main number-theoretic input to the argument:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 16 (Flattening lemma)")]#text(" For any ")#mi("{\\epsilon>0}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("N_p(T) \\ll_\\epsilon \\frac{T^{2+\\epsilon}}{p^3} + \\frac{T^{1+\\epsilon}}{p} + T^\\epsilon.")]]
]

#emph[#text("Proof:")]#text(" Using the definition of ")#mi("{\\Gamma(p)}")#text(", we are basically counting the number of integer solutions ")#mi("{(a,b,c,d) \\in {\\bf Z}^4}")#text(" to the equation")

#align(center)[#tao-fit-display[#mitex("ad-bc = 1")]]

#text("subject to the congruences")

#align(center)[#tao-fit-display[#mitex("a = d = 1 \\text{ mod } p; \\quad b = c = 0 \\text{ mod } p")]]

#text("and the bounds")

#align(center)[#tao-fit-display[#mitex("a, b, c, d = O(T).")]]

#text("Since ")#mi("{b, c}")#text(" are both divisible by ")#mi("{p}")#text(", we see also that ")#mi("{ad = 1 \\text{ mod } p^2}")#text(". Similarly, as ")#mi("{a-1}")#text(" and ")#mi("{d-1}")#text(" are divisible by ")#mi("{p}")#text(", we have ")#mi("{(a-1)(d-1)=0 \\text{ mod } p^2}")#text(". Subtracting, we conclude that")

#align(center)[#tao-fit-display[#mitex("a + d = 2 \\text{ mod } p^2.")]]

#text("Now we proceed as follows. The number of integers ")#mi("{a = 1 \\text{ mod } p}")#text(" with ")#mi("{a = O(T)}")#text(" is ")#mi("{O( \\frac{T}{p} + 1 )}")#text(". For each such ")#mi("{a}")#text(", the number of ")#mi("{d}")#text(" with ")#mi("{a+d=2 \\text{ mod } p^2}")#text(" and ")#mi("{d = O(T)}")#text(" is ")#mi("{O( \\frac{T}{p^2} + 1 )}")#text(". For each fixed ")#mi("{a}")#text(" and ")#mi("{d}")#text(", the expression ")#mi("{ad-1}")#text(" is of size ")#mi("{O(T^2)}")#text("; by the ")#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/")[#text("divisor bound")]#text(", there are thus ")#mi("{O_\\epsilon(T^\\epsilon)}")#text(" ways to factor ")#mi("{ad-1}")#text(" into ")#mi("{bc}")#text(". Thus, we obtain a final bound of")

#align(center)[#tao-fit-display[#mitex("N_p(T) \\ll_\\epsilon (\\frac{T}{p}+1) (\\frac{T}{p^2}+1) T^\\epsilon")]]

#text("giving the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 11")]#text(" One can obtain improved bounds to ")#mi("{N_p(T)}")#text(" for some ranges of ")#mi("{T}")#text(" (particularly when ")#mi("{T}")#text(" ranges between ")#mi("{p}")#text(" and ")#mi("{p^2}")#text(") by using more advanced tools, such as bounds on ")#link("http://en.wikipedia.org/wiki/Kloosterman_sum")[#text("Kloosterman sums")]#text(". Unfortunately, such improvements do not actually improve the final constants in this argument. (Kloosterman sums do however play a key role in the proof of Theorem ")#link(<tao-257e203cadb786676f65>)[#text("10")]#text(", which proceeds by a different, and more highly arithmetic, argument.)")
]

#text("A routine calculation then finishes off the proof of Theorem ")#link(<tao-fe825095b70929bb3a27>)[#text("12")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" Using the above lemma, show that the right-hand side of ")#link(<tao-6e9b1a2f2503b517e10d>)[#text("(9)")]#text(" is ")#metadata(none) <tao-a03e9a0ef8296a393caa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\ll_\\epsilon e^{\\epsilon t} ( 1 + p^3 e^{-t/4} )")]]



#text(" for any ")#mi("{\\epsilon>0}")#text(". Optimising this in ")#mi("{t}")#text(" and using Lemma ")#link(<tao-2969e7b867c99c3a0942>)[#text("15")]#text(", establish a contradiction whenever ")#mi("{\\lambda < \\min(\\frac{1}{12}-\\epsilon,\\lambda_1(X(1)))}")#text(" and ")#mi("{p}")#text(" is sufficiently large depending on ")#mi("{\\epsilon}")#text(", thus giving Theorem ")#link(<tao-fe825095b70929bb3a27>)[#text("12")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 12")]#text(" ")#metadata(none) <tao-a774e484f3848856eb8e>#text(" An inspection of the above argument shows that the ")#mi("{p^3 e^{-t/4}}")#text(" term in ")#link(<tao-a03e9a0ef8296a393caa>)[#text("(10)")]#text(" is the main obstacle to improving the ")#mi("{\\frac{1}{12}}")#text(" constant. This term ultimately can be “blamed” for the relatively large value of the heat kernel ")#mi("{K_t(\\rho)}")#text(" at the origin. To improve this, one can observe that the main features of the heat kernel ")#mi("{K_t(\\rho)}")#text(" that were needed for the argument were that it was positive definite, and had an explicit effect on eigenfunctions ")#mi("{\\phi}")#text(". It turns out that there are several other kernels with these properties, and by selecting a kernel with less concentration at the identity, one can obtain a better result. In particular, an efficient choice of kernel turns out to be the convolution of a ball of radius ")#mi("{t}")#text(" with itself. By performing some additional calculations in hyperbolic geometry (in particular, using the Selberg/Harish-Chandra theory of ")#link("http://en.wikipedia.org/wiki/Zonal_spherical_function")[#text("spherical functions")]#text(") one can use this kernel to improve the ")#mi("{1/12}")#text(" bound given here to ")#mi("{5/36}")#text("; see ")#link("http://www.ams.org/mathscinet-getitem?mr=1900698")[#text("the paper of Gamburd")]#text(" for details. Unfortunately, the fraction ")#mi("{5/36}")#text(" here appears to be the limit of this particular method.")
]

#heading(level: 1)[#text("Comments (30)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-116771")[#strong[#text("254B, Notes 1: Basic theory of expander graphs « Another Word For It")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2011")]

#text("[…] 254B, Notes 3: Quasirandom groups, expansion, and Selberg’s 3/16 theorem […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ed6288e8669727851f80b88c0f19aa472d4acf91d66f3cb59d9668eb0bc3211-02872aadafb531d1c053c2820b868e3f677b2503e46ec9d9ed709b7a56c9925f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wolfgang Moens")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-117221")[#strong[#text("Wolfgang Moens")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2011")])]

#text("Exercise 15: I think the proof of the “in particular”-part of the exercise needs the extra assumption of “non-abelianness”. Am I missing something?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c6953ab4425d109767a7eef3ecc7c8cf8d944a87ec5e2a502981e671d9cc1a-1d73f6869dd4b3f2691c3f1f37c65f3584e7eca39cd73c5b09d3068e6ab0d958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-117537")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2011")])]

#text("The best known bound toward Selberg’s Conjecture is ")#mi("\\lambda_1(X(p)) \\geq \\frac{975}{4096}")#text(", due to ")#link("http://www.ams.org/mathscinet-getitem?mr=1937203")[#text("Kim-Sarnak")]#text(".")

#text("The conjecture has been verified numerically for ")#mi("\\Gamma_1(N)\\backslash\\mathbb{H}")#text(" and ")#mi("N<857")#text(" by ")#link("http://www.ams.org/mathscinet-getitem?mr=2338122")[#text("Booker-Strömbergsson")]#text(" (the resulting expanders would be the Schreyer graphs on ")#mi("\\Gamma(1)/\\Gamma_1(N)")#text(" rather than Cayley graphs but this isn’t much of an issue).")

#text("At the moment the conjecture cannot be verified numerically in general. The problem is that when ")#mi("\\frac{1}{4}")#text(" is an exact eigenvalue, no numerical computation can show that the eigenvalue is not fractionally smaller. The Langlands Conjectures predict when this occurs; in many cases (when the Langlands-Tunnell Theorem applies) Booker-Strömbergsson) then rigorously show that there is an eigenfunction at exactly ")#mi("\\frac{1}{4}")#text(". Since the numerical method does count the eigenvalues, Selberg’s Conjecture follows. However, this does not work all the time.")

#text("The first case where this difficully arises (an “icosahedral representation”) occurs for ")#mi("\\Gamma_1(1951)")#text(".")

#emph[#text("[References added, thanks! – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A variant of Kemperman’s theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-118736")[#strong[#text("A variant of Kemperman’s theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2011")])]

#text("[…] are arcs of a circle. For quasirandom , one can do much better than these bounds, as discussed in this recent blog post; thus, the abelian case is morally the worst case here, although it seems difficult to convert this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b347c1a4783fe766404c94e0d2d824de611388fe3c8bb094183aa7eb764425c-1666733179257f65a3e3d910337c195185ff94ba51ca724975d7d42ab8e82865.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vipulnaik")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-121103")[#strong[#text("vipulnaik")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2012")])]

#text("Your statement of Jordan’s theorem misses the additional fact that the abelian subgroup is normal in the group (i.e., what you’ve written is correct but not the full theorem). Also, to obtain the second para of Exercise 15, the first para should read “proper normal subgroup” instead of “proper subgroups”. We do need to use the stronger assumption of “normal” in order to obtain the result you state in the second para of Exercise 15 involving finite simple non-abelian groups.")

#text("[")#emph[#text("Corrected, thanks – T.")]#text("]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ed6288e8669727851f80b88c0f19aa472d4acf91d66f3cb59d9668eb0bc3211-02872aadafb531d1c053c2820b868e3f677b2503e46ec9d9ed709b7a56c9925f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wolfgang Moens")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-121298")[#strong[#text("Wolfgang Moens")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2012")])]

#text("I have another, rather naive, question. In this post, Jordan’s theorem yields an abelian subgroup that is also normal. But, in one of the previous posts (“The Jordan-Schur theorem”), there was no mention of the existence of an abelian subgoup that was, in addition, normal. Is this just a coincidence, or is there something behind this?")

#text("E.g.: would it really be harder to generalize Jordan to Jordan-Schur if one wants to include the normality of the subgroup?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-121379")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2012")])]

#text("Well, as long as one doesn’t care about the constants, this is straightforward, because any subgroup H of a group G of some index K will always contain a ")#emph[#text("normal")]#text(" subgroup of G of index at most K! (namely, the kernel of the left action of G on the coset space G/H, or equivalently the intersection of all the conjugates of H).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-121482")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2012")])]

#text("Oh, yes. Thanks! =)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ed6288e8669727851f80b88c0f19aa472d4acf91d66f3cb59d9668eb0bc3211-02872aadafb531d1c053c2820b868e3f677b2503e46ec9d9ed709b7a56c9925f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wolfgang Moens")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-121309")[#strong[#text("Wolfgang Moens")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2012")])]

#text("P.S.: Sorry, I have just noticed that I had not read vipulnaik’s message before posting my own.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 4: The Bourgain-Gamburd expansion machine « What’s new")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-122232")[#strong[#text("254B, Notes 4: The Bourgain-Gamburd expansion machine « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2012")])]

#text("[…] of an infinite Cayley graph on a group with Kazhdan’s property (T). The second, discussed in Notes 3, is to combine a quasirandomness property of the group with a flattening hypothesis for the random […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c47a213c5d1b8737bd3785f982adee484374aaa7a00b8f750be1604e65cdc73-5618674392fc17ae9831112af6c64272f61febf37fb959a8426ffbe48ad8cc4c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MK")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-126683")[#strong[#text("MK")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("Shouldn’t exercise 4, ii) state “G is 2-quasirandom iff it is perfect” instead of “not perfect”? ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 5: Product theorems, pivot arguments, and the Larsen-Pink non-concentration inequality « What’s new")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-126686")[#strong[#text("254B, Notes 5: Product theorems, pivot arguments, and the Larsen-Pink non-concentration inequality « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("[…] non-concentration, product theorems, and quasirandomness. Quasirandomness was discussed in Notes 3. In the current set of notes, we discuss product theorems. Roughly speaking, these theorems assert […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 6: Non-concentration in subgroups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-128467")[#strong[#text("254B, Notes 6: Non-concentration in subgroups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2012")])]

#text("[…] the last three notes, we discussed the Bourgain-Gamburd expansion machine and two of its three ingredients, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 7: Sieving and expanders « What’s new")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-131030")[#strong[#text("254B, Notes 7: Sieving and expanders « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2012")])]

#text("[…] a consequence of Proposition 4 of Notes 3, the following claim was shown: Proposition 7 Let be a -quasirandom finite group, is a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Multiple recurrence in quasirandom groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-197378")[#strong[#text("Multiple recurrence in quasirandom groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2012")])]

#text("[…] Geom. Func. Anal.. This paper builds upon a paper of Gowers in which he introduced the concept of a quasirandom group, and established some mixing (or recurrence) properties of such groups. A -quasirandom group is a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mixing for progressions in non-abelian groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-203697")[#strong[#text("Mixing for progressions in non-abelian groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2012")])]

#text("[…] starting motivation for this paper was a question posed in this foundational paper of Tim Gowers on quasirandom groups. In that paper, Gowers showed (among other things) that if was a quasirandom group, patterns such […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-203933")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2012")])]

#text("Remark 3 : for “isocahedral symmetry” read “icosahedral symmetry” . WFL")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0fd56049a8189a380fda42273fee0bc2b9ce50a7a224700afce1fe96194008-d71b4d207f9bb85a02159d9eb02ffc3ded2bfbce61de425e7d3d85b4f53db867.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uwe Stroinski")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-206905")[#strong[#text("Uwe Stroinski")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2012")])]

#text("In the proof of Proposition 3 (mixing inequality) you write eigenvalue ")#mi("\\sigma_1")#text(" and mean eigenvalue ")#mi("\\sigma_1^2")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0fd56049a8189a380fda42273fee0bc2b9ce50a7a224700afce1fe96194008-d71b4d207f9bb85a02159d9eb02ffc3ded2bfbce61de425e7d3d85b4f53db867.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uwe Stroinski")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-216044")[#strong[#text("Uwe Stroinski")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2013")])]

#text("Can you or a reader please help me with exercise 10. I can show the first inequality and I understand that one can use this to quantify that the number of places at which the convolution is small cannot be large. How does that help to prove the first inequality after ‘conclude in particular that’?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-216083")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2013")])]

#text("You might find it easier to first establish the second conclusion (i.e. that ")#mi("ABC = G")#text(" whenever ")#tao-math("\\left|A\\right| \\left|B\\right| \\left|C\\right| > \\left|G\\right|^3/D", block: false)#text(") before establishing the first (which is equivalent to the second).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quasirandom groups and a cheap version of the Brauer-Fowler theorem | What's new")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-227356")[#strong[#text("Quasirandom groups and a cheap version of the Brauer-Fowler theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2013")])]

#text("[…] for groups, the modern study of which was initiated by Gowers, and is discussed for instance in this previous post. It gives the following slightly weaker version of Corollary […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/149b171ab62961ff4ca726aa8075b52dde1a397e5374b5be8e999968962fca3a-7eb4f30478eb591843ace274366b558cd8b04855f7a5c1ec13559dc539843a66.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doron Puder")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-435831")[#strong[#text("Doron Puder")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2014")])]

#text("Dear T.,")#linebreak()#text(" 1) In Proposition 4, shouldn’t the ‘flattening of random walk’ condition be defined by the restriction of \\mu to sum-zero functions? (Otherwise, ||\\mu^{*n}||=1 for all n).")#linebreak()#text(" 2) I suspect the 1/n term in Exercise 13 (ii) is unnecessary. I think one can prove the claim for \\epsilon \\le 1-\\sqrt(n/(Dk)) using Proposition 3 on the eigenfunction of the largest non-trivial eigenvalue (in absolute value) and the characteristic function of S.")

#emph[#text("[(2) corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/149b171ab62961ff4ca726aa8075b52dde1a397e5374b5be8e999968962fca3a-7eb4f30478eb591843ace274366b558cd8b04855f7a5c1ec13559dc539843a66.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doron Puder")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-435834")[#strong[#text("Doron Puder")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2014")])]

#text("Please ignore the first remark. (it’s the l2-norm of a vector, not operator norm of the operator).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A wave equation approach to automorphic forms in analytic number theory | What's new")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-458177")[#strong[#text("A wave equation approach to automorphic forms in analytic number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2015")])]

#text("[…] Using the Weil bound on Kloosterman sums to derive Selberg’s 3/16 theorem on the least non-trivial eigenvalue for on (discussed previously here); […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-461819")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2015")])]

#text("Applying the improved estimate for the ")#mi("\\lambda _{1}\\geq \\frac{975}{4096}")#text(" in Theorem 7 (“J.-M. Deshouillers and H. Iwaniec, Kloosterman sums and Fourier coefficients of cusp forms, Invent. Math. 70 (1982), 219-288”; p.233), you can reduce the degree of an integer ")#mi("X")#text(".Will this affect the estimates of Theorem 11, and with the prospect of Theorem 12 (p.236,237)? Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-461847")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2015")])]

#text("By Theorem 10.11 implies the assertion in Theorem 12 ")#mi("K^{2}(C,D,N,R,S) = CS(RS+N)(C+DR)+C^{2} DS\\sqrt {(RS+N)R}+D^{2}NRS^{-1}")#text(", but I somehow doubt take that on Selberg hypothesis should be the same expression.Let Selberg conjecture is true, then ")#mi("\\theta _{rs}=0")#text(" in Theorem 9. It turns out that in Theorem 12 expression ")#mi("C^{2} DS\\sqrt {(RS+N)R}")#text(" has no place in this form. Or is it all true? I do not know if you could give your comment, if you do not complicate. Thank you.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ConstantinK")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-553214")[#strong[#text("ConstantinK")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2020")])]

#text("Using remark 5, do you agree that on can improve Proposition 3 to the following: ")#tao-math("\\left|\\left|f * g\\right|\\right|_2 \\leq D^{-3/2}\\left|G\\right|^{1/2} \\left|\\left|f\\right|\\right|_2 \\left|\\left|g\\right|\\right|_2", block: false)#text(" for all ")#mi("f,g \\in L^2(G)")#text(". So we also get some sharper bounds in later exercises.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-553282")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2020")])]

#text("I don’t see how to get such a good dependence on D. If one could get such a gain then one could immediately improve the exponents in a number of existing results in the literature, e.g., ")#link("https://www.cambridge.org/core/journals/mathematical-proceedings-of-the-cambridge-philosophical-society/article/mixing-for-threeterm-progressions-in-finite-simple-groups/3871BEAF10295F669BAFCA2C70BF0745")[#text("https://www.cambridge.org/core/journals/mathematical-proceedings-of-the-cambridge-philosophical-society/article/mixing-for-threeterm-progressions-in-finite-simple-groups/3871BEAF10295F669BAFCA2C70BF0745")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ConstantinK")]], [#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-553451")[#strong[#text("ConstantinK")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2020")])]

#text("Ahh now I see my mistake – thank you. I just used blindly the equation from Fourier Analysis for general compact groups:")

#tao-math("\\left|\\left|f\\right|\\right|_2^2 = \\sum_{\\pi \\in \\hat{G}} \\dim(\\pi)\\left|\\left|\\pi(f)\\right|\\right|_{\\mathrm{HS}}^2,", block: false)

#text("where all the integration takes place with respect to the Haar probability measure and I forgot that the 2-norm in this problem is not with respect to the Haar probability measure of ")#mi("G")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/#comment-640855")[#strong[#text("pr.likelihood - Show that $mathrm{SL}_2(mathbb{F}_p)$ is quasi-random Answer - Lord Web")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2022")]

#text("[…] Terry Tao offers this indirect definition of quasi-random group in his notes 3 […]")
]
