// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/
// Converted to Typst by tao2typ: "2026-10-14T16:35:07.499773+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Einstein’s derivation of E=mc^2", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Einstein’s derivation of E=mc^2")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 December 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/")[#text("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Einstein’s equation ")#mi("E=mc^2")#text(" describing the ")#link("http://en.wikipedia.org/wiki/Mass-energy_equivalence")[#text("equivalence of mass and energy")]#text(" is arguably the most famous equation in physics. But his ")#link("http://www.physik.uni-augsburg.de/annalen/history/papers/1906_20_627-633.pdf")[#text("beautifully elegant ")#emph[#text("derivation")]#text(" of this formula")]#text(" (here is the ")#link("http://www.fourmilab.ch/etexts/einstein/E_mc2/www/")[#text("English translation")]#text(") from previously understood laws of physics is considerably less famous. (There is an amusing ")#link("http://en.wikipedia.org/wiki/Far_Side")[#text("Far Side")]#text(" cartoon in this regard, with the punchline “squared away”, which you can find on-line by searching hard enough, though I will not link to it directly.)")

#text("This topic had come up in ")#link("https://terrytao.wordpress.com/2007/12/21/pcm-article-phase-space/#comments")[#text("recent discussion on this blog")]#text(", so I thought I would present Einstein’s derivation here. Actually, to be precise, in the paper mentioned above, Einstein uses the ")#link("http://en.wikipedia.org/wiki/Postulates_of_special_relativity")[#text("postulates of special relativity")]#text(" and other known laws of physics to show the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition")]#text(". (Mass-energy equivalence) If a body at rest emits a total energy of E while remaining at rest, then the mass of that body decreases by ")#mi("E/c^2")#text(".")
]

#text("Assuming that bodies at rest with zero mass necessarily have zero energy, this implies the famous formula ")#mi("E = mc^2")#text(" – but only for bodies which are at rest. For moving bodies, there is a similar formula, but one has to first decide what the correct definition of mass is for moving bodies; I will not discuss this issue here, but see for instance the ")#link("http://en.wikipedia.org/wiki/Mass_in_special_relativity")[#text("Wikipedia entry on this topic")]#text(".")

#text("Broadly speaking, the derivation of the above proposition proceeds via the following five steps:")

#enum(start: 1, 
[#text("Using the ")#link("http://en.wikipedia.org/wiki/Postulates_of_special_relativity")[#text("postulates of special relativity")]#text(", determine how space and time coordinates transform under changes of reference frame (i.e. derive the ")#link("http://en.wikipedia.org/wiki/Lorentz_transformation")[#text("Lorentz transformations")]#text(").")],
[#text("Using 1., determine how the ")#link("http://en.wikipedia.org/wiki/Frequency")[#text("temporal frequency")]#text(" ")#mi("\\nu")#text(" (and ")#link("http://en.wikipedia.org/wiki/Wave_vector")[#text("wave number")]#text(" k) of ")#link("http://en.wikipedia.org/wiki/Photons")[#text("photons")]#text(" transform under changes of reference frame (i.e. derive the formulae for relativistic ")#link("http://en.wikipedia.org/wiki/Doppler_shift")[#text("Doppler shift")]#text(").")],
[#text("Using ")#link("https://en.wikipedia.org/wiki/Planck%E2%80%93Einstein_relation")[#text("Planck’s relation")]#text(" ")#mi("E = h\\nu")#text(" (and ")#emph[#text("de Broglie’s law")]#text(" ")#mi("p = \\hbar k")#text(") and 2., determine how the energy E (and momentum p) of photons transform under changes of reference frame.")],
[#text("Using the ")#link("http://en.wikipedia.org/wiki/Conservation_of_energy")[#text("law of conservation of energy")]#text(" (and momentum) and 3., determine how the energy (and momentum) of bodies transform under changes of reference frame.")],
[#text("Comparing the results of 4. with the classical Newtonian approximations ")#tao-math("KE \\approx \\frac{1}{2} m\\left|v\\right|^2", block: false)#text(" (and ")#mi("p \\approx mv")#text("), deduce the relativistic relationship between mass and energy for bodies at rest (and more generally between mass, velocity, energy, and momentum for moving bodies).")]
)

#text("Actually, as it turns out, Einstein’s analysis for bodies at rest only needs to understand changes of reference frame at infinitesimally low velocity, ")#tao-math("\\left|v\\right| \\ll c", block: false)#text(". However, in order to see enough relativistic effects to deduce the mass-energy equivalence, one needs to obtain formulae which are accurate to second order in v (or more precisely, ")#mi("v/c")#text("), as opposed to those in Newtonian physics which are accurate to first order in v. Also, to understand the relationship between mass, velocity, energy, and momentum for moving bodies rather than bodies at rest, one needs to consider non-infinitesimal changes of reference frame.")

#emph[#text("Important note")]#text(": Einstein’s argument is, of course, a physical argument rather than a mathematical one. While I will use the language and formalism of pure mathematics here, it should be emphasised that I am not exactly giving a formal proof of the above Proposition in the sense of modern mathematics; these arguments are instead more like the classical proofs of Euclid, in that numerous “self evident” assumptions about space, time, velocity, etc. will be made along the way. (Indeed, there is a very strong analogy between Euclidean geometry and the ")#link("http://en.wikipedia.org/wiki/Minkowski_space")[#text("Minkowskian geometry")]#text(" of special relativity.) One can of course make these assumptions more explicit, and this has been done in many other places, but I will avoid doing so here in order not to overly obscure Einstein’s original argument.")#metadata(none) <tao-86280c835665ff682f57>

#heading(level: 1)[#text("— Lorentz transforms to first order —")]

#text("To simplify the notation, we shall assume that the ambient ")#link("http://en.wikipedia.org/wiki/Spacetime")[#text("spacetime")]#text(" S has only one spatial dimension rather than three, although the analysis here works perfectly well in three spatial dimensions (as was done in Einstein’s original paper). Thus, in any ")#link("http://en.wikipedia.org/wiki/Inertial_reference_frame")[#text("inertial reference frame")]#text(" F, the spacetime S is parameterised by two real numbers (t,x). Mathematically, we can describe each frame F as a bijection between S and ")#mi("{\\Bbb R} \\times {\\Bbb R}")#text(". To normalise these coordinates, let us suppose that all reference frames agree to use a single event O in S as their origin (0,0); thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("F(O)=(0,0)")]]

#text("for all frames F.")

#text("Given an inertial reference frame ")#mi("F: S \\to {\\Bbb R} \\times {\\Bbb R}")#text(", one can generate new inertial reference frames in two different ways. One is by ")#emph[#text("reflection")]#text(": one takes the same frame, with the same time coordinate, but reverses the space coordinates to obtain a new frame ")#mi("\\overline{F}: S \\to {\\Bbb R} \\times {\\Bbb R}")#text(", thus reversing the orientation of the frame. In equations, we have")

#align(center)[#text("if ")#mi("F(E) = (t,x)")#text(", then ")#mi("\\overline{F}(E) = (t,-x)")#text(" (2)")]

#text("for any spacetime event E. Another way is by replacing the observer which is stationary in F with an observer which is moving at a constant velocity v in F, to create a new inertial reference frame ")#mi("F_v: S \\to {\\Bbb R} \\times {\\Bbb R}")#text(" with the same orientation as F. In our analysis, we will only need to understand infinitesimally small velocities v; there will be no need to consider observers traveling at speeds close to the speed of light.")

#text("The new frame ")#mi("F_v: S \\to {\\Bbb R} \\times {\\Bbb R}")#text(" and the original frame ")#mi("F: S \\to {\\Bbb R} \\times {\\Bbb R}")#text(" must be related by some transformation law")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("F_v = L_v \\circ F")]]

#text("for some bijection ")#mi("L_v: {\\Bbb R} \\times {\\Bbb R} \\to {\\Bbb R} \\times {\\Bbb R}")#text(". A priori, this bijection ")#mi("L_v")#text(" could depend on the original frame F as well as on the velocity v, but the ")#link("http://en.wikipedia.org/wiki/Principle_of_relativity")[#text("principle of relativity ")]#text("implies that ")#mi("L_v")#text(" is in fact the same in all reference frames F, and so only depends on v.")

#text("It is thus of interest to determine what the bijections ")#mi("L_v: {\\Bbb R} \\times {\\Bbb R} \\to {\\Bbb R} \\times {\\Bbb R}")#text(" are. From our normalisation (1) we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("L_v (0,0) = (0,0)")]]

#text("but this is of course not enough information to fully specify ")#mi("L_v")#text(". To proceed further, we recall ")#link("http://en.wikipedia.org/wiki/Newton%27s_first_law")[#text("Newton’s first law")]#text(", which states that an object with no external forces applied to it moves at constant velocity, and thus traverses a straight line in spacetime as measured in any inertial reference frame. (We are assuming here that the property of “having no external forces applied to it” is not affected by changes of inertial reference frame. For non-inertial reference frames, the situation is more complicated due to the appearance of ")#link("http://en.wikipedia.org/wiki/Fictitious_force")[#text("fictitious forces")]#text(".) This implies that ")#mi("L_v")#text(" transforms straight lines to straight lines. (To be pedantic, we have only shown this for straight lines corresponding to velocities that are physically attainable, but let us ignore this minor technicality here.) Combining this with (4), we conclude that ")#mi("L_v")#text(" is a ")#link("http://en.wikipedia.org/wiki/Linear_transformation")[#text("linear transformation")]#text(". (It is a cute exercise to verify this claim formally, under reasonable assumptions such as smoothness of ")#mi("L_v")#text(". ) Thus we can view ")#mi("L_v")#text(" now as a ")#mi("2 \\times 2")#text(" matrix.")

#text("When v=0, it is clear that ")#mi("L_v")#text(" should be the identity matrix I. Making the plausible assumption that ")#mi("L_v")#text(" varies smoothly with v, we thus have the Taylor expansion")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("L_v = I + L^{\\prime}_0 v + O(v^2)")]]

#text("for some matrix ")#mi("L^{\\prime}_0")#text(" and for infinitesimally small velocities v. (Mathematically, what we are doing here is analysing the ")#link("http://en.wikipedia.org/wiki/Lie_group")[#text("Lie group")]#text(" of transformations ")#mi("L_v")#text(" via its ")#link("http://en.wikipedia.org/wiki/Lie_algebra")[#text("Lie algebra")]#text(".) Expanding everything out in coordinates, we obtain")

#align(center)[#tao-fit-display[#mitex("L_v(t, x) = ( (1 + \\alpha v + O(v^2)) t + (\\beta v + O(v^2)) x,")]]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("(\\gamma v + O(v^2)) t + (1 + \\delta v + O(v^2)) x )")]]

#text("for some absolute constants ")#mi("\\alpha, \\beta, \\gamma, \\delta \\in {\\Bbb R}")#text(" (not depending on t, x, or v).")

#text("The next step, of course, is to pin down what these four constants are. We can use the reflection symmetry (2) to eliminate two of these constants. Indeed, if an observer is moving at velocity v in frame F, it is moving in velocity -v in frame ")#mi("\\overline{F}")#text(", and hence ")#mi("\\overline{F_v} = \\overline{F}_{-v}")#text(". Combining this with (2), (3), (6) one eventually obtains")

#align(center)[#mi("\\alpha = 0")#text(" and ")#mi("\\delta = 0")#text(". (7)")]

#text("Next, if a particle moves at velocity v in frame F, and more specifically moves along the worldline ")#mi("\\{ (t, vt): t \\in {\\Bbb R} \\}")#text(", then it will be at rest in frame ")#mi("F_v")#text(", and (since it passes through the universally agreed upon origin O) must then lie on the worldline ")#mi("\\{ (t^{\\prime}, 0): t^{\\prime} \\in {\\Bbb R} \\}")#text(". From (3), we conclude")

#align(center)[#mi("L_v(t,vt) \\in \\{ (t^{\\prime},0): t^{\\prime} \\in {\\Bbb R} \\}")#text(" for all t. (8)")]

#text("Inserting this into (6) (and using (7)) we conclude that ")#mi("\\gamma = -1")#text(". We have thus pinned down ")#mi("L_v")#text(" to first order almost completely:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("L_v (t, x) = ( t + \\beta v x, x - vt ) + O( v^2 (\\left|t\\right|+\\left|x\\right|) ).", block: true)]]

#text("Thus, rather remarkably, using nothing more than the principle of relativity and Newton’s first law, we have almost entirely determined the reference frame transformation laws, save for the question of determining the real number ")#mi("\\beta")#text(". [In mathematical terms, what we have done is classify the one-dimensional Lie subalgebras of ")#mi("\\mathfrak{gl}_2({\\Bbb R})")#text(" which are invariant under spatial reflection, and coordinatised using (8).] If this number vanished, we would eventually recover classical ")#link("http://en.wikipedia.org/wiki/Galilean_relativity")[#text("Galilean relativity")]#text(". If this number was positive, we would eventually end up with the (rather unphysical) situation of ")#emph[#text("Euclidean relativity")]#text(", in which spacetime had a geometry isomorphic to that of the Euclidean plane. As it turns out, though, in special relativity this number is negative. This follows from the second ")#link("http://en.wikipedia.org/wiki/Postulates_of_special_relativity")[#text("postulate of special relativity")]#text(", which asserts that the speed of light c is the same in all inertial reference frames. In equations (and because ")#mi("F_v")#text(" has the same orientation as F), this is asserting that")

#align(center)[#mi("L_v(t,ct) \\in \\{ (t^{\\prime},ct^{\\prime}): t^{\\prime} \\in {\\Bbb R} \\}")#text(" for all t (10+)")]

#text("and")

#align(center)[#mi("L_v(t,-ct) \\in \\{ (t^{\\prime},-ct^{\\prime}): t^{\\prime} \\in {\\Bbb R} \\}")#text(" for all t. (10-)")]

#text("Inserting either of (10+) or (10-) into (9) we conclude that ")#mi("\\beta = -1/c^2")#text(", and thus we have obtained a full description of ")#mi("L_v")#text(" to first order:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("L_v (t, x) = ( t - \\frac{v x}{c^2}, x - vt ) + O( v^2 (\\left|t\\right|+\\left|x\\right|) ).", block: true)]]

#heading(level: 1)[#text("— Lorentz transforms to second order —")]

#text("It turns out that to get the mass-energy equivalence, first-order expansion of the Lorentz transformations ")#mi("L_v")#text(" is not sufficient; we need to expand to second order. From Taylor expansion we know that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("L_v = I + L^{\\prime}_0 v + \\frac{1}{2} L^{\\prime\\prime}_0 v^2 + O( v^3 )")]]

#text("for some matrix ")#mi("L^{\\prime\\prime}_0")#text(". To compute this matrix, let us make the plausible assumption that if the frame ")#mi("F_v")#text(" is moving at velocity v with respect to F, then F is moving at velocity -v with respect to ")#mi("F_v")#text(". (One can justify this by considering two frames receding at equal and opposite directions from a single reference frame, and using reflection symmetry to consider how these two frames move with respect to each other.) Applying (3) we conclude that ")#mi("L_{-v} \\circ L_v = I")#text(". Inserting this into (12) and comparing coefficients we conclude that ")#mi("L^{\\prime\\prime}_0 = (L^{\\prime}_0)^2")#text(". Since ")#mi("L^{\\prime}_0")#text(" is determined from (11), we can compute everything explicitly, eventually ending up at the second order expansion")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("L_v (t, x) = ( t - \\frac{v x}{c^2} + \\frac{t v^2}{2c^2}, x - vt + \\frac{xv^2}{2c^2}) + O( v^3 (\\left|t\\right|+\\left|x\\right|) ).", block: true)]]

#text("One can continue in this fashion (exploiting the fact that the ")#mi("L_v")#text(" must form a Lie group (with the Lie algebra already determined), and using (8) to fix the parameterisation ")#mi("v \\mapsto L_v")#text(" of that group) to eventually get the full expansion of ")#mi("L_v")#text(", namely")

#align(center)[#mi("L_v (t, x) = \\left( \\frac{t - vx/c^2}{\\sqrt{1-v^2/c^2}}, \\frac{x-vt}{\\sqrt{1-v^2/c^2}} \\right)")#text(",")]

#text("but we will not need to do so here.")

#heading(level: 1)[#text("— Doppler shift —")]

#text("The formula (13) is already enough to recover the relativistic ")#link("http://en.wikipedia.org/wiki/Doppler_shift")[#text("Doppler shift")]#text(" formula (to second order in v) for radiation moving at speed c with some ")#link("http://en.wikipedia.org/wiki/Wave_number")[#text("wave number")]#text(" k. Mathematically, such radiation moving to the right in an inertial reference frame F can be modeled by the function")

#align(center)[#tao-fit-display[#mitex("A \\cos( k (x-ct) + \\theta )")]]

#text("for some amplitude A and phase shift ")#mi("\\theta")#text(". If we move to the coordinates ")#mi("(t^{\\prime},x^{\\prime}) = L_v(t,x)")#text(" provided by an inertial reference frame F’, a computation then shows that the function becomes")

#align(center)[#tao-fit-display[#mitex("A \\cos( k_+ (x^{\\prime}-ct^{\\prime}) + \\theta)")]]

#text("where ")#mi("k_+ =  (1-v/c+v^2/2c^2 + O(v^3)) k")#text(". (actually, if the radiation is tensor-valued, the amplitude A might also transform in some manner, but this transformation will not be of relevance to us.) Similarly, radiation moving at speed c to the left will transform from")

#align(center)[#tao-fit-display[#mitex("A \\cos( k (x+ct) + \\theta )")]]

#text("to")

#align(center)[#tao-fit-display[#mitex("A \\cos( k_- (x+ct) + \\theta )")]]

#text("where ")#mi("{}k_- = (1+v/c+v^2/2c^2 + O(v^3)) k")#text(". This describes how the wave number k transforms under changes of reference frame by small velocities v. The ")#link("http://en.wikipedia.org/wiki/Frequency")[#text("temporal frequency")]#text(" ")#mi("\\nu")#text(" is linearly related to the wave number k by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\nu = \\frac{c}{2\\pi} k,")]]

#text("and so this frequency transforms by the (")#link("http://en.wikipedia.org/wiki/Red_shift")[#text("red-shift")]#text(") formula")

#align(center)[#mi("\\nu_+ =  (1-v/c+v^2/2c^2 + O(v^3))\\nu")#text(" (15+)")]

#text("for right-ward moving radiation and by the (blue-shift) formula")

#align(center)[#mi("\\nu_- =  (1+v/c+v^2/2c^2 + O(v^3))\\nu")#text(" (15-)")]

#text("for left-ward moving radiation. (As before, one can give an exact formula here, but the above asymptotic will suffice for us.)")

#heading(level: 1)[#text("— Energy and momentum of photons —")]

#text("From the work of Planck, and of Einstein himself on the ")#link("http://en.wikipedia.org/wiki/Photoelectric_effect")[#text("photoelectric effect")]#text(", it was known that light could be viewed both as a form of radiation (moving at speed c), and also made up of particles (photons). From ")#link("http://en.wikipedia.org/wiki/Planck%27s_law")[#text("Planck’s law")]#text(", each photon has an energy of ")#mi("E = h \\nu")#text(" and (from de Broglie’s law) a momentum of ")#mi("p = \\pm \\hbar k = \\pm \\frac{h}{2\\pi} k")#text(", where h is Planck’s constant, and the sign depends on whether one is moving rightward or leftward. In particular, from (14) we have the pleasant relationship")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("E = \\left|p\\right| c", block: true)]]

#text("for photons. [More generally, it turns out that for arbitrary bodies, momentum, velocity, and energy are related by the formula ")#mi("p = \\frac{1}{c^2} E v")#text(", though we will not derive this fact here.] Applying (15+), (15-), we see that if we view a photon in a new reference frame ")#mi("F_v")#text(", then the observed energy E and momentum p now become")

#align(center)[#mi("E_+ =  (1-v/c+v^2/2c^2 + O(v^3)) E")#text("; ")#mi("p_+ =  (1-v/c+v^2/2c^2 + O(v^3)) p")#text(" (17+)")]

#text("for right-ward moving photons, and")

#align(center)[#mi("E_- =  (1+v/c+v^2/2c^2 + O(v^3)) E")#text("; ")#mi("p_- =  (1+v/c+v^2/2c^2 + O(v^3)) p")#text(" (17-)")]

#text("for left-ward moving photons.")

#text("These two formulae (17+), (17-) can be unified using (16) into a single formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("(E^{\\prime}/c^2, p^{\\prime}) = L_v (E/c^2,p) + O(v^3)")]]

#text("for any photon (moving either leftward or rightward) with energy E and momentum p as measured in frame F, and energy E’ and momentum p’ as measured in frame ")#mi("F_v")#text(". Actually, the error term ")#mi("O(v^3)")#text(" can be deleted entirely by working a little harder. From the linearity of ")#mi("L_v")#text(" and the conservation of energy and momentum, it is then natural to conclude that (18) should also be valid not only for photons, but for any object that can exchange energy and momentum with photons. This can be used to derive the formula ")#mi("E=mc^2")#text(" fairly quickly, but let us instead give the original argument of Einstein, which is only slightly different.")

#heading(level: 1)[#text("— Einstein’s argument —")]

#text("We are now ready to give Einstein’s argument. Consider a body at rest in a reference frame F with some mass ")#mi("m")#text(" and some rest energy ")#mi("E")#text(". (We do not yet know that ")#mi("E")#text(" is equal to ")#mi("m c^2")#text(".) Now let us view this same mass in some new reference frame ")#mi("F_v")#text(", where v is a small velocity. From Newtonian mechanics, we know that a body of mass ")#mi("m")#text(" moving at velocity v acquires a kinetic energy of ")#mi("\\frac{1}{2} m v^2")#text(". Thus, assuming that Newtonian physics is valid at low velocities to top order, the net energy E’ of this body as viewed in this frame ")#mi("F_v")#text(" should be")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("E^{\\prime} = E + \\frac{1}{2} m v^2 + O(v^3).")]]

#text("If assumes that the transformation law (18) applies for this body, one can already deduce the formula ")#mi("E=mc^2")#text(" for this body at rest from (19) (and the assumption that bodies at rest have zero momentum), but let us instead give Einstein’s original argument.")

#text("We return to frame F, and assume that our body emits two photons of equal energy ")#mi("\\Delta E/2")#text(", one moving left-ward and one moving right-ward. By (16) and conservation of momentum, we see that the body remains at rest after this emission. By conservation of energy, the remaining energy in the body is ")#mi("E - \\Delta E")#text(". Let’s say that the new mass in the body is ")#mi("m - \\Delta m")#text(". Our task is to show that ")#mi("\\Delta E = \\Delta m c^2")#text(".")

#text("To do this, we return to frame ")#mi("F_v")#text(". By (16+), the rightward moving photon has energy")

#align(center)[#mi("(1-v/c+v^2/2c^2 + O(v^3)) \\frac{\\Delta E}{2}")#text("; (20+)")]

#text("in this frame; similarly, the leftward moving photon has energy")

#align(center)[#mi("(1+v/c+v^2/2c^2 + O(v^3)) \\frac{\\Delta E}{2}")#text(". (20-)")]

#text("What about the body? By repeating the derivation of (18), it must have energy")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("(E - \\Delta E) + \\frac{1}{2} (m-\\Delta m)v^2 + O(v^3).")]]

#text("By the principle of relativity, the law of conservation of energy has to hold in the frame ")#mi("F_v")#text(" as well as in the frame F. Thus, the energy (20-)+(20+)+(20) in frame ")#mi("F_v")#text(" after the emission must equal the energy E’=(19) in frame ")#mi("F_v")#text(" before emission. Adding everything together and comparing coefficients we obtain the desired relationship ")#mi("\\Delta E = \\Delta m c^2")#text(".")

#text("[One might quibble that Einstein’s argument only applies to emissions of energy that consist of equal and opposite pairs of photons. But one can easily generalise the argument to handle arbitrary photon emissions, especially if one takes advantage of (18); for instance, another ")#link("http://cosmicvariance.com/2007/02/23/why-does-emc2/")[#text("well-known (and somewhat simpler) variant of the argument")]#text(" works by considering a photon emitted from one side of a box and absorbed on the other. More generally, any other energy emission which could potentially in the future decompose entirely into photons would also be handled by this argument, thanks to conservation of energy. Now, it is possible that other conservation laws prevent decomposition into photons; for instance, the law of conservation of charge prevents an electron (say) from decomposing entirely into photons, thus leaving open the possibility of having to add a linearly charge-dependent correction term to the formula ")#mi("E = mc^2")#text(". But then one can renormalise away this term by redefining the energy to subtract such a term; note that this does not affect conservation of energy, thanks to conservation of charge.]")

#heading(level: 1)[#text("Comments (109)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74bec5665586fa7592c7dc0980cfde5558db478aa11c7a6454e2879bafd4fdfa-b5ba177265e83dda077d072769c5fe0e881e20dd623dd100d1d08f4c49b86394.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jon")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-53440")[#strong[#text("Jon")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2011")])]

#text("Dear Terrence Tao,")

#text("Could you, pls, tell me what do I need to know to understand Einstein general relativity proof ?")

#text("I know that is necessary to understand Differential Geometry, right ?")#linebreak()#text(" What more ?")#linebreak()#text(" I want to set this as one of my lifetime Goals. :o)")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-219687")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2013")])]

#text("Study Tensors. Start with the metric tensor .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-71981")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2011")])]

#text("e=mc 2 is wrong …there must be a factor v that is subtracted from the velocity of light inorder to get the correct equation and that subtracted quantity is the limiting value for the reference frame …if we got that reference frame we can understand the success of reaction ….")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea486da69267eafbd6baba76665d4423306325a04cd146e79218afa49757b9d9-f098aebcd3e4631f59240afa1db3b5706eec31783925fec7f20dd344824af3d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hoyhiv")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-444392")[#strong[#text("hoyhiv")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2014")])]

#text("E= mc q<- einstein forgot theory of relativity")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63af298ee7fbd18323a0badc3cafc52d6820b69f76fd20c9eb80327c165661b1-02e7e836f799b1304855789f9aae798a443bbdb56a6247a4bc3bf527eb34eda3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amateur")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-96052")[#strong[#text("amateur")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2011")])]

#text("How can someone explain changes in 4-d space-time (t,x(t),y(t),z(t)) mathematically since 1 is constant:")

#text("(1,dx/dt,dy/dt,dz/dt)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scottpark")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-146386")[#strong[#text("Scottpark")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2012")])]

#text("So useful post.Thank you!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a9a823ace3f22d40775e7cec7524071381aca04a8f73034d937c87ad348229ed-7be0ea085eaf0beafc0b006ededf732207b125067d0a601f89c9c37d3f4fb5b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kuhan")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-154698")[#strong[#text("Kuhan")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2012")])]

#link("http://www.ams.org/bookstore/pspdf/mbk-59-prev.pdf")[#text("Click to access mbk-59-prev.pdf")]

#text("has similar article")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Einstein’s derivation of E=mc^2 revisited « What’s new")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-177578")[#strong[#text("Einstein’s derivation of E=mc^2 revisited « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2012")])]

#text("[…] back in 2007, I wrote a blog post giving Einstein’s derivation of his famous equation . This derivation used a number of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-177976")[#strong[#text("Wow Terrence Tao « The logic of images")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")]

#text("[…] back in 2007, I wrote a blog post giving Einstein’s derivation of his famous equation for the rest energy of a body with mass . […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c75b16fb55a9199d36cd0cb52e126328239db57f1b3551965b59ae949156a55c-4a06b6fee8e4c3c0d0706a18fbaf8c915f242fcc00d1ef624d9983196718da64.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Milad")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-197798")[#strong[#text("Milad")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2012")])]

#text("Reblogged this on ")#link("http://miladebrahimpour.wordpress.com/2012/11/30/266/")[#text("Milad Ebrahimpour 's Blog")]#text(" and commented:")#linebreak()#text(" You see how the universe is ruled by math?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An introduction to special relativity for a high school math circle « What’s new")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-209603")[#strong[#text("An introduction to special relativity for a high school math circle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2012")])]

#text("[…] equivalence relation E=mc^2, largely following Einstein’s original derivation as discussed in this previous blog post); instead we will probably spend a fair chunk of time on related topics which do not actually […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b27bc80b9492e61975e55dbc22e31438c86cbbb11088c5314b78d98ad1c11aa3-7ba711a6bbfc2e737373eb5633e20458f5fe61a1c9f3de0669f643d8be9ff64c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Einstein’s derivation of E=mc^2 | What about being a physicist")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-211646")[#strong[#text("Einstein’s derivation of E=mc^2 | What about being a physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2012")])]

#text("[…] Einstein’s derivation of E=mc^2. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f5c2b7ae2d57d4f5c634cc2d824d0df9f1bf18fb34b103631392c31f6569c34-4af7b51f4ebb167403467d32432414289ae01ae89e612efe2293c998cb244708.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bert latif")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-212478")[#strong[#text("bert latif")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2013")])]

#text("good justification about e=mcc,,,,,,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-214250")[#strong[#text("Everything is Relative. (Trippy) Consequences of Special Relativity. Prove E = mc2 | A Revolving Wheel")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2013")]

#text("[…] Terrytao: Deriving E=mc2 Ask a Mathematician: Q: Why does E=MC2? Wiki: Theory of Relativity Wiki: Special Relativity Wiki: Introduction to Special Relativity Wiki: Relativity of Simultaneity […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ad5c42fe82487230a30392028f42e1abcd73bac1b1c3107d1200eb40362f487-86a1b68e1026b92ecc5257605c1ef2a1241297705954af099ce19c1008247a01.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jussilindgren")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-219686")[#strong[#text("jussilindgren")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2013")])]

#text("I’ve recently developed a possible model for gravitation that reduces to the Newtonian limit with low velocities/masses and yields also the mass-energy equivalence. The model is based on the idea to consider tensor products in flat Minkowski space. When one generalises then the concept of work-energy principle, one obtains the following nonlinear PDE system:")

#mi("\\frac{1}{c}\\frac{\\partial \\vec{u}}{\\partial t}+\\frac{1}{c}\\vec{u}\\cdot \\nabla \\vec{u}+ \\frac{1}{c^2}\\frac{\\partial \\psi}{\\partial t}\\vec{u}=\\nabla \\psi")

#text("The respective energy equation is the following general wave equation")

#mi("\\frac{1}{c^2}\\frac{\\partial \\psi}{\\partial t^2}-\\Delta \\psi=-\\nabla \\cdot (\\frac{1}{c}\\vec{u}\\cdot \\nabla \\vec{u})- \\nabla \\cdot (\\frac{1}{c^2}\\frac{\\partial \\psi}{\\partial t}\\vec{u})")

#text("This is work in progress, I have a blog on the issue at jussilindgren.wordpress.com")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6dc18570a01e7d2192843d3eaf1146c2cf639864d4aba5bd58c601c9af7e14ba-4e71db70b5a5cf63b607be0c6718643fc556869f04ef65613e9d4dea33458124.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Osuma")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-222208")[#strong[#text("Osuma")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2013")])]

#text("What is the meaning of c in einstein equation")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74b357dbf04aecc5935b1651da2f859bea62b88d9b5d8931cefe94f870ff741b-9538a8e4aaa9c418de67a52f5968658b9b6896dfb72dfaba632a11c8b1bc43f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Reece")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-222257")[#strong[#text("Reece")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2013")])]

#text("The speed of light")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fccdbd60ae8c5c2494e472d230d6e83936ff7fce30b6daef57012706114ab1f-4b24b6f59b9bad047b0fffd028b39946a57971b41e4841e0824e583330e4a104.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of johngokul")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-225640")[#strong[#text("johngokul")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2013")])]

#text("I can’t believe it what a scientist was einstein. this website give chance to know about the universal equation.it will useful the student.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4933a38ba4d0a37299310be53d7bc8568629eca34c450897dae957823096aa70-221aff9c7d81a852dec949b87542156522b2dc3e60b3fd1467b47f85e18b1f57.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aayush Dhital")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-237508")[#strong[#text("Aayush Dhital")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2013")])]

#text("Sir, I searched for the answer of the quesion “why mass causes curvature in space-time?” and I think I’ve found it. However, I’am not 100% sure on it. In my view every atoms contain a unit charge so any body with mass can be considered as a massive charge itself since it is the resultant of all the charges. In my view, this charge actually pushes the dark energy in the space and so does the dark energy. Hence, space-time is curved along the massive body….")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-242142")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2013")])]

#text("this cannot happen bcuz atom is electrically neutral")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18c2e4b37cb320f5bf78c0739f81a1d8426a134c29e28a669538d043acb3436f-7023f4244731080155b79ca4d68486a0a60723ac899b2a0a509aa751c4534e7d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of socratus")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-252774")[#strong[#text("socratus")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2013")])]

#text("The strange and magic E= Mc^2")#linebreak()#text(" 1")#linebreak()#text(" In 1905 Einstein asked:")#linebreak()#text(" “ Does the inertia of a body depend upon its energy content?”")#linebreak()#text(" As he realized the answer was:")#linebreak()#text(" “ Yes, inertia depends on its energy content E= Mc^2 ”")#linebreak()#text(" Newton’s inertia doesn’t have force/energy,")#linebreak()#text(" Einstein’s inertia has energy. How to understand this difference?")#linebreak()#text(" 2.")#linebreak()#text(" In 1928 Dirac said that E= Mc^2 can be as positive")#linebreak()#text(" as negative too. What is interaction between them ?")#linebreak()#text(" 3 –")#linebreak()#text(" Sometimes E= Mc^2 can be ‘rest’ particle and sometimes")#linebreak()#text(" can be ‘active’ particle and can destroy cities like")#linebreak()#text(" Hiroshima and Nagasaki")#linebreak()#text(" Why E= Mc^2 is so strange ? Nobody gives answer")#linebreak()#text(" ===.")#linebreak()#text(" All the best.")#linebreak()#text(" Israel Sadovnik Socratus.")#linebreak()#text(" ==============..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-267697")[#strong[#text("Ask a physicist anything. (8) - Page 61 - Christian Forums")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2014")]

#text("[…] Equation The original formula dealt with the rest mass of a body, forgotten in modern textbooks. ")#link("https://terrytao.wordpress.com/2007/1")[#text("https://terrytao.wordpress.com/2007/1")]#text("…ation-of-emc2/ __________________ \"If one closes their eyes they can imagine a universe of infinite […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cd83dde86c81a1c2a065b8311b4a4913c8c3a9898403cb773d98483daa41912-6071fd7255dc2dc3cfe34b4717111edc63fc626958a8ddb601d254afd37d4023.gif", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Allen")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-271807")[#strong[#text("James Allen")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2014")])]

#text("Where’s Leibniz? Tsk-tsk.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-368015")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2014")])]

#text("Stillni havevthe easiest way to prove it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0868ed79d800e176b8d14e12467a1e80a24a9a86d2ab5df959d60c8c890f604d-d4aa17bc299c1a9d5a33d792a8ec371f62c7dff5db4790bd531729a3aa1d2efb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dominic nentawe.")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-433847")[#strong[#text("dominic nentawe.")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2014")])]

#text("Please can someone deduce the einstein famous energy formula from the de broglie equation")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0dda240d9d072be28cfb90f77c4a3c5f086d54489499dabcd0fd88e1221e30-876385852160741832497bf03dfa847c95bb647965364f9efc77e2cecee1b5a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yusra")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-445359")[#strong[#text("yusra")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2014")])]

#text("how can we find the dimension of E=MC2")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0dda240d9d072be28cfb90f77c4a3c5f086d54489499dabcd0fd88e1221e30-876385852160741832497bf03dfa847c95bb647965364f9efc77e2cecee1b5a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yusra")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-445361")[#strong[#text("yusra")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2014")])]

#text("tell me quick.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-449516")[#strong[#text("On the Beauty Of Physical Theories | ENIGMA")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2015")]

#text("[…] ")#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/")[#text("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/114cbcc2a74dfc81366db7d70b0d57a1cb67b0f59aecb42e66a037bb0458989d-62eb15ac52c562e485dc0b3bd58b3822cb9d0af3de5a0665340040cef6691b92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mjg0")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-450155")[#strong[#text("mjg0")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2015")])]

#text("I urge everyone to read the paper by physicist Eugene Hecht entitled")#linebreak()#text(" “How Einstein confirmed E0=mc^2”, which you download from")

#link("http://www.loreto.unican.es/Carpeta2012/AJP(Hecht)Einstein2011.pdf")[#text("http://www.loreto.unican.es/Carpeta2012/AJP(Hecht)Einstein2011.pdf")]#text(".")

#text("Here is Hecht’s abstract:")

#text("The equivalence of mass m and rest-energy E0 is one of the great discoveries of all time. Despite the")#linebreak()#text(" current wisdom, Einstein did not derive this relation from first principles. Having conceived the idea")#linebreak()#text(" in the summer of 1905 he spent more than 40 years trying to prove it. We briefly examine all of")#linebreak()#text(" Einstein’s conceptual demonstrations of E0=mc2, focusing on their limitations and his awareness of")#linebreak()#text(" their shortcomings. Although he repeatedly confirmed the efficacy of E0=mc2, he never constructed")#linebreak()#text(" a general proof. Leaving aside that it continues to be affirmed experimentally, a rigorous proof of the")#linebreak()#text(" mass-energy equivalence is probably beyond the purview of the special theory [of relativity].")

#text("That last sentence is an important conjecture about the logic of SR.")

#text("A crucial point – which Terence emphasized he was avoiding – is whether mass changes with motion, i.e., whether mass is relativistic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/114cbcc2a74dfc81366db7d70b0d57a1cb67b0f59aecb42e66a037bb0458989d-62eb15ac52c562e485dc0b3bd58b3822cb9d0af3de5a0665340040cef6691b92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mjg0")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-450158")[#strong[#text("mjg0")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2015")])]

#text("Hecht’s article is critical of Einstein’s Sept. 1905 argument, which Terence presented above. Some of Hecht’s criticisms:")

#text("This derivation came very early in the development of")#linebreak()#text(" relativity, and the formal concept of “rest-energy” had not")#linebreak()#text(" yet evolved, nor had E0 been introduced to symbolize it.")#linebreak()#text(" Unless Einstein was willing to assume that whenever E0=0,")#linebreak()#text(" m=0—that all of the mass of a material entity was equivalent")#linebreak()#text(" to energy—he could not take the analysis any farther")#linebreak()#text(" than he had in September 1905. Unfortunately, he did not")#linebreak()#text(" overtly share his concerns about this issue with his readers.")

#text("it would not be until 1912 that he was writing statements")#linebreak()#text(" like: “According to this conception, we would have to view a")#linebreak()#text(" body with inertial mass m as an energy store of magnitude")#linebreak()#text(" mc^2 rest-energy of the body.” To attribute E0=mc^2 or")#linebreak()#text(" even worse, E=mc^2 to Einstein via the September")#linebreak()#text(" 1905 paper is to do injustice to the gradual nature of his")#linebreak()#text(" development of the concepts.")

#text("Einstein made")#linebreak()#text(" two intuitive and seemingly innocent leaps that went beyond")#linebreak()#text(" what he could prove. “Since obviously here it is inessential")#linebreak()#text(" that the energy withdrawn from the body happens to turn into")#linebreak()#text(" energy of radiation rather than some other kind of energy, we")#linebreak()#text(" are led to the more general conclusion: The mass of a body is")#linebreak()#text(" a measure of its energy content [Energieinhalt]….”")

#text("The concept")#linebreak()#text(" of rest-energy was still unformulated, and he was not")#linebreak()#text(" even using the term. Without proof, Einstein guessed that the")#linebreak()#text(" loss of other forms of energy besides electromagnetic would")#linebreak()#text(" result in an equivalent loss of mass. That is no small point,")#linebreak()#text(" especially because many physicists at the time believed mass")#linebreak()#text(" was entirely electromagnetic.")

#text("An unspoken assumption was made early in the September")#linebreak()#text(" 1905 paper that each emitted light pulse was not material,")#linebreak()#text(" in that it carried energy but had no intrinsic mass.")#linebreak()#text(" Throughout his work on the special theory, Einstein maintained")#linebreak()#text(" that light was other than matter. As he put it in 1911,")#linebreak()#text(" “the comparison of light with other ‘stuff’ is not")#linebreak()#text(" permissible.” Thus, Einstein avoided a more complicated")#linebreak()#text(" calculation by conjecturing, without discussion or proof,")#linebreak()#text(" that light was massless. But of course he could not prove")#linebreak()#text(" such a thing, one way or the other.")

#text("Finally, it should be noted that plane waves are a mathematical")#linebreak()#text(" contrivance. No real extended body can actually")#linebreak()#text(" radiate electromagnetic plane waves as required by this")#linebreak()#text(" thought experiment. Naturally enough Einstein said nothing")#linebreak()#text(" about the physical structure of the hypothetical emitting")#linebreak()#text(" body that could perform such a feat. This omission likely")#linebreak()#text(" troubled him because, as we will see, he returned to the issue")#linebreak()#text(" seven years later with a more elaborate emitter.")

#text("What Einstein proved in September 1905 was that if an")#linebreak()#text(" imaginary material body could somehow emit radiant energy")#linebreak()#text(" E0 which is itself massless in the form of plane waves,")#linebreak()#text(" that extraordinary object would diminish in mass by E0 /c^2.")#linebreak()#text(" He did not prove that every form of energy was equivalent to")#linebreak()#text(" mass; that, he simply proclaimed. Yet, he was quite aware")#linebreak()#text(" that his analysis had limitations, and in 1907 he discussed the")#linebreak()#text(" need for a more general approach.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcdb6db3d1aac1e09f8239e7eb01a117588f5ee6c60c0cffa4a71901c2158e54-421b34ca3eedb0d842976be39578ce1d3eac7cb4dff3a0017b809a78cf011e81.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of milkias tesfalem")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-462259")[#strong[#text("milkias tesfalem")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2015")])]

#text("it was amazing but you should write it in other African languages such as Amharic")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-468661")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2016")])]

#text("Best")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ac4547c5a9fdd0cee13bafee92668c2f41a854f3c24cea28ce63a5b89b27f70-1f4b6421871fa588a9252289058ef44d2d865d154a591ad02d4fed4f8db86fa5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-469237")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2016")])]

#text("I think the link to Wikipedia article about Planck’s law should be replaced by a link to the page about Planck–Einstein relation.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ac4547c5a9fdd0cee13bafee92668c2f41a854f3c24cea28ce63a5b89b27f70-1f4b6421871fa588a9252289058ef44d2d865d154a591ad02d4fed4f8db86fa5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-469240")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2016")])]

#text("There is also a similar error in the section “Energy and momentum of photons” and this post: ")#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/")[#text("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/")]

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-471154")[#strong[#text("E=mc^2 – Making Sense of Complications")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2016")]

#text("[…] ")#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/")[#text("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b7749d073f2144cd675f7578268c5de1ac04eec4fec803150d97e987a553af1b-f15b510920a979bf6b1a264c1a36e89baa6bab742197be85e770e0688f848f49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Banashak")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-471320")[#strong[#text("Michael Banashak")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2016")])]

#text("Dear Terence,")

#text("There is no such thing as a mass- energy relationship. What there is, is a mass-energy-momentum relationship. Einstein rejected the idea of relativistic mass in his later years, strongly warning against it. An objects energy can change with speed (velocity) but its mass NEVER changes.")

#text("Einstein’s great discovery was the “rest-energy.” The only energy being put equal to mass is the ” rest -energy.” Mass is invariant.")

#text("Eistein real equation for an object at rest was Eo=moc2 , also written Eo=mc2. “E=mc2” was a result of his careless writing that the medi latched on to. For further information, look inot the great Russian physicists Lev Okun’s articles.")

#text("Best wishes,")#linebreak()#text(" Mike Banashak")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-471325")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2016")])]

#text("A zero rest mast particle (e.g. photon) demonstrates very clearly your remark! (in this case, ")#mi("m_0 c^2 = 0")#text(" – implying that the photon energy is contributed only by its momentum and not by its zero rest mass.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10805c9571d63d9cf51c6f4111c84e89480966267b6a621dd379259f54037cfc-ed8d0217eec414f659b6bad5590ec393f42d20153e268a42b4ef00f9d1d2e2c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cybersharque")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-474458")[#strong[#text("cybersharque")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2016")])]

#text("Which college-level course teaches this, and what are the pre-reqs? Does it (shudder) need complex analysis?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b196981b438d17e454e2c80441f283eafc08683e8e13d6a538fa7947ec16d91a-e9f1e16ad8f8c40ae170196f615af3a31809330f17162c6f4560227cd4677d58.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lukasz T. Stepien")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-474513")[#strong[#text("Lukasz T. Stepien")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2016")])]

#text("Dear Debaters")

#text("Michael Banashak has written that the mass-energy relationship does not exist. I think that saying about “equivalence of mass energy” is even more misleading.")#linebreak()#text(" Energy, as a conserved quantity, is connected to the symmetry of a system, with respect to time translations (it follows from Noether Theorem).")#linebreak()#text(" The square of mass is equal to (with the sign “minus”) the eigenvalue of the Casimir operator, which here is square of four-momentum")#linebreak()#text(" P^{\\mu}P_{\\mu} (the representation of the Poincare algebra – the massive case).")

#text("Best wishes,")#linebreak()#text(" Lukasz T. Stepien")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b7372863f1c5025505c2f0e372bc199488ae50a5b564ba938f96378b1e5c3c9f-201989625023f416037f6f9558889b2717dcd99ac36fd4269049bb986d79e922.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maxis Jaisi")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-474837")[#strong[#text("Maxis Jaisi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2016")])]

#text("Dear Terry, in Einstein’s original paper, there’s an additive constant C ( H_1 – E_1 = K_1 + C). But your derivation doesn’t. Are you setting C = 0? Is there any physical significance to the constant C?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec8375733c8e59aebc8b393cfcfcd6ab0a9c22071a03f94bf5401a0b01f8efd1-ba40e9c319ea3e04b92331fe16284269f910042a2bd216b517bceb199939a292.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dendisuhubdy")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-488639")[#strong[#text("dendisuhubdy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2017")])]

#text("Reblogged this on ")#link("http://suhubdy.com/research/index.php/2017/11/09/einsteins-derivation-of-emc2/")[#text("Artificial Intelligence Research Blog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2159f3810254064815baa1801dd0e8f4d6a61504ef7a8b72a275547ecbbaee6a-390b58582bd705cfe9e65a28bd339bef6394ee821d266da6f3c94ec7ffd6b2c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zcp")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-572099")[#strong[#text("Zcp")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2020")])]

#text("like here, Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/787f1f44da8c72f4fdd2009ade5f5da610aabe6286e3b353e042d264b4a4b4ac-0a0c3938fc18cf5baf303f159df15255ff8d69e987291906cb673c13dfb20aaf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rabi")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-577926")[#strong[#text("Rabi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2020")])]

#text("Apparently not meant for ordinary folks.")#linebreak()#text(" A lot of mumbo-jumbo. Plain english is missing.")#linebreak()#text(" A well understood topic should be easy to communicate.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18a7866c654cf3fe1ab1279db62496f1558286f44647c5b36d79ac83fd1c4771-6f3e77fee47e6083ed03276fb5c145cccb35c5dd51132e7b400ddf4c6d140ff4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hollis Williams")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-583597")[#strong[#text("Hollis Williams")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2020")])]

#text("Einstein also wrote a simpler ‘proof’ later in life, I’m not sure if Tao has read it. Anyway it’s in a book called The Essential Einstein and its only a few pages.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4121e08e65de20011594e64960dacc6dbdcdee51816b1329b08e1a1cf2c2b3e7-83ba494d20bfc793cb8629ab2b0c0a6de3f4b1adad17b8bc21001ea656678094.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ahmed kamel")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-586736")[#strong[#text("Ahmed kamel")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2020")])]

#text("Great ♥️♥️")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70e3a8ddfe0c019df004ce9e4aacba94f2ae631fdf7c0b2f215be192f0cc7fae-fd90c41a82f380117f870d907e7da1948cd442b87e9d8e2ff4aac7a5d7c63874.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fpmarin")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-599998")[#strong[#text("fpmarin")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2020")])]

#text("It’s curious that ")#mi("\\vec{F}\\cdot\\mathrm{d}\\vec{r} = c^{2}\\,\\mathrm{d}m")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-600192")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2020")])]

#text("It is important to note that the classical physical concepts such as mass, electrical charge and vector angular momentum, although “measurable” are not(!) rigorously well defined.")#linebreak()#text(" A rigorous mathematical definition of such concepts (for a given 3D “spatial domain slice” – with a fixed time-coordinate in 4D spacetime) should be based on the 4D spacetime metric.")

#text("A well-known example is the Kerr-Newman blackhole metric which is completely described by its intrinsic parameters (mass, electric charge, and vector angular momentum).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64cdf973b0b2c1adb68c16c6af5011c1a17b6cf2737b60fb23d7e9fb20e1b521-a2ab871031dd5c09b208059c6bf995d7376a710cec0d2c1af74ae7f66d19eae1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of isengbelajar")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-625342")[#strong[#text("isengbelajar")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2021")])]

#text("Nice proof!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e32f39baadba22d3d98ea20170d4cedb0213b53a448c9d9d832e0e5c074b719-955b429d194f4279bc89acd23a6fb125ec86bd5ef4c1e9ae2e99f9fbc57c7963.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Механика Пуанкаре-Эйнштейна — Блог друга Вигнера")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-2/#comment-641948")[#strong[#text("Механика Пуанкаре-Эйнштейна — Блог друга Вигнера")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2022")])]

#text("[…] потребуется дополнительное рассуждение (см. например, эйнштейновский вывод формулы ; но что более важно, если , то энергия и импульс не […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c625be66f01683e85d1a83275b12f8b4aa5f7c9accb665d2d56370c00f9243c6-7ef058e8d924fd94b552a49adcd8e57aca4e81ca3d8b76ccce583a64efa0a71a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roberta")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-22366")[#strong[#text("Roberta")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2007")])]

#text("Thank you for giving students around the world a chance to learn from this blog.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/89b1c2f6f4d1a9c9037bb19d0a2da0d6ed65d56db39f503f509c136654ae6673-fa2856fe7e3fb4bdc5d32dcd69c7895f47be2d6b2e8b7471bbd5a5cdb280c568.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jane")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-22395")[#strong[#text("jane")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2007")])]

#text("Terry, thank you for your latest articles. Being an undergraduate, I could understand both of these. (I once complained that your articles were too mathematically tense for undergrads). Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2083d83ed9def7ee21aafbd328e033cb4b2fd32aa6960e5349dd95b64520b440-7b47872958a8b2ca8997e98f69068c6a55f91e5e469dfabb5e71a30563b7ea8d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-22412")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2007")])]

#text("Just find a typo.")

#text("” Indeed, if an observer is moving at velocity v in frame F, it is moving in velocity -v in frame \\overline{F}, and hence \\overline{F_v} = \\overline{F}_{-v}. ”")

#text("I think it should be")#linebreak()#text(" F_v = \\overline{F}_{-v}")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-461028")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2015")])]

#text("Nop i think it’s not")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c3ada7a6cc841c548825899ac3e4a2f3bf1d8fecedda0fad4d1cee363392dd0-8073f8aa0e75033a5914fd5de9c0edfb33468968b3e64fee85225eccb558c2a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kea")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-22473")[#strong[#text("Kea")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2007")])]

#text("Cool post. BTW, you can use \\hspace (for instance) to set the equation numbers further to the right.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grad Student")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-22554")[#strong[#text("Grad Student")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2007")])]

#text("This post isn’t (necessarily) directed at Dr. Tao or directly related to the topic, so accept my apologies if it is out of line. I am currently about 1/2 way through a graduate program in mathematics, and happily working on problems I enjoy. Looking back on my undergraduate days I wish I had taken more physics, because (1) physical motivation/concepts are showing up more and more in the areas I am working in and (2) despite having avoided physics past the introductory level in college I have always found it interesting. I am curious if anyone has had experience diving back into physics in late math graduate school or later and any advice or thoughts they had on this matter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-22564")[#strong[#text("links for 2007-12-31 « Simply… A User")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2007")]

#text("[…] Einstein’s derivation of E=mc^2 « What’s new (tags: einstein physics mathematics relativity toread **) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-22624")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2007")])]

#text("Hi Terence,")

#text("Thank you for your demonstration of the derivation of E=mc^2.")

#text("As I am more medically [bio-physics] oriented than physics oriented perhaps you may be able to mathematically explain two questions:")

#text("1 – Why do physicists equate voltage energy [eV] to mass when engineers equate inductance [henry or weber per ampere] to mass?")

#text("This question arises from reading Raghbir Singh Khandpur, “Biomedical Instrumentation: Technology and Applications’, specifically from a table of electrical / mechanical equivalents, “The inductance symbol represents the effective vibrating mass of the element.” and figure 3.4 on pages 76-77 ")#link("http://books.google.com/books?id=BMNLEoz8S0MC&pg=PA76&lpg=PA76&dq=inductance+mass&source=web&ots=9D-Qx651dg&sig=krJXEMyMYNufmuehxiI4TErmH6c#PPA76,M1")[#text(" in chapter 3 Physiological transducers, 3.4 Displacement, Position and Motion transducers")]#text(".")#linebreak()#text(" Voltage is listed as corresponding to Force.")

#text("2 – Could you mathematically explain the Lorentz length contraction which from my perspective appears to be a paradox to the theory of inflation and the reaction of ordinary matter to non-relativistic energy changes?")

#text("For example one kilogram of water ice remains one kilogram when phase changes to either liquid or vapor, but the volume increases as the energy increases.")

#text("Naively, I would expect a length expansion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of G")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-22644")[#strong[#text("G")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2007")])]

#text("Hi There, I am afraid the good old Albert would prefer the physics over the math, after all, that is why he is regarded as the father of the subject, even though we talk about Poincare relativity and Lorentz transformations. There is yet another derivation of E/c^2 = m by him, although he used the *murky* notion of center of mass…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-22645")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2007")])]

#text("Doug, they don’t equate inductance with mass in general. This comes from the fact that a series RLC circuit obeys almost the same differential equation as a pendulum, as shown in the table ")#link("http://en.wikipedia.org/wiki/Harmonic_oscillator#Equivalent_systems")[#text("here")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-22830")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2008")])]

#text("Hi John Armstrong,")

#text("Thank you for the wiki reference listing the table in the section ‘equivalent systems’ on the Harmonic oscillator page with the explanation that “… analogous quantities in four harmonic oscillator systems in mechanics and electronics. If analogous parameters on the same line in the table are given numerically equal values, the behavior of the oscillators will be the same.”")

#text("I have seen a similar table from Erik Cheever [PhD bioengineering Swarthmore] ")#link("http://www.swarthmore.edu/NatSci/echeeve1/Ref/Analogs/ElectricalMechanicalAnalogs.html")[#text(" Analogous Electrical and Mechanical Systems")]#text(".")#linebreak()#text(" Cheever has only one electrical column and his two mechanical columns have different labels. The primary difference is that Cheever lists the capacitor energy as equivalent to mass energy and spring energy while inductor energy is equivalent to spring energy and mass energy from Force-current and Force-voltage columns, respectively.")

#text("1 – Where I am confused, is why physicists measure mechanical mass in eV which seems to be an electrical energy measure?")

#text("2 – I was surprised by the next section of your wiki reference ‘Applications’ stating “The problem of the simple harmonic oscillator occurs frequently in physics because of the form of its potential energy function: V(x)=(1/2)kx^2.”")#linebreak()#text(" This form is usually associated with kinetic energy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-22833")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2008")])]

#text("Doug: as the post discusses, mass and energy are equivalent, and can be changed into each other. Imagine a society where we measure furniture in inches, but measure room dimensions in fathoms. When someone realizes that “inches” and “fathoms” are both measuring the same quantity — length — we can use a conversion factor and just use one set of units, making interior decoration much easier.")

#text("Similarly, eV and grams are just two different ways to measure mass-energy. We want to just pick one and go with it, using a conversion factor to change the other measurements. Physicists have settled on eV as the unit because it’s appropriate to the scale of the experiments (you wouldn’t measure furniture in microns or miles) and because it’s appropriate to the sorts of experiments we’re doing. We actually ")#emph[#text("are")]#text(" pushing charged particles through voltage differences, which is how an eV is defined. But the whole thing could be worked out in grams or kilocalories if you wanted to.")

#text("As for your other question, be careful. The form associated with kinetic energy is ")#mi("K=\\frac{1}{2}mv^2")#text(". That is, it’s the same form, but with the mass as the constant and the ")#emph[#text("derivative")]#text(" of position as the variable. It’s sort of fascinating that the potential energy that gives Hooke’s law looks so much like the usual formula for kinetic energy, though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-23018")[#strong[#text("Sp3w")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2008")]

#text("[…] Einstein’s derivation of E=mc^2 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c053e31730b497d8214784b3c86199ae6b37222b8e691e9bd655f0d20ab7260d-588904bc5e771d60828be6c161ef722092bfe69ffb87f70f93f532d1dfcdfb43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Laurens Gunnarsen")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-23051")[#strong[#text("Laurens Gunnarsen")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2008")])]

#text("One rather mysterious aspect of this argument of Einstein’s is that it invokes the quantum theory of light to establish a relationship between variables that are already completely defined within a purely classical theory of mechanics (i.e., by special relativity.)")

#text("It is natural to ask whether this is really necessary — and in fact it is not. Indeed, it turns out that the purely classical explanation of the relation E = mc^2, though essentially different from Einstein’s original one, is also profoundly illuminating.")

#text("We must begin by spelling out the essential assumptions underpinning the classical theory, on which the explanation will rest. And, thanks to Minkowski, we can do this very elegantly by saying that special relativity ascribes to the set of all events the structure of a 4-dimensional affine space whose underlying vector space has an inner product of Lorentz signature.")

#text("The (connected component of the identity of the Lie) group preserving this special relativistic spacetime structure is called the Poincare group, and the building blocks of special-relativistic mechanics are just those physical systems whose phase spaces admit a transitive action of this group by symplectomorphisms.")

#text("A basic theorem (due essentially to Wigner) allows us to classify these physical systems. It turns out that their phase spaces are exactly the coadjoint orbits of the Poincare group, which may in turn be characterized by exactly two independent parameters: mass and spin.")

#text("So, within special-relativistic mechanics, this is how the “m” that appears in the formula E = mc^2 is defined; it’s a parameter that (partially) characterizes an elementary system — what might reasonably be called a “special-relativistic point particle.” But what about the “E” variable? How is that defined, anyway?")

#text("Well, as always in classical mechanics, energy is that function of the state of a system which determines, via Hamilton’s equations, the evolution of that state — its change with time. So this “E” that appears in the formula E = mc^2 cannot be defined until we have chosen a “time axis,” along which the system can evolve. And since, in special-relativistic mechanics, there are (infinitely) many such “time axes,” all on an a priori equal footing, we need to explain exactly what choice we’re making, and why.")

#text("The required explanation is easiest to give and to understand when the spin parameter is zero (although the general explanation isn’t all that much more complicated, really.) For then it happens that the isotropy subgroup of Poincare group determined by the state leaves a unique “time axis” invariant. The choice of “time axis” is, in effect, made for us by the state itself, in a geometrically natural way.")

#text("And it is precisely this particular “time axis” — the one aligned with the (instantaneous) motion of the particle as encoded in its state variables — that defines the “E” in the formula E = mc^2. Time translation (via the Poincare group action) of the state along this particular time axis corresponds precisely to Hamiltonian evolution of the state, with this particular energy function as the Hamiltonian.")

#text("Once this framework is in place, and all these definitions are clearly understood, the proof that E = mc^2 consists of a single line. And this is how things usually go in a fully developed, fully understood theory: all the work goes in to the formulation of the correct conceptual context, which then trivializes the key theorems. As Spivak points out in his CALCULUS ON MANIFOLDS, the proof of Stokes’s Theorem, in its most modern form, is also a single line — once you’ve introduced and understood the whole panoply of definitions needed to state it.")

#text("Is it worth the effort, though, to construct such a framework? I think we can now say rather confidently, after more than a century of working with special relativity theory, that the answer is “yes.” The rewards, both technical and conceptual, are vast, and the difficulties that remain for the learner to overcome are precisely those that really deserve deep, serious thought.")

#text("[By the way, a rather more detailed and explicit formulation of all these ideas is given in Shlomo Sternberg’s superb GROUP THEORY AND PHYSICS, and I would strongly recommend Sternberg’s textbooks, monographs, and review articles (as well as those of George Mackey) to any mathematician who wants better to understand the fundamental ideas of physics.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-23053")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2008")])]

#text("Hi John Armstrong,")

#text("1 – I think the source of my confusion about the units of mass lies within inconsistencies in the literature such as these wiki references:")

#text("a – Dr Tao’s reference ")#link("http://en.wikipedia.org/wiki/Mass_in_special_relativity")[#text(" Mass in special relativity")]#text(" in the paragraph before the section ‘Mass and the momentum 4-vector’ states “Energy is typically in units of electron volts (eV), momentum in units of eV/c, and mass in units of eV/c^2.”")

#text("b – ")#link("http://en.wikipedia.org/wiki/Neutrino")[#text(" ")]#text(" section ‘Types of neutrinos’ has a table ‘Neutrinos in the Standard Model of elementary particles’ listing mass variants as expected values in eV.")

#text("This should be mass in units of eV/c^2 not eV.")

#text("2 – Your comment on treating mass as a constant in kinetic energy may also have meaning in treating mass as a constant and c^2 as a maximum extrema in E=mc^2 when mass fissions into energy.")

#text("I will discuss this implication in my next comment for Dr Tao to which I hope he responds.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-23054")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2008")])]

#text("Hi Terence,")

#text("Note: 1b for 4 January, 2008 at 2:44 pm comment to John Armstrong should read ")#link("http://en.wikipedia.org/wiki/Neutrino")[#text(" Neutrino")]#text(" section ‘Types …")

#text("In your demonstration of the derivation of E=mc^2, you have the equation:")#linebreak()#text(" E’ = E + (1/2)mv^2 + O(v^3).")

#text("Consider:")#linebreak()#text(" a – Let O(v^3) = epsilon; as limit epsilon -> 0; then O(v^3) -> 0. This may represent the difference between the ideal yield and actual yield of mass fission into energy?")

#text("b – There should be a bonding energy of the mass that must be overcome in the situation of mass fission into energy that may be necessary to subtract from the potential energy to determine the resultant kinetic energy. Thus we may have the situation for energy:")#linebreak()#text(" E_kinetic = E_potential + E_bonding where E_bonding = minus E_kinetic?")

#text("If the E = mc^2 is this potential energy, then we may have:")#linebreak()#text(" (1/2)mv^2 = mc^2 – (1/2)mv^2 for")#linebreak()#text(" E_kinetic = E_potential – E_bonding or")#linebreak()#text(" E’ = E + (1/2)mv^2 when O(v^3) = 0?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00f2ccf4f168e12fc05df90c46e3cf1dd02a27265ee107c9a94d6ed5fb5df4f6-d7c875bbf1e6ac987352d12a0019aea0ebbd8fb7b6b6cb6ba5cb92c8ac9b320f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A theoretical blog « My Name Is Legion")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-24707")[#strong[#text("A theoretical blog « My Name Is Legion")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2008")])]

#text("[…] I’ll leave with one quick link. Terry Tao wrote up a very interesting blog post showing Einstein’s derivation of the famous equation E=mc^2. Check it […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4409b546aa8b5bfcdd0e5314bbb717486cf34a509ca0af33dcf4a828b2670e36-da7a4a9759f8a2b688f9329d822f7d2626cd64b7a4c430d427ffa1e34d7b13d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of santosh")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-27205")[#strong[#text("santosh")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2008")])]

#text("being a 9th class student, I could not understand ur description.But,I thank to ur explanation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2aa2d7362573c8a419e4679081df5ca9750195468b8dac3976725ca339dc6dc-c8e4af577ed1587f82b747fcd53e7caab178b2b5059363ab9eb11d9d1e1d0ae3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AMRYT DHAKAL")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-28558")[#strong[#text("AMRYT DHAKAL")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2008")])]

#text("Thanx for giving chance for students to read this but no one can understand it because of complexion derivation")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-29137")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2008")])]

#text("Hi Terence,")

#text("I may have stumbled onto a means of graphically illustrating the derivation of E=mc^2 from an energy economic perspective, using the ")#link("http://en.wikipedia.org/wiki/Gini_coefficient")[#text(" Gini coefficient")]#text(", a measure of statistical dispersion from economics?")

#text("If the upper left of the graphical representation in the wiki article is completed as a square, then these representations may exist:")#linebreak()#text(" – the entire square as total potential energy,")#linebreak()#text(" – the diagonal as the maximum relative velocity which would occur in orthogonal movement,")#linebreak()#text(" – the upper left triangle as kinetic energy,")#linebreak()#text(" – the segment labeled gini index as O(v^3) and")#linebreak()#text(" – the remaining portion of the lower right triangle as E’ or perhaps bonding energy?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-33262")[#strong[#text("my coffee bar » simple-sederhana, dan ya seperti itu…")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2008")]

#text("[…] (menghasilkan) persamaan itu, bukannya sesuatu yang mudah. Kalau kalian tidak percaya pergilah ke sini. :), dan rasakan betapa tidak nyamannya upaya memahami sesuatu yang (sesungguhnya) tidaklah […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jian")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-33548")[#strong[#text("jian")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2008")])]

#text("Thank you for taking time to have written this post. I found it more clear than those in other sources. I helps me to understand Einstein’s original paper too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9447142507ac763cb501a3f4e09f0f84fd42ff7c7671d9f6367bbee435cae802-08145e090831e6ad6774cf0c3a0e1c9e4cb8944670a48e7297b3c4fe2288b18c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of IanDClarkMScPhD(1969 1973)")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-34454")[#strong[#text("IanDClarkMScPhD(1969 1973)")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2008")])]

#text("Extraordinarily simple even for those of us whose major fields are pure mathematics, statistics, symbolic logic and economics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-34841")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2009")])]

#text("A minor typo: “it is moving in velocity -v in frame $latex[\\overline{F}]$, and hence $latex[F_v=\\overline{F_{-v}}]$” (one of the overlines shouldn’t be there). ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-36993")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2009")])]

#text("So is E = mc^2 not exactly true, but only up to order O(v^3)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-37017")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2009")])]

#text("Yes. In fact, for moving objects the exact formula for the energy is ")#mi("E = mc^2 / \\sqrt{1-v^2/c^2} = mc^2 + \\frac{1}{2} mv^2 + O( v^4 )")#text(", thus one can view the ")#mi("O(v^4)")#text(" term as a relativistic correction to the Newtonian formula ")#mi("\\frac{1}{2} mv^2")#text(" for the kinetic energy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-37024")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2009")])]

#text("shoudn’t it be v^2/c^2 in the denominator? ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7ac76cdfb278375bbd60f429fafc42b2e16f5566130f40f08e8d64d8aa8bae8-a413f9063321188702973f09780bf372b535cbfc1ce6fa61d41b8dd098e1fc88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anirudh Kumar Satsangi")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-38186")[#strong[#text("Anirudh Kumar Satsangi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2009")])]

#text("How did Einstein derive conversion factor c^2 in his very famous formula E=mc^2. Whether he did some empirical work for this or he put this constant or conversion factor intuitively? I also feel that this formula does not hold good at black holes where the speed of gravitational wave is much higher than the speed of light.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7ac76cdfb278375bbd60f429fafc42b2e16f5566130f40f08e8d64d8aa8bae8-a413f9063321188702973f09780bf372b535cbfc1ce6fa61d41b8dd098e1fc88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A.K.Satsangi")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-38655")[#strong[#text("A.K.Satsangi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2009")])]

#text("Based on E=mc^2, can it be said that mass is the ‘potential state’ of matter and energy is the ‘kinetic state’ of matter and just multiply mass with c^2 you will get huge amount of energy and divide energy by c^2 you get very small amount of mass OR some other factors/ mechanisms are essential for these conversions ?")

#text("Anirudh")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-38666")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2009")])]

#text("Dear Anirudh,")

#text("You can read about Einsteins’ motivation in his original paper, which is linked to at the top of the post.")

#text("All matter (and radiation, e.g. a “box of photons”) has both mass and energy simultaneously, and does not alternate between a “mass-state” or an “energy-state”, just as a yardstick is simultaneously three feet long and one yard long, rather than somehow having a “feet-state” where it has three feet but no yards, and a “yard-state” where it has one yard but no feet. The formula ")#mi("E=mc^2")#text(" describes an ")#emph[#text("equivalence")]#text(" of mass and energy, rather than a ")#emph[#text("convertibility")]#text(" between mass and energy.")

#text("Note though that the formula ")#mi("E=mc^2")#text(" is only valid for stationary objects. For moving objects, which have non-zero momentum ")#mi("p")#text(", the correct formula is ")#mi("E^2 - p^2 c^2 = m^2 c^4")#text(", thus a moving object would have more energy than just ")#mi("mc^2")#text(". One could call the excess energy ")#mi("E - mc^2")#text(" here the “kinetic” energy of the moving object, and distinguish it from the “rest” energy ")#mi("mc^2")#text(", but this is a somewhat artificial distinction; the total energy ")#mi("E")#text(" is a more physically relevant quantity than either of these two somewhat arbitrary components.")

#text("Einstein’s formula is still valid in the presence of strong gravitational fields, but it should be noted that the concepts of energy and momentum then depend on location as well as on the frame of the observer; in particular, the law of conservation of energy or momentum is now a local conservation law only, rather than a global one. So one cannot directly equate energy or momentum at, say, a location near a black hole, to a nominally equivalent amount of energy or momentum on Earth.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7ac76cdfb278375bbd60f429fafc42b2e16f5566130f40f08e8d64d8aa8bae8-a413f9063321188702973f09780bf372b535cbfc1ce6fa61d41b8dd098e1fc88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anirudh Kumar Satsangi")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-38675")[#strong[#text("Anirudh Kumar Satsangi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2009")])]

#text("How equivalence can be established without one getting converted into other ? How equivalence can be verified? If E=mc^2 is valid only for stationary objects then this formula has no application and can predict nothing since nothing is stationary in the universe.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of conformal")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-38846")[#strong[#text("conformal")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2009")])]

#text("Hi Terry,")#linebreak()#text(" The correct formula with momentum is puzzling. E.g., in ")#link("http://en.wikipedia.org/wiki/Klein-Gordon")[#text("http://en.wikipedia.org/wiki/Klein-Gordon")]#text(" it leads to a nonlocal (cumbersome) expression. However, it seems that after an expansion we get just a Schrodinger equation with convolution modulo identity instead of the laplacian. Would physicists agree?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-38869")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2009")])]

#text("Dear conformal,")

#text("It is true that if one splits up solutions to the Klein-Gordon equation into positive time-oscillating (")#mi("E = +\\sqrt{m^2c^4+p^2c^2}")#text(") and negative time-oscillating components (")#mi("E = -\\sqrt{m^2c^4+p^2c^2}")#text("), then the (local) second-order PDE becomes factorised into two decoupled first-order non-local PDE. But this non-locality is an artefact of the decomposition into positive and negative time-oscillating components, which is itself a non-local decopmosition; any physically measurable quantity of the equation (e.g. the stress-energy tensor) still evolves in a purely local fashion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of conformal")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-38889")[#strong[#text("conformal")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2009")])]

#text("Hi Terry,")#linebreak()#text(" If we can split up like this, then after applying absolute value we get a pseudofirst order equation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-38893")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2009")])]

#text("Well, absolute values don’t quite work, but one can certainly convert the scalar local second-order Klein-Gordon equation ")#mi("- u_{tt} + \\Delta u = u")#text(" to a complex non-local first-order equation by introducing the complex field")

#mi("v := u - i (1-\\Delta)^{-1/2} u_t")

#text("which solves the Schrodinger-like equation")

#mi("i v_t + (1-\\Delta)^{1/2} v = 0")#text(".")

#text("One can view this reduction as a factorisation of the second-order Klein-Gordon operator ")#mi("-\\partial_{tt} + \\Delta - 1")#text(" as the product ")#mi("(i \\partial_t + (1-\\Delta)^{1/2}) (i\\partial_t - (1-\\Delta)^{1/2})")#text(" of two first-order pseudodifferential operators.")

#text("This type of reduction is occasionally useful in the analysis of such PDE, since Fourier-analytic techniques don’t distinguish between differential and pseudo-differential operators very much. But this perspective does certainly obscure some of the physical space features of the equation, for instance locality and finite speed of propagation are not obvious at all from the first-order formulation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of conformal")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-38908")[#strong[#text("conformal")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2009")])]

#text("Hi Terry,")#linebreak()#text(" Is it because absolute value is a noncausal pseudodifferential operator that is doesn’t work? I mean ")#link("http://en.wikipedia.org/wiki/Anticausal")[#text("http://en.wikipedia.org/wiki/Anticausal")]#text(" , e.g., Anticausal behavior in the imaging of a moving object: The implications for high-speed photography, Phys. Rev. A 19, 2377 (1979).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-38916")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2009")])]

#text("Ah, I begin to understand what you meant by “absolute value” – I presume you are talking about transforming the temporal frequency variable (which I would call ")#mi("\\tau")#text(", but which I suppose physicists would call ")#mi("E/\\hbar")#text(" or ")#mi("k_0")#text(") to its absolute value ")#tao-math("\\left|\\tau\\right|", block: false)#text(". Mathematically, this is essentially the same (modulo some minor operations, such as conjugation) as taking a Hilbert transform in time and is, as you say, acausal, and also non-local. Applying it to a solution to the Klein-Gordon equation would indeed recover a solution to a first-order equation quite similar to the one in my previous comment, but it is not so surprising that a non-local transformation applied to a solution to a local PDE gives a solution to a non-local PDE.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of conformal")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-38932")[#strong[#text("conformal")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2009")])]

#text("Hi Terry,")#linebreak()#text(" Slightly offtopic: can we approximate the absolute value symbol with adding a dark dimension? I mean )(g=ng, where ng is the Neumann derivative of the solution of the system Lu=0, u=g in the upper half-plane, with L the laplacian.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-213004")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2013")])]

#text("hey conformal,, are u listening to the master???")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/054734e68d5e45373cb3b851c7c6c4437d3b05c6cf7a5cc25b4fc8b96da290a9-7e79fe69002fdaef8f111d4cb622d547e83fd22bff912d7e693b33a15a1f1e10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gravityandlevity")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-39043")[#strong[#text("gravityandlevity")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2009")])]

#text("I like this thought experiment a lot. Thanks for writing it up.")

#text("Have you seen the “Einstein’s box” derivation of E = mc^2? It uses a center of mass argument. I gave an explanation of it here: ")#link("http://gravityandlevity.wordpress.com/2009/05/16/the-equivalence-of-mass-and-energy-the-center-of-energy/")[#text("http://gravityandlevity.wordpress.com/2009/05/16/the-equivalence-of-mass-and-energy-the-center-of-energy/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3066b1cf2fced406d3cdae8c2aea5028f3ce97223765f4cbefe38b5132cddad-e47c06ae85032b307b3f7082b729dab918304b8ddf429824c1d3b63ee412ea0b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of s.chetan kumar")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-41685")[#strong[#text("s.chetan kumar")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2009")])]

#text("what do you understand by e=mc2 and how it is relatedt to theory of relativity?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca7f904ca6c9147a4acb90eb918a4acc7e18f1fea05c16d5890ae5e934e8f51a-347c5a54782ca86ac26e9a3965b0cd55fbb79bb27205e0aa7115c7127e6e918b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Keith Dow")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-41686")[#strong[#text("Keith Dow")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2009")])]

#text("Here is a simple approach which not 100% correct, but gives good insight.")

#text("Assume a black box in outer space with a long axis of length L. At one end of the")#linebreak()#text(" box is a flashlight attached to the box. The flashlight turns on for an instant and sends a burst of light to the other end of the box, where it is absorbed. The light")#linebreak()#text(" has energy E.")

#text("The momentum of the light is:")

#text("1. P = E/c")

#text("The light took time to travel to the other side:")

#text("2. T = L/c also c= L/T")

#text("When the light was emitted, because of conservation of momentum the box")#linebreak()#text(" gained momentum:")

#text("3. P = Mv")

#text("Since the box has no external forces on it, its center of mass can’t move. So the")#linebreak()#text(" movement of the box has to be equivalent to a “mass” of the light moving a")#linebreak()#text(" distance L. Now the box has mass M and moved a distance of v*T. So the center")#linebreak()#text(" of mass not moving means:")

#text("4. MvT = mL")

#text("From equations 1 and 3 we get:")

#text("5. Mv = E/c")

#text("Plug this into equation 4 and we get:")

#text("6. ET/c = mL")

#text("Or:")

#text("7. E = mcL/T")

#text("Plug in formula 2 we get:")

#text("8. E = mc*c")

#text("The history of E=Mc*c is complicated. Einstein wasn’t the first to publish a form of it. If you want more information read:")

#link("http://arxiv.org/pdf/0805.1400")[#text("http://arxiv.org/pdf/0805.1400")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d596d8e96326c7bcc6d16d8703871df5a501dbe1ab8ee2206e1d040cf4d5311c-dbe7776b50e03b500e85537d1ac0cb4e2e06acd75663b5263f4a7fe164de21ed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sunkhiroes")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-43614")[#strong[#text("sunkhiroes")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2010")])]

#text("a=dv/dt , dx=vdt , , dF=d(ma)dt , E=2 intergral[Fdx]from 0 to c where X1=v1=0 , x2=v2=c when one does integral the first part is E the second part one must define variable m which a type of energy !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d596d8e96326c7bcc6d16d8703871df5a501dbe1ab8ee2206e1d040cf4d5311c-dbe7776b50e03b500e85537d1ac0cb4e2e06acd75663b5263f4a7fe164de21ed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sunkhiroes")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-43616")[#strong[#text("sunkhiroes")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2010")])]

#text("Note from your page. Actually, as it turns out, Einstein’s analysis for bodies at rest only needs to understand changes of reference frame at infinitesimally low velocity, . But the mathematical go about is two part integral where m and a both can be constant and varible.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67ba63ea9ae3c7dbb49e83e35bf6e60d1feeb630f2a4f0247c2b6eeced5355ba-8dca20a54563e8c29c82df6eccf3d851382571444392317e915598a16c289b48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Smith")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-44144")[#strong[#text("James Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2010")])]

#text("Dear Prof Tao,")

#text("this might appear to be a really cheeky request but I’ll try my luck anyway. You have mentioned somewhere in the past that you use a LaTeX to WordPress converter. If this is the case here, could I possibly have the LaTeX source for this post? It would make an excellent basis for a project for my students. I can only offer to add exercises, footnotes and so on to the original source by way of thanks (if this doesn’t seem too presumptous – I thought some of your readers here might appreciate a document they could download. And I can’t think of another way of repaying you, to be honest).")

#text("Apologies if this is asking too much.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bad0606f45c5ef5f5cc7ee6abde3c24f9e2a21655230157e50b754a62264f2e0-347e455d0876d6c26f65628fb2e9ad93bf30ca5b218cbcd465d0225817ee7598.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Conrad J Countess")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-44193")[#strong[#text("Conrad J Countess")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2010")])]

#text("Hi all, this is very interesting and right up my alley")

#text("I have a Geometrical Interpretation of (E=mc^2), that not only shoes that energy and matter are equal, and related through conversion factor c^2, but actually shows how energy equals and turns to matter at a frequency wavelength of c^2. In short it shows that, analogous to “a line of 1 inch in horizontal direction, x a line of 1 in in vertical direction, to create a square inch”, c^2 is “c in the linear direction, x c in 90 degree angular direction, creating a balance of centripetal and centrifugal forces which create circular motion. Energy equals and turns to matter at c^2, because it acquires circular and or spherical motion, at the frequency wavelength of c^2, which is where “E=hf=mc^2”")

#text("here is a more complete description")

#link("http://wbabin.net/science/countess.pdf")[#text("Click to access countess.pdf")]

#text("What do you all think")

#text("Conrad J Countess")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/25bc3b401daf049e546820b42da252f07d40175f19702992abf0a125ae03af2c-38a6cb64ed3f684ac81bd022bddd07e9c22641a5880dfb62060bc7f569785c5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rashmi")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-46313")[#strong[#text("rashmi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2010")])]

#text("its wonderful to have a website like tis to learn about the work of einstein and others physicians")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0cfa84afa0c521ed96ba8fc87ab432596ad5d783ca2c6e85771f4f26e4dc8cfa-e310c91194fde3258c7831f6de9f83c9caa5b5075cfab6d9c64630726e954960.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of agm")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-46324")[#strong[#text("agm")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2010")])]

#text("Professor Tao, I’m working through this, and I have a question about your approach to equation 7, delta = 0. I’ve established it by applying the requirement that the interval is constant: (x^2-c^2 t^2) = (x’2-c^2 t’^2) in the notation of Einstein’s 1920 version. You get terms that of the form delta*v*x that require delta = 0, which then forces the terms of the form delta*gamma*v^2*x*t to zero without constraining gamma. It works, but it could be more elegant and doesn’t seem to follow the spirit of your exposition.")

#text("So how did you arrive at delta = 0?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-46361")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2010")])]

#text("This comes from the symmetry ")#mi("\\overline{F}_v = \\overline{F_{-v}}")#text(", or equivalently that ")#mi("L_v R = R L_{-v}")#text(", where ")#mi("R")#text(" is the reflection map ")#mi("R: (t,x) \\mapsto (t,-x)")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cb8313da5643a96be9e75b6995d859503272e9f59598c984d5ef7827693614d-c38e36c1b6199327860ffd12bd85652e540f03c5f6dc8f88f8d7eba0f6f8820e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anjan")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-46552")[#strong[#text("anjan")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2010")])]

#text("since every body have initial velocity 0")#linebreak()#text(" e=mc^2")#linebreak()#text(" here")#linebreak()#text(" e=total energy of substance")#linebreak()#text(" -E=K.E.+P.E.")#linebreak()#text(" orE=1/2mv^2+mgh")#linebreak()#text(" orE=m[1/2v^2+gh]but[2gh=v^2-u^2] or 2gh=v^2")#linebreak()#text(" orE=m[1/2{2gh}+gh]")#linebreak()#text(" orE=m[gh+gh}")#linebreak()#text(" orE=m2gh")#linebreak()#text(" from above")#linebreak()#text(" E=mv^2")#linebreak()#text(" where v^2=c^2")#linebreak()#text(" cant it be derived from mechanical phyics by above method.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/89c6cf63669bf3fa95287f52efcfe44bd932474febdd0edc0787a8788bd1d482-01ae2798743bba95a3fc269147adb61493aafb252e8de04d48021d6abdb55146.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of india")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-246576")[#strong[#text("india")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2013")])]

#text("You have assumed that the object of mass m attains a speed of light ‘c’ when dropped from earth and that too on Earth!!! If you succeed in doing so, you will win a Nobel price!!! Also Einsteins law violates law of energy conservation.")

#text("And you are deriving d same law using conservation principle!!!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f396bf049db9893ab87eaf950c4afa49492aec8c24e1f88673a282448133d439-e6226ea82b2c7e83b28bbac97b55410f2c439de63cac48ee90d2c982c9743669.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wang Xiuli")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-47471")[#strong[#text("Wang Xiuli")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2010")])]

#text("Einstein’s derivation of the formula is concise,simple and subtle.Yes Subtle is the lord.And many work’s derivations from Lorentz Tranformation and other physical law thereafter are very boring and lack physical intuitions.Physical law can be deducedt or induced by intuition into physics which could almont not be understanded approach of formal proof or mathematical proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f396bf049db9893ab87eaf950c4afa49492aec8c24e1f88673a282448133d439-e6226ea82b2c7e83b28bbac97b55410f2c439de63cac48ee90d2c982c9743669.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wang Xiuli")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-47472")[#strong[#text("Wang Xiuli")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2010")])]

#text("I think maybe the insight or intuition which are more concise ,obvious are more inportant in finding law or presenting law")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f011383ba85e7029d7ca003ca3ddf5ddcab68ed3d196ad28ca53bf3a4852ac89-631c08abf137f690f969b379c1880887f86084ed9e60d1cc028118c623a0f5ff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of eklavya")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-48198")[#strong[#text("eklavya")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2010")])]

#text("thank’s for the equation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2583d9e4ed47342ca3411bdfaa7ae052c9b6df5248e2086ebee1411446f92e2e-a0e88afe803dd1df186eb1ee518d60acd8c6c0ca95bac4a2da6bb2ea75b139d9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vishnu vijay")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-51187")[#strong[#text("vishnu vijay")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2011")])]

#text("Derivation of Einstein’s Energy –Mass equation")#linebreak()#text(" Actually Einstein gave energy mass equation but without any derivation ……nobody I think have exact derivation of this equation.")#linebreak()#text(" Here I tried to give the derivation ……. i don’t know it is correct or not ….. but scientist can apply their mind on this concept also.")#linebreak()#text(" As we all know that ,")#linebreak()#text(" Energy =work done")#linebreak()#text(" And work done can be represented as, W=f*s {f=force,s=distance covered } …………………………..(1)")#linebreak()#text(" Now,")#linebreak()#text(" F=m*a {m=mass,a=acceleration}}")#linebreak()#text(" Now,")#linebreak()#text(" F=m*(v\\t) {as a=velocity \\time} ……………………………………………(2)")#linebreak()#text(" From (1)and(2)")#linebreak()#text(" W=m*(v\\t)*s")#linebreak()#text(" W= m*v*v {here the both the velocities are same because the object is moving with some velocity and the time taken to cover that particular distance give us back the same velocity }")#linebreak()#text(" W=m*v2,")#linebreak()#text(" But we know that Einstein gave E=m*c2, {c=speed of light}")#linebreak()#text(" So here we will consider v=c as in the universe only light has the maximum speed and also if we want to gain maximum energy we have to keep the speed of light. So here,we will get …………")

#text("E=m*c2")

#text("By ,")#linebreak()#text(" Vishnu vijay,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-96004")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2011")])]

#text("u r absolutely wrong as per einstien formula.if u want full inquiry about it call at +91226265856")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd55cfc5ade26050aa91ba8c92d54815ff218742bdafe38e6f41b7da3c21442f-05934e655e26dcc5ea89bcf25d374f9eea5db75538a1f3276080ba2e15d1e1d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guiri")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-52205")[#strong[#text("Guiri")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2011")])]

#text("As light has now been slowed down to a speed of zero, and the velocity of light is also slower when passing through glass or water for example, does this mean that e sometimes equals mc2 only under certain conditions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-52217")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2011")])]

#text("c is only equal to the speed of light in vacuum. In other media it is certainly possible for the speed of light to be significantly less than c.")

#text("Actually, even if we lived in a universe in which there was no electromagnetism (and hence, no light), it would still be possible to define c; the “speed of light in vacuum” is a convenient definition, but hardly a necessary one. For instance, c is also the speed of gravitational propagation, and also shows up (albeit in a more complicated way) in the laws of physics for the other two fundamental forces, namely the strong and weak nuclear forces; alternatively, it is the unique constant which makes the laws of physics (locally) invariant with respect to Lorentz transformations.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dcf67163acabbc85ec4bdc69408d6e6da41ba42ef3b9c44b29e1bbf640e6de7a-826164bf683066da1d36ddcb030f1dc9f52b35c5ce2a8880340749958547ef6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ateixeira")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-72198")[#strong[#text("ateixeira")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2011")])]

#text("Also note this very important and beautiful article by Feigenbaum: ")#link("http://arxiv.org/abs/0806.1234")[#text("http://arxiv.org/abs/0806.1234")]#text(".")

#text("In it he shows that it is possible to derive with full generality Einstein-Poincaré-Lorentz relativity with just one postulate and making no mention of the speed of light.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/317f91243090b8c59c5e21a832c70e745da87fac50320244039750c851848d00-6ab9e4aa91b5981a8d8103792518389f3fd6045307438044c4a0b5860bed033c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gregory Pandev")]], [#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/comment-page-1/#comment-474515")[#strong[#text("Gregory Pandev")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2016")])]

#text("“c is also the speed of gravitational propagation” This isn’t true, the speed of propagation of Einstein’s ‘gravitational waves’ is arbitrary because it is coordinate dependent.")
]
]
]
