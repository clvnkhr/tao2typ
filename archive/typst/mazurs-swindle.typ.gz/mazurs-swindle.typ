// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/10/05/mazurs-swindle/
// Converted to Typst by tao2typ: "2026-10-14T07:37:11.513536+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mazur’s swindle", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mazur’s swindle")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 October 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/10/05/mazurs-swindle/")[#text("https://terrytao.wordpress.com/2009/10/05/mazurs-swindle/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{d}")#text(" be a natural number. A basic operation in the topology of oriented, connected, compact, ")#mi("{d}")#text("-dimensional manifolds (hereby referred to simply as ")#emph[#text("manifolds")]#text(" for short) is that of ")#link("http://en.wikipedia.org/wiki/Connected_sum")[#text("connected sum")]#text(": given two manifolds ")#mi("{M, N}")#text(", the connected sum ")#mi("{M \\# N}")#text(" is formed by removing a small ball from each manifold and then gluing the boundary together (in the orientation-preserving manner). This gives another oriented, connected, compact manifold, and the exact nature of the balls removed and their gluing is not relevant for topological purposes (any two such procedures give homeomorphic manifolds). It is easy to see that this operation is associative and commutative up to homeomorphism, thus ")#mi("{M \\# N \\cong N \\# M}")#text(" and ")#mi("{(M \\# N) \\# O \\cong M \\# (N \\# O)}")#text(", where we use ")#mi("{M \\cong N}")#text(" to denote the assertion that ")#mi("{M}")#text(" is homeomorphic to ")#mi("{N}")#text(".")

#text("(It is important that the orientation is preserved; if, for instance, ")#mi("{d=3}")#text(", and ")#mi("{M}")#text(" is a chiral 3-manifold which is ")#emph[#text("chiral")]#text(" (thus ")#mi("{M \\not \\cong -M}")#text(", where ")#mi("{-M}")#text(" is the orientation reversal of ")#mi("{M}")#text("), then the connect sum ")#mi("{M \\# M}")#text(" of ")#mi("{M}")#text(" with itself is also chiral (by the ")#link("http://en.wikipedia.org/wiki/Prime_decomposition_(3-manifold)")[#text("prime decomposition")]#text("; in fact one does not even need the irreducibility hypothesis for this claim), but ")#mi("{M \\# -M}")#text(" is not. A typical example of an irreducible chiral manifold is the complement of a ")#link("http://en.wikipedia.org/wiki/Trefoil_knot")[#text("trefoil knot")]#text(". Thanks to Danny Calegari for this example.)")

#text("The ")#mi("{d}")#text("-dimensional sphere ")#mi("{S^d}")#text(" is an identity (up to homeomorphism) of connect sum: ")#mi("{M \\# S^d \\cong M}")#text(" for any ")#mi("{M}")#text(". A basic result in the subject is that the sphere is itself irreducible:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Irreducibility of the sphere)")]#text(" ")#metadata(none) <tao-affb5e7b23650fa41232>#text(" If ")#mi("{S^d \\cong M \\# N}")#text(", then ")#mi("{M, N \\cong S^d}")#text(".")
]

#text("For ")#mi("{d=1}")#text(" (curves), this theorem is trivial because the only connected ")#mi("{1}")#text("-manifolds are homeomorphic to circles. For ")#mi("{d=2}")#text(" (surfaces), the theorem is also easy by considering the ")#link("http://en.wikipedia.org/wiki/Genus_(mathematics)")[#text("genus")]#text(" of ")#mi("{M, N, M \\# N}")#text(". For ")#mi("{d=3}")#text(" the result follows from the ")#link("http://en.wikipedia.org/wiki/Prime_decomposition_(3-manifold)")[#text("prime decomposition")]#text(". But for higher ")#mi("{d}")#text(", these ")#emph[#text("ad hoc")]#text(" methods no longer work. Nevertheless, there is an elegant proof of Theorem ")#link(<tao-affb5e7b23650fa41232>)[#text("1")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=117693")[#text("due to Mazur")]#text(", and known as ")#link("http://en.wikipedia.org/wiki/Eilenberg%E2%80%93Mazur_swindle")[#text("Mazur’s swindle")]#text(". The reason for this name should become clear when one sees the proof, which I reproduce below.")

#text("Suppose ")#mi("{M \\# N \\cong S^d}")#text(". Now consider the infinite connected sum")

#align(center)[#tao-fit-display[#mitex("(M \\# N) \\# (M \\# N) \\# (M \\# N) \\# \\ldots.")]]

#text("This is an infinite connected sum of spheres, and can thus be viewed as a half-open cylinder, which is topologically equivalent to a sphere with a small ball removed; alternatively, one can contract the boundary at infinity to a point to recover the sphere ")#mi("{S^d}")#text(". On the other hand, by using the associativity of connected sum (which will still work for the infinite connected sum, if one thinks about it carefully), the above manifold is also homeomorphic to")

#align(center)[#tao-fit-display[#mitex("M \\# (N \\# M) \\# (N \\# M) \\# \\ldots")]]

#text("which is the connected sum of ")#mi("{M}")#text(" with an infinite sequence of spheres, or equivalently ")#mi("{M}")#text(" with a small ball removed. Contracting the small balls to a point, we conclude that ")#mi("{M \\cong S^d}")#text(", and a similar argument gives ")#mi("{N \\cong S^d}")#text(".")

#text("A typical corollary of Theorem ")#link(<tao-affb5e7b23650fa41232>)[#text("1")]#text(" is a generalisation of the ")#link("http://en.wikipedia.org/wiki/Jordan_curve_theorem")[#text("Jordan curve theorem")]#text(": any ")#link("http://en.wikipedia.org/wiki/Locally_flat")[#text("locally flat")]#text(" embedded copy of ")#mi("{S^{d-1}}")#text(" in ")#mi("{S^d}")#text(" divides the sphere ")#mi("{S^d}")#text(" into two regions homeomorphic to balls ")#mi("{B^d}")#text(". (Some sort of regularity hypothesis, such as local flatness, is essential, thanks to the counterexample of the ")#link("http://en.wikipedia.org/wiki/Alexander%27s_horned_sphere")[#text("Alexander horned sphere")]#text(". If one assumes smoothness instead of local flatness, the problem is known as the ")#emph[#text("Schönflies problem")]#text(", and is apparently quite subtle, especially in the four-dimensional case ")#mi("{d=4}")#text(".)")

#text("One can ask whether there is a way to prove Theorem ")#link(<tao-affb5e7b23650fa41232>)[#text("1")]#text(" for general ")#mi("{d}")#text(" without recourse to the infinite sum swindle. I do not know the complete answer to this, but some evidence against this hope can be seen by noting that if one works in the smooth category instead of the topological category (i.e. working with smooth manifolds, and only equating manifolds that are diffeomorphic, and not merely homeomorphic), then the ")#link("http://en.wikipedia.org/wiki/Exotic_sphere")[#text("exotic spheres")]#text(" in five and higher dimensions provide a counterexample to the smooth version of Theorem ")#link(<tao-affb5e7b23650fa41232>)[#text("1")]#text(": it is possible to find two exotic spheres whose connected sum is diffeomorphic to the standard sphere. (Indeed, in five and higher dimensions, the exotic sphere structures on ")#mi("{S^d}")#text(" form a finite abelian group under connect sum, with the standard sphere being the identity element. The situation in four dimensions is much less well understood.) The problem with the swindle here is that the homeomorphism generated by the infinite number of applications of the associativity law is not smooth when one identifies the boundary with a point.")

#text("The basic idea of the swindle – grouping an alternating infinite sum in two different ways – also appears in a few other contexts. Most classically, it is used to show that the sum ")#mi("{1-1+1-1+\\ldots}")#text(" does not converge in any sense which is consistent with the infinite associative law, since this would then imply that ")#mi("{1=0}")#text("; indeed, one can view the swindle as a dichotomy between the infinite associative law and the presence of non-trivial cancellation. (In the topological manifold category, one has the former but not the latter, whereas in the case of ")#mi("{1-1+1-1+\\ldots}")#text(", one has the latter but not the former.) The ")#link("http://en.wikipedia.org/wiki/Alternating_series_test")[#text("alternating series test")]#text(" can also be viewed as a variant of the swindle.")

#text("Another variant of the swindle arises in the proof of the ")#link("http://en.wikipedia.org/wiki/Cantor%E2%80%93Bernstein%E2%80%93Schroeder_theorem")[#text("Cantor–Bernstein–Schröder theorem")]#text(". Suppose one has two sets ")#mi("{A, B}")#text(", together with injections from ")#mi("{A}")#text(" to ")#mi("{B}")#text(" and from ")#mi("{B}")#text(" to ")#mi("{A}")#text(". The first injection leads to an identification ")#mi("{B \\cong C \\uplus A}")#text(" for some set ")#mi("{C}")#text(", while the second injection leads to an identification ")#mi("{A \\cong D \\uplus B}")#text(". Iterating this leads to identifications")

#align(center)[#tao-fit-display[#mitex("A \\cong (D \\uplus C \\uplus D \\uplus \\ldots) \\uplus X")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("B \\cong (C \\uplus D \\uplus C \\uplus \\ldots) \\uplus X")]]

#text("for some additional set ")#mi("{X}")#text(". Using the identification ")#mi("{D \\uplus C \\cong C \\uplus D}")#text(" then yields an explicit bijection between ")#mi("{A}")#text(" and ")#mi("{B}")#text(".")

#text("(Thanks to Danny Calegari for telling me about the swindle, while we were both waiting to catch an airplane.)")

#text("[")#emph[#text("Update")]#text(", Oct 7: See the comments for several further examples of swindle-type arguments.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c8d284dd2ddbb40626c126309bc8e8f09a743a2912dbd9b7b72bfd1a29c8e63-fb26f3846087993e4a4209154a6ee4d8b3e21164c0e309de7f1e307e01f6612f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Morrison")]], [#link("https://terrytao.wordpress.com/2009/10/05/mazurs-swindle/#comment-41716")[#strong[#text("Scott Morrison")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2009")])]

#text("Another nice application is to show that non-trivial knots don’t have inverses under connect sum: you can’t untie a knot by tying another one!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a63fea626f9f808bb4e7a524e587227512a991036e137e2a5e5e51c95ffce89a-52b79f415efa7bee5455c4b4ed96f1143ed1385955a3f75c87e6318278ee8f19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jan")]], [#link("https://terrytao.wordpress.com/2009/10/05/mazurs-swindle/#comment-41717")[#strong[#text("Jan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2009")])]

#text("Nice explanation. Slight nitpick about the exotic spheres: if you happen to have an example of an exotic 4-sphere, you should write an article about it ;) Also, for the exotic 4-spheres it is not known whether they form a group under connected sums, only a monoid. Though of course, it could happen to be a group after all. ")#emph[#text("[Fair enough; I’ve amended the relevant comment to refer only to exotic spheres of dimension five or more. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/10/05/mazurs-swindle/#comment-41719")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2009")])]

#text("I wasn’t previously familiar with the term “chiral manifold”, but I assume there is a there a typo in the first sentence of the second paragraph (“A chiral manifold which is chiral”). ")#emph[#text("[Oops, the first “chiral” should have been “irreducible” – T.]")]#text(" Interesting post!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/390517060033239b9bf4fdf38be68020e8c3713bc59523c096d8f998664e0bbe-8a87dc77dc8f1db8ed403dfd640cfca3565b7b89c4f53fa7c5cbd2c0bed27bd8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2009/10/05/mazurs-swindle/#comment-41722")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2009")])]

#text("Another example: if ")#mi("H")#text(" is an infinite-dimensional separable Hilbert space, then ")#mi("GL(H)")#text(" is contractible. The proof I know uses the identifications ")#mi("H \\simeq H \\oplus H \\simeq H \\oplus \\ell_2(H)")#text(" and it’s those identifications that allow an infinite sum to be regrouped.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of toomuchcoffeeman")]], [#link("https://terrytao.wordpress.com/2009/10/05/mazurs-swindle/#comment-41728")[#strong[#text("toomuchcoffeeman")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2009")])]

#text("By GL(H) do you mean bounded linear invertible operators? in which case, contractibility would also follow from the fact that every invertible bounded operator is a product of two exponentials.")

#text("I dimly recall seeing something like what you mention in a textbook on K-theory, under the name of “Eilenberg swindle”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of toomuchcoffeeman")]], [#link("https://terrytao.wordpress.com/2009/10/05/mazurs-swindle/#comment-41730")[#strong[#text("toomuchcoffeeman")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2009")])]

#text("Ah, I see from a comment below that I’ve misremembered about the Eilenberg trick/swindle. Apologies")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/573d2542ab1f1dbc3aa25ef136ef711e6751ba35c1b4c15c36cc4b068a8c5dfd-811059f52c94f0492664ad3b7849f5bdce509d50393a8abe6b70a2eb60c38940.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy P.")]], [#link("https://terrytao.wordpress.com/2009/10/05/mazurs-swindle/#comment-41726")[#strong[#text("Andy P.")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2009")])]

#text("A very amusing “appreciation” of Mazur’s swindle is contained in the introduction to Stallings’s talk at Mazur’s birthday conference, which is available here : ")#link("http://math.berkeley.edu/~stall/mazur.html")[#text("http://math.berkeley.edu/~stall/mazur.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2009/10/05/mazurs-swindle/#comment-41727")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2009")])]

#text("This reminds me of “Eilenberg’s Trick” from ring theory: If ")#mi("P")#text(" is projective, there is a free module ")#mi("F")#text(" with ")#mi("P \\oplus F = F.")

#text("The idea is to fix a module ")#mi("Q")#text(" with ")#mi("P\\oplus Q=E")#text(" free, next set ")#mi("F=E\\oplus E\\oplus E\\oplus \\cdots")#text(", and rearrange infinite sums in the right way.")

#text("P.S. I hope I got the LaTeX code right. You might consider a “preview post” option.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a8e02c0f12d32b272bdc386cb1b4ad5d300575eaca52b69fa473451e2a3c7c25-1737a78443d7004c976a1bf61475c4e35240eed32cfd3cdc9bdb7d8c6890ac31.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter")]], [#link("https://terrytao.wordpress.com/2009/10/05/mazurs-swindle/#comment-41729")[#strong[#text("Peter")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2009")])]

#text("Small typo: in the Schroder-Bernstein example, the deductions of the identifications from the injections should be the other way round – i.e. the first injection gives ")#mi("B \\cong D + A")#text(", the second gives ")#mi("A \\cong B + C")#text(". ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/10/05/mazurs-swindle/#comment-41740")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2009")])]

#text("Pelczynski’s decomposition method is a nice trick in Banach spaces that makes use of a very similar idea. (No time to explain, but if you Google it you’ll see what I mean.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2009/10/05/mazurs-swindle/#comment-41743")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2009")])]

#link("http://www.springerlink.com/content/r3u0m800k5875312/fulltext.pdf?page=1")[#text("http://www.springerlink.com/content/r3u0m800k5875312/fulltext.pdf?page=1")]

#text("Generalizations of Pelczynski’s decomposition method for Banach")#linebreak()#text(" spaces containing a complemented copy of their squares")#linebreak()#text(" El´oi Medina Galego")#linebreak()#text(" Abstract. Suppose that X and Y are Banach spaces isomorphic to")#linebreak()#text(" complemented subspaces of each other. In 1996, W. T. Gowers solved the")#linebreak()#text(" Schroeder-Bernstein Problem for Banach spaces by showing that X is not")#linebreak()#text(" necessarily isomorphic to Y . However…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cbeda0756aa729997182d849d22bdf17dc0157cd03dc87e41a19538f6ca3035-16c7ec088d5190c3934a05407961c17cf589145d0c64748effbb81db2d509dab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of some guy on the street")]], [#link("https://terrytao.wordpress.com/2009/10/05/mazurs-swindle/#comment-41808")[#strong[#text("some guy on the street")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2009")])]

#text("I rather find the Banach-Tarski proof has a lot of swindle to it. When you think of running their oracle backwards, you might feel swindled again!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A demonstration of the non-commutativity of the English language « What’s new")]], [#link("https://terrytao.wordpress.com/2009/10/05/mazurs-swindle/#comment-42916")[#strong[#text("A demonstration of the non-commutativity of the English language « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2009")])]

#text("[…] the English language is non-commutative (or perhaps non-associative); a linguistic analogue of the swindle, if you […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An integration approach to the Toeplitz square peg problem | What's new")]], [#link("https://terrytao.wordpress.com/2009/10/05/mazurs-swindle/#comment-474547")[#strong[#text("An integration approach to the Toeplitz square peg problem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2016")])]

#text("[…] In contrast to Conjecture 1, which is known for polygonal paths, Conjecture 2 is still open even under the hypothesis of polygonal paths; the homological arguments alluded to previously now show that the number of inscribed squares in the periodic setting is even rather than odd, which is not enough to conclude the conjecture. (This flipping of parity from odd to even due to an infinite amount of oscillation is reminiscent of the “Eilenberg-Mazur swindle“, discussed in this previous post.) […]")
]
