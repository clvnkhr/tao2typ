// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/09/29/princeton-companion-to-mathematics/
// Converted to Typst by tao2typ: "2026-10-14T16:35:24.917113+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Princeton Companion to Mathematics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Princeton Companion to Mathematics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 September 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/09/29/princeton-companion-to-mathematics/")[#text("https://terrytao.wordpress.com/2008/09/29/princeton-companion-to-mathematics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#table(columns: 1, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#table(columns: 1, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#link("http://press.princeton.edu/titles/8350.html?utm_source=Network&utm_medium=Widget&utm_campaign=Title")[#text("The Princeton Companion")#linebreak()#text(" to Mathematics")]],
table.cell(colspan: 1, rowspan: 1)[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/press.princeton.edu/widgets/w8350.png")[Original image]]]],
table.cell(colspan: 1, rowspan: 1)[#link("http://press.princeton.edu/chapters/gowers/gowers_V_10.pdf?utm_source=Network&utm_medium=Widget&utm_campaign=Chapter")[#text("Sample Entry: Fermat’s")#linebreak()#text(" Last Theorem")]],
table.cell(colspan: 1, rowspan: 1)[#link("http://press.princeton.edu/video/gowers.mp3?utm_source=Network&utm_medium=Widget&utm_campaign=Podcast")[#text("Podcast interview with")#linebreak()#text(" editor Timothy Gowers")]]
)]
)

#linebreak()#text(" I was very pleased today to obtain a courtesy copy of the ")#link("http://press.princeton.edu/titles/8350.html")[#text("Princeton Companion to Mathematics")]#text(", which is now in print. I have discussed several of the individual articles (including my own) in this book ")#link("https://terrytao.wordpress.com/category/paper/companion/")[#text("elsewhere in this blog")]#text(", and ")#link("http://en.wikipedia.org/wiki/Timothy_Gowers")[#text("Tim Gowers")]#text(", the main editor of the Companion, has of course also ")#link("http://gowers.wordpress.com/category/princeton-companion-to-mathematics/")[#text("discussed it on his blog")]#text(". Browsing through it, though, I do get the sense that the whole is greater than the sum of its parts. One particularly striking example of this is the ")#link("http://press.princeton.edu/chapters/gowers/gowers_VIII_6.pdf")[#text("final section on advice to younger mathematicians")]#text(", with contributions by ")#link("http://en.wikipedia.org/wiki/Michael_Atiyah")[#text("Sir Michael Atiyah")]#text(", ")#link("http://en.wikipedia.org/wiki/B%C3%A9la_Bollob%C3%A1s")[#text("Béla Bollobás")]#text(", ")#link("http://en.wikipedia.org/wiki/Alain_Connes")[#text("Alain Connes")]#text(", ")#link("http://en.wikipedia.org/wiki/Dusa_McDuff")[#text("Dusa McDuff")]#text(", and ")#link("http://en.wikipedia.org/wiki/Peter_Sarnak")[#text("Peter Sarnak;")]#text(" the individual contributions are already very insightful (and almost linearly independent of each other!), but collectively they give a remarkably comprehensive and accurate portrait of how mathematical progress is made these days.")

#text("The other immediate impression I got from the book was the sheer weight (physical and otherwise – the book comprises 1034 pages) of mathematics that is out there, much of which I still only have a very partial grasp of at best (see also ")#link("http://www.quotationspage.com/quote/26184.html")[#text("Einstein’s famous quote")]#text(" on the subject). But the book also demonstrates that mathematics, while large, is at least connected (and reasonably bounded in diameter, modulo a small exceptional set). I myself certainly plan to use this book as a first reference the next time I need to look up some mathematical theory or concept that I haven’t had occasion to really use much before.")

#text("Given that I have been heavily involved in certain parts of this project, I will not review the book fully here – I am sure that will be done more objectively elsewhere – but comments on the book by other readers are more than welcome here.")

#text("[")#emph[#text("Update")]#text(", Sep 29: link to advice chapter added.]")

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/298f12b2d9036dc5cc3d25eac2898753c5a7d785053730b9c30aa262ba8cbda4-22f286e4671c4581bcf9afb2d5881d1d25499213125f4ec03c31248621fcc3ff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2008/09/29/princeton-companion-to-mathematics/#comment-32706")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2008")])]

#text("Dear Terry, it appears that the whole section on advice to younger mathematicians is available as part of the sample sections from the Princeton University Press webpage you mentionned, namely ")#link("http://press.princeton.edu/chapters/gowers/gowers_VIII_6.pdf")[#text("here")]#text(".")

#text("It is indeed very informative reading (e.g. learning that even Jean-Pierre Serre contemplated giving up during his PhD, stunning!). I hope in years to come the book will be translated into as many languages as possible to reach many undergraduates and even high school students…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/09/29/princeton-companion-to-mathematics/#comment-32707")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2008")])]

#text("Dear Tom: thanks for the link!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark")]], [#link("https://terrytao.wordpress.com/2008/09/29/princeton-companion-to-mathematics/#comment-32708")[#strong[#text("Mark")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2008")])]

#text("This looks like a marvellous book indeed. I doubt it is going to appeal to many students though (me for one) because the price is truly outrageous. Will there ever be a paperback version at an affordable price?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2440d6a669b266b1e0ded0cf262bd8572dc362e7aa000fb14c6782e94a6cbf7-545719ca34e8c1d255335ce8638b341f6cc5ba0edfe9ede6f49618c2d9c7de51.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Livro “The Princeton Companion to Mathematics” « problemas | teoremas")]], [#link("https://terrytao.wordpress.com/2008/09/29/princeton-companion-to-mathematics/#comment-32709")[#strong[#text("Livro “The Princeton Companion to Mathematics” « problemas | teoremas")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2008")])]

#text("[…] — Tags:Matemática, Notícia — Américo Tavares @ 9:32 am Tomei conhecimento neste post do What´s New do Prof. Terence Tao deste livro em fase de impressão. Nos links a seguir há uma […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0bb758487e7490a78b1a5f7044a0ca579192cc2c503a63d81abfa3082cfc4e08-23cb15945de2e31fe4b2de55b76675a8160f65071865386648cf146735b8608e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert")]], [#link("https://terrytao.wordpress.com/2008/09/29/princeton-companion-to-mathematics/#comment-32712")[#strong[#text("Robert")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2008")])]

#text("Having read the sample articles posted here and elsewhere, I am terribly excited to receive my copy! The comments to a young mathematician are encouraging, however I wonder if there is any advice for the person who walked away a little too quickly and now wishes to return to a professional pursuit of mathematics? Not everyone who wants to take it up is still in their late teens or early twenties. I know, for example, that Weierstrass held up independent study before getting into the game at a late age. I don’t pretend to that but I’m still very curious. I’ve kept up studies and readings of my own, but without the pressure of having to perform I worry about the “crispness” of what I’ve learned.")

#text("Simply going back for a master’s not really an option, as I kind of fell into that “dot com” trap and never completed my original undergraduate. (obviously I need to finish this first). I know I’m not the only one out there in this sort of position, so when I see the advice to the younger mathematician I am a little concerned about a perceived bias in when someone can contribute wonderful things to the community. I’ve read a lot of the advice available in the other pages on this site, which are illuminating, so forgive me if I’m overreacting to the bent they take :)")

#text("Kudos on the many clear and inspiring posts!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/29/princeton-companion-to-mathematics/#comment-32715")[#strong[#text("Stones Cry Out - If they keep silent… » Things Heard: e35v2")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2008")]

#text("[…] What i want for my birthday. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2008/09/29/princeton-companion-to-mathematics/#comment-32739")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2008")])]

#text("Hundreds of letters and essays have been written on the general theme “Advice to a young mathematician (scientist/engineer/writer/poet)”, but because there are so many of these essays, it is not common nowadays to find in any one of them advice that is genuinely new.")

#text("Dusa McDuff makes a point that is new (as far as I know) when she asserts: “As is increasingly understood, the real question is how any young person can build a satisfying personal life while still managing to be a creative mathematician. Once people start working on this in a serious way, we will have truly come a long way.”")

#text("Two key phrases in McDuff’s passage are “any young person” and “work on this in a serious way”. On a planet with (about) two billion young people, any serious endeavor to create technical jobs for (say) five percent of these young people has to contemplate creating on the order of one hundred million jobs. If we follow Dusa McDuff’s advice and work on this in a “serious way”, then these are the numbers we have to seriously contemplate.")

#text("Dusa McDuff’s essay deserves credit for starting us on this path.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/09/29/princeton-companion-to-mathematics/#comment-32750")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2008")])]

#text("I too found Dusa McDuff’s article very interesting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd4bfb06bd050a989093ed573685723febc2f7fbc97be93869ddd8bab3257fc9-7fe956b9f8b7dae1686b686a0691c02b9667dd8802e8de59c9cf328efac02d71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A semana nos arXivs… « Ars Physica")]], [#link("https://terrytao.wordpress.com/2008/09/29/princeton-companion-to-mathematics/#comment-32773")[#strong[#text("A semana nos arXivs… « Ars Physica")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2008")])]

#text("[…] Princeton Companion to Mathematics (estou coçando pra comprar o meu! :wink:) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e326116d80ffa4ea14276779575bfeb677b2d71c35871d414d747964da19f5d-7f2523a9ca8eb3e83b0a1051910f1fc37002fb64022cc83c61c32502c4668843.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathdummy")]], [#link("https://terrytao.wordpress.com/2008/09/29/princeton-companion-to-mathematics/#comment-32775")[#strong[#text("mathdummy")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2008")])]

#text("I hope my question is well formulated enough to barely make sense.")

#text("If gauge transformations are connections over some mathematical object -fiber bundles?-and connections-differential forms- are curvature,what do gauge transformations have to do with curvature.")

#text("The reason I ask this question is because gauge transformations have something to do with particle physics which is Quantum Merchanics which is defined on hilbert spaces which are flat-noncurved infinite dimensional spaces. So are spaces where gauge transformations can take place automatically curved?")

#text("Do gauge transformations “glue” together fibers which are infintesmially close.")

#text("d")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2008/09/29/princeton-companion-to-mathematics/#comment-32777")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2008")])]

#text("mathdummy: the Hilbert spaces like those in quantum mechanics are spaces of sections of these bundles. That is, they’re the analogue of function-spaces that come with the bundles. The curvature operator is like taking the Laplacian of a function. The geometry deforms the basic Laplacian into something similar, but dependent on the system in question. In QM, this is like how the operator on the one side of the Schrödinger equation is the Laplacian, deformed by adding the potential function.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2008/09/29/princeton-companion-to-mathematics/#comment-32778")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2008")])]

#text("I’ll attempt an engineering answer to mathdummy’s question (meaning, to adapt a “Tao phrase” from another lecture, my answer will try for a “natural feel rather than a magical one”).")

#text("There are at least two areas in physics where gauge-type invariances appear. The first area is field theory, where the gauge-invariant quantity is the action, and the gauge coordinates are the vector potentials. One practical reason that gauge invariance is useful in field theory is that (depending on the problem) we can choose a gauge that makes calculations shorter and easier. A deeper reason the gauge-invariance of field equations generates conservation laws that constrain the solutions; for example, the gauge invariance of quantum electrodynamics guarantees charge conservation. Deepest of all (and not well understood by me, or perhaps anyone) is that Nature seems to prefer gauge-invariant field theories (perhaps because they are renormalizable?).")

#text("Physicists have been struggling to understand these dynamical gauge invariances for at least the past 130 years (ever since Helmholtz proved celebrated Helmholtz Theorem), and there is still plenty of work to do.")

#text("More recently, gauge-type invariances have begun to appear ubiquitously in quantum information science. Here the gauge-invariant quantity is the time-dependent density matrix, and the gauge-coordinates are the probability densities that appear in Fokker-Planck equations (also called forward Kolmogorov equations). Here too at least three levels of mathematical understanding can be distinguished. From a practical point of view, we can exploit these informatic gauge invariances (in a more-or-less ")#emph[#text("ad hoc")]#text(" way at present) to more efficiently solve practical problems in quantum simulation. At a deeper level, we appreciate that informatic gauge invariances are responsible for enforcing informatic causality (the natural law that quantum correlations cannot transmit information outside the light code). And at the very deepest level, we recognize that Nature is ubiquitously fond of quantum informatic gauge invariances, just as she is ubiquitously fond of quantum dynamical gauge invariances … and the deep reason for this ubiquity (if there is a deep reason) is simply not understood at present.")

#text("The mathematical and physical depth of these gauge-theoretic questions is so great, and they are so far from being answered at present, that I won’t even hazard a guess at what the coming century of research might unveil, but instead will refer you to Feynman’s 1982 article ")#emph[#text("Simulating Physics With Computers")]#text(", whose concluding sentence is “If you want to make a simulation of nature, you’d better make it quantum mechanical, and by golly it’s a wonderful problem, because it doesn’t look so easy!”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/29/princeton-companion-to-mathematics/#comment-32999")[#strong[#text("Princeton Companion latest « Gowers’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2008")]

#text("[…] October: here are links to a few blogs posts that have discussed the Princeton Companion recently. Terence Tao had a few thoughts on receiving his copy. Brian Hayes did too. Fred Shapiro, editor of The Yale […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/29/princeton-companion-to-mathematics/#comment-33066")[#strong[#text("Not Even Wrong » Blog Archive » Princeton Companion to Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2008")]

#text("[…] The person most responsible for this is clearly the editor (and author of some of the pieces), Fields Medalist Timothy Gowers, who had help from many others, including fellow Fields Medalist Terry Tao. Gowers has a weblog, and he has written about the book in these entries (and there’s a podcast interviewing him on the book web-site at PUP). Terry Tao has a posting about the book here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/29/princeton-companion-to-mathematics/#comment-33293")[#strong[#text("Michael Nielsen » Biweekly links for 10/27/2008")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2008")]

#text("[…] Terry Tao: Princeton Companion to Mathematics […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/29/princeton-companion-to-mathematics/#comment-43032")[#strong[#text("If you want to go beyond the Princeton Companion to Mathematics then the Oxford User’s Guide to Mathematics could be an answer « Successful Researcher")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2010")]

#text("[…] reviewed, and often praised, all over the mathematical and scientific blogosphere, see e.g. here, here, here and here. Most of this praise is probably well deserved. But where should an interested […]")
]
