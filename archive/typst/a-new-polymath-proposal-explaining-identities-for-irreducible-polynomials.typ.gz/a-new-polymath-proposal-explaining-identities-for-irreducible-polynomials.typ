// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/12/28/a-new-polymath-proposal-explaining-identities-for-irreducible-polynomials/
// Converted to Typst by tao2typ: "2026-10-14T16:37:52.344849+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A new polymath proposal: explaining identities for irreducible polynomials", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A new polymath proposal: explaining identities for irreducible polynomials")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 December 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/12/28/a-new-polymath-proposal-explaining-identities-for-irreducible-polynomials/")[#text("https://terrytao.wordpress.com/2015/12/28/a-new-polymath-proposal-explaining-identities-for-irreducible-polynomials/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Over on the ")#link("http://polymathprojects.org/")[#text("polymath blog")]#text(", I’ve posted (on behalf of ")#link("http://www.math.rochester.edu/people/faculty/dthakur2/")[#text("Dinesh Thakur")]#text(") ")#link("http://polymathprojects.org/2015/12/28/polymath-proposal-explaining-identities-for-irreducible-polynomials/")[#text("a new polymath proposal")]#text(", which is to explain some numerically observed identities involving the irreducible polynomials ")#mi("P")#text(" in the polynomial ring ")#mi("{\\bf F}_2[t]")#text(" over the finite field of characteristic two, the simplest of which is")

#align(center)[#tao-fit-display[#mitex("\\sum_P \\frac{1}{1+P} = 0")]]

#text("(expanded in terms of Taylor series in ")#mi("u = 1/t")#text("). Comments on the problem should be placed in the polymath blog post; if there is enough interest, we can start a formal polymath project on it.")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2015/12/28/a-new-polymath-proposal-explaining-identities-for-irreducible-polynomials/#comment-464504")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2015")])]

#text("This looks like a very nice project! If it will be developed into a full project this will be (I think) the first time that we have more than one polymath project running in parallel and this is very welcomed! Right now ")#link("https://gilkalai.wordpress.com/2015/12/08/polymath-10-post-3-how-are-we-doing/")[#text("polymath10 devoted to the Erdos-Rado sunflower conjecture is running")]#text(" in my blog; Here is ")#link("https://gilkalai.wordpress.com/2015/11/03/polymath10-the-erdos-rado-delta-system-conjecture/")[#text("the link to the first post")]#text(". It is quite possible that yet another polymath project will take place over a third blog in the coming months.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2015/12/28/a-new-polymath-proposal-explaining-identities-for-irreducible-polynomials/#comment-464509")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2015")])]

#text("One more general polymath news: Here is the link of a mathoverflow question asking for polymath proposals ")#link("http://mathoverflow.net/questions/219638/proposals-for-polymath-projects")[#text("http://mathoverflow.net/questions/219638/proposals-for-polymath-projects")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/28/a-new-polymath-proposal-explaining-identities-for-irreducible-polynomials/#comment-464511")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2015")])]

#text("It seems to involve the Carlitz zeta function. Is there any introductory material on that topic?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/28/a-new-polymath-proposal-explaining-identities-for-irreducible-polynomials/#comment-464527")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2015")])]

#text("Also, Prof. Tao, is it a good idea to make a “reference request” on mathoverflow about Carlitz zeta functions so that we could have more reference?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2015/12/28/a-new-polymath-proposal-explaining-identities-for-irreducible-polynomials/#comment-464557")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2015")])]

#link("https://people.math.osu.edu/goss.3/three.pdf")[#text("Goss’s book")]#text(" is a good quick reference.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/28/a-new-polymath-proposal-explaining-identities-for-irreducible-polynomials/#comment-464568")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2015")])]

#text("so it seems done, right?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2015/12/28/a-new-polymath-proposal-explaining-identities-for-irreducible-polynomials/#comment-464516")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2015")])]

#text("At first I thought of Turán’s Sieve, but then I learned the irreducible polynomials can be counted by inclusion-exclusion: ")#link("http://math.stackexchange.com/questions/40811/number-of-monic-irreducible-polynomials-of-degree-p-over-finite-fields")[#text("http://math.stackexchange.com/questions/40811/number-of-monic-irreducible-polynomials-of-degree-p-over-finite-fields")]

#text("What else…? Plug in ")#mi("t = 0, 1, \\frac{1 \\pm \\sqrt{-3}}{2}")#text(" etc or something very close.")
]
