// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T10:29:05.385348+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The two-dimensional case of the Bourgain-Demeter-Guth proof of the Vinogradov main conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The two-dimensional case of the Bourgain-Demeter-Guth proof of the Vinogradov main conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 December 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/")[#text("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In this blog post, I would like to specialise the arguments of Bourgain, Demeter, and Guth from ")#link("https://terrytao.wordpress.com/2015/12/10/decoupling-and-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/")[#text("the previous post")]#text(" to the two-dimensional case of the Vinogradov main conjecture, namely")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Two-dimensional Vinogradov main conjecture)")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" One has")

#align(center)[#tao-fit-display[#tao-math("\\int_{[0,1]^2} \\left|\\sum_{j=0}^N e( j x + j^2 y)\\right|^6\\ dx dy \\ll N^{3+o(1)}", block: true)]]

#text("as ")#mi("{N \\rightarrow \\infty}")#text(".")
]

#text("This particular case of the main conjecture has a classical proof using some elementary number theory. Indeed, the left-hand side can be viewed as the number of solutions to the system of equations")

#tao-aligned(keep: true)[


#tao-math("j_1 + j_2 + j_3  & = k_1 + k_2 + k_3", block: true)



#tao-math("j_1^2 + j_2^2 + j_3^2  & = k_1^2 + k_2^2 + k_3^2", block: true)
]

#text("with ")#mi("{j_1,j_2,j_3,k_1,k_2,k_3 \\in \\{0,\\dots,N\\}}")#text(". These two equations can combine (using the algebraic identity ")#mi("{(a+b-c)^2 - (a^2+b^2-c^2) = 2 (a-c)(b-c)}")#text(" applied to ")#mi("{(a,b,c) = (j_1,j_2,k_3), (k_1,k_2,j_3)}")#text(") to imply the further equation")

#align(center)[#tao-fit-display[#mitex("(j_1 - k_3) (j_2 - k_3) = (k_1 - j_3) (k_2 - j_3)")]]

#text("which, when combined with the ")#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/")[#text("divisor bound")]#text(", shows that each ")#mi("{k_1,k_2,j_3}")#text(" is associated to ")#mi("{O(N^{o(1)})}")#text(" choices of ")#mi("{j_1,j_2,k_3}")#text(" excluding diagonal cases when two of the ")#mi("{j_1,j_2,j_3,k_1,k_2,k_3}")#text(" collide, and this easily yields Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(". However, the Bourgain-Demeter-Guth argument (which, in the two dimensional case, is essentially contained in ")#link("http://arxiv.org/abs/1403.5335")[#text("a previous paper of Bourgain and Demeter")]#text(") does not require the divisor bound, and extends for instance to the the more general case where ")#mi("{j}")#text(" ranges in a ")#mi("{1}")#text("-separated set of reals between ")#mi("{0}")#text(" to ")#mi("{N}")#text(".")

#text("In this special case, the Bourgain-Demeter argument simplifies, as the lower dimensional inductive hypothesis becomes a simple ")#mi("{L^2}")#text(" almost orthogonality claim, and the multilinear Kakeya estimate needed is also easy (collapsing to just Fubini’s theorem). Also one can work entirely in the context of the Vinogradov main conjecture, and not turn to the increased generality of decoupling inequalities (though this additional generality is convenient in higher dimensions). As such, I am presenting this special case as an introduction to the Bourgain-Demeter-Guth machinery.")

#text("We now give the specialisation of the Bourgain-Demeter argument to Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(". It will suffice to establish the bound")

#align(center)[#tao-fit-display[#tao-math("\\int_{[0,1]^2} \\left|\\sum_{j=0}^N e( j x + j^2 y)\\right|^p\\ dx dy \\ll N^{p/2+o(1)}", block: true)]]

#text("for all ")#mi("{4<p<6}")#text(", (where we keep ")#mi("{p}")#text(" fixed and send ")#mi("{N}")#text(" to infinity), as the ")#mi("{L^6}")#text(" bound then follows by combining the above bound with the trivial bound ")#tao-math("{\\left|\\sum_{j=0}^N e( j x + j^2 x^2)\\right| \\ll N}", block: false)#text(". Accordingly, for any ")#mi("{\\eta > 0}")#text(" and ")#mi("{4<p<6}")#text(", we let ")#mi("{P(p,\\eta)}")#text(" denote the claim that")

#align(center)[#tao-fit-display[#tao-math("\\int_{[0,1]^2} \\left|\\sum_{j=0}^N e( j x + j^2 y)\\right|^p\\ dx dy \\ll N^{p/2+\\eta+o(1)}", block: true)]]

#text("as ")#mi("{N \\rightarrow \\infty}")#text(". Clearly, for any fixed ")#mi("{p}")#text(", ")#mi("{P(p,\\eta)}")#text(" holds for some large ")#mi("{\\eta}")#text(", and it will suffice to establish")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" Let ")#mi("{4<p<6}")#text(", and let ")#mi("{\\eta>0}")#text(" be such that ")#mi("{P(p,\\eta)}")#text(" holds. Then there exists ")#mi("{0 < \\eta^{\\prime} < \\eta}")#text(" (with ")#mi("{\\eta^{\\prime}}")#text(" depending continuously on ")#mi("{\\eta}")#text(") such that ")#mi("{P(p,\\eta^{\\prime})}")#text(" holds.")
]

#text("Indeed, this proposition shows that for ")#mi("{4<p<6}")#text(", the infimum of the ")#mi("{\\eta}")#text(" for which ")#mi("{P(p,\\eta)}")#text(" holds is zero.")

#text("We prove the proposition below the fold, using a simplified form of the methods discussed in the previous blog post. To simplify the exposition we will be a bit cavalier with the uncertainty principle, for instance by essentially ignoring the tails of rapidly decreasing functions.")

#metadata(none) <tao-0f1f8456ac8218437241>

#text("Henceforth we fix ")#mi("{4 < p < 6}")#text(" and ")#mi("{\\eta > 0}")#text(", and assume that ")#mi("{P(p,\\eta)}")#text(" holds. For any interval ")#mi("{I}")#text(", let ")#mi("{f_I: {\\bf R}^2 \\rightarrow {\\bf C}}")#text(" denote the exponential sum")

#align(center)[#tao-fit-display[#mitex("f_I(x,y) := \\sum_{j \\in I \\cap {\\bf Z}} e(jx + j^2 y);")]]

#text("this function is periodic with respect to the lattice ")#mi("{{\\bf Z}^2}")#text(" and can thus also be thought of as a function on the torus ")#mi("{({\\bf R}/{\\bf Z})^2}")#text(". The hypothesis ")#mi("{P(p,\\eta)}")#text(", is then asserting that ")#metadata(none) <tao-8a6dcfb8b3e8e421c7ee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\int_{({\\bf R}/{\\bf Z})^2} \\left|f_{[0,N]}(x,y)\\right|^p\\ dx dy \\ll N^{p/2+\\eta+o(1)}.", block: true)]]

#text("A Galilean rescaling argument (noting that the Galilean transform used lies in ")#mi("{SL_2({\\bf Z})}")#text(") then shows that ")#metadata(none) <tao-a11e43a95d8ce33b525d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\int_{({\\bf R}/{\\bf Z})^2} \\left|f_I(x,y)\\right|^p\\ dx dy \\ll \\left|I\\right|^{p/2+\\eta+o(1)}", block: true)]]

#text("for any interval ")#mi("{I}")#text(" of length going to infinity as ")#mi("{N \\rightarrow \\infty}")#text(".")

#text("Our task is to show that ")#metadata(none) <tao-5e8c9902207afaeb7120>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\int_{({\\bf R}/{\\bf Z})^2} \\left|f_{[0,N]}(x,y)\\right|^p\\ dx dy \\ll N^{p/2+\\eta^{\\prime}+o(1)}", block: true)]]

#text("for some ")#mi("{0 < \\eta^{\\prime} < \\eta}")#text(". We first observe that it will suffice to show the apparently weaker ")#emph[#text("bilinear estimate")]#text(" ")#metadata(none) <tao-c9df9c3f2963b19b9b95>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\int_{({\\bf R}/{\\bf Z})^2} \\left|f_{I_1}(x,y)\\right|^{p/2} \\left|f_{I_2}(x,y)\\right|^{p/2}\\ dx dy \\ll N^{p/2+\\eta^{\\prime}+o(1)}", block: true)]]

#text("whenever ")#mi("{I, J}")#text(" are disjoint intervals in ")#mi("{[0,N]}")#text(" that are separated by ")#mi("{\\gg N}")#text(". Indeed, suppose the bilinear estimate ")#link(<tao-c9df9c3f2963b19b9b95>)[#text("(4)")]#text(" held for all ")#mi("{N}")#text(". If we define the quantity")

#align(center)[#tao-fit-display[#tao-math("A(N) := N^{-p/2} \\int_{({\\bf R}/{\\bf Z})^2} \\left|f_{[0,N]}(x,y)\\right|^p\\ dx dy", block: true)]]

#text("then by decomposing ")#mi("{[0,N]}")#text(" into ")#mi("{K}")#text(" intervals ")#mi("{I_1,\\dots,I_K}")#text(" of length about ")#mi("{N/K}")#text(", with ")#mi("{K}")#text(" a moderately large natural number, we can use the triangle inequality to bound")

#align(center)[#tao-fit-display[#tao-math("A(N)\\leq N^{-p/2} \\int_{({\\bf R}/{\\bf Z})^2} (\\sum_{1 \\leq i,j \\leq K} \\left|f_{I_i}(x,y)\\right|\\left|f_{I_j}(x,y)\\right|)^{p/2}\\ dx dy", block: true)]]

#text("By ")#link(<tao-c9df9c3f2963b19b9b95>)[#text("(4)")]#text(", the contribution of those ")#mi("{i,j}")#text(" with ")#tao-math("{\\left|i-j\\right| > 1}", block: false)#text(" is ")#mi("{O_K( N^{\\eta^{\\prime}+o(1)} )}")#text(". On the other hand, by Hölder’s inequality and affine rescaling, the contribution of the near-diagonal ")#mi("{i,j}")#text(" with ")#tao-math("{\\left|i-j\\right| \\leq 1}", block: false)#text(" is ")#mi("{O( K^{p/2-1} K K^{-p/2} A(N/K) )}")#text(". This gives the inequality")

#align(center)[#tao-fit-display[#mitex("A(N) \\ll A(N/K) + O_K( N^{\\eta^{\\prime} + o(1)} )")]]

#text("and by taking ")#mi("{K}")#text(" to be a sufficiently large constant (depending on ")#mi("{\\eta^{\\prime}}")#text(") and using a trivial bound ")#mi("{A(N) \\ll N^{O(1)}}")#text(" for small ")#mi("{N}")#text(", one can obtain the bound ")#mi("{A(N) \\ll N^{\\eta^{\\prime}+o(1)}}")#text(", which gives ")#link(<tao-5e8c9902207afaeb7120>)[#text("(3)")]#text(". Thus it suffices to show ")#link(<tao-c9df9c3f2963b19b9b95>)[#text("(4)")]#text(".")

#text("Let ")#mi("{I_1, I_2}")#text(" be as in ")#link(<tao-c9df9c3f2963b19b9b95>)[#text("(4)")]#text(". For any fixed ")#mi("{0 \\leq q \\leq s \\leq 1}")#text(" and ")#mi("{2 \\leq t \\leq 6}")#text(", we let ")#mi("{a_t(q,s)}")#text(" denote the best constant for which one has the bound")

#align(center)[#tao-fit-display[#tao-math("\\int_{({\\bf R}/{\\bf Z})^2} \\left|\\sum_{J_1} F_{t,s,J_1}(x,y)^2\\right|^{p/4} \\left|\\sum_{J_2} F_{t,s,J_2}(x,y)^2\\right|^{p/4}\\ dx dy", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll N^{p/2 + a_t(q,s) + o(1)}")]]

#text("as ")#mi("{N \\rightarrow \\infty}")#text(", where for ")#mi("{j=1,2}")#text(", ")#mi("{J_j}")#text(" ranges over a partition of ")#mi("{I_j}")#text(" into intervals of length ")#mi("{\\sim N^{1-q}}")#text(", and")

#align(center)[#tao-fit-display[#tao-math("F_{t,s,J}(x_0,y_0) := (\\frac{1}{\\left|B_{x_0,y_0,s}\\right|} \\int_{B_{x_0,y_0,s}} \\left|f_J(x,y)\\right|^t \\ dx dy)^{1/t}", block: true)]]

#text("is the local ")#mi("{L^t}")#text(" norm of ")#mi("{f_J}")#text(" near ")#mi("{(x_0,y_0)}")#text(", where ")#mi("{B_{x_0,y_0,s}}")#text(" is the rectangle")

#align(center)[#tao-fit-display[#mitex("B_{x_0,y_0,s} := [x_0-N^{-1+s}, x_0+N^{-1+s}] \\times [y_0-N^{-2+s}, y_0+N^{-2+s}].")]]

#text("(Actually, to make the argument below work rigorously we have to replace the indicator ")#mi("{1_{B_{x_0,y_0,s}}}")#text(" by a smoothed out variant ")#mi("{w_{B_{x_0,y_0,s}}}")#text(", but to simplify the exposition we shall simply ignore this technical issue.) The function ")#mi("{f_{I_j}}")#text(" has Fourier support in the rectangle ")#mi("{[0,N] \\times [0,N^2]}")#text(", and so by uncertainty principle heuristics one morally has (ignoring the technical issue alluded to above) a pointwise bound of the form")

#align(center)[#tao-fit-display[#tao-math("\\left|f_{I_j}(x,y)\\right| \\ll N^{2s} \\sum_{J_j} F_{t,s,J_j}(x,y)", block: true)]]

#text("which leads to the bound ")#metadata(none) <tao-dcc38d33829de4342815>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\int_{({\\bf R}/{\\bf Z})^2} \\left|f_{I_1}(x,y)\\right|^{p/2} \\left|f_{I_2}(x,y)\\right|^{p/2}\\ dx dy \\ll N^{p/2+a_t(q,s) + O(q+s)+o(1)}", block: true)]]

#text("for any ")#mi("{0 \\leq q \\leq s \\leq 1}")#text(". We will shortly establish the inequality ")#metadata(none) <tao-71848bc79dcd1d5edc80>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("a_2(u,u) \\leq (1-Wu) \\eta")]]

#text("for any ")#mi("{W>0}")#text(" and for any ")#mi("{u>0}")#text(" that is sufficiently small depending on ")#mi("{W}")#text("; inserting this bound into ")#link(<tao-dcc38d33829de4342815>)[#text("(5)")]#text(" for a suitably large ")#mi("{W}")#text(" and sufficiently small ")#mi("{u}")#text(" gives the desired bound ")#link(<tao-c9df9c3f2963b19b9b95>)[#text("(4)")]#text(".")

#text("It remains to establish ")#link(<tao-71848bc79dcd1d5edc80>)[#text("(6)")]#text(". This will follow from the following claims.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3")]#text(" ")#metadata(none) <tao-62c66a7a5dd70c314661>#text(" For sufficiently small ")#mi("{u}")#text(", we have")

#list(
[#text("(i) (Hölder) The functions ")#mi("{t \\mapsto a_t(u,u)}")#text(" and ")#mi("{t \\mapsto a_t(u,2u)}")#text(" are convex non-increasing in ")#mi("{1/t}")#text(".")],
[#text("(ii) (Rescaled induction hypothesis) We have ")#mi("{a_p(u,2u) \\leq (1-u) \\eta}")#text(".")],
[#text("(iii) (")#mi("{L^2}")#text(" decoupling) We have ")#mi("{a_2(u,2u) \\leq a_2(2u, 2u)}")#text(".")],
[#text("(iv) (Bilinear Kakeya) We have ")#mi("{a_{p/2}(u,u) \\leq a_{p/2}(u,2u)}")#text(".")]
)
]

#text("Let us now see why this proposition implies ")#link(<tao-71848bc79dcd1d5edc80>)[#text("(6)")]#text(" for all ")#mi("{W>0}")#text(". From the proposition we have")

#align(center)[#tao-fit-display[#mitex("a_2(u,u) \\leq a_{p/2}(u,u) \\leq a_{p/2}(u,2u) \\leq a_p(u,2u) \\leq (1-u) \\eta")]]

#text("which gives the claim for ")#mi("{W = 1}")#text(". To increase ")#mi("{W}")#text(", assume that ")#link(<tao-71848bc79dcd1d5edc80>)[#text("(6)")]#text(" already holds for some value of ")#mi("{W}")#text(", then by Proposition ")#link(<tao-62c66a7a5dd70c314661>)[#text("3")]#text("(iii) we have")

#align(center)[#tao-fit-display[#mitex("a_2(u,2u) \\leq a_2(2u,2u) \\leq (1-2Wu)\\eta")]]

#text("for sufficiently small ")#mi("{u}")#text(". On the other hand, from (ii) we have ")#mi("{a_p(u,2u) \\leq \\eta}")#text(". Interpolating using (i) and the hypothesis ")#mi("{4 < p < 6}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("a_{p/2}(u,2u) \\leq (1 - (1+\\delta)W u) \\eta")]]

#text("for sufficiently small ")#mi("{u}")#text(" and for some ")#mi("{\\delta>0}")#text(" depending only on ")#mi("{p}")#text(". Applying (iv) followed by (i) we conclude that ")#link(<tao-71848bc79dcd1d5edc80>)[#text("(6)")]#text(" holds with ")#mi("{W}")#text(" replaced by ")#mi("{(1+\\delta) W}")#text(". Iterating this, we can obtain ")#link(<tao-71848bc79dcd1d5edc80>)[#text("(6)")]#text(" for arbitrarily large ")#mi("{W}")#text(", as required.")

#text("The claim (i) is an easy application of Hölder’s inequality; we now turn to the more interesting claims (ii), (iii), (iv).")

#heading(level: 1)[#strong[#text(" — 1. Rescaled induction hypothesis — ")]]

#text("To prove (ii), we need to show")

#align(center)[#tao-fit-display[#tao-math("\\int_{({\\bf R}/{\\bf Z})^2} \\left|\\sum_{J_1} F_{p,2u,J_1}(x,y)^2\\right|^{p/4} \\left|\\sum_{J_2} F_{p,2u,J_2}(x,y)^2\\right|^{p/4}\\ dx dy", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll N^{p/2 + (1-u)\\eta + o(1)}")]]

#text("where ")#mi("{J_1}")#text(" ranges over a partition of ")#mi("{I_1}")#text(" into intervals of length ")#mi("{N^{1-u}}")#text(", and similarly for ")#mi("{J_2}")#text(". By Hölder’s inequality it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\int_{({\\bf R}/{\\bf Z})^2} \\left|\\sum_{J_j} F_{p,2u,J_j}(x,y)^2\\right|^{p/2}\\ dx dy \\ll N^{p/2 + (1-u)\\eta + o(1)}", block: true)]]

#text("for ")#mi("{j=1,2}")#text(". Since ")#mi("{4 < p < 6}")#text(", we can use Minkowski’s inequality to conclude that")

#align(center)[#tao-fit-display[#tao-math("(\\int_{({\\bf R}/{\\bf Z})^2} \\left|\\sum_{J_j} F_{p,2u,J_j}(x,y)^2\\right|^{p/2}\\ dx dy)^{2/p}", block: true)]]

#tao-aligned(keep: true)[


#tao-math(" & \\leq \\sum_{J_j} (\\int_{({\\bf R}/{\\bf Z})^2} \\left|F_{p,2u,J_j}(x,y)\\right|^p\\ dx dy)^{2/p}", block: true)



#tao-math(" & \\leq \\sum_{J_j} (\\int_{({\\bf R}/{\\bf Z})^2} \\left|f_{J_j}(x,y)\\right|^p\\ dx dy)^{2/p}", block: true)
]

#text("and the claim then follows from ")#link(<tao-a11e43a95d8ce33b525d>)[#text("(2)")]#text(" (since there are ")#mi("{O(N^u)}")#text(" intervals ")#mi("{J_j}")#text(" to sum over).")

#heading(level: 1)[#strong[#text(" — 2. ")#mi("{L^2}")#text(" decoupling — ")]]

#text("To prove (iii), it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\int_{({\\bf R}/{\\bf Z})^2} \\left|\\sum_{J_1} F_{2,2u,J_1}(x,y)^2\\right|^{p/4} \\left|\\sum_{J_2} F_{2,2u,J_2}(x,y)^2\\right|^{p/4}\\ dx dy", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\ll \\int_{({\\bf R}/{\\bf Z})^2} \\left|\\sum_{K_1} F_{2,2u,K_1}(x,y)^2\\right|^{p/4} \\left|\\sum_{K_2} F_{2,2u,K_2}(x,y)^2\\right|^{p/4}\\ dx dy", block: true)]]

#text("where the ")#mi("{J_j}")#text(" and ")#mi("{K_j}")#text(" are partitions of ")#mi("{I_j}")#text(" into intervals of length ")#mi("{\\sim N^{1-u}}")#text(" and ")#mi("{\\sim N^{1-2u}}")#text(" respectively. This will follow from the pointwise estimates")

#align(center)[#tao-fit-display[#mitex("F_{2,2u,J_j}(x_0,y_0)^2 \\ll \\sum_{K_j: K_j \\subset J_j} F_{2,2u,K_j}(x_0,y_0)^2")]]

#text("for any ")#mi("{j=1,2}")#text(", any ")#mi("{x_0,y_0}")#text(" and any interval ")#mi("{J_j}")#text(" of length ")#mi("{\\sim N^{1-u}}")#text(" (assuming the intervals are nicely nested in some dyadic fashion for simplicity). This expands as")

#align(center)[#tao-fit-display[#tao-math("\\int_{B} \\left|\\sum_{K_j \\subset J_j} f_{K_j}(x,y)\\right|^2\\ dx dy \\ll \\sum_{K_j \\subset J_j} \\int_{B} \\left|f_{K_j}(x,y)\\right|^2 \\ dx dy,", block: true)]]

#text("where ")#mi("{B}")#text(" is a rectangle of dimensions roughly ")#mi("{N^{-1+2u} \\times N^{-2+2u}}")#text(" with sides parallel to the coordinate axes. Without the localisation to ")#mi("{B}")#text(", this would be immediate from the orthogonality of the ")#mi("{f_{K_j}}")#text(". Morally, the localisation to ")#mi("{B}")#text(" introduces a Fourier uncertainty by a rectangle of dimensions roughly ")#mi("{N^{1-2u} \\times N^{2-2u}}")#text(". But the frequencies ")#mi("{\\{ (k,k^2): k \\in K_j \\}}")#text(" that the ")#mi("{f_{K_j}}")#text(" are Fourier supported in are essentially disjoint in ")#mi("{K_j}")#text(" even up to this uncertainty, so the global orthogonality of the ")#mi("{f_{K_j}}")#text(" should localise to the scale of the rectangle ")#mi("{B}")#text(". (This can be made rigorous using suitable smoothed approximants to the indicator of ")#mi("{1_B}")#text(", but we omit this technical detail here.)")

#heading(level: 1)[#strong[#text(" — 3. Bilinear Kakeya — ")]]

#text("To prove (iv), it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\int_{({\\bf R}/{\\bf Z})^2} \\left|\\sum_{J_1} F_{p/2,u,J_1}(x,y)^2\\right|^{p/4} \\left|\\sum_{J_2} F_{p/2,u,J_2}(x,y)^2\\right|^{p/4}\\ dx dy", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\ll N^{o(1)} \\int_{({\\bf R}/{\\bf Z})^2} \\left|\\sum_{J_1} F_{p/2,2u,J_1}(x,y)^2\\right|^{p/4} \\left|\\sum_{J_2} F_{p/2,2u,J_2}(x,y)^2\\right|^{p/4}\\ dx dy", block: true)]]

#text("as ")#mi("{N \\rightarrow \\infty}")#text(", where ")#mi("{J_j}")#text(" ranges over a partition of ")#mi("{I_j}")#text(" into intervals of length ")#mi("{\\sim N^{1-u}}")#text(". By averaging, it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\int_B \\left|\\sum_{J_1} F_{p/2,u,J_1}(x,y)^2\\right|^{p/4} \\left|\\sum_{J_2} F_{p/2,u,J_2}(x,y)^2\\right|^{p/4}\\ dx dy", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\ll N^{o(1)} \\int_B \\left|\\sum_{J_1} F_{p/2,2u,J_1}(x,y)^2\\right|^{p/4} \\left|\\sum_{J_2} F_{p/2,2u,J_2}(x,y)^2\\right|^{p/4}\\ dx dy", block: true)]]

#text("whenever ")#mi("{B}")#text(" is a rectangle of dimensions essentially ")#mi("{N^{-1+2u} \\times N^{-2+2u}}")#text(" with sides parallel to the axes. If we set ")#mi("{G_{J_j} := F_{p/2,u,J_j}^{p/2}}")#text(", then we morally have")

#align(center)[#tao-fit-display[#tao-math("F_{p/2,2u,J_j}(x,y)^{p/2} \\sim \\left|B\\right|^{-1} \\int_B G_{J_j}", block: true)]]

#text("on ")#mi("{B}")#text(", and so the estimate will follow if we can show that")

#align(center)[#tao-fit-display[#tao-math("\\left|B\\right|^{-1} \\int_B \\left|\\sum_{J_1} G_{J_1}^{4/p}\\right|^{p/4} \\left|\\sum_{J_2} G_{J_2}^{4/p}\\right|^{p/4}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\ll N^{o(1)} (\\sum_{J_1} (\\left|B\\right|^{-1} \\int_B G_{J_1})^{4/p})^{p/4} (\\sum_{J_2} (\\left|B\\right|^{-1} \\int_B G_{J_2})^{4/p})^{p/4}.", block: true)]]

#text("(As before, to be rigorous we need to replace the ")#mi("{1_B}")#text(" localisation with a smoother weight ")#mi("{w_B}")#text(", but we ignore this technicality here.) We now apply a logarithmic pigeonholing (conceding a factor of ")#mi("{N^{o(1)}}")#text(") to restrict ")#mi("{J_1}")#text(" to a set ")#mi("{{\\mathcal J}_1}")#text(" in which all the means ")#tao-math("{\\left|B\\right|^{-1} \\int_B G_{J_1}}", block: false)#text(" are comparable to each other, and similarly to restrict ")#mi("{J_2}")#text(" to a set ")#mi("{{\\mathcal J}_2}")#text(" where the means ")#tao-math("{\\left|B\\right|^{-1} \\int_B G_{J_2}}", block: false)#text(" are comparable to each other. We can then normalise so that ")#metadata(none) <tao-9dcb3ed7e0568da414ae>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\int_B G_{J} \\sim \\left|B\\right|", block: true)]]

#text("for all surviving ")#mi("{J}")#text(", so it now suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|B\\right|^{-1} \\int_B \\left|\\sum_{J_1 \\in {\\mathcal J}_1} G_{J_1}^{4/p}\\right|^{p/4} \\left|\\sum_{J_2 \\in {\\mathcal J}_2} G_{J_2}^{4/p}\\right|^{p/4}", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll (\\# {\\mathcal J}_1)^{p/4} (\\# {\\mathcal J}_2)^{p/4}.")]]

#text("Since ")#mi("{p>4}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{J_j} G_{J_j}^{4/p}\\right|^{p/4} \\leq (\\# {\\mathcal J}_j)^{p/4 - 1} \\sum_{J_j} G_{J_j}", block: true)]]

#text("for ")#mi("{j=1,2}")#text(", so it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|B\\right|^{-1} \\int_B (\\sum_{J_1 \\in {\\mathcal J}_1} G_{J_1}) (\\sum_{J_2 \\in {\\mathcal J}_2} G_{J_2})", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll (\\# {\\mathcal J}_1) (\\# {\\mathcal J}_2).")]]

#text("By the triangle inequality, it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\int_B G_{J_1} G_{J_2} \\ll \\left|B\\right|.", block: true)]]

#text("Recall that ")#mi("{B}")#text(" is a rectangle of dimensions about ")#mi("{N^{-1+2u} \\times N^{-2+2u}}")#text(". As each ")#mi("{J_j}")#text(" is an interval of length about ")#mi("{N^{1-u}}")#text(", we see from the uncertainty principle that the ")#tao-math("{\\left|f_{J_j}\\right|}", block: false)#text(" are essentially constant along parallelograms with a horizontal side of length ")#mi("{N^{-1+u}}")#text(" and a vertical height of ")#mi("{N^{-2+2u}}")#text(" that fit inside the rectangle ")#mi("{B}")#text(" in a certain orientation (depending on the location of ")#mi("{J_j}")#text("; the slanted side has vertical slope ")#mi("{O(N)}")#text("). Thus the functions ")#mi("{G_{J_j}}")#text(" also exhibit similar behaviour, and can be essentially written within ")#mi("{B}")#text(" as")

#align(center)[#tao-fit-display[#mitex("G_{J_j} \\sim \\sum_{P_j} c_{P_j} 1_{P_j}")]]

#text("for some non-negative coefficients ")#mi("{c_{P_j}}")#text(" and some parallelograms of horizontal side ")#mi("{N^{-1+u}}")#text(" and height ")#mi("{N^{-2+2u}}")#text(" in ")#mi("{B}")#text(". The estimate ")#link(<tao-9dcb3ed7e0568da414ae>)[#text("(7)")]#text(" then takes the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{P_j \\subset B} c_{P_j} \\ll N^{u}")]]

#text("so it would suffice (since ")#tao-math("{\\left|B\\right| \\sim N^{-3+4u}}", block: false)#text(") to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|P_1 \\cap P_2\\right| \\ll N^{-3+2u}", block: true)]]

#text("for any parallelograms ")#mi("{P_1, P_2}")#text(" associated to intervals from ")#mi("{{\\mathcal J}_1, {\\mathcal J}_2}")#text(" respectively. But the transversality of ")#mi("{I_1,I_2}")#text(" ensures that these parallelograms ")#mi("{P_1,P_2}")#text(" have vertical slopes that differ by ")#mi("{\\sim N}")#text(", and the claim follows from simple geometry (")#mi("{P_1 \\cap P_2}")#text(" behaves like a parallelogram of horizontal side ")#mi("{N^{-1+u}}")#text(" and height ")#mi("{N^{-2+u}}")#text(").")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (26)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463484")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2015")])]

#text("Possible typo: “to reduce to restrict” – 4 lines above (7).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463501")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2015")])]

#text("Just under the second display above (5) there is “to make the argument work below rigorously” which is not a good word order; “argument below work rigorously” would be better. In the statement of Proposition 3(i), “Holder” should probably be “Hölder”. The sentence immediately before heading “3. Bilinear Kakeya” about needind to replace 1_B to make things rigorous is not inside parentheses, although every other mention of it appears to be. A few lines above (7) there is “pigenholing”.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463516")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2015")])]

#text("Is the three-dimensional case still simpler than the general case ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463521")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2015")])]

#text("The iterative portion of the argument, in which all the various component estimates (lower dimensional decoupling, multilinear Kakeya, etc.) are put together to obtain the full dimensional decoupling, is a little simpler in 3D than it is in general; the Bourgain-Demeter-Guth paper spends some time on the 3D (and also 4D) cases of the iteration in order to motivate the general case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463528")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2015")])]

#text("Could you explain what you mean by “affine rescaling” after (4)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463549")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2015")])]

#text("The functions ")#mi("f_I(x,y)")#text(" are compositions of functions ")#mi("f_{[0,M]}(x,y)")#text(" with affine transformations, up to a harmless phase modulation. For instance, if ")#mi("I = [a,a+M]")#text(", then ")#mi("f_I(x,y) = e( a x + b^2 y) f_{[0,M]}(x+2by,y)")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of monsieurcactus")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463551")[#strong[#text("monsieurcactus")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2015")])]

#text("I am lost.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/887c077a1c72a53aa12ae4ab297ba4fda9489c344a6aa86f4cc39f2f03e99f52-e40359e769dbeb31d6f90fb861dd32ba9802d69ff97a043d236e2b3b237669a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wooley")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463583")[#strong[#text("wooley")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2015")])]

#text("Two displays below (4), it seems that decomposing ")#mi("[0,N]")#text(" into ")#mi("K")#text(" intervals requires some Holder argument before entering into the ")#mi("(p/2)")#text("-th power of each generating function. So is’nt there an extra factor ")#mi("K^{p/2-1}")#text(" (squared) here to carry through the argument? This is compensated by A(N/K) in the diagonal part of the argument, though only just, since we assume slightly worse than diagonal behaviour. For the non-diagonal part, one has to win this loss back later.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d9e338e0cd3c5854d68f121b5bf4dd9161377bdb81e3cdc27ffbef30ef3227b-78ebb2d5d5bd8641134d35ec8cda100165b35ec3350266a25bb780abe9cd2e13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463586")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2015")])]

#text("If ")#mi("I, J")#text(" intervals are separated by ")#mi("\\gg N")#text(" then how can they both fit in ")#mi("[0,N]")#text(" ??")

#text("Man, I am really fighting with the notation here. I am guessing ")#mi("\\sum_{(\\mathbb{R}/\\mathbb{Z})^2} \\approx \\int_{(\\mathbb{R}/\\mathbb{Z})^2}")#text(" in your definition of ")#mi("A(N)")#text(" after (4)")

#text("Your use of Hölder inequality may have to do with how noisy the function is. I failed to verify the exponent of ")#mi("N^{3 + o(1)}")#text(" on my computer. It oscillates to rapidly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463590")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2015")])]

#text("Thanks for the correction. I am using ")#link("https://en.wikipedia.org/wiki/Big_O_notation#History_.28Bachmann.E2.80.93Landau.2C_Hardy.2C_and_Vinogradov_notations.29")[#text("Vinogradov notation")]#text(" here (appropriately enough, given the subject matter); ")#mi("\\gg N")#text(" means “bounded below by ")#mi("cN")#text(" for some ")#mi("c>0")#text("”. Thus for instance ")#mi("I = [0,N/4]")#text(" and ")#mi("J = [3N/4,N]")#text(" would qualify.")

#text("It is ")#link("http://www.ams.org/mathscinet-getitem?mr=2661311")[#text("a result of Blomer and Bludern")]#text(" (refining a previous work of Rogovskaya) that the integral in Theorem 1 is in fact equal to")

#mi("\\displaystyle \\frac{18}{\\pi^2} N^3 \\log N + \\frac{3}{\\pi^2} (12 \\gamma - 6 \\frac{\\zeta^{\\prime}(2)}{\\zeta(2)} - 5 ) N^3 + O( N^{5/2} \\log N )")

#text("but there may well be some oscillation initially for small values of N (for instance, the integral is necessarily an integer). One can view this result as a more complicated variant of Dirichlet’s bound")

#mi("\\displaystyle \\sum_{n \\leq N} \\sum_{d|n} 1 = N \\log N + (2 \\gamma - 1) N + O( N^{1/2} )")

#text("for the ")#link("https://en.wikipedia.org/wiki/Divisor_summatory_function")[#text("divisor summatory function")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d9e338e0cd3c5854d68f121b5bf4dd9161377bdb81e3cdc27ffbef30ef3227b-78ebb2d5d5bd8641134d35ec8cda100165b35ec3350266a25bb780abe9cd2e13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463666")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2015")])]

#text("This Bourgain-Demeter-Guth integrand oscillates a bunch with respect to ")#mi("(x, y) \\in [0,1]^2")#text(" Here is how the Riemann sum varies with respect to the size of ")#mi("-\\log \\Delta t")#text(" The exact answer was hard to punch into the calculator. Perhaps it’s like 60000. Using numerical integration – literally adding up the value at many points – I got 71000 or so… Which is about the same size as ")#mi("20^3 \\log (20)")#text(" which is 48000")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a824148870d9a797be86b07c9497b6047349bb116a0c81166d266fd325e4fa44-38e92813325ddb36f3594ef4b8ed0253ed92035acbeadfd212974cf68e1b6fb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463631")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2015")])]

#text("I don’t see why proposition 2 implies that P(p, eta) is true for all eta > 0.")

#text("Maybe P(p, eta) is only true for eta > 1 .. that seems to be consistent with proposition 2.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463632")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2015")])]

#text("If P(p, eta) holds for all eta >1 (say) then it holds for eta =1 using its definition. Once we know it holds for eta=1 it must hold for some eta < 1.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-463686")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2015")])]

#text("Th 1 also follows from the Strichartz inequality of JB for the Schrodinger eq. on the circle. It is also shown in the JB paper that o(1) cannot be avoided in your Th 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a242b74cb4708e7075514c46060c610e813e12db4e2d331dfd17e36abe99cbb8-ff298c1e844de97996f439de03b87cc7301ffe06c2ddcea833f9637412a9c9c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edward Spencer")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-464268")[#strong[#text("Edward Spencer")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2015")])]

#text("Terence Tao,")

#text("When you have a god given gift, why don’t you use it to solve the problems of this world.")

#text("If the universe can be described mathematically and you being the most intelligent person to ever live on this planet then surely there must be a mathematical formula for peace.")

#text("You just need to find it. All the best.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-464924")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2016")])]

#text("Where does the ")#mi("K^{p/2 - 1}")#text(" come from in the expression ")#mi("O(K^{p/2 - 1}KK^{-p/2}A(N/K))")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-464926")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2016")])]

#text("Holder’s inequality on the second equation after (4) seems to give that ")#tao-math("(\\sum_{1 \\leq i, j \\leq K}\\left|f_{I_i}f_{I_j}\\right|)^{p/2} \\leq (K^{p/2 - 1})^{2}\\sum_{1 \\leq i, j \\leq K}\\left|f_{I_i}f_{I_j}\\right|^{p/2}", block: false)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-464952")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2016")])]

#text("You need to restrict first to the region ")#tao-math("\\left|i-j\\right| \\leq 1", block: false)#text(" in order to only lose ")#mi("O( K^{p/2-1} )")#text(" rather than ")#mi("O( (K^{p/2-1})^2 )")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-465871")[#strong[#text("Polymath10-post 4: Back to the drawing board? | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2016")]

#text("[…] Because of polymath10, I did not discuss over here other things. Let me mention two super major developments that I am sure you all know about. One is Laci Babai’s quasi-polynomial algorithm for Graph isomorphism. (This is a good time to mention that my wife’s mother’s maiden name is Babai.) You can read about it here (and the next three posts) and here. Another is the solution by Jean Bourgain, Ciprian Demeter, Larry Guth of Vinogradov’s main conjecture. You can read about it here and here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa1324c1c994de839ea47c1d3fc090678b0f30678ef9322eb0fb7c21d28a5761-0bc6d52660a40354927956fb97c9f4ccdb5632a4a81997c2618c656e6462fd96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zak")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-472371")[#strong[#text("Zak")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2016")])]

#text("I do not understand your claim following proposition 6. It seems like, as stated, there is no reason the infimum has to be 0. In a similar spirit, in equation 6, the fact that the smallness of a depends on W seems troublesome.")

#text("In the rescaled induction hypothesis section, the last equality should be an inequality. Also, all that is used is that p is at least 4, not that p is at most six.")

#text("Lastly, thank you for this post, very helpful!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-472372")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2016")])]

#text("Thanks for the correction. As regards Proposition 2, the point is that ")#mi("\\eta^{\\prime}")#text(" depends continuously on ")#mi("\\eta")#text(" (as can be seen from inspection of the argument) and so ")#mi("\\eta - \\eta^{\\prime}")#text(" is uniformly bounded away from zero whenever ")#mi("\\eta")#text(" ranges in a compact set. In particular, if ")#mi("\\eta")#text(" approaches a non-zero infimum then ")#mi("\\eta^{\\prime}")#text(" will dip below that infimum. (For similar reasons, the quantities ")#mi("W")#text(" and ")#mi("u")#text(" can also be chosen to depend continuously on ")#mi("\\eta")#text(" and so cannot degenerate to infinity or zero as ")#mi("\\eta")#text(" approaches any non-zero value.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa1324c1c994de839ea47c1d3fc090678b0f30678ef9322eb0fb7c21d28a5761-0bc6d52660a40354927956fb97c9f4ccdb5632a4a81997c2618c656e6462fd96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zak")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-472385")[#strong[#text("Zak")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2016")])]

#text("thanks for the clarification!")

#text("I have also a conceptual question. In the proof of bilinear Kakeya, the Fourier support is a power of N and is translated of order N. So on the domain side the modulation induced from the translation is rather fast and seems to take over, not allowing one to show that the original function is constant on the appropriate scale.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-472387")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2016")])]

#text("There was a typo: it is ")#tao-math("\\left|f_J\\right|", block: false)#text(" rather than ")#mi("f_J")#text(" that behaves like a constant at the indicated scale.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa1324c1c994de839ea47c1d3fc090678b0f30678ef9322eb0fb7c21d28a5761-0bc6d52660a40354927956fb97c9f4ccdb5632a4a81997c2618c656e6462fd96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zak")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-472834")[#strong[#text("Zak")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2016")])]

#text("Thanks again for your responses!")

#text("I was curious if there is a heuristic reason why one should choose the scales to be u and 2u (as in the third and fourth part of Proposition 3). Checking the arguments, I see that is a boundary case.")

#text("Also, in case it helps future readers, I believe one can take $\\eta’ =(p-4)/2 \\eta$.")

#emph[#text("[This appears to be the optimal scale for the “ball inflation” step based on the bilinear Kakeya estimate to work; this is the most nontrivial part of the argument, and seems to be the main engine powering the decoupling phenomenon. -T.]")]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa1324c1c994de839ea47c1d3fc090678b0f30678ef9322eb0fb7c21d28a5761-0bc6d52660a40354927956fb97c9f4ccdb5632a4a81997c2618c656e6462fd96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zak")]], [#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-473313")[#strong[#text("Zak")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2016")])]

#text("actually I believe there is a subtle relation between the limit of ball inflation and orthogonality estimates and the limitations of how small we can take eta as follows. let s be the solution to ")#mi("s/2 + s/p = 2/p")#text(", coming from interpolating (iii) and (iv). Then we need s to be strictly bigger than 1/2 which is the reciprocal of the ball inflation constant. Otherwise we cannot prove for all eta greater than zero. to check this took me several pages of computations, in other words it’s not obvious to me a priori")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/12/11/the-two-dimensional-case-of-the-bourgain-demeter-guth-proof-of-the-vinogradov-main-conjecture/#comment-557898")[#strong[#text("Fourier multipliers: examples on the torus – Zeros and Ones")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2020")]

#text("[…] a little bit over Cauchy–Schwartz for certain estimates on have interesting implications in counting number of solutions for a system of […]")
]
