// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/04/14/polymath16-now-launched-simplifying-the-lower-bound-argument-for-the-hadwiger-nelson-problem/
// Converted to Typst by tao2typ: "2026-10-14T16:38:20.375962+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath16 now launched: simplifying the lower bound argument for the Hadwiger-Nelson problem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath16 now launched: simplifying the lower bound argument for the Hadwiger-Nelson problem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 April 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/04/14/polymath16-now-launched-simplifying-the-lower-bound-argument-for-the-hadwiger-nelson-problem/")[#text("https://terrytao.wordpress.com/2018/04/14/polymath16-now-launched-simplifying-the-lower-bound-argument-for-the-hadwiger-nelson-problem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("Just a quick announcement that ")#link("https://math.osu.edu/people/mixon.23")[#text("Dustin Mixon")]#text(" and ")#link("https://en.wikipedia.org/wiki/Aubrey_de_Grey")[#text("Aubrey de Grey")]#text(" have ")#link("https://dustingmixon.wordpress.com/2018/04/14/polymath16-first-thread-simplifying-de-greys-graph/")[#text("just launched")]#text(" the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Hadwiger-Nelson_problem")[#text("Polymath16 project")]#text(" over at ")#link("https://dustingmixon.wordpress.com/")[#text("Dustin’s blog")]#text(". The main goal of this project is to simplify the recent ")#link("https://arxiv.org/abs/1804.02385")[#text("proof by Aubrey de Grey")]#text(" that the chromatic number of the unit distance graph of the plane is at least 5, thus making progress on the ")#link("https://en.wikipedia.org/wiki/Hadwiger%E2%80%93Nelson_problem")[#text("Hadwiger-Nelson problem.")]#text(" The current proof is computer assisted (in particular it requires one to control the possible 4-colorings of a certain graph with over a thousand vertices), but one of the aims of the project is to reduce the amount of computer assistance needed to verify the proof; already a number of such reductions have been found. See also ")#link("https://polymathprojects.org/2018/04/10/polymath-proposal-finding-simpler-unit-distance-graphs-of-chromatic-number-5")[#text("this blog post where the polymath project")]#text(" was proposed, as well as ")#link("http://michaelnielsen.org/polymath1/index.php?title=Hadwiger-Nelson_problem")[#text("the wiki page for the project")]#text(". Non-technical discussion of the project will continue at the ")#link("https://polymathprojects.org/2018/04/10/polymath-proposal-finding-simpler-unit-distance-graphs-of-chromatic-number-5")[#text("proposal blog post")]#text(".")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/14/polymath16-now-launched-simplifying-the-lower-bound-argument-for-the-hadwiger-nelson-problem/#comment-496251")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2018")])]

#text("Dear Terry,sir")#linebreak()#text(" May I ask you a little stupid question that you have any works related to Hadwiger-Nelson problem? Thank for your response.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/14/polymath16-now-launched-simplifying-the-lower-bound-argument-for-the-hadwiger-nelson-problem/#comment-496286")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2018")])]

#text("No, I don’t have anything published relating to this problem (I may have written about the tangentially related unit distance problem of Erdos in my book with Van Vu and in some other places, though). I think I played with this problem for a day or so many years ago (hoping to improve upon Falconer’s result in the measurable case) but didn’t get particularly far. I also assigned the problem of proving ")#mi("\\mathrm{CNP} \\geq 4")#text(" in an undergraduate problem solving class about eighteen years ago; I remember that the majority of students needed quite a few hints to discover the standard Moser spindle solution.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/421c1d09702cde925a0633de4ece70927f925ba23f59ce163101305acec8ff08-88817afe06097aa4f59473bd7da1f3fcf58d210d54f1bb5ac3ca9b23b7cfb9a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nazgand")]], [#link("https://terrytao.wordpress.com/2018/04/14/polymath16-now-launched-simplifying-the-lower-bound-argument-for-the-hadwiger-nelson-problem/#comment-496677")[#strong[#text("Nazgand")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2018")])]

#text("Let ")#mi("G_0")#text(" be a graph with chromatic number ")#mi("c_0")#text(" and vertexes ")#mi("v_a,v_b")#text(" such that ")#mi("v_a")#text(" and ")#mi("v_b")#text(" do not not the same color for any ")#mi("c_0")#text("-coloring of ")#mi("G_0")#text(". ")#mi("G_0")#text(" can then be used as a `virtual edge’ with distance ")#tao-math("d_0=\\left\\|{v_a-v_b}\\right\\|", block: false)#text(". Let the chromatic color of a virtual edge be defined as the chromatic color of the graph used to virtualize the edge.")

#text("Multiplicative property of virtual edges:")#linebreak()#text(" Let ")#mi("G_1")#text(" be a graph with chromatic number ")#mi("c_0")#text(" which virtualizes an edge length ")#mi("d_1")#text(". Then replacing all edges of ")#mi("G_0")#text(" with virtual edges of length ")#mi("d_1")#text(" produces a virtual edge of chromatic color ")#mi("c_0")#text(" with length ")#mi("d_0*d_1")#text(".")

#text("If a graph, ")#mi("G_2")#text(", with chromatic number ")#mi("c_2\\geq 1+c_0")#text(" is created using virtual edges with chromatic number ")#mi("c_0")#text(", then a graph, ")#mi("G_3")#text(", of chromatic number ")#mi("c_3")#text(" (s.t. ")#mi("c_2\\geq c_3\\geq 1+c_0")#text(") can be created by replacing the virtual edges with the graphs which virtualize the virtual edges.")

#text("More trivially, if a graph, ")#mi("G_4")#text(", with chromatic number ")#mi("c_4\\leq c_0")#text(" is created using virtual edges with chromatic number ")#mi("c_0")#text(", then replacing the virtual edges with the graphs which virtualize the virtual edges produces a graph with chromatic number ")#mi("c_0")#text(".")

#text("If virtual edges with chromatic number 4 are found, then they may be useful to make a graph of chromatic number 5 which uses fewer vertexes than the current smallest graph. In an extreme example, 5 vertices would be enough if each of the distances between pairs of vertices corresponds to a virtual edge with chromatic number 4.")
]
