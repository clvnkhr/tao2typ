// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/
// Converted to Typst by tao2typ: "2026-10-14T15:19:03.386664+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "When is correlation transitive?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("When is correlation transitive?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 June 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/")[#text("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Given two unit vectors ")#mi("{v,w}")#text(" in a real inner product space, one can define the ")#emph[#text("correlation")]#text(" between these vectors to be their inner product ")#mi("{\\langle v, w \\rangle}")#text(", or in more geometric terms, the cosine of the angle ")#mi("{\\angle(v,w)}")#text(" subtended by ")#mi("{v}")#text(" and ")#mi("{w}")#text(". By the Cauchy-Schwarz inequality, this is a quantity between ")#mi("{-1}")#text(" and ")#mi("{+1}")#text(", with the extreme positive correlation ")#mi("{+1}")#text(" occurring when ")#mi("{v,w}")#text(" are identical, the extreme negative correlation ")#mi("{-1}")#text(" occurring when ")#mi("{v,w}")#text(" are diametrically opposite, and the zero correlation ")#mi("{0}")#text(" occurring when ")#mi("{v,w}")#text(" are orthogonal. This notion is closely related to the notion of ")#link("http://en.wikipedia.org/wiki/Correlation_and_dependence")[#text("correlation between two non-constant square-integrable real-valued random variables")]#text(" ")#mi("{X,Y}")#text(", which is the same as the correlation between two unit vectors ")#mi("{v,w}")#text(" lying in the Hilbert space ")#mi("{L^2(\\Omega)}")#text(" of square-integrable random variables, with ")#mi("{v}")#text(" being the normalisation of ")#mi("{X}")#text(" defined by subtracting off the mean ")#mi("{\\mathbf{E} X}")#text(" and then dividing by the standard deviation of ")#mi("{X}")#text(", and similarly for ")#mi("{w}")#text(" and ")#mi("{Y}")#text(".")

#text("One can also define correlation for complex (Hermitian) inner product spaces by taking the real part ")#mi("{\\text{Re} \\langle , \\rangle}")#text(" of the complex inner product to recover a real inner product.")

#text("While reading the (highly recommended) recent popular maths book “")#link("http://www.jordanellenberg.com/")[#text("How not to be wrong")]#text("“, by my friend and co-author Jordan Ellenberg, I came across the (important) point that correlation is not necessarily transitive: if ")#mi("{X}")#text(" correlates with ")#mi("{Y}")#text(", and ")#mi("{Y}")#text(" correlates with ")#mi("{Z}")#text(", then this does not imply that ")#mi("{X}")#text(" correlates with ")#mi("{Z}")#text(". A simple geometric example is provided by the three unit vectors")

#align(center)[#tao-fit-display[#mitex("u := (1,0); v := (\\frac{1}{\\sqrt{2}}, \\frac{1}{\\sqrt{2}}); w := (0,1)")]]

#text("in the Euclidean plane ")#mi("{{\\bf R}^2}")#text(": ")#mi("{u}")#text(" and ")#mi("{v}")#text(" have a positive correlation of ")#mi("{\\frac{1}{\\sqrt{2}}}")#text(", as does ")#mi("{v}")#text(" and ")#mi("{w}")#text(", but ")#mi("{u}")#text(" and ")#mi("{w}")#text(" are not correlated with each other. Or: for a typical undergraduate course, it is generally true that good exam scores are correlated with a deep understanding of the course material, and memorising from flash cards are correlated with good exam scores, but this does not imply that memorising flash cards is correlated with deep understanding of the course material.")

#text("However, there are at least two situations in which some partial version of transitivity of correlation can be recovered. The first is in the “99%” regime in which the correlations are ")#emph[#text("very")]#text(" close to ")#mi("{1}")#text(": if ")#mi("{u,v,w}")#text(" are unit vectors such that ")#mi("{u}")#text(" is ")#emph[#text("very")]#text(" highly correlated with ")#mi("{v}")#text(", and ")#mi("{v}")#text(" is ")#emph[#text("very")]#text(" highly correlated with ")#mi("{w}")#text(", then this ")#emph[#text("does")]#text(" imply that ")#mi("{u}")#text(" is very highly correlated with ")#mi("{w}")#text(". Indeed, from the identity")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u-v \\right\\| = 2^{1/2} (1 - \\langle u,v\\rangle)^{1/2}", block: true)]]

#text("(and similarly for ")#mi("{v-w}")#text(" and ")#mi("{u-w}")#text(") and the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|u-w\\right\\| \\leq \\left\\|u-v\\right\\| + \\left\\|v-w\\right\\|,", block: true)]]

#text("we see that ")#metadata(none) <tao-e32dd9bb5ec7cb608d54>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("(1 - \\langle u,w \\rangle)^{1/2} \\leq (1 - \\langle u,v\\rangle)^{1/2} + (1 - \\langle v,w\\rangle)^{1/2}.")]]

#text("Thus, for instance, if ")#mi("{\\langle u, v \\rangle \\geq 1-\\varepsilon}")#text(" and ")#mi("{\\langle v,w \\rangle \\geq 1-\\varepsilon}")#text(", then ")#mi("{\\langle u,w \\rangle \\geq 1-4\\varepsilon}")#text(". This is of course closely related to (though slightly weaker than) the triangle inequality for angles:")

#align(center)[#tao-fit-display[#mitex("\\angle(u,w) \\leq \\angle(u,v) + \\angle(v,w).")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" (Thanks to Andrew Granville for conversations leading to this observation.) The inequality ")#link(<tao-e32dd9bb5ec7cb608d54>)[#text("(1)")]#text(" also holds for sub-unit vectors, i.e. vectors ")#mi("{u,v,w}")#text(" with ")#tao-math("{\\left\\|u\\right\\|, \\left\\|v\\right\\|, \\left\\|w\\right\\| \\leq 1}", block: false)#text(". This comes by extending ")#mi("{u,v,w}")#text(" in directions orthogonal to all three original vectors and to each other in order to make them unit vectors, enlarging the ambient Hilbert space ")#mi("{H}")#text(" if necessary. More concretely, one can apply ")#link(<tao-e32dd9bb5ec7cb608d54>)[#text("(1)")]#text(" to the unit vectors")

#align(center)[#tao-fit-display[#tao-math("(u, \\sqrt{1-\\left\\|u\\right\\|^2}, 0, 0), (v, 0, \\sqrt{1-\\left\\|v\\right\\|^2}, 0), (w, 0, 0, \\sqrt{1-\\left\\|w\\right\\|^2})", block: true)]]

#text("in ")#mi("{H \\times {\\bf R}^3}")#text(".")
]

#text("But even in the “")#mi("{1\\%}")#text("” regime in which correlations are very weak, there is still a version of transitivity of correlation, known as the ")#emph[#text("van der Corput lemma")]#text(", which basically asserts that if a unit vector ")#mi("{v}")#text(" is correlated with ")#emph[#text("many")]#text(" unit vectors ")#mi("{u_1,\\dots,u_n}")#text(", then many of the pairs ")#mi("{u_i,u_j}")#text(" will then be correlated with each other. Indeed, from the Cauchy-Schwarz inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle v, \\sum_{i=1}^n u_i \\rangle\\right|^2 \\leq \\left\\|v\\right\\|^2 \\left\\| \\sum_{i=1}^n u_i \\right\\|^2", block: true)]]

#text("we see that ")#metadata(none) <tao-fbb7b5bf4ca348eeeebf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("(\\sum_{i=1}^n \\langle v, u_i \\rangle)^2 \\leq \\sum_{1 \\leq i,j \\leq n} \\langle u_i, u_j \\rangle.")]]

#text("Thus, for instance, if ")#mi("{\\langle v, u_i \\rangle \\geq \\varepsilon}")#text(" for at least ")#mi("{\\varepsilon n}")#text(" values of ")#mi("{i=1,\\dots,n}")#text(", then (after removing those indices ")#mi("{i}")#text(" for which ")#mi("{\\langle v, u_i \\rangle < \\varepsilon}")#text(") ")#mi("{\\sum_{i,j} \\langle u_i, u_j \\rangle}")#text(" must be at least ")#mi("{\\varepsilon^4 n^2}")#text(", which implies that ")#mi("{\\langle u_i, u_j \\rangle \\geq \\varepsilon^4/2}")#text(" for at least ")#mi("{\\varepsilon^4 n^2/2}")#text(" pairs ")#mi("{(i,j)}")#text(". Or as another example: if a random variable ")#mi("{X}")#text(" exhibits at least ")#mi("{1\\%}")#text(" positive correlation with ")#mi("{n}")#text(" other random variables ")#mi("{Y_1,\\dots,Y_n}")#text(", then if ")#mi("{n > 10,000}")#text(", at least two distinct ")#mi("{Y_i,Y_j}")#text(" must have positive correlation with each other (although this argument does not tell you ")#emph[#text("which")]#text(" pair ")#mi("{Y_i,Y_j}")#text(" are so correlated). Thus one can view this inequality as a sort of `pigeonhole principle” for correlation.")

#text("A similar argument (multiplying each ")#mi("{u_i}")#text(" by an appropriate sign ")#mi("{\\pm 1}")#text(") shows the related van der Corput inequality ")#metadata(none) <tao-e54a5df6ff5bc3208e2c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("(\\sum_{i=1}^n \\left|\\langle v, u_i \\rangle\\right|)^2 \\leq \\sum_{1 \\leq i,j \\leq n} \\left|\\langle u_i, u_j \\rangle\\right|,", block: true)]]

#text("and this inequality is also true for complex inner product spaces. (Also, the ")#mi("{u_i}")#text(" do not need to be unit vectors for this inequality to hold.)")

#text("Geometrically, the picture is this: if ")#mi("{v}")#text(" positively correlates with all of the ")#mi("{u_1,\\dots,u_n}")#text(", then the ")#mi("{u_1,\\dots,u_n}")#text(" are all squashed into a somewhat narrow cone centred at ")#mi("{v}")#text(". The cone is still wide enough to allow a few pairs ")#mi("{u_i, u_j}")#text(" to be orthogonal (or even negatively correlated) with each other, but (when ")#mi("{n}")#text(" is large enough) it is not wide enough to allow ")#emph[#text("all")]#text(" of the ")#mi("{u_i,u_j}")#text(" to be so widely separated. Remarkably, the bound here does not depend on the dimension of the ambient inner product space; while increasing the number of dimensions should in principle add more “room” to the cone, this effect is counteracted by the fact that in high dimensions, almost all pairs of vectors are close to orthogonal, and the exceptional pairs that are even weakly correlated to each other become exponentially rare. (See ")#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/")[#text("this previous blog post")]#text(" for some related discussion; in particular, Lemma 2 from that post is closely related to the van der Corput inequality presented here.)")

#text("A particularly common special case of the van der Corput inequality arises when ")#mi("{v}")#text(" is a unit vector fixed by some unitary operator ")#mi("{T}")#text(", and the ")#mi("{u_i}")#text(" are shifts ")#mi("{u_i = T^i u}")#text(" of a single unit vector ")#mi("{u}")#text(". In this case, the inner products ")#mi("{\\langle v, u_i \\rangle}")#text(" are all equal, and we arrive at the useful van der Corput inequality ")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|\\langle v, u \\rangle\\right|^2 \\leq \\frac{1}{n^2} \\sum_{1 \\leq i,j \\leq n} |\\langle T^i u, T^j u \\rangle|.", block: true)]]

#text("(In fact, one can even remove the absolute values from the right-hand side, by using ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("(2)")]#text(" instead of ")#link(<tao-e54a5df6ff5bc3208e2c>)[#text("(4)")]#text(".) Thus, to show that ")#mi("{v}")#text(" has negligible correlation with ")#mi("{u}")#text(", it suffices to show that the shifts of ")#mi("{u}")#text(" have negligible correlation with each other.")

#text("Here is a basic application of the van der Corput inequality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Weyl equidistribution estimate)")]#text(" Let ")#mi("{P: {\\bf Z} \\rightarrow {\\bf R}/{\\bf Z}}")#text(" be a polynomial with at least one non-constant coefficient irrational. Then one has")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N e( P(n) ) = 0,")]]

#text("where ")#mi("{e(x) := e^{2\\pi i x}}")#text(".")
]

#text("Note that this assertion implies the more general assertion")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N e( kP(n) ) = 0")]]

#text("for any non-zero integer ")#mi("{k}")#text(" (simply by replacing ")#mi("{P}")#text(" by ")#mi("{kP}")#text("), which by the Weyl equidistribution criterion is equivalent to the sequence ")#mi("{P(1), P(2),\\dots}")#text(" being asymptotically equidistributed in ")#mi("{{\\bf R}/{\\bf Z}}")#text(".")

#emph[#text("Proof:")]#text(" We induct on the degree ")#mi("{d}")#text(" of the polynomial ")#mi("{P}")#text(", which must be at least one. If ")#mi("{d}")#text(" is equal to one, the claim is easily established from the geometric series formula, so suppose that ")#mi("{d>1}")#text(" and that the claim has already been proven for ")#mi("{d-1}")#text(". If the top coefficient ")#mi("{a_d}")#text(" of ")#mi("{P(n) = a_d n^d + \\dots + a_0}")#text(" is rational, say ")#mi("{a_d = \\frac{p}{q}}")#text(", then by partitioning the natural numbers into residue classes modulo ")#mi("{q}")#text(", we see that the claim follows from the induction hypothesis; so we may assume that the top coefficient ")#mi("{a_d}")#text(" is irrational.")

#text("In order to use the van der Corput inequality as stated above (i.e. in the formalism of inner product spaces) we will need a ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("non-principal ultrafilter")]#text(" ")#mi("{p}")#text(" (see e.g ")#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/")[#text("this previous blog post")]#text(" for basic theory of ultrafilters); we leave it as an exercise to the reader to figure out how to present the argument below without the use of ultrafilters (or similar devices, such as ")#link("http://en.wikipedia.org/wiki/Banach_limit")[#text("Banach limits")]#text("). The ultrafilter ")#mi("{p}")#text(" defines an inner product ")#mi("{\\langle, \\rangle_p}")#text(" on bounded complex sequences ")#mi("{z = (z_1,z_2,z_3,\\dots)}")#text(" by setting")

#align(center)[#tao-fit-display[#mitex("\\langle z, w \\rangle_p := \\text{st} \\lim_{N \\rightarrow p} \\frac{1}{N} \\sum_{n=1}^N z_n \\overline{w_n}.")]]

#text("Strictly speaking, this inner product is only positive semi-definite rather than positive definite, but one can quotient out by the null vectors to obtain a positive-definite inner product. To establish the claim, it will suffice to show that")

#align(center)[#tao-fit-display[#mitex("\\langle 1, e(P) \\rangle_p = 0")]]

#text("for every non-principal ultrafilter ")#mi("{p}")#text(".")

#text("Note that the space of bounded sequences (modulo null vectors) admits a shift ")#mi("{T}")#text(", defined by")

#align(center)[#tao-fit-display[#mitex("T (z_1,z_2,\\dots) := (z_2,z_3,\\dots).")]]

#text("This shift becomes unitary once we quotient out by null vectors, and the constant sequence ")#mi("{1}")#text(" is clearly a unit vector that is invariant with respect to the shift. So by the van der Corput inequality, we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle 1, e(P) \\rangle_p\\right| \\leq \\frac{1}{n^2} \\sum_{1 \\leq i,j \\leq n} \\left|\\langle T^i e(P), T^j e(P) \\rangle_p\\right|", block: true)]]

#text("for any ")#mi("{n \\geq 1}")#text(". But we may rewrite ")#mi("{\\langle T^i e(P), T^j e(P) \\rangle = \\langle 1, e(T^j P - T^i P) \\rangle_p}")#text(". Then observe that if ")#mi("{i \\neq j}")#text(", ")#mi("{T^j P - T^i P}")#text(" is a polynomial of degree ")#mi("{d-1}")#text(" whose ")#mi("{d-1}")#text(" coefficient is irrational, so by induction hypothesis we have ")#mi("{\\langle T^i e(P), T^j e(P) \\rangle_p = 0}")#text(" for ")#mi("{i \\neq j}")#text(". For ")#mi("{i=j}")#text(" we of course have ")#mi("{\\langle T^i e(P), T^j e(P) \\rangle_p = 1}")#text(", and so")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle 1, e(P) \\rangle_p\\right| \\leq \\frac{1}{n^2} \\times n", block: true)]]

#text("for any ")#mi("{n}")#text(". Letting ")#mi("{n \\rightarrow \\infty}")#text(", we obtain the claim. ")#mi("\\Box")

#heading(level: 1)[#text("Comments (29)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-363931")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2014")])]

#text("Single bars in 3 out of 5 displayed formulae preceding (1), perhaps?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-364362")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2014")])]

#text("The non-transitivity of correlation also comes up in representation theory, with characters (or approximate versions such as trace functions) as unit vectors; I’ve taken to interpret “X is correlated with Y” as meaning “X has something in common with Y”, which to me carries the right intuition.")

#text("It can be interpreted algebraically rigorously with the “common parts” being common irreducible subrepresentations.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-368849")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2014")])]

#text("Ah! And now that I have Jordan’s book, I see that this more or less exactly the interpretation he suggests!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc176a31a86ee3eec38b1b4ecb5091d0464812b5eb1df566420871273f898411-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Basil K")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-364628")[#strong[#text("Basil K")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2014")])]

#text("Recently I’ve come across the following property for an element a in some “tolerance space” (A,T) (a set A with a reflexive and symmetric relation T):")

#text("for all b, b’ in A, if (b T a) and (a T b’) then (b T b’) .")

#text("I was wondering what would make a reasonably “natural” example for such special elements a, which facilitate transitions in an otherwise not necessarily transitive setting, and I’ve been asking everyone I know about it – ")#link("https://math.stackexchange.com/questions/816155/have-you-seen-this-property-of-tolerance-relations-before")[#text("and even people I don’t know")]#text(".")

#text("I understand that the spirit of this post is analytic rather than algebraic (as my Math Stackexchange question is), but surely the cone intuition seems to be common to both, so I thought I’d share.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dfba4969350f243c15382c79ccb18b24115d30d887fd1a7aa11ef0c42fa8f23c-dcfa8f5aa3ce0ef1a805ede65b546068f339adeef8e3c473341d866bb6e6aad8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Shakan")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-365879")[#strong[#text("George Shakan")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2014")])]

#text("That is quite an elegant proof of Proposition 1!")

#text("I think I found a couple typos. Of a single unit vector ")#mi("T")#text(" should be of a single unit vector ")#mi("u")#text(". Also I in Proposition 1, probably the ")#mi("e(P(n))")#text(" should be ")#mi("e(kP(n))")#text(" for some positive integer parameter ")#mi("k")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf439e996e29d20cb552d68ffe9f964d8919f4f9773b9c41c886fb326a5a9695-66573747b7b50dc2532a1c1acd7e23c9482f9aeb4a00f437399c08ade2278ee3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aquazorcarson")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-366091")[#strong[#text("aquazorcarson")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2014")])]

#text("Thanks for making Van der Corput so well-motivated. Very enlightening read.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02154781aaf3c00f9858f32eadf9764dffc6bd2394f4e3abe56c62e3a7131917-733738ebb385423168b8583486276cde0dae975fcfec90b508f28699fd388843.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dzako")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-366148")[#strong[#text("dzako")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2014")])]

#text("I dont get the definition of the ultrafilter product $_p$. This is defined for complex sequences and $e(P)$ is clearly not a complex seq.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-366188")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2014")])]

#mi("e(P)")#text(" maps each natural number ")#mi("n")#text(" to the complex number ")#mi("e(P(n)) = e^{2\\pi i P(n)}")#text(", and is thus a complex sequence.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-373979")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2014")])]

#text("The paragraph after equation 1 seems to have several inaccuracies. First it was not assumed that all the pairs have nonnegative correlations. Then i wasnt able to follow the pigeonhole estimates for both examples. Maybe I am missing something.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-374270")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2014")])]

#text("Both arguments are valid even in the presence of some negative correlations. For instance, once one has ")#mi("\\sum_{1 \\leq i,j \\leq n} \\langle u_i,u_j\\rangle \\geq \\varepsilon^4 n^2")#text(", one must have ")#mi("\\langle u_i,u_j \\rangle \\geq \\varepsilon^4/2")#text(" for at least ")#mi("\\varepsilon^4 n^2/2")#text(" pairs ")#mi("(i,j)")#text(", for if this were not the case, one would have ")#mi("\\langle u_i, u_j \\rangle < \\varepsilon^4/2")#text(" for all but fewer than ")#mi("\\varepsilon^4 n^2/2")#text(" pairs ")#mi("(i,j)")#text(", and if one uses the trivial upper bound ")#mi("\\langle u_i,u_j\\rangle \\leq 1")#text(" for these exceptional pairs, one obtains a contradiction. Note that at no point in this argument is any non-negativity hypothesis on the ")#mi("\\langle u_i,u_j\\rangle")#text(" required. Similarly for the second argument.")

#text("At a more intuitive level, any negative correlation between one pair of ")#mi("u_i,u_j")#text(" will only cause the other inner products on the RHS of (1) to become even ")#emph[#text("more")]#text(" positive, if (1) is to hold (but the correlation of each pair maxes out at ")#mi("+1")#text(", so there has to be a lot of pairs that share in this positive correlation): making a pair of vectors at an obtuse angle will squeeze a lot of other angles to become more acute. So negative correlation is not actually an enemy here, and is in fact helpful in some ways. (For similar reasons, the pigeonhole principle is still mathematically valid – and even “stronger”, in some sense – if some pigeonholes are allowed to have a negative number of pigeons, despite the breakdown of the physical pigeon metaphor in this setting.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d28195df14800315168ea974f4adf888eace7d3a34fc83513af492698793a2c-e2ad3cdfa379c5dcf139408dc5d555ac7c236dfa87abd3799a789b51ef5d74f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kodlu")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-477426")[#strong[#text("Kodlu")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("I believe the $\\varepsilon^3$s should be $\\varepsilon^4$s in the above comment, as in the main text below equation (2).")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-374684")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2014")])]

#text("Thanks for your enlightening answer. That part is completely clear now. Now I am confused by the paragraph after equation (2). First if the inner product is standard Euclidean, then the set of vectors positively correlated with v is simply a half space, which is not so “narrow”. Also I don’t understand the explanation for why the equation is independent of dimension. Why does it help to know the weakly correlated pairs are exponentially rare as dimension goes up?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-374712")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2014")])]

#text("Here, one should think of “positively correlated” as meaning “correlation at least epsilon for some fixed epsilon independent of dimension”. Then all the vectors ")#mi("u_i")#text(" will be squashed into a cone of aperture about ")#mi("\\pi - 2 \\varepsilon")#text(", and the angular measure of this cone decays exponentially with the dimension. This reduces the number of opportunities for pairs of vectors in this cone to be orthogonal or to make obtuse angles with each other.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c978ae119cf264abfb14b750b424b42f3028b81c566ed2cfe784a4fb152dbcbb-93dc944583e279071c5ba85e6b16807d05f350aa9dca7f9189939d7f121289c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-377890")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2014")])]

#text("The triangle inequality seems to give slightly weaker bounds than a determinant based approach (for eg.")#linebreak()#text(" ")#link("http://math.stackexchange.com/questions/147374/correlations-between-3-random-variables")[#text("http://math.stackexchange.com/questions/147374/correlations-between-3-random-variables")]#text(") some people have used. For eg. if and are both 0.87, the triangle inequality gives > 0.48, but the determinant based approach gives > 0.5138. Is this alternate approach correct?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c978ae119cf264abfb14b750b424b42f3028b81c566ed2cfe784a4fb152dbcbb-93dc944583e279071c5ba85e6b16807d05f350aa9dca7f9189939d7f121289c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-377895")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2014")])]

#text("the second to last line wasnt posted fully by the comment engine. restating that line, given 3 variables 1,2,3 and pairwise correlations x, y, z, triangle inequality gives the minimum bound as 0.48, while determinant > 0 gives a bound around 0.51.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-378505")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2014")])]

#text("The triangle inequality for angles ")#mi("\\angle x,z \\leq \\angle x,y + \\angle y,z")#text(", which gives the same bound as the determinant approach (as one can verify numerically after using the identity ")#mi("\\angle u,v = \\text{arccos}\\langle u,v\\rangle")#text("), is slightly stronger than the bound coming from the triangle inequality for norms.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c978ae119cf264abfb14b750b424b42f3028b81c566ed2cfe784a4fb152dbcbb-93dc944583e279071c5ba85e6b16807d05f350aa9dca7f9189939d7f121289c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-379708")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2014")])]

#text("Thanks for clarifying this.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-384263")[#strong[#text("taking exponentials of stuff | marekgluza")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2014")]

#text("[…] was reding this: ")#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/")[#text("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/")]#text(" and I got this going for me which is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Elliott-Halberstam conjecture implies the Vinogradov least quadratic nonresidue conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-433752")[#strong[#text("The Elliott-Halberstam conjecture implies the Vinogradov least quadratic nonresidue conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2014")])]

#text("[…] of , this shows that correlates with for various small . By the Cauchy-Schwarz inequality (cf. this previous blog post), this implies that correlates with for some distinct . But this can be ruled out by using Type […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7dc292730de1835068c23603ee90dc44faea5e94e0a81f1c4edfab62f432b500-77276862574adc100352ca00b2e38c7216aa10f71cc5802bb0fc2a839038b654.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hammyhamster")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-445105")[#strong[#text("hammyhamster")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2014")])]

#text("Presumably there are implications for investment porfolios here. It’s well-known that adding a high-volatility (aka variance of return) stock to a portfolio can decrease the portfolio’s overall variance if the high-vol stock is negatively correlated to the others. But lack of transitivity presumably increases the challenge of doing this for large portfolios ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-456500")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2015")])]

#text("Sorry if I’m being silly, but I don’t understand the explanation below equation (2). For example. let ")#mi("n\\epsilon")#text(" be a positive integer and ")#mi("\\sum_{i=1}^n\\langle v,u_i\\rangle=n\\epsilon^2")#text(", that is, all the remaining ")#mi("n-n\\epsilon")#text(" terms be such that there is not correlation between them and ")#mi("v")#text(". In this case, what is stated in the paragraph below isn’t true. I think I’m missing something here, please help me out!")

#emph[#text("[Oops, there was a typo – the exponent 3 should have been a 4. Corrected now – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-457244")[#strong[#text("willis77 comments on “What does it mean for an algorithm to be fair?” | Offer Your")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2015")]

#text("[…] vs causation. In real data, correlation is mostly transitive (there are toy exceptions – ")#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlatio&#8230")[#text("https://terrytao.wordpress.com/2014/06/05/when-is-correlatio&#8230")]#text(";, but they are just that). This means that if you want to predict something, and that something is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-457247")[#strong[#text("willis77 comments on “What does it mean for an algorithm to be fair?” | Exploding Ads")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2015")]

#text("[…] vs causation. In real data, correlation is mostly transitive (there are toy exceptions – ")#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlatio&#8230")[#text("https://terrytao.wordpress.com/2014/06/05/when-is-correlatio&#8230")]#text(";, but they are just that). This means that if you want to predict something, and that something is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7312950ec39ef651614e69c6be19455c3d59cd45c4dd4d1dd401132cc9f01e76-517b3b9cf26d9323f3da9d9419386f00c50eb3235ff7b2e46e4f2ec92c2030f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Foucart")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-459910")[#strong[#text("Foucart")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2015")])]

#text("See Foucart (1991) Transitivité du produit scalaire. Rev. Stat. Appliquée, XXXIX (3), 57-68 and Foucart (1997) numerical analysis of a correlation matrix, Statistics, 29/4, pp. 347-361.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-460236")[#strong[#text("War and Picks - datdota.com")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2015")]

#text("[…] note for the mathematically inclined – correlation is not a proper metric and it is not transitive except in the regime of very high correlation. In practice, this means that patch 6.82 can be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-466675")[#strong[#text("Correlation between Probability theory and Vector Algebra – Arindam Ghosh")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2016")]

#text("[…] product/scalar product/projection product” of Vector Algebra while going through this article on “transitiveness of correlation” by Dr. Terrence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boosting the van der Corput inequality using the tensor power trick | What's new")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-622840")[#strong[#text("Boosting the van der Corput inequality using the tensor power trick | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("[…] this previous blog post I noted the following easy application of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b77cef6f068fb0ad775d7393482c356fac77229eb361d4321b699cc1d7c1992-a376c4210700fd0ff6102bf99677a197fd9fd9cda3032086feba1356c014e41f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lotharson")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-630932")[#strong[#text("lotharson")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2021")])]

#text("Hi Terence, I wish I could quote your blog post in a paper I am writing! ;-)")

#emph[#text("[This is fine; see the last paragraph of ")#link("https://terrytao.wordpress.com/about/")[#text("https://terrytao.wordpress.com/about/")]#text(" , as well as general guides on how to cite blog posts, e.g., at ")#link("https://blog.apastyle.org/apastyle/2016/04/how-to-cite-a-blog-post-in-apa-style.html")[#text("https://blog.apastyle.org/apastyle/2016/04/how-to-cite-a-blog-post-in-apa-style.html")]#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f6695bc082c324311ca9437805c889aa2d74ec6038333e5be039de9551caeae-68d28d2b349b1054c156dc10f824042b0776e23c3e86d7bd11325472feafe6e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of matott")]], [#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/#comment-638041")[#strong[#text("matott")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2021")])]

#text("can someone help me with a real world application (not being a mathematician):")#linebreak()#text(" I have two logistic regressions (a and b), both being derived of and validated in a database S. Regression a is also tested and validated in a second database T.")#linebreak()#text(" Can I now say that my second regression b is also valid in the second database T, since a and b are both valid in S.")#linebreak()#text(" Comparing S and T directly, they have the same demographics (plus o moins)")

#text("Sorry for intruding with a real life problem. I would really appreciate a helpin hand (brain ;-)")
]
