// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/12/17/multi-linear-multipliers-associated-to-simplexes-of-arbitrary-length/
// Converted to Typst by tao2typ: "2026-10-14T15:16:34.241420+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Multi-linear multipliers associated to simplexes of arbitrary length", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Multi-linear multipliers associated to simplexes of arbitrary length")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 December 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/12/17/multi-linear-multipliers-associated-to-simplexes-of-arbitrary-length/")[#text("https://terrytao.wordpress.com/2007/12/17/multi-linear-multipliers-associated-to-simplexes-of-arbitrary-length/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.cornell.edu/People/Faculty/muscalu.html")[#text("Camil Muscalu")]#text(", ")#link("http://www.math.ucla.edu/~thiele/")[#text("Christoph Thiele")]#text(" and I have just uploaded to the ")#link("http://arxiv.org/")[#text("arXiv")]#text(" our joint paper, “")#link("http://arxiv.org/abs/0712.2420")[#text("Multi-linear multipliers associated to simplexes of arbitrary length")]#text("“, submitted to ")#link("http://pjm.math.berkeley.edu/apde/about/journal/about.html")[#text("Analysis & PDE")]#text(". This paper grew out of our project from many years ago to attempt to prove the nonlinear (or “scattering”) version of ")#link("http://en.wikipedia.org/wiki/Convergence_of_Fourier_series")[#text("Carleson’s theorem")]#text(" on the almost everywhere convergence of Fourier series. This version is still open; our original approach was to handle the nonlinear Carleson operator by multilinear expansions in terms of the potential function V, but while the ")#link("http://front.math.ucdavis.edu/math.CA/0102084")[#text("first three terms of this expansion were well behaved")]#text(", the fourth term was ")#link("http://front.math.ucdavis.edu/math.CA/0108156")[#text("unfortunately divergent")]#text(", due to the unhelpful location of a certain minus sign. [This ")#link("http://arxiv.org/abs/math/0307008")[#text("survey by Michael Lacey")]#text(", as well as this ")#link("http://front.math.ucdavis.edu/math.CA/0205139")[#text("paper of ourselves")]#text(", covers some of these topics.]")

#text("However, what we did find out in this paper was that if we modified the nonlinear Carleson operator slightly, by replacing the underlying Schrödinger equation by a more general ")#link("http://www.ams.org/mathscinet-getitem?mr=450815")[#text("AKNS system")]#text(", then for “generic” choices of this system, the problem of the ill-placed minus sign goes away, and each term in the multilinear series is, in fact, convergent (though we did not yet verify that the series actually converged, though in view of the earlier work ")#link("http://www.ams.org/mathscinet-getitem?mr=1809117")[#text("of Christ and Kiselev")]#text(" on this topic, this seems likely). The verification of this convergence (at least with regard to the scattering data, rather than the more difficult analysis of the eigenfunctions) is the main result of our current paper. It builds upon ")#link("http://front.math.ucdavis.edu/math.CA/0102084")[#text("our earlier estimates")]#text(" of the bilinear term in the expansion (which we dubbed the “biest”, as a multilingual pun). The main new idea in our earlier paper was to decompose the relevant region of frequency space ")#mi("\\{ (\\xi_1,\\xi_2,\\xi_3) \\in {\\Bbb R}^3: \\xi_1 < \\xi_2 < \\xi_3 \\}")#text(" into more tractable regions, a typical one being the region in which ")#mi("\\xi_2")#text(" was much closer to ")#mi("\\xi_1")#text(" than to ")#mi("\\xi_3")#text(". The contribution of each region can then be “parafactored” into a “paracomposition” of simpler operators, such as the bilinear Hilbert transform, which can be treated by standard time-frequency analysis methods. (Much as a paraproduct is a frequency-restricted version of a product, the paracompositions that arise here are frequency-restricted versions of composition.)")

#text("A similar analysis happens to work for the multilinear operators associated to the frequency region ")#mi("S := \\{ (\\xi_1,\\ldots,\\xi_n): \\xi_1 < \\ldots < \\xi_n \\}")#text(", but the combinatorics are more complicated; each of the component frequency regions has to be indexed by a tree (in a manner reminiscent of the well-separated pairs decomposition), and a certain key “weak Bessel inequality” becomes considerably more delicate. Our ultimate conclusion is that the multilinear operator")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("T(V_1,\\ldots,V_n) := \\int_{(\\xi_1,\\ldots,\\xi_n) \\in S} \\hat V_1(\\xi_1) \\ldots \\hat V_n(\\xi_n) e^{2i (\\xi_1+\\ldots+\\xi_n) x}\\ d\\xi_1 \\ldots d\\xi_n")]]

#text("(which generalises the bilinear Hilbert transform and the biest) obeys ")#link("http://en.wikipedia.org/wiki/H%C3%B6lder%27s_inequality")[#text("Hölder")]#text("-type ")#mi("L^p")#text(" estimates (note that Hölder’s inequality related to the situation in which the (projective) ")#link("http://en.wikipedia.org/wiki/Simplex")[#text("simplex")]#text(" S is replaced by the entire frequency space ")#mi("{\\Bbb R}^n")#text(").")

#text("For the remainder of this post, I thought I would describe the “nonlinear Carleson theorem” conjecture, which is still one of my favourite open problems, being an excellent benchmark for measuring progress in the (still nascent) field of “")#link("http://www.math.ucla.edu/%7Ethiele/lecturenotes/nlft.pdf")[#text("nonlinear Fourier analysis")]#text("“, while also being of interest in its own right in scattering and spectral theory.")

#metadata(none) <tao-7b894d48e7a9ab2cab67>

#text("My starting point will be the one-dimensional time-independent ")#link("http://en.wikipedia.org/wiki/Schrodinger_equation")[#text("Schrödinger equation")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("- u_{xx}(k,x) + V(x) u(k,x) = k^2 u(k,x)")]]

#text("where ")#mi("V: {\\Bbb R} \\to {\\Bbb R}")#text(" is a given potential function, ")#mi("k \\in {\\Bbb R}")#text(" is a frequency parameter, and ")#mi("u: {\\Bbb R} \\times {\\Bbb R} \\to {\\Bbb C}")#text(" is the wave function. This equation (after reinstating constants such as ")#link("http://en.wikipedia.org/wiki/Planck%27s_constant")[#text("Planck’s constant")]#text(" ")#mi("\\hbar")#text(", which we have normalised away) describes the instantaneous state of a quantum particle with energy ")#mi("k^2")#text(" in the presence of the potential V. To avoid technicalities let us assume that V is smooth and compactly supported (say in the interval ")#mi("{}[-R,R]")#text(") for now, though the eventual conjecture will concern potentials V that are merely square-integrable.")

#text("For each fixed frequency k, the equation (2) is a linear homogeneous second order ODE, and so has a two-dimensional space of solutions. In the free case V=0, the solution space is given by")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("u(k,x) = \\alpha(k) e^{ikx} + \\beta(k) e^{-ikx}")]]

#text("where ")#mi("\\alpha(k)")#text(" and ")#mi("\\beta(k)")#text(" are arbitrary complex numbers; physically, these numbers represent the amplitudes of the rightward and leftward propagating components of the solution respectively.")

#text("Now suppose that V is non-zero, but is still compactly supported on an interval ")#mi("{}[-R,+R]")#text(". Then for a fixed frequency k, a solution to (2) will still behave like (3) in the regions ")#mi("x > R")#text(" and ")#mi("x < R")#text(", where the potential vanishes; however, the amplitudes on either side of the potential may be different. Thus we would have")

#align(center)[#tao-fit-display[#mitex("u(k,x) = \\alpha_+(k) e^{ikx} + \\beta_+(k) e^{-ikx}")]]

#text("for ")#mi("x > R")#text(" and")

#align(center)[#tao-fit-display[#mitex("u(k,x) = \\alpha_-(k) e^{ikx} + \\beta_-(k) e^{-ikx}")]]

#text("for ")#mi("x < -R")#text(". Since there is only a two-dimensional linear space of solutions, the four complex numbers ")#mi("\\alpha_-(k), \\beta_-(k), \\alpha_+(k), \\beta_+(k)")#text(" must be related to each other by a linear relationship of the form")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} \\alpha_+(k) \\\\ \\beta_+(k) \\end{pmatrix} = \\overbrace{V}(k)  \\begin{pmatrix} \\alpha_-(k) \\\\ \\beta_-(k) \\end{pmatrix}")]]

#text("where ")#mi("\\overbrace{V}(k)")#text(" is a ")#mi("2 \\times 2")#text(" matrix depending on V and k, known as the ")#link("http://en.wikipedia.org/wiki/Scattering_matrix")[#text("scattering matrix")]#text(" of V at frequency ")#mi("k")#text(". (We choose this notation to deliberately invoke a resemblance to the Fourier transform ")#mi("\\hat V(k) := \\int_{-\\infty}^\\infty V(x) e^{-2ikx}\\ dx")#text(" of V; more on this later.) Physically, this matrix determines how much of an incoming wave at frequency k gets reflected by the potential, and how much gets transmitted.")

#text("What can we say about the matrix ")#mi("\\overbrace{V}(k)")#text("? By using the ")#link("http://en.wikipedia.org/wiki/Wronskian")[#text("Wronskian")]#text(" of two solutions to (2) (or by viewing (2) as a Hamiltonian flow in phase space) we can show that ")#mi("\\overbrace{V}(k)")#text(" must have determinant 1. Also, by using the observation that the solution space to (2) is closed under complex conjugation ")#mi("u(k,x) \\mapsto \\overline{u(k,x)}")#text(", one sees that each coefficient of the matrix ")#mi("\\overbrace{V}(k)")#text(" is the complex conjugate of the diagonally opposite coefficient. Combining the two, we see that ")#mi("\\overbrace{V}(k)")#text(" takes values in the Lie group")

#align(center)[#tao-fit-display[#tao-math("SU(1,1) := \\{ \\begin{pmatrix} a & \\overline{b} \\\\ b & \\overline{a} \\end{pmatrix}: a,b \\in {\\Bbb C}, \\left|a\\right|^2-\\left|b\\right|^2 = 1 \\}", block: true)]]

#text("(which, incidentally, is isomorphic to ")#mi("SL_2({\\Bbb R})")#text("), thus we have")

#align(center)[#tao-fit-display[#mitex("\\overbrace{V}(k) =  \\begin{pmatrix} a(k) & \\overline{b(k)} \\\\ b (k) & \\overline{a(k)} \\end{pmatrix}")]]

#text("for some functions ")#mi("a: {\\Bbb R} \\to {\\Bbb C}")#text(" and ")#mi("b: {\\Bbb R} \\to {\\Bbb C}")#text(" obeying the constraint ")#tao-math("\\left|a(k)\\right|^2 - \\left|b(k)\\right|^2 = 1", block: false)#text(". (The functions ")#mi("\\frac{1}{a(k)}")#text(" and ")#mi("\\frac{b(k)}{a(k)}")#text(" are sometimes known as the ")#emph[#text("transmission coefficient")]#text(" and ")#emph[#text("reflection coefficient")]#text(" respectively; note that they square-sum to 1, a fact related to the law of conservation of energy.) These coefficients evolve in a beautifully simple manner if V evolves via the ")#link("http://en.wikipedia.org/wiki/Korteweg%E2%80%93de_Vries_equation")[#text("Korteweg-de Vries (KdV) equation")]#text(" ")#mi("V_t + V_{xxx} = 6VV_x")#text(" (indeed, one has ")#mi("\\partial_t a = 0")#text(" and ")#mi("\\partial_t b = 8ik^3 b")#text("), being part of the fascinating subject of ")#link("http://en.wikipedia.org/wiki/Exactly_solvable_model")[#text("completely integrable systems")]#text(", but that is a long story which we will not discuss here. This connection does however provide one important source of motivation for studying the ")#emph[#text("scattering transform ")]#mi("V \\mapsto \\overbrace{V}")#text(" and its inverse.")

#text("What are the values of the coefficients ")#mi("a(k), b(k)")#text("? In the free case ")#mi("V=0")#text(", one has ")#mi("a(k)=1")#text(" and ")#mi("b(k)=0")#text(". When V is non-zero but very small, one can linearise in V (discarding all terms of order ")#mi("O(V^2)")#text(" or higher), and obtain the approximation")

#align(center)[#tao-fit-display[#mitex("a(k) \\approx 1 -\\frac{i}{2k}\\int_{-\\infty}^\\infty V; \\quad b(k) \\approx \\frac{-i}{2k} \\hat V(k)")]]

#text("known as the ")#link("http://en.wikipedia.org/wiki/Born_approximation")[#text("Born approximation")]#text("; this helps explain why we think of ")#mi("\\overbrace{V}(k)")#text(" as a nonlinear variant of the Fourier transform. A slightly more precise approximation, known as the ")#link("http://en.wikipedia.org/wiki/WKB_approximation")[#text("WKB approximation")]#text(", is")

#align(center)[#mi("a(k) \\approx e^{-\\frac{i}{2k}\\int_{-\\infty}^\\infty V}; \\quad b(k) \\approx \\frac{-i}{2k} e^{-\\frac{i}{2k}\\int_{-\\infty}^\\infty V} \\int_{-\\infty}^{\\infty} V(x) e^{-2ikx + \\frac{i}{k} \\int_{-\\infty}^x V}\\ dx")#text(".")]

#text("(One can avoid the additional technicalities caused by the WKB phase correction by working with the ")#link("http://en.wikipedia.org/wiki/Dirac_equation")[#text("Dirac equation")]#text(" instead of the Schrödinger; this formulation is in fact cleaner in many respects, but we shall stick with the more traditional Schrödinger formulation here. More generally, one can consider analogous scattering transforms for AKNS systems.) One can in fact expand ")#mi("a(k)")#text(" and ")#mi("b(k)")#text(" as a formal power series of multilinear integrals in V (distorted slightly by the WKB phase correction ")#mi("e^{\\frac{i}{k} \\int_{-\\infty}^x V}")#text("), whose terms resemble the multilinear expression (1) except for some (crucial) sign changes and some WKB phase corrections. It is relatively easy to show that this multilinear series is absolutely convergent for every k when the potential V is absolutely integrable (this is the nonlinear analogue to the obvious fact that the Fourier integral ")#mi("\\hat V(k) = \\int_{-\\infty}^\\infty V(k) e^{-2ikx}")#text(" is absolutely convergent when V is absolutely integrable; it can also be deduced without recourse to multilinear series by using Levinson’s theorem.) If V is not absolutely integrable, but instead lies in ")#mi("L^p({\\Bbb R})")#text(" for some ")#mi("p > 1")#text(", then the series can diverge for some k; this fact is closely related to a classic result of Wigner and von Neumann that the Schrödinger operator can contain embedded pure point spectrum. However, Christ and Kiselev showed that the series is absolutely convergent for almost every k in the case ")#mi("1 < p < 2")#text(" (this is a non-linear version of the ")#link("http://en.wikipedia.org/wiki/Hausdorff-Young_inequality")[#text("Hausdorff-Young inequality")]#text("). In fact they proved a stronger statement, namely that for almost every k, the eigenfunctions ")#mi("x \\mapsto u(k,x)")#text(" are bounded (and converge asymptotically to plane waves ")#mi("\\alpha_\\pm(k) e^{ikx} + \\beta_\\pm(k) e^{-ikx}")#text(" as ")#mi("x \\to \\infty")#text("). There is an analogue of the Born and WKB approximations for these eigenfunctions, which shows that the Christ-Kiselev result is the nonlinear analogue of a classical result of Menshov, Paley and Zygmund showing the conditional convergence of the Fourier integral ")#mi("\\int_{-\\infty}^\\infty V(x) e^{-2ikx}\\ dx")#text(" for almost every k when ")#mi("V \\in L^p({\\Bbb R})")#text(" for some ")#mi("1 < p < 2")#text(".")

#text("The analogue of the Menshov-Paley-Zygmund theorem at the endpoint ")#mi("p=2")#text(" is the celebrated ")#link("http://www.ams.org/mathscinet-getitem?mr=199631")[#text("theorem of Carleson")]#text(" on almost everywhere convergence of Fourier series of ")#mi("L^2")#text(" functions. (The claim fails for ")#mi("p > 2")#text(", as can be seen by investigating random Fourier series, though I don’t recall the reference for this fact.) The nonlinear version of this would assert that for square-integrable potentials V, the eigenfunctions ")#mi("x \\mapsto u(k,x)")#text(" are bounded for almost every k. This is the nonlinear Carleson theorem conjecture. Unfortunately, it cannot be established by multilinear series, because of a ")#link("http://front.math.ucdavis.edu/math.CA/0108156")[#text("divergence in the trilinear term of the expansion")]#text("; but other methods may succeed instead. For instance, the weaker statement that the coefficients ")#mi("a(k)")#text(" and ")#mi("b(k)")#text(" (defined by density) are well defined and finite almost everywhere for square-integrable V (which is a nonlinear analogue of ")#link("http://en.wikipedia.org/wiki/Plancherel%27s_theorem")[#text("Plancherel’s theorem")]#text(" that the Fourier transform can be defined by density on ")#mi("L^2({\\Bbb R})")#text(") was essentially established ")#link("http://www.ams.org/mathscinet-getitem?mr=1697600")[#text("by Deift and Killip")]#text(", using a trace formula (a nonlinear analogue to Plancherel’s formula). Also, the “")#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/")[#text("dyadic")]#text("” or “function field” model of the conjecture ")#link("http://front.math.ucdavis.edu/math.CA/0205139")[#text("is known")]#text(", by a modification of Carleson’s original argument. But the general case still seems to require more tools; for instance, we still do not have a good nonlinear Littlewood-Paley theory (except in the dyadic case), which is preventing time-frequency type arguments from being extended directly to the nonlinear setting.")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/12/17/multi-linear-multipliers-associated-to-simplexes-of-arbitrary-length/#comment-20900")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2007")])]

#text("Dear Terry,")#linebreak()#text(" This na scent theory looks classical, as most of your work.")#linebreak()#text(" Not to share any pushy opinions, but ARMA is always seeking")#linebreak()#text(" promising preprints.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/720aed7977eabb513bcfa8d2f168f738626f5329177dedf87e20c0d34ca9e0fd-d3dfabca8ec9873e8ccfe696341cc3090c1419f47e4101dd83a183d830836989.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cowgonemad")]], [#link("https://terrytao.wordpress.com/2007/12/17/multi-linear-multipliers-associated-to-simplexes-of-arbitrary-length/#comment-21699")[#strong[#text("cowgonemad")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2007")])]

#text("Hi Terry,")

#text("something I am always wondering when looking at these low regularity scattering transform (or the dyadic one)s, is that has somebody ever looked at their inverses? Or how the KdV flow would act on them?")

#text("Or to be more specific:")#linebreak()#text(" – Is injectivity known?")#linebreak()#text(" – Can you characterize the image?")

#text("Best,")#linebreak()#text(" Helge")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/17/multi-linear-multipliers-associated-to-simplexes-of-arbitrary-length/#comment-21879")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2007")])]

#text("Dear Helge,")

#text("These are good questions. I think injectivity for potentials in the class H^{1,1} – functions V such that ")#mi("xV")#text(" and ")#mi("V^{\\prime}")#text(" are square-integrable – might be implicit from the work of Deift and Zhou, (in which they obtain asymptotics for NLS in this class; here the scattering problem is for a Dirac equation rather than a Schrodinger equation, but one expects the theory to be similar in both cases). One may have to place some additional assumptions on the potential though to really get injectivity.")

#text("In the case when the potential is supported on a half-line, then the method of layer stripping becomes available, and one can show that the scattering transform is a bijection between L^2 and a sort of Hardy-Nevanlinna space; there is some work by Sylvester in this direction. But to pass from the half line to the whole line one would need to solve the Riemann-Hilbert problem for very rough potentials. Christoph Thiele and I worked out the case when the scattering coefficients were rational functions, and discovered some new sources of non-injectivity in this case when a pole of the rational function touched the real line. On the other hand, for the discrete analogue of the scattering problem (i.e. orthogonal polynomials for Jacobi matrices), Yuditskii and Volberg were able to use Hilbert space methods to demonstrate invertibility in L^2.")

#text("Obtaining a good inverse scattering theory in L^2 on the full line may well be an important step towards the nonlinear Carleson conjecture (but presumably the theory would have to supply a lot of useful estimates before it can really impact that conjecture).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/720aed7977eabb513bcfa8d2f168f738626f5329177dedf87e20c0d34ca9e0fd-d3dfabca8ec9873e8ccfe696341cc3090c1419f47e4101dd83a183d830836989.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Helge")]], [#link("https://terrytao.wordpress.com/2007/12/17/multi-linear-multipliers-associated-to-simplexes-of-arbitrary-length/#comment-22386")[#strong[#text("Helge")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2007")])]

#text("Dear Terry,")

#text("the bench mark result for inverse scattering for Schroedinger’s equation is as far as I believe by Marchenko, which yields the result for V and x V integrable functions. It can be found in his monograph on Sturm-Liouville equations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2007/12/17/multi-linear-multipliers-associated-to-simplexes-of-arbitrary-length/#comment-38920")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2009")])]

#text("Dear Terry,")

#text("Can you (or anyone who is reading this) direct me to literature on boundedness of multilinear Fourier multipliers between L2 based Sobolev spaces, please?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/17/multi-linear-multipliers-associated-to-simplexes-of-arbitrary-length/#comment-38923")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2009")])]

#text("Dear Timur,")

#text("I have a paper on this topic at")

#link("http://front.math.ucdavis.edu/math.AP/0005001")[#text("http://front.math.ucdavis.edu/math.AP/0005001")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2007/12/17/multi-linear-multipliers-associated-to-simplexes-of-arbitrary-length/#comment-38924")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2009")])]

#text("Thanks a lot for the quick reply!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A variation norm Carleson theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2007/12/17/multi-linear-multipliers-associated-to-simplexes-of-arbitrary-length/#comment-41794")[#strong[#text("A variation norm Carleson theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2009")])]

#text("[…] The estimate (2) also provides a new proof of a result of Christ and Kiselev on the almost everywhere boundedness of eigenfunctions of Schrodinger operators with potentials with . Unfortunately, due to various endpoint issues, this barely fails to settle the endpoint case , a conjecture known as the nonlinear Carleson conjecture (discussed in this previous post). […]")
]
