// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/
// Converted to Typst by tao2typ: "2026-10-14T11:00:35.787738+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Course announcement: Math 246A, complex analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Course announcement: Math 246A, complex analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 September 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/")[#text("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Starting on Oct 2, I will be teaching ")#link("https://ccle.ucla.edu/course/view/20F-MATH246A-1")[#text("Math 246A")]#text(", the first course in the three-quarter graduate complex analysis sequence at the math department here at UCLA. This first course covers much of the same ground as an honours undergraduate complex analysis course, in particular focusing on the basic properties of holomorphic functions such as the Cauchy and residue theorems, the classification of singularities, and the maximum principle, but there will be more of an emphasis on rigour, generalisation and abstraction, and connections with other parts of mathematics. The main text I will be using for this course is ")#link("http://www.ams.org/mathscinet-getitem?mr=1976398")[#text("Stein-Shakarchi")]#text(" (with ")#link("http://www.ams.org/mathscinet-getitem?mr=510197")[#text("Ahlfors")]#text(" as a secondary text), but I will also be using ")#link("https://terrytao.wordpress.com/category/teaching/246a-complex-analysis/")[#text("the blog lecture notes")]#text(" I wrote the last time I taught this course in 2016. At this time I do not expect to significantly deviate from my past lecture notes, though I do not know at present how different the pace will be this quarter when the course is taught remotely. As with my ")#link("https://terrytao.wordpress.com/category/teaching/247b-classical-fourier-analysis/")[#text("247B course last spring")]#text(", the lectures will be open to the public, though other coursework components will be restricted to enrolled students.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (29)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2845569d5604558323db56a80ff608af4e667890d2603ce0525d371d1bef8b0-93392cf032c9274148be57d0055e2a6e0880ee70b47cdd9612fc3f417c893e48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro M. Silva")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-589006")[#strong[#text("Pedro M. Silva")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2020")])]

#text("Dear prof. Tao,")#linebreak()#text(" (I hope this comment finds you well during these strange times.)")#linebreak()#text(" Thank you so much for providing open access to such nice classes.")#linebreak()#text(" Unfortunately, due to the difference in time zones, I won’t be able to follow the course.")#linebreak()#text(" Nonetheless, I was wondering if you are aware of any other professors or universities giving access to their online courses in math subjects for this semester/quarter. I couldn’t really find any others, except for past courses (which are recorded). Maybe we could collect this info somewhere, as this kind of initiative really helps during these quarentine moments.")#linebreak()#text(" In any case, thank you so much.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/33b26edc4ef5e000529026ac77dd839231886a7bffaa8c1dd07531e238933100-5f9603ca0a37873cafc810cfe8dd5f2e70a532324b85eb4e9b217e39c16faaaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Prateek P Kulkarni")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-589015")[#strong[#text("Prateek P Kulkarni")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2020")])]

#text("Dear Pedro,")#linebreak()#text(" Does ‘open access’ mean we can join the lectures too via zoom link?")#linebreak()#text(" ‘Cause I have been wanting to take such a course (from a long time)..")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-589337")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2020")])]

#text("Yes. You can join via zoom link.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/654860f7ab3bccdacdd1edf4ed9ca7a452824bc33757d21bd183dd0012aafae1-bef87085757bcf462a3a59c721d677df37b119c3fd1e9113e67b868e9183be0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edgawliet")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-589011")[#strong[#text("Edgawliet")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2020")])]

#text("Hello, where can I (not a student) enrol/take the course?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hulk")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-589013")[#strong[#text("Hulk")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2020")])]

#text("A small typo in the first sentence : departmeht departement. Do you teach about the 1966 Fields medalist A. Grothendieck contribution and more precisely about Grothendieck theorem (or inequality and its recent applications in theoretical computer science and graph theory) and Grothendieck real and complex constants introduced in his famous Résumé of 1956 and whose exact values still remain unknown and open problem problems nowadays (to the best of out knowledge and belief) despite a lot of old and recent research works both in maths and quantum physics which focused on finding and computing their lower and upper bounds (e.g., for the upper bound in the real case, cf. the works of Krivine in 1971 and of Braverman, Makarychev, Makarychev and Naor in 2011) ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/33b26edc4ef5e000529026ac77dd839231886a7bffaa8c1dd07531e238933100-5f9603ca0a37873cafc810cfe8dd5f2e70a532324b85eb4e9b217e39c16faaaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Prateek P Kulkarni")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-589014")[#strong[#text("Prateek P Kulkarni")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2020")])]

#text("Sir, can non-UCLA students join the lectures (the zoom meeting mentioned on course website)? I am very much wanting to take this course sir. I very much look forward to this Complex Analysis course. Please let me know sir…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-589336")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2020")])]

#text("Yes. Anyone can attend the lectures.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/320a618ef53c7c1b58cd60d2e39e12834d571c3ee06f1153970cdea61608cdc4-4ab92598afa3bd4a40d062a0dae8dc0fb8d4ef6280441e32dd192fcf0b23163b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-589017")[#strong[#text("Ryan")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2020")])]

#text("Terry, have you looked at Marshall’s new text on the subject? – it seems like a very interesting text with a sweeping breadth of problems. Was wondering also what others think of it.")

#text("Warmly,")

#text("Ryan")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/963068b5e5c25488dda9891cf910f3940be72f43b9cf3136d5b6a7b8f4b7808f-bd8c06050f71e3a8d8d27c59cad60e7e8f40a57d5dcaaca1eaf85f668d010366.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AC")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-590238")[#strong[#text("AC")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2020")])]

#text("Some blog with high visibility should make a page collecting all online resources for various math classes especially videos. There is probably a lot of them out there that we don’t know about, like this one ")#link("https://www.youtube.com/channel/UCIyDqfi_cbkp-RU20aBF-MQ")[#text("https://www.youtube.com/channel/UCIyDqfi_cbkp-RU20aBF-MQ")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ba2ac1a11f900cb152d113eb52636971e9679209e11b65b64ea19debd4afa4b-edbbae9536673dce5765aa452d9f91a04c33cdba247fe14e5bbe26dd5bcbc670.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of termino olaven")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-593776")[#strong[#text("termino olaven")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("do it! do a good job it won’t be a problem getting blog and other publicity.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75a5b5d3495b7cf3fdcf222ed41d4159b151bbb54e4db6707e3942f4028dad9b-da354247deb2a4d904516c4dedccb5b97260d3dff5dcd1b7eeed4f3a07fe1a18.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sai Gopal")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-591687")[#strong[#text("Sai Gopal")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2020")])]

#text("Where do I find the zoom meet link to join the public lecture ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-592094")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2020")])]

#text("Check the course link Prof. Tao provided. It is there.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-591912")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2020")])]

#text("Hello Prof. Tao,")#linebreak()#text(" Are the homeworks going to be from Stein and Shakarchi? Also, another related question is, will any of the homeworks be based on your notes?")#linebreak()#text(" Thank you,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a98d20754f8295451c9dca2b4d8a80219f1b9580f5d286eb322856ed7a75dba7-b137dafc8142cb6cf0c739fa5f3d88bfecc35eadabd561b13c690f796bfd9097.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sabino Lamonaca")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-595937")[#strong[#text("Sabino Lamonaca")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2020")])]

#text("Can anyone tell me what kind of argument would this be? For personal interest only")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5de6601fac6cb296ef0ce36a2ba1083f6c9e55a6f479fb98bee8bdc381527898-f87dae66b6420ec50302c1601ca20f2d5b604640fcb66b7b62aa0f927ea6f360.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sandy")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-593219")[#strong[#text("Sandy")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2020")])]

#text("Hello,")#linebreak()#text(" I am a non-UCLA student who is excited to audit this course. Unfortunately, I was traveling during the first class meeting yesterday, so I was wondering if it is still possible to follow the material having missed the first lecture.")

#text("I also wanted to ask whether there is any way for me to watch a recording of Friday’s class (of course I fully understand if the answer is no, since I am not UCLA-affiliated).")

#text("Thanks for your time,")#linebreak()#text(" Sandy")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-593499")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2020")])]

#text("Due to ")#link("https://www.adminvc.ucla.edu/covid-19/academic-continuity/protecting-privacy-and-data-during-remote-working-and-using-zoom")[#text("UCLA privacy rules")]#text(", video recordings can only be hosted on university-hosted platforms such as CCLE, which are restricted to enrolled students.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-593952")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2020")])]

#text("Understood, thanks.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb51e76e33340b0bca11c3dc7000f0cfea343e99cefb4e05413465537c1861f7-f3c09c4fc1c0e9768011bcf5d810025ae74a14cbf082f430b8b06af90fe261fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-593774")[#strong[#text("D")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("No zoom link on the UCLA official page. Any help, anyone? Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ba2ac1a11f900cb152d113eb52636971e9679209e11b65b64ea19debd4afa4b-edbbae9536673dce5765aa452d9f91a04c33cdba247fe14e5bbe26dd5bcbc670.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of termino olaven")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-593777")[#strong[#text("termino olaven")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("it’s linked to the linked page–“course description”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-594244")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("Dear Prof. Tao:")

#text("If the pen keeps frozen in OneNote, maybe you can try using Notability. It works well. Also, the notes you use in class is not up to date as the ones you posted on line. The one on line has less errors :-)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-595613")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2020")])]

#text("Not to promote Apple, but Mac, iPad, and Apple pencil all works much better.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-594461")[#strong[#text("Christian")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2020")])]

#text("Can non UCLA students attend the discussion session on Thursday?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69f78ca84676cd596cc590c6317f8ff7b2f20f23ad01251f1373e9c45950429d-939f3e1dfca2696608dd916944f50d7f61d1824cab438612049e6384ee35f0c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-595062")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("Yes, I’m fine with non-UCLA students attending the Thursday discussion, although priority will be given to enrolled students when it comes to answering questions. – Ben")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a98d20754f8295451c9dca2b4d8a80219f1b9580f5d286eb322856ed7a75dba7-b137dafc8142cb6cf0c739fa5f3d88bfecc35eadabd561b13c690f796bfd9097.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sabino Lamonaca")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-594641")[#strong[#text("Sabino Lamonaca")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2020")])]

#text("This Is so interesting! Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-603466")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2020")])]

#text("I was not admitted to the Zoom room today. Is it because there is no class at UCLA due to Veterans Day holiday?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-603471")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2020")])]

#text("Will there be any class on Friday (Nov 13, 20)?")

#text("The class page (")#link("https://ccle.ucla.edu/mod/page/view.php?id=3173126")[#text("https://ccle.ucla.edu/mod/page/view.php?id=3173126")]#text(") marks the schedule for this week as “Week 6 (Nov 9-15)”, not “Week 6 (Nov 9-13)”. Will there be any class on Nov 15?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ef416d4d65005c8c948ba1d552bca5b19817468eb0dee8254d21e31a58194c6-223b876ebec382062e2d73b2f69e1cb83720cbf9b4506b21b5e50432ab15b78f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-603483")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2020")])]

#text("There will be class this Friday. – Ben")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-603476")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2020")])]

#text("This also happened to me. I was stuck in the waiting room for the entire hour.")

#text("I also had problems with being stuck in the waiting room for the previous two lectures as well (I left and rejoined and was admitted automatically, but that didn’t work this time).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ef416d4d65005c8c948ba1d552bca5b19817468eb0dee8254d21e31a58194c6-223b876ebec382062e2d73b2f69e1cb83720cbf9b4506b21b5e50432ab15b78f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2020/09/14/course-announcement-math-246a-complex-analysis/#comment-603482")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2020")])]

#text("Yes, there was no lecture today due to Veteran’s day. We’ll reconvene on Friday. – Ben")
]
]
