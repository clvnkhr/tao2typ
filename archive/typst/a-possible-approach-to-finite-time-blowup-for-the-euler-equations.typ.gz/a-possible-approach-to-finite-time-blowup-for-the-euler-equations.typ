// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/09/08/a-possible-approach-to-finite-time-blowup-for-the-euler-equations/
// Converted to Typst by tao2typ: "2026-10-14T15:21:01.367320+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A possible approach to finite time blowup for the Euler equations", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A possible approach to finite time blowup for the Euler equations")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 September 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/09/08/a-possible-approach-to-finite-time-blowup-for-the-euler-equations/")[#text("https://terrytao.wordpress.com/2024/09/08/a-possible-approach-to-finite-time-blowup-for-the-euler-equations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Given a smooth compact Riemannian manifold ")#mi("{M = (M,g)}")#text(", the incompressible Euler equations can be written in ")#link("https://en.wikipedia.org/wiki/Abstract_index_notation")[#text("abstract index notation")]#text(" as")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u^\\alpha + u^\\beta \\nabla_\\beta u^\\alpha  & = - \\nabla^\\alpha p", block: true)



#tao-math("\\nabla_\\alpha u^\\alpha  & = 0", block: true)
]

#text("where ")#mi("{p: [0,T) \\rightarrow C^\\infty(M)}")#text(" is a time-dependent scalar field (representing pressure), and ")#mi("{u: [0,T) \\rightarrow \\Gamma(TM)}")#text(" is a time-dependent vector field (representing fluid velocity). Here ")#mi("{\\nabla}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Levi-Civita_connection")[#text("Levi-Civita connection")]#text(" associated to ")#mi("{g}")#text(". One can recover ")#mi("{p}")#text(" from ")#mi("{u}")#text(" (up to constants), so I will abuse notation and refer to the solution to this system as ")#mi("{u}")#text(" rather than ")#mi("{(u,p)}")#text(". Over the last few years I have been interested in the following conjecture:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Finite time blowup)")]#text(" ")#metadata(none) <tao-d1a73570aa079cee4251>#text(" There exists a manifold ")#mi("{M}")#text(" and a smooth solution ")#mi("{u}")#text(" to the Euler equations that blows up at some finite time ")#mi("{T}")#text(".")
]

#text("This remains open, however there has been progress on rougher versions of this problem. For instance, there is the well-known ")#link("https://zbmath.org/1492.35199")[#text("result of Elgindi")]#text(" (discussed in ")#link("https://terrytao.wordpress.com/2019/12/26/elgindis-approximation-of-the-biot-savart-law/")[#text("this previous post")]#text(") that when ")#mi("{M = {\\bf R}^3}")#text(" and ")#mi("{\\alpha>0}")#text(" is sufficiently small, there exists a ")#mi("{C^{1,\\alpha}}")#text(" solution ")#mi("{u}")#text(" to the Euler equations on ")#mi("{{\\bf R}^3}")#text(" that blows up in finite time. There has also been progress in establishing various “universality” properties of the Euler flow on manifolds (which informally state that “fluid computers” are possible); see for instance this recent ")#link("https://arxiv.org/abs/2405.20999")[#text("survey of Cardona, Miranda, and Peralta-Salas")]#text(". Unfortunately, these “fluid computers” do not combine well with scaling symmetries, and so thus far have not been able to produce (finite energy) blowups.")

#text("I have been playing with one approach to this conjecture, which reduces to solving a certain underdetermined system of partial differential equations, and then establishing some stability result for the resulting solution. However, I have not been able to make headway on solving this latter system despite its underdetermined nature; so I thought I would record my partial attempt here in case anyone is interested in pursuing it further (and also to contribute to the practice of sharing unsuccessful attempts to solve a problem, which is still quite infrequently done in our community).")

#text("To avoid technicalities let us simplify the problem by adding a forcing term ")#mi("{f: [0,T) \\rightarrow \\Gamma(TM)}")#text(":")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u^\\alpha + u^\\beta \\nabla_\\beta u^\\alpha  & = - \\nabla^\\alpha p + f^\\alpha", block: true)



#tao-math("\\nabla_\\alpha u^\\alpha  & = 0.", block: true)
]

#text("Standard local well-posedness theory (using the vorticity-stream formulation of the Euler equations) tells us that this problem is well-posed if the initial data ")#mi("{u_0}")#text(" is divergence free and in ")#mi("{C^{1,\\alpha}(M)}")#text(" for some ")#mi("{\\alpha>0}")#text(", and the forcing term ")#mi("{f}")#text(" is in ")#mi("{L^1_t C^{1,\\alpha}(M)}")#text(". We have the following ")#link("https://arxiv.org/abs/2309.08495")[#text("recent result")]#text(" of Córdoba and Martínez-Zoroa, solving a version of the above conjecture in the presence of a reasonably regular forcing term:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Finite time blowup for the forced equation)")]#text(" There exists a smooth solution to the forced Euler equations on ")#mi("{{\\bf R}^3}")#text(" that exhibits finite time blowup, in which the forcing term ")#mi("{f}")#text(" stays uniformly bounded in ")#mi("{C^{1,\\alpha}({\\bf R}^3)}")#text(" for any ")#mi("{\\alpha < 1/2}")#text(".")
]

#text("Roughly speaking, their argument proceeds by a multiscale construction, in which the solution is set up to eventually have some presence at a spatial scale ")#mi("{1/N}")#text(", which is conducive to generating an exponential “stretching” of a small forcing term at a much higher spatial scale ")#mi("{1/M}")#text(", which one then introduces to then set up the solution for the next scale.")

#text("As a model problem, I tried to reproduce this type of result from a more geometric perspective, trying to aim for a more “self-similar” blowup than a “multi-scale” one, in the hope that this latter type of blowup might be more tractable to analyze and eventually resolve Conjecture ")#link(<tao-d1a73570aa079cee4251>)[#text("1")]#text(". I didn’t fully succeed; but I think the approach I outline below is in principle feasible.")

#text("The manifold I will work on is a cylinder ")#mi("{M = {\\bf R} \\times N}")#text(", where ")#mi("{N = (N,h)}")#text(" is a smooth compact manifold, and the metric on ")#mi("{M}")#text(" is just the sum of the standard metric ")#mi("{dx_1^2}")#text(" on the first coordinate and ")#mi("{h}")#text(":")

#align(center)[#tao-fit-display[#mitex("dg^2 = dx_1^2 + dh^2.")]]

#text("(I have experimented with working with more warped metrics to gain more flexibility, but this seems to only influence lower order terms. However, such tricks may be useful to improve the regularity of the forcing term, or perhaps even to eliminate it entirely.) The idea is to try to create a solution that blows up on a slice ")#mi("{\\{0\\} \\times N}")#text(" on this cylinder, but stays smooth until the blowup time, and also uniformly smooth away from this slice. As such, one can localize the solution away from this slice, and replace the unbounded component ")#mi("{{\\bf R}}")#text(" of ")#mi("{M}")#text(" by a compact circle ")#mi("{{\\bf R}/L{\\bf Z}}")#text(" for some large ")#mi("{L}")#text(" if desired. However, I prefer to work with the unbounded component ")#mi("{{\\bf R}}")#text(" here in order to scale in this direction.")

#text("If we now use Greek indices to only denote coordinates in the “vertical” coordinate ")#mi("{N}")#text(", the velocity field ")#mi("{u}")#text(" now becomes ")#mi("{(u^1, u^\\alpha)}")#text(", and the Euler equations now split as")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u^1 + u^1 \\partial_1 u^1 + u^\\beta \\nabla_\\beta u^1  & = - \\partial_1 p + f^1", block: true)



#tao-math("\\partial_t u^\\alpha + u^1 \\partial_1 u^\\alpha + u^\\beta \\nabla_\\beta u^\\alpha  & = - \\nabla^\\alpha p + f^\\alpha", block: true)



#tao-math("\\partial_1 u^1 + \\nabla_\\alpha u^\\alpha  & = 0.", block: true)
]

#text("If the solution is concentrating in a narrow neighborhood of the slice ")#mi("{\\{0\\} \\times N}")#text(", we expect the terms involving ")#mi("{\\partial_1}")#text(" to be quite large, and the terms involving ")#mi("{u_1}")#text(" to be rather small. This suggests that the ")#mi("{\\partial_1 p}")#text(" pressure term is going to be more significant than the ")#mi("{\\nabla^\\alpha p}")#text(" term. We therefore select the forcing term to cancel this term by choosing")

#align(center)[#tao-fit-display[#mitex("f^1 = 0; f^\\alpha = \\nabla^\\alpha p")]]

#text("leaving us with the simplified equation")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u^1 + u^1 \\partial_1 u^1 + u^\\beta \\nabla_\\beta u^1  & = - \\partial_1 p", block: true)



#tao-math("\\partial_t u^\\alpha + u^1 \\partial_1 u^\\alpha + u^\\beta \\nabla_\\beta u^\\alpha  & = 0", block: true)



#tao-math("\\partial_1 u^1 + \\nabla_\\alpha u^\\alpha  & = 0.", block: true)
]

#text("The nice thing about this latter equation is that the first equation is basically just a formula for ")#mi("{p}")#text(" and so can be dropped, leaving us with")

#metadata(none) <tao-8589a1a1732eac524c5c>

#tao-aligned(keep: true)[


#tao-math("\\partial_t u^\\alpha + u^1 \\partial_1 u^\\alpha + u^\\beta \\nabla_\\beta u^\\alpha  & = 0", block: true, numbering: n => [#text("(1)")])

#metadata(none) <tao-b5bb3545f9694d6cde52>

#tao-math("\\partial_1 u^1 + \\nabla_\\alpha u^\\alpha  & = 0.", block: true, numbering: n => [#text("(2)")])
]

#text("This equation now admits a two-parameter family of scale invariances")

#align(center)[#tao-fit-display[#mitex("u^1(t,x^1,y) \\mapsto \\frac{\\lambda}{\\mu} u^1(t/\\mu, x/\\lambda,y); u^\\alpha(t,x^1,y) \\mapsto \\frac{1}{\\mu} u^1(t/\\mu, x/\\lambda,x^\\alpha)")]]

#text("for ")#mi("{\\lambda, \\mu > 0}")#text(", where we use ")#mi("{y}")#text(" to ednote the ")#mi("{N}")#text(" coordinate. It also inherits an energy conservation law from the original Euler equations; the conserved energy is")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} \\int_{\\bf R} \\int_N u^\\alpha(t,x^1,y) u_\\alpha(t,x^1,y)\\ dy dx^1")]]

#text("using the metric on ")#mi("{N}")#text(" to raise and lower the Greek indices.")

#text("It is now tempting to try to set up an approximately scale-invariant blowup solution. It seems that the first step in this is to construct a “soliton” type localized steady state solution, that is a solution ")#mi("{u_1 \\in C^\\infty({\\bf R} \\times N)}")#text(", ")#mi("{u^\\alpha : {\\bf R} \\rightarrow \\Gamma(TN)}")#text(" to the equation")

#tao-aligned(keep: true)[


#tao-math("u^1 \\partial_1 u^\\alpha + u^\\beta \\nabla_\\beta u^\\alpha  & = 0", block: true)



#tao-math("\\partial_1 u^1 + \\nabla_\\alpha u^\\alpha  & = 0.", block: true)
]

#text("that decays in the ")#mi("{x_1}")#text(" variable; one can then hope to do a suitable stability (or instability) analysis of this soliton to perturb it to a blowup solution, as there are many results of this type for other equations that one could use as a model. The energy conservation law does constrain to some extent the nature of the blowup (basically, the two scaling parameters ")#mi("{\\mu,\\lambda}")#text(" above become linked by the relation ")#mi("{\\mu \\sim \\lambda^{1/2}}")#text("), but does not seem to otherwise prevent such a blowup from occuring.")

#text("Analytically, this is not a particularly pleasant equation to try to solve; one can substitute the second equation into the first to obtain a single equation")

#align(center)[#tao-fit-display[#mitex("-(\\partial_1^{-1} \\nabla_\\beta u^\\beta) \\partial_1 u^\\alpha + u^\\beta \\nabla_\\beta u^\\alpha = 0")]]

#text("but the inverse derivative ")#mi("{\\partial_1^{-1}}")#text(" is difficult to work with and seems to create ill-posedness (somewhat reminiscent of the ill-posedness of the Prandtl ")#link("https://en.wikipedia.org/wiki/Boundary_layer")[#text("boundary layer equation")]#text(").")

#text("Nevertheless, one can still attempt to solve this equation by separation of variables. If one makes the ansatz")

#tao-aligned(keep: true)[


#tao-math("u^1(x^1,y)  & = \\frac{1}{1+(x^1)^2} \\varphi(y)", block: true)



#tao-math("u^\\alpha(x^1,y)  & = \\frac{v^\\alpha(y) + x^1 w^\\alpha(y)}{(1+(x^1)^2)^2}", block: true)
]

#text("for some smooth ")#mi("{\\varphi \\in C^\\infty(N)}")#text(" and ")#mi("{v,w \\in \\Gamma(TN)}")#text(", some calculation shows that the system now reduces to a system purely on ")#mi("{N}")#text(":")

#tao-aligned(keep: true)[


#tao-math("\\varphi w^\\alpha + v^\\beta \\nabla_\\beta v^\\alpha  & = 0", block: true)



#tao-math("-2 \\varphi v^\\alpha + v^\\beta \\nabla_\\beta w^\\alpha + w^\\beta \\nabla_\\beta v^\\alpha  & = 0", block: true)



#tao-math("-3 \\varphi w^\\alpha + w^\\beta \\nabla_\\beta w^\\beta  & = 0", block: true)



#tao-math("\\nabla_\\alpha v^\\alpha  & = 0.", block: true)



#tao-math("\\nabla_\\alpha w^\\alpha  & = 2\\varphi.", block: true)
]

#text("The metric ")#mi("{h}")#text(" is hidden in this system through the covariant derivative ")#mi("{\\nabla}")#text(". To eliminate the metric, we can lower indices to write")

#tao-aligned(keep: true)[


#tao-math("\\varphi w_\\alpha + v^\\beta \\nabla_\\beta v_\\alpha  & = 0", block: true)



#tao-math("-2 \\varphi v_\\alpha + v^\\beta \\nabla_\\beta w_\\alpha + w^\\beta \\nabla_\\beta v_\\alpha  & = 0", block: true)



#tao-math("-3 \\varphi w_\\alpha + w^\\beta \\nabla_\\beta w_\\beta  & = 0", block: true)



#tao-math("\\mathrm{div}_h v  & = 0.", block: true)



#tao-math("\\mathrm{div}_h w  & = 2\\varphi.", block: true)
]

#text("Here the divergence is relative to the volume form induced by ")#mi("{h}")#text(", but by a dimension lifting trick (see Section 3 of ")#link("https://arxiv.org/abs/1707.07807")[#text("this paper of mine")]#text(") one can replace this divergence with a divergence ")#mi("{\\mathrm{div}_{vol}}")#text(" with respect to any other volume form on ")#mi("{N}")#text(". We have the identity")

#align(center)[#tao-fit-display[#mitex("v^\\beta \\nabla_\\beta v_\\alpha = v^\\beta (\\nabla_\\beta v_\\alpha - \\nabla_\\alpha v_\\beta) + \\frac{1}{2} \\partial_\\alpha (v^\\beta v_\\beta)")]]

#align(center)[#tao-fit-display[#mitex("v \\neg d\\theta + \\frac{1}{2} d (\\theta(v))")]]

#text("where we have switched to coordinate-free notation, and ")#mi("{\\theta = h \\cdot v}")#text(" is the ")#mi("{1}")#text("-form associated to ")#mi("{v}")#text(". If we similarly let ")#mi("{\\lambda}")#text(" be the ")#mi("{1}")#text("-form associated to ")#mi("{w}")#text(", and eliminate ")#mi("{\\varphi}")#text(", the system now becomes")

#metadata(none) <tao-87aaf606ddebb4099c78>

#tao-aligned(keep: true)[


#tao-math("\\frac{1}{2} \\lambda \\mathrm{div}_{vol} w + v \\neg d\\theta + \\frac{1}{2} d (\\theta(v))  & = 0", block: true, numbering: n => [#text("(3)")])

#metadata(none) <tao-d5c401328d3bc60f858a>

#tao-math("-\\theta \\mathrm{div}_{vol} w + v \\neg d\\lambda + w \\neg d\\theta + \\frac{1}{2} d (\\theta(w) + \\lambda(v))  & = 0", block: true, numbering: n => [#text("(4)")])

#metadata(none) <tao-790fe8b9eb73baf47d3b>

#tao-math("-\\frac{3}{2}\\lambda \\mathrm{div}_{vol} w + w \\neg d\\lambda + \\frac{1}{2} d (\\lambda(w))  & = 0", block: true, numbering: n => [#text("(5)")])

#metadata(none) <tao-6f0b1baba1dab6bbe8d7>

#tao-math("\\mathrm{div}_{vol} v  & = 0.", block: true, numbering: n => [#text("(6)")])
]

#text("Also, the fact that ")#mi("{\\lambda,\\theta}")#text(" are dual to ")#mi("{v,w}")#text(" with respect to some unspecified Riemannian metric ")#mi("{h}")#text(" turns out to essentially be equivalent to the assumption that the Gram matrix is positive definite,")

#metadata(none) <tao-fd8348c37e3c2786327d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\begin{pmatrix} \\lambda(v) & \\lambda(w) \\\\ \\theta(v) & \\theta(w) \\end{pmatrix} \\succ 0;")]]

#text("see Section 4 of ")#link("https://arxiv.org/abs/1707.07807")[#text("the aforementioned paper")]#text(". This looks like a rather strange system; but it is three vector equations ")#link(<tao-87aaf606ddebb4099c78>)[#text("(3)")]#text(", ")#link(<tao-d5c401328d3bc60f858a>)[#text("(4)")]#text(", ")#link(<tao-790fe8b9eb73baf47d3b>)[#text("(5)")]#text(" in four vector (or one-form) unknowns ")#mi("{v, w, \\theta, \\lambda}")#text(", together with a divergence-free condition ")#link(<tao-6f0b1baba1dab6bbe8d7>)[#text("(6)")]#text(" and a positive definiteness condition ")#link(<tao-fd8348c37e3c2786327d>)[#text("(7)")]#text(", which I view as basically being scalar conditions. Thus, this system becomes underdetermined when the dimension of ")#mi("{N}")#text(" is large enough (in fact a naive count of degrees of freedom suggests that dimension at least three should be sufficient). It should thus be possible to locate an abundant number of solutions to this system; but to my frustration, the system is just barely complicated enough to prevent me from simplifying it to the point where it becomes evident how to construct solutions; in particular, I have not been able to find a viable further ansatz to transform the system to a more tractable one. Part of the problem is that while the system is technically underdetermined, there are not that many degrees of freedom to spare to ensure this underdetermined nature, so one cannot afford to make an ansatz that sacrifices too many of these degrees of freedom. In my previous paper I was able to use a very symmetric construction (taking ")#mi("{N}")#text(" to basically be the product of an orthogonal group and a torus) to solve a similar system that was in fact quite overdetermined, but I have not been able to exploit such symmetries here. I have also experimented with other separation of variable ansatzes, but they tend to give similar systems to the ones here (up to some changes in the coefficients).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" One can also try to directy create a self-similar blowup to ")#link(<tao-8589a1a1732eac524c5c>)[#text("(1)")]#text(", ")#link(<tao-b5bb3545f9694d6cde52>)[#text("(2)")]#text(", for instance by making the ansatz")

#tao-aligned(keep: true)[


#tao-math("u^1(t,x^1,y)  & = (t^6+(x^1)^2)^{1/3} \\varphi(y)", block: true)



#tao-math("u^\\alpha(t,x^1,y)  & = \\frac{v^\\alpha(y)}{(t^6+(x^1)^2)^{1/3}} + \\frac{w^\\alpha(y) + x^1 q^\\alpha(y)}{(t^6+(x^1)^2)^{2/3}} + \\frac{r^\\alpha(y) + x^1 s^\\alpha(y)}{(t^6+(x^1)^2)}", block: true)
]

#text("for ")#mi("{t<0}")#text(" and some fields ")#mi("{\\varphi \\in C^\\infty(N)}")#text(" and ")#mi("{v,w,q,r,s \\in \\Gamma(TN)}")#text(". This particular ansatz seems consistent with all known conservation laws; however it works out to basically be ten vector equations (plus some additional scalar constraints) on ten vector field unknowns, so is just barely overdetermined. I have not been able to locate a self-similar blowup ansatz that is underdetermined.")
]

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/08/a-possible-approach-to-finite-time-blowup-for-the-euler-equations/#comment-685757")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2024")])]

#text("great to see you active in the page working on mathematics , have a nice day")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/08/a-possible-approach-to-finite-time-blowup-for-the-euler-equations/#comment-685762")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2024")])]

#text("Blowup… what is it… not friendly to amateur fake mathematicians…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/08/a-possible-approach-to-finite-time-blowup-for-the-euler-equations/#comment-685770")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2024")])]

#text("I used ChatGPT o1 to understand this text.")

#text("In fact, for people like Koreans whose native language is not English, the difficulty was often not in expanding equations or understanding phenomena, but in the English language itself.")

#text("While o1’s explanations were not perfect, I was able to grasp the flow of the text through its natural paraphrasing.")

#text("Previously, when I used a Korean-English translator to read this blog post, my comprehension was about 10% after 30 minutes of careful reading. After using o1, I feel that my comprehension has increased to over 80% after just 5 minutes of careful reading.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2bb842258b040d699c721f644030fecdc22c9238ba0571551bda772faf17210e-2cc94c6bf194e5f0820ef564dde484baadd6d805623e6bbc5b4fa0616a1b258d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacob Manaker")]], [#link("https://terrytao.wordpress.com/2024/09/08/a-possible-approach-to-finite-time-blowup-for-the-euler-equations/#comment-685772")[#strong[#text("Jacob Manaker")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2024")])]

#text("There appear to be a number of typos in equations (3-5); if I’m understanding correctly, the volume-divergences of ")#mi("v")#text(" there should be divergences of ")#mi("w")#text(" instead; and the exterior derivative in (4) should be ")#mi("d(\\theta(w)+\\lambda(v))")

#text("Separately, you don’t mention explicitly what boundedness and nonvanishing conditions you expect on a solution to (3-7) is; but I think that’s worth setting out. After all, suppose ")#mi("(\\theta,\\lambda,w,v)")#text(" are all constants (in ")#mi("y")#text(") chosen to satisfy (7). Then those functions trivially satisfy (3-6), as all terms in (3-6) are of (differential) degree 1. But that’s not a useful solution, because you need ")#mi("\\mathrm{div}_{\\text{vol}}(w)")#text(" not identically zero, because that’s ")#mi("\\phi")#text(", and if ")#mi("\\phi")#text(" is identically zero then so is ")#mi("u^1")#text(".")

#text("I’ll conclude with a vague and lazy suggestion. In the large-")#mi("\\mathrm{dim}(N)")#text(" limit, additional scalar conditions are free as you note. It seems natural to require ")#mi("\\theta(w)+\\lambda(v)")#text(", ")#mi("\\theta(v)")#text(", and ")#mi("\\lambda(w)")#text(" to all be constants, as that kills the final exterior derivative terms in (3-5). But unless the constants in question are ")#mi("0")#text(", or ")#mi("N")#text(" is compact, such constancy is (I think) incompatible with any ")#mi("L^p")#text(" condition on ")#mi("(\\theta,\\lambda,w,v)")#text(". So maybe one ought to look at ")#mi("N=(\\mathbb{R}/\\mathbb{Z})^k")#text(", where ")#mi("k \\geq 5")#text(". IIRC smallest nontrivial D-module is polynomials; and polynomials in ")#mi("z^\\alpha=y^\\alpha \\left(y^\\alpha-\\frac{1}{2}\\right)(y^\\alpha-1)")#text(" are periodic with periodic derivative, so well-defined on ")#mi("N")#text(". So maybe ")#mi("(\\theta,\\lambda,w,v)")#text(" affine or low-degree polynomial in ")#mi("z^\\alpha")#text(" is a good ansatz? Even the affine case has at least ")#mi("5^2\\cdot2\\cdot4=200")#text(" free parameters, too many to work out by hand. But programming ")#emph[#text("Mathematica")]#text(" to write down the equations doesn’t seem like it should take more than an afternoon, and then one can always call FindInstance[].")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2bb842258b040d699c721f644030fecdc22c9238ba0571551bda772faf17210e-2cc94c6bf194e5f0820ef564dde484baadd6d805623e6bbc5b4fa0616a1b258d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacob Manaker")]], [#link("https://terrytao.wordpress.com/2024/09/08/a-possible-approach-to-finite-time-blowup-for-the-euler-equations/#comment-685774")[#strong[#text("Jacob Manaker")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2024")])]

#text("Ah, screwed up my computation of the free parameters; there should be ")#mi("(5^2+5)\\cdot4=120")#text(" undetermined coefficients in an affine ansatz.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/09/08/a-possible-approach-to-finite-time-blowup-for-the-euler-equations/#comment-685790")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2024")])]

#text("Thanks for the corrections! I had not explicitly written down the non-degeneracy conditions because, in order to be useful for the purposes of creating a finite time blowup, the steady-state solution would need to be reasonably stable (e.g., the linearization around the state should only have a finite number of unstable modes), and this is difficult to formalize in a clean way without actually seeing the solution. But, yes, a solution with vanishing ")#mi("\\varphi")#text(" (i.e., ")#mi("w")#text(" divergence free) would almost certainly not be useful, being a purely “vertical” flow and thus unlikely to have any good stability properties (nothing is offsetting the laminar shearing effects).")

#text("The suggestion of working with a medium-size polynomial with computer assistance is a promising one. The number of variables in the resulting quadratic program may make the program challenging to solve, but perhaps there are some symmetry reductions (spending some of the underdeterminancy if needed) that might simplify it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/09/08/a-possible-approach-to-finite-time-blowup-for-the-euler-equations/#comment-685800")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2024")])]

#text("Will P=NP help here?")
]
]
]
