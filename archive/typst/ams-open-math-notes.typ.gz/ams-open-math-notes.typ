// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/
// Converted to Typst by tao2typ: "2026-10-14T15:19:50.694736+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "AMS open math notes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("AMS open math notes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 December 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/")[#text("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I just learned (from ")#link("https://blogs.ethz.ch/kowalski/2016/12/17/ams-open-math-notes/")[#text("Emmanuel Kowalski’s blog")]#text(") that the AMS has just started a ")#link("http://www.ams.org/open-math-notes")[#text("repository of open-access mathematics lecture notes")]#text(". There are only a few such sets of notes there at present, but hopefully it will grow in the future; I just submitted some ")#link("https://terrytao.wordpress.com/wp-content/uploads/2016/12/linear-algebra-notes.pdf")[#text("old lecture notes of mine")]#text(" from ")#link("http://www.math.ucla.edu/~tao/resource/general/115a.3.02f/")[#text("an undergraduate linear algebra course I taught in 2002")]#text(" (with some updating of format and fixing of various typos).")

#text("[Update, Dec 22: my own notes are now ")#link("https://www.ams.org/open-math-notes/omn-view-listing?listingId=110650")[#text("on the repository")]#text(".]")

#heading(level: 1)[#text("Comments (35)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-475100")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2016")])]

#text("That is a nice one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-475102")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2016")])]

#text("It’d be nice if there were an upvoting system in place, and also a comments section for each set of notes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91ba065c8bb4f7d002b7842a03f300980122cd55943861d33657023f8cd401c6-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-475104")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2016")])]

#text("It may be that existing StackExchanges effectively provide the rating service that you suggest, in the sense that (for example) searching ")#emph[#text("MathOverflow")]#text(" for “Kowalski notes” finds the well-rated question “Elementary Aspects of Galois Deformation”, which includes a link to (what are now) Kowalski’s open math notes.")

#text("A substantial and not-readily-duplicated virtue of the StackExchanges (as it seems to me) is that StackExchange ratings aren’t readily “gamed” (in the all-too-familiar sense that, for example, Amazon product ratings can be gamed).")

#text("In summary, if it becomes common practice for StackExchange comments to reference AMS open math notes (when applicable)—perhaps tags could be introduced to facilitate this?—then two systems that individually are very good for mathematics might together be even better.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-475107")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2016")])]

#text("The notes that are on Open Math Notes are _not_ those on Galois deformations! (They couldn’t be, because those were notes I had taken during a course of J. Tunnell, not something that I had written myself).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91ba065c8bb4f7d002b7842a03f300980122cd55943861d33657023f8cd401c6-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-475116")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2016")])]

#text("My apology is hereby extended, and especially, my appreciation and thanks are extended you and your mathematical collegues for your work in sharing your notes. Perhaps this shows why StackExchange tags for AMS open notes might eventually—as the number and variety of notes increases—prove helpful to the community at large, in that there’s no very obvious (to me) upper bound to the number and variety of open notes that might be posted in the long run.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7eacd066555d2553dad2786361f93ebb2b1d72f9468e6eccf54e23333feb93d-e800c92dc9e7530cccdb19b6a195fa03344541422a4d496266f804bea56c83b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Free Math Notes by AMS | Singapore Maths Tuition")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-475105")[#strong[#text("Free Math Notes by AMS | Singapore Maths Tuition")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2016")])]

#text("[…] learnt from Professor Terence Tao’s blog that there is a new series of free math notes by the American Mathematical […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-475113")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2016")])]

#text("The book “A singular mathematical promenade” by Etienne Ghys is remarkable both by its high mathematical quality and by its many beautiful artistic illustrations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-688369")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2025")])]

#text("WHAT IS THE EASY WAY TO LOGIN TO AMS open math notes for free without being a customer of AMS .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/250ef44e5d9d1498ea529d42aadcaffe2e5b53cc77b294899c5c801f565a46d1-6ecc6a0b1cac73fe5554dc1b87ebbcb29d1c33f3132fd813bcce6c454eaf5b50.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Ericson")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-475114")[#strong[#text("Lars Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2016")])]

#text("Here’s one not on AMS: ")#link("https://web.math.princeton.edu/~nelson/books/rept.pdf")[#text("https://web.math.princeton.edu/~nelson/books/rept.pdf")]

#text("In general it would be nice to see a lot more advanced math courses with interactive tests on EdX. Right now EdX, Coursera, Lagunita and the like have many many special interest courses but very few courses that take you from undergrad through graduate mathematics up to say the level of a pure or applied math Masters degree and pre-PhD oral exam.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/250ef44e5d9d1498ea529d42aadcaffe2e5b53cc77b294899c5c801f565a46d1-6ecc6a0b1cac73fe5554dc1b87ebbcb29d1c33f3132fd813bcce6c454eaf5b50.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Ericson")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-475115")[#strong[#text("Lars Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2016")])]

#text("Another thing that would be great to have somewhere is an interactive skill assessment that probes you on questions throughout college to graduate math and gives you back a picture of where you have been trained.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cd500aabd56b81f6643b31f074d92d701784e77b43ef82f0e830e7297b64a1a-c88b1a2ad26c3a5f6335fb15e3fcfc1701468232fcf2f1505acdc89f12c66e49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of victorivrii")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-475134")[#strong[#text("victorivrii")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2016")])]

#text("I am rather disappointed by an implementation. There are two reasons for this")

#text("1) The Lecture Notes are 𝘰𝘱𝘦𝘯 but not 𝘰𝘱𝘦𝘯 𝘴𝘰𝘶𝘳𝘤𝘦, and therefore an instructor cannot modify them easily, adjusting to the particular cource. Basically these Notes are free rextbooks.")

#text("2) I strongly believe that 𝘱𝘥𝘧 is the most suitable format for scholarly articles and books, but lecture notes and textbooks are rather different. 10 y.a. I believed that 𝘱𝘥𝘧 was the best format for them as well, but 𝘩𝘵𝘮𝘭 has been advancing (html5, MathJax, etc). Sure, 𝘱𝘥𝘧 has been also advanced but its improvement are not that beneficial for math publications, especially because many of the require AA/AR versions 10+, not available for any plutform other than MacOS and Windows, leaving Linux on the cold. Other pdf browsers are not full-featured (no embedded movies/3D-models, no javascript support).")

#text("I believe that instead of 𝘩𝘰𝘴𝘵𝘪𝘯𝘨 online LN, AMS would fare better just 𝘤𝘢𝘵𝘢𝘭𝘰𝘨𝘪𝘯𝘨 them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75f1b214daedeb4f7a5504354d6eb9b490c055f85842c5fb5ab08482a62d1a0c-e518eb203719bacf50805ab23e5ba88e96ac1b62b91c99e7a4f2aed65bdb059d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Douglas Costa")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-475136")[#strong[#text("Douglas Costa")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2016")])]

#text("Whoa, great news!")

#text("To all readers: Don’t forget to archive those PDF links, for example to archive Terry’s “https://terrytao.files.wordpress.com/2016/12/linear-algebra-notes.pdf” just type it after “https://web.archive.org/save/” like this:")

#link("https://web.archive.org/save/https://terrytao.files.wordpress.com/2016/12/linear-algebra-notes.pdf")[#text("Click to access linear-algebra-notes.pdf")]

#text("This to ensure that these collections wont get lost and to ensure that it is there for future generations!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Merry Christmas")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-475139")[#strong[#text("Merry Christmas")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2016")])]

#text("Nice but rough implementation. Why course pages show files names like v3(PDF) instead of just giving a link? Some links are broken, e.g. for Étienne Ghys “A Singular Mathematical Promenade”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc09702093dfb542dc616fc269a31ef95646be0f9f2b1f794be8a10f05ead4c5-1a92920da93c30fd2522c7fd41dbece5f12562cd4cdd072391626377db210f0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Axel")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-475174")[#strong[#text("Axel")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2016")])]

#text("On the Theodorus Spiral, look at the line 0, 3, 24 = n!-1.")

#text("16+1=17 [0,1[ Steinhaus problem")#linebreak()#text(" 25-1=24")#linebreak()#text(" 5*5=3*3+4*4 5 (G1,G2,G3,G4,G6) + 12 = 17 plane symmetry group")

#text("Vitruvian men = 8/5 with (3,4,5) + (1,4,V17) *4")

#text("Willes-Fermat = (3,4,5) = AM (3,4)/QM (3,4) = 0,7. V2 = 98,99… %")

#text("Lambda incompletness…")

#text("———————————–")#linebreak()#text(" 23 (5, 11, 17, 23, 29) only one (p+6,+12,+18,+24)")

#text("23 is factorial, Eisenstein and Gaussian = its a “real” prime.")

#text("3,5,7")#linebreak()#text(" 11,13")#linebreak()#text(" 17,19")#linebreak()#text(" 29,31")

#text("11, 23 are Gaussian and Eisenstein")#linebreak()#text(" Only 23 is factorial and not twice.")

#text("23 is regular and 3 class factors (the first)")#linebreak()#text(" Cunningham 1 (0 iteration) = 11, 13")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc09702093dfb542dc616fc269a31ef95646be0f9f2b1f794be8a10f05ead4c5-1a92920da93c30fd2522c7fd41dbece5f12562cd4cdd072391626377db210f0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Axel")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-475177")[#strong[#text("Axel")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2016")])]

#text("Merry Christmas.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ff25f0818d475b0408bce202c10af506072f94caea8597aac6479826e50129a2-d53018fe917e9522a595deccd50135720327f5a0c0a6719ae7caa77458912f37.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Gent")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-476143")[#strong[#text("Peter Gent")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2017")])]

#text("Hi Terry,")

#text("Thanks for letting us know about this AMS resource and also a big thanks for putting your linear algebra notes up there. I’m currently reading your Analysis book and loving every page so I really look forward to going through the linear algebra stuff next.")

#text("Peter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b83abba898f069b650da462de444de27877d791fc0d50ec073ac00bfcc1fc0e1-270c8af63ca193c4bb5781b7ea0c87f95f5eb13a3340b35de1ad8818f7fe37fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nischay Reddy")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-476218")[#strong[#text("Nischay Reddy")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2017")])]

#text("Hey Terry,")

#text("I am planning to go through these lecture notes and attempt the assignments and examinations, and so, I was wondering, how much time were the students given for the midterm and final?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/250ef44e5d9d1498ea529d42aadcaffe2e5b53cc77b294899c5c801f565a46d1-6ecc6a0b1cac73fe5554dc1b87ebbcb29d1c33f3132fd813bcce6c454eaf5b50.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Ericson")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-476266")[#strong[#text("Lars Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2017")])]

#text("Here is a large list of qualifying exams from UMass. I really wish there was an online program that mapped out skills and training with automatically generated and scored questions. Until then, this will have to do: ")#link("https://www.math.umass.edu/graduate/sample-qualifying-exams")[#text("https://www.math.umass.edu/graduate/sample-qualifying-exams")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cc59ab5dd8c67037217f7b148d2e1eab78983d747f8f3299ef21431ad900991-d12dc41a938cab326bb3eb1b4282747177de6ffaccb50321fe369381f28cd6fe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ramiro")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-476327")[#strong[#text("Ramiro")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2017")])]

#text("Professor Tao, thank you very much for taking part in this. From the perspective of a non-mathematics student who is still interested in the field, an open source is a major incentive to carry on studying it. It is too bad that not everyone on your university understands the externalities of such an initiative, not making public their coursenotes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e61d020eb5d4a79a2ddd4647f419a85128931336990d2b437925383058847a8-c52c25f4123c65058f107cdd6c8c1e1b55b76ad68cb644bd35a8f25afbfa0c9f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chr0538")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-476336")[#strong[#text("chr0538")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2017")])]

#text("Dear Terence Tao,I’m a Chinese.Now I want to know that how to be a good mathematician.")#linebreak()#text(" Sorry,my English is not good. ,,, A Chinese student")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e61d020eb5d4a79a2ddd4647f419a85128931336990d2b437925383058847a8-c52c25f4123c65058f107cdd6c8c1e1b55b76ad68cb644bd35a8f25afbfa0c9f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chr0538")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-476359")[#strong[#text("chr0538")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2017")])]

#text("Dear Mr. Tao, I am a junior high school student who loves math but my IQ is not high. My dream is to learn math and be a mathematician, but I do not know how to do it. Please teach me how to do it. If so, be grateful. A junior high school student who loves mathematics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e5296b75242012daa1e4d627b7cd5b01010b81d8468fd8fd06c48e351fbb369-b7abc69797d36ef2864be9866590a1d776a5f3c1a4d9dc44a1956eba8d7d4369.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Aldrich")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-476378")[#strong[#text("Chris Aldrich")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2017")])]

#text("chr0538, Dr. Tao wrote a great book on ")#emph[#link("http://amzn.to/2jbwSou")[#text("Solving Mathematical Problems")]]#text(". Try starting there and see where it takes you. He’s also written some general math articles here on his blog that you can get something out of. Stick with math if you love it. It gets easier as you go further.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e61d020eb5d4a79a2ddd4647f419a85128931336990d2b437925383058847a8-c52c25f4123c65058f107cdd6c8c1e1b55b76ad68cb644bd35a8f25afbfa0c9f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chr0538")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-476385")[#strong[#text("chr0538")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2017")])]

#text("Thank you very much.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ca77ac7b66908460d97a063baf0e54b195c834b2959aa27df5cdf2281100a1a-508c60d0d5dcaef2c75254b23fa842073f004dc77eac2bb5e18269f081a740b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AMS Open Math Notes")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-476372")[#strong[#text("AMS Open Math Notes")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2017")])]

#text("[…] to Terry Tao for the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c8111291bd8ac89c90f33d2476b70aedd7da5b435ee33a3db015e0995347b8c-5e1148278ca9bea4f9a768713a909bf69f68736dceff0e48470edb38b4769d48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lujana")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-476407")[#strong[#text("Lujana")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2017")])]

#text("Dear Prof Tao,")#linebreak()#text(" Math is my passion and I decided I want to be a mathematician. My love for math started when I noticed patterns with number 9 in different arthimetic operations (It’s my favorite number since ever) when I was in second grade and I still notice new tricks to do mental math quickly. It’s fun but it’s way behind the mathematics of our modern world. I discovered mathematicians are interested in prime numbers. So I kept thinking about them. Last year, I came up with a simple function that generates prime numbers (not consecutive ones though). I wasn’t confident about it though for a few reasons: 1) it doesn’t generate consecutive primes 2) it doesn’t generate primes everytime, most of the outputs are numbers near primes but not actaully primes. So it generates primes and numbers near primes, but as the numbers get bigger the primes that it generates become less, and the numbers near the primes are even becoming more spaced from the primes 3) and to be honest I discovered it accidentally as a result of some mathematical flunks (I didn’t derive it logically, and I have no proof for why it works, I just found it and calculated results and discovered it generates primes). The education where I live is horrible. I can’t afford to buy any math books that I want. Recently I learned about Mills constant amd it encouraged me to try to publish my function. But I couldn’t publish it on arxiv because I’m still a middle school student and I don’t have a university email to be registered author. I just wanted other mathematicans to see it and give me any kind of feedback. My name is Lujana Elwan. I’m currently 15 years old and all I want is to become a mathematician like you and like Guass and Pierre de Fermat and Leonhard Euler. But I still can’t understand advanced mathematics. When I try to read a math paper I fail to understand (the mathematical notation used, the mathematical terms, and overall whta is meant byt it). I can’t study calculus because I can’t buy books and I am forced to study for my school exams as well. I hate school where they make us memorize everything to pass the exams. I am a human not a robot. I want to think intellectually and spend my life doing what I love. Please read this, and give me advice.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-501357")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2018")])]

#text("“… the exact substance of an object is not important, only its properties and functions.”")

#text("should be")

#text("“… the exact substance of an object is not important, only its properties and functions ARE.”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59f9f0b83a52d3783947a9e8ccd9f678d3e8f512f7bd70b53bc6edeaeb96fe45-8ca135ef6847cf14d67a73f7baf6bc57abd733c58d55e960f98f24e063e483e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pink Iguana")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-512344")[#strong[#text("Pink Iguana")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2019")])]

#text("[…] Terry Tao, What’s New, AMS open math notes, here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-689223")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2025")])]

#text("Dr Tao,")

#text("Hi I am a undergrad who is just begin learning LA with these notes. I think these notes hold a couple of great insights, but I would like to ask:")

#text("a) In Page 6 you said: “This will force us to understand various statistics associated with a matrix, such as determinant, trace, characteristic polynomial, eigenvalues, and eigenvectors”, What do you mean “statistics”? I am a freshmen and I haven’t taken “statisctics” course so I don’t know what it means.")

#text("b) In Page 60 the boldfaced title said: The right-shift as a “linear transformation”, but then you wrote: Define the right-shift “operator” without saying what “operators” is. I wasn’t sure if you use these term intentionally or unintentionally.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-689224")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2025")])]

#text("Here, I am using statistic in the informal sense of a numerical quantity associated to the matrix in question.")

#text("Operators are a type of transformation that is often linear: ")#link("https://en.wikipedia.org/wiki/Operator_(mathematics)")[#text("https://en.wikipedia.org/wiki/Operator_(mathematics)")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-689228")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2025")])]

#text("You used the words “statistics” in this blog post down below a lot, do these words also mean some “numberical quantity”?")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/")[#text("A second draft of a non-technical article on universality")]
]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-689233")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2025")])]

#text("In probabilistic contexts, statistics generally refer to numerical quantities, or distributions of quantities, that arise from one or more random variables (or random ensembles), or from distributions of such variables. See ")#link("https://en.wikipedia.org/wiki/Statistic")[#text("https://en.wikipedia.org/wiki/Statistic")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-691707")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2026")])]

#text("Dr Tao,")

#text("I think the proof of the rank-nullity theorem in the notes is quite complex, could you please explain a bit about the ideas or strategies used in the proof?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-691708")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2026")])]

#text("I am ")#link("https://gemini.google.com/share/a2f0e9152af2")[#text("outsourcing this question to an AI")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guanyuming He")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-691710")[#strong[#text("Guanyuming He")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2026")])]

#text("Dear Prof. Tao,")

#text("When we already know the intention behind a proof, we could verify if a LLM gets the correct explanation. However, when we try to use LLMs to learn a proof, how can we know if it captures the correct intention as the prover intended, except for cases where we can see a contradiction?")

#text("Looking at it another way, would a LLM’s explanation still be valuable, if it follows the logic correctly but got the intention wrong?")

#text("Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/12/17/ams-open-math-notes/#comment-691714")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2026")])]

#text("For the particular LLM responses that I share, I am endorsing the broad thrust of their answer, though (as with my own human-generated answers) there may be minor inaccuracies in specific technical details.")

#text("In any event, I assume that, if not asked in the context of the historical record, the purpose of asking for the intention of an argument is to be able to better understand the argument itself. As long as the reader can use the answer provided to do this, the question of whether the answer was a literal 100% match to the author’s intent is secondary.")
]
]
]
]
