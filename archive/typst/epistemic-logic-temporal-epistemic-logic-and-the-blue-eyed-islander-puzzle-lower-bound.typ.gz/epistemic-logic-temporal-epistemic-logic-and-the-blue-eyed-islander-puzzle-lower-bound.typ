// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/
// Converted to Typst by tao2typ: "2026-10-14T15:18:04.863147+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Epistemic logic, temporal epistemic logic, and the blue-eyed islander puzzle lower bound", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Epistemic logic, temporal epistemic logic, and the blue-eyed islander puzzle lower bound")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 May 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/")[#text("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I ")#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/")[#text("recently reposted")]#text(" my favourite logic puzzle, namely the blue-eyed islander puzzle. I am fond of this puzzle because in order to properly understand the correct solution (and to properly understand why the alternative solution is incorrect), one has to think very clearly (but unintuitively) about the nature of knowledge.")

#text("There is however an additional subtlety to the puzzle that was pointed out in comments, in that the correct solution to the puzzle has two components, a (necessary) upper bound and a (possible) lower bound (I’ll explain this further below the fold, in order to avoid blatantly spoiling the puzzle here). Only the upper bound is correctly explained in the puzzle (and even then, there are some slight inaccuracies, as will be discussed below). The lower bound, however, is substantially more difficult to establish, in part because the bound is merely possible and not necessary. Ultimately, this is because to demonstrate the upper bound, one merely has to show that a certain statement is logically deducible from an islander’s state of knowledge, which can be done by presenting an appropriate chain of logical deductions. But to demonstrate the lower bound, one needs to show that certain statements are ")#emph[#text("not")]#text(" logically deducible from an islander’s state of knowledge, which is much harder, as one has to rule out ")#emph[#text("all")]#text(" possible chains of deductive reasoning from arriving at this particular conclusion. In fact, to rigorously establish such impossiblity statements, one ends up having to leave the “syntactic” side of logic (deductive reasoning), and move instead to the dual “semantic” side of logic (creation of models). As we shall see, semantics requires substantially more mathematical setup than syntax, and the demonstration of the lower bound will therefore be much lengthier than that of the upper bound.")

#text("To complicate things further, the particular logic that is used in the blue-eyed islander puzzle is not the same as the logics that are commonly used in mathematics, namely ")#link("http://en.wikipedia.org/wiki/Propositional_calculus")[#text("propositional logic")]#text(" and ")#link("http://en.wikipedia.org/wiki/First-order_logic")[#text("first-order logic")]#text(". Because the logical reasoning here depends so crucially on the concept of knowledge, one must work instead with an ")#link("http://en.wikipedia.org/wiki/Epistemic_modal_logic")[#text("epistemic logic")]#text(" (or more precisely, an ")#emph[#text("epistemic modal logic")]#text(") which can properly work with, and model, the knowledge of various agents. To add even more complication, the role of time is also important (an islander may not know a certain fact on one day, but learn it on the next day), so one also needs to incorporate the language of ")#link("http://en.wikipedia.org/wiki/Temporal_logic")[#text("temporal logic")]#text(" in order to fully model the situation. This makes both the syntax and semantics of the logic quite intricate; to see this, one only needs to contemplate the task of programming a computer with enough epistemic and temporal deductive reasoning powers that it would be able to solve the islander puzzle (or even a smaller version thereof, say with just three or four islanders) without being deliberately “fed” the solution. (The fact, therefore, that humans can grasp the correct solution without any formal logical training is therefore quite remarkable.)")

#text("As difficult as the syntax of temporal epistemic modal logic is, though, the semantics is more intricate still. For instance, it turns out that in order to completely model the epistemic state of a finite number of agents (such as 1000 islanders), one requires an ")#emph[#text("infinite")]#text(" model, due to the existence of arbitrarily long nested chains of knowledge (e.g. “")#mi("{A}")#text(" knows that ")#mi("{B}")#text(" knows that ")#mi("{C}")#text(" knows that ")#mi("{D}")#text(" has blue eyes”), which cannot be automatically reduced to shorter chains of knowledge. Furthermore, because each agent has only an incomplete knowledge of the world, one must take into account multiple ")#emph[#text("hypothetical worlds")]#text(", which differ from the real world but which are considered to be possible worlds by one or more agents, thus introducing ")#link("http://en.wikipedia.org/wiki/Linguistic_modality")[#text("modality")]#text(" into the logic. More subtly, one must also consider worlds which each agent knows to be impossible, but are not ")#link("http://en.wikipedia.org/wiki/Common_knowledge")[#text("commonly known")]#text(" to be impossible, so that (for instance) one agent is willing to admit the possibility that another agent considers that world to be possible; it is the consideration of such worlds which is crucial to the resolution of the blue-eyed islander puzzle. And this is even before one adds the temporal aspect (e.g. “On Tuesday, ")#mi("{A}")#text(" knows that on Monday, ")#mi("{B}")#text(" knew that by Wednesday, ")#mi("{C}")#text(" will know that ")#mi("{D}")#text(" has blue eyes”).")

#text("Despite all this fearsome complexity, it ")#emph[#text("is")]#text(" still possible to set up both the syntax and semantics of temporal epistemic modal logic in such a way that one can formulate the blue-eyed islander problem rigorously, and in such a way that one has both an upper and a lower bound in the solution. The purpose of this post is to construct such a setup and to explain the lower bound in particular. The same logic is also useful for analysing another well-known paradox, the ")#link("http://en.wikipedia.org/wiki/Unexpected_hanging_paradox")[#text("unexpected hanging paradox")]#text(", and I will do so at the end of the post. Note though that there is more than one way to set up epistemic logics, and they are not all equivalent to each other.")

#text("(On the other hand, for puzzles such as the islander puzzle in which there are only a finite number of atomic propositions and no free variables, one at least can avoid the need to admit ")#link("http://en.wikipedia.org/wiki/Predicate_logic")[#text("predicate logic")]#text(", in which one has to discuss quantifiers such as ")#mi("{\\forall}")#text(" and ")#mi("{\\exists}")#text(". A fully formed predicate temporal epistemic modal logic would indeed be of terrifying complexity.)")

#text("Our approach here will be a little different from the approach commonly found in the epistemic logic literature, in which one jumps straight to “arbitrary-order epistemic logic” in which arbitrarily long nested chains of knowledge (“")#mi("{A}")#text(" knows that ")#mi("{B}")#text(" knows that ")#mi("{C}")#text(" knows that \\ldots”) are allowed. Instead, we will adopt a hierarchical approach, recursively defining for ")#mi("{k=0,1,2,\\ldots}")#text(" a “")#mi("{k^{th}}")#text("-order epistemic logic” in which knowledge chains of depth up to ")#mi("{k}")#text(", but no greater, are permitted. The arbitrarily order epistemic logic is then obtained as a limit (a ")#link("http://en.wikipedia.org/wiki/Direct_limit")[#text("direct limit")]#text(" on the syntactic side, and an ")#link("http://en.wikipedia.org/wiki/Inverse_limit")[#text("inverse limit")]#text(" on the semantic side, which is dual to the syntactic side) of the finite order epistemic logics.")

#text("I should warn that this is going to be a rather formal and mathematical post. Readers who simply want to know the answer to the islander puzzle would probably be better off reading the discussion at the ")#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/")[#text("puzzle’s own blog post")]#text(" instead.")

#metadata(none) <tao-f1d077d523b7656d5f86>

#heading(level: 1)[#strong[#text(" — 1. Zeroth-order logic — ")]]

#text("Before we plunge into the full complexity of epistemic logic (or temporal epistemic logic), let us first discuss formal logic in general, and then focus on a particularly simple example of a logic, namely ")#emph[#text("zeroth order logic")]#text(" (better known as ")#link("http://en.wikipedia.org/wiki/Propositional_logic")[#text("propositional logic")]#text("). This logic will end up forming the foundation for a hierarchy of epistemic logics, which will be needed to model such logic puzzles as the blue-eyed islander puzzle.")

#text("Informally, a logic consists of three inter-related components:")

#enum(start: 1, 
[#text("A ")#link("http://en.wikipedia.org/wiki/Formal_language")[#text("language")]#text(". This describes the type of sentences the logic is able to discuss.")],
[#text("A ")#link("http://en.wikipedia.org/wiki/Syntax_(logic)")[#text("syntax")]#text(". This describes the rules by which the logic can deduce conclusions (from given hypotheses).")],
[#text("A ")#link("http://en.wikipedia.org/wiki/Semantics_of_logic")[#text("semantics")]#text(". This describes the sentences which the logic interprets to be true (in given models).")]
)

#text("A little more formally:")

#enum(start: 1, 
[#text("A ")#emph[#text("language")]#text(" is a set ")#mi("{L}")#text(" of ")#link("http://en.wikipedia.org/wiki/Sentence_(mathematical_logic)")[#text("sentences")]#text(", which are certain strings of symbols from a fixed alphabet, that are generated by some rules of grammar.")],
[#text("A ")#emph[#text("syntax")]#text(" is a collection of ")#link("http://en.wikipedia.org/wiki/Inference_rule")[#text("inference rules")]#text(" for generating deductions of the form ")#mi("{T \\vdash S}")#text(" (which we read as “From ")#mi("{T}")#text(", we can deduce ")#mi("{S}")#text("” or “")#mi("{S}")#text(" is a consequence of ")#mi("{T}")#text("“), where ")#mi("{T}")#text(" and ")#mi("{S}")#text(" are sentences in ")#mi("{L}")#text(" (or sets of sentences in ")#mi("{L}")#text(").")],
[#text("A ")#emph[#text("semantics")]#text(" describes what a ")#link("http://en.wikipedia.org/wiki/Model_(logic)")[#text("model")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Interpretation_(logic)")[#text("interpretation")]#text(", or ")#emph[#text("structure")]#text(", or ")#emph[#text("world")]#text(") ")#mi("{M}")#text(" of the logic is, and defines what it means for a sentence ")#mi("{S}")#text(" in ")#mi("{L}")#text(" (or a collection of sentences) to be true in such a model ")#mi("{M}")#text(" (which we write as ")#mi("{M \\models S}")#text(", and we read as “")#mi("{M}")#text(" models ")#mi("{S}")#text("“, “")#mi("{M}")#text(" obeys ")#mi("{S}")#text("“, or “")#mi("{S}")#text(" is true in ")#mi("{M}")#text("“).")]
)

#text("We will abuse notation a little bit and use the language ")#mi("{L}")#text(" as a ")#link("http://en.wikipedia.org/wiki/Metonymy")[#text("metonym")]#text(" for the entire logic; strictly speaking, the logic should be a tuple ")#mi("{(L, \\vdash_L, \\models_L)}")#text(" consisting of the language, syntax, and semantics, but this leads to very unwieldy notation.")

#text("The syntax and semantics are dual to each other in many ways; for instance, the syntax can be used to show that certain statements can be proved, while the semantics can be used to show that certain statements ")#emph[#text("cannot")]#text(" be proved. This distinction will be particularly important in the blue-eyed islander puzzle; in order to show that all blue-eyed islanders commit suicide by the 100th day, one can argue purely on syntactical grounds; but to show that it is possible for the blue-eyed islanders to ")#emph[#text("not")]#text(" commit suicide on the 99th day or any preceding day, one must instead use semantic methods.")

#text("To illustrate the interplay between language, syntax, and semantics, we begin with the simple example of ")#link("http://en.wikipedia.org/wiki/Propositional_calculus")[#text("propositional logic")]#text(". To describe this logic, one must first begin with some collection of ")#link("http://en.wikipedia.org/wiki/Atomic_sentence")[#text("atomic propositions")]#text(". For instance, on an island with three islanders ")#mi("{I_1, I_2, I_3}")#text(", one could consider the propositional logic generated by three atomic propositions ")#mi("{A_1, A_2, A_3}")#text(", where each ")#mi("{A_i}")#text(" is intended to model the statement that ")#mi("{I_i}")#text(" has blue eyes.")

#text("One can have either a finite or an infinite set of atomic propositions. In this discussion, it will suffice to consider the situation in which there are only finitely many atomic propositions, but one can certainly also study logics with infinitely many such propositions.")

#text("The language ")#mi("{L}")#text(" would then consist of all the sentences that can be formed from the atomic propositions using the usual logical connectives (")#mi("{\\wedge}")#text(", ")#mi("{\\vee}")#text(", ")#mi("{\\neg}")#text(", ")#mi("{\\implies}")#text(", ")#mi("{\\top}")#text(", ")#mi("{\\bot}")#text(", etc.) and parentheses, according to the usual rules of logical grammar (which consists of rules such as “If ")#mi("{S}")#text(" and ")#mi("{T}")#text(" are sentences in ")#mi("{L}")#text(", then ")#mi("{(S \\vee T)}")#text(" is also a sentence in ")#mi("{L}")#text("“). For instance, if ")#mi("{A_1,A_2,A_3}")#text(" are atomic propositions, then")

#align(center)[#tao-fit-display[#mitex("((A_1 \\wedge A_2) \\vee (A_3 \\wedge \\neg A_1))")]]

#text("would be an example of a sentence in ")#mi("{L}")#text(". On the other hand,")

#align(center)[#tao-fit-display[#mitex("\\wedge A_1 \\neg A_3 A_1 ) \\vee \\implies A_2 (")]]

#text("is not a sentence in ")#mi("{L}")#text(", despite being a juxtaposition of atomic propositions, connectives, and parentheses, because it is not built up from rules of grammar.")

#text("One could certainly write down a finite list of all the rules of grammar for propositional calculus (as is done for instance at ")#link("http://en.wikipedia.org/wiki/Well-formed_formula#Propositional_calculus")[#text("this Wikipedia page")]#text("), but we will not do so here in order not to disrupt the flow of discussion.")

#text("It is customary to abuse notation slightly and omit parentheses when they are redundant (or when there is enough associativity present that the precise placement of parentheses are not relevant). For instance, ")#mi("{((A_1 \\wedge A_2) \\wedge A_3)}")#text(" could be abbreviated as ")#mi("{A_1 \\wedge A_2 \\wedge A_3}")#text(". We will adopt this type of convention in order to keep the exposition as uncluttered as possible.")

#text("Now we turn to the syntax of propositional logic. This syntax is generated by basic rules of deductive logic, such as ")#link("http://en.wikipedia.org/wiki/Modus_ponens")[#text("modus ponens")]

#align(center)[#tao-fit-display[#mitex("A, (A \\implies B) \\vdash B")]]

#text("or the ")#link("http://en.wikipedia.org/wiki/Law_of_the_excluded_middle")[#text("law of the excluded middle")]

#align(center)[#tao-fit-display[#mitex("\\vdash (A \\vee \\neg A)")]]

#text("and completed by transitivity (if ")#mi("{S \\vdash T}")#text(" and ")#mi("{T \\vdash U}")#text(", then ")#mi("{S \\vdash U}")#text("), monotonicity (")#mi("{S,T \\vdash S}")#text("), and concatenation (if ")#mi("{S \\vdash T}")#text(" and ")#mi("{S \\vdash U}")#text(" then ")#mi("{S \\vdash T,U}")#text("). (Here we adopt the usual convention of representing a set of sentences without using the usual curly braces, instead relying purely on the comma separator.) Another convenient inference rule to place in this logic is the ")#link("http://en.wikipedia.org/wiki/Deduction_theorem")[#text("deduction theorem")]#text(": if ")#mi("{S \\vdash T}")#text(", then one can infer ")#mi("{\\vdash (S \\implies T)}")#text(". (In propositional logic (or predicate logic), this rule is redundant (hence the designation of this rule as a ")#emph[#text("theorem")]#text("), but for the epistemic logics below, it will be convenient to make deduction an explicit inference rule, as it simplifies the other inference rules one will have to add to the system.)")

#text("A typical deduction that comes from this syntax is")

#align(center)[#tao-fit-display[#mitex("(A_1 \\vee A_2 \\vee A_3), \\neg A_2, \\neg A_3 \\vdash A_1")]]

#text("which using the blue-eyed islander interpretation, is the formalisation of the assertion that given that at least one of the islanders ")#mi("{I_1,I_2,I_3}")#text(" has blue eyes, and that ")#mi("{I_2, I_3}")#text(" do not have blue eyes, one can deduce that ")#mi("{I_1}")#text(" has blue eyes.")

#text("As with the laws of grammar, one can certainly write down a finite list of inference rules in propositional calculus; one such list for instance is given at ")#link("http://en.wikipedia.org/wiki/Propositional_calculus#Example_2._Natural_deduction_system")[#text("this Wikipedia page")]#text(". Note though that, much as a given vector space has more than one set of generators, there is more than one possible list of inference rules for propositional calculus, due to some rules being equivalent to, or at least deducible from, other rules; the precise choice of basic inference rules is to some extent a matter of personal taste and will not be terribly relevant for the current discussion.")

#text("Finally, we discuss the semantics of propositional logic. For this particular logic, the models ")#mi("{M}")#text(" are described by ")#link("http://en.wikipedia.org/wiki/Truth_assignment")[#text("truth assignments")]#text(", that assign a truth value ")#mi("{(M \\models A_i) \\in \\{ \\text{true}, \\text{false} \\}}")#text(" to each atomic statement ")#mi("{A_i}")#text(". Once a truth value ")#mi("{(M \\models A_i)}")#text(" to each atomic statement ")#mi("{A_i}")#text(" is assigned, the truth value ")#mi("{(M \\models S)}")#text(" of any other sentence ")#mi("{S}")#text(" in the propositional logic generated by these atomic statements can then be interpreted using the usual ")#link("http://en.wikipedia.org/wiki/Truth_table")[#text("truth tables")]#text(". For instance, returning to the islander example, consider a model ")#mi("{M}")#text(" in which ")#mi("{M \\models A_1}")#text(" is true, but ")#mi("{M \\models A_2}")#text(" and ")#mi("{M \\models A_3}")#text(" are false; informally, ")#mi("{M}")#text(" describes a hypothetical world in which ")#mi("{I_1}")#text(" has blue eyes but ")#mi("{I_2}")#text(" and ")#mi("{I_3}")#text(" do not have blue eyes. Then the sentence ")#mi("{A_1 \\vee A_2 \\vee A_3}")#text(" is true in ")#mi("{M}")#text(",")

#align(center)[#tao-fit-display[#mitex("M \\models (A_1 \\vee A_2 \\vee A_3),")]]

#text("but the statement ")#mi("{A_1 \\implies A_2}")#text(" is false in ")#mi("{M}")#text(",")

#align(center)[#tao-fit-display[#mitex("M \\not \\models (A_1 \\implies A_2).")]]

#text("If ")#mi("{S}")#text(" is a set of sentences, we say that ")#mi("{M}")#text(" models ")#mi("{S}")#text(" if ")#mi("{M}")#text(" models each sentence in ")#mi("{S}")#text(". Thus for instance, if we continue the preceding example, then")

#align(center)[#tao-fit-display[#mitex("M \\models (A_1 \\vee A_2 \\vee A_3), (A_2 \\implies A_3)")]]

#text("but")

#align(center)[#tao-fit-display[#mitex("M \\not \\models (A_1 \\vee A_2 \\vee A_3), (A_1 \\implies A_2).")]]

#text("Note that if there are only finitely many atomic statements ")#mi("{A_1,\\ldots,A_n}")#text(", then there are only finitely many distinct models ")#mi("{M}")#text(" of the resulting propositional logic; in fact, there are exactly ")#mi("{2^n}")#text(" such models, one for each truth assignment. We will denote the space of all possible models of a language ")#mi("{L}")#text(" as ")#mi("{\\text{Mod}(L)}")#text(".")

#text("If one likes, one can designate one of these models to be the “real” world ")#mi("{\\text{Real}}")#text(" so that all the other models become purely hypothetical worlds. In the setting of propositional logic, the hypothetical worlds then have no direct bearing on the real world; the fact that a sentence ")#mi("{S}")#text(" is true or false in a hypothetical world ")#mi("{M}")#text(" does not say anything about what sentences are true or false in ")#mi("{\\text{Real}}")#text(". However, when we turn to epistemic logics later in this post, we will see that hypothetical worlds will play an important role in the real world, because such worlds may be considered to be possible worlds by one or more agents (or, an agent may consider it possible that another agent considers the world to be possible, and so forth.).")

#text("The syntatical and semantic sides of propositional logic are tied together by two fundamental facts:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Soundness and completeness)")]#text(" Let ")#mi("{L}")#text(" be a propositional logic, and let ")#mi("{S}")#text(" be a set of sentences in ")#mi("{L}")#text(", and let ")#mi("{T}")#text(" be another sentence in ")#mi("{L}")#text(".")

#enum(start: 1, 
[#text("(Soundness) If ")#mi("{S \\vdash T}")#text(", then every model ")#mi("{M}")#text(" which obeys ")#mi("{S}")#text(", also obeys ")#mi("{T}")#text(" (i.e. ")#mi("{M \\models S}")#text(" implies ")#mi("{M \\models T}")#text(").")],
[#text("(Completeness) If every model ")#mi("{M}")#text(" that obeys ")#mi("{S}")#text(", also obeys ")#mi("{T}")#text(", then ")#mi("{S \\vdash T}")#text(".")]
)
]

#text("Soundness is easy to prove; one merely needs to verify that each of the inference rules ")#mi("{S \\vdash T}")#text(" in one’s syntax is ")#link("http://en.wikipedia.org/wiki/Validity")[#text("valid")]#text(", in that models that obey ")#mi("{S}")#text(", automatically obey ")#mi("{T}")#text(". This boils down to some tedious inspection of truth tables. (The soundness of the deduction theorem is a little trickier to prove, but one can achieve this by an induction on the number of times this theorem is invoked in a given induction.) Completeness is a bit more difficult to establish; this claim is in fact a special case of the ")#link("http://en.wikipedia.org/wiki/G%C3%B6del%27s_completeness_theorem")[#text("Gödel completeness theorem")]#text(", and is discussed in ")#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/")[#text("this previous blog post")]#text("; we also sketch a proof of completeness below.")

#text("By taking the contrapositive of soundness, we have the following important corollary: if we can find a model ")#mi("{M}")#text(" which obeys ")#mi("{S}")#text(" but does not obey ")#mi("{T}")#text(", then it must not be possible to deduce ")#mi("{T}")#text(" as a logical consequence of ")#mi("{S}")#text(": ")#mi("{S \\not \\vdash T}")#text(". Thus, we can use semantics to demonstrate limitations in syntax.")

#text("For instance, consider a truth assignment ")#mi("{M}")#text(" in which ")#mi("{A_2}")#text(" is true but ")#mi("{A_1}")#text(" is false. Then ")#mi("{M \\models (A_1 \\implies A_2)}")#text(", but ")#mi("{M \\not \\models (A_2 \\implies A_1)}")#text(". This demonstrates that")

#align(center)[#tao-fit-display[#mitex("(A_1 \\implies A_2) \\not \\vdash (A_2 \\implies A_1),")]]

#text("thus an implication such as ")#mi("{A_1 \\implies A_2}")#text(" does not entail its converse ")#mi("{A_2 \\implies A_1}")#text(".")

#text("A ")#link("http://en.wikipedia.org/wiki/Theory_(logic)")[#text("theory")]#text(" (or more precisely, a ")#emph[#text("deductive theory")]#text(") in a logic ")#mi("{L}")#text(", is a set of sentences ")#mi("{{\\mathcal T}}")#text(" in ")#mi("{L}")#text(" which is closed under deductive consequence, thus if ")#mi("{{\\mathcal T} \\vdash S}")#text(" for some sentence ")#mi("{S}")#text(" in ")#mi("{L}")#text(", then ")#mi("{S \\in {\\mathcal T}}")#text(". Given a theory ")#mi("{{\\mathcal T}}")#text(", one can associate the set")

#align(center)[#tao-fit-display[#mitex("\\text{Mod}_L({\\mathcal T}) = \\text{Mod}({\\mathcal T}) := \\{ M \\in \\text{Mod}(L): M \\models {\\mathcal T} \\}")]]

#text("of all possible worlds (or models) in which that theory is true; conversely, given a set ")#mi("{{\\mathcal M} \\subset \\text{Mod}(L)}")#text(" of such models, one can form the ")#emph[#text("theory")]

#align(center)[#tao-fit-display[#mitex("\\text{Th}_L({\\mathcal M}) = \\text{Th}({\\mathcal M}) := \\{ S \\in L: M \\models S \\text{ for all } M \\in {\\mathcal M} \\}")]]

#text("of sentences which are true in all models in ")#mi("{{\\mathcal M}}")#text(". If the logic ")#mi("{L}")#text(" is both sound and complete, these operations invert each other: given any theory ")#mi("{{\\mathcal T}}")#text(", we have ")#mi("{\\text{Th}(\\text{Mod}({\\mathcal T})) = {\\mathcal T}}")#text(", and given any set ")#mi("{{\\mathcal M} \\subset \\text{Mod}(L)}")#text(" of models, ")#mi("{\\text{Th}({\\mathcal M})}")#text(" is a theory and ")#mi("{\\text{Mod}(\\text{Th}({\\mathcal M})) = {\\mathcal M}}")#text(". Thus there is a one-to-one correspondence between theories and sets of possible worlds in a sound complete language ")#mi("{L}")#text(".")

#text("For instance, in our running example, if ")#mi("{{\\mathcal T}}")#text(" is the theory generated by the three statements ")#mi("{A_1 \\vee A_2 \\vee A_3}")#text(", ")#mi("{A_2}")#text(", and ")#mi("{\\neg A_3}")#text(", then ")#mi("{\\text{Mod}({\\mathcal T})}")#text(" consists of precisely two worlds; one in which ")#mi("{A_1, A_2}")#text(" are true and ")#mi("{A_3}")#text(" is false, and one in which ")#mi("{A_2}")#text(" is true and ")#mi("{A_1,A_3}")#text(" are false. Since neither of ")#mi("{A_1}")#text(" or ")#mi("{\\neg A_1}")#text(" are true in both worlds in ")#mi("{\\text{Mod}({\\mathcal T})}")#text(", neither of ")#mi("{A_1}")#text(" or ")#mi("{\\neg A_1}")#text(" lie in ")#mi("{{\\mathcal T} = \\text{Th}(\\text{Mod}({\\mathcal T}))}")#text(". Thus, it is not possible to deduce either of ")#mi("{A_1}")#text(" or ")#mi("{\\neg A_1}")#text(" from the hypotheses ")#mi("{A_1 \\vee A_2 \\vee A_3}")#text(", ")#mi("{A_2}")#text(", and ")#mi("{\\neg A_3}")#text(". More informally, if one knows that there is at least one blue-eyed islander, that ")#mi("{I_2}")#text(" has blue eyes, and ")#mi("{I_3}")#text(" does not have blue eyes, this is not enough information to determine whether ")#mi("{I_1}")#text(" has blue eyes or not.")

#text("One can use theories to prove the completeness theorem. Roughly speaking, one can argue by taking the contrapositive. Suppose that ")#mi("{S \\not \\vdash T}")#text(", then we can find a theory which contains all sentences in ")#mi("{S}")#text(", but does not contain ")#mi("{T}")#text(". In this finite setting, we can easily pass to a maximal such theory (with respect to set inclusion); one then easily verifies that this theory is ")#emph[#text("complete")]#text(" in the sense that for any given sentence ")#mi("{U}")#text(", exactly one of ")#mi("{U}")#text(" and ")#mi("{\\neg U}")#text(" is true. From this complete theory one can then directly build a model ")#mi("{M}")#text(" which obeys ")#mi("{S}")#text(" but does not obey ")#mi("{T}")#text(", giving the desired claim.")

#heading(level: 1)[#strong[#text(" — 2. First-order epistemic logic — ")]]

#text("Having reviewed propositional logic (which we will view as the zeroth-order iteration of epistemic logic), we now turn to the first non-trivial example of epistemic logic, which we shall call ")#emph[#text("first-order epistemic logic")]#text(" (which should not be confused with the more familiar ")#link("http://en.wikipedia.org/wiki/First-order_logic")[#text("first-order predicate logic")]#text("). Roughly speaking, first-order epistemic logic is like zeroth-order logic, except that there are now also some knowledge agents that are able to know certain facts in zeroth-order logic (e.g. an islander ")#mi("{I_1}")#text(" may know that the islander ")#mi("{I_2}")#text(" has blue eyes). However, in this logic one cannot yet express higher-order facts (e.g. we will not yet be able to formulate a sentence to the effect that ")#mi("{I_1}")#text(" knows that ")#mi("{I_2}")#text(" knows that ")#mi("{I_3}")#text(" has blue eyes). This will require a second-order or higher epistemic logic, which we will discuss later in this post.")

#text("Let us now formally construct this logic. As with zeroth-order logic, we will need a certain set of atomic propositions, which for simplicity we will assume to be a finite set ")#mi("{A_1,\\ldots,A_n}")#text(". This already gives the zeroth order language ")#mi("{L_0}")#text(" of sentences that one can form from the ")#mi("{A_1,\\ldots,A_n}")#text(" by the rules of propositional grammar. For instance,")

#align(center)[#tao-fit-display[#mitex("(A_1 \\implies A_2) \\wedge (A_2 \\implies A_3)")]]

#text("is a sentence in ")#mi("{L_0}")#text(". The zeroth-order logic ")#mi("{L_0}")#text(" also comes with a notion of inference ")#mi("{\\vdash_{L_0}}")#text(" and a notion of modeling ")#mi("{\\models_{L_0}}")#text(", which we now subscript by ")#mi("{L_0}")#text(" in order to distinguish it from the first-order notions of inference ")#mi("{\\vdash_{L_1}}")#text(" and modeling ")#mi("{\\models_{L_1}}")#text(" which we will define shortly. Thus, for instance")

#align(center)[#tao-fit-display[#mitex("(A_1 \\implies A_2) \\wedge (A_2 \\implies A_3) \\vdash_{L_0} (A_1 \\implies A_3),")]]

#text("and if ")#mi("{M_0}")#text(" is a truth assignment for ")#mi("{L_0}")#text(" for which ")#mi("{A_1, A_2, A_3}")#text(" are all true, then")

#align(center)[#tao-fit-display[#mitex("M_0 \\models_{L_0} (A_1 \\implies A_2) \\wedge (A_2 \\implies A_3).")]]

#text("We will also assume the existence of a finite number of ")#emph[#text("knowledge agents")]#text(" ")#mi("{K_1,\\ldots,K_m}")#text(", each of which are capable of knowing sentences in the zeroth order language ")#mi("{L_0}")#text(". (In the case of the islander puzzle, and ignoring for now the time aspect of the puzzle, each islander ")#mi("{I_i}")#text(" generates one knowledge agent ")#mi("{K_i}")#text(", representing the state of knowledge of ")#mi("{I_i}")#text(" at a fixed point in time. Later on, when we add in the temporal aspect to the puzzle, we will need different knowledge agents for a single islander at different points in time, but let us ignore this issue for now.) To formalise this, we define the first-order language ")#mi("{L_1}")#text(" to be the language generated from ")#mi("{L_0}")#text(" and the rules of propositional grammar by imposing one additional rule:")

#list(
[#text("If ")#mi("{S}")#text(" is a sentence in ")#mi("{L_0}")#text(", and ")#mi("{K}")#text(" is a knowledge agent, then ")#mi("{K(S)}")#text(" is a sentence in ")#mi("{L_1}")#text(" (which can informally be read as “")#mi("{K}")#text(" knows (or believes) ")#mi("{S}")#text(" to be true”).")]
)

#text("Thus, for instance,")

#align(center)[#tao-fit-display[#mitex("K_2( A_1 ) \\wedge K_1( A_1 \\vee A_2 \\vee A_3 ) \\wedge \\neg A_3")]]

#text("is a sentence in ")#mi("{L_1}")#text("; in the islander interpretation, this sentence denotes the assertion that ")#mi("{I_2}")#text(" knows ")#mi("{I_1}")#text(" to have blue eyes, and ")#mi("{I_1}")#text(" knows that at least one islander has blue eyes, but ")#mi("{I_3}")#text(" does not have blue eyes. On the other hand,")

#align(center)[#tao-fit-display[#mitex("K_1( K_2 ( A_3 ) )")]]

#text("is ")#emph[#text("not")]#text(" a sentence in ")#mi("{L_1}")#text(", because ")#mi("{K_2(A_3)}")#text(" is not a sentence in ")#mi("{L_0}")#text(". (However, we will be able to interpret ")#mi("{K_1(K_2(A_3))}")#text(" in the second-order epistemic language ")#mi("{L_2}")#text(" that we will define later.)")

#text("We give ")#mi("{L_1}")#text(" all the rules of syntax that ")#mi("{L_0}")#text(" presently enjoys. For instance, thanks to modus ponens, we have ")#metadata(none) <tao-13876d0627a48f198e5d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("K_1(A_1) \\wedge (K_1(A_1) \\implies K_1(A_2)) \\vdash_{L_1} K_1(A_2).")]]

#text("Similarly, if ")#mi("{S, T}")#text(" are sentences in ")#mi("{L_0}")#text(" such that ")#mi("{S \\vdash_{L_0} T}")#text(", then one automatically has ")#mi("{S \\vdash_{L_1} T}")#text(".")

#text("However, we would like to add some additional inference rules to reflect our understanding of what “knowledge” means. One has some choice in deciding what rules to lay down here, but we will only add one rule, which informally reflects the assertion that “all knowledge agents are highly logical”:")

#list(
[#strong[#text("First-order epistemic inference rule:")]#text(" If ")#mi("{S_1,\\ldots,S_i,T\\in L_0}")#text(" are sentences such that")

#align(center)[#tao-fit-display[#mitex("S_1,\\ldots,S_i \\vdash_{L_0} T")]]

#text("and ")#mi("{K}")#text(" is a knowledge agent, then")

#align(center)[#tao-fit-display[#mitex("K(S_1), \\ldots, K(S_i) \\vdash_{L_1} K(T).")]]]
)

#text("(We will introduce higher order epistemic inference rules when we turn to higher order epistemic logics.)")

#text("Informally speaking, the epistemic inference rule asserts that if ")#mi("{T}")#text(" can be deduced from ")#mi("{S_1,\\ldots,S_i}")#text(", and ")#mi("{K}")#text(" knows ")#mi("{S_1,\\ldots S_i}")#text(" to be true, then ")#mi("{K}")#text(" must also know ")#mi("{T}")#text(" to be true. For instance, since modus ponens gives us the inference")

#align(center)[#tao-fit-display[#mitex("A_1, (A_1 \\implies A_2) \\vdash_{L_0} A_2")]]

#text("we therefore have, by the first-order epistemic inference rule,")

#align(center)[#tao-fit-display[#mitex("K_1(A_1), K_1(A_1 \\implies A_2) \\vdash_{L_1} K_1(A_2)")]]

#text("(note how this is different from ")#link(<tao-13876d0627a48f198e5d>)[#text("(1)")]#text(" – why?).")

#text("Another example of more relevance to the islander puzzle, we have")

#align(center)[#tao-fit-display[#mitex("(A_1 \\vee A_2 \\vee A_3), \\neg A_2, \\neg A_3 \\vdash_{L_0} A_1")]]

#text("and thus, by the first-order epistemic inference rule,")

#align(center)[#tao-fit-display[#mitex("K_1(A_1 \\vee A_2 \\vee A_3), K_1(\\neg A_2), K_1(\\neg A_3) \\vdash_{L_1} K_1(A_1).")]]

#text("In the islander interpretation, this asserts that if ")#mi("{I_1}")#text(" knows that one of the three islanders ")#mi("{I_1,I_2,I_3}")#text(" has blue eyes, but also knows that ")#mi("{I_2}")#text(" and ")#mi("{I_3}")#text(" do not have blue eyes, then ")#mi("{I_1}")#text(" must also know that he himself (or she herself) has blue eyes.")

#text("One particular consequence of the first-order epistemic inference rule is that if a sentence ")#mi("{T \\in L_0}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Tautology_(logic)")[#text("tautology")]#text(" in ")#mi("{L_0}")#text(" – true in every model of ")#mi("{L_0}")#text(", or equivalently (by completeness) deducible from the inference rules of ")#mi("{L_0}")#text(", and ")#mi("{K}")#text(" is a knowledge agent, then ")#mi("{K(T)}")#text(" is a tautology in ")#mi("{L_1}")#text(": ")#mi("{\\vdash_{L_0} T}")#text(" implies ")#mi("{\\vdash_{L_1} K(T)}")#text(". Thus, for instance, we have ")#mi("{\\vdash_{L_1} K_1(A_1 \\implies A_1)}")#text(", because ")#mi("{A_1}")#text(" is a tautology in ")#mi("{L_0}")#text(" (thus ")#mi("{\\vdash_{L_0} A_1 \\implies A_1}")#text(").")

#text("It is important to note, however, that if a statement ")#mi("{T}")#text(" is not a tautology, but merely ")#emph[#text("true")]#text(" in the “real” world ")#mi("{\\text{Real}}")#text(", this does ")#emph[#text("not")]#text(" imply that ")#mi("{K(T)}")#text(" is also true in the real world: as we shall see later, ")#mi("{\\text{Real} \\models_{L_0} T}")#text(" does not imply ")#mi("{\\text{Real} \\models_{L_1} K(T)}")#text(". (We will define what ")#mi("{\\models_{L_1}}")#text(" means presently.) Intuitively, this reflects the obvious fact that knowledge agents need not be omniscient; it is possible for a sentence ")#mi("{T}")#text(" to be true without a given agent ")#mi("{K}")#text(" being aware of this truth.")

#text("In the converse direction, we also allow for the possibility that ")#mi("{K(T)}")#text(" is true in the real world, without ")#mi("{T}")#text(" being true in the real world, thus it is conceivable that ")#mi("{\\text{Real} \\models_{L_1} K(T)}")#text(" is true but ")#mi("{\\text{Real} \\models_{L_0} T}")#text(" is false. This reflects the fact that a knowledge agent may in fact have incorrect knowledge of the real world. (This turns out not to be an important issue in the islander puzzle, but is of relevance for the unexpected hanging puzzle.)")

#text("In a related spirit, we also allow for the possibility that ")#mi("{K(T)}")#text(" and ")#mi("{K(\\neg T)}")#text(" may both be true in the real world; an agent may conceivably be able to know inconsistent facts. However, from the inference ")#mi("{T, \\neg T \\vdash_{L_0} S}")#text(" of ")#link("http://en.wikipedia.org/wiki/Ex_falso_quodlibet")[#text("ex falso quodlibet")]#text(" and the first-order epistemic inference rule, this would mean that ")#mi("{K(S)}")#text(" is true in this world for every ")#mi("{S}")#text(" in ")#mi("{L_0}")#text(", thus this knowledge agent believes absolutely every statement to be true. Again, such inconsistencies are not of major relevance to the islander puzzle, but as we shall see, their analysis is important for resolving the unexpected hanging puzzle correctly.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" It is perhaps worth re-emphasising the previous points. In some interpretations of knowledge, ")#mi("{K(S)}")#text(" means that ")#mi("{S}")#text(" has somehow been “justified” to be true, and in particular ")#mi("{K(S)}")#text(" should entail ")#mi("{S}")#text(" in such interpretations. However, we are taking a more general (and abstract) point of view, in which we are agnostic as regards to whether ")#mi("{K}")#text(" represents necessary or justified knowledge. In particular, our analysis also applies to “generalised knowledge” operators, such as “belief”. One can of course specialise this general framework to a more specific knowledge concept by adding more axioms, in which case one can obtain sharper conclusions regarding the resolution of various paradoxes, but we will work here primarily in the general setting.")
]

#text("Having discussed the language and syntax of the first-order epistemic logic ")#mi("{L_1}")#text(", we now turn to the semantics, in which we describe the possible models ")#mi("{M_1}")#text(" of ")#mi("{L_1}")#text(". As ")#mi("{L_1}")#text(" is an extension of ")#mi("{L_0}")#text(", any model ")#mi("{M_1}")#text(" of ")#mi("{L_1}")#text(" must contain as a component a model ")#mi("{M_0}")#text(" of ")#mi("{L_0}")#text(", which describes the truth assignment of each of the atomic propositions ")#mi("{A_i}")#text(" of ")#mi("{L_0}")#text("; but it must also describe the state of knowledge of each of the agents ")#mi("{K_i}")#text(" in this logic. One can describe this state in two equivalent ways; either as a ")#emph[#text("theory")]#text(" ")#mi("{\\{ S \\in L_0: M_1 \\models_{L_1} K_i(S) \\}}")#text(" (in ")#mi("{L_0}")#text(") of all the sentences ")#mi("{S}")#text(" in ")#mi("{L_0}")#text(" that ")#mi("{K_i}")#text(" knows to be true (which, by the first-order epistemic inference rule, is closed under ")#mi("{\\vdash_{L_0}}")#text(" and is thus indeed a theory in ")#mi("{L_0}")#text("); or equivalently (by the soundness and completeness of ")#mi("{L_0}")#text("), as a set")

#align(center)[#tao-fit-display[#mitex("\\{ M_{0,i} \\in \\text{Mod}(L_0): M_{0,i} \\models_{L_0} S \\text{ whenever } M_1 \\models_{L_1} K_i(S) \\}")]]

#text("of all the possible models of ")#mi("{L_0}")#text(" in which all the statements that ")#mi("{K_i}")#text(" knows to be true, are in fact true. We will adopt the latter perspective; thus a model ")#mi("{M_1}")#text(" of ")#mi("{L_1}")#text(" consists of a tuple")

#align(center)[#tao-fit-display[#mitex("M_1 = (M_0, {\\mathcal M}_0^{(1)}, \\ldots, {\\mathcal M}_0^{(m)})")]]

#text("where ")#mi("{M_0 \\in \\text{Mod}(L_0)}")#text(" is a model of ")#mi("{L_0}")#text(", and for each ")#mi("{i=1,\\ldots,m}")#text(", ")#mi("{{\\mathcal M}_0^{(i)} \\subset \\text{Mod}(L_0)}")#text(" is a set of models of ")#mi("{L_0}")#text(". To interpret sentences ")#mi("{S \\in L_1}")#text(" in ")#mi("{M_1}")#text(", we then declare ")#mi("{M_1 \\models A_i}")#text(" iff ")#mi("{M_0 \\models A_i}")#text(" for each atomic sentence ")#mi("{A_i}")#text(", and declare ")#mi("{M_1 \\models K_i(S)}")#text(" iff ")#mi("{S}")#text(" is true in every model in ")#mi("{{\\mathcal M}_0^{(i)}}")#text(", for each ")#mi("{i=1,\\ldots,m}")#text(" and ")#mi("{S \\in L_0}")#text(". All other sentences in ")#mi("{L_1}")#text(" are then interpreted by applying the usual truth tables.")

#text("As an example of such a model, consider a world with three islanders ")#mi("{I_1, I_2, I_3}")#text(", each of which has blue eyes, and can each see that each other has blue eyes, but are each unaware of their own eye colour. In this model, ")#mi("{M_0}")#text(" assigns a true value to each of ")#mi("{A_1, A_2, A_3}")#text(". As for ")#mi("{{\\mathcal M}_0^{(1)}}")#text(", which describes the knowledge state of ")#mi("{I_1}")#text(", this set consists of two possible ")#mi("{L_0}")#text("-worlds. One is the “true” ")#mi("{L_0}")#text("-world ")#mi("{M_0}")#text(", in which ")#mi("{A_1,A_2,A_3}")#text(" are all true; but there is also an additional hypothetical ")#mi("{L_0}")#text("-world ")#mi("{M_{0,1}}")#text(", in which ")#mi("{A_2, A_3}")#text(" is true but ")#mi("{A_1}")#text(" is false. With ")#mi("{I_1}")#text("‘s current state of knowledge, neither of these two possibilities can be ruled out. Similarly, ")#mi("{{\\mathcal M}_0^{(2)}}")#text(" and ")#mi("{{\\mathcal M}_0^{(3)}}")#text(" will also consist of two ")#mi("{L_0}")#text("-worlds, one of which is the “true” ")#mi("{L_0}")#text("-world ")#mi("{M_0}")#text(", and the other is not.")

#text("In this particular case, the true ")#mi("{L_0}")#text("-world ")#mi("{M_0}")#text(" is included as a possible world in each of the knowledge agents’ set of possible worlds ")#mi("{{\\mathcal M}_0^{(i)}}")#text(", but in situations in which the agents knowledge is incorrect or inconsistent, it can be possible for ")#mi("{M_0}")#text(" to not be an element of one or more of the ")#mi("{{\\mathcal M}^{(i)}_0}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One can view an ")#mi("{L_1}")#text(" model ")#mi("{M_1}")#text(" as consisting of the “real world” – the ")#mi("{L_0}")#text("-model ")#mi("{M_0}")#text(" – together with ")#mi("{m}")#text(" clouds ")#mi("{{\\mathcal M}_0^{(i)}}")#text(", ")#mi("{i=1,\\ldots,m}")#text(" of “hypothetical worlds”, one for each knowledge agent ")#mi("{K_i}")#text(". If one chooses, one can “enter the head” of any one of these knowledge agents ")#mi("{K_i}")#text(" to see what he or she is thinking. One can then select any one of the ")#mi("{L_0}")#text("-worlds ")#mi("{M_{0,i}}")#text(" in ")#mi("{{\\mathcal M}_0^{(i)}}")#text(" as a “possible world” in ")#mi("{K_i}")#text("‘s worldview, and explore that world further. Later on we will iterate this process, giving a tree-like structure to the higher order epistemic models.")
]

#text("Let ")#mi("{\\text{Mod}(L_1)}")#text(" be the set of all models of ")#mi("{L_1}")#text(". This is quite a large set; if there are ")#mi("{n}")#text(" atomic statements ")#mi("{A_1,\\ldots,A_n}")#text(" and ")#mi("{m}")#text(" knowledge agents ")#mi("{K_1,\\ldots,K_m}")#text(", then there are ")#mi("{2^n}")#text(" possibilities for the ")#mi("{L_0}")#text("-world ")#mi("{M_0}")#text(", and each knowledge agent ")#mi("{K_i}")#text(" has its own independent set ")#mi("{{\\mathcal M}_0^{(i)}}")#text(" of possible worlds, of which there are ")#mi("{2^{2^n}}")#text(" different possibilities, leading to ")#mi("{2^{n + m 2^n}}")#text(" distinct models ")#mi("{M_1}")#text(" for ")#mi("{L_1}")#text(" in all. For instance, with three islanders wondering about eye colours, this leads to ")#mi("{2^{27}}")#text(" possibilities (although, once everyone learns each other’s eye colour, the number of possible models goes down quite significantly).")

#text("It can be shown (but is somewhat tedious to do so) that the syntax and semantics of the first-order epistemic logic ")#mi("{L_1}")#text(" is still sound and complete, basically by mimicking (and using) the proof of the soundness and completeness of ")#mi("{L_0}")#text("; we sketch a proof of this below when we discuss higher order logics.")

#heading(level: 1)[#strong[#text(" — 3. Higher-order epistemic logic — ")]]

#text("We can iterate the above procedure and construct a language, syntax, and semantics for ")#mi("{k^{th}}")#text(" order epistemic logic ")#mi("{L_k}")#text(" generated by some atomic propositions ")#mi("{A_1,\\ldots,A_n}")#text(" and knowledge agents ")#mi("{K_1,\\ldots,K_m}")#text(", recursively in terms of the preceding epistemic logic ")#mi("{L_{k-1}}")#text(". More precisely, let ")#mi("{k \\geq 1}")#text(" be a natural number, and suppose that the logic ")#mi("{L_{k-1}}")#text(" has already been defined. We then define the language of ")#mi("{L_k}")#text(" as the extension of ")#mi("{L_{k-1}}")#text(" generated by the laws of propositional grammar and the following rule:")

#list(
[#text("If ")#mi("{S}")#text(" is a sentence in ")#mi("{L_{k-1}}")#text(", and ")#mi("{K}")#text(" is a knowledge agent, then ")#mi("{K(S)}")#text(" is a sentence in ")#mi("{L_k}")#text(".")]
)

#text("Thus, for instance, in the running example of three propositions ")#mi("{A_1,A_2,A_3}")#text(" and three knowledge agents ")#mi("{K_1,K_2,K_3}")#text(",")

#align(center)[#tao-fit-display[#mitex("K_1(A_3) \\wedge K_1(K_2(A_3))")]]

#text("is a sentence in ")#mi("{L_2}")#text(" (and hence in ")#mi("{L_3}")#text(", ")#mi("{L_4}")#text(", etc.) but not in ")#mi("{L_1}")#text(".")

#text("As for the syntax, we adopt all the inference rules of ordinary propositional logic, together with one new rule:")

#list(
[#strong[#mi("{k^{th}}")#text("-order epistemic inference rule:")]#text(" If ")#mi("{S_1,\\ldots,S_i,T\\in L_{k-1}}")#text(" are sentences such that")

#align(center)[#tao-fit-display[#mitex("S_1,\\ldots,S_i \\vdash_{L_{k-1}} T")]]

#text("and ")#mi("{K}")#text(" is a knowledge agent, then")

#align(center)[#tao-fit-display[#mitex("K(S_1), \\ldots, K(S_i) \\vdash_{L_k} K(T).")]]]
)

#text("Thus, for instance, starting with")

#align(center)[#tao-fit-display[#mitex("A_1, (A_1 \\implies A_2) \\vdash_{L_0} A_2")]]

#text("one has")

#align(center)[#tao-fit-display[#mitex("K_1(A_1), K_1(A_1 \\implies A_2) \\vdash_{L_1} K_1(A_2),")]]

#text("and then")

#align(center)[#tao-fit-display[#mitex("K_2(K_1(A_1)), K_2(K_1(A_1 \\implies A_2)) \\vdash_{L_2} K_2(K_1(A_2)),")]]

#text("and so forth. Informally, this rule asserts that all agents are highly logical, that they know that all agents are highly logical, and so forth. A typical deduction from these inference rules, which is again of relevance to the islander puzzle, is")

#align(center)[#tao-fit-display[#mitex("K_1( K_2( A_1 \\vee A_2 \\vee A_3 ) ), K_1( K_2( \\neg A_3 ) ) \\vdash_{L_2}")]]

#align(center)[#tao-fit-display[#mitex("K_1( (\\neg K_2(A_2)) \\implies (\\neg K_2( \\neg A_1 )) ).")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" This is a very minimal epistemic syntax, and is weaker than some epistemic logics considered in the literature. For instance, we do not have any version of the ")#emph[#text("positive introspection rule")]

#align(center)[#tao-fit-display[#mitex("K(S) \\vdash K(K(S));")]]

#text("thus we allow the possibility that an agent knows ")#mi("{S}")#text(" “subconsciously”, in that the agent knows ")#mi("{S}")#text(" but does not know that he or she knows ")#mi("{S}")#text(". Similarly, we do not have any version of the ")#emph[#text("negative introspection rule")]

#align(center)[#tao-fit-display[#mitex("\\neg K(S) \\vdash K(\\neg K(S)),")]]

#text("so we allow the possibility that an agent is “unaware of his or her own ignorance”. One can of course add these additional rules ")#emph[#text("ex post facto")]#text(" and see how this strengthens the syntax and limits the semantics, but we will not need to do so here.")

#text("There is also no reason to expect the knowledge operators to commute:")

#align(center)[#tao-fit-display[#mitex("K(K^{\\prime}(S)) \\not \\vdash K^{\\prime}(K(S)).")]]
]

#text("Now we turn to the semantics. A model ")#mi("{M_k}")#text(" of the language ")#mi("{L_k}")#text(" consists of a ")#mi("{L_0}")#text("-model ")#mi("{M_0 \\in \\text{Mod}(L_0)}")#text(", together with sets of possible ")#mi("{L_{k-1}}")#text("-models ")#mi("{{\\mathcal M}_{k-1}^{(1)},\\ldots,{\\mathcal M}_{k-1}^{(m)} \\subset \\text{Mod}(L_{k-1})}")#text(" associated to their respective knowledge agents ")#mi("{K_1,\\ldots,K_m}")#text(". To describe how ")#mi("{M_k}")#text(" models sentences, we declare ")#mi("{M_k \\models_{L_k} A_i}")#text(" iff ")#mi("{M_0 \\models_{L_0} A_i}")#text(", and for any sentence ")#mi("{S}")#text(" in ")#mi("{L_{k-1}}")#text(" and ")#mi("{i = 1,\\ldots,m}")#text(", we declare ")#mi("{M_k \\models_{L_k} K_i(S)}")#text(" iff one has ")#mi("{M_{k-1,i} \\models S}")#text(" for every ")#mi("{M_{k-1} \\in {\\mathcal M}_{k-1}^{(i)}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" ")#metadata(none) <tao-5f67fa77872a6a97a04e>#text(" We consider an islander model with ")#mi("{n}")#text(" atomic propositions ")#mi("{A_1,\\ldots,A_n}")#text(" (with each ")#mi("{A_i}")#text(" representing the claim that ")#mi("{I_i}")#text(" has blue eyes) and ")#mi("{n}")#text(" knowledge agents ")#mi("{K_1,\\ldots,K_n}")#text(" (with ")#mi("{K_i}")#text(" representing the knowledge state of ")#mi("{I_i}")#text(" at a fixed point in time). There are ")#mi("{2^n}")#text(" ")#mi("{L_0}")#text("-models ")#mi("{M_0}")#text(", determined by the truth values they assign to the ")#mi("{n}")#text(" atomic propositions ")#mi("{A_1,\\ldots,A_n}")#text(". For each ")#mi("{k \\geq 0}")#text(", we can then recursively associate a ")#mi("{L_k}")#text("-model ")#mi("{M_k(M_0)}")#text(" to each ")#mi("{L_0}")#text("-model ")#mi("{M_0}")#text(", by setting ")#mi("{M_0(M_0) := M_0}")#text(", and then for ")#mi("{k \\geq 1}")#text(", setting ")#mi("{M_k(M_0)}")#text(" to be the ")#mi("{L_k}")#text("-model with ")#mi("{L_0}")#text("-model ")#mi("{M_0}")#text(", and with ")#mi("{{\\mathcal M}_{k-1}^{(i)}}")#text(" consisting of the pair ")#mi("{\\{ M_{k-1}(M_{0,i}^-), M_{k-1}(M_{0,i}^+) \\}}")#text(", where ")#mi("{M_{0,i}^-}")#text(" (resp. ")#mi("{M_{0,i}^+}")#text(") is the ")#mi("{L_0}")#text("-model which is identical to ")#mi("{M_0}")#text(" except that the truth value of ")#mi("{A_i}")#text(" is set to false (resp. true). Informally, ")#mi("{M_k(M_0)}")#text(" models the ")#mi("{k^{th}}")#text("-order epistemology of the ")#mi("{L_0}")#text("-world ")#mi("{M_0}")#text(", in which each islander sees each other’s eye colour (and knows that each other islander can see all other islander’s eye colour, and so forth for ")#mi("{k}")#text(" iterations), but is unsure as to his or her own eye colour (which is why the set ")#mi("{{\\mathcal M}_{k-1}^{(i)}}")#text(" of ")#mi("{A_i}")#text("‘s possible ")#mi("{L_{k-1}}")#text("-worlds branches into two possibilities). As one recursively explores the clouds of hypothetical worlds in these models, one can move further and further away from the “real” world. Consider for instance the situation when ")#mi("{n=3}")#text(" and ")#mi("{M_0 \\models A_1,A_2,A_3}")#text(" (thus in the “real” world, all three islanders have blue eyes), and ")#mi("{k=3}")#text(". From the perspective of ")#mi("{K_1}")#text(", it is possible that one is in the world ")#mi("{M_2(M_{0,1}^-)}")#text(", in which ")#mi("{I_1}")#text(" does not have blue eyes: ")#mi("{M_{0,1}^- \\models \\neg A_1, A_2, A_3}")#text(". In that world, we can then pass to the perspective of ")#mi("{K_2}")#text(", and then one could be in the world ")#mi("{M_1( M_{0,1,2}^{--} )}")#text(", in which neither ")#mi("{I_1}")#text(" nor ")#mi("{I_2}")#text(" have blue eyes: ")#mi("{M_{0,1,2}^{--} \\models \\neg A_1, \\neg A_2, A_3}")#text(". Finally, inside this doubly nested hypothetical world, one can consider the perspective of ")#mi("{K_3}")#text(", in which one could be in the world ")#mi("{M_{0,1,2,3}^{---}}")#text(", in which none of ")#mi("{I_1,I_2,I_3}")#text(" have blue eyes: ")#mi("{M_{0,1,2,3}^{---} \\models \\neg A_1, \\neg A_2, \\neg A_3}")#text(". This is the total opposite of the “real” model ")#mi("{M_0}")#text(", but cannot be ruled out in at this triply nested level. In particular, we have")

#align(center)[#tao-fit-display[#mitex("M_3(M_0) \\models \\neg K_1(K_2(K_3(A_1 \\vee A_2 \\vee A_3)))")]]

#text("despite the fact that")

#align(center)[#tao-fit-display[#mitex("M_3(M_0) \\models A_1 \\vee A_2 \\vee A_3")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("M_3(M_0) \\models K_i(A_1 \\vee A_2 \\vee A_3)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("M_3(M_0) \\models K_i(K_j(A_1 \\vee A_2 \\vee A_3))")]]

#text("for all ")#mi("{i,j \\in \\{1,2,3\\}}")#text(". (In particular, the statement ")#mi("{A_1 \\vee A_2 \\vee A_3}")#text(", which asserts “at least one islander has blue eyes”, is not ")#link("http://en.wikipedia.org/wiki/Common_knowledge_(logic)")[#text("common knowledge")]#text(" in ")#mi("{M_3(M_0)}")#text(".")
]

#text("We have the basic soundness and completeness properties:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" For each ")#mi("{k \\geq 0}")#text(", ")#mi("{L_k}")#text(" is both sound and complete.")
]

#emph[#text("Proof:")]#text(" (Sketch) This is done by induction on ")#mi("{k}")#text(". For ")#mi("{k=0}")#text(", this is just the soundness and completeness of propositional logic. Now suppose inductively that ")#mi("{k \\geq 1}")#text(" and the claim has already been proven for ")#mi("{k-1}")#text(". Soundness can be verified as in the propositional logic case (with the validity of the ")#mi("{k^{th}}")#text(" epistemic inference rule being justified by induction). For completeness, one again uses the trick of passing to a maximal ")#mi("{L_k}")#text("-theory ")#mi("{{\\mathcal T}}")#text(" that contains one set ")#mi("{S}")#text(" of sentences in ")#mi("{L_k}")#text(", but not another sentence ")#mi("{T}")#text(". This maximal ")#mi("{L_k}")#text("-theory ")#mi("{{\\mathcal T}}")#text(" uniquely determines an ")#mi("{L_0}")#text("-model ")#mi("{M_0}")#text(" by inspecting whether each ")#mi("{A_i}")#text(" or its negation lies in the theory, and also determines ")#mi("{L_{k-1}}")#text("-theories ")#mi("{\\{ S \\in L_{k-1}: K_i(S) \\in {\\mathcal T} \\}}")#text(" for each ")#mi("{i=1,\\ldots,m}")#text(". By induction hypothesis, each of these theories can be identified with a collection ")#mi("{{\\mathcal M}_{k-1}^{(i)}}")#text(" of ")#mi("{L_{k-1}}")#text("-models, thus creating a ")#mi("{L_k}")#text("-model ")#mi("{M_k}")#text(" that obeys ")#mi("{T}")#text(" but not ")#mi("{S}")#text(", giving (the contrapositive of) completeness. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 4. Arbitrary order epistemic logic — ")]]

#text("An easy induction shows that the ")#mi("{k^{th}}")#text(" order logic ")#mi("{L_k}")#text(" extends the previous logic ")#mi("{L_{k-1}}")#text(", in the sense that every sentence in ")#mi("{L_{k-1}}")#text(" is a sentence in ")#mi("{L_k}")#text(", every deduction on ")#mi("{L_{k-1}}")#text(" is also a deduction in ")#mi("{L_k}")#text(", and every model of ")#mi("{L_k}")#text(" projects down (by “forgetting” some aspects of the model) to a model of ")#mi("{L_{k-1}}")#text(". We can then form a limiting logic ")#mi("{L_\\omega}")#text(", whose language is the union of all the ")#mi("{L_k}")#text(" (thus, ")#mi("{S}")#text(" is a sentence in ")#mi("{L_\\omega}")#text(" iff ")#mi("{S}")#text(" lies in ")#mi("{L_k}")#text(" for some ")#mi("{k}")#text("), whose deductive implications are the union of all the ")#mi("{L_k}")#text(" deductive implications (thus, ")#mi("{S \\vdash_{L_\\infty} T}")#text(" if we have ")#mi("{(S \\cap L_k) \\vdash_{L_k} T}")#text(" for some ")#mi("{k}")#text("), and whose models are the ")#link("http://en.wikipedia.org/wiki/Inverse_limit")[#text("inverse limits")]#text(" of the ")#mi("{L_k}")#text(" models (thus, a model ")#mi("{M_\\infty}")#text(" of ")#mi("{L_\\infty}")#text(" is an infinite sequence of models ")#mi("{M_k}")#text(" of ")#mi("{L_k}")#text(" for each ")#mi("{k}")#text(", such that each ")#mi("{M_k}")#text(" projects down to ")#mi("{M_{k-1}}")#text(" for ")#mi("{k \\geq 1}")#text(". It is not difficult to see that the soundness and completeness of each of the ")#mi("{L_k}")#text(" implies the soundness and completeness of the limit ")#mi("{L_\\infty}")#text(" (assuming the axiom of choice, of course, in our metamathematics).")

#text("The logic ")#mi("{L_\\infty}")#text(" now allows one to talk about arbitrarily deeply nested strings of knowledge: if ")#mi("{S}")#text(" is a sentence in ")#mi("{L_\\infty}")#text(", and ")#mi("{K}")#text(" is a knowledge agent, then ")#mi("{K(S)}")#text(" is also a sentence in ")#mi("{L_\\infty}")#text(". This allows for the following definition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3 (Common knowledge)")]#text(" If ")#mi("{S}")#text(" is a sentence in ")#mi("{L_\\infty}")#text(", then ")#mi("{C(S)}")#text(" is the set of all sentences of the form")

#align(center)[#tao-fit-display[#mitex("K_{i_1}( K_{i_2} ( \\ldots ( K_{i_k}( S) ) \\ldots ) )")]]

#text("where ")#mi("{k \\geq 0}")#text(" and ")#mi("{K_{i_1},\\ldots,K_{i_k}}")#text(" are knowledge agents (possibly with repetition).")
]

#text("Thus, for instance, using the epistemic inference rules, every tautology in ")#mi("{L_\\infty}")#text(" is commonly known as such: if ")#mi("{\\vdash_{L_\\infty} S}")#text(", then ")#mi("{\\vdash_{L^\\infty} C(S)}")#text(".")

#text("Let us now work in the islander model in which there are ")#mi("{n}")#text(" atomic propositions ")#mi("{A_1,\\ldots,A_n}")#text(" and ")#mi("{n}")#text(" knowledge agents ")#mi("{K_1,\\ldots,K_n}")#text(". To model the statement that “it is commonly known that each islander knows each other islander’s eye colour”, one can use the sets of sentences ")#metadata(none) <tao-de23e270986c386aae04>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("C( A_i \\implies K_j(A_i) )")]]

#text("and ")#metadata(none) <tao-58db1fdb5de6c42d106e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("C( \\neg A_i \\implies K_j(\\neg A_i) )")]]

#text("for all distinct ")#mi("{i,j \\in \\{1,\\ldots,n\\}}")#text(".")

#text("For any ")#mi("{0 \\leq l \\leq n}")#text(", let ")#mi("{B_{\\geq l}}")#text(" denote the sentence that there are at least ")#mi("{l}")#text(" blue-eyed islanders; this can be encoded as a suitable finite combination of the ")#mi("{A_1,\\ldots,A_n}")#text(". For instance, ")#mi("{B_{\\geq 0}}")#text(" can be expressed by any tautology, ")#mi("{B_{\\geq 1}}")#text(" can be expressed by ")#mi("{A_1 \\vee \\ldots \\vee A_n}")#text(", ")#mi("{B_{\\geq n}}")#text(" can be expressed by ")#mi("{A_1 \\wedge \\ldots \\wedge A_n}")#text(", and intermediate ")#mi("{B_{\\geq l}}")#text(" can be expressed by more complicated formulae. Let ")#mi("{B_l}")#text(" denote the statement that there are ")#emph[#text("exactly")]#text(" ")#mi("{k}")#text(" blue-eyed islanders; for instance, if ")#mi("{n=3}")#text(", then ")#mi("{B_1}")#text(" can be expressed as")

#align(center)[#tao-fit-display[#mitex("(A_1 \\wedge \\neg A_2 \\wedge \\neg A_3) \\vee (\\neg A_1 \\wedge A_2 \\wedge \\neg A_3) \\vee (\\neg A_1 \\wedge \\neg A_2 \\wedge A_3).")]]

#text("The following theorem asserts, roughly speaking, that if there are ")#mi("{m}")#text(" blue-eyed islanders, and it is commonly known that there are at least ")#mi("{l}")#text(" blue-eyed islanders, then all blue-eyed islanders can deduce their own eye colour if ")#mi("{m \\leq l}")#text(", but not otherwise.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4")]#text(" Let ")#mi("{{\\mathcal T}}")#text(" be the set of sentences consisting of the union of ")#link(<tao-de23e270986c386aae04>)[#text("(2)")]#text(" and ")#link(<tao-58db1fdb5de6c42d106e>)[#text("(3)")]#text(" for all distinct ")#mi("{i,j \\in \\{1,\\ldots,n\\}}")#text(". Let ")#mi("{0 \\leq m, l \\leq n}")#text(". Let ")#mi("{S}")#text(" denote the sentence")

#align(center)[#tao-fit-display[#mitex("S = \\bigwedge_{i=1}^n (A_i \\implies K_i(A_i))")]]

#text("(informally, ")#mi("{S}")#text(" asserts that all blue-eyed islanders know their own eye colour).")

#enum(start: 1, 
[#text("If ")#mi("{m \\leq l}")#text(", then")

#align(center)[#tao-fit-display[#mitex("{\\mathcal T}, B_m, C(B_{\\geq l}) \\vdash_{L_\\infty} S.")]]],
[#text("If ")#mi("{m > l}")#text(", then")

#align(center)[#tao-fit-display[#mitex("{\\mathcal T}, B_m, C(B_{\\geq l}) \\not \\vdash_{L_\\infty} S.")]]]
)
]

#emph[#text("Proof:")]#text(" The first part of the theorem can be established informally as follows: if ")#mi("{B_m}")#text(" holds, then each blue-eyed islander sees ")#mi("{m-1}")#text(" other blue-eyed islanders, but also knows that there are at least ")#mi("{l}")#text(" blue-eyed islanders. If ")#mi("{m \\leq l}")#text(", this forces each blue-eyed islander to conclude that his or her own eyes are blue (and in fact if ")#mi("{m<l}")#text(", the blue-eyed islander’s knowledge is now inconsistent, but the conclusion is still valid thanks to ")#emph[#text("ex falso quodlibet")]#text("). It is a routine matter to formalise this argument using the axioms ")#link(<tao-de23e270986c386aae04>)[#text("(2)")]#text(", ")#link(<tao-58db1fdb5de6c42d106e>)[#text("(3)")]#text(" and the epistemic inference rule; we leave the details as an exercise.")

#text("To prove the second part, it suffices (by soundness) to construct a ")#mi("{L_\\infty}")#text("-model ")#mi("{M_\\infty}")#text(" which satisfies ")#mi("{{\\mathcal T}}")#text(", ")#mi("{B_m}")#text(", and ")#mi("{C(B_{\\geq l})}")#text(" but not ")#mi("{S}")#text(". By definition of an ")#mi("{L_\\infty}")#text("-model, it thus suffices to construct, for all sufficiently large natural numbers ")#mi("{k}")#text(", an ")#mi("{L_\\infty}")#text("-model ")#mi("{M_k}")#text(" which satisfies ")#mi("{{\\mathcal T} \\cap L_k}")#text(", ")#mi("{B_m}")#text(", and ")#mi("{C(B_{\\geq l}) \\cap L_k}")#text(", but not ")#mi("{S}")#text(", and which are consistent with each other in the sense that each ")#mi("{M_k}")#text(" is the restriction of ")#mi("{M_{k+1}}")#text(" to ")#mi("{L_k}")#text(".")

#text("We can do this by a modification of the construction in Example ")#link(<tao-5f67fa77872a6a97a04e>)[#text("1")]#text(". For any ")#mi("{L_0}")#text("-model ")#mi("{M_0}")#text(", we can recursively define an ")#mi("{L_k}")#text("-model ")#mi("{M_{k, \\geq l}(M_0)}")#text(" for any ")#mi("{k \\geq 0}")#text(" by setting ")#mi("{M_{0,\\geq l}(M_0) := M_0}")#text(", and then for each ")#mi("{k \\geq 1}")#text(", setting ")#mi("{M_{k,\\geq l}(M_0)}")#text(" to be the ")#mi("{L_k}")#text("-model with ")#mi("{L_0}")#text("-model ")#mi("{M_0}")#text(", and with possible worlds ")#mi("{{\\mathcal M}_{k-1}^{(i)}}")#text(" given by")

#align(center)[#tao-fit-display[#mitex("{\\mathcal M}_{k-1}^{(i)} := \\{ M_{k-1, \\geq l}( M_{0,i} ): M_{0,i} \\in \\{M_{0,i}^+, M_{0,i}^-\\}; M_{0,i} \\models_{L_0} B_{\\geq l} \\};")]]

#text("this is the same construction as in Example ")#link(<tao-5f67fa77872a6a97a04e>)[#text("1")]#text(", except that at all levels of the recursive construction, we restrict attention to worlds that obey ")#mi("{B_{\\geq l}}")#text(". A routine induction shows that the ")#mi("{M_{k,\\geq l}(M_0)}")#text(" determine a limit ")#mi("{M_{\\infty,\\geq l}(M_0)}")#text(", which is an ")#mi("{L_\\infty}")#text(" model that obeys ")#mi("{{\\mathcal T}}")#text(" and ")#mi("{C(B_{\\geq l})}")#text(". If ")#mi("{M_0 \\models_{L_0} B_m}")#text(", then clearly ")#mi("{M_{\\infty, \\geq l}(M_0) \\models_{L_\\infty} B_m}")#text(" as well. But if ")#mi("{m > l}")#text(", then we see that ")#mi("{M_{\\infty, \\geq l}(M_0) \\not \\models_{L_\\infty} S}")#text(", because for any index ")#mi("{i}")#text(" with ")#mi("{M_0 \\models_{L_0} A_i}")#text(", we see that if ")#mi("{k-1}")#text(", then ")#mi("{{\\mathcal M}_{k-1}^{(i)}(M_0)}")#text(" contains worlds in which ")#mi("{A_i}")#text(" is false, and so ")#mi("{M_{k,\\geq l}(M_0) \\not \\models_{L_k} K_i(A_i)}")#text(" for any ")#mi("{k \\geq 1}")#text(". ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 5. Temporal epistemic logic — ")]]

#text("The epistemic logic discussed above is sufficiently powerful to model the knowledge environment of the islanders in the blue-eyed islander puzzle at a ")#emph[#text("single instant in time")]#text(", but in order to fully model the islander puzzle, we now must now incorporate the role of time. To avoid confusion, I feel that this is best accomplished by adopting a “spacetime” perspective, in which time is treated as another coordinate rather than having any particularly privileged role in the theory, and the model incorporates all time-slices of the system at once. In particular, if we allow the time parameter ")#mi("{t}")#text(" to vary along some set ")#mi("{T}")#text(" of times, then each actor ")#mi("{I_i}")#text(" in the model should now generate not just a single knowledge agent ")#mi("{K_i}")#text(", but instead a ")#emph[#text("family")]#text(" ")#mi("{(K_{i,t})_{t \\in T}}")#text(" of knowledge agents, one for each time ")#mi("{t \\in T}")#text(". Informally, ")#mi("{K_{i,t}(S)}")#text(" should then model the assertion that “")#mi("{I_i}")#text(" knows ")#mi("{S}")#text(" at time ")#mi("{t}")#text("“. This of course leads to many more knowledge agents than before; if for instance one considers an islander puzzle with ")#mi("{n}")#text(" islanders over ")#mi("{M}")#text(" distinct points in time, this would lead to ")#mi("{nM}")#text(" distinct knowledge agents ")#mi("{K_{i,t}}")#text(". And if the set of times ")#mi("{T}")#text(" is countably or uncountably infinite, then the number of knowledge agents would similarly be countably or uncountably infinite. Nevertheless, there is no difficulty extending the previous epistemic logics ")#mi("{L_k}")#text(" and ")#mi("{L_\\infty}")#text(" to cover this situation. In particular we still have a complete and sound logical framework to work in.")

#text("Note that if we do so, we allow for the ability to nest knowledge operators at different times in the past or future. For instance, if we have three times ")#mi("{t_1 < t_2 < t_3}")#text(", one could form a sentence such as")

#align(center)[#tao-fit-display[#mitex("K_{1,t_2}( K_{2,t_1}( S ) ),")]]

#text("which informally asserts that at time ")#mi("{t_2}")#text(", ")#mi("{I_1}")#text(" knows that ")#mi("{I_2}")#text(" already knew ")#mi("{S}")#text(" to be true by time ")#mi("{t_1}")#text(", or")

#align(center)[#tao-fit-display[#mitex("K_{1,t_2}( K_{2,t_3}( S ) ),")]]

#text("which informally asserts that at time ")#mi("{t_2}")#text(", ")#mi("{I_1}")#text(" knows that ")#mi("{I_2}")#text(" will know ")#mi("{S}")#text(" to be true by time ")#mi("{t_3}")#text(". The ability to know certain statements about the future is not too relevant for the blue-eyed islander puzzle, but is a crucial point in the unexpected hanging paradox.")

#text("Of course, with so many knowledge agents present, the models become more complicated; a model ")#mi("{M_k}")#text(" of ")#mi("{L_k}")#text(" now must contain inside it clouds ")#mi("{{\\mathcal M}_{k-1}^{(i,t)}}")#text(" of possible worlds for each actor ")#mi("{I_i}")#text(" and each time ")#mi("{t \\in T}")#text(".")

#text("One reasonable axiom to add to a temporal epistemological system is the ability of agents to remember what they know. More precisely, we can impose the “memory axiom” ")#metadata(none) <tao-c064fbca9d9de8dd9bb0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("C( K_{i,t}(S) \\implies K_{i,t^{\\prime}}(S) )")]]

#text("for any ")#mi("{S \\in L_\\infty}")#text(", any ")#mi("{i=1,\\ldots,m}")#text(", and any ")#mi("{t < t^{\\prime}}")#text(". (This axiom is important for the blue-eyed islander puzzle, though it turns out not to be relevant for the unexpected hanging paradox.)")

#text("We can also define a notion of common knowledge at a single time ")#mi("{t \\in T}")#text(": given a sentence ")#mi("{S \\in L_\\infty}")#text(", we let ")#mi("{C_t(S)}")#text(" denote the set of sentences of the form")

#align(center)[#tao-fit-display[#mitex("K_{i_1,t}( K_{i_2,t} ( \\ldots ( K_{i_k,t}(S) ) \\ldots ) )")]]

#text("where ")#mi("{k \\geq 0}")#text(" and ")#mi("{i_1,\\ldots,i_k \\in \\{1,\\ldots,n\\}}")#text(". This is a subset of ")#mi("{C(S)}")#text(", which is the set of all sentences of the form")

#align(center)[#tao-fit-display[#mitex("K_{i_1,t_1}( K_{i_2,t_2} ( \\ldots ( K_{i_k,t_k}(S) ) \\ldots ) )")]]

#text("where ")#mi("{t_1,\\ldots,t_k \\in T}")#text(" can vary arbitrarily in ")#mi("{T}")#text(".")

#heading(level: 1)[#strong[#text(" — 6. The blue-eyed islander puzzle — ")]]

#text("Now we can model the blue-eyed islander puzzle. To simplify things a bit, we will work with a discrete set of times ")#mi("{T = {\\bf Z}}")#text(" indexed by the integers, with ")#mi("{0}")#text(" being the day in which the foreigner speaks, and any other time ")#mi("{t}")#text(" being the time ")#mi("{t}")#text(" days after (or before, if ")#mi("{t}")#text(" is negative) the foreigner speaks. (One can also work with a continuous time with only minor changes.) Note the presence of negative time; this is to help resolve the question (which often comes up in discussion of this puzzle) as to whether the islanders would already have committed suicide even before the foreigner speaks.")

#text("Also, the way the problem is set up, we have the somewhat notationally annoying difficulty that once an islander commits suicide, it becomes meaningless to ask whether that islander continues to know anything or not. To resolve this problem, we will take the liberty of modifying the problem by replacing “suicide” with a non-lethal public ritual. (This means (thanks to ")#link(<tao-c064fbca9d9de8dd9bb0>)[#text("(4)")]#text(") that once an islander learns his or her own eye colour, he or she will be condemned to repeating this ritual “suicide” every day from that point.) It is possible to create a logic which tracks when different agents are alive or dead and to thus model the concept of suicide, but this is something of a distraction from the key point of the puzzle, so we will simply redefine away this issue.")

#text("For similar reasons, we will not concern ourselves with eye colours other than blue, and only consider suicides stemming from blue eyes, rather than from any non-blue colour. (It is intuitively obvious, and can eventually be proven, that the foreigner’s statement about the existence of blue-eyed islanders is insufficient information to allow any islander to distinguish between, say, green eyes and brown eyes, and so this statement cannot trigger the suicide of any non-blue-eyed person.)")

#text("As in previous sections, our logic will have the atomic propositions ")#mi("{A_1,\\ldots,A_n}")#text(", with each ")#mi("{A_i}")#text(" expressing the statement that ")#mi("{I_i}")#text(" has blue eyes, as well as knowledge agents ")#mi("{K_{i,t}}")#text(" for each ")#mi("{i=1,\\ldots,n}")#text(" and ")#mi("{t \\in {\\bf Z}}")#text(". However, we will also need further atomic propositions ")#mi("{S_{i,t}}")#text(" for ")#mi("{i = 1,\\ldots,n}")#text(" and ")#mi("{t \\in {\\bf Z}}")#text(", which denote the proposition that ")#mi("{I_i}")#text(" commits suicide (or a ritual equivalent) at time ")#mi("{t}")#text(". Thus we now have a countably infinite number of atomic propositions and a countably infinite number of knowledge agents, but there is little difficulty extending the logics ")#mi("{L_k}")#text(" and ")#mi("{L_\\infty}")#text(" to cover this setting.")

#text("We can now set up the various axioms for the puzzle. The “highly logical” axiom has already been subsumed in the epistemological inference rule. We also impose the memory axiom ")#link(<tao-c064fbca9d9de8dd9bb0>)[#text("(4)")]#text(". Now we formalise the other assumptions of the puzzle:")

#list(
[#text("(All islanders see each other’s eye colour) If ")#mi("{i,j \\in \\{1,\\ldots,n\\}}")#text(" are distinct and ")#mi("{t \\in {\\bf Z}}")#text(", then")

#metadata(none) <tao-c24444d59be2c3121326>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("C( A_i \\implies K_{j,t}(A_i) )")]]

#text("and")

#metadata(none) <tao-f95c6cc08628ed219331>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("C( \\neg A_i \\implies K_{j,t}(\\neg A_i) ).")]]],
[#text("(Anyone who learns their own eye colour is blue, must commit suicide the next day) If ")#mi("{i \\in\\{1,\\ldots,n\\}}")#text(" and ")#mi("{t \\in {\\bf Z}}")#text(", then")

#metadata(none) <tao-5304378d007825ccb104>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("C( K_{i,t}(A_i) \\implies S_{i,t+1} ).")]]],
[#text("(Suicides are public) For any ")#mi("{i \\in \\{1,\\ldots,n\\}}")#text(", ")#mi("{t \\in {\\bf Z}}")#text(", and ")#mi("{S^{\\prime}_{i,t} \\in C_t( S_{i,t} )}")#text(", we have")

#metadata(none) <tao-f5a4012326198ccbd574>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("C( S_{i,t} \\implies S^{\\prime}_{i,t} ).")]]

#text("Similarly, if ")#mi("{S^{\\prime\\prime}_{i,t} \\in C_t( \\neg S_{i,t} )}")#text(", then")

#metadata(none) <tao-b0ccae52c2cc68a18526>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("C( \\neg S_{i,t} \\implies S^{\\prime\\prime}_{i,t} ).")]]],
[#text("(Foreigner announces in public on day 0 that there is at least one blue-eyed islander) We have")

#metadata(none) <tao-a9391007239d7d05cdaa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("C_0( B_{\\geq 1} ).")]]]
)

#text("Let ")#mi("{{\\mathcal T}}")#text(" denote the union of all the axioms ")#link(<tao-c064fbca9d9de8dd9bb0>)[#text("(4)")]#text(", ")#link(<tao-c24444d59be2c3121326>)[#text("(5)")]#text(", ")#link(<tao-f95c6cc08628ed219331>)[#text("(6)")]#text(", ")#link(<tao-5304378d007825ccb104>)[#text("(7)")]#text(", ")#link(<tao-f5a4012326198ccbd574>)[#text("(8)")]#text(", ")#link(<tao-a9391007239d7d05cdaa>)[#text("(10)")]#text(". The “solution” to the islander puzzle can then be summarised as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5")]#text(" Let ")#mi("{1 \\leq m \\leq n}")#text(".")

#enum(start: 1, 
[#text("(At least one blue-eyed islander commits suicide by day ")#mi("{m}")#text(")")

#align(center)[#tao-fit-display[#mitex("{\\mathcal T}, B_m \\vdash_{L_\\infty} \\bigvee_{i=1}^n \\bigvee_{t=1}^m (A_i \\wedge S_{i,t}).")]]],
[#text("(Nobody needs to commit suicide before day ")#mi("{m}")#text(") For any ")#mi("{t < m}")#text(" and ")#mi("{1 \\leq i \\leq n}")#text(",")

#align(center)[#tao-fit-display[#mitex("{\\mathcal T}, B_m \\not \\vdash_{L_\\infty} S_{i,t}.")]]]
)
]

#text("The first conclusion is weaker than the “Solution 2″ of the puzzle, which would assert in fact that all ")#mi("{m}")#text(" blue-eyed islanders will commit suicide on day ")#mi("{m}")#text(". While this indeed the “default” outcome of the hypotheses ")#mi("{{\\mathcal T}, B_m}")#text(", it turns out that this is not the only possible outcome; for instance, if one blue-eyed person happens to commit suicide on day ")#mi("{0}")#text(" or day ")#mi("{1}")#text(" (perhaps for an unrelated reason than learning his or her own eye colour), then it turns out that this “cancels” the effect of the foreigner’s announcement, and prevents further suicides. (So, strictly speaking, Solution 2 is not quite accurate, though it is much closer to the truth than Solution 1 is.)")

#text("In fact there is a strengthening of the first conclusion: given the hypotheses ")#mi("{{\\mathcal T}, B_m}")#text(", there must exist a time ")#mi("{1 \\leq t \\leq m}")#text(" and ")#mi("{t}")#text(" distinct islanders ")#mi("{I_{i_1},\\ldots,I_{i_t}}")#text(" such that ")#mi("{A_{i_j} \\wedge S_{i_j,t}}")#text(" holds for all ")#mi("{j=1,\\ldots,t}")#text(".")

#text("Note that the second conclusion does not prohibit the existence of some models of ")#mi("{{\\mathcal T}, B_m}")#text(" in which suicides occur before day ")#mi("{m}")#text(" (consider for instance a situation in which a second foreigner made a similar announcement a few days before the first one, causing the chain of events to start at an earlier point and leading to earlier suicides).")

#emph[#text("Proof:")]#text(" (Sketch) To illustrate the first part of the theorem, we focus on the simple case ")#mi("{m=n=2}")#text("; the general case is similar but requires more notation (and an inductive argument). It suffices to establish that")

#align(center)[#tao-fit-display[#mitex("{\\mathcal T}, B_2, \\neg S_{1,1}, \\neg S_{2,1} \\vdash_{L_\\infty} S_{1,2} \\wedge S_{2,2}")]]

#text("(i.e. if nobody suicides by day ")#mi("{1}")#text(", then both islanders will suicide on day ")#mi("{2}")#text(".)")

#text("Assume ")#mi("{{\\mathcal T}, B_2, \\neg S_{1,1}, \\neg S_{2,1}}")#text(". From ")#link(<tao-a9391007239d7d05cdaa>)[#text("(10)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("K_{1,0}( K_{2,0}( A_1 \\vee A_2 ) )")]]

#text("and hence by ")#link(<tao-c064fbca9d9de8dd9bb0>)[#text("(4)")]

#align(center)[#tao-fit-display[#mitex("K_{1,1}( K_{2,0}( A_1 \\vee A_2 ) ).")]]

#text("By ")#link(<tao-f95c6cc08628ed219331>)[#text("(6)")]#text(" we also have")

#align(center)[#tao-fit-display[#mitex("K_{1,1}( \\neg A_1 \\implies K_{2,0}( \\neg A_1 ) )")]]

#text("whereas from the epistemic inference axioms we have")

#align(center)[#tao-fit-display[#mitex("K_{1,1}( (K_{2,0}( A_1 \\vee A_2 ) \\wedge K_{2,0}( \\neg A_1 )) \\implies K_{2,0}(A_2) ).")]]

#text("From the epistemic inference axioms again, we conclude that")

#align(center)[#tao-fit-display[#mitex("K_{1,1}( \\neg A_1 \\implies K_{2,0}(A_2) )")]]

#text("and hence by ")#link(<tao-5304378d007825ccb104>)[#text("(7)")]#text(" (and epistemic inference)")

#align(center)[#tao-fit-display[#mitex("K_{1,1}( \\neg A_1 \\implies S_{2,1} ).")]]

#text("On the other hand, from ")#mi("{\\neg S_{2,1}}")#text(" and ")#link(<tao-b0ccae52c2cc68a18526>)[#text("(9)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("K_{1,1}( \\neg S_{2,1} )")]]

#text("and hence by epistemic inference")

#align(center)[#tao-fit-display[#mitex("K_{1,1}( A_1 )")]]

#text("and thus by ")#link(<tao-5304378d007825ccb104>)[#text("(7)")]

#align(center)[#tao-fit-display[#mitex("S_{1,2}.")]]

#text("A similar argument gives ")#mi("{S_{2,2}}")#text(", and the claim follows.")

#text("To prove the second part, one has to construct, for each ")#mi("{k}")#text(", an ")#mi("{L_k}")#text("-model in which ")#mi("{{\\mathcal T}, B_m}")#text(" is true and ")#mi("{S_{i,t}}")#text(" is false for any ")#mi("{1 \\leq i \\leq n}")#text(" and ")#mi("{t < m}")#text(". This is remarkably difficult, in large part due to the ability of nested knowledge operators to jump backwards and forwards in time. In particular, one can jump backwards to before Day 0, and so one must first model worlds in which there is no foreigner announcement. We do this as follows. Given an ")#mi("{L_0}")#text("-model ")#mi("{M_0}")#text(", we recursively define a ")#mi("{L_k}")#text("-model ")#mi("{M_k(M_0)}")#text(" for ")#mi("{k=0,1,2,\\ldots}")#text(" as follows. Firstly, ")#mi("{M_0(M_0) := M_0}")#text(". Next, if ")#mi("{k \\geq 1}")#text(" and ")#mi("{M_{k-1}()}")#text(" has already been defined, we define ")#mi("{M_k(M_0)}")#text(" to be the ")#mi("{L_k}")#text("-model with ")#mi("{L_0}")#text("-model ")#mi("{M_0}")#text(", and for any ")#mi("{i=1,\\ldots,n}")#text(" and ")#mi("{t \\in {\\bf Z}}")#text(", setting ")#mi("{{\\mathcal M}_{k-1}^{(i,t)}(M_0)}")#text(" to be the set of all ")#mi("{L_{k-1}}")#text("-models of the form ")#mi("{M_{k-1}(M^{\\prime}_0)}")#text(", where ")#mi("{M^{\\prime}_0}")#text(" is an ")#mi("{L_0}")#text("-model obeying the following properties:")

#list(
[#text("(")#mi("{I_i}")#text(" sees other islanders’ eyes) If ")#mi("{j \\in \\{1,\\ldots,n\\}}")#text(" and ")#mi("{j \\neq i}")#text(", then ")#mi("{M^{\\prime}_0 \\models_{L_0} A_i}")#text(" iff ")#mi("{M_0 \\models_{L_0} A_i}")#text(".")],
[#text("(")#mi("{I_i}")#text(" remembers suicides) If ")#mi("{j \\in \\{1,\\ldots,n\\}}")#text(" and ")#mi("{t^{\\prime} \\leq t}")#text(", then ")#mi("{M^{\\prime}_0 \\models_{L_0} S_{j,t^{\\prime}}}")#text(" iff ")#mi("{M_0 \\models_{L_0} S_{j,t^{\\prime}}}")#text(".")]
)

#text("Now we model worlds in which there is a foreigner announcement. Define an ")#emph[#text("admissible ")#mi("{L_0}")#text(" model")]#text(" to be an ")#mi("{L_0}")#text("-model ")#mi("{M_0}")#text(" such that there exist ")#mi("{1 \\leq t \\leq m}")#text(" for which the following hold:")

#list(
[#mi("{M_0 \\models_{L_0} B_m}")#text(" (i.e. there are exactly ")#mi("{m}")#text(" blue-eyed islanders in the world ")#mi("{M_0}")#text(").")],
[#text("There exists distinct ")#mi("{i_1,\\ldots,i_t \\in \\{1,\\ldots,n\\}}")#text(" such that ")#mi("{M_0 \\models_{L_0} A_{i_j}}")#text(" and ")#mi("{M_0 \\models_{L_0} S_{i_j,t}}")#text(" for all ")#mi("{j=1,\\ldots,t}")#text(".")],
[#text("For any ")#mi("{i \\in \\{1,\\ldots,n\\}}")#text(" and ")#mi("{t^{\\prime} \\in {\\bf Z}}")#text(", ")#mi("{M_0 \\models_{L_0} S_{i,t^{\\prime}}}")#text(" implies ")#mi("{M_0 \\models_{L_0} S_{i,t^{\\prime}+1}}")#text(".")]
)

#text("We call ")#mi("{m}")#text(" the ")#emph[#text("blue-eyed count")]#text(" of ")#mi("{M_0}")#text(".")

#text("(Such models, incidentally, can already be used to show that no suicides necessarily occur in the absence of the foreigner’s announcement, because the limit ")#mi("{M_\\infty(M_0)}")#text(" of such models always obey all the axioms of ")#mi("{{\\mathcal T}}")#text(" except for ")#link(<tao-a9391007239d7d05cdaa>)[#text("(10)")]#text(".)")

#text("Given an admissible ")#mi("{L_0}")#text("-model ")#mi("{M_0}")#text(" of some blue-eyed count ")#mi("{m}")#text(", we recursively define an ")#mi("{L_k}")#text(" model ")#mi("{\\tilde M_k(M_0)}")#text(" for ")#mi("{k=0,1,2,\\ldots}")#text(" by setting ")#mi("{\\tilde M_0(M_0) := M_0}")#text(", then if ")#mi("{k \\geq 1}")#text(" and ")#mi("{\\tilde M_{k-1}()}")#text(" has already been defined, we define ")#mi("{\\tilde M_k(M_0)}")#text(" to be the ")#mi("{L_k}")#text("-model with ")#mi("{L_0}")#text("-model ")#mi("{M_0}")#text(", and with ")#mi("{{\\mathcal M}_{k-1}^{(i,t)}(M_0)}")#text(" for ")#mi("{i=1,\\ldots,n}")#text(" and ")#mi("{t \\in {\\bf Z}}")#text(" defined by the following rules:")

#strong[#text("Case 1.")]#text(" If ")#mi("{t < 0}")#text(", then we set ")#mi("{{\\mathcal M}_{k-1}^{(i,t)}(M_0)}")#text(" to be the set of all ")#mi("{L_{k-1}}")#text("-models of the form ")#mi("{M_{k-1}(M^{\\prime}_0)}")#text(", where ")#mi("{M^{\\prime}_0}")#text(" obeys the two properties “")#mi("{I_i}")#text(" sees other islanders’ eyes” and “")#mi("{I_i}")#text(" remembers suicides” from the preceding construction. (")#mi("{M^{\\prime}_0}")#text(" does not need to be admissible in this case.)")

#strong[#text("Case 2.")]#text(" If ")#mi("{t=m-1}")#text(", ")#mi("{M_0 \\models A_i}")#text(", and there does not exist ")#mi("{1 \\leq t^{\\prime} \\leq t}")#text(" distinct ")#mi("{i_1,\\ldots,i_{t^{\\prime}}\\in \\{1,\\ldots,n\\}}")#text(" such that ")#mi("{M_0 \\models_{L_0} A_{i_j} \\wedge S_{i_j,t^{\\prime}}}")#text(" for all ")#mi("{j=1,\\ldots,t^{\\prime}}")#text(", then we set ")#mi("{{\\mathcal M}_{k-1}^{(i,t)}(M_0)}")#text(" ")#mi("{L_{k-1}}")#text("-models of the form ")#mi("{\\tilde M_{k-1}(M^{\\prime}_0)}")#text(", where ")#mi("{M^{\\prime}_0}")#text(" is admisssible, obeys the two properties “")#mi("{I_i}")#text(" sees other islanders’ eyes” and “")#mi("{I_i}")#text(" remembers suicides” from the preceding construction, and also obeys the additional property ")#mi("{M^{\\prime}_0 \\models A_i}")#text(". (Informally, this is the case in which ")#mi("{I_i}")#text(" “must learn” ")#mi("{A_i}")#text(".)")

#strong[#text("Case 3.")]#text(" In all other cases, we set ")#mi("{{\\mathcal M}_{k-1}^{(i,t)}(M_0)}")#text(" to be the set of all ")#mi("{L_{k-1}}")#text("-models of the form ")#mi("{\\tilde M_{k-1}(M^{\\prime}_0)}")#text(", where ")#mi("{M^{\\prime}_0}")#text(" is admissible and obeys the two properties “")#mi("{I_i}")#text(" sees other islanders’ eyes” and “")#mi("{I_i}")#text(" remembers suicides” from the preceding construction.")

#text("We let ")#mi("{\\tilde M_\\infty(M_0)}")#text(" be the limit of the ")#mi("{\\tilde M_k(M_0)}")#text(" (which can easily be verified to exist by induction). A quite tedious verification reveals that for any admissible ")#mi("{L_0}")#text("-model ")#mi("{M_0}")#text(" of blue-eyed count ")#mi("{m}")#text(", that ")#mi("{\\tilde M_\\infty(M_0)}")#text(" obeys both ")#mi("{{\\mathcal T}}")#text(" and ")#mi("{B_m}")#text(", but one can choose ")#mi("{M_0}")#text(" to not admit any suicides before time ")#mi("{m}")#text(", which will give the second claim of the theorem. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" Under the assumptions used in our analysis, we have shown that it is inevitable that the foreigner’s comment will cause at least one death. However, it is possible to avert all deaths by breaking one or more of the assumptions used. For instance, if it is possible to sow enough doubt in the islanders’ minds about the logical and devout nature of the other islanders, then one can cause a breakdown of the epistemic inference rule or of ")#link(<tao-5304378d007825ccb104>)[#text("(7)")]#text(", and this can prevent the chain of deductions from reaching its otherwise deadly conclusion.")
]

#heading(level: 1)[#strong[#text(" — 7. The unexpected hanging paradox — ")]]

#text("We now turn to the ")#link("http://en.wikipedia.org/wiki/Unexpected_hanging_paradox")[#text("unexpected hanging paradox")]#text(", and try to model it using (temporal) epistemic logic. (For a formulation of this paradox, I will refer to ")#link("http://en.wikipedia.org/wiki/Unexpected_hanging_paradox")[#text("the Wikipedia entry")]#text(" for this paradox.)")

#text("It turns out that there are several, not quite equivalent, ways to model this “paradox” epistemologically, with the differences hinging on how one interprets what “unexpected” or “surprise” means. In particular, if ")#mi("{S}")#text(" is a sentence and ")#mi("{K}")#text(" is a knowledge agent, how would one model the sentence “")#mi("{K}")#text(" does not expect ")#mi("{S}")#text("” or “")#mi("{K}")#text(" is surprised by ")#mi("{S}")#text("“?")

#text("One possibility is to model this sentence as ")#metadata(none) <tao-2a36430635e7505479f0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\neg K(S),")]]

#text("i.e. as the assertion that ")#mi("{K}")#text(" does not know ")#mi("{S}")#text(" to be true. However, this leads to the following situation: if ")#mi("{K}")#text(" has inconsistent knowledge (in particular, one has ")#mi("{K(\\bot)}")#text(", where ")#mi("{\\bot}")#text(" represents falsity (the negation of a tautology)), then by ")#link("http://en.wikipedia.org/wiki/Principle_of_explosion")[#text("ex falso quodlibet")]#text(", ")#mi("{K(S)}")#text(" would be true for every ")#mi("{S}")#text(", and hence ")#mi("{K}")#text(" would expect everything and be surprised by nothing. An alternative interpretation, then, is to adopt the convention that an agent with inconsistent knowledge is so confused as to not be capable of expecting anything (and thus be surprised by everything). In this case, “")#mi("{K}")#text(" does not expect ")#mi("{S}")#text("” should instead be modeled as ")#metadata(none) <tao-c17c036604f660ca5f75>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("(\\neg K(S)) \\vee K(\\bot),")]]

#text("i.e. that ")#mi("{K}")#text(" either does not know ")#mi("{S}")#text(" to be true, or is inconsistent.")

#text("Both interpretations ")#link(<tao-2a36430635e7505479f0>)[#text("(11)")]#text(", ")#link(<tao-c17c036604f660ca5f75>)[#text("(12)")]#text(" should be compared with the sentence ")#metadata(none) <tao-fa34f521b2c2ee9c4d09>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("K(\\neg S),")]]

#text("i.e. that ")#mi("{K}")#text(" knows that ")#mi("{S}")#text(" is false. If ")#mi("{K}")#text(" is consistent, ")#link(<tao-fa34f521b2c2ee9c4d09>)[#text("(13)")]#text(" implies ")#link(<tao-2a36430635e7505479f0>)[#text("(11)")]#text(", but if ")#mi("{K}")#text(" is inconsistent then ")#link(<tao-fa34f521b2c2ee9c4d09>)[#text("(13)")]#text(" is true and ")#link(<tao-2a36430635e7505479f0>)[#text("(11)")]#text(" is false. In either case, though, we see that ")#link(<tao-fa34f521b2c2ee9c4d09>)[#text("(13)")]#text(" implies ")#link(<tao-c17c036604f660ca5f75>)[#text("(12)")]#text(".")

#text("Let now analyse the unexpected hanging paradox using the former interpretation ")#link(<tao-2a36430635e7505479f0>)[#text("(11)")]#text(" of surprise. We begin with the simplest (and somewhat degenerate) situation, in which there is only one time (say Monday at noon) in which the hanging is to take place. In this case, there is just one knowledge agent ")#mi("{K}")#text(" (the knowledge of the prisoner after the judge speaks, but before the executation date of Monday at noon). We introduce an atomic sentence ")#mi("{E}")#text(", representing the assertion that the prisoner will be hanged on Monday at noon. In this case (and using the former interpretation ")#link(<tao-2a36430635e7505479f0>)[#text("(11)")]#text(" of surprise), the judge’s remarks can be modeled by the sentence")

#align(center)[#tao-fit-display[#mitex("S := E \\wedge (E \\implies \\neg K(E)).")]]

#text("The “paradox” in this case stems from the following curious fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6")]#text(" ")#metadata(none) <tao-b737ca7ee563ae80e457>

#enum(start: 1, 
[#text("There exist ")#mi("{L_\\infty}")#text("-models in which ")#mi("{S}")#text(" is true.")],
[#text("There exist ")#mi("{L_\\infty}")#text("-models in which ")#mi("{K(S)}")#text(" is true.")],
[#text("However, there does not exist any ")#mi("{L_\\infty}")#text("-model in which both ")#mi("{S}")#text(" and ")#mi("{K(S)}")#text(" is true.")]
)
]

#text("Thus, the judge’s statement can be true, but if so, it is not possible for the prisoner to know this! (In this regard, the sentence ")#mi("{S}")#text(" is analogous to a Godel sentences, which can be true in models of a formal system, but not provable in that system.) More informally: knowing a surprise, ruins that surprise.")

#emph[#text("Proof:")]#text(" The third statement is easy enough to establish: if ")#mi("{S}")#text(" is true in some model, then clearly ")#mi("{\\neg K(E)}")#text(" is true in that model; but if ")#mi("{K(S)}")#text(" is true in the same model, then (by epistemic inference) ")#mi("{K(E)}")#text(" will be true as well, which is a contradiction.")

#text("The first statement is also fairly easy to establish. We have two ")#mi("{L_0}")#text("-models; a model ")#mi("{M_0^+}")#text(" in which ")#mi("{E}")#text(" is true, and a model ")#mi("{M_0^-}")#text(" in which ")#mi("{E}")#text(" is false. We can recursively define the ")#mi("{L_k}")#text("-model ")#mi("{M_k(M_0)}")#text(" for any ")#mi("{k \\geq 0}")#text(" and any ")#mi("{M_0 \\in \\{M_0^+,M_0^-\\}}")#text(" by setting ")#mi("{M_0(M_0) := M_0}")#text(", and for ")#mi("{k \\geq 1}")#text(", setting ")#mi("{M_k(M_0)}")#text(" to be the ")#mi("{L_k}")#text("-model with ")#mi("{L_0}")#text("-model ")#mi("{M_0}")#text(", and with ")#mi("{{\\mathcal M}_{k-1} := \\{ M_{k-1}(M_0^+), M_{k-1}(M_0^-) \\}}")#text(". One then easily verifies that the ")#mi("{M_k(M_0)}")#text(" have a limit ")#mi("{M_\\infty(M_0)}")#text(", and that ")#mi("{M_\\infty(M_0^+)}")#text(" models ")#mi("{S}")#text(" (but not ")#mi("{K(S)}")#text(", of course).")

#text("A trivial way to establish the second statement is to make a model in which ")#mi("{K}")#text(" is inconsistent (thus ")#mi("{{\\mathcal M}_{k-1}}")#text(" is empty). One can also take ")#mi("{{\\mathcal M}_{k-1}}")#text(" to be ")#mi("{M_{k-1}(M_0^+)}")#text(", and this will also work. (Of course, in such models, ")#mi("{S}")#text(" must be false.) ")#mi("\\Box")

#text("Another peculiarity of the sentence ")#mi("{S}")#text(" is that")

#align(center)[#tao-fit-display[#mitex("K(S), K(K(S)) \\models_{L_\\infty} K(\\bot)")]]

#text("as can be easily verified (by modifying the proof of the second statement of the above theorem). Thus, the sentence ")#mi("{S}")#text(" has the property that if the prisoner believes ")#mi("{S}")#text(", and also knows that he or she believes ")#mi("{S}")#text(", then the prisoner’s beliefs automatically become inconsistent – despite the fact that ")#mi("{S}")#text(" is not actually a self-contradictory statement (unless also combined with ")#mi("{K(S)}")#text(").")

#text("Now we move to the case when the execution could take place at two possible times, say Monday at noon and Tuesday at noon. We then have two atomic statements: ")#mi("{E_1}")#text(", the assertion that the execution takes place on Monday at noon, and ")#mi("{E_2}")#text(", the assertion that the execution takes place on Tuesday at noon. There are two knowledge agents; ")#mi("{K_1}")#text(", the state of knowledge just before Monday at noon, and ")#mi("{K_2}")#text(", the state of knowledge just before Tuesday at noon. (There is again the annoying notational issue that if ")#mi("{E_1}")#text(" occurs, then presumably the prisoner will have no sensible state of knowledge by Tuesday, and so ")#mi("{K_2}")#text(" might not be well defined in that case; to avoid this irrelevant technicality, we replace the execution by some non-lethal punishment (or use an alternate formulation of the puzzle, such as the surprise exam formulation).)")

#text("We will need one axiom beyond the basic axioms of epistemic logic, namely ")#metadata(none) <tao-0acbf84757d057b4eaf5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("C( \\neg E_1 \\implies K_2( \\neg E_1 ) ).")]]

#text("Thus, it is common knowledge that if the execution does not happen on Monday, then by Tuesday, the prisoner will be aware of this fact. This axiom should of course be completely non-controversial.")

#text("The judge’s sentence, in this case, is given by")

#align(center)[#tao-fit-display[#mitex("S := (E_1 \\vee E_2) \\wedge (E_1 \\implies \\neg K_1(E_1)) \\wedge (E_2 \\implies \\neg K_2(E_2)).")]]

#text("Analogously to Theorem ")#link(<tao-b737ca7ee563ae80e457>)[#text("6")]#text(", we can find ")#mi("{L_\\infty}")#text(" models obeying ")#link(<tao-0acbf84757d057b4eaf5>)[#text("(14)")]#text(" in which ")#mi("{S}")#text(" is true, but one cannot find models obeying ")#link(<tao-0acbf84757d057b4eaf5>)[#text("(14)")]#text(" in which ")#mi("{S}")#text(", ")#mi("{K_1(S)}")#text(", ")#mi("{K_2(S)}")#text(", and ")#mi("{K_1(K_2(S))}")#text(" are all true, as one can soon see that this leads to a contradiction. Indeed, from ")#mi("{S}")#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\neg E_1 \\implies \\neg K_2(E_2)")]]

#text("while from ")#link(<tao-0acbf84757d057b4eaf5>)[#text("(14)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\neg E_1 \\implies K_2(\\neg E_1)")]]

#text("and from ")#mi("{K_2(S)}")#text(" one has")

#align(center)[#tao-fit-display[#mitex("K_2(E_1 \\wedge E_2)")]]

#text("wihch shows that ")#mi("{\\neg E_1}")#text(" leads to a contradiction, which implies ")#mi("{E_1}")#text(" and hence ")#mi("{\\neg K_1(E_1)}")#text(" by ")#mi("{S}")#text(". On the other hand, from ")#mi("{K_1(S)}")#text(" one has")

#align(center)[#tao-fit-display[#mitex("K_1( \\neg E_1 \\implies \\neg K_2(E_2) )")]]

#text("while from ")#link(<tao-0acbf84757d057b4eaf5>)[#text("(14)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("K_1( \\neg E_1 \\implies K_2(\\neg E_1) )")]]

#text("and from ")#mi("{K_1(K_2(S))}")#text(" one has")

#align(center)[#tao-fit-display[#mitex("K_1( K_2(E_1 \\wedge E_2) )")]]

#text("which shows that ")#mi("{K_1( \\neg E_1 \\implies \\bot )}")#text(", and thus ")#mi("{K_1(E_1)}")#text(", a contradiction. So, as before, ")#mi("{S}")#text(" is a secret which can only be true as long as it is not too widely known.")

#text("A slight variant of the above argument shows that if ")#mi("{K_1(S)}")#text(", ")#mi("{K_2(S)}")#text(", and ")#mi("{K_1(K_2(S))}")#text(" hold, then ")#mi("{K_1(\\neg E_1)}")#text(" and ")#mi("{\\neg E_1 \\implies K_2(\\neg E_2)}")#text(" hold – or informally, the prisoner can deduce using knowledge of ")#mi("{S}")#text(" (and knowledge of knowledge of ")#mi("{S}")#text(") that there will be no execution on either date. This may appear at first glance to be consistent with ")#mi("{S}")#text(" (which asserts that the prisoner will be surprised when the execution does happen), but this is a confusion between ")#link(<tao-2a36430635e7505479f0>)[#text("(11)")]#text(" and ")#link(<tao-fa34f521b2c2ee9c4d09>)[#text("(13)")]#text(". Indeed, one can show under the assumptions ")#mi("{K_1(S), K_2(S), K_1(K_2(S))}")#text(" that ")#mi("{K_1}")#text(" is inconsistent, and (if ")#mi("{\\neg E_1}")#text(" holds) then ")#mi("{K_2}")#text(" is also inconsistent, and so ")#mi("{K_1(\\neg E_1)}")#text(" and ")#mi("{\\neg E_1 \\implies K_2(\\neg E_2)}")#text(" do not, in fact, imply ")#mi("{S}")#text(".")

#text("Now suppose that we interpret surprise using ")#link(<tao-c17c036604f660ca5f75>)[#text("(12)")]#text(" instead of ")#link(<tao-2a36430635e7505479f0>)[#text("(11)")]#text(". Let us begin first with the one-day setting. Now the judge’s sentence becomes")

#align(center)[#tao-fit-display[#mitex("S = E \\wedge (E \\implies (\\neg K(E) \\vee K(\\bot))).")]]

#text("In this case it is possible for ")#mi("{S}")#text(" and ")#mi("{K(S)}")#text(" to be true, and in fact for ")#mi("{S}")#text(" to be common knowledge, basically by making ")#mi("{K}")#text(" inconsistent. (A little more precisely: we use the ")#mi("{L_k}")#text("-model ")#mi("{M_k}")#text(" where ")#mi("{M_0 = M_0^+}")#text(" and ")#mi("{{\\mathcal M}_{k-1} = \\emptyset}")#text(". Informally: the judge has kept the execution a surprise by driving the prisoner insane with contradictions.")

#text("The situation is more interesting in the two-day setting (as first pointed out ")#link("http://www.ams.org/notices/201011/rtx101101454p.pdf")[#text("by Kritchman and Raz")]#text("), where ")#mi("{S}")#text(" is now")

#align(center)[#tao-fit-display[#mitex("S := (E_1 \\vee E_2) \\wedge (E_1 \\implies (\\neg K_1(E_1) \\vee K_1(\\bot)))")]]

#align(center)[#tao-fit-display[#mitex("\\wedge (E_2 \\implies (\\neg K_2(E_2) \\vee K_2(\\bot))).")]]

#text("Here it is possible for ")#mi("{S}")#text(" to in fact be common knowledge in some ")#mi("{L_\\infty}")#text("-model, but in order for this to happen, at least one of the following three statements must be true in this model:")

#list(
[#mi("{K_1(\\bot)}")#text(".")],
[#mi("{K_2(\\bot)}")#text(".")],
[#mi("{\\neg K_1(\\neg K_2(\\bot))}")#text(".")]
)

#text("(We leave this as an exercise for the interested reader.) In other words, in order for the judge’s sentence to be common knowledge, either the prisoner’s knowledge on Monday or Tuesday needs to be inconsistent, or else the prisoner’s knowledge is consistent, but the prisoner is unable (on Monday) to determine that his or her own knowledge (on Tuesday) is consistent. Notice that the third conclusion here ")#mi("{\\neg K_1(\\neg K_2(\\bot))}")#text(" is very reminiscent of ")#link("http://en.wikipedia.org/wiki/G%C3%B6del's_incompleteness_theorems")[#text("Gödel’s second incompleteness theorem")]#text(", and indeed in the above-mentioned ")#link("http://www.ams.org/notices/201011/rtx101101454p.pdf")[#text("paper of Kritchman and Raz")]#text(", the surprise examination argument is modified to give a rigorous proof of that theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" Here is an explicit example of a ")#mi("{L_\\infty}")#text("-world in which ")#mi("{S}")#text(" is common knowledge, and ")#mi("{K_1}")#text(" and ")#mi("{K_2}")#text(" are both consistent (but ")#mi("{K_1}")#text(" does not know that ")#mi("{K_2}")#text(" is consistent). We first define ")#mi("{L_k}")#text("-models ")#mi("{M_k}")#text(" for each ")#mi("{k=0,1,\\ldots}")#text(" recursively by setting ")#mi("{M_0}")#text(" to be the world in which ")#mi("{M_0 \\models_{L_0} E_2}")#text(" and ")#mi("{M_0 \\models_{L_0} \\neg E_1}")#text(", and then define ")#mi("{M_k}")#text(" for ")#mi("{k \\geq 1}")#text(" to be the ")#mi("{L_k}")#text("-model with ")#mi("{L_0}")#text("-model ")#mi("{M_0}")#text(", with ")#mi("{{\\mathcal M}_{k-1}^{(1)} := \\{ M_{k-1}\\}}")#text(", and ")#mi("{{\\mathcal M}_{k-1}^{(2)} := \\emptyset}")#text(". (Informally: the execution is on Tuesday, and the prisoner knows this on Monday, but has become insane by Tuesday.) We then define the models ")#mi("{\\tilde M_k}")#text(" for ")#mi("{k=0,1,\\ldots}")#text(" recursively by setting ")#mi("{\\tilde M_0}")#text(" to be the world in which ")#mi("{\\tilde M_0 \\models_{L_0} E_1}")#text(" and ")#mi("{\\tilde M_0 \\models_{L_0} \\neg E_2}")#text(", then define ")#mi("{\\tilde M_k}")#text(" for ")#mi("{k \\geq 1}")#text(" to be the ")#mi("{L_k}")#text("-model with ")#mi("{L_0}")#text("-model ")#mi("{\\tilde M_0}")#text(", ")#mi("{{\\mathcal M}_{k-1}^{(1)} := \\{ M_{k-1}, \\tilde M_{k-1} \\}}")#text(", and ")#mi("{{\\mathcal M}_{k-1}^{(2)} := \\{ \\tilde M_{k-1} \\}}")#text(". (Informally: the execution is on Monday, but the prisoner only finds this out after the fact.) The limit ")#mi("{\\tilde M_\\infty}")#text(" of the ")#mi("{\\tilde M_k}")#text(" then has ")#mi("{S}")#text(" as common knowledge, with ")#mi("{K_1(\\bot)}")#text(" and ")#mi("{K_2(\\bot)}")#text(" both false, but ")#mi("{K_1(\\neg K_2(\\bot))}")#text(" is also false.")
]

#heading(level: 1)[#text("Comments (55)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/809d373133438ed5179ba8ad359b747ed05a388f30e7c99e6e7f66de2c3d8baa-0af53830b7dc822834233f65a9b78057cd5fcd84a9798578c2eed2f24304c5f9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of astrolemei")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-52962")[#strong[#text("astrolemei")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2011")])]

#text("I don’t know why, but this article does not show up in my Google Reader update, while the one before and the one after this article both show up.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53019")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2011")])]

#text("On the unexpected hanging paradox, aka the surprise-exam paradox: The beauty of the paradox is that it is phrased in terms of real-life situations, where the teacher states something as true, the student tries to work via proof by contradiction to refute the statement, believes he has done so, and then the statement still is true.")

#text("In the *initial* formulation of the paradox by Kritchman and Raz paper, their resolution is that the teacher’s statement was simply a contradiction. However, that is not satisfying because those reading the problem see that the teacher did not lie. The students *were* surprised, just as she said. The teacher’s statement only becomes a lie when we equate being surprised with provability, and that throws into question the idea of making them equivalent in our formulation.")

#text("Kritchman and Raz then try to modify the teacher’s sentence to make it a non-contradiction, but in doing so they don’t address the the inadequacy of their initial formulation. Further, while possessing interesting properties (some of which you explain in your post above), the new formulation doesn’t seem to be natural or really contain the paradox anymore. Would we find it puzzling to be given a self-referential formal sentence which tells us we cannot prove something using that sentence? Not really.")

#text("But I think that both of those formulations hide a much simpler resolution to the paradox. Namely, the student, along with Kritchman and Raz, are committing a modal fallacy: ")#link("http://www.sfu.ca/~swartz/modal_fallacy.htm")[#text("http://www.sfu.ca/~swartz/modal_fallacy.htm")]#text(" They are interpreting the judge’s statement as a statement about the future which must *necessarily* be true. They make it an axiom. But think about it. If we change the teacher’s words to reflect this understanding — if she were to say something like “There is no way you won’t be surprised by your test.” the game-theorists among us would say “Well, I’ll just plan on being tested every day.” The teacher’s statement would be false, and this would be evidenced by us when we prepare for a test each morning. (We wouldn’t be like the student in the example, and let our guard down, thinking we had already refuted the teacher.)")

#text("But if the teacher merely asserted (because, of course, no real teacher could assert absolute knowledge of what you will do) that you will be surprised when you are tested, and we understand that the teacher was merely voicing her opinion, it becomes clear what the student’s mistake was. He was reading the teachers statement as one of necessity, when it was not so.")

#text("So, in summary, while it makes sense to interpret the statement made by the visitor to the island as an commonly known axiom that must hold true in all possible worlds; doing so in the surprise-test paradox is making the same mistake as the student.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53020")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2011")])]

#text("Yes, one can certainly interpret the surprise examination without paradox if one interprets surprise using the necessary modal operator, i.e. “the student will be surprised by X” is interpreted as “the student knows that X is necessarily false” (or, the subtly different “the student does not necessarily know that X is true”), and then the resolution is that the teacher’s statement is not known to be necessarily true. But this is only one of several possible ways to interpret the paradox; one could instead interpret surprise in terms of belief, i.e. “the student will be surprised by X” means that “the student believes that X is false” (or, the subtly different “the student does not believe that X is true”). The teacher’s statement is certainly believable, and so one needs a different resolution to the paradox in this case. (For instance, one can resolve the paradox by noting that the teacher’s statement can be true, but it cannot be believed by the student without causing an inconsistency in that student’s belief system; this is the resolution I prefer in my post above (the epistemic logic I use works just as well for belief as it does for knowledge). Kritchman and Raz have a slightly different formulation in which one possible resolution comes from the fact that a student cannot consistently believe that his or her future beliefs are consistent, while also believing statements about the future such as the teacher’s statement.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f313f15eacebf69cb882ecf84822372cef032924aae58c4f3da2570b57b4ee88-0c3caaedfe52b826ecc1351cf286159d56c1f115d79c134b4bb8d74a5a26b78d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Koray")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53023")[#strong[#text("Koray")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2011")])]

#text("I don’t think we should be looking for ways to be able to still “interpret” this as a paradox. The only way this would be a “paradox” is when the judge/teacher does not mislead, the student/prisoner is not inconsistent and the definition of K is surprised is: A is true and K(not A).")

#text("If the student can hold unsupported beliefs or the teacher can lie, I have trouble explaining to anyone why this problem is interesting.")

#text("Thanks for the excellent post.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53027")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2011")])]

#text("I see a large difference between the words “belief” and “knowledge.” For instance, I view belief as more fluid, and more under our control, and would be opposed to axiom (4) on that (and other grounds) with respect to belief. But since your original post uses the term knowledge, as does the Kritchman and Raz paper, I’ll try to stick with that word. If you want to separate your view from the one in that paper– that knowledge and provability can be interchanged–just let me know and I’ll switch gears.")

#text("In your post you say: “Here it is possible for {S} to in fact be common knowledge in some {L_\\infty}-model…” and in your response to me you say “The teacher’s statement is certainly believable, and so one needs a different resolution to the paradox in this case. ” The trouble is, I don’t believe the teacher’s statement is necessarily true. Even in the phrasing used by Kritchman and Raz, if I’m parsing it correctly, T+S is consistent if and only if T+ not(S) is consistent. The student in the paradox ultimately does not believe the teacher either even though, in that particular world, the teacher is correct. If S were common knowledge, the student would have no reason to search for a contradiction. It would be futile. Thus, if we are only looking at models where S is common knowledge then that is, in my opinion, fundamentally changing what the paradox is talking about.")

#text("As an easy fix, we might say we don’t assume S is common knowledge. Instead, the student just looks at the possible worlds where S is true, and tries to find a contradiction in them all, and thus he will know either his own world is inconsistent or S is false. This seems to match what is happening in the original wording. The trouble is, in some of those possible worlds he does not know S is true (such as in the world he actually lives in). So whatever his logic, he cannot assume K(S) in that world either. He can merely assume S. [Note: Such a blunder would be another type of modal error, thinking of K as a modal operator.]")

#text("Let’s assume our student does not make that error, and does not assume K(S). Let’s also look with our student at a world M where S is true and E_1 is true. Let’s further say this is the real world for simplicity (and to match what actually happens in the paradox), although the student doesn’t know this. Well, since S is true, the student in that possible world, at time 1, does not know that E_1 is true. If we try to translate the original wording of the student’s logic into this framework, it immediately falls apart, because even if K_2(E_2) is false, in the world M, K_1 does not know that K_2(E_2) is false, in fact he does not believe (let alone know) that S is true (even though it is). Notice that this is exactly what happens in the real world. Further note that the error in E_1’s logic is not in some tacit assumption that he will only know true things in the future, but rather in an incorrect use of logic to come to the conclusion K_1(not(K_2(E_2))) in M (or K(S) in M).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53051")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2011")])]

#text("As I said in my reply to Jordan below, I’m working in an abstract generalised framework in which one can take an agnostic position as to whether K represents knowledge, belief, necessary truth, empirical knowledge, or any other knowledge-like operator. In this abstract setting, what one can show in general (using the first interpretation (11) of surprise) is that the judge’s statement S cannot be commonly known to be true, or (using the second interpretation (12) of surprise) that if S to be commonly known, then either K_1 or K_2 is inconsistent, or K_1 does not know that K_2 is consistent.")

#text("One can then specialise this abstract result to more specific interpretations of knowledge and get a simpler conclusion. In particular, if K represents necessary knowledge, then the conclusion is simply (as you say) that S is not knowable (in the first interpretation, at least); and if K represents provability, then (using the second interpretation) Kritchman and Raz obtain a rigorous proof of the second incompleteness theorem. In a belief model of knowledge, the conclusion is that believing S (and also believing that one believes S) leads to inconsistency in one’s beliefs.")

#text("Incidentally, the memory axiom (4) is needed in a crucial way for the islander puzzle, but not for the surprise paradox (basically because the deductive chain of reasoning moves forwards in time in the former, but backwards in time in the latter), and so one can safely omit this axiom if desired if one is only interested in treating the surprise paradox. (I’ll update the text to clarify this point.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53056")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2011")])]

#text("I think I understood all of this. I also hope it was clear that I had allowed an expansive view of the K operator in my response. And it *is* neat that S has such interesting properties, although there are simpler sentences with one or all of these properties, such as: “You will not have consistent beliefs.”")

#text("But the point that I’m contending (hopefully in a non-contentious was) is that none of those facts has any bearing on the actual surprise examination paradox. There is no reason to assume the teacher’s statement as either axiomatic or common knowledge. We, the readers, already understand that the teacher/judge’s statement should be taken with a grain of salt. The response of the student/criminal shows us that much; he doesn’t believe it either. Any analysis of what happens when assuming C(S) is besides the point. The only way we might want to start assuming C(S) is if we think the teacher has some added information about the student (e.g., knows he is bad at logic), but then we cannot identify with the student in the paradox. For the power in the paradox is that the student’s logic is initially appealing. We want to put ourselves in his/her shoes and work it out ourselves.")

#text("So it is interesting to discuss what happens when one assumes S is common knowledge, but that is besides the point with regards to the resolution of the paradox itself (unless you interpret the student/criminal’s argument as implicitly assuming C(S); but then the resolution is simply that this should not have been assumed by the student, *especially* since the student does not believe S!).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53057")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2011")])]

#text("That first sentence should be “If you believe this sentence, you will not have consistent beliefs.” Or something like that.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b10ac4dddfd7869b2f45dbb9f43d28f4237a8e4938892647fd83e295f13c555c-7f56189f74ed2bf31d239fb4220e5e79326b0012e1c36f7d501efdfae2728d25.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-126301")[#strong[#text("Paul")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2012")])]

#text("“…the game theorists among us…” brings to mind an unpublished idea of Karl Narveson mentioned in ")#link("http://www-math.mit.edu/~tchow/unexpected.pdf")[#text("http://www-math.mit.edu/~tchow/unexpected.pdf")]#text(". “The teacher ’s goal is to")#linebreak()#text(" ﬁnd a probability distribution that maximizes the absolute value of the expected surprise when the quiz is announced. Here “surprise” is based on Shannon entropy…” (Back in the ’80s I sent a similar formulation to Douglas R. Hofstadter’s “Metamagical Themas” column.) The fact that the optimal strategies for both the students and the teacher are not pure corresponds directly to (and quantifies) the consistency (or lack thereof) of the students’ beliefs and the teacher’s assertion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53024")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2011")])]

#text("Very interesting, Terry!")

#text("A traditional view among epistemologists — and one which I think remains widely held — is that knowledge is “justified true belief.” In particular, I think many philosophers would call your K operator something other than “knowledge” since you don’t want K(S) to entail S. Perhaps they would like to call it “belief,” or some unnamed intermediate value between “belief” and “knowledge?”")

#text("If you ask K(S) to entail S, then in the unexpected hanging situation I think one is forced to conclude that it is _impossible_ to know (in the “justified true belief” sense) that the hanging will be unexpected.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53048")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2011")])]

#text("Ah, I see that my choice of terminology (and my minimalistic choice of axioms) here has caused some confusion. Perhaps I would term my operators K “generalised knowledge operators”; they could represent knowledge in the “justified true belief” sense (or the more formal sense of “provability” as used by Kritchman and Raz), or they could represent knowledge in the empirical sense (obtained from (non-mathematical) inductive reasoning, for instance), or belief, but I deliberately chose to be agnostic as to which interpretation to assign to K, so that the abstract analysis I give here could be applicable to a variety of interpretations. I’ll update the text to clarify this point.")

#text("As such, I view the surprise paradox as having a number of distinct formulations (depending on one’s interpretation of K, and one’s interpretation of “surprise”), and each has a slightly different resolution, somewhat analogously to how, say, Russell’s paradox, has a number of distinct formulations and resolutions depending on the set theory one wishes to work in. In those interpretations in which knowledge is necessarily true, and commonly known to be such (thus, in my notation, ")#mi("C( K(T) \\implies T )")#text(" for all T and K), the resolution is indeed that the judge/teacher’s statement S is unknowable; the standard of knowledge here is simply too high to admit this statement as necessary truth, no matter how reliable or trustworthy the judge/teacher is.")

#text("As pointed out by several commenters, with this interpretation the paradox is no longer particularly impressive, as we are accustomed to not giving the proclamation of any authority the status of necessary truth. (A somewhat topical possible counterexample, incidentally, is the version of S found in Matthew 24:36: “No man knows the day or hour [of Christ’s return]”, though the interpretation of this sentence is subject to dispute, to put it mildly. Still, it is amusing to note that under some interpretations at least of knowledge, of S, and of the authority of the Bible, we obtain as a corollary of the surprise paradox argument that no man can obtain any finite upper bound of the day or hour of Christ’s return either.)")

#text("More interesting, in my view, is an empirical interpretation of knowledge; for instance, a model in which K(S) is true if S has been observed empirically in a large number of previous instances.")#linebreak()#text(" One can then imagine a scenario in which the surprise exam is conducted over and over again, with the hapless student always concluding that no exam can occur, and being surprised every time. In this case, what happens is that one’s empirical knowledge can lead to inconsistency. While this is not a novel observation (cf. the ")#link("http://en.wikipedia.org/wiki/Grue_and_bleen")[#text("grue paradox")]#text("), it is a somewhat “non-artificial” demonstration of this fact (analogously to how Goedel’s second incompleteness theorem demonstrates the undecidability of a “non-artificial” sentence – namely, consistency – in contrast to the first incompleteness theorem, in which the undecidable statement is clearly artificial.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53090")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2011")])]

#text("Once you have gone this far it seems natural to go all the way and model degrees of belief — i.e. to have, for each d in [0,1] an operator K_d(S) modeling “knowledge agent has degree of belief d in S,” or perhaps “has degree of belief at least d in S.” My sense is that even propositional logic runs into trouble when you try to introduce propositions whose truth is uncertain, so perhaps there are insuperable difficulties here. On the other hand, perhaps quarantining all uncertainties into statements about belief defuses problems which look difficult when we try to interpret them as uncertainty about actual truth.")

#text("Without something like this I worry that the “empirically supported belief” model will be vulnerable to sorites problems, where it is hard to see how “one more observation” can change K(S) from false to true.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53111")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2011")])]

#text("Ah, that is an interesting way to model belief. It is true that the solution to the islander puzzle starts collapsing if, say, each islander has only a 99% confidence in the logical and devout nature of the other islanders (or is only 99% confident that they heard the foreigner speak, etc.), and if islanders only commit suicide if they have, say, 90% or more confidence in their own eye colour. One can then imagine the solution holding up for small numbers of blue-eyed islanders but not for larger ones as the confidence will start decreasing as one stacks more and more 99% implications in one’s deductive chain of reasoning.")

#text("The surprise paradox seems to similarly disappear if one makes any pronouncement about a certain degree of belief, less certain than the belief in question. For instance, if a judge asserts that one will not be able to expect the hanging with 99% confidence, one might only rate this statement with a 98% confidence of correctness. In such an event, one cannot obtain any sort of contradiction or inconsistency even if the judge’s statement is commonly known.")

#text("It does seem quite hard to model this type of approximate belief rigorously, though. Bayesian probability is presumably the way to go, but one has to be careful to avoid self-referentiality.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/704b81e58ca29743b47850bb62f82d988587af8aa950d2d86ccec5d2d2505f3a-ae78c7c51eb8b92e65e74b0790dfb510525c2923707a533c2fcc07a150e39602.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of plm")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53036")[#strong[#text("plm")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2011")])]

#text("Seeing the number of comments on the previous blue eyed posts I am pretty sure a few will be disappointed at the length and complexity of this one. At least if they read that “Solution 2 is not quite accurate” there.")

#text("This may hurt sensibilities. And, if I understand correctly, if Solution 2 fails it is because t islanders commit suicide on day t<m for some other reason. But for puzzling sake we could arguably assume that islanders do not behave unpredictably, at least adding the axiom that they only commit suicide day t+1 if they know their eyes blue (a left-right arrow in (7)).")

#text("Thank you for the very nice post.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53046")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2011")])]

#text("Yes, this is the reason why Solution 2 is only accurate in a “default” sense. Unfortunately, it is difficult to formalise “do not behave unpredictably”, even if one makes (7) an if-and-only-if, it is still possible for the islanders to have access to external sources of knowledge (e.g. mirrors) that could lead one or more islanders to deduce their eye colour prematurely. (The puzzle does explicitly rule out reflective surfaces in the informal wording, but it is difficult to formalise this hypothesis in an epistemological model.) The best I can do is to come up with a model of the puzzle in which the suicides do indeed happen on the 100th day, showing that the outcome of Solution 2 is _possible_, but not _necessary_.")

#text("I did think about making a simplified version of this post purely for the purposes of “solving” the blue-eyed islander puzzle, but ultimately I decided that this would “spoil” the puzzle too much, and if were not completely formalised, it probably would not conclusively settle all doubt.")

#text("EDIT: Actually, I suppose in this case one can actually formalise the “do not behave unpredictably” assumption as follows. Call a model of an epistemic theory _minimal-knowledge_ if the only knowledge that any agent has is that knowledge which is necessarily true in all models of that theory. It seems to me that the assumptions of the blue-eyed islander puzzle are closed under intersection of knowledge, and as such, a minimal-knowledge model exists. In that model, at least, there will be no suicides until the 100th day (assuming (7) is now an if and only if).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/704b81e58ca29743b47850bb62f82d988587af8aa950d2d86ccec5d2d2505f3a-ae78c7c51eb8b92e65e74b0790dfb510525c2923707a533c2fcc07a150e39602.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of plm")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53064")[#strong[#text("plm")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2011")])]

#text("This looks like a great solution, formalizing the appearance of a second (nth?) concept of completeness in epistemic logic.")

#text("Sorry that I was mistaken on my proposed amendment.")

#text("I will probably be mistaken again, but I think I should still post the following proposals.")

#text("1. Adding another rule, the converse of the rule of epistemic inference -predictability/rationality/… rule?")

#text("2. Adding the axiom scheme K_i(\\phi)->\\phi. (I have serious doubts about this one, but the idea is that islander i should know a fact only if it is provable, so perhaps we need rather add K_i(\\phi) for \\phi axioms and then finish the definition recursively.)")

#text("3. We could look for “minimal” suicide rate models where suicides occur as late as possible. Actually, the later the suicides the more, if I am not mistaken.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53539")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2011")])]

#text("I’m trying to understand your comment about a minimal knowledge model. Let MK be your minimal knowledge model. Let model A be one where one of the islanders was insane and committed suicide early. Let model B be one where the blue-eyed islanders all commit suicide on the last day possible.")

#text("In model A there is an islander who knows on day 2 that someone has died (since suicides are public). In model B, that same islander knows that nobody has died (because he knows suicides are public, and he didn’t see any suicide). So, in model MK does that islander know someone has died or not?")

#text("[It would be interesting to have a world where that world itself has no impact on your knowledge–rather only the Platonic world of absolutes.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53540")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2011")])]

#text("Ah, I think I have to refine the notion of a minimal knowledge model a bit, in that the only k^th order knowledge present in such a world is that which is available in all worlds ")#emph[#text("with the same (k-1)^{th} order knowledge")]#text(". So one would never intersect world A with world B, because the 0^th order state of these two worlds is different.")

#text("With this new definition of minimal knowledge world, though, uniqueness becomes trickier to establish; it is not immediately obvious, for instance, that there is not a MK world in which there is a suicide on the first day, until one can first establish that on the first day in any MK world that no islander knows his or her own eye colour. One may have to “start the clock” at some finite time -N in order to be able to inductively establish uniqueness.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53542")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2011")])]

#text("I see a possible point of equivocation. Is k the depth on the order of logic (as used in your original post above), or is k the time index? From what you wrote most recently, I think you meant the time index. If I’m wrong, just let me know.")

#text("If k is the time index t, I don’t see how starting the clock helps. Your axioms do not force worlds to evolve the same way. For example, for all we know worlds A and B in the example above agree before the first day. (Or, we could modify them slightly to agree on the first day, but diverge on the second day. etc…) And knowledge is affected by what happens in the world in which you live.")

#text("As long as your set-up allows for someone to know (or not know) their eye-color on some day for no reason at all, then it will also mean that future states are not *necessary*, they are not determined. Thus opposite states can result from equivalent previous times. When this fact is paired with any axiom which *forces* islanders to know which of the opposite states exists in the actual world in which they live, that will prevent the existence of MK worlds.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53544")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2011")])]

#text("Hmm, I guess one would have to use both depth and time ordering together to get a good concept of a MK world, namely that a knowledge agent K in an MK world knows a k^th knowledge order sentence S at time n or before, thus ")#mi("MK \\models K_n(S)")#text(" if and only if ")#mi("K_n(S)")#text(" is also true in all worlds ")#mi("M")#text(" which agree with MK on all sentences of up to k^th knowledge order involving only times up to n. Branching of worlds beyond day n only affects knowledge beyond day n (because, unlike the situation with the surprise paradox, there is no mechanism for knowing anything non-tautological about the future), so this should allow for the existence of an MK world (namely, the “obvious” one in which islanders only know (as common knowledge) by the end of day n that there are at least n blue-eyed islanders, until n hits 100, at which point all the blue-eyed islanders commit suicide.)")

#text("With this setup, and initialising at, say, day 0 for simplicity, it seems to me that one can assert that in an MK world, nobody knows their eye colour at day 0 even after the foreigner speaks, and so on day 1 (by the converse of (7)), nobody commits suicide; and so forth.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53548")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2011")])]

#text("That makes a lot of sense, but I still see a small problem with your statement “With this setup, and initialising at, say, day 0 for simplicity, it seems to me that one can assert that in an MK world, nobody knows their eye colour at day 0 even after the foreigner speaks, and so on day 1 (by the converse of (7)), nobody commits suicide; and so forth.”")

#text("One last problem I see arises if we allow an infinite past. For example, let S_t be the statement: knowledge agent K knows at time t that “if nobody commits suicide at time 0 then she has blue eyes”. Suppose that the collection S_t is true for all t in our world MK. Then on day 0 the agent K sees that nobody has committed suicide, and thus knows her eye-color.")

#text("Notice that the collection S_t does not run afoul of your latest definition of an MK world, no matter when you choose to initialize your world, because of the memory axiom. (Any initial segment of the S_t implies the rest.)")

#text("An easy work-around is either to not have an infinite past, or to require the agents to be blank slates at some point (i.e. to merely know the axioms and all common knowledge).")

#text("Thanks for all the clarifications. It seems to me that your most recent formulation of an MK world is a way to put a form of determinism in your system. (One’s knowledge is determined by what came before.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53058")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2011")])]

#text("Nice post! Dumb questions: 1) Why is it surprising that the “same” problem has different solutions in different epistemic logics, or that a given abstract epistemic logic has nonisomorphic models?; 2)What is a reasonable notion of a morphism between such objects?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b9b75b8113a61248cabed1e4d5ea82454ba7c12916b54bf2850a5c0265a6031-9d123777b76c13d85aa72ef9d63b883d6e6cdd60eb63f7cab3efca6d23ab7bd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miracula")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53062")[#strong[#text("Miracula")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2011")])]

#text("In the blue-eyed islander puzzle, if the information is not symmetry, those who having the complete information die. For example, A,B,C are three blue-eyed islanders. The visitor told A that he had told B that he had told C the sentence “there exist some blue-eyed islanders” and that he had told C that he had told B the sentence. But the visitor didn’t told B (C) that he had told A that he had told C (B) the sentence or that he had told C (B) that he had told A the sentence. This case could happen in this way: the visitor met B and C together, and addressed them his speech; and then he met A, and addressed him the same speech plus the fact that he had already addressed B and C. In this case, A died in the third day, B and C survived. What the visitor has said is not important, it’s the way he says really kills people. Always the man who has the complete information is doomed to die.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29884bbba47c6be14a754803ce5ef4f246acbf49de864658588ee8546cbd08c4-926f96a1e80ba6c336337d531a4bb56248108c322a0061d9db8b005b0901ac97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giampiero Campa")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53063")[#strong[#text("Giampiero Campa")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2011")])]

#text("Very Interesting. I was also wondering whether perhaps one could represent the internal knowledge of an islander with something like a collection of matrices, in which entries 1,-1,0 indicate the belief that a certain islander has blue, non-blue or unknown-colour eyes. One could then set up initial conditions and some evolution equations (this might be tricky because such evolution equations would probably involve estimating the state of the world before updating the actual knowledge state of an islander) , and let the system evolve to see what happens …")

#text("But i am not clear on whether this is feasible at least in theory (not sure if it is possible with a finite data structure), if it would be a good idea (maybe one could prove or disprove convergence theorems or find attraction regions for the system), and what kind of data structure one could use to actually represent knowledge and belief.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53085")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2011")])]

#text("Section 1, penultimate paragraph:")#linebreak()#text(" for")#linebreak()#text(" ” to determine whether {A_1} has blue eyes or not. ”")#linebreak()#text(" read")#linebreak()#text(" “to determine whether {I_1} has blue eyes or not.”")

#text("Section 2, first bullet:")#linebreak()#text(" ” which can informally be read as “{K} knows {S} to be true” ”")#linebreak()#text(" — or more accurately")#linebreak()#text(" ” which can informally be read as “{K} believes {S} to be true” ”")#linebreak()#text(" Perhaps the distinction is irrelevant for the present application")#linebreak()#text(" — as is mentioned later in the section.")

#text("Fred Lunnon")

#emph[#text("[Corrected, thanks = T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53831")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2011")])]

#text("I’ve been thinking about this post for the last few weeks, and had some further ideas. I hope than these comments might be helpful. Each of these things is small and kind of obvious (but perhaps useful).")

#text("One of the implicit assumptions in the problem is that not only do the islanders see each other’s eyes, but they know that everyone else can see each other’s eyes, and so forth. I would recommend expanding the name of axioms 5 and 6 to make this implicit assumption explicit. This seems to be one of the key pieces that people similarly miss about the visitor’s announcement: sure, the visitor’s announcement didn’t give any new information (where there are two or more blue-eyed islanders), but the fact that you saw that other people saw his announcement (and so forth) *does* give new information.")

#text("Also, I realized (and am sure many of you did long ago) that it isn’t necessary to add the atomic propositions about suicide. Instead, one could merely replace axioms 7-9 with the axiom C(K_{i,t}(A_{i}) -> C_{t}(K_{i,t}(A_{i}))). Or, in other words, the new punishment for knowing your eye-color is that you must make it common knowledge that you know your eye-color; and this punishment is common knowledge to everyone. Then, instead of waiting for someone to commit suicide, you just wait to know that they know their eye-color. The benefits of this change are that there are not extra atomic propositions, there is no time delay of a day, and it fits a little more nicely with what I will say next.")

#text("Finally, assuming this change, the proof that all MK worlds have all blue-eyed islanders dying on the last possible day reduces to showing that at the k=1 stage, you can induct over time t (starting at some fixed time t_0) and take as your cloud of possible worlds the union of all clouds in all other models which agree up to that time. [The existence of MK worlds also seems to rely on the fact that given the k=0 and k=1 levels of a model are defined and compatible with the given axioms, then the other levels can also be defined compatible with the axioms.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53853")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2011")])]

#text("When thinking about that last part, I realized I didn’t really understand what “each M_k projects down to M_{k-1}” means, even when k=2. When k=1 I think this simply means that the first component of M_1 is that given M_0. But when k=2 there is no preferred M_1 model in M_2 (there is only M_0 and clouds of M_1 models).")

#text("What am I missing?")

#text("The reason I’m having trouble is that I realized the kth order epistemic rule in conjunction with modus ponens allows one to get higher order knowledge to imply lower order knowledge. But, it also seems like lower order knowledge is also defined in terms only on that level of the model. And it wasn’t clear to me how to make those compatible.")

#text("So, for example, one of the islanders may be insane (while also extremely logical). Thus, at the M_2 stage he might only consider worlds which never happen (or ignore important worlds that could happen) and I don’t see how these worlds need to be compatible with the M_1 stage.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53855")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2011")])]

#text("Because L_1 models projects down to L_0 models, every cloud of L_1 models projects down to a cloud of L_0 models (ignoring repetitions). As a consequence, every L_2 model projects down to an L_1 model. Continuing this procedure recursively, we see that each L_k model projects down to a L_{k-1} model for each k >= 1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53887")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2011")])]

#text("I’m not sure I understand.")

#text("Let M_0 be an L_0 model.")

#text("If I’m understanding correctly, an L_1 model is a collection consisting of a distinguished L_0 model and collections of L_0 models (one for each of the agents) corresponding to (if you will) the cloud of worlds they consider as possible. Let M_1 be such a model.")

#text("It was my understanding that M_1 and M_0 are compatible when taking the inverse limit if and only if the distinguished L_0 model in M_1 equals M_0. Is this correct? It was my impression that the clouds of possible worlds have no significance whatsoever in this compatibility. (I see I might be wrong about this as said in my bottom paragraph.)")

#text("Now, again if I’m understanding correctly, a model M_2 of L_2 consists of a distinguished L_0 model, and collections of L_1 models (one for each of the agents). I see how any element of any of the collections can map to M_1, I just don’t see how this relates to the formation of the inverse limit.")

#text("One way I see around this is that maybe there was a small typo and a model of L_k does not start with a distinguished copy of an L_0 model, but a distinguished copy of an L_{k-1} model. And this is how the inverse system is formed. In that case, I think it would be necessary (to make the higher order epistemic rules consistent with how knowledge is defined) to include in all clouds of possible worlds the actual real world.")

#text("On the other hand, by compatibility, maybe you mean that in *each* of the clouds there is a copy of the lower level model. In that case, the real world is picked out in the inverse limit simply by going to the appropriate level. But then, why the need for the distinguished L_0 model?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53890")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2011")])]

#text("M_2 consists of an L_0 model M_0, and clouds ")#mi("{\\mathcal M}_1^{(i)}")#text(" of L_1 models. We can project each cloud ")#mi("{\\mathcal M}_1^{(i)}")#text(" of L_1 models to a cloud ")#mi("{\\mathcal M}_0^{(i)}")#text(" of L_0 models by replacing each L_1 model with its L_0 projection. The original L_0 model M_0, combined with the projected clouds ")#mi("{\\mathcal M}_0^{(i)}")#text(", is then an L_1 model M_1, the projection of M_2.")

#text("For instance: suppose we have three islanders A, B, C. Consider the following nested models of reality:")

#text("M_0: A, B, C all have blue eyes.")

#text("M_1: A, B, C all have blue eyes, and know that each other have blue eyes, but do not know their own eye colour. In this case, the base L_0 world is M_0, and (say) A’s cloud ")#mi("{\\mathcal M}_0^{(A)}")#text(" consists of two L_0 worlds: the “true” L_0 world M_0, and also a second L_0 world M_0^{A,-} in which B and C still have blue eyes, but A does not. Similarly for ")#mi("{\\mathcal M}_0^{(B)}")#text(" and ")#mi("{\\mathcal M}_0^{(C)}")#text(".")

#text("M_2: A, B, C have blue eyes, know that each other has blue eyes, and know that the other islanders can see the eye colour of everyone else, but do not know their own eye colour (and know that the other islanders do not know their eye colour either). The base L_0 world is still M_0, and the cloud ")#mi("{\\mathcal M}_1^{(A)}")#text(" consists of two L_1 worlds: the “true” L_1 world M_1, and a second L_1 world M_1^{A,-} in which B and C have blue eyes and A does not, and all islanders know each other’s eye colour but not their own. (Thus, for instance, B’s L_0 cloud ")#mi("{\\mathcal M}_0^{(B)}(M_1^{A,-})")#text(" of M_1^{A,-} consists of two L_0 worlds, one in which only C has blue eyes, and one in which both B and C have blue eyes.)")

#text("To project M_2 onto M_1, we project each L_1 cloud such as ")#mi("{\\mathcal M}_1^{(A)}")#text(" to an L_0 cloud ")#mi("{\\mathcal M}_0^{(A)}")#text(" by taking each of the L_1 worlds in the former cloud (in this case, M_1 and M_1^{A,-} and replacing them with their L_0 projections (in this case, M_0 and M_0^{A,-}). In some cases this may reduce the cardinality of the cloud, although this is not the case in this particular running example. (For instance, one could consider a variant M’_2 of M_2 in which each islander allows the possibility that the other islanders somehow know their own eye colour, in which case one has to add some more L_1 worlds to ")#mi("{\\mathcal M}_1^{(A)}, {\\mathcal M}_1^{(B)}, {\\mathcal M}_1^{(C)}")#text(" to reflect these possibilities, but the projections to the L_0 clouds remain unchanged.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-53925")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2011")])]

#text("Thank you for taking the time to spell this out so completely. I think I understand now. The way I’m picturing what you said is that, thinking of these models as nested sets of nested sets, etc…, we remove the “deepest level” of the nesting. We keep all of the “distinguished” L_0 models (at any depth) and throw away the last layer of clouds. Or, in other words, to build up to the next level, we throw on possible worlds at the bottom level.")

#text("I think I also now see how to get around my issues with the higher epistemic rules. Let me describe what I was thinking and how it fits now. For simplicity, let us consider the case with only two agents A and B. Let P,Q,R,S be the four worlds corresponding to the four cases (respectively) A and B have blue eyes, A is brown-eyed and B is blue-eyed, A is blue-eyed and B is brown-eyed, and finally A and B both have brown eyes.")

#text("We start with the model M_0=P. So, the “real world” consists of both A and B having blue eyes.")

#text("Now, let M_1={P, {Q},{R}}. This model projects to M_0. We can interpret this world as the one where A believes that he has brown eyes but also believes that B has blue eyes; whereas B thinks he has brown eyes but A has blue eyes. Note in particular that neither A nor B know that their eye color is blue.")

#text("Now let M_2={P,{Q,{P},{P}},{R,{P},{P}}}. This model projects to M_1. We can interpret this world as the one where A only considers the world Q (where he has brown eyes and B has blue eyes) but in that world, he only considers the case where he believes that he will believe he has blue eyes (and he also believes that B will believe they both have blue eyes).")

#text("Let K be the predicate “A knows” and let I be the statement “A has blue eyes”. In our model, we have K(K(I)). We also have \\neg K(I). My issue was that the way I was interpreting what you were saying I thought that K(K(I)–>I) was true. But it isn’t. The statement K(I)–>I is not true in the L_1 model {Q,{P},{P}}, even though K(I) is true in that model and I is true in all of the possible worlds of that model and also in the “truly real world”. The problem is that I is not true in what that models thinks of as the real world (namely, Q).")

#text("Again, thank you for clarifying this for me.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a9120f1f38510387dd7c227e382d49a9e323d4667857475dda14dd607e23daa1-97c4d6dd15c1a4efba460f1b4a94d71b9da2e32dcc893cc7b430689278dc4394.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of del")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-90432")[#strong[#text("del")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2011")])]

#text("Interesting post! Another approach is to use “dynamic” epistemic logics, which are designed for reasoning about the kind of multi-agent information change going on in this puzzle. The simplest of these systems, Public Announcement Logic, has been used to model similar puzzles. For example, see the following:")

#link("http://www.cs.otago.ac.nz/research/publications/oucs-2004-10.pdf")[#text("Click to access oucs-2004-10.pdf")]

#link("http://www.illc.uva.nl/lgc/translation/papers/LonelyNumber.pdf")[#text("Click to access LonelyNumber.pdf")]

#link("http://www.illc.uva.nl/Research/Reports/PP-2005-06.text.pdf")[#text("Click to access PP-2005-06.text.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-142579")[#strong[#text("Голубоглазые островитяне | Блог Хеллера")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2012")]

#text("[…] Опять же по наводке Даниила подробное решение задачи опять же Терренсом Тао. В частности интересен […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-240979")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2013")])]

#text("I’ve been thinking about the blue-eyed islander puzzle, and related conundrums, on and off over the past year. I have a thought which may be of interest to those who followed this blog post last year. It relates to Löb’s theorem: ")#link("http://en.wikipedia.org/wiki/L%C3%B6b%27s_theorem")[#text("http://en.wikipedia.org/wiki/L%C3%B6b%27s_theorem")]#text(" In particular, I’m interested in whether it is possible to formalize the fact that it is common knowledge that all of the islanders are perfectly logical, while also retaining the standard solution in a complex enough system (say, encompassing first order arithmetic, to allow for diagonalization arguments).")

#text("So, here is my framework. Suppose you are one of the islanders, and you know/believe that all of the other islanders are perfectly logical. Let’s do as above, and view knowledge/belief as a predicate obeying certain rules. One axiom is the “rule of necessitation” which states that if ")#mi("p")#text(" is a valid statement (i.e. provable from the axioms), then ")#mi("K(p)")#text(" is also a valid statement. In other words, these islanders at the very least know what is provable.")

#text("Now, is this rule of necessitation, itself, common knowledge? As usually stated, the puzzle seems to point to a yes (else, what would it mean to believe the others are perfectly logical?).")

#text("So, let me ask you: if after the first day nobody has committed suicide what can you conclude? It appears that we would then know that there are no contradictions. Why? If the logical system *is* inconsistent then your fellow islanders would have found an inconsistency. They then would have killed themselves, for by the principle of ex falso quodlibet they then believe they know their eyecolor. Of course, if we now know that the system is consistent, and since the system is complicated enough to allow for Gödel numbering, this leads to a contradiction, forcing us to kill ourselves on the second day.")

#text("On the other hand, if we cannot conclude from the lack of suicides that the system is consistent, then why should we be able to conclude that the others do not know their eye color? If it is possible that they just missed some inconsistency, isn’t it just as likely that they missed something that would allow them to derive their eye color? (Indeed, if there is an inconsistency, that would be just the thing to convince them that they know their own eye color!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of It ought to be common knowledge that Donald Trump is not fit for the presidency of the United States of America | What's new")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-469271")[#strong[#text("It ought to be common knowledge that Donald Trump is not fit for the presidency of the United States of America | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("[…] of the distinction comes from the blue-eyed islander puzzle, discussed previously here, here and here on the blog. (By the way, I would ask that any commentary about that puzzle be directed to those […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e03a9fdc31333faef089085da585b8df99a8cbfd369b4259bdd8ee9e253a4c14-5fe3a1ba4c7894bd9ebdef177c274ddaef7b36792756fb9e03078400630b6649.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cosmia Nebula in Iceland")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-474270")[#strong[#text("Cosmia Nebula in Iceland")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2016")])]

#text("Concerning “formalise the other assumptions of the puzzle:”")#linebreak()#text(" I think there needs to be one more set of assumptions, that is, “Anyone who does not learn their own eye colour is blue, must not commit suicide the next day”")

#text("\\displaystyle C( \\neg K_{i,t}(A_i) \\implies \\neg S_{i,t+1} ). \\ \\ \\ \\ \\ (7)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-477039")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2017")])]

#text("Blue-eyed islanders puzzle. I have not read through all of the hundreds of posts on this site, but I’ve read about this puzzle on various websites.")#linebreak()#text(" Most suggest that the debate is about which of two possible solutions is correct. 1. that the visitor to the island imparts no new information and thus nothing happens, and 2. that the visitor’s announcement starts the induction process. My question is: why not a third solution, namely that the induction process DOES take place, but the visitor’s announcement is not needed for that to happen.")#linebreak()#text(" Since there are many versions of this puzzle I will use the one where, instead of committing ritual suicide, the islanders can leave the island. Everything else is the same. (The only reason i want to use this version is because the reasoning I am going to give is easier to phrase in this situation, because in this case the result is something the islanders all want.)")#linebreak()#text(" So, let’s say the islanders all WANT to leave the island, but when they were put on the island, they were told they can only leave if and when they know their own eye color. And there’s a boat that arrives and leaves every day at mid-day, in case any of them should find themselves in that happy situation.")#linebreak()#text(" Since there are 100 blue-eyed people, everyone knows that everyone else knows that there are many blue-eyed people there. (I know it won’t work for 3 or fewer of any color). Now, is it really necessary to have someone say out loud “I see someone with blue eyes”? Why wouldn’t the islanders, all being logical and knowing that everyone else is logical, simply ASSUME that blue eyes on the island is common knowledge, and also assume that everyone else will assume that because they too are logical. So, rather than waiting for some visitor who may or may not ever say that statement out loud, why would they not simply ACT AS IF that statement had been spoken?")#linebreak()#text(" I mean, whom would that statement benefit anyway? The hypothetical solitary blue-eyed person who, without the statement, could not leave? But hypothetical people can’t hear anyway. So it’s only for the benefit of the calculation. So why wouldn’t all these logical islanders, all of whom want to get off the island, get around that by ASSUMING the common knowledge, and start counting the days, via the induction process, from the moment they are all deposited on the island and told that they can only leave if/when they know their eye-color? Sure, in their mental calculation they can start with the case of just 1 islander, but say “In that case I will assume that someone has made it common knowledge that there is at least one blue-eyed person, and that hypothetical solitary blue-eyed person would then know it was him/her since he/she doesn’t see anyone else with blue eyes.” And they can confidently know that every other islander will be making the same assumption because they all know that everyone is perfectly logical. I mean, would they really sit around for years thinking “oh I do wish that the boat operator who comes here everyday would just announce that there is at least one blue-eyed person here, and then we can all start getting off this island!”?")#linebreak()#text(" (I don’t know if my reasoning is correct or not. I am not a mathematician, so I can’t read the formulas and symbols I sometimes see with the various explanations. I just want to where my reasoning is flawed, if it is. I’m also wondering if anyone has tested this problem in practice? e.g., by having a bunch of people in a room, putting colored stickers on their forehead and having opportunities to leave the room at regular intervals, such as every minute. (Or, maybe more people would be willing to play if, instead of leaving the room, make it so they can start eating when they’ve worked out the color. But they would all have to be very logical.) Thanks for reading!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e03a9fdc31333faef089085da585b8df99a8cbfd369b4259bdd8ee9e253a4c14-5fe3a1ba4c7894bd9ebdef177c274ddaef7b36792756fb9e03078400630b6649.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cosmia Nebula in Iceland")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-477040")[#strong[#text("Cosmia Nebula in Iceland")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2017")])]

#text("“blue eyes on the island is common knowledge” cannot be assumed, because it is not public knowledge before the announcement.")#linebreak()#text(" Consider the simple case of 2 people with blue eyes. Both know “there are blue eyes on this island”, but both do not know “everyone knows that ‘there are blue eyes on this island'”.")#linebreak()#text(" Then in the case of 3 people with blue eyes. All know “everyone knows that ‘there are blue eyes on this island'”, but something more subtle happens:")#linebreak()#text(" 1 knows that 2 and 3 has blue eyes, but 1 does not know that 1 has blue eyes. Thus 1 must consider the possible world where only 2 and 3 has blue eyes. In that world, 2 would not know that “3 knows that ‘there are blue eyes on this island'”.")#linebreak()#text(" Thus, 1 does not know that “2 knows that “3 knows that “there are blue eyes on this island”””, even though 2 knows that “3 knows that “there are blue eyes on this island””.")#linebreak()#text(" After the public announcement, everyone knows that everyone knows that everyone knows that there are blue eyes on this island, and in particular, 1 knows that “2 knows that “3 knows that “there are blue eyes on this island”””, thus this public announcement gave them new information.")

#text("Now, if you think hard about the 3 blue eyes case, you can generalize to the general case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-477041")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2017")])]

#text("Thank you for your reply! I have thought it out for the case of 1 blue-eyed person, two blue-eyed people, three blue-eyed people, and more, and I understand the reasoning. I’ve drawn numerous charts over the last few months, and can see that one will always get down to that situation where there is one blue-eyed person who will not know until the public announcement. But I took all of that into account and suggested that I nevertheless think there may be a another solution. I am wondering where specifically my reasoning goes wrong, if it does. (Which is a bit different from asking for the correct solution. And I know my post was very long, and I apologize for that, but it had to be in order to explain what I mean. Because it surprises me that I have not read my argument in any of the posts (but, as I stated at the start, I have not read everything on this thread, although I have read much about this puzzle.) Thanks again for replying!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e03a9fdc31333faef089085da585b8df99a8cbfd369b4259bdd8ee9e253a4c14-5fe3a1ba4c7894bd9ebdef177c274ddaef7b36792756fb9e03078400630b6649.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cosmia Nebula in Iceland")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-477043")[#strong[#text("Cosmia Nebula in Iceland")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2017")])]

#text("It would benefit to think about the symmetry of the situation. Suppose they suddenly decide to “count the days”, how would they decide at the same time without communication? The only communication, remember, is the act of leaving the island.")#linebreak()#text(" So they can’t decide to count the days at the same day without something to “synchronize” them, such as the public annoucement.")

#text("They cannot assume that blue eyes on the island is common knowledge, because it is not common knowledge, which I explained why in my last comment.")

#text("They would sit around for years thinking “oh I do wish that the boat operator who comes here everyday would just announce that there is at least one blue-eyed person here, and then we can all start getting off this island!”, because that would give them new information.")

#text("Imagine the island has exactly 2 people, person 1 has red eyes, person 2 has blue eyes.")#linebreak()#text(" Suppose person 1 gets tired of waiting and decides to pretend there had been a public announcement “there is at least one blue eye” in the afternoon of day 1.")#linebreak()#text(" Then at the noon of day 2, he sees that person 2 hasn’t left, and would think that this logically proves that he has blue eyes.")#linebreak()#text(" Then at the noon of day 3 he went to the boat operator and says he has blue eyes, and of course gets it wrong.")#linebreak()#text(" Person 1 goes back and gets so angry that he becomes able to speak, so he asks why hasn’t person 2 left. Person 2 replies with surprise, since he has always thought that both of them probably has red eyes.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-477049")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2017")])]

#text("Thanks. That’s interesting, and I will have to think about it a lot more.")#linebreak()#text(" The examples with 1, 2, or even 3 people clearly don’t work without the announcement. But the original puzzle says there are 100 blue-eyed people.")#linebreak()#text(" I thought that the people WILL have a synchronization point at which to start calculating, and it would be the moment when, as they are deposited on the island, they are told by the boat operator: “here you stay, until you work out your eye-color. If you ever do”. That would be Day 1.")#linebreak()#text(" However, I don’t know if that changes the initial premise of the puzzle and if THAT announcement has a similar effect to that of the visitor in the Terry Tao version. It would be interesting to see if this apparently slight change to the initial puzzle does, in fact, lead to a different result. And I’ll have to do a lot more thinking about it all before I reject my reasoning, which I will happily reject if/when I see it to be incorrect.")#linebreak()#text(" What I really need to do is get about 30 logicians at a dinner party, put stickers on their foreheads, and say they can’t start eating until they know their sticker color, with opportunities for them to announce their color every minute or so. Trouble is, I don’t know many logicians and most of my friends tend to run the other way whenever I start to mention this puzzle… :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-477050")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2017")])]

#text("I should add that in the dinner party experiment, in order to ensure synchronization, they should all be given a few minutes to just look around at every one else, after which the person conducting the experiment can say, “okay, opportunities to announce you sticker color will be when the timer rings, which it will every minute, beginning NOW.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e03a9fdc31333faef089085da585b8df99a8cbfd369b4259bdd8ee9e253a4c14-5fe3a1ba4c7894bd9ebdef177c274ddaef7b36792756fb9e03078400630b6649.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cosmia Nebula in Iceland")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-477053")[#strong[#text("Cosmia Nebula in Iceland")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2017")])]

#text("If you want that experiment, 3 people is good enough. If you want a big experiment, you’d have to use the Internet.")

#text("Besides, imagine 3 people, 1 blue, 1 green, 1 red. The announcer came and said, “beginning NOW”.")#linebreak()#text(" How are they going to decide which color to synchronize to??")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-477054")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2017")])]

#text("I agree that in that situation it would definitely not work. I will continue to fine-tune my thinking about this, using the situation where, like in the original puzzle, there are only blues and many browns, and many of them, so everyone can see lots of just 2 colors and may think that he/she is the only one with a third color if there were a third color, which of course they don’t know. Will probably post something in a few days after I’ve had a chance to rethink… (But SO GLAD that someone’s willing to discuss this with me!!!!!! Thank you!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-477055")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2017")])]

#text("No idea why that last post listed me as Anonymous. Still new to this…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f1bb8be4ae3b23e53e391cf18517b602e0fa28f9a20a334d645ad3b095bfae9-c20e886f7976c323cabaa3259f93d299bc2f346ed43977043916be5bb341a9f9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lensgravatar")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-484422")[#strong[#text("lensgravatar")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2017")])]

#text("Argument by induction works on a mathematical model where you have proved the statement true for 1 and know that if it is true for n then it is true for n+1. Also, it is well known that if you assume a premise to be true that is actually false, then you can prove pretty much anything you want. A lot of paradoxes play off this notion by having a loosely defined situation. So, for example, if you start with “If 1=2 then…” you are toast. In this puzzle if there are more than 3 blue eyed people, then everyone knows there are more than 1 blue eyed person. So you cannot start a valid argument by induction by saying “If there was one blue eyed person…”, because it is a false premise. So the paradox arises by conflating logic with a situation. Interesting to watch Tao dig ever deeper holes for himself on this one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-484424")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2017")])]

#text("Thanks, lensgravatar, you may have unraveled the mystery!")

#text("But first, there seem to be 2 similar threads, one called The Blue eyed islanders, the other called Epistemic logic. I originally posted on the latter, but recently have been posting on the former, so I don’t know if you have read what I wrote there.")

#text("I too was skeptical about including the n =1, n = 2, or n =3 scenarios in a situation where everyone can see at least 99 blue-eyed people.")

#text("So here is a re-post of what I put on the other thread a few days ago. I wonder if you would agree with it. (note that I wrote it before I read your response because it was on a different thread)")

#text("The induction process sounds logical. And yet.. I wonder if one can really base everything on a hypothetical situation where there is just one blue eyed person when everyone knows there are at least 99 of them..Because that’s what is happening in all the nested scenarios – one always ends up with that hypothetical situation where there is just one blue-eyed islander, and because he/she has not heard the announcement nothing can happen. (But – hypotheical people cannot hear anyway!!!)")

#text("Since it is easier (at least for me) to imagine scenarios where the outcome is something the islanders want (like being able to leave the island) rather than something they would wish to avoid (like ritual suicide) I will go back to the scenario I proposed a few posts earlier – where instead of ritual suicide the goal is to get off the island, and when the people were put on the island they were told (all at once) that they can leave only if/when they know their eye color. And a boat comes and goes every day to give them the chance to leave if they can.")

#text("Since they are all logical people and know that everyone else is logical too, would they really sit around for years thinking “oh I do wish that the boat operator who comes here every day would just hurry up and announce that there is at least one blue-eyed person here (which we all already know anyway) so we can start getting off this island!”?")

#text("Why not just ASSUME (i.e., ACT AS IF) the boat operator had made the announcement. Being logical they would know that everyone would think so too. (They could still start with the one person scenario for the purpose of calculating WHEN they can leave, but those calculations can begin as soon as they are told the rules about leaving. THAT would then be the clock starter, and not the announcement about eye color, since the color they could work out as long as they make the assumption mentioned above.)")

#text("If someone could explain to me if this is correct or, if not, where the fault is in this argument, that would be great.")

#text("(I will be away from the internet for a few days so will not be able to respond to any comments during that time)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/560be6052c738bdff3c3c936a1af2f19d1f598968c0a17b886c8bbbd58e62dce-ad53ec62f789fc26f08664515a977ab1b920c63e93d1e67b4f0e68cef1ddc717.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous Coward")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-506241")[#strong[#text("Anonymous Coward")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2018")])]

#text("I could have sworn I had read this one, yet it took me quite some searching to find it … Sir Terence, if you don’t mind tagging the blue-eyed islanders posts so they can be all be found from one another? See here:")

#link("https://terrytao.wordpress.com/tag/blue-eyed-islanders/")[#text("https://terrytao.wordpress.com/tag/blue-eyed-islanders/")]#linebreak()#text(" ")#link("https://terrytao.wordpress.com/tag/blue-eyed-islander-puzzle/")[#text("https://terrytao.wordpress.com/tag/blue-eyed-islander-puzzle/")]#linebreak()#text(" You have used two distinct tags :-/")

#text("Apart from that, I am grateful for this post. While I could accept the induction argument for what I could see it did prove, I could not by any means accept it as a proof that they had to last as long as ’til the nth day.")#linebreak()#text(" And I see that the Wikipedia article on common knowledge still posts the induction “proof” without any reservation that it is an upper bound.")

#emph[#text("[Tag changed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8db163ee2080530d530ad01e00b4f831e42348d8e0c11cecb9c0298815b6a4f0-c5d8d8d6496d0e650b45f0d3097ff78f97b9aeaca6fce1792c38496673e0c2d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Think")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-506269")[#strong[#text("Think")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2018")])]

#text("People talk about simulating reality. How does one go about simulating this without feeding in the rule of deliberate suicide apriori? Everything is deterministic in effect. However the way the puzzle is formulated seems to introduce some sort of free will.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d5448d3f529d2d0b1538acf67d6d82160656f1744f87a12d86bf97c5baa76752-eb66d613c5aa0f712770db4021c00db0d63d08a231f9579907f34d3f48863aaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexandru Soare")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-506337")[#strong[#text("Alexandru Soare")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2018")])]

#text("A suggestion that may at first seem outside of this subject and the like, but with some thought may be realized to be relevant:")

#text("The Shape of Goodness")

#text("1. All things want to be that which they truly are and no thing else; often they do not know what they truly are, and this is unhappiness, pain.")#linebreak()#text(" 2. An evil thing is, what it truly is, is something that prevents or seeks to prevent other things from being what they truly are (or confuse the subject); and an evil thing would wish to be no thing else.")#linebreak()#text(" 3. We have two categories, one of all that is not evil (good), and the other being evil. Goodness can speak for all that is not evil (good) and says that the difference between the two is in fact not only the previous categorical difference, but also very much greater, the greatest difference possible, always more, entirely spiritual beyond measure, and goodness says this because it is more good for this to be thus.")#linebreak()#text(" 4. Good and evil are not opposites; they are very different, no reflection down any axis. The opposite of a good thing in every way is another good thing, and the opposite of an evil thing in every way is another evil thing.")#linebreak()#text(" 5. Goodness is the only categorical thing the opposite of which is entirely contained within itself. The shape of goodness is a box whose opposite is fully within it; that is, a protrusion of it is the opposite of the entire ensemble of box and protrusion, and it can easily be computed, and seen to be a Klein-bottle like shape. Systems which fit within such boxes are likely good, functional.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-539752")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2020")])]

#text("Dear Pro. Tao,")#linebreak()#text(" I was really puzzled about the blue-eyes island problem for the first time I saw it, However, I finally found the argument 2 just an inconspicuously wrong use of reduction to absurdity (though it is more like induction!). The reason is as follow:")

#text("1. If we regard argument 2 as induction, it means that for every n=1,2…100, there is a foreigner saying “blue-eyed people exist”. In fact, foreigner only said it for n=100, so argument 2 is not induction.")

#text("2. We can change argument 2 to other word which is more like reduction to absurdity: people-1 assumes himself brown eyes, then he wants to deduce that other 99 blue-eyed people will die on the 99th day. The specific deduction of people-1 is the reduction to absurdity of people-2 who assumes himself brown eyes, then wants to deduce that other 98 blue-eyed people will die on the 98th day. Reduction to absurdity is go on like this until people-100.")

#text("3. Unfortunately, this reduction to absurdity is totally wrong for which it violates a basic rule—–if the assumption may change other certain precondition (especially when we even don’ t know it is true or false!), then the precondition should only be used to compare finally, rather than be still used to deduce as correct precondition (after assuming, the precondition may be wrong). In the blue-eyes island problem, once a people assuming himself brown eyes, the information of “blue-eyed people exist” may change (actually change at people-98), then the deduction base on “blue-eyed people exist” is no longer reliable (because the assumption may be wrong).")

#text("I believe from begin to end: no new information, and no new result!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-539756")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2020")])]

#text("supplement for 3: After people-1 assuming himself brown eyes, the assumption of people-2 is actually people-1 and people-2 are both brown eyes (because he just think about the rest 98 people). On his view, people-1 is blue-eyed, his assumption is wrong, so the precondition “blue-eyed people exist” should be revalued!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6da0cc12f8e10a619c95b86bbbcc19ebbeb5b64c256f9061d2e4c4fcb98ebb78-5f4bcddae8d934d534c2dd7f137008b48260152b38488f3826a5a8c401cb92c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-539763")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2020")])]

#text("There is a pretty clean information theoretic argument for this in the number on forehead model in communication complexity. I am surprised that this result is not thought to be that unsurprising. Please look up NOF model.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd355f89eabe8e858afc8ffffdea8eabd57b3c42ab01963ef718ec454d0b333e-ffc26dfc1f80edc741e217bb2245f5a5ddc1a8d9de2d2d79760ef95bbe73fff9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brad Fortner")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-637498")[#strong[#text("Brad Fortner")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2021")])]

#text("After giving this problem some more thought, I would like to retract any previous comments I may have posted. The formal notation of logic is interesting, but in my opinion, it describes the problem without solving it. The following is my best attempt at a solution, containing several conditional solutions, and only employing basic reasoning, and leaving the symbolic logic for others to use.")#linebreak()#text(" This problem, along with its many variants and similar problems, reminds me of Schelling Points, and in fact, they may be examples of that concept. A Schelling Point exists among logical minds, whenever there is no explicit information, and yet there is an option, recognized by some players, that naturally stands out from the other options. Accepting a Schelling Point as the best option, and acting on that option, implies that the players who do so are motivated to err on the side of action. This relates to the Blue-Eyed Islanders Problem, in that its solution depends on several conditions, the motivation of the islanders to act being one of those conditions.")#linebreak()#text(" The fact that the islanders existed, still on the island, at the time of the visit by the outsider means one of two things. Either they were in the process of counting the days until they would take action, or they were not in that process, due to uncertainty. In the first case, the visitor’s announcement would not give new information, and they would continue the countdown (the Islanders Problem is solved for that condition). In the second case, the announcement would have to give certainty in the knowledge everyone needed to start a countdown. They could have started a countdown earlier, but uncertainty prevented it. Perhaps they were lacking the knowledge that everyone was a pefect logician. Or maybe they were unsure that everyone knew their day of arrival. Or perhaps they arrived on different days, and not all of the arrival dates were known to be known by everyone. The announcement by the visitor would have to clear up any and all uncertainty, and it must effectively reset the starting date for any possible countdown. The previous time must be ignored, since it held uncertainty, and a new era must begin, with no uncertainty.")#linebreak()#text(" Does the visitor’s announcement achieve these two requirements – 1. Give certainty in perfect knowledge by everyone, about everyone (other than their own eye color). 2. Give the logical starting point for a countdown. It seems that if (1) is met, then (2) is also achieved, and the logical start for a countdown is the day that (1) is achieved. So… is (1) achieved by the visitor’s announcement? If so, then we have another conditional solution to the Islanders Problem. That is, if we assume that some islanders are unsure about the knowledge of all of the islanders, then (1) is not achieved, because the visitor does not address the islanders’ capacity for using logic, or the uniformity of this trait over all islanders. The visitor says nothing that clears up uncertainty that some islanders may have about other islanders. The islanders will not begin a countdown, and will not take action at this time. Alternatively, if we assume that the only uncertainty among the islanders is the date of everyone having the required information (the starting point), then (1) is already met, and the visitor’s announcement must be enough to achieve (2) on its own, in order to begin the countdown. It seems that the visitor’s announcement about eye color is a landmark on the collective psyche of the islanders, and is the only thing needed to begin a countdown by people who are certain about their shared knowledge, and are clearly motivated to take action at the first opportunity. Whether the Problem involves escaping from the island by boat, or leaving this space-time realm by death, the islanders are very motivated to act on their knowledge. Under this last condition, they will err on the side of action.")#linebreak()#text(" Brad Fortner – 11/26/2021")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/#comment-685782")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2024")])]

#text("I recently came across the Prisoner’s Riddle, which is more of a combinatorial problem but possibly to your tastes! ")#link("https://www.youtube.com/watch?v=iSNsgj1OCLA")[#text("https://www.youtube.com/watch?v=iSNsgj1OCLA")]
]
