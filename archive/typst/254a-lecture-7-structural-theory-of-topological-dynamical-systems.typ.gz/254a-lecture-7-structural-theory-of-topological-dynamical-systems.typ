// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/
// Converted to Typst by tao2typ: "2026-10-14T06:53:10.563935+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Lecture 7: Structural theory of topological dynamical systems", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Lecture 7: Structural theory of topological dynamical systems")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 January 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/")[#text("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("In our final lecture on topological dynamics, we discuss a ")#link("http://www.ams.org/mathscinet-getitem?mr=157368")[#text("remarkable theorem of Furstenberg")]#text(" that classifies a major type of topological dynamical system – ")#emph[#text("distal")]#text(" systems – in terms of highly structured (from an algebraic point of view) systems, namely towers of isometric extensions. This theorem is also a model for an important analogous result in ergodic theory, the ")#emph[#text("Furstenberg-Zimmer structure theorem")]#text(", which we will turn to in a few lectures. We will not be able to prove Furstenberg’s structure theorem for distal systems here in full, but we hope to illustrate some of the key points and ideas.")

#metadata(none) <tao-6f80a7691cd070e0707b>

#text("— Distal systems —")

#text("Furstenberg’s theorem concerns a significant generalisation of the equicontinuous (or isometric) systems, namely the ")#emph[#text("distal")]#text(" systems.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1.")]#text(" (Distal systems) Let ")#mi("(X,{\\mathcal F}, T)")#text(" be a topological dynamical system, and let d be an arbitrarily metric on X (it is not important which one one picks here). We say that two points x, y in X are ")#emph[#text("proximal")]#text(" if we have ")#mi("\\lim \\inf_{n \\to \\infty} d(T^n x, T^n y) = 0")#text(". We say that X is distal if no two distinct points ")#mi("x \\neq y")#text(" in X are proximal, or equivalently if for every distinct x, y there exists ")#mi("\\varepsilon > 0")#text(" such that ")#mi("d(T^n x, T^n y) \\geq \\varepsilon")#text(" for all n.")
]

#text("It is obvious that every isometric or equicontinuous system is distal, but the converse is not true, as the following example shows:")

#strong[#text("Example 1. ")]#text(" If ")#mi("\\alpha \\in {\\Bbb R}")#text(", then the skew shift ")#mi("( ({\\Bbb R}/{\\Bbb Z})^2, (x,y) \\mapsto (x+\\alpha,y+x))")#text(" turns out to be not equicontinuous; indeed, if we start with a pair of nearby points ")#mi("(0,0), (1/2n,0)")#text(" for some large n and apply ")#mi("T^n")#text(", one ends up with ")#mi("(n\\alpha, \\frac{n(n-1)}{2}\\alpha)")#text(" and ")#mi("(n\\alpha, \\frac{n(n-1)}{2}\\alpha + \\frac{1}{2})")#text(", thus demonstrating failure of equicontinuity. On the other hand, the system is still distal: given any pair of distinct points ")#mi("(x,y), (x^{\\prime},y^{\\prime})")#text(", either ")#mi("x \\neq x^{\\prime}")#text(" (in which case the horizontal separation between ")#mi("T^n (x,y)")#text(" and ")#mi("T^n(x^{\\prime},y^{\\prime})")#text(" is bounded from below) or ")#mi("x = x^{\\prime}")#text(" (in which case the vertical separation is bounded from below). ")#mi("\\diamond")

#strong[#text("Exercise 1")]#text(". Show that any non-trivial Bernoulli system ")#mi("\\Omega^{\\Bbb Z}")#text(" is not distal. ")#mi("\\diamond")

#text("Distal systems interact nicely with the action ")#mi("p \\mapsto T^p")#text(" of the compactified integers ")#mi("\\beta {\\Bbb Z}")#text(":")

#strong[#text("Exercise 2")]#text(". Let ")#mi("(X, {\\mathcal F}, T)")#text(" be a topological dynamical system.")

#enum(start: 1, 
[#text("Show that two points x, y in X are proximal if and only if ")#mi("T^p x = T^p y")#text(" for some ")#mi("p \\in \\beta {\\Bbb Z}")#text(".")],
[#text("Show that X is distal if and only if all the maps ")#mi("T^p")#text(" for ")#mi("p \\in \\beta {\\Bbb Z}")#text(" are injective.")],
[#text("If X is distal, show that ")#mi("T^p = \\text{id}")#text(" whenever ")#mi("p \\in \\beta{\\Bbb Z}")#text(" is idempotent. (Hint: use part 2.)")],
[#text("If X is distal, show that the set of transformations ")#mi("G := \\{ T^p: p \\in \\beta {\\Bbb Z} \\}")#text(" on X forms a group, known as the ")#emph[#text("Ellis group")]#text(" of X. (Hint: use part 3, together with Lemma 3 from ")#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/")[#text("Lecture 5")]#text(".) Show that G is a compact subset of ")#mi("X^X")#text(" (with the product topology), and that G acts transitively on X if and only if X is minimal. ")#mi("\\diamond")]
)

#strong[#text("Exercise 3.")]#text(" Show that an inverse limit of a totally ordered set ")#mi("(Y_{\\alpha})_{\\alpha \\in A}")#text(" of distal factors is still distal. (This turns out to be slightly easier than Lemma 1 from the ")#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/")[#text("previous lecture")]#text(".) ")#mi("\\diamond")

#strong[#text("Exercise 4")]#text(". Show that every topological dynamical system has a maximal distal factor. (Hint: repeat the proof of Corollary 1 from the ")#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/")[#text("previous lecture")]#text(".) ")#mi("\\diamond")

#strong[#text("Exercise 5.")]#text(" Show that any distal system can be partitioned into disjoint minimal distal systems. (One can of course adapt the proof of Proposition 2 from the ")#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/")[#text("previous lecture")]#text(" to do this; but there is a slicker way to do it by exploiting the Ellis group.) ")#mi("\\diamond")#linebreak()#text(" Note that the skew shift system, while not isometric, does have a non-trivial isometric factor, namely the circle shift ")#mi("({\\Bbb R}/{\\Bbb Z}, x \\mapsto x+\\alpha)")#text(" with the projection map ")#mi("\\pi: (x,y) \\mapsto x")#text(". It turns out that this phenomenon is general:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" (Baby ")#link("http://www.ams.org/mathscinet-getitem?mr=157368")[#text("Furstenberg structure theorem")]#text("). Let ")#mi("(X,{\\mathcal F},T)")#text(" be minimal, distal and non-trivial (i.e. not a point). Then X has a non-trivial isometric factor ")#mi("\\pi: X \\to Y")#text(".")
]

#text("This result – a toy case of Furstenberg’ s full structure theorem – is already rather difficult to establish. We will not give Furstenberg’s original proof here (though see Exercise 13 below), but will at least sketch how the factor ")#mi("\\pi: X \\to Y")#text(" is constructed. A key object in the construction is the symmetric function ")#mi("F: X \\times X \\to {\\Bbb R}^+")#text(" defined by the formula")

#mi("F(x,y) := \\inf_{n \\in {\\Bbb Z}} d( T^n x, T^n y )")#text(". (3)")

#strong[#text("Example 2.")]#text(" We again consider the skew shift ")#mi("(({\\Bbb R}/{\\Bbb Z})^2, (x,y) \\mapsto (x+\\alpha,y+x))")#text(" with ")#mi("\\alpha")#text(" irrational. For sake of concreteness let us choose the taxicab metric ")#tao-math("d((x,y),(x^{\\prime},y^{\\prime})) := \\left\\|x-x^{\\prime}\\right\\|_{{\\Bbb R}/{\\Bbb Z}} + \\left\\|y-y^{\\prime}\\right\\|_{{\\Bbb R}/{\\Bbb Z}}", block: false)#text(", where ")#tao-math("\\left\\|x\\right\\|_{{\\Bbb R}/{\\Bbb Z}}", block: false)#text(" is the distance from x to the integers. Then one can check that ")#mi("F( (x,y),(x^{\\prime},y^{\\prime}) )")#text(" is equal to ")#tao-math("\\left\\|x-x^{\\prime}\\right\\|_{{\\Bbb R}/{\\Bbb Z}}", block: false)#text(" when ")#mi("x - x^{\\prime}")#text(" is irrational, and equal to ")#tao-math("\\left\\|x-x^{\\prime}\\right\\|_{{\\Bbb R}/{\\Bbb Z}} + \\frac{1}{q} \\left\\|q(y-y^{\\prime})\\right\\|_{{\\Bbb R}/{\\Bbb Z}}", block: false)#text(" when ")#mi("x-x^{\\prime}")#text(" is rational, where q is the least positive integer such that ")#mi("q(x-x^{\\prime})")#text(" is an integer. Thus F is highly discontinuous, but it is at least upper semi-continuous in each of its two variables. (Actually, the upper semi-continuity of F holds for arbitrary topological dynamical systems, since F is the infimum of continuous functions.) ")#mi("\\diamond")

#strong[#text("Exercise 6.")]#text(" Let G be the Ellis group of a minimal distal system X.")

#enum(start: 1, 
[#text("For any ")#mi("x,y \\in X")#text(", show that ")#mi("F(x,y) = \\inf_{g \\in G} d(gx, gy)")#text(". In particular, ")#mi("F(gx,gy) = F(x,y)")#text(" for all ")#mi("g \\in G")#text(".")],
[#text("For any ")#mi("x,y \\in X")#text(", show that the set ")#mi("\\{ (gx, gy): g \\in G \\}")#text(" is a minimal subsystem of ")#mi("X \\times X")#text(" (with the product shift ")#mi("(x,y) \\mapsto (Tx, Ty)")#text(". Conclude in particular that if ")#mi("F(x,y) < a")#text(", then the set ")#mi("\\{ n \\in {\\Bbb Z}: d(T^n x, T^n y) < a )\\}")#text(" is syndetic.")],
[#text("If ")#mi("x,y \\in X")#text(" and ")#mi("a > 0")#text(" is such that ")#mi("F(x,y) < a")#text(", show that there exists ")#mi("\\varepsilon")#text(" such that ")#mi("F(x,z) < a")#text(" whenever ")#mi("d(y,z) < \\varepsilon")#text(".")],
[#text("Let ")#mi("X_F = (X, {\\mathcal F}_F)")#text(" be the space X whose topology is generated by the basic open sets ")#mi("U_{a,x} := \\{ y \\in X: F(x,y) < a \\}")#text(". (That this is a base follows from 3.) Equivalently, ")#mi("X_F")#text(" is equipped with the weakest topology on which F is upper semi-continuous in each variable. Show that ")#mi("X_F")#text(" is a weaker topological space than X (i.e. the identity map from X to ")#mi("X_F")#text(" is continuous); in particular, ")#mi("X_F")#text(" is compact. Also show that all the maps in G are homeomorphisms on ")#mi("X_F")#text(". ")#mi("\\diamond")]
)

#text("If ")#mi("X_F")#text(" were ")#link("http://en.wikipedia.org/wiki/Hausdorff_space")[#text("Hausdorff")]#text(", then the system ")#mi("(X_F, {\\mathcal F}_F, T)")#text(" would be equicontinuous, by Exercise 2 from the ")#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/")[#text("previous lecture")]#text(". Unfortunately, ")#mi("X_F")#text(" is not Hausdorff in general. However, it turns out that we can “quotient out” the non-Hausdorff nature of ")#mi("X_F")#text(". Define the equivalence relation ")#mi("\\sim")#text(" on ")#mi("X_F")#text(" by declaring ")#mi("x \\sim y")#text(" if we have ")#mi("F(x,z) = F(y,z)")#text(" for all z outside of a set of the first category in X. This is clearly an equivalence relation, and so we can create the quotient space ")#mi("Y := X_F/\\sim")#text("; since X embeds into ")#mi("X_F")#text(" we thus have a factor map ")#mi("\\pi: X \\to Y")#text(". It is a deep fact (which we will not prove here) that this quotient space is non-trivial and Hausdorff, and that ")#mi("\\sim")#text(" is preserved by the shift T and even by the Ellis group G (thus if ")#mi("x \\sim y")#text(" and ")#mi("g \\in G")#text(" then ")#mi("gx \\sim gy")#text(". Because of this, G continues to act on Y homeomorphically, and so by Exercise 2 from the ")#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/")[#text("previous lecture")]#text(", ")#mi("\\pi: X \\to Y")#text(" is a non-trivial isometric factor of X as desired.")

#strong[#text("Exercise 7.")]#text(" Show that in the case of the skew shift (Example 2), this construction recovers the factor that was discussed just before Theorem 1. (The trickiness of this exercise should already give you some idea of the difficulty level of Theorem 1.) ")#mi("\\diamond")

#text("— The Furstenberg structure theorem for distal systems —")

#text("We have already noted that isometric systems are distal systems. More generally, we have")

#strong[#text("Exercise 8.")]#text(" Show that an isometric extension of a distal system is still distal. (Hint: Example 1 is a good model case.) ")#mi("\\diamond")

#text("Thus, for instance, the iterated skew shifts that appear in (5) from ")#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-24974")[#text("the previous lecture")]#text(" are distal. Also, recall from Exercise 7 that the inverse limit of distal systems is again distal. It turns out that these are the ")#emph[#text("only ")]#text("ways to generate distal systems, in the following sense:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(". (")#link("http://www.ams.org/mathscinet-getitem?mr=157368")[#text("Furstenberg’s structure theorem for distal systems")]#text(") Let ")#mi("(X, {\\mathcal F}, T)")#text(" be a distal system. Then there exists an ")#link("http://en.wikipedia.org/wiki/Ordinal_number")[#text("ordinal")]#text(" ")#mi("\\alpha")#text(" and a factor ")#mi("Y_\\beta")#text(" for every ")#mi("\\beta \\leq \\alpha")#text(" with the following properties:")

#enum(start: 1, 
[#mi("Y_\\emptyset")#text(" is a point.")],
[#text("For every ")#link("http://en.wikipedia.org/wiki/Successor_ordinal")[#text("successor ordinal")]#text(" ")#mi("\\beta+1 \\leq \\alpha")#text(", ")#mi("Y_{\\beta+1}")#text(" is an isometric extension of ")#mi("Y_\\beta")#text(".")],
[#text("For every ")#link("http://en.wikipedia.org/wiki/Limit_ordinal")[#text("limit ordinal")]#text(" ")#mi("\\beta \\leq \\alpha")#text(", ")#mi("Y_\\beta")#text(" is an inverse limit of the ")#mi("Y_\\gamma")#text(" for ")#mi("\\gamma < \\beta")#text(".")],
[#mi("Y_\\alpha")#text(" is equal to X.")]
)
]

#text("The collection of factors ")#mi("(Y_\\beta)_{\\beta \\leq \\alpha}")#text(" is sometimes known as a “Furstenberg tower”.")

#text("Theorem 2 follows by applying Zorn’s lemma with the following key proposition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1. ")]#text("(Key inductive step) Let ")#mi("(X,{\\mathcal F},T)")#text(" be a distal system, and let Y be a proper factor of X (i.e. the factor map is not an isomorphism). Then there exists another factor Z of X which is a proper isometric extension of Y.")
]

#text("Note that Theorem 1 is the special case of Proposition 1 when Y is a point. Indeed, Proposition 1 is proven in the same way as Theorem 1, but with several additional technicalities which I will not discuss here; see the ")#link("http://www.ams.org/mathscinet-getitem?mr=157368")[#text("original paper of Furstenberg")]#text(" for details.")

#strong[#text("Exercise 9.")]#text(" Deduce Theorem 2 from Proposition 1 and Zorn’s lemma. ")#mi("\\diamond")#linebreak()#text(" ")#strong[#text("Remark 1.")]#text(" It is known that in Theorem 2, one can take the ordinal ")#mi("\\alpha")#text(" to be countable, and ")#link("http://www.ams.org/mathscinet-getitem?mr=1417768")[#text("conversely")]#text(" that for every countable ordinal ")#mi("\\alpha")#text(", there exists a system whose smallest Furstenberg tower has height ")#mi("\\alpha")#text(". ")#mi("\\diamond")

#strong[#text("Remark 2.")]#text(" Several generalisations and extensions of Furstenberg’s structure theorem are known, but they are somewhat technical to state and will not be detailed here; see this ")#link("http://www.ams.org/mathscinet-getitem?mr=1774426")[#text("survey of Glasner")]#text(" for a discussion. ")#mi("\\diamond")

#text("— Weak mixing and isometric factors —")

#text("We have seen that distal systems always contain non-trivial isometric factors. What about more general systems? It turns out that there is in fact a nice dichotomy between systems with non-trivial isometric factors, and those without.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2.")]#text(" (Topological transitivity) A topological dynamical system ")#mi("(X, {\\mathcal F}, T)")#text(" is ")#emph[#text("topologically transitive")]#text(" if, for every pair U, V of non-empty open sets, there exists an integer n such that ")#mi("T^n U \\cap V \\neq \\emptyset")#text(".")
]

#strong[#text("Exercise 10")]#text(". Show that a topological dynamical system is topologically transitive if and only if it is equal to the orbit closure of one of its points. (Compare this with minimal systems, which is the orbit closure of ")#emph[#text("any")]#text(" of its points. Thus minimality is stronger than topological transitivity; for instance, the compactified integers ")#mi("\\{-\\infty\\} \\cup {\\Bbb Z} \\cup \\{+\\infty\\}")#text(" with the usual shift is topologically transitive but not minimal.) ")#mi("\\diamond")

#strong[#text("Exercise 11. ")]#text("Show that any factor of a topologically transitive system is again topologically transitive. ")#mi("\\diamond")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3. ")]#text("(Topological weak mixing) A topological dynamical system ")#mi("(X, {\\mathcal F}, T)")#text(" is ")#emph[#text("topologically weakly mixing")]#text(" if the product system ")#mi("X \\times X")#text(" is topologically transitive.")
]

#strong[#text("Exercise 12. ")]#text("A system is said to be ")#emph[#text("topologically mixing")]#text(" if for every pair U, V of non-empty open sets, one has ")#mi("T^n U \\cap V \\neq \\emptyset")#text(" for all sufficiently large n. Show that topological mixing implies topological weak mixing. (The converse is false, but actually constructing a counterexample is somewhat tricky.) ")#mi("\\diamond")

#strong[#text("Example 3. ")]#text("No circle shift ")#mi("({\\Bbb R}/{\\Bbb Z}, x \\mapsto x+\\alpha)")#text(" is topologically weak mixing (or topologically mixing), even though such shifts are minimal (and hence transitive) when ")#mi("\\alpha")#text(" is irrational. On the other hand, any Bernoulli shift is easily seen to be topologically mixing (and hence topologically weak mixing). ")#mi("\\diamond")

#text("We have the following dichotomy, first proven ")#link("http://www.ams.org/mathscinet-getitem?mr=237748")[#text("by Keynes and Robertson ")]#text("(using ideas from the above-mentioned paper of ")#link("http://www.ams.org/mathscinet-getitem?mr=157368")[#text("Furstenberg")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(". (Dichotomy between structure and randomness) Let ")#mi("(X, {\\mathcal F}, T)")#text(" be a minimal topological dynamical system. Then exactly one of the following statements is true:")

#enum(start: 1, 
[#text("(Structure) X has a non-trivial isometric factor.")],
[#text("(Randomness) X is topologically weakly mixing.")]
)
]

#strong[#text("Remark 3.")]#text(" Combining this with Exercise 6 from the previous lecture, we obtain an equivalent formulation of this theorem: a minimal system is topologically weakly mixing if and only if it has no non-trivial eigenfunctions. ")#mi("\\diamond")

#strong[#text("Proof. ")]#text("We first prove the easy direction: that if X has a non-trivial isometric factor, then it is not topologically weakly mixing. In view of Exercise 11, it suffices to prove this when X itself is isometric. Let ")#mi("x, x^{\\prime}")#text(" be two distinct points of Y, let r denote the distance between x and x’ with respect to the metric that makes X isometric, and let B and B’ be the open balls of radius r/10 centred at x and x’ respectively. As X is isometric, we see for any integer n that ")#mi("T^n B")#text(" cannot intersect both B and B’, or equivalently that ")#mi("(T \\times T)^n (B \\times B)")#text(" cannot intersect ")#mi("B \\times B^{\\prime}")#text(". Thus X is not topologically transitive as desired.")

#text("Now we prove the difficult direction: if X is not topologically weakly mixing, then it has a non-trivial isometric factor. For this we use an ")#link("http://www.ams.org/mathscinet-getitem?mr=1764920")[#text("argument of Blanchard, Host, and Maass")]#text(", based on earlier work ")#link("http://www.ams.org/mathscinet-getitem?mr=467704")[#text("of McMahon")]#text(". By Definition 3, there exist open non-empty sets U, V in ")#mi("X \\times X")#text(" such that ")#mi("(T \\times T)^n U \\cap V = \\emptyset")#text(" for all n. If we thus set ")#mi("K := \\overline{\\bigcup_n (T \\times T)^n U}")#text(", we see that K is a compact proper ")#mi("T \\times T")#text("-invariant subset of ")#mi("X \\times X")#text(" with non-empty interior. On the other hand, the projection of K to either factor of ")#mi("X \\times X")#text(" is a non-empty compact invariant subset of X and thus must be all of X.")

#text("We need to somehow use K to build an isometric factor of X. For this, we shall move from the topological dynamics setting to that of the ergodic theory setting. By Corollary 1 in the appendix, X admits an invariant ")#link("http://en.wikipedia.org/wiki/Borel_measure")[#text("Borel")]#text(" measure ")#mi("\\mu")#text(". The ")#link("http://en.wikipedia.org/wiki/Support_%28measure_theory%29")[#text("support")]#text(" of ")#mi("\\mu")#text(" is a non-empty closed invariant subset of X, and is thus equal to all of X by minimality.")

#text("The space ")#mi("L^1(X,\\mu)")#text(" is a metric space, with an isometric shift map ")#mi("Tf := f \\circ T^{-1}")#text(". We define the map ")#mi("\\pi: X \\to L^1(X,\\mu)")#text(" by the formula")

#mi("\\pi(x): y \\mapsto 1_K(x,y)")#text(" (1)")

#text("for all ")#mi("x \\in X")#text(", where ")#mi("1_K")#text(" is the indicator function of K. Because K has non-empty interior and non-empty exterior, and because ")#mi("\\mu")#text(" has full support, it is not hard to show that ")#mi("\\pi")#text(" is non-constant. By the T-invariance of W, it also preserves the shift T. So if we can show that ")#mi("\\pi")#text(" is continuous, we see that ")#mi("\\pi(X)")#text(" will be a non-trivial isometric factor of X and we will be done.")

#text("Let us first consider the scalar function ")#mi("f(x) := \\int_X 1_K(x,y)\\ d\\mu(y)")#text(". From the ")#link("http://en.wikipedia.org/wiki/Dominated_convergence_theorem")[#text("dominated convergence theorem")]#text(" and the fact that K is closed, we see that f is ")#link("http://en.wikipedia.org/wiki/Semi-continuity")[#text("upper semi-continuous")]#text(", and continuous at at least one point, thanks to Lemma 3 from Lecture 4. On the other hand, since K is ")#mi("T \\times T")#text("-invariant and ")#mi("\\mu")#text(" is T-invariant, we see that f is T-invariant. Applying Exercise 15 from Lemma 4 we see that f is constant. On the other hand, as K is closed we have ")#mi("\\limsup_{x \\to x_0} 1_K(x,y) \\leq 1_K(x_0,y)")#text(" for any ")#mi("x_0 \\in X")#text(", and so by dominated convergence again we see that ")#mi("1_K(x,\\cdot)")#text(" converges in ")#mi("L^1")#text(" to zero outside of the support of ")#mi("1_K(x_0,\\cdot)")#text(". Combining this with the constancy of f we conclude that ")#mi("1_K(x,\\cdot)")#text(" converges to ")#mi("1_K(x_0,\\cdot)")#text(" in ")#mi("L^1")#text(" on all of X, and thus ")#mi("\\pi")#text(" is continuous as required. ")#mi("\\Box")

#strong[#text("Remark 4.")]#text(" Note how the measure-theoretic structure was used to obtain metric structure, by passing from the measure space ")#mi("(X, \\mu)")#text(" to the metric space ")#mi("L^1(X, \\mu)")#text(". This again shows that one can sometimes upgrade weak notions of structure (such as topological or measure-theoretic structure) to strong notions (such as geometric or algebraic structure). ")#mi("\\diamond")

#strong[#text("Exercise 13")]#text(". Use Theorem 3 to prove Theorem 1. (Hint: use Exercise 10.) ")#mi("\\diamond")

#strong[#text("Remark 5.")]#text(" It would be very convenient if one had a relative version of Theorem 3, namely that if X is an extension of Y, then X is either relatively topologically weakly mixing with respect to Y (which means that the relative product ")#mi("X \\times_Y X := \\{ (x,x^{\\prime}) \\in X \\times X: \\pi(x)=\\pi(x^{\\prime})\\}")#text(" is topologically transitive), or else X has a factor Z which is a non-trivial isometric extension of Y; among other things, this would have given a new proof of Theorem 2, and in fact establish a somewhat stronger structural theorem. Unfortunately, this relative version fails; a counterexample (based on the Morse sequence) can be found in Exercise 1.19.3 of ")#link("http://www.ams.org/mathscinet-getitem?mr=1958753")[#text("Glasner’s book")]#text(". Nevertheless, the analogue of this claim does hold true in the measure-theoretic setting, as we shall see in a few lectures. ")#mi("\\diamond")

#text("— Appendix: sequential compactness of Borel probability measures —")

#text("We now recall some standard facts from measure theory about ")#link("http://en.wikipedia.org/wiki/Borel_measure")[#text("Borel")]#text(" probability measures on a compact metrisable space X. Recall that a sequence of such measures ")#mi("\\mu_n")#text(" converges in the ")#link("http://en.wikipedia.org/wiki/Vague_topology")[#text("vague topology")]#text(" to another ")#mi("\\mu")#text(" if we have ")#mi("\\int_X f\\ d\\mu_n \\to \\int_X f\\ d\\mu")#text(" for all ")#mi("f \\in C(X)")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" (Vague sequential compactness) The space ")#mi("\\text{Pr}(X)")#text(" of Borel probability measures on X is sequentially compact in the vague topology.")
]

#strong[#text("Proof. ")]#text("From the ")#link("http://en.wikipedia.org/wiki/Stone-Weierstrass_theorem")[#text("Stone-Weierstrass theorem")]#text(" we know that C(X) is ")#link("http://en.wikipedia.org/wiki/Separable")[#text("separable")]#text(". The claim then follows from ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem")[#text("Riesz representation theorem")]#text(" and the usual ")#link("http://en.wikipedia.org/wiki/Arzela-Ascoli_theorem")[#text("Arzelà-Ascoli")]#text(" diagonalisation argument. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1. ")]#text("(Krylov-Bogolubov theorem) Let ")#mi("(X, {\\mathcal F}, T)")#text(" be a topological dynamical system. Then there exists a T-invariant probability measure ")#mi("\\mu")#text(" on X.")
]

#text("Proof. Pick any point ")#mi("x_0 \\in X")#text(" and consider the finite probability measures")

#mi("\\mu_N := \\frac{1}{N} \\sum_{n=1}^N \\delta_{T^n x_0}")#text(" (1)")

#text("where ")#mi("\\delta_x")#text(" is the ")#link("http://en.wikipedia.org/wiki/Dirac_delta_function")[#text("Dirac mass")]#text(" at x. By Lemma 1, some subsequence ")#mi("\\mu_{N_j}")#text(" converges in the vague topology to another Borel probability measure ")#mi("\\mu")#text(". Since we have")

#mi("\\int T f\\ d\\mu_N = \\int f\\ d\\mu_N + O_f( 1/N )")#text(" (2)")

#text("for all bounded continuous f, we conclude on taking vague limits and using the Riesz representation theorem that ")#mi("\\mu")#text(" is T-invariant as required. ")#mi("\\Box")

#strong[#text("Remark 6.")]#text(" Note that Corollary 1, like many other results obtained via compactness methods, guarantees existence of an invariant measure but not uniqueness (this latter property is known as ")#emph[#text("unique ergodicity")]#text("). Even for minimal systems, it is possible for uniqueness to fail, although actually constructing an example is tricky (see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=133429")[#text("this paper of Furstenberg")]#text("). However, as already observed in the proof of Theorem 3, any invariant measure on a minimal topological dynamical system must be ")#emph[#text("full ")]#text("(i.e. its support must be the whole space). ")#mi("\\diamond")

#strong[#text(" ")]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (26)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cffb9d73f5cdeb54f901e1e613f6142baae7161d757e643bb5fe534b21ae4cd6-4f000b6371d1a2eb7ae2a291748b24acfcf30d04a8640cbd3fad063e36b277ea.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Made Eka")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-25092")[#strong[#text("Made Eka")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2008")])]

#text("I use dynamical system to solve my problem in neurology. But I dont understant this lecture. Unlucky me n glad to know you.")

#text("Sucsess,")#linebreak()#text(" Made Eka")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-643250")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2022")])]

#text("What was the problem?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 9: Ergodicity « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-25523")[#strong[#text("254A, Lecture 9: Ergodicity « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("[…] if and only if the only T-invariant Borel probability measure on T is . (Hint: use Lemma 1 from Lecture 7.) Because of this fact, one can sensibly define what it means for a topological dynamical system […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 10: The Furstenberg correspondence principle « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-25936")[#strong[#text("254A, Lecture 10: The Furstenberg correspondence principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("[…] going to infinity such that . On the other hand, by vague sequential compactness (Lemma 1 of Lecture 7) we know that some subsequence of converges in the vague topology to a probability measure , which […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 11: Compact systems « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-26058")[#strong[#text("254A, Lecture 11: Compact systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2008")])]

#text("[…] its maximum and minimum. By the vague sequential compactness of probability measures (Lemma 1 from Lecture 7), one can find a probability measure which minimises the oscillation of . If this oscillation is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 12: Weakly mixing systems « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-26558")[#strong[#text("254A, Lecture 12: Weakly mixing systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2008")])]

#text("[…] Exercise 11. Let be any minimal topological system with Borel -algebra , and let be a shift invariant Borel probability measure. Show that if is weakly mixing (resp. strongly mixing), then is topologically weakly mixing (resp. topologically mixing), as defined in Definition 3 and Exercise 12 of Lecture 7. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 15: The Furstenberg-Zimmer structure theorem and the Furstenberg recurrence theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-26985")[#strong[#text("254A, Lecture 15: The Furstenberg-Zimmer structure theorem and the Furstenberg recurrence theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2008")])]

#text("[…] Furstenberg’s structure theorem for distal systems in topological dynamics (Theorem 2 from Lecture 7). Indeed, in analogy to that theorem, the factors are known as distal measure-preserving systems. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-33488")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2008")])]

#text("Dear Prof. Tao,")

#text("Thank you so much for your so nice lecture!")

#text("I am a little confused on Lemma 1. If our ")#mi("\\mu_n")#text(" is the transition probability of standard Brownian motion at time n, it seems these measures do not converge in vague topology. It seems this is a contradiction for Lemma 1.")

#text("Another question is about the Krylov-Bogoliubov existence theorem of invariant measures. We still consider the transition probability of standard Brownian motion, ")#mi("\\frac{1}{n} \\sum_{k=1}^n  p_k(x,dy)dt")#text(" does not converge to any measure.")

#text("I am not familiar with the ergodic theorem, maybe my questions are silly.")

#text("Thanks a lot!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-33489")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2008")])]

#text("Dear PDEbeginner,")

#text("I am not sure exactly how you are defining ")#mi("\\mu_n")#text(", but I would imagine that the underlying space X that these measures are supported on is non-compact.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-33490")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2008")])]

#text("Dear Prof. Tao,")

#text("Yes, the underlying space X is non-compact. If the X is compact, I think I can understand it. If X is non-compact, I still have the problems (for instance, the Brownian motion ")#mi("(B_t)_{t \\geq 0}")#text(" on ")#mi("{\\bf R}^1")#text(".")

#text("I guess the X in this note is compact, since you applied Stone-Weirerstrass theorem.")

#text("Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-41702")[#strong[#text("Ergodic Ramsey Theory (by Yuri Lima) « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2009")]

#text("[…] of general measure-preserving systems, known as Furstenberg’s Structural Theorem (see this lecture of Terence Tao for a discussion of this result in the case of distal systems). This gave birth to a new area, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-44966")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2010")])]

#text("Dear Professor Tao:")#linebreak()#text(" The last exercise of this lecture is the same one with exercise 12 of lecture 9. Also, the conception of uniquely ergodic is introduced there.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-44971")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2010")])]

#text("Fair enough… I’ve removed the exercise.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Solutions to Ergodic Theory：Lecture twelve « Xiaochuan Liu's Weblog")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-45564")[#strong[#text("Solutions to Ergodic Theory：Lecture twelve « Xiaochuan Liu's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2010")])]

#text("[…] Exercise 11. Let be any minimal topological system with Borel -algebra , and let be a shift invariant Borel probability measure. Show that if is weakly mixing (resp. strongly mixing), then is topologically weakly mixing (resp. topologically mixing), as defined in Definition 3 and Exercise 12 of Lecture 7. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Solutions to Ergodic Theory：Lecture Seven « Xiaochuan Liu's Weblog")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-45598")[#strong[#text("Solutions to Ergodic Theory：Lecture Seven « Xiaochuan Liu's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2010")])]

#text("[…] This is the fifteen exercises in lecture nine. Here is the the page of this course，and here is the page of this lecture. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Tu")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-53512")[#strong[#text("Robert Tu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2011")])]

#text("Dear Professor Tao:")#linebreak()#text(" In Example 1,I think the second point should be (1/2n,0).And after applying $T^n$,we can get the desired point,and there is an n missed before $\\alpha$,I think.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-91211")[#strong[#text("Conférence internationale Géométrie Ergodique (Orsay 2011) IV « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2011")]

#text("[…] paper): Proposition 9 is the largest vector subspace such that the stabilizer of in is distal (i.e., acts on in a distal […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/094ba7107f01d84b33f2fd6f7e2a7b2ee29e9e6e0b2c7b25397920ac06d51e11-0138b87675a19787605c4b9dfc606d120cfc1caf2713663e1bdb7c6b85b9f981.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sann4673")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-527581")[#strong[#text("sann4673")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2019")])]

#text("In exercise 6 (3), I think the last F should be d? If it was d, then the statement follows easily from usc of F. And I think we can construct a counterexample based on example 2 if it was F.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-642086")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2022")])]

#text("In exercise 12, what counterexamples did you have in mind for dynamical systems that are topologically weak mixing but not topologically mixing?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-642090")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2022")])]

#text("Unfortunately I don’t know of any really simple example of such a system. Roughly speaking the idea is to concoct a shift ")#mi("T")#text(" with the property that ")#mi("T^{n_k}")#text(" converges pointwise to the identity for some really sparse sequence ")#mi("n_k")#text(", without creating any continuous eigenfunctions of ")#mi("T")#text(" in the process, but the constructions of such systems that I am aware of (e.g., ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=370662")[#text("by Anosov and Katok")]#text(") are quite complicated, and I would be interested to know of an example that is simple to construct and analyze.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-642153")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2022")])]

#text("Would a product of a mixing system and an irrational circle rotated not work?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-642243")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2022")])]

#text("Such a product will neither be mixing nor weakly mixing, as it contains continuous eigenfunctions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-643251")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2022")])]

#text("What about flows on torus?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-642111")[#strong[#text("gn.common topology - Equivalent definitions of topological feeble mixing Answer - Lord Web")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2022")]

#text("[…] $f$ is topologically feeble mixing if $ftimes f$ is topologically transitive on $Xtimes X$ (e.g right here) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-642324")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2022")])]

#text("Reblogged this on ")#link("https://jasthephysicist.blog/2022/04/02/254a-lecture-7-structural-theory-of-topological-dynamical-systems/")[#text("Metaphysics")]#text(" and commented:")#linebreak()#text(" I only heard of structural theory in a linear algebra course. It reminds me of this: ")#link("https://www.degruyter.com/document/doi/10.1515/crll.1968.232.180/html")[#text("https://www.degruyter.com/document/doi/10.1515/crll.1968.232.180/html")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/#comment-643268")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2022")])]

#text("For the general concept of mathematical structure, see the Wikipedia article on mathematical structure.")
]
]
