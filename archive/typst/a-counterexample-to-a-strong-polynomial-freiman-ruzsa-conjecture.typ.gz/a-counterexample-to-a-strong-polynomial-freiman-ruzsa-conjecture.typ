// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/11/09/a-counterexample-to-a-strong-polynomial-freiman-ruzsa-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T15:16:54.955366+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A counterexample to a strong polynomial Freiman-Ruzsa conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A counterexample to a strong polynomial Freiman-Ruzsa conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 November 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/11/09/a-counterexample-to-a-strong-polynomial-freiman-ruzsa-conjecture/")[#text("https://terrytao.wordpress.com/2008/11/09/a-counterexample-to-a-strong-polynomial-freiman-ruzsa-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of my favourite open problems in additive combinatorics is the polynomial Freiman-Ruzsa conjecture, which Ben Green ")#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/")[#text("guest blogged about")]#text(" here some time ago. It has many equivalent formulations (which is always a healthy sign when considering a conjecture), but here is one involving “approximate homomorphisms”:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Polynomial Freiman-Ruzsa conjecture. ")]#text(" Let ")#mi("f: F_2^n \\to F_2^m")#text(" be a function which is an approximate homomorphism in the sense that ")#mi("f(x+y)-f(x)-f(y) \\in S")#text(" for all ")#mi("x,y \\in F_2^n")#text(" and some set ")#mi("S \\subset F_2^m")#text(". Then there exists a genuine homomorphism ")#mi("g: F_2^n \\to F_2^m")#text(" such that ")#mi("f-g")#text(" takes at most ")#tao-math("O( \\left|S\\right|^{O(1)} )", block: false)#text(" values.")
]

#strong[#text("Remark 1.")]#text(" The key point here is that the bound on the range of ")#mi("f-g")#text(" is at most polynomial in |S|. An exponential bound of ")#tao-math("2^{\\left|S\\right|}", block: false)#text(" can be trivially established by splitting ")#mi("F_2^m")#text(" into the subspace spanned by S (which has size at most ")#tao-math("2^{\\left|S\\right|}", block: false)#text(") and some complementary subspace, and then letting g be the projection of f to that complementary subspace. ")#mi("\\diamond")

#text("Recently, Ben Green and I have shown that this conjecture is equivalent to a certain polynomially quantitative strengthening of the inverse conjecture for the Gowers norm ")#mi("U^3(F_2^n)")#text("; I hope to talk about this in a future post. For this (somewhat technical) post, I want to comment on a possible further strengthening of this conjecture, namely")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Strong Polynomial Freiman-Ruzsa conjecture. ")]#text(" Let ")#mi("f: F_2^n \\to F_2^m")#text(" be a function which is an approximate homomorphism in the sense that ")#mi("f(x+y)-f(x)-f(y) \\in S")#text(" for all ")#mi("x,y \\in F_2^n")#text(" and some set ")#mi("S \\subset F_2^m")#text(". Then there exists a genuine homomorphism ")#mi("g: F_2^n \\to F_2^m")#text(" such that ")#mi("f-g")#text(" takes values in the sumset ")#mi("CS := S + \\ldots + S")#text(" for some fixed ")#mi("C=O(1)")#text(".")
]

#text("This conjecture is known to be true for certain types of set S (e.g. for Hamming balls, this is a result ")#link("http://www.ams.org/mathscinet-getitem?mr=1770537")[#text("of Farah")]#text("). Unfortunately, it is false in general; the purpose of this post is to describe one counterexample (related to the failure of the inverse conjecture for the Gowers norm for ")#mi("U^4(F_2^n)")#text(" for classical polynomials; in particular, the arguments here have several features in common with those in the papers of ")#link("http://www.cs.huji.ac.il/~salex/papers/Gowers-false.pdf")[#text("Lovett-Meshulam-Samorodnitsky")]#text(" and ")#link("http://arxiv.org/abs/0711.3191")[#text("Green-Tao")]#text("). [A somewhat different counterexample also appears in the paper of Farah.] The verification of the counterexample is surprisingly involved, ultimately relying on the multidimensional Szemerédi theorem of ")#link("http://www.ams.org/mathscinet-getitem?mr=531279")[#text("Furstenberg and Katznelson")]#text(".")

#text("(The results here are derived from forthcoming joint work with Ben Green.)")

#heading(level: 1)[#metadata(none) <tao-9d8b1ad46c8a03e7dc4d>#text("— Description of counterexample —")]

#text("We let n be a large number, and replace ")#mi("F_2^m")#text(" by the ")#mi("\\frac{n(n+1)}{2}")#text("-dimensional vector space V of quadratic forms ")#mi("Q: F_2^n \\to F_2")#text(" (with a basis given by the monomials ")#mi("x_i x_j")#text(" with ")#mi("1 \\leq i \\leq j \\leq n")#text("). We let ")#mi("f: F_2^n \\to V")#text(" be defined by the formula")

#align(center)[#mi("f(h_1,\\ldots,h_n)(x_1,\\ldots,x_n) := \\sum_{1 \\leq i < j \\leq n} h_i x_i h_j x_j")#text(".")]

#text("A brief computation shows that for any ")#mi("h, k \\in F_2^n")#text(", the quadratic form ")#mi("f(h+k)-f(h)-f(k)")#text(" is of rank at most three, by which we mean that it is a function of at most three linear forms. More specifically, we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("f(h+k)-f(h)-f(k) = a_{h,k} b_{h,k} + b_{h,k} c_{h,k} + c_{h,k} a_{h,k}")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("a_{h,k}(x)  & = \\sum_{i=1}^n h_i(1-k_i) x_i", block: true)



#tao-math("b_{h,k}(x)  & = \\sum_{i=1}^n (1-h_i) k_i x_i", block: true)



#tao-math("c_{h,k}(x)  & = \\sum_{i=1}^n h_i k_i x_i", block: true)
]

#text("Thus, if we let S be the space of quadratic forms of rank at most 3, the hypotheses of the polynomial Freiman-Ruzsa conjecture hold.")

#heading(level: 1)[#text("— Verification of counterexample —")]

#text("To establish the counterexample, we assume for contradiction that there exists a linear function ")#mi("g: F_2^n \\to V")#text(" such that ")#mi("f(h)-g(h)")#text(" has bounded rank for all h, and deduce a contradiction (for n sufficiently large).")

#text("By hypothesis, we have linear forms ")#mi("L_{h,1},\\ldots,L_{h,d}")#text(" for all ")#mi("h \\in F_2^n")#text(" and some ")#mi("d = O(1)")#text(" and coefficients ")#mi("c_{h,i,j} \\in F_2")#text(" for all ")#mi("1 \\leq i \\leq j \\leq d")#text(" such that")

#align(center)[#tao-fit-display[#mitex("f(h)-g(h) = \\sum_{1 \\leq i \\leq j \\leq n} c_{h,i,j} L_{h,i} L_{h,j}")]]

#text("and in particular (by (1) and linearity of g)")

#align(center)[#tao-fit-display[#mitex("a_{h,k} b_{h,k} + b_{h,k} c_{h,k} + c_{h,k} a_{h,k}")]]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("= \\sum_{1 \\leq i \\leq j \\leq n} c_{h+k,i,j} L_{h+k,i} L_{h+k,j} - c_{h,i,j} L_{h,i} L_{h,j} - c_{k,i,j} L_{k,i} L_{k,j}.")]]

#text("The key point is that the linear forms ")#mi("a_{h,k}, b_{h,k}, c_{h,k}")#text(" are usually “independent” of the linear forms ")#mi("L_{h,i}, L_{k,i}, L_{h+k,i}")#text(". The key lemma in this regard is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1. ")]#text("If h, k are selected uniformly and independently at random, then with probability 1-o(1), ")#mi("a_{h,k}")#text(" is not a linear combination of the ")#mi("L_{h,i}, L_{k,i}, L_{h+k,i}")#text(". Similarly for ")#mi("b_{h,k}, c_{h,k}")#text(".")
]

#strong[#text("Proof.")]#text(" By cyclically permuting h,k,h+k it suffices to show this for ")#mi("c_{h,k}")#text(". Since there are at most O(1) possible linear combinations amongst the ")#mi("L_{h,i}, L_{k,i}, L_{h+k,i}")#text(", it suffices to show that for any given assignments ")#mi("h \\mapsto L^{\\prime}_h, k \\mapsto L^{\\prime\\prime}_k, h+k \\mapsto L^{\\prime\\prime\\prime}_{h+k}")#text(" of linear forms, that the probability of the event")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("c_{h,k} = L^{\\prime}_h + L^{\\prime\\prime}_k + L^{\\prime\\prime\\prime}_{h+k}")]]

#text("is o(1). Suppose for contradiction that the event (3) holds for a set E of pairs (h,k) in ")#mi("F_2^n \\times F_2^n")#text(" of positive density. Applying the ")#link("http://www.ams.org/mathscinet-getitem?mr=531279")[#text("Furstenberg-Katznelson")]#text(" multidimensional Szemerédi theorem) we can find (for n large enough) a square ")#mi("(h,k), (h+r,k), (h,k+r), (h+r,k+r)")#text(" in E with r non-zero. Applying (3) for all four pairs and summing, we obtain")

#align(center)[#tao-fit-display[#mitex("c_{h,k} +c_{h+r,k} + c_{h,k+r} + c_{h+r,k+r} = 0")]]

#text("(recall we are in characteristic 2). But the left-hand side is equal to the linear form ")#mi("\\sum_i r_i x_i")#text(", which is non-zero, a contradiction. ")#mi("\\Box")

#text("Now we can obtain the desired contradiction. For a generic choice of h,k, we now know that none of the ")#mi("a_{h,k}, b_{h,k}, c_{h,k}")#text(" are linear combinations of the ")#mi("L_{h,i}, L_{k,i}, L_{h+k,i}")#text(". Thus, on a given level set of the ")#mi("L_{h,i}, L_{k,i}, L_{h+k,i}")#text(" (which form a subspace of ")#mi("F_2^n")#text("), the linear functions ")#mi("a_{h,k}, b_{h,k}, c_{h,k}")#text(" are non-constant, and so the range of the triplet ")#mi("(a_{h,k}, b_{h,k}, c_{h,k})")#text(" must be an affine subspace of ")#mi("F_2^3")#text(" which is not contained in any plane in ")#mi("F_2^3")#text(" that is parallel to the two of the coordinate axes (i.e. of the form ")#mi("a=const")#text(", ")#mi("b=const")#text(", or ")#mi("c=const")#text(". This forces the subspace to be parallel to (1,1,1). But this implies that ")#mi("(a,b,c) \\mapsto ab+bc+ca")#text(" is non-constant on this space, contradicting (2).")

#strong[#text("Remark 2.")]#text(" The function f appearing in the above example is closely related to the symmetric polynomial")

#align(center)[#mi("\\displaystyle S_4(x) := \\sum_{1 \\leq i < j < k < l \\leq n} x_i x_j x_k x_l")#text(".")]

#text("Indeed, one can show that the derivative ")#mi("S_4(x+h)-S_4(x)")#text(" of ")#mi("S_4")#text(" is equal to ")#mi("f(h)")#text(", plus some additional terms which involve only a finite number of linear forms, and the quadratic polynomial ")#mi("S_2(x) := \\sum_{1 \\leq i < j \\leq n} x_i x_j")#text(". If it was the case that ")#mi("f")#text(" could be approximated by a linear map ")#mi("g")#text(" modulo low rank errors, then it one could use this to eventually show that ")#mi("S_4")#text(" correlated with a cubic polynomial; but it is known (from the papers of ")#link("http://www.cs.huji.ac.il/~salex/papers/Gowers-false.pdf")[#text("Lovett-Meshulam-Samorodnitsky")]#text(" and ")#link("http://arxiv.org/abs/0711.3191")[#text("Green-Tao")]#text(") that this is not the case. Thus there is an alternate way to verify that the above example is indeed a counterexample to the strong polynomial Freiman-Ruzsa conjecture. ")#mi("\\diamond")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2008/11/09/a-counterexample-to-a-strong-polynomial-freiman-ruzsa-conjecture/#comment-33493")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2008")])]

#text("Terry,")

#text("I know that your blog has a wide readership and so it would be irresponsible of me to endorse gambling in any way. However I should perhaps mention the informal bet I had with Jean Bourgain, whereby he wins 100 dollars from me if a counterexample to PFR is found and I win the same if a proof of the conjecture is found within 5 years.")

#text("This counterexample to the `strong’ form of the conjecture (which I knew about before making the bet….) does suggest that a proof of the statement might have to be a little weird.")

#text("I’d like to take this rare opportunity to use the word `cohomology’ on your website (or indeed at all). Emmanuel Breuillard pointed out to me that there is this thing called bounded cohomology, which roughly speaking measures the obstruction to maps ")#mi("f : G \\rightarrow \\Bbb{R}")#text(" with ")#tao-math("\\left|f(xy) - f(x)f(y)\\right| \\leq C", block: false)#text(" being a bounded distance from genuine homomorphisms. Apparently quite a lot of the theory is developed in a paper of Gromov which I have yet to obtain. See also an article by Kotschick in Notices of the AMS, vol 51. no .2 called “What is a quasimorphism”?")

#text("Perhaps `Ruzsa cohomology’ can resolve these issues but suddenly 5 years looks like a very short period of time :-)")

#text("Ben")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2008/11/09/a-counterexample-to-a-strong-polynomial-freiman-ruzsa-conjecture/#comment-36516")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("Hi –")

#text("I think there are a couple of mistakes. The definitions of a_{h,k}, b_{h,k} and c_{h,k} after equation (1) can’t be right. What are the right polynomials? In the section right thereafter, all occurences of L_{h,d}, L_{k,d}, L_{h+k,d} should be")#linebreak()#text(" L_{h,j},L_{k,j}, L_{h+k,j} instead.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/11/09/a-counterexample-to-a-strong-polynomial-freiman-ruzsa-conjecture/#comment-36517")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("Thanks for the correction! The ")#mi("b_{h,k}")#text(" was missing a ")#mi("k_i")#text(" in their definition; I’ve fixed it now.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2008/11/09/a-counterexample-to-a-strong-polynomial-freiman-ruzsa-conjecture/#comment-36534")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("Also – what does “any coordinate plane” mean? Does that mean the xy, yz, xz planes? If so, how does the fact that the range of (a_{h,k},b_{h,k},c_{h,k}) is not contained in one of those imply that it is at least two-dimensional?")

#text("Harald")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/11/09/a-counterexample-to-a-strong-polynomial-freiman-ruzsa-conjecture/#comment-36544")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2009")])]

#text("Dear Harald,")

#text("By coordinate plane I meant the planes in ")#mi("F_2^3")#text(" in which x, y, or z is held constant. The only one-dimensional spaces which are not in coordinate planes are those lines in the direction (1,1,1), but ab+bc+ca is not constant on those lines. I’ll reword the argument there to make it a bit clearer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An equivalence between inverse sumset theorems and inverse conjectures for the U^3 norm « What’s new")]], [#link("https://terrytao.wordpress.com/2008/11/09/a-counterexample-to-a-strong-polynomial-freiman-ruzsa-conjecture/#comment-39633")[#strong[#text("An equivalence between inverse sumset theorems and inverse conjectures for the U^3 norm « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2009")])]

#text("[…] Math. Proc. Camb. Phil. Soc.. The main result of this short paper (which was briefly announced in this earlier post) is a connection between two types of inverse theorems in additive combinatorics, namely the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Metric entropy analogues of sum set theory | What's new")]], [#link("https://terrytao.wordpress.com/2008/11/09/a-counterexample-to-a-strong-polynomial-freiman-ruzsa-conjecture/#comment-277058")[#strong[#text("Metric entropy analogues of sum set theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2014")])]

#text("[…] due to the failure of a certain strong version of Freiman’s theorem, as discussed in this previous post); nevertheless, the proofs of the discrete arguments are elementary enough that they can be […]")
]
