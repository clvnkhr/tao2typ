// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/08/what-should-we-teach-our-undergraduate-students/
// Converted to Typst by tao2typ: "2026-11-09T16:40:56.331841+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "What should we teach our (undergraduate) students?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("What should we teach our (undergraduate) students?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/08/what-should-we-teach-our-undergraduate-students/")[#text("https://terrytao.wordpress.com/2026/11/08/what-should-we-teach-our-undergraduate-students/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-09 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://owd.tcnj.edu/~gevertz/")[#text("Jana Gevertz")]#text(" and ")#link("https://owd.tcnj.edu/~marcuss/")[#text("Steffen Marcus")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("In the last few months AI has hit our discipline with a frightening force. Many of us, understandably, have turned our attention to our students. They are absorbing this change while still working out what kind of mathematicians, and what kind of professionals, they hope to become. On this blog, Álvaro Lozano-Robledo recently asked “what should we tell our students?” (")#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/")[#text("What should we tell our students? | What’s new")]#text("). In this post, we will focus on the natural follow-up question: “what should we teach them?”")

#metadata(none) <tao-755bd9b99e028c80f7a4>

#text("Whatever our students choose for their future careers, be it academia or industry, their work will continue to depend on the depth of their mathematical understanding. However, more and more of that work will likely involve prompting, interpreting, checking, and communicating mathematical ideas that an AI model helped generate. Mathematical understanding as we have come to teach it is built on a time-honored tradition of exercise, proof, and computation: struggle with hard problems until a discovery is made, develop a conjecture and make an effort to prove it, compute by hand to uncover a desired result or a pattern that reveals itself. How will our students build mathematical understanding when AI tools can automate the very processes needed to develop it? What does it mean to train new mathematicians?")

#text("Presuming society continues to cede more decisions and reasoning to AI, it has been rightly argued that it would be dangerous for these decisions to “rest on reasons that no human community understands” (")#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/")[#text("We’re gonna need a lot more mathematicians | What’s new")]#text("). In mathematics, as in many other academic communities, understanding begins with undergraduate training that builds off years of education at the primary and secondary level. Without thriving undergraduate mathematics programs, the mathematics community is at risk of depleting the pool of individuals with the capacity to assess work done with (or by) AI and to set the directions of the field.")

#text("However, undergraduate education is at an impasse. In our liberal arts style college here in New Jersey, we have struggled with the practical implications of AI on our classrooms while circling more broadly around the question of how our curriculum must change for the future. There is a visceral feeling that our courses need to change, but it’s not clear what that change should look like. The discipline’s conversations so far have centered on our research and publications, our early career colleagues, and our graduate students. The 2026 AMS Committee on Education Workshop Report (")#link("https://terrytao.wordpress.com/2026/10/13/2026-ams-committee-on-education-workshop-report/")[#text("2026 AMS Committee on Education Workshop Report | What’s new")]#text(") highlights the beginning of our efforts to reorganize graduate level curricula with AI in mind. We believe a parallel and continuous effort focused on our undergraduate programs is needed.")

#text("This is especially important for our students entering graduate school, as they will be interfacing with mathematics differently than we have in the past. If it is true that “we won’t get to be heroes anymore” (")#link("https://www.nytimes.com/2026/10/13/podcasts/the-daily/mathematicians-problem-ai-jobs.html")[#text("When AI comes for Your Purpose in Life – The New York Times")]#text(") and we will begin working in larger teams along with AI systems to develop new ideas and proofs, then our training needs to be focused on understanding and robustly checking results presented to us in slightly “alien” forms.")

#strong[#text("The central problem: teaching understanding")]

#text("Luckily, this is not really a completely new way of thinking and teaching. After all, undergraduate training has always been about teaching students to check, interpret, and explain results already known to other mathematicians. Whether it be calculations that have been executed time and time again, or proofs of important theorems that are well-established, undergraduate students learn mathematics and shape their understanding using pre-existing knowledge. From that perspective, the basic skills used to interpret, understand, and communicate mathematics learned through an AI system are already a central piece of undergraduate curricula.")

#text("However, we cannot simply continue to ignore this technology as a nuisance to our ability to assign homework exercises and hope for the best. We must teach students to work with these systems. And we must find the right way to do so without offloading their ability to think through problems on their own. Our students need both the skillset and the experience necessary to critically validate AI outputs. Whether we like it or not, they will be expected to work in this way with AI systems in their careers. Our coursework needs to carefully train them to develop mathematical intuition, reasoning, and computational skills in concert with this new technology, rather than apart from it, as is our current instinct.")

#text("Our pre-AI experience shows that there are distinct differences between productively struggling to re-create existing knowledge and using technology to do this work. Consider an undergraduate student learning strategies of integration in a calculus class. From the student’s perspective, there is something distinctly different about identifying the substitution that transforms a seemingly “impossible” integral into an easily solvable one versus reading through a solution where the substitution has been selected. A student who considered the structure of the integrand to identify an appropriate substitution would indeed have created the result for themselves, despite the expected substitution being well known. A student who instead blindly followed a computer’s (or even their instructor’s) approach without investigating will likely not internalize that changing variables is a foundational mathematical technique that maps difficult problems onto solvable problems.")

#text("This is a small example of the difference between teaching the concept versus teaching the computation. This battle has been playing out in our discussions of pedagogy and content since symbolic computation software have become widespread. What has changed is that this conflict has now expanded to the advanced levels of our undergraduate curricula — the newest AI models have come to make our courses a push-button exercise. If our students rely on reading out computer generated proofs and computations exercise by exercise, they immediately lose the critical moments of productive struggle necessary to build mathematical understanding.")

#strong[#text("Where do we go from here?")]

#text("As with any debate, there are those who will passionately argue both extremes. Some will say we simply must eschew AI technology by continuing to teach as we always have, relying on in-class pen and paper assessments. This approach fails to prepare our students for a future in which they will need to work efficiently with AI models and manage their output. Others will argue we should throw away our outdated curricula and embrace the transformative power of AI. The risk in this approach is the outsourcing of student learning and understanding, a risk that is simply too high. The answer must lie somewhere subtly in the middle of these two extremes.")

#text("In her recent post on this blog (")#link("https://terrytao.wordpress.com/2026/10/29/ai-mathematics-education-and-a-public-goods-problem/")[#text("AI, Mathematics, Education, and a public goods problem | What’s New")]#text("), Gireeja Ranade argues that “we must teach harder, better, and stronger”. Ranade identifies the central issue facing our community as we learn how to teach our students to work with AI models: “we need to train students so that they know what they know and don’t know — students who can identify proof by intimidation and by authority, and have the confidence to push back.” Looking around, it seems the natural inclination for many of us is to revert to how we have taught in the past (perhaps “harder, better, and stronger”) and to ignore the power of AI within the confines of the classroom. Most of us are quietly choosing one of the two extremes.")

#text("Indeed, as authors of this post ourselves, we have yet to find the right way to incorporate AI in our mathematical biology or geometry classes this semester, though we have been thinking about it for a while. Adjusting an undergraduate curriculum is difficult and time-consuming work that cannot simply be done on top of the full-time job faculty already do. Reaching a consensus is also going to be very challenging, and even once a curriculum is agreed upon, the work that must follow to redesign course materials is substantial. For these reasons, it is easy to let our undergraduate courses wait three, four, or five more years until we see how everything shakes out. However, our students desperately need us to find this delicate balance more quickly. They need to acquire a breadth of experience interfacing with these systems in their mathematical work now, or they risk getting left behind.")

#text("And therein lies the challenge: how do we design undergraduate mathematics curricula that takes such a balanced approach? There have been a number of recent summits, reports, and statements regarding how AI is changing the mathematical landscape and how we should respond. Similar concerted efforts with a focus on undergraduate education are necessary. The ")#link("https://maa.org/wp-content/uploads/2026/09/091726-MAA-Statement-on-AI-in-Higher-Ed.pdf")[#text("MAA Statement on AI in Higher Education")]#text(" outlines some top-down beliefs on how the undergraduate curriculum may have to change. However, much more activity is needed to help guide department leaders and educators on how to make these suggestions concrete. Together we need to work towards a modernized curriculum that considers the following questions.")

#list(
[#text("How do we design and implement a curriculum that places a greater emphasis on higher-order competencies, including conceptual and computational reasoning as well as problem solving and modeling (per: ")#link("https://maa.org/wp-content/uploads/2026/09/091726-MAA-Statement-on-AI-in-Higher-Ed.pdf")[#text("MAA Statement on AI")]#text(")? Efforts to change curricula and teaching in similar ways have often been met with hesitation.")],
[#text("How do we incorporate the critical evaluation of AI output into our courses so that students can robustly check these results?")],
[#text("Should we be incorporating formalization techniques such as Lean into our upper-level and proof-based courses?")],
[#text("Can we reduce the number of topics within each course to create space to focus on reading and interpreting AI output and comparing the answers it gives to the theory students understand to be true?")],
[#text("Can we reduce the focus on arduous computations while continuing to emphasize the procedural fluency necessary to critically analyze mathematical arguments?")],
[#text("How do engineering, science, social science, business, and health science disciplines see their mathematics, statistics, and data science educational needs changing in the coming years? We certainly must collaborate with related disciplines to thoughtfully consider how moving away from computation to concept and interpretation impacts the training of their students.")],
[#text("How do we create courses that emphasize humanized mathematical and statistical communication?")]
)

#text("This list is in no way exhaustive, but we do hope it can jumpstart the conversation.")

#text("Faculty in all departments need to be thinking hard about how our curriculum should change, before external players force change upon us. Continued leadership from mathematical organizations, including the AMS and MAA, as well as private organizations, is needed. The federal government would also be well-served by offering grants to support the development of innovative mathematics curricula for the AI era. After all, AI technology does not exist without the work of mathematicians. Together, we can work to give our students what they are owed: an education that prepares them to enter a world where they can effectively use AI as a tool, but not as a crutch.")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b2471604c8902ec9746d53afa441873dadc9012b5022d6ff0bc83852a9993e-b8d80f565218ccfbd08a65971f9e4d3de692f80225ef4b30178db5d2e2c01251.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/08/what-should-we-teach-our-undergraduate-students/#comment-699276")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2026")])]

#text("Why not be conservative? It is really not that difficult to use AI. Only the industry tells people that you’ll be left behind if you don’t use AI.")

#text("In reality it takes two days to surrender your mind to the machine. There is no need to teach it at all apart from attracting industry sponsors.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3945b7809286abba658ee75af873a597740719d68beca61d78cbadb5d7042e9f-6896ba09db6278899bf781123736697877abbcb81ebd9c03118def76a04abd9d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2026/11/08/what-should-we-teach-our-undergraduate-students/#comment-699277")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2026")])]

#text("To the bullet point “[s]hould we be incorporating formalization techniques such as Lean into our upper-level and proof-based courses,” it seems to me that the answer is ")#emph[#text("no")]#text(", at least if “incorporation” means teaching students that a solution has been found iff a Lean file has been produced.")

#text("The trade-off with using formal proof systems is that we gain certainty in the truth of the output at the cost of other desiderata; a student can arrive at a solution to the problem “prove that addition is commutative” in the natural number game without ever having a coherent idea of what the strategy of the proof was. In an extreme case, a Lean file proving X can spend arbitrarily many lines of code proving unrelated facts; so, a student learning the proof of the inverse function theorem can come to believe that it involves a lot of group theory. The example’s a bit silly; but, I think anyone who has played the natural number game can sympathize with the experience that a lot of it is blundering in the dark until the green light goes off, without having acquired any mathematical understanding.")

#text("The point, of course, is to indicate that the production of a Lean file should not be treated by students as sufficient for having solved a problem. Some sort of understanding beyond this is necessary.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of akkapi")]], [#link("https://terrytao.wordpress.com/2026/11/08/what-should-we-teach-our-undergraduate-students/#comment-699281")[#strong[#text("akkapi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2026")])]

#text("Are instructors necessary to teach the youth how to interact with AI to get answers? I wonder how well the current generation of mathematicians itself knows how to best use AI for research, versus the variety of better and more optimal paths that the younger generation will discover and could teach the mathematicians of today.")

#text("The point of mathematical instruction by mathematicians should be to teach mathematics, rather than bifurcate tasks both for the instructors and the students. Considering that there is so much worry about students using AI to do their homework, probably spending more instruction time on this is less useful than accepting that this would happen anyways and focusing on assessing how much the students have learned ")#emph[#text("even with")]#text(" the help of AI. In this sense, the focus might shift to ")#emph[#text("how to assess students better")]#text(" “in the age of AI”. Improvements in this regard, without increasing stress both for the students and the instructional team (the teachers, the graders, etc.) will likely go much farther: good strategies would implicitly enforce students to be more critical with regards to what they may read from AI output.")

#text("Teaching formalization ")#emph[#text("tools")]#text(" like Lean seems to also put the cart before the horse. How well do mathematicians in fields outside of the nucleus of formalization (type theory, calculus of inductive constructions, etc.) actually understand the theory of Lean or can explain why it works? Should emphasis be placed in mathematical instruction on learning tools regarding proof that the instructor themself doesn’t fully understand? A key issue in “trusting AI” is the interaction between the natural language and Lean outputs it produces, which are only very recently being properly studied in research mathematics: advancements in this direction are likely good candidates for future special-topics courses. As has been done with other areas of mathematics, it seems there would be more to be gained by offering better courses and putting some emphasis on the foundations of these tools, in addition to the tools themselves.")

#text("Ultimately, what is the point of teaching mathematics? At the risk of oversimplification, a basic analogy is that although there are many tricks in abstract algebra, a good group theory course still requires the student to go through computations by hand to get a feel for how symmetries behave based on structure. This approach of doing things “from first principles” is present in all parts of existing mathematical instruction, where what constitutes the “first principles” moves as one advances along the theory. In mathematics as a whole, however, the development of proof, or a tight logical argument from start to finish, is by definition “the” first principle. If the point of teaching mathematics is for the student to learn mathematics, then it seems that teaching how to instruct AI to do mathematics or to “think in the Lean language” (or similar) would be a distraction, both for instructors as well as students.")
]
