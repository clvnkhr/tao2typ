// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:36:39.833845+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 4: Building metrics on groups, and the Gleason-Yamabe theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 4: Building metrics on groups, and the Gleason-Yamabe theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 October 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/")[#text("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In this set of notes we will be able to finally prove the Gleason-Yamabe theorem from ")#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/")[#text("Notes 0")]#text(", which we restate here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Gleason-Yamabe theorem)")]#text(" ")#metadata(none) <tao-903d8df0b5ef51b3d76c>#text(" Let ")#mi("{G}")#text(" be a locally compact group. Then, for any open neighbourhood ")#mi("{U}")#text(" of the identity, there exists an open subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" and a compact normal subgroup ")#mi("{K}")#text(" of ")#mi("{G^{\\prime}}")#text(" in ")#mi("{U}")#text(" such that ")#mi("{G^{\\prime}/K}")#text(" is isomorphic to a Lie group.")
]

#text("In the next set of notes, we will combine the Gleason-Yamabe theorem with some topological analysis (and in particular, using the ")#link("http://en.wikipedia.org/wiki/Invariance_of_domain")[#text("invariance of domain")]#text(" theorem) to establish some further control on locally compact groups, and in particular obtaining a solution to ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_fifth_problem")[#text("Hilbert’s fifth problem")]#text(".")

#text("To prove the Gleason-Yamabe theorem, we will use three major tools developed in previous notes. The first (from ")#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/")[#text("Notes 2")]#text(") is a criterion for Lie structure in terms of a special type of metric, which we will call a Gleason metric:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2")]#text(" Let ")#mi("{G}")#text(" be a topological group. A ")#emph[#text("Gleason metric")]#text(" on ")#mi("{G}")#text(" is a left-invariant metric ")#mi("{d: G \\times G \\rightarrow {\\bf R}^+}")#text(" which generates the topology on ")#mi("{G}")#text(" and obeys the following properties for some constant ")#mi("{C>0}")#text(", writing ")#tao-math("{\\left\\|g\\right\\|}", block: false)#text(" for ")#mi("{d(g,\\text{id})}")#text(":")

#list(
[#text("(Escape property) If ")#mi("{g \\in G}")#text(" and ")#mi("{n \\geq 1}")#text(" is such that ")#tao-math("{n \\left\\|g\\right\\| \\leq \\frac{1}{C}}", block: false)#text(", then ")#tao-math("{\\left\\|g^n\\right\\| \\geq \\frac{1}{C} n \\left\\|g\\right\\|}", block: false)#text(".")],
[#text("(Commutator estimate) If ")#mi("{g, h \\in G}")#text(" are such that ")#tao-math("{\\left\\|g\\right\\|, \\left\\|h\\right\\| \\leq \\frac{1}{C}}", block: false)#text(", then")

#metadata(none) <tao-0a83d217c9ff25c77929>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\|[g,h]\\right\\| \\leq C \\left\\|g\\right\\| \\left\\|h\\right\\|,", block: true)]]

#text("where ")#mi("{[g,h] := g^{-1}h^{-1}gh}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Commutator")[#text("commutator")]#text(" of ")#mi("{g}")#text(" and ")#mi("{h}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Building Lie structure from Gleason metrics)")]#text(" ")#metadata(none) <tao-d6434d130e6177cf02f7>#text(" Let ")#mi("{G}")#text(" be a locally compact group that has a Gleason metric. Then ")#mi("{G}")#text(" is isomorphic to a Lie group.")
]

#text("The second tool is the existence of a left-invariant Haar measure on any locally compact group; see Theorem 3 from ")#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/")[#text("Notes 3")]#text(". Finally, we will also need the compact case of the Gleason-Yamabe theorem (Theorem 8 from Notes 3), which was proven via the Peter-Weyl theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Gleason-Yamabe theorem for compact groups)")]#text(" ")#metadata(none) <tao-5e180a6b364155347a53>#text(" Let ")#mi("{G}")#text(" be a compact Hausdorff group, and let ")#mi("{U}")#text(" be a neighbourhood of the identity. Then there exists a compact normal subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" contained in ")#mi("{U}")#text(" such that ")#mi("{G/H}")#text(" is isomorphic to a linear group (i.e. a closed subgroup of a general linear group ")#mi("{GL_n({\\bf C})}")#text(").")
]

#text("To finish the proof of the Gleason-Yamabe theorem, we have to somehow use the available structures on locally compact groups (such as Haar measure) to build good metrics on those groups (or on suitable subgroups or quotient groups). The basic construction is as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 5 (Building metrics out of test functions)")]#text(" Let ")#mi("{G}")#text(" be a topological group, and let ")#mi("{\\psi: G \\rightarrow {\\bf R}^+}")#text(" be a bounded non-negative function. Then we define the pseudometric ")#mi("{d_\\psi: G \\times G \\rightarrow {\\bf R}^+}")#text(" by the formula")

#tao-aligned(keep: true)[


#tao-math("d_\\psi(g,h)  & := \\sup_{x \\in G} \\left|\\tau(g) \\psi(x) - \\tau(h) \\psi(x)\\right|", block: true)



#tao-math(" & = \\sup_{x \\in G} \\left|\\psi(g^{-1} x ) - \\psi(h^{-1} x)\\right|", block: true)
]

#text("and the semi-norm ")#mi("{\\| \\|_\\psi: G \\rightarrow {\\bf R}^+}")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g\\right\\|_\\psi := d_\\psi(g, \\text{id}).", block: true)]]
]

#text("Note that one can also write")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g\\right\\|_\\psi = \\sup_{x \\in G} \\left|\\partial_g \\psi(x)\\right|", block: true)]]

#text("where ")#mi("{\\partial_g \\psi(x) := \\psi(x) - \\psi(g^{-1} x)}")#text(" is the “derivative” of ")#mi("{\\psi}")#text(" in the direction ")#mi("{g}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Let the notation and assumptions be as in the above definition. For any ")#mi("{g,h,k \\in G}")#text(", establish the metric-like properties")

#enum(start: 1, 
[#text("(Identity) ")#mi("{d_\\psi(g,h) \\geq 0}")#text(", with equality when ")#mi("{g=h}")#text(".")],
[#text("(Symmetry) ")#mi("{d_\\psi(g,h) = d_\\psi(h,g)}")#text(".")],
[#text("(Triangle inequality) ")#mi("{d_\\psi(g,k) \\leq d_\\psi(g,h) + d_\\psi(h,k)}")#text(".")],
[#text("(Continuity) If ")#mi("{\\psi \\in C_c(G)}")#text(", then the map ")#mi("{d_\\psi: G \\times G \\rightarrow {\\bf R}^+}")#text(" is continuous.")],
[#text("(Boundedness) One has ")#tao-math("{d_\\psi(g,h) \\leq \\sup_{x \\in G} \\left|\\psi(x)\\right|}", block: false)#text(". If ")#mi("{\\psi \\in C_c(G)}")#text(" is supported in a set ")#mi("{K}")#text(", then equality occurs unless ")#mi("{g^{-1} h \\in K K^{-1}}")#text(".")],
[#text("(Left-invariance) ")#mi("{d_\\psi(g,h) = d_\\psi(kg,kh)}")#text(". In particular, ")#tao-math("{d_\\psi(g,h) = \\left\\| h^{-1} g \\right\\|_\\psi = \\left\\| g^{-1} h \\right\\|_\\psi}", block: false)#text(".")]
)

#text("In particular, we have the norm-like properties")

#enum(start: 1, 
[#text("(Identity) ")#tao-math("{\\left\\|g\\right\\|_\\psi \\geq 0}", block: false)#text(", with equality when ")#mi("{g=\\text{id}}")#text(".")],
[#text("(Symmetry) ")#tao-math("{\\left\\|g\\right\\|_\\psi = \\left\\|g^{-1}\\right\\|_\\psi}", block: false)#text(".")],
[#text("(Triangle inequality) ")#tao-math("{\\left\\|gh\\right\\|_\\psi \\leq \\left\\|g\\right\\|_\\psi + \\left\\|h\\right\\|_\\psi}", block: false)#text(".")],
[#text("(Continuity) If ")#mi("{\\psi \\in C_c(G)}")#text(", then the map ")#mi("{\\|\\|_\\psi: G \\rightarrow {\\bf R}^+}")#text(" is continuous.")],
[#text("(Boundedness) One has ")#tao-math("{\\left\\|g\\right\\|_\\psi \\leq \\sup_{x \\in G} \\left|\\psi(x)\\right|}", block: false)#text(". If ")#mi("{\\psi \\in C_c(G)}")#text(" is supported in a set ")#mi("{K}")#text(", then equality occurs unless ")#mi("{g \\in K K^{-1}}")#text(".")]
)
]

#text("We remark that the first three properties of ")#mi("{d_\\psi}")#text(" in the above exercise ensure that ")#mi("{d_\\psi}")#text(" is indeed a ")#link("http://en.wikipedia.org/wiki/Pseudometric_space")[#text("pseudometric")]#text(".")

#text("To get good metrics (such as Gleason metrics) on groups ")#mi("{G}")#text(", it thus suffices to obtain test functions ")#mi("{\\psi}")#text(" that obey suitably good “regularity” properties. We will achieve this primarily by means of two tricks. The first trick is to obtain high-regularity test functions by convolving together two low-regularity test functions, taking advantage of the existence of a left-invariant Haar measure ")#mi("{\\mu}")#text(" on ")#mi("{G}")#text(". The second trick is to obtain low-regularity test functions by means of a metric-like object on ")#mi("{G}")#text(". This latter trick may seem circular, as our whole objective is to get a metric on ")#mi("{G}")#text(" in the first place, but the key point is that the metric one starts with does not need to have as many “good properties” as the metric one ends up with, thanks to the regularity-improving properties of convolution. As such, one can use a “bootstrap argument” (or induction argument) to create a good metric out of almost nothing. It is this bootstrap miracle which is at the heart of the proof of the Gleason-Yamabe theorem (and hence to the solution of Hilbert’s fifth problem).")

#text("The arguments here are based on the nonstandard analysis arguments used to establish Hilbert’s fifth problem ")#link("http://www.ams.org/mathscinet-getitem?mr=967314")[#text("by Hirschfeld")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2680491")[#text("by Goldbring")]#text(" (and also some unpublished lecture notes of Goldbring and van den Dries). However, we will not explicitly use any nonstandard analysis in this post.")

#metadata(none) <tao-e9f461e2bdf9541e1c9c>

#heading(level: 1)[#strong[#text(" — 1. Warmup: the Birkhoff-Kakutani theorem — ")]]

#text("To illustrate the basic idea of using test functions to build metrics, let us first establish a classical theorem on topological groups, which gives a necessary and sufficient condition for metrisability. Recall that a topological space is metrisable if there is a metric on that space that generates the topology.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Birkhoff-Kakutani theorem)")]#text(" A topology group is metrisable if and only if it is Hausdorff and ")#link("http://en.wikipedia.org/wiki/First-countable_space")[#text("first countable")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" The group structure is crucial; for instance, the ")#link("http://en.wikipedia.org/wiki/Long_line_(topology)")[#text("long line")]#text(" is Hausdorff and first countable, but not metrisable.")
]

#text("We now prove this theorem (following the arguments in ")#link("http://www.ams.org/mathscinet-getitem?mr=73104")[#text("this book of Montgomery and Zippin")]#text("). The “only if” direction is easy, so it suffices to establish the “if” direction. The key lemma is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9 (Urysohn-type lemma)")]#text(" ")#metadata(none) <tao-1ffb6a8634b36d55fec6>#text(" Let ")#mi("{G}")#text(" be a Hausdorff first countable group. Then there exists a bounded continuous function ")#mi("{\\psi: G \\rightarrow [0,1]}")#text(" with the following properties:")

#list(
[#text("(Unique maximum) ")#mi("{\\psi(\\text{id}) = 1}")#text(", and ")#mi("{\\psi(x) < 1}")#text(" for all ")#mi("{x \\neq \\text{id}}")#text(".")],
[#text("(Neighbourhood base) The sets ")#mi("{\\{ x \\in G: \\psi(x) > 1-1/n \\}}")#text(" for ")#mi("{n=1,2,\\ldots}")#text(" form a ")#link("http://en.wikipedia.org/wiki/Neighbourhood_system")[#text("neighbourhood base")]#text(" at the identity.")],
[#text("(Uniform continuity) For every ")#mi("{\\varepsilon > 0}")#text(", there exists an open neighbourhood ")#mi("{U}")#text(" of the identity such that ")#tao-math("{\\left|\\psi(gx)-\\psi(x)\\right| \\leq \\varepsilon}", block: false)#text(" for all ")#mi("{g \\in U}")#text(" and ")#mi("{x \\in G}")#text(".")]
)
]

#text("Note that if ")#mi("{G}")#text(" had a left-invariant metric, then the function ")#mi("{\\psi(x) := \\max( 1 - d(x,\\text{id}), 0)}")#text(" would suffice for this lemma, which already gives some indication as to why this lemma is relevant to the Birkhoff-Kakutani theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Let ")#mi("{G}")#text(" be a Hausdorff first countable group, and let ")#mi("{\\psi}")#text(" be as in Lemma ")#link(<tao-1ffb6a8634b36d55fec6>)[#text("9")]#text(". Show that ")#mi("{d_\\psi}")#text(" is a metric on ")#mi("{G}")#text(" (so in particular, ")#mi("{d_\\psi(g,h)}")#text(" only vanishes when ")#mi("{g=h}")#text(") and that ")#mi("{d_\\psi}")#text(" generates the topology of ")#mi("{G}")#text(" (thus every set which is open with respect to ")#mi("{d_\\psi}")#text(" is open in ")#mi("{G}")#text(", and vice versa).")
]

#text("In view of the above exercise, we see that to prove the Birkhoff-Kakutani theorem, it suffices to prove Lemma ")#link(<tao-1ffb6a8634b36d55fec6>)[#text("9")]#text(", which we now do. By first countability, we can find a countable neighbourhood base")

#align(center)[#tao-fit-display[#mitex("V_1 \\supset V_2 \\supset \\ldots \\supset \\{\\text{id}\\}")]]

#text("of the identity. As ")#mi("{G}")#text(" is Hausdorff, we must have")

#align(center)[#tao-fit-display[#mitex("\\bigcap_{n=1}^\\infty V_n = \\{\\text{id}\\}.")]]

#text("Using the continuity of the group operations, we can recursively find a sequence of nested open neighbourhoods of the identity ")#metadata(none) <tao-8c3b59f15babd916995e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("U_1 \\supset U_{1/2} \\supset U_{1/4} \\supset \\ldots \\supset \\{\\text{id}\\}")]]

#text("such that each ")#mi("{U_{1/2^n}}")#text(" is symmetric (i.e. ")#mi("{g \\in U_{1/2^n}}")#text(" if and only if ")#mi("{g^{-1} \\in U_{1/2^n}}")#text("), is contained in ")#mi("{V_n}")#text(", and is such that ")#mi("{U_{1/2^{n+1}} \\cdot U_{1/2^{n+1}} \\subset U_{1/2^n}}")#text(" for each ")#mi("{n \\geq 0}")#text(". In particular the ")#mi("{U_{1/2^n}}")#text(" are also a neighbourhood base of the identity with ")#metadata(none) <tao-68bca10eea2ba33f6f15>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\bigcap_{n=1}^\\infty U_{1/2^n} = \\{\\text{id}\\}.")]]

#text("For every dyadic rational ")#mi("{a/2^n}")#text(" in ")#mi("{(0,1)}")#text(", we can now define the open sets ")#mi("{U_{a/2^n}}")#text(" by setting")

#align(center)[#tao-fit-display[#mitex("U_{a/2^n} := U_{1/2^{n_k}} \\cdot \\ldots \\cdot U_{1/2^{n_1}}")]]

#text("where ")#mi("{a/2^n = 2^{-n_1} + \\ldots + 2^{-n_k}}")#text(" is the binary expansion of ")#mi("{a/2^n}")#text(" with ")#mi("{1 \\leq n_1 < \\ldots < n_k}")#text(". By repeated use of the hypothesis ")#mi("{U_{1/2^{n+1}} \\cdot U_{1/2^{n+1}} \\subset U_{1/2^n}}")#text(" we see that the ")#mi("{U_{a/2^n}}")#text(" are increasing in ")#mi("{a/2^n}")#text("; indeed, we have the inclusion ")#metadata(none) <tao-78fbd9ec4f620ff73f58>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("U_{1/2^n} \\cdot U_{a/2^n} \\subset U_{(a+1)/2^n}")]]

#text("for all ")#mi("{n \\geq 1}")#text(" and ")#mi("{1 \\leq a < 2^n}")#text(".")

#text("We now set")

#align(center)[#tao-fit-display[#mitex("\\psi(x) := \\sup \\{ 1 - \\frac{a}{2^n}: n \\geq 1; 1 \\leq a < 2^n; x \\in U_{a/2^n} \\}")]]

#text("with the understanding that ")#mi("{\\psi(x)=0}")#text(" if the supremum is over the empty set. One easily verifies using ")#link(<tao-78fbd9ec4f620ff73f58>)[#text("(4)")]#text(" that ")#mi("{\\psi}")#text(" is continuous, and furthermore obeys the uniform continuity property. The neighbourhood base property follows since the ")#mi("{U_{1/2^n}}")#text(" are a neighbourhood base of the identity, and the unique maximum property follows from ")#link(<tao-68bca10eea2ba33f6f15>)[#text("(3)")]#text(". This proves Lemma ")#link(<tao-1ffb6a8634b36d55fec6>)[#text("9")]#text(", and the Birkhoff-Kakutani theorem follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Let ")#mi("{G}")#text(" be a topological group. Show that ")#mi("{G}")#text(" is ")#link("http://en.wikipedia.org/wiki/Completely_regular_space")[#text("completely regular")]#text(", that is to say for every closed subset ")#mi("{F}")#text(" in ")#mi("{G}")#text(" and every ")#mi("{x \\in G \\backslash F}")#text(", there exists a continuous function ")#mi("{f: G \\rightarrow {\\bf R}}")#text(" that equals ")#mi("{1}")#text(" on ")#mi("{F}")#text(" and vanishes on ")#mi("{x}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12 (Reduction to the metrisable case)")]#text(" ")#metadata(none) <tao-549fedc167d28745132a>#text(" Let ")#mi("{G}")#text(" be a locally compact group, let ")#mi("{U}")#text(" be an open neighbourhood of the identity, and let ")#mi("{G^{\\prime}}")#text(" be the group generated by ")#mi("{U}")#text(".")

#list(
[#text("(i) Construct a sequence of open neighbourhoods of the identity")

#align(center)[#tao-fit-display[#mitex("U \\supset U_1 \\supset U_2 \\supset \\ldots")]]

#text("with the property that ")#mi("{U_{n+1}^2 \\subset U_n}")#text(" and ")#mi("{U_{n+1}^U \\subset U_n}")#text(" for all ")#mi("{n \\geq 1}")#text(", where ")#mi("{A^B := \\{ a^b: a \\in A, b \\in B \\}}")#text(" and ")#mi("{a^b := b^{-1} a b}")#text(".")],
[#text("(ii) If we set ")#mi("{H := \\bigcap_{n=1}^\\infty U_n}")#text(", show that ")#mi("{H}")#text(" is a closed normal subgroup ")#mi("{G^{\\prime}}")#text(" in ")#mi("{U}")#text(", and the quotient group ")#mi("{G^{\\prime}/H}")#text(" is Hausdorff and first countable (and thus metrisable, by the Birkhoff-Kakutani theorem).")],
[#text("(iii) Conclude that to prove the Gleason-Yamabe theorem (Theorem ")#link(<tao-903d8df0b5ef51b3d76c>)[#text("1")]#text("), it suffices to do so under the assumption that ")#mi("{G}")#text(" is metrisable.")]
)

#text("The above arguments are essentially in ")#link("http://www.ams.org/mathscinet-getitem?mr=49203")[#text("this paper of Gleason")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Birkhoff-Kakutani theorem for local groups)")]#text(" Let ")#mi("{G}")#text(" be a local group which is Hausdorff and first countable. Show that there exists an open neighbourhood ")#mi("{V_0}")#text(" of the identity which is metrisable.")
]

#heading(level: 1)[#strong[#text(" — 2. Obtaining the commutator estimate via convolution — ")]]

#text("We now return to the main task of constructing Gleason metrics. The first thing we will do is dispense with the commutator property ")#link(<tao-0a83d217c9ff25c77929>)[#text("(1)")]#text(". Thus, define a ")#emph[#text("weak Gleason metric")]#text(" on a topological group ")#mi("{G}")#text(" to be a left-invariant metric ")#mi("{d: G \\times G \\rightarrow {\\bf R}^+}")#text(" which generates the topology on ")#mi("{G}")#text(" and obeys the escape property for some constant ")#mi("{C>0}")#text(", thus one has ")#metadata(none) <tao-cb65a96799cc2a3c19fc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\|g^n\\right\\| \\geq \\frac{1}{C} n \\|g\\| \\text{ whenever } g \\in G, n \\geq 1, \\text{ and } n \\left\\|g\\right\\| \\leq \\frac{1}{C}.", block: true)]]

#text("In this section we will show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 14")]#text(" ")#metadata(none) <tao-4d4546383ac2aa8c12be>#text(" Every weak Gleason metric is a Gleason metric (possibly after adjusting the constant ")#mi("{C}")#text(").")
]

#text("We now prove this theorem. The key idea here is to involve a bump function ")#mi("{\\phi}")#text(" formed by convolving together two Lipschitz functions. The escape property ")#link(<tao-cb65a96799cc2a3c19fc>)[#text("(5)")]#text(" will be crucial in obtaining quantitative control of the metric geometry at very small scales, as one can study the size of a group element ")#mi("{g}")#text(" very close to the origin through its powers ")#mi("{g^n}")#text(", which are further away from the origin.")

#text("Specifically, let ")#mi("{\\varepsilon > 0}")#text(" be a small quantity to be chosen later, and let ")#mi("{\\psi \\in C_c(G)}")#text(" be a non-negative Lipschitz function supported on the ball ")#mi("{B(0,\\varepsilon)}")#text(" which is not identically zero. For instance, one could use the explicit function")

#align(center)[#tao-fit-display[#tao-math("\\psi(x) := (1 - \\frac{\\left\\|x\\right\\|}{\\varepsilon})_+", block: true)]]

#text("where ")#mi("{y_+ := \\max(y,0)}")#text(", although the exact form of ")#mi("{\\psi}")#text(" will not be important for our argument. Being Lipschitz, we see that ")#metadata(none) <tao-355c34e7c2a90b66f5f0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left\\| \\partial_g \\psi \\right\\|_{C_c(G)} \\ll \\left\\|g\\right\\|", block: true)]]

#text("for all ")#mi("{g \\in G}")#text(" (where we allow implied constants to depend on ")#mi("{G}")#text(", ")#mi("{\\varepsilon}")#text(", and ")#mi("{\\psi}")#text("), where ")#mi("{\\|\\|_{C_c(G)}}")#text(" denotes the sup norm.")

#text("Let ")#mi("{\\mu}")#text(" be a left-invariant Haar measure on ")#mi("{G}")#text(", the existence of which was established in Theorem 3 from ")#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/")[#text("Notes 3")]#text(". We then form the convolution ")#mi("{\\phi := \\psi * \\psi}")#text(", with convolution defined using the formula ")#metadata(none) <tao-a11e43a95d8ce33b525d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("f*g(x) := \\int_G f(y) g(y^{-1} x)\\ d\\mu(y).")]]

#text("This is a continuous function supported in ")#mi("{B(0,2\\varepsilon)}")#text(", and gives a metric ")#mi("{d_\\phi}")#text(" and a norm ")#mi("{\\| \\|_\\phi}")#text(" as usual.")

#text("We now prove a variant of the commutator estimate ")#link(<tao-0a83d217c9ff25c77929>)[#text("(1)")]#text(", namely that ")#metadata(none) <tao-866ab33b8463db1b3906>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left\\| \\partial_g \\partial_h \\phi \\right\\|_{C_c(G)} \\ll \\left\\|g\\right\\| \\left\\| h \\right\\|", block: true)]]

#text("whenever ")#mi("{g, h \\in B(0,\\varepsilon)}")#text(". To see this, we first use the left-invariance of Haar measure to write ")#metadata(none) <tao-8ac52d7d0c530608a22f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\partial_h \\phi = (\\partial_h \\psi) * \\psi,")]]

#text("thus")

#align(center)[#tao-fit-display[#mitex("\\partial_h \\phi(x) = \\int_G (\\partial_h \\psi)(y) \\psi(y^{-1} x)\\ d\\mu(y).")]]

#text("We would like to similarly move the ")#mi("{\\partial_g}")#text(" operator over to the second factor, but we run into a difficulty due to the non-abelian nature of ")#mi("{G}")#text(". Nevertheless, we can still do this provided that we twist that operator by a conjugation. More precisely, we have ")#metadata(none) <tao-ed72acc8c987fe55546a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\partial_g \\partial_h \\phi(x) = \\int_G (\\partial_h \\psi)(y) (\\partial_{g^y} \\psi)(y^{-1} x)\\ d\\mu(y)")]]

#text("where ")#mi("{g^y := y^{-1} g y}")#text(" is ")#mi("{g}")#text(" conjugated by ")#mi("{y}")#text(". If ")#mi("{h \\in B(0,\\varepsilon)}")#text(", the integrand is only non-zero when ")#mi("{y \\in B(0,2\\varepsilon)}")#text(". Applying ")#link(<tao-355c34e7c2a90b66f5f0>)[#text("(6)")]#text(", we obtain the bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\partial_g \\partial_h \\phi \\right\\|_{C_c(g)} \\ll \\left\\|h\\right\\| \\sup_{y \\in B(0,2\\varepsilon)} \\left\\|g^y\\right\\|.", block: true)]]

#text("To finish the proof of ")#link(<tao-866ab33b8463db1b3906>)[#text("(8)")]#text(", it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g^y\\right\\| \\ll \\left\\|g\\right\\|", block: true)]]

#text("whenever ")#mi("{g \\in B(0,\\varepsilon)}")#text(" and ")#mi("{y \\in B(0,2\\varepsilon)}")#text(".")

#text("We can achieve this by the escape property ")#link(<tao-cb65a96799cc2a3c19fc>)[#text("(5)")]#text(". Let ")#mi("{n}")#text(" be a natural number such that ")#tao-math("{n \\left\\|g\\right\\| \\leq \\varepsilon}", block: false)#text(", then for all ")#mi("{m \\leq n}")#text(" we have ")#tao-math("{\\left\\|g^m\\right\\| \\leq \\varepsilon}", block: false)#text(" and so ")#mi("{g^m \\in B(0,\\varepsilon)}")#text(". Conjugating by ")#mi("{y}")#text(", this implies that ")#mi("{(g^y)^m \\in B(0,5\\varepsilon)}")#text(" for all ")#mi("{m \\leq n}")#text(", and so by ")#link(<tao-cb65a96799cc2a3c19fc>)[#text("(5)")]#text(", we have ")#tao-math("{\\left\\|g^y\\right\\| \\ll \\frac{1}{n}}", block: false)#text(" (if ")#mi("{\\varepsilon}")#text(" is small enough), and the claim follows.")

#text("Next, we claim that the norm ")#mi("{\\| \\|_\\phi}")#text(" is locally comparable to the original norm ")#mi("{\\| \\|}")#text(". More precisely, we claim:")

#enum(start: 1, 
[#text("If ")#mi("{g \\in G}")#text(" with ")#tao-math("{\\left\\| g \\right\\|_\\phi}", block: false)#text(" sufficiently small, then ")#tao-math("{\\left\\| g \\right\\| \\ll \\left\\| g\\right\\|_\\phi}", block: false)#text(".")],
[#text("If ")#mi("{g \\in G}")#text(" with ")#tao-math("{\\left\\| g \\right\\|}", block: false)#text(" sufficiently small, then ")#tao-math("{\\left\\|g\\right\\|_\\phi \\ll \\left\\|g\\right\\|}", block: false)#text(".")]
)

#text("Claim 2 follows easily from ")#link(<tao-8ac52d7d0c530608a22f>)[#text("(9)")]#text(" and ")#link(<tao-355c34e7c2a90b66f5f0>)[#text("(6)")]#text(", so we turn to Claim 1. Let ")#mi("{g \\in G}")#text(", and let ")#mi("{n}")#text(" be a natural number such that")

#align(center)[#tao-fit-display[#tao-math("n \\left\\|g\\right\\|_\\phi < \\left\\| \\phi \\right\\|_{C_c(G)}.", block: true)]]

#text("Then by the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g^n \\right\\|_\\phi < \\left\\|\\phi \\right\\|_{C_c(G)}.", block: true)]]

#text("This implies that ")#mi("{\\phi}")#text(" and ")#mi("{\\tau_{g^n} \\phi}")#text(" have overlapping support, and hence ")#mi("{g^n}")#text(" lies in ")#mi("{B(0,4\\varepsilon)}")#text(". By the escape property ")#link(<tao-cb65a96799cc2a3c19fc>)[#text("(5)")]#text(", this implies (if ")#mi("{\\varepsilon}")#text(" is small enough) that ")#tao-math("{\\left\\|g\\right\\| \\ll \\frac{1}{n}}", block: false)#text(", and the claim follows.")

#text("Combining Claim 2 with ")#link(<tao-866ab33b8463db1b3906>)[#text("(8)")]#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\partial_g \\partial_h \\phi \\right\\|_{C_c(G)} \\ll \\left\\|g\\right\\|_\\phi \\left\\| h \\right\\|_\\phi", block: true)]]

#text("whenever ")#tao-math("{\\left\\|g\\right\\|_\\phi, \\left\\|h\\right\\|_\\phi}", block: false)#text(" are small enough. Now we use the identity")

#tao-aligned(keep: true)[


#tao-math("\\left\\| [g,h]\\right\\|_\\phi  & = \\left\\| \\tau([g,h]) \\phi - \\phi \\right\\|_{C_c(G)}", block: true)



#tao-math(" & = \\left\\| \\tau(g) \\tau(h) \\phi - \\tau(h) \\tau(g) \\phi \\right\\|_{C_c(G)}", block: true)



#tao-math(" & = \\left\\| \\partial_g \\partial_h \\phi - \\partial_h \\partial_g \\phi \\right\\|_{C_c(G)}", block: true)
]

#text("and the triangle inequality to conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| [g,h] \\right\\|_\\phi \\ll \\left\\|g\\right\\|_\\phi \\left\\|h\\right\\|_\\phi", block: true)]]

#text("whenever ")#tao-math("{\\left\\|g\\right\\|_\\phi, \\left\\|h\\right\\|_\\phi}", block: false)#text(" are small enough. Theorem ")#link(<tao-4d4546383ac2aa8c12be>)[#text("14")]#text(" then follows from Claim 1 and Claim 2.")

#heading(level: 1)[#strong[#text(" — 3. Building metrics on NSS groups — ")]]

#text("We will now be able to build metrics on groups using a set of hypotheses that do not explicitly involve any metric at all. The key hypothesis will be the ")#link("http://en.wikipedia.org/wiki/No_small_subgroup")[#text("no small subgroups")]#text(" (NSS) property:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 15 (No small subgroups)")]#text(" A topological group ")#mi("{G}")#text(" has the ")#emph[#text("no small subgroups")]#text(" (or NSS) property if there exists an open neighbourhood ")#mi("{U}")#text(" of the identity which does not contain any subgroup of ")#mi("{G}")#text(" other than the trivial group.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" ")#metadata(none) <tao-8b1d7193283d3d7e19ba>#text(" Show that any Lie group is NSS.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" Show that any group with a weak Gleason metric is NSS.")
]

#text("For an example of a group which is not NSS, consider the infinite-dimensional torus ")#mi("{({\\bf R}/{\\bf Z})^{\\bf N}}")#text(". From the definition of the product topology, we see that any neighbourhood of the identity in this torus contains an infinite-dimensional subtorus, and so this group is not NSS.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" Show that for any prime ")#mi("{p}")#text(", the ")#mi("{p}")#text("-adic groups ")#mi("{{\\bf Z}_p}")#text(" and ")#mi("{{\\bf Q}_p}")#text(" are not NSS. What about the solenoid group ")#mi("{{\\bf R} \\times {\\bf Z}_p / {\\bf Z}^\\Delta}")#text("?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Show that an NSS group is automatically Hausdorff. (")#emph[#text("Hint:")]#text(" use Exercise 3 from ")#link("http://en.wikipedia.org/wiki/No_small_subgroup")[#text("Notes 3")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Show that an NSS locally compact group is automatically metrisable. (")#emph[#text("Hint:")]#text(" use Exercise ")#link(<tao-549fedc167d28745132a>)[#text("12")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21 (NSS implies escape property)")]#text(" ")#metadata(none) <tao-cf78f2f9c55e877cff6b>#text(" Let ")#mi("{G}")#text(" be a locally compact NSS group. Show that if ")#mi("{U}")#text(" is a sufficiently small neighbourhood of the identity, then for every ")#mi("{g \\in G \\backslash \\{\\text{id}\\}}")#text(", there exists a positive integer ")#mi("{n}")#text(" such that ")#mi("{g^n \\not \\in U}")#text(". Furthermore, for any other neighbourhood ")#mi("{V}")#text(" of the identity, there exists a positive integer ")#mi("{N}")#text(" such that if ")#mi("{g,\\ldots,g^N \\in U}")#text(", then ")#mi("{g \\in V}")#text(".")
]

#text("We can now prove the following theorem (first proven in full generality ")#link("http://www.ams.org/mathscinet-getitem?mr=58607")[#text("by Yamabe")]#text("), which is a key component in the proof of the Gleason-Yamabe theorem and in the wider theory of Hilbert’s fifth problem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 22")]#text(" ")#metadata(none) <tao-b3140286ac71ad2acf69>#text(" Every NSS locally compact group admits a weak Gleason metric. In particular, by Theorem ")#link(<tao-4d4546383ac2aa8c12be>)[#text("14")]#text(" and Theorem ")#link(<tao-d6434d130e6177cf02f7>)[#text("3")]#text(", every NSS locally compact group is isomorphic to a Lie group.")
]

#text("In view of this theorem and Exercise ")#link(<tao-8b1d7193283d3d7e19ba>)[#text("16")]#text(", we see that for locally compact groups, the property of being a Lie group is equivalent to the property of being an NSS group. This is a major advance towards both the Gleason-Yamabe theorem and Hilbert’s fifth problem, as it has reduced the property of being a Lie group into a condition that is almost purely algebraic in nature.")

#text("We now prove Theorem ")#link(<tao-b3140286ac71ad2acf69>)[#text("22")]#text(". An important concept will be that of an ")#emph[#text("escape norm")]#text(" associated to an open neighbourhood ")#mi("{U}")#text(" of a group ")#mi("{G}")#text(", defined by the formula ")#metadata(none) <tao-4cd0e21a9a0795a14ec9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left\\|g\\right\\|_{e,U} := \\inf \\{ \\frac{1}{n+1}: g, g^2, \\ldots, g^n \\in U \\}", block: true)]]

#text("for any ")#mi("{g \\in G}")#text(", where ")#mi("{n}")#text(" ranges over the natural numbers (thus, for instance ")#tao-math("{\\left\\|g\\right\\|_{e,U} \\leq 1}", block: false)#text(", with equality iff ")#mi("{g \\not \\in U}")#text("). Thus, the longer it takes for the orbit ")#mi("{g, g^2, \\ldots}")#text(" to escape ")#mi("{U}")#text(", the smaller the escape norm.")

#text("Strictly speaking, the escape norm is not necessarily a norm, as it need not obey the symmetry, non-degeneracy, or triangle inequalities; however, we shall see that in many situations, the escape norm behaves similarly to a norm, even if it does not exactly obey the norm axioms. Also, as the name suggests, the escape norm will be well suited for establishing the escape property ")#link(<tao-cb65a96799cc2a3c19fc>)[#text("(5)")]#text(".")

#text("It is possible for the escape norm ")#tao-math("{\\left\\|g\\right\\|_{e,U}}", block: false)#text(" of a non-identity element ")#mi("{g \\in G}")#text(" to be zero, if ")#mi("{U}")#text(" contains the group ")#mi("{\\langle g \\rangle}")#text(" generated by ")#mi("{U}")#text(". But if the group ")#mi("{G}")#text(" has the NSS property, then we see that this cannot occur for all sufficiently small ")#mi("{U}")#text(" (where “sufficiently small” means “contained in a suitably chosen open neighbourhood ")#mi("{U_0}")#text(" of the identity”). In fact, more is true: if ")#mi("{U, U^{\\prime}}")#text(" are two sufficiently small open neighbourhoods of the identity in a locally compact NSS group ")#mi("{G}")#text(", then the two escape norms are comparable, thus we have ")#metadata(none) <tao-d11db1eb7e3ecfbdab04>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\left\\|g \\right\\|_{e,U} \\ll \\left\\|g\\right\\|_{e,U^{\\prime}} \\ll \\left\\|g\\right\\|_{e,U}", block: true)]]

#text("for all ")#mi("{g \\in G}")#text(" (where the implied constants can depend on ")#mi("{U, U^{\\prime}}")#text(").")

#text("By symmetry, it suffices to prove the second inequality in ")#link(<tao-d11db1eb7e3ecfbdab04>)[#text("(12)")]#text(". By ")#link(<tao-4cd0e21a9a0795a14ec9>)[#text("(11)")]#text(", it suffices to find an integer ")#mi("{m}")#text(" such that whenever ")#mi("{g \\in G}")#text(" is such that ")#mi("{g, g^2, \\ldots, g^m \\in U}")#text(", then ")#mi("{g \\in U^{\\prime}}")#text(". But this follows from Exercise ")#link(<tao-cf78f2f9c55e877cff6b>)[#text("21")]#text(". This concludes the proof of ")#link(<tao-d11db1eb7e3ecfbdab04>)[#text("(12)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Let ")#mi("{G}")#text(" be a locally compact group. Show that if ")#mi("{d}")#text(" is a left-invariant metric on ")#mi("{G}")#text(" obeying the escape property ")#link(<tao-cb65a96799cc2a3c19fc>)[#text("(5)")]#text(" that generates the topology, then ")#mi("{G}")#text(" is NSS, and ")#tao-math("{\\left\\| g\\right\\|}", block: false)#text(" is comparable to ")#tao-math("{\\left\\|g\\right\\|_{e,U}}", block: false)#text(" for all sufficiently small ")#mi("{U}")#text(" and for all sufficiently small ")#mi("{g}")#text(". (In particular, any two left-invariant metrics obeying the escape property and generating the topology are locally comparable to each other.)")
]

#text("Henceforth ")#mi("{G}")#text(" is a locally compact NSS group. We now establish a metric-like property on the escape norm ")#mi("{\\|\\|_{e,U_0}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 24 (Approximate triangle inequality)")]#text(" ")#metadata(none) <tao-6309089b4e49323ae874>#text(" Let ")#mi("{U_0}")#text(" be a sufficiently small open neighbourhood of the identity. Then for any ")#mi("{n}")#text(" and any ")#mi("{g_1,\\ldots,g_n \\in G}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| g_1 \\ldots g_n \\right\\|_{e,U_0} \\ll \\sum_{i=1}^n \\left\\|g_i\\right\\|_{e,U_0}", block: true)]]

#text("(where the implied constant can depend on ")#mi("{U_0}")#text(").")
]

#text("Of course, in view of ")#link(<tao-d11db1eb7e3ecfbdab04>)[#text("(12)")]#text(", the exact choice of ")#mi("{U_0}")#text(" is irrelevant, so long as it is small. It is slightly convenient to take ")#mi("{U_0}")#text(" to be symmetric (thus ")#mi("{U_0 = U_0^{-1}}")#text("), so that ")#tao-math("{\\left\\|g\\right\\|_{e,U_0} = \\left\\|g^{-1}\\right\\|_{e,U_0}}", block: false)#text(" for all ")#mi("{g}")#text(".")

#emph[#text("Proof:")]#text(" We will use a bootstrap argument. Assume to start with that we somehow already have a weaker form of the conclusion, namely ")#metadata(none) <tao-cb5ae32cbd84a47c77ab>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left\\| g_1 \\ldots g_n \\right\\|_{e,U_0} \\leq M \\sum_{i=1}^n \\left\\|g_i\\right\\|_{e,U_0}", block: true)]]

#text("for all ")#mi("{n,g_1,\\ldots,g_n}")#text(" and some huge constant ")#mi("{M}")#text("; we will then deduce the same estimate with a smaller value of ")#mi("{M}")#text(". Afterwards we will show how to remove the hypothesis ")#link(<tao-cb5ae32cbd84a47c77ab>)[#text("(13)")]#text(".")

#text("Now suppose we have ")#link(<tao-cb5ae32cbd84a47c77ab>)[#text("(13)")]#text(" for some ")#mi("{M}")#text(". Motivated by the argument in the previous section, we now try to convolve together two “Lipschitz” functions. For this, we will need some metric-like functions. Define the modified escape norm ")#tao-math("{\\left\\|g\\right\\|_{*,U_0}}", block: false)#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g\\right\\|_{*,U_0} := \\inf \\{ \\sum_{i=1}^n \\left\\|g_i\\right\\|_{e,U_0}: g = g_1 \\ldots g_n \\}", block: true)]]

#text("where the infimum is over all possible ways to split ")#mi("{g}")#text(" as a finite product of group elements. From ")#link(<tao-cb5ae32cbd84a47c77ab>)[#text("(13)")]#text(", we have ")#metadata(none) <tao-af07ff91ab7ce2a7d1f9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\frac{1}{M}\\left\\|g\\right\\|_{e,U_0} \\leq \\left\\|g\\right\\|_{*,U_0} \\leq \\left\\|g\\right\\|_{e,U_0}", block: true)]]

#text("and we have the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|gh\\right\\|_{*,U_0} \\leq \\left\\|g\\right\\|_{*,U_0} + \\left\\|h\\right\\|_{*,U_0}", block: true)]]

#text("for any ")#mi("{g,h \\in G}")#text(". We also have the symmetry property ")#tao-math("{\\left\\|g\\right\\|_{*,U_0} = \\left\\|g^{-1} \\right\\|_{*,U_0}}", block: false)#text(". Thus ")#mi("{\\| \\|_{*,U_0}}")#text(" gives a left-invariant semi-metric on ")#mi("{G}")#text(" by defining")

#align(center)[#tao-fit-display[#tao-math("\\text{dist}_{*,U_0}(g,h) := \\left\\|g^{-1} h \\right\\|_{*,U_0}.", block: true)]]

#text("We can now define a “Lipschitz” function ")#mi("{\\psi: G \\rightarrow {\\bf R}}")#text(" by setting")

#align(center)[#tao-fit-display[#mitex("\\psi(x) := (1 - M \\text{dist}_{*,U_0}(x, U_0))_+.")]]

#text("On the one hand, we see from ")#link(<tao-af07ff91ab7ce2a7d1f9>)[#text("(14)")]#text(" that this function takes values in ")#mi("{[0,1]}")#text(" and obeys the Lipschitz bound ")#metadata(none) <tao-55b077ccbb0acccbafc2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left|\\partial_g \\psi(x)\\right| \\leq M \\left\\|g\\right\\|_{e,U_0}", block: true)]]

#text("for any ")#mi("{g, x \\in G}")#text(". On the other hand, it is supported in the region where ")#mi("{\\text{dist}_{*,U_0}(x,U_0) \\leq 1/M}")#text(", which by ")#link(<tao-af07ff91ab7ce2a7d1f9>)[#text("(14)")]#text(" (and ")#link(<tao-4cd0e21a9a0795a14ec9>)[#text("(11)")]#text(") is contained in ")#mi("{U_0^2}")#text(".")

#text("We could convolve ")#mi("{\\psi}")#text(" with itself in analogy to the preceding section, but in doing so, we will eventually end up establishing a much worse estimate than ")#link(<tao-cb5ae32cbd84a47c77ab>)[#text("(13)")]#text(" (in which the constant ")#mi("{M}")#text(" is replaced with something like ")#mi("{M^2}")#text("). Instead, we will need to convolve ")#mi("{\\psi}")#text(" with another function ")#mi("{\\eta}")#text(", that we define as follows. We will need a large natural number ")#mi("{L}")#text(" (independent of ")#mi("{M}")#text(") to be chosen later, then a small open neighbourhood ")#mi("{U_1 \\subset U_0}")#text(" of the identity (depending on ")#mi("{L, U_0}")#text(") to be chosen later. We then let ")#mi("{\\eta: G \\rightarrow {\\bf R}}")#text(" be the function")

#align(center)[#tao-fit-display[#mitex("\\eta(x) := \\sup \\{ 1 - \\frac{j}{L}: x \\in U_1^j U_0; j = 0,\\ldots,L \\} \\cup \\{0\\}.")]]

#text("Similarly to ")#mi("{\\psi}")#text(", we see that ")#mi("{\\eta}")#text(" takes values in ")#mi("{[0,1]}")#text(" and obeys the Lipschitz-type bound ")#metadata(none) <tao-9ace10752e5bc55d2c76>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left|\\partial_g \\eta(x)\\right| \\leq \\frac{1}{L}", block: true)]]

#text("for all ")#mi("{g \\in U_1}")#text(" and ")#mi("{x \\in G}")#text(". Also, ")#mi("{\\eta}")#text(" is supported in ")#mi("{U_1^L U_0}")#text(", and hence (if ")#mi("{U_1}")#text(" is sufficiently small depending on ")#mi("{L,U_0}")#text(") is supported in ")#mi("{U_0^2}")#text(", just as ")#mi("{\\psi}")#text(" is.")

#text("The functions ")#mi("{\\psi, \\eta}")#text(" need not be continuous, but they are compactly supported, bounded, and Borel measurable, and so one can still form their convolution ")#mi("{\\phi := \\psi * \\eta}")#text(", which will then be continuous and compactly supported; indeed, ")#mi("{\\phi}")#text(" is supported in ")#mi("{U_0^4}")#text(".")

#text("We have a lower bound on how big ")#mi("{\\phi}")#text(" is, since")

#align(center)[#tao-fit-display[#mitex("\\phi(0) \\geq \\mu(U_0) \\gg 1")]]

#text("(where we allow implied constants to depend on ")#mi("{\\mu, U_0}")#text(", but remain independent of ")#mi("{L}")#text(", ")#mi("{U_1}")#text(", or ")#mi("{M}")#text("). This gives us a way to compare ")#mi("{\\| \\|_{\\phi}}")#text(" with ")#mi("{\\| \\|_{e,U_0}}")#text(". Indeed, if ")#tao-math("{n \\left\\|g\\right\\|_{\\phi} < \\phi(0)}", block: false)#text(", then (as in the proof of Claim 1 in the previous section) we have ")#mi("{g^n \\in U_0^8}")#text("; this implies that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| g \\right\\|_{e,U_0^8} \\ll \\left\\| g \\right\\|_{\\phi}", block: true)]]

#text("for all ")#mi("{g \\in G}")#text(", and hence by ")#link(<tao-d11db1eb7e3ecfbdab04>)[#text("(12)")]#text(" we have ")#metadata(none) <tao-9ad66d3ac3c3fba69d99>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\left\\| g \\right\\|_{e,U_0} \\ll \\left\\| g \\right\\|_{\\phi}", block: true)]]

#text("also. In the converse direction, we have")

#tao-aligned(keep: true)[


#tao-math("\\left\\|g\\right\\|_\\phi  & = \\left\\| \\partial_g (\\psi * \\eta) \\right\\|_{C_c(G)}", block: true)



#tao-math(" & = \\left\\| (\\partial_g \\psi) * \\eta \\right\\|_{C_c(G)}", block: true)
]

#metadata(none) <tao-c3ccedf562d9529001d8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\ll M \\left\\|g\\right\\|_{e,U_0}", block: true)]]

#text("thanks to ")#link(<tao-55b077ccbb0acccbafc2>)[#text("(15)")]#text(". But we can do better than this, as follows. For any ")#mi("{g, h \\in G}")#text(", we have the analogue of ")#link(<tao-ed72acc8c987fe55546a>)[#text("(10)")]#text(", namely")

#align(center)[#tao-fit-display[#mitex("\\partial_g \\partial_h \\phi(x) = \\int_G (\\partial_h \\psi)(y) (\\partial_{g^y} \\eta)(y^{-1} x)\\ d\\mu(y)")]]

#text("If ")#mi("{h \\in U_0}")#text(", then the integrand vanishes unless ")#mi("{y \\in U_0^3}")#text(". By continuity, we can find a small open neighbourhood ")#mi("{U_2 \\subset U_1}")#text(" of the identity such that ")#mi("{g^y \\in U_1}")#text(" for all ")#mi("{g \\in U_2}")#text(" and ")#mi("{y \\in U_0^3}")#text("; we conclude from ")#link(<tao-55b077ccbb0acccbafc2>)[#text("(15)")]#text(", ")#link(<tao-9ace10752e5bc55d2c76>)[#text("(16)")]#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\partial_g \\partial_h \\phi(x)\\right| \\ll \\frac{M}{L} \\left\\|h\\right\\|_{e,U_0}.", block: true)]]

#text("whenever ")#mi("{h \\in U_0}")#text(" and ")#mi("{g \\in U_2}")#text(". To use this, we observe the telescoping identity")

#align(center)[#tao-fit-display[#mitex("\\partial_{g^n} = n \\partial_g + \\sum_{i=0}^{n-1} \\partial_g \\partial_{g^i}")]]

#text("for any ")#mi("{g \\in G}")#text(" and natural number ")#mi("{n}")#text(", and thus by the triangle inequality ")#metadata(none) <tao-72d9f85b4e4fda3ed392>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("\\left\\| g^n \\right\\|_\\phi = n \\left\\| g \\right\\|_\\phi + O( \\sum_{i=0}^{n-1} \\left\\| \\partial_g \\partial_{g^i} \\phi \\right\\|_{C_c(G)} ).", block: true)]]

#text("We conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g^n\\right\\|_\\phi = n \\left\\|g\\right\\|_\\phi + O( n \\frac{M}{L} \\left\\|g\\right\\|_{e,U_0} )", block: true)]]

#text("whenever ")#mi("{n \\geq 1}")#text(" and ")#mi("{g,\\ldots,g^n \\in U_2}")#text(". Using the trivial bound ")#tao-math("{\\left\\|g^n\\right\\|_\\phi = O(1)}", block: false)#text(", we then have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g\\right\\|_\\phi \\ll \\frac{1}{n} + \\frac{M}{L} \\left\\|g\\right\\|_{e,U_0};", block: true)]]

#text("optimising in ")#mi("{n}")#text(" we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g\\right\\|_\\phi \\ll \\left\\|g\\right\\|_{e,U_2} + \\frac{M}{L} \\left\\|g\\right\\|_{e,U_0}", block: true)]]

#text("and hence by ")#link(<tao-d11db1eb7e3ecfbdab04>)[#text("(12)")]

#align(center)[#tao-fit-display[#tao-math("\\left\\|g\\right\\|_\\phi \\ll (\\frac{M}{L} + O_{U_2}(1)) \\left\\|g\\right\\|_{e,U_0}", block: true)]]

#text("where the implied constant in ")#mi("{O_{U_2}(1)}")#text(" can depend on ")#mi("{U_0,U_1,U_2, L}")#text(", but is crucially independent of ")#mi("{M}")#text(". Note the essential gain of ")#mi("{\\frac{1}{L}}")#text(" here compared with ")#link(<tao-c3ccedf562d9529001d8>)[#text("(18)")]#text(". We also have the norm inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g_1 \\ldots g_n \\right\\|_\\phi \\leq \\sum_{i=1}^n \\left\\|g_i\\right\\|_\\phi.", block: true)]]

#text("Combining these inequalities with ")#link(<tao-9ad66d3ac3c3fba69d99>)[#text("(17)")]#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| g_1 \\ldots g_n \\right\\|_{e,U_0} \\ll (\\frac{1}{L} M + O_{U_2}(1)) \\sum_{i=1}^n \\left\\|g_i\\right\\|_{e,U_0}.", block: true)]]

#text("Thus we have improved the constant ")#mi("{M}")#text(" in the hypothesis ")#link(<tao-cb5ae32cbd84a47c77ab>)[#text("(13)")]#text(" to ")#mi("{O( \\frac{1}{L} M ) + O_{U_2}(1)}")#text(". Choosing ")#mi("{L}")#text(" large enough and iterating, we conclude that we can bootstrap any finite constant ")#mi("{M}")#text(" in ")#link(<tao-cb5ae32cbd84a47c77ab>)[#text("(13)")]#text(" to ")#mi("{O(1)}")#text(".")

#text("Of course, there is no reason why there has to be a finite ")#mi("{M}")#text(" for which ")#link(<tao-cb5ae32cbd84a47c77ab>)[#text("(13)")]#text(" holds in the first place. However, one can rectify this by the usual trick of creating an epsilon of room. Namely, one replaces the escape norm ")#tao-math("{\\left\\| g \\right\\|_{e,U_0}}", block: false)#text(" by, say, ")#tao-math("{\\left\\|g\\right\\|_{e,U_0}+\\varepsilon}", block: false)#text(" for some small ")#mi("{\\varepsilon > 0}")#text(" in the definition of ")#mi("{\\| \\|_{*,U_0}}")#text(" and in the hypothesis ")#link(<tao-cb5ae32cbd84a47c77ab>)[#text("(13)")]#text(". Then the bound ")#link(<tao-cb5ae32cbd84a47c77ab>)[#text("(13)")]#text(" will be automatic with a finite ")#mi("{M}")#text(" (of size about ")#mi("{O(1/\\varepsilon)}")#text("). One can then run the above argument with the requisite changes and conclude a bound of the form")

#align(center)[#tao-fit-display[#tao-math("\\left\\| g_1 \\ldots g_n \\right\\|_{e,U_0} \\ll \\sum_{i=1}^n (\\left\\|g_i\\right\\|_{e,U_0}+\\varepsilon)", block: true)]]

#text("uniformly in ")#mi("{\\varepsilon}")#text("; we omit the details. Sending ")#mi("{\\varepsilon \\rightarrow 0}")#text(", we have thus shown Proposition ")#link(<tao-6309089b4e49323ae874>)[#text("24")]#text(". ")#mi("\\Box")

#text("Now we can finish the proof of Theorem ")#link(<tao-b3140286ac71ad2acf69>)[#text("22")]#text(". Let ")#mi("{G}")#text(" be a locally compact NSS group, and let ")#mi("{U_0}")#text(" be a sufficiently small neighbourhood of the identity. From Proposition ")#link(<tao-6309089b4e49323ae874>)[#text("24")]#text(", we see that the escape norm ")#mi("{\\| \\|_{e,U_0}}")#text(" and the modified escape norm ")#mi("{\\| \\|_{*,U_0}}")#text(" are comparable. We have seen ")#mi("{d_{*,U_0}}")#text(" is a left-invariant pseudometric. As ")#mi("{G}")#text(" is NSS and ")#mi("{U_0}")#text(" is small, there are no non-identity elements with zero escape norm, and hence no non-identity elements with zero modified escape norm either; thus ")#mi("{d_{*,U_0}}")#text(" is a genuine metric.")

#text("We now claim that ")#mi("{d_{*,U_0}}")#text(" generates the topology of ")#mi("{G}")#text(". Given the left-invariance of ")#mi("{d_{*,U_0}}")#text(", it suffices to establish two things: firstly, that any open neighbourhood of the identity contains a ball around the identity in the ")#mi("{d_{*,U_0}}")#text(" metric; and conversely, any such ball contains an open neighbourhood around the identity.")

#text("To prove the first claim, let ")#mi("{U}")#text(" be an open neighbourhood around the identity, and let ")#mi("{U^{\\prime} \\subset U}")#text(" be a smaller neighbourhood of the identity. From ")#link(<tao-d11db1eb7e3ecfbdab04>)[#text("(12)")]#text(" we see (if ")#mi("{U^{\\prime}}")#text(" is small enough) that ")#mi("{\\| \\|_{*,U_0}}")#text(" is comparable to ")#mi("{\\| \\|_{e,U^{\\prime}}}")#text(", and ")#mi("{U^{\\prime}}")#text(" contains a small ball around the origin in the ")#mi("{d_{*,U_0}}")#text(" metric, giving the claim. To prove the second claim, consider a ball ")#mi("{B(0,r)}")#text(" in the ")#mi("{d_{*,U_0}}")#text(" metric. For any positive integer ")#mi("{m}")#text(", we can find an open neighbourhood ")#mi("{U_m}")#text(" of the identity such that ")#mi("{U_m^m \\subset U_0}")#text(", and hence ")#tao-math("{\\left\\|g\\right\\|_{e,U_0} \\leq \\frac{1}{m}}", block: false)#text(" for all ")#mi("{g \\in U_m}")#text(". For ")#mi("{m}")#text(" large enough, this implies that ")#mi("{U_m \\subset B(0,r)}")#text(", and the claim follows.")

#text("To finish the proof of Theorem ")#link(<tao-b3140286ac71ad2acf69>)[#text("22")]#text(", we need to verify the escape property ")#link(<tao-cb65a96799cc2a3c19fc>)[#text("(5)")]#text(". Thus, we need to show that if ")#mi("{g \\in G}")#text(", ")#mi("{n \\geq 1}")#text(" are such that ")#tao-math("{n \\left\\|g\\right\\|_{*,U_0}}", block: false)#text(" is sufficiently small, then we have ")#tao-math("{\\left\\|g^n\\right\\|_{*,U_0} \\gg n \\left\\|g\\right\\|_{*,U_0}}", block: false)#text(". We may of course assume that ")#mi("{g}")#text(" is not the identity, as the claim is trivial otherwise. As ")#mi("{\\|\\|_{*,U_0}}")#text(" is comparable to ")#mi("{\\| \\|_{e,U_0}}")#text(", we know that there exists a natural number ")#tao-math("{m \\ll 1 / \\left\\| g \\right\\|_{*,U_0}}", block: false)#text(" such that ")#mi("{g^m \\not \\in U_0}")#text(". Let ")#mi("{U_1}")#text(" be a neighbourhood of the identity small enough that ")#mi("{U_1^2 \\subset U_0}")#text(". We have ")#tao-math("{\\left\\|g^i\\right\\|_{*,U_0} \\leq n \\left\\|g\\right\\|_{*,U_0}}", block: false)#text(" for all ")#mi("{i=1,\\ldots,n}")#text(", so ")#mi("{g^i \\in U_1}")#text(" and hence ")#mi("{m > n}")#text(". Let ")#mi("{m+i}")#text(" be the first multiple of ")#mi("{n}")#text(" larger than ")#mi("{n}")#text(", then ")#mi("{i \\leq n}")#text(" and so ")#mi("{g^i \\in U_1}")#text(". Since ")#mi("{g^m \\not \\in U_0}")#text(", this implies ")#mi("{g^{m+i} \\not \\in U_1}")#text(". Since ")#mi("{m+i}")#text(" is divisible by ")#mi("{n}")#text(", we conclude that ")#tao-math("{\\left\\| g^n \\right\\|_{e,U_1} \\geq \\frac{n}{m+i} \\gg n \\left\\| g \\right\\|_{*,U_0}}", block: false)#text(", and the claim follows from ")#link(<tao-d11db1eb7e3ecfbdab04>)[#text("(12)")]#text(".")

#heading(level: 1)[#strong[#text(" — 4. NSS from subgroup trapping — ")]]

#text("In view of Theorem ")#link(<tao-b3140286ac71ad2acf69>)[#text("22")]#text(", the only remaining task in the proof of the Gleason-Yamabe theorem is to locate “big” subquotients ")#mi("{G^{\\prime}/H}")#text(" of a locally compact group ")#mi("{G}")#text(" with the NSS property. We will need some further notation. Given a neighbourhood ")#mi("{V}")#text(" of the identity in a topological group ")#mi("{G}")#text(", let ")#mi("{Q[V]}")#text(" denote the union of all the subgroups of ")#mi("{G}")#text(" that are contained in ")#mi("{V}")#text(". Thus, a group is NSS if ")#mi("{Q[V]}")#text(" is trivial for all sufficiently small ")#mi("{V}")#text(".")

#text("We will need a property that is weaker than NSS:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 25 (Subgroup trapping)")]#text(" ")#metadata(none) <tao-7b885bcc8763d78e786e>#text(" A topological group has the ")#emph[#text("subgroup trapping property")]#text(" if, for every open neighbourhood ")#mi("{U}")#text(" of the identity, there exists another open neighbourhood ")#mi("{V}")#text(" of the identity such that ")#mi("{Q[V]}")#text(" generates a subgroup ")#mi("{\\langle Q[V] \\rangle}")#text(" contained in ")#mi("{U}")#text(".")
]

#text("Clearly, every NSS group has the subgroup trapping property. Informally, groups with the latter property do have small subgroups, but one cannot get very far away from the origin just by combining together such subgroups.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 26")]#text(" The infinite-dimensional torus ")#mi("{({\\bf R}/{\\bf Z})^{\\bf N}}")#text(" does not have the NSS property, but it does have the subgroup trapping property.")
]

#text("It is difficult to produce an example of a group that does not have the subgroup trapping property; the reason for this will be made clear in the next section. For now, we establish the following key result.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 27 (From subgroup trapping to NSS)")]#text(" ")#metadata(none) <tao-e0f953ec8ff68d020aa7>#text(" Let ")#mi("{G}")#text(" be a locally compact group with the subgroup trapping property, and let ")#mi("{U}")#text(" be an open neighbourhood of the identity in ")#mi("{G}")#text(". Then there exists an open subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(", and a compact subgroup ")#mi("{N}")#text(" of ")#mi("{G^{\\prime}}")#text(" contained in ")#mi("{U}")#text(", such that ")#mi("{G^{\\prime}/N}")#text(" is locally compact and NSS. In particular, by Theorem ")#link(<tao-b3140286ac71ad2acf69>)[#text("22")]#text(", ")#mi("{G^{\\prime}/N}")#text(" is isomorphic to a Lie group.")
]

#text("Intuitively, the idea is to use the subgroup trapping property to find a small compact normal subgroup ")#mi("{N}")#text(" that contains ")#mi("{Q[V]}")#text(" for some small ")#mi("{V}")#text(", and then quotient this group out to get an NSS group. Unfortunately, because ")#mi("{N}")#text(" is not necessarily contained in ")#mi("{V}")#text(", this quotienting operation may create some additional small subgroups. To fix this, we need to pass from the compact subgroup ")#mi("{N}")#text(" to a smaller one. In order to understand the subgroups of compact groups, the main tool will be Gleason-Yamabe theorem for compact groups (Theorem ")#link(<tao-5e180a6b364155347a53>)[#text("4")]#text(").")

#text("For us, the main reason why we need the compact case of the Gleason-Yamabe theorem is that Lie groups automatically have the NSS property, even though ")#mi("{G}")#text(" need not. Thus, one can view Theorem ")#link(<tao-5e180a6b364155347a53>)[#text("4")]#text(" as giving the compact case of Proposition ")#link(<tao-e0f953ec8ff68d020aa7>)[#text("27")]#text(".")

#text("We now prove Proposition ")#link(<tao-e0f953ec8ff68d020aa7>)[#text("27")]#text(", using an argument ")#link("http://www.ams.org/mathscinet-getitem?mr=54613")[#text("of Yamabe")]#text(". Let ")#mi("{G}")#text(" be a locally compact group with the subgroup trapping property, and let ")#mi("{U}")#text(" be an open neighbourhood of the identity. We may find a smaller neighbourhood ")#mi("{U_1}")#text(" of the identity with ")#mi("{U_1^2 \\subset U}")#text(", which in particular implies that ")#mi("{\\overline{U_1} \\subset U}")#text("; by shrinking ")#mi("{U_1}")#text(" if necessary, we may assume that ")#mi("{\\overline{U_1}}")#text(" is compact. By the subgroup trapping property, one can find an open neighbourhood ")#mi("{U_2}")#text(" of the identity such that ")#mi("{\\langle Q(U_2) \\rangle}")#text(" is contained in ")#mi("{U_1}")#text(", and thus ")#mi("{H := \\overline{\\langle Q(U_2) \\rangle}}")#text(" is a compact subgroup of ")#mi("{G}")#text(" contained in ")#mi("{U}")#text(". By shrinking ")#mi("{U_2}")#text(" if necessary we may assume ")#mi("{U_2 \\subset U_1}")#text(".")

#text("Ideally, if ")#mi("{H}")#text(" were normal and contained in ")#mi("{U_2}")#text(", then the quotient group ")#mi("{G/H}")#text(" would have the NSS property. Unfortunately ")#mi("{H}")#text(" need not be normal, and need not be contained in ")#mi("{U_2}")#text(", but we can fix this as follows. Applying Theorem ")#link(<tao-5e180a6b364155347a53>)[#text("4")]#text(", we can find a compact normal subgroup ")#mi("{N}")#text(" of ")#mi("{H}")#text(" contained in ")#mi("{U_2 \\cap H}")#text(" such that ")#mi("{H/N}")#text(" is isomorphic to a Lie group, and in particular is NSS. In particular, we can find an open symmetric neighbourhood ")#mi("{U_3}")#text(" of the identity in ")#mi("{G}")#text(" such that ")#mi("{U_3 N U_3 \\subset U_2}")#text(" and that the quotient space ")#mi("{\\pi(U_3 N U_3 \\cap H)}")#text(" has no non-trivial subgroups in ")#mi("{H/N}")#text(", where ")#mi("{\\pi: H \\rightarrow H/N}")#text(" is the quotient map.")

#text("We now claim that ")#mi("{N}")#text(" is normalised by ")#mi("{U_3}")#text(". Indeed, if ")#mi("{g \\in U_3}")#text(", then the conjugate ")#mi("{N^g := g^{-1} N g}")#text(" of ")#mi("{N}")#text(" is contained in ")#mi("{U_3 N U_3}")#text(" and hence in ")#mi("{U_2}")#text(". As ")#mi("{N^g}")#text(" is a group, it must thus be contained in ")#mi("{Q(U_2)}")#text(" and hence in ")#mi("{H}")#text(". But then ")#mi("{\\pi(N^g)}")#text(" is a subgroup of ")#mi("{H/N}")#text(" that is contained in ")#mi("{\\pi(U_3 N U_3 \\cap H)}")#text(", and is hence trivial by construction. Thus ")#mi("{N^g \\subset N}")#text(", and so ")#mi("{N}")#text(" is normalised by ")#mi("{U_3}")#text(". If we then let ")#mi("{G^{\\prime}}")#text(" be the subgroup of ")#mi("{G}")#text(" generated by ")#mi("{N}")#text(" and ")#mi("{U_3}")#text(", we see that ")#mi("{G^{\\prime}}")#text(" is an open subgroup of ")#mi("{G}")#text(", with ")#mi("{N}")#text(" a compact normal subgroup of ")#mi("{G^{\\prime}}")#text(".")

#text("To finish the job, we need to show that ")#mi("{G^{\\prime}/N}")#text(" has the NSS property. It suffices to show that ")#mi("{U_3 N U_3 / N}")#text(" has no nontrivial subgroups. But any subgroup in ")#mi("{U_3 N U_3 / N}")#text(" pulls back to a subgroup in ")#mi("{U_3 N U_3}")#text(", hence in ")#mi("{U_2}")#text(", hence in ")#mi("{Q(U_2)}")#text(", hence in ")#mi("{H}")#text("; since ")#mi("{(U_3 N U_3 \\cap H)/N}")#text(" has no nontrivial subgroups, the claim follows. This concludes the proof of Proposition ")#link(<tao-e0f953ec8ff68d020aa7>)[#text("27")]#text(".")

#heading(level: 1)[#strong[#text(" — 5. The subgroup trapping property — ")]]

#text("In view of Theorem ")#link(<tao-b3140286ac71ad2acf69>)[#text("22")]#text(", Proposition ")#link(<tao-e0f953ec8ff68d020aa7>)[#text("27")]#text(", and Exercise ")#link(<tao-549fedc167d28745132a>)[#text("12")]#text(", we see that the Gleason-Yamabe theorem (Theorem ")#link(<tao-903d8df0b5ef51b3d76c>)[#text("1")]#text(") now reduces to the following claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 28")]#text(" ")#metadata(none) <tao-8564388283117bb31df2>#text(" Every locally compact metrisable group has the subgroup trapping property.")
]

#text("We now prove this proposition, which is the hardest step of the entire proof and uses almost all the tools already developed. In particular, it requires both Theorem ")#link(<tao-5e180a6b364155347a53>)[#text("4")]#text(" and Gleason’s convolution trick, as well as some of the basic theory of Hausdorff distance; as such, this is perhaps the most “infinitary” of all the steps in the argument.")

#text("The Gleason-type arguments can be encapsulated in the following proposition, which is a weak version of the subgroup trapping property:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 29 (Finite trapping)")]#text(" ")#metadata(none) <tao-d27d1a09d9f1be229304>#text(" Let ")#mi("{G}")#text(" be a locally compact group, let ")#mi("{U}")#text(" be an open precompact neighbourhood of the identity, and let ")#mi("{m \\geq 1}")#text(" be an integer. Then there exists an open neighbourhood ")#mi("{V}")#text(" of the identity with the following property: if ")#mi("{Q \\subset Q[V]}")#text(" is a symmetric set containing the identity, and ")#mi("{n \\geq 1}")#text(" is such that ")#mi("{Q^n \\subset U}")#text(", then ")#mi("{Q^{mn} \\subset U^8}")#text(".")
]

#text("Informally, Proposition ")#link(<tao-d27d1a09d9f1be229304>)[#text("29")]#text(" asserts that subsets of ")#mi("{Q[V]}")#text(" grow much more slowly than “large” sets such as ")#mi("{U}")#text(". We remark that if one could replace ")#mi("{U^8}")#text(" in the conclusion here by ")#mi("{U}")#text(", then a simple induction on ")#mi("{n}")#text(" (after first shrinking ")#mi("{V}")#text(" to lie in ")#mi("{U}")#text(") would give Proposition ")#link(<tao-8564388283117bb31df2>)[#text("28")]#text(". It is the loss of ")#mi("{8}")#text(" in the exponent that necessitates some non-trivial additional arguments.")

#emph[#text("Proof:")]#text(" } Let ")#mi("{V}")#text(" be small enough to be chosen later, and let ")#mi("{Q, n}")#text(" be as in the proposition. Once again we will convolve together two “Lipschitz” functions ")#mi("{\\psi, \\eta}")#text(" to obtain a good bump function ")#mi("{\\phi = \\psi*\\eta}")#text(" which generates a useful metric for analysing the situation. The first bump function ")#mi("{\\psi: G \\rightarrow {\\bf R}}")#text(" will be defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\psi(x) := \\sup \\{ 1 - \\frac{j}{n}: x \\in Q^j U; j = 0,\\ldots,n \\} \\cup \\{0\\}.")]]

#text("Then ")#mi("{\\psi}")#text(" takes values in ")#mi("{[0,1]}")#text(", equals ")#mi("{1}")#text(" on ")#mi("{U}")#text(", is supported in ")#mi("{U^2}")#text(", and obeys the Lipschitz type property ")#metadata(none) <tao-409a14887e0958f1efcd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("\\left|\\partial_q \\psi(x)\\right| \\leq \\frac{1}{n}", block: true)]]

#text("for all ")#mi("{q \\in Q}")#text(". The second bump function ")#mi("{\\eta: G \\rightarrow {\\bf R}}")#text(" is similarly defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\eta(x) := \\sup \\{ 1 - \\frac{j}{M}: x \\in (V^{U^4})^j U; j = 0,\\ldots,M \\} \\cup \\{0\\},")]]

#text("where ")#mi("{V^{U^4} := \\{ g^{-1} x g: x \\in V, g \\in U^4 \\}}")#text(", where ")#mi("{M}")#text(" is a quantity depending on ")#mi("{m}")#text(" and ")#mi("{U}")#text(" to be chosen later. If ")#mi("{V}")#text(" is small enough depending on ")#mi("{U}")#text(" and ")#mi("{m}")#text(", then ")#mi("{(V^{U^4})^M \\subset U}")#text(", and so ")#mi("{\\eta}")#text(" also takes values in ")#mi("{[0,1]}")#text(", equals ")#mi("{1}")#text(" on ")#mi("{U}")#text(", is supported in ")#mi("{U^2}")#text(", and obeys the Lipschitz type property ")#metadata(none) <tao-847901fd867ee75b5f12>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\left|\\partial_g \\psi(x)\\right| \\leq \\frac{1}{M}", block: true)]]

#text("for all ")#mi("{g \\in V^{U^4}}")#text(".")

#text("Now let ")#mi("{\\phi := \\psi * \\eta}")#text(". Then ")#mi("{\\phi}")#text(" is supported on ")#mi("{U^4}")#text(" and ")#tao-math("{\\left\\| \\phi \\right\\|_{C_c(G)} \\gg 1}", block: false)#text(" (where implied constants can depend on ")#mi("{U}")#text(", ")#mi("{\\mu}")#text("). As before, we conclude that ")#mi("{g \\in U^8}")#text(" whenever ")#tao-math("{\\left\\|g\\right\\|_\\phi}", block: false)#text(" is sufficiently small.")

#text("Now suppose that ")#mi("{q \\in Q[V]}")#text("; we will estimate ")#tao-math("{\\left\\|q\\right\\|_\\phi}", block: false)#text(". From ")#link(<tao-72d9f85b4e4fda3ed392>)[#text("(19)")]#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\|q\\right\\|_\\phi \\ll \\frac{1}{n} \\left\\| q^n \\right\\|_\\phi + \\sup_{0 \\leq i \\leq n} \\left\\| \\partial_{q^i} \\partial_{q} \\phi \\right\\|_{C_c(G)}", block: true)]]

#text("(note that ")#mi("{\\partial_{q^i}}")#text(" and ")#mi("{\\partial_q}")#text(" commute). For the first term, we can compute")

#align(center)[#tao-fit-display[#tao-math("\\left\\| q^n \\right\\|_\\phi = \\sup_x \\left|\\partial_{q^n} (\\psi * \\eta)(x)\\right|", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\partial_{q^n} (\\psi * \\eta)(x) = \\int_G \\psi(y) \\partial_{(q^n)^y}(y^{-1} x) d\\mu(y).")]]

#text("Since ")#mi("{q \\in Q[V]}")#text(", ")#mi("{q^n \\in V}")#text(", so by ")#link(<tao-847901fd867ee75b5f12>)[#text("(21)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| q^n \\right\\|_\\phi \\ll \\frac{1}{M}.", block: true)]]

#text("For the second term, we similarly expand")

#align(center)[#tao-fit-display[#mitex("\\partial_{q^i} \\partial_{q^i} \\phi(x) = \\int_G (\\partial_q \\psi)(y) \\partial_{(q^n)^y}(y^{-1} x) d\\mu(y).")]]

#text("Using ")#link(<tao-847901fd867ee75b5f12>)[#text("(21)")]#text(", ")#link(<tao-409a14887e0958f1efcd>)[#text("(20)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\partial_{q^i} \\partial_{q^i} \\phi(x)\\right| \\ll \\frac{1}{Mn}.", block: true)]]

#text("Putting this together we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|q\\right\\|_\\phi \\ll \\frac{1}{Mn}", block: true)]]

#text("for all ")#mi("{q \\in Q[V]}")#text(", which in particular implies that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| g \\right\\|_\\phi \\ll \\frac{m}{M}", block: true)]]

#text("for all ")#mi("{g \\in Q^{mn}}")#text(". For ")#mi("{M}")#text(" sufficiently large, this gives ")#mi("{Q^{mn} \\subset U^8}")#text(" as required. ")#mi("\\Box")

#text("We will also need the following compactness result in the ")#link("http://en.wikipedia.org/wiki/Hausdorff_distance")[#text("Hausdorff distance")]

#align(center)[#tao-fit-display[#mitex("d_H( E, F ) := \\max( \\sup_{x \\in E} \\text{dist}(x,F), \\sup_{y \\in F} \\text{dist}(E, y) )")]]

#text("between two non-empty closed subsets ")#mi("{E, F}")#text(" of a metric space ")#mi("{(X,d)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 30")]#text(" In ")#mi("{{\\bf R}}")#text(" with the usual metric, the finite sets ")#mi("{\\{ \\frac{i}{n}: i=1,\\ldots,n\\}}")#text(" converge in Hausdorff distance to the closed interval ")#mi("{[0,1]}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31")]#text(" ")#metadata(none) <tao-59bd2e1fa31d7ce676a3>#text(" Show that the space ")#mi("{K(X)}")#text(" of non-empty closed subsets of a compact metric space ")#mi("{X}")#text(" is itself a compact metric space (with the Hausdorff distance as the metric). (")#emph[#text("Hint:")]#text(" use the ")#link("http://en.wikipedia.org/wiki/Heine%E2%80%93Borel_theorem")[#text("Heine-Borel theorem")]#text(".)")
]

#text("Now we can prove Proposition ")#link(<tao-8564388283117bb31df2>)[#text("28")]#text(". Let ")#mi("{G}")#text(" be a locally compact group endowed with some metric ")#mi("{d}")#text(", and let ")#mi("{U}")#text(" be an open neighbourhood of the identity; by shrinking ")#mi("{U}")#text(" we may assume that ")#mi("{U}")#text(" is precompact. Let ")#mi("{V_i}")#text(" be a sequence of balls around the identity with radius going to zero, then ")#mi("{Q[V_i]}")#text(" is a symmetric set in ")#mi("{V_i}")#text(" that contains the identity. If, for some ")#mi("{i}")#text(", ")#mi("{Q[V_i]^n \\subset U}")#text(" for every ")#mi("{n}")#text(", then ")#mi("{\\langle Q[V_i] \\rangle \\subset U}")#text(" and we are done. Thus, we may assume for sake of contradiction that there exists ")#mi("{n_i}")#text(" such that ")#mi("{Q[V_i]^{n_i} \\subset U}")#text(" and ")#mi("{Q[V_i]^{n_i + 1} \\not \\subset U}")#text("; since the ")#mi("{V_i}")#text(" go to zero, we have ")#mi("{n_i \\rightarrow \\infty}")#text(". By Proposition ")#link(<tao-d27d1a09d9f1be229304>)[#text("29")]#text(", we can also find ")#mi("{m_i \\rightarrow \\infty}")#text(" such that ")#mi("{Q[V_i]^{m_i n_i} \\subset U^8}")#text(".")

#text("The sets ")#mi("{\\overline{Q[V_i]}^{n_i}}")#text(" are closed subsets of ")#mi("{\\overline{U}}")#text("; by Exercise ")#link(<tao-59bd2e1fa31d7ce676a3>)[#text("31")]#text(", we may pass to a subsequence and assume that they converge to some closed subset ")#mi("{E}")#text(" of ")#mi("{\\overline{U}}")#text(". Since the ")#mi("{Q[V_i]}")#text(" are symmetric and contain the identity, ")#mi("{E}")#text(" is also symmetric and contains the identity. For any fixed ")#mi("{m}")#text(", we have ")#mi("{Q[V_i]^{m n_i} \\subset U^8}")#text(" for all sufficiently large ")#mi("{i}")#text(", which on taking Hausdorff limits implies that ")#mi("{E^m \\subset \\overline{U^8}}")#text(". In particular, the group ")#mi("{H := \\overline{\\langle E \\rangle}}")#text(" is a compact subgroup of ")#mi("{G}")#text(" contained in ")#mi("{\\overline{U^8}}")#text(".")

#text("Let ")#mi("{U_1}")#text(" be a small neighbourhood of the identity in ")#mi("{G}")#text(" to be chosen later. By Theorem ")#link(<tao-5e180a6b364155347a53>)[#text("4")]#text(", we can find a normal subgroup ")#mi("{N}")#text(" of ")#mi("{H}")#text(" contained in ")#mi("{U_1 \\cap H}")#text(" such that ")#mi("{H/N}")#text(" is NSS. Let ")#mi("{B}")#text(" be a neigbourhood of the identity in ")#mi("{H/N}")#text(" so small that ")#mi("{B^{10}}")#text(" has no small subgroups. A compactness argument then shows that there exists a natural number ")#mi("{k}")#text(" such that for any ")#mi("{g \\in H/N}")#text(" that is not in ")#mi("{B}")#text(", at least one of ")#mi("{g, \\ldots,g^k}")#text(" must lie outside of ")#mi("{B^{10}}")#text(".")

#text("Now let ")#mi("{\\varepsilon > 0}")#text(" be a small parameter. Since ")#mi("{Q[V_i]^{n_i+1} \\not \\subset U}")#text(", we see that ")#mi("{Q[V_i]^{n_i+1}}")#text(" does not lie in the ")#mi("{\\varepsilon}")#text("-neighbourhood ")#mi("{\\pi^{-1}(B)_\\varepsilon}")#text(" of ")#mi("{\\pi^{-1}(B)}")#text(" if ")#mi("{\\varepsilon, U_1, B}")#text(" are small enough, where ")#mi("{\\pi: H \\rightarrow H/N}")#text(" is the projection map. Let ")#mi("{n^{\\prime}_i}")#text(" be the first integer for which ")#mi("{Q[V_i]^{n^{\\prime}_i}}")#text(" does not lie in ")#mi("{\\pi^{-1}(B)_\\varepsilon}")#text(", then ")#mi("{n^{\\prime}_i \\leq n_i+1}")#text(" and ")#mi("{n^{\\prime}_i \\rightarrow \\infty}")#text(" as ")#mi("{i \\rightarrow \\infty}")#text(" (for fixed ")#mi("{\\varepsilon}")#text("). On the other hand, as ")#mi("{Q[V_i]^{n^{\\prime}_i-1} \\subset \\pi^{-1}(B)_\\varepsilon}")#text(", we see from another application of Proposition ")#link(<tao-d27d1a09d9f1be229304>)[#text("29")]#text(" that ")#mi("{Q[V_i]^{kn^{\\prime}_i} \\subset (\\pi^{-1}(B)_\\varepsilon)^8}")#text(" if ")#mi("{i}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon}")#text(".")

#text("On the other hand, since ")#mi("{Q[V_i]^{n_i}}")#text(" converges to a subset of ")#mi("{H}")#text(" in the Hausdorff distance, we know that for ")#mi("{i}")#text(" large enough, ")#mi("{Q[V_i]^{2n_i}}")#text(" and hence ")#mi("{Q[V_i]^{n^{\\prime}_i}}")#text(" is contained in the ")#mi("{\\varepsilon}")#text("-neighbourhood of ")#mi("{H}")#text(". Thus we can find an element ")#mi("{g_i}")#text(" of ")#mi("{Q[V_i]^{n^{\\prime}_i}}")#text(" that lies within ")#mi("{\\varepsilon}")#text(" of a group element ")#mi("{h_i}")#text(" of ")#mi("{H}")#text(", but does not lie in ")#mi("{\\pi^{-1}(B)_\\varepsilon}")#text("; thus ")#mi("{h_i}")#text(" lies inside ")#mi("{H \\backslash \\pi^{-1}(B)}")#text(". By construction of ")#mi("{B}")#text(", we can find ")#mi("{1 \\leq j_i \\leq k}")#text(" such that ")#mi("{h^{j_i}_i}")#text(" lies in ")#mi("{H \\backslash \\pi^{-1}(B^{10})}")#text(". But ")#mi("{h_i^{j_i}}")#text(" also lies within ")#mi("{o(1)}")#text(" of ")#mi("{g_i^{j_i}}")#text(", which lies in ")#mi("{Q[V_i]^{kn^{\\prime}_i}}")#text(" and hence in ")#mi("{(\\pi^{-1}(B)_\\varepsilon)^8}")#text(", where ")#mi("{o(1)}")#text(" denotes a quantity depending on ")#mi("{\\varepsilon}")#text(" that goes to zero as ")#mi("{\\varepsilon \\rightarrow 0}")#text(". We conclude that ")#mi("{H \\backslash \\pi^{-1}(B^{10})}")#text(" and ")#mi("{\\pi^{-1}(B^8)}")#text(" are separated by ")#mi("{o(1)}")#text(", which leads to a contradiction if ")#mi("{\\varepsilon}")#text(" is sufficiently small (note that ")#mi("{\\overline{\\pi^{-1}(B^8)}}")#text(" and ")#mi("{H \\backslash \\pi^{-1}(B^{10})}")#text(" are compact and disjoint, and hence separated by a positive distance), and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32")]#text(" Let ")#mi("{X}")#text(" be a compact metric space, ")#mi("{K_c(X)}")#text(" denote the space of non-empty closed and ")#emph[#text("connected")]#text(" subsets of ")#mi("{X}")#text(". Show that ")#mi("{K_c(X)}")#text(" with the Hausdorff metric is also a compact metric space.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" Show that the metrisability condition in Proposition ")#link(<tao-8564388283117bb31df2>)[#text("28")]#text(" can be dropped; in other words, show that every locally compact group has the subgroup trapping property.")
]

#heading(level: 1)[#strong[#text(" — 6. The local group case — ")]]

#text("In the thesis of Goldbring (and also the later ")#link("http://www.ams.org/mathscinet-getitem?mr=2743102")[#text("paper of Goldbring and van den Dries")]#text("), the above theory was extended to the setting of local groups. In fact, there is relatively little difficulty (other than some notational difficulties) in doing so, because the analysis in the previous sections can be made to take place on a small neighbourhood of the origin. This extension to local groups is not simply a generalisation for its own sake; it will turn out that it will be natural to work with local groups when we classify approximate groups in later notes.")

#text("One technical issue that comes up in the theory of local groups is that basic cancellation laws such as ")#mi("{gh=gk \\implies h=k}")#text(", which are easily verified for groups, are not always true for local groups. However, this is a minor issue as one can always recover the cancellation laws by passing to a slightly smaller local group, as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 34 (Cancellative local group)")]#text(" A local group ")#mi("{G}")#text(" is said to be ")#emph[#text("symmetric")]#text(" if the inverse operation is always well-defined. It is said to be ")#emph[#text("cancellative")]#text(" if it is symmetric, and the following axioms hold:")

#list(
[#text("(i) Whenever ")#mi("{g,h,k \\in G}")#text(" are such that ")#mi("{gh}")#text(" and ")#mi("{gk}")#text(" are well-defined and equal to each other, then ")#mi("{h=k}")#text(". (Note that this implies in particular that ")#mi("{(g^{-1})^{-1} = g}")#text(".)")],
[#text("(ii) Whenever ")#mi("{g,h,k \\in G}")#text(" are such that ")#mi("{hg}")#text(" and ")#mi("{kg}")#text(" are well-defined and equal to each other, then ")#mi("{h=k}")#text(".")],
[#text("(iii) Whenever ")#mi("{g,h \\in G}")#text(" are such that ")#mi("{gh}")#text(" and ")#mi("{h^{-1}g^{-1}}")#text(" are well-defined, then ")#mi("{(gh)^{-1} = h^{-1}g^{-1}}")#text(". (In particular, if ")#mi("{U \\subset G}")#text(" is symmetric and ")#mi("{U^m}")#text(" is well-defined in ")#mi("{G}")#text(" for some ")#mi("{m \\geq 1}")#text(", then ")#mi("{U^m}")#text(" is also symmetric.)")]
)
]

#text("Clearly, all global groups are cancellative, and more generally the restriction of a global group to a symmetric neighbourhood of the identity s cancellative. While not all local groups are cancellative, we have the following substitute:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35")]#text(" Let ")#mi("{G}")#text(" be a local group. Show that there is a neighbourhood ")#mi("{U}")#text(" of the identity which is cancellative (thus, the restriction ")#mi("{G\\downharpoonright_U}")#text(" of ")#mi("{G}")#text(" to ")#mi("{U}")#text(" is cancellative).")
]

#text("Note that any symmetric neighbourhood of the identity in a cancellative local group is again a cancellative local group. Because of this, it turns out in practice that we may restrict to the cancellative setting without much loss of generality.")

#text("Next, we need to localise the notion of a quotient ")#mi("{G/H}")#text(" of a global group ")#mi("{G}")#text(" by a normal subgroup ")#mi("{H}")#text(". Recall that in order for a subset ")#mi("{H}")#text(" og a global group ")#mi("{G}")#text(" to be a normal subgroup, it has to be symmetric, contain the identity, be closed under multiplication (thus ")#mi("{h_1 h_2 \\in H}")#text(" whenever ")#mi("{h_1,h_2 \\in H}")#text(", and closed under conjugation (thus ")#mi("{h^g := g^{-1} hg \\in H}")#text(" whenever ")#mi("{h \\in H}")#text(" and ")#mi("{g \\in G}")#text("). We now localise this concept as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 36 (Normal sublocal group)")]#text(" Let ")#mi("{G}")#text(" be a cancellative local group. A subset ")#mi("{H}")#text(" of ")#mi("{G}")#text(" is said to be ")#emph[#text("a normal sublocal group")]#text(" if there is an open neighbourhood ")#mi("{V}")#text(" of ")#mi("{H}")#text(" (called a ")#emph[#text("normalising neighbourhood")]#text(" of ")#mi("{H}")#text(") obeying the following axioms:")

#enum(start: 1, 
[#text("(Identity and inverse) ")#mi("{H}")#text(" is symmetric and contains the identity.")],
[#text("(Local closure) If ")#mi("{g, h \\in H}")#text(" and ")#mi("{gh}")#text(" is well-defined in ")#mi("{V}")#text(", then ")#mi("{gh \\in H}")#text(".")],
[#text("(Normality) If ")#mi("{g \\in V, h \\in H}")#text(" are such that ")#mi("{h^g = g^{-1} h g}")#text(" is well-defined in ")#mi("{V}")#text(", then ")#mi("{h^g \\in H}")#text(".")]
)

#text("(Strictly speaking, one should refer to the pair ")#mi("{(H,V)}")#text(" as the normal sublocal group, rather than just ")#mi("{H}")#text(", but by abuse of notation we shall omit the normalising neighbourhood ")#mi("{V}")#text(" when referring to the normal sublocal group.)")
]

#text("It is easy to see that if ")#mi("{H}")#text(" is a normal sublocal group of ")#mi("{G}")#text(", then ")#mi("{H}")#text(" is itself a cancellative local group, using the topology and group structure formed by restriction from ")#mi("{G}")#text(". (Note how the open neighbourhood ")#mi("{V}")#text(" is needed to ensure that the domain of the multiplication map in ")#mi("{H}")#text(" remains open.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 37")]#text(" In the global group ")#mi("{G = {\\bf R}^2 = ({\\bf R}^2,+)}")#text(", the open interval ")#mi("{H := (-1,1) \\times \\{0\\}}")#text(" is a normal sub-local subgroup if one takes (say) ")#mi("{V := (-1,1) \\times (-1,1)}")#text(" as the normalising neighbourhood.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 38")]#text(" Let ")#mi("{T: ({\\bf R}/{\\bf Z})^{\\bf Z} \\rightarrow ({\\bf R}/{\\bf Z})^{\\bf Z}}")#text(" be the shift map ")#mi("{T (a_n)_{n \\in {\\bf Z}} := (a_{n-1})_{n\\in {\\bf Z}}}")#text(", and let ")#mi("{{\\bf Z} \\ltimes_T ({\\bf R}/{\\bf Z})^{\\bf Z}}")#text(" be the semidirect product of ")#mi("{{\\bf Z}}")#text(" and ")#mi("{({\\bf R}/{\\bf Z})^{\\bf Z}}")#text(". Then if ")#mi("{H}")#text(" is any (global) subgroup of ")#mi("{({\\bf R}/{\\bf Z})^{\\bf Z}}")#text(", the set ")#mi("{\\{0\\} \\times H}")#text(" is a normal sub-local subgroup of ")#mi("{{\\bf Z} \\ltimes_T ({\\bf R}/{\\bf Z})^{\\bf Z}}")#text(" (with normalising neighbourhood ")#mi("{\\{0\\} \\times ({\\bf R}/{\\bf Z})^{\\bf Z}}")#text("). This is despite the fact that ")#mi("{H}")#text(" will, in general, not be normal in ")#mi("{{\\bf Z} \\ltimes_T ({\\bf R}/{\\bf Z})^{\\bf Z}}")#text(" in the classical (global) sense.")
]

#text("As observed by Goldbring, one can define the operation of quotienting a local group by a normal sub-local group, provided that one restricts to a sufficiently small neighbourhood of the origin:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39 (Quotient spaces)")]#text(" ")#metadata(none) <tao-d861ee362e3823440ae6>#text(" Let ")#mi("{G}")#text(" be a cancellative local group, and let ")#mi("{H}")#text(" be a normal sub-local group with normalising neighbourhood ")#mi("{V}")#text(". Let ")#mi("{W}")#text(" be a symmetric open neighbourhood of the identity such that ")#mi("{W^6}")#text(" is well-defined and contained in ")#mi("{V}")#text(". Show that there exists a cancellative local group ")#mi("{W/H}")#text(" and a surjective continuous homomorphism ")#mi("{\\phi: W \\rightarrow W/H}")#text(" such that, for any ")#mi("{g, h \\in W}")#text(", one has ")#mi("{\\phi(g)=\\phi(h)}")#text(" if and only if ")#mi("{gh^{-1} \\in H}")#text(", and for any ")#mi("{E \\subset W/H}")#text(", one has ")#mi("{E}")#text(" open if and only if ")#mi("{\\phi^{-1}(E)}")#text(" is open.")
]

#text("It is not difficult to show that the quotient ")#mi("{W/H}")#text(" defined by the above exercise is unique up to local isomorphism, so we will abuse notation and talk about “the” quotient space ")#mi("{W/H}")#text(" given by the above construction.")

#text("We can now state the local version of the Gleason-Yamabe theorem, first proven by Goldbring in his thesis, and later reproven ")#link("http://www.ams.org/mathscinet-getitem?mr=2743102")[#text("by Goldbring and van den Dries")]#text(" by a slightly different method:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 40 (Local Gleason-Yamabe theorem)")]#text(" ")#metadata(none) <tao-38823db53c3bd2b4c22d>#text(" Let ")#mi("{G}")#text(" be a locally compact local group. Then there exists an open symmetric neighbourhood ")#mi("{G^{\\prime}}")#text(" of the identity, and a compact global group ")#mi("{H}")#text(" in ")#mi("{G^{\\prime}}")#text(" that is normalised by ")#mi("{G^{\\prime}}")#text(", such that ")#mi("{G^{\\prime}/H}")#text(" is well-defined and isomorphic to a local Lie group.")
]

#text("The proofs of this theorem by Goldbring and Goldbring-van den Dries were phrased in the language of nonstandard analysis. However, it is possible to translate those arguments to standard analysis arguments, which closely follow the arguments given in previous sections and notes. (Actually, our arguments are not a verbatim translation of those in Goldbring and Goldbring-van den Dries, as we have made a few simplifications in which the role of Gleason metrics is much more strongly emphasised.) We briefly sketch the main points here.")

#text("As in the global case, the route to obtaining (local) Lie structure is via Gleason metrics. On a local group ")#mi("{G}")#text(", we define a ")#emph[#text("local Gleason metric")]#text(" to be a metric ")#mi("{d: U \\times U \\rightarrow {\\bf R}^+}")#text(" defined on some symmetric open neighbourhood ")#mi("{U}")#text(" of the identity with (say) ")#mi("{U^{100}}")#text(" well-defined (to avoid technical issues), which generates the topology of ")#mi("{U}")#text(", and which obeys the following version of the left-invariance, escape and commutator properties:")

#list(
[#text("(Left-invariance) If ")#mi("{g,h, k \\in U}")#text(" are such that ")#mi("{gh, gk \\in U}")#text(", then ")#mi("{d(h,k) = d(gh,gk)}")#text(".")],
[#text("(Escape property) If ")#mi("{g \\in U}")#text(" and ")#tao-math("{n \\left\\|g\\right\\| \\leq \\frac{1}{C}}", block: false)#text(", then ")#mi("{g,\\ldots,g^n}")#text(" are well-defined in ")#mi("{U}")#text(" and ")#tao-math("{\\left\\|g^n\\right\\| \\geq \\frac{1}{C} n \\left\\|g\\right\\|}", block: false)#text(".")],
[#text("(Commutator estimate) If ")#mi("{g, h \\in U}")#text(" are such that ")#tao-math("{\\left\\|g\\right\\|, \\left\\|h\\right\\| \\leq \\frac{1}{C}}", block: false)#text(", then ")#mi("{[g,h]}")#text(" is well-defined in ")#mi("{U}")#text(" and ")#link(<tao-0a83d217c9ff25c77929>)[#text("(1)")]#text(" holds.")]
)

#text("One can then verify (by localisation of the arguments in ")#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/")[#text("Notes 2")]#text(") that any locally compact local Lie group with a local Gleason metric is locally Lie (i.e. some neighbourhood of the identity is isomorphic to a local Lie group); see Exercise 10 from Notes 2. Next, one can define the notion of a weak local Gleason metric by dropping the commutator estimate, and one can verify an analogue of Theorem ")#link(<tao-4d4546383ac2aa8c12be>)[#text("14")]#text(", namely that any weak local Gleason metric is automatically a local Gleason metric, after possibly shrinking the neighbourhood ")#mi("{U}")#text(" and adjusting the constant ")#mi("{C}")#text(" as necessary. The proof of this statement is essentially the same as that in Theorem ")#link(<tao-4d4546383ac2aa8c12be>)[#text("14")]#text(" (which is already localised to small neighbourhoods of the identity), but uses a local Haar measure instead of a global Haar measure, and requires some preliminary shrinking of the neighbourhood ")#mi("{U}")#text(" to ensure that all group-theoretic operations (and convolutions) are well-defined. We omit the (rather tedious) details.")

#text("Now we define the concept of an NSS local group as a local group which has an open neighbourhood of the identity that contains no non-trivial global subgroups. The proof of Theorem ")#link(<tao-b3140286ac71ad2acf69>)[#text("22")]#text(" is already localised to small neighbourhoods of the identity, and it is possible (after being sufficiently careful with the notation) to translate that argument to the local setting, and conclude that any NSS local group admits a weak Gleason metric on some open neighbourhood of the identity, and is hence locally Lie. (A typical example of being “sufficiently careful with the notation”: to define the escape norm ")#link(<tao-4cd0e21a9a0795a14ec9>)[#text("(11)")]#text(", one adopts the convention that a statement such as ")#mi("{g,\\ldots,g^n \\in U}")#text(" is automatically false if ")#mi("{g,\\ldots,g^n}")#text(" are not all well-defined. The induction hypothesis ")#link(<tao-cb5ae32cbd84a47c77ab>)[#text("(13)")]#text(" will play a key role in ensuring that all expressions involved are well-defined and localised to a suitably small neighbourhood of the identity.) Again, we omit the details.")

#text("The next step is to obtain a local version of Proposition ")#link(<tao-e0f953ec8ff68d020aa7>)[#text("27")]#text(". Here we encounter a slight difficulty because in a general local group ")#mi("{G}")#text(", we do not have a good notion of the group ")#mi("{\\langle A \\rangle}")#text(" generated by a set ")#mi("{A}")#text(" of generators in ")#mi("{G}")#text(". As such, the subgroup trapping property does not automatically translate to the local group setting as defined in Definition ")#link(<tao-7b885bcc8763d78e786e>)[#text("41")]#text(". However, this difficulty can be easily avoided by rewording the definition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 41 (Subgroup trapping)")]#text(" ")#text(" A local group has the ")#emph[#text("subgroup trapping property")]#text(" if, for every open neighbourhood ")#mi("{U}")#text(" of the identity, there exists another open neighbourhood ")#mi("{V}")#text(" of the identity such that ")#mi("{Q[V]}")#text(" is contained in a global subgroup ")#mi("{H}")#text(" that is in turn contained in ")#mi("{U}")#text(". (Here, ")#mi("{Q[V]}")#text(" is, as before, the union of all the global subgroups contained in ")#mi("{V}")#text(".)")
]

#text("Because ")#mi("{Q[V]}")#text(" is now contained in a global group ")#mi("{H}")#text(", the group ")#mi("{\\langle Q[V] \\rangle}")#text(" generated by ")#mi("{H}")#text(" is well-defined. As ")#mi("{H}")#text(" is in the open neighbourhood ")#mi("{U}")#text(", one can then also form the closure ")#mi("{\\overline{\\langle Q[V] \\rangle}}")#text("; if we choose ")#mi("{U}")#text(" small enough to be precompact, then this is a compact global group (and thus describable by the Gleason-Yamabe theorem for such groups, Theorem ")#link(<tao-5e180a6b364155347a53>)[#text("4")]#text("). Because of this, it is possible to adapt Proposition ")#link(<tao-e0f953ec8ff68d020aa7>)[#text("27")]#text(" without much difficulty to the local setting to conclude that given any locally compact local group ")#mi("{G}")#text(" with the subgroup trapping property, there exists an open symmetric neighbourhood ")#mi("{G^{\\prime}}")#text(" of the identity, and a compact global group ")#mi("{H}")#text(" in ")#mi("{G^{\\prime}}")#text(" that is normalised by ")#mi("{G^{\\prime}}")#text(", such that ")#mi("{G^{\\prime}/H}")#text(" is well-defined and NSS (and thus locally isomorphic to a local Lie group).")

#text("Finally, to finish the proof of Theorem ")#link(<tao-38823db53c3bd2b4c22d>)[#text("40")]#text(", one has to establish the analogue of Proposition ")#link(<tao-8564388283117bb31df2>)[#text("28")]#text(", namely that one has to show that every locally compact metrisable local group has the subgroup trapping property. (It is not difficult to adapt Exercise ")#link(<tao-549fedc167d28745132a>)[#text("12")]#text(" to the local group setting to reduce to the metrisable case.) The first step is to prove the local group analogue of Proposition ")#link(<tao-d27d1a09d9f1be229304>)[#text("29")]#text(" (again adopting the obvious convention that a statement such as ")#mi("{Q^n \\subset U}")#text(" is only considered true if ")#mi("{Q^n}")#text(" is well-defined, and adding the additional hypothesis that ")#mi("{U}")#text(" is sufficiently small in order to ensure that all manipulations are justified). This can be done by a routine modification of the proof. But then one can modify the rest of the argument in Proposition ")#link(<tao-8564388283117bb31df2>)[#text("28")]#text(" to hold in the local setting as well (note, as in the proof of Proposition ")#link(<tao-e0f953ec8ff68d020aa7>)[#text("27")]#text(", that the compact set ")#mi("{H}")#text(" generated in the course of this argument remains a ")#emph[#text("global")]#text(" group rather than a local one, and so one can again use Theorem ")#link(<tao-5e180a6b364155347a53>)[#text("4")]#text(" without difficulty). Again, we omit the details.")

#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/003d80c657714e282f5d6d586d402b9db82e83b8c74f138425e3b6d24f7fa0ea-836a55d2a61da723178c54a471f82f99a312174f8942cb1ed7a69bb05f810606.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mateusz Kwaśnicki")]], [#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/#comment-89123")[#strong[#text("Mateusz Kwaśnicki")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2011")])]

#text("It seems that Theorem 1 is missing “contained in U” phrase.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Escape property of the Gleason metric and sub-riemannian distances again | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/#comment-89359")[#strong[#text("Escape property of the Gleason metric and sub-riemannian distances again | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2011")])]

#text("[…] See the recent post 254A, Notes 4: Bulding metrics on groups, and the Gleason-Yamabe theorem by Terence Tao, for understanding in detail the role of the escape property in the proof of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gleason metric and CC distance | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/#comment-89360")[#strong[#text("Gleason metric and CC distance | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2011")])]

#text("[…] See the recent post 254A, Notes 4: Bulding metrics on groups, and the Gleason-Yamabe theorem by Terence Tao, for details of the role of the Gleason metric in the proof of the Hilbert 5th […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 5: The structure of locally compact groups, and Hilbert’s fifth problem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/#comment-90825")[#strong[#text("254A, Notes 5: The structure of locally compact groups, and Hilbert’s fifth problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2011")])]

#text("[…] thus Lie as well. Thus the assertion that all locally compact NSS groups are Lie (Theorem 10 from Notes 4) is a special case of the Gleason-Yamabe […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The structure of approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/#comment-96267")[#strong[#text("The structure of approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2011")])]

#text("[…] , slightly). (This result arose from the solution to Hilbert’s fifth problem, as discussed here. For our extension to local groups, we use a recent local version of the Gleason-Yamabe theorem, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 7: Models of ultra approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/#comment-97539")[#strong[#text("254A, Notes 7: Models of ultra approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2011")])]

#text("[…] be usefully modeled by locally compact groups (and hence, through the Gleason-Yamabe theorem from previous notes, by Lie groups also). As per the Heine-Borel theorem, the local compactness will come from a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The microstructure of approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/#comment-101199")[#strong[#text("254A, Notes 8: The microstructure of approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2011")])]

#text("[…] difficulty in the theory surrounding Hilbert’s fifth problem that was discussed in previous notes. A key tool in being able to resolve such structure was to build left-invariant metrics (or […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Hayes")]], [#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/#comment-101230")[#strong[#text("Ben Hayes")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2011")])]

#text("In Exercise 12, for comparability I think we need to assume that $g$ is sufficiently small as well. For example, one could consider $GL(n,\\RR)$ and then any escape norm is bounded by 1, whereas there is no bound for the operator norm of an invertible operator.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hans")]], [#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/#comment-124628")[#strong[#text("Hans")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2012")])]

#text("If I could just ask a silly question about beginning of Prop. 15:")

#text("Why can we choose V small enough, such that ")#mi("(V^{U^4})^M \\subset U")#text("? The fact that we don’t know a lot about ")#mi("U^4")#text(" worries me.(especially when I think about xy and ")#mi("x \\in [0,\\infty)")#text(")? Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/#comment-124637")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2012")])]

#text("Oops, I forgot to add the hypothesis that U (and hence ")#mi("U^4")#text(") was precompact, in which case one can make ")#mi("V^{U^4}")#text(" as small as desired by a compactness argument.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hans")]], [#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/#comment-124638")[#strong[#text("Hans")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2012")])]

#text("Yes, that’s what I secretly suspected. Thank you for the prompt reply!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Three problems and a disclaimer | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/#comment-138003")[#strong[#text("Three problems and a disclaimer | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2012")])]

#text("[…] normed group with dilations. This is true because one parameter sub-groups and Gleason metrics are used to solve the problem. The BCH formula solves then another problem: from the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/#comment-471279")[#strong[#text("Building metrics on groups – Mémoires")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2016")]

#text("[…] ")#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-ya&#8230")[#text("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-ya&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4774596e45dca160be5aa2a18445143dc45ff41dff7be1904c54f961d8c53d1f-a3e746399be0fcfd579a9246b2ade6fb3b503db955e51955e3e1089934b1b44b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arturo Rodríguez Fanlo")]], [#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/#comment-514707")[#strong[#text("Arturo Rodríguez Fanlo")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2019")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I have a question about the proof of theorem 8. There, to prove {\\|g^y\\|\\ll\\|g\\|}, you say")

#text("“We can achieve this by the escape property (5). Let {n} be a natural number such that {n \\|g\\| \\leq \\epsilon}, then {\\|g^n\\| \\leq \\epsilon} and so {g^n \\in B(0,\\epsilon)}. Conjugating by {y}, this implies that {(g^y)^n \\in B(0,5\\epsilon)}, and so by (5), we have {\\|g^y\\| \\ll \\frac{1}{n}} (if {\\epsilon} is small enough), and the claim follows.”")

#text("For me, it seems that you are using the escape property under the hypothesis that {\\|g^n\\|} is small. However, the escape property is given when {n\\|g\\|} is small.")

#text("Similarly, in Notes 2, proving that the one-parameter subgroups are Lipschitz, it also seems that you used the escape property when {\\|\\phi(\\frac{t}{n})^n\\|} is small, while it should be used when {n\\|\\phi(\\frac{t}{n})\\|} is small.")

#text("Of course, when {n\\|g\\|} is small, we have {\\|g^n\\|\\leq n\\|g\\|}, concluding that {\\|g^n\\|} is small. However, I do not see a way to conclude that {n\\|g\\|} is small assuming that {\\|g^n\\|} is small. It is particularly annoying, since the escape property is actually giving that control.")

#text("In other words, my problem could be rewritten as follows:")#linebreak()#text(" Why is not possible to have a sequence {(g_k)_{k\\in {\\bf N}} } and a constant {C} such that {\\|g^n_k\\|\\rightarrow 0} while {k\\rightarrow \\infty} but {n\\|g_k\\|>C} for each {k\\in{\\bf N}}?")

#text("Best wishes,")#linebreak()#text(" Arturo")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/#comment-514708")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2019")])]

#text("I guess strictly speaking one should not just use the fact that ")#mi("(g^y)^n \\in B(0,5\\epsilon)")#text(", but rather that ")#mi("(g^y)^m \\in B(0,5\\epsilon)")#text(" for all ")#mi("1 \\leq m \\leq n")#text(". This is then incompatible with the escape property if ")#tao-math("\\frac{1}{C(m+1)} \\leq \\left\\|g^y\\right\\| \\leq \\frac{1}{Cm}", block: false)#text(" for any ")#mi("1 \\leq m \\leq n")#text(", and since ")#tao-math("\\left\\|g^y\\right\\| \\leq \\frac{1}{C}", block: false)#text(", this only leaves the possibility that ")#tao-math("\\left\\|g^y\\right\\| \\ll \\frac{1}{n}", block: false)#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4774596e45dca160be5aa2a18445143dc45ff41dff7be1904c54f961d8c53d1f-a3e746399be0fcfd579a9246b2ade6fb3b503db955e51955e3e1089934b1b44b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arturo Rodríguez Fanlo")]], [#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/#comment-515206")[#strong[#text("Arturo Rodríguez Fanlo")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2019")])]

#text("Dear Prof. Tao,")

#text("Thank you very much. That was really useful.")

#text("Please, would you mind to help me again with my next questions?")

#text("First of all, in proposition 11, with the dilatation given by ")#mi("\\varepsilon")#text(", to prove that ")#mi("\\phi")#text(" is well defined we need to show that ")#mi("\\eta")#text(" and ")#mi("\\psi")#text(" are ")#mi("L^2")#text(". Clearly, ")#mi("\\eta")#text(" is simple so it is in ")#mi("L^2")#text(". However, I do not see how to argue in the case of ")#mi("\\psi")#text(". Furthermore, I expect that it is continuous, but I do not know how to show that.")

#text("Secondly, in the proof of proposition 14, I do not understand the following sentence:")

#text("“Since ")#mi("Q[V_i]^{n_i+1} \\not \\subset U")#text(", we see that ")#mi("Q[V_i]^{n_i+1}")#text(" does not lie in the ")#mi("\\epsilon")#text("-neighbourhood ")#mi("\\pi^{-1}(B)_\\epsilon")#text(" of ")#mi("\\pi^{-1}(B)")#text(" if ")#mi("\\epsilon")#text(" is small enough, where ")#mi("\\pi: H \\rightarrow H/N")#text(" is the projection map.”")

#text("Why we get that? I do not see trivially a contradiction assuming that ")#mi("Q[V_i]^{n_i+1}")#text(" is contained in the closure of ")#mi("\\pi^{-1}(B)")#text(".")

#text("Also, in proposition 14, what about ")#mi("U_1")#text("? You express that it will be chosen later, but I do not see how and where we need to choose ")#mi("U_1")#text(".")

#text("Finally, if it is possible, I would sincerely appreciate any hint to show the lower bound of point (vii) of exercise 9 of notes 1.")

#text("Again, thank you very much.")

#text("Best wishes,")#linebreak()#text(" Arturo")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/#comment-515242")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2019")])]

#mi("\\psi")#text(" is bounded by 1, supported in the precompact set ")#mi("U_0^2")#text(", and is Borel measurable, hence in ")#mi("L^2")#text(".")

#text("“")#mi("\\varepsilon")#text(" small enough” should really be “")#mi("U_1, B, \\varepsilon")#text(" small enough”, to ensure that ")#mi("\\pi^{-1}(B)_\\varepsilon")#text(" lies in ")#mi("U")#text(".")

#text("(Regarding the Notes 1 exercise, please post a detailed question in that post regarding the exercise, stating what you have tried and where precisely you are stuck.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/#comment-515667")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2019")])]

#text("Dear Prof. Tao,")

#text("Thank you very much for your attention. That was really useful.")

#text("Best wishes,")#linebreak()#text(" Arturo")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28df25a01e95f335c20a827f206d464be3865d5b1cd1449ad4c577a31280360c-3418f556d4939977a5a9b4fe60aba1985a8c381b0af50d5f125276e78567d46f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kindbubble")]], [#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/#comment-693756")[#strong[#text("kindbubble")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2026")])]

#text("Dear professor Tao,")

#text("I have noticed that the Gleason-Yamabe theorem implies that locally compact Hausdorff topological groups have discrete transitive topological group action with stabilizer which is a pro-object in the category of Lie-groups")

#text("Since not all pro-objects in the category of Lie-groups are locally-compact Hausdorff, one might try to generalize Haar integral to them by first considering the continuous functions out of ")#mi("\\Pi_{n \\in \\mathbb{N}} \\mathbb{R}")#text(" which have summable fibres ")#mi("\\Pi_{n \\in \\mathbb{N}} (\\mathbb{Z} + c_i)")#text(" for each ")#mi("c_i \\in \\Pi_{n \\in \\mathbb{N}} \\mathbb{R}")#text(". These sum-forward to continuous functions on ")#mi("\\Pi_{n \\in \\mathbb{N}} S^1")#text(", which has a Haar integral.")
]
