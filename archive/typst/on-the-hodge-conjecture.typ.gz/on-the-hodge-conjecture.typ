// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T11:18:47.550993+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On the Hodge conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On the Hodge conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/")[#text("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://www.math.ucla.edu/~totaro/")[#text("Burt Totaro")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("These are strange times for mathematicians. It now seems possible that AI companies will burn through vast resources in order to prove some new fact about the ")#link("https://en.wikipedia.org/wiki/Hodge_conjecture")[#text("Hodge conjecture")]#text(". I’d like to discuss the current status of the Hodge conjecture, in order to think about the value to the mathematical community of exploring such hard problems. Thanks to Terry Tao for suggesting this guest post.")

#text("The Hodge conjecture crystallizes a big mystery: the relation between topology and algebraic geometry, or (what amounts to the same) between real and complex geometry. In short, real submanifolds are flexible, whereas complex submanifolds are quite rigid, and it is a challenge to relate the two. The setting is a “smooth complex projective variety” ")#mi("{X}")#text(", a complex manifold defined by algebraic equations. We want to understand the possible shapes of complex algebraic subspaces of ")#mi("{X}")#text(". (By a famous result of ")#link("https://zbmath.org/3063550")[#text("Wei-Liang Chow (1949)")]#text(", every complex analytic submanifold of ")#mi("{X}")#text(" is in fact algebraic.) One could ask whether every real submanifold of ")#mi("{X}")#text(" can be moved continuously to a complex submanifold. That is far too optimistic. Still, to a first approximation, the Hodge conjecture predicts which real submanifolds can be moved continuously to a complex submanifold, in terms of whether certain integrals are zero. (More precisely: every Hodge class in the rational cohomology of ")#mi("{X}")#text(" should be the class of an algebraic cycle.) The conjecture goes back to ")#link("https://zbmath.org/3076397")[#text("William Hodge (1950)")]#text(".")

#metadata(none) <tao-1e893fbeb7573a00ad08>

#text("Now suppose in some counterfactual world that the day after the conjecture was made some inhuman oracle told us that the answer was “yes” and the conjecture was considered “solved.” We can see, by examining our real world, the vast body of mathematical knowledge that would have been lost. In our world, what we want from a great conjecture is a challenge that inspires all kinds of other discoveries, even if the original question remains open. The Hodge conjecture has been that kind of conjecture for geometers.")

#text("A key piece of evidence for the Hodge conjecture is the “")#link("https://en.wikipedia.org/wiki/Lefschetz_theorem_on_(1,1)-classes")[#text("Lefschetz ")#mi("{(1,1)}")#text("-theorem")]#text("“, which says that the Hodge conjecture is true for algebraic cycles of codimension 1 (that is, of complex dimension ")#mi("{n-1}")#text(", if ")#mi("{X}")#text(" has complex dimension ")#mi("{n}")#text("), and also for cycles of dimension 1. ")#link("https://zbmath.org/2597379")[#text("Solomon Lefschetz’s work")]#text(" was quite early (around 1924), well before the Hodge conjecture was stated in general. Interestingly, some of the most important proofs by both Lefschetz and Hodge have gaps, from our current perspective. They had tremendous insight, but the full justification of their results required hard analysis by many mathematicians, notably Kunihiko Kodaira (around 1950).")

#text("By some measures, one could say that progress on the Hodge conjecture has been limited. In view of Lefschetz’s results, the first open case is for codimension-2 cycles on a variety of complex dimension 4, and that case (for arbitrary varieties of dimension 4) still seems far out of reach. But the Hodge conjecture has been enormously successful for inspiring new mathematical theories, such as Phillip Griffiths’s “")#link("https://en.wikipedia.org/wiki/Variation_of_Hodge_structure")[#text("Variations of Hodge structure")]#text("” (starting in the 1960s) and Pierre Deligne’s “")#link("https://zbmath.org/3853242")[#text("absolute Hodge cycles")]#text("“. Broadly speaking, the Hodge conjecture suggests that the structure of algebraic cycles should be controlled by Hodge theory, in other words by integrals of algebraic functions. This hope has led to vast numbers of proved insights about the structure of algebraic cycles. (For example, ")#link("https://zbmath.org/3341218")[#text("Griffiths disproved")]#text(" Grothendieck’s conjecture that algebraic and homological equivalence were the same, which was a surprise; but he used Hodge theory in order to do it.) In recent decades, ")#link("https://en.wikipedia.org/wiki/Claire_Voisin")[#text("Claire Voisin")]#text(" has been a leader in using Hodge theory in new ways to get information about algebraic cycles.")

#text("An exciting recent development is ")#link("https://arxiv.org/abs/2502.03415")[#text("Eyal Markman’s 2025 proof")]#text(" of the Hodge conjecture for abelian varieties of dimension 4 and 5. (")#link("https://en.wikipedia.org/wiki/Abelian_variety")[#text("Abelian varieties")]#text(", the tori with a complex algebraic structure, are very special compared to all algebraic varieties; but they are a particularly important class in many ways, for example in number theory.) This is a monumental piece of work that builds on many earlier developments. ")#link("https://zbmath.org/3659552")[#text("André Weil (1977)")]#text(" identified a class of abelian varieties, those of Weil type, for which there are “unexpected” Hodge classes that do not appear on most other abelian varieties. In low dimensions such as 4, ")#link("https://zbmath.org/784714")[#text("Ben Moonen and Yuri Zarhin (1995)")]#text(" showed that the Hodge conjecture for all abelian varieties would follow from the special case of abelian varieties of Weil type. ")#link("https://zbmath.org/3401070")[#text("Spencer Bloch (1972)")]#text(", extended by ")#link("https://zbmath.org/1960065")[#text("Ragnar-Olaf Buchweitz and Hubert Flenner (2003)")]#text(", defined a property called “semi-regularity” which, when it holds, allows proving the Hodge conjecture for a continuous family of varieties when it holds for one variety in the family.")

#text("For a long time, however, semi-regularity seemed far too strong a condition ever to apply to hard cases of the Hodge conjecture. Markman found, with great ingenuity, how to construct enough examples of semi-regular sheaves to prove the Hodge conjecture for abelian varieties in dimensions 4 and 5. His ideas use several big theories that have been developed in recent decades, notably about derived equivalences between algebraic varieties and about ")#link("https://en.wikipedia.org/wiki/Hyperk%C3%A4hler_manifold")[#text("hyperkähler manifolds")]#text(". In the end, Markman actually needed an extension of Buchweitz–Flenner’s semi-regularity theorem to “twisted sheaves”, which was supplied by ")#link("https://zbmath.org/7961535")[#text("Jonathan Pridham (2024)")]#text(".")

#text("At this point, I am confident that with enough effort, it will be possible to push these ideas further. As we have seen, AI companies are willing to mobilize resources on an incomprehensible scale to attack problems that attract their interest. We don’t know how much insight may come from any given AI-generated proof. But there is reason to worry about the commercial pressure on AI companies to claim advances at high speed and the knock-on effect this has on mathematicians. The power of mathematical ideas comes from a continual negotiation among people. What we care about are not so much isolated facts, but rather the ideas and inspiration that the search leads to.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (33)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694553")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Excellent initiative!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694631")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("But what if the conjecture is false, and AI proves it? Wouldn’t that redirect the huge efforts made to prove that it’s true away from a dead end towards other questions or areas where progress is possible?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694727")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("tell me you know nothing about mathematical research without telling me you know nothing about mathematical research")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-695046")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("This is off-topic, but it’s truly saddening to see so many likes given to such a disparaging reply that contributes nothing but the driving away of a good-faith question from an interested commenter. One shouldn’t have to hold specialized knowledge in mathematics (rather, a solid sense of what’s right and wrong developed as they traverse through life) to see how one that contains a personal attack, all in lowercase without any attention paid to even grammar, is at the very least misplaced. Hell, there isn’t even any further elaboration; I’m just imaging some sophomore feeling particularly smug in passing and deciding to ridicule a stranger on the internet.")

#text("Thus is the result of letting people contribute to something anonymously, I suppose. No virtue, no responsibility; while you’re able to receive more diversity in opinion from people who’d otherwise be restricted from the annoyance of creating an account, you have to bear contributions like this, ones that do nothing but discourage and demean. Maybe I shouldn’t be so worked up about a single reply, but how can I help it? It’s maddening! I’m just imagining the awful scenario of a child who’s interested in mathematics and visiting the blog of a person whom they think so highly of, commenting on one of their posts just to be shooed away, probably for a long time. Yes, that does happen; yes, it’s real; and so are its effects.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-695260")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("Thank you for existing.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b3dc0994dcd71cf808c59d082568cdb9bebc4d474bb51f5af75efff7294b7f8-9084dc80fe5efd328cf333e202e2f0c025799de1146d72ab8c850b096216c114.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Burt Totaro")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694733")[#strong[#text("Burt Totaro")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Yes, that’s a fair question. You probably picked up from my tone that I believe the Hodge conjecture is true. If the conjecture turns out to be false, that makes it even more impressive how much knowledge the human process of doing mathematics can build from an inspiring question. Pursuing the Hodge conjecture would not have been a dead end, even if it turns out to be false.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694816")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I might add that the beautiful counterexamples to the ")#strong[#text("integral")]#text(" Hodge conjecture never stalled, discouraged, or even slowed down the community. If anything, they further our collective intuition that algebraic cycles are deeply interesting objects worth understanding.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694843")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("This is an honest question, how “huge” are the efforts for each of the millennium prize problems? To my knowledge, no one is seriously working on P=NP, but I’m unclear of the situation in other fields.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad4c3787242d6ad347603b086c9199bde1ce5d44e9675c4e5b19425957052ce2-db07be4e620a168e46cf17ccc7dae887491bf310a23bf33f361f64f756be6ccd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tchow8")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694886")[#strong[#text("tchow8")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("P = NP is just one of a huge family of complexity class separation problems. There are a lot of people working on such problems, so it depends on whether you count them as “working on P = NP.” They’re not making a direct frontal attack on P = NP, because it doesn’t make that much sense to work directly on something like that when you don’t even have any idea how to solve much simpler versions of the problem. But if you work on a much easier separation problem, with the idea of making some contribution that may eventually lead to the solution of P = NP, does that count as “working on P = NP”? I think the situation is similar with many of the other Millennium Prize problems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694891")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Plenty of people working on the Hodge conjecture and Navier-Stokes; it’s why those conjectures are the first ones to fall to large language models because they can just piggyback on what humans have already done (a lot of times without proper citations to the humans).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694639")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("The amount of money and energy OpenAI is wasting on proving conjectures irrelevant to the rest of society, like Navier-Stokes and the Hodge conjecture, would be much better used if instead OpenAI spent it on improving the average American’s mathematics education.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694725")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("OpenAI has no interest in education, ethics, humanity or science. Their ultimate goal and that of other similar companies, is profit maximization. By doing this, they are implicitly suggesting that they “don’t need intellectual work”, but in reality, they want to minimize it as much as possible and replace it with AGI. One of the biggest costs is labor and I believe that has always been the goal since the first industrial revolution, but now with intellectual work, something reaching this level should have involved greater government intervention. If they have the government on their side, cryptocurrencies, propaganda and everything else, they have the ideal scenario. These big tech companies don’t care about mathematics, what matters to them is profit maximization, the exchange of variable capital for fixed capital. It seems that much progress has already been made and I don’t see a problem with mathematical research not needing to be in this race, going slower. Things are naturally becoming more difficult, but in general, humanity can’t keep up with this race, and I’m honestly tired of seeing things about AI. For me, LLM was one of the worst things ever done.")

#text("What they did to mathematics education was make it much worse. Look at the PISA 2025 results, most developed countries had some of the worst results and much of this is due to the use of mobile phones and AI. Learning takes time and effort, AI will never replace a textbook written by experienced teachers. The more people dependent on their platforms, the greater the competitiveness and the lower the wages, the better in the end. They want more and more power and to maximize their profits. Only naive people would think anything positive about these companies. Sociology has been showing us this for a long time.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b3dc0994dcd71cf808c59d082568cdb9bebc4d474bb51f5af75efff7294b7f8-9084dc80fe5efd328cf333e202e2f0c025799de1146d72ab8c850b096216c114.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Burt Totaro")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694713")[#strong[#text("Burt Totaro")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I agree that what I wrote at first was too negative about the value of knowing answers to questions like the Hodge conjecture. Certainly we do want to know answers, among other things. In fact, I accidentally posted a version of my note that I hadn’t finished editing, although that should be fixed soon. Here is what my final paragraph should say: “At this point, I am confident that with enough effort, it will be possible to push these ideas further. As we have seen, AI companies are willing to mobilize resources on an incomprehensible scale to attack problems that attract their interest. We don’t know how much insight may come from any given AI-generated proof. But there is reason to worry about the commercial pressure on AI companies to claim advances at high speed and the knock-on effect this has on mathematicians. The power of mathematical ideas comes from a continual negotiation among people. What we care about are not so much isolated facts, but rather the ideas and inspiration that the search leads to.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694732")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Dear Burt,")

#text("Thank you for your write up. Indeed it seems that LLM companies will prove some cases of the Hodge conjecture for abelian varieties by brute forcing ideas of Markman.")

#text("As you have said, it seems there will be very little to nothing to be gained by us from such a proof. On the other hand, we do have a lot to lose. One can lament the number of insights that would come to us by studying the conjecture while it is still not solved; one could hope, for example, that a future mathematician would come up with brilliant new ideas to circumvent ‘semi-regularity’ checks.")

#text("In fact I would go so far as to say that the Hodge conjecture has more value as an unsolved problem than as a solved one.")

#text("Kind regards,")

#text("A concerned member of the AG community")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694855")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("“the Hodge conjecture has more value as an unsolved problem than as a solved one.”")

#text("That’s a beautiful way to put it, thanks for sharing")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694884")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I’d appreciate your opinion on a question. Why could mathematicians not continue to study the landscape around the conjecture even after the specific question (e.g., “Hodge is true/false”) is resolved? Is your concern that the problem is motivation for exploring the domain and so knowing an isolated fact (“conjecture is true/false”) will actually discourage further study of that whole region of math? If so, I hope that demotivation effect can be overcome, since that seems like it could plausibly be common in the future.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-695019")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Dear Anonymous,")

#text("I think I want to respond to your question with a poetic analogy. I apologise if this is not a satisfactory response to you. ")#linebreak()#text("Mathematical problems are like lighthouses in the mathematical landscape. When a mathematician goes to solve a problem, they chart a path to that landscape. Along that path one may imagine them planting trees as they travel through it.")

#text("Those trees often grow up to bear fruit which sustains the next generation of mathematicians in their explorations of the landscape.")

#text("Of recent experience (the Jacobian conjecture and complex structures on S^6 come to mind), when an LLM company goes to solve a problem, one can imagine them bulldozing or even nuking the path to the lighthouse with no trees planted along the way. It is not so clear, at least to me, if the ground is now fertile enough to sustain new trees in the near future.")

#text("Best wishes, ")#linebreak()#text("A concerned member of the AG community")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694893")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Unfortunately mathematics academia strongly values solving these problems for stuff like tenure. Until that changes, you will have these perverse incentives in mathematics for people to just fire up a large language model at a conjecture and solve it, so that they can put it on their CV to gain an advantage over their peers when it comes time for job hunting for permanent positions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-695178")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("“the Hodge conjecture has more value as an unsolved problem than as a solved one”")

#text("Suppose your stochastic parrot is lucky today and gives you the solution to the conjecture. Would you delete it and pretend it never happened, for the good of math community and humanity?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694748")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Dear Dr Torato,")

#text("What mathematical prerequisites are needed to understand the Hodge conjecture?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-695102")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("The pre-reqs are algebraic geometry and knowledge of smooth and complex manifolds. There are books dedicated to these subjects you can find. To understand those subjects requires a good foundation in undergraduate (and graduate) mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f727f942dd6fd9c5debb849c63a2439f12886de1b430a1c4a7aed8c17ce94393-8af46d89311a7d7fce476f2acd9cb563dca03f68e3e33ff2e7aacc30c75fbefa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MathGuy521")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694765")[#strong[#text("MathGuy521")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("When AlphaGo beat Lee Sedol at Go, the average Elo of human players in the subsequent months increased a lot as they analyzed the novel strategies the AI had used.")

#text("The same thing happened with chess after Deep Blue and StockFish, and the same will happen with mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694813")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("It is important to change and reevaluate the awards system, so that we may, as mathematical community, define, emphasize and award values. This may stop AI companies from going for the kill. Killing the challenge is like killing the human spirit. We may need to legislate to hinder this.")

#text("-Savitha Muthanna")

#text("(Case Western Reserve, Mathematics).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0407444868fc42987e0e767c3fa8c7571cd73af435533bcece7a36bd594b0514-2ae27efe97fcf1ece7ea67e36afa94eee62825664716dc4ee7cf030a881d77c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shannon7774")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694835")[#strong[#text("shannon7774")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Isn’t there still hope that even for problems such as the forced Navier-Stokes singularity, that energetic mathematicians can mine some insight from the proof over time?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44074828fd903c718f3c4b97c56f09dfb7c17e1274ef2e8ae27aa523a419fbc9-2139911a82943d1e762c520d75b0b53741aaf0b0b5f5660ee451f724f1353cb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MHealy1975")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694845")[#strong[#text("MHealy1975")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("This is an important and interesting discussion, kudos to Burt. One worry I have is that, although there does seem to be something scientifically speaking missing from a scenario in which frontier LLMs establish new abelian cases of the Hodge conjecture, we need an account of that loss which does not overgeneralize.")

#text("The thought behind the criticism seems to be that what matters in science isn’t merely the acquisition of isolated truths, but such things as the ideas, understanding, and inspiration generated by the search. Fair enough. But if the relevant principle is that we should forgo an easily attainable result in favour of a more difficult route in cases where the struggle itself would bring further benefits via the overcoming of obstacles, then the principle looks much too broad. It would seem to tell in favour of walking a mile to school rather than taking the car because the walk builds character, etc., or using an axe rather than a chainsaw because manual labour has its own virtues. So the criticism needs something like a limiting principle, viz., what is distinctive (and doesn’t carry over to the other reductio cases) about the human search for a proof that makes it scientifically valuable in a way that is not replicated when an LLM supplies the proof, and which is some property not shared also by the other cases where the value of engaging with obstacles doesn’t override the value of securing the end.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-695053")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("“walking a mile to school rather than taking the car because the walk builds character, etc., or using an axe rather than a chainsaw because manual labour has its own virtues”")

#text("Maybe we ")#emph[#text("have")]#text(" lost something by getting rid of manual labour in these cases. One could argue that we have also gained something far greater than what we lost. But this is certainly subjective (“value” is subjective); for the virtues of walking a thousand miles instead of using modern transport, see all the work by Craig Mod.")

#text("So the questions are: what do mathematicians lose")#emph[#text(", ")]#text("and what do mathematicians gain from AI solving a problem quickly? The experience of doing mathematics is special, and it doesn’t make sense to do this loss-gain calculus without actually being invested in the process i.e. without being a mathematician. I think we would lose a lot.")

#text("Sincerely")

#text("a tcs postdoc.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694848")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I’m confused by the discourse. First, I don’t see how to core argument distinguished AI advances and human ones–if a mathematician proves hodge and then leaves math, do they give a negative contribution to math?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694892")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("They give a positive contribution to math. No human mathematician could brute force new cases of Hodge. They would have to develop a lot of new theory and techniques (cf. the case of Markman’s recent advances).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-694924")[#strong[#text("On the Hodge conjecture | Geometry Bulletin Board")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")]

#text("[…] I’ve written a guest post for Terry Tao’s blog in light of recent rumors and developments: ")#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/")[#text("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-695429")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("I like the term “oracle” in this post.")

#text("Another term could be the Angel of Infinity. For example, you ask the AoI about the Collatz conjecture, and it simply looks at all the cases and tells you whether the conjecture holds for every integer or not. But it does not tell you anything about the patterns or why the statement is true or false.")

#text("It will be interesting to see what problems are resistant to AI in the coming years, if any, and how that compares to what human mathematicians are able to eventually accomplish.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-695619")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("If AI just claimed it can solve a problem, without anyone understanding the main ideas of the proof, then the proof itself is of no value to the community anyway. We had “proofs” like that before the AI age.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-695748")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("What would you say to an undergraduate student who was really excited about pursuing a PhD but is now disheartened by everything that’s going on?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b3dc0994dcd71cf808c59d082568cdb9bebc4d474bb51f5af75efff7294b7f8-9084dc80fe5efd328cf333e202e2f0c025799de1146d72ab8c850b096216c114.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Burt Totaro")]], [#link("https://terrytao.wordpress.com/2026/09/11/on-the-hodge-conjecture/#comment-697654")[#strong[#text("Burt Totaro")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("I would encourage an undergraduate who was excited about pursuing a Ph.D. to continue with that, even though mathematics has experienced a shock. This is a time to stand up for human values. It will always be worthwhile for people to learn and to communicate their understanding to others. Whether you stay in an academic career or not, showing that you can learn something in real depth will be important.")
]
]
