// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/02/23/uchiyamas-constructive-proof-of-the-fefferman-stein-decomposition/
// Converted to Typst by tao2typ: "2026-10-14T16:34:50.625745+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Uchiyama’s constructive proof of the Fefferman-Stein decomposition", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Uchiyama’s constructive proof of the Fefferman-Stein decomposition")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 February 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/02/23/uchiyamas-constructive-proof-of-the-fefferman-stein-decomposition/")[#text("https://terrytao.wordpress.com/2007/02/23/uchiyamas-constructive-proof-of-the-fefferman-stein-decomposition/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’ve just uploaded the short story “")#link("https://terrytao.wordpress.com/wp-content/uploads/2015/03/uchiyama.pdf")[#text("Uchiyama’s constructive proof of the Fefferman-Stein decomposition")]#text("“. In 1982, ")#link("http://www.ams.org/mathscinet-getitem?mr=666111")[#text("Uchiyama gave")]#text(" a new proof of the celebrated ")#link("http://www.ams.org/mathscinet-getitem?mr=447953")[#text("Fefferman-Stein theorem")]#text(" that expressed any BMO function as the sum of a bounded function, and Riesz transforms of bounded functions. Unlike the original proof (which relied, among other things, on the Hahn-Banach theorem), Uchiyama’s proof was very explicit, constructing the decomposition by building the bounded functions one Littlewood-Paley frequency band at a time while keeping the functions taking values on or near a sphere, and then iterating away the error. Here I have written some notes on how the proof goes. The notes are a little condensed, in that a number of standard computations involving estimations of Schwartz tails, Carleson measures, etc. have been omitted, but hopefully the gist of the argument is still clear.")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fc2c99afee0668b8e90a338a766aafe608b5259ff35e6f161328c1c2f0bac33-05d3eeeee07780c177666558c4352e090bba3be15c673d0dfbe98eb669c1f24c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ford Denison")]], [#link("https://terrytao.wordpress.com/2007/02/23/uchiyamas-constructive-proof-of-the-fefferman-stein-decomposition/#comment-183")[#strong[#text("Ford Denison")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2007")])]

#text("You can’t imagine how flattering it is to have my blog listed right under Bruce Schneier’s!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c387c0103df4480f8ca2c8663e0bb1cb88a59a3a465350b722aad81a735caca4-eec7698395e6211be202abe518f01a16e8fdd6895c90cb5ad69ec11f4bb85f16.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chemakh")]], [#link("https://terrytao.wordpress.com/2007/02/23/uchiyamas-constructive-proof-of-the-fefferman-stein-decomposition/#comment-25407")[#strong[#text("Chemakh")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2008")])]

#text("Salut tt le monde, pour votre cv essayez ca ")#link("http://www.smart-http.com/mon_cv+index.htm")[#text("http://www.smart-http.com/mon_cv+index.htm")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 9: The Baire category theorem and its Banach space consequences « What’s new")]], [#link("https://terrytao.wordpress.com/2007/02/23/uchiyamas-constructive-proof-of-the-fefferman-stein-decomposition/#comment-35402")[#strong[#text("245B, Notes 9: The Baire category theorem and its Banach space consequences « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2009")])]

#text("[…] Remark 9. The phenomenon of nonlinear quantitative solvability actually comes up in many applications of interest. For instance, consider the Fefferman-Stein decomposition theorem, which asserts that any of bounded mean oscillation can be decomposed as for some , where H is the Hilbert transform. This theorem was first proven by using the duality of the Hardy space and BMO (and by using Exercise 13 from Notes 6), and by using the fact that a function f is in if and only if f and Hf both lie in . From the open mapping theorem we know that we can pick g, h so that the norms of g, h are bounded by a multiple of the BMO norm of f. But it turns out not to be possible to pick g and h in a bounded linear manner in terms of f, although this is a little tricky to prove. (Uchiyama famously gave an explicit construction of g, h in terms of f, but the construction was highly nonlinear; see my blog post on the topic.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The double Duhamel trick and the in/out decomposition « What’s new")]], [#link("https://terrytao.wordpress.com/2007/02/23/uchiyamas-constructive-proof-of-the-fefferman-stein-decomposition/#comment-42844")[#strong[#text("The double Duhamel trick and the in/out decomposition « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2009")])]

#text("[…] nature of a certain subspace of a Banach space; see these lecture notes of mine and this old blog post for some discussion.) So one could imagine a sophisticated nonlinear decomposition as a general […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dd792ce466ac8b4341f8a9162d68c16b08d9bd178f616ec98d0ff844a340d447-a8dd3134e6b8d7ab623dcabc4d8253d43da8f3dc0c51f6abafac24a8be615411.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt R.")]], [#link("https://terrytao.wordpress.com/2007/02/23/uchiyamas-constructive-proof-of-the-fefferman-stein-decomposition/#comment-461132")[#strong[#text("Matt R.")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2015")])]

#text("Dear Professor Tao, the PDF copy of your short story which appears from the link above seems to have some problems in the formatting regarding theorem numbering, equation numbering, etc. Do you have another PDF copy which you can make available? Thank you.")

#emph[#text("[I don’t see the issues with the current PDF, could you be more specific? Thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The nonlinearity of the Fefferman-Stein decomposition | What's new")]], [#link("https://terrytao.wordpress.com/2007/02/23/uchiyamas-constructive-proof-of-the-fefferman-stein-decomposition/#comment-507482")[#strong[#text("The nonlinearity of the Fefferman-Stein decomposition | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2018")])]

#text("[…] theorem). A constructive proof was later given by Uchiyama, and was in fact the topic of the second post on this blog. A notable feature of Uchiyama’s argument is that the construction is quite nonlinear; the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Embedding the Heisenberg group into a bounded dimensional Euclidean space with optimal distortion | What's new")]], [#link("https://terrytao.wordpress.com/2007/02/23/uchiyamas-constructive-proof-of-the-fefferman-stein-decomposition/#comment-507736")[#strong[#text("Embedding the Heisenberg group into a bounded dimensional Euclidean space with optimal distortion | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2018")])]

#text("[…] with Uchiyama’s constructive proof of the Fefferman-Stein decomposition theorem, discussed in this previous post (and in this recent […]")
]
