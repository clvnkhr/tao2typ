// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/12/28/the-inverse-theorem-for-the-u3-gowers-uniformity-norm-on-arbitrary-finite-abelian-groups-fourier-analytic-and-ergodic-approaches/
// Converted to Typst by tao2typ: "2026-10-14T11:04:52.257383+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The inverse theorem for the U^3 Gowers uniformity norm on arbitrary finite abelian groups: Fourier-analytic and ergodic approaches", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The inverse theorem for the U^3 Gowers uniformity norm on arbitrary finite abelian groups: Fourier-analytic and ergodic approaches")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 December 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/12/28/the-inverse-theorem-for-the-u3-gowers-uniformity-norm-on-arbitrary-finite-abelian-groups-fourier-analytic-and-ergodic-approaches/")[#text("https://terrytao.wordpress.com/2021/12/28/the-inverse-theorem-for-the-u3-gowers-uniformity-norm-on-arbitrary-finite-abelian-groups-fourier-analytic-and-ergodic-approaches/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://asgarjam.wixsite.com/home")[#text("Asgar Jamneshan")]#text(" and myself have just uploaded to the arXiv our preprint “")#link("https://arxiv.org/abs/2112.13759")[#text("The inverse theorem for the ")#mi("{U^3}")#text(" Gowers uniformity norm on arbitrary finite abelian groups: Fourier-analytic and ergodic approaches")]#text("“. This paper, which is a companion to ")#link("https://terrytao.wordpress.com/2021/12/06/the-structure-of-arbitrary-conze-lesigne-systems/")[#text("another recent paper")]#text(" of ourselves and ")#link("http://www.math.huji.ac.il/~orshalom/")[#text("Or Shalom")]#text(", studies the inverse theory for the third ")#link("https://en.wikipedia.org/wiki/Gowers_norm")[#text("Gowers uniformity norm")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{U^3(G)}^8 = {\\bf E}_{h_1,h_2,h_3,x \\in G} \\Delta_{h_1} \\Delta_{h_2} \\Delta_{h_3} f(x)", block: true)]]

#text("on an arbitrary finite abelian group ")#mi("{G}")#text(", where ")#mi("{\\Delta_h f(x) := f(x+h) \\overline{f(x)}}")#text(" is the multiplicative derivative. Our main result is as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Inverse theorem for ")#mi("{U^3(G)}")#text(")")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" Let ")#mi("{G}")#text(" be a finite abelian group, and let ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" be a ")#mi("{1}")#text("-bounded function with ")#tao-math("{\\left\\|f\\right\\|_{U^3(G)} \\geq \\eta}", block: false)#text(" for some ")#mi("{0 < \\eta \\leq 1/2}")#text(". Then:")

#list(
[#text("(i) (Correlation with locally quadratic phase) There exists a regular Bohr set ")#mi("{B(S,\\rho) \\subset G}")#text(" with ")#tao-math("{\\left|S\\right| \\ll \\eta^{-O(1)}}", block: false)#text(" and ")#mi("{\\exp(-\\eta^{-O(1)}) \\ll \\rho \\leq 1/2}")#text(", a locally quadratic function ")#mi("{\\phi: B(S,\\rho) \\rightarrow {\\bf R}/{\\bf Z}}")#text(", and a function ")#mi("{\\xi: G \\rightarrow \\hat G}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_{x \\in G} \\left|{\\bf E}_{h \\in B(S,\\rho)} f(x+h) e(-\\phi(h)-\\xi(x) \\cdot h)\\right| \\gg \\eta^{O(1)}.", block: true)]]],
[#text("(ii) (Correlation with nilsequence) There exists an explicit degree two filtered nilmanifold ")#mi("{H/\\Lambda}")#text(" of dimension ")#mi("{O(\\eta^{-O(1)})}")#text(", a polynomial map ")#mi("{g: G \\rightarrow H/\\Lambda}")#text(", and a Lipschitz function ")#mi("{F: H/\\Lambda \\rightarrow {\\bf C}}")#text(" of constant ")#mi("{O(\\exp(\\eta^{-O(1)}))}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E}_{x \\in G} f(x) \\overline{F}(g(x))\\right| \\gg \\exp(-\\eta^{-O(1)}).", block: true)]]]
)
]

#text("Such a theorem was proven ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2391635")[#text("by Ben Green and myself")]#text(" in the case when ")#tao-math("{\\left|G\\right|}", block: false)#text(" was odd, and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2402476")[#text("by Samorodnitsky")]#text(" in the ")#mi("{2}")#text("-torsion case ")#mi("{G = {\\bf F}_2^n}")#text(". In all cases one uses the “higher order Fourier analysis” techniques ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1631259")[#text("introduced by Gowers")]#text(". After some now-standard manipulations (using for instance what is now known as the Balog-Szemerédi-Gowers lemma), one arrives (for arbitrary ")#mi("{G}")#text(") at an estimate that is roughly of the form")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E}_{x \\in G} {\\bf E}_{h,k \\in B(S,\\rho)} f(x+h+k) b(x,k) b(x,h) e(-B(h,k))\\right| \\gg \\eta^{O(1)}", block: true)]]

#text("where ")#mi("{b}")#text(" denotes various ")#mi("{1}")#text("-bounded functions whose exact values are not too important, and ")#mi("{B: B(S,\\rho) \\times B(S,\\rho) \\rightarrow {\\bf R}/{\\bf Z}}")#text(" is a symmetric locally bilinear form. The idea is then to “integrate” this form by expressing it in the form")

#metadata(none) <tao-58f5c9937d625a9f2f21>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("B(h,k) = \\phi(h+k) - \\phi(h) - \\phi(k)")]]

#text("for some locally quadratic ")#mi("{\\phi: B(S,\\rho) \\rightarrow {\\bf C}}")#text("; this then allows us to write the above correlation as")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E}_{x \\in G} {\\bf E}_{h,k \\in B(S,\\rho)} f(x+h+k) e(-\\phi(h+k)) b(x,k) b(x,h)\\right| \\gg \\eta^{O(1)}", block: true)]]

#text("(after adjusting the ")#mi("{b}")#text(" functions suitably), and one can now conclude part (i) of the above theorem using some linear Fourier analysis. Part (ii) follows by encoding locally quadratic phase functions as nilsequences; for this we ")#link("https://arxiv.org/abs/1404.7742")[#text("adapt an algebraic construction of Manners")]#text(".")

#text("So the key step is to obtain a representation of the form ")#link(<tao-58f5c9937d625a9f2f21>)[#text("(1)")]#text(", possibly after shrinking the Bohr set ")#mi("{B(S,\\rho)}")#text(" a little if needed. This has been done in the literature in two ways:")

#list(
[#text("When ")#tao-math("{\\left|G\\right|}", block: false)#text(" is odd, one has the ability to divide by ")#mi("{2}")#text(", and on the set ")#mi("{2 \\cdot B(S,\\frac{\\rho}{10}) = \\{ 2x: x \\in B(S,\\frac{\\rho}{10})\\}}")#text(" one can establish ")#link(<tao-58f5c9937d625a9f2f21>)[#text("(1)")]#text(" with ")#mi("{\\phi(h) := B(\\frac{1}{2} h, h)}")#text(". (This is similar to how in single variable calculus the function ")#mi("{x \\mapsto \\frac{1}{2} x^2}")#text(" is a function whose second derivative is equal to ")#mi("{1}")#text(".)")],
[#text("When ")#mi("{G = {\\bf F}_2^n}")#text(", then after a change of basis one can take the Bohr set ")#mi("{B(S,\\rho)}")#text(" to be ")#mi("{{\\bf F}_2^m}")#text(" for some ")#mi("{m}")#text(", and the bilinear form can be written in coordinates as")

#align(center)[#tao-fit-display[#mitex("B(h,k) = \\sum_{1 \\leq i,j \\leq m} a_{ij} h_i k_j / 2 \\text{ mod } 1")]]

#text("for some ")#mi("{a_{ij} \\in {\\bf F}_2}")#text(" with ")#mi("{a_{ij}=a_{ji}}")#text(". The diagonal terms ")#mi("{a_{ii}}")#text(" cause a problem, but by subtracting off the rank one form ")#mi("{(\\sum_{i=1}^m a_{ii} h_i) ((\\sum_{i=1}^m a_{ii} k_i) / 2}")#text(" one can write")

#align(center)[#tao-fit-display[#mitex("B(h,k) = \\sum_{1 \\leq i,j \\leq m} b_{ij} h_i k_j / 2 \\text{ mod } 1")]]

#text("on the orthogonal complement of ")#mi("{(a_{11},\\dots,a_{mm})}")#text(" for some coefficients ")#mi("{b_{ij}=b_{ji}}")#text(" which now vanish on the diagonal: ")#mi("{b_{ii}=0}")#text(". One can now obtain ")#link(<tao-58f5c9937d625a9f2f21>)[#text("(1)")]#text(" on this complement by taking")

#align(center)[#tao-fit-display[#mitex("\\phi(h) := \\sum_{1 \\leq i < j \\leq m} b_{ij} h_i h_k / 2 \\text{ mod } 1.")]]]
)

#text("In our paper we can now treat the case of arbitrary finite abelian groups ")#mi("{G}")#text(", by means of the following two new ingredients:")

#list(
[#text("(i) Using some geometry of numbers, we can lift the group ")#mi("{G}")#text(" to a larger (possibly infinite, but still finitely generated) abelian group ")#mi("{G_S}")#text(" with a projection map ")#mi("{\\pi: G_S \\rightarrow G}")#text(", and find a ")#emph[#text("globally")]#text(" bilinear map ")#mi("{\\tilde B: G_S \\times G_S \\rightarrow {\\bf R}/{\\bf Z}}")#text(" on the latter group, such that one has a representation")

#metadata(none) <tao-b3926346e92cac557f00>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("B(\\pi(x), \\pi(y)) = \\tilde B(x,y)")]]

#text("of the locally bilinear form ")#mi("{B}")#text(" by the globally bilinear form ")#mi("{\\tilde B}")#text(" when ")#mi("{x,y}")#text(" are close enough to the origin.")],
[#text("(ii) Using an explicit construction, one can show that every globally bilinear map ")#mi("{\\tilde B: G_S \\times G_S \\rightarrow {\\bf R}/{\\bf Z}}")#text(" has a representation of the form ")#link(<tao-58f5c9937d625a9f2f21>)[#text("(1)")]#text(" for some globally quadratic function ")#mi("{\\tilde \\phi: G_S \\rightarrow {\\bf R}/{\\bf Z}}")#text(".")]
)

#text("To illustrate (i), consider the Bohr set ")#tao-math("{B(S,1/10) = \\{ x \\in {\\bf Z}/N{\\bf Z}: \\left\\|x/N\\right\\|_{{\\bf R}/{\\bf Z}} < 1/10\\}}", block: false)#text(" in ")#mi("{G = {\\bf Z}/N{\\bf Z}}")#text(" (where ")#mi("{\\|\\|_{{\\bf R}/{\\bf Z}}}")#text(" denotes the distance to the nearest integer), and consider a locally bilinear form ")#mi("{B: B(S,1/10) \\times B(S,1/10) \\rightarrow {\\bf R}/{\\bf Z}}")#text(" of the form ")#mi("{B(x,y) = \\alpha x y \\text{ mod } 1}")#text(" for some real number ")#mi("{\\alpha}")#text(" and all integers ")#mi("{x,y \\in (-N/10,N/10)}")#text(" (which we identify with elements of ")#mi("{G}")#text(". For generic ")#mi("{\\alpha}")#text(", this form cannot be extended to a globally bilinear form on ")#mi("{G}")#text("; however if one lifts ")#mi("{G}")#text(" to the finitely generated abelian group")

#align(center)[#tao-fit-display[#mitex("G_S := \\{ (x,\\theta) \\in {\\bf Z}/N{\\bf Z} \\times {\\bf R}: \\theta = x/N \\text{ mod } 1 \\}")]]

#text("(with projection map ")#mi("{\\pi: (x,\\theta) \\mapsto x}")#text(") and introduces the globally bilinear form ")#mi("{\\tilde B: G_S \\times G_S \\rightarrow {\\bf R}/{\\bf Z}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\tilde B((x,\\theta),(y,\\sigma)) = N^2 \\alpha \\theta \\sigma \\text{ mod } 1")]]

#text("then one has ")#link(<tao-b3926346e92cac557f00>)[#text("(2)")]#text(" when ")#mi("{\\theta,\\sigma}")#text(" lie in the interval ")#mi("{(-1/10,1/10)}")#text(". A similar construction works for higher rank Bohr sets.")

#text("To illustrate (ii), the key case turns out to be when ")#mi("{G_S}")#text(" is a cyclic group ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(", in which case ")#mi("{\\tilde B}")#text(" will take the form")

#align(center)[#tao-fit-display[#mitex("\\tilde B(x,y) = \\frac{axy}{N} \\text{ mod } 1")]]

#text("for some integer ")#mi("{a}")#text(". One can then check by direct construction that ")#link(<tao-58f5c9937d625a9f2f21>)[#text("(1)")]#text(" will be obeyed with")

#align(center)[#tao-fit-display[#mitex("\\tilde \\phi(x) = \\frac{a \\binom{x}{2}}{N} - \\frac{a x \\binom{N}{2}}{N^2} \\text{ mod } 1")]]

#text("regardless of whether ")#mi("{N}")#text(" is even or odd. A variant of this construction also works for ")#mi("{{\\bf Z}}")#text(", and the general case follows from a short calculation verifying that the claim (ii) for any two groups ")#mi("{G_S, G^{\\prime}_S}")#text(" implies the corresponding claim (ii) for the product ")#mi("{G_S \\times G^{\\prime}_S}")#text(".")

#text("This concludes the Fourier-analytic proof of Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(". In this paper we also give an ergodic theory proof of (a qualitative version of) Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text("(ii), using a correspondence principle argument adapted from ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2663409")[#text("this previous paper of Ziegler, and myself")]#text(". Basically, the idea is to randomly generate a dynamical system on the group ")#mi("{G}")#text(", by selecting an infinite number of random shifts ")#mi("{g_1, g_2, \\dots \\in G}")#text(", which induces an action of the infinitely generated free abelian group ")#mi("{{\\bf Z}^\\omega = \\bigcup_{n=1}^\\infty {\\bf Z}^n}")#text(" on ")#mi("{G}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("T^h x := x + \\sum_{i=1}^\\infty h_i g_i.")]]

#text("Much as the law of large numbers ensures the almost sure convergence of ")#link("https://en.wikipedia.org/wiki/Monte_Carlo_integration")[#text("Monte Carlo integration")]#text(", one can show that this action is almost surely ergodic (after passing to a suitable Furstenberg-type limit ")#mi("{X}")#text(" where the size of ")#mi("{G}")#text(" goes to infinity), and that the dynamical Host-Kra-Gowers seminorms of that system coincide with the combinatorial Gowers norms of the original functions. One is then well placed to apply an inverse theorem for the third Host-Kra-Gowers seminorm ")#mi("{U^3(X)}")#text(" for ")#mi("{{\\bf Z}^\\omega}")#text("-actions, which was accomplished in the ")#link("https://terrytao.wordpress.com/2021/12/06/the-structure-of-arbitrary-conze-lesigne-systems/https://terrytao.wordpress.com/2021/12/06/the-structure-of-arbitrary-conze-lesigne-systems/")[#text("companion paper to this one")]#text(". After doing so, one ")#emph[#text("almost")]#text(" gets the desired conclusion of Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text("(ii), except that after undoing the application of the Furstenberg correspondence principle, the map ")#mi("{g: G \\rightarrow H/\\Lambda}")#text(" is merely an ")#emph[#text("almost polynomial")]#text(" rather than a polynomial, which roughly speaking means that instead of certain derivatives of ")#mi("{g}")#text(" vanishing, they instead are merely very small outside of a small exceptional set. To conclude we need to invoke a “stability of polynomials” result, which at this level of generality was first established ")#link("https://arxiv.org/abs/1902.01098")[#text("by Candela and Szegedy")]#text(" (though we also provide an independent proof here in an appendix), which roughly speaking asserts that every approximate polynomial is close in measure to an actual polynomial. (This general strategy is also employed in the Candela-Szegedy paper, though in the absence of the ergodic inverse theorem input that we rely upon here, the conclusion is weaker in that the filtered nilmanifold ")#mi("{H/\\Lambda}")#text(" is replaced with a general space known as a “CFR nilspace”.)")

#text("This transference principle approach seems to work well for the higher step cases (for instance, the stability of polynomials result is known in arbitrary degree); the main difficulty is to establish a suitable higher step inverse theorem in the ergodic theory setting, which we hope to do in future research.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/12/28/the-inverse-theorem-for-the-u3-gowers-uniformity-norm-on-arbitrary-finite-abelian-groups-fourier-analytic-and-ergodic-approaches/#comment-638734")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2021")])]

#text("Is it possible to unify/combine the analytic and ergodic approaches?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/12/28/the-inverse-theorem-for-the-u3-gowers-uniformity-norm-on-arbitrary-finite-abelian-groups-fourier-analytic-and-ergodic-approaches/#comment-638779")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2021")])]

#text("I believe this will eventually be the case. Certainly there are close analogies between the two approaches and a partial dictionary between the two; to give just one example, being measurable with respect to the Kronecker factor in the ergodic theory approach corresponds to being well approximated by a linear combination of a bounded number of Fourier characters in the Fourier-analytic approach. The framework of nilspace structures on hyperfinite abelian groups is in some sense a partial unification of the two approaches, though at our current level of understanding, nilspaces don’t seem to fully capture all the dynamical structure that the ergodic theory approach exploits (or all of the additive combinatorial structure that the Fourier analytic approach exploits). Hopefully as research advances, these approaches will become more unified, but it is still a work in progress.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Helen")]], [#link("https://terrytao.wordpress.com/2021/12/28/the-inverse-theorem-for-the-u3-gowers-uniformity-norm-on-arbitrary-finite-abelian-groups-fourier-analytic-and-ergodic-approaches/#comment-638758")[#strong[#text("Helen")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2021")])]

#text("I have passed the entrance exam，and making effort to become a good student in math，and trying to understand your blog～")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa99c9c4e4ea1dc50c795652bf4b9b5cea2c0c75bd24fef1a4a3d44510f5d075-763abf3828a752d347d90126d33d3ffa51f0c6353e1a8eb35774901c30b2131f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rohan Bhardwaj")]], [#link("https://terrytao.wordpress.com/2021/12/28/the-inverse-theorem-for-the-u3-gowers-uniformity-norm-on-arbitrary-finite-abelian-groups-fourier-analytic-and-ergodic-approaches/#comment-638919")[#strong[#text("Rohan Bhardwaj")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2021")])]

#text("Dear Tao,")

#text("Since you have solved a part of Collatz Conjecture, I hope you may help me.")

#text("Will it be helpful to find a series of odd numbers that follow Collatz conjecture?")

#text("Thank you")#linebreak()#text(" Best")#linebreak()#text(" Rohan")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee842db111ab7122b09ae0e589161eed33124e8ee1964eabb0a705a573376b52-54a5853c2f23221be3d900deac4d1995a898d80700219e2cfc4370c7dbef38dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Hunter")]], [#link("https://terrytao.wordpress.com/2021/12/28/the-inverse-theorem-for-the-u3-gowers-uniformity-norm-on-arbitrary-finite-abelian-groups-fourier-analytic-and-ergodic-approaches/#comment-639091")[#strong[#text("Michael Hunter")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2022")])]

#text("Is your work primarily in creating binding geometric structures for prime distributions, to upper and lower bound for a measure of convergence/predictability?")

#text("I’m enjoying reading your posts!")

#text("Have an awesome day.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5de81caf27ea1c884d83698fab5720d79784c1bc30ac8b91cf5c21806efffcf3-9d689153f43e1cf61419d8e19dc3b330e46a370f82739e4bf88989de76732e68.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CFNB")]], [#link("https://terrytao.wordpress.com/2021/12/28/the-inverse-theorem-for-the-u3-gowers-uniformity-norm-on-arbitrary-finite-abelian-groups-fourier-analytic-and-ergodic-approaches/#comment-639382")[#strong[#text("CFNB")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2022")])]

#text("Line 7 of the post: “…on an arbitrary finite abelian group $f$”, should replace f by G.")

#text("Additionally, in the abstract for the paper, the first line reads “…for the Gowers uniformity norm […] on an arbitrary finite group G”. Surely this should be an arbitrary finite *abelian* group G?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2021/12/28/the-inverse-theorem-for-the-u3-gowers-uniformity-norm-on-arbitrary-finite-abelian-groups-fourier-analytic-and-ergodic-approaches/#comment-640710")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2022")])]

#text("How do I even begin to understand this blog. Should I just start with your real analysis lecture series/notes/book?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0fd56049a8189a380fda42273fee0bc2b9ce50a7a224700afce1fe96194008-d71b4d207f9bb85a02159d9eb02ffc3ded2bfbce61de425e7d3d85b4f53db867.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uwe Stroinski")]], [#link("https://terrytao.wordpress.com/2021/12/28/the-inverse-theorem-for-the-u3-gowers-uniformity-norm-on-arbitrary-finite-abelian-groups-fourier-analytic-and-ergodic-approaches/#comment-640729")[#strong[#text("Uwe Stroinski")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2022")])]

#text("Definition 1.4 (ii) of regular Bohr sets in your paper is not consistent with your usual definition.")

#emph[#text("[I don’t see the inconsistency; the definition is taken from Definition 4.24 of my book with Van Vu. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0fd56049a8189a380fda42273fee0bc2b9ce50a7a224700afce1fe96194008-d71b4d207f9bb85a02159d9eb02ffc3ded2bfbce61de425e7d3d85b4f53db867.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uwe Stroinski")]], [#link("https://terrytao.wordpress.com/2021/12/28/the-inverse-theorem-for-the-u3-gowers-uniformity-norm-on-arbitrary-finite-abelian-groups-fourier-analytic-and-ergodic-approaches/#comment-641059")[#strong[#text("Uwe Stroinski")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2022")])]

#text("In that case it is a minor typo. One needs ")#tao-math("\\left|\\kappa\\right|", block: false)#text(" in the inequality.")

#emph[#text("[Thanks, this will be corrected in the next version of the ms – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on inverse theorem entropy | What's new")]], [#link("https://terrytao.wordpress.com/2021/12/28/the-inverse-theorem-for-the-u3-gowers-uniformity-norm-on-arbitrary-finite-abelian-groups-fourier-analytic-and-ergodic-approaches/#comment-644067")[#strong[#text("Notes on inverse theorem entropy | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2022")])]

#text("[…] the norm on an arbitrary finite abelian group, the recent inverse theorem of Jamneshan and myself gives (after some calculations) a bound of the polynomial form on the -entropy for some , which […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/12/28/the-inverse-theorem-for-the-u3-gowers-uniformity-norm-on-arbitrary-finite-abelian-groups-fourier-analytic-and-ergodic-approaches/#comment-652141")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2022")])]

#text("Is there a good reference for Calderon Transference principle?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/12/28/the-inverse-theorem-for-the-u3-gowers-uniformity-norm-on-arbitrary-finite-abelian-groups-fourier-analytic-and-ergodic-approaches/#comment-652162")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2022")])]

#text("A paper titled “Ergodic theory and translation invariant operators” is a good place to start.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/07cfee8a2674842417a50a81f0b90492ec70d0295199db341d2f0b99d83e5769-059add3be0c5cc2d4c449d338d6cdd5450b88279db62f2ca0ca1b614f7fb5e55.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dilip Kulkarni")]], [#link("https://terrytao.wordpress.com/2021/12/28/the-inverse-theorem-for-the-u3-gowers-uniformity-norm-on-arbitrary-finite-abelian-groups-fourier-analytic-and-ergodic-approaches/#comment-652188")[#strong[#text("Dilip Kulkarni")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2022")])]

#text("3x-1 seems to reach. Is this something well known and has attention like 3x+1")#linebreak()#text(" x=1 -> 3.1-1=2, 2/2 =1 loop 1-2-1")#linebreak()#text(" x=2 –> 1 loop")#linebreak()#text(" x=3 –> 8–>4–>2–>1 loop 1-2-1")#linebreak()#text(" x=4 –> 2–>1 loop")#linebreak()#text(" x=5 –> 14 –>7–>20–>10 –>5 loop to 14")#linebreak()#text(" x=6 –> 3 –>8–>4–>2–>1 loop to 2")#linebreak()#text(" x=7 –> 20 –>10–>5–>14–>7–>20 loop to 7")#linebreak()#text(" x=8 –> 4–>2–>1")#linebreak()#text(" x=9 –>26–>13–>38–>19–>56–>28–>14–>7–>20 loop to 7")#linebreak()#text(" x=10 –>5–>14 –>7–>20–>10 loop")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A Host–Kra ${bf F}^omega_2$-system of order 5 that is not Abramov of order 5, and non-measurability of the inverse theorem for the $U^6({bf F}^n_2)$ norm; The structure of totally disconnected Host–Kra–Ziegler factors, and the inverse th")]], [#link("https://terrytao.wordpress.com/2021/12/28/the-inverse-theorem-for-the-u3-gowers-uniformity-norm-on-arbitrary-finite-abelian-groups-fourier-analytic-and-ergodic-approaches/#comment-675856")[#strong[#text("A Host–Kra ${bf F}^omega_2$-system of order 5 that is not Abramov of order 5, and non-measurability of the inverse theorem for the $U^6({bf F}^n_2)$ norm; The structure of totally disconnected Host–Kra–Ziegler factors, and the inverse th")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2023")])]

#text("[…] developed in that paper (see also this paper of Towsner for a closely related principle, and this paper of Jamneshan and I for a refinement). In a paper with Bergelson and Ziegler, we were able to establish Conjecture 2 in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A Host–Kra ${bf F}^omega_2$-system of order 5 that is not Abramov of order 5, and non-measurability of the inverse theorem for the $U^6({bf F}^n_2)$ norm; The structure of totally disconnected Host–Kra–Ziegler factors, and the inverse th")]], [#link("https://terrytao.wordpress.com/2021/12/28/the-inverse-theorem-for-the-u3-gowers-uniformity-norm-on-arbitrary-finite-abelian-groups-fourier-analytic-and-ergodic-approaches/#comment-675862")[#strong[#text("A Host–Kra ${bf F}^omega_2$-system of order 5 that is not Abramov of order 5, and non-measurability of the inverse theorem for the $U^6({bf F}^n_2)$ norm; The structure of totally disconnected Host–Kra–Ziegler factors, and the inverse th")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2023")])]

#text("[…] developed in that paper (see also this paper of Towsner for a closely related principle, and this paper of Jamneshan and I for a refinement). In a paper with Bergelson and Ziegler, we were able to establish Conjecture 2 in […]")
]
