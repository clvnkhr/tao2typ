// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/
// Converted to Typst by tao2typ: "2026-10-14T16:35:37.764866+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "DHJ(3): 900-999 (Density Hales-Jewett type numbers)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("DHJ(3): 900-999 (Density Hales-Jewett type numbers)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 March 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/")[#text("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("This is a continuation of the ")#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/")[#text("700-799 thread")]#text(" of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("polymath1")]#text(" project, which is now full. During the course of that thread, we have made significant progress on the three problems being focused on:")

#strong[#text("1. Upper and lower bounds for ")#mi("c_n")#text(" for small n.")]

#text("Let ")#mi("c_n")#text(" be the largest size of a set in ")#mi("[3]^n")#text(" without a ")#link("http://michaelnielsen.org/polymath1/index.php?title=Line")[#text("combinatorial line")]#text(". We now have ")#link("http://michaelnielsen.org/polymath1/index.php?title=Upper_and_lower_bounds")[#text("both human and computer-assisted proofs")]#text(" of the first few values of this sequence:")

#align(center)[#mi("c_0=1; c_1=2; c_2=6; c_3=18; c_4=52; c_5 = 150; c_6 = 450")#text(".")]

#text("The current best-known bounds for ")#mi("c_7")#text(" are ")#mi("1302 \\leq c_7 \\leq 1348")#text(". Given the gap involved here, and the rate at which the complexity of the problem has increased with n, it seems unlikely that we will be able to compute ")#mi("c_7")#text(" exactly any time soon, but it is possible that some improvement can still be made here.")

#strong[#text("2. A hyper-optimistic conjecture")]

#text("Consider a variant of the above problem in which each element of ")#mi("[3]^n")#text(" with a 1s, b 2s, and c 3s is weighted by the factor ")#mi("\\frac{a! b! c!}{n!}")#text("; this gives ")#mi("[3]^n")#text(" a total weight of ")#mi("\\frac{(n+1)(n+2)}{2}")#text(". Let ")#mi("c^\\mu_n")#text(" be the largest weight of a line-free set of ")#mi("[3]^n")#text(", and let ")#mi("\\overline{c}^\\mu_n")#text(" be the largest size of a subset of")

#mi("\\Delta_n := \\{ (a,b,c) \\in {\\Bbb Z}_+^3: a+b+c=n \\}")

#text("which contains no upward-pointing equilateral triangles ")#mi("(a+r,b,c), (a,b+r,c), (a,b,c+r)")#text(" with r>0. It is known that ")#mi("c^\\mu_n \\geq \\overline{c}^\\mu_n")#text("; the “")#link("http://michaelnielsen.org/polymath1/index.php?title=Hyper-optimistic_conjecture")[#text("hyper-optimistic conjecture")]#text("” is that one in fact has ")#mi("c^\\mu_n = \\overline{c}^\\mu_n")#text(". This would imply density Hales-Jewett for k=3.")

#text("Currently, the conjecture is verified for ")#mi("n \\leq 5")#text(", where the values of ")#mi("c^\\mu_n = \\overline{c}^\\mu_n")#text(" for ")#mi("n=0,1,2,3,4,5")#text(" are 1,2,4,6,9,12 respectively; see ")#link("http://michaelnielsen.org/polymath1/index.php?title=Fujimura%27s_problem")[#text("this page")]#text(" and ")#link("http://michaelnielsen.org/polymath1/index.php?title=Hyper-optimistic_conjecture")[#text("this page")]#text(" for details. It seems feasible to handle ")#mi("n=6")#text(". Currently we know that ")#mi("15 \\leq \\overline{c}^\\mu_6 \\leq 17")#text(" and ")#mi("\\overline{c}^\\mu_6 \\leq c^\\mu_6 \\leq 28")#text(".")

#strong[#text("3. Asymptotics for Moser’s cube problem")]

#link("http://michaelnielsen.org/polymath1/index.php?title=Moser%27s_cube_problem")[#text("Moser’s cube problem")]#text(" asks to compute the largest size ")#mi("c^{\\prime}_n")#text(" of a subset of the cube ")#mi("[3]^n")#text(" without geometric lines. The first few values of ")#mi("c^{\\prime}_n")#text(" are known:")

#align(center)[#mi("c^{\\prime}_0=1; c^{\\prime}_1 = 2; c^{\\prime}_2 = 6; c^{\\prime}_3 = 16; c^{\\prime}_4 = 43")#text(".")]

#text("The best asymptotic lower bound known is still of the order of ")#mi("3^n/\\sqrt{n}")#text(". Improving this bound seems related to the well-known problem of improving the bounds in Behrend’s construction of an AP-3 free set of integers.")

#text("We are quite close now to pinning down ")#mi("c^{\\prime}_5")#text("; we know that it is equal to either 124 or 125, and it is looking increasingly unlikely that it is 125.")

#text("Comments on this thread should start at 900.")

#heading(level: 1)[#text("Comments (110)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-3/#comment-36667")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2009")])]

#text("990. Diagonal Moser cubes")

#text("Michael, this is great! I of course plunked the inequalities into the linear program at")

#link("http://michaelnielsen.org/polymath1/index.php?title=Maple_calculations")[#text("http://michaelnielsen.org/polymath1/index.php?title=Maple_calculations")]

#text("to see what improves. The 4D bound for a+b+c+d+e+d/2 for e=1 improved from 41.5 to 40, giving a new inequality a+b+c+d+e+d/2 + 3e <= 43. The 5D bound a+b+c+d+e+f <= 119 for f=1 improved to 117, giving a new inequality a+b+c+d+e+f+7f <= 124. The ")#mi("c^{\\prime}_6")#text(" bound unfortunately did not budge at 361, but the extremal changed (e and f became even smaller), suggesting that at least some of the 361-point cases were eliminated. When g=1, the bound dropped from 355 to 352, which is below Kareem’s example and thus demonstrates for the first time that g=0 for the ")#mi("c^{\\prime}_6")#text(" extremiser.")

#text("In 7D, the bound for ")#mi("c^{\\prime}_7")#text(" improved from 1078 to 1073, and when h=1 there is a further improvement from 1071 to 1065. So the new inequalities are having an impact…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-3/#comment-36672")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2009")])]

#text("991. Diagonal Moser cubes")

#text("Inequalities arising from xxxyz diagonals:")#linebreak()#text(" Letters a to f are densities")#linebreak()#text(" 8a+4b+2c+2d+4e+2f <=11")#linebreak()#text(" 4a+2b+1c+2d+2e+1f <= 6")#linebreak()#text(" 0a+0b+2c+0d+0e+1f <= 2")#linebreak()#text(" 4a+4b+1c+0d+2e+1f <= 6")#linebreak()#text(" 7a+2b+1c+1d+2e+1f <= 7")#linebreak()#text(" 8a+2b+1c+2d+2e+1f <= 8")#linebreak()#text(" 4a+0b+2c+0d+0e+1f <= 4")#linebreak()#text(" 4a+0b+2c+2d+2e+1f <= 6")#linebreak()#text(" 8a+0b+2c+2d+2e+1f <= 8")#linebreak()#text(" 8a+4b+1c+0d+2e+1f <= 8")

#text("Inequalities arising from xxxxyz diagonals")#linebreak()#text(" a,b,c,e,f,g are densities. These cubes do not intersect the d slice")#linebreak()#text(" 8a+4b+2c+2e+4f+2g <= 11")#linebreak()#text(" 0a+0b+2c+0e+0f+1g <= 2")#linebreak()#text(" 4a+2b+1c+2e+2f+1g <= 6")#linebreak()#text(" 7a+2b+1c+1e+2f+1g <= 7")#linebreak()#text(" 4a+0b+2c+0e+0f+1g <= 4")#linebreak()#text(" 4a+0b+2c+2e+2f+1g <= 6")#linebreak()#text(" 8a+0b+2c+2e+2f+1g <= 8")#linebreak()#text(" 8a+2b+1c+2e+2f+1g <= 8")#linebreak()#text(" 4a+4b+1c+0e+2f+1g <= 6")#linebreak()#text(" 8a+4b+1c+0e+2f+1g <= 8")

#text("Inequalities from xxxyyz diagonals")#linebreak()#text(" Letters a to g are densities")#linebreak()#text(" 4a+2b+0c+3d+1e+1f+1g <= 6")#linebreak()#text(" 4a+0b+2c+3d+1e+1f+1g <= 6")#linebreak()#text(" 8a+2b+0c+3d+1e+1f+1g <= 8")#linebreak()#text(" 8a+0b+2c+3d+1e+1f+1g <= 8")#linebreak()#text(" 0a+4b+0c+0d+2e+0f+1g <= 4")#linebreak()#text(" 0a+0b+4c+0d+0e+2f+1g <= 4")#linebreak()#text(" 8a+4b+0c+0d+2e+0f+1g <= 1")#linebreak()#text(" 8a+0b+4c+0d+0e+2f+1g <= 1")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-3/#comment-36678")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2009")])]

#text("992.")

#text("Michael, there seems to be something wrong with your third set of inequalities (xxxyyz), for instance they are inconsistent with the densities a=1, b=c=d=e=f=g=0, which is of course feasible. Perhaps the weighting is a bit off?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-3/#comment-36680")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2009")])]

#text("993. Question II.A revisited")

#text("Post 984 is a bit off, as I used ")#mi("n")#text(" in a place I should have had ")#mi("\\sqrt{n}")#text(". Here’s an improved construction, with corrected analysis of its size.")

#text("It comes down to this: ")#mi("c_n > C 3^{n - 4\\sqrt{\\log 2}\\sqrt{\\log n}+\\frac 12 \\log \\log n}")#text(" for some absolute constant ")#mi("C")#text(", and where all logarithms are base-3.")

#text("For convenience, let ")#mi("n")#text(" be a multiple of 3. Elkin’s bound gives ")#mi("r_3(\\sqrt{n}) > C \\sqrt{n} (\\log n)^{1/4} \\exp_2(-2 \\sqrt{\\log_2 n})")#text(", and let ")#mi("R")#text(" be a subset of ")#mi("(-3\\sqrt{n}/2,3\\sqrt{n}/2)")#text(" without 3-term APs and with size ")#mi("r_3(\\sqrt{n})")#text(", and with all elements being integer multiples of 3 (again as a matter of convenience). For each ")#mi("r,s\\in R")#text(", let ")#mi("a = (n-r-s)/3")#text(". The set ")#mi("A")#text(" is the union of all ")#mi("\\Gamma_{a,a+r,a+s}")#text(". Since all of ")#mi("a, a+r,a+s")#text(" are between ")#mi("n/3-2\\sqrt{n}")#text(" and ")#mi("n/3+2\\sqrt{n}")#text(", the size of ")#mi("\\Gamma_{a,a+r,a+s}")#text(" is at least ")#mi("C 3^n / n")#text(". Since there are ")#mi("r_3(\\sqrt{n})^2")#text(" choices for ")#mi("r")#text(" and ")#mi("s")#text(", we have a set with size at least")#linebreak()#text(" ")#mi("C (\\sqrt{n} (\\log n)^{1/4} \\exp_2(-2 \\sqrt{\\log_2 n}))^2 3^n / n.")#linebreak()#text(" This simplifies to ")#mi("C \\sqrt{\\log n} \\exp_3(n-\\alpha \\sqrt{\\log_3(n)})")#text(", where ")#mi("\\alpha=4 \\sqrt{\\log_3(2)}")#text(", assuming my algebra holds this time.")

#text("Now suppose that ")#mi("x_i\\in \\Gamma_{a_i,a_i+r_i,a_i+s_i}")#text(" is a combinatorial line in the set ")#mi("A")#text(". Then ")#mi("(a_i+s_i)-(a_i)=s_i")#text(" is a 3-term AP contained in ")#mi("R")#text(", so the ")#mi("s_i")#text(" are all the same. Similarly, all of the ")#mi("r_i")#text(" are the same, and therefore all of the ")#mi("a_i")#text(" are the same, too. But this implies that the ")#mi("x_i")#text(" sequence is constant, which means the line is degenerate.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-3/#comment-36682")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2009")])]

#text("993. Moser’s diagonal cubes – correction")

#text("Hi Terry. Thanks for checking that.")

#text("The last two inequalities for xxxyyz should have 8 on the RHS.")#linebreak()#text(" 8a+4b+0c+0d+2e+0f+1g <= 8")#linebreak()#text(" 8a+0b+4c+0d+0e+2f+1g <= 8")#linebreak()#text(" The extremals for xxxyyz are")#linebreak()#text(" (4113111),(3223111),(2224220),(4113220),(4224200), (4223011),(4226000),(4222220),(4422020),(4224020), (4222111),(4223101),(4242200),(4444000),(8000000)")

#text("I checked the other inequalities, and I believe they are correct.")#linebreak()#text(" The density inequalities for xxyz, which I didn’t give above, are")#linebreak()#text(" 4a+2b+3c+2d+e <= 6")#linebreak()#text(" 8a+2b+3c+2d+e <= 8")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seva")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-3/#comment-36694")[#strong[#text("Seva")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2009")])]

#text("994. While all the major players are (supposedly) still out there, I wonder whether anything intelligent can be said on the smallest possible size of a Kakeya set in ")#mi("{\\mathbb F}_3^r")#text(". Let’s denote it ")#mi("k_r")#text("; thus, ")#mi("k_r")#text(" is the smallest integer for which a set ")#mi("K\\subset {\\mathbb F}_3^r")#text(" exists such that ")#tao-math("\\left|K\\right|=k_r", block: false)#text(" and for every ")#mi("d\\in {\\mathbb F}_3^r\\setminus\\{0\\}")#text(", the set ")#mi("K")#text(" has a line in the direction ")#mi("d")#text(". (A line in the direction ")#mi("d")#text(" is, of course, a three-element set of the form ")#mi("\\{a-d,a,a+d\\}")#text(".)")

#text("Clearly, we have ")#mi("k_1=3")#text(", and it is easy to see that ")#mi("k_2=7")#text(". Using a computer, I also found ")#mi("k_3=13")#text(" and ")#mi("k_4\\le 27")#text(". I suspect that, indeed, ")#mi("k_4=27")#text(" holds (meaning that in ")#mi("{\\mathbb F}_3^4")#text(" one cannot get away with just ")#mi("26")#text(" elements), and I am very curious to know whether ")#mi("k_5=53")#text(": notice the pattern in")

#mi("3,7,13,27,53,\\ldots")

#text("As to the general estimates, we have")

#mi("k_r(k_r-1)\\ge 3(3^r-1)")

#text("and, on the other hand,")

#mi("k_r\\le 2^{r+1}-1:")

#text("the former since for each ")#mi("d\\in {\\mathbb F}_3^r\\setminus\\{0\\}")#text(" there are at least three ordered pairs of elements of a Kakeya set with difference ")#mi("d")#text(", the latter due to the fact that the set of all vectors in ")#mi("{\\mathbb F}_3^r")#text(" such that at least one of the numbers ")#mi("1")#text(" and ")#mi("2")#text(" is missing among their coordinates is a Kakeya set. (I actually can improve the lower bound to something like ")#mi("k_r\\gg 3^{0.51r}")#text(".) Also, we have the trivial inequalities")

#mi("k_r\\le k_{r+1}\\le 3k_r;")

#text("can the upper bound be strengthened to ")#mi("k_{r+1}\\le 2k_r+1")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-3/#comment-36705")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2009")])]

#text("995. Thread moving")

#text("As is now our tradition, I’m declaring this thread full and am moving to the 1100-1199 thread at")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/")[#text("DHJ(3): 1100-1199 (Density Hales-Jewett type numbers)")]
]

#text("I’ll try to respond to several of the interesting new comments on this thread at the other thread.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DHJ(3): 1100-1199 (Density Hales-Jewett type numbers) « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-3/#comment-36706")[#strong[#text("DHJ(3): 1100-1199 (Density Hales-Jewett type numbers) « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2009")])]

#text("[…] March, 2009 in math.CO | Tags: polymath1 | by Terence Tao This is a continuation of the 900-999 thread of the polymath1 project, which is now full. We’ve made quite a bit of progress so far on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36510")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("946. Note on 945")

#text("I should not have put the word monochromatic before line in several")#linebreak()#text(" cases in the second to last paragraph.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36511")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("947. Rewrite of 942")

#text("If a Moser set for n=5 has 125 points")#linebreak()#text(" It must have the following statistics:")#linebreak()#text(" • (7,40,78,0,0,0) or")#linebreak()#text(" • (8,39,78,0,0,0)")

#text("Assume it has statistics (6,40,79,0,0,0),")#linebreak()#text(" the only remaining case.")#linebreak()#text(" Now look at the 6 points with all coordinates not")#linebreak()#text(" equal to 2 in the set. Any set of 5 of these has one pair of")#linebreak()#text(" points that differ in exactly two coordinates")#linebreak()#text(" See the proof of lemma 3 in the Moser wiki.")#linebreak()#text(" We start with 5 of these points and get at least one")#linebreak()#text(" pair that differs in exactly two coordinates if there is more than")#linebreak()#text(" one we choose a pair")#linebreak()#text(" Then we remove one of the points the pair and add the")#linebreak()#text(" additional point to replace then we have two pairs.")

#text("Then we note that each of these pairs of points")#linebreak()#text(" has the potential of forming a line with the")#linebreak()#text(" point p that has two twos in the coordinates i and j that the pair of points differ and where the points of the pair have")#linebreak()#text(" the same coordinate p has that coordinate. So p must be absent from the Moser set. Now")#linebreak()#text(" each such point p has the possibility of blocking two")#linebreak()#text(" such lines. the pair of points that has 11 and 33 in the coordinates where")#linebreak()#text(" p has two twos and the same coordinates as p elsewhere")#linebreak()#text(" and the points that have 13 and 31 in the points where")#linebreak()#text(" p has two 2’s and the same coordinates elsewhere.")

#text("Now in the case of this Moser set with")#linebreak()#text(" statistics (6,40,79,0,0,0)")#linebreak()#text(" We have two such pairs and since only one of 80")#linebreak()#text(" points with two twos is missing to avoid")#linebreak()#text(" a line the missing point must block both lines for the two")#linebreak()#text(" pairs as above.")

#text("Now we have from the above")#linebreak()#text(" four points which agree")#linebreak()#text(" on three coordinates called fixed coordinates and take on all")#linebreak()#text(" possible values on the remaining two coordinates.")#linebreak()#text(" They have the potential of forming lines")#linebreak()#text(" with those points with one two, namely those")#linebreak()#text(" points which agree with the four")#linebreak()#text(" points on the three fixed coordinates mentioned")#linebreak()#text(" above and have one two and one arbitrary")#linebreak()#text(" value on the remaining two coordinates.")#linebreak()#text(" There are four such points.")#linebreak()#text(" They must be absent from the Moser set")#linebreak()#text(" to avoid formin a line.")#linebreak()#text(" The point p")#linebreak()#text(" mentioned earlier which agrees with the above")#linebreak()#text(" points in the three fixed coordinates")#linebreak()#text(" and has 2’s in the remaining coordinate")#linebreak()#text(" forms two lines with these points.")#linebreak()#text(" These two lines are empty since p or any")#linebreak()#text(" of the other four points are not in the Moser")#linebreak()#text(" set .")

#text("The two lines were counted in the")#linebreak()#text(" inequality 2B + C is less than or equal to")#linebreak()#text(" 160 with weight one half. which is lemma three in the Wiki section n=5")#linebreak()#text(" we can remove these two lines and count over the remaining lines")#linebreak()#text(" since they are empty 2B +C will not be effected but the 160")#linebreak()#text(" will be reduced to 158 so then we will have")#linebreak()#text(" 2B +C is less than or equal to 158")#linebreak()#text(" but 2B+C is 159 in the case with statistics")#linebreak()#text(" (6,40,79,0,0,0).")

#text("So only the remaining two statistics are possible and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36512")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("948. Rewrite of 945.")

#text("If a Moser set for n=5 has 125 points")#linebreak()#text(" It must have the following statistics:")#linebreak()#text(" • (8,39,78,0,0,0)")

#text("Assume it does not then the only remaining case")#linebreak()#text(" is that it must have these statistics:")#linebreak()#text(" • 7,40,78,0,0,0)")

#text("Now look at the 7 points in the set with all coordinates not")#linebreak()#text(" equal to 2 Any set of 5 of these has one pair of")#linebreak()#text(" points that differ in exactly two coordinates")#linebreak()#text(" see the proof of lemma 3 in the Moser wiki.")#linebreak()#text(" We start with 5 of these points and get at least one")#linebreak()#text(" pair that differs in exactly two coordinates if there is more than")#linebreak()#text(" one we choose a pair")#linebreak()#text(" then we remove one of the points the pair and add the")#linebreak()#text(" additional point to replace then we have two pairs. We")#linebreak()#text(" keep doing this until we have three pairs.")#linebreak()#text(" If a line is to be avoided there must be a point with")#linebreak()#text(" two 2’s not in the in Moser set which has 2’s")#linebreak()#text(" where the points of the pair differ and for the")#linebreak()#text(" points where the pair agree it also agrees, if this")#linebreak()#text(" does not happen we will have a line.")

#text("Now from the above")#linebreak()#text(" we have four points which agree")#linebreak()#text(" on three coordinates called fixed coordinates and take on all")#linebreak()#text(" possible values on the remaining two")#linebreak()#text(" coordinates.")

#text("They have the potential of forming lines")#linebreak()#text(" with those points with one two, namely those")#linebreak()#text(" points which agree with the four")#linebreak()#text(" points on the three fixed coordinates mentioned")#linebreak()#text(" above and have one two and one arbitrary")#linebreak()#text(" value on the remaining two coordinates")#linebreak()#text(" there are four such points call them a,b,c,d. The point p")#linebreak()#text(" mentioned earlier which agrees with the above")#linebreak()#text(" points in the three coordinates mentioned earlier")#linebreak()#text(" and has 2’s in the remaining coordinate")#linebreak()#text(" forms two lines with these points.")#linebreak()#text(" these lines are empty since if p or any")#linebreak()#text(" of the other four points are in the Moser")#linebreak()#text(" set they form a line with the points")#linebreak()#text(" in the two pairs.")

#text("The two lines were counted in the")#linebreak()#text(" Inequality 2B + C is less than or equal to")#linebreak()#text(" 160 with weight one half. which is lemma three")#linebreak()#text(" we can remove these two lines and count over the remaining lines")#linebreak()#text(" since they are empty 2B +C will not be effected but the 160")#linebreak()#text(" will be reduced to 158. So then we will have")#linebreak()#text(" 2B +C is less than or equal to 158")#linebreak()#text(" but 2B+C is 158 in the case with statistics")#linebreak()#text(" (7,40,78,0,0,0)")

#text("Now this gives 2B+C for the remaining lines is less")#linebreak()#text(" Than or equal to 158 but 2B+C in this case = 158.")#linebreak()#text(" Which means that every one of the remaining lines must have exactly two points.")

#text("We will use this fact in the proof that follows by starting")#linebreak()#text(" with the points a, b, c, d which as noted above are not in the Moser set. Taking lines from the remaining lines that")#linebreak()#text(" contain a, b, c or d and hence have to have the remaining")#linebreak()#text(" point in the line. We will use these points to force a line")#linebreak()#text(" In the set and thus get a contradiction.")

#text("We start with the points a, b, c, d")#linebreak()#text(" mentioned earlier. We are going")#linebreak()#text(" to force the existence of two sets of four points")#linebreak()#text(" similar to a,b,c,d")#linebreak()#text(" They are identical to points of a, b, c, d except")#linebreak()#text(" in one coordinate.")

#text("Let us assume that the points")#linebreak()#text(" Of p have the following form 111xy where")#linebreak()#text(" The fixed coordinates are assumed to be 1")#linebreak()#text(" And in the first three places and x and y are")#linebreak()#text(" The moving coordinates. Then a b c d")#linebreak()#text(" Are of the form 11121, 11123, 11112, 11132.")#linebreak()#text(" The two new sets of similar to a b c d")#linebreak()#text(" Are 13121, 13123, 13112, 13132 and")#linebreak()#text(" 11321, 11323, 11312, 11332 we get that")#linebreak()#text(" they must be in the Moser set by the above")#linebreak()#text(" and looking at lines 1×121, 1×123, 1×112, 1×132")#linebreak()#text(" and 11×21, 11×23, 11×12, 11×32")#linebreak()#text(" where x denotes a coordinate that may take")#linebreak()#text(" any of three values which are")#linebreak()#text(" not in the lines removed and hence by the above")#linebreak()#text(" must have 2 points and hence give us the 8 new")#linebreak()#text(" points mentioned above are in the Moser set.")#linebreak()#text(" Now we note that the points")#linebreak()#text(" 13121, 13123, 13112, 13132")#linebreak()#text(" which by the above must be in the Moser set")#linebreak()#text(" together with 13122 forms a monochromatic line")#linebreak()#text(" in fact two monochromatic lines so the 13122")#linebreak()#text(" must not be in the Moser set.")

#text("Since we already have")#linebreak()#text(" 11122 is not in the set all other points with")#linebreak()#text(" two twos must be in the set now")#linebreak()#text(" look at the points 11321, 11323, 11312, 11332")#linebreak()#text(" which must be in the set")#linebreak()#text(" together with 11322 which must be in the Moser set by the above they")#linebreak()#text(" form a monochromatic line in the Moser set so we get")#linebreak()#text(" a contradiction.")

#text("Similarly we can form 8 such points")#linebreak()#text(" from the points p and a, b, c and d above")#linebreak()#text(" no matter what the value of the the fixed coordinates")#linebreak()#text(" and no matter the position of the fixed coordinates")#linebreak()#text(" and force a monochromatic line in the same way")#linebreak()#text(" and the get a contradiction so the only case remaining")#linebreak()#text(" is: that having statistics (8,39,78,0,0,0) and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36515")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("949. A Moser set for n=5 has 124 points")

#text("A Moser set for n=5 has 124 points.")#linebreak()#text(" If it doesn’t it must have 125 points since we have shown that a contradiction results if there are more than 126 points. Since it has 125 points")#linebreak()#text(" it must have the following statistics:")#linebreak()#text(" • (8,39,78,0,0,0)")

#text("Now look at the 8 points in the Moser set with all coordinates not")#linebreak()#text(" equal to 2 Any set of 5 of these has one pair of")#linebreak()#text(" points that differ in exactly two coordinates")#linebreak()#text(" see the proof of lemma 3 in the Moser wiki.")#linebreak()#text(" We start with 5 of these points and get at least one")#linebreak()#text(" pair that differs in exactly two coordinates if there is more than")#linebreak()#text(" one we choose a pair")#linebreak()#text(" then we remove one of the points the pair and add the")#linebreak()#text(" additional point to replace then we have two pairs. We")#linebreak()#text(" keep doing this until we have four pairs.")

#text("There must be points with exactly 2 coordinates equal to two for each of the coordinates where the pairs differ with coordinates. We have four pairs and only two possible points absent from the Moser set as we see by looking at the statistics. Now each of these points can block at most two of the lines formed by a pair. Since those coordinates constant in a pair must be constant in the point as well so only pairs which agree with the point on these constant coordinates can be blocked and there are only two such pairs for each set of three constant coordinates. They are the following points those which agree on the constant coordinates and have all 1’s or all 3’s on the remaining coordinates or the remaining two points which agree on the constant coordinates. Since we have four pairs and only two points with exactly two 2’s missing from the Moser set they must block the four lines formed by all four pairs. Each point blocks two lines.")

#text("Call these two points ")#mi("p_1")#text(" and ")#mi("p_2")#text(".")#linebreak()#text(" Now from the above")#linebreak()#text(" we have two sets of four points. Each set agrees")#linebreak()#text(" on three coordinates called fixed coordinates and takes on all")#linebreak()#text(" possible values on the remaining two")#linebreak()#text(" coordinates.")

#text("Each set has the potential of forming lines")#linebreak()#text(" with those points with one two, namely those")#linebreak()#text(" points which agree with the four")#linebreak()#text(" points on the three fixed coordinates mentioned")#linebreak()#text(" above and have one two and one arbitrary")#linebreak()#text(" value on the remaining two coordinates")#linebreak()#text(" there are four such points for each set. The points ")#mi("p_1")#text(" and ")#mi("p_2")#text(" mentioned earlier")#linebreak()#text(" each form two lines with one set of four points mentioned above. So we have four such lines. These lines are empty since if ")#mi("p_1")#text(" or ")#mi("p_2")#text(" or any")#linebreak()#text(" of the either set of four points are in the Moser")#linebreak()#text(" set they form a line with the points")#linebreak()#text(" in the four pairs.")

#text("The four lines were counted in the")#linebreak()#text(" Inequality 2B + C is less than or equal to")#linebreak()#text(" 160 with weight one half. which is lemma three")#linebreak()#text(" we can remove these four lines and count over the remaining lines")#linebreak()#text(" since they are empty 2B +C will not be effected but the 160")#linebreak()#text(" will be reduced to 156. So then we will have")#linebreak()#text(" 2B +C is less than or equal to 156")#linebreak()#text(" but 2B+C is 156 in the case with statistics")#linebreak()#text(" (8,39,78,0,0,0)")#linebreak()#text(" Now this gives 2B+C for the remaining lines is less")#linebreak()#text(" Than or equal to 156 but 2B+C in this case = 156.")#linebreak()#text(" Which means that every one of the remaining lines must have exactly two points.")#linebreak()#text(" We will use this fact in the proof that follows by starting")#linebreak()#text(" with one set of four points with exactly one two which are associated with ")#mi("p_1")#text(". Which as noted above are not in the Moser set. Taking lines from the remaining lines that")#linebreak()#text(" contain these and hence have to have the remaining")#linebreak()#text(" point in the line. We will use these points to force a line")#linebreak()#text(" n the set and thus get a contradiction. We will have to do this for two sets of four points because one of the sets formed might be the other set of four points associated with the other two pairs. However this can be dealt with because there are enough degrees of freedom to pick two and in fact three such sets of four points.")#linebreak()#text(" Let us assume that the points")#linebreak()#text(" Of two pairs forming one of the sets noted above have the following form 111xy where")#linebreak()#text(" The fixed coordinates are assumed to be 1")#linebreak()#text(" And in the first three places and x and y are")#linebreak()#text(" The moving coordinates. Then a b c d")#linebreak()#text(" Are of the form 11121, 11123, 11112, 11132.")#linebreak()#text(" The two new sets are")#linebreak()#text(" 13121, 13123, 13112, 13132 and")#linebreak()#text(" 11321, 11323, 11312, 11332 we get that")#linebreak()#text(" they must be in the Moser set by the above")#linebreak()#text(" and looking at lines 1×121, 1×123, 1×112, 1×132")#linebreak()#text(" and 11×21, 11×23, 11×12, 11×32")#linebreak()#text(" where x denotes a coordinate that may take")#linebreak()#text(" any of three values which are")#linebreak()#text(" not in the lines removed and hence by the above")#linebreak()#text(" must have 2 points and hence give us the 8 new")#linebreak()#text(" points mentioned above are in the Moser set unless the exception is as noted above that one of the two groups of 4 is the group of four points associated with the other set formed by the points of the other two pairs. In any case we will have one set of four points out of the two sets of four points that must be in the Moser set.")#linebreak()#text(" Now we note that these points without loss of generality can 13121, 13123, 13112, 13132. The proof is essentially the same for both cases.")#linebreak()#text(" These points by the above must be in the Moser set.")#linebreak()#text(" together with 13122 forms a line in fact two lines. Now if 13122 is not in the Moser set it must be one of ")#mi("p_1")#text(" or ")#mi("p_2")#text(" however by construction it cannot be ")#mi("p_1")#text(" and if it were ")#mi("p_2")#text(" then the set of four points 13121, 13123, 13112, 13132 would be the second set formed by the second set of two pairs associated with $platex p_2$ but we have chosen these points so that does not occur so it is in the Moser set.")#linebreak()#text(" So we have a line in the Moser set so we have a contradiction.")

#text("Similarly we can form 8 such points")#linebreak()#text(" from the four pairs above")#linebreak()#text(" no matter what the value of the fixed coordinates")#linebreak()#text(" and no matter the position of the fixed coordinates")#linebreak()#text(" and force a monochromatic line in the same way")#linebreak()#text(" and the get a contradiction so the only case remaining")#linebreak()#text(" is: that having statistics (8,39,78,0,0,0) and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36519")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("950. Moser(3)")

#text("Kristal, this is great! I haven’t yet had time to go through the arguments and wikify them but I will get round to it at some point.")

#text("The next step will be to try to reduce the dependence on computer data. I think the classification of 3D extremals will help out a lot here. There are some very specific facts we need from the 4D data (e.g. no 41+ points sets with d >= 4, etc.) and it may well be that the inequalities coming from the 3D theory are enough for this. This should be checkable with Maple, and then ")#emph[#text("a posteriori")]#text(" we can then write down a human proof.")

#text("Incidentally, I have submitted ")#mi("c^{\\prime\\prime}_n")#text(" to the OEIS at")

#link("http://www.research.att.com/~njas/sequences/A157795")[#text("http://www.research.att.com/~njas/sequences/A157795")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36521")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("951. Moser(3)")

#text("I’ve put Kristal’s arguments on the wiki. It would be good for others to go through the proof and keep an eye out for any corrections or simplifications. The points where the n=4 data is relied on should be inspected particularly carefully, to see if alternate arguments are available.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36522")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("c’_7")#linebreak()#text(" The 978 point solution:")#linebreak()#text(" ")#link("http://twofoldgaze.wordpress.com/2009/03/10/978-element-solution/")[#text("http://twofoldgaze.wordpress.com/2009/03/10/978-element-solution/")]

#text("c’_6")#linebreak()#text(" ")#link("http://twofoldgaze.wordpress.com/2009/03/10/353-element-solution/")[#text("http://twofoldgaze.wordpress.com/2009/03/10/353-element-solution/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36523")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("953.")

#text("My program is still running for the next few hours so I can’t access it yet but it seems I just found a 985 solution for c’_7.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f9d692058b3170db4792107e161953922c74174c9aedb54dc7e8573cee314db-f8ae0f47bdb439ebcfb520a027a99b4623d616ede2f24bfeabe8b0a49a1ced27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36528")[#strong[#text("Kareem")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("954. (It’s hard to keep these posting numbers straight when sleep deprived.)")

#text("My largest solution for c_7 is 988. One more caveat, the algorithm I used to display the long form solutions has a bug in it. I will correct it soon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f9d692058b3170db4792107e161953922c74174c9aedb54dc7e8573cee314db-f8ae0f47bdb439ebcfb520a027a99b4623d616ede2f24bfeabe8b0a49a1ced27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36529")[#strong[#text("Kareem")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("955.")

#text("The term c_7 in my last comment should be c’_7.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36531")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("956.")

#text("The good news is that I corrected the bug and the solutions on my blog are correct now. I updated my 978 solution to a 988 solution. There is some bad news unfortunately. The long form solutions that I provided for c_n are probably all wrong in the same way. So stick with the short form solutions for now. For a quick fix, if things look wrong just shift the element to the one just below it so 113 -> 112 and so on. I will fix it as soon as I can.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36533")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("957.")

#text("Terry:")

#text("I thought your suggestion of solution seeding was a great idea so I implemented it using a stock of better than 972 solutions. Then I spent some time visualizing the solutions and I realize they have patterns. So I checked to see what parts of the chromosomes are conserved between solutions and that seems to be an effective form of solution seeding also.")

#link("http://twofoldgaze.files.wordpress.com/2009/03/visualization1.pdf")[#text("Click to access visualization1.pdf")]

#link("http://twofoldgaze.files.wordpress.com/2009/03/visualization2.pdf")[#text("Click to access visualization2.pdf")]

#text("guest: I thought a little more about your comment and decided to give it a more rigorous evaluation. I spent some time with a notepad and a pencil carefully noting the effectiveness of crossover. Paradoxically, without mutation crossover with a stocastic sort of greedy algorithm seemed to improve the solutions 5% of the time which was approximately the same as not doing crosover. However, when I implement crossover with mutation (with an underlying greedy algorithm to ensure no missed opportunities), 20% of the time crossover improves a solution versus 15% for mutation. Something about mutation seems to be boosting the effectiveness of crossover. (When I say it improves a solution, I mean a random solution in the population is improved, not necessarily the best solution.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36539")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2009")])]

#text("958. Moser(3), dim-5")

#text("There is one step I am not sure of. The proof of Lemma 7 relies on slices with non-zero d having scores of 59 7/12 or below. But there are two examples in the list, with d=3 and d=2, with higher scores than that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36542")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2009")])]

#text("959. 5D Moser(3)")

#text("Thanks Michael. Fortunately one can rule out the d>1 cases by observing from Lemma 7 that there is a way to cut the cube so that the side slices have at most one C-point missing (i.e. one side has c=24 and the other has c at least 23) and no D-points, and hence the middle slice has at most one D-point. I’ve updated the wiki appropriately.")

#text("There is also an alternate approach from Cantwell.912, Cantwell.913. Both approaches rely to some extent on the 4D statistics. It would be good to have an alternate proof of this fact which relied less on these statistics (e.g. relying more on the 3D inequalities, which are human-verifiable).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36559")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2009")])]

#text("5D Moser(3)")

#text("Congratulations to Kristal on doing three quarters of the proof, and for completing the proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36561")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2009")])]

#text("Yes, congratulations! It looks like this project is achieving many of its intended objectives; by a coincidence of timing, the same is true of the other half of the project at Gowers’ blog. There is now a retrospective discussion there at")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://gowers.wordpress.com/2009/03/10/polymath1-and-open-collaborative-mathematics/")[#text("Polymath1 and open collaborative mathematics")]
]

#text("; I think some feedback from our side of the project would be valuable.")

#text("There are a few loose ends to tie up, I think: the proof of ")#mi("c^{\\prime}_6=124")#text(" could be simplified, with less of a dependence on computer data; and it would be interesting to see how the genetic algorithm performs for some other numbers, whether there are any cheap ways to improve its performance, and what an analysis of its solutions can tell us about what ")#mi("c^{\\prime}_7")#text(" (say) might look like. There’s also the hyperoptimistic conjecture to look at; we have some computer data now but our human-level understanding of the problem is fairly primitive still. But I think we are in general moving to the “endgame” and should begin thinking about issues such as how to write things up (I plan to comment on this over at Tim’s blog in a bit).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fac1eeb1dd8f9455228833f962802a575b4ef16d9cb91303ec5db915305f23ad-c546abf6e77cccbfaec3e5e60470ea1b73ad37d1d53351642ae76a65c77d98c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Link Starbureiy")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36571")[#strong[#text("Link Starbureiy")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2009")])]

#text("Congratulations to all of you on a job well done over the past weeks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36575")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2009")])]

#text("961. HOC")#linebreak()#text(" I have done some more work on the weighted problem in the HOC and I found the results interesting.")

#text("I have not been able to prove that I have optimal values for n greater than 5, but for n=6 there is a unique solution of weight 15, which is the size of the optimal solution for Fujimura’s problem. Likewise there is a unique solution of weight 18 for n=7. The solutions are here")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/solutions-n=6-k=3-HOC")[#text("http://abel.math.umu.se/~klasm/solutions-n=6-k=3-HOC")]#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/solutions-n=7-k=3-HOC")[#text("http://abel.math.umu.se/~klasm/solutions-n=7-k=3-HOC")]#linebreak()#text(" In order to find these solutions I have specified that the program should look for all solutions of this exact weight. For n=7 the program find a solution and then prove that it is the only one in 4 seconds. For n=8 the integer program suddenly gets a lot harder to solve and the program has not yet found a solution.")

#text("The tricky thing is that for this problem it is much harder to reduce the upper bound for the integer program ( I have multiplied all weight in the program by n! to get integer weights).")#linebreak()#text(" For n=6 I expect to soon have reduced the upper bound on the optimal solutions to strictly less than 16, again having to use a linux cluster. However, since we don’t know that the optimum for this problem is an integer the upper bound does not imply that the unique solution of weight 15 is the optimum, and reducing the bound to 15 seems too hard for my current program.")

#text("There is an interesting contrast here. For Fujimiura’s problem the number of optimal solutions seems to grow, on the average, with n, but if the solutions for n=6,7 for the weighted problem are optimal then this problem has a unique optimal solution for n=4,5,6,7")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36576")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2009")])]

#text("And congratulations to Kristal for proving an upper bound which was too hard for my program!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6aee136dbc4c0bc79c68cbcf7d17f526cce6319a8e6e98ec412127af7d47f3a8-376867c974a73315b8452903740c9fc3635e43fe0fc86f758644077298bb8a0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Elsholtz")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36577")[#strong[#text("Christian Elsholtz")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2009")])]

#text("962 Moser")

#text("Congratulations to Kristal!!")

#text("Here is a comment on the symmetry of the Moser sets.")#linebreak()#text(" The Moser sets in dimension 5, with 124 points:")#linebreak()#text(" The statistics of all 243 points is: (32,80,80,40,10,1)")#linebreak()#text(" The statistics of the known examples is: (4,40,80,0,0)")

#text("For each of the 40 and 80 points the antipodal point is included.")#linebreak()#text(" For the 4 points with no 2 there are example with no antipodal pairs, and there is")#linebreak()#text(" an example where 2 of the 4 points are antipodal, the other 2 are not.")

#text("To the best of my knowledge no symmetric solution (with regard to the")#linebreak()#text(" centre) is known to exist.")#linebreak()#text(" If the 124 solutions should all come from the same 40+80 points,")#linebreak()#text(" then there are no 4 symmetric points.")

#text("Those examples in dimension 6 (344 points) and 7 (960 points), that were")#linebreak()#text(" implicitly in Chvatal’s paper, Canadian Math Bulletin, Vol 15, 1972, 19-21.")#linebreak()#text(" “Remarks on a problem of Moser”, based on (elementary) bounds from coding")#linebreak()#text(" theory, contained some full Behrend spheres,")#linebreak()#text(" and some rather empty ones, so were in a similar spirit to the one above.")

#text("The better examples by Kareem Carr")#linebreak()#text(" 353 points, have distribution")#linebreak()#text(" (22, 66, 165, 100, 0, 0 0)")#linebreak()#text(" out of")#linebreak()#text(" (64, 192, 240, 160, 60, 12, 1) for all 729 points, so have no almost full sphere.")

#text("The study of antipodal points of the 353 example on Kareems webpage gives")#linebreak()#text(" 65 pairs of antipodal points")#linebreak()#text(" 45 of these with two 2’s, and 20 with three 2’s.")

#text("For the 988 example in dimension 7 on Kareem’s webpage with distribution:")#linebreak()#text(" (36, 65, 336, 551, 0, 0, 0, 0)")#linebreak()#text(" compared to (for all 2187 points)")#linebreak()#text(" (128, 448, 672, 560, 280, 84, 14, 1)")#linebreak()#text(" let us make the following observations:")#linebreak()#text(" 1) The sphere with three 2’s is quite full.")#linebreak()#text(" 2) there are 272 antipodal pairs,")#linebreak()#text(" 271 of these with three 2’s, and one pair with one 2.")#linebreak()#text(" (Of course there must be many antipodal pairs, if a sphere is almost")#linebreak()#text(" full).")

#text("Perhaps this gives a heuristical clue how good examples in some further")#linebreak()#text(" medium sized dimensions look like.")#linebreak()#text(" One almost full sphere, with (dimension/2) 2’s and in the other")#linebreak()#text(" partial spheres:")#linebreak()#text(" if point x occurs, then the antipodal does not occur.")

#text("Remarkably, the behaviour in dimension (2 to 5), 6 and now 7 are so")#linebreak()#text(" different…")

#text("In any case, perhaps this helps finding good “seeds” for the algorithm?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36587")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2009")])]

#text("963. Christian Elsholtz:")

#text("If you will give me a few days to make them available, I have 25 other solutions of length 353 that might be interesting. Perhaps they have different properties.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36588")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2009")])]

#text("964. Dimension transition in Moser(3)")

#text("Two comments… it seems that the best solutions in 6D and 7D we have so far are avoiding all but the first four Behrend spheres (the strings with 0, 1, 2, or 3 twos). To speed up the GA, perhaps we could simply ")#emph[#text("assume")]#text(" that all other spheres are empty and remove those chromosomes from the genotype. (I believe this will cut down the number of lines by a significant factor – quite a few lines pass through the inner spheres).")

#text("The second comment is that I think one reason for the transition is that in 5D and lower, the optimal solutions have density >1/2, and in 6D and higher, the optimal solutions have density <1/2. The thing is that the linear inequalities we have on sphere densities cannot rule out the possibility that every sphere has density 1/2 or less. Consider for instance the 3D case, in which the full set [3]^3 has statistics (8,12,6,1), so a mythical “half-density” Moser set would have statistics (4,6,3,0.5). Of course this is not possible, however the statistics (4,6,4,0) and (4,6,2,1) are possible, and so from the perspective of linear inequalities, nothing is preventing half-densities everywhere. I don’t know whether the same is true in 4D: half of (16,32,24,8,1) is (8,16,12,4,0.5), and I don’t know whether this is attainable as a convex combination of Moser 4D statistics. But this phenomenon may help explain the tendency for the higher D statistics to fill out about half of every sphere. (This also matches with the linear programming I did in 944.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36590")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2009")])]

#text("965. HOC")

#text("I checked the solution in Markström.961 of n=6, which is the same as the equal slice solution 510, 420, 330, 240, 150, 501, 402, 303, 204, 105, 015, 024, 033, 042, 051. (It’s all combinations of 1 & 2, 2 & 3, and 1 & 3.)")

#text("This is the same solution as the general bound for Fujimura of that size.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36591")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2009")])]

#text("966. HOC")

#text("A quick scan indicates the same thing applies to n=7.")

#text("Klas, look for a solution of 21 on n=8 and see if you get one solution just like the general bound for Fujimura. If so I am guessing the HOC is false.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36594")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2009")])]

#text("Thank you to everyone for the congratulations! My congratulations to everyone here and also those who worked on the other half of this project. I will be working on proving there are no sets with 41 or more points with d greater than or equal to 4.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36597")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2009")])]

#text("967. Terry:")

#text("“Two comments… it seems that the best solutions in 6D and 7D we have so far are avoiding all but the first four Behrend spheres (the strings with 0, 1, 2, or 3 twos). ”")

#text("It turns out I had already been doing something like this when I tried to preserve the conserved regions between solutions. I had been looking at the conserved regions set to zero and the ones set to one both together and singly. I noticed that the conserved zero region (points consistently left out) turned out to be of length 379 (which I didn’t check by hand) but is the same size as the set of points with strings with four or more 2’s.")

#text("In the same spirit, I had a region of conserved one’s which turns out to contain 411 points. Perhaps someone else will see the pattern.")

#text("{13, 31, 37, 39, 41, 43, 49, 67, 85, 91, 93, 95, 97, 103, 111, 117, 119, 123, 125, 127, 133, 139, 145, 147, 149, 151, 157, 175, 193, 199, 201, 203, 211, 229, 247, 253, 255, 257, 259, 273, 275, 277, 281, 285, 287, 289, 291, 295, 301, 307, 311, 313, 319, 325, 327, 331, 333, 335, 339, 341, 343, 345, 347, 349, 353, 369, 371, 375, 379, 383, 385, 387, 389, 393, 395, 397, 399, 401, 409, 415, 417, 419, 421, 433, 437, 443, 447, 449, 451, 453, 455, 457, 469, 471, 473, 475, 481, 499, 517, 523, 525, 527, 535, 553, 571, 577, 579, 581, 583, 599, 601, 603, 605, 609, 611, 613, 615, 617, 619, 631, 635, 643, 661, 679, 685, 687, 689, 691, 697, 733, 739, 745, 751, 757, 761, 773, 775, 781, 787, 793, 797, 799, 805, 813, 815, 819, 825, 829, 833, 837, 839, 845, 855, 861, 865, 867, 869, 871, 873, 879, 881, 889, 903, 905, 907, 913, 921, 923, 925, 927, 933, 937, 939, 941, 949, 955, 957, 959, 961, 967, 981, 983, 987, 989, 991, 993, 995, 999, 1001, 1007, 1017, 1019, 1023, 1031, 1035, 1037, 1047, 1049, 1055, 1059, 1061, 1071, 1077, 1109, 1115, 1125, 1127, 1133, 1135, 1145, 1149, 1151, 1155, 1157, 1159, 1181, 1185, 1189, 1191, 1193, 1195, 1197, 1199, 1203, 1207, 1211, 1225, 1227, 1229, 1231, 1237, 1243, 1247, 1249, 1251, 1253, 1261, 1263, 1265, 1281, 1297, 1299, 1301, 1305, 1307, 1315, 1317, 1321, 1325, 1341, 1347, 1349, 1351, 1353, 1355, 1357, 1365, 1367, 1369, 1371, 1373, 1375, 1381, 1387, 1389, 1399, 1405, 1407, 1409, 1411, 1415, 1419, 1421, 1423, 1425, 1427, 1435, 1441, 1443, 1447, 1453, 1471, 1489, 1495, 1497, 1525, 1543, 1549, 1551, 1553, 1555, 1561, 1567, 1569, 1571, 1573, 1575, 1577, 1585, 1587, 1589, 1597, 1603, 1605, 1607, 1633, 1651, 1657, 1659, 1661, 1663, 1669, 1687, 1705, 1711, 1713, 1715, 1729, 1733, 1735, 1737, 1739, 1745, 1747, 1749, 1751, 1753, 1759, 1765, 1767, 1769, 1777, 1783, 1785, 1787, 1791, 1797, 1801, 1803, 1805, 1807, 1809, 1811, 1817, 1827, 1829, 1833, 1835, 1837, 1841, 1843, 1845, 1847, 1853, 1855, 1857, 1859, 1861, 1875, 1877, 1879, 1885, 1891, 1893, 1895, 1897, 1899, 1901, 1905, 1911, 1915, 1921, 1927, 1931, 1933, 1939, 1981, 1983, 1985, 1987, 1993, 2011, 2029, 2035, 2037, 2039, 2047, 2053, 2055, 2057, 2059, 2061, 2063, 2067, 2069, 2071, 2073, 2075, 2077, 2083, 2091, 2093, 2095, 2101, 2137, 2143, 2145, 2147, 2149, 2155, 2173}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6aee136dbc4c0bc79c68cbcf7d17f526cce6319a8e6e98ec412127af7d47f3a8-376867c974a73315b8452903740c9fc3635e43fe0fc86f758644077298bb8a0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Elsholtz")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36598")[#strong[#text("Christian Elsholtz")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2009")])]

#text("the 411 points above all have 3 two’s.")#linebreak()#text(" Otherwise coordinate stastistics alone will not help, since it contains for example the points")#linebreak()#text(" {2, 2, 2, 1, 1, 1, 3}, {2, 2, 2, 1, 1, 3, 1}, {2, 2, 2, 1, 1, 3, 3}, {2, 2, 2, 1, 3, 1, 1},")#linebreak()#text(" {2, 2, 2, 1, 3, 3, 1}, {2, 2, 2, 3, 1, 1, 3}, {2, 2, 2, 3, 1, 3, 3}, {2, 2, 2, 3, 3, 1, 1}, {2, 2, 2, 3, 3, 1, 3},")#linebreak()#text(" {2, 2, 2, 3, 3, 3, 3} etc.")#linebreak()#text(" that is some but not all permutations of 2221113.")#linebreak()#text(" It also pairs of points with Hamming distance 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36599")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2009")])]

#text("969. Integer programming")

#text("I discovered an integer programming package (Optimization) on Maple 12, and gave it a whirl, see")

#link("http://michaelnielsen.org/polymath1/index.php?title=Maple_calculations")[#text("http://michaelnielsen.org/polymath1/index.php?title=Maple_calculations")]

#text("for details. I reconfirmed the fact that by throwing in all the linear inequalities we already know about, we can get ")#mi("c^{\\prime}_6 \\leq 364")#text(". The extremal statistics are")

#text("(31,94,126,83,23,7,0). (*)")

#text("[In comparison, Kareem’s 353-point solution has statistics (22, 66, 165, 100, 0, 0 0).]")

#text("If we can find some reason why the statistics (*) are impossible, this should eventually be convertible to a linear inequality which I can then add to the integer program to improve the bound. Hopefully we can iterate this computer+human procedure to get the bounds to be closer to each other.")

#text("If I assume g=1 (i.e. the point 222222 is in the set), then the upper bound improves substantially to 355, with extremal (24,96,120,80,30,4,1). If instead I assume e=f=g=0 as in Kareem’s example, the upper bound similarly improves to 356, with extremal (24,72,180,80,0,0,0).")

#text("The 7D computations were disappointing; the best upper bound I could get was 1092, i.e. 3 times the current 6D bound.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36600")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2009")])]

#text("770. Linear programming")

#text("There are some more inequalities available. For instance in 4D, we have ")#mi("a+b+c+d+e \\leq 43")#text(", but when e=1, we have the better estimate ")#mi("a+b+c+d+e \\leq 39")#text(" (which I also verified by linear programming). Thus we in fact have ")#mi("a+b+c+d+5e \\leq 43")#text(". Similarly, the ")#mi("c^{\\prime}_5=124")#text(" result gives ")#mi("a+b+c+d+e+f \\leq 124")#text(" in 5D, but when f=1 the linear inequalities improve this to 119, thus ")#mi("a+b+c+d+e+6f \\leq 124")#text(".")

#text("I inserted this into the integer program. Sadly, this did not improve the upper bound ")#mi("c^{\\prime}_6 \\leq 364")#text(", but it did give a prettier extremiser, namely (32,96,120,80,30,6,0), i.e. every Behrend sphere except for the last one is filled with density exactly 1/2. Also, this argument managed to improve the bound for ")#mi("c^{\\prime}_7")#text(" from 1092 to 1086.")

#text("The wiki page is adjusted to reflect these improvements, of course.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36601")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2009")])]

#text("771. Linear programming")

#text("I found a 4D inequality which was inconsistent with the above 1/2-density scenario, and it gave some good results (basically it is useful for eliminating scenarios in which d, e, etc. are large).")

#text("It exploits the fact that the 41+ 4D solutions have small d and e. Indeed, the data shows that e=0 and a+b+c+d+e+d/2 <= 43 for such solutions. Meanwhile, linear programming shows that for 40- point solutions, one has a+b+c+d+e+d/2 <= 43, and furthermore a+b+c+d+e+d/2 <= 40.5 if e=0. We conclude that a+b+c+d+e+d/2+5e/2 <= 43. Inserting this into the integer programming machine gives significant improvements, namely ")#mi("c^{\\prime}_6 \\leq 360")#text(" and ")#mi("c^{\\prime}_7 \\leq 1075")#text(".")

#text("To proceed further, one needs to find a reason why the ")#mi("c^{\\prime}_6")#text(" extremiser statistics, which happen to be (29,87,134,97,8,5,0), are not attainable. It may also be useful to figure out why the e=f=g=0 extremiser statistics (24, 72, 180, 80, 0, 0, 0) are not attainable; the densities here are quite clean, namely (3/8, 3/8, 3/4, 1/2, 0, 0, 0).")

#text("Wiki page updated as before.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36602")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2009")])]

#text("Christian Elsholtz:")

#text("Interesting points. The one thing I would add is that the 411 are probably not perfect as they are based on a guess of the better solutions found so far. Although, I realize I should have taken them more seriously as I was very surprised to see that the 379 zero points conserved matched so well with the Behrend spheres.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36609")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2009")])]

#text("972 HOC")

#text("Jason, I ran the program for n=8 and solutions of weight 21. The program quickly found a solution and in a few minuets proved that it is the unique solutions of that weight.")#linebreak()#text(" The solution is here")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/solutions-n=8-k=3-HOC-21")[#text("http://abel.math.umu.se/~klasm/solutions-n=8-k=3-HOC-21")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36614")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2009")])]

#text("973. A semi-optimist conjecture")

#text("Thanks Klas! Now I can say…")

#text("For ")#mi("n > 2")#text(", ")#mi("c^\\mu_n = 3(n-1)")

#text("This implies at least the ")#link("http://gowers.wordpress.com/2009/02/23/brief-review-of-polymath1/#comment-2405")[#text("optimist conjecture")]#text(" (if not the original version of the HOC, which I guess was an inequality?) which implies DHJ (3).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36617")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2009")])]

#text("974. Linear programming")

#text("I made a data entry error causing the bounds announced earlier to be off a little bit. Currently I can show ")#mi("c^{\\prime}_6 \\leq 361")#text(" and ")#mi("c^{\\prime}_7 \\leq 1078")#text(", with the 361 bound improving just to 360 if one assumes e=f=g=0, and to 355 if one assumes g=1. The 361 extremiser is (28,80,160,80,10,3,0).")

#text("Jason, I am not sure I understand what you are getting at here. Every solution to Fujimura gives a solution to weighted DHJ, so ")#mi("c^\\mu_n")#text(" always has to be at least as large as ")#mi("\\overline{c}^\\mu_n")#text("; in particular, ")#mi("c^\\mu_8")#text(" has to be at least ")#mi("\\overline{c}^\\mu_8=22")#text(".")

#text("Actually, this now confuses me quite a bit. Back in 923, 925, Klas found 72 22-point triangle-free sets in n=8. This will imply the existence of many 21-point triangle-free sets also, simply by removing one point from these examples. One can convert this to having many line-free sets with weight 21 in 8D, but the integer program tells us that there is only a unique solution… so something is strange somewhere.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36623")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2009")])]

#text("975. HOC")

#text("Oh yes, even though the weights of the individual points represented by the edges of the lattice are larger, each complete slice has a weight that adds up to 1. This *is* really odd.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36624")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2009")])]

#text("976. Moser set n=4")

#text("Here I am proving a partial result. Eventually I want to get the following:")#linebreak()#text(" If a Moser set for n=4 has 4 or more points with three 2’s it has less than 41 points.")

#text("If a Moser set for n=4 has six or more points with three 2’s it must have less than 41 points. We note that there cannot be a point with four 2’s as then we would have 39 points. We have 5 points with exactly three 2’s and one coordinate not equal to 2. That gives 5 values not equal to 2 and four coordinates one coordinate must have the coordinate value not equal to 2 from 2 of the five points. One value must be three the other one. We slice at this point and get two cubes with the center point filled which by the n=3 section of the wiki on Moser sets must have 13 points or less. Since there are six or more points with three 2’s the center slice must have the remaining four or more. Now if we have 41 or more points it must have a center slice equal to 15 points or more. However by the Pareto-optimal statistics in the section n=3 of the wiki we see that a cube with c greater than three can have value at most 14. So there at most 13+14+13=40 points and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36625")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2009")])]

#text("977. HOC")#linebreak()#text(" This got me really worried too so I have been checking things and I think I have found the problem.")

#text("In order to get an integer problem with integer coefficients I multiplied all weights with n!. For small n this is perfectly fine but for the larger n this will actually cause the bound used to specify a solution of a given weight to be too large for the datatype the linear programing solver uses for coefficients.")

#text("So I created formally correct input files for the solver, but the weights are to large for the solver I have been using. This means that the claimed uniqueness in the weighted problem for n greater than 5 is meaningless.")

#text("For the other problems all weights and coefficients are 0/1 so they do not suffer from this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36634")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2009")])]

#text("978. Making c^mu_n tractable")

#text("This is starting to get frustrating to work with in that we have no good way to approach c^mu_n by hand. Is there at least a conjecture we can make here that if true which might help us get a handle on it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36636")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2009")])]

#text("979. ")#mi("c^\\mu_n")

#text("Well, we may have to go back to the very small values of n. For instance, I can work out ")#mi("c^\\mu_2 \\leq 4")#text(" by hand, but already ")#mi("c^\\mu_3 \\leq 6")#text(" is rather challenging. My guess is that we should be looking at the slice densities ")#tao-math("\\alpha_{a,b,c} := \\left|A \\cap \\Gamma_{a,b,c}\\right|/\\left|\\Gamma_{a,b,c}\\right|", block: false)#text(" of the line-free set A, and finding linear relations between them, perhaps to throw into an integer program to maximise ")#mi("c^\\mu_n")#text(", which is the maximal sum of all the ")#mi("\\alpha_{a,b,c}")#text(". (This of course sounds a lot like what Klas is doing, but this will be an integer program on ")#mi("\\binom{(n+1)(n+2)}{2}")#text(" variables rather than ")#mi("3^n")#text(" variables, and so has a chance of being scaled up to reasonable values of n, such as 6 or 7.) We actually did a little bit of this way back in the 200 thread (see e.g. Jakobsen.210, Jakobsen.216, Tao.219, Peake.220).")

#text("We know that given any equilateral triangle, the sum of the ")#mi("\\alpha_{a,b,c}")#text(" in that triangle adds up to at most 2. This should already give some bound; after finding that bound, we can see how to improve it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6aee136dbc4c0bc79c68cbcf7d17f526cce6319a8e6e98ec412127af7d47f3a8-376867c974a73315b8452903740c9fc3635e43fe0fc86f758644077298bb8a0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Elsholtz")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36652")[#strong[#text("Christian Elsholtz")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2009")])]

#text("980 Linear Programming.")

#text("In 770 Terry described that improvements on bounds of type")#linebreak()#text(" 4D: ")#mi("a+b+c+d+5e \\leq 43")#text(" etc help improving bounds in dimension 7.")

#text("I expect, that for In dimension 4, with e=1 a much better result holds.")#linebreak()#text(" In 778 KS Chua mentioned that the best example of this type he found had")#linebreak()#text(" 36 points, (and his programme found a 124 point example in 5D).")

#text("Also, those programmes that classified the 43 extremisers could hopefully")#linebreak()#text(" be adapted to verify the maximum number of points in 4D.")

#text("If 36 is the maximum, this gives")#linebreak()#text(" ")#mi("a+b+c+d+8e \\leq 43")

#text("Similar, for 5D I would expect a considerable gain over the currently used")#linebreak()#text(" ")#mi("a+b+c+d+e+6f \\leq 124")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36654")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2009")])]

#text("981 Linear programming")

#text("Christian: yes, that’s a great idea. Inserting the improvements to ")#mi("a+b+c+d+e \\leq 43")#text(" that we already had were already instrumental in killing off the large e (or large f,g) counterexamples in 6D, 7D, and improved their bounds significantly (from 164 to 161 in 3D, and from 1092 to 1078 in 3D). Further such improved estimates would undoubtedly do better, and perhaps even eradicate e, f, g entirely in 6D (note that Kareem’s examples have e=f=g=0).")

#text("Another inequality that could stand improving is the inequality ")#mi("a+b+c+d+e + d/2 + 5e/2 \\leq 43")#text(" in 4D. For e=0 this comes by inspection of the 41+ point data (in particular, the fact that d is so small in this regime) plus use of the existing 3D inequalities for 40- point data (somewhat analogous to Kristal’s 976). For e=1 I am relying purely on the linear programming from the 3D inequalities. Getting a better upper bound for a+b+c+d+e+d/2 in the e=1 case (currently it is 40.5) would help.")

#text("I quite like this approach as it wastes as little as possible: any “excess” estimate one gets in, say, 4D, can be recycled into improvements in 5D and higher.")

#text("This may well be the way to go for the HOC. For n=2, say, we should be able to classify the Pareto-optimal and extremal statistics for the slice densities ")#mi("\\alpha_{a,b,c}")#text(", giving linear inequalities. These inequalities then imply analogues in 3D, which we could then integer program and apply further combinatorial analysis to beget further linear inequalities to use in 4D, and so on and so forth.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36655")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2009")])]

#text("982 Moser(3) Diagonal cubes in 6D")

#text("The 6D cube contains 120 3D cubes of the form xxyyzz. The two xs take the values (11,22,33) or (13,22,31), and the same with the two ys and two zs.")

#text("Each point in the 3D cube contains 0,2,4 or 6 twos, so this introduces a set of new inequalities connecting a,c,e and g.")

#text("These inequalities are easiest to express in the density notation ")#mi("\\alpha_i")#text(". One of the inequalities for the simple 3D cube is ")#mi("8\\alpha_0 + 6\\alpha_1 + 6\\alpha_2 + 2\\alpha_3 \\le 11")#text(". The corresponding inequality for these diagonal cubes is ")#mi("8\\alpha_0 + 6\\alpha_2 + 6\\alpha_4 + 2\\alpha_6 \\le 11")#text(".")

#text("I don’t know whether these inequalities provide new information. Certainly the solution ")#mi("\\alpha_i = 1/2")#text(", which satisfies all the old 3D inequalities, satisfies the new ones too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36656")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2009")])]

#text("983 6D Moser(3) diagonal cubes")

#text("Thanks Michael! Actually I had put those cubes in the linear program already (it’s the term op(subs([b=c,c=e,d=g],X3)) in the definition of X6) but I had forgotten to tell people about this. But yes, it does help. Without it, the bound on ")#mi("c^{\\prime}_6")#text(" stays where it as at 361, but the bound on ")#mi("c^{\\prime}_6")#text(" under the additional assumption g=1 worsens from 355 to 358. (It makes sense that this new inequality is really of use when g is non-zero.) This cuts down the inequality a+b+c+d+e+f+7g <= 361 to a+b+c+d+e+f+4g <= 361, which ends up worsening the ")#mi("c^{\\prime}_7")#text(" bound from 1078 to 1079.")

#text("There are also cubes in which each wildcard occurs a different number of times (e.g. 1xyy23) but I was unable to figure out how to use those “skew” cubes to generate more inequalities.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36657")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2009")])]

#text("984. I don’t see anywhere anybody taking up question II.A: what exactly is the bound that comes out of the Behrend/Elkin construction?")

#text("Elkin’s bound is ")#mi("r_3(n) > C n (\\log n)^{1/4} 2^{-\\sqrt{8 \\log_2 n}}")#text(". He stated it just for n of a particular form, but it works for all n. The second ingredient is that ")#mi("\\binom{n}{a,b,c}")#text(", this size of ")#mi("\\Gamma_{a,b,c}")#text(" is at least ")#mi("C 3^n/n")#text(" provided that all of a, b, c, are between ")#mi("n/3- \\sqrt {n}")#text(" and ")#mi("n/3+\\sqrt {n}")#text(". The final ingredient is that if ")#mi("x_i")#text(" (with ")#mi("1\\leq i \\leq 3")#text(") are a line and ")#mi("x_i")#text(" is in ")#mi("\\Gamma_{a_i,b_i,c_i}")#text(", then ")#mi("c_i-a_i")#text(" are a (possibly constant) arithmetic progression of integers.")

#text("Now to put these together. Let R be a largest set of integers without 3-term APs that is contained in ")#mi("(-\\sqrt{n}/2,\\sqrt{n}/2)")#text(". The set ")#mi("A = \\bigcup_{c-n/3 \\in R} \\Gamma_{n/3,b,c}")#text(" has no lines, and has size at least ")#mi("\\sum_{c-n/3\\in R} \\binom{n}{n/3,b,c}")#text(". For each element r of R, we can take ")#mi("c=r+n/3")#text(" and ")#mi("b=n/3-r")#text(", in which case ")#mi("\\binom{n}{n/3,b,c} > C 3^n /n")#text(". The size of A is then at least ")#mi("C r_3(\\sqrt{n}) \\cdot C 3^n/n")#text(", which is at least ")#mi("C (\\log n)^{1/4} \\exp_3(n- \\alpha \\sqrt{\\log_3 n})")#text(", and ")#mi("\\alpha=2\\sqrt{\\log_3(2)}")#text(". Here, ")#mi("\\exp_3(x)")#text(" is shorthand for ")#mi("3^x")#text(".")

#text("As I write this, it doesn’t feel very optimal to set ")#mi("a=n/3")#text(", instead of letting it vary at least a little. In particular, I am unpleased by the asymmetry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36659")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2009")])]

#text("985. c^{\\mu}_3=6")

#text("If we have all")#linebreak()#text(" Three points of the form aaa removed")#linebreak()#text(" Then the remaining points have value 7 and")#linebreak()#text(" We have covered all lines that have any set of moving coordinates")#linebreak()#text(" And all constant points equal to one value this leaves")#linebreak()#text(" The lines xab a,b not equal. Each point of the set")#linebreak()#text(" abc covers three of these lines the entire set covers each of these lines")#linebreak()#text(" there is no duplication the only alternative is to remove a point")#linebreak()#text(" abc and cover the lines with points of the form aab which have")#linebreak()#text(" a higher weight and only cover two lines each this would lower the weight")#linebreak()#text(" so the maximum weight occurs when all of abc is omitted along with")#linebreak()#text(" the three points aaa and that weight is 6.")

#text("If we have only two points removed of the form xxx then")#linebreak()#text(" The weight is at most 8 say the point not removed is 222")#linebreak()#text(" Then we must cover the lines xx2 and x22 we have three six such")#linebreak()#text(" Lines and all the xx2 must be covered one at a time by either 112")#linebreak()#text(" Or 332 the x22 must be covered one at a time by 322 or 122")#linebreak()#text(" These points must be removed and the that lowers the weight")#linebreak()#text(" To 8 – 3*(2/6) – 3*(2/6) = 6 again we have c^{\\mu} must be less than 6")

#text("If we have one point removed say 111 then we must cover all lines of")#linebreak()#text(" The form xx2 xx3 and x22 and x33 the best we can do is to cover")#linebreak()#text(" Two of these at once as no point can cover x22 and x33 or xx2 and xx3")#linebreak()#text(" Only points of the form xxy can cover these lines and as we have 12 lines")#linebreak()#text(" Covering 2 at a times we must have 6 such lines which will have weight 3/6")#linebreak()#text(" So we will have removed one point with weight one and 6 more")#linebreak()#text(" With weight 1/2 giving remaining weight 6 or less for the remaining points.")

#text("Finally we have no points of the form xxx removed but then we will")#linebreak()#text(" have a line of the form xxx so we must have the earlier three cases and the weight of the points not removed can be at most 6.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36660")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2009")])]

#text("986. Second try at c^{\\mu}_3=6")

#text("I don’t think the previous proof works I made some changes.")

#text("c^{\\mu}_3=6")#linebreak()#text(" If we have all")#linebreak()#text(" Three points of the form xxx removed")#linebreak()#text(" Then the remaining points have value 7 and")#linebreak()#text(" We have covered all lines any set of moving coordinates")#linebreak()#text(" And all constant points equal to one value this leaves")#linebreak()#text(" The lines xab a,b not equal. Each point of the set")#linebreak()#text(" abc covers three of these lines the entire set covers each of these lines")#linebreak()#text(" there is no duplication the only alternative is to remove a point")#linebreak()#text(" abc and cover the lines with points of the form aab which have")#linebreak()#text(" a higher weight and only cover one line each this would lower the weight")#linebreak()#text(" so the maximum weight occurs when all of abc is omitted along with")#linebreak()#text(" the three points xxx and the weight is 6")

#text("If we have only two points removed of the form xxx then")#linebreak()#text(" The weight is at most 8 say the point not removed is 222")#linebreak()#text(" Then we must cover the lines xx2 and x22 we have three six such")#linebreak()#text(" Lines and all the xx2 must be covered one at a time by either 112")#linebreak()#text(" Or 332 the x22 must be covered one at a time by 322 or 122")#linebreak()#text(" These points must be removed and the that lowers the weight")#linebreak()#text(" To 8 – 3*(2/6) – 3*(2/6) = 6 again we have c^{\\mu} must be less than 6")

#text("If we have one point removed say 111 then we must cover all lines of")#linebreak()#text(" The form xx2 xx3 and x22 and x33 the best we can do is to cover these lines")#linebreak()#text(" Two of at once as no point can cover x22 and x33 or xx2 and xx3")#linebreak()#text(" And we have all points of the form aab when a = 2 and b =3")#linebreak()#text(" Or b=2 and a=3")#linebreak()#text(" Only points of the form xxy can cover these lines and as we have 12 lines")#linebreak()#text(" Cover 2 at a times we must have 6 such lines which will have weight 2/6")#linebreak()#text(" So we will have removed one point with weight one and six more")#linebreak()#text(" With weight 1/3 giving remaining weight 7 and we will have")#linebreak()#text(" Lines of the form x11 and xx1 to cover as well as x12 and x13")#linebreak()#text(" The lines of the form x11 will have to be covered by 3 lines with")#linebreak()#text(" Weight 1/3 however we are not done as we can split a point of the")#linebreak()#text(" Form 223 into 113 and 221 then we will cover the lines 22x and xx3")#linebreak()#text(" With two lines instead of one but we will cover one line of the")#linebreak()#text(" Form 11x however we due this we will either have to split")#linebreak()#text(" 3 pairs and we will have weight 6 since 7-1=6 or split two")#linebreak()#text(" and use one point of the form 11x for the remaining line of the")#linebreak()#text(" form 11x or again the total is 6 or split one and use 2 and again")#linebreak()#text(" the remaining points total 6.")

#text("Finally we have no points of the form xxx removed but then we will")#linebreak()#text(" have a line of the form xxx")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36661")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2009")])]

#text("986. 4D Moser(3) Diagonal cube")

#text("There are 12 3D cubes that fit diagonally in 4D, with coordinates xxyz, where xx = (11,22,33) or (13,22,31), and y and z both range over (1,2,3).")

#text("Their points have (a,b,c,d,e) = (8,8,6,4,1)")#linebreak()#text(" So each a-point is in 6, each b-point in 3, c-pt in 3, d-pt in 6, e-pt in 12")

#text("Of the solutions without a coordinate line, there were 37 Pareto-optimal solutions and the following ten extremal solutions.")

#text("(34321),(42321),(44221),(44311),(24440), (42340),(44240),(44600),(48400),(80000).")

#text("These satisfy ")#mi("2a+b+2c+2d+4e \\le 24, 4a+b+2c+2c+4e \\le 32")#text(" and ")#mi("a \\le 8, b\\le 8, c \\le 6, d \\le 4, e\\le 1")

#text("The inequality for the 4D set is 4A + B + 2C + 4D + 16E \\le 96")#linebreak()#text(" 8A + B + 2C + 4D + 16E \\le 128")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36663")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2009")])]

#text("987. c^{\\mu}_3=6 (rephrased)")

#text("Just to make sure I understand I am rephrasing Kristal’s proof.")

#text("Consider the line 111, 222, 333. Either one is removed, two are removed, or three are removed. (It’s impossible to have zero removed — we are left with the line.)")

#text("Suppose all three are removed. Then we are left with 18 disjoint lines represented by a single wildcard. This can be done by removing all points on the slice \\Gamma_{1,1,1}; each removal takes out 3 of the disjoint lines and we are left a weight of 6. Removing from the hexagon of slices 120-012-012-102-201-210 removes only 2 disjoint lines at a time with a higher weight, so the removal we’ve already found is optimal.")

#text("Suppose two are removed, leaving (suppose, noting symmetry) 222. Then we are left with disjoint lines **2, 2**, *2* (corresponding to the slices \\Gamma_{2,1,0} and \\Gamma_{0,1,2} and *22, 2*2, 22* (corresponding to the slices \\Gamma_{1,2,0} and \\Gamma{0,2,1}). There must be one removal for each of the six disjoint lines, removing a weight of 2 and leaving a weight of 6.")

#text("While I was typing Kristal changed her proof of one removed, so I’ll finish the rest later. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36665")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2009")])]

#text("988. c^{\\mu}_3=6 question")

#text("Looking at your new one point proof: Kristal, are you sure we assume the slices ")#mi("\\Gamma{0,2,1}")#text(" and ")#mi("\\Gamma{0,1,2}")#text(" have to be removed? (It’s what you call “points of the form aab when a = 2 and b =3")#linebreak()#text(" Or b=2 and a=3”.) Even though it’s non optimal to pick two from one of the other slices it doesn’t put us quite over the weight limit (and shouldn’t be too hard to prove that it will) but since it’s not an immediate contradiction we can’t just assume we pick the locally optimal scenario.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-2/#comment-36666")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2009")])]

#text("989. 5D Moser(3) containing diagonal cubes xxyyz")

#text("Following on from 986. A 5D Moser cube contains 60 3D cubes diagonally, in the form xxyyz. Each contains points (a,b,c,d,e,f) = (8,4,8,4,2,1).")

#text("The sets without geometric lines have 42 Pareto maxima and the following 13 extrema:")#linebreak()#text(" (324211),(413211)(422211)(424111)(424201)(224420)(413320), (424220)(444020)(422410)(424400)(448000)(800000)")#linebreak()#text(" giving the following ten inequalities")#linebreak()#text(" ")#mi("4\\alpha + \\beta+2\\gamma +2\\delta + \\epsilon + \\phi \\le 5.5, 2\\epsilon + \\phi \\le 2,  4\\alpha+4\\gamma+2\\delta+\\epsilon+\\phi \\le 6, 4\\alpha+2\\beta+2\\gamma+2\\delta+\\epsilon+\\phi \\le 6, 7\\alpha+\\beta+2\\gamma+2\\delta+\\epsilon+\\phi\\le 7, 4\\alpha+2\\epsilon+\\phi\\le 4, 8\\alpha+4\\gamma+2\\delta+\\epsilon+\\phi \\le 8, 8\\alpha+2\\beta+2\\gamma+2\\delta+\\epsilon+\\phi \\le 8, 4\\alpha+2\\beta+2\\delta+2\\epsilon+\\phi \\le 6, 8\\alpha+2\\beta+2\\delta+2\\epsilon+\\phi \\le 8")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36324")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("900. I have posted this to the old thread but in case I should")#linebreak()#text(" have put it in the new thread I am posting it here again.")

#text("We have already shown that if")#linebreak()#text(" The center slice is 42 or 43 and it has")#linebreak()#text(" 17 or more points then there at most 124")#linebreak()#text(" Case 2")#linebreak()#text(" The center slice is 42 and c is less that 17")#linebreak()#text(" Then we must have c is 12")#linebreak()#text(" And we must have on of the 8")#linebreak()#text(" (6, 24, 12, 0, 0) sets.")#linebreak()#text(" Without less of generality")#linebreak()#text(" We can assume it to be ")#mi("\\Gamma _{220}+\\Gamma _{202}+\\Gamma _{022}+\\Gamma _{112}+\\Gamma _{211}")#linebreak()#text(" In particular the middles slice")#linebreak()#text(" Contains the points")#linebreak()#text(" 2122 21212 21221")#linebreak()#text(" 23322 23232 23223 and the *1*** and *3*** slices")#linebreak()#text(" have a d value of at least three and so have at most")#linebreak()#text(" 41 points now if the center slice is 42 we have 124 points")#linebreak()#text(" and we are done so it must be 43 but then it has value 18 or more")#linebreak()#text(" and and by case 1 we have 124 points or less so we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36330")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("901. Moser(3)")

#text("I think we are now quite close to classifying all the 125 point Moser sets (if any) and thus computing ")#mi("c^{\\prime}_5")#text(" precisely.")

#text("From Kristal’s lemma and the averaging argument from my 793, 795 comments, we now know that (after rotating a 125 point Moser set) that the 1****, 3**** slices have (a,b,c,d,e) distribution from the following four choices:")

#text("* (4,16,23,0,0) [score: 62 1/3]")#linebreak()#text(" * (3,16,24,0,0) [score: 63]")#linebreak()#text(" * (4,15,24,0,0) [score: 62 3/4]")#linebreak()#text(" * (2,16,24,0,0) [score: 62]")

#text("with total score at least 125. The maximal or near-maximal “c” values of these slices force the “c” value of the middle slice 2**** to be at most 1.")

#text("Now let A, B, C, D, E, F be the number of points in the Moser set with no 2s, one 2, …, five 2s respectively. We already know that E=F=0; the above discussion shows that D is at most 1, and also A is at most 4+4=8. Meanwhile, a double counting argument shows that 2B+C is at most 160 (details on the wiki). Since")

#mi("125 = A+B+C+D+E+F \\leq A + \\frac{1}{2} 160 + \\frac{1}{2} C + D")

#text("we thus have")

#mi("C \\geq 90 - 2A - 2D")#text(". (1)")

#text("But this looks quite hard to satisfy; C can at most be 80! Furthermore, if D is 1 (e.g. if 11222 is in the set), then C can be at most 77, because of the three lines (e.g. 11×22, 112×2, 1122x) going through the D-point that have their other vertices as C-points. Also, as pointed out by Michael in 784, if C is 80, then A is at most 4. So it’s looking quite hard to actually satisfy the equation (1). Perhaps just a little more case analysis will finish the problem off for good… (and then we might look at how one can reduce the reliance on computer proofs, and perhaps even hope for a completely human proof).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36331")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("902. Moser(3)")

#text("Actually, I think I can show that D=1. Suppose not (e.g. if 11222 was in the set); then there would be two choices of coordinates in which one of the side slices would have d=1 (e.g. 1**** and *1****). But the table at")

#link("http://spreadsheets.google.com/ccc?key=p5T0SktZY9DuqNcxJ171Bbw&hl=en")[#text("http://spreadsheets.google.com/ccc?key=p5T0SktZY9DuqNcxJ171Bbw&hl=en")]

#text("shows that such slices have a score of at most 59 7/12, so that the total score from those two coordinates is at most 63 + 59 7/12 = 122 7/12. On the other hand, the other three slices have a net score of at most 63+63 = 126. This averages out to at most 124.633… < 125, a contradiction. So D=0.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36332")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("903. ")#mi("\\overline{c}^\\mu_6 \\neq 17")

#text("(The solutions I-VI are defined as in my last proof.)")

#text("Here, “upper triangle” means the first four rows of the triangular lattice (with 060 at top) and “lower trapezoid” means the bottom three rows.")

#text("Suppose 11 removals leave a triangle-free set.")

#text("First, suppose that 5 removals come from the upper triangle and 6 come from the lower trapezoid.")

#text("Suppose the trapezoid 600-420-321-303 used solution IV. There are three disjoint triangles 402-222-204, 213-123-114, and 105-015-006. The remainder of the points in the lower trapezoid (420, 321, 510, 501, 402, 312, 024) must be left open. 024 being open forces either 114 or 015 to be removed.")

#text("Suppose 114 is removed. Then 213 is open, and with 312 open that forces 222 to be removed. Then 204 is open, and with 024 that forces 006 to be removed. So the bottom trapezoid is a removal configuration of 600-411-303-222-114-006, and the rest of the points in the bottom trapezoid are open. All 10 points in the upper triangle form equilateral triangles with bottom trapezoid points, hence 10 removals in the upper triangle would be needed, so 114 being removed doesn’t work.")

#text("Suppose 015 is removed. Then 006-024 forces 204 to be removed. Regardless of where the removal in 123-213-114, the points 420, 321, 222, 024, 510, 312, 501, 402, 105, and 006 must be open. This forces upper triangle removals at 330, 231, 042, 060, 051, 132, which is more than the 5 allowed, so 015 being removed doesn’t work, so the trapezoid 600-420-321-303 doesn’t use solution IV.")

#text("Suppose the trapezoid 600-420-321-303 uses solution VI. The trapezoid 303-123-024-006 can’t be IV (already eliminated by symmetry) or VI’ (leaves the triangle 402-222-204). Suppose the trapezoid 303-123-024-006 is solution VI. The removals from the lower trapezoid are then 420, 501, 312, 123, 204, and 015, leaving the remaining points in the lower trapezoid open. The remaining open points is forces 10 upper triangle removals, so the trapezoid 600-420-321-303 doesn’t use solution VI. Therefore the trapezoid 303-123-024-006 is solution V. The removals from the lower trapezoid are then 420, 510, 312, 204, 114, and 105. The remaining points in the lower trapezoid are open, and force 9 upper triangle removals, hence the trapezoid 303-123-024-006 can’t be V, and the solution for 600-420-321-303 can’t be VI.")

#text("The solution VI’ for the trapezoid 600-420-321-303 can be eliminated by the same logic by symmetry.")

#text("Therefore it is impossible for 5 removals come from the upper triangle and 6 come from the lower trapezoid.")#linebreak()#text(" Therefore 4 removals come from the upper triangle and 7 come from the lower trapezoid.")

#text("At this point note the triangle 141-411-141 must have one point removed, so let it be 141 and note that any logic that follows is also true for a removal of 411 and 141 by symmetry.")

#text("This implies the upper triangle must have either solution I or II.")

#text("Suppose it has solution II. Note there are five disjoint triangles 600-510-501, 411-321-312, 402-222-204, 213-123-114, and 105-015-006.")

#text("Suppose 420 and 024 are removed. Then, noting 303 must be open, 606 must be removed, leaving 510 open. 510-240 forces 213 to be removed, and 510-150 force 114 to be removed. 213 are 114 are in the same disjoint triangle. Hence both 420 and 024 both can’t be removed.")

#text("So at least either 420 or 024 is open. Let it be 420, noting by symmetry identical logic will apply if 024 is removed. Then 321, 222, and 123 are removed based on 420 and the open spaces in the upper triangle. This leaves four disjoint triangles 600-501-510, 402-303-312, 213-033-015, 204-114-105. So 411 and 420 are open, forcing the removal of 510. This leaves 501 open, and 501-411 forces the removal of 402. 600-303, and 330 are then open, forming an equilateral triangle. Therefore 420 isn’t open, therefore the upper triangle can’t have solution II.")

#text("Therefore the upper triangle has solution I.")

#text("Suppose 222 is open. 222 with open points in the upper triangle force 420, 321, 123, and 024 to be removed. This leaves four disjoint triangles 411-501-402, 213-303-204, 015-105-006, and 132-312-114. This would force 8 removals in the lower trapezoid, so 222 must be closed.")

#text("Therefore 222 is removed. There are six disjoint triangles 150-420-123, 051-321-024, 231-501-204, 132-402-105, 510-150-114, and 312-042-015. So 600, 411, 393, 114, and 006 are open. 600-240 open forces 204 to be removed and 600-150 open forces 105 to be removed. This forces 501 and 402 to be open, but 411 is open, so there is the equilateral triangle 501-411-402.")

#text("Therefore the solution of the upper triangle is not II, and we have a contradiction. So ")#mi("\\overline{c}^\\mu_6 \\neq 17")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36333")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("902. Terry had previously mentioned that a GA (Genetic Algorithm) based solution might be something to try so I implemented one. The best results were:")

#text("[3]^5, 150")#linebreak()#text(" [3]^6, 450")#linebreak()#text(" [3]^7, 1302")#linebreak()#text(" [3]^8, 3780")#linebreak()#text(" [3]^9, 11340")

#text("The GA fairly easily found the first three. It starts getting challenging around 8 and 9. I have run the program several times on each example and the results are replicable. I am having trouble with [3]^10. The best result so far is 32272. I feel some confidence in the results for 7,8 and 9 as I’ve attained them several times (the smaller ones more often than the large ones due to computational restraints).")

#text("At this point, it might be reasonable to conjecture that the procedure used to predict 1302, 3780 and 11340 will continue to be valid for larger n.")

#text("I will put the solutions on my blog.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36338")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("903. Genetic algorithms")

#text("Kareem, this is very interesting! One is tempted to see how the algorithm would cope with the other three quantities ")#mi("c^{\\prime}_n, c^\\mu_n, \\overline{c}^\\mu_n")#text(" we are studying (and in particular to see what it does with ")#mi("c^{\\prime}_5")#text("). One difficulty with the Moser problem is that there are substantially more lines (the cube ")#mi("[3]^n")#text(" has ")#mi("4^n-3^n")#text(" combinatorial lines, but ")#mi("(5^n-3^n)/2")#text(" geometric lines).")

#text("It would also be great to have some details on implementation and various statistics (e.g. population size, number of iterations needed to reach the solution, etc.).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36342")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2009")])]

#text("Metacomment.")

#text("Someone (Marc again?) posted lower bound improvements to ")#mi("\\overline{c}^\\mu_{8}")#text(" and ")#mi("\\overline{c}^\\mu_{9}")#text(". I have modified the spreadsheet to match.")

#text("Since the editor didn’t log in to the wiki, all we have is the IP address. This brings up the odd notion that someone could contribute to the project yet be entirely anonymous.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36343")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2009")])]

#text("904. Scores for ")#mi("c^{\\prime}_6")

#text("It might be possible to adapt Terry’s score to limit the possible values of ")#mi("c^{\\prime}_6")#text(".")

#text("The following argument assumes f=g=0, which is likely to be correct.")

#text("Consider the sixty corners 11****, 13**** and so on.")#linebreak()#text(" Give the ")#mi("c^{\\prime}_4")#text(" arrangements the score ")#mi("a/15+b/10+c/6+d/3+e")#text(". The total of the scores equals the number of points in the solution.")

#text("Of the 41-point, 42-point and 43-point solutions, the highest score is 5.833")#linebreak()#text(" If that were the highest possible score, ")#mi("c^{\\prime}_6")#text(" would be at most 350.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36344")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2009")])]

#text("905. Genetic Algorithm Details")

#text("** Lookup Table **")

#text("I created a lookup table for each c_n on which I ran the genetic algorithm. This speeds up checking if a chromosome is line-free tremendously, making this tractable. (Any ideas about efficient ways to do this will have a very large effect on the speed of the algorithm).")

#text("** Encoding Solutions **")

#text("Chromosome structure: I code the solutions as a list of ones and zeros of length 3^n. The elements are ordered in this way 1…11, 1…12, 1…13, 1…21 and so on. A 0 in position 1 means element 1…11 is not in the set, otherwise it is.")

#text("** Making a new generation **")

#text("Selection: Any solutions below the mean of the population are completely ignored. The rest are selected with a probablity related to their score.")

#text("Crossover operator: I pick a random number, m between 2 and (3^n) – 1 and I make a new chromosome with the first m elements of a one chromosome and the last (3^n) – m elements of another chromosome.")

#text("Mutation operator: I pick a few points at random and flip them.")

#text("I check any new chromosomes to make sure they are valid. I do this by going through the chromosome elements in a random order (visiting each one) and removing points that conflict with other points.")

#text("** Population size **")

#text("I use elitism. (I keep the best 5 or sometimes 10 between generations.)")

#text("Population size: 60")

#text("I make more children than I can use (somewhere between 60-80) making the algorithm somewhat Malthusian. I take the best of the children and use them to replace the rest of the population.")

#text("** Non-standard addition **")

#text("An extremely effective trick has been to use a greedy algoritm on the list of all solutions to:")

#text("1. pick a small but fixed number of points in each chromosome and flip them if they improve the score.")

#text("2. run the greedy algorithm on the whole chromosome, going through all positions in a random order, and flipping any that make an improvement.")

#text("I vary the number of times I use 1 versus 2 in order to control the computational costs of this step.")

#text("I have found that without this step the algorithm is dramatically less good.")

#text("** Adaptive Elements **")

#text("The mutation rate is adaptive. I keep statistics on whether there are any repetitions in the chromosomes I generated and if there are, I increase the mutation rate until they disappear. Thus the mutation rate is just high enough to make sure a maximum number of novel solutions are being explored. If I have increased the rate twice in a row then I double the increment size and if I decrease the rate twice in the row then I half the increment size. (This allows quick changes in the rate if necessary.)")

#text("I also keep statistics on the probability that crossover and the probability that mutaton improve the score. I randomly choose one or the other in proportion to their effectiveness in the last generation.")

#text("** Cataloging solutions **")

#text("I set a criteria for when I think the genetic algorithm is stuck (200 generations with no change in the best performer). If there is no improvement then I restart the algorithm and I store the best solution.")

#text("** Final comments **")

#text("For n less than 8, this works very quickly. For n=5, a quick look at a few examples shows 150 is attained within 40 generations. This gets faster after the program has attained the solution once because a better mutation rate than my default guess is found.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36345")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2009")])]

#text("906.")

#text("In a previous thread, I saw that 12 solutions were found for c_5. I was also able to find these solutions. In addition, I found 12 solutions for c_7. I only found a single solution for c_8 and c_9. Could this mean that if n is a prime larger than 3, there are 12 solutions?")

#text("I am not sure if this is already known but the 12 solutions for c_5 can be constructed from 9 smaller units: 6 of length 5 and 3 of length 70. Each solution contains four disjoint units: two of length 70 and two of length 5.")

#text("The 12 solutions for c_7 can be similarly constructed from 9 smaller units: 6 of length 21 and 3 of length 630. Each solution again contains four disjoint units: two of length 630 and two of length 21.")

#text("I will put the units used to make the solutions on my website along with the solutions as soon as soon as I have enough time to organize the data.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36346")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2009")])]

#text("906. Scores for ")#mi("c^{\\prime}_6")

#text("Michael: this is a nice observation! The proposed upper bound of 350 is close enough to the current lower bound of 344 that one can hope that ")#mi("c^{\\prime}_6")#text(" may actually be feasible to compute exactly. (It would be interesting to see how the genetic algorithm performs on this problem.)")

#text("There may be three ways to establish rigorously that 5.833 is the highest ")#mi("c^{\\prime}_6")#text("-score of all four-dimensional Moser sets. Firstly, I would assume that Klas’s integer programming methods (which were able to find the maximal value of ")#mi("a+b+c+d+e")#text(", namely 43) would also be able to find the maximal value of this score in a comparable amount of time (and even classify extremisers, etc.). Secondly, it may be that for 40-point sets and below one can use the inequalities that one already has on a,b,c,d,e (some are collected at the wiki page) together with the inequality ")#mi("a+b+c+d+e \\leq 40")#text(". A third way is to iterate the score strategy. One can presumably dispose of the e=1 case (we know already, for instance, that such sets have at most 39 points). Once e is gone, we can bound the score of a 4D Moser set by an average of a different type of score for 3D Moser sets. Now, the set of possibilities of statistics (a,b,c,d) of a 3D Moser set should be computable more or less exactly. [Actually, come to think of it, this is a worthwhile project to do anyway, as it may help us a lot in obtaining a human proof of Klas’s very valuable computer-generated facts about 4D Moser statistics that we have been relying heavily on in our 5D analysis. I guess a warmup is to first completely understand the (a,b,c) statistics of a 2D Moser set.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36347")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2009")])]

#text("907.")

#text("I have noticed that each group of 70 seems to have two possible groups of 5 which are associated with it. Thus to construct a solution, we pick two groups of 70 (of the three possible) and then for each selected group of 70, we pick one of the two possible associated groups of 5. (Again, if this is repetition, I apologize.)")

#text("I think the same principle applies to the c_7 solutions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36349")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2009")])]

#text("908. Moser statistics")

#text("I’ve started on the wiki a proposal to control the statistics (a,b,c,…) of Moser sets in low dimensions. Some definitions:")

#text("* A statistic (a,b,c,…) is ")#emph[#text("attainable")]#text(" if there is a Moser set with that statistic. For instance, (2,4,0) is attainable due to the Moser set {11, 12, 21, 23, 32, 33}.")

#text("* An attainable statistic is ")#emph[#text("Pareto-optimal")]#text(" if it is not pointwise dominated by another attainable statistic. For instance (2,4,0) is Pareto-optimal, but (2,3,0) is not.")

#text("* An attainable statistic is ")#emph[#text("extremal")]#text(" if it is not the convex combination of other attainable statistics; this is stronger than Pareto-optimal. For instance (3,2,0) is Pareto-optimal but not extremal (it’s a convex combination of (2,4,0) and (4,0,0).")

#text("If one wants to maximise a linear score (or more generally, a convex score) over all statistics, it suffices to check it on extremal statistics. So it looks like a worthwhile task to classify extremal statistics for small n. So far I have")

#text("* n=0: The extremal statistics are (1).")#linebreak()#text(" * n=1: The extremal statistics are (2,0), (1,1).")#linebreak()#text(" * n=2: The extremal statistics are (4,0,0), (2,4,0), (2,2,1). There is also an additional Pareto-optimal statistic (3,2,0).")

#text("It looks like n=3 should be completely computable, and then (perhaps with the assistance of the known statistics for 41+ points) n=4 should be also.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36350")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2009")])]

#text("909. Alternate cube problem type")

#text("Back in the ")#link("http://gowers.wordpress.com/2009/02/23/brief-review-of-polymath1/#comment-2470")[#text("other thread in the replies to O’Donnell .832")]#text(" I mentioned using alternate wildcard types to produce variations of Moser’s.")

#text("In patricular consider one with two wildcards * and #, such that * gives 1, 2, 3 and # gives 2, 3, 1. (In other words, rather than the permutation between the wildcards being a 2-cycle, it’s a 3-cycle.) The leads to lines like for example **# which gives 112, 223, and 331.")

#text("I was curious how this looked so I tried a picture for [3]^3:")

#link("http://numberwarrior.files.wordpress.com/2009/03/3cycle.png")[#text("Picture of 3 cycle permutation of wildcards")]

#text("I did not add in the standard combinatorial lines from having only a single wild card.")

#text("How many removals are needed so there are no more lines? Is this a known problem, or a new one?")

#text("And if it’s a new problem, what would it be called? “3-cycle cube problem” doesn’t make me entirely happy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36352")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2009")])]

#text("910. Alternate cube problem")

#text("Dear Jason,")

#text("I haven’t seen this problem before, but if you allow six wildcards that encode all 3! permutations of 123, then this is basically the capset problem (i.e. computing ")#mi("c^{\\prime\\prime}_n")#text(").")

#text("Randall McCutcheon and Seva Lev independently proposed what we now call the “Strong Roth theorem” on the wiki, which corresponds to using the three wildcards 123, 231, 312 (i.e. cyclic permutations of 123). This problem, like the capset problem has the advantage of being translation-invariant with respect to the addition structure of ")#mi("({\\Bbb Z}/3{\\Bbb Z})^n")#text(".")

#text("I’ll put something to this effect on the wiki.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36358")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2009")])]

#text("911. If a Moser set has 124 points or less and its center slice is of side 41")#linebreak()#text(" It must have 11 points or less with two twos in its center slice.")

#text("Suppose it has 12 or more then all 12 points have values")#linebreak()#text(" not equal to 2 divided among 4 coordinates there are 24 such values")#linebreak()#text(" So one coordinate must have six of these values.")

#text("Now if four of these are are equal to one or four equal to three")#linebreak()#text(" we have one side slice equal to 40 (since a 41 point slice can have")#linebreak()#text(" at most d equal to three) and combined with")#linebreak()#text(" the fact we have shown the center slice must be 41 or lower and the third slice must be 43 or less we have the total points sum to 124")#linebreak()#text(" or less and we are done so they must be divided 3 3 and then each side")#linebreak()#text(" slice must be 41 or less and that combined with the center slice being 41 or less we 124 points or less and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36360")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2009")])]

#text("912. If the center slice of a Moser set is size 41 or more the set must have")#linebreak()#text(" 124 or less points.")

#text("Because we have shown c of the center slice must be less than 12")#linebreak()#text(" we are left only with case where there are c = 6, note that these points have three 2’s")#linebreak()#text(" overall in the configuration . We will first show that there must")#linebreak()#text(" be three or more points with three twos outside the center slice, Now since c = 6 the 6 points have")#linebreak()#text(" 12 coordinates with value 1 or 3 divided among 4 coordinates")#linebreak()#text(" one coordinate must have at least three of these coordinates now if we slice")#linebreak()#text(" at this coordinate we will three coordinates which will not be in the")#linebreak()#text(" center slice then if there are less than three coordinates with three twos")#linebreak()#text(" outs we will end up with c for the center slice being less than 6")#linebreak()#text(" and hence the center slice will have to have 40 points or less and the three points")#linebreak()#text(" with two threes that moved outside the center will if they lie")#linebreak()#text(" in one slice lower its value to 41 hence lower the total value to or less")#linebreak()#text(" if they are split among two slices those slices will have value 42 or less")#linebreak()#text(" and combined with 40 or less of the center will give 124 or less.")

#text("So we have must 9 points then we must have one cut with side slices 43 or more and since d=0 for the side slices we have all 9 points with three twos")#linebreak()#text(" In the center slice then we have 18 values not equal to 2 divided among")#linebreak()#text(" 4 coordinates one must have 5 values we cut along that coordinate")#linebreak()#text(" and if one of the side slices has 4 or more points then that slice will have 40 or")#linebreak()#text(" less points and that combined with the 41 points of the center slice")#linebreak()#text(" and the fact the remaining slice must have 43 or less points gives 124")#linebreak()#text(" and we are done. So we must have 3 such points in one outside slice")#linebreak()#text(" and two in another. That gives at most 41 points in the center slice")#linebreak()#text(" at most 42 points in one side slice and at most 41 points in the other slice")#linebreak()#text(" which gives less than 124 points and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36362")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2009")])]

#text("913. If a Moser set contains a point with three twos it has 124")#linebreak()#text(" points or less.")#linebreak()#text(" We have there is cut which gives one slice with")#linebreak()#text(" 43 points on each outside slice thus the point with three twos")#linebreak()#text(" must lie in the center slice of this cut we slice at a value where this point")#linebreak()#text(" does not equal two then in the new set of slices the center slice")#linebreak()#text(" must have 40 points or less and the point with three twos must")#linebreak()#text(" lie on one of the outside slices if it has value 41 the we must have")#linebreak()#text(" a total of 124 points and we are done if it has value 42 it must have")#linebreak()#text(" two points with three twos and one coordinate at which these points")#linebreak()#text(" have values 3 and 1 we slice at this value and get that the center slice")#linebreak()#text(" must have 40 points or less and since the two side slices have at least")#linebreak()#text(" one point with three two’s each they must have 42 points or less and")#linebreak()#text(" the total is 124 or less and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36379")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2009")])]

#text("914. Pareto set of ")#mi("{}[3]^3")

#text("There seem to be 22 Pareto-optimal statistics:")

#text("(3,6,3,1),(4,4,3,1),(4,6,2,1),(2,6,6,0),(3,6,5,0),(4,4,5,0),(3,7,4,0),(4,6,4,0), (3,9,3,0),(4,7,3,0),(5,4,3,0),(4,9,2,0),(5,6,2,0),(6,3,2,0),(3,10,1,0),(5,7,1,0), (6,4,1,0),(4,12,0,0),(5,9,0,0),(6,6,0,0),(7,3,0,0),(8,0,0,0)")

#text("If I use the same argument as in 904, ")#mi("c^{\\prime}_5")#text(" is only restricted to 132 or below, which is not very effective. Even excluding points with three 2s, as Kristal has achieved, this argument only restricts ")#mi("c^{\\prime}_5")#text(" to 128 or below.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36393")[#strong[#text("Hales-Jewett « The Twofold Gaze")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2009")]

#text("[…] The problem is very well written up elsewhere. So without further ado here are the solutions for c_n for a few small […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36394")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2009")])]

#text("915. Hi everyone,")

#text("Sorry about the delay. Judging from the traffic there has been a lot of interest. There is now a zip file on my website with the solutions that I have managed to compute so far. I tried to make it as complete as I could.")

#link("http://twofoldgaze.wordpress.com/2009/03/06/hales-jewett/")[#text("http://twofoldgaze.wordpress.com/2009/03/06/hales-jewett/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36395")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2009")])]

#text("916. Just one warning, there is an error in the long form of the disjoint sets which generate the solutions for [3]^7. The elements listed are of length 5 and not the expected 7 (a consequence of not setting a parameter n=7 somewhere after I had finished doing the 12 solutions of n=5.) I will get it fixed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36397")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2009")])]

#text("917.")

#text("I’m a bit busy today, so only some quick comments here:")

#text("Kristal: I haven’t had time to verify your results yet, but they look very interesting! If you have time you might want to merge them with the lemmas on the wiki page.")

#text("Michael: Nice! Your list shows, by the way, that the previous computation that a 3D Moser set with 222 has at most 13 points is sharp. (This is one of the reasons it’s nice to have a list of extremal triples).")

#text("Presumably if one reduces from Pareto-optimal triples to extremal triples then one should have a much smaller (and hence more tractable) set of triples to work with. Once one has those, one should be able to describe the sharp linear inequalities between a,b,c,d in 3D. For instance, in 2D, where the extremals are (4,0,0), (2,4,0), (2,2,1), there is only one non-trivial sharp linear inequality ")#mi("2a+b + 2c \\leq 8")#text(" between the a,b,c, together of course with the trivial inequalities ")#mi("a \\geq 0")#text(", ")#mi("0 \\leq b \\leq 4")#text(", ")#mi("0 \\leq c \\leq 1")#text(".")

#text("Once we have the sharp linear inequalities in 3D, the averaging trick should then give us a bunch of useful linear inequalities in 4D. These are probably not optimal in themselves (in particular, they probably won’t be able to recover the sharp bound of 43, which still does not have a short human proof) but I’m hoping in conjunction with the data on 41, 42, and 43 point sets, we can do things like verify your conjecture that 4D Moser sets have a 5D score of at most 5.833.")

#text("Kareem: thanks for the data and the details of the GA!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36399")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2009")])]

#text("918. ")#mi("\\overline{c}^\\mu_7 \\leq 22")

#text("Finishing ")#mi("\\overline{c}^\\mu_6")#text(" will take some time, so here’s a quick chunk off of ")#mi("\\overline{c}^\\mu_7")#text(".")

#text("I’m using the same eight extremal solutions to ")#mi("\\overline{c}^\\mu_3")#text(" as previous proofs:")

#text("Solution I: remove 300, 020, 111, 003")#linebreak()#text(" Solution II: remove 030, 111, 201, 102")#linebreak()#text(" Solution III (and 2 rotations): remove 030, 021, 210, 102")#linebreak()#text(" Solution III’ (and 2 rotations): remove 030, 120, 012, 201")

#text("Suppose the 8x8x8 lattice can be triangle-free with only 13 removals.")

#text("Slice the lattice into region A (070-340-043) region B (430-700-403) and region C (034-304-007). Each region must have at least 4 points removed. Note there is an additional disjoint triangle 232-322-223 that also must have a point removed. Therefore the points 331, 133, and 313 are open. 331-313 open means 511 must be removed, 331-133 open means 151 must be removed, and 133-313 open means 115 must be removed. Based on the three removals, the solutions for regions A, B, and C must be either I or II. All possible combinations for the solutions leave several triangles open (for example 160-520-124). So we have a contradiction, and ")#mi("\\overline{c}^\\mu_7 \\leq 22")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36400")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2009")])]

#text("919. …and I completely blanked on the rotations of II (fixing 151 helps nullify the III cases, but allows II to be rotated), which means I need to go back and fix my previous proofs. The proof of 918 is still fine, although a complete listing of cases might be in order.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36401")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2009")])]

#text("920. For n=6 a Moser set must contain 373 or less points.")

#text("We have from 912 that if n=5 a 125 point set must have its center slice")#linebreak()#text(" 40 or less. Then slice arbitrarily call the coordinate i if the Moser set is 374")#linebreak()#text(" or more two of the slices must have 125 points and those slices must")#linebreak()#text(" have a center slice of 40 then if we slice again call that coordinate j so we have 9")#linebreak()#text(" sets of 81 points with each set representing one choice of two coordinates i, j")#linebreak()#text(" by the above For the two values of i with 125 points the center slices must be forty or less")#linebreak()#text(" which means the center slice of the set with respect to j has at most")#linebreak()#text(" 40 + 40 + 43 points and by looking at the j slices we get 125 + 125 + 123 = 373 points or less.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36404")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2009")])]

#text("921. If a Moser set has 125 points then the number of points with")#linebreak()#text(" exactly two 2’s is either 78 or 79.")

#text("It must be less than 80")#linebreak()#text(" by lemma three in the section of the wiki dealing with Moser")#linebreak()#text(" sets for n=5.")

#text("If it is 77 or less then the three or more missing points must have")#linebreak()#text(" 6 or more values equal to 2 divided among 5 coordinates")#linebreak()#text(" one coordinate must have two such values. Then in")#linebreak()#text(" that coordinate b must be equal to 30 or less. Now")#linebreak()#text(" if this center slice is 38 or less then we have 38 + 43 + 43 is less than 125 and we are done. So it must be 39 or more. We have")#linebreak()#text(" 4a + b is less than or equal to 64 from the section of the")#linebreak()#text(" wiki on Moser sets devoted to n = 4. so we have a + b")#linebreak()#text(" is 39 or more and 4a + b is 64 or less we can subtract")#linebreak()#text(" and get 3a is less than 25 so a is less than 9 but that combined")#linebreak()#text(" with b is thirty or less gives a total set size of 38 or less which results in a contradiction as noted above.")

#text("So the number of points with exactly 2 2’s in a Moser set with n=5")#linebreak()#text(" With 125 or more points is greater than 77 and not equal to 80.")#linebreak()#text(" So it must be 78 or 79.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36405")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2009")])]

#text("922. I am going to have to redo 912 I made a mistake in which I assumed their")#linebreak()#text(" had to be two side slices in one cut with 43 points or more.")#linebreak()#text(" However it can be easily fixed. Here is the corrected version:")

#text("If the center slice of a Moser set is size 41 or more the set must have")#linebreak()#text(" 124 or less points.")

#text("Because we have shown c of the center slice must be less than 12")#linebreak()#text(" we are left only with case where there are c = 6, note that these points have three 2’s")#linebreak()#text(" overall in the configuration . We will first show that there must")#linebreak()#text(" be three or more points with three twos outside the center slice, Now since c = 6 the 6 points have")#linebreak()#text(" 12 coordinates with value 1 or 3 divided among 4 coordinates")#linebreak()#text(" one coordinate must have at least three of these coordinates now if we slice")#linebreak()#text(" at this coordinate we will three coordinates which will not be in the")#linebreak()#text(" center slice then if there are less than three coordinates with three twos")#linebreak()#text(" outs we will end up with c for the center slice being less than 6")#linebreak()#text(" and hence the center slice will have to have 40 points or less and the three points")#linebreak()#text(" with two threes that moved outside the center will if they lie")#linebreak()#text(" in one slice lower its value to 41 hence lower the total value to or less")#linebreak()#text(" if they are split among two slices those slices will have value 42 or less")#linebreak()#text(" and combined with 40 or less of the center will give 124 or less.")#linebreak()#text(" So we have must 9 points then we must have one cut with side slices in one of the four categories")#linebreak()#text(" 1. (2,16,24,0,0) [42 points, score: 62]")#linebreak()#text(" 2. (4,16,23,0,0) [43 points, score: 62 1/3]")#linebreak()#text(" 3. (4,15,24,0,0) [43 points, score: 62 3/4]")#linebreak()#text(" 4. (3,16,24,0,0) [43 points, score: 63]")#linebreak()#text(" See the wiki on Moser sets, the section n = 5 lemma four and following discussion")#linebreak()#text(" for the details of this.")

#text("This implies d=0 for the side slices of this cut we have all 9 points with three twos")#linebreak()#text(" in the center slice then we have 18 values not equal to 2 divided among")#linebreak()#text(" 4 coordinates one must have 5 values we cut along that coordinate")#linebreak()#text(" and if one of the side slices has 4 or more points then that slice will have 40 or")#linebreak()#text(" less points and that combined with the 41 points of the center slice")#linebreak()#text(" and the fact the remaining slice must have 43 or less points gives 124")#linebreak()#text(" and we are done. So we must have 3 such points in one outside slice")#linebreak()#text(" and two in another. That gives at most 41 points in the center slice")#linebreak()#text(" at most 42 points in one side slice and at most 41 points in the other slice")#linebreak()#text(" which gives less than 124 points and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36406")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2009")])]

#text("923 Fujimura’s problem")#linebreak()#text(" Earlier today coded up Fujimura’s problem for integer programming. Here are the results")

#text("n=3, maximum 6 points, 10 solutions")#linebreak()#text(" n=4, maximum 9 points, 1 solution")#linebreak()#text(" n=5, maximum 12 points, 1 solution")#linebreak()#text(" n=6, maximum 15 points, 4 solutions")#linebreak()#text(" n=7, maximum 18 points, 85 solutions")#linebreak()#text(" n=8, maximum 22 points, 72 solutions")#linebreak()#text(" n=9, maximum 26 points, 183 solutions")#linebreak()#text(" n=10, maximum 31 points, 6 solutions")#linebreak()#text(" n=11, maximum 35 points, 576 solutions")#linebreak()#text(" n=12, maximum 40 points, 876 solutions")

#text("Here are the solutions for n=3")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/solutions-n=3-k=3-FUJ")[#text("http://abel.math.umu.se/~klasm/solutions-n=3-k=3-FUJ")]

#text("Here are the solutions for n=4")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/solutions-n=3-k=3-FUJ")[#text("http://abel.math.umu.se/~klasm/solutions-n=3-k=3-FUJ")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36407")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2009")])]

#text("924.")#linebreak()#text(" Here are the solutions for n=5")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/solutions-n=5-k=3-FUJ")[#text("http://abel.math.umu.se/~klasm/solutions-n=5-k=3-FUJ")]

#text("Here are the solutions for n=6")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/solutions-n=6-k=3-FUJ")[#text("http://abel.math.umu.se/~klasm/solutions-n=6-k=3-FUJ")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36408")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2009")])]

#text("925")#linebreak()#text(" Here are the solutions for n=7")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/solutions-n=7-k=3-FUJ")[#text("http://abel.math.umu.se/~klasm/solutions-n=7-k=3-FUJ")]

#text("Here are the solutions for n=8")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/solutions-n=8-k=3-FUJ")[#text("http://abel.math.umu.se/~klasm/solutions-n=8-k=3-FUJ")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36409")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2009")])]

#text("926")#linebreak()#text(" Here are the solutions for n=9")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/solutions-n=9-k=3-FUJ")[#text("http://abel.math.umu.se/~klasm/solutions-n=9-k=3-FUJ")]

#text("Here are the solutions for n=10")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/solutions-n=10-k=3-FUJ")[#text("http://abel.math.umu.se/~klasm/solutions-n=10-k=3-FUJ")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36410")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2009")])]

#text("927")#linebreak()#text(" Here are the solutions for n=11")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/solutions-n=11-k=3-FUJ")[#text("http://abel.math.umu.se/~klasm/solutions-n=11-k=3-FUJ")]

#text("Here are the solutions for n=12")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/solutions-n=12-k=3-FUJ")[#text("http://abel.math.umu.se/~klasm/solutions-n=12-k=3-FUJ")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36414")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2009")])]

#text("928.")

#text("Hi everyone,")

#text("I have been computing the first few c’_prime numbers and I got an extremal that was too large for n=3. Can someone help me find the geometric line in this solution?")

#text("{112, 113, 121, 123, 131, 132, 211, 213, 231, 233, 311, 312, 321, 323, 332, 333}")

#text("Thank you.")

#text("(I apologize if this is a repeated comment, something seems like it went wrong with my submission.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36415")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2009")])]

#text("929.")

#text("Oops, I think that was my fault; I wrote ")#mi("c^{\\prime}_3 = 14")#text(" on the blog post when it should be ")#mi("c^{\\prime}_3=16")#text(". Corrected now…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of guest")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36417")[#strong[#text("guest")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2009")])]

#text("930.")

#text("Kareem,")

#text("Have you tried a version of your genetic algorithm *without* crossover? In other words, a randomized version of hill-climbing based on your mutation operator? (run many times with different starting points.) I’ve heard several people who have worked with GAs report that sometimes switching to randomized hill-climbing, iterated with different initial conditions, gives results more efficiently.")

#text("(if nothing else, this is easy to test–just comment out the crossover step!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36421")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2009")])]

#text("931 Details of Moser(3), 3-dim")

#text("Following on from 914. and 917., the extremal statistics are")

#text("(3,6,3,1),(4,4,3,1),(4,6,2,1),(2,6,6,0),(4,4,5,0),(4,6,4,0),(4,12,0,0),(8,0,0,0)")

#text("Their sharp linear bounds are :")#linebreak()#text(" 2a+b+2c+4d <= 22")#linebreak()#text(" 3a+2b+3c+6d <= 36")#linebreak()#text(" 7a+2b+4c+8d <= 56")#linebreak()#text(" 6a+2b+3c+6d <= 48")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36431")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2009")])]

#text("932. If a Moser set has 125 points or more then it must have at least one cut where the center slice has 39 points or less.")

#text("If not all points must have center slice exactly equal to 40, Now one set of outside slices must have scores that sum to 125 or more then by the discussion following lemma 4 of the Wiki on Moser sets in the section devoted to n=5 and the slices must be chosen from the following")#linebreak()#text(" • (2,16,24,0,0) [42 points, score: 62]")#linebreak()#text(" • (4,16,23,0,0) [43 points, score: 62 1/3]")#linebreak()#text(" • (4,15,24,0,0) [43 points, score: 62 3/4]")#linebreak()#text(" • (3,16,24,0,0) [43 points, score: 63]")

#text("Now since the slice has 40 points the slice must")#linebreak()#text(" Contain the slice with 42 points and one of the slices")#linebreak()#text(" With 43 points however since the sum is 125 or more")#linebreak()#text(" It must contain the bottom slice thus the following is forced")#linebreak()#text(" As statistics of slices")

#text("(2,16,24,0,0) [42 points, score: 62]")#linebreak()#text(" (3,16,24,0,0) [43 points, score: 63]")

#text("Now the sum of these two slices is 125")#linebreak()#text(" Since the sum of all 5 sets of slices is 625")#linebreak()#text(" By lemma 4 of the section devoted to n=5")#linebreak()#text(" So we can subtract and get the sum of the")#linebreak()#text(" Four remaining slices is 500 but then we can repeat the")#linebreak()#text(" Process getting another cut with the same set of statistics of slices")#linebreak()#text(" And the three remaining sets of slices equal to 375 we can repeat")#linebreak()#text(" The process until we are done and get all 5 slices have the")#linebreak()#text(" Following statistics")#linebreak()#text(" (2,16,24,0,0) [42 points, score: 62]")#linebreak()#text(" (3,16,24,0,0) [43 points, score: 63]")

#text("The presence in the above of the 24 in the third position")#linebreak()#text(" means that the configuration must have all 80 points")#linebreak()#text(" with exactly two twos but by lemma 3 of the Wiki")#linebreak()#text(" in the section devoted to n=5 we have that implies")#linebreak()#text(" that the configuration has 124 points or less and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36432")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2009")])]

#text("933. If a configuration has 125 or more points")#linebreak()#text(" then it must have 6, 7 or 8 points with")#linebreak()#text(" no twos.")

#text("There must be a cut of the configuration whose outside slices sum to")#linebreak()#text(" 125 or more.")#linebreak()#text(" If it has 40 points it must sum to exactly 125")#linebreak()#text(" and since we have the sum of all 5 sets of outside slices")#linebreak()#text(" is 125 we can subtract and get the remaining sets of slices")#linebreak()#text(" has sum 500 we keep repeating this step until a cut with")#linebreak()#text(" center slice 39 or less is chosen this must happen because")#linebreak()#text(" we will eventually run out of cuts with center slice 40.")#linebreak()#text(" We have shown that there is at least one cut")#linebreak()#text(" with center slice 39 or less. Then we will eventually get")#linebreak()#text(" a cut whose side slices sum to 125 or more whose")#linebreak()#text(" center slice is less than 40 then since we have the side slices")#linebreak()#text(" Must be")

#text("1. (2,16,24,0,0) [42 points, score: 62]")#linebreak()#text(" 2. (4,16,23,0,0) [43 points, score: 62 1/3]")#linebreak()#text(" 3. (4,15,24,0,0) [43 points, score: 62 3/4]")#linebreak()#text(" 4. (3,16,24,0,0) [43 points, score: 63]")#linebreak()#text(" The center slice must be of size 39 and the choice of the outside slice")#linebreak()#text(" with 42 points is not possible then since the values of the remaining")#linebreak()#text(" possible slices have a=3 or 4 we must have 6, 7 or 8 points with")#linebreak()#text(" no coordinates equal to 2 in the configuration and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36433")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2009")])]

#text("934. If a Moser set with exactly 125 points has exactly 78 points")#linebreak()#text(" with two 2’s it must have either 7 or 8 points")#linebreak()#text(" with no twos.")

#text("We know that it must have 6, 7 or 8 points with")#linebreak()#text(" no twos, if it has 6 then it must have 125 minus 78 minus 6")#linebreak()#text(" equals 41 points with exactly one two.")

#text("Then one of the center slices must contain 9 or more")#linebreak()#text(" points with exactly one two in the configuration. But that leads to")#linebreak()#text(" A contradiction since the slice is equal to 39 or 40")#linebreak()#text(" Take the case where it is equal to 39 We have 4a + b is less than or equal to 64 from the section of the wiki on Moser sets devoted to n = 4. so we have a + b is 39 and 4a + b is 64 or less we can subtract and get 3a is less than 25 so a is less than 9 and we have a contradiction so the center slice must have 40 points")#linebreak()#text(" Then again we have 4a + b is less than or equal to 64 from the section of the wiki on Moser sets devoted to n = 4. so we have a + b is 40 and 4a + b is 64 or less we can subtract and get 3a is less than 24 so a is less than 8 but that gives a contradiction so we are done.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36436")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2009")])]

#text("935. Moser(3)")

#text("I reorganised the Moser wiki page a bit to incorporate the recent progress (and also simplified some of the arguments). It now seems that we have the distribution (A,B,C,D,E,F) of 125-point Moser sets in 5D pinned down to just three possibilities:")

#text("* (6,40,79,0,0,0)")#linebreak()#text(" * (7,40,78,0,0,0)")#linebreak()#text(" * (8,39,78,0,0,0)")

#text("It seems that we are reaching the limit of what we can do by analysing slices, and we will have to start understanding sphere packing better…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36437")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2009")])]

#text("guest: “Have you tried a version of your genetic algorithm *without* crossover?”")

#text("Thanks for the suggestion. This is only my second genetic algorithm project so I appreciate the input. I tried it without crossover and crossover does seem to help. In the beginning, I tried crossover on the chomosomes with regular crossover points at the one third and two thirds mark. That did seem to be disasterous, leading to very early convergence.")

#text("Do you happen to know why it was suggested that crossover not be used? I measure the probability that a particular operator can improve solutions so bad operators are not over used. However, if the issue is early convergence then I have no ideas on defending against that other than automated restarting of the algorithm.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36443")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2009")])]

#text("937. GA improvement")

#emph[#text("I created a lookup table for each c_n on which I ran the genetic algorithm. This speeds up checking if a chromosome is line-free tremendously, making this tractable. (Any ideas about efficient ways to do this will have a very large effect on the speed of the algorithm).")]

#text("Could you go into detail about how you do this now?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36447")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2009")])]

#text("938. Jason Dyer:")

#text("For each element, I figured out the two other elements that are needed to make a line. For instance, 123 means that both 122 and 121 can’t be in the set. For each element, I have all possible pairs that would conflict if they were both elements of the set. If I do a simple transformation of 1->0,2->1 and 3->2 then I get numbers in base three which can then of course be representable as numbers in base 10. Thus I can represent each pair that I need to avoid as two numbers. (This is good as integers can be stored easily in a big table.) So that’s how I store them, I number everything from 0 to 3^n-1 and for each element I have a list of pairs that I have to check for. I store all this in an array where the nth row contains each pair in order.")

#text("The solutions are represented as binary numbers of length 3^n where if the mth element of [3]^n is a member of the set then the mth binary digit is set to 1 otherwise it is set to zero.")

#text("To check if a solution valid, for each position p, I check row p of my lookup table. I check pair by pair looking at the binary digits corresponding to each pair and making sure they aren’t both set to 1.")

#text("For example, my look up table for c_2 is the following:")

#text("1 2 3 6 4 8")#linebreak()#text(" 0 2 4 7 -1 -1")#linebreak()#text(" 0 1 5 8 -1 -1")#linebreak()#text(" 0 6 4 5 -1 -1")#linebreak()#text(" 0 8 1 7 3 5")#linebreak()#text(" 2 8 3 4 -1 -1")#linebreak()#text(" 0 3 7 8 -1 -1")#linebreak()#text(" 1 4 6 8 -1 -1")#linebreak()#text(" 0 4 2 5 6 7")

#text("The -1’s mark the end of the list so my program knows when the list of pairs has ended.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36463")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2009")])]

#text("939. ")#mi("c^{\\prime 6} \\le 365")

#text("Use the classification of 3-dim solutions.")

#text("The ")#mi("{}[3]^6")#text(" cube has 160 corner cubes, eg 111***,")#linebreak()#text(" 240 edge cubes, eg. 112*** and 120 face cubes, 122***")

#text("Give the corner cubes a score ")#mi("s_1 = 0.05a+0.026b + 0.05c + 0.1d")#linebreak()#text(" Give the edge cubes a score ")#mi("s_2 = 0.074b+0.0415c + 0.0714d+0.1429e")#linebreak()#text(" Give the face cubes a score ")#mi("s_3 = 0.0755c + 0.0286d + 0.0357e + 0.1f")

#text("From the list of extremal solutions, ")#mi("s_1 \\le 0.556, s_2 \\le 0.831, s_3 \\le 0.645")

#text("The total score is ")#mi("a+b+c+d+e+f = 160s_1+240s_2 + 120s_3 < 365.8")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36465")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2009")])]

#text("940. Possible lower bounds for c_6 and c_7")

#text("I just wanted to give a bit of an update concerning c’_n. My best solutions are:")

#text("c’_5: 124 (399 unique solutions – 3 million generations)")#linebreak()#text(" c’_6: 353 (26 unique solutions – 3 million generations)")#linebreak()#text(" c’_7: 978 (1 solution – 5.4 million generations)")

#text("I will put these on my website when I can so that the solutions can be doublechecked. At this point, I can say this is a much harder problem than c_n. I have included the amount of computation that I have thrown at each problem in order to indicate the diminishing returns with increasing n. I think it’s entirely possible that there are larger solutions.")

#text("(Sorry I keep forgetting to put the numbers, Terry.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36469")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2009")])]

#text("941. ")#mi("c^{\\prime}_6")

#text("Kareem, it seems that your 6D and 7D solutions are better than those we already had, it will be interesting to analyse their structure. (It occurred to me that one might be able to “seed” a GA by throwing in some decent solutions that we already have and seeing whether evolution will improve it… so perhaps it’s still worth compiling a pool of reasonably good solutions here even if they are non-optimal.)")

#text("Incidentally, your 353-point example example shows that the conjecture in 904 is incorrect; either the score a/15+b/10+c/6+d/3+e for 4D sets can exceed 5.8333, or the 353-point example has a nonzero value of f or g. I guess what is going on here is that large values of d or e, which don’t show up in the 41+ point examples, can occur for smaller examples and result in a score larger than that for the big examples.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36475")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2009")])]

#text("If a Moser set for n=5 has 125 points")#linebreak()#text(" It must have the following statistics:")#linebreak()#text(" • (7,40,78,0,0,0) or")#linebreak()#text(" • (8,39,78,0,0,0)")

#text("Assume it has statistics (6,40,79,0,0,0),")#linebreak()#text(" the only remaining case")#linebreak()#text(" Now look at the 6 points with all coordinates not")#linebreak()#text(" equal to 2. Any set of 5 of these has one pair of")#linebreak()#text(" points that differ in exactly two coordinates")#linebreak()#text(" See the proof of lemma 3 in the Moser wiki")#linebreak()#text(" We start with 5 of these points and get at least one")#linebreak()#text(" pair that differs in exactly two coordinates if there is more than")#linebreak()#text(" one we choose a pair")#linebreak()#text(" Then we remove one of the points the pair and add the")#linebreak()#text(" additional point to replace then we have two pairs.")

#text("Then we note that each of these pairs of points")#linebreak()#text(" has the potential of forming a line with the")#linebreak()#text(" point p that has two twos in the coordinates i and j that the pair")#linebreak()#text(" of points differ and where the points of the pair have")#linebreak()#text(" the same coordinate p has that coordinate now")#linebreak()#text(" each such point p has the possibility of blocking two")#linebreak()#text(" such lines names those pairs nameless the pair")#linebreak()#text(" of points that has 11 and 33 in the coordinates where")#linebreak()#text(" p has two twos and the same coordinates as p elsewhere")#linebreak()#text(" and the points that have 13 and 31 in the points where")#linebreak()#text(" p has two 2’s and the same coordinates elsewhere")

#text("Now in the case of this Moser set with")#linebreak()#text(" Statistics (6,40,79,0,0,0)")#linebreak()#text(" We have two such pairs and since one of 80")#linebreak()#text(" Points with two twos is missing to avoid")#linebreak()#text(" A line the missing point must block both lines for the two")#linebreak()#text(" Pairs as above.")

#text("Now we have the from the above")#linebreak()#text(" four points which agree")#linebreak()#text(" On three coordinates and take on all")#linebreak()#text(" possible values on the remaining two coordinates.")#linebreak()#text(" They have the potential of forming lines")#linebreak()#text(" with those points with one two, namely those")#linebreak()#text(" points which agree which agree with the four")#linebreak()#text(" points on the the three coordinates mentioned")#linebreak()#text(" above and have one two and one arbitrary")#linebreak()#text(" value on the remaining two coordinates")#linebreak()#text(" there are four such points. The point p")#linebreak()#text(" mentoned earlier which agrees with the above")#linebreak()#text(" points in the three coordinates mentioned earlier")#linebreak()#text(" and has 2’s in the remaining coordinate")#linebreak()#text(" forms two lines with these points.")#linebreak()#text(" These lines are empty since p or any")#linebreak()#text(" of the other four points are in the Moser")#linebreak()#text(" set they form a a line with the points")#linebreak()#text(" in the two pairs.")

#text("The two lines were counted in the")#linebreak()#text(" Inequality 2B + C is less than or equal to")#linebreak()#text(" 160 with weight one half. which is lemma three in the Wiki section n=5")#linebreak()#text(" we can remove these two lines and count over the remaining lines")#linebreak()#text(" since they are empty 2B +C will not be effected but the 160")#linebreak()#text(" will be reduced to 158 so then we will have")#linebreak()#text(" 2B +C is less than or equal to 158")#linebreak()#text(" but 2B+C is 159 in the case with statistics")#linebreak()#text(" Statistics (6,40,79,0,0,0)")#linebreak()#text(" So only the remaining two statistics are possible and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36481")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2009")])]

#text("943. An alternate proof of ")#mi("c^{\\prime}_4 \\leq 43")

#text("Here is a relatively short, mostly human proof that ")#mi("c^{\\prime}_4 \\leq 43")#text(" using the extremals from the 3D theory.")

#text("When e=1 (i.e. the 4D set contains 2222) then we have at most 41 points (in fact at most 39) by counting antipodal points, so assume e=0.")

#text("Define the score of a 3D slice to be a/4+b/3+c/2+d. Observe from double counting that the size of a 4D set is the sum of the scores of its eight side slices.")

#text("But by looking at the extremals (see the spreadsheet")

#link("http://spreadsheets.google.com/ccc?key=p5T0SktZY9DuKZ2DyzO9EOg&hl=en#")[#text("http://spreadsheets.google.com/ccc?key=p5T0SktZY9DuKZ2DyzO9EOg&hl=en#")]

#text(") we see that the largest score is 44/8, attained at only one point, namely when (a,b,c,d) = (2,6,6,0). So the only way one can have a 44-point set is if all side slices are (2,6,6,0), or equivalently if the whole set has statistics (a,b,c,d,e) = (4,16,24,0,0). But then we have all the points with two 2s, which means that the four “a” points cannot be separated by Hamming distance 2. We conclude that we must have an antipodal pair among the “a” points with an odd number of 1s, and an antipodal pair among the “a” points with an even number of 1s. By the symmetries of the cube, we may take the a-set to then be 1111, 3333, 1113, 3331. But then the “b” set must exclude both 1112 and 3332, and so can have at most three points in the eight-point set xyz2 (with x,y,z=1,3) rather than four (to get four points one must alternate in a checkerboard pattern). Adding this to the at most four points of the form xy2z, x2yz, 2xyz we see that b is at most 16, a contradiction.")

#text("This argument also heuristically explains why the 43-point Moser sets have statistics close to (4,16,24,0,0).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36487")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2009")])]

#text("944. ")#mi("c^{\\prime}_6 \\leq 364")

#text("Michael’s method in 939 can be pushed a little bit. Given a Moser set in ")#mi("[3]^n")#text(", let ")#mi("\\alpha_i")#text(" denote the fraction of the points with i 2s in the cube that lie in the set; in terms of the (a,b,c,d,e) notation, we have ")#mi("\\alpha_0 = a/2^n, \\alpha_1 = b/(n 2^{n-1})")#text(", etc.")

#text("The double counting argument applied to side slices of ")#mi("[3]^{n+1}")#text(" tells us that any linear inequality between the ")#mi("\\alpha_i")#text(" that holds at dimension n, is also true at dimension n+1. Applying to middle slices instead, we see that any linear inequality between the ")#mi("\\alpha_i")#text(" that holds at dimension n, is also true at dimension n+1 after replacing each ")#mi("\\alpha_i")#text(" with ")#mi("\\alpha_{i+1}")#text(".")

#text("For instance, when n=3 a typical inequality is ")#mi("2a+b+2c+4d \\leq 22")#text(", which in normalized notation is ")#mi("8\\alpha_0+6\\alpha_1+6\\alpha_2+2\\alpha_3 \\leq 11")#text(". This inequality then holds for all higher n. For ")#mi("n \\geq 4")#text(" we also get the shifted inequality ")#mi("8\\alpha_1+6\\alpha_2+6\\alpha_3+2\\alpha_4 \\leq 11")#text(", for ")#mi("n \\geq 5")#text(" we get ")#mi("8\\alpha_2+6\\alpha_3+6\\alpha_4+2\\alpha_5 \\leq 11")#text(", etc.")

#text("Throwing all the inequalities descended from n=3 into a big list and using Maple’s linear programming routines, I can get an upper bound of 44 in four dimensions, 126 in five dimensions, and 364 in six dimensions. Here is the 6D code:")

#text("> with(simplex);")

#text("> X := [8*a+6*b+6*c+2*d<=11, 4*a+4*b+3*c+d<=6, 7*a+3*b+3*c+d <= 7, 4*b+2*c+d<=4, 4*a+6*c+2*d<=7, 6*a+3*c+d<=5, 2*a+d<=2, 2*b+d <= 2, 2*c+d <= 2, d <= 1, 8*b+6*c+6*d+2*e<=11, 4*b+4*c+3*d+e<=6, 7*b+3*c+3*d+e <= 7, 4*c+2*d+e<=4, 4*b+6*d+2*e<=7, 6*b+3*d+e<=5, 2*b+e<=2, 2*c+e <= 2, 2*d+e <= 2, e <= 1, 8*c+6*d+6*e+2*f<=11, 4*c+4*d+3*e+f<=6, 7*c+3*d+3*e+f <= 7, 4*d+2*e+f<=4, 4*c+6*e+2*f<=7, 6*c+3*e+f<=5, 2*c+f<=2, 2*d+f <= 2, 2*e+f <= 2, f <= 1, 8*d+6*e+6*f+2*g<=11, 4*d+4*e+3*f+g<=6, 7*d+3*e+3*f+g <= 7, 4*e+2*f+g<=4, 4*d+6*f+2*g<=7, 6*d+3*f+g<=5, 2*d+g<=2, 2*e+g <= 2, 2*f+g <= 2, g Z := 64*a+192*b+240*c+160*d+60*e+12*f+g;")

#text("> Z := 64*a+192*b+240*c+160*d+60*e+12*f+g;")

#text("> maximize(Z, X, NONNEGATIVE);")

#text("> evalf(subs(%,Z));")

#text("364.6984127")

#text("Incidentally, the statistics (a,b,c,d,e,f,g) of the maximiser are")

#text("[31.49206349, 94.98412698, 121.9047619, 83.80952381, 25.07936508, 7.428571429, 0.]")

#text("or in normalized form ")#mi("(\\alpha_0,\\ldots,\\alpha_6)")

#text("[0.4920634921, 0.4947089947, 0.5079365079, 0.5238095238, 0.4179894180, 0.6190476190, 0.]")

#text("thus one is filling up about half of each Behrend sphere (except for the origin 222222), which seems to be different behaviour from lower dimensions. [Perhaps this is because 6D is the first place where we really have to deal with sets of density less than 1/2.]")

#text("Presumably one could use the 4D and 5D data to generate more inequalities to dump into the pot, which should shave this upper bound downwards a bit. (But I did try tossing in the fact that 4D sets have at most 43 points, and (optimistically) 5D sets have at most 124 points, but got no improvement in the 6D bound this way.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a21d2891ca83a13147acdddc932f4ceb8569a3d2fd2111c6cd5e2044533ccaea-a49299ab26fda1a726dd0292d3db0cbd7bb2aaafab3831d8b174682928de1e1d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gilang")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36507")[#strong[#text("gilang")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("Prof. Tao, I am very interested with your blog although i am not a talented in mathematic. But now i will not ask you all about the complexity or what you have posted. My question just simple and for long time with big patient i waiting for propose this quastion for one of the great mathematician. What you feel or crossed in your mind that you are one of the outstanding mathematician ? Can you imagine that when you at 7 years old you just a little boy study mathematic and now you take the control on mathematic, i mean You haved extended Mathematic standpoint not as a student of mathematic anymore? Maybe my question too laud/praise for you and i know you are a humble mathematician as I know. But this is my trully question from my mind with big curiosity to you? I will be glad when you respond my question")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/comment-page-1/#comment-36508")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("945. Moser set n=5.")

#text("If a Moser set for n=5 has 125 points")#linebreak()#text(" It must have the following statistics:")#linebreak()#text(" • (8,39,78,0,0,0)")

#text("Assume it does not then the only remaining case")#linebreak()#text(" is that it must have these statistics:")#linebreak()#text(" • 7,40,78,0,0,0)")

#text("Now look at the 7 points with all coordinates not")#linebreak()#text(" equal to 2 Any set of 5 of these has one pair of")#linebreak()#text(" points that differ in exactly two coordinates")#linebreak()#text(" see the proof of lemma 3 in the Moser wiki.")#linebreak()#text(" We start with 5 of these points and get at least one")#linebreak()#text(" pair that differs in exactly two coordinates if there is more than")#linebreak()#text(" one we choose a pair")#linebreak()#text(" then we remove one of the points the pair and add the")#linebreak()#text(" additional point to replace then we have two pairs. We")#linebreak()#text(" keep doing this until we have three pairs.")

#text("If a line is to be avoided there must be a point with")#linebreak()#text(" two 2’s not in the in Moser set which has 2’s")#linebreak()#text(" where the points of the pair differ and for the")#linebreak()#text(" points where the pair agree it also agrees, if this")#linebreak()#text(" does not happen we will have a line.")

#text("Now we have the from the above")#linebreak()#text(" we have four points which agree")#linebreak()#text(" on three coordinates and take on all")#linebreak()#text(" possible values on the remaining two")#linebreak()#text(" coordinates.")

#text("They have the potential of forming lines")#linebreak()#text(" with those points with one two, namely those")#linebreak()#text(" points which agree which agree with the four")#linebreak()#text(" points on the the three coordinates mentioned")#linebreak()#text(" above and have one two and one arbitrary")#linebreak()#text(" value on the remaining two coordinates")#linebreak()#text(" there are four such points call the a, b,c,d. The point p")#linebreak()#text(" mentoned earlier which agrees with the above")#linebreak()#text(" points in the three coordinates mentioned earlier")#linebreak()#text(" and has 2’s in the remaining coordinate")#linebreak()#text(" forms two lines with these points.")#linebreak()#text(" these lines are empty since p or any")#linebreak()#text(" of the other four points are in the Moser")#linebreak()#text(" set they form a a line with the points")#linebreak()#text(" in the two pairs.")

#text("The two lines were counted in the")#linebreak()#text(" Inequality 2B + C is less than or equal to")#linebreak()#text(" 160 with weight one half. which is lemma three")#linebreak()#text(" we can remove these two lines and count over the remaining lines")#linebreak()#text(" since they are empty 2B +C will not be effected but the 160")#linebreak()#text(" will be reduced to 158 so then we will have")#linebreak()#text(" 2B +C is less than or equal to 158")#linebreak()#text(" but 2B+C is 158 in the case with statistics")#linebreak()#text(" Statistics (7,40,78,0,0,0)")

#text("Now this gives 2B+C for the remaining lines is less")#linebreak()#text(" Than or equal to 158 but 2B+C in this case = 158")#linebreak()#text(" Which means that every line must have exactly two points")#linebreak()#text(" We will use this fact in the proof that follows by starting")#linebreak()#text(" With empty points taking lines that aren’t the set that")#linebreak()#text(" Have the empty set and hence have to have the remaining")#linebreak()#text(" Point in the line we will use these points to force a line")#linebreak()#text(" In the set and thus get a contradiction.")

#text("For the empty set we start with the points a, b, c, d")#linebreak()#text(" Mentioned earlier have one two we are going")#linebreak()#text(" To force the existence of two sets of four points")#linebreak()#text(" Similar to a,b,c,d")#linebreak()#text(" They are identical to points of a, b, c,d except")#linebreak()#text(" In one coordinate.")

#text("Let us assume that the points")#linebreak()#text(" Of p have the following form 111xy where")#linebreak()#text(" The fixed coordinates are assumed to be 1")#linebreak()#text(" And in the first three places and x and y are")#linebreak()#text(" The moving coordinates. Then a b c d")#linebreak()#text(" Are of the form 11121, 11123, 11112, 11132.")#linebreak()#text(" The two new sets of similar to a b c d")#linebreak()#text(" Are 13121, 13123, 13112, 13132 and")#linebreak()#text(" 11321, 11323, 11312, 11332 we get that")#linebreak()#text(" they must be in the Moser set by the above")#linebreak()#text(" and looking at lines 1×121, 1×123, 1×112, 1×132")#linebreak()#text(" and 11×21, 11×23, 11×12, 11×32")#linebreak()#text(" where x denotes a coordinate that may take")#linebreak()#text(" any of three values which are")#linebreak()#text(" not in the lines removed and hence by the above")#linebreak()#text(" must have 2 points and hence give us the 8 new")#linebreak()#text(" points mentioned above in the Moser set.")#linebreak()#text(" Now we note that the points")#linebreak()#text(" 13121, 13123, 13112, 13132")#linebreak()#text(" together with 13122 forms a monochromatic line")#linebreak()#text(" in fact two monochromatic lines so the 13122")#linebreak()#text(" must not be in the set since we already have")#linebreak()#text(" 11122 is not in the set all other points with")#linebreak()#text(" two twos must be in the set now")#linebreak()#text(" look at the points 11321, 11323, 11312, 11332")#linebreak()#text(" which must be in the set")#linebreak()#text(" together with 11322 which must be in the set they")#linebreak()#text(" form a monochromatic line in the set so we get")#linebreak()#text(" a contradiction.")

#text("Similarly we can form 8 such points")#linebreak()#text(" from the points p and a, b, c and d above")#linebreak()#text(" no matter what the value of the the fixed coordinates")#linebreak()#text(" and no matter the position of the fixed coordinates")#linebreak()#text(" and force a monochromatic line in the same way")#linebreak()#text(" and the get a contradiction so the only case remaining")#linebreak()#text(" is: that having statistics (8,39,78,0,0,0) and we are done.")
]
