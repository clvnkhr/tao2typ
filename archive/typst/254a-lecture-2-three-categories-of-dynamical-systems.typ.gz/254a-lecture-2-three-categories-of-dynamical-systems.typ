// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/
// Converted to Typst by tao2typ: "2026-10-14T16:35:08.622971+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Lecture 2: Three categories of dynamical systems", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Lecture 2: Three categories of dynamical systems")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 January 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/")[#text("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Before we begin or study of dynamical systems, topological dynamical systems, and measure-preserving systems (as defined in the ")#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/")[#text("previous lecture")]#text("), it is convenient to give these three classes the structure of a ")#link("http://en.wikipedia.org/wiki/Category_theory")[#text("category")]#text(". One of the basic insights of category theory is that a mathematical objects in a given class (such as dynamical systems) are best studied not in isolation, but in relation to each other, via ")#link("http://en.wikipedia.org/wiki/Morphism")[#text("morphisms")]#text(". Furthermore, many other basic concepts pertaining to these objects (e.g. subobjects, factors, direct sums, irreducibility, etc.) can be defined in terms of these morphisms. One advantage of taking this perspective here is that it provides a unified way of defining these concepts for the three different categories of dynamical systems, topological dynamical systems, and measure-preserving systems that we will study in this course, thus sparing us the need to give any of our definitions (except for our first one below) in triplicate.")

#metadata(none) <tao-af69023f0b081d7e0323>

#text("Informally, a morphism between two objects in a class is any map which respects all the structures of that class. For the three categories we are interested in, the formal definition is as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1")]#text(". (Morphisms)")

#enum(start: 1, 
[#text("A ")#emph[#text("morphism")]#text(" ")#mi("\\phi: (X,T) \\to (Y,S)")#text(" between two dynamical systems is a map ")#mi("\\phi: X \\to Y")#text(" which intertwines T and S in the sense that ")#mi("S \\circ \\phi = \\phi \\circ T")#text(".")],
[#text("A ")#emph[#text("morphism")]#text(" ")#mi("\\phi: (X, {\\mathcal F}, T) \\to (Y, {\\mathcal G}, S)")#text(" between two topological dynamical systems is a morphism ")#mi("\\phi: (X,T) \\to (Y,S)")#text(" of dynamical systems which is also continuous, thus ")#mi("\\phi^{-1}(U) \\in {\\mathcal F}")#text(" for all ")#mi("U \\in {\\mathcal G}")#text(".")],
[#text("A ")#emph[#text("morphism")]#text(" ")#mi("\\phi: (X, {\\mathcal X},\\mu, T) \\to (Y, {\\mathcal Y}, \\nu, S)")#text(" between two measure-preserving systems is a morphism ")#mi("\\phi: (X,T) \\to (Y,S)")#text(" of dynamical systems which is also measurable (thus ")#mi("\\phi^{-1}(E) \\in {\\mathcal X}")#text(" for all ")#mi("E \\in {\\mathcal Y}")#text(") and measure-preserving (thus ")#mi("\\mu( \\phi^{-1}(E) ) = \\nu( E )")#text(" for all ")#mi("E \\in {\\mathcal Y}")#text("). Equivalently, ")#mi("\\nu = \\phi_*(\\mu)")#text(" is the ")#link("http://en.wikipedia.org/wiki/Pushforward_measure")[#text("push-forward")]#text(" of ")#mi("\\mu")#text(" by ")#mi("\\phi")#text(".")]
)

#text("When it is clear what category we are working in, and what the shifts are, we shall often refer to a system by its underlying space, thus for instance a morphism ")#mi("\\phi: (X,{\\mathcal X},\\mu,T) \\to (Y,{\\mathcal Y},\\nu,S)")#text(" might be abbreviated as ")#mi("\\phi: X \\to Y")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("If a morphism ")#mi("\\phi: X \\to Y")#text(" has an inverse ")#mi("\\phi^{-1}: Y \\to X")#text(" which is also a morphism, we say that ")#mi("\\phi")#text(" is an ")#link("http://en.wikipedia.org/wiki/Isomorphism")[#text("isomorphism")]#text(", and that X and Y are ")#emph[#text("isomorphic")]#text(" or ")#emph[#text("conjugate")]#text(".")
]

#text("It is easy to see that morphisms obey the axioms of a (")#link("http://en.wikipedia.org/wiki/Concrete_category")[#text("concrete")]#text(") category, thus the identity map ")#mi("\\text{id}_X: X \\to X")#text(" on a system is always a morphism, and the composition ")#mi("\\psi \\circ \\phi: X \\to Z")#text(" of two morphisms ")#mi("\\phi: X \\to Y")#text(" and ")#mi("\\psi: Y \\to Z")#text(" is again a morphism.")

#text("Let’s give some simple examples of morphisms.")

#list(
[#strong[#text("Example 1.")]#text(" If (X,T) is a dynamical system, a topological dynamical system, or a measure-preserving dynamical system, then ")#mi("T^n: X \\to X")#text(" is an isomorphism for any integer n. (Indeed, one can view the map ")#mi("X \\mapsto T^n")#text(" as a ")#strike[#text("covariant functor")]#text(" ")#link("http://en.wikipedia.org/wiki/Natural_transformation")[#text("natural transformation")]#text(" from the identity ")#link("http://en.wikipedia.org/wiki/Functor")[#text("functor")]#text(" on the category of dynamical systems (or topological dynamical systems, etc.) to itself, although we will not take this perspective here.)")],
[#strong[#text("Example 2")]#text(" (Subsystems). Let (X,T) be a dynamical system, and let E be a subset of X which is T-invariant in the sense that ")#mi("T^n E = E")#text(" for all n. Then the restriction of ")#mi("(E, T\\downharpoonright_E)")#text(" of (X,T) to E is itself a dynamical system, and the inclusion map ")#mi("\\iota: E \\to X")#text(" is a morphism. In the category of topological dynamical systems ")#mi("(X,{\\mathcal F},T)")#text(", we have the same assertion so long as E is ")#emph[#text("closed")]#text(" (hence compact, since X is compact). In the category of measure-preserving systems ")#mi("(X,{\\mathcal X},\\mu,T)")#text(", we have the same assertion so long as E has full measure (thus ")#mi("E \\in {\\mathcal X}")#text(" and ")#mi("\\mu(E)=1")#text("). We thus see that subsystems are not very common in measure-preserving systems and will in fact play very little role there; however, subsystems (and specifically, ")#emph[#text("minimal")]#text(" subsystems) will play a fundamental role in topological dynamics.")],
[#strong[#text("Example 3")]#text(" (Skew shift). Let ")#mi("\\alpha \\in {\\Bbb R}")#text(" be a fixed real number. Let ")#mi("(X,T)")#text(" be the dynamical system ")#mi("X := ({\\Bbb R}/{\\Bbb Z})^2, T: (x_1,x_2)  \\mapsto (x_1+\\alpha,x_2+x_1)")#text(", let ")#mi("(Y,S)")#text(" be the dynamical system ")#mi("Y := {\\Bbb R}/{\\Bbb Z}, S: y \\mapsto y+\\alpha")#text(", and let ")#mi("\\pi: X \\to Y")#text(" be the projection map ")#mi("\\pi: (x_1,x_2) \\to x_1")#text(". Then ")#mi("\\pi")#text(" is a morphism. If one converts X and Y into either a topological dynamical system or a measure-preserving system in the obvious manner, then ")#mi("\\pi")#text(" remains a morphism. Observe that ")#mi("\\pi")#text(" foliates the big space X “upstairs” into “vertical” fibres ")#mi("\\pi^{-1}(\\{y\\}), y \\in Y")#text(" indexed by the small “horizontal” space “downstairs”; the shift S on the factor space Y downstairs determines how the fibres move (the shift T upstairs sends each vertical fibre ")#mi("\\pi^{-1}(\\{y\\})")#text(" to another vertical fibre ")#mi("\\pi^{-1}(\\{S y\\})")#text(", but does not govern the dynamics ")#emph[#text("within")]#text(" each fibre. More generally, any ")#emph[#text("factor map")]#text(" (i.e. a surjective morphism) exhibits this type of behaviour. (Another example of a factor map is the map ")#mi("\\pi: {\\Bbb Z}/N{\\Bbb Z} \\to {\\Bbb Z}/M{\\Bbb Z}")#text(" between two cyclic groups (with the standard shift ")#mi("x \\mapsto x+1")#text(") given by ")#mi("\\pi: x \\mapsto x \\text{ mod } M")#text(". This is a well-defined factor map when M is a factor of N, which may help explain the terminology. If we wanted to adhere strictly to the category theoretic philosophy, we should use ")#link("http://en.wikipedia.org/wiki/Epimorphism")[#text("epimorphisms")]#text(" rather than surjections, but we will not require this subtle distinction here.)")],
[#strong[#text("Example 4")]#text(" (Universal pointed dynamical system). Let ")#mi("{\\Bbb Z} = ({\\Bbb Z}, +1)")#text(" be the dynamical system given by the integers with the standard shift ")#mi("n \\mapsto n+1")#text(". Then given any other dynamical system (X,T) with a distinguished point ")#mi("x \\in X")#text(", the orbit map ")#mi("\\phi: n \\mapsto T^n x")#text(" is a morphism from ")#mi("{\\Bbb Z}")#text(" to ")#mi("X")#text(". This allows us to lift most questions about dynamical systems (with a distinguished point x) to those for a single “universal” dynamical system, namely the integers (with distinguished point 0). One cannot pull off the same trick directly with topological dynamical systems or measure-preserving systems, because ")#mi("{\\Bbb Z}")#text(" is non-compact and does not admit a shift-invariant probability measure. As we shall see later, the former difficulty can be resolved by passing to a universal compactification of the integers, namely the ")#link("http://en.wikipedia.org/wiki/Stone-Cech_compactification")[#text("Stone–Čech compactification")]#text(" ")#mi("{\\beta} {\\Bbb Z}")#text(" (or equivalently, the space of ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilters")]#text(" on the integers), though with the important caveat that this compactification is not metrisable. To resolve the second difficulty (with the assistance of a distinguished set rather than a distinguished point), see the next example.")],
[#strong[#text("Example 5")]#text(" (Universal dynamical system with distinguished set). Recall the boolean Bernoulli system ")#mi("(2^{\\Bbb Z},U)")#text(" (Example 6 from the ")#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/")[#text("previous lecture")]#text("). Given any other dynamical system ")#mi("(X,T)")#text(" with a distinguished set ")#mi("A \\subset X")#text(", the ")#emph[#text("recurrence map")]#text(" ")#mi("\\phi: X \\to 2^{\\Bbb Z}")#text(" defined by ")#mi("\\phi(x) := \\{ n \\in {\\Bbb Z}: T^n x \\in A \\}")#text(" is a morphism. Observe that ")#mi("A = \\phi^{-1}(B)")#text(", where B is the ")#link("http://en.wikipedia.org/wiki/Cylinder_set")[#text("cylinder set")]#text(" ")#mi("B := \\{ E \\in 2^{\\Bbb Z}: 0 \\in E \\}")#text(". Thus we can push forward an arbitrary dynamical system ")#mi("(X,T,A)")#text(" with distinguished set to a universal dynamical system ")#mi("(2^{\\Bbb Z},U,B)")#text(". Actually one can restrict ")#mi("(2^{\\Bbb Z},U,B)")#text(" to the subsystem ")#mi("(\\phi(X), U\\downharpoonright_{\\phi(X)}, B \\cap \\phi(X))")#text(", which is easily seen to be shift-invariant. In the category of topological dynamical systems, the above assertions still hold (giving ")#mi("2^{\\Bbb Z}")#text(" the ")#link("http://en.wikipedia.org/wiki/Product_topology")[#text("product topology")]#text("), so long as A is clopen. In the category of measure-preserving systems ")#mi("(X,{\\mathcal X},\\mu,T)")#text(", the above assertions hold as long as A is measurable, ")#mi("2^{\\Bbb Z}")#text(" is given the product ")#mi("\\sigma")#text("-algebra, and the ")#link("http://en.wikipedia.org/wiki/Pushforward_measure")[#text("push-forward measure")]#text(" ")#mi("\\phi_*(\\mu)")#text(".")]
)

#text("Now we begin our analysis of dynamical systems. When studying other mathematical objects (e.g. groups or representations), often one of the first steps in the theory is to decompose general objects into “irreducible” ones, and then hope to classify the latter. Let’s see how this works for dynamical systems (X,T) and topological dynamical systems ")#mi("(X,{\\mathcal F},T)")#text(". (For measure-preserving systems, the analogous decomposition will be the ")#emph[#text("ergodic decomposition")]#text(", which we will discuss later in this course.)")

#text("Define a ")#emph[#text("minimal")]#text(" dynamical system to be a system (X,T) which has no ")#link("http://en.wikipedia.org/wiki/Proper_subset")[#text("proper")]#text(" subsystems (Y,S). Similarly define a minimal topological dynamical system to be a system ")#mi("(X,{\\mathcal F},T)")#text(" with no proper subsystems ")#mi("(Y, {\\mathcal G},S)")#text(". [One could make the same definition for measure-preserving systems, but it tends to be a bit vacuous – given any measure preserving system that contains points of measure zero, one can make it trivially smaller by removing the ")#link("http://en.wikipedia.org/wiki/Orbit_%28dynamics%29")[#text("orbit ")]#mi("T^{\\Bbb Z} x := \\{ T^n x: n \\in {\\Bbb Z}\\}")#text(" of any point x of measure zero. One could place a topology on the space X and demand that it be compact, in which case minimality just means that the probability measure ")#mi("\\mu")#text(" has full ")#link("http://en.wikipedia.org/wiki/Support_(measure_theory)")[#text("support")]#text(".]")

#text("For a dynamical system, it is not hard to see that for any ")#mi("x \\in X")#text(", the orbit ")#mi("Y = T^{\\Bbb Z} x = \\{ T^n x: n \\in {\\Bbb Z}\\}")#text(" is a minimal system, and conversely that all minimal systems arise in this manner; in particular, every point is contained in a minimal orbit. It is also easy to see that any two minimal systems (i.e. orbits) are either disjoint or coincident. Thus every dynamical system can be uniquely decomposed into the disjoint union of minimal systems. Also, every orbit ")#mi("T^{\\Bbb Z} x")#text(" is isomorphic to ")#mi("{\\Bbb Z}/\\text{Stab}(x)")#text(", where ")#mi("\\text{Stab}(x) := \\{ n \\in {\\Bbb Z}: T^n x = x \\}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Orbit_%28group_theory%29#Orbits_and_stabilizers")[#text("stabiliser")]#text(" group of x. Since we know what all the subgroups of ")#mi("{\\Bbb Z}")#text(", we conclude that every minimal system is either equivalent to a cyclic group shift ")#mi("({\\Bbb Z}/N{\\Bbb Z}, x \\mapsto x+1)")#text(" for some ")#mi("N \\geq 1")#text(", or to the integer shift ")#mi("({\\Bbb Z}, x \\mapsto x+1)")#text(". Thus we have completely classified all dynamical systems up to isomorphism as the arbitrary union of these minimal examples. [In the case of finite dynamical systems, the integer shift does not appear, and we have recovered the classical fact that every ")#link("http://en.wikipedia.org/wiki/Permutation")[#text("permutation")]#text(" is uniquely decomposable as the product of disjoint ")#link("http://en.wikipedia.org/wiki/Cycle_%28mathematics%29")[#text("cycles")]#text(".]")

#text("For topological dynamical systems, it is still true that any two minimal systems are either disjoint or coincident (why?), but the situation nevertheless is more complicated. First of all, orbits need not be closed (consider for instance the circle shift ")#mi("({\\Bbb R}/{\\Bbb Z}, x \\mapsto x+\\alpha)")#text(" with ")#mi("\\alpha")#text(" irrational). If one considers the ")#emph[#text("orbit closure")]#text(" ")#mi("\\overline{T^{\\Bbb Z} x}")#text(" of a point x, then this is now a subsystem (why?) , and every minimal system is the orbit closure of any of its elements (why?), but in the converse direction, not all orbit closures are minimal. Consider for instance the boolean Bernoulli system ")#mi("(2^{\\Bbb Z}, A \\mapsto A-1)")#text(" with ")#mi("x = {\\Bbb N} := \\{ 0,1,2,\\ldots\\} \\in 2^{\\Bbb Z}")#text(" being the natural numbers. Then the orbit ")#mi("T^{\\Bbb Z} x")#text(" of x consists of all the half-lines ")#mi("\\{ a,a+1,\\ldots,\\} \\in 2^{\\Bbb Z}")#text(" for ")#mi("a \\in {\\Bbb Z}")#text(", but it is not closed; it has the point ")#mi("{\\Bbb Z} \\in 2^{\\Bbb Z}")#text(" and the point ")#mi("\\emptyset \\in 2^{\\Bbb Z}")#text(" as limit points (recall that ")#mi("2^{\\Bbb Z}")#text(" is given the product (i.e. pointwise) topology). Each of these points is an invariant point of T and thus forms its own orbit closure, which is obviously minimal. [In particular, this shows that x itself is not contained in any minimal system – why?]")

#text("Thus we see that finite dynamical systems do not quite form a perfect model for topological dynamical systems. A slightly better (but still imperfect) model would be that of ")#emph[#text("non-invertible")]#text(" finite dynamical systems ")#mi("(X,T)")#text(", in which ")#mi("T: X \\to X")#text(" is now just a function rather than a permutation. Then we can still verify that all minimal orbits are given by disjoint cycles, but they no longer necessarily occupy all of X; it is quite possible for the orbit ")#mi("T^{\\Bbb N} x = \\{ T^n x: n \\in {\\Bbb N} \\}")#text(" of a point x to start outside of any of the minimal cycles, although it will eventually be absorbed in one of them.")

#text("In the above examples, the limit points of an orbit formed their own minimal orbits. In some cases, one has to pass to limits multiple times before one reaches a minimal orbit (cf. the “Glaeser refinements” in this ")#link("https://terrytao.wordpress.com/2007/11/15/distinguished-lecture-series-ii-charles-fefferman-interpolation-of-functions-on-rn/")[#text("lecture of Charlie Fefferman")]#text("). For instance, consider the boolean Bernoulli system again, but now consider the point")

#mi("y := \\bigcup_{n=0}^\\infty [4^n,2 \\times 4^n] = [1,2] \\cup [4,8] \\cup [16,32] \\cup \\ldots \\in 2^{\\Bbb Z}")

#text("where we use the notation ")#mi("{}[N,M] := \\{ n \\in {\\Bbb Z}: N \\leq n \\leq M \\}")#text(". Observe that the point x defined earlier is not in the orbit ")#mi("T^{\\Bbb N} y")#text(", but lies in the orbit closure, as it is the limit of ")#mi("T^{4^n} y")#text(". On the other hand, the orbit closure of x does not contain y. So the orbit closure of x is a subsystem of that of y, and then inside the former system one has the minimal systems ")#mi("\\{ {\\Bbb Z} \\}")#text(" and ")#mi("\\{ \\emptyset \\}")#text(". It is not hard to iterate this type of example and see that we can have quite intricate hierarchies of systems.")

#strong[#text("Exercise 1")]#text(". Construct a topological dynamical system ")#mi("(X,{\\mathcal F},T)")#text(" and a sequence of orbit closures ")#mi("\\overline{T^{\\Bbb Z} x_n}")#text(" in X which form a proper nested sequence, thus")

#mi("\\overline{T^{\\Bbb Z} x_1} \\supsetneq \\overline{T^{\\Bbb Z} x_2} \\supsetneq \\overline{T^{\\Bbb Z} x_3} \\supsetneq \\ldots")

#text("[")#emph[#text("Hint")]#text(": Take a countable family of nested Bernoulli systems, and find a way to represent each one as a orbit closure.] ")#mi("\\diamond")

#text("Despite this apparent complexity, we can always terminate such hierarchies of subsystems at a minimal system:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(". Every topological dynamical system ")#mi("(X,{\\mathcal F},T)")#text(" contains a minimal dynamical system.")
]

#strong[#text("Proof")]#text(". Observe that the intersection of any chain of subsystems of X is again a subsystem (here we use the ")#link("http://en.wikipedia.org/wiki/Finite_intersection_property")[#text("finite intersection property")]#text(" of compact sets to guarantee that the intersection is non-empty, and we also use the fact that the arbitrary intersection of closed or T-invariant sets is again closed or T-invariant). The claim then follows from ")#link("http://en.wikipedia.org/wiki/Zorn%27s_lemma")[#text("Zorn’s lemma")]#text(". [We will always assume the ")#link("http://en.wikipedia.org/wiki/Axiom_of_choice")[#text("axiom of choice")]#text(" throughout this course.] ")#mi("\\Box")

#strong[#text("Exercise 2")]#text(". Every compact metrisable space is ")#link("http://en.wikipedia.org/wiki/Second_countable")[#text("second countable")]#text(" and thus has a countable ")#link("http://en.wikipedia.org/wiki/Base_%28topology%29")[#text("base")]#text(". Suppose we are given an explicit enumeration ")#mi("V_1,V_2,\\ldots")#text(" of such a base. Then find a proof of Lemma 1 which avoids the axiom of choice. ")#mi("\\diamond")

#text("It would be nice if we could use Lemma 1 to decompose topological dynamical systems into the union of minimal subsystems, as we did in the case of non-topological dynamical systems. Unfortunately this does not work so well; the problem is that the complement of a minimal system is an open set rather than a closed set, and so we cannot cleanly separate a minimal system from its complement. (In any case, the preceding examples already show that there can be some points in a system that are not contained in any minimal subsystem. Also, in contrast with non-invertible non-topological dynamical systems, our examples also show that a closed orbit can contain multiple minimal subsystems, so we cannot reduce to some sort of “nilpotent” system that has only one minimal system.)")#linebreak()#text(" We will study minimal dynamical systems in detail in the next few lectures. I’ll close now with some examples of minimal systems.")

#strong[#text("Example 6")]#text(" (Cyclic group shift). The cyclic group shift ")#mi("({\\Bbb Z}/N{\\Bbb Z}, x\\mapsto x+1)")#text(", where N is a positive integer, is a minimal system, and these are the only discrete minimal topological dynamical systems. More generally, if x is a periodic point of a topological dynamical system (thus ")#mi("T^N x = x")#text(" for some ")#mi("N \\geq 1")#text("), then the closed orbit of x is isomorphic to a cyclic group shift and is thus minimal.")

#strong[#text("Example 7")]#text(" (Torus shift). Consider a torus shift ")#mi("( ({\\Bbb R}/{\\Bbb Z})^d, x \\mapsto x+\\alpha)")#text(", where ")#mi("\\alpha \\in {\\Bbb R}^d")#text(" is a fixed vector. It turns out that this system is minimal if and only if ")#mi("\\alpha")#text(" is ")#emph[#text("totally irrational")]#text(", which means that ")#mi("n \\cdot \\alpha")#text(" is not an integer for any non-zero ")#mi("n \\in {\\Bbb Z}^d")#text(". (The “if” part is slightly non-trivial, requiring ")#link("http://en.wikipedia.org/wiki/Equidistribution_theorem")[#text("Weyl’s equidistribution theorem")]#text("; but the “only if” part is easy, and is left as an exercise.)")

#strong[#text("Example 8")]#text(" (Morse sequence): Let ")#mi("A = \\{a,b\\}")#text(" be a two-letter alphabet, and consider the Bernoulli system ")#mi("(A^{\\Bbb Z},T)")#text(" formed from doubly infinite words")

#align(center)[#tao-fit-display[#mitex("\\ldots x_{-2} x_{-1}.x_0 x_1 x_2 \\ldots")]]

#text("in A with the left-shift. Now define the sequence of finite words")

#align(center)[#mi("w_1 := a.b")#text(", ")#mi("w_2 := abba.baab")#text(", ")#mi("w_3 := abbabaabbaababba.baababbaabbabaab")#text(", etc.")]

#text("by the recursive formula")

#align(center)[#tao-fit-display[#mitex("w_1 := a.b; \\quad w_{i+1} := f(w_i)")]]

#text("where ")#mi("f(w)")#text(" denotes the word formed from w by replacing each occurrence of a and b by abba and baab respectively. These words ")#mi("w_i")#text(" converge pointwise to an infinite word")

#align(center)[#mi("w = \\ldots abbabaababbabaabbaababba.baababbaabbabaababbabaab\\ldots")#text(".")]

#strong[#text("Exercise 3")]#text(". Show that w is not a periodic element of ")#mi("A^{\\Bbb Z}")#text(", but that the orbit ")#mi("\\overline{T^{\\Bbb Z} w}")#text(" is both closed and minimal. [Hint: find large subwords of w which appear ")#link("http://en.wikipedia.org/wiki/Syndetic_set")[#text("syndetically")]#text(", which means that the gaps between each appearance are bounded. In fact, all subwords of w appear syndetically. One can also work with a more explicit description of w involving the number of non-zero digits in the binary expansion of the index.] This set is an example of a ")#emph[#text("substitution minimal set")]#text(". ")#mi("\\diamond")

#strong[#text("Exercise 4")]#text(". Let ")#mi("(X, {\\mathcal F}, T)")#text(" and ")#mi("(Y, {\\mathcal G}, S)")#text(" be topological dynamical systems. Define the ")#emph[#text("product")]#text(" of these systems to be ")#mi("(X \\times Y, {\\mathcal F} \\times {\\mathcal G}, T \\times S)")#text(", where ")#mi("X \\times Y")#text(" is the ")#link("http://en.wikipedia.org/wiki/Cartesian_product")[#text("Cartesian product")]#text(", ")#mi("{\\mathcal F} \\times {\\mathcal G}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Product_topology")[#text("product topology")]#text(", and ")#mi("T \\times S")#text(" is the map ")#mi("(x,y) \\mapsto (Tx,Sy)")#text(". Note that there are obvious projection morphisms from this product system to the two original systems. Show that this product system is indeed a ")#link("http://en.wikipedia.org/wiki/Product_%28category_theory%29")[#text("product in the sense of category theory")]#text(". Do analogous claims hold in the categories of dynamical systems and measure-preserving systems? ")#mi("\\diamond")

#strong[#text("Exercise 5.")]#text(" Let ")#mi("(X, {\\mathcal F}, T)")#text(" and ")#mi("(Y, {\\mathcal G}, S)")#text(" be topological dynamical systems. Define the ")#emph[#text("disjoint union")]#text(" of these systems to be ")#mi("(X \\uplus Y, {\\mathcal F} \\uplus {\\mathcal G}, T \\uplus S)")#text(" where ")#mi("(X \\uplus Y, {\\mathcal F} \\uplus {\\mathcal G})")#text(" is the ")#link("http://en.wikipedia.org/wiki/Disjoint_union_%28topology%29")[#text("disjoint union")]#text(" of ")#mi("(X,{\\mathcal F})")#text(" and ")#mi("(Y,{\\mathcal G})")#text(", and ")#mi("T \\uplus S")#text(" is the map which agrees with T on X and agrees with S on Y. Note that there are obvious embedding morphisms from the original two systems into the disjoint union. Show that the disjoint union is a ")#link("http://en.wikipedia.org/wiki/Coproduct")[#text("coproduct in the sense of category theory")]#text(". Are analogous claims true for the categories of dynamical systems and measure-preserving systems? ")#mi("\\diamond")

#text("[")#emph[#text("Update")]#text(", Jan 11: several corrections.]")

#text("[")#emph[#text("Update")]#text(", Jan 14: A required to be clopen in the topological version of Example 4.]")

#text("[")#emph[#text("Update")]#text(", Jan 17: Slight change to Example 7.]")

#text("[Update, Jan 20: More exercises added.]")

#heading(level: 1)[#text("Comments (36)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c257ec4509388d8e9f186e1ef453458356a2f9940f80d4c20f997595b54d2353-40978253acb14b75f7c8c045398eedb0a7aa78e2b9b130ca8f0533bebd9d1797.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hao")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-23928")[#strong[#text("Hao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2008")])]

#text("Dear Prof. Tao,")

#text("Is the covariant functor in example 1 given by:")#linebreak()#text(" sends (X,T) to (X,T^n)")#linebreak()#text(" and the morphism (a map that interwines T and S) to a map that interwines T^n and S^n?")

#text("I am not sure about what X->T^n means in the example.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/573d2542ab1f1dbc3aa25ef136ef711e6751ba35c1b4c15c36cc4b068a8c5dfd-811059f52c94f0492664ad3b7849f5bdce509d50393a8abe6b70a2eb60c38940.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy P.")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-23931")[#strong[#text("Andy P.")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2008")])]

#text("A very nice lecture! Some comments/corrections:")

#text("When you refer to previous lectures (like in Ex 5), please put a link")

#text("Ex 1 : The notation X–>T^n is confusing. Better would be (X,T)–>(X,T^n)")

#text("Ex 3 : Using y for the second coordinate in X and Y for the second dynamical system (the projection of X onto its FIRST coordinate) is confusing.")

#text("Ex 5 : Shouldn’t \\phi(A) be contained in, not equal to B? Also, the thing you restrict to should be (I think) the intersection of B with \\phi(X), not U.")

#text("Last sentence in paragraph starting with “For topological dynamical systems…” : What is $y$?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-23951")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2008")])]

#text("Thanks for the corrections! Sorry about the confusion with the functor business; I meant “natural transformation” instead.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of orr")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-24101")[#strong[#text("orr")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2008")])]

#text("One remark of yours made me jump:")#linebreak()#text(" [We will always assume the axiom of choice throughout this course.]")

#text("Do you not always assume the axiom of choice?")#linebreak()#text(" It would would be very interesting to hear your opinion on this matter.")#linebreak()#text(" In particular, is your (and Green’s) result about arithmetic progression in the primes independent of the axiom of choice?")#linebreak()#text(" Can much of your work related on PDE’s be carried out rigorously without it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-24178")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2008")])]

#text("Dear Orr,")

#text("For large parts of mathematics (including my work with Ben on the primes, or my various works on PDE) it is not difficult to remove the axiom of choice from one’s arguments (though it is still very convenient to hold on to the axiom of infinity). A general rule of thumb is that if Zorn’s lemma is not being used explicitly or implicitly anywhere in one’s theory and arguments, then the axiom of choice can usually be removed. Even when Zorn’s lemma is being used, one can often eliminate the use of choice (or at least fall back to a weaker version of choice, such as countable choice) by replacing the use of that lemma with more complicated substitutes.")

#text("Of course, thanks to Godel’s work on the independence of AC from the other axioms of set theory, it is completely safe to use the axiom of choice for the purposes of establishing finitary conclusions (provided of course that one believes in the consistency of set theory, but if you don’t, then the axiom of choice should be the least of your concerns). But it is still useful to gauge the extent to which AC is used in an argument, as it gives a crude measure as to how easy it will be to make the arguments quantitative, and how strong the bound is going to be; as a rule of thumb, the more one relies on AC, the harder it is going to be to extract a civilised quantitative bound.")

#text("Another reason why it is worth noting when AC is used in a non-trivial manner is to alert the reader to the possibility that pathological objects, such as non-Lebesgue measurable sets, may potentially arrive on the scene, allowing one to guard against some standard errors in the subject.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-24276")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2008")])]

#text("Sorry to ask a dumb question, but am I right in thinking that you’ve used the product topology on {0,1}^Z induced by the topology {empty, {1}, {0,1}} on {0,1} (as opposed to 2^{0,1})?")

#text("Also, to repeat a correction of Andy P, shouldn’t the restricted subsystem in Example 5 read (\\phi(X), U|_\\phi(X), B \\intersection \\phi(X) )?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-24309")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2008")])]

#text("Thanks for the (reiterated) correction. In this particular case, I would like to put the discrete topology on {0,1} (to keep everything Hausdorff, which is a necessary condition for metrisability). There are some places in which the non-Hausdorff topology on {0,1} is also useful (as pointed out by another commenter, this is the correct base topology in which to construct Stone-Cech compactifications of non-discrete spaces) but I doubt I will need to use it much in this course.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-24315")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2008")])]

#text("But doesn’t using the discrete topology on {0,1} mean that (in Example 5) for the map \\phi to be continuous, the set A must be both open and closed. Since if \\pi_n is the projection from 2^Z to the nth coordinate, then we want the following set to be open: \\phi^{-1} (\\pi_n^{-1} {0}) = X \\ (T^n)^{-1}(A) ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-24317")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2008")])]

#text("Oops, you’re right; A does need to be clopen for the topological version of Example 5. (I will primarily use this space in the measure category rather than the topological category, though.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-24660")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2008")])]

#text("What do you mean by ‘totally irrational’ in Example 7? Under your definition, no real vector is totally irrational (take n to be the zero vector).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-24670")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2008")])]

#text("Oops, I forgot to state that n needs to be non-zero. This should be fixed now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-24770")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2008")])]

#text("What is an distinguished set or an distinguished point?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-24773")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2008")])]

#text("Dear Anonymous,")

#text("A distinguished object is simply an object (among many in a certain class) that we give a special name to (this is sometimes called a “marked object”, “preferred object”, “chosen object”, or “special object” instead of a “distinguished object”). Choosing objects such as points, coordinate frames, metrics, orientations, etc. on a space tends to create more structure on that space, at the expense of less symmetry (as one gives up the freedom to move that object around). For instance, a vector space can be viewed as an affine space with a distinguished point, namely the origin 0, thus giving up translation symmetry for vector space structure; a Cartesian plane can be viewed as a two-dimensional vector space with a distinguished basis (namely the standard basis ")#mi("\\{e_1,e_2\\}")#text("), thus giving up linear transformation symmetry for coordinate structure; and so forth.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liu")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-24950")[#strong[#text("Liu")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2008")])]

#text("Dear Prof. Tao,")#linebreak()#text(" About example 7, what if \\alpha is equal to (1,1,…,1)? Then TZx is x itself.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9567992adfdc46e689b6c8702f08facf0c15a08c7f5cf7d8a8551679e73bdb2-7aa49d595a79f0ff1b87fe4d34c0e4e1fcbc9cc0c0f526e493edf0538e74b9c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-24955")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2008")])]

#text("Dear Prof. Tao,")

#text("In exercise 2 of this lecture, you conclude “(…) Then find a proof of Lemma 1 which avoids the axiom of choice.”")#linebreak()#text(" However, doesn’t the assertion “Every compact metrisable space is second countable”, which we use in this exercise, depend on (at least some countable version of) the axiom of choice?")#linebreak()#text(" Also, might it be possible to deduce some (weak) version of the axiom of choice from the assumption “Every topological dynamical system contains a minimal dynamical system.”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-24957")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2008")])]

#text("Dear Liu: ")#mi("\\alpha = (1,1,\\ldots,1)")#text(" is not totally irrational (indeed, one could call it “totally rational”, since ")#mi("n \\cdot \\alpha")#text(" is an integer for ")#emph[#text("every")]#text(" ")#mi("n \\in {\\Bbb Z}^d")#text(").")

#text("Dear Sam: I guess the wording may be a little unclear, but in Exercise 2 I am asking to prove a reformulated version of Lemma 1 in which an explicit basis ")#mi("V_1, V_2, \\ldots")#text(" is already supplied in the hypotheses. Of course, depending on exactly how one defines “compact metrisability”, the ability to find such a basis may require (countable) choice.")

#text("Your second question is an interesting one, but not one that I can readily answer; perhaps some reverse mathematics experts might venture an opinion? One potential difficulty is that without the axiom of choice, one might not have as many provably compact spaces as one would like to have for the purposes of building topological dynamical systems, since Tychnonoff’s theorem is no longer available, though for countable products of (explicitly) second countable spaces one should still be OK, I think, by Arzela-Ascoli type arguments.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 6: Isometric systems and isometric extensions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-24991")[#strong[#text("254A, Lecture 6: Isometric systems and isometric extensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2008")])]

#text("[…] extension is finite, then it is automatically an abelian group extension. (Hint: recall from Lecture 2 that minimal finite systems are equivalent to shifts on a cyclic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 10: The Furstenberg correspondence principle « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-25940")[#strong[#text("254A, Lecture 10: The Furstenberg correspondence principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("[…] boolean Bernoulli system with the cylinder set as before. To see this, recall from Example 5 of Lecture 2 that there is a morphism from any measure-preserving system with a distinguished set E to the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e3a41d2e49f99496331086313091876657e94fc1fa6eb03dd7fc7744d112706-ccb789f07279c510d7296f4fdaee60491e95a9dbe98ef733bb51533f04938f8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nilay")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-27090")[#strong[#text("Nilay")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2008")])]

#text("Sir")

#text("In the paragraph above exercise 1, you have said that ")#mi("x = {\\Bbb N} := \\{ 0,1,2,\\ldots\\}")#text(" lies in orbit closure of ")#mi("y := \\bigcup_{n=0}^\\infty [4^n,2 \\times 4^n] = [1,2] \\cup [4,8] \\cup [16,32] \\cup \\ldots \\in 2^{\\Bbb Z}")#text(" as it is the limit of ")#mi("T^{4^{n}}y")#text(". This claim seems incorrect to me as ")#mi("T^{4^{n}}y")#text(" will contain negative integers as well and they do not belong to ")#mi("x")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-27102")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2008")])]

#text("Dear Nilay,")

#text("In the product topology (also known as the pointwise topology) it is possible for sets containing negative numbers to converge to sets which contain no negative numbers. For instance, the sequence of sets ")#mi("A_n := \\{ -n, 1 \\}")#text(" for ")#mi("n = 1, 2, \\ldots")#text(" converges to ")#mi("A := \\{1\\}")#text(" in the product topology (because ")#mi("A_n \\cap S")#text(" converges to ")#mi("A \\cap S")#text(" for every finite set S).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e3a41d2e49f99496331086313091876657e94fc1fa6eb03dd7fc7744d112706-ccb789f07279c510d7296f4fdaee60491e95a9dbe98ef733bb51533f04938f8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nilay")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-27145")[#strong[#text("Nilay")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2008")])]

#text("Sir")

#text("I got it. My reasoning might not be mathematically correct. This is what I think. The points that can be on the left hand side of ")#mi("{}0")#text(" reach negative infinity as ")#mi("4^n \\rightarrow \\infty")#text(" and hence are no longer in ")#mi("y")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of What is a gauge? « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-32690")[#strong[#text("What is a gauge? « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2008")])]

#text("[…] Example 2: circle extensions of a dynamical system. Recall (see e.g. my lecture notes) that a dynamical system is a pair X = (X,T), where X is a space and is an invertible map. (One can also place additional topological or measure-theoretic structures on this system, as is done in those notes, but we will ignore these structures for this discussion.) Given such a system, and given a cocycle (which, in this context, is simply a function from X to the unit circle), we can define the skew product of X and the unit circle , twisted by the cocycle , to be the Cartesian product with the shift ; this is easily seen to be another dynamical system. (If one wishes to have a topological or measure-theoretic dynamical system, then will have to be continuous or measurable here, but let us ignore such issues for this discussion.) Observe that there is a free action of the circle group on the skew product that commutes with the shift ; the quotient space of this action is isomorphic to X, thus leading to a factor map , which is of course just the projection map . (An example is provided by the skew shift system, described in my lecture notes.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 陶哲轩遍历论习题解答：第二讲 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-34348")[#strong[#text("陶哲轩遍历论习题解答：第二讲 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2008")])]

#text("[…] (注：遍历论为陶哲轩教授于今年年初的一门课程，我尝试将所有习题做出来，这是第二讲的五个习题。这里是本讲的链接。最后两个习题涉及到范畴论，我不是很熟悉，也不清楚应当掌握多少这方面的知识为宜。) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sriram")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-41627")[#strong[#text("Sriram")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2009")])]

#text("Hi")#linebreak()#text(" Is it possible to put your notes in a pdf file as well")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eff7fdf81b9c7b14562a2d3c05ec212cf39bd4d8490507d000c140b683b77e96-3043580e7c8e8c447632ec009143aa81249d2bae11e52af323fbed12cb32fb92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boaz")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-42645")[#strong[#text("Boaz")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2009")])]

#text("Dear Terry:")

#text("In Example 7 (Torus Shift), it would help explaining that n*alpha is")#linebreak()#text(" a scalar/inner product, to avoid confusions.")

#text("Thanks for your notes!")

#text("Boaz")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-42864")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2009")])]

#text("Dear Prof. Tao,")

#text("I was wondering if you could give some hint on how to prove that the orbit ")#mi("\\overline{T^\\mathbb Z \\omega}")#text(" is minimal in exercise 3.")

#text("Thanks in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-42870")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2009")])]

#text("I think this can be done once one notices X is a minimal system if and only if for any open set V, ")#mi("\\cup_{n\\in \\Bbb Z}T^n V=X")#text(". In fact, otherwise the close set ")#mi("X\\backslash \\cup_{n\\in \\Bbb Z}T^n V")#text(" would contain a proper subsystem of X.")

#text("Since the space is compact, the condition could be reduced to ")#mi("\\cup_{1\\leq n\\leq N}T^n V=X")#text(" for some finite integer. Then things becomes easier.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hispa")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-120528")[#strong[#text("Hispa")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2012")])]

#text("Dear Terence,")#linebreak()#text(" I have a doubt on exercise 1.")#linebreak()#text(" I take the family [tex](n^Z)[\\tex] for n>0 and i find the way to represent it as a proper nested sequence of orbit closures. So the space X should be the union of the [tex](n^Z)[\\tex], that is the space of bounded Z-sequences of integers, but that space in not compact. Where’s the error?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-120588")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2012")])]

#text("Compactify the natural numbers (the union of the sets n).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hispa")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-121027")[#strong[#text("Hispa")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2012")])]

#text("Dear Terence,")#linebreak()#text(" Thank you for the imput, now i completely solved the exercise.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-124467")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2012")])]

#text("Dear Terry,")

#text("About exercise 4: Does there even exist a categorical product in the category of measure-preserving systems? It seems that the naïve product construction (with the standard product measure) doesn’t satisfy the desired properties.")

#text("Recall that to be a categorical quotient means that when we have a test object S in the category and morphisms f: S —> X and g: S —> Y, then there corresponds a unique morphism f x g: S —> X x Y such that the composition with the projections X x Y —> X and X x Y —> Y give us back our original maps f and g. Stated more succinctly, a product object X x Y is an object representing the functor Hom(-,X) x Hom(-,Y).")

#text("Let us now restrict attention to the category of measure-preserving systems, where the morphisms are measurable, measure-preserving maps.")

#text("Let (X,T) be the torus shift R/Z with T(x) = x + a. We can think of the naive product space X x X as the set of points of the square [0,1) x [0,1), endowed with the product measure. If we set the morphisms f and g to both be the identity map id: X —> X, then the induced map f x g: X —> X x X is the diagonal embedding D(x) = (x,x). However, the diagonal embedding is not measure-preserving, so this map isn’t legally in our category.")

#text("Rex")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-124486")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2012")])]

#text("Oops, you’re right. I’ve changed the last sentence of Exercise 4 to a question instead.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 3: Minimal dynamical systems, recurrence, and the Stone-Čech compactification | What's new")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-245591")[#strong[#text("254A, Lecture 3: Minimal dynamical systems, recurrence, and the Stone-Čech compactification | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2013")])]

#text("[…] somewhat more difficult, and highlights the role of minimal dynamical systems (as introduced in the previous lecture) in the theory. We will approach the subject from two (largely equivalent) approaches, the first […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-349947")[#strong[#text("An example of plagiarism by systematic renaming of concepts | Uncover Malpractice")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2014")]

#text("[…] systems. Please compare their definition of coarse graining with the following definitions.Feom ")#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/“Definition")[#text("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/“Definition")]#text(" 1. (Morphisms) 1. A morphism phi: (X,T) to (Y,S) between two dynamical […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-461920")[#strong[#text("What is Gauge? | The Conscience of A Libertarian")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2015")]

#text("[…] Example 2: circle extensions of a dynamical system. Recall (see e.g. mylecture notes) that a dynamical system is a pair X = (X,T), where X is a space and is an invertible map. (One can also place additional topological or measure-theoretic structures on this system, as is done in those notes, but we will ignore these structures for this discussion.) Given such a system, and given a cocycle (which, in this context, is simply a function from X to the unit circle), we can define the skew product of X and the unit circle , twisted by the cocycle , to be the Cartesian product with the shift ; this is easily seen to be another dynamical system. (If one wishes to have a topological or measure-theoretic dynamical system, then will have to be continuous or measurable here, but let us ignore such issues for this discussion.) Observe that there is a free action of the circle group on the skew product that commutes with the shift ; the quotient space of this action is isomorphic to X, thus leading to a factor map , which is of course just the projection map . (An example is provided by the skew shift system, described in my lecture notes.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 4: Multiple recurrence | What's new")]], [#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/#comment-503368")[#strong[#text("254A, Lecture 4: Multiple recurrence | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2018")])]

#text("[…] we need to prove Theorem 4. By Lemma 1 of Lecture 2 to establish this theorem for minimal dynamical systems. We will need to note that for minimal […]")
]
