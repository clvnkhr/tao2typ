// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/
// Converted to Typst by tao2typ: "2026-10-14T15:18:22.482118+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254B, Notes 5: Product theorems, pivot arguments, and the Larsen-Pink non-concentration inequality", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254B, Notes 5: Product theorems, pivot arguments, and the Larsen-Pink non-concentration inequality")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 February 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/")[#text("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the ")#link("https://terrytao.wordpress.com/2012/01/13/254b-notes-4-the-bourgain-gamburd-expansion-machine/")[#text("previous set of notes")]#text(", we saw that one could derive expansion of Cayley graphs from three ingredients: non-concentration, product theorems, and quasirandomness. Quasirandomness was discussed in ")#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/")[#text("Notes 3")]#text(". In the current set of notes, we discuss product theorems. Roughly speaking, these theorems assert that in certain circumstances, a finite subset ")#mi("{A}")#text(" of a group ")#mi("{G}")#text(" either exhibits expansion (in the sense that ")#mi("{A^3}")#text(", say, is significantly larger than ")#mi("{A}")#text("), or is somehow “close to” or “trapped” by a genuine group.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Product theorem in ")#mi("{SL_d(k)}")#text(")")]#text(" ")#metadata(none) <tao-317c6953d7b0cb5ea874>#text(" Let ")#mi("{d \\geq 2}")#text(", let ")#mi("{k}")#text(" be a finite field, and let ")#mi("{A}")#text(" be a finite subset of ")#mi("{G := SL_d(k)}")#text(". Let ")#mi("{\\epsilon >0}")#text(" be sufficiently small depending on ")#mi("{d}")#text(". Then at least one of the following statements holds:")

#list(
[#text("(Expansion) One has ")#tao-math("{\\left|A^3\\right| \\geq \\left|A\\right|^{1+\\epsilon}}", block: false)#text(".")],
[#text("(Close to ")#mi("{G}")#text(") One has ")#tao-math("{\\left|A\\right| \\geq \\left|G\\right|^{1-O_d(\\epsilon)}}", block: false)#text(".")],
[#text("(Trapping) ")#mi("{A}")#text(" is contained in a proper subgroup of ")#mi("{G}")#text(".")]
)
]

#text("We will prove this theorem (which was proven first in the ")#mi("{d=2,3}")#text(" cases for fields ")#mi("{F}")#text(" of prime order ")#link("http://www.ams.org/mathscinet-getitem?mr=2415382")[#text("by")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2781932")[#text("Helfgott")]#text(", and then for ")#mi("{d=2}")#text(" and general ")#mi("{F}")#text(" ")#link("http://arxiv.org/abs/1001.5069")[#text("by Dinai")]#text(", and finally to general ")#mi("{d}")#text(" and ")#mi("{F}")#text(" independently ")#link("http://arxiv.org/abs/1005.1858")[#text("by Pyber-Szabo")]#text(" and ")#link("http://arxiv.org/abs/1005.1881")[#text("by Breuillard-Green-Tao")]#text(") later in this notes. A more qualitative version of this proposition was also previously obtained ")#link("http://www.ams.org/mathscinet-getitem?mr=2833482")[#text("by Hrushovski")]#text(". There are also generalisations of the product theorem of importance to number theory, in which the field ")#mi("{k}")#text(" is replaced by a cyclic ring ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(" (with ")#mi("{q}")#text(" not necessarily prime); this was achieved first for ")#mi("{d=2}")#text(" and ")#mi("{q}")#text(" square-free ")#link("http://www.ams.org/mathscinet-getitem?mr=2587341")[#text("by Bourgain, Gamburd, and Sarnak")]#text(", ")#link("http://arxiv.org/abs/1001.3664")[#text("by Varju")]#text(" for general ")#mi("{d}")#text(" and ")#mi("{q}")#text(" square-free, and finally by ")#link("http://www.math.ias.edu/files/avi/BourgainVarju-1.pdf")[#text("this paper of Bourgain and Varju")]#text(" for arbitrary ")#mi("{d}")#text(" and ")#mi("{q}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1 (Diameter bound)")]#text(" Assuming Theorem ")#link(<tao-317c6953d7b0cb5ea874>)[#text("1")]#text(", show that whenever ")#mi("{S}")#text(" is a symmetric set of generators of ")#mi("{SL_d(k)}")#text(" for some finite field ")#mi("{k}")#text(" and some ")#mi("{d\\geq 2}")#text(", then any element of ")#mi("{SL_d(k)}")#text(" can be expressed as the product of ")#tao-math("{O_d( \\log^{O_d(1)} \\left|k\\right| )}", block: false)#text(" elements from ")#mi("{S}")#text(". (Equivalently, if we add the identity element to ")#mi("{S}")#text(", then ")#mi("{S^m = SL_d(k)}")#text(" for some ")#tao-math("{m = O_d( \\log^{O_d(1)} \\left|k\\right| )}", block: false)#text(".) This is a special case of a ")#link("http://www.ams.org/mathscinet-getitem?mr=1179520")[#text("conjecture of Babai and Seress")]#text(", who conjectured that the bound should hold uniformly for all finite simple groups (in particular, the implied constants here should not actually depend on ")#mi("{d}")#text(". The methods used to handle the ")#mi("{SL_d}")#text(" case can handle other finite groups of Lie type of bounded rank, but at present we do not have bounds that are independent of the rank. On the other hand, ")#link("http://arxiv.org/abs/1109.3550")[#text("a recent paper of Helfgott and Seress")]#text(" has almost resolved the conjecture for the permutation groups ")#mi("{A_n}")#text(".")
]

#text("A key tool to establish product theorems is an argument which is sometimes referred to as the ")#emph[#text("pivot argument")]#text(". To illustrate this argument, let us first discuss a much simpler (and older) theorem, essentially ")#link("http://www.ams.org/mathscinet-getitem?mr=435006")[#text("due to Freiman")]#text(", which has a much weaker conclusion but is valid in any group ")#mi("{G}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Baby product theorem)")]#text(" ")#metadata(none) <tao-a3ca38ef0e8554b39ce6>#text(" Let ")#mi("{G}")#text(" be a group, and let ")#mi("{A}")#text(" be a finite non-empty subset of ")#mi("{G}")#text(". Then one of the following statements hold:")

#list(
[#text("(Expansion) One has ")#tao-math("{\\left|A^{-1} A\\right| \\geq \\frac{3}{2} \\left|A\\right|}", block: false)#text(".")],
[#text("(Close to a subgroup) ")#mi("{A}")#text(" is contained in a left-coset of a group ")#mi("{H}")#text(" with ")#tao-math("{\\left|H\\right| < \\frac{3}{2} \\left|A\\right|}", block: false)#text(".")]
)
]

#text("To prove this theorem, we suppose that the first conclusion does not hold, thus ")#tao-math("{\\left|A^{-1} A\\right| <\\frac{3}{2} \\left|A\\right|}", block: false)#text(". Our task is then to place ")#mi("{A}")#text(" inside the left-coset of a fairly small group ")#mi("{H}")#text(".")

#text("To do this, we take a group element ")#mi("{g \\in G}")#text(", and consider the intersection ")#mi("{A\\cap gA}")#text(". ")#emph[#text("A priori")]#text(", the size of this set could range from anywhere from ")#mi("{0}")#text(" to ")#tao-math("{\\left|A\\right|}", block: false)#text(". However, we can use the hypothesis ")#tao-math("{\\left|A^{-1} A\\right| < \\frac{3}{2} \\left|A\\right|}", block: false)#text(" to obtain an important dichotomy, reminiscent of the classical fact that two cosets ")#mi("{gH, hH}")#text(" of a subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" are either identical or disjoint:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Dichotomy)")]#text(" ")#metadata(none) <tao-30ee9c81e22076a1ce6b>#text(" If ")#mi("{g \\in G}")#text(", then exactly one of the following occurs:")

#list(
[#text("(Non-involved case) ")#mi("{A \\cap gA}")#text(" is empty.")],
[#text("(Involved case) ")#tao-math("{\\left|A \\cap gA\\right| > \\frac{\\left|A\\right|}{2}}", block: false)#text(".")]
)
]

#emph[#text("Proof:")]#text(" Suppose we are not in the pivot case, so that ")#mi("{A \\cap gA}")#text(" is non-empty. Let ")#mi("{a}")#text(" be an element of ")#mi("{A \\cap gA}")#text(", then ")#mi("{a}")#text(" and ")#mi("{g^{-1} a}")#text(" both lie in ")#mi("{A}")#text(". The sets ")#mi("{A^{-1} a}")#text(" and ")#mi("{A^{-1} g^{-1} a}")#text(" then both lie in ")#mi("{A^{-1} A}")#text(". As these sets have cardinality ")#tao-math("{\\left|A\\right|}", block: false)#text(" and lie in ")#mi("{A^{-1}A}")#text(", which has cardinality less than ")#tao-math("{\\frac{3}{2}\\left|A\\right|}", block: false)#text(", we conclude from the inclusion-exclusion formula that")

#align(center)[#tao-fit-display[#tao-math("\\left|A^{-1} a \\cap A^{-1} g^{-1} a\\right| > \\frac{\\left|A\\right|}{2}.", block: true)]]

#text("But the left-hand side is equal to ")#tao-math("{\\left|A \\cap gA\\right|}", block: false)#text(", and the claim follows. ")#mi("\\Box")

#text("The above proposition provides a clear separation between two types of elements ")#mi("{g \\in G}")#text(": the “non-involved” elements, which have nothing to do with ")#mi("{A}")#text(" (in the sense that ")#mi("{A \\cap gA = \\emptyset}")#text(", and the “involved” elements, which have a lot to do with ")#mi("{A}")#text(" (in the sense that ")#tao-math("{\\left|A \\cap gA\\right| > \\left|A\\right|/2}", block: false)#text(". The key point is that there is a significant “gap” between the non-involved and involved elements; there are no elements that are only “slightly involved”, in that ")#mi("{A}")#text(" and ")#mi("{gA}")#text(" intersect a little but not a lot. It is this gap that will allow us to upgrade approximate structure to exact structure. Namely,")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4")]#text(" The set ")#mi("{H}")#text(" of involved elements is a finite group, and is equal to ")#mi("{A A^{-1}}")#text(".")
]

#emph[#text("Proof:")]#text(" It is clear that the identity element ")#mi("{1}")#text(" is involved, and that if ")#mi("{g}")#text(" is involved then so is ")#mi("{g^{-1}}")#text(" (since ")#mi("{A \\cap g^{-1} A = g^{-1}(A \\cap gA)}")#text(". Now suppose that ")#mi("{g, h}")#text(" are both involved. Then ")#mi("{A \\cap gA}")#text(" and ")#mi("{A\\cap hA}")#text(" have cardinality greater than ")#tao-math("{\\left|A\\right|/2}", block: false)#text(" and are both subsets of ")#mi("{A}")#text(", and so have non-empty intersection. In particular, ")#mi("{gA \\cap hA}")#text(" is non-empty, and so ")#mi("{A \\cap g^{-1} hA}")#text(" is non-empty. By Proposition ")#link(<tao-30ee9c81e22076a1ce6b>)[#text("3")]#text(", this makes ")#mi("{g^{-1} h}")#text(" involved. It is then clear that ")#mi("{H}")#text(" is a group.")

#text("If ")#mi("{g \\in A A^{-1}}")#text(", then ")#mi("{A \\cap gA}")#text(" is non-empty, and so from Proposition ")#link(<tao-30ee9c81e22076a1ce6b>)[#text("3")]#text(" ")#mi("{g}")#text(" is involved. Conversely, if ")#mi("{g}")#text(" is involved, then ")#mi("{g \\in A A^{-1}}")#text(". Thus we have ")#mi("{H = A A^{-1}}")#text(" as claimed. In particular, ")#mi("{H}")#text(" is finite. ")#mi("\\Box")

#text("Now we can quickly wrap up the proof of Theorem ")#link(<tao-a3ca38ef0e8554b39ce6>)[#text("2")]#text(". By construction, ")#tao-math("{A \\cap gA| > \\left|A\\right|/2}", block: false)#text(" for all ")#mi("{g \\in H}")#text(",which by double counting shows that ")#tao-math("{\\left|H\\right| < 2\\left|A\\right|}", block: false)#text(". As ")#mi("{H = A A^{-1}}")#text(", we see that ")#mi("{A}")#text(" is contained in a right coset ")#mi("{Hg}")#text(" of ")#mi("{H}")#text("; setting ")#mi("{H^{\\prime} := g^{-1} H g}")#text(", we conclude that ")#mi("{A}")#text(" is contained in a left coset ")#mi("{gH^{\\prime}}")#text(" of ")#mi("{H^{\\prime}}")#text(". ")#mi("{H^{\\prime}}")#text(" is a conjugate of ")#mi("{H}")#text(", and so ")#tao-math("{\\left|H^{\\prime}\\right| < 2\\left|A\\right|}", block: false)#text(". If ")#mi("{h \\in H^{\\prime}}")#text(", then ")#mi("{A}")#text(" and ")#mi("{Ah}")#text(" both lie in ")#mi("{H^{\\prime}}")#text(" and have cardinality ")#tao-math("{\\left|A\\right|}", block: false)#text(", so must overlap; and so ")#mi("{h \\in A^{-1} A}")#text(". Thus ")#mi("{A^{-1} A = H^{\\prime}}")#text(", and so ")#tao-math("{\\left|H^{\\prime}\\right| < \\frac{3}{2} \\left|A\\right|}", block: false)#text(", and Theorem ")#link(<tao-a3ca38ef0e8554b39ce6>)[#text("2")]#text(" follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Show that the constant ")#mi("{3/2}")#text(" in Theorem ")#link(<tao-a3ca38ef0e8554b39ce6>)[#text("2")]#text(" cannot be replaced by any larger constant.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Let ")#mi("{A \\subset G}")#text(" be a finite non-empty set such that ")#tao-math("{\\left|A^2\\right| < 2\\left|A\\right|}", block: false)#text(". Show that ")#mi("{AA^{-1}=A^{-1} A}")#text(". (")#emph[#text("Hint:")]#text(" If ")#mi("{ab^{-1} \\in A A^{-1}}")#text(", show that ")#mi("{ab^{-1} = c^{-1} d}")#text(" for some ")#mi("{c,d \\in A}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Let ")#mi("{A \\subset G}")#text(" be a finite non-empty set such that ")#tao-math("{\\left|A^2\\right| < \\frac{3}{2} \\left|A\\right|}", block: false)#text(". Show that there is a finite group ")#mi("{H}")#text(" with ")#tao-math("{\\left|H\\right| < \\frac{3}{2} \\left|A\\right|}", block: false)#text(" and a group element ")#mi("{g \\in G}")#text(" such that ")#mi("{A \\subset Hg \\cap gH}")#text(" and ")#mi("{H = A A^{-1}}")#text(".")
]

#text("Below the fold, we give further examples of the pivot argument in other group-like situations, including Theorem ")#link(<tao-a3ca38ef0e8554b39ce6>)[#text("2")]#text(" and also the “sum-product theorem” of ")#link("http://www.ams.org/mathscinet-getitem?mr=2053599")[#text("Bourgain-Katz-Tao")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2225493")[#text("Bourgain-Glibichuk-Konyagin")]#text(".")

#metadata(none) <tao-2d885b9f960a9786ea94>

#heading(level: 1)[#strong[#text(" — 1. The sum-product theorem — ")]]

#text("Consider a finite non-empty subset ")#mi("{A}")#text(" of a field ")#mi("{k}")#text(". Then we may form the sumset")

#align(center)[#tao-fit-display[#mitex("A+A := \\{a+b: a,b \\in A \\}")]]

#text("and the product set")

#align(center)[#tao-fit-display[#mitex("A \\cdot A := \\{ab: ab \\in A \\}.")]]

#text("The minimal sizes of such sets are well understood:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" ")#metadata(none) <tao-484b490593f77d3cae8f>#text(" Let ")#mi("{A}")#text(" be a finite non-empty subset of a field ")#mi("{k}")#text(".")

#list(
[#text("(i) Show that ")#tao-math("{\\left|A+A\\right| \\geq \\left|A\\right|}", block: false)#text(", with equality occuring if and only if ")#mi("{A}")#text(" is an additive coset ")#mi("{A = x+H}")#text(" of an finite additive subgroup ")#mi("{H}")#text(" of ")#mi("{k}")#text(" with some ")#mi("{x \\in k}")#text(".")],
[#text("(ii) Show that ")#tao-math("{\\left|A\\cdot A\\right|\\geq \\left|A\\right|}", block: false)#text(", with equality occuring if and only if ")#mi("{A}")#text(" is either equal to a multiplicative coset ")#mi("{A = gH}")#text(" of a finite multiplicative subgroup ")#mi("{H}")#text(" of ")#mi("{k^\\times := k \\backslash \\{0\\}}")#text(" with some ")#mi("{g \\in k^\\times}")#text(", or the set ")#mi("{\\{0\\}}")#text(", or the set ")#mi("{\\{0\\} \\cup gH}")#text(" where ")#mi("{gH}")#text(" is a multiplicative coset.")],
[#text("(iii) Show that ")#tao-math("{\\max(\\left|A+A\\right|, \\left|A\\cdot A\\right|\\geq \\left|A\\right|}", block: false)#text(", with equality occuring if and only if ")#mi("{A}")#text(" is either equal to a multiplicative dilate ")#mi("{A = cF}")#text(" of a finite subfield ")#mi("{F}")#text(" of ")#mi("{k}")#text(" with ")#mi("{c \\in k^\\times}")#text(", a singleton set, or an additive subgroup of order ")#mi("{2}")#text(".")]
)
]

#text("The ")#emph[#text("sum-product phenomenon")]#text(" is a robust version of the above observation, asserting that one of ")#mi("{A+A}")#text(" or ")#mi("{A\\cdot A}")#text(" must be significantly larger than ")#mi("{A}")#text(" if ")#mi("{A}")#text(" is not somehow “close” to a genuine subfield of ")#mi("{k}")#text(". Here is one formulation of this phenomenon:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Sum-product theorem)")]#text(" ")#metadata(none) <tao-b74bd1156332ecb8999b>#text(" Let ")#mi("{\\epsilon>0}")#text(" be a sufficiently small number. Then for any field ")#mi("{k}")#text(" and any finite non-empty subset ")#mi("{A}")#text(", one of the following statements hold:")

#list(
[#text("(Expansion) ")#tao-math("{\\max(\\left|A+A\\right|, \\left|A\\cdot A\\right|) \\geq \\left|A\\right|^{1+\\epsilon}}", block: false)#text(".")],
[#text("(Close to a subfield) There is a dilate ")#mi("{cF}")#text(" of a subfield ")#mi("{F}")#text(" of ")#mi("{k}")#text(" with ")#tao-math("{\\left|F\\right| \\ll \\left|A\\right|^{1+O(\\epsilon)}}", block: false)#text(" and ")#mi("{c\\neq 0}")#text(" which contains all but ")#tao-math("{O(\\left|A\\right|^{O(\\epsilon)})}", block: false)#text(" elements of ")#mi("{A}")#text(".")],
[#text("(Smallness) ")#mi("{A}")#text(" is an additive subgroup of order ")#mi("{2}")#text(".")]
)
]

#text("If ")#mi("{k}")#text(" has characteristic zero, then the second option here cannot occur, and we conclude that ")#tao-math("{\\max(\\left|A+A\\right|,\\left|A \\cdot A\\right|) \\geq \\left|A\\right|^{1+\\epsilon}}", block: false)#text(" for some absolute constant ")#mi("{\\epsilon>0}")#text(" as soon as ")#mi("{A}")#text(" contains at least two non-zero elements, a claim first established in ")#mi("{{\\bf R}}")#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=820223")[#text("by Erdos and Szemeredi")]#text(". When ")#mi("{k}")#text(" is a finite field of prime order, the second option can only occur when ")#mi("{F=k}")#text(", and we conclude that ")#tao-math("{\\max(\\left|A+A\\right|,\\left|A \\cdot A\\right|) \\geq \\left|A\\right|^{1+\\epsilon}}", block: false)#text(" as soon as ")#tao-math("{\\left|A\\right| \\leq \\left|k\\right|^{1-C\\epsilon}}", block: false)#text(" whenever ")#mi("{\\epsilon}")#text(" is sufficiently small, ")#mi("{C}")#text(" is an absolute constant, and ")#mi("{A}")#text(" has at least two non-zero elements. A preliminary version of this result (which required more size assumptions on ")#mi("{A}")#text(", in particular a bound of the shape ")#tao-math("{\\left|A\\right| \\geq \\left|k\\right|^\\delta}", block: false)#text(") was obtained by ")#link("http://www.ams.org/mathscinet-getitem?mr=2053599")[#text("Bourgain, Katz, and Tao")]#text(", with the version stated above first obtained by ")#link("http://www.ams.org/mathscinet-getitem?mr=2053599")[#text("Bourgain, Glibichuk, and Konyagin")]#text(". The proof given here is drawn from ")#link("http://www.ams.org/mathscinet-getitem?mr=2289012")[#text("my book with Van")]#text(", and was originally inspired by ")#link("http://www.ams.org/mathscinet-getitem?mr=1998834")[#text("this paper of Bourgain and Konyagin")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" There has been a substantial amount of literature on trying to optimise the exponent ")#mi("{\\epsilon}")#text(" in the sum-product theorem. A relatively recent survey of this literature can be found in ")#link("https://terrytao.wordpress.com/2008/06/17/the-sum-product-phenomenon-in-arbitrary-rings/")[#text("this paper of mine")]#text(" (and in the references to the other papers cited in this remark). In ")#mi("{{\\bf R}}")#text(", the best result currently in this direction is ")#link("http://arxiv.org/abs/0806.1040")[#text("by Solymosi")]#text(", who established that one can take ")#mi("{\\epsilon}")#text(" arbitrarily close to ")#mi("{1/3}")#text("; for ")#mi("{{\\bf C}}")#text(", the best result currently is ")#link("http://arxiv.org/abs/1111.4977")[#text("by Rudnev")]#text(", who shows that one can take ")#mi("{\\epsilon}")#text(" arbitrarily close to ")#mi("{19/69}")#text(". For fields of prime order, one can take ")#mi("{\\epsilon}")#text(" arbitrarily close to ")#mi("{1/11}")#text(", a ")#link("http://arxiv.org/abs/1011.2738")[#text("result of Rudnev")]#text("; an extension to arbitrary finite fields was then obtained ")#link("http://arxiv.org/abs/1106.1148")[#text("by Li and Roche-Newton")]#text(".")
]

#text("We now start proving Theorem ")#link(<tao-b74bd1156332ecb8999b>)[#text("5")]#text(". As with Theorem ")#link(<tao-a3ca38ef0e8554b39ce6>)[#text("2")]#text(", the engine of the proof is a dichotomy similar to that of Proposition ")#link(<tao-30ee9c81e22076a1ce6b>)[#text("3")]#text(". Whilst the former proposition was modeled on the basic group-theoretic assertion that cosets ")#mi("{gH}")#text(" of a subgroup where either identical or disjoint, this proposition is modeled on the basic linear algebra fact that if ")#mi("{F}")#text(" is a subfield of ")#mi("{k}")#text(" and ")#mi("{\\xi \\in k}")#text(", then ")#mi("{F+\\xi F}")#text(" is either of size ")#tao-math("{\\left|F\\right|^2}", block: false)#text(", or of size ")#tao-math("{\\left|F\\right|}", block: false)#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (Dichotomy)")]#text(" ")#metadata(none) <tao-63631485dac5a72b0358>#text(" Let ")#mi("{k}")#text(" be a field, let ")#mi("{A}")#text(" be a finite non-empty subset of ")#mi("{k}")#text(", and let ")#mi("{\\xi \\in k}")#text(". Then at least one of the following statements hold:")

#list(
[#text("(Non-involved case) ")#tao-math("{\\left|A + \\xi A\\right| = \\left|A\\right|^2}", block: false)#text(".")],
[#text("(Involved case) ")#tao-math("{\\left|A + \\xi A\\right| \\leq \\left|(A-A) A +(A-A) A\\right|}", block: false)#text(".")]
)
]

#emph[#text("Proof:")]#text(" Suppose that we are not in the non-involved case, thus ")#tao-math("{\\left|A + \\xi A\\right| \\neq \\left|A\\right|^2}", block: false)#text(". Then the map ")#mi("{(a,b) \\mapsto a+\\xi b}")#text(" from ")#mi("{A\\times A}")#text(" to ")#mi("{k}")#text(" is not injective, and so there exists ")#mi("{a,b,c,d \\in A}")#text(" with ")#mi("{(a,b) \\neq (c,d)}")#text(" and")

#align(center)[#tao-fit-display[#mitex("a+\\xi b = c+\\xi d.")]]

#text("In particular, ")#mi("{b \\neq d}")#text(". We then have ")#mi("{\\xi = (a-c)/(d-b)}")#text(" and so")

#align(center)[#tao-fit-display[#tao-math("\\left|A + \\xi A\\right| = \\left|(d-b) A + (a-c) A\\right| \\leq \\left|(A-A) A +(A-A) A\\right|.", block: true)]]

#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One can view ")#mi("{A+\\xi A}")#text(" as measuring the extent to which the dilate ")#mi("{\\xi A}")#text(" of ")#mi("{A}")#text(" is “transverse” to ")#mi("{A}")#text(". As the “slope” ")#mi("{\\xi}")#text(" varies, ")#mi("{\\xi A}")#text(" “pivots” around the origin, encountering both the (relatively rare) involved slopes, and the (generic) non-involved slopes. It is this geometric picture which led to the term “pivot argument”, as used in particular ")#link("http://arxiv.org/abs/0807.2027")[#text("by Helfgott")]#text(" (who labeled the non-involved slopes as “pivots”).")
]

#text("This dichotomy becomes useful if there is a significant gap between ")#tao-math("{\\left|(A-A) A +(A-A) A\\right|}", block: false)#text(" and ")#tao-math("{\\left|A\\right|^2}", block: false)#text(". Let’s see how. To prove Theorem ")#link(<tao-b74bd1156332ecb8999b>)[#text("5")]#text(", we may assume that ")#tao-math("{\\left|A\\right|}", block: false)#text(" is larger than some large absolute constant ")#mi("{C}")#text(", as the claim follows from Exercise ")#link(<tao-484b490593f77d3cae8f>)[#text("5")]#text(" otherwise (making ")#mi("{\\epsilon}")#text(" small enough depending on ")#mi("{C}")#text("). by deleting ")#mi("{0}")#text(" from ")#mi("{A}")#text(", and tweaking ")#mi("{\\epsilon}")#text(", noting that we may then assume that ")#mi("{A}")#text(" does not contain ")#mi("{0}")#text(". We suppose that")

#align(center)[#tao-fit-display[#tao-math("\\left|A+A\\right|, \\left|A\\cdot A\\right|\\leq K\\left|A\\right|", block: true)]]

#text("for some ")#tao-math("{K \\leq \\left|A\\right|^{\\epsilon_0}}", block: false)#text(" and some sufficiently small absolute constant ")#mi("{\\epsilon_0}")#text(". In particular we see that ")#tao-math("{\\left|A\\right|}", block: false)#text(" will exceed any quantity of the form ")#mi("{O(K^{O(1)})}")#text(" if we make ")#mi("{\\epsilon_0}")#text(" small enough and ")#mi("{C}")#text(" large enough.")

#text("We would like to boost this control of sums and products to more complex combinations of ")#mi("{A}")#text(". We will need some basic tools from additive combinatorics.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7 (Ruzsa triangle inequality)")]#text(" If ")#mi("{A,B,C}")#text(" are non-empty finite subsets of ")#mi("{k}")#text(", then ")#tao-math("{\\left|A-C\\right| \\leq \\frac{\\left|A-B\\right|\\left|B-C\\right|}{\\left|B\\right|}}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" This is the additive version of Exercise 4 from ")#link("https://terrytao.wordpress.com/2012/01/13/254b-notes-4-the-bourgain-gamburd-expansion-machine/")[#text("Notes 4")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8 (Ruzsa covering lemma)")]#text(" If ")#mi("{A, B}")#text(" are non-empty finite subsets of ")#mi("{k}")#text(", then ")#mi("{A}")#text(" can be covered by at most ")#tao-math("{\\frac{\\left|A+B\\right|}{\\left|B\\right|}}", block: false)#text(" translates of ")#mi("{B-B}")#text(".")
]

#emph[#text("Proof:")]#text(" This is the additive version of Exercise 5 from ")#link("https://terrytao.wordpress.com/2012/01/13/254b-notes-4-the-bourgain-gamburd-expansion-machine/")[#text("Notes 4")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6 (Sum set estimates)")]#text(" If ")#mi("{A, B}")#text(" are non-empty finite subsets of ")#mi("{k}")#text(" such that ")#tao-math("{\\left|A+B\\right|\\leq K \\left|A\\right|^{1/2}\\left|B\\right|^{1/2}}", block: false)#text(", show that ")#mi("{A}")#text(" and ")#mi("{B}")#text(" can both be covered by ")#mi("{O(K^{O(1)})}")#text(" translates of the same ")#mi("{O(K^{O(1)})}")#text("-approximate group ")#mi("{H}")#text(", with ")#tao-math("{\\left|H\\right| \\ll K^{O(1)} \\left|A\\right|}", block: false)#text(". Conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|n_1 A - n_2 A + n_3 B - n_4 B\\right| \\ll_{n_1,n_2,n_3,n_4} K^{O(\\left|n_1\\right|+\\left|n_2\\right|+\\left|n_3\\right|+\\left|n_4\\right|)} \\left|A\\right|", block: true)]]

#text("for any natural numbers ")#mi("{n_1,n_2,n_3,n_4}")#text(", where ")#mi("{nA := A+\\ldots+A}")#text(" denotes the sum set of ")#mi("{n}")#text(" copies of ")#mi("{A}")#text(". (")#emph[#text("Hint:")]#text(" use the additive form of Exercise 7 from ")#link("https://terrytao.wordpress.com/2012/01/13/254b-notes-4-the-bourgain-gamburd-expansion-machine/")[#text("Notes 4")]#text(", and the preceding lemmas.)")
]

#text("These lemmas allow us to improve the sum-product properties of ")#mi("{A}")#text(" by passing to a large subset ")#mi("{B}")#text(" (cf. the Balog-Szemeredi-Gowers lemma from ")#link("https://terrytao.wordpress.com/2012/01/13/254b-notes-4-the-bourgain-gamburd-expansion-machine/")[#text("Notes 4")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9 (Katz-Tao lemma)")]#text(" Let ")#mi("{A}")#text(" be as above. Then there is a subset ")#mi("{B}")#text(" of ")#mi("{A}")#text(" with ")#tao-math("{\\left|B\\right| \\geq \\left|A\\right|/2K}", block: false)#text(" such that ")#tao-math("{\\left|B^2-B^2\\right| \\ll K^{O(1)} \\left|B\\right|}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" The dilates ")#mi("{aA}")#text(" of ")#mi("{A}")#text(" with ")#mi("{a \\in A}")#text(" all lie in a set ")#mi("{A^2}")#text(" of cardinality at most ")#tao-math("{K\\left|A\\right|}", block: false)#text(". Intuitively, this should force a lot of collision between the ")#mi("{aA}")#text(", which we will exploit using the sum set estimates. More precisely, observe that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{a \\in A} 1_{aA}\\right\\|_{\\ell^1}= \\left|A\\right|^2", block: true)]]

#text("and hence by Cauchy-Schwarz")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{a \\in A} 1_{aA}\\right\\|_{\\ell^2}^2 \\geq \\left|A\\right|^3/K.", block: true)]]

#text("The left-hand side can be written as")

#align(center)[#tao-fit-display[#tao-math("\\sum_{b \\in A} \\sum_{a\\in A}\\left|aA\\cap bA\\right|", block: true)]]

#text("and so by the pigeonhole principle we can find ")#mi("{b_0 \\in A}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{a\\in A}\\left|aA\\cap b_0 A\\right| \\geq \\left|A\\right|^2/K.", block: true)]]

#text("We apply a dilation to set ")#mi("{b_0=1}")#text(" (recall that ")#mi("{A}")#text(" does not contain ")#mi("{0}")#text("). If we set ")#tao-math("{B := \\{a \\in A: \\left|aA\\cap A\\right| \\geq \\left|A\\right|/2K\\}}", block: false)#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{a \\in B}\\left|aA\\cap A\\right| \\geq \\left|A\\right|^2/2K", block: true)]]

#text("which implies in particular that")

#align(center)[#tao-fit-display[#tao-math("\\left|B\\right|\\geq \\left|A\\right|/2K", block: true)]]

#text("If ")#mi("{a \\in B}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left|aA \\cap A\\right| \\geq \\left|A\\right|/2K;", block: true)]]

#text("since ")#tao-math("{\\left|aA + aA\\right| \\leq K\\left|A\\right|}", block: false)#text(" we also have")

#align(center)[#tao-fit-display[#tao-math("\\left|aA + (aA \\cap A)\\right| \\leq K\\left|A\\right|", block: true)]]

#text("and similarly")

#align(center)[#tao-fit-display[#tao-math("\\left|A + (aA \\cap A)\\right| \\leq K\\left|A\\right|", block: true)]]

#text("and thus by the Ruzsa triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|aA -A\\right| \\ll K^{O(1)} \\left|A\\right|", block: true)]]

#text("whenever ")#mi("{a \\in B}")#text(". Informally, let us call a non-zero element ")#mi("{a}")#text(" of ")#mi("{k}")#text(" ")#emph[#text("good")]#text(" if ")#tao-math("{\\left|aA - A\\right| \\ll K^{O(1)} \\left|A\\right|}", block: false)#text(" (but note that this notion of “good” is a bit fuzzy, as it depends on the choice of implied constants in the ")#mi("{O()}")#text(" notation). Observe that if ")#mi("{a,a^{\\prime}}")#text(" are good, then")

#align(center)[#tao-fit-display[#tao-math("\\left|aa^{\\prime} A - a A\\right|, \\left|a A - A\\right| \\ll K^{O(1)} \\left|A\\right|", block: true)]]

#text("and thus by the Ruzsa triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|aa^{\\prime} A - A\\right| \\ll K^{O(1)} \\left|A\\right|,", block: true)]]

#text("thus the product of two good elements are good (with somewhat worse implied constants). Similarly, from the Ruzsa covering lemma we see that ")#mi("{aA}")#text(" and ")#mi("{a^{\\prime} A}")#text(" are both covered by ")#mi("{O(K^{O(1)})}")#text(" translates of ")#mi("{A-A}")#text(", and from this and sum set estimates we see that")

#align(center)[#tao-fit-display[#tao-math("\\left|(a+a^{\\prime})A-A\\right| \\ll K^{O(1)} \\left|A\\right|", block: true)]]

#text("and so the sum of two good elements is again good. Similarly the difference of good elements is good. Applying all these facts, we conclude that all the elements of ")#mi("{B^2-B^2}")#text(" are good, thus ")#tao-math("{\\left|gA-A\\right| \\ll K^{O(1)} \\left|A\\right|}", block: false)#text(" for all ")#mi("{g \\in B^2-B^2}")#text(". In particular, since ")#tao-math("{\\left|A\\right|}", block: false)#text(" exceeds ")#mi("{K^{O(1)}}")#text(", we see from the Cauchy-Schwarz inequality that for each ")#mi("{g \\in B^2-B^2}")#text(", there are ")#tao-math("{\\gg \\left|A\\right|^3/K^{O(1)}}", block: false)#text(" solutions to the equation ")#mi("{ga_1-a_2=ga_3-a_4}")#text(" with ")#mi("{a_1 \\neq a_3}")#text(" and ")#mi("{a_1,a_2,a_3,a_4 \\in A}")#text(". However, there are only ")#tao-math("{\\left|A\\right|^4}", block: false)#text(" possible choices for ")#mi("{a_1,a_2,a_3,a_4}")#text(", and each such choice uniquely determines ")#mi("{g}")#text(", so there are at most ")#tao-math("{O(K^{O(1)} \\left|A\\right|)}", block: false)#text(" possible choices for ")#mi("{g}")#text(", and the claim follows. ")#mi("\\Box")

#text("Note that one could replace ")#mi("{B^2-B^2}")#text(" in the above lemma by any other homogeneous polynomial combination of ")#mi("{B}")#text(".")

#text("By applying a dilation, we may assume that ")#mi("{B}")#text(" contains ")#mi("{1}")#text(". Applying Proposition ")#link(<tao-63631485dac5a72b0358>)[#text("6")]#text(" to this set ")#mi("{B}")#text(" (and using sum set estimates), we arrive at the following dichotomy: every field element ")#mi("{\\xi \\in k}")#text(" is either “non-involved” in the sense that ")#tao-math("{\\left|B+\\xi B\\right| = \\left|B\\right|^2}", block: false)#text(", or is “involved” in the sense that ")#tao-math("{\\left|B+\\xi B\\right| \\leq C_1 K^{C_1} \\left|B\\right|}", block: false)#text(" for some fixed absolute constant ")#mi("{C_1}")#text(". By sum set estimates we have ")#tao-math("{\\left|B+BB\\right| \\ll K^{O(1)} \\left|B\\right|}", block: false)#text("; as we can assume that ")#tao-math("{\\left|A\\right|}", block: false)#text(", and hence ")#tao-math("{\\left|B\\right|}", block: false)#text(", is larger than any quantity of the form ")#mi("{O(K^{O(1)})}")#text(", this forces all elements of ")#mi("{B}")#text(" to be involved.")

#text("To exploit this, observe (by repeating the proof of Proposition ")#link(<tao-63631485dac5a72b0358>)[#text("6")]#text(") that if ")#mi("{\\xi_1,\\xi_2}")#text(" are involved, then the quantities ")#mi("{\\xi = \\xi_1\\xi_2, \\xi_1+\\xi_2, \\xi_1-\\xi_2}")#text(" are somewhat involved in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\left|B + \\xi B\\right|\\ll K^{O(1)} \\left|B\\right|", block: true)]]

#text("for those choices of ")#mi("{\\xi}")#text(" (where the implied constants depend on ")#mi("{C_1}")#text("). But as we can assume that ")#tao-math("{\\left|A\\right|}", block: false)#text(", and hence ")#tao-math("{\\left|B\\right|}", block: false)#text(", is larger than any quantity of the form ")#mi("{O(K^{O(1)})}")#text(", we see from Proposition ")#link(<tao-63631485dac5a72b0358>)[#text("6")]#text(" that this forces ")#mi("{\\xi}")#text(" to be involved as well (this is the crucial step at which approximate structure is improved to exact structure). We thus see that the set ")#mi("{F}")#text(" of all involved elements is closed under multiplication, addition, and subtraction; as it also contains ")#mi("{0}")#text(", it is a subring of ")#mi("{k}")#text(". Arguing as in the proof of Proposition ")#link(<tao-63631485dac5a72b0358>)[#text("6")]#text(", we have that ")#mi("{F}")#text(" is finite with ")#tao-math("{\\left|F\\right|\\ll K^{O(1)} \\left|A\\right|}", block: false)#text("; in particular, ")#mi("{F}")#text(" must now be a finite subfield of ")#mi("{k}")#text(".")

#text("Now we enter the “endgame”, in which we use this ")#mi("{F}")#text(" to control ")#mi("{A}")#text(". By previous discussion, ")#mi("{F}")#text(" contains ")#mi("{B}")#text(", and thus ")#tao-math("{\\left|A \\cap F\\right| \\gg K^{-O(1)} \\left|A\\right|}", block: false)#text(". By the Ruzsa triangle inequality applied to ")#mi("{A, A \\cap F, F}")#text(", this implies that ")#tao-math("{\\left|A+F\\right| \\ll K^{O(1)} \\left|F\\right|}", block: false)#text(", and so ")#mi("{A}")#text(" can be covered by ")#mi("{O(K^{O(1)})}")#text(" translates of ")#mi("{F}")#text(". A similar argument applied multiplicatively shows that ")#mi("{A}")#text(" can be covered by ")#mi("{O(K^{O(1)})}")#text(" dilates of ")#mi("{F}")#text(". Since a non-trivial translate of ")#mi("{F}")#text(" and a non-trivial dilate of ")#mi("{F}")#text(" intersect in at most one point, we conclude that ")#mi("{A}")#text(" has at most ")#mi("{O(K^{O(1)})}")#text(" elements outside of ")#mi("{F}")#text(", and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" One can abstract this argument by replacing the multiplicative structure here by an abelian group action; see ")#link("http://arxiv.org/abs/0807.2027")[#text("this paper of Helfgott")]#text(" for details. The argument can also extend to non-commutative settings, such as division algebras or more generally to arbitrary rings (though in the latter case, the presence of non-trivial zero-divisors becomes a very significant issue); see ")#link("https://terrytao.wordpress.com/2008/06/17/the-sum-product-phenomenon-in-arbitrary-rings/")[#text("this paper")]#text(" for details.")
]

#heading(level: 1)[#strong[#text(" — 2. Finite subgroups of ")#mi("{SL_2}")#text(" — ")]]

#text("We will shortly establish Theorem ")#link(<tao-317c6953d7b0cb5ea874>)[#text("1")]#text(", which can be viewed as a way to describe approximate subgroups of ")#mi("{SL_d(k)}")#text(". Before we do so, let us first warm up and digress slightly by by studying ")#emph[#text("genuine")]#text(" finite subgroups ")#mi("{A}")#text(" of ")#mi("{SL_d(k)}")#text(", in the model case ")#mi("{d=2}")#text(", for which ")#emph[#text("ad hoc")]#text(" explicit calculations are available. In order to make the algebraic geometry of the situation cleaner, it is convenient to embed the field ")#mi("{k}")#text(" in its algebraic closure ")#mi("{\\overline{k}}")#text(", and similarly embed ")#mi("{SL_2(k)}")#text(" in ")#mi("{SL_2(\\overline{k})}")#text(". This is a group which is also an algebraic variety (identifying the space of ")#mi("{2 \\times 2}")#text(" matrices with coefficients in ")#mi("{\\overline{k}}")#text(" with ")#mi("{\\overline{k}^4}")#text("), whose group operations are algebraic (in fact, polynomial) maps; in other words, ")#mi("{SL_2(\\overline{k})}")#text(" is an ")#link("http://en.wikipedia.org/wiki/Algebraic_group")[#text("algebraic group")]#text(". We now consider the question of what finite subgroups of ")#mi("{SL_2(\\overline{k})}")#text(" can look like. This is a classical question, with a complete classification obtained by Dickson in 1901. The precise classification is somewhat complicated; to give just a taste of this complexity, we observe that the symmetry group of the isocahedron is a finite subgroup of ")#mi("{SO_3({\\bf R})}")#text(", which can be lifted to the spin group ")#mi("{Spin_3({\\bf R})}")#text(" (giving what is known as the ")#emph[#text("binary isocahedral group")]#text(", a group of order ")#mi("{120}")#text("), which is a subgroup of ")#mi("{Spin_3({\\bf C})}")#text(", which can be identified with ")#mi("{SL_2({\\bf C})}")#text(". Because of this, it is possible for some choices of finite field ")#mi("{k}")#text(" to embed the binary isocahedral group into ")#mi("{SL_2(\\overline{k})}")#text(" or ")#mi("{SL_2(k)}")#text(". Similar considerations obtain for the symmetry group of other Platonic solids. However, if one is willing to settle for a “rough” classification, in which one ignores groups of bounded size (and more generally, is willing just to describe a bounded index subgroup of the group ")#mi("{A}")#text("), the situation becomes much simpler. In the characteristic zero case ")#mi("{k={\\bf C}}")#text(", for instance, we have ")#link("http://en.wikipedia.org/wiki/Jordan%27s_theorem_on_finite_linear_groups")[#text("Jordan’s theorem")]#text(", which asserts that given a finite subgroup ")#mi("{A}")#text(" of ")#mi("{SL_d({\\bf C})}")#text(" for some ")#mi("{d=O(1)}")#text(", a bounded index subgroup of ")#mi("{A}")#text(" is abelian. (Jordan’s theorem was ")#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/")[#text("discussed further in last quarter’s course")]#text(".) The finite characteristic case is inherently more complicated though (due in large part to the proliferation of finite subfields), with a satisfactory rough classification only becoming available for general ")#mi("{d}")#text(" with the work ")#link("http://www.ams.org/mathscinet-getitem?mr=2813339")[#text("of Larsen and Pink")]#text(" (published in 2011, but which first appeared as a preprint in 1998). However, the ")#mi("{d=2}")#text(" case is significantly simpler and can be treated by somewhat ")#emph[#text("ad hoc")]#text(" methods, as we shall now do. The discussion here is loosely based on ")#link("http://arxiv.org/abs/1201.1139")[#text("this paper of Kowalski")]#text(".")

#text("We pause to recall some basic structural facts about ")#mi("{SL_2(\\overline{k})}")#text(". Elements of this group are ")#mi("{2 \\times 2}")#text(" matrices with determinant one, and thus have two (algebraic, possibly repeated) eigenvalues ")#mi("{t, t^{-1}}")#text(" for some ")#mi("{t\\in \\overline{k}}")#text(" (note here that we are using the algebraically closed nature of ")#mi("{\\overline{k}}")#text("). This allows us to classify elements of ")#mi("{SL_2(\\overline{k})}")#text(" into three classes:")

#list(
[#text("The ")#emph[#text("central")]#text(" elements ")#mi("{\\pm 1}")#text(";")],
[#text("The ")#emph[#text("regular unipotent elements")]#text(" and their negations, which are non-central elements with a double eigenvalue at ")#mi("{+1}")#text(" (or a double eigenvalue at ")#mi("{-1}")#text("); and")],
[#text("The ")#emph[#text("regular semisimple elements")]#text(", which have two distinct eigenvalues.")]
)

#text("We collectively refer to regular unipotent elements and their negations as ")#emph[#text("regular projectively unipotent elements")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" The presence of the non-identity central element ")#mi("{-1}")#text(" leads to some slight technical annoyances (for instance, it means that ")#mi("{SL_2}")#text(" merely an ")#emph[#text("almost simple")]#text(" algebraic group rather than a simple one, in the sense that the only normal algebraic subgroups are finite). One can eliminate this element by working instead with the ")#emph[#text("projective special linear group")]#text(" ")#mi("{PSL_2:= SL_2/\\{\\pm 1\\}}")#text(", but we will not do so here. We remark that if one works in ")#mi("{SL_d}")#text(" for ")#mi("{d>2}")#text(" then the classification of elements becomes significantly more complicated, for instance there exist elements which are semisimple (i.e. diagonalisable) but neither regular nor central, because some but not all of the eigenvalues may be repeated.")
]

#text("One can distinguish the unipotent elements from the semisimple ones using the trace: unipotent elements have trace ")#mi("{+2}")#text(", their negations have trace ")#mi("{-2}")#text(", and the semisimple elements have traces distinct from ")#mi("{\\pm 2}")#text(". The ability to classify elements purely from the trace is a very special fact concerning ")#mi("{SL_2}")#text(" which breaks down completely for higher rank matrix groups, but we will not hesitate to take advantage of this fact here.")

#text("Associated to the above classification are some natural algebraic subgroups of ")#mi("{SL_2(\\overline{k})}")#text(", including the ")#link("http://en.wikipedia.org/wiki/Maximal_torus")[#text("standard maximal torus")]

#align(center)[#tao-fit-display[#mitex("T(\\overline{k}) := \\{ \\begin{pmatrix} t & 0 \\\\ 0 & t^{-1} \\end{pmatrix}: t \\in \\overline{k}^\\times \\},")]]

#text("the one-dimensional ")#emph[#text("standard unipotent group")]

#align(center)[#tao-fit-display[#mitex("U(\\overline{k}) := \\{ \\begin{pmatrix} 1 & x \\\\ 0 & 1 \\end{pmatrix}: x \\in \\overline{k} \\},")]]

#text("and the two-dimensional ")#link("http://en.wikipedia.org/wiki/Borel_subgroup")[#text("standard Borel subgroup")]

#align(center)[#tao-fit-display[#mitex("B(\\overline{k}) := \\{ \\begin{pmatrix} t & x \\\\ 0 & t^{-1} \\end{pmatrix}: x \\in \\overline{k}; t \\in \\overline{k}^\\times \\}.")]]

#text("More generally, we define a maximal torus of ")#mi("{SL_2(\\overline{k})}")#text(" to be a conjugate (in ")#mi("{SL_2(\\overline{k})}")#text(") of the standard maximal torus, a unipotent group to be a conjugate of the standard unipotent group, and a Borel subgroup to be a conjugate of the standard Borel subgroup. (This is not really the “right” way to define these groups, for the purpose of generalisation to other algebraic groups, but will suffice as long as we are only working with ")#mi("{SL_2}")#text(".) Note that one can also think of a Borel subgroup as the stabiliser of a one-dimensional subspace of ")#mi("{\\overline{k}^2}")#text(" (using the obvious action of ")#mi("{SL_2(\\overline{k})}")#text(" on ")#mi("{\\overline{k}^2}")#text("). Using the ")#link("http://en.wikipedia.org/wiki/Jordan_normal_form")[#text("Jordan normal form")]#text(" (again taking advantage of the algebraically closed nature of ")#mi("{\\overline{k}}")#text("), we can see how these groups interact with group elements:")

#list(
[#text("The central elements lie in every maximal torus and every Borel subgroup. The identity ")#mi("{+1}")#text(" lies in every unipotent group, but ")#mi("{-1}")#text(" lies in none of them.")],
[#text("Every regular unipotent element lies in exactly one unipotent group, which in turn lies in exactly one Borel subgroup (the normaliser of the unipotent group). Conversely, a unipotent group consists entirely of regular unipotent elements and the identity ")#mi("{+1}")#text(".")],
[#text("Every regular semisimple element lies in exactly one maximal torus, which in turn lies in exactly two Borel subgroups (the stabiliser of one of the eigenspaces of a regular semisimple element in the torus). Conversely, a maximal torus consists entirely of regular semisimple elements and the central elements ")#mi("{\\pm 1}")#text(".")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" If one was working in a non-algebraically closed field ")#mi("{F}")#text(" instead of in ")#mi("{\\overline{k}}")#text(", one could subdivide the regular semisimple elements into two classes, the ")#emph[#text("split")]#text(" case when the elements can be diagonalised inside ")#mi("{F}")#text(", and the ")#emph[#text("non-split")]#text(" case when they can only be diagonalised in a quadratic extension of ")#mi("{F}")#text(". This similarly subdivides maximal tori into two families, the split tori and the non-split tori. In the case when one is working over the field ")#mi("{{\\bf R}}")#text(", the unipotent, split semisimple, and non-split semisimple elements are referred to as parabolic, hyperbolic, and elliptic elements of ")#mi("{SL_2({\\bf R})}")#text(" respectively. Fortunately, in our applications we can work in algebraically closed fields and avoid these sorts of finer distinctions.")
]

#text("Ignoring the exceptional small examples of subgroups of ")#mi("{SL_2(\\overline{k})}")#text(", such as the binary isocahedral group mentioned earlier, there are two obvious ways to generate subgroups of ")#mi("{SL_2(\\overline{k})}")#text(". One is to pass from ")#mi("{\\overline{k}}")#text(" to a subfield ")#mi("{F}")#text(", creating “arithmetic” subgroups of the form ")#mi("{SL_2(F)}")#text(" (or conjugates thereof). The other is to replace ")#mi("{SL_2}")#text(" with an algebraic subgroup of the three-dimensional group ")#mi("{SL_2}")#text(", such as the maximal tori, unipotent groups, and Borel subgroups mentioned earlier. (Actually, these are the only (connected) proper algebraic subgroups of ")#mi("{SL_2}")#text(", as can be seen by consideration of the associated Lie algebras.)")

#text("Observe that if ")#mi("{A = SL_2(F)}")#text(" is an arithmetic subgroup, then its intersections ")#mi("{T(F) := A \\cap T(\\overline{k})}")#text(", ")#mi("{U(F) := A \\cap U(\\overline{k})}")#text(", ")#mi("{B(F) := A \\cap B(\\overline{k})}")#text(" capture a portion of ")#mi("{A}")#text(" proportionate to the dimensions involved, or more precisely that")

#align(center)[#tao-fit-display[#tao-math("\\left|A \\cap T(\\overline{k})\\right| \\ll \\left|A\\right|^{1/3}; \\left|A \\cap U(\\overline{k})\\right| \\ll \\left|A\\right|^{1/3}; \\quad \\left|A \\cap B(\\overline{k})\\right| \\ll \\left|A\\right|^{2/3}.", block: true)]]

#text("Indeed, it is easy to see that ")#tao-math("{\\left|A\\right| = \\left|SL_2(F)\\right| \\sim \\left|F\\right|^3}", block: false)#text(", ")#tao-math("{\\left|A \\cap T(\\overline{k})\\right| = \\left|T(F)\\right| \\sim \\left|F\\right|}", block: false)#text(", and so forth. An important and general ")#link("http://www.ams.org/mathscinet-getitem?mr=2781932")[#text("observation of Larsen and Pink")]#text(" is that this sort of behaviour is shared by all other finite subgroups of algebraic groups such as ")#mi("{SL_2(\\overline{k})}")#text(", as long as these groups are not (mostly) trapped in a proper algebraic subgroup. We first illustrate this phenomenon for the torus groups:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10 (Larsen-Pink inequality, special case)")]#text(" ")#metadata(none) <tao-fdd3b4897d05021f62ae>#text(" Let ")#mi("{A}")#text(" be a finite subgroup of ")#mi("{SL_2(\\overline{k})}")#text(". Then one of the following statements hold:")

#list(
[#text("(Non-concentration) For any maximal torus ")#mi("{T}")#text(", one has ")#tao-math("{\\left|A \\cap T\\right| \\ll \\left|A\\right|^{1/3}}", block: false)#text(".")],
[#text("(Trapping) There is a Borel subgroup ")#mi("{B}")#text(" such that ")#tao-math("{\\left|A \\cap B\\right| \\gg \\left|A\\right|}", block: false)#text(".")]
)
]

#emph[#text("Proof:")]#text(" Suppose that the trapping hypothesis fails, thus ")#tao-math("{\\left|A \\cap B\\right| = o(\\left|A\\right|)}", block: false)#text(" for all Borel subgroups ")#mi("{B}")#text(", where we interpret ")#tao-math("{o(\\left|A\\right|)}", block: false)#text(" here to mean “less than ")#tao-math("{\\epsilon \\left|A\\right|}", block: false)#text(" for an arbitrarily small constant ")#mi("{\\epsilon>0}")#text(" which we are at liberty to choose”. (If one is uncomfortable with this type of definition, one can instead consider a sequence of potential counterexamples ")#mi("{A = A_n}")#text(" to the above proposition in various groups ")#mi("{SL_2(\\overline{k_n})}")#text(", in which ")#tao-math("{\\sup_B \\left|A \\cap B\\right| = o_{n \\rightarrow \\infty}(\\left|A\\right|)}", block: false)#text(". Alternatively, one can also rephrase this argument if desired in the language of nonstandard analysis.) In particular, we see that any coset of ")#mi("{B}")#text(" occupies a fraction ")#mi("{o(1)}")#text(" at most of ")#mi("{A}")#text(". Thus, for instance, if we select an element ")#mi("{\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}}")#text(" from ")#mi("{A}")#text(" uniformly at random, then with probability ")#mi("{1-o(1)}")#text(", ")#mi("{b}")#text(" is non-zero, and similarly for ")#mi("{a,c,d}")#text(". To put it more informally, the matrix entries of an element of ")#mi("{A}")#text(" are “generically” non-zero. Similarly if we first conjugate ")#mi("{A}")#text(" by a fixed group element.")

#text("We need to show that ")#tao-math("{\\left|A \\cap T\\right| \\ll \\left|A\\right|^{1/3}}", block: false)#text(" for any maximal torus ")#mi("{T}")#text(". By conjugation we may take ")#mi("{T}")#text(" to be the standard maximal torus ")#mi("{T = T(\\overline{k})}")#text(". Set ")#mi("{A^{\\prime} := A \\cap T(\\overline{k})}")#text(", then ")#mi("{A^{\\prime}}")#text(" is a subgroup of ")#mi("{A}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("A^{\\prime} := \\{ \\begin{pmatrix} t & 0 \\ & t^{-1} \\end{pmatrix}: t\\in H \\}")]]

#text("for some finite multiplicative subgroup ")#mi("{H}")#text(" of ")#mi("{\\overline{k}^\\times}")#text(". We may assume that ")#tao-math("{\\left|H\\right|}", block: false)#text(" is larger than any given absolute constant, as the claim is trivial otherwise. Our task is to show that ")#tao-math("{\\left|H\\right|^3 \\ll \\left|A\\right|}", block: false)#text(".")

#text("Let ")#mi("{g = \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}}")#text(" be a typical element of ")#mi("{A}")#text(". By the preceding discussion, we may assume that ")#mi("{a,b,c,d}")#text(" are all non-zero. Since ")#mi("{A^{\\prime}}")#text(" is a subgroup of ")#mi("{A}")#text(", we have ")#mi("{A^{\\prime} g A^{\\prime} g A^{\\prime} \\subset A}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} t_1 & 0 \\\\ 0 & t_1^{-1} \\end{pmatrix} \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} \\begin{pmatrix} t_2 & 0 \\\\ 0 & t_2^{-1} \\end{pmatrix} \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} \\begin{pmatrix} t_3 & 0 \\\\ 0 & t_3^{-1} \\end{pmatrix} \\in A")]]

#text("for all ")#mi("{t_1,t_2,t_3 \\in H}")#text(". We evaluate the inner matrix products to obtain that")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} t_1 & 0 \\\\ 0 & t_1^{-1} \\end{pmatrix} \\begin{pmatrix} a^2 t_2 + bc t_2^{-1} & ac t_2 + bd t_2^{-1} \\\\ ac t_2 + cd t_2^{-1} & bc t_2 + d^2 t_2^{-1} \\end{pmatrix} \\begin{pmatrix} t_3 & 0 \\\\ 0 & t_3^{-1} \\end{pmatrix} \\in A")]]

#text("for ")#mi("{t_1,t_2,t_3 \\in H}")#text(".")

#text("Because ")#mi("{a,b,c,d}")#text(" are non-zero, we see that for all but ")#mi("{O(1)}")#text(" values of ")#mi("{t_2}")#text(", all four entries of the middle matrix here are non-zero. As a consequence, if one fixes ")#mi("{t_2}")#text(" and lets ")#mi("{t_1,t_3}")#text(" vary, all of the triple products given above are distinct. Note that if one takes the above triple product and multiplies the diagonal entries together, the ")#mi("{t_1, t_3}")#text(" terms cancel and one obtains ")#mi("{(a^2 t_2 + bc t_2^{-1}) (bc t_2 + d^2 t_2^{-1})}")#text(". This rational map (as a function of ")#mi("{t_2}")#text(") is at most four-to-one; each value of this map is associated to at most four values of ")#mi("{t_2}")#text(". Putting all this together, we conclude that there are ")#tao-math("{\\gg \\left|H\\right|^3}", block: false)#text(" different triple products one can form here as ")#mi("{t_1,t_2,t_3 \\in H}")#text(" vary, and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" ")#metadata(none) <tao-f631d67b4db19b8d894b>#text(" Establish a variant of Proposition ")#link(<tao-fdd3b4897d05021f62ae>)[#text("10")]#text(" in which the maximal tori are replaced by unipotent groups.")
]

#text("Given a group element ")#mi("{g \\in SL_2(\\overline{k})}")#text(", let ")#mi("{Conj(g) := \\{ hgh^{-1}: h \\in SL_2(\\overline{k}) \\}}")#text(" be the conjugacy class of ")#mi("{g}")#text(". The behaviour of this class depends on the nature of ")#mi("{g}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" ")#metadata(none) <tao-3d8e95cd6e662236ed31>#text(" Let ")#mi("{g}")#text(" be an element of ")#mi("{SL_2(\\overline{k})}")#text(".")

#list(
[#text("(i) If ")#mi("{g}")#text(" is central, show that ")#mi("{Conj(g) = \\{\\pm 1\\}}")#text(".")],
[#text("(ii) If ")#mi("{g}")#text(" is regular unipotent, show that ")#mi("{Conj(g)}")#text(" is the space of all regular unipotent elements.")],
[#text("(iii) If ")#mi("{g}")#text(" is negative of a regular unipotent element, show that ")#mi("{Conj(g)}")#text(" is the space of all negatives of regular unipotent elements.")],
[#text("(iv) If ")#mi("{g}")#text(" is regular semisimple, show that ")#mi("{Conj(g) := \\{ g^{\\prime}\\in SL_2(\\overline{k}): \\text{tr}(g)= \\text{tr}(g^{\\prime})\\}}")#text(".")]
)
]

#text("We can “dualise” the upper bound on maximal tori in Proposition ")#link(<tao-fdd3b4897d05021f62ae>)[#text("10")]#text(" into a lower bound on conjugacy classes:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 11 (Large conjugacy classes)")]#text(" ")#metadata(none) <tao-b8103ba73bca263ca43b>#text(" Let ")#mi("{A}")#text(" be a finite subgroup of ")#mi("{SL_2(\\overline{k})}")#text(". Then one of the following statements hold:")

#list(
[#text("(Large conjugacy classes) For any regular semisimple or regular projectively unipotent ")#mi("{g \\in A}")#text(", one has ")#tao-math("{\\left|A \\cap Conj(g)\\right| \\gg \\left|A\\right|^{2/3}}", block: false)#text(".")],
[#text("(Trapping) There is a Borel subgroup ")#mi("{B}")#text(" such that ")#tao-math("{\\left|A \\cap B\\right| \\gg \\left|A\\right|}", block: false)#text(".")]
)
]

#emph[#text("Proof:")]#text(" As before we may assume that ")#tao-math("{\\left|A \\cap B\\right| =o(\\left|A\\right|)}", block: false)#text(" for all Borel subgroups ")#mi("{B}")#text(". Let ")#mi("{g \\in A}")#text(" be regular semisimple, and consider the map ")#mi("{\\phi: h \\mapsto hgh^{-1}}")#text(" from ")#mi("{A}")#text(" to ")#mi("{A \\cap Conj(g)}")#text(". For each ")#mi("{g^{\\prime} \\in A \\cap Conj(g)}")#text(", the preimage of ")#mi("{g^{\\prime}}")#text(" by ")#mi("{\\phi}")#text(" is contained in a coset of the centraliser ")#mi("{C(g^{\\prime}) := \\{ h \\in SL_2(\\overline{k}): hg^{\\prime}=g^{\\prime}h\\}}")#text(" of ")#mi("{g^{\\prime}}")#text(". As ")#mi("{g}")#text(" (and hence ")#mi("{g^{\\prime}}")#text(") is regular semisimple or regular projectively unipotent, this centraliser is a maximal torus or (two copies of) a unipotent group (this can be seen by placing ")#mi("{g}")#text(" in Jordan normal form). By Proposition ")#link(<tao-fdd3b4897d05021f62ae>)[#text("10")]#text(" or Exercise ")#link(<tao-f631d67b4db19b8d894b>)[#text("7")]#text(", we conclude that each preimage of ")#mi("{\\phi}")#text(" has cardinality ")#tao-math("{O(\\left|A\\right|^{1/3})}", block: false)#text(", which forces the range to have cardinality ")#tao-math("{\\gg \\left|A\\right|^{2/3}}", block: false)#text(" as claimed. ")#mi("\\Box")

#text("We remark that this gives a dichotomy analogous to Lemma ")#link(<tao-30ee9c81e22076a1ce6b>)[#text("3")]#text(" or Lemma ")#link(<tao-63631485dac5a72b0358>)[#text("6")]#text(" in the case ")#tao-math("{\\left|A\\cap B\\right| =o(\\left|A\\right|)}", block: false)#text(". Namely, for any ")#mi("{g \\in SL_2({\\overline{k}})}")#text(", either ")#mi("{A \\cap Conj(g)}")#text(" is empty, or ")#tao-math("{\\left|A \\cap Conj(g)\\right| \\gg \\left|A\\right|^{2/3}}", block: false)#text(". We will take advantage of a dichotomy similar to this (but for tori instead of conjugacy classes) in the next section.")

#text("We can match the lower bound in Proposition ")#link(<tao-b8103ba73bca263ca43b>)[#text("11")]#text(" with an upper bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 12 (Larsen-Pink inequality, another special case)")]#text(" ")#metadata(none) <tao-ba22855ac516f13914df>#text(" Let ")#mi("{A}")#text(" be a finite subgroup of ")#mi("{SL_2(\\overline{k})}")#text(". Then one of the following statements hold:")

#list(
[#text("(Non-concentration) For any regular semisimple ")#mi("{g \\in SL_2(\\overline{k})}")#text(", one has ")#tao-math("{\\left|A \\cap Conj(g)\\right| \\ll \\left|A\\right|^{2/3}}", block: false)#text(".")],
[#text("(Trapping) There is a Borel subgroup ")#mi("{B}")#text(" such that ")#tao-math("{\\left|A \\cap B\\right| \\gg \\left|A\\right|}", block: false)#text(".")]
)
]

#emph[#text("Proof:")]#text(" Again, we may assume that ")#tao-math("{\\left|A \\cap B\\right| = o(\\left|A\\right|)}", block: false)#text(" for all Borel subgroups ")#mi("{B}")#text(". In particular, we may take ")#tao-math("{\\left|A\\right|}", block: false)#text(" larger than any given absolute constant. Let ")#mi("{g}")#text(" be regular semisimple, and let ")#mi("{S:= A \\cap Conj(g) =\\{ s \\in A: \\text{tr}(s) = \\text{tr}(g)\\}}")#text("; our task is to show that ")#tao-math("{\\left|S\\right| \\ll \\left|A\\right|^{2/3}}", block: false)#text(". Note from Exercise ")#link(<tao-3d8e95cd6e662236ed31>)[#text("8")]#text(" that ")#mi("{g}")#text(" is conjugate to ")#mi("{g^{-1}}")#text(", and so ")#mi("{S}")#text(" is symmetric: ")#mi("{S = S^{-1}}")#text(". Also, ")#mi("{Sa=aS}")#text(" for all ")#mi("{a \\in A}")#text(".")

#text("Observe that whenever ")#mi("{a, b \\in A}")#text(" and ")#mi("{s \\in S \\cap a^{-1} S \\cap b^{-1} S}")#text(", then the triple ")#mi("{(s,as, bs)}")#text(" lies in ")#mi("{S^3}")#text("; conversely, every triple in ")#mi("{S^3}")#text(" arises in this manner. Thus we have the identity")

#align(center)[#tao-fit-display[#tao-math("\\left|S\\right|^3 = \\sum_{a,b \\in A} |S \\cap a^{-1} S \\cap b^{-1} S|.", block: true)]]

#text("We will show that ")#metadata(none) <tao-e124adcce1fb2f88e1ea>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\sum_{a,b \\in A} \\left|S \\cap a^{-1} S \\cap b^{-1} S\\right| \\ll \\left|A\\right|^2 + \\left|A\\right|^{4/3} \\left|S\\right|,", block: true)]]



#text(" which will give ")#tao-math("{\\left|S\\right| \\ll \\left|A\\right|^{2/3}}", block: false)#text(" as required.")

#text("We now establish ")#link(<tao-e124adcce1fb2f88e1ea>)[#text("(1)")]#text(". We divide into several contributions. First suppose that ")#mi("{a = \\pm 1}")#text(". Then we bound the summand by ")#tao-math("{\\left|S\\right|}", block: false)#text("; there are ")#tao-math("{O(\\left|A\\right|)}", block: false)#text(" summands here, leading to a total contribution of ")#tao-math("{O(\\left|A\\right| \\left|S\\right|)}", block: false)#text(", which is acceptable. Similarly if ")#mi("{b=\\pm 1}")#text(", or ")#mi("{a = \\pm b}")#text(", so we may restrict to the remaining cases when ")#mi("{\\pm 1}")#text(", ")#mi("{\\pm a}")#text(", ")#mi("{\\pm b}")#text(" are distinct. In particular, ")#mi("{a, b}")#text(" are now either regular unipotent or regular semisimple.")

#text("We now consider the case in which ")#mi("{1,a,b}")#text(" are linearly dependent (in the space ")#mi("{M_2(\\overline{k})}")#text(" of ")#mi("{2\\times 2}")#text(" matrices). For fixed ")#mi("{a}")#text(", this constrains ")#mi("{b}")#text(" to either a maximal torus or a unipotent group (depending on whether ")#mi("{a}")#text(" is regular semisimple or regular projectively unipotent); this is easiest to see by placing ")#mi("{a}")#text(" in Jordan canonical form. By the preceding results, we see that there are ")#tao-math("{O(\\left|A\\right|^{1/3})}", block: false)#text(" choices of ")#mi("{b}")#text(" for each ")#tao-math("{\\left|A\\right|}", block: false)#text(", leading to a contribution of ")#tao-math("{O( \\left|A\\right|^{4/3} \\left|S\\right| )}", block: false)#text(" in this case, which is acceptable. So we may now take ")#mi("{1,a,b}")#text(" to be linearly independent.")

#text("The set ")#mi("{S \\cap a^{-1} S \\cap b^{-1} S}")#text(" is the intersection of ")#mi("{A}")#text(" with the affine line")

#align(center)[#tao-fit-display[#mitex("\\ell := \\{ s \\in M_2(\\overline{k}); \\text{tr}(s) = \\text{tr}(as) = \\text{tr}(bs) = \\text{tr}(g) \\};")]]

#text("this is indeed a line when ")#mi("{1,a,b}")#text(" are linearly independent. In most cases, this line ")#mi("{\\ell}")#text(" will intersect ")#mi("{SL_2(\\overline{k})}")#text(" (which we can view as a quadric surface in ")#mi("{M_2(\\overline{k})}")#text(") in at most two points, leading to a contribution of ")#tao-math("{O(\\left|A\\right|^2)}", block: false)#text(" for this case, which is acceptable. The only cases left to treat are when the line ")#mi("{\\ell}")#text(" are incident to ")#mi("{SL_2(\\overline{k})}")#text(". This only occurs when the line ")#mi("{\\ell}")#text(" takes the form ")#mi("{hU}")#text(" for some ")#mi("{h \\in SL_2(\\overline{k})}")#text(" and unipotent group ")#mi("{U}")#text("; this is easiest to see by multiplying ")#mi("{\\ell}")#text(" on the left so that it contains the identity, and then placing another element of the line in Jordan normal form. In that case, we have")

#align(center)[#tao-fit-display[#mitex("\\text{tr}(hu) = \\text{tr}(ahu) = \\text{tr}(bhu) = \\text{tr}(g)")]]

#text("for all ")#mi("{u \\in U}")#text(". This forces ")#mi("{h, ah, bh}")#text(" to all lie in the Borel subgroup ")#mi("{B}")#text(" associated to ")#mi("{U}")#text(" (this is easiest to see by first conjugating ")#mi("{U}")#text(" into the standard unipotent group ")#mi("{U(\\overline{k})}")#text("). In particular, ")#mi("{a, b}")#text(" both lie in ")#mi("{B}")#text(". Furthermore, if we write ")#mi("{\\text{tr}(g) = t + t^{-1}}")#text(", then the diagonal entries of ")#mi("{h,ah,bh}")#text(" are ")#mi("{t,t^{-1}}")#text(" or ")#mi("{t^{-1},t}")#text(", and so the diagonal entries of ")#mi("{a,b}")#text(" are either ")#mi("{1,1}")#text(" or ")#mi("{t^{-2},t^2}")#text(" or ")#mi("{t^2,t^{-2}}")#text(". In particular, ")#mi("{U}")#text(" is the stabiliser of one of the eigenvectors of ")#mi("{a}")#text(" – so for fixed ")#mi("{a}")#text(", there are at most two choices for ")#mi("{U}")#text(" (recall that ")#mi("{a}")#text(" was regular). Furthermore, for fixed ")#mi("{a}")#text(" and ")#mi("{U}")#text(", ")#mi("{b}")#text(" is constrained to lie in at most three cosets of ")#mi("{U}")#text(". As such, there are only ")#tao-math("{O(\\left|A\\right|^{1/3})}", block: false)#text(" choices of ")#mi("{b}")#text(" here for each ")#mi("{a}")#text(", giving another contribution of ")#tao-math("{O(\\left|A\\right|^{4/3}\\left|S\\right|)}", block: false)#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" ")#metadata(none) <tao-2274631b81def59664f2>#text(" Let ")#mi("{A}")#text(" be a finite subgroup of ")#mi("{SL_2(\\overline{k})}")#text(", such that ")#tao-math("{\\left|A \\cap B\\right| = o(\\left|A\\right|)}", block: false)#text(" for all Borel subgroups ")#mi("{B}")#text(". Show that at most ")#tao-math("{O(\\left|A\\right|^{2/3})}", block: false)#text(" of the elements of ")#mi("{A}")#text(" are unipotent.")
]

#text("We can use the upper bound on conjugacy classes to obtain a lower bound on tori:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 13 (Large tori)")]#text(" ")#metadata(none) <tao-10ee633ef5d289c02fa6>#text(" Let ")#mi("{A}")#text(" be a finite subgroup of ")#mi("{SL_2(\\overline{k})}")#text(". Then one of the following statements hold:")

#list(
[#text("(Large torus) For any regular semisimple ")#mi("{g \\in A}")#text(", one has ")#tao-math("{\\left|A \\cap T\\right| \\gg \\left|A\\right|^{1/3}}", block: false)#text(", where ")#mi("{T}")#text(" is the unique maximal torus containing ")#mi("{g}")#text(".")],
[#text("(Trapping) There is a Borel subgroup ")#mi("{B}")#text(" such that ")#tao-math("{\\left|A \\cap B\\right| \\gg \\left|A\\right|}", block: false)#text(".")]
)
]

#emph[#text("Proof:")]#text(" We can of course assume that the trapping case does not occur. We consider the map ")#mi("{\\phi: a\\mapsto aga^{-1}}")#text(" from ")#mi("{A}")#text(" to ")#mi("{A \\cap Conj(g)}")#text(". By Proposition ")#link(<tao-ba22855ac516f13914df>)[#text("12")]#text(", the range of ")#mi("{\\phi}")#text(" has cardinality ")#tao-math("{O(\\left|A\\right|^{2/3})}", block: false)#text(", so by the pigeonhole principle, there is a preimage of ")#mi("{A \\cap Conj(g)}")#text(" of cardinality ")#tao-math("{\\gg \\left|A\\right|^{1/3}}", block: false)#text(". But all preimages are conjugate to each other, so the preimage of ")#mi("{g}")#text(" has cardinality ")#tao-math("{\\gg \\left|A\\right|^{1/3}}", block: false)#text(". But this preimage is the intersection of ")#mi("{A}")#text(" with the centraliser of ")#mi("{g}")#text(", which two cosets of ")#mi("{T}")#text(", and so ")#tao-math("{\\left|A \\cap T\\right| \\gg \\left|A\\right|^{1/3}}", block: false)#text(" as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" ")#metadata(none) <tao-0114108ab3b9e75d2f99>#text(" Establish a variant of Proposition ")#link(<tao-10ee633ef5d289c02fa6>)[#text("13")]#text(" in which ")#mi("{g}")#text(" is regular unipotent instead of regular semisimple, and ")#mi("{T}")#text(" is replaced with the unique unipotent group containing ")#mi("{g}")#text(".")
]

#text("This gives a second (and particularly useful) dichotomy: assuming ")#mi("{A}")#text(" is not trapped by a Borel subgroup, for a maximal torus ")#mi("{T}")#text(", ")#tao-math("{\\left|A\\cap T\\right|}", block: false)#text(" is either at most two, or is comparable to ")#tao-math("{\\left|A\\right|^{1/3}}", block: false)#text(".")

#text("To exploit this, we use the following counting argument ")#link("http://www.ams.org/mathscinet-getitem?mr=2781932")[#text("of Larsen and Pink")]#text(" (which is also reminiscent of an old argument of Jordan, used to prove ")#link("http://en.wikipedia.org/wiki/Jordan%E2%80%93Schur_theorem")[#text("his theorem")]#text(" mentioned previously), followed by some ")#emph[#text("ad hoc")]#text(" arguments specific to ")#mi("{SL_2}")#text(". We continue to assume that ")#mi("{A}")#text(" is not trapped by a Borel subgroup. Let ")#mi("{Z := A \\cap\\{+1,-1\\}}")#text(" denote the central elements of ")#mi("{A}")#text(", thus ")#tao-math("{\\left|Z\\right|}", block: false)#text(" is either ")#mi("{1}")#text(" or ")#mi("{2}")#text(". Observe that every element in ")#mi("{A \\backslash Z}")#text(" is either regular projectively unipotent or regular semisimple; in the latter case, the element lies in a unique maximal torus, which also contains ")#mi("{Z}")#text(". We conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|A\\right|-\\left|Z\\right| = u + \\sum_T (\\left|A \\cap T\\right| - \\left|Z\\right|)", block: true)]]

#text("where ")#mi("{T}")#text(" ranges over all the maximal tori that intersect ")#mi("{A}")#text(", and ")#mi("{u}")#text(" is the number of regular projective unipotents in ")#mi("{A}")#text(".")

#text("If we conjugate a maximal torus ")#mi("{T}")#text(" by an element of ")#mi("{A}")#text(", we get another maximal torus, or the same maximal torus if the element used to conjugate ")#mi("{T}")#text(" in was in the normaliser ")#mi("{N_A(T) := \\{ a \\in A: a T=Ta\\}}")#text(" of ")#mi("{T}")#text(". Thus, by the ")#link("http://en.wikipedia.org/wiki/Group_action#Orbit-stabilizer_theorem")[#text("orbit-stabilizer theorem")]#text(", there are exactly ")#tao-math("{\\left|A\\right|/\\left|N_A(T)\\right|}", block: false)#text(" tori conjugate to ")#mi("{T}")#text(" in ")#mi("{A}")#text(". We thus see that")

#align(center)[#tao-fit-display[#tao-math("\\left|A\\right|-\\left|Z\\right| = u + \\sum_{T \\in {\\mathcal T}} \\frac{\\left|A\\right|}{\\left|N_A(T)\\right|} (\\left|A \\cap T\\right| - \\left|Z\\right|)", block: true)]]

#text("where ")#mi("{{\\mathcal T}}")#text(" is a collection of representatives of conjugacy classes of maximal tori intersecting ")#mi("{A}")#text(" in a regular semisimple element. We rearrange this as")

#align(center)[#tao-fit-display[#tao-math("1 = \\frac{u+\\left|Z\\right|}{\\left|A\\right|} + \\sum_{T \\in {\\mathcal T}} \\frac{1}{[N_A(T):A \\cap T]} (1 - \\frac{\\left|Z\\right|}{\\left|A \\cap T\\right|}).", block: true)]]

#text("Note that if ")#mi("{T}")#text(" is a maximal torus, the normaliser of ")#mi("{T}")#text(" in ")#mi("{SL_2(\\overline{k})}")#text(" has index ")#mi("{2}")#text(". As such, ")#mi("{A\\cap T}")#text(" has index at most two in ")#mi("{N_A(T)}")#text(", and so ")#mi("{\\frac{1}{[N_A(T):A \\cap T]}}")#text(" is either equal to ")#mi("{1}")#text(" or ")#mi("{1/2}")#text(" for each ")#mi("{T}")#text(". From the preceding bounds on tori and unipotent elements, we also have ")#tao-math("{\\frac{\\left|Z\\right|}{\\left|A \\cap T\\right|} \\sim \\left|A\\right|^{-1/3}}", block: false)#text(" and ")#tao-math("{\\frac{u+\\left|Z\\right|}{\\left|A\\right|} = O( \\left|A\\right|^{-1/3} )}", block: false)#text(". As we are assuming ")#tao-math("{\\left|A\\right|}", block: false)#text(" to be large, the above equation is only consistent when ")#mi("{{\\mathcal T}}")#text(" has cardinality ")#mi("{1}")#text(" or ")#mi("{2}")#text(", and ")#tao-math("{\\frac{u+\\left|Z\\right|}{\\left|A\\right|}}", block: false)#text(" is comparable to ")#tao-math("{\\left|A\\right|^{-1/3}}", block: false)#text(", or equivalently that ")#mi("{u}")#text(" is comparable to ")#tao-math("{\\left|A\\right|^{2/3}}", block: false)#text(". Thus, ")#mi("{A}")#text(" has plenty of regular projective unipotents (matching the upper bound from Exercise ")#link(<tao-2274631b81def59664f2>)[#text("9")]#text("); in particular, there is at least one regular unipotent.")

#text("Applying a conjugation, we may assume that ")#mi("{A}")#text(" contains ")#mi("{e := \\begin{pmatrix} 1 & 1 \\\\ 0 & 1 \\end{pmatrix}}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("A \\cap U(\\overline{k}) = \\{\\begin{pmatrix} 1 & t \\\\ 0 & 1 \\end{pmatrix}: t \\in E\\}")]]

#text("for some additive group ")#mi("{E \\subset \\overline{k}}")#text(" containing ")#mi("{1}")#text(". By Exercise ")#link(<tao-f631d67b4db19b8d894b>)[#text("7")]#text(", ")#tao-math("{\\left|E\\right| \\ll \\left|A\\right|^{1/3}}", block: false)#text("; by Exercise ")#link(<tao-0114108ab3b9e75d2f99>)[#text("10")]#text(", we have ")#tao-math("{\\left|E\\right|\\gg \\left|A\\right|^{1/3}}", block: false)#text(" also.")

#text("The map ")#mi("{a \\mapsto a(A \\cap U(\\overline{k}))a^{-1}}")#text(" maps ")#mi("{A}")#text(" to unipotent groups that intersect ")#mi("{A}")#text(" in ")#tao-math("{\\sim \\left|A\\right|^{1/3}}", block: false)#text(" regular unipotents. As there are ")#tao-math("{\\sim \\left|A\\right|^{2/3}}", block: false)#text(" regular unipotent elements in ")#mi("{A}")#text(", we see that there are only ")#tao-math("{O(\\left|A\\right|^{1/3})}", block: false)#text(" such unipotent groups available. From the pigeonhole principle and conjugation, we conclude that the preimage of ")#mi("{U(\\overline{k})}")#text(" in this map has cardinality ")#tao-math("{\\gg \\left|A\\right|^{2/3}}", block: false)#text(". But this preimage is simply ")#mi("{A \\cap B(\\overline{k})}")#text(". In particular, the quotient ")#mi("{(A\\cap B(\\overline{k}))/(A \\cap U(\\overline{k}))}")#text(" has cardinality ")#tao-math("{\\gg \\left|A\\right|^{1/3}}", block: false)#text(". Observe that each element of this quotient acts on ")#mi("{A \\cap U(\\overline{k})}")#text(" by conjugation, and the corresponding action on ")#mi("{E}")#text(" is multiplicative (by the square of a diagonal entry of an element in the quotient). As such, if we set")

#align(center)[#tao-fit-display[#mitex("F := \\{ \\xi \\in \\overline{k}: \\xi E \\subset E\\}")]]

#text("to be the “multiplicative symmetry set” of ")#mi("{E}")#text(", then we have ")#tao-math("{\\left|F\\right|\\gg \\left|A\\right|^{1/3}}", block: false)#text(". As ")#mi("{E}")#text(" is a finite additive group, ")#mi("{F}")#text(" is a field of size at most ")#tao-math("{\\left|E\\right| \\ll\\left|A\\right|^{1/3}}", block: false)#text(", thus ")#mi("{F}")#text(" is a finite field of cardinality ")#tao-math("{\\left|F\\right| \\sim \\left|A\\right|^{1/3}}", block: false)#text(". Also, ")#mi("{E}")#text(" is a vector space over ")#mi("{F}")#text("; as ")#mi("{E}")#text(" contains ")#mi("{1}")#text(" and has cardinality ")#tao-math("{O(\\left|A\\right|^{1/3})}", block: false)#text(", we see that ")#mi("{E=F}")#text(". Thus we have ")#metadata(none) <tao-b22a4aa3b70fea26fa94>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("A \\cap U(\\overline{k}) = \\begin{pmatrix} 1 & F \\\\ 0 & 1 \\end{pmatrix}.")]]



#text(" Also, as ")#mi("{(A\\cap B(\\overline{k}))/(A \\cap U(\\overline{k}))}")#text(" has to stabilise ")#mi("{F}")#text(", we see that all elements of ")#mi("{A \\cap B(\\overline{k})}")#text(" have diagonal elements whose square lies in ")#mi("{F}")#text(". Combining this with ")#link(<tao-b22a4aa3b70fea26fa94>)[#text("(2)")]#text(", we see that ")#mi("{A \\cap B(\\overline{k})}")#text(" takes the form ")#metadata(none) <tao-6511c5688bbb87798128>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("A \\cap B(\\overline{k}) = \\{ \\begin{pmatrix} t & f(t) + x \\\\ 0 & t^{-1} \\end{pmatrix}: t \\in H, x\\in F\\}")]]



#text(" for some multiplicative group ")#mi("{H}")#text(" of elements whose square lies in ")#mi("{F^\\times}")#text(" (in particular, ")#mi("{H \\cap F^\\times}")#text(" has index at most ")#mi("{2}")#text(" in ")#mi("{H}")#text("), and some function ")#mi("{f: H \\rightarrow \\overline{k}}")#text("; since ")#mi("{A \\cap B(\\overline{k})}")#text(" has cardinality ")#tao-math("{\\gg \\left|A\\right|^{2/3} \\sim \\left|F\\right|^2}", block: false)#text(", ")#mi("{H}")#text(" must have cardinality ")#tao-math("{\\sim \\left|F\\right|}", block: false)#text(". By taking the commutators of two matrices in ")#link(<tao-6511c5688bbb87798128>)[#text("(3)")]#text(", we see that ")#metadata(none) <tao-b68c83a34a662573e975>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("f(t) (s-s^{-1}) - f(s) (t-t^{-1}) \\in F")]]



#text(" for all ")#mi("{s,t \\in H}")#text(".")

#text("If we select ")#mi("{t_0 \\in H \\cap F^\\times}")#text(" such that ")#mi("{t_0-t_0^{-1}}")#text(" is non-zero, then by conjugating ")#mi("{A}")#text(" by a suitable element of ")#mi("{U(\\overline{k})}")#text(" (which does not affect any of the previous control established on ")#mi("{A}")#text(") we may normalise ")#mi("{f(t_0)}")#text(" to be zero. From ")#link(<tao-b68c83a34a662573e975>)[#text("(4)")]#text(" this makes ")#mi("{f(t) \\in F}")#text(" for all ")#mi("{t \\in H}")#text(". In particular, ")#mi("{A \\cap B(\\overline{k})}")#text(" is almost completely contained in ")#mi("{B(F)}")#text(": ")#metadata(none) <tao-8bc324acda6e9a5e920a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left|A \\cap B(\\overline{k}) \\cap B(F)\\right| \\geq \\left|A \\cap B(\\overline{k})\\right|/2.", block: true)]]



#text(" Now for any ")#mi("{g \\in A}")#text(", the subgroups ")#mi("{A \\cap B(\\overline{k})}")#text(" and ")#mi("{g^{-1} (A \\cap B(\\overline{k})) g}")#text(" of ")#mi("{A}")#text(" have index ")#tao-math("{O(\\left|A\\right|^{1/3})}", block: false)#text(", so their intersection must have cardinality ")#tao-math("{\\gg \\left|A\\right|^{1/3} \\gg \\left|F\\right|}", block: false)#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\left|A \\cap B(F) \\cap g B(F) g^{-1}\\right| \\gg \\left|F\\right|.", block: true)]]

#text("In particular, there must exist either a regular unipotent or a regular semisimple element ")#mi("{h \\in A}")#text(" of ")#mi("{B(F)}")#text(" such that ")#mi("{ghg^{-1}}")#text(" also lies in ")#mi("{B(F)}")#text(". If ")#mi("{h}")#text(" is regular semisimple in ")#mi("{B(F)}")#text(", it has an eigenbasis in ")#mi("{F^2}")#text(", and so ")#mi("{g}")#text(" must map such an eigenbasis to another eigenbasis, and thus lies in ")#mi("{SL_2(F)}")#text(". If instead ")#mi("{h}")#text(" is regular unipotent, it has the line ")#mi("{\\{0\\} \\times \\overline{k}}")#text(" as the unique (geometric) eigenspace; ")#mi("{g}")#text(" must preserve this eigenspace and thus lies in ")#mi("{B(\\overline{k})}")#text(", and thus in ")#mi("{B(F)}")#text(" and therefore in ")#mi("{SL_2(F)}")#text(" by ")#link(<tao-8bc324acda6e9a5e920a>)[#text("(5)")]#text(". Combining the cases, we conclude that ")#mi("{A \\subset SL_2(F)}")#text(". We may therefore summarise our discussion as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 14 (Rough description of finite subgroups of ")#mi("{SL_2}")#text(")")]#text(" ")#metadata(none) <tao-de1edc97b5c7ca959bec>#text(" Let ")#mi("{A}")#text(" be a finite subgroup of ")#mi("{SL_2(\\overline{k})}")#text(". Then one of the following statements hold:")

#list(
[#text("(Arithmetic subgroup) There is a finite subfield ")#mi("{F}")#text(" of ")#mi("{\\overline{k}}")#text(" with ")#tao-math("{\\left|F\\right| \\sim \\left|A\\right|^{1/3}}", block: false)#text(" such that ")#mi("{A}")#text(" is contained in a conjugate of ")#mi("{SL_2(F)}")#text(" (and is thus a subgroup of that conjugate of index ")#mi("{O(1)}")#text(").")],
[#text("(Trapping) There is a Borel subgroup ")#mi("{B}")#text(" such that ")#tao-math("{\\left|A \\cap B\\right| \\gg \\left|A\\right|}", block: false)#text(".")]
)
]

#text("In principle, the trapping case can be analysed further (using manipulations similar to those used to reach ")#link(<tao-8bc324acda6e9a5e920a>)[#text("(5)")]#text(") but we will not pursue this here. We remark that while these computations were somewhat lengthy (and less elementary and precise than the more classical results of Dickson), they can extend to more complicated algebraic groups, such as ")#mi("{SL_d(\\overline{k})}")#text(", or more generally to any algebraic group of bounded rank; see ")#link("http://www.ams.org/mathscinet-getitem?mr=2813339")[#text("this paper of Larsen and Pink")]#text(" for details. In particular, Larsen and Pink were able to use these methods to establish an important subcase of the famous ")#link("http://en.wikipedia.org/wiki/Classification_of_finite_simple_groups")[#text("classification of finite simple groups")]#text(", namely by verifying this classification for sufficiently large subgroups of a linear group of bounded rank over a field of arbitrary characteristic. It is conceivable that these methods may be extended in the future to give an alternate proof of the full classification (for sufficiently large groups, at least).")

#heading(level: 1)[#strong[#text(" — 3. The product theorem in ")#mi("{SL_2(k)}")#text(" — ")]]

#text("In this section we prove the ")#mi("{d=2}")#text(" case of Theorem ")#link(<tao-317c6953d7b0cb5ea874>)[#text("1")]#text(". This result was first established (for fields of prime order) ")#link("http://www.ams.org/mathscinet-getitem?mr=2415382")[#text("by Helfgott")]#text(" and then in the general case ")#link("http://arxiv.org/abs/1001.5069")[#text("by Dinai")]#text("; we will present a variant of Helfgott’s original argument which was developed ")#link("http://arxiv.org/abs/1005.1881")[#text("by Breuillard, Green, and Tao")]#text(" and independently ")#link("http://arxiv.org/abs/1005.1858")[#text("by Pyber and Szabo")]#text(". It is convenient to rephrase Helfgott’s theorem as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 15 (Product theorem in ")#mi("{SL_2(k)}")#text(", alternate form)")]#text(" ")#metadata(none) <tao-c0b95fab9925e02f06d6>#text(" Let ")#mi("{k}")#text(" be a finite field, and let ")#mi("{A}")#text(" be a ")#mi("{K}")#text("-approximate group in ")#mi("{G := SL_2(k)}")#text(" that generates ")#mi("{G}")#text(" for some ")#mi("{K \\geq 2}")#text(". Then one of the following holds:")

#list(
[#text("(Close to trivial) One has ")#tao-math("{\\left|A\\right| \\ll K^{O(1)}}", block: false)#text(".")],
[#text("(Close to ")#mi("{G}")#text(") One has ")#tao-math("{\\left|A\\right| \\geq K^{-O(1)} \\left|G\\right|}", block: false)#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Show that Theorem ")#link(<tao-317c6953d7b0cb5ea874>)[#text("1")]#text(" follows from Theorem ")#link(<tao-c0b95fab9925e02f06d6>)[#text("15")]#text(". (")#emph[#text("Hint:")]#text(" if ")#tao-math("{\\left|A^3\\right| \\leq \\left|A\\right|^{1+\\epsilon}}", block: false)#text(", use the multiplicative form of the Rusza triangle and covering lemmas to show that ")#mi("{(A \\cup \\{1\\} \\cup A^{-1})^2}")#text(" is a ")#tao-math("{O(\\left|A\\right|^{O(\\epsilon)})}", block: false)#text("-approximate group.)")
]

#text("The problem now concerns the behaviour of finite approximate subgroups ")#mi("{A}")#text(" of ")#mi("{SL_2(k)}")#text(". The first step will be to establish analogues of the Larsen-Pink non-concentration inequalities of the preceding section, but for approximate subgroups rather than genuine subgroups. (The observation that these inequalities could be usefully extended to the approximate group setting is ")#link("http://www.ams.org/mathscinet-getitem?mr=2833482")[#text("due to Hrushovski")]#text(", although for the specific case of ")#mi("{SL_2(k)}")#text(", the most important of these inequalities for the purposes of proving Theorem ")#link(<tao-c0b95fab9925e02f06d6>)[#text("15")]#text(" were first established ")#link("http://www.ams.org/mathscinet-getitem?mr=2415382")[#text("by Helfgott")]#text(".) We begin by eliminating concentration in linear subgroups.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 16 (Escape from subspaces)")]#text(" ")#metadata(none) <tao-177b7cb0686749afeb39>#text(" Let ")#mi("{A}")#text(", ")#mi("{K}")#text(" be as in Theorem ")#link(<tao-c0b95fab9925e02f06d6>)[#text("15")]#text(", and let ")#mi("{C>0}")#text(". Then one of the following holds:")

#list(
[#text("(Close to trivial) One has ")#tao-math("{\\left|A\\right| \\ll_C K^{O_C(1)}}", block: false)#text(".")],
[#text("(Escape) For any ")#mi("{d=0,1,2,3}")#text(" and any ")#mi("{d}")#text("-dimensional subspace ")#mi("{V}")#text(" of ")#mi("{\\overline{k}^4}")#text(", such that ")#mi("{V\\cap SL_2(\\overline{k})}")#text(" is a subgroup of ")#mi("{SL_2(\\overline{k})}")#text(", one has ")#tao-math("{\\left|A^2 \\cap V\\right| \\leq K^{-C} \\left|A\\right|}", block: false)#text(".")]
)
]

#text("In practice, we will only apply the escape conclusion for Borel subgroups of ")#mi("{SL_2(\\overline{k})}")#text(", which are intersections of ")#mi("{SL_2(\\overline{k})}")#text(" with three-dimensional subspaces; however, we need to work with the more general escape construction in the ")#emph[#text("proof")]#text(" of the lemma, for inductive purposes. The claim can in fact be established for any ")#mi("{d}")#text("-dimensional subspace ")#mi("{V}")#text(", or more generally for bounded complexity ")#mi("{d}")#text("-dimensional algebraic varieties; this will be discussed in the next section.")

#emph[#text("Proof:")]#text(" We induct on ")#mi("{d}")#text(". For ")#mi("{d=0}")#text(", the claim is trivial, since ")#tao-math("{\\left|A^2 \\cap V\\right|=1}", block: false)#text(" in that case. Now suppose that ")#mi("{d=1,2,3}")#text(", and the claim has already been proven for smaller values of ")#mi("{d}")#text(".")

#text("Let ")#mi("{V}")#text(" be a ")#mi("{d}")#text("-dimensional subspace of ")#mi("{SL_2(\\overline{k})}")#text(" with ")#mi("{V \\cap SL_2(\\overline{k})}")#text(" a group, and suppose for contradiction that ")#tao-math("{\\left|A^2 \\cap V\\right|>K^{-C}\\left|A\\right|}", block: false)#text(". As ")#mi("{A^2}")#text(" can be covered by ")#mi("{K}")#text(" copies of ")#mi("{A}")#text(", we can find ")#mi("{a\\in A}")#text(" such that ")#metadata(none) <tao-8e55a8eb125f0f428e4a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left|aA\\cap V\\right| > K^{-C-1} |A|.", block: true)]]





#text("Suppose that there exists an element ")#mi("{b}")#text(" of ")#mi("{A}")#text(" such that ")#mi("{bVb^{-1} \\neq V}")#text(", so that ")#mi("{bVb^{-1} \\cap V}")#text(" has dimension strictly less than ")#mi("{V}")#text(". From ")#link(<tao-8e55a8eb125f0f428e4a>)[#text("(6)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|A^4 \\cap bVb^{-1}\\right| \\geq \\left|baAb^{-1} \\cap bVb^{-1}\\right| > K^{-C-1}|A|.", block: true)]]

#text("Since ")#mi("{A^4}")#text(" can be covered by ")#mi("{K^3}")#text(" right translates of ")#mi("{A}")#text(", we can find ")#mi("{g \\in A^5}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|gA \\cap bVb^{-1}\\right| > K^{-C-4}|A|.", block: true)]]

#text("Let ")#mi("{A_1 :=aA \\cap V}")#text(" and ")#mi("{A_2 := gA \\cap bVb^{-1}}")#text(". Then ")#mi("{A_1 A_2^{-1}}")#text(" is contained in ")#mi("{A^7}")#text(", and so ")#mi("{1_{A_1} * 1_{A_2^{-1}}}")#text(" is supported on a set of cardinality at most ")#tao-math("{K^6 \\left|A\\right|}", block: false)#text(". Since")

#align(center)[#tao-fit-display[#tao-math("\\left\\| 1_{A_1} * 1_{A_2^{-1}} \\right\\|_{\\ell^1} = \\left|A_1\\right|\\left|A_2\\right| \\geq K^{-2C-5} \\left|A\\right|^2", block: true)]]

#text("we thus see from the pigeonhole principle that")

#align(center)[#tao-fit-display[#tao-math("\\left|1_{A_1} * 1_{A_2^{-1}}(x)\\right| \\geq K^{-2C-11} |A|.", block: true)]]

#text("The left-hand side is ")#tao-math("{\\left|A_1 \\cap x A_2\\right|}", block: false)#text(", and thus")

#align(center)[#tao-fit-display[#tao-math("\\left|(A_1\\cap x A_2)^{-1} \\cap (A_1 \\cap x A_2)\\right| \\geq K^{-2C-11}|A|.", block: true)]]

#text("The set in the left-hand side is contained in both ")#mi("{A^2}")#text(" and in ")#mi("{V\\cap (bVb^{-1})}")#text(" (here we use the group nature of ")#mi("{V \\cap SL_2(\\overline{k})}")#text("), and so")

#align(center)[#tao-fit-display[#tao-math("\\left|A^2 \\cap V\\cap (bVb^{-1})\\right| \\geq K^{-2C-11} |A|.", block: true)]]

#text("Applying the induction hypothesis, we conclude that ")#tao-math("{\\left|A\\right| \\leq K^{O_C(1)}}", block: false)#text(", and the claim follows.")

#text("The only remaining case is when ")#mi("{bVb^{-1}=V}")#text(" for all ")#mi("{b \\in A}")#text(". As ")#mi("{A}")#text(" generates ")#mi("{SL_2(k)}")#text(", this implies that ")#mi("{V}")#text(" is normalised by ")#mi("{SL_2(k)}")#text(". But this is impossible if ")#mi("{V}")#text(" has dimension ")#mi("{1,2,3}")#text("; see Exercise ")#link(<tao-317b32c143692b9939c1>)[#text("12")]#text(" below. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12 (Almost simplicity of ")#mi("{SL_2(k)}")#text(")")]#text(" ")#metadata(none) <tao-317b32c143692b9939c1>#text(" Let ")#mi("{V}")#text(" be a subspace of ")#mi("{\\overline{k}^4}")#text(" of dimension ")#mi("{1}")#text(", ")#mi("{2}")#text(", or ")#mi("{3}")#text(". Show that the group ")#mi("{\\{ g \\in SL_2(k): gVg^{-1} = V\\}}")#text(" does not contain all of ")#mi("{SL_2(k)}")#text(".")
]

#text("Now we can obtain an approximate version of Proposition ")#link(<tao-fdd3b4897d05021f62ae>)[#text("10")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 17 (Larsen-Pink inequality, special case)")]#text(" ")#metadata(none) <tao-302eaa73cba30e609ac4>#text(" Let ")#mi("{A}")#text(", ")#mi("{K}")#text(" be as in Theorem ")#link(<tao-c0b95fab9925e02f06d6>)[#text("15")]#text(". Then for any maximal torus ")#mi("{T}")#text(", one has ")#tao-math("{\\left|A^2 \\cap T\\right| \\ll K^{O(1)} \\left|A\\right|^{1/3}}", block: false)#text(".")
]

#text("In the context of ")#mi("{SL_2}")#text(", this bound on torus concentration was first established ")#link("http://www.ams.org/mathscinet-getitem?mr=2415382")[#text("by Helfgott")]#text(" (and extended to ")#mi("{SL_d}")#text(" in a ")#link("http://www.ams.org/mathscinet-getitem?mr=2781932")[#text("subsequent paper of Helfgott")]#text(").")

#emph[#text("Proof:")]#text(" We may assume that ")#tao-math("{\\left|A\\right| \\geq K^C}", block: false)#text(" for any given constant ")#mi("{C}")#text(", as the claim is trivial otherwise. Similarly, by Lemma ")#link(<tao-177b7cb0686749afeb39>)[#text("16")]#text(", we may assume that ")#tao-math("{\\left|A^2 \\cap B\\right|\\leq K^{-C}\\left|B\\right|}", block: false)#text(" for all Borel subgroups ")#mi("{B}")#text(".")

#text("We need to show that ")#tao-math("{\\left|A^2 \\cap T\\right| \\ll \\left|A\\right|^{1/3}}", block: false)#text(" for any maximal torus ")#mi("{T}")#text(". By conjugation we may take ")#mi("{T}")#text(" to be the standard maximal torus ")#mi("{T = T(\\overline{k})}")#text(". (This may make ")#mi("{A}")#text(" generate a conjugate of ")#mi("{SL_2(k)}")#text(", rather than ")#mi("{SL_2(k)}")#text(" itself, but this will not impact our argument). Set ")#mi("{A^{\\prime} := A^2 \\cap T(\\overline{k})}")#text(", then")

#align(center)[#tao-fit-display[#mitex("A^{\\prime} := \\{ \\begin{pmatrix} t & 0 \\\\ 0 & t^{-1} \\end{pmatrix}: t\\in H \\}")]]

#text("for some finite subset ")#mi("{H}")#text(" of ")#mi("{\\overline{k}^\\times}")#text(". We may assume that ")#tao-math("{\\left|H\\right| \\geq K^C}", block: false)#text(", as the claim is trivial otherwise. Our task is to show that ")#tao-math("{\\left|H\\right|^3 \\ll K^{O(1)} \\left|A\\right|}", block: false)#text(".")

#text("As in the proof of Proposition ")#link(<tao-302eaa73cba30e609ac4>)[#text("17")]#text(", we may find an element ")#mi("{g = \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}}")#text(" of ")#mi("{A^2}")#text(" with ")#mi("{a,b,c,d}")#text(" all non-zero. Since ")#mi("{A^{\\prime} g A^{\\prime} g A^{\\prime} \\subset A^{10}}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} t_1 & 0 \\\\ 0 & t_1^{-1} \\end{pmatrix} \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} \\begin{pmatrix} t_2 & 0 \\\\ 0 & t_2^{-1} \\end{pmatrix} \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} \\begin{pmatrix} t_3 & 0 \\\\ 0 & t_3^{-1} \\end{pmatrix} \\in A^{10}")]]

#text("for all ")#mi("{t_1,t_2,t_3 \\in H}")#text(". Arguing as in Proposition ")#link(<tao-302eaa73cba30e609ac4>)[#text("17")]#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|H\\right|^3\\ll \\left|A^{10}\\right|,", block: true)]]

#text("and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Show that if the non-concentration conclusion in Proposition ")#link(<tao-302eaa73cba30e609ac4>)[#text("17")]#text(" holds, then for every maximal torus ")#mi("{T}")#text(" and every ")#mi("{m \\geq 1}")#text(", one has ")#tao-math("{\\left|A^m \\cap T\\right| \\ll_m K^{O_m(1)} \\left|A\\right|^{1/3}}", block: false)#text(".")
]

#text("We can now establish variants of the other Larsen-Pink inequalities from the preceding section:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" ")#metadata(none) <tao-2c96ab740b97ba6e0aa4>#text(" Establish a variant of Proposition ")#link(<tao-302eaa73cba30e609ac4>)[#text("17")]#text(" in which the maximal tori are replaced by unipotent groups.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Large conjugacy classes)")]#text(" Let ")#mi("{A}")#text(", ")#mi("{K}")#text(" be as in Theorem ")#link(<tao-c0b95fab9925e02f06d6>)[#text("15")]#text(". Show that for any regular semisimple or regular projectively unipotent ")#mi("{g \\in A}")#text(", one has ")#tao-math("{\\left|A^3 \\cap Conj(g)\\right| \\gg K^{-O(1)} \\left|A\\right|^{2/3}}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16 (Larsen-Pink inequality, another special case)")]#text(" ")#metadata(none) <tao-2ceb1b60950a005d76d6>#text(" Let ")#mi("{A}")#text(", ")#mi("{K}")#text(" be as in Theorem ")#link(<tao-c0b95fab9925e02f06d6>)[#text("15")]#text(". Show that for any regular semisimple ")#mi("{g \\in SL_2(\\overline{k})}")#text(" and any ")#mi("{m \\geq 1}")#text(", one has ")#tao-math("{\\left|A^m \\cap Conj(g)\\right| \\ll_m K^{O_m(1)} \\left|A\\right|^{2/3}}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17 (Unipotent bound)")]#text(" Let ")#mi("{A}")#text(", ")#mi("{K}")#text(" be as in Theorem ")#link(<tao-c0b95fab9925e02f06d6>)[#text("15")]#text(". Show that ")#tao-math("{O(K^{O(1)} \\left|A\\right|^{2/3})}", block: false)#text(" of the elements of ")#mi("{A}")#text(" are unipotent.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18 (Large tori)")]#text(" ")#metadata(none) <tao-5cd3b6a3e0eae79eaedd>#text(" Let ")#mi("{A}")#text(", ")#mi("{K}")#text(" be as in Theorem ")#link(<tao-c0b95fab9925e02f06d6>)[#text("15")]#text(". Show that for any regular semisimple ")#mi("{g \\in A^2}")#text(", one has ")#tao-math("{\\left|A^4 \\cap T\\right| \\gg K^{-O(1)} \\left|A\\right|^{1/3}}", block: false)#text(", where ")#mi("{T}")#text(" is the unique maximal torus containing ")#mi("{g}")#text(". In fact one has ")#tao-math("{\\left|A^2 \\cap T\\right| \\gg K^{-O(1)} \\left|A\\right|^{1/3}}", block: false)#text(". (For the latter claim, cover ")#mi("{A^4}")#text(" by left translates of ")#mi("{A}")#text(".)")
]

#text("We remark that versions of most the results in the above exercises were first obtained in the context of ")#mi("{SL_2}")#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2415382")[#text("by Helfgott")]#text(" (and extended to ")#mi("{SL_d}")#text(" in a ")#link("http://www.ams.org/mathscinet-getitem?mr=2781932")[#text("subsequent paper of Helfgott")]#text("). However, the lower bound in Exercise ")#link(<tao-5cd3b6a3e0eae79eaedd>)[#text("18")]#text(" was only obtained in those papers for some maximal tori meeting ")#mi("{A^2}")#text(" non-trivially, rather than for all such tori, leading to some additional technical complications in Helfgott’s proof of Theorem ")#link(<tao-c0b95fab9925e02f06d6>)[#text("15")]#text(".")

#text("We now have a dichotomy: given a maximal torus ")#mi("{T}")#text(", either ")#mi("{A^2\\cap T}")#text(" has no regular semisimple elements (and thus contains only central elements), or else has cardinality ")#tao-math("{\\gg K^{-O(1)} \\left|A\\right|^{1/3}}", block: false)#text(". We exploit this dichotomy as follows. Call a maximal torus ")#mi("{T}")#text(" ")#emph[#text("involved")]#text(" if ")#mi("{A^2 \\cap T}")#text(" contains a regular semisimple element.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 18 (Key lemma)")]#text(" Let ")#mi("{A}")#text(", ")#mi("{K}")#text(" be as in Theorem ")#link(<tao-c0b95fab9925e02f06d6>)[#text("15")]#text(". Then one of the following statements hold:")

#list(
[#text("(Invariance) If ")#mi("{T}")#text(" is an involved torus and ")#mi("{a \\in A}")#text(", then ")#mi("{aTa^{-1}}")#text(" is an involved torus.")],
[#text("(Close to trivial) One has ")#tao-math("{\\left|A\\right| \\ll K^{O(1)}}", block: false)#text(".")]
)
]

#emph[#text("Proof:")]#text(" Let ")#mi("{T}")#text(" be an involved torus, then by the preceding exercise we have ")#tao-math("{\\left|A^2 \\cap T\\right|\\gg K^{-O(1)}\\left|A\\right|^{1/3}}", block: false)#text(", and thus ")#tao-math("{\\left|A^4 \\cap aTa^{-1}\\right| \\gg K^{-O(1)}\\left|A\\right|^{1/3}}", block: false)#text(". Thus, one has ")#tao-math("{\\left|gA \\cap aTa^{-1}\\right| \\gg K^{-O(1)} \\left|A\\right|^{1/3}}", block: false)#text(" for some ")#mi("{g \\in G}")#text(", which implies that ")#tao-math("{\\left|A^2 \\cap aTa^{-1}\\right| \\gg K^{-O(1)} \\left|A\\right|^{1/3}}", block: false)#text(". In particular, if ")#mi("{A}")#text(" is not close to trivial, ")#mi("{A^2 \\cap aTa^{-1}}")#text(" contains a regular semisimple element and so ")#mi("{aTa^{-1}}")#text(" is involved, as desired. ")#mi("\\Box")

#text("We can now finish the proof of Theorem ")#link(<tao-c0b95fab9925e02f06d6>)[#text("15")]#text(". Suppose ")#mi("{A}")#text(" is not close to trivial. As there are at most ")#tao-math("{O(K^{O(1)}\\left|A\\right|^{2/3})}", block: false)#text(" unipotent elements and ")#mi("{O(1)}")#text(" central elements in ")#mi("{A}")#text(", ")#mi("{A}")#text(" at least one regular semisimple element, and so there is at least one involved torus. By the above lemma, and the fact that ")#mi("{A}")#text(" generates ")#mi("{G}")#text(", we see that the set of involved tori is invariant under conjugation by ")#mi("{G}")#text(". As ")#mi("{G}")#text(" has cardinality ")#tao-math("{\\gg \\left|k\\right|^3}", block: false)#text(", and its intersection with the stabiliser of a single torus has cardinality ")#tao-math("{O(\\left|k\\right|)}", block: false)#text(", we conclude that there are ")#tao-math("{\\gg \\left|k\\right|^2 \\ll \\left|G\\right|^{2/3}}", block: false)#text(" involved tori. By Exercise ")#link(<tao-5cd3b6a3e0eae79eaedd>)[#text("18")]#text(", each of these tori contains ")#tao-math("{\\gg K^{-O(1)} \\left|A\\right|^{1/3}}", block: false)#text(" regular semisimple elements of ")#mi("{A^2}")#text(". Since each regular semisimple element belongs to a unique maximal torus, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|A^2\\right| \\gg \\left|G\\right|^{2/3} K^{-O(1)} \\left|A\\right|^{1/3};", block: true)]]

#text("as ")#tao-math("{\\left|A^2\\right| \\leq K\\left|A\\right|}", block: false)#text(", we conclude that ")#tao-math("{\\left|A\\right|\\gg K^{-O(1)} \\left|G\\right|}", block: false)#text(", as claimed.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" ")#metadata(none) <tao-de6da716412716d8f011>#text(" Let ")#mi("{A}")#text(" be a finite ")#mi("{K}")#text("-approximate subgroup of ")#mi("{SL_2(\\overline{k})}")#text(" for some algebraically closed field ")#mi("{\\overline{k}}")#text(". Show that one of the following statements hold:")

#list(
[#text("(Close to group) ")#mi("{A}")#text(" generates a finite subgroup ")#mi("{G}")#text(" of ")#mi("{SL_2(\\overline{k})}")#text(" with ")#tao-math("{\\left|G\\right| \\ll K^{O(1)} \\left|A\\right|}", block: false)#text(".")],
[#text("(Concentrated in Borel) There is a Borel subgroup ")#mi("{B}")#text(" of ")#mi("{SL_2(\\overline{k})}")#text(" with ")#tao-math("{\\left|A \\cap B\\right| \\gg K^{-O(1)} \\left|B\\right|}", block: false)#text(".")]
)

#text("(")#emph[#text("Hint:")]#text(" this does not follow directly from Theorem ")#link(<tao-c0b95fab9925e02f06d6>)[#text("15")]#text(", but can be established by a modification of the proof of that theorem.)")
]

#text("Note that the above exercise can be combined with Theorem ")#link(<tao-de1edc97b5c7ca959bec>)[#text("14")]#text(" to give a more detailed description of ")#mi("{A}")#text(". The Borel group ")#mi("{B}")#text(" is solvable, and by using tools from additive combinatorics, such as ")#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/")[#text("Freiman’s theorem in solvable groups")]#text(" (or the Helfgott-Lindenstrauss conjecture, discussed in the ")#link("https://terrytao.wordpress.com/2011/11/13/254a-notes-9-applications-of-the-structural-theory-of-approximate-groups/")[#text("previous quarter’s notes")]#text("), one can give even more precise descriptions of ")#mi("{A}")#text(" (at the cost of losing polynomial dependence of the bounds on ")#mi("{K}")#text("), but we will not discuss these topics here.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Use Exercise ")#link(<tao-de6da716412716d8f011>)[#text("19")]#text(" to give an alternate proof of Theorem ")#link(<tao-b74bd1156332ecb8999b>)[#text("5")]#text(". (")#emph[#text("Hint:")]#text(" there are a number of ways to embed the sum-product problem in a field ")#mi("{k}")#text(" into a product problem in ")#mi("{SL_2(k)}")#text(" (or ")#mi("{SL_2(\\overline{k})}")#text("). For instance, one consider the tripling properties of sets of the form ")#mi("{\\{ \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}: a,b,c,d \\in A \\}}")#text(" in terms of sets such as ")#mi("{A^2+A^2}")#text(" or ")#mi("{A^3+A^3+A^3+A^3}")#text(", and then project this set onto ")#mi("{SL_2(k)}")#text(" (or ")#mi("{PSL_2(k)}")#text("), and combine this with the Katz-Tao lemma to obtain Theorem ")#link(<tao-b74bd1156332ecb8999b>)[#text("5")]#text(". More details of this connection can be found in Section 8 of ")#link("http://arxiv.org/abs/1005.1881")[#text("this paper")]#text(".) This is of course a much more complicated and inefficient way to establish the sum-product theorem, but it does illustrate the link between the two results (beyond the fact that both proofs exploit a dichotomy). Note alsot that the original proof of the product theorem in ")#mi("{SL_2(F_p)}")#text(" by Helfgott actually used the sum-product theorem in ")#mi("{F_p}")#text(" as a key tool.")
]

#heading(level: 1)[#strong[#text(" — 4. The product theorem in ")#mi("{SL_d(k)}")#text(" — ")]]

#text("We now discuss the extension of the ")#mi("{SL_2(k)}")#text(" product theory to the more general groups ")#mi("{SL_d(k)}")#text(". Actually, the arguments here will be valid in any almost simple connected algebraic group of bounded rank, but for sake of concreteness we will work with ")#mi("{SL_d(k)}")#text(". (This also has the (very) minor advantage that ")#mi("{SL_d}")#text(" is an affine variety rather than a projective one, so we can work entirely in affine spaces such as ")#mi("{{\\bf A}^{d^2}(\\overline{k}) :=\\overline{k}^{d^2}}")#text("; related to this, the only regular maps we need to consider will be polynomial in nature.) There is also some recent work on product theorems in other algebraic groups than the almost simple ones; see for instance the papers of ")#link("http://arxiv.org/abs/1005.1858")[#text("Pyber-Szabo")]#text(", ")#link("http://arxiv.org/abs/1008.5264")[#text("Gill-Helfgott")]#text(", and ")#link("http://arxiv.org/abs/1005.1881")[#text("Breuillard-Green-Tao")]#text(" for some examples of this. It is conceivable that a satisfactory understanding of approximate subgroups of arbitrary algebraic groups of bounded dimension will be available in the near future.")

#text("The treatment of the ")#mi("{d=2}")#text(" case relied on a number of ")#emph[#text("ad hoc")]#text(" computations which were only valid in ")#mi("{SL_2}")#text(", and also on the pleasant fact that the only non-regular elements of ")#mi("{SL_2}")#text(" were the central elements ")#mi("{\\pm 1}")#text(", which is certainly false for higher values of ")#mi("{d}")#text(". In ")#link("http://www.ams.org/mathscinet-getitem?mr=2781932")[#text("this paper")]#text(", Helfgott was able to push his original ")#mi("{d=2}")#text(" arguments to the ")#mi("{d=3}")#text(" case, but again the arguments were somewhat ")#emph[#text("ad hoc")]#text(" in nature and did not seem to extend to the general setting. However, the arguments based on the Larsen-Pink concentration estimates have proven to be quite general, and in particular can handle the situation of ")#mi("{SL_d(k)}")#text(". The one catch is that instead of working with very concrete and explicit subsets of ")#mi("{SL_2}")#text(", such as Borel subgroups or other intersections ")#mi("{SL_2 \\cap V}")#text(" with linear spaces ")#mi("{V}")#text(", one has to work with more general algebraic subvarieties of ")#mi("{SL_d}")#text(". As such, a certain amount of basic algebraic geometry becomes necessary. Also, because we are seeking results with quantitative bounds, we will need to keep some track of the “complexity” of the varieties that one encounters in the course of the argument.")

#text("We now very quickly review some algebraic geometry notions, though for reasons of space we will not attempt to develop the full theory of algebraic geometry here, referring instead to standard texts such as ")#link("http://www.ams.org/mathscinet-getitem?mr=1416564")[#text("Harris")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1748380")[#text("Mumford")]#text(", or ")#link("http://www.ams.org/mathscinet-getitem?mr=1288523")[#text("Griffiths-Harris")]#text(". As usual, algebraic geometry is cleanest when working over an algebraically closed field, so we will work primarily over ")#mi("{\\overline{k}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 19 (Variety)")]#text(" Let ")#mi("{M \\geq d \\geq 0}")#text(" be integers, and let ")#mi("{\\overline{k}}")#text(" be an algebraically closed field. We write ")#mi("{{\\bf A}^d(\\overline{k})}")#text(" for the affine space ")#mi("{\\overline{k}^d}")#text(".")

#list(
[#text("An (affine) ")#link("http://en.wikipedia.org/wiki/Algebraic_variety")[#text("variety")]#text(" ")#mi("{V = V(\\overline{k}) \\subset {\\bf A}^d(\\overline{k})}")#text(" of complexity at most ")#mi("{M}")#text(" is a set of the form")

#align(center)[#tao-fit-display[#mitex("V = \\{ x \\in \\overline{k}^d: P_1(x) =\\ldots = P_m(x) = 0 \\},")]]

#text("where ")#mi("{0 \\leq m \\leq M}")#text(" and ")#mi("{P_1,\\ldots,P_m: {\\bf A}^d(\\overline{k}) \\rightarrow\\overline{k}}")#text(" are polynomials of degree at most ")#mi("{M}")#text(". (Thus the complexity parameter ")#mi("{M}")#text(" controls the dimension, degree, and number of polynomials needed to cut out the variety. Note that we do not assume our varieties to be irreducible, and as such what we call a variety corresponds to what is sometimes known as an ")#emph[#text("algebraic set")]#text(" in the literature.) Note that the union or intersection of two varieties of complexity at most ")#mi("{M}")#text(", is another variety of complexity at most ")#mi("{O_M(1)}")#text(".")],
[#text("A variety is ")#emph[#text("irreducible")]#text(" if it cannot be expressed as the union of two proper (i.e. strict) subvarieties.")]
)
]

#text("Thus, for instance, ")#mi("{SL_d(\\overline{k})}")#text(" is a variety of complexity ")#mi("{O_d(1)}")#text(" in ")#mi("{{\\bf A}^{d^2}(\\overline{k})}")#text(" (after identifying this latter affine space with the space of ")#mi("{d \\times d}")#text(" matrices over ")#mi("{\\overline{k}}")#text(").")

#text("It is known that any variety can be expressed as the union of a finite number of irreducible components, and this decomposition is unique if we require that no component is contained in any other. Furthermore, to each irreducible variety ")#mi("{V}")#text(" one can assign a ")#emph[#text("dimension")]#text(" ")#mi("{\\text{dim}(V)}")#text(", defined as the maximal integer ")#mi("{D}")#text(" for which there exists a chain")

#align(center)[#tao-fit-display[#mitex("\\emptyset \\neq V_0 \\subsetneq \\ldots \\subsetneq V_D = V")]]

#text("of irreducible varieties; this will be an integer between ")#mi("{0}")#text(" and ")#mi("{D}")#text(". For instance, it can be shown that ")#mi("{{\\bf A}^d(\\overline{k})}")#text(" has dimension ")#mi("{d}")#text(" (as expected). We define the dimension of a non-irreducible variety ")#mi("{V}")#text(" to be the least integer ")#mi("{D}")#text(" such that ")#mi("{V}")#text(" can be covered by finitely many irreducible varieties of dimension ")#mi("{D}")#text(". If a (non-empty) variety ")#mi("{V}")#text(" can be cut out from an irreducible variety ")#mi("{W}")#text(" by setting ")#mi("{m}")#text(" polynomials to zero, then one has ")#mi("{\\text{dim}(W) - m \\leq \\text{dim}(V) \\leq \\text{dim}(W)}")#text(". Since ")#mi("{SL_d(\\overline{k})}")#text(" can be cut out from ")#mi("{{\\bf A}^{d^2}(\\overline{k})}")#text(" by a single polynomial, and is not equal to all of ")#mi("{{\\bf A}^{d^2}(\\overline{k})}")#text(", we conclude in particular that ")#mi("{SL_d(\\overline{k})}")#text(" has dimension ")#mi("{d^2-1}")#text(".")

#text("One can show that the image of a ")#mi("{D}")#text("-dimensional variety by a polynomial map ")#mi("{P: {\\bf A}^{d_1}\\rightarrow {\\bf A}^{d_2}}")#text(" is contained in a variety of dimension at most ")#mi("{D}")#text(". One can thus produce upper bounds on the dimension of varieties, by covering them by polynomial images of varieties already known to be bounded by the same dimension.")

#text("An ")#emph[#text("algebraic subgroup")]#text(" of ")#mi("{SL_d(\\overline{k})}")#text(" is a subvariety of ")#mi("{SL_d(\\overline{k})}")#text(" which is also a subgroup of ")#mi("{SL_d(\\overline{k})}")#text(". For instance, the ")#emph[#text("standard maximal torus")]#text(" ")#mi("{T(\\overline{k})}")#text(", consisting of all the diagonal elements of ")#mi("{SL_d(\\overline{k})}")#text(", is an algebraic subgroup; more generally, any ")#emph[#text("maximal torus")]#text(", by which we mean a conjugate of the standard maximal torus, is an algebraic subgroup.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Show that every maximal torus has dimension ")#mi("{d-1}")#text(" and complexity ")#mi("{O_d(1)}")#text(".")
]

#text("Dual to the maximal tori are the conjugacy classes ")#mi("{Conj(g) := \\{ hgh^{-1}: h \\in SL_d(\\overline{k})\\}}")#text(" of regular semisimple elements. We call a element ")#mi("{g}")#text(" of ")#mi("{SL_d(\\overline{k})}")#text(" ")#emph[#text("regular semisimple")]#text(" if it has ")#mi("{d}")#text(" distinct eigenvalues, and is thus diagonalisable. Observe that each regular semisimple element lies in precisely one maximal torus.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Show that every conjugacy class of a regular semisimple element has dimension ")#mi("{d^2-d}")#text(" and complexity ")#mi("{O_d(1)}")#text(".")
]

#text("If ")#mi("{F}")#text(" is a finite subfield of ")#mi("{\\overline{k}}")#text(", then ")#mi("{SL_d(F)}")#text(" is a finite subgroup of ")#mi("{SL_d(\\overline{k})}")#text(", and is thus technically a ")#mi("{0}")#text("-dimensional algebraic subgroup of ")#mi("{SL_d(\\overline{k})}")#text(". However, the complexity of this algebraic group is huge (comparable to the cardinality of ")#mi("{SL_d(F)}")#text("). It turns out that ")#mi("{SL_d(F)}")#text(" is “effectively Zariski-dense” in the sense that it cannot be captured in a low complexity algebraic variety:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 20 (Schwartz-Zippel lemma for ")#mi("{SL_d(F)}")#text(")")]#text(" ")#metadata(none) <tao-289d18efedfb4f5268fd>#text(" Let ")#mi("{V}")#text(" be a proper subvariety of ")#mi("{SL_d(\\overline{k})}")#text(" of complexity at most ")#mi("{M}")#text(". Let ")#mi("{F}")#text(" be a finite subfield of ")#mi("{\\overline{k}}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\left|SL_d(F) \\cap V\\right| \\ll_{M,d} \\left|F\\right|^{d^2-2}.", block: true)]]
]

#emph[#text("Proof:")]#text(" ")#mi("{SL_d(\\overline{k})}")#text(" is the hypersurface in ")#mi("{{\\bf A}^{d^2}(\\overline{k})}")#text(" cut out by the determinant polynomial. As ")#mi("{V}")#text(" is a proper subvariety, we can find a polynomial ")#mi("{P: \\overline{k}^{d^2} \\rightarrow \\overline{k}}")#text(" which is not a multiple of the determinant polynomial, but which vanishes on ")#mi("{V}")#text("; by the complexity hypothesis we may take ")#mi("{P}")#text(" to have degree ")#mi("{O_{M,d}(1)}")#text(". Our task is then to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ x \\in SL_d(F): P(x)=0 \\}\\right| \\ll_{M,d} \\left|F\\right|^{d^2-2}.", block: true)]]

#text("Let us write the ")#mi("{d^2}")#text(" coordinates of ")#mi("{{\\bf A}^{d^2}(\\overline{k})}")#text(" arbitrarily as ")#mi("{x_1,\\ldots,x_{d^2}}")#text(". In a given element of ")#mi("{SL_d(F)}")#text(", not all of the ")#mi("{x_i}")#text(" can be zero; thus by symmetry and relabeling if necessary it suffices to show that ")#metadata(none) <tao-f563fcd3fb8578799b80>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left|\\{ x \\in SL_d(F): P(x)=0; x_{d^2} \\neq 0 \\}\\right| \\ll_{M,d} \\left|F\\right|^{d^2-2}.", block: true)]]



#text(" But then one can express ")#mi("{x_{d^2}}")#text(" as a rational function of the other ")#mi("{d^2-1}")#text(" coordinates, and the left-hand side of ")#link(<tao-f563fcd3fb8578799b80>)[#text("(7)")]#text(" is contained in a set of the form ")#mi("{\\{ x \\in F^{d^2-1}: Q(x)=0\\}}")#text(" for some polynomial ")#mi("{Q}")#text(" of degree ")#mi("{O_{M,d}(1)}")#text(" that is not identically zero. The claim then follows from the ")#link("http://en.wikipedia.org/wiki/Schwartz%E2%80%93Zippel_lemma")[#text("Schwartz-Zippel lemma")]#text(", which we give as an exercise below. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23 (Schwartz-Zippel lemma)")]#text(" Let ")#mi("{F}")#text(" be a finite field, and let ")#mi("{Q:F^d \\rightarrow F}")#text(" be a polynomial of degree ")#mi("{D}")#text(" that is not identically zero. Show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ x \\in F^d: Q(x) = 0 \\}\\right| \\ll_d D \\left|F\\right|^{d-1}.", block: true)]]

#text("For an additional challenge, obtain the sharper bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ x \\in F^d: Q(x) = 0 \\}\\right| \\leq D \\left|F\\right|^{d-1}.", block: true)]]
]

#text("We contrast this with the size of ")#mi("{SL_d(F)}")#text(" itself:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" ")#metadata(none) <tao-d6e40bfb18262554f2b8>#text(" Let ")#mi("{F}")#text(" be a finite field. Show that ")#tao-math("{\\left|F\\right|^{d^2-1} \\ll_d \\left|SL_d(F)\\right|\\ll_d \\left|F\\right|^{d^2-1}}", block: false)#text(".")
]

#text("The key non-concentration inequality we will need is the following.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 21 (Larsen-Pink inequality)")]#text(" ")#metadata(none) <tao-c8dce18756ad18d43189>#text(" Let ")#mi("{A}")#text(" be a ")#mi("{K}")#text("-approximate subgroup of ")#mi("{SL_d(\\overline{k})}")#text(" for some ")#mi("{K \\geq 2}")#text(", and let ")#mi("{V}")#text(" be a subvariety of ")#mi("{SL_d(\\overline{k})}")#text(" of complexity at most ")#mi("{M}")#text(". Let ")#mi("{m \\geq 1}")#text(". Then one of the following is true:")

#list(
[#text("(Non-concentration) One has ")#metadata(none) <tao-030c328ec6336d6b6a6d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left|A^m \\cap V\\right| \\ll_{M,d,m} K^{O_{M,d,m}(1)} \\left|A\\right|^{dim(V)/dim(SL_d)}.", block: true)]]],
[#text("(Trapping) ")#mi("{A}")#text(" is contained in a proper algebraic subgroup ")#mi("{H}")#text(" of ")#mi("{SL_d(\\overline{k})}")#text(" of complexity ")#mi("{O_{M,d,m}(1)}")#text(".")]
)
]

#text("This inequality subsumes results such as Proposition ")#link(<tao-302eaa73cba30e609ac4>)[#text("17")]#text(", Exercise ")#link(<tao-2c96ab740b97ba6e0aa4>)[#text("14")]#text(", and Exercise ")#link(<tao-2ceb1b60950a005d76d6>)[#text("16")]#text(". Note from Lemma ")#link(<tao-289d18efedfb4f5268fd>)[#text("20")]#text(" (and Exercise ")#link(<tao-d6e40bfb18262554f2b8>)[#text("24")]#text(") that the trapping option of the above proposition cannot occur if ")#mi("{A}")#text(" generates ")#mi("{SL_d(F)}")#text(" and ")#tao-math("{\\left|F\\right|}", block: false)#text(" is sufficiently large depending on ")#mi("{M, d, m}")#text(", while the non-concentration claim is trivial when ")#tao-math("{\\left|F\\right| = O_{M,d,m}(1)}", block: false)#text("; thus in this case we have ")#link(<tao-030c328ec6336d6b6a6d>)[#text("(9)")]#text(" unconditionally.")

#text("The proof of Proposition ")#link(<tao-c8dce18756ad18d43189>)[#text("21")]#text(" is somewhat complicated and is deferred to the next section. We record some particular consequences of this inequality.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25 (Consequences of the non-concentration inequality)")]#text(" Let ")#mi("{A}")#text(" be a ")#mi("{K}")#text("-approximate subgroup of ")#mi("{SL_d(\\overline{k})}")#text(" for some ")#mi("{K \\geq 2}")#text(", which generates ")#mi("{SL_d(F)}")#text(" for some finite field ")#mi("{F}")#text(".")

#list(
[#text("(i) If ")#mi("{T}")#text(" is a maximal torus (and thus of dimension ")#mi("{d-1}")#text("), show that ")#tao-math("{\\left|A^{10} \\cap T\\right| \\ll_d K^{O_d(1)} \\left|A\\right|^{\\frac{1}{d+1}}}", block: false)#text(".")],
[#text("(ii) If ")#mi("{T_0}")#text(" denotes the elements of ")#mi("{T}")#text(" which are not regular semisimple, show that ")#tao-math("{\\left|A^{10} \\cap T\\right| \\ll_d K^{O_d(1)} \\left|A\\right|^{\\frac{d-2}{d^2-1}}}", block: false)#text(".")],
[#text("(iii) If ")#mi("{g \\in SL_d(\\overline{k})}")#text(" is regular semisimple, show that ")#tao-math("{\\left|A^{10} \\cap Conj(g)\\right|\\ll_d K^{O_d(1)} \\left|A\\right|^{\\frac{d}{d+1}}}", block: false)#text(".")],
[#text("(iv) Show that at most ")#tao-math("{O_d(K^{O_d(1)} \\left|A\\right|^{\\frac{d^2-2}{d^2-1}})}", block: false)#text(" of the elements of ")#mi("{A}")#text(" are not regular semisimple.")],
[#text("(v) For any regular semisimple ")#mi("{g \\in A}")#text(", show that ")#tao-math("{\\left|A^3 \\cap Conj(g)\\right| \\gg_d K^{-O_d(1)} \\left|A\\right|^{\\frac{d}{d+1}}}", block: false)#text(".")],
[#text("(vi) For any regular semisimple ")#mi("{g \\in A}")#text(", show that ")#tao-math("{\\left|A^2 \\cap T\\right| \\gg_d K^{-O_d(1)} \\left|A\\right|^{\\frac{1}{d+1}}}", block: false)#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" By repeating the arguments of the preceding section, establish Theorem ")#link(<tao-317c6953d7b0cb5ea874>)[#text("1")]#text(" for general ")#mi("{d}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" There is an analogue of Exercise ")#link(<tao-de6da716412716d8f011>)[#text("19")]#text(", in which the role of the Borel subgroups is replaced by proper algebraic subgroups of bounded complexity; see Theorem 5.5 of ")#link("http://arxiv.org/abs/1005.1881")[#text("the paper of Breuillard, Green, and Tao")]#text(" for a more precise statement.")
]

#heading(level: 1)[#strong[#text(" — 5. Proof of the Larsen-Pink inequality (optional) — ")]]

#text("We now prove Proposition ")#link(<tao-c8dce18756ad18d43189>)[#text("21")]#text(". In order to escape the burden of having to keep track of the complexity of everything, we will use the tool of ")#link("http://en.wikipedia.org/wiki/Ultraproduct")[#text("ultraproducts")]#text(" (which we will phrase in the language of ")#link("http://en.wikipedia.org/wiki/Nonstandard_analysis")[#text("nonstandard analysis")]#text("). See ")#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/")[#text("this previous blog post")]#text(" for a discussion of ultraproducts and how they can be used to turn quantitative (or “hard”) analysis tasks into qualitative (or “soft”) analysis tasks. One can also use the machinery of schemes and inverse limits as a substitute for the ultraproduct formalism; this is the approach taken in the ")#link("http://www.ams.org/mathscinet-getitem?mr=2813339")[#text("paper of Larsen and Pink")]#text(". The ")#link("http://arxiv.org/abs/1005.1881")[#text("paper of Breuillard, Green, and Tao")]#text(" has a slightly reduced reliance on ultraproducts, at the cost of more complexity bookkeeping, while ")#link("http://arxiv.org/abs/1005.1858")[#text("the Pyber-Szabo paper")]#text(" avoids ultraproducts altogether but has perhaps the most bookkeeping of all the papers mentioned here (but, by the same token, is the only argument currently known which gives effective bounds). We will thus presume some familiarity both with ultraproducts (and nonstandard analysis) and with algebraic geometry in this section.")

#text("As in the ")#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/")[#text("previously mentioned blog post")]#text(", we select a non-principal ultrafilter ")#mi("{\\alpha \\in \\beta {\\bf N} \\backslash {\\bf N}}")#text(", and use it to construct ultraproducts and nonstandard objects. (To ensure the existence of such an object, we shall assume the ")#link("http://en.wikipedia.org/wiki/Axiom_of_choice")[#text("axiom of choice")]#text(", as we have already been doing implicitly throughout this course.) We also use the usual nonstandard asymptotic notation, thus for instance ")#mi("{O(1)}")#text(" denotes a nonstandard quantity bounded in magnitude by a standard number.")

#text("The quantitative Larsen-Pink inequality (Proposition ")#link(<tao-c8dce18756ad18d43189>)[#text("21")]#text(") can then be deduced from the following nonstandard version, in which all references to complexity are now absent:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 22 (Larsen-Pink inequality)")]#text(" ")#metadata(none) <tao-8528dd2421fa53bf780e>#text(" Let ")#mi("{d \\geq 2}")#text(" be standard. Let ")#mi("{\\overline{k} = \\prod_{n \\rightarrow\\alpha} \\overline{k_n}}")#text(" be a nonstandard algebraically complete field (i.e. an ultraproduct of standard algebraically complete fields). Let ")#mi("{K = \\lim_{n \\rightarrow\\alpha} K_n \\geq 2}")#text(" be a nonstandard natural number, and let ")#mi("{A}")#text(" be a nonstandard ")#mi("{K}")#text("-approximate subgroup of ")#mi("{SL_d(\\overline{k})}")#text(" (i.e. an ultraproduct ")#mi("{A = \\prod_{n \\rightarrow \\alpha} A_n}")#text(" of standard ")#mi("{K_n}")#text("-approximate subgroups of ")#mi("{SL_d(\\overline{k_n})}")#text("), and let ")#mi("{V}")#text(" be a subvariety of ")#mi("{SL_d(\\overline{k})}")#text(". Then one of the following is true:")

#list(
[#text("(Non-concentration) One has ")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left|A^m \\cap V\\right| \\ll K^{O(1)} \\left|A\\right|^{dim(V)/dim(SL_d)}", block: true)]]

#text("for all standard ")#mi("{m \\geq 1}")#text(", where ")#tao-math("{\\left|A\\right| := \\lim_{n \\rightarrow \\alpha} \\left|A_n\\right|}", block: false)#text(" is the nonstandard cardinality of ")#mi("{A}")#text(".")],
[#text("(Trapping) ")#mi("{A}")#text(" is contained in a proper algebraic subgroup ")#mi("{H}")#text(" of ")#mi("{SL_d(\\overline{k})}")#text(".")]
)
]

#text("Let us see why Proposition ")#link(<tao-8528dd2421fa53bf780e>)[#text("22")]#text(" implies Proposition ")#link(<tao-c8dce18756ad18d43189>)[#text("21")]#text(". Suppose for contradiction that Proposition ")#link(<tao-c8dce18756ad18d43189>)[#text("21")]#text(" failed. Carefully negating all the quantifiers (and using the axiom of choice), this means that there is a sequence ")#mi("{\\overline{k_n}}")#text(" of standard algebraically closed fields, a sequence ")#mi("{K_n \\ge 2}")#text(" of standard numbers, a sequence ")#mi("{A_n}")#text(" of ")#mi("{K_n}")#text("-approximate subgroups of ")#mi("{SL_d(\\overline{k_n})}")#text(", and a standard ")#mi("{M \\geq 1}")#text(", a sequence ")#mi("{V_n}")#text(" of subvarieties of ")#mi("{SL_d(\\overline{k_n})}")#text(" of complexity at most ")#mi("{M}")#text(", and a standard ")#mi("{m \\geq 1}")#text(", such that for each ")#mi("{n}")#text(", ")#mi("{A_n}")#text(" is not contained in a proper algebraicd subgroup of ")#mi("{SL_d(\\overline{k_n})}")#text(" of complexity ")#mi("{n}")#text(" or less, and one has")

#align(center)[#tao-fit-display[#tao-math("\\left|A_n^m \\cap V_n\\right| \\geq n K^n \\left|A\\right|^{dim(V_n)/dim(SL_d)}.", block: true)]]

#text("Now one forms the ultralimit ")#mi("{K :=\\lim_{n \\rightarrow\\alpha} K_n}")#text(" and the ultraproducts ")#mi("{\\overline{k} := \\prod_{n \\rightarrow \\alpha} \\overline{k_n}}")#text(", ")#mi("{A := \\prod_{n \\rightarrow \\alpha} A_n}")#text(", ")#mi("{V := \\prod_{n \\rightarrow \\alpha} V_n}")#text(". Then ")#mi("{\\overline{k}}")#text(" is an algebraically closed field, ")#mi("{A}")#text(" is a nonstandard ")#mi("{K}")#text("-approximate subgroup of ")#mi("{SL_d(\\overline{k})}")#text(", and ")#mi("{V}")#text(" is an algebraic subvariety of ")#mi("{SL_d(\\overline{k})}")#text(" (here we use the uniform complexity bound). One can also show that ")#mi("{\\text{dim}(V) = \\lim_{n \\rightarrow \\alpha}\\text{dim}(V_n)}")#text("; see Lemma 3 of ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("this blog post")]#text(". As such, we have")

#align(center)[#tao-fit-display[#tao-math("\\left|A^m \\cap V\\right| \\not \\ll K^{O(1)} \\left|A\\right|^{dim(V)/dim(SL_d)},", block: true)]]

#text("so by Proposition ")#link(<tao-8528dd2421fa53bf780e>)[#text("22")]#text(", ")#mi("{A}")#text(" is contained in a proper algebraic subgroup ")#mi("{H}")#text(" of ")#mi("{SL_d(\\overline{k})}")#text(". By unpacking the coefficients of all the polynomials over ")#mi("{\\overline{k}}")#text(" used to cut out ")#mi("{H}")#text(", we see that ")#mi("{H}")#text(" is itself an ultraproduct ")#mi("{H = \\prod_{n \\rightarrow \\alpha} H_n}")#text(" of proper algebraic subgroups of ")#mi("{SL_d(\\overline{k_n})}")#text(", of complexity bounded uniformly in ")#mi("{n}")#text(". By ")#link("http://en.wikipedia.org/wiki/Ultraproduct#.C5.81o.C5.9B.27s_theorem")[#text("Los’s theorem")]#text(", one has ")#mi("{A_n \\subset H_n}")#text(" for all ")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(", which gives a contradiction for ")#mi("{n}")#text(" large enough.")

#text("It remains to establish Proposition ")#link(<tao-8528dd2421fa53bf780e>)[#text("22")]#text(". By Los’s theorem, the ultraproduct ")#mi("{\\overline{k}}")#text(" of algebraically closed fields is again algebraically closed, which allows us to use algebraic geometry in the nonstandard field ")#mi("{\\overline{k}}")#text(" without difficulty.")

#text("Let ")#mi("{\\langle A\\rangle}")#text(" be the group generated by ")#mi("{A}")#text(", and consider the Zariski closure ")#mi("{\\overline{\\langle A \\rangle}}")#text(" of this group, that is to say the intersection of all the varieties containing ")#mi("{\\langle A \\rangle}")#text(". This is again an algebraic variety (here we use the Noetherian property of varieties, that there does not exist any infinite descending chain of varieties), and is also a group (exercise!), and is thus an algebraic subgroup of ")#mi("{SL_d(\\overline{k})}")#text(". If this subgroup is proper then we have the trapping propertly, so we may assume that the closure is all of ")#mi("{SL_d(\\overline{k})}")#text(". In other words, ")#mi("{\\langle A\\rangle}")#text(" is ")#emph[#text("Zariski dense")]#text(" in ")#mi("{SL_d(\\overline{k})}")#text(".")

#text("For any dimension ")#mi("{D}")#text(" between ")#mi("{0}")#text(" and ")#mi("{\\text{dim}(SL_d)}")#text(" inclusive, and any standard real ")#mi("{\\sigma}")#text(", let us call ")#mi("{\\sigma}")#text(" ")#emph[#mi("{D}")#text("-admissible")]#text(" if one has the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|A^m \\cap V\\right| \\ll K^{O(1)} \\left|A\\right|^{\\sigma}", block: true)]]

#text("whenever ")#mi("{m\\geq 1}")#text(" is standard and ")#mi("{V}")#text(" is a ")#mi("{D}")#text("-dimensional subvariety of ")#mi("{SL_d(\\overline{k})}")#text(". Our task is to show that ")#mi("{D/\\text{dim}(SL_d)}")#text(" is admissible for all ")#mi("{0 \\leq D \\leq \\text{dim}(SL_d)}")#text(". This claim is trivial at the two endpoints ")#mi("{D=0}")#text(" and ")#mi("{D=\\text{dim}(SL_d)}")#text("; the difficulty is to somehow “interpolate” between these two endpoints. We need the following combinatorial observation.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27 (Extreme dimensions)")]#text(" Suppose for sake of contradiction that ")#mi("{D/\\text{dim}(SL_d)}")#text(" is inadmissible for some ")#mi("{0 < D< \\text{dim}(SL_d)}")#text(". Show that we can find dimensions")

#align(center)[#tao-fit-display[#mitex("0 < D_1 \\leq D_2 < \\text{dim}(SL_d)")]]

#text("and a real number ")#mi("{\\theta \\geq 1/\\text{dim}(SL_d)}")#text(" such that")

#list(
[#mi("{D_1 \\theta}")#text(" is not ")#mi("{D_1}")#text("-admissible;")],
[#mi("{D_2 \\theta}")#text(" is not ")#mi("{D_2}")#text("-admissible;")],
[#mi("{D\\theta}")#text(" is ")#mi("{D}")#text("-admissible whenever ")#mi("{0 \\leq D < D_1}")#text(" or ")#mi("{D_2 < D \\leq \\text{dim}(SL_d)}")#text(";")],
[#mi("{(D+1)\\theta}")#text(" is ")#mi("{D}")#text("-admissible for any ")#mi("{0 \\leq D \\leq \\text{dim}(SL_d)}")#text(".")]
)
]

#text("Let ")#mi("{D_1,D_2,\\theta}")#text(" be as in the above exercise. By construction, we can then find subvarieties ")#mi("{V_1, V_2}")#text(" of ")#mi("{SL_d(\\overline{k})}")#text(" of dimension ")#mi("{D_1,D_2}")#text(" respectively and standard positive integers ")#mi("{m_1,m_2}")#text(" such that ")#metadata(none) <tao-fd7275bbea343cb9700f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left|A^{m_1} \\cap V_1\\right| \\not \\ll K^{O(1)} \\left|A\\right|^{\\theta D_1}", block: true)]]



#text(" and ")#metadata(none) <tao-42e37905bbac669726dd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left|A^{m_2} \\cap V_2\\right| \\not \\ll K^{O(1)} \\left|A\\right|^{\\theta D_2}.", block: true)]]



#text(" On the other hand, we have ")#metadata(none) <tao-be0ce8855f1debce5dd8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\left|A^{m} \\cap V\\right| \\ll K^{O(1)} \\left|A\\right|^{\\theta (\\text{dim}(V)+1)}", block: true)]]



#text(" whenever ")#mi("{V}")#text(" is a subvariety of ")#mi("{SL_d(\\overline{k})}")#text(", with the improvement ")#metadata(none) <tao-4dc22c6f087061cb3746>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left|A^{m} \\cap V\\right| \\ll K^{O(1)} \\left|A\\right|^{\\theta \\text{dim}(V)}", block: true)]]



#text(" whenever ")#mi("{V}")#text(" has dimension strictly less than ")#mi("{D_1}")#text(", or strictly greater than ")#mi("{D_2}")#text(".")

#text("We can use ")#link(<tao-be0ce8855f1debce5dd8>)[#text("(12)")]#text(", ")#link(<tao-4dc22c6f087061cb3746>)[#text("(13)")]#text(" to show that ")#mi("{A^{m_1} \\times A^{m_2}}")#text(" is “quantitatively Zariski dense” in ")#mi("{V_1 \\times V_2}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 23 (Quantitative Zariski density)")]#text(" ")#metadata(none) <tao-d017ca3d3ffedb39f3ff>#text(" For any proper subvariety ")#mi("{W}")#text(" of ")#mi("{V_1 \\times V_2}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|(A^{m_1} \\times A^{m_2}) \\cap W\\right|\\ll K^{O(1)} \\left|A\\right|^{\\theta (D_1+D_2)}.", block: true)]]
]

#emph[#text("Proof:")]#text(" ")#mi("{W}")#text(" has dimension at most ")#mi("{D_1+D_2-1}")#text(". By standard algebraic geometry, we see that for each ")#mi("{0\\leq D \\leq D_1}")#text(", the set of ")#mi("{y \\in V_2}")#text(" for which the slice ")#mi("{\\{ x \\in V_1: (x,y) \\in W\\}}")#text(" has dimension ")#mi("{D}")#text(", has dimension at most ")#mi("{D_1+D_2-D-1}")#text(". In particular, if ")#mi("{D < D_1}")#text(", then by ")#link(<tao-be0ce8855f1debce5dd8>)[#text("(12)")]#text(", ")#link(<tao-4dc22c6f087061cb3746>)[#text("(13)")]#text(" the contribution of such ")#mi("{x}")#text(" to ")#tao-math("{\\left|(A^{m_1} \\times A^{m_2}) \\cap W\\right|}", block: false)#text(" is at most")

#align(center)[#tao-fit-display[#tao-math("K^{O(1)} \\times \\left|A\\right|^{\\theta D} \\times K^{O(1)} \\left|A\\right|^{\\theta (D_1+D_2-D-1+1)}", block: true)]]

#text("while if ")#mi("{D = D_1}")#text(", then the contribution is at most")

#align(center)[#tao-fit-display[#tao-math("K^{O(1)} \\times \\left|A\\right|^{\\theta (D+1)} \\times K^{O(1)} \\left|A\\right|^{\\theta (D_1+D_2-D-1)}.", block: true)]]

#text("(One may wonder about the question of uniformity in the ")#mi("{O()}")#text(" notation, but in nonstandard analysis one can automatically gain such uniformity through countable saturation; see Exercise 20 of ")#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/")[#text("this blog post")]#text(".) Summing over all ")#mi("{D}")#text(" we obtain the claim. ")#mi("\\Box")

#text("We will now use a counting argument (which is, unsurprisingly, related to the counting argument used to establish Proposition ")#link(<tao-302eaa73cba30e609ac4>)[#text("17")]#text(", or any of the other Larsen-Pink inequalities in preceding sections) to obtain a contradiction from these four estimates.")

#text("First, by decomposing ")#mi("{V_1,V_2}")#text(" into irreducible components (and using ")#link(<tao-be0ce8855f1debce5dd8>)[#text("(12)")]#text(" to eliminate all lower-dimensional components) we may assume that ")#mi("{V_1,V_2}")#text(" are both irreducible.")

#text("The product ")#mi("{V_1 \\cdot V_2}")#text(" is not necessarily a variety, but it is still a constructible set (i.e. a finite boolean combination of varieties), and can still be assigned a dimension (by equating the dimension of a constructible set with the dimension of its Zariski closure). As it contains a translate of ")#mi("{V_2}")#text(", it has dimension at least ")#mi("{D_2}")#text(". It would be convenient if ")#mi("{V_1 \\cdot V_2}")#text(" had dimension strictly greater than ")#mi("{V_2}")#text(". This is not necessarily the case, but it turns out that it becomes so after a generic conjugation, thanks to the almost simplicity of ")#mi("{SL_d}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28 (Almost simplicity)")]#text(" Show that the only proper normal subgroups of ")#mi("{SL_d(\\overline{k})}")#text(" are those contained in the centre of ")#mi("{SL_d(\\overline{k})}")#text(", i.e. in the identity matrix multipled by the ")#mi("{d^{th}}")#text(" roots of unity. (")#emph[#text("Hint:")]#text(" Let ")#mi("{G}")#text(" be a normal subgroup of ")#mi("{SL_d(\\overline{k})}")#text(" that contains an element which is not a multiple of the identity. Place that element in Jordan normal form and divide it by one of its conjugates to make it fix a subspace of ")#mi("{\\overline{k}^d}")#text("; iterate this procedure until one finds an element in ")#mi("{G}")#text(" that is the direct sum of the identity in ")#mi("{SL_{d-2}(\\overline{k})}")#text(" and a non-central element of ")#mi("{SL_2(\\overline{k})}")#text(". Then use this to generate all of ")#mi("{SL_d(\\overline{k})}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 24 (Generic skewness)")]#text(" For generic ")#mi("{g \\in SL_d(\\overline{k})}")#text(" (i.e. for all ")#mi("{g}")#text(" in ")#mi("{SL_d(\\overline{k})}")#text(" outside of a lower-dimensional variety), the set ")#mi("{V_1 \\cdot g \\cdot V_2}")#text(" has dimension strictly greater than ")#mi("{D_2}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{g \\in SL_d(\\overline{k})}")#text(", and assume that ")#mi("{V_1 \\cdot g \\cdot V_2}")#text(" has dimension exactly ")#mi("{D_2}")#text(". This set contains all the translates ")#mi("{xg V_2}")#text(" with ")#mi("{x \\in V_1}")#text(", which are each ")#mi("{D_2}")#text("-dimensional irreducible varieties. By splitting up ")#mi("{V_1\\cdot g \\cdot V_2}")#text(" into components, we conclude that there are only finitely many distinct translates ")#mi("{xg V_2}")#text(". If we denote one of these translates as ")#mi("{W}")#text(", the set ")#mi("{\\{ x \\in SL_d(\\overline{k}): xgV_2 = W \\}}")#text(" is easily seen to be a variety (as it is the intersection of varieties ")#mi("{Wy^{-1}g^{-1}}")#text(" for ")#mi("{y \\in V_2}")#text("); as a finite number of these sets cover ")#mi("{V_1}")#text(", at least one of them has to be all of ")#mi("{V_1}")#text("; thus there is a ")#mi("{W}")#text(" such that ")#mi("{xgV_2=W}")#text(" for all ")#mi("{x \\in V_1}")#text(". In particular, this implies that ")#mi("{g^{-1} y^{-1} x g V_2 = V_2}")#text(" for all ")#mi("{x,y \\in V_1}")#text(".")

#text("Let ")#mi("{S := \\{ h \\in SL_d(\\overline{k}): hV_2 = V_2\\}}")#text(". Arguing as before, ")#mi("{S}")#text(" is a variety, and is also a group; it is thus an algebraic group, and by the preceding discussion we have ")#mi("{g^{-1} V_1^{-1} V_1 g \\subset S}")#text(".")

#text("The set ")#mi("{\\{ g \\in SL_d(\\overline{k}): g^{-1} V_1^{-1} V_1 g \\subset S \\}}")#text(" is a variety. If it has dimension strictly less than that of ")#mi("{SL_d}")#text(", we are done, so we may assume this set is all of ")#mi("{SL_d}")#text("; thus ")#mi("{g^{-1} V_1^{-1} V_1 g \\subset S}")#text(" for all ")#mi("{g \\in SL_d(\\overline{k})}")#text(". By almost simplicity, the normal subgroup generated by ")#mi("{V_1^{-1} V_1}")#text(" is all of ")#mi("{SL_d(\\overline{k})}")#text("; thus ")#mi("{S}")#text(" must be all of ")#mi("{SL_d(\\overline{k})}")#text(", thus ")#mi("{hV_2 = V_2}")#text(" for all ")#mi("{h \\in SL_d(\\overline{k})}")#text(". But this forces ")#mi("{V_2 = SL_d(\\overline{k})}")#text(", a contradiction since ")#mi("{D_2}")#text(" is strictly less than ")#mi("{\\text{dim}(SL_d)}")#text(". ")#mi("\\Box")

#text("Combining this proposition with the Zariski density of ")#mi("{\\langle A\\rangle}")#text(", we see that we can find ")#mi("{g \\in A^m}")#text(" for some standard ")#mi("{m}")#text(" such that ")#mi("{V_1 \\cdot g \\cdot V_2}")#text(" has dimension ")#mi("{D}")#text(" strictly greater than ")#mi("{D_2}")#text(".")

#text("Fix this ")#mi("{g}")#text(". Let ")#mi("{\\phi: V_1 \\times V_2 \\rightarrow \\overline{V_1 \\cdot g \\cdot V_2}}")#text(" be the twisted product map ")#mi("{\\phi(x,y) := xgy}")#text(". We have the double counting identity")

#align(center)[#tao-fit-display[#tao-math("\\sum_{z \\in A^{m_1+m+m_2} \\cap \\overline{V_1 \\cdot g \\cdot V_2}} \\left|A^{m_1}\\times A^{m_2} \\cap \\phi^{-1}(\\{z\\})\\right| = \\left|A^{m_1} \\cap V_1\\right| \\left|A^{m_2} \\cap V_2\\right|", block: true)]]

#text("and thus by ")#link(<tao-fd7275bbea343cb9700f>)[#text("(10)")]#text(", ")#link(<tao-42e37905bbac669726dd>)[#text("(11)")]

#align(center)[#tao-fit-display[#tao-math("\\sum_{z \\in A^{m_1+m+m_2} \\cap \\overline{V_1 \\cdot g \\cdot V_2}} |A^{m_1}\\times A^{m_2} \\cap \\phi^{-1}(\\{z\\})| \\not \\ll K^{O(1)} \\left|A\\right|^{\\theta(D_1+D_2)}.", block: true)]]

#text("Now, ")#mi("{\\phi}")#text(" is a map from an irreducible ")#mi("{D_1+D_2}")#text("-dimensional variety to a ")#mi("{D}")#text("-dimensional variety with Zariski-dense image, and is thus a ")#emph[#text("dominant map")]#text(". Among other things, this implies that there is a subvariety ")#mi("{S}")#text(" of ")#mi("{V_1 \\times V_2}")#text(" of dimension at most ")#mi("{D_1+D_2-1}")#text(" such that for all ")#mi("{x \\in \\overline{V_1 \\cdot g \\cdot V_2}}")#text(", the set ")#mi("{\\phi^{-1}(\\{x\\}) \\backslash S}")#text(" has dimension ")#mi("{D_1+D_2-D}")#text(". By ")#link(<tao-4dc22c6f087061cb3746>)[#text("(13)")]#text(", we then have")

#align(center)[#tao-fit-display[#tao-math("\\left|A^{m_1}\\times A^{m_2} \\cap \\phi^{-1}(\\{z\\}) \\backslash S\\right| \\ll K^{O(1)} \\left|A\\right|^{\\theta(D_1+D_2-D)}", block: true)]]

#text("for all ")#mi("{z \\in A^{m_1+m+m_2} \\cap \\overline{V_1 \\cdot g \\cdot V_2}}")#text("; by another application of ")#link(<tao-4dc22c6f087061cb3746>)[#text("(13)")]#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|A^{m_1+m+m_2} \\cap \\overline{V_1 \\cdot g \\cdot V_2}\\right| \\ll K^{O(1)} \\left|A\\right|^{\\theta D}.", block: true)]]

#text("Combining these estimates we see that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{z \\in A^{m_1+m+m_2} \\cap \\overline{V_1 \\cdot g \\cdot V_2}} |A^{m_1}\\times A^{m_2} \\cap \\phi^{-1}(\\{z\\}) \\cap S| \\not \\ll K^{O(1)} \\left|A\\right|^{\\theta(D_1+D_2)}.", block: true)]]

#text("The left-hand side simplifies to ")#tao-math("{\\left|A^{m_1} \\times A^{m_2} \\cap S\\right|}", block: false)#text(". But this then contradicts Lemma ")#link(<tao-d017ca3d3ffedb39f3ff>)[#text("23")]#text(".")

#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/#comment-126705")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("I am impressed!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/735100dd31344c03189dd3286bc294d681d2fd7556adac12a18fbcb944b68cc5-42cd81408e697baae438b1defa20f504fce658de69288b9e569a0d4558a153dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Misha Rudnev")]], [#link("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/#comment-126866")[#strong[#text("Misha Rudnev")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2012")])]

#text("Dear Terry: small corrections to Remark 1. Solymosi’s sum-products’ epsilon over C is 3/11 [MR2143727 (2006c:11021)]. I’ve recently made some minor improvements to that in arXiv:1111.4977v1. Sorry for being pernickety — this is obviously not the subject of the post, which I will now try to digest with great interest.")#linebreak()#text(" Best,")#linebreak()#text(" Misha")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 6: Non-concentration in subgroups « What’s new")]], [#link("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/#comment-128466")[#strong[#text("254B, Notes 6: Non-concentration in subgroups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2012")])]

#text("[…] the last three notes, we discussed the Bourgain-Gamburd expansion machine and two of its three ingredients, namely […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 7: Sieving and expanders « What’s new")]], [#link("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/#comment-131029")[#strong[#text("254B, Notes 7: Sieving and expanders « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2012")])]

#text("[…] see that is multiplicative for such . Finally, from the Schwarz-Zippel lemma (see Exercise 23 from Notes 5) we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43fbdc309a0f42392b47d1b5c7d3545d9e2ae68f92ec86e097a7ced6e87c7feb-f35b7d4c3dc87f7b77d5ec3ee32399552994ddf5bb258b5b43a9869026fe5d41.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wei Zhou")]], [#link("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/#comment-144047")[#strong[#text("Wei Zhou")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2012")])]

#text("Dear Prof. Tao,")#linebreak()#text(" There are some typo at the end of the paragraph before Exercise. It may be like the following: $g^{-1}A , hg^{-1}A$ are both contained in $H’$, and their joint is not empty, and then the joint of $A, ghg^{-1}A$ is not empty, which implies $ h \\in H$.")

#emph[#text("[Hopefully fixed now – it was a strange LaTeX rendering bug. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed443d8a11784c5982f0b00db9d6e57690f7cc863fb7396ea292b24f4fd574cd-b10cb900580c30ca3df78ffbb919dd4350ef5dfed17e13b62581b02831e2799a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/#comment-167715")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2012")])]

#text("Hi Terry –")

#text("For what it is worth, much or most of the material in section 2 first appeared in my paper on SL_2. This includes, for instance, Proposition 10 and a slightly weaker version of Proposition 13.")

#text("As you know, Larsen-Pink (which predated my work, at least in preprint form) did not make any statements about approximate subgroups or sets of small tripling; it also did not apply such results in this context. I am not , mind you, disputing the importance of their work. For one thing, it showed itself very useful in your generalization (with Breuillard and Green) of my work, in that it strongly suggested what the right strength and degree of generality of these statements should be (and gave alternative ideas to a proof, when seen from the optic of work on approximate groups). At the same time, note that Pyber-Szabo got essentially the same generalization as you did proceeding essentially from what I explained in SL_2 and SL_3.")#linebreak()#text(" Especially since you are explaining matters in the case of SL_2, referring and naming this kind of result only after Larsen-Pink looks odd.")

#text("Best")#linebreak()#text(" Harald")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/#comment-167724")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2012")])]

#text("Dear Harald,")

#text("Section 2 of this post is devoted exclusively to the setting of finite groups, and not more general approximate groups, and is thus covered directly by the results of the Larsen-Pink paper (in particular Proposition 10 and Proposition 13 are special cases of Theorem 4.2 and Theorem 6.2 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2813339")[#text("Larsen-Pink")]#text(" respectively). On the other hand, Hrushovski (see Section 5 of ")#link("http://arxiv.org/abs/0909.2190")[#text("his paper")]#text(") observed that the Larsen-Pink arguments carried over without essential difficulty to the setting of approximate groups (well, strictly speaking, he worked with ultraproducts of approximate groups rather than with individual approximate groups, but I view this as a primarily technical distinction).")

#text("But you’re certainly right that your papers (which predate Hrushovski’s) were the first to explicitly establish many of the key cases of the Larsen-Pink estimates for approximate groups in the SL_2 and SL_3 cases (though I believe that nobody was aware of the connection of your work with the earlier work of Larsen-Pink at that point). This was already mentioned briefly in the beginning of Section 3 (which, unlike Section 2, is devoted to approximate groups rather than to finite groups), but I will edit things a bit here to further clarify this point.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed443d8a11784c5982f0b00db9d6e57690f7cc863fb7396ea292b24f4fd574cd-b10cb900580c30ca3df78ffbb919dd4350ef5dfed17e13b62581b02831e2799a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/#comment-167733")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2012")])]

#text("Dear Terry,")

#text("Yes, I see – we would be talking about Proposition 17 and exercise 17-18 instead (for instance).")

#text("Just to be precise: as you know, in “Growth in SL_3”, the section dealing with this kind of estimates proves them not just for SL_3, but much more generally – sometimes for all groups of classical type (see, e.g., Corollary 5.4), sometimes for SL_n, but with proofs that work more generally (e.g., Corollary 5.16).")

#text("(What I had a bit of trouble making work in general was the pivoting argument – in retrospect, because one of the estimates was not quite strong enough.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/#comment-167747")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2012")])]

#text("The post has now been edited to reflect these statements.")

#text("Incidentally, on reading through Hrushovski’s paper again, I now see that the observation on the general applicability of the Larsen-Pink argument was first made in a ")#link("http://www.ams.org/mathscinet-getitem?mr=2436141")[#text("2008 paper of Hrushovski and Wagner")]#text(" (this is also mentioned in the “History” section of the Larsen-Pink paper). The situation there, being abstract and model-theoretic in nature, is far more general than the setting of either finite groups or approximate groups, but the specialisation to approximate groups was only made explicitly in the later paper of Hrushovski (and the key cases for the SL_2(F_p) problem are of course in ")#link("http://www.ams.org/mathscinet-getitem?mr=2415382")[#text("your own 2008 paper")]#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Expansion in finite simple groups of Lie type | What's new")]], [#link("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/#comment-244504")[#strong[#text("Expansion in finite simple groups of Lie type | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2013")])]

#text("[…] out to be an elementary combinatorial one, based on the “pivot” argument discussed in these lecture notes of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9dfd506431bdc82b623f4c4c75df1ca02cac8ffe0b080cdb73b83c6058bb838a-b436cbfacd459fdce34b9ba635d8f458b91eb525ecb76f956d24b02556b5db00.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew Tointon")]], [#link("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/#comment-506234")[#strong[#text("Matthew Tointon")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2018")])]

#text("Dear Terry,")#linebreak()#text(" I think it might be more natural to call Exercise 1 a diameter bound rather than a girth bound.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8bf5f0c70af1dbe68292e79edaca19680a66dab85ac63905790e0b67001275ac-cfbbb1c7f09f9b4414091b10ef8d99624cd65a712b49028f6912fb4ca8d42b0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Constantin Kogler")]], [#link("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/#comment-633359")[#strong[#text("Constantin Kogler")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2021")])]

#text("I think there is a typo in the penultimate line of the proof of Theorem 2.")#linebreak()#text(" As you write for ")#mi("h \\in H^{\\prime}")#text(" it holds that ")#mi("A")#text(" and ")#mi("Ah^{\\prime}")#text(" have a non-empty intersection. Yet this implies ")#mi("H^{\\prime} \\subset A^{-1}A")#text(" (and not ")#mi("\\subset AA^{-1}")#text(")")

#text("Furthermore we can show that ")#tao-math("\\left|AA^{-1}\\right| = \\left|A^{-1}A\\right|", block: false)#text(" and ")#mi("H^{\\prime} = A^{-1}A")#text(": As ")#tao-math("\\left|AA^{-1}\\right| = \\left|H\\right| = \\left|H^{\\prime}\\right|", block: false)#text(", using the assumption we conclude ")#tao-math("\\left|AA^{-1}\\right| \\leq \\left|A^{-1}A\\right| <  \\frac{3}{2}\\left|A\\right|", block: false)#text(". Repeating the same argument with ")#mi("A^{-1}")#text(" instead of ")#mi("A")#text(", it follows that ")#tao-math("\\left|AA^{-1}\\right| = \\left|A^{-1}A\\right|", block: false)#text(" and ")#mi("H^{\\prime} = A^{-1}A")#text(".")

#text("I was not able to show that ")#mi("A^{-1}A = AA^{-1}")#text(". Do you think this holds in general?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/#comment-633486")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2021")])]

#text("Thanks for pointing out the typo, which is now corrected. The argument shows that ")#mi("H^{\\prime} = A^{-1} A")#text(" and ")#mi("H = A A^{-1}")#text(" are conjugate groups, but they are not equal in general (consider for instance the case when ")#mi("A = Hg = gH^{\\prime}")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/#comment-684739")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2024")])]

#text("In theorem 2, why is $A subseteq H’$ and not $A subseteq gH’$?")

#emph[#text("[Sorry, I do not understand this question; the assertion ")#mi("A \\subseteq H^{\\prime}")#text(" is not made anywhere in the proof. -T]")]
]
