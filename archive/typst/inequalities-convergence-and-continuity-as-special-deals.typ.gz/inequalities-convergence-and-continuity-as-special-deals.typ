// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/
// Converted to Typst by tao2typ: "2026-10-14T11:10:14.269726+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Inequalities, convergence, and continuity as “special deals”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Inequalities, convergence, and continuity as “special deals”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 June 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/")[#text("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

#text("The “epsilon-delta” nature of analysis can be daunting and unintuitive to students, as the heavy reliance on inequalities rather than equalities. But it occurred to me recently that one might be able to leverage the intuition one already has from “deals” – of the type one often sees advertised by corporations – to get at least some informal understanding of these concepts.")

#text("Take for instance the concept of an upper bound ")#mi("{X \\leq A}")#text(" or a lower bound ")#mi("{X \\geq B}")#text(" on some quantity ")#mi("{X}")#text(". From an economic perspective, one could think of the upper bound as an assertion that ")#mi("{X}")#text(" can be “bought” for ")#mi("{A}")#text(" units of currency, and the lower bound can similarly be viewed as an assertion that ")#mi("{X}")#text(" can be “sold” for ")#mi("{B}")#text(" units of currency. Thus for instance, a system of inequalities and equations like")

#tao-aligned(keep: true)[


#tao-math("2  & \\leq Y \\leq 5", block: true)



#tao-math("X+Y  & \\leq 7", block: true)



#tao-math("X+Y+Z  & = 10", block: true)



#tao-math("Y+Z  & \\leq 6", block: true)
]

#text("could be viewed as analogous to a currency rate exchange board, of the type one sees for instance in airports:")

#table(columns: 3, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Currency")],
table.cell(colspan: 1, rowspan: 1)[#text("We buy at")],
table.cell(colspan: 1, rowspan: 1)[#text("We sell at")],
table.cell(colspan: 1, rowspan: 1)[#mi("{Y}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{5}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{X+Y}")],
table.cell(colspan: 1, rowspan: 1)[#text("–")],
table.cell(colspan: 1, rowspan: 1)[#mi("{7}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{X+Y+Z}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{10}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{10}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{Y+Z}")],
table.cell(colspan: 1, rowspan: 1)[#text("–")],
table.cell(colspan: 1, rowspan: 1)[#mi("{6}")]
)

#text("Someone with an eye for spotting “deals” might now realize that one can actually buy ")#mi("{Y}")#text(" for ")#mi("{3}")#text(" units of currency rather than ")#mi("{5}")#text(", by purchasing one copy each of ")#mi("{X+Y}")#text(" and ")#mi("{Y+Z}")#text(" for ")#mi("{7+6=13}")#text(" units of currency, then selling off ")#mi("{X+Y+Z}")#text(" to recover ")#mi("{10}")#text(" units of currency back. In more traditional mathematical language, one can improve the upper bound ")#mi("{Y \\leq 5}")#text(" to ")#mi("{Y \\leq 3}")#text(" by taking the appropriate linear combination of the inequalities ")#mi("{X+Y \\leq 7}")#text(", ")#mi("{Y+Z \\leq 6}")#text(", and ")#mi("{X+Y+Z=10}")#text(". More generally, this way of thinking is useful when faced with a ")#link("https://en.wikipedia.org/wiki/Linear_programming")[#text("linear programming")]#text(" situation (and of course linear programming is a key foundation for ")#link("https://en.wikipedia.org/wiki/Operations_research")[#text("operations research")]#text("), although this analogy begins to break down when one wants to use inequalities in a more non-linear fashion.")

#text("Asymptotic estimates such as ")#mi("{X = O(Y)}")#text(" (also often written ")#mi("{X \\lesssim Y}")#text(" or ")#mi("{X \\ll Y}")#text(") can be viewed as some sort of liquid market in which ")#mi("{Y}")#text(" can be used to purchase ")#mi("{X}")#text(", though depending on market rates, one may need a large number of units of ")#mi("{Y}")#text(" in order to buy a single unit of ")#mi("{X}")#text(". An asymptotic estimate like ")#mi("{X=o(Y)}")#text(" represents an economic situation in which ")#mi("{Y}")#text(" is so much more highly desired than ")#mi("{X}")#text(" that, if one is a patient enough haggler, one can eventually convince someone to give up a unit of ")#mi("{X}")#text(" for even just a tiny amount of ")#mi("{Y}")#text(".")

#text("When it comes to the basic analysis concepts of convergence and continuity, one can similarly view these concepts as various economic transactions involving the buying and selling of ")#emph[#text("accuracy")]#text(". One could for instance imagine the following hypothetical range of products in which one would need to spend more money to obtain higher accuracy to measure weight in grams:")

#table(columns: 3, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Object")],
table.cell(colspan: 1, rowspan: 1)[#text("Accuracy")],
table.cell(colspan: 1, rowspan: 1)[#text("Price")],
table.cell(colspan: 1, rowspan: 1)[#text("Low-end kitchen scale")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\pm 1}")#text(" gram")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\$ 5}")],
table.cell(colspan: 1, rowspan: 1)[#text("High-end bathroom scale")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\pm 0.1}")#text(" grams")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\$ 15}")],
table.cell(colspan: 1, rowspan: 1)[#text("Low-end lab scale")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\pm 0.01}")#text(" grams")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\$ 50}")],
table.cell(colspan: 1, rowspan: 1)[#text("High-end lab scale")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\pm 0.001}")#text(" grams")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\$ 250}")]
)

#text("The concept of convergence ")#mi("{x_n \\rightarrow x}")#text(" of a sequence ")#mi("{x_1,x_2,x_3,\\dots}")#text(" to a limit ")#mi("{x}")#text(" could then be viewed as somewhat analogous to a rewards program, of the type offered for instance by airlines, in which various tiers of perks are offered when one hits a certain level of “currency” (e.g., frequent flyer miles). For instance, the convergence of the sequence ")#mi("{x_n := 2 + \\frac{1}{\\sqrt{n}}}")#text(" to its limit ")#mi("{x := 2}")#text(" offers the following accuracy “perks” depending on one’s level ")#mi("{n}")#text(" in the sequence:")

#table(columns: 3, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Status")],
table.cell(colspan: 1, rowspan: 1)[#text("Accuracy benefit")],
table.cell(colspan: 1, rowspan: 1)[#text("Eligibility")],
table.cell(colspan: 1, rowspan: 1)[#text("Basic status")],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|x_n - x\\right| \\leq 1}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#mi("{n \\geq 1}")],
table.cell(colspan: 1, rowspan: 1)[#text("Bronze status")],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|x_n - x\\right| \\leq 0.1}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#mi("{n \\geq 10^2}")],
table.cell(colspan: 1, rowspan: 1)[#text("Silver status")],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|x_n - x\\right| \\leq 0.01}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#mi("{n \\geq 10^4}")],
table.cell(colspan: 1, rowspan: 1)[#text("Gold status")],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|x_n - x\\right| \\leq 0.001}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#mi("{n \\geq 10^6}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\dots}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\dots}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\dots}")]
)

#text("With this conceptual model, convergence means that any status level of accuracy can be unlocked if one’s number ")#mi("{n}")#text(" of “points earned” is high enough.")

#text("In a similar vein, continuity becomes analogous to a conversion program, in which accuracy benefits from one company can be traded in for new accuracy benefits in another company. For instance, the continuity of the function ")#mi("{f(x) = 2 + \\sqrt{x}}")#text(" at the point ")#mi("{x_0=0}")#text(" can be viewed in terms of the following conversion chart:")

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Accuracy benefit of ")#mi("{x}")#text(" to trade in")],
table.cell(colspan: 1, rowspan: 1)[#text("Accuracy benefit of ")#mi("{f(x)}")#text(" obtained")],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|x - x_0\\right| \\leq 1}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|f(x) - f(x_0)\\right| \\leq 1}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|x - x_0\\right| \\leq 0.01}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|f(x) - f(x_0)\\right| \\leq 0.1}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|x - x_0\\right| \\leq 0.0001}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|f(x) - f(x_0)\\right| \\leq 0.01}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\dots}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\dots}")]
)

#text("Again, the point is that one can purchase any desired level of accuracy of ")#mi("{f(x)}")#text(" provided one trades in a suitably high level of accuracy of ")#mi("{x}")#text(".")

#text("At present, the above conversion chart is only available at the single location ")#mi("{x_0}")#text(". The concept of ")#link("https://en.wikipedia.org/wiki/Uniform_continuity")[#text("uniform continuity")]#text(" can then be viewed as an advertising copy that “offer prices are valid in all store locations”. In a similar vein, the concept of ")#link("https://en.wikipedia.org/wiki/Equicontinuity")[#text("equicontinuity")]#text(" for a class ")#mi("{{\\mathcal F}}")#text(" of functions is a guarantee that “offer applies to all functions ")#mi("{f}")#text(" in the class ")#mi("{{\\mathcal F}}")#text(", without any price discrimination. The combined notion of ")#emph[#text("uniform equicontinuity")]#text(" is then of course the claim that the offer is valid in all locations and for all functions.")

#text("In a similar vein, differentiability can be viewed as a deal in which one can trade in accuracy of the input for approximately linear behavior of the output; to oversimplify slightly, smoothness can similarly be viewed as a deal in which one trades in accuracy of the input for high-accuracy polynomial approximability of the output. Measurability of a set or function can be viewed as a deal in which one trades in a level of resolution for an accurate approximation of that set or function at the given resolution. And so forth.")

#text("Perhaps readers can propose some other examples of mathematical concepts being re-interpreted as some sort of economic transaction?")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (37)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678449")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2023")])]

#text("The simplest example is that implication ")#mi("A\\Rightarrow B")#text(" is an allowance to exchange somebody’s ")#mi("A")#text(" for ")#mi("B")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ac2e645812fcbc6d35b6275adfcb65427bc93d156abddf4e8b86887115ad488-054d00a6c3439ba946e1ebc2d02f598b0a2b087958bbaa247b9c613f8093acd6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of b_epstein")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678451")[#strong[#text("b_epstein")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2023")])]

#text("Is that true? A => B, A => C. Exchange A for B and lose something.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678452")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2023")])]

#text("@b_epstein When writing this, I had in mind that we have an unlimited supply of copies of A.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678456")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2023")])]

#text("It seems that all the above examples can be formulated in terms of semi-algebraic geometry. Integration is not a semi-algebraic operation, So it would be interesting to find also similar examples which involve integration.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678462")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2023")])]

#text("I find “economic intuition” and “economic transaction” hard to understand and inequalities per se are much easier to understand, because I have never had a chance to take an Economics 101. So one can read this article the other way around: one can use the formal math, particularly, inequalities, to gain a better understanding of concepts in economics?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0b12ee9eb4d6ee06585f8f500c2bd7e9752de9448ea14e4139ad2f043eb6c8c-4371435d321d49e1c2b162e3b0dd6b44bbea368f5bc8984ebec4bc1a7123efea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mathur Maynard Amadi")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678464")[#strong[#text("Mathur Maynard Amadi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2023")])]

#text("Quantities are the distributive factors of classified integers; thus, an inevitability must depend on the definitions of their Mathematical entries.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678469")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2023")])]

#text("I am a big fan of these types of posts, of making math more accessible! Thank you!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5d712ad6f5a78a749b10dcdbda5168b68f6d5ff12e664d7855e70552b1c0a71-59b6006e9bb2847d088bda33144700abbac588df66fab6affdfe638646317ddf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Shamov")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678470")[#strong[#text("Alexander Shamov")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2023")])]

#text("I don’t have anything to say about the pedagogical merits of this, but this looks related to game semantics. It could very well be the case that under a game interpretation of type theory a proof of an inequality is literally a strategy in some complicated game with some of its moves resembling currency exchanges.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678477")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2023")])]

#text("I just remembered an ")#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/comment-page-1/#comment-32776")[#text("ancient comment on my blog")]#text(" (from my old friend Allen Knutson) that currency exchange can be viewed as a connection on a line bundle over the space of international currencies. Thus for instance the bundle would contain a line ")#mi("\\{ x\\text{\\ USD}: x \\in {\\bf R} \\}")#text(" over the US dollar, another line ")#mi("\\{ x \\text{\\ EUR}: x \\in {\\bf R} \\}")#text(" over the Euro, and so forth. If one currency is convertible to another, the conversion rate gives the connection over the path from the former currency to the latter. As a first approximation (ignoring commissions and other friction costs), this connection is linear. If one performs a loop of currency exchanges, one does not necessarily return to one’s initial amount of currency due to market inefficiencies; so this connection has curvature! But one can arbitrage away this curvature by appropriate trades (including “short” sales if the sign of the curvature is unfavorable), so in an efficient market the connection should be effectively flat.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a05e6c5e4acb764268b434a632ccdc8b44e72d8f338d53f361649e8b3ec18887-b57040a7240be33157ec9c18f23d70126afa6c644b4ad1caae2962a91a7cb8c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of awkward person")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678479")[#strong[#text("awkward person")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2023")])]

#text("Interesting….. Why didn’t he write a paper on this? He could have created a new topic. Also happy to see the ‘pres(s)i(ng)dent’ has given you some time to do your math homework!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678480")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2023")])]

#text("An interesting cosmological interpretation of such conversion rate is usually used to model the (large scale) expansion of the universe by a (cosmic) scale factor ")#mi("a(t)")#text(" (which induce curvature and contains information on several cosmological parameters), see")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/Scale_factor_(cosmology)")[#text("https://en.wikipedia.org/wiki/Scale_factor_(cosmology)")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leonid V")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678491")[#strong[#text("Leonid V")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2023")])]

#text("Great analogy! Just in case someone looks for an elementary level reference, I recommend checking “Physics from Finance – A gentle introduction to gauge theories, fundamental interactions and fiber bundles” by Jakob Schwichtenberg.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678577")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2023")])]

#text("For posterity, the comment of Knutson that you reference has a now-defunct link to Kirill Ilinski’s thought-provoking 1997 paper “Physics of Finance”. It can be accessed from ")#link("https://arxiv.org/abs/hep-th/9710148")[#text("https://arxiv.org/abs/hep-th/9710148")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-682266")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2023")])]

#text("Juan Maldacena has a paper on this analogy (aimed at the general public): ")#link("https://arxiv.org/abs/1410.6753")[#text("https://arxiv.org/abs/1410.6753")]

#text("In a footnote: “The analogy between foreign exchange and lattice gauge theory was noted in K. Young, “Foreign")#linebreak()#text(" exchange market as a lattice gauge theory”, American Journal of Physics 67, 862 (1999). Here we will")#linebreak()#text(" extend that discussion, with the physics goal in mind. See also K. Illinski, ")#link("http://arxiv.org/abs/hep-")[#text("http://arxiv.org/abs/hep-")]#linebreak()#text(" th/9705086 and P. Malaney, Harvard Ph.D. thesis.”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa78f1721eb24b4c8c9207612c4900ace136e8f826348889aa402da861c4def9-7a8fb38d3bdf6c72b856555be4d9ddcf13dd51dd74a340234bfb0c3c7959a2fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Natananel")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678502")[#strong[#text("Natananel")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2023")])]

#text("Probability may also be interpreted in terms of prices of contingent contracts. In this case, one can show that a simple desideratum (people don’t want to loose money for sure) leads to the basic rules of probability calculus (excep. for sigma-additivity).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ef416d4d65005c8c948ba1d552bca5b19817468eb0dee8254d21e31a58194c6-223b876ebec382062e2d73b2f69e1cb83720cbf9b4506b21b5e50432ab15b78f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678503")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2023")])]

#text("I suppose, in this analogy, “small” losses like ")#mi("\\log R")#text(" or ")#mi("C_\\varepsilon R^\\varepsilon")#text(" could be viewed as a sort of “sales tax;” one can safely disregard them for rough budgeting, but any scheme which involves a lengthy sequence of trades needs to involve a more careful accounting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1cd1a8973230d426ec3ab3dcdaee82c8bebac86b13f347181024ee3e59490b7e-717f5d87c986865d056d26331680d8d4d2b4ba2d6c0cc51fc86aea738c273f14.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wednesday assorted links - Marginal REVOLUTION")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678512")[#strong[#text("Wednesday assorted links - Marginal REVOLUTION")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2023")])]

#text("[…] 4. Terence Tao on convergence and “spotting deals.” […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678513")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2023")])]

#text("One colorful example of mathematical concept being formulated in economic language is the characterization of amenable groups as precisely those groups for which there doesn’t exist a profitable/sustainable Ponzi scheme on its Cayley graph.")

#text("See, for example, page 21 of ")#link("https://arxiv.org/pdf/1210.3671.pdf")[#text("https://arxiv.org/pdf/1210.3671.pdf")]#text(" for a more formal definition of what this means.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678514")[#strong[#text("Wednesday assorted links | Factuel News | News that is Facts")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2023")]

#text("[…] 4. Terence Tao on convergence and “spotting deals.” […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678515")[#strong[#text("Wednesday assorted links – IMT Fair")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2023")]

#text("[…] 4. Terence Tao on convergence and “spotting deals.” […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678516")[#strong[#text("Wednesday assorted links – Life Style Box")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2023")]

#text("[…] 4. Terence Tao on convergence and “spotting deals.” […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/059358c7113101f7531c773ba27f68e7777414327e77aecfd7eade7525eaf858-490f378e6bf9e9c9f3f4f03f9d1593000da31c77dcc0d2133beaf449c64d1215.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jack morava")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678517")[#strong[#text("jack morava")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2023")])]

#text("Conway’s `On Numbers and Games’ (Ch I) has a beautiful interpretation of numbers (which are totally ordered) as a special class of games (which are not).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/059358c7113101f7531c773ba27f68e7777414327e77aecfd7eade7525eaf858-490f378e6bf9e9c9f3f4f03f9d1593000da31c77dcc0d2133beaf449c64d1215.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jack morava")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678594")[#strong[#text("jack morava")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2023")])]

#text("Maybe I should say that in Conway’s system, the value of a game (in von Neumann & Morgenstern’s sense when it applies, \\eg classical 2-person zero-sum games) is the number it defines in that case. His numbers are equivalence classes of Dedekind cuts defined by dominating positions among strategies.")

#text("I think we should be told. ( : + { ) }")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678527")[#strong[#text("\"不等式、收敛与连续性作为“特别优惠”\" - 偏执的码农")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2023")]

#text("[…] 详情参考 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4aba73246595af8ea0554c834a7ac4fbe0ee0ec25feb6b98b53f26f490ce923-6687e092c7bc015e84b352f3951935ed5d5507b3e9b45ffa3dfbc4ca9cd38f27.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gabe Khan")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678533")[#strong[#text("Gabe Khan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2023")])]

#text("It is possible to consider the Sobolev embedding theorems for being an exchange in which one can trade in weak differentiability for some additional integrability. Similarly, Morrey’s inequality gives a way to trade sufficient weak differentiability for some classical derivatives. In general, this process is irreversible and there is almost a second law of thermodynamics preventing trades in the other direction. However, one way to interpret Schauder theory and elliptic regularity is that the equation gives a mechanism to make deals going in the opposite direction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20776b0bbb93616ecc6e30231f2aefc63a08a61c9ad1202c1b6fd00e9196efe7-8625adbc421ffc849147661898f7924f245a3c394d6e2198ef59b7b586d995f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Kontorovich")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678553")[#strong[#text("Alex Kontorovich")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2023")])]

#text("I like this! I often say it in terms of engineering rather than economics, but basically the same thing… ")#link("https://twitter.com/AlexKontorovich/status/1648790922497523712?s=20")[#text("https://twitter.com/AlexKontorovich/status/1648790922497523712?s=20")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0b12ee9eb4d6ee06585f8f500c2bd7e9752de9448ea14e4139ad2f043eb6c8c-4371435d321d49e1c2b162e3b0dd6b44bbea368f5bc8984ebec4bc1a7123efea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mathur Maynard Amadi")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678554")[#strong[#text("Mathur Maynard Amadi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2023")])]

#text("The dissertation of any truth depends on the cosmic distance of ones knowledge.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa64c9c253f65a7d9cc17341c4b22ebef482e1440374dcc9f37da48992a6c01-adae0e3099b1eca8bd0752161d24380b97aab9790b1fa32b2687d7d9e5d3dd74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Asimov")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678560")[#strong[#text("Dan Asimov")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2023")])]

#text("In my opinion, it is very important to teach the epsilon-delta definition of limit as one of the early pinnacles of modern mathematics. And as calculus students are constantly dealing with limits, they really should know how a limit is defined. I am strongly opposed to a recent tendency to omit this chapter in calculus courses.")

#text("But I think that trying to teach limits by teaching something else (like “deals”) will be mainly distracting and not helpful.")

#text("Rather, I would carefully and slowly go over the meaning of each of the four clauses of Cauchy’s definition of limit before stitching them together for the full definition, with plenty of examples and exercises at each stage.")

#text("(A small thing that I believe helps is to use only *one* of < and >, or of ≥ and ≤, if at al possible during a single discussion. And I would not expect students to prove a limit exists in a case where the inequalities get tricky.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678562")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2023")])]

#text("I thought the confusing aspects of limits and continuity to beginning calculus students was the workings of nested quantifiers (forall epsilon, there exists delta…) which at that time are new to them, at least as mathematical formalism. Also, continuity vs uniform continuity amounts to changing the order of quantifiers. Maybe some of that can be handled by comparisons to everyday experience: “you can fool all of the people some of the time (forall p:person, exists t:time, canfool(person p at time t), and some of the people all of the time (exists p, forall t, canfool(p,t)), but not all of the people all of the time (¬ (forall p, forall t, canfool(…)).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678563")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2023")])]

#text("And I would add the “uniform” version of the first part of that saying: there might be a specific instant during which you can fool everyone simultaneously: exists t, forall p, canfool(p,t). In the US, this usually happens when whoever is president decides to start a war, and goes on tv to get support for it ;).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/15d0e16496de322c7505bd61aa49ab57d53933c345d2ff8157c6dd85bb126464-787e72d05167f3478c8320ca742621f94f34edda6e69104fb891299d76c74d8c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678596")[#strong[#text("Tim")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2023")])]

#text("When you say: “From an economic perspective, one could think of the upper bound as an assertion that {X} can be “bought” for {A} units of currency, and the lower bound can similarly be viewed as an assertion that {X} can be “sold” for {B} units of currency” is this from the perspective of another buyer/seller as later you say that Currency We buy at We sell at")#linebreak()#text(" {Y} {2} {5}. Should it be the other way around or am I mistaken about something?")

#emph[#text("[Currency exchangers usually display their buy/sell prices from their perspective rather than the customer. If you wish, you can replace “We buy at” and “We sell at” to “You sell at” and “You buy at”, if this is clearer for you. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/15d0e16496de322c7505bd61aa49ab57d53933c345d2ff8157c6dd85bb126464-787e72d05167f3478c8320ca742621f94f34edda6e69104fb891299d76c74d8c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678664")[#strong[#text("Tim")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2023")])]

#text("Thanks that is helpful.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0b12ee9eb4d6ee06585f8f500c2bd7e9752de9448ea14e4139ad2f043eb6c8c-4371435d321d49e1c2b162e3b0dd6b44bbea368f5bc8984ebec4bc1a7123efea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mathur Maynard Amadi")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678602")[#strong[#text("Mathur Maynard Amadi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2023")])]

#text("Time is the difference between light and darkness but work is the distance between them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arman")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-678652")[#strong[#text("Arman")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2023")])]

#text("PROF wounderful post thanks please more MATH like THIS😊")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b2317767e02bc6d685bd0eea89774698b17033f31d098a360818f0d6531dadb-007acbf03d4a5295bc70e2db2adc9c24d83459fa933e62c8cd7d00bfbf86b726.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spearman")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-679445")[#strong[#text("Spearman")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2023")])]

#text("From the outset I don’t really follow what X <= A is supposed to represent. A is units of some currency, let's say USD. What is X? Is it assumed to be some fixed quantity of another currency? Why is it an inequality and not an equality, e.g. and exchange rate 1 GBP = 1.2 USD is not expressed as an inequality")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-679545")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2023")])]

#mi("X")#text(" would represent something that one could buy with ")#mi("A")#text(" units of currency, though possibly the particular offer is overpriced and that one could also buy ")#mi("X")#text(" for cheaper elsewhere (which mathematically corresponds to improving the upper bound for ")#mi("X")#text(" with some superior bound).")

#text("When trading large amounts of extremely liquid currencies or commodities, such as GBP and USD, the markets are efficient enough to essentially match the bid and ask prices for one currency in the units of the other, so that one effectively has equality instead of inequality (though even here there is occasionally a small spread between the two prices). But this is actually the exception rather than the rule: most items do not trade in a way that their bid and ask prices coincide exactly, especially when working with small amounts where friction costs such as transaction fees also become relevant. For instance, if one can purchase a car from a dealer for say 30,000 USD, this does not mean that one can immediately resell that same car for exactly the same price; the best sale price will typically be significantly less than 30,000 USD. The example of rate exchange boards that one might see for instance at an airport currency exchange are another example. Similarly, in mathematics we are fortunate in some cases to have exact expressions for an unknown, but in many cases all we can achieve are upper and lower bounds that have some gap between them.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/04/inequalities-convergence-and-continuity-as-special-deals/#comment-692045")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2026")])]

#text("Dear Dr. Tao,")

#text("I’ve come up with some perspectives, but I’m not sure if they are correct: Continuing with your analogy, which views convergence as a reward program, I think pointwise convergence and uniform convergence can be interpreted as the ")#emph[#text("route-specific reward programs")]#text(" and a ")#emph[#text("system-wide global reward chart")]#text(" respectively.")

#text("Say, for an easy route, Pointwise convergence means you might only need 10,000 miles to unlock Gold status; for a remote route, the exact same Gold status might cost you 1,000,000 miles. While you can eventually unlock any status on any given route if you fly enough, there is no universal mileage threshold that guarantees Gold status across all routes simultaneously；Meanwhile, Uniform convergence means offer and prices are valid on all routes, with zero destination-based price discrimination.")

#text("However, I still cannot figure out how to explain more advanced concepts of convergence, such as ")#emph[#text("convergence in measure")]#text(" and ")#emph[#text("convergence in the L¹ norm.")]
]
