// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/01/27/louis-nirenberg/
// Converted to Typst by tao2typ: "2026-10-14T10:57:01.695953+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Louis Nirenberg", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Louis Nirenberg")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 January 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/01/27/louis-nirenberg/")[#text("https://terrytao.wordpress.com/2020/01/27/louis-nirenberg/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("I just heard the news that ")#link("https://www.abelprize.no/nyheter/vis.html?tid=75971")[#text("Louis Nirenberg")]#text(" died a few days ago, aged 94. Nirenberg made a vast number of contributions to analysis and PDE (and his work has come up ")#link("https://terrytao.wordpress.com/?s=nirenberg")[#text("repeatedly on my own blog")]#text("); I wrote about his beautiful moving planes argument ")#link("http://www.ams.org/mathscinet-getitem?mr=544879")[#text("with Gidas and Ni")]#text(" to establish symmetry of ground states in ")#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/")[#text("this post")]#text(" on the occasion of him receiving the Chern medal, and on how his extremely useful ")#link("https://en.wikipedia.org/wiki/Gagliardo%E2%80%93Nirenberg_interpolation_inequality")[#text("interpolation inequality with Gagliardo")]#text(" (generalising a ")#link("https://en.wikipedia.org/wiki/Ladyzhenskaya%27s_inequality")[#text("previous inequality of Ladyzhenskaya")]#text(") can be viewed as an amplification of the usual Sobolev inequality in ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("this post")]#text(". Another fundamentally useful inequality of Nirenberg is the ")#link("https://en.wikipedia.org/wiki/Bounded_mean_oscillation#The_John%E2%80%93Nirenberg_Inequality")[#text("John-Nirenberg inequality")]#text(" established with Fritz John: if a (locally integrable) function ")#mi("f: {\\bf R} \\to {\\bf R}")#text(" (which for simplicity of exposition we place in one dimension) obeys the ")#link("https://en.wikipedia.org/wiki/Bounded_mean_oscillation")[#text("bounded mean oscillation")]#text(" property")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\frac{1}{\\left|I\\right|} \\int_I |f(x)-f_I|\\ dx \\leq A", block: true)]]

#text("for all intervals ")#mi("I")#text(", where ")#tao-math("f_I := \\frac{1}{\\left|I\\right|} \\int_I f", block: false)#text(" is the average value of ")#mi("f")#text(" on ")#mi("I")#text(", then one has exponentially good large deviation estimates")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\frac{1}{\\left|I\\right|} \\left|\\{ x \\in I: \\left|f(x)-f_I\\right| \\geq \\lambda A \\}\\right| \\leq \\exp( - c \\lambda )", block: true)]]

#text("for all ")#mi("\\lambda>0")#text(" and some absolute constant ")#mi("c")#text(". This can be compared with Markov’s inequality, which only gives the far weaker decay")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\frac{1}{\\left|I\\right|} \\left|\\{ x \\in I: \\left|f(x)-f_I\\right| \\geq \\lambda A \\}\\right| \\leq \\frac{1}{\\lambda}.", block: true)]]

#text("The point is that (1) is assumed to hold not just for a given interval ")#mi("I")#text(", but also all subintervals of ")#mi("I")#text(", and this is a much more powerful hypothesis, allowing one for instance to use the standard Calderon-Zygmund technique of stopping time arguments to “amplify” (3) to (2). Basically, for any given interval ")#mi("I")#text(", one can use (1) and repeated halving of the interval ")#mi("I")#text(" until significant deviation from the mean is encountered to locate some disjoint exceptional subintervals ")#mi("J")#text(" where ")#mi("f_J")#text(" deviates from ")#mi("f_I")#text(" by ")#mi("O(A)")#text(", with the total measure of the ")#mi("J")#text(" being a small fraction of that of ")#mi("I")#text(" (thanks to a variant of (3)), and with ")#mi("f")#text(" staying within ")#mi("O(A)")#text(" of ")#mi("f_I")#text(" at almost every point of ")#mi("I")#text(" outside of these exceptional intervals. One can then establish (2) by an induction on ")#mi("\\lambda")#text(". (There are other proofs of this inequality also, e.g., one can use Bellman functions, as discussed in ")#link("http://www.math.ucla.edu/~tao/preprints/Expository/john_nirenberg.dvi")[#text("this old set of notes of mine")]#text(".) Informally, the John-Nirenberg inequality asserts that functions of bounded mean oscillation are “almost as good” as bounded functions, in that they almost always stay within a bounded distance from their mean, and in fact the space BMO of functions of bounded mean oscillation ends up being superior to the space ")#mi("L^\\infty")#text(" of bounded measurable functions for many harmonic analysis purposes (among other things, the space is more stable with respect to singular integral operators).")

#text("I met Louis a few times in my career; even in his later years when he was wheelchair-bound, he would often come to conferences and talks, and ask very insightful questions at the end of the lecture (even when it looked like he was asleep during much of the actual talk!). I have a vague memory of him asking me some questions in one of the early talks I gave as a postdoc; I unfortunately do not remember exactly what the topic was (some sort of PDE, I think), but I was struck by how kindly the questions were posed, and how patiently he would listen to my excited chattering about my own work.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven Heilman")]], [#link("https://terrytao.wordpress.com/2020/01/27/louis-nirenberg/#comment-537597")[#strong[#text("Steven Heilman")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("He brought his Chern medal in a nondescript plastic bag, to show students at the celebration honoring that achievement. Perhaps greatness within a humble exterior best describes him. Very sad news. He will be missed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/27/louis-nirenberg/#comment-537608")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("Awesome mathematician.Deepest respects to him.I wish i could have been a little older so as to learn from the best.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/637addf7249fd129c526d50c1ff9e11f075b18b3eb7267607ae7caa4cde4bf93-a1483fb28e3b100f0edbff2b979118cbc0b9ea991d4a8fa0a234caed4d3e78fb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thepoliblog")]], [#link("https://terrytao.wordpress.com/2020/01/27/louis-nirenberg/#comment-537613")[#strong[#text("thepoliblog")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("Hans Bethe, too, had the ability to ask penetrating questions after appearing to doze through a talk.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b35ac837f5895fa03ec91ff1f2404eb8ad3cbd5dbe9afb39ca219cbb54d996b-e3bdb7734728362b1a13a0fd318372afc3cd6fe76e1751e5d31880eee1c884a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ahmedalshabi")]], [#link("https://terrytao.wordpress.com/2020/01/27/louis-nirenberg/#comment-537629")[#strong[#text("ahmedalshabi")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("RIP")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcc8946f803e2fd7a6157d43b3a347a85dfdccc1a772a4fe526012aa745e91ff-b32507acb466766f9be1685d880c057ea5d929c88b1bbb6a4e287c2627f485ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David W. Fry")]], [#link("https://terrytao.wordpress.com/2020/01/27/louis-nirenberg/#comment-537753")[#strong[#text("David W. Fry")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2020")])]

#text("Dear Dr. Tao,")#linebreak()#text(" I am extremely disheartened to hear about your colleague. It is obvious that you had a great deal of respect and admiration for Dr. Nirenberg.")

#text("Very Sincerely,")

#text("David")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cad1d81abe76b7370ad7d532bd52c709228e794a2d843f26470be0cc65607553-411ff35c15d856d36327c83d57536ca14034e316f6cb50b77319631dded0085b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brenton LeMesurier")]], [#link("https://terrytao.wordpress.com/2020/01/27/louis-nirenberg/#comment-537886")[#strong[#text("Brenton LeMesurier")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2020")])]

#text("One fond memory from my days as a student at the Courant Institute was the gentle questions that Nirenberg would ask in seminars, not because he did not know the answer, but to ensure that us graduate students got the explanation we needed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54753265e0dc5601fee8273cee5ab7d5af0fe176dd7fb42d3359062efc6dd218-440557b13b4e63e05b5db711103f690c05279f4a8457f1edabe51f1b7ce56469.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kirill Mayorov")]], [#link("https://terrytao.wordpress.com/2020/01/27/louis-nirenberg/#comment-537932")[#strong[#text("Kirill Mayorov")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2020")])]

#text("Needless to say how many bright disciples he produced: ")#link("https://www.genealogy.math.ndsu.nodak.edu/id.php?id=13410")[#text("https://www.genealogy.math.ndsu.nodak.edu/id.php?id=13410")]

#text("In particular, Walter Craig (")#link("https://math.mcmaster.ca/news-events/news/1919-walter-craig-1953-2019.html")[#text("https://math.mcmaster.ca/news-events/news/1919-walter-craig-1953-2019.html")]#text(") was one of them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5a158335c2a87400dadf1787c3791eeeaf41c14b67445c26efe39ce8ac1410d0-fdcf8f97e41eeaa80c44ade3d51690bcf855572217ef70348234b5a874dc9094.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sophie MacDonald")]], [#link("https://terrytao.wordpress.com/2020/01/27/louis-nirenberg/#comment-538335")[#strong[#text("Sophie MacDonald")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2020")])]

#text("Walter was my first research advisor, for an undergraduate summer project. The day that I met with him to decide the topic, there was an elderly man visiting him as well, who in retrospect looked a lot like Nirenberg — at the time, I had no idea who he was. Walter was exceptionally generous to me that summer and in the few remaining years of his life. Gone far too soon.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4ffa76d10622ca988de308cb98d1740c216c06e973b3103a5755a84f5a62ac2-f507995f11004b1242e07cc0e67e73fb5269f40e171c7d6c585b9a9ad3d9e04a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2020/01/27/louis-nirenberg/#comment-537999")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2020")])]

#text("Is the JN inequality applicable to probability in special formalized cases?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/01/27/louis-nirenberg/#comment-538111")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2020")])]

#text("There is a certain amount of literature on martingales of bounded mean oscillation (see e.g., ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=651556")[#text("this text of Petersen")]#text("), in which I would imagine the John-Nirenberg inequality plays a useful role. However I am not familiar with the details.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/27/louis-nirenberg/#comment-538287")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2020")])]

#text("Dear Sir , Pro.Tao")#linebreak()#text(" Today , I would like to have a suggestion for you after I have thoughts for many days.")#linebreak()#text(" Pro.Tao, Maths is very important in our life. Now, Biology and Chemistry are more important. You can stop do maths in one month in order to focus on other field. ( Although it is not your field, I know well). But you use your intelligent ( IQ 230) which God presented to you to save many people in the world. I mean you can find a medicine solution in your dream at night to kill virus corona. Nothing is impossible! I wait a miracle from you. If this becomes true, all human beings in the world would be grateful to you deeply. You become a great hero , a living saint for mankind. After that , you certainly get a Nobel prize in October , 2020.")#linebreak()#text(" Thank you, Sir.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a775d453bcd6946c502156f1cb35a4bed1e86c38743b7a8571353128d52ec436-2b5bcc287629bf18fb3f6a74d4985caac1fe38ce645b05a2bab667c82d4872a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of VCP")]], [#link("https://terrytao.wordpress.com/2020/01/27/louis-nirenberg/#comment-538300")[#strong[#text("VCP")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2020")])]

#text("Touching obituary of an impactful mathematician, who will certainly be remembered for many reasons.")#linebreak()#text(" (I wonder whether in the definition of ")#mi("f_I")#text(" after (1), the averaging term ")#mi("\\int_I f(x) dx")#text(" is missing.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/01/27/louis-nirenberg/#comment-538390")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2020")])]

#text("Touching obituary but you forgot to mention the other mathematical great that died — Koebe")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/01/27/louis-nirenberg/#comment-538710")[#strong[#text("Various | Not Even Wrong")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2020")]

#text("[…] I was sorry to hear recently about the death of mathematician Louis Nirenberg. Kenneth Chang at the New York Times has written an excellent obituary. Terry Tao has some comments here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/01/27/louis-nirenberg/#comment-539626")[#strong[#text("Leo's blog · My change to WP")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2020")]

#text("[…] WordPress (henceforth, WP), I decided to give it a shot (see, for example, Andrew Gelman and Terence Tao. I actually “stole” the style from the […]")
]
