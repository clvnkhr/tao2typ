// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/
// Converted to Typst by tao2typ: "2026-10-14T16:35:52.546507+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "More Mahler lectures", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("More Mahler lectures")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 31 August 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/")[#text("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I am posting here four more of my ")#link("http://www.austms.org.au/tiki-read_article.php?articleId=61")[#text("Mahler lectures")]#text(", each of which is based on earlier talks of mine:")

#list(
[#link("https://terrytao.wordpress.com/wp-content/uploads/2009/08/compressed-sensing1.pdf")[#text("Compressed sensing")]#text(". This is an updated and reformatted version of my ")#link("https://terrytao.wordpress.com/2008/02/06/compressed-sensing/")[#text("ANZIAM talk on this topic")]#text(".")],
[#link("https://terrytao.wordpress.com/wp-content/uploads/2009/08/random_matrix.pdf")[#text("Discrete random matrices")]#text(". This talk is a survey on recent developments on the universality phenomenon in random matrices, including work of myself and Van Vu. It covers similar material to my ")#link("http://www.math.technion.ac.il/Site/events/special-lectures/net-lect.html")[#text("Netanyahu lecture")]#text(", which has not previously appeared in electronic form.")],
[#link("https://terrytao.wordpress.com/wp-content/uploads/2009/08/prime-number-theory1.pdf")[#text("Recent progress in additive prime number theory")]#text(". This is an updated and reformatted version of my ")#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/")[#text("AMS lecture on this topic")]#text(".")],
[#link("https://terrytao.wordpress.com/wp-content/uploads/2009/08/kakeya.pdf")[#text("Recent progress on the Kakeya conjecture")]#text(". This is an updated and reformatted version of my ")#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/")[#text("Fefferman conference lecture")]#text(".")]
)

#text("As always, comments, corrections, and other feedback are welcome.")

#heading(level: 1)[#text("Comments (24)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b80186b23ecd7183baf3997fea0be9728242b29992242075d680bd57d5ecaf5e-c01d0095c1e1fd68ce186085beae7f7aa8012003d8a49df53762ddeb97b4ffff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phi. Isett")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-41218")[#strong[#text("Phi. Isett")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2009")])]

#text("On page 16 of the Random matrices talk there’s a sentence fragment")

#text("“Many, many further refinements and")#linebreak()#text(" proofs.”")

#text("And another on page 18 (but it’s the same, so I’m now a bit unsure it’s unintentional…)")

#text("Slightly related and maybe the wrong entry to ask: a long time ago on one of your blog posts you mentioned (paraphrasing) that there’s a connection between the law of large numbers (or maybe it was the central limit theorem) and intuition from information theory (presumably something to do with entropy?). I’m not sure if you’ve elaborated that point since then (it sounded interesting). Maybe you would like to talk more about it in connection to this new work?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11afcd7e98db9c0c7decafac00152ba901171454e32d09b138dca6889f797da9-44b6f520b40872468796e361144eba914a06d174c4971d8db461a04104bd875e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lachlan Andrew")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-41221")[#strong[#text("Lachlan Andrew")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2009")])]

#text("That may have been a reference to the relation between the central limit theorem and the information theoretic result that a Gaussian has maximum entropy of any distribution of a given variance.")

#text("The connection is discussed in")#linebreak()#text(" A. R. Barron.")#linebreak()#text(" Entropy and the central limit theorem.")#linebreak()#text(" Ann. Probab., 14:336-342, 1986.")#linebreak()#text(" and refined in")#linebreak()#text(" “Solution of Shannon’s problem on the monotonicity of entropy”")#linebreak()#text(" Author(s): Shiri Artstein; Keith M. Ball; Franck Barthe; Assaf Naor")#linebreak()#text(" Journal: J. Amer. Math. Soc. 17 (2004), 975-982.")

#text("The latter shows that the entropy of $\\sum_{i=1}^{n}/\\sqrt{n}$ increases monotonically.")

#text("I’ve been looking for other senses in which convergence to the CLT is “monotonic” in the number of terms, and would be grateful for any pointers.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0d7595e061568413d7b06c2441568893d7ad03083441e854fffd2c0f53eb4b7-78379cad78d5b43e3a96b9fc8c552afdb09998ce1924640d0f0fd9f68a60e9eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AK")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-41219")[#strong[#text("AK")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2009")])]

#text("typo: “Recent progress in additive prime number theory”")#linebreak()#text(" page 15: To put … no structure beyong [beyond] the obvious ones …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-41225")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2009")])]

#text("Typo in Kakeya slide; needs more verb:")#linebreak()#text(" “use linear algebra to a non-trivial polynomial”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KKK")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-41232")[#strong[#text("KKK")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2009")])]

#text("In the prime number theory slide, the last sentence is not shown clearly on p.9, at the bottom.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-41240")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2009")])]

#text("Thanks for the corrections! I’ve updated the compressed sensing and prime number theory slides to address some significant issues (missing slides, etc.). I’ll hold off on the other updates until other significant changes need to be made.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ragib Morshed")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-41253")[#strong[#text("Ragib Morshed")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2009")])]

#text("Dear Prof. Tao,")

#text("I have always been intrigued by compressive sensing. Both my undergraduate thesis in computer science and mathematics were on compressive sensing. Even though I am starting my graduate studies in machine learning, I am still very interested in compressive sensing ideas. I was first introduced to compressive sensing at a talk by Emmanuel Candes, and decided to do my undergraduate theses based on it. My cs and math advisors are not specialized in this field, but they took great interest in guiding me after I proposed working on this topic.")

#text("Anyways, I took a quick look through your slides on compressed sensing, and it looks like a really good introductory talk. However, I think it might be more interesting if you include, as an example, application of compressive sensing ideas to face recognition. Here’s the link:")

#link("http://perception.csl.illinois.edu/recognition/Home.html")[#text("http://perception.csl.illinois.edu/recognition/Home.html")]

#text("There are also a number of other interesting applications, like human action classifier, for example, that might serve as interesting examples in your talk.")

#text("Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-41260")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2009")])]

#text("In the additive primes, page 27, the common difference is one more than a prime, rather than one less than a prime.")

#text("In the cosmic ladder talk, on page 80, you hint that you will say why Aristarchus’ ideas were rejected by the ancients; was it because")#linebreak()#text(" the measurements were inaccurate, as on page 83, or another reason?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-41275")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2009")])]

#text("Thanks for the corrections! I forgot to tell the story hinted at on page 80, which was that the Greeks objected to the heliocentric model on the grounds that it would caused observable parallax in the fixed stars, unless those stars were an unimaginably large distance away – which, of course, they are. I’ve amended the slides to reflect this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-41266")[#strong[#text("Mathematical Research and the Internet « Euclidean Ramsey Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2009")]

#text("[…] ")#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/")[#text("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/")]#text(" Possibly related posts: (automatically generated)Mathematical research and the internet […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20d797b53d730fce1ebcc039214349c7753246b819222d94aac892705e0f787e-d3861ee35a6ed7ec1e214d271e83aebfde315447c65c354e04e5b45e75e8fa70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-41271")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2009")])]

#text("My brother encouraged me to skip school so I could see Don Zagier give the Mahler lectures at Melbourne University. His talks were absolutely inspiring — and Zagier paced, of course! It was my first exposure to many beautiful ideas in mathematics, from Hecke eigenforms and the BSD conjecture to the relationship between hyberbolic volume, special values of dilogarithms, and the Bloch group. Together with a two hour conversation with Matthew Emerton (on that same day) this pinpoints the very moment I decided to study algebraic number theory instead of analytic number theory. I hope your lectures will be similarly inspiring.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/61e50fe74d63679857127e92f4106a70a5f27615da0e0b91a6749349a3c105d4-e856cda0c7d5bfa7292fdc6cc61de18af7c459534b70ab67aeb79354113e1306.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andriy")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-41273")[#strong[#text("Andriy")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2009")])]

#text("Interesting introduction to compressed sensing, wait to watch it today. Hope that that time all will be OK with connections and we will be able to hear questions and answers:-))")#linebreak()#text(" Just a question: You assume that the “right basis” is given, then you solve l_1 minimization problem.")#linebreak()#text(" However very often statistical(image analysis,…) point of view is that you have to find a “right basis” and l_1 minimization simultaneously. Indeed in many cases we do not know the “right basis” for huge new data sets in advance. Also the pair l_1 solution+basis might be nonunique. Are there any general theoretical results on simultaneous basis choice and l_1 minimization?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-41278")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2009")])]

#text("Well, every signal is sparse with respect to ")#emph[#text("some")]#text(" basis, for instance a basis which includes the signal itself as one of the basis elements, so one can’t proceed very far just by knowing sparsity with respect to an unknown basis. But with a library of signals, I think there are tools (e.g. from machine learning) that can discover a common basis that is efficient for the bulk of these signals.")

#text("In practice, I would imagine that it would not be effective to learn the basis simultaneously with performing compressed sensing; ideally, one would like to spend more measurements to acquire an initial library of training signals with which to learn the basis before doing the compressed measurements.")

#text("Amusingly, if one is receiving a signal with an as-yet unknown basis, one could record it using random gaussian measurements, since such measurements work well with respect to any (orthonormal) basis. If and when the correct basis is discovered, one could perform l^1 minimisation (or other algorithms) to reconstruct the signal; until then, the data has been stored, but cannot be reconstructed.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/61e50fe74d63679857127e92f4106a70a5f27615da0e0b91a6749349a3c105d4-e856cda0c7d5bfa7292fdc6cc61de18af7c459534b70ab67aeb79354113e1306.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andriy")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-41281")[#strong[#text("Andriy")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2009")])]

#text("Thank you for you comments. Absolutely agree in general case. Of course we are not going to include each signal in the basis :-))")

#text("Might be I had to specify my previous question. Suppose that we have different candidate bases from our initial analysis (as you mentioned we learn the basis before, but we might have many candidates, just for simplicity – different families with unknown parameters). I am interested to estimate parameters in the basis to inform my colleagues on my choice of basis (I can send them only parameters instead of all basis functions) and perform l_1 minimisation. Choice of basis parameters might not be l_1 problem (I am not 100% sure, need to check it). Do you think that in this case the following l_1 minimization is appropriate? I am suspicious that 2 stage procedure gives the best result, that’s why I asked about simultaneous one.")

#text("It seems knowing you use l_1 norm must force you to use some appropriate corresponding methods to chose the basis. So it supports some simultaneous choice somehow.")

#text("Might be more correct question is not about completely unknown basis, but partially unknown (or choice in some class of candidates).")

#text("I see that the problem is a little bit far of presentation results. Any way it is interesting to know your opinion. Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-41283")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2009")])]

#text("Your questions remind me of work on compressed sensing in redundant dictionaries (e.g. unions of several distinct bases), see e.g.")

#link("http://arxiv.org/PS_cache/math/pdf/0701/0701131v1.pdf")[#text("Click to access 0701131v1.pdf")]

#text("It seems that much of the compressed sensing machinery extends to this case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-41313")[#strong[#text("Clay-Mahler lecture series « Mathematics in Australia")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2009")]

#text("[…] Here are the slides for the four Access Grid Room talks, “Compressed sensing”, “Discrete random matrices”, “Recent progress in additive prime number theory”, and “Recent progress on the Kakeya problem”. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e942430ff1257ac41f2cb8b03de7d52203ef174c36ddbff15f615d8ab4914902-8ddc25447f5bfeef892b40ed87c269f9cb4ec46df0a94ba282313a4ca3c594ec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pietro Poggi-Corradini")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-41331")[#strong[#text("Pietro Poggi-Corradini")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2009")])]

#text("I’ve enjoyed the talk on random matrices. Any chances it will become an actual survey paper with some details, references, etc…or does a closed substitute already exist?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29f2c78bc50405896b0bde3fe4e6948cb77c7bfa0d98065e60a5e447fa2ba88f-b33e7cdfd1e491053e3a3ea8bea255dee1c5c0adff712392a338537b763f95b6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yuan Lee")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-41370")[#strong[#text("Yuan Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2009")])]

#text("Hi Terry,")

#text("Really enjoyed the Q&A and your talk on compress sensing at the University of Queensland. Hope you’ll visit Australia soon again :)")

#text("Regards,")

#text("Yuan")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ec2f78ceb57d9bd64b34cc4b78429f1c5eac54c83816135c602986374a75021-e038760ba298b6b7b263cacae9f591e1977f4216ef31f5659d7913e113c583d0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Leopardi")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-41387")[#strong[#text("Paul Leopardi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2009")])]

#text("On slide 38 of the Kayaka conjecture talk, what is the relationship between n and d?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-41402")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2009")])]

#text("Oops, n is supposed to be d. It will be corrected in the next major update of the slides.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3cab72c6f7c640c47ff649b3411d9a3f34129389be3418febc4e4a65d08e5b5-29091e9390891e05aba45dfc1d3ba5582c4e7800ae2409ab8bcfef2012909d2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Indian")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-41435")[#strong[#text("Indian")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2009")])]

#text("Dear Prof Tao,")

#text("I would like to ask you a query and it is: Are you attending (or going to attend) the next International Congress of Mathematicians (ICM) ’10 at Hyderabad?")

#text("If so, then it would be very nice. Are you attending it next year?")

#text("I don’t know for sure whether this is an appropriate place to ask you this query. If it isn’t I apologize.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJ")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-46084")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2010")])]

#text("Professor:")#linebreak()#text(" Is there any work of UUP on non-archimedean spaces? Uncertainty has an implicit non-commutative flavor. Is there any study of UUP from anabelian geometry perspective?")#linebreak()#text(" Thank you,")#linebreak()#text(" AJ")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10f3af7edada5142aa5868d089a4b316d3bfa2ec1af4464846597f3ec6748fd3-5f28ddd2c4d2b8886b42b73d8306c2bf572d897a158a21a96b7b08e078faccd7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sper")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-51154")[#strong[#text("Sper")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2011")])]

#text("Some minor observations concerning slide 13 of the Compressed sensing slides are as follows:")

#text("1. The proof of the Proposition should begin: Then there are two S-sparse signals ")#mi("x\\neq x^{\\prime} \\in \\mathbb{R}^n")#text(".")

#text("2. In the general case ")#mi("x - x^{\\prime}")#text(" is at most 2S-sparse, and not always 2S sparse. For the purpose of the proof though, the fact that ")#mi("x - x^{\\prime}")#text(" is exactly 2S-sparse is relevant, as written in the slides.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10f3af7edada5142aa5868d089a4b316d3bfa2ec1af4464846597f3ec6748fd3-5f28ddd2c4d2b8886b42b73d8306c2bf572d897a158a21a96b7b08e078faccd7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sper")]], [#link("https://terrytao.wordpress.com/2009/08/31/more-mahler-lectures/#comment-51173")[#strong[#text("Sper")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2011")])]

#text("Actually, revisiting the definition of S-sparse signals: “A signal is S-sparse if it contains (at most) S nonzero entries”, led me to the conclusion that the second observation in my previous post is unfounded.")
]
