// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/22/simple-and-critical-zeros-of-the-riemann-zeta-function/
// Converted to Typst by tao2typ: "2026-10-25T11:50:19.159608+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Simple and critical zeros of the Riemann zeta-function", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Simple and critical zeros of the Riemann zeta-function")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/22/simple-and-critical-zeros-of-the-riemann-zeta-function/")[#text("https://terrytao.wordpress.com/2026/10/22/simple-and-critical-zeros-of-the-riemann-zeta-function/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-25 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#emph[#text("[This is a guest post by ")#link("https://www.carleton.edu/directory/cturnageb/")[#text("Caroline Turnage-Butterbaugh")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("Evidence in favor of the Riemann Hypothesis comes in many flavors. ")#link("https://github.com/openai/math/blob/main/preprints/The-Quasi-Riemann-Hypothesis-September-30-2026/paper.pdf")[#text("OpenAI’s proof of the quasi-Riemann Hypothesis")]#text(" is definitely one such flavor; however, in this post I will focus my comments on a different kind of evidence: lower bounds on the proportion of nontrivial zeros of the Riemann zeta-function on the critical line. Great strides have recently been made on this problem, both ")#link("https://www.anthropic.com/research/riemann-zeta")[#text("with")]#text(" and ")#link("https://arxiv.org/abs/2609.02882")[#text("without")]#text(" the use of AI. Many thanks to Terry Tao for inviting me to discuss this problem and the recent breakthrough results.")

#strong[#text("Background.")]#text(" Let ")#mi("{s=\\sigma+it}")#text(", where ")#mi("{\\sigma,t}")#text(" are real. The Riemann Hypothesis (RH) states that the nontrivial zeros of the Riemann zeta-function ")#mi("{\\zeta(s)}")#text(" have real part equal to 1/2. It arose out of ")#link("https://www.claymath.org/collections/riemanns-1859-manuscript/")[#text("Riemann’s foundational work")]#text(", which led to proofs of the Prime Number Theorem by ")#link("https://www.numdam.org/item/BSMF_1896__24__199_1/")[#text("Hadamard")]#text(" and ")#link("https://babel.hathitrust.org/cgi/pt?id=hvd.32044102916723&seq=7")[#text("de la Vallée Poussin")]#text(" in 1896. If RH is true, then the error term in the Prime Number Theorem is essentially as small as possible.")

#text("Denote a nontrivial zero of ")#mi("{\\zeta(s)}")#text(" by ")#mi("{\\rho = \\beta + i \\gamma}")#text(", where ")#mi("{\\beta, \\gamma}")#text(" are real values and ")#mi("{0 < \\beta < 1}")#text(". The ")#emph[#text("critical line")]#text(" is the line ")#mi("{\\Re(s)=1/2}")#text(", and often we will refer to a nontrivial zero on the critical line as a ")#emph[#text("critical zero")]#text(". Riemann asserted that ")#mi("{\\zeta(s)}")#text(" has infinitely many nontrivial zeros, and in 1914 ")#link("https://gallica.bnf.fr/ark:/12148/bpt6k3111d/f1014.image.r=")[#text("Hardy")]#text(" proved that ")#mi("{\\zeta(s)}")#text(" has infinitely many critical zeros. (See Chapter 10 of ")#link("https://mathscinet.ams.org/mathscinet/article?mr=882550")[#text("Titchmarsh")]#text(" for several proofs of this fact.) ")#link("https://mathscinet.ams.org/mathscinet/article?mr=4275089")[#text("Platt and Trudgian")]#text(" have numerically verified RH up to ")#mi("{3\\cdot 10^{12}}")#text(", i.e. all of the nontrivial zeros for which ")#mi("{0 < \\gamma \\le 3\\cdot 10^{12}}")#text(" have ")#mi("{\\beta = 1/2}")#text(". (The nontrivial zeros are symmetric about the real line, so it suffices to consider those zeros for which ")#mi("{\\gamma >0}")#text(".) The authors also show that these zeros are simple, which we expect to be true of every nontrivial zero. We set ")#mi("{m_\\rho}")#text(" to denote the multiplicity of the nontrivial zero ")#mi("{\\rho}")#text(".")

#text("The recent proportionality results making headlines give a lower bound on the quantity ")#metadata(none) <tao-e70ae939d74b2af512a1>#mi("\\displaystyle  \\kappa_0^s :=\\liminf_{T \\rightarrow \\infty} \\frac{N_0^s(T)}{N(T)}. \\ \\ \\ \\ \\ (1)")#text(" ")#text(" Here, ")#mi("{N(T)}")#text(" denotes the number of nontrivial zeros ")#mi("{\\rho}")#text(" for which ")#mi("{0 < \\gamma \\le T}")#text(", and ")#mi("{N_0^s(T)}")#text(" denotes the number of zeros counted by ")#mi("{N(T)}")#text(" which are both simple and critical, i.e. for which ")#mi("{m_{\\rho}=1}")#text(" and ")#mi("{\\beta=1/2}")#text(". One can analogously define ")#mi("{N_0(T)}")#text(" to count critical zeros and set")

#align(center)[#tao-fit-display[#mitex("\\kappa_0:=\\liminf_{T \\rightarrow \\infty} \\frac{N_0(T)}{N(T)}.")]]

#text("The ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93von_Mangoldt_formula")[#text("Riemann–von Mangoldt formula")]#text(" gives a surprisingly precise asymptotic formula for ")#mi("{N(T)}")#text("; for this discussion, it suffices to record that")

#align(center)[#tao-fit-display[#mitex("N(T)\\sim (T/2\\pi)\\log T \\qquad \\text{as}\\quad T\\rightarrow \\infty.")]]

#text("(Here and throughout, ")#mi("{f(x)\\sim g(x)}")#text(" means ")#mi("{\\lim_{x\\rightarrow \\infty} f(x)/g(x) = 1}")#text(" and ")#mi("{g(x)}")#text(" is a positive function.) Recall that zeros of analytic functions are counted by the argument principle with their multiplicity. Therefore:")

#align(center)[#emph[#text("** It is important to keep in mind that we always count zeros with multiplicity.**")]]

#strong[#text("Previous key unconditional results on ")#mi("{\\kappa_0}")#text(" and ")#mi("{\\kappa_0^s}")#text(".")]#text(" In 1942, ")#link("https://mathscinet.ams.org/mathscinet/article?mr=10712")[#text("Selberg")]#text(" proved that a positive proportion of the nontrivial zeros lie on the critical line. More specifically, he proved that there exists an effectively computable constant ")#mi("{c>0}")#text(" such that ")#mi("{N_0(T)> c N(T)}")#text(". (In his 1947 PhD thesis, ")#link("https://soas.on.worldcat.org/search/detail/1064612611?queryString=no%3A1064612611")[#text("S. H. Min")]#text(" calculated ")#mi("{c}")#text(" to be around ")#mi("{1/15000000}")#text(".) In 1974, ")#link("https://mathscinet.ams.org/mathscinet/article?mr=564081")[#text("Levinson")]#text(" introduced a new method to show that ")#mi("{N_0(T)> \\tfrac{1}{3}N(T)}")#text(", i.e. at least ")#mi("{1/3}")#text(" of the nontrivial zeros lie on the critical line. Soon after, ")#link("https://mathscinet.ams.org/mathscinet/article?mr=369281")[#text("he improved the proportion")]#text(" to ")#mi("{0.3474}")#text(". In 1979, ")#link("https://mathscinet.ams.org/mathscinet/article?mr=535789")[#text("Heath-Brown")]#text(" showed that Levinson’s method may be used to prove proportionality results on nontrivial zeros that are both simple ")#emph[#text("and")]#text(" critical. Levinson’s method was extended by ")#link("https://mathscinet.ams.org/mathscinet/article?mr=1004130")[#text("Conrey")]#text(" in 1989 to show that at least ")#mi("{2/5}")#text(" of the nontrivial zeros of ")#mi("{\\zeta(s)}")#text(" are simple and critical. Over the years and with much effort and insight, members of the analytic number theory community have harnessed Levinson’s method to slightly improve these bounds, culminating with the work of ")#link("https://mathscinet.ams.org/mathscinet/article?mr=4045193")[#text("Pratt, Robles, Zaharescu and Zeindler")]#text(" who proved in 2020 that at least ")#mi("{5/12}")#text(" of the nontrivial zeros of ")#mi("{\\zeta(s)}")#text(" are on the critical line. The table below gives a snapshot of these results, with the precise proportions recorded.")

#table(columns: 3, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Author(s)/Year")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\kappa_0 >}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\kappa_0^s >}")],
table.cell(colspan: 1, rowspan: 1)[#text("Levinson (1975), Heath-Brown (1979)")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.3474}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.3474}")],
table.cell(colspan: 1, rowspan: 1)[#text("Conrey (1989)")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.4088}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.401}")],
table.cell(colspan: 1, rowspan: 1)[#text("Pratt, Robles, Zaharescu, Zeindler (2020)")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.417293}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.407511}")]
)

#align(center)[#emph[#text("A few key unconditional results on proportions of critical and simple zeros, prior to 2026.")]]

#strong[#text("Counting simple zeros under RH.")]#text(" In 1973, ")#link("https://mathscinet.ams.org/mathscinet/article?mr=337821")[#text("Montgomery")]#text(" published his groundbreaking work on the pair correlation of the zeros of ")#mi("{\\zeta(s)}")#text(". As a corollary to his main theorem, which we will state below, he showed that under RH at least ")#mi("{2/3}")#text(" of the nontrivial zeros are simple.")

#text("We now give a sketch of Montgomery’s argument for simple zeros. (To supplement the broad strokes which follow, I recommend ")#link("https://mathscinet.ams.org/mathscinet/article?mr=2166459")[#text("Goldston’s expository paper")]#text(".) This approach will lead us to the construction of Montgomery’s function ")#mi("{F(\\alpha)}")#text(", and, in turn, the statement of his theorem concerning the pair correlation of the zeros of ")#mi("{\\zeta(s)}")#text(".")

#text("Montgomery begins with the observation ")#metadata(none) <tao-c281e970e068a45ff244>#mi("\\displaystyle  N_0^s(T)=\\sum_{\\substack{0<\\gamma \\le T\\\\\\rho \\text{ simple}}}1 \\ge \\sum_{0 < \\gamma \\le T}\\left( 2-m_{\\rho}\\right). \\ \\ \\ \\ \\ (2)")#text(" ")#text(" Note that since the argument assumes RH, the zeros are necessarily critical! The goal is to determine a constant ")#mi("{1\\le c < 2}")#text(" such that ")#mi("{\\sum m_{\\rho} \\le c N(T)}")#text(" so that, when combined with ")#link(<tao-c281e970e068a45ff244>)[#text("(2)")]#text(", we may conclude ")#mi("{N_0^s(T) / N(T) \\ge 2 - c >0}")#text(". A key transition occurs after noting ")#metadata(none) <tao-0d64ab601b5bf2f6e3c0>#mi("\\displaystyle  \\sum_{0 < \\gamma \\le T}m_{\\rho} = \\sum_{\\substack{0 < \\gamma,\\gamma^{\\prime}\\le T\\\\ \\gamma = \\gamma^{\\prime}}}1. \\ \\ \\ \\ \\ (3)")#text(" ")#text(" (Keep in mind that we always count with multiplicity.) The sum on the right-hand side is a double sum over ")#mi("{\\gamma}")#text(" and ")#mi("{\\gamma^{\\prime}}")#text(", and with it pair correlation will soon enter the picture. Roughly, the idea is to find a nice function ")#mi("{r(u)}")#text(" for which ")#metadata(none) <tao-45a4be745c24fa6b3c8f>#mi("\\displaystyle  \\sum_{\\substack{0 < \\gamma,\\gamma^{\\prime}\\le T\\\\ \\gamma = \\gamma^{\\prime}}}1 \\le \\sum_{0< \\gamma,\\gamma^{\\prime} \\le T}r\\left(\\frac{\\gamma-\\gamma^{\\prime}}{2\\pi/\\log T} \\right), \\ \\ \\ \\ \\ (4)")#text(" ")#text(" where ")#mi("{r(0)=1}")#text(" and ")#mi("{0\\le r(u)<1}")#text(" when ")#mi("{u\\ne 0}")#text(". (Note that we have normalized the difference ")#mi("{\\gamma-\\gamma^{\\prime}}")#text(" by ")#mi("{2\\pi/\\log T}")#text(", the average spacing between zeros around height ")#mi("{T}")#text(".) For ")#mi("{r(u)\\in L^1}")#text(", define the Fourier transform by")

#align(center)[#tao-fit-display[#mitex("\\hat{r}(\\alpha) = \\int_{-\\infty}^{\\infty}r(u)e^{2\\pi i \\alpha u}\\,du.")]]

#text("Then if ")#mi("{\\hat{r}(\\alpha) \\in L^1}")#text(", we have almost everywhere")

#align(center)[#tao-fit-display[#mitex("r(u)=\\int_{-\\infty}^{\\infty}\\hat{r}(\\alpha)e^{-2\\pi i \\alpha u}\\, d\\alpha.")]]

#text("Suppose for the moment that we have a function ")#mi("{r(u)}")#text(" satisfying the properties above. Then proceeding formally and ignoring error terms, we arrive at an inequality of the shape")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\substack{0<\\gamma,\\gamma^{\\prime}\\le T \\\\ \\gamma = \\gamma^{\\prime}}}1 \\le \\int_{-\\infty}^{\\infty}\\hat{r}(\\alpha)\\sum_{0<\\gamma,\\gamma^{\\prime}\\le T}T^{i\\alpha(\\gamma-\\gamma^{\\prime})}\\,d\\alpha.")]]

#text("Montgomery showed how to estimate (a weighted version of) the inner sum on the right-hand side above by proving, under RH, an explicit formula relating the nontrivial zeros of ")#mi("{\\zeta(s)}")#text(" and the primes. This weighted sum is given by")

#metadata(none) <tao-f1df5b500036cb328878>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\begin{array}{c} F(\\alpha)=F(\\alpha,T) := \\Big{\\left(\\frac{T}{2\\pi}\\log T\\right)}^{-1}\\sum_{0<\\gamma,\\gamma^{\\prime} \\le T} T^{i\\alpha(\\gamma-\\gamma^{\\prime})} w(\\gamma-\\gamma^{\\prime}), \\\\ \\text{where} \\quad w(u) := \\frac{4}{4+u^2}. \\end{array}")]]

#text("Note that ")#mi("{w(0)=1}")#text(" and ")#mi("{w(u)<1}")#text(" when ")#mi("{u\\ne 0}")#text(". We may now state Montgomery’s Theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Montgomery, 1973)")]#text(" Assume the Riemann Hypothesis. Then ")#mi("{F(\\alpha)}")#text(" is real, even, nonnegative, and, as ")#mi("{T\\rightarrow \\infty}")#text(",")

#align(center)[#tao-fit-display[#mitex("F(\\alpha) = \\alpha + o(1) + (1+o(1))T^{-2\\alpha}\\log T")]]

#text("uniformly for ")#mi("{0\\le \\alpha \\le 1}")#text(".")
]

#text("(That the theorem holds up to ")#mi("{\\alpha=1}")#text(" is due to ")#link("https://mathscinet.ams.org/mathscinet/article?mr=1018376")[#text("Goldston and Montgomery")]#text(".) There are ")#link("https://www.ias.edu/ideas/2013/primes-random-matrices")[#text("scores of interesting things to say")]#text(" about this theorem and Montgomery’s pair correlation conjecture, but we will stay on task and return to the simple zeros argument. Assembling the chain of inequalities above and adjusting to accommodate the weight ")#mi("{w(u)}")#text(", we find that ")#metadata(none) <tao-0524ff76217f14061e7c>#mi("\\displaystyle  \\frac{N_0^s(T)}{N(T)}\\gtrapprox 2 - \\int_{-\\infty}^{\\infty}\\hat{r}(\\alpha)F(\\alpha)\\,d\\alpha. \\ \\ \\ \\ \\ (6)")#text(" ")#text(" Under RH, one can evaluate the RHS using Montgomery’s Theorem, provided ")#mi("{\\text{supp}(\\hat{r})\\subseteq [-1,1]}")#text(" and positivity is maintained. Inserting the Fejér kernel")

#align(center)[#tao-fit-display[#tao-math("r(u) = \\left(\\frac{\\sin \\pi u}{\\pi u} \\right)^2, \\qquad \\hat{r}(\\alpha)=\\max\\{1-\\left|\\alpha\\right|,0\\}", block: true)]]

#text("into Montgomery’s theorem yields")

#align(center)[#tao-fit-display[#mitex("\\sum_{0<\\gamma,\\gamma^{\\prime}\\le T}\\left(\\frac{\\sin(\\tfrac{1}{2}(\\gamma-\\gamma^{\\prime})\\log T)}{\\tfrac{1}{2}(\\gamma-\\gamma^{\\prime})\\log T} \\right)^2w(\\gamma-\\gamma^{\\prime}) \\sim \\frac{4}{3}\\frac{T}{2\\pi}\\log T.")]]

#text("Thus, by ")#link(<tao-0524ff76217f14061e7c>)[#text("(6)")]

#align(center)[#tao-fit-display[#mitex("\\frac{N_0^s(T)}{N(T)} \\gtrapprox 2 - \\frac{4}{3} = \\frac{2}{3}.")]]

#text("In other words, under RH at least ")#mi("{2/3}")#text(" of the nontrivial zeros are simple.")

#strong[#text("Counting critical zeros via pair correlation under a weaker-than-RH assumption.")]#text(" It was known among experts for some time that Montgomery’s Theorem could be made unconditional. Indeed, the starting point of the proof of Montgomery’s explicit formula is an ")#link("https://archive.org/details/handbuchderlehre01landuoft/page/352/mode/2up")[#text("unconditional explicit formula due to Landau")]#text(" from 1909 (see equation (9) on page 353). Setting ")#mi("{\\rho = 1/2+\\delta+i\\gamma}")#text(", where ")#tao-math("{\\left|\\delta\\right|<1/2}", block: false)#text(", the same arguments for Montgomery’s explicit formula and theorem carry through. That one could use an unconditional form of Montgomery’s Theorem to extract information about critical zeros was recently discovered by Siegfred Baluyot, Daniel Goldston, Ade Irma Suriajaya, and myself; henceforth BGST-B. In our ")#link("https://mathscinet.ams.org/mathscinet/article?mr=4772293")[#text("first project")]#text(" we did not realize this capability of Montgomery’s method, and erroneously stated in the abstract “The method of proof neither requires nor provides any information on whether any of these zeros are or are not on the critical line where ")#mi("{\\beta=1/2}")#text(".” In a ")#link("https://arxiv.org/abs/2501.14545")[#text("follow-up paper")]#text(" we realized that, in fact, we ")#emph[#text("could")]#text(" extract information on critical zeros using the pair correlation method, albeit upon an assumption weaker than RH. Roughly, we showed that if the nontrivial zeros of ")#mi("{\\zeta(s)}")#text(" are contained in a narrow vertical box centered on the critical line, then the pair correlation method shows that at least 67.25% of the zeros are both simple and critical. I’ll give a sketch of the argument, highlighting some of the key distinctions from Montgomery’s work. Portions of what follows below appear in our preprint.")

#text("In addition to making use of the multiplicity ")#mi("{m_\\rho}")#text(" of a nontrivial zero ")#mi("{\\rho}")#text(", we use a quantity we refer to as the ")#emph[#text("horizontal multiplicity")]#text(" of ")#mi("{\\rho}")#text(". (This framework was suggested to us by Soundararajan and simplified our original classification of the ways in which ")#mi("{\\gamma=\\gamma^{\\prime}}")#text(" can occur.) For ")#mi("{j}")#text(" a fixed real number, the horizontal multiplicity ")#mi("{H(j)}")#text(" is the number of nontrivial zeros of ")#mi("{\\zeta(s)}")#text(" on the horizontal line ")#mi("{s=\\sigma + ij, 0 <\\sigma < 1}")#text(", counted with multiplicity. Assuming RH, ")#mi("{H(j)}")#text(" is either zero or the multiplicity ")#mi("{m_\\rho}")#text(" of the zero ")#mi("{\\rho=1/2+ij}")#text(". Note that if ")#mi("{H(\\gamma)=1}")#text(", then on the line ")#mi("{t=\\gamma}")#text(", there is one simple zero on the critical line.")

#text("Let ")#mi("{\\mathcal{Z}(T)}")#text(" denote the multiset of nontrivial zeros of ")#mi("{\\zeta(s)}")#text(" for which ")#mi("{T < \\gamma \\le 2T}")#text(". We can partition ")#mi("{\\mathcal{Z}(T)}")#text(" into disjoint multisets of zeros according to their horizontal multiplicity:")

#align(center)[#tao-fit-display[#mitex("\\mathcal{H}(k):=\\{\\rho \\in \\mathcal{Z}(T): H(\\gamma)=k\\}.")]]

#text("Consider the multiset ")#mi("{\\mathcal{S}}")#text(" of simple zeros in ")#mi("{\\mathcal{Z}(T)}")#text(" and the multiset ")#mi("{\\mathcal{C}}")#text(" of critical zeros in ")#mi("{\\mathcal{Z}(T)}")#text(". Furthermore, note that")

#align(center)[#tao-fit-display[#mitex("\\mathcal{H}(1) \\subset \\mathcal{S}\\cap \\mathcal{C}.")]]

#text("To obtain a lower bound on the proportion of simple and critical zeros, we begin with the following observation, which should be compared to ")#link(<tao-c281e970e068a45ff244>)[#text("(2)")]#text(":")

#metadata(none) <tao-28f2870890635ddc1d80>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left|\\mathcal{S}\\cap \\mathcal{C}\\right|\\ge \\sum_{\\substack{\\rho \\in \\mathcal{Z}(T)\\\\H(\\gamma)=1}}1\\ge \\sum_{\\rho \\in \\mathcal{Z}(T)}(2-H(\\gamma)).", block: true)]]

#text("Then, as in ")#link(<tao-0d64ab601b5bf2f6e3c0>)[#text("(3)")]#text(", we transition to a pair correlation argument upon noting")

#metadata(none) <tao-4a0333afb4ac44d3ca2e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\sum_{\\rho \\in \\mathcal{Z}(T)}H(\\gamma) = \\sum_{\\substack{\\rho,\\rho^{\\prime}\\\\ 0< \\gamma, \\gamma^{\\prime} \\le T\\\\\\gamma=\\gamma^{\\prime}}}1.")]]

#text("As in ")#link(<tao-45a4be745c24fa6b3c8f>)[#text("(4)")]#text(" we need to pick a kernel that maintains positivity. ")#link("https://mathscinet.ams.org/mathscinet/article?mr=1260885")[#text("Tsang")]#text(" found a kernel that partially meets our needs; however, after rescaling for our setting, the positivity is only maintained provided the zeros ")#mi("{\\rho,\\rho^{\\prime}\\in \\mathcal{Z}(T)}")#text(" are in a thin box centered on the critical line such that ")#tao-math("{\\left|\\beta-\\beta^{\\prime}\\right|< b/\\log T}", block: false)#text(" for some ")#mi("{0<b<1}")#text(". Assuming this condition, we may use the unconditional version of Montgomery’s Theorem (see equations (3.2) and (3.3) in ")#link("https://arxiv.org/abs/2501.14545")[#text("our preprint")]#text(") to bound from above the contribution of the right-hand side of ")#link(<tao-4a0333afb4ac44d3ca2e>)[#text("(8)")]#text(" in terms of the Tsang kernel. In particular, choosing ")#mi("{b=0.001}")#text(" yields ")#mi("{\\kappa_0^s > 0.67250}")#text(".")

#strong[#text("Counting critical zeros via pair correlation unconditionally.")]#text(" On August 10, 2026, ")#link("https://www.anthropic.com/research/riemann-zeta")[#text("Anthropic announced")]#text(" that an unreleased research model of Claude had connected the BGST-B approach above with a 2000 ")#link("https://mathscinet.ams.org/mathscinet/article?mr=1841692")[#text("paper by Bombieri")]#text(" to unconditionally prove that ")#mi("{\\kappa_0^s > 0.67250}")#text(". The result was soon after verified by ")#link("https://arxiv.org/abs/2608.13637")[#text("Alpöge and Furman")]#text(", two mathematicians at Anthropic. Then, on September 2, 2026, ")#link("https://arxiv.org/abs/2609.02882")[#text("Lamzouri")]#text(" announced a new, conceptually simpler proof of the same result. The entire preprint is very nicely written with helpful clarifications and remarks; in particular, Lamzouri takes care to compare/contrast his approach to that of Claude. With all of this in mind, I will focus this discussion on Lamzouri’s key ideas.")

#text("Lamzouri points out that the BGST-B approach cannot be made unconditional by merely finding a better kernel ")#mi("{K}")#text(" at the transition ")#metadata(none) <tao-598bbdf62e0568a57de0>#mi("\\displaystyle  \\sum_{\\substack{\\rho,\\rho^{\\prime}\\\\ 0< \\gamma, \\gamma^{\\prime} \\le T\\\\\\gamma=\\gamma^{\\prime}}}1 \\le \\sum_{\\substack{\\rho,\\rho^{\\prime}\\\\0<\\gamma,\\gamma^{\\prime}\\le T}}K\\left(\\frac{i(\\rho-\\rho^{\\prime})}{2\\pi/\\log T} \\right). \\ \\ \\ \\ \\ (9)")#text(" ")#text(" Lamzouri, in fact, avoids this transition altogether by changing the mechanism with which simple and critical zeros are identified. As he helpfully writes on page 5,")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Our key idea is that one can bypass the inequality [")#link(<tao-598bbdf62e0568a57de0>)[#text("(9)")]#text("] and directly prove, for a large class of kernels ")#mi("{K}")#text(", that the number of simple real elements of a finite multiset ")#mi("{\\mathcal{Z}}")#text(" which is invariant under complex conjugation is")

#align(center)[#tao-fit-display[#mitex("\\ge 2\\sum_{z\\in \\mathcal{Z}}1-\\sum_{z,s\\in\\mathcal{Z}}K(z-s)^2")]]

#text("without requiring that the individual off-diagonal terms ")#mi("{K(z-s)^2}")#text(" be non-negative.")
]

#text("Instead of setting ")#mi("{\\mathcal{Z}(T)}")#text(" to be the multiset of nontrivial zeros for which ")#mi("{0<\\gamma \\le T}")#text(" as in BGST-B, he takes it to be the multiset")

#align(center)[#tao-fit-display[#mitex("\\mathcal{Z}_T:= \\left \\{\\frac{i(\\rho-1/2)}{2\\pi/\\log T}: 0 < \\gamma \\le T\\right\\}.")]]

#text("This is such a clever idea! This multiset is invariant under complex conjugation, i.e. if ")#mi("{z\\in \\mathcal{Z}_T}")#text(" then ")#mi("{\\bar{z}\\in \\mathcal{Z}_T}")#text(" and ")#mi("{m_{\\bar{z}}=m_{z}}")#text("; its real elements are those with corresponding zero satisfying ")#mi("{\\beta=1/2}")#text("; its real and simple elements are those with corresponding zero being critical and simple. As Lamzouri notes in Remark 2.2, “the square [i.e., in ")#mi("{K(z-s)^2}")#text("] is also naturally adapted to the Hilbert space argument in the proof [of Proposition 2.1] and to the use of Bessel’s inequality.” This new framework allows Lamzouri to bypass the portion of the previous arguments that required an assumption on the location of the nontrivial zeros.")

#strong[#text("Concluding remarks.")]#text(" Since the breakthrough results by Anthropic and Lamzouri, subsequent minor improvements have been made. (I will refrain from quoting the strongest result at the time of writing, since it will likely be out of date by the time this appears!) It is important to keep in mind that even if we increased 67.25% to 100%, the Riemann Hypothesis would not be solved. (Refer back to the precise definition of ")#mi("{\\kappa_0^s}")#text(" which appears in ")#link(<tao-e70ae939d74b2af512a1>)[#text("(1)")]#text(".) Nevertheless, the old and new ideas which have come together to realize these breakthrough results have expanded our understanding not only of the nontrivial zeros of the Riemann zeta-function, but, more broadly, of how different techniques were used, pushed, and molded to breathe new life into this problem.")

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/22/simple-and-critical-zeros-of-the-riemann-zeta-function/comment-page-1/#comment-698635")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("How do the percentages of Riemann zeta function zeroes on the critical line change when we apply the new critical strip of 1/8 < Re(s) < 7/8?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb6404c0b3d7f16b4f0c74a43c79a23a7cd5ea93ec573aeb2292c803c25a4646-dffb764b3cd802341a74c1c79537010dc27f655034bc35a25421c791b6cfb956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nathan Ng")]], [#link("https://terrytao.wordpress.com/2026/10/22/simple-and-critical-zeros-of-the-riemann-zeta-function/comment-page-1/#comment-698641")[#strong[#text("Nathan Ng")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("It should be noted that Farzad Aryan was the first person to prove an unconditional version of Montgomery’s Pair Correlation Result in the article “On an extension of the Landau-Gonek Formula” in Journal of Number Theory in 2022 (see Corollary 1.2). He used this to show that a zero-density hypothesis implied the 2/3 simple zeros result (Corollary 1.3 of his article).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/22/simple-and-critical-zeros-of-the-riemann-zeta-function/comment-page-1/#comment-698648")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("It would be helpful not to link to mathscinet as I imagine that many of us do not have a subscription. An alternative might be ")#link("https://zbmath.org")[#text("https://zbmath.org")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48ef522df7849f0ea3b171cb9a48b74138a0d5baba681ec4d211021574a845a2-85d30fcc7bcb16d3272c98aeec5d9779c20c17c9e69734a26146bab13daa6e9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michel Kern")]], [#link("https://terrytao.wordpress.com/2026/10/22/simple-and-critical-zeros-of-the-riemann-zeta-function/comment-page-1/#comment-698659")[#strong[#text("Michel Kern")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2026")])]

#text("In case it’s helpful, here are the links to zbmath ")#linebreak()#text("Selberg: ")#link("https://zbmath.org/0028.11101")[#text("https://zbmath.org/0028.11101")]#linebreak()#text("Levinson: ")#link("https://zbmath.org/0281.10017")[#text("https://zbmath.org/0281.10017")]#text(", ")#link("https://zbmath.org/0294.10027")[#text("https://zbmath.org/0294.10027")]#linebreak()#text("Heath-Brown: ")#link("https://zbmath.org/0409.10027")[#text("https://zbmath.org/0409.10027")]#linebreak()#text("Conrey: ")#link("https://zbmath.org/0668.10044")[#text("https://zbmath.org/0668.10044")]#linebreak()#text("Pratt et al.: ")#link("https://zbmath.org/1505.11116")[#text("https://zbmath.org/1505.11116")]#linebreak()#text("Montgomery: ")#link("https://zbmath.org/0268.10023")[#text("https://zbmath.org/0268.10023")]#linebreak()#text("Goldston: ")#link("https://zbmath.org/1168.11320")[#text("https://zbmath.org/1168.11320")]#linebreak()#text("Goldston and Montgomery: ")#link("https://zbmath.org/0629.10032")[#text("https://zbmath.org/0629.10032")]#linebreak()#text("BGST-B: ")#link("https://zbmath.org/1556.11092")[#text("https://zbmath.org/1556.11092")]#linebreak()#text("Bombieri: ")#link("https://zbmath.org/1008.11034")[#text("https://zbmath.org/1008.11034")]

#text("Let me know if I’ve missed any one")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65fdf2a4f40c84f3ddb76ee8ba6bb92d8b82efcd724f957af0cde94c788c7727-1dc824137ef9effa61761915b3f12cde2c9381c75080406df34ef6d3529bc679.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacob Manaker")]], [#link("https://terrytao.wordpress.com/2026/10/22/simple-and-critical-zeros-of-the-riemann-zeta-function/comment-page-1/#comment-698680")[#strong[#text("Jacob Manaker")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2026")])]

#text("You state that ")#tao-fit-display[#mitex("\\mathcal{H}(1)\\subseteq\\mathcal{S}\\cap\\mathcal{C}")]#text(". But, since you’re not working under RH, I don’t see how we rule out the case of a horizontal line with a single noncritical zero. Is it known to analytic number theorists that if there is a noncritical zero ")#tao-fit-display[#mitex("x+yi")]#text(", then we must also have ")#tao-fit-display[#mitex("\\zeta(1/2+yi)=0")]#text("?")

#text("(Yes, I could have asked this of Claude. But I think it’s worth posting here to inspire human discussion.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/22/simple-and-critical-zeros-of-the-riemann-zeta-function/comment-page-1/#comment-698693")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2026")])]

#text("This may not be the right place to ask this, but let me try (will appreciate responses from knowledgeable folks) : what is the intuitive reasoning behind Riemann’s idea of extending the zeta function from a real argument to a complex one? How did he “guess” that this was indeed needed to get a formula for pi(x) = {#primes <=x}? (Also, the elementary proof of PNT doesn’t use complex analysis though I have no clue how that proof was obtained)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63b49eb890ed710b8c76993bc58baae29a2e3c8cccefffcddbfee8eec8351751-0b5f8ed2fd0af0be5adcb141fe77cbdbe858a8085e65a8f6a868d46e73aa5efe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/10/22/simple-and-critical-zeros-of-the-riemann-zeta-function/comment-page-1/#comment-698695")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2026")])]

#text("I can’t give you a historical account of how Riemann personally had the idea, but here’s one way to motivate things:")

#text("Start with Euler’s proof of the infinitude of primes: for real ")#mi("s>1")#text(" let ")#mi("\\zeta(s) = \\sum_{n\\geq 1} n^{-s} = \\prod_p (1-p^{-s})^{-1}")#text(". As ")#mi("s\\to 1^+")#text(" the sum diverges to infinity, but if there were only finitely many factors the product would remain finite. Now a natural way of handling a product is by taking logarithms and it’s easy to verify from the product that that ")#mi("-\\frac{\\zeta^{\\prime}}{\\zeta}(s) = - \\frac{d}{ds} \\log \\zeta(s) = \\sum_n \\Lambda(n) n^{-s}")#text(" where ")#mi("\\Lambda(n)")#text(" is the von-Mangoldt function, equal to ")#mi("\\log p")#text(" if ")#mi("n")#text(" is a positive power of the prime ")#mi("p")#text(" and zero otherwise.")

#text("Ignoring the (relatively) negligible contribution from the prime powers, we have a sum that looks like ")#mi("\\sum_p \\frac{\\log p}{p^s} \\approx \\frac 1{s-1}")#text(" (I’m being vague on what the approximation is). The sum we want (counting primes up to sum cutoff ")#mi("x")#text(") is ")#mi("\\sum_{p\\leq x} \\log p")#text(", and so we can think of the decreasing weight ")#mi("\\frac1{p^s}")#text(" as a smoother approximation to the ")#emph[#text("sharp cutoff")]#text(" ")#mi("\\mathbf{1}(\\frac n x)")#text(".")

#text("The problem is that the cutoff ")#mi("\\frac1{n^s}")#text(" for real ")#mi("s>1")#text(" is not a good approximation to the sharp cutoff. The approximation above is enough to determine the “logarithmic density”, that is the asymptotics of sums of the type ")#mi("\\sum_{p\\leq x} \\frac 1p")#text(" and ")#mi("\\sum_{p\\leq x} \\frac{\\log p}{p}")#text(", but not actually count the primes.")

#text("However, Fourier analysis comes to the rescue: writing ")#mi("s= \\sigma+it")#text(" with fixed real part ")#mi("\\sigma")#text(", we ")#emph[#text("can")]#text(" express the sharp cutoff as a linear combination of these cutoffs: ")#mi("\\mathbf{1}(\\frac n x) = \\int_{t=-\\infty}^{t=\\infty} (x/n)^{\\sigma + it} \\varphi_\\sigma (t)")#text(". Indeed just write ")#mi("y^{it} = e^{it\\log{y}}")#text(" to see that this is basically an inverse Fourier transform — in other words ")#mi("(y)^{\\sigma} \\varphi_\\sigma(t)")#text(" should be the Fourier transform of ")#mi("\\mathbf{1}(\\log y)")#text(".")

#text("Now Fourier transforms are entire functions, so ")#mi("\\varphi_\\sigma(t)")#text(" is really the value at ")#mi("\\sigma+it")#text(" of a meromorphic function. Now it’s natural to interpret the integral as a countour integral and, if we can continue the zetafunction too, we could shift the contour.")

#text("(For a more modern point of view, the discontinuity of the sharp cutoff makes for very bad decay of its Fourier transform, which makes handling this analysis technically hard. The technical solution is to replace the sharp cutoff with a ")#emph[#text("smooth cutoff")]#text(", that is a smooth function (say of compact support) which approximates it well.)")

#text("(If you want the details of these arguments, I’ll be teaching an open course on Analytic Number Theory starting January; details may be found on my website).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/22/simple-and-critical-zeros-of-the-riemann-zeta-function/comment-page-1/#comment-698729")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("Thanks for this very clear survey. Two possible minor corrections ?")

#text("In (8), the right-hand double sum should run over ")#mi("T<\\gamma,\\gamma^{\\prime}\\le 2T")#text(" rather than ")#mi("0<\\gamma,\\gamma^{\\prime}\\le T")#text(", to match the definition of ")#mi("\\mathcal{Z}(T)")#text(" immediately above (cf. equation (1.4) of arXiv:2501.14545).")

#text("Similarly, in the Lamzouri section, the description of BGST-B’s multiset ")#mi("\\mathcal{Z}(T)")#text(" should presumably use ")#mi("T<\\gamma\\le 2T")#text(" rather than ")#mi("0<\\gamma\\le T")#text(". Lamzouri’s subsequent definition of his own transformed multiset ")#mi("\\mathcal{Z}_T")#text(" using ")#mi("0<\\gamma\\le T")#text(" is correct (cf. arXiv:2609.02882, proof of Theorem 1.1).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/22/simple-and-critical-zeros-of-the-riemann-zeta-function/comment-page-1/#comment-698730")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("Thank you for this great post. Lamzouri’s Remark 3.4 observes that the Montgomery–Taylor constant is optimal within his particular framework. Do you see the most promising route to substantially stronger unconditional proportions as coming from improved pair-correlation estimates, a different Hilbert-space approach, or perhaps information about the zeros beyond pair correlation ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/22/simple-and-critical-zeros-of-the-riemann-zeta-function/comment-page-1/#comment-698751")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("I don’t understand why you need to specify that the narrow vertical box is centered on the critical line; as a consequence of the functional equation, the nontrivial zeros are necessarily symmetric wrt the critical line, so you can simply assume that any box containing them is (or can be made) centered.")
]
