// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/
// Converted to Typst by tao2typ: "2026-10-14T07:01:47.705046+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Random matrices: Universality of ESDs and the circular law", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Random matrices: Universality of ESDs and the circular law")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 August 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/")[#text("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.rutgers.edu/~vanvu/")[#text("Van Vu")]#text(" and I have just uploaded to the ")#link("http://arxiv.org/")[#text("arXiv")]#text(" our new paper, “")#link("http://arxiv.org/abs/0807.4898")[#text("Random matrices: Universality of ESDs and the circular law")]#text("“, with an appendix by ")#link("http://www.math.toronto.edu/manju/")[#text("Manjunath Krishnapur")]#text(" (and some numerical data and graphs by ")#link("http://www.math.rutgers.edu/~matchett/")[#text("Philip Wood")]#text("). One of the things we do in this paper (which was our original motivation for this project) was to finally establish the endpoint case of the ")#link("http://mathworld.wolfram.com/GirkosCircularLaw.html")[#text("circular law")]#text(" (in both strong and weak forms) for random ")#link("http://en.wikipedia.org/wiki/Independent_and_identically-distributed_random_variables")[#text("iid")]#text(" matrices ")#mi("A_n = (a_{ij})_{1 \\leq i,j \\leq n}")#text(", where the coefficients ")#mi("a_{ij}")#text(" are iid random variables with mean zero and unit variance. (The strong circular law says that with probability 1, the empirical spectral distribution (ESD) of the normalised eigenvalues ")#mi("\\frac{1}{\\sqrt{n}} \\lambda_1, \\ldots, \\frac{1}{\\sqrt{n}} \\lambda_n")#text(" of the matrix ")#mi("A_n")#text(" converges to the uniform distribution on the unit circle as ")#mi("n \\to \\infty")#text(". The weak circular law asserts the same thing, but with ")#link("http://en.wikipedia.org/wiki/Convergence_in_probability")[#text("convergence in probability")]#text(" rather than ")#link("http://en.wikipedia.org/wiki/Almost_sure_convergence#Almost_sure_convergence")[#text("almost sure convergence")]#text("; this is in complete analogy with the weak and ")#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/")[#text("strong law of large numbers")]#text(", and in fact this law is used in the proof.) In a ")#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/")[#text("previous paper")]#text(", we had established the same claim but under the additional assumption that the ")#mi("(2+\\eta)^{th}")#text(" moment ")#tao-math("{\\Bbb E} \\left|a_{ij}\\right|^{2+\\eta}", block: false)#text(" was finite for some ")#mi("\\eta > 0")#text("; this builds upon a significant body of earlier work by Mehta, Girko, Bai, Bai-Silverstein, Gotze-Tikhomirov, and Pan-Zhou, as discussed in the ")#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/")[#text("blog article for the previous paper")]#text(".")

#text("As it turned out, though, in the course of this project we found a more general ")#emph[#text("universality principle")]#text(" (or ")#emph[#text("invariance principle")]#text(") which implied our results about the circular law, but is perhaps more interesting in its own right. Observe that the statement of the circular law can be split into two sub-statements:")

#enum(start: 1, 
[#text("(Universality for iid ensembles) In the asymptotic limit ")#mi("n \\to \\infty")#text(", the ESD of the random matrix ")#mi("A_n")#text(" is ")#emph[#text("independent")]#text(" of the choice of distribution of the coefficients, so long as they are normalised in mean and variance. In particular, the ESD of such a matrix is asymptotically the same as that of a (real or complex) gaussian matrix ")#mi("G_n")#text(" with the same mean and variance.")],
[#text("(Circular law for gaussian matrices) In the asymptotic limit ")#mi("n \\to \\infty")#text(", the ESD of a gaussian matrix ")#mi("G_n")#text(" converges to the circular law.")]
)

#text("The reason we single out the gaussian matrix ensemble ")#mi("G_n")#text(" is that it has a much richer algebraic structure (for instance, the real (resp. complex) gaussian ensemble is invariant under right and left multiplication by the ")#link("http://en.wikipedia.org/wiki/Orthogonal_group")[#text("orthogonal group")]#text(" O(n) (resp. the ")#link("http://en.wikipedia.org/wiki/Unitary_group")[#text("unitary group")]#text(" U(n))). Because of this, it is possible to compute the eigenvalue distribution very explicitly by algebraic means (for instance, using the machinery of ")#link("http://en.wikipedia.org/wiki/Orthogonal_polynomials")[#text("orthogonal polynomials")]#text("). In particular, the circular law for complex gaussian matrices (Statement 2 above) was established all the way back in 1967 ")#link("http://www.ams.org/mathscinet-getitem?mr=220494")[#text("by Mehta")]#text(", using an explicit formula for the distribution of the ESD in this case due ")#link("http://www.ams.org/mathscinet-getitem?mr=173726")[#text("to Ginibre")]#text(".")

#text("These highly algebraic techniques completely break down for more general iid ensembles, such as the Bernoulli ensemble of matrices whose entries are +1 or -1 with an equal probability of each. Nevertheless, it is a remarkable phenomenon – which has been referred to as ")#emph[#text("universality")]#text(" in the literature, for instance in this ")#link("http://arxiv.org/abs/math-ph/0603038")[#text("survey by Deift")]#text(" – that the spectral properties of random matrices for non-algebraic ensembles are in many cases asymptotically indistinguishable in the limit ")#mi("n \\to \\infty")#text(" from that of algebraic ensembles with the same mean and variance (i.e. Statement 1 above). One might view this as a sort of “non-Hermitian, non-commutative” analogue of the universality phenomenon represented by the ")#link("http://en.wikipedia.org/wiki/Central_limit_theorem")[#text("central limit theorem")]#text(", in which the limiting distribution of a normalised average")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\overline{X}_n := \\frac{1}{\\sqrt{n}} (X_1 + \\ldots + X_n )")]]

#text("of an iid sequence depends only on the mean and variance of the elements of that sequence (assuming of course that these quantities are finite), and not on the underlying distribution. (The Hermitian non-commutative analogue of the CLT is known as ")#link("http://en.wikipedia.org/wiki/Wigner_semicircle_distribution")[#text("Wigner’s semicircular law")]#text(".)")

#text("Previous approaches to the circular law did not build upon the gaussian case, but instead proceeded directly, in particular controlling the ESD of a random matrix ")#mi("A_n")#text(" via estimates on the ")#emph[#text("Stieltjes transform")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\frac{1}{n} \\log \\left|\\det( \\frac{1}{\\sqrt{n}} A_n - zI )\\right|", block: true)]]

#text("of that matrix for complex numbers z. This method required a combination of delicate analysis (in particular, a bound on the least singular values of ")#mi("\\frac{1}{\\sqrt{n}} A_n - zI")#text("), and algebra (in order to compute and then invert the Stieltjes transform). [As a general rule, and oversimplifying somewhat, algebra tends to be used to control main terms in a computation, while analysis is used to control error terms.]")

#text("What we discovered while working on our paper was that the algebra and analysis could be largely decoupled from each other: that one could establish a universality principle (Statement 1 above) by relying primarily on tools from analysis (most notably the bound on least singular values mentioned earlier, but also Talagrand’s concentration of measure inequality, and a universality principle for the singular value distribution of random matrices due ")#link("http://www.ams.org/mathscinet-getitem?mr=2322123")[#text("to Dozier and Silverstein")]#text("), so that the algebraic heavy lifting only needs to be done in the gaussian case (Statement 2 above) where the task is greatly simplified by all the additional algebraic structure available in that setting. This suggests a possible strategy to proving other conjectures in random matrices (for instance concerning the eigenvalue spacing distribution of random iid matrices), by first establishing universality to swap the general random matrix ensemble with an algebraic ensemble (without fully understanding the limiting behaviour of either), and then using highly algebraic tools to understand the latter ensemble. (There is now a sophisticated theory in place to deal with the latter task, but the former task – understanding universality – is still only poorly understood in many cases.)")

#metadata(none) <tao-770c48e8afe436b80c43>

#text("To oversimplify a little bit, the universality principle we actually establish is the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(". (Universality principle) Let ")#mi("A_n = (a_{ij})_{1 \\leq i,j \\leq n}")#text(" be a random matrix with bounded expected normalised second moment ")#tao-math("{\\Bbb E} \\frac{1}{n^2} \\sum_{i,j=1}^n \\left|a_{ij}\\right|^2", block: false)#text(" such that the normalised coefficients ")#mi("a_{ij} - {\\Bbb E} a_{ij}")#text(" are iid. Then in the limit ")#mi("n \\to \\infty")#text(", the ESD of ")#mi("A_n")#text(" depends only on the ESD of the mean ")#mi("{\\Bbb E} A_n")#text(", and on the variance of the coefficients.")
]

#text("The universality for the circular law (Statement 1) corresponds to the special case ")#mi("{\\Bbb E} A_n = 0")#text(". There are strong and weak versions of this principle, depending on whether one wants the limit to be in the sense of almost sure convergence or convergence in probability, but this is slightly technical and I will not detail it here. In an appendix by Manjunath Krishnapur, the weak version of this universality principle is extended to the setting in which the normalised coefficients are not iid, but remain jointly independent, have variances uniformly bounded above and below, and also obey some technical uniform integrability conditions (e.g. the Pastur condition).")

#text("In the case of the central limit theorem, or for limit theorems for the (necessarily real) eigenvalues of Hermitian or symmetric random matrices, this sort of universality can be obtained via the ")#emph[#text("moment method")]#text(", and is well understood (and known as the “Lindeberg principle”). Consider for instance the situation in the central limit theorem, and more precisely the task of understanding the distribution of the averages ")#mi("\\overline{X}_n")#text(" defined by (1) when the ")#mi("X_n")#text(" are iid with zero mean and finite variance. To show universality of these averages in the limit ")#mi("n \\to \\infty")#text(", it suffices to establish universality for the limits ")#mi("\\lim_{n \\to \\infty} {\\Bbb E} \\overline{X_n}^k")#text(" for ")#mi("k=1,2,3,\\ldots")#text(", basically because a probability measure on the real line with suitable decay at infinity can be uniquely recovered from its moments. (This statement is essentially the dual of the ")#link("http://en.wikipedia.org/wiki/Weierstrass_approximation_theorem")[#text("Weierstrass approximation theorem")]#text(", combined with the ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem")[#text("Riesz representation theorem")]#text(", though there are some technical issues regarding the “suitable decay at infinity” disclaimer.)")

#text("If one expands out the expected moment ")#mi("{\\Bbb E} \\overline{X_n}^k")#text(", one obtains a linear combination of mixed moments of the form")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E} X_{i_1}^{a_1} \\ldots X_{i_j}^{a_j}")]]

#text("for various indices ")#mi("1 \\leq i_1 < \\ldots < i_j \\leq n")#text(" and exponents ")#mi("a_1, \\ldots, a_j > 0")#text(" adding up to k. As long as all the exponents are either 1 or 2, one can use the iid hypothesis to conclude that such moments depend only on the mean and variance of the random variable, and not on any finer properties of the distribution. Thus, to establish universality, it suffices to show that the contribution of all the mixed moments which contain at least one exponent larger than 2 is negligible in the limit ")#mi("n \\to \\infty")#text(". This can be done by rather crude combinatorial upper bounds regarding how many such contributions exist.")

#text("Note that this purely analytical approach did not attempt to actually compute what the limiting moments ")#mi("\\lim_{n \\to \\infty} {\\Bbb E} \\overline{X_n}^k")#text(" were; they only sought to show that such limits were universal. Now, in this case, it is not terribly difficult to perform the enumerative combinatorics and compute these moments exactly, but once we have universality, we can pursue a simpler route: we use universality to swap the iid sequence ")#mi("X_1,\\ldots,X_n")#text(" with an iid gaussian sequence ")#mi("G_1,\\ldots,G_n \\equiv N(0,1)")#text(". The algebraic properties of gaussians then ensure that the averages ")#mi("\\overline{G_n}")#text(" are themselves gaussians N(0,1), and thus converge to a gaussian in the limit; universality then tells us that the same is true for the original iid sequence, thus proving the central limit theorem. (This proof is due ")#link("http://www.ams.org/mathscinet-getitem?mr=1544569")[#text("to Lindeberg")]#text(".)")

#text("A similar argument allows one to establish Wigner’s semicircular law by first reducing it to the case of the gaussian ensemble; see ")#link("http://arxiv.org/abs/math/0508519")[#text("this paper of Chatterjee")]#text(" for a discussion and extensive generalisations. (In this particular case, this route is not all that much simpler than the traditional method of using the enumerative combinatorics of ")#link("http://en.wikipedia.org/wiki/Catalan_numbers")[#text("Catalan numbers")]#text(" to compute the moments directly, or by using the slick machinery of ")#link("http://en.wikipedia.org/wiki/Free_probability")[#text("free probability")]#text(" to clean up the computations, but it still illustrates the basic point that one can establish universality by primarily analytic means before having to understand what the limit actually is.)")

#text("In the case of non-Hermitian random matrix ensembles, such as iid ensembles, the eigenvalues are now complex instead of real, and the moment method no longer gives enough information on the ESD to settle the problem. (For instance, in the case of the circular law, all normalised moments ")#mi("{\\Bbb E} \\frac{1}{n} \\sum_{j=1}^n (\\frac{1}{\\sqrt{n}} \\lambda_j)^k = {\\Bbb E} \\frac{1}{n} \\text{tr} (\\frac{1}{\\sqrt{n}} A_n)^k")#text(" in fact vanish identically in the limit ")#mi("n \\to \\infty")#text(", even though the normalised distribution is clearly not identically zero in the limit. A more fundamental explanation for this phenomenon is that the ESD for non-Hermitian matrices can be unstable with respect to perturbations (due to the presence of ")#link("http://en.wikipedia.org/wiki/Pseudospectrum")[#text("pseudospectrum")]#text("), whereas moments are stable, and so cannot control the ESD on their own.)")

#text("Nevertheless, ")#link("http://www.ams.org/mathscinet-getitem?mr=773436")[#text("Girko observed")]#text(" that the (normalised) ESD of a matrix ")#mi("A_n")#text(" can be computed in a reasonably stable manner from the distribution of its Stieltjes transforms (2) (though the latter are themselves unstable when the least singular value of ")#mi("\\frac{1}{\\sqrt{n}} A_n - zI")#text(" becomes small). Because of this, one can deduce universality for the ESD from a universality property of the Stieltjes transform. (We formalise this statement as a “replacement principle” in our paper.)")

#text("So the remaining task is to show a universal property for the magnitude of the determinant of random matrices such as ")#mi("\\frac{1}{\\sqrt{n}} A_n - zI")#text(". The reason why it is so much more preferable to deal with determinants rather than with eigenvalues is that there are many different and useful ways to try to compute the determinant: as a product of eigenvalues, a product of singular values, as the volume of a parallelopiped, as a cofactor expansion, etc.")

#text("In previous work on the circular law, starting from the breakthrough ")#link("http://www.ams.org/mathscinet-getitem?mr=773436")[#text("paper of Girko")]#text(", this determinant was tackled by expressing it as a product of the singular values of ")#mi("\\frac{1}{\\sqrt{n}} A_n - zI")#text(". The limiting distribution of these values can be determined (with some effort) from the moment method and some non-trivial algebraic computations, but to transfer this limit to that of the determinant, one needed a good rate of convergence in this distribution, as well as control of the least singular value to avoid degeneracy in the product. This required a certain amount of analysis which was first set out rigorously (under some moderately strong hypotheses on the coefficients) ")#link("http://www.ams.org/mathscinet-getitem?mr=1428519")[#text("by Bai")]#text(".")

#text("A recent ")#link("http://www.ams.org/mathscinet-getitem?mr=2322123")[#text("paper of Dozier and Silverstein")]#text(" shows that the limiting distribution of ")#mi("\\frac{1}{\\sqrt{n}} A_n - zI")#text(" enjoys universality under some rather general hypotheses on ")#mi("A_n")#text(" (and also provides an explicit formula for this limit, though we do not need that formula for our arguments). In principle, this gives universality for the determinant and thus for the original ESD of ")#mi("A_n")#text(", but unfortunately the results in that paper do not supply a sufficiently strong rate of convergence to make these arguments rigorous.")

#text("To resolve this, we took a slightly different tack, expressing the magnitude of the determinant as the volume of the parallelopiped generated by its rows, which by the high-school “base times height” formula is then the product of various distances from one row to the subspace spanned by previous rows. The first few terms in this product are easy to understand, but things become difficult for the very last few rows, as the subspace now has very high dimension. Nevertheless, thanks to existing work on the least singular value problem (and in particular, the bounds on this problem contained in our ")#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/")[#text("previous circular law paper")]#text("), one can show that the contribution of the last few rows is in fact negligible. For the bulk of the rows, one can use a classical singular value interlacing inequality going back to Cauchy to control the bulk contribution by the distribution of the singular values, for which the Dozier-Silverstein approach applies. It remains to control the contribution of the intermediate rows which are close, but not too close, to the bottom. Previously, these rows needed a good rate of convergence on the singular values in order to be controlled; but, borrowing a trick from ")#link("http://front.math.ucdavis.edu/math.CO/0411095")[#text("one of our previous papers")]#text(", we applied a very useful ")#link("http://en.wikipedia.org/wiki/Concentration_of_measure")[#text("concentration-of-measure inequality")]#text(" of Talagrand instead to show that the contribution of these rows is negligible also.")

#text("In the appendix by Manjunath Krishnapur, a variant of the Dozier-Silverstein result, which establishes universality (in the weak sense of convergence in probability) without computing the limit for a wider class of random matrices, is established by exploiting an invariance principle ")#link("http://arxiv.org/abs/math/0508519")[#text("of Chatterjee")]#text(" that generalises the Lindeberg trick.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (34)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-31865")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2008")])]

#text("This is a very nice approach, and beautiful results.")

#text("A typo (or missing detail?) in the post: you write")

#text("“in the case of the circular law, all normalised moments ")#mi("{\\Bbb E} \\frac{1}{n} \\sum_{j=1}^n (\\frac{1}{\\sqrt{n}} \\lambda_j)^k = {\\Bbb E} \\frac{1}{n} \\text{tr} (\\frac{1}{\\sqrt{n}} A_n)^k")#text(" in fact vanish identically”.")

#text("They do vanish in the limit as ")#mi("n \\to \\infty")#text(", but not necessarily for finite ")#mi("n")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-31873")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2008")])]

#text("Dear Mark: Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of R.A.")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-31882")[#strong[#text("R.A.")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2008")])]

#text("Dear Prof. Tao,")

#text("when writing about moments determining the measure , you probably meant “bounded” and not “finite”. I think that for instance the log-normal distribution is not determined by its moments (or maybe I am just confusing something?).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-31886")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2008")])]

#text("Dear R.A.: Hmm, good point, I oversimplified that part a bit. I don’t want to get bogged down in technical issues at that point, though, so I’ll just put in a vague disclaimer that one needs to assume the probability distribution “has sufficient decay at infinity” (e.g. subgaussian is certainly OK, and one can probably relax this quite a bit.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-31903")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2008")])]

#text("Regarding R.A.’s point: I don’t recall what the necessary and sufficient decay condition is, although it’s known and in standard references. One easy-to-state sufficient condition is that the moment generating function (i.e. Laplace transform) converges in some neighborhood of 0. Thus exponential decay is already enough.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of weiyu")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-33017")[#strong[#text("weiyu")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2008")])]

#text("I am reading and trying to understand and learn from this paper. I just have a few minor questions. Can you explain a little more here?")

#text("In equation (16), why do we have “some smooth, rapidly decreasing function \\hat(f)” and why the measure “du=\\hat(f)du dv” is finite?")#linebreak()#text(" Should the A_n in the second integral be B_n?")

#text("Are the brackets in equation (8) (or in Theorem 1.22) put in the right way?")#linebreak()#text(" In equation (19), the denominator in the integral may be “|s+it-w|^2”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-33030")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2008")])]

#text("Dear Weiyu,")

#text("Thanks for the corrections! In (8), there should be additional parentheses around ")#mi("(\\frac{1}{\\sqrt{n}} A_n - zI)^* + \\epsilon_n I")#text(".")

#text("In (16), ")#mi("\\hat f")#text(" is basically the Fourier transform of f (we are using Parseval’s identity here). The Fourier transform of a smooth compactly supported function is smooth and rapidly decreasing (indeed, both f and ")#mi("\\hat f")#text(" are Schwartz functions).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of From the Littlewood-Offord problem to the Circular Law: universality of the spectral distribution of random matrices « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-33108")[#strong[#text("From the Littlewood-Offord problem to the Circular Law: universality of the spectral distribution of random matrices « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2008")])]

#text("[…] to the circular law for the ESDs for iid random matrices with zero mean and unit variance (see my previous blog post on this topic, or my Lewis lectures). We conclude by mentioning a few open problems in the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of weiyu")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-33269")[#strong[#text("weiyu")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2008")])]

#text("Dear Professor Tao,")#linebreak()#text(" I guess in Proposition 5.1, $d$ should be [1, n-n^0.99], instead of [1,n-n^0.9] . The exponent 0.9 certainly implies the result for the exponent 0.99, but in the proof, when we do the projection from C^n->C^{n’} (the equation 32) and be “adjusting c slightly”, the exponent 0.9 does not seem to go through. From the context, it also seems to be 0.99. Hope I did not get it wrong")

#text("In using Talagrand’s inequality, do we implicitly assume that as n grows, the “median” be approaching the square root of the “expected second moments”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-33271")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2008")])]

#text("Dear Weiyu,")

#text("Thanks for the correction! Talagrand’s inequality implies in particular that the root mean square is necessarily close to the median, and so bounding one is equivalent (up to constants) to bounding the other.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of weiyu")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-33395")[#strong[#text("weiyu")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2008")])]

#text("Dear Professor Tao,")

#text("Thanks for the previous answers and they help a lot.")#linebreak()#text(" I have one additional question left. In the proof of Lemma 6.3., can you explain in further details how the interlacing property leads to the euqation right below equation (37)? I am not sure I understand this part or understand correctly.")

#text("Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-33397")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2008")])]

#text("Dear weiyu,")

#text("Let’s start with the base case ")#mi("n^{\\prime}=n-1")#text(". From the interspersing relation")

#mi("\\lambda_1 \\leq \\lambda^{\\prime}_1 \\leq \\lambda_2 \\leq \\ldots \\leq \\lambda^{\\prime}_{n-1} \\leq \\lambda_n")

#text("we see that for any function f, the difference between ")#mi("\\sum_{i=1}^n f(\\lambda_i)")#text(" and ")#mi("\\sum_{i=1}^{n^{\\prime}} f(\\lambda^{\\prime}_i)")#text(" is bounded in magnitude by the total variation of f, plus the maximum value of f. This gives an error term of the form ")#mi("O_\\varepsilon(1/n)")#text(" in the equation below (37). Iterating this, we see that when ")#mi("n^{\\prime} \\approx (1-\\delta) n")#text(", the total error is about ")#mi("O_\\varepsilon(\\delta)")#text(", which is ")#mi("O(\\varepsilon)")#text(" when ")#mi("\\delta")#text(" is small enough.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbd6aebbf6f61679c9cf2d33d05a72948d3919a340cae7e578edeff50f1cb44f-217fcb24f7aee6512ae32052c9f7892f503348788d27eb66e625298f1aebdc67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Jiang")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-33748")[#strong[#text("John Jiang")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2008")])]

#text("Dear Professor Tao,")#linebreak()#text(" I am wondering how the circular law will be different if one restricts to real valued gaussian iid entries. Does the same approach of Girko’s lemma work in that case? Also have you thought about singular values of iid complex Gaussian square matrices? I know their limiting spectral measure obey the quadrant law, which is the first quadrant of the unit disk on the complex plane, but as far as I know there are no rigorous proofs of this result yet.")

#text("Thanks,")#linebreak()#text(" John")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-33768")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2008")])]

#text("Dear John,")

#text("The circular law is valid for all complex iid matrices with zero mean and unit variance, which includes the real-valued gaussian case (for which the circular law was first worked out by Edelman).")

#text("For singular values of iid matrices the universality principle is much easier to establish (because in this case the bulk distribution can be worked out from the moment method), and indeed we rely on a paper of Dozier and Silverstein which more or less does exactly this (as does the paper of Chatterjee that we also use). In particular, the distribution of the singular values of an iid matrix will depend only on the mean and variance of the entries.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2739898e1a9931c3d814276e200f9243b28ef9dac889d309e3c176d860a68935-d27dddf3e295eac8b06b07553017354f9e1e00f60df1bdec7fde5985d94e4b2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bobo")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-33778")[#strong[#text("bobo")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2008")])]

#text("Dear Prof Tao,")

#text("i have x in C^n complex gaussian vector and X=x*x’ form Hermitian")#linebreak()#text(" matrix with rank 1. eign distribution of X can be evaluated with")#linebreak()#text(" Wishard Distribution.")#linebreak()#text(" But i would like to know.. the spacing distribution of two consecutive")#linebreak()#text(" eigenvalues. could you pls point me the reference..")

#text("thanks,")#linebreak()#text(" bobo")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-35390")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2009")])]

#text("Dear Prof Tao,")

#text("I’m trying to understand and learn form this paper. I have some minor questions during the reading, could you please give a little more details?")

#text("In (22), how can I see the inner integrand is bounded by an explicit upper bound of Pi and the “inequality” below (26) should \\lamda be the absolute value of \\lamda?")

#text("I guess it should be n^2 instead of n in (13) and B_n instead of A_n in (16).")#linebreak()#text(" Also, in (17) I think we are taking the real part of the summation.")

#text("Thanks,")#linebreak()#text(" Ricky")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-35398")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2009")])]

#text("Dear Ricky,")

#text("Thanks for the corrections!")

#text("The upper bound in (22) stems from the classical Poisson integral identity ")#mi("\\int_{-\\infty}^\\infty \\frac{a}{a^2+(x-x_0)^2}\\ dx = \\pi")#text(", which can be seen by a trigonometric substitution. (The ")#mi("e^{ius+ivt} (1-\\psi(t/R^2))")#text(" term has magnitude at most 1 and can be discarded.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b482f13fdf1b2b152f5524156505b1698bc7c22af17c063900f8d049249ef486-e798f25c2f45a6ce4be197648a2e6af48467871c7436a7ad2203d3bb078143d8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-35476")[#strong[#text("Paul")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2009")])]

#text("Dear Professor Tao,")

#text("When trying to understand the new techniques in your paper, there is a minor point I could not get. To show the strong boundedness of the empirical spectral distribution (Lemma 1.11), the strong law of large numbers is required. It seems to me that we need such a law for triangular arrays of random variables, which does not exit in full generality. How do you circumvent this ?")

#text("Thank you,")

#text("Paul")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-35478")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2009")])]

#text("Dear Paul,")

#text("The expression ")#tao-math("\\frac{1}{n^2} \\left\\| X_n\\right\\|_2^2 = \\frac{1}{n^2} \\sum_{i=1}^n \\sum_{j=1}^n \\left|x_{ij}\\right|^2", block: false)#text(" is the average of ")#mi("n^2")#text(" iid copies of a single random variable ")#tao-math("\\left|x\\right|^2", block: false)#text(". By a suitable relabeling one can rewrite this expression as ")#mi("\\frac{1}{n^2} \\sum_{k=1}^{n^2} y_k")#text(", where ")#mi("y_1, y_2, \\ldots")#text(" are iid copies of ")#tao-math("\\left|x\\right|^2", block: false)#text(" (and such that ")#mi("y_1,\\ldots,y_{m^2}")#text(" correspond to the ")#tao-math("\\left|x_{ij}\\right|^2", block: false)#text(" for ")#mi("1 \\leq i,j \\leq m")#text("). From the strong law of large numbers we know that ")#mi("\\frac{1}{N} \\sum_{k=1}^{N} y_k")#text(" is a.s. bounded (and even convergent), and so ")#mi("\\frac{1}{n^2} \\sum_{k=1}^{n^2} y_k")#text(" is also a.s. bounded.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b482f13fdf1b2b152f5524156505b1698bc7c22af17c063900f8d049249ef486-e798f25c2f45a6ce4be197648a2e6af48467871c7436a7ad2203d3bb078143d8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-35480")[#strong[#text("Paul")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2009")])]

#text("Dear Professor Tao,")

#text("Thank you for your answer. The strong law of large numbers means that")#linebreak()#text(" ")#mi("\\frac{1}{N} \\sum_{k=1}^{N} y_k")#text(" converges almost surelay, as you say. My impression here was that we need a strong law of large numbers for sums like ")#mi("\\frac{1}{N} \\sum_{k=1}^{N} y^{(N)}_k")#text(", where the $y^{(N)}_k$’s are iid but all distinct when $N$ changes.")

#text("Best,")

#text("Paul")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b482f13fdf1b2b152f5524156505b1698bc7c22af17c063900f8d049249ef486-e798f25c2f45a6ce4be197648a2e6af48467871c7436a7ad2203d3bb078143d8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-35481")[#strong[#text("Paul")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2009")])]

#text("Sorry, I just realized that the entries ")#mi("x_{ij}")#text(" are conserved for all ")#mi("n>max(i,j)")#text(", thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-35623")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("Dear Professor Tao,")

#text("Thanks for your previous answer, it’s very helpful! I’m not quite sure the meaning of the symbol in the equation right below (26) which looks like a inequality sign and I’m also confused about the right hand side of that equation. Could you specify this a little more?")

#text("Thank you,")

#text("Ricky")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-35628")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("The equation ")#mi("X \\lesssim_{\\phi_{u,v,R}} Y")#text(" below (26) should read ")#mi("X \\leq O_{\\phi_{u,v,R}}(Y)")#text(" (we changed the notation at some point from ")#mi("\\lesssim")#text("‘s to O()’s, but I guess this particular equation managed to somehow survive the switch). The estimate is a fairly crude one, basically reflecting the fact that")

#tao-math("\\int_{\\left|s\\right|, \\left|t\\right| = O(1)} \\log \\left| z - (s+it) \\right|^2\\ ds dt = O( \\log^2 (2 + \\left|z\\right| ) ) = O( 1 + \\left|z\\right|^2 )", block: false)#text(".")

#text("(The first estimate comes from the local integrability of ")#mi("\\log^2")#text(" in the plane.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A sharp inverse Littlewood-Offord theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-35912")[#strong[#text("A sharp inverse Littlewood-Offord theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("[…] 16 February, 2009 in math.CO, math.PR, paper | Tags: generalised arithmetic progressions, Littlewood-Offord theorems, random walks, Van Vu | by Terence Tao Van Vu and I have just uploaded to the arXiv our preprint “A sharp inverse Littlewood-Offord theorem“, which we have submitted to Random Structures and Algorithms. This paper gives a solution to the (inverse) Littlewood-Offord problem of understanding when random walks are concentrated in the case when the concentration is of polynomial size in the length of the walk; our description is sharp up to epsilon powers of . The theory of inverse Littlewood-Offord problems and related topics has been of importance in recent developments in the spectral theory of discrete random matrices (e.g. a “robust” variant of these theorems was crucial in our work on the circular law). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-36263")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2009")])]

#text("Dear Professor Tao,")

#text("Could you please explain more about how you get the equation right before (23), I specially want to know what role did “|w|<=R” play here.")

#text("Thank you")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-36266")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2009")])]

#text("Dear anonymous,")

#text("The assumption ")#tao-math("\\left|w\\right| \\leq R", block: false)#text(" ensures (in conjunction with the presence of the cutoff ")#mi("1 - \\psi(t/R^2)")#text(") that the denominator ")#mi("w - (s+it)")#text(" is large (of size at least ")#mi("R^2")#text("). Now we integrate by parts, integrating the ")#mi("e^{ivt}")#text(" term many times (four times will suffice) and differentiating all the other terms. When the derivative falls on the cutoff ")#mi("1 - \\psi(t/R^2)")#text(" one essentially gains a factor of ")#mi("1/R^2")#text("; and similarly when the derivative falls on ")#tao-math("\\text{Re}(w-(s+it))/\\left|w-(s+it)\\right|^2", block: false)#text(", due to the separation between t and w. (In fact one can continue integrating by parts indefinitely and get a bound of ")#mi("O(R^{-C})")#text(" for any C.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-38151")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2009")])]

#text("Dear Professor Tao,")

#text("Thanks for your previous answer.")

#text("To see equation(24)on page 20: I tried to break the eigenvalues of")#linebreak()#text(" A_n (say \\lamda_j ) into two cases: i) |\\lamda_j \\leq R ii) |\\lamda_j|>R.")#linebreak()#text(" By part ii) of lemma 3.4 and 17), the triangle inequality")#linebreak()#text(" we have (24) is O(\\epsilon) when i) holds and there’s no question about that.")#linebreak()#text(" For case ii), I think we need to get a upper bound of (22) which is")#linebreak()#text(" independent of R, because (22) is O(\\epsilon)only when R is large enough.")#linebreak()#text(" Then one can use (21) and triangle inequality to get (24) is O(\\epsilon) in this case too, which implies the claim of (24). But unfortunately I haven’t worked it out so far.")#linebreak()#text(" could you please give a little more details about this?")

#text("Thank you")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-38155")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2009")])]

#text("Dear anonymous,")

#text("The bounds (23), (24) are only proven under the assumption that R is sufficiently large depending on epsilon, but as one can choose R to be whatever one pleases, this is all one needs anyway (note that the convergence of (25) is going to be established for every R).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random matrices: universality of local eigenvalue statistics « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-39170")[#strong[#text("Random matrices: universality of local eigenvalue statistics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2009")])]

#text("[…] are based primarily on the Lindeberg replacement strategy, which Van and I also used to obtain universality for the circular law for iid matrices, and for the least singular value for iid matrices, but also rely on other tools, such as some […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student A")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-40716")[#strong[#text("Student A")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2009")])]

#text("Dear Prof. Tao,")

#text("do you have a quick argument, proving that the normalized spectral moments of non-Hermitian randm matrix ensembles converge to zero identically?")

#text("Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-40724")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2009")])]

#text("Well, for ensembles such as the random complex gaussian matrix A, one can use the invariance of the distribution under the phase rotation ")#mi("A \\mapsto e^{i\\theta} A")#text(" to show that all moments ")#mi("\\text{tr} A^k")#text(" must have zero expectation.")

#text("For more general ensembles (e.g. random Bernoulli), I think one can just work out the moments by hand and see that they are quite small. For instance working out the normalised moments ")#mi("{\\Bbb E} \\frac{1}{n} (\\text{tr} \\frac{1}{\\sqrt{n}} A)^k")#text(" for A Bernoulli and k=1,2,3,4 is quite instructive.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24e4f0acbdcc91b2c7ba7aa365b93230645de6434c5bb00b576cb2e5b7b4b5d4-c613a49f867fec7449a638a997a449750baa68478c75c7b8283270fc50513284.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Peccati")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-40998")[#strong[#text("Giovanni Peccati")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2009")])]

#text("Dear Terence,")

#text("some joint CLTs for traces of non-Hermitian random matrices, which have a somewhat ”universal” flavour, are contained in a recent paper by I. Nourdin and myself")

#link("http://arxiv.org/abs/0908.0391")[#text("http://arxiv.org/abs/0908.0391")]

#text("All the best,")

#text("Giovanni")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The circular law « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-43883")[#strong[#text("254A, Notes 8: The circular law « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2010")])]

#text("[…] This theorem has a long history; it is analogous to the semi-circular law, but the non-Hermitian nature of the matrices makes the spectrum so unstable that key techniques that are used in the semi-circular case, such as truncation and the moment method, no longer work; significant new ideas are required. In the case of random gaussian matrices, this result was established by Mehta (in the complex case) and by Edelman (in the real case), as was sketched out in Notes. In 1984, Girko laid out a general strategy for establishing the result for non-gaussian matrices, which formed the base of all future work on the subject; however, a key ingredient in the argument, namely a bound on the least singular value of shifts , was not fully justified at the time. A rigorous proof of the circular law was then established by Bai, assuming additional moment and boundedness conditions on the individual entries. These additional conditions were then slowly removed in a sequence of papers by Gotze-Tikhimirov, Girko, Pan-Zhou, and Tao-Vu, with the last moment condition being removed in a paper of myself, Van Vu, and Manjunath Krishnapur. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Local universality of zeroes of random polynomials | What's new")]], [#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/#comment-238973")[#strong[#text("Local universality of zeroes of random polynomials | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2013")])]

#text("[…] paper (and can be viewed as a local-scale version of the global-scale replacement principle in this earlier paper of ours). Specialising the replacement principle to the elliptic or flat polynomials, and using the […]")
]
