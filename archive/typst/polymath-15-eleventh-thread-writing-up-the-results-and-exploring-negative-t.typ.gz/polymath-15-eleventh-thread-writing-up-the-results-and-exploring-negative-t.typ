// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/
// Converted to Typst by tao2typ: "2026-10-14T16:38:30.605576+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath15, eleventh thread: Writing up the results, and exploring negative t", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath15, eleventh thread: Writing up the results, and exploring negative t")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 December 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/")[#text("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is the eleventh research thread of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("Polymath15 project")]#text(" to upper bound the ")#link("https://en.wikipedia.org/wiki/De_Bruijn%E2%80%93Newman_constant")[#text("de Bruijn-Newman constant")]#text(" ")#mi("{\\Lambda}")#text(", continuing ")#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/")[#text("this post")]#text(". Discussion of the project of a non-research nature can continue for now in ")#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/")[#text("the existing proposal thread")]#text(". Progress will be summarised at ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("this Polymath wiki page")]#text(".")

#text("There are currently two strands of activity. One is writing up the paper describing the combination of theoretical and numerical results needed to obtain the new bound ")#mi("\\Lambda \\leq 0.22")#text(". The latest version of the writeup may be found ")#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/Writeup/debruijn.pdf")[#text("here")]#text(", in ")#link("https://github.com/km-git-acc/dbn_upper_bound/tree/master/Writeup")[#text("this directory")]#text(". The theoretical side of things have mostly been written up; the main remaining tasks to do right now are")

#enum(start: 1, 
[#text("giving a more detailed description and illustration of the two major numerical verifications, namely the barrier verification that establishes a zero-free region for ")#mi("H_t(x+iy)=0")#text(" for ")#tao-math("0 \\leq t \\leq 0.2, 0.2 \\leq y \\leq 1, \\left|x - 6 \\times 10^{10} - 83952\\right| \\leq 0.5", block: false)#text(", and the Dirichlet series bound that establishes a zero-free region for ")#mi("t = 0.2, 0.2 \\leq y \\leq 1, x \\geq 6 \\times 10^{10} + 83952")#text("; and")],
[#text("giving more detail on the conditional results assuming more numerical verification of RH.")]
)

#text("Meanwhile, several of us have been exploring the behaviour of the zeroes of ")#mi("H_t")#text(" for negative ")#mi("t")#text("; this does not directly lead to any new progress on bounding ")#mi("\\Lambda")#text(" (though there is a good chance that it may simplify the proof of ")#mi("\\Lambda \\geq 0")#text("), but there have been some interesting numerical phenomena uncovered, as summarised in ")#link("https://drive.google.com/file/d/13a1wAsyf99DR272XmMKpRFC2ZoEWYJBq/view")[#text("this set of slides")]#text(". One phenomenon is that for large negative ")#mi("t")#text(", many of the complex zeroes begin to organise themselves near the curves")

#align(center)[#tao-fit-display[#mitex("y = -\\frac{t}{2} \\log \\frac{x}{4\\pi n(n+1)} - 1.")]]

#text("(An example of the agreement between the zeroes and these curves may be found ")#link("https://drive.google.com/file/d/1uMsz5gZSD6HbaiPAcFN5ZMWPesdu0g3d/view?usp=sharing")[#text("here")]#text(".) We now have a (heuristic) theoretical explanation for this; we should have an approximation")

#align(center)[#tao-fit-display[#mitex("H_t(x+iy) \\approx B_t(x+iy) \\sum_{n=1}^\\infty \\frac{b_n^t}{n^{s_*}}")]]

#text("in this region (where ")#mi("B_t, b_n^t, n^{s_*}")#text(" are defined in equations (11), (15), (17) of the ")#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/Writeup/debruijn.pdf")[#text("writeup")]#text(", and the above curves arise from (an approximation of) those locations where two adjacent terms ")#mi("\\frac{b_n^t}{n^{s_*}}")#text(", ")#mi("\\frac{b_{n+1}^t}{(n+1)^{s_*}}")#text(" in this series have equal magnitude (with the other terms being of lower order).")

#text("However, we only have a partial explanation at present of the interesting behaviour of the real zeroes at negative t, for instance the surviving zeroes at extremely negative values of ")#mi("t")#text(" appear to lie on the curve where the quantity ")#mi("N")#text(" is close to a half-integer, where")

#tao-aligned(keep: true)[


#tao-math("\\tilde x  & := x + \\frac{\\pi t}{4}", block: true)



#tao-math("N  & := \\sqrt{\\frac{\\tilde x}{4\\pi}}", block: true)
]

#text("The remaining zeroes exhibit a pattern in ")#mi("(N,u)")#text(" coordinates that is approximately 1-periodic in ")#mi("N")#text(", where")

#align(center)[#tao-fit-display[#tao-math("u := \\frac{4\\pi \\left|t\\right|}{\\tilde x}.", block: true)]]

#text("A plot of the zeroes in these coordinates (somewhat truncated due to the numerical range) may be ")#link("https://drive.google.com/file/d/101wtC7VyM9aHTst2F-X1Xf62FQT0m6e9/view")[#text("found here")]#text(".")

#text("We do not yet have a total explanation of the phenomena seen in this picture. It appears that we have an approximation")

#align(center)[#tao-fit-display[#tao-math("H_t(x) \\approx A_t(x) \\sum_{n=1}^\\infty \\exp( -\\frac{\\left|t\\right| \\log^2(n/N)}{4(1-\\frac{iu}{8\\pi})} - \\frac{1+i\\tilde x}{2} \\log(n/N) )", block: true)]]

#text("where ")#mi("A_t(x)")#text(" is the non-zero multiplier")

#align(center)[#tao-fit-display[#mitex("A_t(x) := e^{\\pi^2 t/64} M_0(\\frac{1+i\\tilde x}{2}) N^{-\\frac{1+i\\tilde x}{2}} \\sqrt{\\frac{\\pi}{1-\\frac{iu}{8\\pi}}}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("M_0(s) := \\frac{1}{8}\\frac{s(s-1)}{2}\\pi^{-s/2} \\sqrt{2\\pi} \\exp( (\\frac{s}{2}-\\frac{1}{2}) \\log \\frac{s}{2} - \\frac{s}{2} )")]]

#text("The derivation of this formula may be found in ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem#Large_negative_values_of_.5Bmath.5Dt.5B.2Fmath.5D")[#text("this wiki page")]#text(". However our initial attempts to simplify the above approximation further have proven to be somewhat inaccurate numerically (in particular giving an incorrect prediction for the location of zeroes, as seen in ")#link("https://drive.google.com/file/d/15Z45HHQWhBA-MT2g335cVpEzWrnqjBeu/view")[#text("this picture")]#text("). We are in the process of using numerics to try to resolve the discrepancies (see ")#link("https://github.com/km-git-acc/dbn_upper_bound/issues/126")[#text("this page")]#text(" for some code and discussion).")

#heading(level: 1)[#text("Comments (78)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509642")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2018")])]

#text("In order to understand the approximation numerical errors, it seems that a sufficiently good upper bound on the approximation error is needed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95f817915d852118c2db29947edd1f0232e34af1da29fce284382b8d2c7693dd-c5b61708c0ddc7fbbb44307dda379ff58b8a251c9a58d151d7df61c10d12963d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jim Cohen")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509646")[#strong[#text("Jim Cohen")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2018")])]

#text("Why is research always in quotes?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509658")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2018")])]

#text("Polymath projects typically have some posts designated as “research” threads and other posts designated as “discussion” threads, though in this case we have not created a dedicated “discussion” thread, using the (very low-traffic) proposal post instead for this purpose. The volume of discussion in the research thread is currently low enough that one is welcome to also have non-technical discussion of the project in this post intermingled with the research, but for some other projects it was useful to keep the two separate. But since the quotes could be misinterpreted, I have now removed them.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509647")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2018")])]

#text("In ")#mi("A_t(x)")#text(" above, I believe the exponent in the first factor should be ")#tao-math("-\\pi^2\\left|t\\right|/64", block: false)#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509648")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2018")])]

#text("Ignore my comment. You dropped the abs(t), and the domain is -t.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd7f0c7c0d4fbfecc9fe20ed6b17df9e9642328cf3bf3ea4d587717f9811b07a-375a0ba6bb3e036e615a8b50ca670ac553d9c235f2265cf371b6f3d3729e44ff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of varjakBaby")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509650")[#strong[#text("varjakBaby")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2018")])]

#text("Such arbitrary bounds. So interesting.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509662")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2018")])]

#text("One can trace the provenance for various of these factors. Following Csordas-Smith-Varga, the function ")#mi("H_0(ix)")#text(" is defined as")

#mi("\\displaystyle H_0(ix) = \\frac{1}{8} \\xi( \\frac{1+ix}{2} )")

#text("which already explains the 1/8 factor in the ")#mi("M_0")#text(" multiplier and the presence of the quantity ")#mi("\\frac{1+ix}{2}")#text(". The Riemann xi function is defined as")

#mi("\\displaystyle \\xi(s) = \\frac{s(s-1)}{2} \\pi^{-s/2} \\Gamma(s/2) \\zeta(s)")

#text("which when combined with the Stirling approximation")

#mi("\\Gamma(z) \\approx \\sqrt{2\\pi} \\exp( (z-\\frac{1}{2}) \\log z - z)")

#text("explains the rest of the ")#mi("M_0")#text(" factor. The Gamma factor ")#mi("M_0(\\frac{1+ix}{2})")#text(" decays exponentially in the ")#mi("x")#text(" variable, like ")#mi("e^{-\\pi x/8}")#text(" (this is ultimately because the logarithm in the Stirling approximation has an imaginary part close to ")#mi("\\pi/2")#text(". The effect of this decay when applying the heat flow for time ")#mi("t")#text(" is to essentially recenter the zeta function term from ")#mi("\\frac{1+ix}{2}")#text(" to ")#mi("\\frac{1+i\\tilde x}{2}")#text(" (and is also responsible for the ")#mi("e^{t (\\pi/8)^2} = e^{\\pi^2 t/64}")#text(" term in the multiplier). If one formally writes")

#mi("\\displaystyle \\zeta(\\frac{1+i\\tilde x}{2}) = \\sum_{n=1}^\\infty \\frac{1}{n^{\\frac{1+i\\tilde x}{2}}}")

#text("one can see the ")#mi("\\exp( \\frac{1+i\\tilde x}{2} \\log n )")#text(" term emerge. As it turns out this sum is concentrated around ")#mi("n=N")#text(", so we have renormalised by ")#mi("N")#text(" leading to the various appearances of ")#mi("N")#text(" in the approximation. The heat flow applied to each summand also gives the exponential correction ")#tao-math("\\exp( -\\frac{\\left|t\\right|\\log^2(n/N)}{4(1-iu/8\\pi)} )", block: false)#text(" and the Gaussian integral ")#mi("\\sqrt{\\frac{\\pi}{1-iu/8\\pi}} = \\int_{-\\infty}^\\infty e^{-(1-iu/8\\pi) v^2}\\ dv")#text(". (The ")#mi("iu/8\\pi")#text(" term comes from a contribution of the second derivative of the logarithm of the ")#mi("M_0")#text(" factor, arising from the fact that ")#mi("M_0")#text(" is not simply an exponentially decaying weight but also has a phase that is roughly of the form ")#mi("e^{ \\frac{i}{4} x \\log \\frac{x}{4\\pi}}")#text("; this phase is also the source of the Riemann-von Mangoldt formula for the distribution of zeroes of the zeta function).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509656")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2018")])]

#text("In the multiplier should both x have tilde?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509659")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2018")])]

#text("No; the ")#mi("M_0(\\frac{1+ix}{2})")#text(" factor arises before a certain change of variables is made (which effectively shifts ")#mi("x")#text(" to ")#mi("\\tilde x")#text("), while the ")#mi("N^{-\\frac{1+i\\tilde x}{2}}")#text(" term emerges after this change of variables.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509660")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2018")])]

#text("then Ht318 in ")#link("https://github.com/km-git-acc/dbn_upper_bound/issues/126")[#text("https://github.com/km-git-acc/dbn_upper_bound/issues/126")]#text(" has a mistake")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509691")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2018")])]

#text("Bit confused now. On the Wiki-page the change of variables already occurs in 3.4 and ")#mi("M0")#text(" is ‘carved out’ later in 3.8 using the ")#mi("\\tilde x")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509721")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2018")])]

#text("Oops, you were right; my previous comment was mistaken. I have corrected the post accordingly.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6803f451a822a44c3357dffe0946273ac8b678c1381d8f6f15471f78bf5064e-c0cdd6fbf9fa11cb38f669d32e0c33214ced4ab5f9e837265aa2a25f482e13f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of BR")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509715")[#strong[#text("BR")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2018")])]

#text("These recent observations about zeros at negative t are really interesting. How accurately are the locations of zeros being computed in the graphs on page 8 of the slides (i.e. how many decimal places)? It’s hard to make an eyeball judgement, but considering each family of zeros in isolation, is the spacing between zeros (or real parts of zeros) relatively rigid (like a picket fence, up to renormalization)? By contrast for sufficiently large x, if all the real parts of zeros are considered together, do the gaps between real parts start to resemble poisson type spacings (that is would a histogram have exponential distribution)?")

#text("Letting x_k(t) be these real parts it could be interesting to make some tables of x_{k+1}-x_k, both along some fixed family (say n=1), and also for all zeros together. (And indeed it may be more natural to consider some nice deformation of x_k, depending on which family the zero lies in…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509728")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2018")])]

#text("The zeros on page 8 of the slides have been computed at 4 decimals accuracy. The spacings between the zeros indeed seem rather rigid (esp. on or near the outer curves). ")#link("https://drive.google.com/file/d/14sC-LrpVJ7F9RfS4WvV8hhAqcYO-sE0k/view?usp=sharing")[#text("Here ")]#text(" is the data used. Note that I am not claiming that all zeros have been found exhaustively.")

#text("To obtain more data points, I am currently establishing the complex roots for a wider range of x (up to 5000) for ")#mi("t=-90")#text(". Will post the results together with the data once ready.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a778b2ba58f0a83758d062a31b82125493a164e454bac4ed73a5f0b4cb8b8e89-caa1cd9f5051dd9589cb04a35a3d8e1d4fec68bd79393a9eb54194c68326ea90.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of BR")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-511279")[#strong[#text("BR")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2019")])]

#text("Here is a histogram of (unrenormalized) spacings between the real parts of zeros of H_t (up to x = 5000, with t=-90).")

#link("https://i.ibb.co/1KFQDv0/1038-H-t.jpg")[#image("../assets/546245b864c1fbd12d38e5784bd39c862e3ad6b31f26103b41ce498dc802bcd8-20bdcb3d30196568240dcbb283fb0072f0e4d6492fb93a643613a310d383e459.jpg", width: 90%)]

#text("This was done using mathematica. Unfortunately the pattern is not so discernible. In blue is the exponential prediction. It may be that the data converges to this pattern very slowly, but there does seem to be a rather long tail…")

#text("(The large number of spacings in the very last bin all have size around 18.13; at first I thought this was a mistake, but this is the spacing between zeros on the first n=1 curve, and is as large a gap as one can have. Note that 4*Pi/log(2) is roughly 18.13, so this is in excellent agreement with the Remark 2.1 in the sharkfin ms the polymath prepared.)")

#text("By comparison, here is a histogram of (unrenormalized) spacings between zeros of H_0, and the Montgomery-Odlyzko prediction (I took the same number of zeros which ends up being up to just x = 3500). The convergence is fairly fast.")

#link("https://i.ibb.co/vXthcb0/1038-zeta.jpg")[#image("../assets/0d429c51773a9111d8e0171c0ccd712ade81203baf5ef37d00fd8e449739ea29-748a237bd518bb27e84f738ab3dc9ef3cde7754a43e7d6969056cc8f91b56ffb.jpg", width: 90%)]

#text("It could also be that spacings between real parts of H_t is not quite the ‘right’ object to look at, since zeros won’t follow a straight trajectory down to the real axis. (I am not sure if there is a rough description of the trajectory, up to some oscillating error term?)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509758")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2018")])]

#text("I tried reproducing ")#link("https://drive.google.com/file/d/15Z45HHQWhBA-MT2g335cVpEzWrnqjBeu/view")[#text("this picture")]#text(" and I got ")#link("https://i.imgur.com/HFR1F9I.png")[#text("this")]#text(". Green pixels show sign changes of the real part of the 3.18 approximation with multiplier. Red shows sign changes of 3.26 without multiplier. The functions are evaluated only once per pixel so it’s possible that some roots are missed. The 3.18 approximation uses 1000 summation terms and does not account for truncation error.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509862")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#text("Nice! It appears you have gotten a stable evaluation of 3.26 and it fits well with the earlier plots where we found a match with the straight lines. The key thing that still seems to be missing is that the zeros of ")#mi("\\Theta")#text(" should also ‘catch’ the curves between these lines. We now know this is still the case at eq. 3.18 however somehow this information gets lost in the next few equations.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509958")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2018")])]

#text("Attached are a few slides in ")#link("https://drive.google.com/file/d/1_W457QTRdjwQZcAyTHU7kQt-l7fkif19/view?usp=sharing")[#text("PPT")]#text(" and ")#link("https://drive.google.com/file/d/1oJq-RcGiX5nDEaxKMqjVsl8RBgYOmpAA/view?usp=sharing")[#text("PDF")]#text(" that aim to visualise the behaviour of the complex zeros of ")#mi("H_t(x+iy)")#text(" at ")#mi("t = -90")#text(" for ")#mi("x=20...5000")#text(".")

#text("The fit with the curves, I’ve now used the ‘effective model’ formula to compute these more accurately, is excellent especially on the outer (lower ")#mi("n")#text(") curves.")

#text("What might be a new phenomenon is that the zeros closer to the real line appear to behave in waves whose frequency increases and amplitude decreases compared to zeros on curves with a lower ")#mi("n")#text(".")

#text("I have also included a rather “suggestive” visual that illustrates a possible correlation between the values of the curves at ")#mi("y=0")#text(" and the starts of the straight real zero trajectories at ")#mi("t=-90")#text(".")

#text("Below are the links to the data used (both in t,x,y csv-format). Again, I am not claiming to have found all complex zeros in this domain, some could have been missed.")

#link("https://drive.google.com/file/d/1mS46VQseOg39Rtbm7tQPxk97bvZNx_JG/view?usp=sharing")[#text("Complex zero data")]

#link("https://drive.google.com/file/d/1lJkDHwGfZLMAZDWcRwwqjZRZbLFWyS-Y/view?usp=sharing")[#text("Curve data")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509980")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2018")])]

#text("Interesting oscillations!")

#text("Given that these curves are largely driven by the first few terms of the series ")#mi("H_t(z) \\sim \\sum_n \\frac{b_n^t}{n^{s_*}}")#text(", it may be that one can start isolating some of these curves by plotting the zeroes of various partial sums of this sum. For instance, summing two adjacent terms ")#mi("\\frac{b_n^t}{n^{s_*}} + \\frac{b_{n+1}^t}{(n+1)^{s_*}}")#text(" and plotting the zeroes should already give a good approximation to the n^th curve for small values of n. To explain the oscillations, perhaps adding the neighbouring terms as well will suffice, e.g., ")#mi("\\frac{b_{n-1}^t}{(n-1)^{s_*}} + \\frac{b_n^t}{n^{s_*}} + \\frac{b_{n+1}^t}{(n+1)^{s_*}} + \\frac{b_{n+2}^t}{(n+2)^{s_*}}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-510054")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2019")])]

#text("Your predictions are spot on. Here is a ")#link("https://drive.google.com/file/d/1_eO7Ipg0rRBQPRczmxJfOnIa24p5iphi/view?usp=sharing")[#text("plot")]#text(" of the first few terms that almost exactly reproduce the curves and the oscillations.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509978")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2018")])]

#text("While numerically exploring real zeros at moderately negative t some time back, we had thought all real zeros were born out of a collision of complex zeros, and then drifted apart with increase in t. So in this model, even the zeros which seemed to be on a straight line trajectory would ultimately meet as we lowered t.")#linebreak()#text(" But now with data available at much lower t and the possibility that the lines are parallel, non rigorously speaking is there some dynamics phenomenon that doesn’t involve complex zeros?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509982")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2018")])]

#text("It was indeed surprising to me that it looks like a sparse set of real zeroes are going to persist forever as ")#mi("t \\to -\\infty")#text(" despite the fact that the real zeroes are attracted to each other, and once they collide they will escape into the complex plane and never come back (because of the repulsion effect from their complex conjugate). We haven’t yet sorted out the asymptotics in this regime well enough to say for sure what is going on, but it does look like the real zeroes that survive are located where ")#mi("N = \\sqrt{ \\frac{x}{4\\pi} + \\frac{t}{16} }")#text(" is close to a half-integer. In particular they are quite sparse (only about ")#mi("\\sqrt{x/4\\pi + t/16}")#text(" real zeroes up to height ")#mi("x")#text(", as opposed to the roughly ")#mi("\\frac{x}{4\\pi} \\log \\frac{x}{4\\pi}")#text(" zeroes one expects overall). It could be that at this range of sparsity, the real zeroes are just too far away from each other to ever collide. (The spacing between each real zero and the next is something like ")#mi("\\sqrt{x}")#text(", so the force exerted on each real zero to its neighbour is proportional to ")#mi("1/\\sqrt{x}")#text(" – and when cancelled against the attraction to the neighbour on the opposite side, I think the total net velocity contribution of this pair of neighbours drops to about ")#mi("x^{-1}")#text(", which is lower order than the total velocity which is close to ")#mi("\\pi/4")#text(". This is far too slow for the surviving real zeroes to ever collide with each other. So the dynamical explanation seems to simply be that zeroes stop colliding when they become so sparse that they can’t catch up with their neighbours. Probably the influence of the complex zeroes is a more dominant effect at this point.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509995")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2018")])]

#text("From the above asymptotic estimate of the number of real zeros of ")#mi("H_t")#text(" (for large negative ")#mi("t")#text("), it follows that the first positive zero ")#mi("x_1(t)")#text(" should be about ")#tao-math("\\pi \\left|t\\right| /4", block: false)#text(" (for large negative ")#mi("t")#text(") so that ")#mi("x/(4 \\pi) + t/16")#text(" (which appears in the above estimate under the square root) should be nonnegative.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-510055")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2019")])]

#text("Since the real zeros of ")#mi("H_t")#text(" are moving away from the imaginary axis with “average speed” of ")#mi("\\pi /4")#text(", the zero-free real interval containing the origin for ")#mi("H_t")#text(" should be about")#linebreak()#text(" ")#tao-math("[ -\\pi \\left|t\\right| /4 , \\pi \\left|t\\right| / 4]", block: false)#text(" for large negative ")#mi("t")#text(".")#linebreak()#text(" So even the remaining sparse set of real zeros should disappear from any finite fixed interval for sufficiently large negative ")#mi("t")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21b1383b8a28dfb0977c0449135f6de3d3d62f94f684ebb6f4543a03c551fa35-90b71ee999da76a51a89a39897ef03751846071d69027384e36d99ea707f348d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-509996")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2018")])]

#text("I am extremly excited to follow all of your research posts for polymath projects (thats an unique opportunity, for which I am very thankful). I do not want to disturb your research, as I am a non-mathematician. However, I cannot resist to ask — after now so many discussions on properties of zeros at negative time and some apparently surprising properties: Are there concrete connections to the Riemann hypothesis? I mean, is it known or easy to see that – given some hypothetical behaviour of zeros at negative times – one could develope a new tool to tackle the RH? If not, what are other motivations of analysing the negative time solutions in more details? It seems I dont understand the motivation of this (obviously exciting) endevour. Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-510018")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2018")])]

#text("I think any unexpected numerical phenomenon is worth investigating . My feeling is that there is a 99% chance that we will eventually find an explanation of the remaining numerically discovered phenomena using existing facts about the Riemann xi function and its heat flow deformations ")#mi("H_t")#text(". But there is always that 1% chance that some of these phenomena are manifestations of some hitherto unrealised property of these functions. In principle it is possible that there is some useful property of ")#mi("H_t")#text(" waiting to be unearthed that can then lead back to something new to say about ")#mi("H_0")#text(" (i.e., about the Riemann zeta function). Thus far, though, the causality has always flowed in the opposite direction: we use facts about ")#mi("H_0")#text(" to deduce information about ")#mi("H_t")#text(" for non-zero ")#mi("t")#text(", rather than vice versa. So the overwhelming likelihood is that we do not directly make progress on RH via this project, but we would at least understand ")#mi("H_t")#text(" a lot better, which may help give some understanding as to how “special” the Riemann zeta function is amongst the class of all zeta-like functions that have a meromorphic continuation and a functional equation. (For instance, the Newman conjecture can be thought of as a statement that RH is at best only “barely” true, because even small perturbations of the zeta function can destroy the property of the zeroes all lying on the critical line.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sylvainjulien")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-510009")[#strong[#text("sylvainjulien")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2018")])]

#text("Is there any physical meaning to Lambda being positive or not ? For example, if we consider a toy model of the universe in general relativity with cosmological constant incidentally also denoted by Lambda equal to the de Bruijn-Newman constant, what would be the observational consequences ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-510075")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2019")])]

#text("Your question on a possible connection between RH and some physical constant, reminds Atiyah’s proposed proof of RH using ideas from his proposed evaluation of the fine structure constant.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-510351")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2019")])]

#text("Just a small update on the explorations into the patterns of the real zeroes of ")#mi("H_t(x)=0")#text(" for large negative ")#mi("t")#text(". We’ve discovered some intriguing patterns while working in the coordinate system")

#tao-math("\\displaystyle (N, u) := (\\sqrt{x/4\\pi + t/16}, \\frac{\\left|t\\right|}{x/4\\pi + t/16})", block: false)#text(";")

#text("see for instance ")#link("https://user-images.githubusercontent.com/36714969/50696298-5b2a6580-103f-11e9-840d-4afa55fa6ecf.png")[#text("this graphic")]#text(". We’re getting hints that these asymmetric oscillations around every integer and half-integer value of N have something to do with the Airy function, but we don’t yet have a full explanation. But we’re making progress with a combination of theory and numerics; you can see the ongoing discussion on this at ")#link("https://github.com/km-git-acc/dbn_upper_bound/issues/126")[#text("https://github.com/km-git-acc/dbn_upper_bound/issues/126")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-510359")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2019")])]

#text("Is it possible to use “higher order refinments” of the coordinates ")#mi("(N, u)")#text(" to get a clearer picture of the patterns (or its governing “main term”)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-511046")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2019")])]

#text("After quite a lot of experimental mathematics (documented at the above linked thread), we now have a satisfactory description and heuristic justification of the behaviour of the real zeroes of ")#mi("H_t(x)=0")#text(" for large negative t, as measured in (N,u) coordinates. Actually it is convenient to work in ")#mi("(N,v)")#text(" coordinates where ")#mi("v := \\frac{Nu^2}{64\\pi^2}")#text(". Firstly, in the region ")#mi("v > 4/9")#text(" one should have a zero near every half-integer value of ")#mi("N")#text(" (thus the locus of the equation ")#mi("H_t(x)=0")#text(" is close ")#mi("\\{N+\\frac{1}{2}\\}=0")#text("). For smaller values of ")#mi("v")#text(", there is a periodic “sharkfin” pattern in the region")

#mi("\\displaystyle (\\frac{9v}{4})^{1/3} - v \\leq \\{ 2N+\\frac{1}{2}\\} \\leq 1 - v \\quad (1)")

#text("where the zero locus is approximately the solutions to the equation")

#mi("\\displaystyle \\frac{4\\sqrt{N}}{3} (1-v-\\{ 2N+\\frac{1}{2}\\})^{3/2} + \\frac{1}{4} = 0 \\text{ mod } 1. \\quad (2)")

#text("See for instance ")#link("https://camo.githubusercontent.com/2c580672b515267c49874967b305d32ce504ac93/68747470733a2f2f692e696d6775722e636f6d2f504149725259782e706e67")[#text("this graphic")]#text(", with the zeroes of ")#mi("H_t")#text(" in (N,v) coordinates displayed as the green curves, the region (1) displayed in lavender, and the solutions to (2) displayed as the red lines. (Here N is close to 1000.)")

#text("The reason for this is rather unusual pattern is because in this region the function ")#mi("H_t")#text(" can be asymptotically approximated by an expression involving the Airy function; see ")#link("http://michaelnielsen.org/polymath1/index.php?title=Second_attempt_at_computing_H_t(x)_for_negative_t")[#text("http://michaelnielsen.org/polymath1/index.php?title=Second_attempt_at_computing_H_t(x)_for_negative_t")]

#text("These phenomena only capture a very sparse subset of the zeroes; it seems that most of the zeroes of ")#mi("H_t")#text(" exit the real line long before this “sharkfin” picture begins to take form.")

#text("At some point we may try to write up these observations and heuristic justifications into a second paper; it seems to be a good example of how experimental mathematics and heuristic arguments work together (in particular, the numerical data was instrumental in detecting several occasions in which the heuristics began to be inaccurate).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-511130")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2019")])]

#text("I’ve transcribed the wiki heuristic computations to a TeX file on the writeup: ")#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/Writeup/Sharkfin/sharkfin.pdf")[#text("https://github.com/km-git-acc/dbn_upper_bound/blob/master/Writeup/Sharkfin/sharkfin.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a778b2ba58f0a83758d062a31b82125493a164e454bac4ed73a5f0b4cb8b8e89-caa1cd9f5051dd9589cb04a35a3d8e1d4fec68bd79393a9eb54194c68326ea90.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of BR")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-511280")[#strong[#text("BR")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2019")])]

#text("Is it expected from the heuristic involved with Remark 2.1 that for any negative t, O(x) of the zeros of H_t will be within O(1) of the real axis? (Obviously proving this is a different matter.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-511332")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2019")])]

#text("Hmm, a good question! If one naively adds up the predicted number of zeroes ")#mi("N_*^2 \\log \\frac{n+1}{n}")#text(" that should peel off on the curves for ")#mi("n = 1,\\dots,N_*")#text(", together with their complex conjugates, one does seem to exhaust the bulk of the ")#mi("N_*^2 \\log N_*^2")#text(" or so total zeroes, so it is plausible that the number of zeroes remaining near the real axis should be of lower order, and your conjecture of ")#mi("O(N_*^2)")#text(" sounds reasonable. (Maybe a histogram of imaginary parts of the zeroes will clarify this?)")

#text("The question amounts to understanding the winding number of ")#mi("H_t(x+iy)")#text(" for fixed choices of ")#mi("t, y")#text(" in some dyadic range ")#mi("x \\sim 4 \\pi N_*^2")#text(". This amounts to understanding the winding number of an exponential sum that is roughly of the form ")#mi("\\sum_{n \\sim N_*} n^{-ix}")#text(" times some well understood factors (there is a factor ")#tao-math("\\exp( - \\frac{\\left|t\\right|}{4} \\log^2 \\frac{N}{n} )", block: false)#text(" that is effectively localising to the region ")#mi("n \\sim N_*")#text("). Comparing this against the sum ")#mi("\\sum_{n \\leq N_*} n^{-1/2-ix}")#text(" that would come out of the Riemann-Siegel formula, one could indeed imagine that the winding number of the latter is only ")#mi("O(1/\\log N_*)")#text(" times that of the former, which would be consistent with your ")#mi("O(x) = O(N_*^2)")#text(" prediction, but this is _extremely_ non-rigorous :) It’s possible that one could use the theory of random Dirichlet series as a model to predict what should happen though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a778b2ba58f0a83758d062a31b82125493a164e454bac4ed73a5f0b4cb8b8e89-caa1cd9f5051dd9589cb04a35a3d8e1d4fec68bd79393a9eb54194c68326ea90.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of BR")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-511356")[#strong[#text("BR")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2019")])]

#text("A histogram of the imaginary parts does indeed end up being interesting. Using rudolph01’s data set for zeros with x=20 to 5000, for t = -90, the result is")

#link("https://i.ibb.co/bsvPTnG/Imaginary-parts-H-t.jpg")[#image("../assets/c6c277164ee4ededac15b1931d492af993c948c10799c12fd59d31d55c107a7c-ef6bac1bf3d6a690f81ab3257820f9117488f50ea8946734d7d15da55356681c.jpg", width: 90%)]

#text("This takes all the imaginary parts and puts them into bins of width 3. If x is only taken up to 1000 or 2000 rather than 5000 the same basic pattern emerges. There is some fluctuation in the later part, and surely this is due to the n=1 curve (roughly) y = |t|log(Sqrt[X/4*Pi]/Sqrt[2]), and the n=2 curve etc.")

#text("A bit more surprising in this histogram: lower imaginary parts seem a little less likely, with the rest of the range (roughly) from 0 to |t|*log(Sqrt[X/4*Pi]) reasonably equidistributed apart from the already mentioned fluctuations.")

#text("If we define N_t(X,Y) to be the number of zeros of H_t(z) with real part in [0,X] and imaginary part in [-Y,Y], this also becomes pretty revealing to plot, using the same data set.")

#text("Plotting 1/2* N_t(X,Y) / (X/4Pi) for various Y cutoffs (and X equal to 5x) gives the following plots:")

#text("Y=20")#linebreak()#text(" ")#link("https://i.ibb.co/CvJFb3n/N-t-20.jpg")[#image("../assets/b4f87ddcebc31a724e0a6a91b0f815b7fddebaa43f681d76d732cdb60f99f8f1-ffce35cf4d4fe459e5edfeaf3bc272cb458ebb22925e72bcc0d222c6ed64081f.jpg", width: 90%)]

#text("Y=150")#linebreak()#text(" ")#link("https://i.ibb.co/VQPcTcs/N-t-150.jpg")[#image("../assets/a4bb8fa4f4d93a926a4384278a87d67fe8416649d3faa4e34f533f8c5b599871-64d0aa3a839e2e3e6f4b510acc441235118c6f0d4fe43e85ae3bd58c8663eabc.jpg", width: 90%)]

#text("Y=200")#linebreak()#text(" ")#link("https://i.ibb.co/HBzkhD1/N-t-200.jpg")[#image("../assets/6c8c5df8e2f6ee707a5a2e8308e09a5b1e0d599460d08a4714edf4cdb167a75c-0c33592f1ae383882c74025f71cba4c011bbf8812cbcfd5b6442d4ce845d50bf.jpg", width: 90%)]

#text("No Y cutoff (just the Riemann-von Mangoldt formula for negative t)")#linebreak()#text(" ")#link("https://i.ibb.co/DzcKQxS/N-t-Infinity.jpg")[#image("../assets/715c377e3e83fbbd06b0343186cb6a2fb74f87ff3a914d5efea29fd7d5e04cec-3afcb22e942cebcb9d7726efa7cfc1f6cccf48cbb2e009d618b8bab960419bcd.jpg", width: 90%)]

#text("Considering counts in aggregate rather than in small bins should have the effect of smoothing over the the fluctuations in the first histogram above. To make a somewhat wild guess (and ignore all second order terms), it may be that for fixed negative t,")

#text("N_t(X,Y) << (X/4Pi)*Min(log X, (2/|t|)*Y)")

#text("for Y in any fixed range [epsilon,Infinity), and to make a second guess this is an asymptotic formula as long as Y is growing. If Y is some fixed constant (not zero), this may still be true as an asymptotic formula, but at least judging by the histogram there could be some sort of term that changes the asymptotic a little. If one wanted to use numerics to test this quantitatively rather than qualitatively, it would probably be necessary to consider second order terms (e.g. log X should be replaced by log(X/4Pi), but there are certainly other missing terms like this too and I don't have a conjecture).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-511640")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2019")])]

#text("Below are a few more datasets of complex zeros of ")#mi("H_t(z)")#text(" in the range ")#mi("x=20..5000")#text(" for different ")#mi("-t")#text(":")

#link("https://drive.google.com/file/d/1eKPGWbt4D0V9tkPxgsJdp4W9TteYgx69/view?usp=sharing")[#text("t=-1")]

#link("https://drive.google.com/file/d/19ufGhpznyuMiY74oRnjlkJxVOEwbzjwS/view?usp=sharing")[#text("t=-5")]

#link("https://drive.google.com/file/d/1rpfYLvE1LVbYhdmTAms2qsgUOmXWjksH/view?usp=sharing")[#text("t=-10")]

#link("https://drive.google.com/file/d/1r5tcKQ0NCdoLf1i9pzJx-ny9JEs8Xr1j/view?usp=sharing")[#text("t=-30")]

#text("We now understand what happens to the real zeros when ")#mi("t \\rightarrow \\pm \\infty")#text(", and also what happens to the complex zeros when ")#mi("t \\rightarrow +\\infty")#text(" (all gone when ")#mi("\\Lambda \\ge 0.22")#text("). However we haven’t yet fully explored what happens to these curves of complex zeros when ")#mi("t \\rightarrow - \\infty")#text(".")

#text("Maybe this is trivial, but when I compute the complex solutions for ")#mi("Z(t, s*, n) = \\frac{b^t_n}{n^{s*}} + \\frac{b^t_{n+1}}{(n+1)^{s*}} = 0")#text(", it seems at first that the curves just drift further away from the real line and then ‘straighten out’ into horizontal lines at increasingly negative ")#mi("t")#text(". However at a certain point new complex zeros start to emerge close to the origin as can be seen in this plot (")#mi("t=-1000, n=1,2,3")#text(" with ")#mi("n=1")#text(" is the most inner curve):")

#link("https://ibb.co/g6t600t")[#text("https://ibb.co/g6t600t")]

#emph[#text("[It appears that if the link ends in something like .jpg then it is automatically rendered, but if it is not a recognised image extension then it is not. -T]")]

#text("The complex zeros appear to originate from a certain ")#mi("-y")#text(" and then travel into the ")#mi("+y")#text(" domain when ")#mi("-t")#text(" decreases further (note that the zeros of ")#mi("Z()")#text(" are not conjugated pairs, e.g. at ")#mi("t=0")#text(" the curves would become straight lines at ")#mi("y=-1")#text(". I guess a slightly different version for Z() exists that produces the conjugated version of the curves).")

#text("Note that the outer right sides of the n-curves in the plot are all relatively close to the ")#mi("N+\\frac12")#text(" vertical lines of real zeros (the zeros always stay on the left side of these vertical lines). Where could these new complex zeros come from and how could they travel through the real line without a collision with their conjugate and thereby inducing a new pair of real zeros?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-511651")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2019")])]

#text("These phenomena may be artefacts of continuing the approximation ")#mi("Z(t,s_*,n)=0")#text(" for these curves well beyond their range of applicability. For instance I would imagine that these curves diverge significantly from the simpler approximation ")#mi("y = -\\frac{t}{2} \\log \\frac{x}{4\\pi n(n+1)} - 1")#text(", as well as from the actual zeroes of ")#mi("H_t")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-511264")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2019")])]

#text("Here is one more question, can’t let it go yet :)")

#text("We now know that for increasingly negative ")#mi("t")#text(", all complex zeros are ‘peeled off’ from the real line and eventually organise themselves on curves that can be explained by the dominance of two adjacent terms from an asymptotic (Dirichlet-type) series for ")#mi("H_t")#text(". The most outer curve only requires the first two terms from this series and including more terms yields more curved patterns that are increasingly closer to the real line, however contain less complex zeros and oscillate more. These oscillations fade out when going further back in time as the curves move away from the real line.")

#text("All complex zeros originate from collisions of a pair of real zeros at a certain ")#mi("-t, x")#text(", So, the wave forms of the complex zeros near the real line should also ‘cast a shadow’ on the collision patterns of the real zeros at ")#mi("y=0")#text(". As ")#mi("-t")#text(" gets closer to ")#mi("t=0")#text(", this ‘peeling off process’ clearly becomes increasingly more complex, however moving further away from ")#mi("t=0")#text(" things seem to become ‘quieter’. This culminated in the recent discovery that the final ‘peeling off-wave’ can be fully explained by the collisions of the real zeros of an Airy function (with the collisions occurring on the left edges of ‘sharkfin’ shaped structures). To explain this ‘most outer’ pattern at ")#mi("y=0")#text(", we again only require the first two dominant terms of an asymptotic series (eq. 1.41 + 1.55), i.e. ")#mi("m=0")#text(" for the half integer lines and ")#mi("m=1")#text(" inducing the required oscillations in the sharkfin-shapes.")

#text("This is a long shot, but similar to the mechanisms that explained the oscillations in the complex zeros, could it be that subsequently adding Airy terms e.g. ")#mi("m=(0,1,2), m=(0,1,2,3), ..")#text(" will fit a few of the noisier collisions patterns of real zeros at less negative ")#mi("t")#text("?")

#text("P.S.:")#linebreak()#text(" Surprisingly there even exists an ")#link("http://mathworld.wolfram.com/AiryZetaFunction.html")[#text("Airy-Zeta function")]#text(" that seems to share a few high level properties with the Riemann Zeta-function.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-511066")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2019")])]

#text("Just a final thought about the real zeros in the negative ")#mi("t")#text(" domain.")

#text("All the equations derived so far strongly indicate that information about ")#mi("H_t")#text(" always originates from ")#mi("H_0")#text(" and there is no information flowing vice versa. The ")#mi("H_0")#text(" case, i.e. the Riemann ")#mi("\\xi")#text("-function, seems therefore special. On the other hand, this is the original function that we chose to perturb in the ")#mi("+t")#text(" and ")#mi("-t")#text(" directions.")

#text("The recent insights from exploring the ")#mi("-t")#text(" domain have changed my initial mental model in which real and complex zeros were flowing from a gaseous towards a solid state over time. It now more feels like ")#mi("t=0")#text(" represents a sort of thermodynamical equilibrium state (with the highest possible entropy) that is being disturbed by injecting an increasingly positive or negative ")#mi("t")#text(" and eventually converges the zero trajectories towards the regular (lower entropy) patterns that we can now all fully explain.")

#text("From the perspective of a model with ")#mi("t=0")#text(" at the centre, I find it still surprising that there isn’t at least some symmetry found between ")#mi("H_t")#text(" and ")#mi("H_{-t}")#text(". An obvious reason for the asymmetry probably is the dominant presence of complex zeros in the ")#mi("-t")#text(" domain, however I could think of these two high level symmetries/similarities:")

#text("+t = real zeros always repel each other, complex zeros always attract each other.")#linebreak()#text(" 0 = ‘peaceful’ coexistence between all zeros.")#linebreak()#text(" -t = real zeros always attract each other, complex zeros always repel each other.")

#text("+t = there is a minimum speed by which complex zeros fall towards their conjugates and collide.")#linebreak()#text(" 0 = all zeros in a standstill.")#linebreak()#text(" -t = there is a minimum speed by which real zeros fall towards a partner and collide.")

#text("For the latter similarity we know that this minimal speed is determined by a solution to an ODE, respectively the DBN upper bound for complex zeros at ")#mi("+t")#text(" (using the known supremum ")#tao-math("\\left|y\\right| \\le 1", block: false)#text(") and the Airy-function for some ‘latest collision’ real zeros at larger ")#mi("x, -t")#text(".")

#text("So, we now know how far imaginary zeros can penetrate the ")#mi("+t")#text(" domain (the DBN bound, or hey, hey: $\\Lambda \\le 0.22$ !) and we also know how far real zeros can penetrate the ")#mi("-t")#text(" domain (the curve drawn through the tips of the sharkfins, thereby ignoring the zeros on the straight lines at half integers).")

#text("The bound for the complex zeros was derived from their dynamics, so from a symmetry perspective, could a bound for the real zeros at ")#mi("-t")#text(" also be derived from their dynamics? I.e. when one starts from a set of non-trivial zeros up to ")#mi("x")#text(" at ")#mi("t=0")#text(", is it possible to derive from their (assuming only attractive) dynamics the (x, -t) upper bound before which all these zeros must have collided?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-511131")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2019")])]

#text("I agree with you that ")#mi("H_0(x+iy)")#text(" is the most complicated function (particularly on the critical line ")#mi("y=0")#text(") and all the other quantities ")#mi("H_t(x+iy)")#text(" for positive or negative ")#mi("t")#text(" are simpler. There still seems to be some asymmetry between positive ")#mi("t")#text(" and negative ")#mi("t")#text(" though.")

#text("From the toy approximation (relying entirely on the “B” series) we heuristically have an approximation")

#mi("H_t(x+iy) \\propto \\sum_{n=1}^\\infty n^{-\\frac{1+y}{2}-\\frac{t}{4} \\log^2 \\frac{N}{n}  } n^{-i\\tilde x/2}")

#text("of ")#mi("H_t(x+iy)")#text(" as a weighted exponential sum times some simple additional terms, where ")#mi("\\tilde x = x + \\pi t/4")#text(" and ")#mi("N := \\sqrt{\\tilde x/4\\pi}")#text(" (the wiki says ")#mi("N = \\sqrt{x/4\\pi}")#text(" but I think the latter is actually a slightly better approximation). When ")#mi("t=y=0")#text(", the weights ")#mi("n^{-\\frac{1+y}{2}-\\frac{t}{4} \\log^2 \\frac{N}{n}  }")#text(" simplifies to ")#mi("n^{-1/2}")#text(" which makes all of the phases ")#mi("n^{-i\\tilde x/2}")#text(" coming from a single dyadic range of ")#mi("n")#text(" have equal “strength” as far as square root cancellation heuristics are concerned. But as one varies ")#mi("y")#text(" and ")#mi("t")#text(", the weight changes shape and effectively localises the sum to much smaller ranges of ")#mi("n")#text(" (e.g., ")#mi("n")#text(" near 1, or ")#mi("n")#text(" near ")#mi("N")#text("), at which point the behaviour of the sum can be simplified to the point where one can understand the zeroes asymptotically.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2934cb562ae458983e671622732f3b850ca0605d450dae97afc307d6a237f08-98f7afe2168c061903bf4deef1c906f4fc4afafbf4e1ee5065e8652fbbf3871a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marshall Flax")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-510367")[#strong[#text("Marshall Flax")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2019")])]

#text("As far as Airy functions, the US government is shut down, but the Internet Archive has a copy of the website — ")#link("https://web.archive.org/web/20181106010212/https://dlmf.nist.gov/9")[#text("https://web.archive.org/web/20181106010212/https://dlmf.nist.gov/9")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-510681")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2019")])]

#text("In page 13 of the writeup, in the line below (32), it seems that “vanishes” should be “")#mi("\\neq 0")#text("“.")

#emph[#text("[Thanks, this will be corrected in the next build of the writeup PDF. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-510873")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2019")])]

#text("This typo is obvious (since the derivative at a simple zero must be nonzero – the opposite of “vanishes”.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-511137")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2019")])]

#text("Also in page 13 of the writeup, the limit in (33) is applied to a function represented (pointwise) by a locally uniformly convergent sum which is therefore continuous – so there is NO NEED to justify (by the dominated convergenge theorem) the interchange of summation and limit (which is equivalent to the continuity of this pointwise sum at ")#mi("z = z_j")#text(") as remarked at the end of page 13.")

#emph[#text("[This will be reworded in the next build of the pdf. -T]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-510968")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2019")])]

#text("Atiyah passed away :\\")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-510970")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2019")])]

#link("https://royalsociety.org/news/2019/01/tribute-to-former-president-of-the-royal-society-sir-michael-atiyah/")[#text("https://royalsociety.org/news/2019/01/tribute-to-former-president-of-the-royal-society-sir-michael-atiyah/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-510976")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2019")])]

#text("Sad news.")#linebreak()#text(" So many great mathematicians passed away in less than one month.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-511388")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2019")])]

#text("If you suppose that $\\Lambda=0$, there are some good consequences about $H_t$ (beyond Riemann hypothesis)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-513267")[#strong[#text("Dan Romik Studies the Riemann’s Zeta Function, and Other Zeta News. | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2019")]

#text("[…] task of polymath15 (proposed here, launched here, last (11th) post here) was to use current analytic number theory technology that already has yielded information on the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-514823")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2019")])]

#text("Any updates? I’m just curious.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-514865")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2019")])]

#text("Actually I’ve been working on the writeup this week (see the discussion on github at ")#link("https://github.com/km-git-acc/dbn_upper_bound/issues/131")[#text("https://github.com/km-git-acc/dbn_upper_bound/issues/131")]#text(" ). There was a slight issue with the theoretical justification of the method used to lower bound a certain Dirichlet-type series (in a long rectangular region to the right of the barrier) and I am currently in the process of repairing it. I will then also try to replicate some of the numerics and rewrite some of the rough descriptions of those numerics in the relevant portion of the paper. Then the paper should be largely completed except perhaps for the final section on conditional results. I had been distracted in the last few months with a number of other urgent issues but am now focusing on getting this project wrapped up.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-514971")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2019")])]

#text("The writeup is now nearing a final form: ")#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/Writeup/debruijn.pdf")[#text("https://github.com/km-git-acc/dbn_upper_bound/blob/master/Writeup/debruijn.pdf")]#text(" ; the holdup had been an accurate description of the numerical part of the project but I think now that this part of the paper has reached a satisfactory state.")

#text("Regarding what to do with the paper, one possibility is to submit to Research in the Mathematical Sciences, which previously published the Polymath8b paper, and which is willing to accept longer papers such as this one (currently at 68 pages).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-515320")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2019")])]

#text("I guess participation in this project has wound down quite a bit, but I will wait for another week to see if there are any further comments or objections to the writeup and to the proposal to submit to RMS (and the arXiv, of course). I think it is perhaps a good time to “declare victory” on this project and wrap it up, now that the pace of activity has slowed to basically zero.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-515321")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2019")])]

#text("In the caption of figure 1 are the descriptions of ii and iii switched? In the figure iii is more barrier-related but in the caption ii is more barrier-related. I don’t know if the rest of the paper is correct or not, I just skimmed to the first figure and read its caption.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-515324")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2019")])]

#text("Is Remark 1.6 still current given the comment by Rudolph above in this thread “The recent insights from exploring the -t domain have changed my initial mental model in which real and complex zeros were flowing from a gaseous towards a solid state over time”?")

#emph[#text("[Reworded – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-515359")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2019")])]

#text("Elaborating a bit on my comment:")

#text("The analogy that ")#mi("H_t")#text(" ‘cools’ down from a liquid state (with highly unequal spacings between the real zeroes) into a solidified equilibrium (with zeros arranged in an arithmetic progression) for increasingly positive ")#mi("t")#text(", still looks sound to me.")

#text("However, with the heuristic insights from the negative ")#mi("t")#text(" domain, the sentence in Remark 1.6: “A “gaseous” state corresponds to the situation in which the zeroes of ")#mi("H_t")#text(" are strictly complex.” might be phrased a bit too strongly for two reasons:")#linebreak()#text(" 1) There actually doesn’t appear to exist a time where all zeros are ‘strictly’ complex, since we know there always is a very small subset of zeros that have been real ‘throughout their entire life’.")#linebreak()#text(" 2) It seems that for increasing ")#mi("x")#text(", the last complex zeros will be ‘peeled’ off the real line at increasingly negative ")#mi("t")#text(". Hence for larger ")#mi("x")#text(", one has to go further and further back in time to make all zeros ‘strictly’ complex.")

#text("As has been mentioned before, all information and insights we have gained about ")#mi("H_t")#text(" (so far), always originated from ")#mi("H_0")#text(". Also, the function ")#mi("H_t(x+yi)")#text(" seems to reach its highest complexity at ")#mi("t=0, y=0")#text(". This could be another indication that instead of ‘heating up into gas’ at more negative ")#mi("t")#text(", there also is a form of solidification happening to ")#mi("H_t")#text(" (ref. the ‘Sharkfin’ Airy functions for real zeros and complex zeros organising themselves on curves). Of course this is currently all based on visual observations and heuristic math, but wonder whether there could exist a way to formalise the complexity of ")#mi("H_t")#text("? This wouldn’t help prove the RH, but I still do expect it to reach its highest point somewhere in the range ")#mi("0 \\le \\Lambda \\le 0.22")#text(" :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-515328")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2019")])]

#text("The truncation of B(b) at E=50 on page 36 in the multieval section is justified by visually inspecting figure 13, and this is obvious enough to not be worth writing down an estimate of the truncation error?")

#emph[#text("[More explanation given. The actual bounding is rather tedious but the procedure is straightforward. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-515329")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2019")])]

#text("The manuscript mentions massive computations performed using a boinc based grid, but doesn’t cite boinc in the references. Maybe that’s OK like not citing texas instruments if you use a TI-81 to add numbers together, but if not heres a citation link ")#link("https://dl.acm.org/citation.cfm?id=1033223")[#text("https://dl.acm.org/citation.cfm?id=1033223")]

#emph[#text("[Citation added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-515648")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2019")])]

#text("I have just submitted the Polymath15 paper to the arXiv and to Research in the Mathematical Sciences.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-514987")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2019")])]

#text("In page 44 of the writeup, in the first line it is claimed (without sufficient clarification) that ")#mi("B")#text(" “can also be seen to be decreasing in the range ")#mi("N \\geq N_1")#text("“. And in the third line, it is not clear which claim follows.")

#emph[#text("[More explanation added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-515384")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2019")])]

#text("Dear Terry,")#linebreak()#text(" May I have a question?")#linebreak()#text(" Do you think what is more impressive between polymath8 and polymath15?")#linebreak()#text(" Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-515387")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2019")])]

#text("polymath8 was more impressive because it attracted more famous participants and it was based on yitang zhang’s breakthrough which got high ratings. polymath15 was also more impressive because it reached 56% of the way to proving the riemann hypothesis whose ratings are also high")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b71017f3ba0f543c5044556f27512e72972ffa9e69a8bf9184eadd8f7695b8bf-bea05fabd012afb0eff4e8714fccbbf0a0ed5d4690e1d374727fd01c1f9ac003.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M Ruxton")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-515397")[#strong[#text("M Ruxton")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2019")])]

#text("I think this impressiveness question is irrelevant.")

#text("This is like asking which of your niece and nephew is your favourite.")

#text("Zhang’s work was a breakthrough; everyone was impressed, but we knew many people would build on Zhang’s work.")

#text("Rodgers and Tao’s work was a breakthrough. Unless we are willing to proceed under the belief that the RH is false, the work left to do is to lower the upper bound.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0c966f83956f88e0ae0569a5a0b03c90ac4da8d83a15599ca142d3f1d3503e6-6da5889455160fc1a4651d11d6dc54150c1eee35c9adbd8ae366b68451ab2690.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of goingtoinfinity")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-515400")[#strong[#text("goingtoinfinity")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2019")])]

#text("Is there an technical reason why it is difficult to get below 0,22 as the current lower bound (except of computations getting more expensive)?")

#text("In an explanation for polymath8, the parity-problem was named as a reason for hindering further progress with current technology, even with assumption of strong conjectures. Is there a similar technical obstruction that would hinder progress beyond a certain value for the de Bruijn-Newman constant ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-515401")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2019")])]

#text("The main bottleneck is the parameter ")#mi("X")#text(", which basically is the height to which we can numerically verify the Riemann hypothesis, and which we have taken to be basically ")#mi("6 \\times 10^{10}")#text(". Once ")#mi("X")#text(" is given, we can pretty much optimise all the other parameters in our method (in particular ")#mi("t_0, y_0")#text(") in a numerically feasible time (at least until ")#mi("X")#text(" reaches ")#mi("10^{22}")#text(" or so). The final bound on ")#mi("\\Lambda")#text(" is proportional to ")#mi("1/\\log X")#text(" (and we heuristically believe that we cannot do much better than this with current technology, save perhaps to improve the proportionality constant a little). So, judging by Table 1 of the paper, it might be possible to lower the bound to say ")#mi("0.20")#text(" with significant computational effort on numerical verification of RH, but to get to for instance ")#mi("0.1")#text(" looks well beyond current computational capability.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-515410")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2019")])]

#text("It seems that it is not posssible for each given ")#mi("\\Lambda_0 \\geq \\Lambda")#text(" to establish an explicit lower bound (")#mi("M(\\Lambda_0)")#text(", say) for the minimal computational complexity needed to verify that the given ")#mi("\\Lambda_0")#text(" is indeed an upper bound for ")#mi("\\Lambda")#text(", because such complexity lower bound should imply a lower bound ")#mi("M(0)")#text(" on the complexity of any proof for the RH.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-515413")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2019")])]

#text("I think when he says “final bound on lambda” it’s with respect to the “current technology”, so not the final final bound on lambda that you could get with a hypothetical different technology such as would be needed to prove RH.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-515421")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2019")])]

#text("This project is a good example where a bound can be pushed by increasing the height of RH numerical verification. I wonder if there’s a compilation of such bounds or other constants in the literature that would similarly benefit from greater RH numerical verification height?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-515441")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2019")])]

#text("In the line below (33) of the writeup, the statement that ")#mi("H_t")#text(" is non-zero at the origin can be made clearer by adding that it follows from the positivity of ")#mi("\\Phi")#text(".")#linebreak()#text(" Note however that this discussion partially reappear(!) (with more details) in the proof of theorem 1.5(iv) (page 61).")

#emph[#text("[Explanation added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-515527")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2019")])]

#text("In the writeup, first line of page 9, it is claimed that in the asymptotic limit ")#mi("x \\to \\infty")#text(" “one easily sees” three asymptotic estimates – which are (at least for me) not obvious at all.")#linebreak()#text(" Note also that the coefficients ")#mi("b_n^t")#text(" (defined in (15)) grow faster than any power of ")#mi("n")#text(". Does it means that the summands in the first sum of (14) are growing in absolute value?")

#emph[#text("[Asymptotics corrected. ")#mi("b_n^t")#text(" is indeed increasing, but the expression ")#mi("b_n^t/n^{s_*}")#text(" in practice will be decreasing up to ")#mi("n \\leq N")#text(", though it will eventually diverge if we instead took ")#mi("n \\to \\infty")#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c7e250ebd5a95e657e86c2bd7699027f195cb9b828aaccdd1b11e5231e8dff94-9cf0bf9df7ec67e7c95e786c53370408e56c069f76d49c043fddda86297df181.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of EP")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-515574")[#strong[#text("EP")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2019")])]

#text("It seems that it is possible to improve slightly the current value of ")#mi("\\Lambda")#text(" by improving de Bruijn classical bound (theorem 3.2) by using improved differential inequality of the form")

#mi("-\\partial_t(y_j^2) \\geq 2 + c y_j^2")

#text("where ")#mi("z_j = x_j + i y_j")#text(" is a simple non-real zero of ")#mi("H_t")#text(" such that ")#tao-math("y_j \\geq \\left|y_k\\right|", block: false)#text(" for all zeros ")#mi("z_k = x_k + i y_k")#text(" of ")#mi("H_t")#text(".")

#text("It follows that ")#mi("c")#text(" is a growing positive function of ")#mi("x_j")#text(" (which grows like ")#mi("\\log x_j")#text(") and is lower bounded by a positive absolute constant. The improved differential inequality implies the new bound")

#mi("\\Lambda \\leq t_0 + c^{-1}\\log(1+cy_0^2/2)")

#text("Which is slightly better than de Bruijn bound. (the best constant ")#mi("c")#text(" is dependent on ")#mi("y_0")#text(" as well on any given lower bound on ")#mi("x_j")#text(" but, as remarked, it is still lower bounded by an absolute positive constant)")

#text("I hope to give the details of this (simple) derivation in a day or two.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c7e250ebd5a95e657e86c2bd7699027f195cb9b828aaccdd1b11e5231e8dff94-9cf0bf9df7ec67e7c95e786c53370408e56c069f76d49c043fddda86297df181.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of EP")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-515646")[#strong[#text("EP")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2019")])]

#text("Let ")#mi("z_j = x_j + i y_j")#text(" be a simple zero of ")#mi("H_t")#text(".")#linebreak()#text(" If ")#mi("y_j \\neq 0")#text(", it is known that")

#tao-math("-\\partial_t(y_j^2) = 2 + \\sum_{k \\in K^{\\prime\\prime}_j} 4 y_j(y_j - y_k)/\\left|z_k-z_j\\right|^2", block: false)

#text("Where ")#mi("K^{\\prime\\prime}_j")#text(" denotes the set of indices ")#mi("k")#text(" for which ")#mi("z_k \\neq z_j, \\bar{z_j}")

#text("If for all ")#mi("k")#text(", ")#tao-math("\\left|y_k\\right| \\leq y_j", block: false)#text(", then ")#tao-math("\\left|z_k -z_j\\right|^2 \\leq (x_k-x_j)^2+4 y_j^2", block: false)

#text("Hence ")#mi("-\\partial_t(y_j^2) \\geq 2+\\sum_{k \\in K^{\\prime\\prime}_j} 4y_j(y_j-y_k)/[(x_k-x_j)^2+4y_j^2]")

#mi("= 2 + y_j^2 c(z_j) - 4 y_j S(z_j)")

#text("where ")#mi("c(z_j) := \\sum_{k \\in K^{\\prime\\prime}_j} 4/ [(x_k - x_j)^2 + 4 y_j^2]")#text(" , and")

#mi("S(z_j) := \\sum_{k \\in K^{\\prime\\prime}_j} y_k / [(x_k - x_j)^2 + 4 y_j^2]")

#text("Now observe that ")#mi("S(z_j) = 0")#text(" because the contribution of each ")#mi("k")#text(" with real ")#mi("z_k")#text(" to this sum is zero (since ")#mi("y_k = 0")#text("), while the contribution of any ")#mi("k")#text(" with non-real ")#mi("z_k")#text(" is canceled(!) by the contribution of its conjugate.) This gives the basic inequality")

#mi("-\\partial_t(y_j^2) \\geq 2 + y_j^2 c(z_j)")

#text("In order to lower bound ")#mi("c(z_j)")#text(", define for all ")#mi("\\Delta > 0")

#mi("c(z_j, \\Delta) := \\sum_{k \\in K^{\\prime\\prime}_j(\\Delta)} 4/ [(x_k - x_j)^2 + 4y_j^2]")

#text("where ")#mi("K^{\\prime\\prime}_j(\\Delta)")#text(" denotes the set of indices ")#mi("k")#text(" in ")#mi("K^{\\prime\\prime}_j")#text(" for which ")#tao-math("\\left|x_k - x_j\\right| \\leq \\Delta", block: false)#text(". Hence for all ")#mi("\\Delta >0")#linebreak()#text(" ")#mi("c(z_j) \\geq c(z_j, \\Delta) \\geq c_1(z_j, \\Delta)")

#text("where ")#mi("c_1(z_j, \\Delta) := \\sum_{k \\in K^{\\prime\\prime}_j(\\Delta)} 4/(\\Delta^2+4y_j^2)")

#text("Hence ")#mi("c(z_j) \\geq c_1(z_j) := \\sup_{\\Delta > 0} c_1(z_j, \\Delta)")

#text("Now we extend the definition of ")#mi("N_t(x)")#text(" to be an odd function for all real x by ")#mi("H_t(-x) := - H_t(x)")#text(". It easy to verify that the number of indices ")#mi("k")#text(" in ")#mi("K^{\\prime\\prime}_j(\\Delta)")#text(" satisfies")

#tao-math("\\left|k^{\\prime\\prime}_j(\\Delta)\\right| := \\sum_{k \\in K^{\\prime\\prime}_j(\\Delta)} 1 \\geq N_t(x_j + \\Delta) -N_t(x_j - \\Delta) -2", block: false)

#text("with equality if ")#mi("x_j + \\Delta, x_j - \\Delta")#text(" are not ")#mi("x_k")#text(" for some ")#mi("k")#text(". This gives the more explicit bound")

#mi("c_1(z_j) \\geq c_2(z_j) := \\sup_{\\Delta > 0} [N_t(x_j + \\Delta) - N_t(x_j - \\Delta) - 2] / (\\Delta^2 + 4 y_j^2)")

#text("For simplicity, we lower bound ")#mi("c_2(z_j)")#text(" by")

#mi("c_3(z_j) := \\sup_{0 < \\Delta < x_j} [N_t(x_j + \\Delta) - N_t(x_j - \\Delta) - 2] / (\\Delta^2 + 4 y_j^2)")

#mi("N_t(x) = g_t(x) + h_t(x)")

#text("where ")#mi("g_t(x) := (x/ (4 \\pi)) \\log (x / (4 /pi)) - x/ (4 \\pi)")

#text("and ")#mi("h_t(x) := O_{\\leq} (C \\log(2+x))")

#text("Since ")#mi("g_t(x+\\Delta) - g_t(x-\\Delta) \\geq 2 \\Delta g^{\\prime}_t(x-\\Delta) = 2 \\Delta /(4 \\pi) \\log ((x-\\Delta)/(4 \\pi))")#text(". Therefore")

#mi("c_3(z_j) \\geq \\sup_{0 < \\Delta < x_j} [(2 \\Delta / 4 \\pi) \\log((x_j - \\Delta)/(4 \\pi)) - 2 C \\log (2+ x_j)] / (\\Delta^2 + 4 y_j^2)")

#text("For sufficiently large ")#mi("x_j")#text(", we may approximate this maximization problem by maximizing the function")

#mi("(\\Delta / (4 \\pi) - C) / (\\Delta^2 + 4 Y_j^2) 2 \\log x_j")

#text("The maximum is attained (approximately) for ")#mi("\\Delta = 8 \\pi C")#text(", giving the approximate lower bound")

#mi("C_3(z_j) \\geq \\log (x_j) / (32 \\pi^2 C)")#text(".")

#text("Remark: This elementary bounding method is crude, improving very slightly de Bruijn bound. Fortunately, there is a much better (nearly optimal) analytical bounding method, giving a much better differential inequality of the form")

#mi("-\\partial_t(y_j^2) \\geq 2 + c y_j")

#text("where the \"main term\" of the expression for ")#mi("c")#text(" can be calculated precisely and is very close to ")#mi("\\log(x_j/(4 \\pi))/(2 y_j)")#text(". I'll give the improved analytical bounding method and its improved de Bruijn bound for ")#mi("\\Lambda")#text(" in my next comment.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-515647")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2019")])]

#text("For complicated calculations it may be better to use another web site, such as the polymath wiki, and then add a link here.")

#text("One issue though is that it appears that you are trying to use the Riemann-von Mangoldt formula. Currently this is only established (with effective constants) at t=0, however we will need also some effective version of this formula for positive t, and this has not yet been done.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-518666")[#strong[#text("Dan Romik on the Riemann zeta function | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2019")]

#text("[…] paper by Rodgers and Tao [4] proving a major conjecture of Newman, and the recent paper [9] by the Polymath15 project (mentioned by Gil in his earlier post), for the latest on this […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-518796")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2019")])]

#text("In order to prove RH, it is sufficient (by Hurwitz theorem) to find a sequence of non-vanishing analytic functions in the critical strip which converge locally uniformly to the xi function in the critical strip.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-525195")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2019")])]

#text("Is this polymath over?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-525198")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2019")])]

#text("Yes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/28/polymath-15-eleventh-thread-writing-up-the-results-and-exploring-negative-t/#comment-682850")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2024")])]

#text("This result had a new progress:")

#link("https://arxiv.org/pdf/2004.09765.pdf")[#text("Click to access 2004.09765.pdf")]

#text("We know now that ")#tao-fit-display[#mitex("\\Lambda \\leq 0.2")]#text(".")
]
