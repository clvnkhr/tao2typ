// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/08/13/the-ionescu-wainger-multiplier-theorem-and-the-adeles/
// Converted to Typst by tao2typ: "2026-10-14T15:20:32.205813+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Ionescu-Wainger multiplier theorem and the adeles", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Ionescu-Wainger multiplier theorem and the adeles")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 August 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/08/13/the-ionescu-wainger-multiplier-theorem-and-the-adeles/")[#text("https://terrytao.wordpress.com/2020/08/13/the-ionescu-wainger-multiplier-theorem-and-the-adeles/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper ")#link("https://arxiv.org/abs/2008.05066")[#text("The Ionescu-Wainger multiplier theorem and the adeles")]#text("“. This paper revisits a useful ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2188130")[#text("multiplier theorem of Ionescu and Wainger")]#text(" on “major arc” Fourier multiplier operators on the integers ")#mi("{{\\bf Z}}")#text(" (or lattices ")#mi("{{\\bf Z}^d}")#text("), and strengthens the bounds while also interpreting it from the viewpoint of the adelic integers ")#mi("{{\\bf A}_{\\bf Z}}")#text(" (which were also used in ")#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/")[#text("my recent paper with Krause and Mirek")]#text(").")

#text("For simplicity let us just work in one dimension. Any smooth function ")#mi("{m: {\\bf R}/{\\bf Z} \\rightarrow {\\bf C}}")#text(" then defines a discrete Fourier multiplier operator ")#mi("{T_m: \\ell^p({\\bf Z}) \\rightarrow \\ell^p({\\bf Z})}")#text(" for any ")#mi("{1 \\leq p \\leq \\infty}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("{\\mathcal F}_{\\bf Z} T_m f(\\xi) =: m(\\xi) {\\mathcal F}_{\\bf Z} f(\\xi)")]]

#text("where ")#mi("{{\\mathcal F}_{\\bf Z} f(\\xi) := \\sum_{n \\in {\\bf Z}} f(n) e(n \\xi)}")#text(" is the Fourier transform on ")#mi("{{\\bf Z}}")#text("; similarly, any test function ")#mi("{m: {\\bf R} \\rightarrow {\\bf C}}")#text(" defines a continuous Fourier multiplier operator ")#mi("{T_m: L^p({\\bf R}) \\rightarrow L^p({\\bf R})}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("{\\mathcal F}_{\\bf R} T_m f(\\xi) := m(\\xi) {\\mathcal F}_{\\bf R} f(\\xi)")]]

#text("where ")#mi("{{\\mathcal F}_{\\bf R} f(\\xi) := \\int_{\\bf R} f(x) e(x \\xi)\\ dx}")#text(". In both cases we refer to ")#mi("{m}")#text(" as the ")#emph[#text("symbol")]#text(" of the multiplier operator ")#mi("{T_m}")#text(".")

#text("We will be interested in discrete Fourier multiplier operators whose symbols are supported on a finite union of arcs. One way to construct such operators is by “folding” continuous Fourier multiplier operators into various target frequencies. To make this folding operation precise, given any continuous Fourier multiplier operator ")#mi("{T_m: L^p({\\bf R}) \\rightarrow L^p({\\bf R})}")#text(", and any frequency ")#mi("{\\alpha \\in {\\bf R}/{\\bf Z}}")#text(", we define the discrete Fourier multiplier operator ")#mi("{T_{m;\\alpha}: \\ell^p({\\bf Z}) \\rightarrow \\ell^p({\\bf Z})}")#text(" for any frequency shift ")#mi("{\\alpha \\in {\\bf R}/{\\bf Z}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("{\\mathcal F}_{\\bf Z} T_{m,\\alpha} f(\\xi) := \\sum_{\\theta \\in {\\bf R}: \\xi = \\alpha + \\theta} m(\\theta) {\\mathcal F}_{\\bf Z} f(\\xi)")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("T_{m;\\alpha} f(n) = \\int_{\\bf R} m(\\theta) {\\mathcal F}_{\\bf Z} f(\\alpha+\\theta) e( n(\\alpha+\\theta) )\\ d\\theta.")]]

#text("More generally, given any finite set ")#mi("{\\Sigma \\subset {\\bf R}/{\\bf Z}}")#text(", we can form a multifrequency projection operator ")#mi("{T_{m;\\Sigma}}")#text(" on ")#mi("{\\ell^p({\\bf Z})}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("T_{m;\\Sigma} := \\sum_{\\alpha \\in \\Sigma} T_{m;\\alpha}")]]

#text("thus")

#align(center)[#tao-fit-display[#mitex("T_{m;\\alpha} f(n) = \\sum_{\\alpha \\in \\Sigma} \\int_{\\bf R} m(\\theta) {\\mathcal F}_{\\bf Z} f(\\alpha+\\theta) e( n(\\alpha+\\theta) )\\ d\\theta.")]]

#text("This construction gives discrete Fourier multiplier operators whose symbol can be localised to a finite union of arcs. For instance, if ")#mi("{m: {\\bf R} \\rightarrow {\\bf C}}")#text(" is supported on ")#mi("{[-\\varepsilon,\\varepsilon]}")#text(", then ")#mi("{T_{m;\\Sigma}}")#text(" is a Fourier multiplier whose symbol is supported on the set ")#mi("{\\bigcup_{\\alpha \\in \\Sigma} \\alpha + [-\\varepsilon,\\varepsilon]}")#text(".")

#text("There are a body of results relating the ")#mi("{\\ell^p({\\bf Z})}")#text(" theory of discrete Fourier multiplier operators such as ")#mi("{T_{m;\\alpha}}")#text(" or ")#mi("{T_{m;\\Sigma}}")#text(" with the ")#mi("{L^p({\\bf R})}")#text(" theory of their continuous counterparts. For instance we have the basic result of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1888798")[#text("Magyar, Stein, and Wainger")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Magyar-Stein-Wainger sampling principle)")]#text(" ")#metadata(none) <tao-d2a8bfe64f2c5a3eee91>#text(" Let ")#mi("{1 \\leq p \\leq \\infty}")#text(" and ")#mi("{\\alpha \\in {\\bf R}/{\\bf Z}}")#text(".")

#list(
[#text("(i) If ")#mi("{m: {\\bf R} \\rightarrow {\\bf C}}")#text(" is a smooth function supported in ")#mi("{[-1/2,1/2]}")#text(", then ")#tao-math("{\\left\\|T_{m;\\alpha}\\right\\|_{B(\\ell^p({\\bf Z}))} \\lesssim \\left\\|T_m\\right\\|_{B(L^p({\\bf R}))}}", block: false)#text(", where ")#mi("{B(V)}")#text(" denotes the operator norm of an operator ")#mi("{T: V \\rightarrow V}")#text(".")],
[#text("(ii) More generally, if ")#mi("{m: {\\bf R} \\rightarrow {\\bf C}}")#text(" is a smooth function supported in ")#mi("{[-1/2Q,1/2Q]}")#text(" for some natural number ")#mi("{Q}")#text(", then ")#tao-math("{\\left\\|T_{m;\\alpha + \\frac{1}{Q}{\\bf Z}/{\\bf Z}}\\right\\|_{B(\\ell^p({\\bf Z}))} \\lesssim \\left\\|T_m\\right\\|_{B(L^p({\\bf R}))}}", block: false)#text(".")]
)
]

#text("When ")#mi("{p=2}")#text(" the implied constant in these bounds can be set to equal ")#mi("{1}")#text(". In the paper of Magyar, Stein, and Wainger it was posed as an open problem as to whether this is the case for other ")#mi("{p}")#text("; in an appendix to this paper I show that the answer is negative if ")#mi("{p}")#text(" is sufficiently close to ")#mi("{1}")#text(" or ")#mi("{\\infty}")#text(", but I do not know the full answer to this question.")

#text("This proposition allows one to get a good multiplier theory for symbols supported near cyclic groups ")#mi("{\\frac{1}{Q}{\\bf Z}/{\\bf Z}}")#text("; for instance it shows that a discrete Fourier multiplier with symbol ")#mi("{\\sum_{\\alpha \\in \\frac{1}{Q}{\\bf Z}/{\\bf Z}} \\phi(Q(\\xi-\\alpha))}")#text(" for a fixed test function ")#mi("{\\phi}")#text(" is bounded on ")#mi("{\\ell^p({\\bf Z})}")#text(", uniformly in ")#mi("{p}")#text(" and ")#mi("{Q}")#text(". For many applications in discrete harmonic analysis, one would similarly like a good multiplier theory for symbols supported in “major arc” sets such as ")#metadata(none) <tao-6558a6a3379db4f31039>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\bigcup_{q=1}^N \\bigcup_{\\alpha \\in \\frac{1}{q}{\\bf Z}/{\\bf Z}} \\alpha + [-\\varepsilon,\\varepsilon]")]]

#text(" ")#text(" and in particular to get a good Littlewood-Paley theory adapted to major arcs. (This is particularly the case when trying to control “true complexity zero” expressions for which the minor arc contributions can be shown to be negligible; ")#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/")[#text("my recent paper with Krause and Mirek")]#text(" is focused on expressions of this type.) At present we do not have a good multiplier theory that is directly adapted to the classical major arc set ")#link(<tao-6558a6a3379db4f31039>)[#text("(1)")]#text(" (though I do not know of rigorous negative results that show that such a theory is not possible); however, ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2188130")[#text("Ionescu and Wainger were able")]#text(" to obtain a useful substitute theory in which ")#link(<tao-6558a6a3379db4f31039>)[#text("(1)")]#text(" was replaced by a somewhat larger set that had better multiplier behaviour. Starting with a finite collection ")#mi("{S}")#text(" of pairwise coprime natural numbers, and a natural number ")#mi("{k}")#text(", one can form the major arc type set")

#metadata(none) <tao-0c1c541af9cc252a1c75>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\bigcup_{\\alpha \\in \\Sigma_{\\leq k}} \\alpha + [-\\varepsilon,\\varepsilon]")]]

#text("where ")#mi("{\\Sigma_{\\leq k} \\subset {\\bf R}/{\\bf Z}}")#text(" consists of all rational points in the unit circle of the form ")#mi("{\\frac{a}{Q} \\mod 1}")#text(" where ")#mi("{Q}")#text(" is the product of at most ")#mi("{k}")#text(" elements from ")#mi("{S}")#text(" and ")#mi("{a}")#text(" is an integer. For suitable choices of ")#mi("{S}")#text(" and ")#mi("{k}")#text(" not too large, one can make this set ")#link(<tao-0c1c541af9cc252a1c75>)[#text("(2)")]#text(" contain the set ")#link(<tao-6558a6a3379db4f31039>)[#text("(1)")]#text(" while still having a somewhat controlled size (very roughly speaking, one chooses ")#mi("{S}")#text(" to consist of (small powers of) large primes between ")#mi("{N^\\rho}")#text(" and ")#mi("{N}")#text(" for some small constant ")#mi("{\\rho>0}")#text(", together with something like the product of all the primes up to ")#mi("{N^\\rho}")#text(" (raised to suitable powers)).")

#text("In the regime where ")#mi("{k}")#text(" is fixed and ")#mi("{\\varepsilon}")#text(" is small, there is a good theory:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Ionescu-Wainger theorem, rough version)")]#text(" If ")#mi("{p}")#text(" is an even integer or the dual of an even integer, and ")#mi("{m: {\\bf R} \\rightarrow {\\bf C}}")#text(" is supported on ")#mi("{[-\\varepsilon,\\varepsilon]}")#text(" for a sufficiently small ")#mi("{\\varepsilon > 0}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left\\|T_{m;\\Sigma_{\\leq k}}\\right\\|_{B(\\ell^p({\\bf Z}))} \\lesssim_{p, k} (\\log(1+\\left|S\\right|))^{O_k(1)} \\left\\|T_m\\right\\|_{B(L^p({\\bf R}))}.", block: true)]]
]

#text("There is a more explicit description of how small ")#mi("{\\varepsilon}")#text(" needs to be for this theorem to work (roughly speaking, it is not much more than what is needed for all the arcs ")#mi("{\\alpha + [-\\varepsilon,\\varepsilon]}")#text(" in ")#link(<tao-0c1c541af9cc252a1c75>)[#text("(2)")]#text(" to be disjoint), but we will not give it here. The logarithmic loss of ")#tao-math("{(\\log(1+\\left|S\\right|))^{O_k(1)}}", block: false)#text(" was reduced to ")#tao-math("{\\log(1+\\left|S\\right|)}", block: false)#text(" ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3738256")[#text("by Mirek")]#text(". In this paper we refine the bound further to ")#metadata(none) <tao-158980e66693a9c1a795>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\|T_{m;\\Sigma_{\\leq k}}\\right\\|_{B(\\ell^p({\\bf Z}))} \\leq O(r \\log(2+kr))^k \\left\\|T_m\\right\\|_{B(L^p({\\bf R}))}.", block: true)]]

#text(" ")#text(" when ")#mi("{p = 2r}")#text(" or ")#mi("{p = (2r)^{\\prime}}")#text(" for some integer ")#mi("{r}")#text(". In particular there is no longer any logarithmic loss in the cardinality of the set ")#mi("{S}")#text(".")

#text("The proof of ")#link(<tao-158980e66693a9c1a795>)[#text("(3)")]#text(" follows a similar strategy as to previous proofs of Ionescu-Wainger type. By duality we may assume ")#mi("{p=2r}")#text(". We use the following standard sequence of steps:")

#list(
[#text("(i) (Denominator orthogonality) First one splits ")#mi("{T_{m;\\Sigma_{\\leq k}} f}")#text(" into various pieces depending on the denominator ")#mi("{Q}")#text(" appearing in the element of ")#mi("{\\Sigma_{\\leq k}}")#text(", and exploits “")#link("https://arxiv.org/abs/2007.10249")[#text("superorthogonality")]#text("” in ")#mi("{Q}")#text(" to estimate the ")#mi("{\\ell^p}")#text(" norm by the ")#mi("{\\ell^p}")#text(" norm of an appropriate square function.")],
[#text("(ii) (Nonconcentration) One expands out the ")#mi("{p^{th}}")#text(" power of the square function and estimates it by a “nonconcentrated” version in which various factors that arise in the expansion are “disjoint”.")],
[#text("(iii) (Numerator orthogonality) We now decompose based on the numerators ")#mi("{a}")#text(" appearing in the relevant elements of ")#mi("{\\Sigma_{\\leq k}}")#text(", and exploit some residual orthogonality in this parameter to reduce to estimating a square-function type expression involving sums over various cosets ")#mi("{\\alpha + \\frac{1}{Q}{\\bf Z}/{\\bf Z}}")#text(".")],
[#text("(iv) (Marcinkiewicz-Zygmund) One uses the Marcinkiewicz-Zygmund theorem relating scalar and vector valued operator norms to eliminate the role of the multiplier ")#mi("{m}")#text(".")],
[#text("(v) (Rubio de Francia) Use a reverse square function estimate of Rubio de Francia type to conclude.")]
)

#text("The main innovations are that of using the probabilistic decoupling method to remove some logarithmic losses in (i), and recent progress on the Erdos-Rado sunflower conjecture (as discussed in ")#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/")[#text("this recent post")]#text(") to improve the bounds in (ii). For (i), the key point is that one can express a sum such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{A \\in \\binom{S}{k}} f_A,")]]

#text("where ")#mi("{\\binom{S}{k}}")#text(" is the set of ")#mi("{k}")#text("-element subsets of an index set ")#mi("{S}")#text(", and ")#mi("{f_A}")#text(" are various complex numbers, as an average")

#align(center)[#tao-fit-display[#mitex("\\sum_{A \\in \\binom{S}{k}} f_A = \\frac{k^k}{k!} {\\bf E} \\sum_{s_1 \\in {\\bf S}_1,\\dots,s_k \\in {\\bf S}_k} f_{\\{s_1,\\dots,s_k\\}}")]]

#text("where ")#mi("{S = {\\bf S}_1 \\cup \\dots \\cup {\\bf S}_k}")#text(" is a random partition of ")#mi("{S}")#text(" into ")#mi("{k}")#text(" subclasses (chosen uniformly over all such partitions), basically because every ")#mi("{k}")#text("-element subset ")#mi("{A}")#text(" of ")#mi("{S}")#text(" has a probability exactly ")#mi("{\\frac{k!}{k^k}}")#text(" of being completely shattered by such a random partition. This “decouples” the index set ")#mi("{\\binom{S}{k}}")#text(" into a Cartesian product ")#mi("{{\\bf S}_1 \\times \\dots \\times {\\bf S}_k}")#text(" which is more convenient for application of the superorthogonality theory. For (ii), the point is to efficiently obtain estimates of the form")

#align(center)[#tao-fit-display[#mitex("(\\sum_{A \\in \\binom{S}{k}} F_A)^r \\lesssim_{k,r} \\sum_{A_1,\\dots,A_r \\in \\binom{S}{k} \\text{ sunflower}} F_{A_1} \\dots F_{A_r}")]]

#text("where ")#mi("{F_A}")#text(" are various non-negative quantities, and a ")#link("https://en.wikipedia.org/wiki/Sunflower_(mathematics)")[#text("sunflower")]#text(" is a collection of sets ")#mi("{A_1,\\dots,A_r}")#text(" that consist of a common “core” ")#mi("{A_0}")#text(" and disjoint “petals” ")#mi("{A_1 \\backslash A_0,\\dots,A_r \\backslash A_0}")#text(". The other parts of the argument are relatively routine; see for instance ")#link("https://arxiv.org/abs/2007.10249")[#text("this survey of Pierce")]#text(" for a discussion of them in the simple case ")#mi("{k=1}")#text(".")

#text("In this paper we interpret the Ionescu-Wainger multiplier theorem as being essentially a consequence of various quantitative versions of the ")#link("https://en.wikipedia.org/wiki/Nyquist%E2%80%93Shannon_sampling_theorem")[#text("Shannon sampling theorem")]#text(". Recall that this theorem asserts that if a (Schwartz) function ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" has its Fourier transform supported on ")#mi("{[-1/2,1/2]}")#text(", then ")#mi("{f}")#text(" can be recovered uniquely from its restriction ")#mi("{f|_{\\bf Z}: {\\bf Z} \\rightarrow {\\bf C}}")#text(". In fact, as can be shown from a little bit of routine Fourier analysis, if we narrow the support of the Fourier transform slightly to ")#mi("{[-c,c]}")#text(" for some ")#mi("{0 < c < 1/2}")#text(", then the restriction ")#mi("{f|_{\\bf Z}}")#text(" has the same ")#mi("{L^p}")#text(" behaviour as the original function, in the sense that ")#metadata(none) <tao-6ea43e45ff5cd60af903>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\| f|_{\\bf Z} \\right\\|_{\\ell^p({\\bf Z})} \\sim_{c,p} \\left\\|f\\right\\|_{L^p({\\bf R})}", block: true)]]

#text(" ")#text(" for all ")#mi("{0 < p \\leq \\infty}")#text("; see Theorem 4.18 of ")#link("https://arxiv.org/abs/2008.00857")[#text("this paper of myself with Krause and Mirek")]#text(". This is consistent with the uncertainty principle, which suggests that such functions ")#mi("{f}")#text(" should behave like a constant at scales ")#mi("{\\sim 1/c}")#text(".")

#text("The quantitative sampling theorem ")#link(<tao-6ea43e45ff5cd60af903>)[#text("(4)")]#text(" can be used to give an alternate proof of Proposition ")#link(<tao-d2a8bfe64f2c5a3eee91>)[#text("1")]#text("(i), basically thanks to the identity")

#align(center)[#tao-fit-display[#mitex("T_{m;0} (f|_{\\bf Z}) = (T_m f)_{\\bf Z}")]]

#text("whenever ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" is Schwartz and has Fourier transform supported in ")#mi("{[-1/2,1/2]}")#text(", and ")#mi("{m}")#text(" is also supported on ")#mi("{[-1/2,1/2]}")#text("; this identity can be easily verified from the Poisson summation formula. A variant of this argument also yields an alternate proof of Proposition ")#link(<tao-d2a8bfe64f2c5a3eee91>)[#text("1")]#text("(ii), where the role of ")#mi("{{\\bf R}}")#text(" is now played by ")#mi("{{\\bf R} \\times {\\bf Z}/Q{\\bf Z}}")#text(", and the standard embedding of ")#mi("{{\\bf Z}}")#text(" into ")#mi("{{\\bf R}}")#text(" is now replaced by the embedding ")#mi("{\\iota_Q: n \\mapsto (n, n \\text{ mod } Q)}")#text(" of ")#mi("{{\\bf Z}}")#text(" into ")#mi("{{\\bf R} \\times {\\bf Z}/Q{\\bf Z}}")#text("; the analogue of ")#link(<tao-6ea43e45ff5cd60af903>)[#text("(4)")]#text(" is now")

#metadata(none) <tao-6e29961c5529e9094a3f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| f \\circ \\iota_Q \\right\\|_{\\ell^p({\\bf Z})} \\sim_{c,p} \\left\\|f\\right\\|_{L^p({\\bf R} \\times {\\bf Z}/Q{\\bf Z})}", block: true)]]

#text("whenever ")#mi("{f: {\\bf R} \\times {\\bf Z}/Q{\\bf Z} \\rightarrow {\\bf C}}")#text(" is Schwartz and has Fourier transform ")#mi("{{\\mathcal F}_{{\\bf R} \\times {\\bf Z}/Q{\\bf Z}} f\\colon {\\bf R} \\times \\frac{1}{Q}{\\bf Z}/{\\bf Z} \\rightarrow {\\bf C}}")#text(" supported in ")#mi("{[-c/Q,c/Q] \\times \\frac{1}{Q}{\\bf Z}/{\\bf Z}}")#text(", and ")#mi("{{\\bf Z}/Q{\\bf Z}}")#text(" is endowed with probability Haar measure.")

#text("The locally compact abelian groups ")#mi("{{\\bf R}}")#text(" and ")#mi("{{\\bf R} \\times {\\bf Z}/Q{\\bf Z}}")#text(" can all be viewed as projections of the adelic integers ")#mi("{{\\bf A}_{\\bf Z} := {\\bf R} \\times \\hat {\\bf Z}}")#text(" (the product of the reals and the ")#link("https://en.wikipedia.org/wiki/Profinite_integer")[#text("profinite integers")]#text(" ")#mi("{\\hat {\\bf Z}}")#text("). By using the Ionescu-Wainger multiplier theorem, we are able to obtain an adelic version of the quantitative sampling estimate ")#link(<tao-6e29961c5529e9094a3f>)[#text("(5)")]#text(", namely")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\circ \\iota \\right\\|_{\\ell^p({\\bf Z})} \\sim_{c,p} \\left\\|f\\right\\|_{L^p({\\bf A}_{\\bf Z})}", block: true)]]

#text("whenever ")#mi("{1 < p < \\infty}")#text(", ")#mi("{f: {\\bf A}_{\\bf Z} \\rightarrow {\\bf C}}")#text(" is ")#link("https://en.wikipedia.org/wiki/Schwartz%E2%80%93Bruhat_function")[#text("Schwartz-Bruhat")]#text(" and has Fourier transform ")#mi("{{\\mathcal F}_{{\\bf A}_{\\bf Z}} f: {\\bf R} \\times {\\bf Q}/{\\bf Z} \\rightarrow {\\bf C}}")#text(" supported on ")#mi("{[-\\varepsilon,\\varepsilon] \\times \\Sigma_{\\leq k}}")#text(" for some sufficiently small ")#mi("{\\varepsilon}")#text(" (the precise bound on ")#mi("{\\varepsilon}")#text(" depends on ")#mi("{S, p, c}")#text(" in a fashion not detailed here). This allows one obtain an “adelic” extension of the Ionescu-Wainger multiplier theorem, in which the ")#mi("{\\ell^p({\\bf Z})}")#text(" operator norm of any discrete multiplier operator whose symbol is supported on major arcs can be shown to be comparable to the ")#mi("{L^p({\\bf A}_{\\bf Z})}")#text(" operator norm of an adelic counterpart to that multiplier operator; in principle this reduces “major arc” harmonic analysis on the integers ")#mi("{{\\bf Z}}")#text(" to “low frequency” harmonic analysis on the adelic integers ")#mi("{{\\bf A}_{\\bf Z}}")#text(", which is a simpler setting in many ways (mostly because the set of major arcs ")#link(<tao-0c1c541af9cc252a1c75>)[#text("(2)")]#text(" is now replaced with a product set ")#mi("{[-\\varepsilon,\\varepsilon] \\times \\Sigma_{\\leq k}}")#text(").")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/08/13/the-ionescu-wainger-multiplier-theorem-and-the-adeles/#comment-582065")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2020")])]

#text("Maygar everywhere in the text should be Magyar (means Hungarian)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/08/13/the-ionescu-wainger-multiplier-theorem-and-the-adeles/#comment-582222")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2020")])]

#text("Are there similar results for “minor arcs” ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63c5e3d164b60dbf2c30b341adc5ad73b787518ecb74470ab6a00431ab9dc71a-de3e719e9960b0a44f0116a1201823a8b5ddfd465aacf6c51ba7363425eb9495.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuyao")]], [#link("https://terrytao.wordpress.com/2020/08/13/the-ionescu-wainger-multiplier-theorem-and-the-adeles/#comment-582495")[#strong[#text("liuyao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2020")])]

#text("A suggestion for your blog in general: how about the “main text font” set to serif, instead of sans serif? I thought it would work better with inline latex (which is serif). Don’t know why no one does it. In the early days, sans serif is preferred for reading on lower-resolution displays. You may give it a try by following the steps here ")#link("https://themeisle.com/blog/improve-wordpress-blog-typography/")[#text("https://themeisle.com/blog/improve-wordpress-blog-typography/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1df03c4c27ea6a16ba68def56427781617e0652a8ba0ad0de5626808a8051fb9-2f805c85058f6ee35120268a608cf1564a622d4e31760251be271316574ade2b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sliderman")]], [#link("https://terrytao.wordpress.com/2020/08/13/the-ionescu-wainger-multiplier-theorem-and-the-adeles/#comment-582526")[#strong[#text("Sliderman")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2020")])]

#text("General remark: Why not associate Dr. Mariusz Mirek as the second author of the present paper (if he agrees of course and, in this case, update the Acknowledgments section 1.1) ?")#linebreak()#text(" Minor mistake founded:")#linebreak()#text(" – on the blog: the Erdos-Rado sunflower conjecture => the Erdo:s-Rado sunflower conjecture ;")#linebreak()#text(" – in the paper: p. 33 applictaions => applications")#linebreak()#text(" Best written sentence: The key point here is that we can cover the whole Farey sequence U by using well-suited major arcs whose width can be choosen as large as possible in respect to exp (…).")#linebreak()#text(" p. 37 mollification => modification ;")#linebreak()#text(" References")#linebreak()#text(" #1 …, 624-630, 22-26 June 2020, Chicago, IL, USA.")#linebreak()#text(" #21 … A Littlewood-Paley … Revista Matema’tica Iberoamericana 1(2):1-14, 1985.")#linebreak()#text(" #22 … Chernoff-Hoeffding Bounds for Applications with Limited Independence. in: SODA 1993 Proceedings of the 4th Annual ACM/SIGACT – ACM Symposium on Discrete Algorithms, 331-340, 25-27 January 1993, Austin, TX, USA.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/08/13/the-ionescu-wainger-multiplier-theorem-and-the-adeles/#comment-582604")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2020")])]

#text("These are some great spelling corrections. Maybe you should also be made a coauthor.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1df03c4c27ea6a16ba68def56427781617e0652a8ba0ad0de5626808a8051fb9-2f805c85058f6ee35120268a608cf1564a622d4e31760251be271316574ade2b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/08/13/the-ionescu-wainger-multiplier-theorem-and-the-adeles/#comment-582632")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2020")])]

#text("In the paper uploaded on ArXiv, here are some other corrections only at the lexical level:")#linebreak()#text(" – page 6 : whhich -> which")#linebreak()#text(" The argument uses the same basic approach -> The argument follows the same basic approach")#linebreak()#text(" – the reference [3] should be written as follows: F. Bruhat. … à l’étude des représentations des groupes p-adiques. Bulletin de la Société Mathématique de France (SMF), 89, 43-75, Paris, France, 1961.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/08/13/the-ionescu-wainger-multiplier-theorem-and-the-adeles/#comment-583261")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2020")])]

#text("In the paper uploaded to ArXiv:")#linebreak()#text(" “unimportant” -> “negligible” seems to be more suited in this context")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/08/13/the-ionescu-wainger-multiplier-theorem-and-the-adeles/#comment-583729")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2020")])]

#text("Dear Pro. Terence Tao,")#linebreak()#text(" I entirely think that you are the only mathematician in the world which has been prospective the best by the all students and mathematicians. You are intelligent enough to understand my idea and you know that you should do what I say here. You are a mathematician, so you should value your time. Day by day, time goes by very quickly and you can not come back. This year 2020, you maybe promise me as well as math comunity to climb the highest peak of mountain in maths? I always expect you everyday and hope you will be successful sooner.")#linebreak()#text(" Best wishes,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YiaoMin")]], [#link("https://terrytao.wordpress.com/2020/08/13/the-ionescu-wainger-multiplier-theorem-and-the-adeles/#comment-592109")[#strong[#text("YiaoMin")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2020")])]

#text("Dear Professor Tao,")#linebreak()#text(" Typos founded in your ArXiv uploaded paper:")#linebreak()#text(" – whhich –> which")#linebreak()#text(" – mollification –> modification")#linebreak()#text(" – applictaions –> applications")#linebreak()#text(" In your bibliography:")#linebreak()#text(" [3] l’tude –> l’étude")#linebreak()#text(" [21] A LittlewoodPaley –> A Littlewood-Paley")#linebreak()#text(" [22] in: Proceedings of SODA 1993")#linebreak()#text(" Best regards")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/08/13/the-ionescu-wainger-multiplier-theorem-and-the-adeles/#comment-678629")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2023")])]

#text("Hello: Professor Tao, in section 5 of your paper, on the construction of Ionescu-Wainger major arc, Lemma 5.1. Is the condition ")#mi("N\\geq 2^k")#text(" essential? It seems that without this condition, (iii) still holds for certain absolute constant ")#mi("C")#text(".")

#text("I am learning the ")#mi("\\ell^p(\\mathbb{Z})")#text(" variational estimate of the polynomial partial sum operator ")#mi("M_N(f)(x)=\\frac{1}{N}\\sum_{0\\leq n\\leq N-1}f(x-P(n)),\\text{ where }N\\in\\mathbb{N}")#text(". It defines a Ionescu-Wainger frequencies by ")#mi("\\Sigma_{\\leq k}(N)=\\{a/q:\\ q\\text{ is a product of at most }k \\text{ elements in }S\\}")#text(", and then defining a height for rational number ")#mi("\\theta")#text(" by ")#mi("\\mathbf{h}_{\\rho}(\\theta)=\\inf\\{N\\in 2^\\mathbb{N}:\\ \\theta\\in \\Sigma_{\\leq k}(N)\\}")#text(".")

#text("If ")#mi("N\\geq 2^k")#text(", then I met some problems when verifying that ")#mi("\\mathbf{h}_{\\rho}(a/q)\\leq q")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/08/13/the-ionescu-wainger-multiplier-theorem-and-the-adeles/#comment-678717")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2023")])]

#text("It’s quite possible that one can extend these estimates (perhaps with some ")#mi("k")#text("-dependent losses in the constants) to have ")#mi("N")#text(" go all the way down to ")#mi("1")#text(", but in any case one can add the restriction ")#mi("N \\geq 2^k")#text(" to the definition of height and then one should get a bound such as ")#mi("{\\mathbf h}_\\rho(a/q) \\ll_k q")#text(" which should suffice in many applications (usually ")#mi("k")#text(" is bounded).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/08/13/the-ionescu-wainger-multiplier-theorem-and-the-adeles/#comment-681906")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2023")])]

#text("Hello professor Tao:")#linebreak()#text(" I have a question in the proof of Lemma 4.2 (ii). From the definition of superorthogonality in (2.2), to prove that ")#mi("(f_{\\Sigma_A})")#text(" is type II superorthogonal, here we should take ")#mi("X=\\mathbb{Z}")#text(" with counting measure, then (2.2) becomes ")#mi("\\sum_{n\\in\\mathbb{Z}}\\prod_{j=1}^{r}\\langle f_{A_j}(n),f_{A_{r+j}}(n)\\rangle_H=0")

#text("Then you said that (ii) is proved via inspecting the Fourier transform. Do you mean by Plancherel formula ")#mi("\\langle f,g\\rangle_{\\ell^2(\\mathbb{Z})}=\\langle \\hat{f},\\hat{g}\\rangle_{L^2(\\mathbb{T})}")#text("?")#linebreak()#text(" If ")#mi("r>2")#text(", how could we use Plancherel formula? I think maybe one can write (2.2) as ")#mi("\\sum_{n\\in\\mathbb{Z}}\\langle f_{A_1}(n),f_{A_{r+1}}(n)\\rangle_H\\cdot\\prod_{j=2}^{r}\\langle f_{A_j}(n),f_{A_{r+j}}(n)\\rangle_H")#text(". Then use Plancherel to prove that the supports of their Fourier transform do not intersect. However, I can not understand how to reduce to ")#mi("\\sum_1^r (\\alpha_j+\\theta_j)-\\sum_{r+1}^{2r}(\\alpha_j+\\theta_j)\\neq0")#text(".")

#text("P.S. I can understand the argument when taking ")#mi("H=\\mathbb{C}")#text(", which is very easy, just use Plancherel to the product ")#mi("f_{A_1}f_{A_2}...f_{A_r}")#text(" and ")#mi("\\overline{f_{A_{r+1}}} \\overline{f_{A_{r+2}}}...\\overline{f_{A_{2r}}}")#text(". But it made me confused when dealing with general Hilbert space ")#mi("H")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/08/13/the-ionescu-wainger-multiplier-theorem-and-the-adeles/#comment-681908")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2023")])]

#text("Correction: I thought I misunderstood your argument. To prove that ")#mi("\\sum_ng(n)=0")#text(", its equivalent to show that ")#mi("\\hat{g}(0)=0")#text(", which is equivalent to show that 0 is not in the support of the Fourier transform of ")#mi("g")#text(". Now we only need to study the support of the Fourier transform of the function ")#mi("\\prod_{j=1}^r\\langle f_{A_j}(n),f_{A_{r+j}}(n)\\rangle_H")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/08/13/the-ionescu-wainger-multiplier-theorem-and-the-adeles/#comment-681909")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2023")])]

#text("Once one can establish this vanishing in the scalar case ")#mi("H = {\\bf C}")#text(", the vector-valued case can then be established by decomposing the vector-valued functions with respect to some arbitrarily chosen orthonormal basis and applying the scalar theory to each of the terms arising from various combinations of the coefficients in that basis.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/08/13/the-ionescu-wainger-multiplier-theorem-and-the-adeles/#comment-681910")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2023")])]

#text("Yes, thank you very much for an immediate reply. I just figured out it by using an orthonormal basis of H.")
]
]
]
]
