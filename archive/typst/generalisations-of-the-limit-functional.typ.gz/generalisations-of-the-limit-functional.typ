// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/
// Converted to Typst by tao2typ: "2026-10-14T10:40:40.085829+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Generalisations of the limit functional", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Generalisations of the limit functional")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 May 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/")[#text("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Suppose one has a bounded sequence ")#mi("{(a_n)_{n=1}^\\infty = (a_1, a_2, \\dots)}")#text(" of real numbers. What kinds of limits can one form from this sequence?")

#text("Of course, we have the usual notion of limit ")#mi("{\\lim_{n \\rightarrow \\infty} a_n}")#text(", which in this post I will refer to as the ")#emph[#text("classical limit")]#text(" to distinguish from the other limits discussed in this post. The classical limit, if it exists, is the unique real number ")#mi("{L}")#text(" such that for every ")#mi("{\\varepsilon>0}")#text(", one has ")#tao-math("{\\left|a_n-L\\right| \\leq \\varepsilon}", block: false)#text(" for all sufficiently large ")#mi("{n}")#text(". We say that a sequence is (classically) convergent if its classical limit exists. The classical limit obeys many useful ")#emph[#text("limit laws")]#text(" when applied to classically convergent sequences. Firstly, it is linear: if ")#mi("{(a_n)_{n=1}^\\infty}")#text(" and ")#mi("{(b_n)_{n=1}^\\infty}")#text(" are classically convergent sequences, then ")#mi("{(a_n+b_n)_{n=1}^\\infty}")#text(" is also classically convergent with ")#metadata(none) <tao-2f48b881ea7073f1c6f0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\lim_{n \\rightarrow \\infty} (a_n + b_n) = (\\lim_{n \\rightarrow \\infty} a_n) + (\\lim_{n \\rightarrow \\infty} b_n)")]]

#text(" and similarly for any scalar ")#mi("{c}")#text(", ")#mi("{(ca_n)_{n=1}^\\infty}")#text(" is classically convergent with ")#metadata(none) <tao-2eca094654ff645c50cf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\lim_{n \\rightarrow \\infty} (ca_n) = c \\lim_{n \\rightarrow \\infty} a_n.")]]

#text(" It is also an algebra homomorphism: ")#mi("{(a_n b_n)_{n=1}^\\infty}")#text(" is also classically convergent with ")#metadata(none) <tao-74fc00afd03ae325a97e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\lim_{n \\rightarrow \\infty} (a_n b_n) = (\\lim_{n \\rightarrow \\infty} a_n) (\\lim_{n \\rightarrow \\infty} b_n).")]]

#text(" We also have shift invariance: if ")#mi("{(a_n)_{n=1}^\\infty}")#text(" is classically convergent, then so is ")#mi("{(a_{n+1})_{n=1}^\\infty}")#text(" with ")#metadata(none) <tao-ecd3fad7a4d35d7130c6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\lim_{n \\rightarrow \\infty} a_{n+1} = \\lim_{n \\rightarrow \\infty} a_n")]]

#text(" and more generally in fact for any injection ")#mi("{\\phi: {\\bf N} \\rightarrow {\\bf N}}")#text(", ")#mi("{(a_{\\phi(n)})_{n=1}^\\infty}")#text(" is classically convergent with ")#metadata(none) <tao-7ae152b42c7f197b2245>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\lim_{n \\rightarrow \\infty} a_{\\phi(n)} = \\lim_{n \\rightarrow \\infty} a_n.")]]

#text(" The classical limit of a sequence is unchanged if one modifies any finite number of elements of the sequence. Finally, we have boundedness: for any classically convergent sequence ")#mi("{(a_n)_{n=1}^\\infty}")#text(", one has ")#metadata(none) <tao-5e1cf42878df58fea7bf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\inf_n a_n \\leq \\lim_{n \\rightarrow \\infty} a_n \\leq \\sup_n a_n.")]]

#text(" One can in fact show without much difficulty that these laws uniquely determine the classical limit functional on convergent sequences.")

#text("One would like to extend the classical limit notion to more general bounded sequences; however, when doing so one must give up one or more of the desirable limit laws that were listed above. Consider for instance the sequence ")#mi("{a_n = (-1)^n}")#text(". On the one hand, one has ")#mi("{a_n^2 = 1}")#text(" for all ")#mi("{n}")#text(", so if one wishes to retain the homomorphism property ")#link(<tao-74fc00afd03ae325a97e>)[#text("(3)")]#text(", any “limit” of this sequence ")#mi("{a_n}")#text(" would have to necessarily square to ")#mi("{1}")#text(", that is to say it must equal ")#mi("{+1}")#text(" or ")#mi("{-1}")#text(". On the other hand, if one wished to retain the shift invariance property ")#link(<tao-ecd3fad7a4d35d7130c6>)[#text("(4)")]#text(" as well as the homogeneity property ")#link(<tao-2eca094654ff645c50cf>)[#text("(2)")]#text(", any “limit” of this sequence would have to equal its own negation and thus be zero.")

#text("Nevertheless there are a number of useful generalisations and variants of the classical limit concept for non-convergent sequences that obey a significant portion of the above limit laws. For instance, we have the ")#link("https://en.wikipedia.org/wiki/Limit_superior_and_limit_inferior")[#text("limit superior")]

#align(center)[#tao-fit-display[#mitex("\\limsup_{n \\rightarrow \\infty} a_n := \\inf_N \\sup_{n \\geq N} a_n")]]

#text("and ")#link("https://en.wikipedia.org/wiki/Limit_superior_and_limit_inferior")[#text("limit inferior")]

#align(center)[#tao-fit-display[#mitex("\\liminf_{n \\rightarrow \\infty} a_n := \\sup_N \\inf_{n \\geq N} a_n")]]

#text("which are well-defined real numbers for any bounded sequence ")#mi("{(a_n)_{n=1}^\\infty}")#text("; they agree with the classical limit when the sequence is convergent, but disagree otherwise. They enjoy the shift-invariance property ")#link(<tao-ecd3fad7a4d35d7130c6>)[#text("(4)")]#text(", and the boundedness property ")#link(<tao-5e1cf42878df58fea7bf>)[#text("(6)")]#text(", but do not in general obey the homomorphism property ")#link(<tao-74fc00afd03ae325a97e>)[#text("(3)")]#text(" or the linearity property ")#link(<tao-2f48b881ea7073f1c6f0>)[#text("(1)")]#text("; indeed, we only have the subadditivity property")

#align(center)[#tao-fit-display[#mitex("\\limsup_{n \\rightarrow \\infty} (a_n + b_n) \\leq (\\limsup_{n \\rightarrow \\infty} a_n) + (\\limsup_{n \\rightarrow \\infty} b_n)")]]

#text("for the limit superior, and the superadditivity property")

#align(center)[#tao-fit-display[#mitex("\\liminf_{n \\rightarrow \\infty} (a_n + b_n) \\geq (\\liminf_{n \\rightarrow \\infty} a_n) + (\\liminf_{n \\rightarrow \\infty} b_n)")]]

#text("for the limit inferior. The homogeneity property ")#link(<tao-2eca094654ff645c50cf>)[#text("(2)")]#text(" is only obeyed by the limits superior and inferior for non-negative ")#mi("{c}")#text("; for negative ")#mi("{c}")#text(", one must have the limit inferior on one side of ")#link(<tao-2eca094654ff645c50cf>)[#text("(2)")]#text(" and the limit superior on the other, thus for instance")

#align(center)[#tao-fit-display[#mitex("\\limsup_{n \\rightarrow \\infty} (-a_n) = - \\liminf_{n \\rightarrow \\infty} a_n.")]]

#text("The limit superior and limit inferior are examples of ")#link("https://en.wikipedia.org/wiki/Limit_point")[#text("limit points")]#text(" of the sequence, which can for instance be defined as points that are limits of at least one subsequence of the original sequence. Indeed, the limit superior is always the largest limit point of the sequence, and the limit inferior is always the smallest limit point. However, limit points can be highly non-unique (indeed they are unique if and only if the sequence is classically convergent), and so it is difficult to sensibly interpret most of the usual limit laws in this setting, with the exception of the homogeneity property ")#link(<tao-2eca094654ff645c50cf>)[#text("(2)")]#text(" and the boundedness property ")#link(<tao-5e1cf42878df58fea7bf>)[#text("(6)")]#text(" that are easy to state for limit points.")

#text("Another notion of limit are the ")#link("https://en.wikipedia.org/wiki/Ces%C3%A0ro_summation")[#text("Césaro limits")]

#align(center)[#tao-fit-display[#mitex("\\mathrm{C}\\!\\!-\\!\\!\\lim_{n \\rightarrow \\infty} a_n := \\lim_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N a_n;")]]

#text("if this limit exists, we say that the sequence is Césaro convergent. If the sequence ")#mi("{(a_n)_{n=1}^\\infty}")#text(" already has a classical limit, then it also has a Césaro limit that agrees with the classical limit; but there are additional sequences that have a Césaro limit but not a classical one. For instance, the non-classically convergent sequence ")#mi("{a_n= (-1)^n}")#text(" discussed above is Césaro convergent, with a Césaro limit of ")#mi("{0}")#text(". However, there are still bounded sequences that do not have Césaro limit, such as ")#mi("{a_n := \\sin( \\log n )}")#text(" (exercise!), basically because such sequences oscillate too slowly for the Césaro averaging to be of much use in accelerating the convergence. The Césaro limit is linear, bounded, and shift invariant, but not an algebra homomorphism and also does not obey the rearrangement property ")#link(<tao-7ae152b42c7f197b2245>)[#text("(5)")]#text(".")

#text("Using ")#link("https://en.wikipedia.org/wiki/Hahn%E2%80%93Banach_theorem")[#text("the Hahn-Banach theorem")]#text(", one can extend the classical limit functional to ")#emph[#text("generalised limit functionals")]#text(" ")#mi("{\\mathop{\\widetilde \\lim}_{n \\rightarrow \\infty} a_n}")#text(", defined to be bounded linear functionals from the space ")#mi("{\\ell^\\infty({\\bf N})}")#text(" of bounded real sequences to the real numbers ")#mi("{{\\bf R}}")#text(" that extend the classical limit functional (defined on the space ")#mi("{c_0({\\bf N}) + {\\bf R}}")#text(" of convergent sequences) without any increase in the operator norm. (In some of my past writings I made the slight error of referring to these generalised limit functionals as ")#link("https://en.wikipedia.org/wiki/Banach_limit")[#text("Banach limits")]#text(", though as discussed below, the latter actually refers to a subclass of generalised limit functionals.) It is not difficult to see that such generalised limit functionals will range between the limit inferior and limit superior. In fact, for any specific sequence ")#mi("{(a_n)_{n=1}^\\infty}")#text(" and any number ")#mi("{L}")#text(" lying in the closed interval ")#mi("{[\\liminf_{n \\rightarrow \\infty} a_n, \\limsup_{n \\rightarrow \\infty} a_n]}")#text(", there exists at least one generalised limit functional ")#mi("{\\mathop{\\widetilde \\lim}_{n \\rightarrow \\infty}}")#text(" that takes the value ")#mi("{L}")#text(" when applied to ")#mi("{a_n}")#text("; for instance, for any number ")#mi("{\\theta}")#text(" in ")#mi("{[-1,1]}")#text(", there exists a generalised limit functional that assigns that number ")#mi("{\\theta}")#text(" as the “limit” of the sequence ")#mi("{a_n = (-1)^n}")#text(". This claim can be seen by first designing such a limit functional on the vector space spanned by the convergent sequences and by ")#mi("{(a_n)_{n=1}^\\infty}")#text(", and then appealing to the Hahn-Banach theorem to extend to all sequences. This observation also gives a necessary and sufficient criterion for a bounded sequence ")#mi("{(a_n)_{n=1}^\\infty}")#text(" to classically converge to a limit ")#mi("{L}")#text(", namely that all generalised limits of this sequence must equal ")#mi("{L}")#text(".")

#strike[#text("Because of the reliance on the Hahn-Banach theorem, the existence of generalised limits requires the axiom of choice (or some weakened version thereof); there are models of set theory without the axiom of choice in which no generalised limits exist. For instance, consider a ")#link("https://en.wikipedia.org/wiki/Solovay_model")[#text("Solovay model")]#text(" in which all subsets of the real numbers are measurable. If one lets ")#mi("{e_n: {\\bf R} \\rightarrow \\{0,1,2\\}}")#text(" denote the function that extracts the ")#mi("{n^{th}}")#text(" ternary digit past the decimal point (thus ")#mi("{e_n(x) = \\lfloor 3^n x \\rfloor \\text{ mod } 3}")#text(", and lets ")#mi("{\\mathop{\\widetilde \\lim}}")#text(" be a generalised limit functional, then the function ")#mi("{f(x) := \\mathop{\\widetilde \\lim}_{n \\rightarrow \\infty} e_n(x)}")#text(" is non-constant (e.g. ")#mi("{f(0)=0}")#text(" and ")#mi("{f(1/2)=1}")#text("), but also invariant almost everywhere with respect to translation by ternary rationals ")#mi("{a/3^n}")#text(", and hence cannot be measurable (due to the continuity of translation in the strong operator topology, or the ")#link("https://en.wikipedia.org/wiki/Steinhaus_theorem")[#text("Steinhaus lemma")]#text("), and so generalised limit functionals cannot exist.")]

#text("Generalised limits can obey the shift-invariance property ")#link(<tao-ecd3fad7a4d35d7130c6>)[#text("(4)")]#text(" or the algebra homomorphism property ")#link(<tao-74fc00afd03ae325a97e>)[#text("(3)")]#text(", but as the above analysis of the sequence ")#mi("{a_n = (-1)^n}")#text(" shows, they cannot do both. Generalised limits that obey the shift-invariance property ")#link(<tao-ecd3fad7a4d35d7130c6>)[#text("(4)")]#text(" are known as ")#link("https://en.wikipedia.org/wiki/Banach_limit")[#text("Banach limits")]#text("; one can for instance construct them by applying the Hahn-Banach theorem to the Césaro limit functional; alternatively, if ")#mi("{\\mathop{\\widetilde \\lim}}")#text(" is any generalised limit, then the Césaro-type functional ")#mi("{(a_n)_{n=1}^\\infty \\mapsto \\mathop{\\widetilde \\lim}_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N a_n}")#text(" will be a Banach limit. The existence of Banach limits can be viewed as a demonstration of the amenability of the natural numbers (or integers); see ")#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/")[#text("this previous blog post")]#text(" for further discussion.")

#text("Generalised limits that obey the algebra homomorphism property ")#link(<tao-74fc00afd03ae325a97e>)[#text("(3)")]#text(" are known as ")#emph[#text("ultrafilter limits")]#text(". If one is given a generalised limit functional ")#mi("{p\\!\\!-\\!\\!\\lim_{n \\rightarrow \\infty}}")#text(" that obeys ")#link(<tao-74fc00afd03ae325a97e>)[#text("(3)")]#text(", then for any subset ")#mi("{A}")#text(" of the natural numbers ")#mi("{{\\bf N}}")#text(", the generalised limit ")#mi("{p\\!\\!-\\!\\!\\lim_{n \\rightarrow \\infty} 1_A(n)}")#text(" must equal its own square (since ")#mi("{1_A(n)^2 = 1_A(n)}")#text(") and is thus either ")#mi("{0}")#text(" or ")#mi("{1}")#text(". If one defines ")#mi("{p \\subset 2^{2^{\\bf N}}}")#text(" to be the collection of all subsets ")#mi("{A}")#text(" of ")#mi("{{\\bf N}}")#text(" for which ")#mi("{p\\!\\!-\\!\\!\\lim_{n \\rightarrow \\infty} 1_A(n) = 1}")#text(", one can verify that ")#mi("{p}")#text(" obeys the axioms of a ")#link("https://en.wikipedia.org/wiki/Ultrafilter")[#text("non-principal ultrafilter")]#text(". Conversely, if ")#mi("{p}")#text(" is a non-principal ultrafilter, one can define the associated generalised limit ")#mi("{p\\!\\!-\\!\\!\\lim_{n \\rightarrow \\infty} a_n}")#text(" of any bounded sequence ")#mi("{(a_n)_{n=1}^\\infty}")#text(" to be the unique real number ")#mi("{L}")#text(" such that the sets ")#tao-math("{\\{ n \\in {\\bf N}: \\left|a_n - L\\right| \\leq \\varepsilon \\}}", block: false)#text(" lie in ")#mi("{p}")#text(" for all ")#mi("{\\varepsilon>0}")#text("; one can check that this does indeed give a well-defined generalised limit that obeys ")#link(<tao-74fc00afd03ae325a97e>)[#text("(3)")]#text(". Non-principal ultrafilters can be constructed using ")#link("https://en.wikipedia.org/wiki/Zorn%27s_lemma")[#text("Zorn’s lemma")]#text(". In fact, they do not quite need the full strength of the axiom of choice; see ")#link("https://en.wikipedia.org/wiki/Boolean_prime_ideal_theorem#The_ultrafilter_lemma")[#text("the Wikipedia article on the ultrafilter lemma")]#text(" for examples.")

#text("We have previously noted that generalised limits of a sequence can converge to any point between the limit inferior and limit superior. The same is not true if one restricts to Banach limits or ultrafilter limits. For instance, by the arguments already given, the only possible Banach limit for the sequence ")#mi("{a_n = (-1)^n}")#text(" is zero. Meanwhile, an ultrafilter limit must converge to a limit point of the original sequence, but conversely every limit point can be attained by at least one ultrafilter limit; we leave these assertions as an exercise to the interested reader. In particular, a bounded sequence converges classically to a limit ")#mi("{L}")#text(" if and only if all ultrafilter limits converge to ")#mi("{L}")#text(".")

#text("There is no generalisation of the classical limit functional to any space that includes non-classically convergent sequences that obeys the subsequence property ")#link(<tao-7ae152b42c7f197b2245>)[#text("(5)")]#text(", since any non-classically-convergent sequence will have one subsequence that converges to the limit superior, and another subsequence that converges to the limit inferior, and one of these will have to violate ")#link(<tao-7ae152b42c7f197b2245>)[#text("(5)")]#text(" since the limit superior and limit inferior are distinct. So the above limit notions come close to the best generalisations of limit that one can use in practice.")

#text("(Added after comments) If ")#mi("{\\beta {\\bf N}}")#text(" denotes the ")#link("https://en.wikipedia.org/wiki/Stone%E2%80%93%C4%8Cech_compactification")[#text("Stone-Cech compactification")]#text(" of the natural numbers, then ")#mi("{\\ell^\\infty({\\bf N})}")#text(" can be canonically identified with the continuous functions on ")#mi("{\\beta {\\bf N}}")#text(", and hence by the Riesz representation theorem, bounded linear functionals on ")#mi("{\\ell^\\infty({\\bf N})}")#text(" can be identified with finite measures on this space. From this it is not difficult to show that generalised limit functionals can be canonically identified with probability measures on the compact Hausdorff space ")#mi("{\\beta {\\bf N} \\backslash {\\bf N}}")#text(", that ultrafilter limits correspond to those probability measures that are Dirac measures (i.e. they can be canonically identified with points in ")#mi("{\\beta {\\bf N} \\backslash {\\bf N}}")#text("), and Banach limits correspond to those probability measures that are invariant with respect to the translation action of the integers ")#mi("{{\\bf Z}}")#text(" on ")#mi("{\\beta {\\bf N} \\backslash {\\bf N}}")#text(".")

#text("We summarise (some of) the above discussion in the following table:")

#table(columns: 6, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Limit")],
table.cell(colspan: 1, rowspan: 1)[#text("Always defined")],
table.cell(colspan: 1, rowspan: 1)[#text("Linear")],
table.cell(colspan: 1, rowspan: 1)[#text("Shift-invariant")],
table.cell(colspan: 1, rowspan: 1)[#text("Homomorphism")],
table.cell(colspan: 1, rowspan: 1)[#text("Constructive")],
table.cell(colspan: 1, rowspan: 1)[#text("Classical")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("Superior")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("Inferior")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("Césaro")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("Generalised")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("Depends")],
table.cell(colspan: 1, rowspan: 1)[#text("Depends")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#text("Banach")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#text("Ultrafilter")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("No")],
table.cell(colspan: 1, rowspan: 1)[#text("Yes")],
table.cell(colspan: 1, rowspan: 1)[#text("No")]
)

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (41)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f2de6aa9514af890cf2226c874137fb5322023fc83b06ca2703201c9deb6779-dbf670f5df7e0cfe04ec1a026cb9a951ca7f729abb7f7c3bc9e00cfe91f09427.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aryeh")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-480538")[#strong[#text("Aryeh")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2017")])]

#text("I think the inequality sign in the superadditive property of liminf is backwards.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/669e79ea75ca65fa0dc1a6551eb9dd396c642e2c496689173f33adc25aaa41e5-d02f4e797b144a9174ffccc4c84ce03cbd8a2534183846c32e7aa18a3db04bee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiangui Zhao")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-480546")[#strong[#text("Xiangui Zhao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2017")])]

#text("I think there is a redundant word “the” in the sentence “Indeed, the limit superior is the always the largest limit point of the sequence, and… ”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-480547")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2017")])]

#text("Something pear-shaped about the definition of Césaro limit (singular?),")#linebreak()#text(" which currently reads “C minus lim … := …” ?")#linebreak()#text(" WFL")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Crust")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-480548")[#strong[#text("Crust")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2017")])]

#text("I think it’s correct. You should think of “-” here as “dash” not “minus” as in “p-norm” or “semi-ring”, etc.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-480555")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2017")])]

#text("What is the meaning of “maybe” in the table?")

#emph[#text("[Reworded to “Depends” for clarity – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-480560")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2017")])]

#text("In the fifth line, it seems that “this point” should be “this post”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-480562")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2017")])]

#text("One can identify ")#mi("\\ell^\\infty")#text(" with ")#mi("C(\\beta \\mathbf{N})")#text(", and hence the dual of ")#mi("\\ell^\\infty")#text(" with the space of bounded measures on ")#mi("\\beta \\mathbf{N}")#text(". Stipulating that nonnegative sequences map to nonnegative limits and 1 maps to 1 forces the measure to be a probability measure, so you can think of an arbitrary linear generalized limit as a “convex combination” of ultrafilter limits.")

#emph[#text("[Thanks, I’ve added this remark to the post. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-480590")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2017")])]

#text("Can Ramanujan’s example ")#mi("1+2+3+ ... =-1/12")#text(" be considered as a generalized limit of its partial sums in the sense of one of the above generalized limit methods?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-480598")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2017")])]

#text("This example well predates Ramanujan (it’s basically due to Riemann). And belongs to a different notion of limits, “regularization”. The sequence of partial sums is truly divergent and beyond the reach of this kind of generalized limits.")

#text("The value ")#mi("-\\frac{1}{12}")#text(" comes from interpreting the sum formally as the value at ")#mi("s=-1")#text(" of the series ")#mi("\\zeta(s) = \\sum_{n\\geq 1} n^{-s}")#text(" and using the analytical continuation from the usual domain of convergence ")#mi("\\Re(s)>1")#text(".")

#text("It is more in the spirit of setting ")#mi("1+2+4+8+16+32+\\cdots = -1")#text(" by analytical continuation of the formula for the sum of geometric series [though this geometric series does converge with respect to the ")#mi("2")#text("-adic absolute value].")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-480599")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2017")])]

#text("Sorry – I now see that Ramanujan did independently discover this result, through manipulation of infinite series. My comment otherwise stands: while some of the approaches above (e.g. Cesàro summation) can sometimes deal with unbounded sequences, this sum is beyond their reach.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-480600")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2017")])]

#text("Thanks for the information!")#linebreak()#text(" In fact, I credited Ramanujan for this example because he stated it in one of his early letters to Hardy.")#linebreak()#text(" Meanwhile, I found more information on this type of “series regularization” in the Wikipedia articles “Ramanujan summation” and “Abel – Plana formula”.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b9d2b471a95950cf9ab900a2a956433a802e53dd7dce19b8f99e969eecbfb6d-928b219cdc034ba412fab685a5c24ece80537934e15e706cc872bf337f74deba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of allenknutson")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-480595")[#strong[#text("allenknutson")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2017")])]

#text("I like to define “continuous” as “commutes with the limit functional”, for people who have recently learned the definition of “linear” as “commutes with addition and scalar multiplications”.")

#text("Do you really want to expand sup/inf to superior/inferior not supremum/infimum?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-480602")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2017")])]

#text("From a nonstandard analysis point of view, one can precisely describe the continuous functions as the standard functions ")#mi("f: {\\bf R} \\to {\\bf R}")#text(" whose nonstandard extension ")#mi("{}^* f: {}^* {\\bf R} \\to {}^* {\\bf R}")#text(", when restricted to the bounded nonstandard reals ")#mi("O({\\bf R})")#text(", commutes with the ")#link("https://en.wikipedia.org/wiki/Standard_part_function")[#text("standard part ring homomorphism")]#text(" ")#mi("\\mathrm{st}: O({\\bf R}) \\to {\\bf R}")#text(" (which, incidentally, is part of the short exact sequence ")#mi("0 \\to o({\\bf R}) \\to O({\\bf R}) \\to {\\bf R} \\to 0")#text(" relating the bounded nonstandard reals ")#mi("O({\\bf R})")#text(" to the standard reals ")#mi("{\\bf R}")#text(" and the infinitesimal reals ")#mi("o({\\bf R})")#text("). So one can indeed describe continuity in purely algebraic terms if one is willing to use nonstandard analysis.")

#text("Limit superior and limit inferior are ")#link("https://en.wikipedia.org/wiki/Limit_superior_and_limit_inferior")[#text("common expansions")]#text(" of ")#mi("\\limsup")#text(" and ")#mi("\\liminf")#text(", though as noted on that Wikipedia page there are some other expansions such as “supremum limit”, etc.. I suppose the idea is that “limit” is the noun and “superior/inferior” is the modifying (Latin) adjective.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed46753abb9b9d7ba883d5f49e124f7cdf1fa4982cfdc2d73317ea132b59f9f-16e7223e25b645f3285465cecad79eaa69988183cc76bd52780a04e9496ddd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikhail Katz")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-480697")[#strong[#text("Mikhail Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2017")])]

#text("Indeed, ")#mi("f")#text(" is continuous at ")#mi("c\\in\\mathbb{R}")#text(" iff ")#mi("f(st(x))=st(f(x))")#text(" for all ")#mi("x")#text(" infinitely close to ")#mi("c")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e56585db621b41a08296d5c75274bec46a17836a6830fb83773a5f2164759dd7-e8e57b7792a08c4612542db934f36f2ef1215b4825ead7345e8179acf0255d7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vincent")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-480727")[#strong[#text("Vincent")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2017")])]

#text("Why does the Latex in Mikhail Katz’s post not compile while that in other posts above clearly does? I can’t see anything wrong with it.")

#emph[#text("[LaTeX now fixed. See ")#link("https://terrytao.wordpress.com/about/")[#text("https://terrytao.wordpress.com/about/")]#text(" for how to enter LaTeX into posts. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-480606")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2017")])]

#text("Oddly enough, it seems as though the boundedness condition (6), together with shift invariance (4), already suffice to determine the limit functional on the space of convergent sequences.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed46753abb9b9d7ba883d5f49e124f7cdf1fa4982cfdc2d73317ea132b59f9f-16e7223e25b645f3285465cecad79eaa69988183cc76bd52780a04e9496ddd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikhail Katz")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-480688")[#strong[#text("Mikhail Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2017")])]

#text("Thanks for a nice post, Terry. In earlier postings you referred to such “generalized ultrafilter limits” as ULTRALIMITS. That seems like a useful term. Why have you avoided it in this particular post?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-480743")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2017")])]

#text("I like to use the term ultralimit to denote the nonstandard element ")#mi("x")#text(" associated to a sequence ")#mi("(x_n)_{n=1}^\\infty")#text(" of standard elements (up to equivalence in the ultrafilter). What I call an ultrafilter limit here is the standard part of the ultralimit, but is not the ultralimit itself. (But the term ultralimit is also used in the literature in a ")#link("https://en.wikipedia.org/wiki/Ultralimit")[#text("slightly different sense")]#text(" – for something that I would call a nonstandard hull.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-480741")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2017")])]

#text("ZF + the Hahn-Banach theorem are enough to prove the Banach-Tarski paradox (reference in the Wikipedia article about BT). While by a famous theorem of Solovay, there are models of ZF in which all sets of reals are Lebesgue measurable. So the Hahn-Banach theorem can’t hold in such models. But does the existence of generalised limits really require the Hahn-Banach theorem, in the sense that their existence (plus ZF) proves the Hahn-Banach theorem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-480742")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2017")])]

#text("Wait, I don’t know if the above is right, that the existence of the Solovay model applies to R**3 and not just R. Hmm.")

#emph[#text("[Comment added to post on how one can use Solovay models to deny the existence of generalised limits. I’m pretty sure that existence of generalised limits is weaker than the full strength of Hahn-Banach, since it only uses one special case of that theorem, but do not have an immediate reference for this. But see ")#link("https://mathoverflow.net/questions/45844/hahn-banach-without-choice")[#text("https://mathoverflow.net/questions/45844/hahn-banach-without-choice")]#text(" for some related discussion.-T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f7d7261e750bd5f93ea7843fb6ea488ddf6333ebce9fd687846ecaeba3d0415b-3afc6f3598361a02eec2c7614fd2ef88fd46688368a1ada4bc9941e68336f019.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Banachero")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-480760")[#strong[#text("Banachero")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2017")])]

#text("Concerning the sentence “the only possible Banach limit for the sequence {a_n = (-1)^n} is zero”, it comes to mind the notion of “Almost convergence” which traces back to the work of Lorentz. See ")#link("https://en.wikipedia.org/wiki/Almost_convergent_sequence")[#text("https://en.wikipedia.org/wiki/Almost_convergent_sequence")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0d851a5161cc5b8e023b231e88f5861a9f784e89acdc1c6bbe75a3bc98dde82-e1ec3e396dabd1bced61319f4bdf7083b1503fb85344fcaed5a1ac4a5968de40.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shahrooz Janbaz")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-482188")[#strong[#text("Shahrooz Janbaz")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2017")])]

#text("Is it possible we see the different definitions of limits as various type of measures? Thanks for your interesting post. I will use a simplified version of your post in my calculus lecture. I am sure that students will enjoy of these different views.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d218b17239389d59b0ffa06f41195872ff39a4c1e1e2da7d9d403a4f8fe2f500-90142d8aecd7f4b021e7cd863c006b61865a7608f3048388a0408807845e9b60.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey Wiederin")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-483143")[#strong[#text("Aubrey Wiederin")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2017")])]

#text("It seems like a lot of this could be realized through considering distributions on the range of the function, i.e. applying the function to a random variable on the domain, and then possibly reducing that to a statistic.")#linebreak()#text(" Banach limits seem to be when using the limit of a uniform distribution and then applying a weighted mean, and specifically the Cesaro mean is with the expected value, or a uniform weighting. If you don’t mind losing linearity you could also use generalized means, which I believe would get you the inf and sup limits. Haven’t checked to see what the geometric or harmonic means would produce, but I wouldn’t be surprised if they are already well-known.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b30843979278a06ae31ff830ef9f01f7168985ee1943b8dec285e24e9b0d539b-fe0543f3cebcde9d75c398397c5c54bec4b9fc93b0b61366a4c96641faff819d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Torstein")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-484430")[#strong[#text("Torstein")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2017")])]

#text("Going to make a total ass of myself here, but I thought the Hahn-Banach theorem for spaces with a countable basis was proved by ordinary induction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-484475")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2017")])]

#text("One would still need the axiom of countable choice in this case. But in any event, ")#mi("\\ell^\\infty")#text(" does not have a countable (")#link("https://en.wikipedia.org/wiki/Basis_(linear_algebra)#Analysis")[#text("Hamel")]#text(") basis, as can be seen for instance from the Baire category theorem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The structure of logarithmically averaged correlations of multiplicative functions, with applications to the Chowla and Elliott conjectures | What's new")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-484811")[#strong[#text("The structure of logarithmically averaged correlations of multiplicative functions, with applications to the Chowla and Elliott conjectures | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2017")])]

#text("[…] all limits exist. (In the paper, we instead use the device of generalised limits, as discussed in this previous post.) The idea is to combine together two rather different ways to control this function . The first […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4af40c9bb40d1642a6724f2781c2a82929f6c0dc21251a140d6103e5a6a73b08-9f4e1649cf4fe40733455354e17844e74a90380c5a044bd1abb9f60e8312fca2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jesús López")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-485059")[#strong[#text("Jesús López")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2017")])]

#text("One can also say ultrafilter and classic limits are cases of limits along a filter as in planetmath, where in the classic case the filter is Fréchet’s. If one thinks of the sequence as defined on the ordinal omega plus one, the topological definition of limit of function at a point, here omega, matches the one of limit of a sequence at inifinity, picturalizing the expression ‘neighborhood of inifinity’ and allowing one to think of local and sequential limits at once. Local concepts such as stalk or germ should be predicable also at that point omega also.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb8aef9e586fcdb01ffbe154709269bb746775ae39eac702fa17d3d101a6e850-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Smania")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-486743")[#strong[#text("Daniel Smania")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2017")])]

#text("Teaching Functional Analysis this year we learned that with the analytic version of HB theorem with Minkowski functionals (like in Brezis’s book) we can obtain no trivial and interesting linear functionals from the null functional and trivial space, provided the Minkowski functional also assume negative values.")

#text("My students asked me about an exercise in Maddox’s book to construct a linear functional g that satisfies")

#text("\\liminf_n x_n\\leq g(x)\\leq \\limsup_n x_n.")

#text("I started to construct a Banach limit extending the functional that gives the Cesaro limit on the subspace of Cesaro convergent sequences.")

#text("The students knew better: they told me to take the Minkowski functional p(x)= limsup_n x_n and the subspace of convergent sequences and apply the analytic HB theorem. My solution was an overkill…")

#text("Soon we realized that we can consider the Minkowski functional p(x)= limsup_n x_n and Y as the trivial subspace Y={0}, where 0 denotes the constant sequence (0,0,0,…). Then of course the null functional f satisfies f(x)\\leq p(x) on Y, so there is an extension to a function g on l_\\infty that satisfies")

#text("g(x)\\leq limsup_n x_n \\leq |x|_\\infty")

#text("and consequently g is bounded and satisfies (considering g(-x) )")

#text("\\liminf_n x_n\\leq g(x)\\leq \\limsup_n x_n")

#text("I was very shocked by this, that we can start from the trial subspace and functional and construct such interesting bounded functional.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4af40c9bb40d1642a6724f2781c2a82929f6c0dc21251a140d6103e5a6a73b08-9f4e1649cf4fe40733455354e17844e74a90380c5a044bd1abb9f60e8312fca2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jesús López")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-493433")[#strong[#text("Jesús López")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2018")])]

#text("Correct me if wrong, but in “Generalised limits can obey the shift-invariance property (4) or the algebra homomorphism property (2)”, “Generalised limits that obey the algebra homomorphism property (2) are known as ultrafilter limits” and in next sentence, (3) is meant instead of (2).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ddacb543355e1835ce81ca7560e1344c08df80a2bc7f9a625086818b109ad6d-0907d74613bbc88b9e8cc67f8cd9247d874b92a2fc0e205569355bbc908313c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Corey Levinson")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-494044")[#strong[#text("Corey Levinson")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2018")])]

#text("This question is based on completely ")#link("https://en.wikipedia.org/wiki/Cesàro_summation")[#text("https://en.wikipedia.org/wiki/Cesàro_summation")]

#text("I’m a little confused. You write the sequence ")#mi("(-1)^n")#text(" has Césaro limit of ")#mi("0")#text(", but going by the definition we have Césaro limit is ")#mi("\\lim_{N\\to\\infty}\\frac{1}{N}\\sum_{n=1}^{N} (-1)^n")#text(". So how do we find this?")

#text("Well, the sequence of partial sums ")#mi("(s_k) = \\sum_{k=1}^{n} (-1)^k")#text(" is (-1, 0, -1, 0, -1, 0, …) which is not classically convergent. However, this sum is Césaro summable. Let ")#mi("(t_n)")#text(" be the sequence of arithmetic means of the first n partial sums:")

#mi("t_n = \\frac{1}{n}\\sum_{k=0}^{n-1} =")#text("(")#mi("\\frac{-1}{1}")#text(", ")#mi("\\frac{-1}{2}")#text(", ")#mi("\\frac{-2}{3}")#text(", ")#mi("\\frac{-2}{4}")#text(", ")#mi("\\frac{-3}{5}")#text(", ")#mi("\\frac{-3}{6}")#text(", …)")

#text("Then ")#mi("\\lim_{n\\to\\infty} t_n = \\frac{-1}{2}")

#text("So ")#mi("(-1)^n")#text(" has Césaro limit of ")#mi("\\frac{-1}{2}")#text(" instead of 0?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ddacb543355e1835ce81ca7560e1344c08df80a2bc7f9a625086818b109ad6d-0907d74613bbc88b9e8cc67f8cd9247d874b92a2fc0e205569355bbc908313c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Corey Levinson")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-494045")[#strong[#text("Corey Levinson")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2018")])]

#text("Unless actually I just found the Césaro sum, and so the limit is ")#mi("\\lim_{N\\to\\infty} \\frac{1}{N} * \\frac{-1}{2} = 0")#text(". So actually it should be 0! Nevermind then, I guess")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/336d96d1683b32f7dd76c444eba0cd9882b7ddf8636ae2e2d6c35942b8cda8bf-767979cddc8701cb7a136f45fd326b7c8ad84478bfb78f7d02d07fc9dcb363b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jonbannon")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-513837")[#strong[#text("jonbannon")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2019")])]

#text("When you construct the nonprincipal ultrafilter from the generalized limit functional satisfying (2), it is not crystal clear here why the generalized limit functional is the corresponding ultrafilter limit. How is this most easily seen?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/336d96d1683b32f7dd76c444eba0cd9882b7ddf8636ae2e2d6c35942b8cda8bf-767979cddc8701cb7a136f45fd326b7c8ad84478bfb78f7d02d07fc9dcb363b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jonbannon")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-513838")[#strong[#text("jonbannon")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2019")])]

#text("I see, perhaps it would be pedantic. One can show this for the functions 1_A with A in the ultrafilter, and the other functionals are linear combinations of these…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/336d96d1683b32f7dd76c444eba0cd9882b7ddf8636ae2e2d6c35942b8cda8bf-767979cddc8701cb7a136f45fd326b7c8ad84478bfb78f7d02d07fc9dcb363b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jonbannon")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-513839")[#strong[#text("jonbannon")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2019")])]

#text("No, that wasn’t quite right. This is standard, but your exposition above is so nice I feel it needs a sentence to finish that. Given the character one constructs the nonprincipal ultrafilter. The limit along this ultrafilter is also a character and will have the same kernel as the original character, so they are identical.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abstracting induction on scales arguments | What's new")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-517407")[#strong[#text("Abstracting induction on scales arguments | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2019")])]

#text("[…] arguments here would also apply with one of the other generalised limit functionals discussed in this previous post, such as ultrafilter […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b53c04a5b8172da9489d30afac38392019b1f10d3ab9dab0807a280c1ad3eb4-fbf538f0eb097b306cc346765165a7d45ecbfa211b41c0ad87edb9ebdf9f1e9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Math lover")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-530388")[#strong[#text("Math lover")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2019")])]

#text("So I still do not understand how to prove this claim: “there exists at least one generalised limit functional {\\mathop{\\widetilde \\lim}_{n \\rightarrow \\infty}} that takes the value {L} when applied to {a_n}”? Why consider the span of convergent sequences and {a_n}? Any hints?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-530414")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2019")])]

#text("First construct a linear functional from the space spanned by the convergent sequences and ")#mi("(a_n)_{n=1}^\\infty")#text(" that agrees with the limit functional on convergent sequences, and maps ")#mi("(a_n)_{n=1}^\\infty")#text(" to ")#mi("L")#text(". (This linear functional will be unique, although the generalised limit functional one then constructs from it using Hahn-Banach will not be.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b53c04a5b8172da9489d30afac38392019b1f10d3ab9dab0807a280c1ad3eb4-fbf538f0eb097b306cc346765165a7d45ecbfa211b41c0ad87edb9ebdf9f1e9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Math lover")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-530879")[#strong[#text("Math lover")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2019")])]

#text("Thanks for your answer. I have another question. Is there any applicatio of the generalized limit or Banach limit? Thanks.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88ff6bdd81b63eb76aa0fd4529fd9e67fcef3513010aadb550253164230b5802-08bae7c620a6f1f142eb8237cdaa5112c45777bcee5ce977b8126fd3f06df7da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-534482")[#strong[#text("Chris")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2020")])]

#text("Really interesting. Should (2) be (3) in the statement “If one is given a generalised limit functional {p\\!-\\!\\lim_{n \\rightarrow \\infty}} that obeys (2)…” And again further down?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harry West")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-597829")[#strong[#text("Harry West")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2020")])]

#text("To show that non-principal ultrafilters don’t exist in the Solovay model, you need to use more than the behavior of $f$ at two points. And you probably want to use the property of Baire rather than Lebesgue measure; it is not know whether Lebesgue measurability of all sets of reals implies that Banach limits don’t exist: ")#link("https://mathoverflow.net/questions/256133/does-the-existence-of-a-non-principal-measure-on-%CF%89-imply-that-of-a-non-lebesgue")[#text("https://mathoverflow.net/questions/256133/does-the-existence-of-a-non-principal-measure-on-%CF%89-imply-that-of-a-non-lebesgue")]#text(" . In ZFC the function $f$ exists and is Lebesgue measurable: $f(x)=1$ almost everywhere.")

#emph[#text("[Good catch! I have deleted the paragraph with the incorrect argument – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0553c4f596cf5f1599c0cf820dba7d03abe786d8b664771702e1a49f71945e66-45247d147c72f44435c5ae51ad25516948c50c921ec0852e19f110d46aafc136.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Attila Losonczi")]], [#link("https://terrytao.wordpress.com/2017/05/11/generalisations-of-the-limit-functional/#comment-631026")[#strong[#text("Attila Losonczi")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2021")])]

#text("We may also add Abel’s method to the list. However originally it is for infinite series, one can apply it for sequences in the usual way: if (a_n) is a sequence then apply Abel’s method for the series a_1+(a_2-a_1)+(a_3-a_2)+… E.g. the (non-bounded) sequence 1,-,1,2,-2,3,-3,… converges in Abel’s sense (to 1/4), and does not converge in Cesaro’s sense. Abel’s method extends Cesaro’s since whenever a series is Cesaro summable, it is also Abel summable and has the same sum.")#linebreak()#text(" It is linear and shift invariant as well.")
]
