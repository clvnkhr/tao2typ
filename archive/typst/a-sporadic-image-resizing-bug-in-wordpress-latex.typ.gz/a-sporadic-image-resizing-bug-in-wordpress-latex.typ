// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/
// Converted to Typst by tao2typ: "2026-10-14T15:18:53.764537+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A sporadic image resizing bug in WordPress LaTeX", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A sporadic image resizing bug in WordPress LaTeX")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 January 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/")[#text("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’m encountering a sporadic bug over the past few months with the way WordPress renders or displays its LaTeX images on this blog (and occasionally on other WordPress blogs). On most computers, it seems to work fine, but on some computers, the sizes of images are occasionally way off, leading to extremely distorted and fairly unreadable versions of the images appearing in blog posts and comments. A sample screenshot (with accompanying HTML source), supplied to me by a reader, can be ")#link("https://terrytao.wordpress.com/wp-content/uploads/2014/01/screen-shot-2013-12-14-at-3-56-19-pm.png")[#text("found here")]#text(" (in which ")#link("https://terrytao.wordpress.com/wp-content/uploads/2014/01/test.png")[#text("an image")]#text(" whose dimensions should be 321 x 59 are instead being displayed as 552 x 20). Is anyone else encountering this issue? The problem sometimes can be resolved by refreshing the page, but not always, so it is a bit unclear where the problem is coming from and how one might mitigate it. (If nothing else, I can add it to the ")#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/")[#text("bug collection post")]#text(", once it can be reliably replicated.)")

#heading(level: 1)[#text("Comments (34)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b057d3f2c7ed35bc6b3891e63f5e0178f3483dbc2dfc91faf2ded8605962ff2e-d71fd86f5a588cd12351a0cb5aa165032e0d72fa110677758f540326caeb0e82.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sivaram")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261232")[#strong[#text("Sivaram")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2014")])]

#text("Yes, I too see the typeset math in a weird fashion sometimes (")#link("http://imgur.com/1ro0079")[#text("http://imgur.com/1ro0079")]#text("). However, if I reload the page couple of times, the issue goes away.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/063b675704132fba480f5d8523d45eaa6dc1a29606f3921d71f5ba0b6df3a79b-85ac7e85c91e2494dd2382e5ffdaa6d08684f7e06205f699a9f94f45d85b434f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan Reich")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261233")[#strong[#text("Ryan Reich")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2014")])]

#text("I’ve had this problem for a long while, on this and other WordPress blogs. I always just refresh, which usually resolves it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261432")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2014")])]

#text("same for me … i do the refresh thing …")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9521e98d660cc271844f73bbffc279f55fe0a15b317f2088883011d1c7d85724-f20a2ad7fb6a7f4b7b42f2e267f725604eceed14375e89dfea88ac48dafc2029.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261247")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2014")])]

#text("I can also see it: ")#link("http://i.imgur.com/zV1Nv32.png")[#text("http://i.imgur.com/zV1Nv32.png")]#text(". On a buggy page, equations are OK till some “breaking point”, after which every image is distorted.")

#text("I use Chrome on Ubuntu and can’t reproduce in Firefox nor Opera. Did anyone get it there too?")

#text("It seems if I disable Javascript in the browser, equations render normally. Enable it, and the bug reappears. (Of course Javascript is crucial for many web pages and this is no workaround.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a75edac8286128b0d4e899a2e4e2601b1d30471a4849383ddf741b499b67dcd0-ad941f6a12224375189bb2fa337a573a0f4ac2878458ed85060fed0fb3f85670.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of {RCRISTO - Tecnologia e Informação}")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261248")[#strong[#text("{RCRISTO - Tecnologia e Informação}")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2014")])]

#text("I noticed some (very large) odd characters for some mathematical symbols. This occurs when the browser renders and displays these characters, seems to be a flaw in java script that sets the style sheet.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/745de7e1ff53e8a6f60ff88865dfef07982fe6ddb3e254e4d9cf880def122a75-9c8c9eb9ac6dcd52a1792a6a84c4ab50c979808c6123e8f910af707d9537ee9c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261253")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2014")])]

#text("I use up-to-date Debian stable, amd64 port. My browser is “Iceweasel” which is Debian’s name for Firefox. I have formula sizing problems almost every time I look at Terry Tao’s blog. The formulas will display properly if I refresh the page sveral times. Usually most of the formulas are affected.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a32b79603bc15dd3d284fb115848f3e6c3fccbf509992c81f5364f695352c642-d8a55261264dc05ebb8a8fa0550235f3ee588d25447926c78d7ab3529d4020f9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261258")[#strong[#text("Ryan")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2014")])]

#text("Yes, I’ve been getting this for a month or two now too. Chrome on Windows.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261276")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2014")])]

#text("I have been getting exactly the same issues ever since I switched to Windows 8. Originally I thought it is a problem with IE. But it persists with Chrome as well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/765239e24b694b43a86ec48b8118edb661d0f7d594cfcebfdc84780dae68ec54-29be3e6889435bc63e9b74dc97ed83e841a62acef0908f34435e289b120e59a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Evgeniy")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261306")[#strong[#text("Evgeniy")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2014")])]

#text("I have the same problem in my browser, and the refreshing doesn’t help at all (I use Chrome, but quick test with IE shows that it is the same, at least in the first loading and refreshing).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/feda2708ab41aeb5a863f024d1bdf0b1d8e756e1e19ef3e175c14fd9820c8eca-3335bed4a94ed4d3a639469274e25dfa6b77c1b83e32303b80b4b71de3b79cf8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Lowry-Duda")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261319")[#strong[#text("David Lowry-Duda")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2014")])]

#text("I’ve been getting this issue. It’s what finally tipped me over to hosting my own site. Although it’s still WordPress, I have greater control and so I don’t get that problem now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261326")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2014")])]

#text("I’ve been having this problem for at least weeks (in both Chrome and IE) and refreshing doesn’t help. For some bizarre reason I don’t have it on my blog but I get it on everyone else’s.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261327")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2014")])]

#text("I should say, refreshing doesn’t help in a particularly weird fashion: the resizings will happen in different ways when I refresh.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ddb1c63708eadc889a6574097fe923c8b94a1aa108fdd77a026ba3ed95f9a7b-14d4dea4390961a886e388d13add9a1d01d21a510dd289b50e86d171b30f95ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikael P. Sundqvist")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261328")[#strong[#text("Mikael P. Sundqvist")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2014")])]

#text("I recommend you to use Mathjax instead, see")

#link("http://www.mathjax.org")[#text("http://www.mathjax.org")]

#text("and")

#link("http://wordpress.org/plugins/mathjax-latex")[#text("http://wordpress.org/plugins/mathjax-latex")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b6c183e66bf0d5eea5ac2c7f580ab4cdfce5df6bb0a7bc70cdf5008e4cde674-f39eadc61e7438c735baff1677a31f5b42dffa64142bf167f143e1c7ef681e6f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of B.")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261352")[#strong[#text("B.")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2014")])]

#text("I totally agree with Mikael! Mathjax is a very efficient way to go. It seems to be quite stable since mathscinet, the arXiv, and others are using it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9adc4a944494870794b36e81325f4f42ab601a227ae5cedcbf8f5b1c0b0a114d-53ba2eb0eb9f0d6bb5a48549fba4328c98ad698dfb6a2d9848d83b99ecebf493.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Willie Wong")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-266409")[#strong[#text("Willie Wong")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2014")])]

#text("For blogs hosted on WordPress.com, it is not so simple.")

#text("To load MathJax requires editing the header of the templates to load a specific JavaScript file. This operation is trivial for those who host their own WordPress installations, but impossible (currently) for users of WordPress.com.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rz")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261359")[#strong[#text("rz")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2014")])]

#text("I’ve experienced the symptoms you mentioned. I’m using chrome in windows. I thought it happens because I resized the web. I usually use 125% magnification on your page. When I turn it back to default size, problem seems to go away.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27e7070af2c8cecbe65c0bd2047912d0dde6eaa77e7595e4d0dd4e7741b1f7ee-011cc43a6a7233cc01cb9ca581e8df3b57df1eee94f84c3b434ec595dee77387.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261361")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2014")])]

#text("I have had these bugs when reading your posts on Chrome for several weeks now, and refreshing does not frequently resolve the problem. However, the bugs were absent when I used a desktop computer, on both Chrome and Firefox.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dcb79885a8feb9397f4b87c7726bc1ee8cd4e1cbea7fe5a72a5008d364c55809-c48395fc122352627b8359f5f54c5368c0b48fe77f4e8a827964af719aa80b81.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of inordinatum")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261367")[#strong[#text("inordinatum")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2014")])]

#text("I’m having the same problem on my blog, and likewise independently of the browser (IE, Firefox, Chrome)… If anybody finds a reliable solution (short of hosting your own site) I’d be very grateful!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b544fbea8487108c4c9dcb3056f26fbf7cc559f7a53708463f9c918f339b4bf-40fc3c7ec90a74401940f28a09703bae5dc816501a60c66655a2d9d6590201fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of john dorian")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261369")[#strong[#text("john dorian")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2014")])]

#text("I started having this problem a month or two ago, I am using windows 7 and chrome")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ece5c85e429eb3a97553cd6aa98582ccd1bfb87463a93bf6692b3f7e2c9f30e-1c85d26fc978a1a7dbbcb118cdf9a13062678c9cb4250de386cc17c086221409.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alec")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261381")[#strong[#text("Alec")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2014")])]

#text("Having the same problem, have been for a few months now. Chrome on Mac")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261382")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2014")])]

#text("Chrome on MacOS; the problem only occurs with non-default zoom and always goes away by reverting to default zoom, refreshing, and remaining at default zoom until loading completes")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/570044150d90f16b29a8906a025b503d65d3e14a01875d7060feb010b2389eda-8889ae34c3458b08263a584cc4e3fede321bd8e83a5b6950c428b5dc9f3d5fd8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jon Awbrey")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261396")[#strong[#text("Jon Awbrey")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2014")])]

#text("There are problems also with WordPress parsing LaTeX “tabular” formats in a very inconsistent manner.")

#text("☞ ")#link("http://inquiryintoinquiry.com/tables/")[#text("http://inquiryintoinquiry.com/tables/")]

#text("WordPress “Support” is not very good at responding to bug reports, either.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/167d869bd4f5f5b1508c48c8c4ade3ced6419d222f88850b529b0e3c84decf30-3781c9bc4ed44a730d9dc47273ac66a7e44236756367a6f1988d4d948dabe9f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Axurez")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261402")[#strong[#text("Axurez")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2014")])]

#text("I have made a chrome extension which can replace LaTeX images with MathJax-rendered contents (you can set the domain-matching rules). Check it out here: ")#link("https://chrome.google.com/webstore/detail/math-as-you-will/dhclcadjnhmoimnlkbboigmihbebfmdc")[#text("https://chrome.google.com/webstore/detail/math-as-you-will/dhclcadjnhmoimnlkbboigmihbebfmdc")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90be308eed25ee97422b84bb02b87e52566d4e296322a811776b8ebbfeb5cf46-92174fba00f66eede65dbb894aba8b12eabf1776e9882fcc866f44f1799e58b2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathtuition88")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261404")[#strong[#text("mathtuition88")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2014")])]

#text("Reblogged this on ")#link("http://mathtuition88.com/2014/01/04/a-sporadic-image-resizing-bug-in-wordpress-latex/")[#text("Singapore Maths Tuition")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4db7f931b7831845d5ad9a27b1a6319cf65192de9454a28bb64b50d9e9f9875b-09b27acb458a076240e9968737c42ca77e5653b215ae746d53770326465c5608.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261412")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2014")])]

#text("Yes. It’s often impossible to read, and worse further down the page.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Séguin")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261426")[#strong[#text("Richard Séguin")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2014")])]

#text("I’ve never seen this bug occur using Firefox, Safari, or the recently revived Omniweb (beta 6.0) within OS X Mavericks, whether zoomed or not. In all three I have Javascript turned on and Java turned off.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa110cd843baa2000ae418ed3de2ae68b28bc66ef4075ccbcac1820a765bc52e-85a2258f3dc17fc3c3f5478e04ec551c8963350f4e5cfb87059b48fab2cfb0f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris J.")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261577")[#strong[#text("Chris J.")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2014")])]

#text("I consistently see this. Yeah, it’s quite distracting. I am using the latest Chrome on Mac OS X 10.8.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/189645cfb9f987222d0b04916d637c0d7d22cb0862a5c0332a675455da60310a-25f80fcdd5dcf840dec644ed463dfe8ca0b1ce04ea6ad905ac886aee64ed7685.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dirk")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261611")[#strong[#text("Dirk")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2014")])]

#text("Same bug here (using Firefox on Ubuntu 12.04).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02bac94babd1f10a61d6a34c6fef3ef21d52a84b8debdc2e02f5b15b3c10d5ae-2f8ff17e1311f739c91aab6a821816a2c8e48a73c1cf867d0451ddcd5379cdd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261753")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2014")])]

#text("Same problem when using Chrome, but it works fine with Safari. (OS X 10.8)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261755")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2014")])]

#text("I’m having the same problem on my WordPress blog (in both Firefox and IE) and on several others WordPress blogs, including yours, when using a PC or a laptop. Refreshing normally helps. However it does not occur with an Android tablet.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-261969")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2014")])]

#text("I also get the bug. I think if you reset your zoom to 100% and refresh, it goes away for me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/764631b1f5e4cf83a83ec4c0937b8509e60e6a2e7d5417788b48d7d3a537ef1b-89b9fe48f2c8bcf5f76a12da31e7fd30ae0df185ebc579730e3c364cb4bcb88e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gaurav Tiwari")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-262179")[#strong[#text("Gaurav Tiwari")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2014")])]

#text("On the other hand, I always complain about how the LaTeX png images behave on printing the posts. Wish those were rendered as svg instead of png.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a34de3cadf72ccac6610285e12c3bcebfccb65bbfbc1dbf4a0a4e1418f0dfae9-ff08d1e6595501802fa250f8098ab7d7e733ad521cc83d71559bc3462cc6ab4f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vít Tuček")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-262463")[#strong[#text("Vít Tuček")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("Recent version of Chrome on Windows 7 has the same problem. Refreshing usually helps only when I set the zoom factor to 100%.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cefc075ba8b78b94f7172ed8253ecb81510fa34f735b72ca65d084415d58698-59e1053277d9329365e3b62fbf44714901655e504d808b003efd60f90cab2e27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KWRegan")]], [#link("https://terrytao.wordpress.com/2014/01/03/a-sporadic-image-resizing-bug-in-wordpress-latex/#comment-262682")[#strong[#text("KWRegan")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("Dick Lipton and I notice that this occurs almost every time when we view a ")#emph[#text("draft")]#text(" of a post. We don’t know anything better than refreshing the page (either).")
]
