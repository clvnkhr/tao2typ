// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/
// Converted to Typst by tao2typ: "2026-10-14T15:21:14.644582+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A digestion of the Jacobian conjecture counterexample", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A digestion of the Jacobian conjecture counterexample")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 July 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/")[#text("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The notorious ")#link("https://en.wikipedia.org/wiki/Jacobian_conjecture")[#text("Jacobian conjecture")]#text(" can be formulated concretely over the complex numbers as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Jacobian Conjecture)")]#text(" Let ")#mi("{F:{\\bf C}^n \\rightarrow {\\bf C}^n}")#text(" be a polynomial map in ")#mi("{n}")#text(" complex variables, whose Jacobian ")#mi("{\\mathrm{det} DF}")#text(" is a non-zero constant. Then ")#mi("{F}")#text(" is invertible (with polynomial inverse).")
]

#text("The condition that the Jacobian ")#mi("{\\mathrm{det} DF}")#text(" is non-zero is equivalent to ")#mi("{F}")#text(" being locally invertible. (The implication of local invertibility from non-vanishing Jacobian follows from the inverse function theorem; the converse implication can be derived from the ")#link("https://en.wikipedia.org/wiki/Weierstrass_preparation_theorem")[#text("Weierstrass preparation theorem")]#text(", but is omitted here; see also Lemma 5 of ")#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/")[#text("this previous blog post")]#text(".) Also, from the fundamental theorem of algebra, once the Jacobian polynomial ")#mi("{\\mathrm{det} DF}")#text(" is non-zero, it must be constant. So the hypothesis “Jacobian ")#mi("{\\mathrm{det} DF}")#text(" is a non-zero constant” can be replaced with “")#mi("{F}")#text(" is locally invertible”. So the Jacobian conjecture can be viewed as an assertion that local invertibility implies global invertibility. The complex numbers can be easily replaced with other fields of characteristic zero by the ")#link("https://en.wikipedia.org/wiki/Algebraic_geometry_and_analytic_geometry#The_Lefschetz_principle")[#text("Lefschetz principle")]#text(", but I prefer to work in the concrete setting of the complex numbers.")

#text("It was ")#link("https://www.newscientist.com/article/2580374-ais-solution-to-87-year-old-riddle-takes-mathematicians-by-surprise/")[#text("recently shown")]#text(" (using the Fable AI) that the conjecture is false in three dimensions (and thus in higher dimensions as well):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Counterexample to conjecture)")]#text(" ")#metadata(none) <tao-24c114941183fd3be2f3>#text(" There exists a polynomial ")#mi("{F : {\\bf C}^3 \\rightarrow {\\bf C}^3}")#text(" which has non-zero constant Jacobian, but is not invertible.")
]

#text("The conjecture remains open in two dimensions, and is easy to establish in one dimension.")

#text("The example can be stated completely explicitly: one can take ")#metadata(none) <tao-4d602493dce987d46e52>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("F(z_1,z_2,z_3) = \\Big((1+z_1 z_2)^3 z_3 + z_2^2 (1+z_1z_2) (4+3z_1z_2),")]]



#align(center)[#tao-fit-display[#mitex("z_2 + 3 z_1 (1+z_1z_2)^2 z_3 + 3 z_1 z_2^2 (4+3z_1z_2),")]]

#align(center)[#tao-fit-display[#mitex("2 z_1 - 3 z_1^2 z_2 - z_1^3 z_3\\Big)")]]

#text("and one can verify by a brief calculation that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{det} DF = -2")]]

#text("and")

#tao-aligned(keep: true)[


#tao-math("F(0,0,-1/4)  & = F(1,-3/2, 13/2) = F(-1,3/2,13/2)", block: true)



#tao-math(" & = (-1/4,0,0).", block: true)
]

#text("While this is an extremely quick verification, the construction presented in this fashion appears like a massive miracle. The polynomial ")#mi("{F}")#text(" has degree seven, so ")#emph[#text("a priori")]#text(" the Jacobian ")#mi("{\\mathrm{det} DF}")#text(" ought to be a polynomial in three variables of degree as large as ")#mi("{3 \\times 6 = 18}")#text(", so the fact that all non-constant coefficients of this polynomial vanish looks like a massive cancellation involving ")#mi("{\\binom{18+3}{3}-1 = 1329}")#text(" equations, which is much larger than the ")#mi("{3 \\times \\binom{7+3}{3} = 360}")#text(" degrees of freedom for a generic degree seven polynomial map of three variables. So finding such a polynomial looks highly unlikely to be located by brute force.")

#text("The example has since been retroactively ")#link("https://x.com/davikrehalt/status/2079175065695035442")[#text("explained in more geometric terms")]#text(". As a “digestion” exercise to myself, I sought to write this explanation with relatively little use of algebraic geometry, in a manner that minimizes the amount of “miracles” required, although there are still a few places where some remarkable phenomena occur.")

#text("It is convenient to use the local injectivity formulation, and to generalize the domain ")#mi("{{\\bf C}^3}")#text(" to an equivalent affine variety. Namely, we will show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Counterexample, reformulated)")]#text(" ")#metadata(none) <tao-40a04291cec1d65b3060>#text(" There exists an affine variety ")#mi("{X \\subset {\\bf C}^5}")#text(" that is isomorphic to ")#mi("{{\\bf C}^3}")#text(" by polynomial changes of variable, and a polynomial map ")#mi("{F : X \\rightarrow {\\bf C}^3}")#text(" which is locally injective, but not globally injective.")
]

#text("Clearly one can get from Theorem ")#link(<tao-40a04291cec1d65b3060>)[#text("3")]#text(" to Theorem ")#link(<tao-24c114941183fd3be2f3>)[#text("2")]#text(" by composing with the isomorphism ")#mi("{X \\cong {\\bf C}^3}")#text(" and using the previously mentioned fact that local injectivity implies non-zero constant Jacobian. Our objective is now to find data ")#mi("{X}")#text(", ")#mi("{F : X \\rightarrow {\\bf C}^3}")#text(" that obeys three separate properties:")

#list(
[#text("(a) ")#mi("{F}")#text(" is locally injective on ")#mi("{X}")#text(".")],
[#text("(b) ")#mi("{F}")#text(" is not globally injective on ")#mi("{X}")#text(".")],
[#text("(c) ")#mi("{X}")#text(" is isomorphic to ")#mi("{{\\bf C}^3}")#text(" by polynomial changes of variable.")]
)

#text("The advantage of splitting the problem in to these three components is that we can build towards each of them separately.")

#text("(A pedantic remark: strictly speaking, in the arguments below, we not only replace the domain ")#mi("{{\\bf C}^3}")#text(" of ")#mi("{F}")#text(" by an equivalent variety ")#mi("{X}")#text(", but also replace the range ")#mi("{{\\bf C}^3}")#text(" of ")#mi("{F}")#text(" by an equivalent variety ")#mi("{V}")#text(". But the equivalence between ")#mi("{V}")#text(" and ")#mi("{{\\bf C}^3}")#text(" is a boring linear isomorphism (")#mi("{V}")#text(" will just be a hyperplane in a four-dimensional vector space ")#mi("{\\mathrm{Sym}^3({\\bf C}^2)}")#text("), so we do not highlight this aspect of the construction.)")

#text("It turns out that ")#mi("{F}")#text(" and ")#mi("{X}")#text(" can be built out of the operation of multiplication of low degree polynomials. Namely, consider the following three simple affine spaces:")

#list(
[#text("The space ")#mi("{\\mathrm{Sym}^1({\\bf C}^2)}")#text(" of linear homogeneous polynomials ")#mi("{L(z,w) = az + bw}")#text(" of two complex variables ")#mi("{z,w}")#text(".")],
[#text("The space ")#mi("{\\mathrm{Sym}^2({\\bf C}^2)}")#text(" of quadratic homogeneous polynomials ")#mi("{Q(z,w) = cz^2 + dzw + ew^2}")#text(" of two complex variables ")#mi("{z,w}")#text(".")],
[#text("The space ")#mi("{\\mathrm{Sym}^3({\\bf C}^2)}")#text(" of cubic homogeneous polynomials ")#mi("{C(z,w) = fz^3 + gz^2w + hzw^2 + iw^3}")#text(" of two complex variables ")#mi("{z,w}")#text(".")]
)

#text("(The notation ")#mi("{\\mathrm{Sym}^k(V)}")#text(" here refers to the ")#mi("{k^{th}}")#text(" ")#link("https://en.wikipedia.org/wiki/Symmetric_power")[#text("symmetric power")]#text(" of a vector space ")#mi("{V}")#text(".) Clearly these spaces are isomorphic to ")#mi("{{\\bf C}^2, {\\bf C}^3, {\\bf C}^4}")#text(" respectively. Furthermore, we have a multiplication map ")#mi("{F : \\mathrm{Sym}^1({\\bf C}^2) \\times \\mathrm{Sym}^2({\\bf C}^2) \\rightarrow \\mathrm{Sym}^3({\\bf C}^2)}")#text(", mapping a pair ")#mi("{(L,Q)}")#text(" of a linear polynomial ")#mi("{L}")#text(" and a quadratic polynomial ")#mi("{Q}")#text(" to a cubic polynomial")

#align(center)[#tao-fit-display[#mitex("F(L,Q) := LQ.")]]

#text("(Right now, the domain and range of this map ")#mi("{F}")#text(" is larger dimensional than the target of three; we will cut the dimensions down to three as the argument progresses.)")

#text("The map ")#mi("{F}")#text(", essentially a map from ")#mi("{{\\bf C}^5}")#text(" to ")#mi("{{\\bf C}^4}")#text(", is clearly polynomial; it is given explicitly in coordinates as ")#metadata(none) <tao-c0c75a8e79ad011929e6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("F( (a,b), (c,d,e) ) = (ac, ad + bc, ae + bd, be).")]]

#text(" ")#text(" The map ")#mi("{F}")#text(" also enjoys two basic (and commuting) symmetries:")

#list(
[#text("If one applies a scaling ")#mi("{(L,Q) \\mapsto (\\lambda_1 L, \\lambda_2 Q)}")#text(" for some non-zero complex numbers ")#mi("{\\lambda_1, \\lambda_2}")#text(", then the product ")#mi("{LQ}")#text(" is scaled by ")#mi("{C \\mapsto \\lambda_1 \\lambda_2 C}")#text(": ")#mi("{F( \\lambda_1 L, \\lambda_2 Q) = \\lambda_1 \\lambda_2 F(L,Q)}")#text(".")],
[#text("If one applies a change of variables ")#mi("{(L, Q) \\mapsto (L \\circ T, Q \\circ T)}")#text(" for some invertible linear transformation ")#mi("{T \\in \\mathrm{SL}_2({\\bf C})}")#text(", then the product ")#mi("{LQ}")#text(" is transformed by ")#mi("{C \\mapsto C \\circ T}")#text(": ")#mi("{F(L \\circ T, Q \\circ T) = F(L,Q) \\circ T}")#text(".")]
)

#text("So this map enjoys a huge amount of equivariance, basically with respect to an action of the five-dimensional group ")#mi("{{\\bf C}^\\times \\times {\\bf C}^\\times \\times \\mathrm{SL}_2({\\bf C})}")#text(".")

#text("The five-dimensional domain ")#mi("{\\mathrm{Sym}^1({\\bf C}^2) \\times \\mathrm{Sym}^2({\\bf C}^2)}")#text(" is of course larger than the four-dimensional range ")#mi("{\\mathrm{Sym}^3({\\bf C}^2)}")#text(", so the map ")#mi("{F}")#text(" clearly cannot be injective. This can already be seen from the scaling symmetry, as the specific scalings ")#metadata(none) <tao-54b759dba2ded0937372>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("(L, Q) \\mapsto (\\lambda L, \\lambda^{-1} Q)")]]

#text(" ")#text(" for ")#mi("{\\lambda \\in {\\bf C}^\\times}")#text(" modify the linear and quadratic polynomials ")#mi("{L,Q}")#text(" but not their product ")#mi("{C = LQ}")#text(". But even if one quotients out by this symmetry ")#link(<tao-54b759dba2ded0937372>)[#text("(3)")]#text(" to cut the dimension of the domain down to four, the map ")#mi("{F}")#text(" is still not injective for the following basic reason. A generically chosen cubic polynomial ")#mi("{C}")#text(" will split into the product ")#mi("{C = L_1 L_2 L_3}")#text(" of three independent linear polynomials. Then there are three pairs")

#metadata(none) <tao-528a556ab1f8fa01985b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("(L_1, L_2 L_3), (L_2, L_1 L_3), (L_3, L_1 L_2)")]]

#text("which all map to the same cubic polynomial")

#align(center)[#tao-fit-display[#mitex("F(L_1, L_2 L_3) = F(L_2, L_1 L_3) = F(L_3, L_1 L_2) = C")]]

#text("under the multiplication map ")#mi("{F}")#text(", but are not related to each other by scaling symmetry ")#link(<tao-54b759dba2ded0937372>)[#text("(3)")]#text(". Thus, we see that even after quotienting out by the scaling symmetry ")#link(<tao-54b759dba2ded0937372>)[#text("(3)")]#text(", the multiplication map ")#mi("{F}")#text(" is generically non-injective in a three-to-one fashion. Thus we already have achieved something resembling goal (b)!")

#text("It will be convenient to “spend” the scaling symmetry ")#mi("{(L, Q) \\mapsto (\\lambda L, \\lambda^{-1} Q)}")#text(" to obtain a useful normalization. If ")#mi("{L(z,w) = az+bw}")#text(" is a linear polynomial and ")#mi("{Q(z,w) = cz^2 + dzw + ew^2}")#text(" is a quadratic polynomial, the (homogeneous) ")#link("https://en.wikipedia.org/wiki/Resultant#Homogeneous_resultant")[#text("resultant")]#text(" ")#mi("{\\mathrm{Res}(L,Q)}")#text(" can be defined by the determinant ")#metadata(none) <tao-09d85373326859f01a07>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\mathrm{Res}(L,Q) = \\begin{vmatrix} a & b & 0 \\\\ 0 & a & b \\\\ c & d & e \\end{vmatrix} = a^2 e - abd + c b^2.")]]

#text(" ")#text(" If we have a factorization")

#align(center)[#tao-fit-display[#mitex("L(z,w) = a (z - \\alpha w), \\quad Q(z,w) = c (z - \\beta_1 w)(z - \\beta_2 w)")]]

#text("then the resultant can also be described as")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Res}(L,Q) = a^2 c (\\alpha - \\beta_1) (\\alpha - \\beta_2).")]]

#text("Thus the resultant measures whether the linear polynomial ")#mi("{L}")#text(" and the quadratic polynomial ")#mi("{Q}")#text(" share a common root. A fundamental fact about resultants is that they are ")#mi("{SL_2}")#text("-invariant: for any ")#mi("{T \\in SL_2({\\bf C})}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Res}(L \\circ T, Q \\circ T) = \\mathrm{Res}(L,Q).")]]

#text("One way to see this is to check it first for translations ")#mi("{(z,w) \\mapsto (z + hw, w)}")#text(" (which translate the roots ")#mi("{\\alpha,\\beta_1,\\beta_2}")#text(" by ")#mi("{-h}")#text(" while leaving ")#mi("{a,c}")#text(" unchanged) and for inversions ")#mi("{(z,w) \\mapsto (w,-z)}")#text(" (which map ")#mi("{\\alpha,\\beta_1,\\beta_2}")#text(" to ")#mi("{-1/\\alpha, -1/\\beta_1, -1/\\beta_2}")#text(" while mapping ")#mi("{a,c}")#text(" to ")#mi("{a\\alpha}")#text(" and ")#mi("{c\\beta_1 \\beta_2}")#text(" respectively), and then noting that these transformations generate all of ")#mi("{SL_2({\\bf C})}")#text(". They also interact very nicely with scaling:")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Res}(\\lambda_1 L, \\lambda_2 Q) = \\lambda_1^2 \\lambda_2 \\mathrm{Res}(L,Q).")]]

#text("In particular, the scaling symmetry ")#link(<tao-54b759dba2ded0937372>)[#text("(3)")]#text(" multiplies ")#mi("{\\mathrm{Res}(L,Q)}")#text(" by ")#mi("{\\lambda}")#text(":")

#metadata(none) <tao-e246c011acd7f558b14e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\mathrm{Res}(\\lambda L, \\lambda^{-1} Q) = \\lambda \\mathrm{Res}(L,Q).")]]

#text("Thus, we can (generically) normalize away this scaling symmetry by imposing the condition")

#metadata(none) <tao-0e405b9869cefa2cf895>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\mathrm{Res}(L,Q) = 1.")]]

#text("We now have a restricted multiplication map (which by abuse of notation we will continue to call ")#mi("{F}")#text(") from the four-dimensional variety ")#metadata(none) <tao-2522fb7024fe0a83e6b9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\{ (L,Q) \\in \\mathrm{Sym}^1({\\bf C}^2) \\times \\mathrm{Sym}^2({\\bf C}^2) : \\mathrm{Res}(L,Q) = 1\\}")]]

#text(" ")#text(" to the four-dimensional space ")#mi("{\\mathrm{Sym}^3({\\bf C}^2)}")#text(". This map ")#mi("{F}")#text(" is still not globally injective, as we can take the three pairs in ")#link(<tao-528a556ab1f8fa01985b>)[#text("(4)")]#text(" from before and apply the scaling ")#link(<tao-54b759dba2ded0937372>)[#text("(3)")]#text(" separately to each of the three pairs to obtain the normalization ")#link(<tao-0e405b9869cefa2cf895>)[#text("(7)")]#text(". So we have kept property (b). Furthermore, this map retains the ")#mi("{SL_2}")#text("-equivariance (and also one remaining scaling symmetry, though we will not make much further use of that symmetry).")

#text("But we now also have property (a)! Suppose we want to show the local injectivity of ")#mi("{F}")#text(" in the neighborhood of a pair ")#mi("{(L,Q)}")#text(" with ")#mi("{\\mathrm{Res}(L,Q) = 1}")#text(". As the resultant is non-vanishing, the root ")#mi("{\\alpha}")#text(" of ")#mi("{L}")#text(" (which exists in the Riemann sphere, or projective line if you prefer) is distinct from the two roots ")#mi("{\\beta_1, \\beta_2}")#text(" of ")#mi("{Q}")#text(" (though the latter two roots could be equal to each other). Applying the ")#mi("{SL_2}")#text(" action (which performs Möbius transforms on the roots), one can assume without loss of generality that ")#mi("{\\alpha}")#text(" is the point at infinity (or equivalently ")#mi("{a=0}")#text("), thus ")#mi("{L(z,w) = b w}")#text(" for some complex number ")#mi("{b}")#text(" and ")#mi("{Q(z,w) = c (z - \\beta_1 w)(z - \\beta_2 w)}")#text(" for some complex numbers ")#mi("{c, \\beta_1, \\beta_2}")#text(", with the resultant condition ")#link(<tao-0e405b9869cefa2cf895>)[#text("(7)")]#text(" simplifies to ")#mi("{cb^2 = 1}")#text(" (so in particular ")#mi("{c,b}")#text(" are also non-zero). It is then clear that if one perturbs ")#mi("{L}")#text(" and ")#mi("{Q}")#text(" by a small amount (say, modifying each coefficient by ")#mi("{O(\\varepsilon)}")#text("), then the root ")#mi("{\\alpha=\\infty}")#text(" of ")#mi("{L}")#text(" will perturb to something large (")#mi("{\\gg 1/\\varepsilon}")#text("), while the roots ")#mi("{\\beta_1,\\beta_2}")#text(" of ")#mi("{Q}")#text(" stay bounded. Thus, just from knowledge of the product ")#mi("{F(L,Q)}")#text(", one can reconstruct which of the three roots of this cubic polynomial will be the perturbed root of ")#mi("{L}")#text(", and which two will be the perturbed roots of ")#mi("{Q}")#text("; from this and ")#link(<tao-e246c011acd7f558b14e>)[#text("(6)")]#text(", ")#link(<tao-0e405b9869cefa2cf895>)[#text("(7)")]#text(" we can also reconstruct the leading coefficient ")#mi("{c}")#text(" of ")#mi("{Q}")#text(", and this completely determines both ")#mi("{L}")#text(" and ")#mi("{Q}")#text(". This establishes the local injectivity property (a). (In fact it is ")#link("https://en.wikipedia.org/wiki/Formally_%C3%A9tale_morphism")[#text("étale")]#text(", but we will not need the machinery of étale maps here.)")

#text("Unfortunately, (the four-dimensional analogue of) condition (c) fails: the quadric hypersurface ")#link(<tao-2522fb7024fe0a83e6b9>)[#text("(8)")]#text(" is not isomorphic to the affine space ")#mi("{{\\bf C}^4}")#text(". But we can try to get around this by passing to a three-dimensional slice. Let ")#mi("{V}")#text(" be some three-dimensional affine plane of ")#mi("{\\mathrm{Sym}^3({\\bf C}^2)}")#text(" (which we will take to avoid the origin for technical reasons), then we can restrict ")#mi("{F}")#text(" as a map from the set ")#metadata(none) <tao-8a3cb1c26307077dabdc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\{ (L,Q) \\in \\mathrm{Sym}^1({\\bf C}^2) \\times \\mathrm{Sym}^2({\\bf C}^2) : \\mathrm{Res}(L,Q) = 1;")]]



#align(center)[#tao-fit-display[#mitex("F(L,Q) \\in V\\}")]]

#text("to ")#mi("{V}")#text(". ")#mi("{V}")#text(" is clearly identifiable (by linear changes of coordinate) to ")#mi("{{\\bf C}^3}")#text(". As ")#mi("{F}")#text(" was already locally invertible, it remains locally invertible under restriction; and because generic cubic polynomials ")#mi("{C}")#text(" had three preimages under ")#mi("{F}")#text(" in ")#link(<tao-2522fb7024fe0a83e6b9>)[#text("(8)")]#text(", this continues to be the case after restricting to ")#link(<tao-8a3cb1c26307077dabdc>)[#text("(9)")]#text(" (unless ")#mi("{V}")#text(" was somehow so degenerate that it had no generic elements, but this turns out to be impossible). So we have retained properties (a) and (b). The miracle is that, with a good choice of ")#mi("{V}")#text(", we can also obtain (c) and obtain the desired counterexample to the Jacobian conjecture: despite appearances, the variety ")#link(<tao-8a3cb1c26307077dabdc>)[#text("(9)")]#text(" is in fact equivalent to the affine space ")#mi("{{\\bf C}^3}")#text(" by polynomial changes of variable!")

#text("Let’s see how. The affine hyperplanes in ")#mi("{\\mathrm{Sym}^3({\\bf C}^2)}")#text(" avoiding the origin are parameterized by the dual space of ")#mi("{\\mathrm{Sym}^3({\\bf C}^2)}")#text(" avoiding the origin, which one can think of as the non-zero third order homogeneous differential operators ")#mi("{D = j \\partial_z^3 + k \\partial_z^2 \\partial_w + l \\partial_z \\partial_w^2 + m \\partial_w^3}")#text(" in two variables. Indeed, every such operator ")#mi("{D}")#text(" generates an affine hyperplane ")#mi("{\\{ C \\in \\mathrm{Sym}^3({\\bf C}^2) : D(C) = 1\\}}")#text(" that avoids the origin, and conversely by duality every affine hyperplane avoiding the origin arises in this form uniquely. Just as the cubic polynomials in ")#mi("{\\mathrm{Sym}^3({\\bf C}^2)}")#text(" can be factored into three linear polynomials, the differential operators in the dual space ")#mi("{\\mathrm{Sym}^3({\\bf C}^2)^*}")#text(" can also be factored into three linear differential operators, e.g.,")

#align(center)[#tao-fit-display[#mitex("D = j (\\partial_z - \\gamma_1 \\partial_w) (\\partial_z - \\gamma_2 \\partial_w) (\\partial_z - \\gamma_3 \\partial_w)")]]

#text("in the case that ")#mi("{j}")#text(" is non-zero. The ")#mi("{SL_2}")#text(" action moves the roots ")#mi("{\\gamma_1,\\gamma_2,\\gamma_3}")#text(" around the Riemann sphere by Möbius transformations. As these transformations are ")#mi("{3}")#text("-transitive, the actual selection of such roots is not too important (and the scaling symmetry similarly makes the choice of leading coefficient ")#mi("{j}")#text(" unimportant); the only thing to keep track of is whether the roots repeat. Up to the symmetries, there are in fact just three different equivalence classes of differential operator ")#mi("{D}")#text(" (and thus of affine hyperplane ")#mi("{V}")#text(") to consider:")

#list(
[#text("Operators where the three roots ")#mi("{\\gamma_1,\\gamma_2,\\gamma_3}")#text(" are all distinct, thus ")#mi("{D = D_1 D_2 D_3}")#text(" for independent first-order operators ")#mi("{D_1,D_2,D_3}")#text(".")],
[#text("Operators where two roots coincide and one is distinct, thus ")#mi("{D = D_1^2 D_2}")#text(" for independent first-order operators ")#mi("{D_1,D_2}")#text(".")],
[#text("Operators where all three roots coincide, thus ")#mi("{D = D_1^3}")#text(" for some first-order operator ")#mi("{D_1}")#text(".")]
)

#text("It turns out that the affine miracle for ")#link(<tao-8a3cb1c26307077dabdc>)[#text("(9)")]#text(" occurs precisely in the second case, when ")#mi("{D}")#text(" has two identical roots. I do not have a completely satisfactory geometric explanation for this miracle, but one can verify it by the following coordinate computation.")

#text("By applying the ")#mi("{SL_2}")#text(" action, we can normalize so that ")#mi("{D = \\frac{1}{2} \\partial_z^2 \\partial_w}")#text(", thus ")#mi("{V}")#text(" is now the affine hyperplane of cubic polynomials ")#mi("{C(z,w) = f z^3 + g z^2 w + h z w^2 + i w^3}")#text(" with ")#mi("{g=1}")#text(". Using ")#link(<tao-c0c75a8e79ad011929e6>)[#text("(2)")]#text(" and ")#link(<tao-09d85373326859f01a07>)[#text("(5)")]#text(", the variety ")#link(<tao-8a3cb1c26307077dabdc>)[#text("(9)")]#text(" can now be described explicitly in coordinates as ")#metadata(none) <tao-3b283e93debf035e990d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\{ (a,b,c,d,e) \\in {\\bf C}^5 : a^2 e - abd + cb^2 = 1; ad + bc = 1 \\}.")]]

#text(" ")#text(" At first glance this seems to be a generic-looking variety cut out by a cubic equation and a quadratic equation – hardly a candidate to be affine! But observe that if ")#mi("{a}")#text(" is non-zero, then the second equation ")#mi("{ad+bc = 1}")#text(" can be solved for ")#mi("{d}")#text(",")

#metadata(none) <tao-926f1181cf7fa63bc403>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("d = \\frac{1 - bc}{a}")]]

#text("and the first equation ")#mi("{a^2 e - abd + cb^2 = 1}")#text(" can be solved for ")#mi("{e}")#text(",")

#metadata(none) <tao-bc38b45c66a2a84843b3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("e = \\frac{1 + abd - cb^2}{a^2}.")]]

#text("Putting these two equations together, we see that as long as one removes the case ")#mi("{a=0}")#text(", the quintuple ")#mi("{(a,b,c,d,e)}")#text(" is uniquely determined by ")#mi("{(a,b,c)}")#text(" by a change of variables which is Laurent in ")#mi("{a}")#text(" and polynomial in ")#mi("{b,c}")#text(". Thus we have a nice birational equivalence")

#align(center)[#tao-fit-display[#mitex("\\{ (a,b,c,d,e) \\in {\\bf C}^5 : a^2 e - abd + cb^2 = 1; ad + bc = 1; a \\neq 0 \\}")]]

#align(center)[#tao-fit-display[#mitex("\\cong \\{ (a,b,c) \\in {\\bf C}^3 : a \\neq 0 \\}.")]]

#text("Thus we have already ")#emph[#text("almost")]#text(" established property (c): the variety ")#link(<tao-8a3cb1c26307077dabdc>)[#text("(9)")]#text(" becomes birationally equivalent to ")#mi("{{\\bf C}^3}")#text(" after cutting out the ")#mi("{a=0}")#text(" subvariety. In particular, for each fixed non-zero value ")#mi("{a_0}")#text(" of ")#mi("{a}")#text(", the corresponding fiber")

#align(center)[#tao-fit-display[#mitex("\\{ (a,b,c,d,e) \\in {\\bf C}^5 : a^2 e - abd + cb^2 = 1; ad + bc = 1; a = a_0 \\}")]]

#text("of ")#link(<tao-3b283e93debf035e990d>)[#text("(10)")]#text(" is equivalent to ")#mi("{{\\bf C}^2}")#text(" by polynomial changes of variable, since we can reconstruct ")#mi("{d,e}")#text(" from the coordinates ")#mi("{b,c}")#text(" by the polynomial formulae")

#align(center)[#tao-fit-display[#mitex("d = \\frac{1-bc}{a_0}; \\quad e = \\frac{1 + a_0 d b - c b^2}{a_0^2}.")]]

#text("So we just need to glue back in the ")#mi("{a=0}")#text(" fiber. Indeed, from ")#link(<tao-3b283e93debf035e990d>)[#text("(10)")]#text(" we see that the fiber at ")#mi("{0}")#text(" is just")

#align(center)[#tao-fit-display[#mitex("\\{ (0,b,c,d,e) \\in {\\bf C}^5 : cb^2 = 1; bc = 1 \\}.")]]

#text("Now we observe a key miracle: the cubic equation ")#mi("{cb^2 = 1}")#text(" and quadratic equation ")#mi("{bc = 1}")#text(" have a unique affine solution ")#mi("{b=c=1}")#text(" (as opposed to the six possible solutions that Bezout’s theorem might suggest – the other five solutions live on the line at infinity). So the fiber here is also affine:")

#align(center)[#tao-fit-display[#mitex("\\{ (0,1,1,d,e) \\in {\\bf C}^5 : d, e \\in {\\bf C} \\}.")]]

#text("This is extremely encouraging for the purposes of establishing property (c), as it strongly suggests that the variety ")#link(<tao-3b283e93debf035e990d>)[#text("(10)")]#text(" has the structure of an ")#mi("{{\\bf C}^2}")#text("-bundle over ")#mi("{{\\bf C}^1}")#text(", which is already extremely close to being isomorphic to the affine space ")#mi("{{\\bf C}^3}")#text(". The main remaining task is to make sure that nothing singular happens in the limit ")#mi("{a \\rightarrow 0}")#text(", and that a global polynomial coordinate chart for ")#link(<tao-3b283e93debf035e990d>)[#text("(10)")]#text(" that covers both the ")#mi("{a \\neq 0}")#text(" and ")#mi("{a = 0}")#text(" fibers can be constructed.")

#text("The standard way to proceed here is to manipulate various tangent spaces using the modern machinery of algebraic geometry and commutative algebra, but given my own background, I prefer to adopt the language of analysis, and in particular big-O notation (in place of the ideals used in algebraic geometry), in order to investigate the limit ")#mi("{a \\rightarrow 0}")#text(" by hand. On the variety ")#link(<tao-3b283e93debf035e990d>)[#text("(10)")]#text(", let us use ")#mi("{O(X)}")#text(" to denote any multiple of ")#mi("{X}")#text(" by a polynomial expression in ")#mi("{a,b,c,d,e}")#text(". Thus, for instance, the equation ")#mi("{ad + bc = 1}")#text(" implies that ")#metadata(none) <tao-25be5204b557360cd0a8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("bc = 1 + O(a)")]]

#text(" ")#text(" while the equation ")#mi("{a^2 e - abd + cb^2 = 1}")#text(" implies that")

#metadata(none) <tao-c2a574cbed39f480dc19>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("cb^2 = 1 + O(a)")]]

#text("as well as the more refined estimate")

#metadata(none) <tao-2642254dd2c7c7d7ff00>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("cb^2 = 1 + abd + O(a^2).")]]

#text("In the ")#mi("{a=0}")#text(" case we could conclude that ")#mi("{b=c=1}")#text(". Now we perturb this observation. Multiplying ")#link(<tao-25be5204b557360cd0a8>)[#text("(13)")]#text(" by ")#mi("{b}")#text(" we have ")#mi("{b^2 c = b + O(a)}")#text(", which on substitution into ")#link(<tao-c2a574cbed39f480dc19>)[#text("(14)")]#text(" gives ")#mi("{b = 1 + O(a)}")#text("; substituting this back into either ")#link(<tao-25be5204b557360cd0a8>)[#text("(13)")]#text(" or ")#link(<tao-c2a574cbed39f480dc19>)[#text("(14)")]#text(" also gives ")#mi("{c = 1 + O(a)}")#text(".")

#text("We can get some more precise asymptotics by also taking advantage of ")#link(<tao-2642254dd2c7c7d7ff00>)[#text("(15)")]#text(". Substituting ")#mi("{ad+bc=1}")#text(" into ")#link(<tao-2642254dd2c7c7d7ff00>)[#text("(15)")]#text(", we obtain after some algebra")

#align(center)[#tao-fit-display[#mitex("2 cb^2 = 1 + b + O(a^2).")]]

#text("So if we write ")#mi("{b = 1+O(a)}")#text(" more explicitly as ")#mi("{b = 1 + a y}")#text(", then we have")

#align(center)[#tao-fit-display[#mitex("2 c (1 + 2ay + O(a^2)) = 2 + ay + O(a^2)")]]

#text("and thus")

#metadata(none) <tao-7f351415c99bdf213321>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("c = 1 - \\frac{3}{2} ay + O(a^2).")]]

#text("Substituting this back into ")#link(<tao-926f1181cf7fa63bc403>)[#text("(11)")]#text(" gives an asymptotic for ")#mi("{d}")#text(":")

#tao-aligned(keep: true)[


#tao-math("d  & = \\frac{1 - bc}{a}", block: true)



#tao-math(" & = \\frac{1 - (1 + ay) (1 - \\frac{3}{2} ay + O(a^2))}{a}", block: true)



#tao-math(" & =\\frac{1}{2} y + O(a).", block: true)
]

#text("Finally, one can insert these estimates into ")#link(<tao-bc38b45c66a2a84843b3>)[#text("(12)")]#text(", although one only gets a trivial bound in this case:")

#tao-aligned(keep: true)[


#tao-math("e  & = \\frac{1 + abd - cb^2}{a^2}", block: true)



#tao-math(" & = \\frac{1 + a (1+O(a)) (\\frac{1}{2} y + O(a)) - (1 - \\frac{3}{2} ay + O(a^2)) (1 + ay)^2}{a^2}", block: true)



#tao-math(" & = O(1).", block: true)
]

#text("Expanding the ")#mi("{O(a^2)}")#text(" error term in ")#link(<tao-7f351415c99bdf213321>)[#text("(16)")]#text(" as ")#mi("{a^2 z}")#text(", and doing a little more algebra, we thus have a polynomial change of variables")

#tao-aligned(keep: true)[


#tao-math("a  & = a", block: true)



#tao-math("b  & = 1 + ay", block: true)



#tao-math("c  & = 1 - \\frac{3}{2} ay + a^2 z", block: true)



#tao-math("d  & = \\frac{1-bc}{a} = \\frac{1}{2} y - az + \\frac{3}{2} a y^2 - a^2 yz", block: true)



#tao-math("e  & = \\frac{1 + abd - cb^2}{a^2} = -2z + 4y^2 - 4ayz + 3ay^3 - 2a^2 y^2 z", block: true)
]

#text("which completely parameterizes the variety ")#link(<tao-3b283e93debf035e990d>)[#text("(10)")]#text(" by polynomial combinations of three coordinates ")#mi("{a,y,z}")#text(". This already gives (c) and thus completes the proof of Theorem ")#link(<tao-40a04291cec1d65b3060>)[#text("3")]#text(".")

#text("The previous computations, when expanded out, also gives polynomial inverse maps:")

#tao-aligned(keep: true)[


#tao-math("a  & = a", block: true)



#tao-math("y  & = 2bd - ae", block: true)



#tao-math("z  & = 2d^2 + ce + 6bd^2 + 3bce - \\frac{9}{2} e", block: true)
]

#text("The map from ")#mi("{(a,y,z)}")#text(" to the ")#mi("{(f,h,i)}")#text(" coefficients of ")#mi("{F(L,Q)}")#text(" (dropping the ")#mi("{g}")#text(" coefficient which is constrained to equal ")#mi("{1}")#text("), we obtain a polynomial map")

#align(center)[#tao-fit-display[#mitex("(a,y,z) \\mapsto (G_1(a,y,z), G_2(a,y,z), G_3(a,y,z))")]]

#text("with")

#align(center)[#tao-fit-display[#mitex("\\begin{array}{rl}  G_1(a,y,z) &= a - \\frac{3}{2} a^2 y + a^3 z \\\\ G_2(a,y,z) &= \\frac{1}{2} y - 3az + 6ay^2 - 6a^2 yz + \\frac{9}{2} a^2 y^3 - 3a^3 y^2 z \\\\ G_3(a,y,z) &= -2z + 4y^2 - 6ayz + 7ay^3 - 6a^2 y^2 z + 3a^2 y^4 \\\\ & \\quad - 2 a^3 y^3 z \\end{array}")]]

#text("which theory predicts to have a constant Jacobian, and indeed one can calculate that the Jacobian is ")#mi("{-1}")#text(". This is essentially the original example up to trivial changes of variable; indeed, one can check that the map")

#align(center)[#tao-fit-display[#mitex("(a, y, -2z) \\mapsto (G_3(a,y,z), 2G_2(a,y,z), 2G_1(a,y,z))")]]

#text("is exactly the map ")#mi("{F}")#text(" given in ")#link(<tao-4d602493dce987d46e52>)[#text("(1)")]#text(".")

#text("AI disclosure: I ")#link("https://chatgpt.com/share/6a5fdc7a-d6f8-83e8-bbea-8deb42cfed56")[#text("used an AI chatbot")]#text(" to discuss various aspects of this problem and to confirm several of the calculations made here.")

#heading(level: 1)[#text("Comments (179)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c596c81c231ee0e7efc8aded11d50aa07361b3e0fd161cf8e2fa4a20d1b44618-9a9b06512bde5dda2172e1faf22fd2051e66a077c9cb5bf491d8553fa91e492a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roland")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693681")[#strong[#text("Roland")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2026")])]

#text("Right before the introduction of the resultant, the definition of ")#mi("Q(z,w)")#text(" seems to be missing. Otherwise, thanks for the post!")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693684")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2026")])]

#text("The provenance question comes up a lot in this thread… for what it’s worth, this is currently tracked as “pending peer review,” not fully verified, at openconjectures.org/c/kill-jacobian-2026, credited to Claude Fable 5 with Levent Alpöge. Worth checking back once (if) it clears formal review rather than treating Tao’s writeup as the verification step itself.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693690")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2026")])]

#text("It is credited to Levent Alpöge, with Claude Fable 5 (Anthropic), not vice versa. Anyone with high school math competence can verify the counterexample.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d881a966306fc30a6e04943ec9b2cc31cfc3f442da7fcfc535fc4c8421b37765-88fdffb8dffcfff0ef987fdcfb6845f563faae647e70b26cf844d191d30dddb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 정동우")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693687")[#strong[#text("정동우")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2026")])]

#text("My question is about how you use AI rather than about the mathematics itself.")

#text("I could follow parts of your discussion of the Jacobian counterexample, and I was particularly interested in the way you moved between different representations of the problem. For example, you considered restrictions such as (c_2=1), hyperplane sections, and a fixed resultant level set. My impression was that the resultant condition removed a scaling degree of freedom and reduced the complexity of the problem.")

#text("From the conversation, I inferred a workflow roughly like this:")

#text("Define the problem and identify the invariants that must be preserved.")

#text("Generate several nearby representations or modeling hypotheses.")

#text("Systematically perturb and test those models by looking for counterexamples, equivalent formulations, special cases, and hidden structure.")

#text("Prefer models that explain more with fewer assumptions and make the calculations shorter.")

#text("Translate the resulting structure back into the original formulation and verify it there.")

#text("As a programmer, I was tempted to describe the third step as a kind of domain-specific semantic fuzzing or metamorphic testing: instead of inserting random program inputs, one varies the representation of the problem while checking that certain relationships and invariants remain intact.")

#text("I may be overinterpreting a single conversation, but I am interested in extracting a general workflow that could be applied outside mathematics as well. When you use GPT for research, is this broadly similar to your usual approach, or was this conversation atypical?")

#text("I realize this is a personal and somewhat meta-level question, so please do not feel any obligation to reply. I am simply trying to understand what it takes to use AI as effectively as you do.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1376208dbe10f73ccea1c1b1ab283536b3de23555176c8f7257d849d59c459fa-f1c24f4bc483e1cdee50c990547ec3334fefb8e50f31178dc9dd77fe9e416759.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kittenspeedyfa57a3f9ea")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693692")[#strong[#text("kittenspeedyfa57a3f9ea")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2026")])]

#text("A mechanical Bass–Connell–Wright reduction of Alpöge’s ℂ³ counterexample, yielding a cubic Keller map of ℂ¹⁹ that is 3-to-1 over a point. Worked out and verified with Claude (Fable 5).")

#link("https://rhicksrad.github.io/jacobian-degree3/")[#text("https://rhicksrad.github.io/jacobian-degree3/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693697")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2026")])]

#text("there’s something special about the natural number two that causes it to behave differently than natural numbers greater than two for a whole bunch of conjectures.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693695")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("“the conjecture is false in three dimensions (and thus in higher dimensions as well)”")
]

#text("Why is this implication true? Could anyone give me a link or quick explanation? Sorry if this is a dumb question.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693704")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2026")])]

#text("Lemma 3.1 of ")#link("https://arxiv.org/abs/2607.22198")[#text("the preprint mentioned in a recent comment")]#text(" establishes this implication, which is a simple matter of adding dummy variables to one’s polynomial.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-694217")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2026")])]

#text("In other words, you can complete the 3 dimensions counter-example by the identity mapping in (n-3) dimensions… This lets the Jacobian unchanged, giving a counter-example in dimension n > 3.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693696")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2026")])]

#text("I am a mathematician and not at all an expert on AI. I guess Alpöge has not been the first to ask AI about Jacobi’s conjecture. Do we know how did he get an answer? What prompt did he ask? Any specific training for the AI? How much did the AI work on his prompt?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71201f395df7767381e6f128fb702b6b806f8684a24a9f379cba33ba9c365fbe-44615daa6b4ed9c2ef237f863a907f77c1fe89e219bd8133ad8fcd03956ddad3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christopher")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693698")[#strong[#text("Christopher")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2026")])]

#text("Suggestion: the link for resultant should be changed to ")#link("https://en.wikipedia.org/wiki/Resultant#Homogeneous_resultant")[#text("https://en.wikipedia.org/wiki/Resultant#Homogeneous_resultant")]

#emph[#text("[Updated, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693699")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2026")])]

#text("There’s another route to proving the Jacobian conjecture in two dimensions, and that is by proving the Hessian conjecture in four dimensions:")

#link("https://arxiv.org/abs/2607.22198")[#text("https://arxiv.org/abs/2607.22198")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71201f395df7767381e6f128fb702b6b806f8684a24a9f379cba33ba9c365fbe-44615daa6b4ed9c2ef237f863a907f77c1fe89e219bd8133ad8fcd03956ddad3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christopher")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693701")[#strong[#text("Christopher")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2026")])]

#text("Hmm, for equation (16), is the derivation that using the analytic definition c = 1 – 3ay/2 + O(a^2), but then since we know that c is a polynomial from c = 1 + O(a), than O(a^2) must also be a polynomial?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693702")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2026")])]

#text("No analysis (in particular, no Neumann series or Taylor series) is used here; the big-O notation is meant to evoke analytic intuition, but has an algebraic interpretation. Because we already know that ")#mi("c = 1 + O(a)")#text(", the ")#mi("2c \\times 2ay")#text(" term can be simplified to ")#mi("4ay + O(a^2)")#text(", and the ")#mi("2c \\times O(a^2)")#text(" term can similarly be simplified to ")#mi("O(a^2)")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693705")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2026")])]

#text("Contrary to all the hype, the Jacobian conjecture counterexample is not that exciting because it relies on techniques established by Vitushkin in his 1999 paper. So there really is nothing new here. The only thing different is that here it’s applied to three dimensions and one gets a polynomial map, whereas in two dimensions one only gets a rational map.")

#text("If it were a human being who came up with this counterexample instead of a large language model, it’ll just be a writeup in Quanta Magazine, and then people move on because the techniques used in the proof aren’t new or that interesting, and the two dimensional case was always the more interesting one to algebraic geometers and still did not get resolved.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693711")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2026")])]

#text("The hype for the Jacobian conjecture counterexample is because Abhyankar and Moh made the conjecture famous in the 1970s and 1980s among mathematicians in academia. It has nothing to do with AI. Any human being who came up with the counterexample will be made instantly famous for disproving a famous conjecture.")

#text("You’re going to have to go back in time and stop Abhyankar and Moh from popularizing the Jacobian conjecture if you don’t want hype for disproving the Jacobian conjecture.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693726")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2026")])]

#text("But the fact is, when Abhyankar and Moh named “Jacobian conjecture” in the 1970-80s, they only referred to the 2-dimensional version. When such a conjecture is named, it really requires many positive results and strong evidence; this is only satisfied for 2D version. The higher dimensional generalization is only one extension of problem to see what’s possibly true and what’s not. But later some other mathematicians named the n-version “Jacobian conjecture” is kind of misleading, just like some named the n-version “Dixmier conjecture”, while Dixmier primarily focused on ")#mi("A_1")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693732")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2026")])]

#text("I don’t think that, prior to 2026, there was any consensus as to whether the planar Jacobian conjecture or the general dimensional Jacobian conjecture was the more “fundamental” one. To give four data points to complement the writings of Abhyankar and Moh:")

#list(
[#text("In 1998, Steven Smale listed the general dimensional conjecture as Problem #16 on his high-profile ")#link("http://smaleinstitute.com/Mathematical_problems_for_the_next_century.pdf")[#text("list of “problems for the next century”")]#text(", explicitly calling it “The Jacobian Conjecture”. In his own words, he holds “a belief that the question, its solution, partial results or even attempts at its solution are likely to have great importance for mathematics and its development in the next century.”. His commentary around this problem (see page 19) only discusses the general dimensional case, and does not even mention the planar case at all as worthy of any particular attention.")],
[#text("The ")#link("https://en.wikipedia.org/w/index.php?title=Jacobian_conjecture&oldid=1361627214")[#text("last version of the Wikipedia page on the conjecture before the counterexample discovery, dated 29 June 2026")]#text(", does (in my opinion) a reasonable job of approximating what the conventional wisdom towards the conjecture was at that moment; the two-dimensional case is mentioned and discussed, but does not have a central role, and the conjecture is formally stated in general dimension. (However, it is noted on that page that the two-dimensional conjecture was claimed (with a flawed proof) by Kraus in 1884, launching a very long line of failed proofs of this conjecture.)")],
[#text("I myself briefly mentioned the Jacobian conjecture in a ")#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/")[#text("blog post from 2009")]#text("; at the time, I had no impression that the ")#mi("n=2")#text(" case was of any particular significance. In particular, the result of Rudin discussed in that post that an injective polynomial map was automatically bijective with polynomial inverse works in all dimensions, and serves perhaps as a weak hint that the Jacobian conjecture is most naturally phrased in the general dimensional setting.")],
[#text("In the ")#link("https://link.springer.com/article/10.1007/BF01695502")[#text("original 1938 paper of Keller")]#text(", the conjecture is already formulated in all dimensions (contrary to some later accounts of this paper, which are in error), although he does single out the two-dimensional case as already being difficult. On page 301, Keller writes “die Frage, ob Polynome mit der Funktionaldeterminante 1 sich stets durch Polyhome umkehren lassen … mir scheint die Frage eine Untersuchung sehr zu lohnen, sie scheint jedoch bereits im ebenen Fall sehr schwierig zu sein.” (“the question of whether polynomials with a functional determinant of 1 can always be inverted by polynomials … it seems to me that this question is very worth investigating, however, it already seems to be very difficult in the planar case.”)")]
)

#text("In hindsight, we now know that the planar Jacobian conjecture is the more interesting question, but to say that this was the accepted conventional wisdom before 2026 is not strongly supported by the historical record. I think the most honest assessment one can make is the planar problem and the general-dimensional problem were both considered to be of interest, though individual mathematicians might choose to focus on one of the questions over the other. In retrospect it would probably have been a good idea to give these two conjectures slightly different names rather than calling them both “the Jacobian conjecture”, but going forward one can easily make a distinction between the (still open) planar Jacobian conjecture and the (now disproven) general-dimensional Jacobian conjecture.")

#text("An analogy might be with the Riemann hypothesis. When Riemann first introduced the hypothesis, it was solely about the Riemann zeta function. Over time, the hypothesis was generalized far beyond Riemann’s original intent, first to Dirichlet L-functions, then to Dedekind L-functions, and to many other L-functions besides. Similar to the situation with Rudin’s theorem, many of the partial or auxiliary results around RH tend to have analogues for GRH (though often with more technical difficulty in the proofs). Is there a current consensus as to which of RH and GRH is “more important”? As a thought experiment, suppose that in a few years an advanced AI discovers a way to construct an L-function that serves as a counterexample to GRH. Would this be considered a significant result? Or would the reaction be that it was “misleading” to talk about the generalized Riemann hypothesis at all, and that one should only be discussing Riemann’s original form of the hypothesis, rather than the now falsified generalizations introduced by “some other mathematicians”?")

#text("The Kakeya conjecture is another prominent example of a problem that was first posed in the plane in its original formulation, but subsequently became generalized to higher dimensions. In this case, it was the higher-dimensional case that turned out to be far more interesting. So one cannot always use the original historical formulation as a definitive ruling on what the most natural formulation of a problem is.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693733")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2026")])]

#text("The earliest appearance of this problem was in 1884 by Kraus, who focused on 2D. Keller’s work on general dimension problem was well-known, but all these false proofs before 1970s by Kraus, Segre, Gröbner, Engel and after that, the failed attempt during doctoral study by Yitang Zhang, wrong proofs by Amel’kin, Yucai Su focused on 2D. I do not oppose that the n-dimensional problem is and was important. I said 2D is central because disproving 2D automatically implies disproving the n-D version, as tried by Vitushkin; and proving 2D almost leads to the highest honor in math. Because of this, Abhyankar, Moh, and Vitushkin focused on 2D so hard that they did much less on higher dimensions and people only said “almost no evidence supports the higher dimension claim”, even without tries on finding counter examples (except for Moh who did a bit computation but even didn’t check if the algorithm was correct or not). Later people tend to higher dimensional case and equivalent formulations (conjectures) largely because it’s just so desperate to prove the 2D Jacobian conjecture directly, and people tend to produce more works on this topic. I agree that the new counter example is still an important achievement, but just one of these works in the long history of its reseach, even together with a few wrong proofs (which still contain correct lemmas). But clearly the claim by media and companies “the Jacobian conjecture was resolved” is highly misleading.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693736")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2026")])]

#text("The wording I would use here is that the AI-generated example resolves one, but not both, of the two commonly accepted versions of the Jacobian conjecture. For instance, it resolves the version of the Jacobian conjecture as stated by Smale’s Problem #16 (with this explicit name), by Keller (though he calls it “die Frage [nach] Polynome mit der Funktionaldeterminante 1” rather than “the Jacobian conjecture”), or by Wikipedia as of June 2026.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65c5e04ee1a502636b69db74fa76bab9c4881887c1e8a15673952f98a6808211-0aa3637d3f7b754aa1b558e5bfa8893ff0f93ca68bccabe12aa172b0090719e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dutifullyb3c31ab42c")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693734")[#strong[#text("dutifullyb3c31ab42c")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2026")])]

#text("I agree that mathematicians are truly free to make conjectures, at least in the before-AI ages, even without calculating any examples, because the mathematical world knows how to evaluate the works. But now I’m just afraid that the AI companies manipulate the public opinion so much that the evaluation system by mathematicians is affected and even mathematicians are misled (of course mathematicians even in algebraic geometry are not familiar with all subfields). Previously I see that even some people put the JC wiki page under the “Anthropic” category, like it’s their property. (Categories surve to mark the defining characteristics rather than tags). Later someone reverts the edit, but it seems the people opposing this change are the minority on Wiki page.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65c5e04ee1a502636b69db74fa76bab9c4881887c1e8a15673952f98a6808211-0aa3637d3f7b754aa1b558e5bfa8893ff0f93ca68bccabe12aa172b0090719e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dutifullyb3c31ab42c")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693738")[#strong[#text("dutifullyb3c31ab42c")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2026")])]

#text("I’m not sure if Smale really meant this “universal Jacobian conjecture”, as he didn’t say “for any n” or “let n be…”. In the literature, the Jacobian conjecture is very commonly indexed by dimensions. So now we are playing games of words, but for sure the media reports have led to large misleading, for instance many said “the AI disproved Jacobian conjecture” and then said “this problem indirectly led to Yitang Zhang’s years of working odd jobs to survive”. I wish the media reports could be more clear on this, while it seems just hopeless, like maybe after a few days or years, even if someone proves the 2D Jacobian conjecture, he or she will not obtain the deserved honor and Anthropic will be on top of them for this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693741")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2026")])]

#text("I can’t find any interpretation of Smale’s formulation of problem 16 that indicates that he was particularly interested in any specific value of n, such as n=2, rather than asking the question for arbitrary n. This can be contrasted with his discussion of problem 2 (the Poincare conjecture), which he formulates for arbitrary n, but has a detailed discussion of specific values of n, in particular highlighting the n=3 case as being the primary case to consider for this problem. It is also worth noting that none of the other problems on Smale’s list appears to be parameterized by any sort of dimensional parameter, so there appears to be no reason to assume that such a parameterization is secretly in effect just for this problem. (As explicitly noted on the first page of the paper, he is seeking questions “with a yes or no answer”, which to me strongly suggests that he is not introducing any additional parameters to these problems.)")

#text("In fact, it is notable that for Problems 2, 5, 6, 7, and 15 the dimension is explicitly fixed to a numerical constant to arrive at a “yes or no” question even though these questions also make sense in other dimensions, but for Problem 16 (and also Problem 12) he pointedly refuses to do so (though for Problem 12 he does isolate the case of a 2-sphere as a key special case).")

#text("Also, his problem 18 (limits of intelligence) is surprisingly relevant in the current context.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65c5e04ee1a502636b69db74fa76bab9c4881887c1e8a15673952f98a6808211-0aa3637d3f7b754aa1b558e5bfa8893ff0f93ca68bccabe12aa172b0090719e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dutifullyb3c31ab42c")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693742")[#strong[#text("dutifullyb3c31ab42c")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2026")])]

#text("But the reference he used, the work by van den Essen wrote clearly “the cases of dimension two and that of dimension bigger than two are")#linebreak()#text(" essentially different” on the first page, and labeled the Jacobian conjecture as “JC(n)” on the second page. Anyway, as wrote by Smale on the first page, the question were mainly collected but not asked by him. The statement of the Jacobian conjecture was quite varying at that period, and it makes more sense that mathematicians were in general interested in what we can get instead of whether or not it holds for every n. Would they regard the problem not important if it’s proved to hold only for 2D (to be proved)? I suspect so. Btw, I do not mean to criticize the people who made JC “general for all n”. But one fact is, in the 1980s (even up to 2 months before), the base to support the JC_n (n>=3) is not mature (people in recent 30 years frequently said almost no evidence supports it). Probably because of those positive results of 2D, people didn’t realize there were huge differences for dimensions at that time, and jumped a bit fast. On the contrary, coherent theory of L-functions, strong analogies across different families, the Weil conjectures proved by Deligne, and extensive computations strongly support GRH. This makes both proving and disproving super striking.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693744")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2026")])]

#text("In that referenced paper of van Essen, any reference to “the Jacobian conjecture” without any qualifier on ")#mi("n")#text(" (e.g., in the conclusions of Proposition 1.5, Theorem 1.6, or Theorem 1.7) clearly is in reference to the general dimension Jacobian conjecture. This is even more clear in another ")#link("https://seminariomatematico.polito.it/rendiconti/cartaceo/55-4/283.pdf")[#text("1997 paper of van Essen")]#text(", in which again the default interpretation of the Jacobian conjecture is taken to be the general dimensional one, starting with the first line of the abstract “there is no good reason to believe that the Jacobian conjecture holds” (whilst in the body of the article he makes it abundantly clear that there is quite strong evidence that the planar Jacobian conjecture (which is referred to using terms such as “the Jacobian conjecture for ")#mi("n=2")#text("“) is true).")

#text("Again, I think the only honest reading here is that both forms of the Jacobian conjecture were considered of interest prior to 2026. As the 1997 paper of van Essen shows, there was more evidence in favor of the planar Jacobian conjecture than the general conjecture, but not overwhelmingly so (cf., the “62.4% verdict” that the general Jacobian conjecture (which van Essen simply calls “the Jacobian conjecture”) is false at the end of the article). I also find it noteworthy that while the 1997 van Essen paper is unusually opinionated for a mathematical research publication, and goes to great lengths to distinguish the planar Jacobian conjecture from the general Jacobian conjecture, even in this paper no opinion is given as to which of the two forms of the Jacobian conjecture is more interesting to study (or which one is more important to resolve). In particular, the ")#emph[#text("de facto")]#text(" status of the general dimensional Jacobian conjecture as the “default” interpretation of that conjecture is not contested by that article.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65c5e04ee1a502636b69db74fa76bab9c4881887c1e8a15673952f98a6808211-0aa3637d3f7b754aa1b558e5bfa8893ff0f93ca68bccabe12aa172b0090719e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dutifullyb3c31ab42c")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693743")[#strong[#text("dutifullyb3c31ab42c")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2026")])]

#text("And of course even for a conjecture one has no positive results on it, one can still assume it fails/holds and have some results. But when generalizing some previous conjecture, one always needs to be cautious and try to avoid the same name for different problems. This happens in the case of Dixmier’s conjecture. After generalizing to ")#mi("A_n")#text(", it’s good to call it “generalized Dixmier conjecture”, but sometimes if people ignore the “generalized”, then a problem arises. People say “Dixmier conjecture is wrong”, but Dixmier’s formulation is on ")#mi("A_1")#text(", which remains open.")

#text("Btw, there is another “Generalized Jacobian Conjecture” established by Miyanishi from the aspect of affine algebraic geometry, in which he described the generalized Jacobian conjecture more like a condition for an algebraic variety instead of a universal statement, because he stated the conjection and at the same time provided counter examples.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65c5e04ee1a502636b69db74fa76bab9c4881887c1e8a15673952f98a6808211-0aa3637d3f7b754aa1b558e5bfa8893ff0f93ca68bccabe12aa172b0090719e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dutifullyb3c31ab42c")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693749")[#strong[#text("dutifullyb3c31ab42c")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2026")])]

#text("The “yes or no” clearly means not some ambiguous statement like “what is the xxxx”? For instance, when someone mentions about Kakeya conjecture, in case someone in future disproves some higher dimensional case, would he think the importance of 3D proof weaker? That would be ridiculous. (FYI, I’m working on analysis). Also, the second problem is not a good example for your argument. Smale is clearly an expert of Poincaré conjecture, and the only open case for Top was 3d at that time. For the problems 6, 10, 11, 13, they in fact support my claim that “when Smale didn’t write clearly ‘for any xx'”, he means these are parameters and the cases are important to distinguish for different parameters. For 16, the reason why he didn’t write claims for different n is not only he isn’t an expert in this field, but also that there were just no yes or no results for nontrivial dimensions available at that time. Your understanding that “he pointedly refuses to do so” lacks support. Finally, for the paper van den Essen, I’d like to point out that 62.4% reflects people’s attitude, but the differences in evidence were indeed overwhelming: he wrote explicitly “there is an overwhelming evidence for the 2 dim JC”, and “no good reason to believe the (universal) Jacobian conjecture”, and “enormous contrast between the 2-dimensional case and the cases n>=3”. Btw, it’s obvious that people working on this field have preferences over 2D or higher dimensional JC (maybe this difference results from almost nothing to break through in 2D from their point of view). Abhyankar, Moh, Vitushkin, Lih-Chung Wang, Heitmann, Yitang Zhang (in the past), Tráng, Hochster, Formanek, etc. clearly focused on 2D, and Bass, Connell, Wright, van den Essen, Wenhua Zhao, etc. clearly focused on general dimensional case (or even the universal case). This clearly explains why van den Essen mentions JC(n) and at the same time work on the universal conjecture (which was proved to be false).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693754")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2026")])]

#text("RE: Wikipedia.")

#text("A Wikipedia user named D.Lazard just undid all the distinguishing between the 2D and the general case in the article:")

#link("https://en.wikipedia.org/w/index.php?title=Jacobian_conjecture&diff=prev&oldid=1367187138")[#text("https://en.wikipedia.org/w/index.php?title=Jacobian_conjecture&diff=prev&oldid=1367187138")]

#text("Looks like Abhyankar and Moh and the proponents of “Jacobian conjecture” to refer to the 2D case just lost the war on Wikipedia. The Jacobian conjecture just refers to the general n dimensional case according to Wikipedia now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693766")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2026")])]

#text("All that the Wikipedia editors did was move that information to a new history section. The last paragraph of that section explicitly says that the two dimensional conjecture was “especially well studied” and that mathematicians like Abhyankar and Moh used “Jacobian conjecture” to refer to the 2D problem. Think that’s a win for the people who think the 2D problem was more important historically than the general nD problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693768")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2026")])]

#text("“Abhyankar and Moh and the proponents of “Jacobian conjecture” to refer to the 2D case”")

#text("That war over the proper usage of “Jacobian conjecture” was lost in 1998 when Moh started mentioning higher dimensions in his formulating of the Jacobian conjecture. Abhyankar is dead. The only people left fighting that war are clueless math students who seem stuck in the 1970s and haven’t gotten themselves acquainted with the recent literature on the topic where the authors always mention that the Jacobian conjecture is parameterized by dimension.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693856")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2026")])]

#text("“The last paragraph of that section explicitly says that the two dimensional conjecture was “especially well studied””")

#text("The Wikipedia article might state that in the history section, but the results section on the two dimensional case is just a paragraph on that people have ruled out counterexamples to the conjecture up to degree 108 or something. Where are all the other results in two dimensions if the two dimensional conjecture is “especially well studied”?")

#text("Compare with the n dimensional case where there are over a dozen paragraphs in the results section for the general n dimensional case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693931")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2026")])]

#text("Wikipedia is having a huge debate over whether the ‘Jacobian conjecture’ simpliciter is disproved or not:")

#link("https://en.wikipedia.org/wiki/Talk:Jacobian_conjecture#Categories")[#text("https://en.wikipedia.org/wiki/Talk:Jacobian_conjecture#Categories")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693748")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2026")])]

#text("The first published use of the term “Jacobian conjecture” was by Masayoshi Miyanishi in 1973 and referred to the general n dimensional case. Abhyankar and Moh only started publishing their stuff on the 2D Jacobian conjecture in the later half of the 1970s.")

#text("So, Abhyankar and Moh should be the ones to be blamed for confusing things and making “Jacobian conjecture” refer to the two dimensional case, when “Jacobian conjecture” was originally used for the n dimensional case.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693770")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2026")])]

#text("There’re no absolute rules on “determining the name by the first published existence”. There are some examples of naming by unpublished works, e.g. Frobenius coin problem and Gauss–Lucas theorem (Gauss part). I think history will judge this fairly (in case the mathematical community or humans still exist at that time). In case the 2D case is proved, then this will be highly striking and its importance will greatly surpass the general-dimension version, unless people find all possible counter-examples. But for now, it’s fair to index the JC by dimensions and say “n-variable Jacobian conjecture”, not the universal one that claims “for all n”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693772")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2026")])]

#text("Abhyankar and Moh should be blamed for not publishing a paper in the late 1960s and early 1970s. They started using the word “Jacobian conjecture” for the two dimensional conjecture privately amongst themselves after Oscar Zariski told them sometime in the 1960s that the conjecture was still unnamed. Had they published a paper back then, then it would have been in official public publication before the n dimensional conjecture shills got their hands on “Jacobian conjecture”, and then the n dimensional conjecture shills would have had to instead use a different name like “generalized Jacobian conjecture” or something similar.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693773")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2026")])]

#text("Moh himself is a “n dimensional conjecture shill” then because in his 1998 paper he defined the Jacobian conjecture parameterized by n.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693779")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2026")])]

#text("Moh said in response to the discovery of the three dimensional counterexample that he always only ever cared about the two dimensional conjecture; how does that make him a “n dimensional conjecture shill”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693789")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2026")])]

#text("Because the original commenter says that anybody who defines Jacobian conjecture in terms of n dimensions is an “n dimensional conjecture shill”. Which I think is extremely dumb.")

#text("I’m trying to point out to the original commenter that even Moh who is famous for working only on the two dimension version defines the Jacobian conjecture in n dimensions these days, but seems like there are three people who disagree with me for some reason because they downvoted my comment.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693715")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2026")])]

#text("The actual technique is “Construct a space with a marked factor, then forget the mark” according to a mathematician on twitter (forgot who it was).")

#text("What’s actually new is that thanks to the AI hype, mathematicians are now applying the technique to other conjectures that aren’t the Jacobian conjecture and disproving them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693720")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2026")])]

#text("Probably a bit extreme but the general idea is correct. People concentrated on 2D because it’s the most attractive (with too many wrong proofs) and disproving it leads to disproving all dimensions. The latter is considered by Vitushkin, who clearly focused on finding the obstruction for an easy 2D counter example without caring about 3D or higher. JC is a great treasure, and it should really belong to someone who prove $JC_2$ (probably in hundreds of years), and the recent work is just one step out of the very long history of research on it. However, Anthropic clearly used any ways of advertising to claim that “")#link("https://www.anthropic.com/research/discovering-cryptographic-weaknesses")[#text("they resolved JC")]#text("“, with a Wiki link, and then immediately someone added the Wiki article to categories “Anthropic”, “2026 AI”, like the JC is their propery. I’m so afraid that major mathematicians forget that the core problem is $JC_2$, in which case it means that the history has been distorted.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693759")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2026")])]

#text("People are moving on from the Jacobian conjecture in the real world because AI is too busy proving too many theorems. Connes rigidity conjecture and the construction of non-soric groups are far more impressive results than the Jacobian conjecture.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693769")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2026")])]

#text("Connes rigidity conjecture and non-sofic groups don’t have the drama over which version of the Jacobian conjecture is supposed to be the main version of the Jacobian conjecture. People will debate endlessly over whether the two dimensional or the n dimensional Jacobian conjecture is more important and not move on.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693774")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2026")])]

#text("With the n dimensional version solved for n > 2, I think it’s fair to say that the two dimensional version has won the battle and is now the more important version going forwards, and so the debate is over and people will move on.")

#text("Now as for the historical importance, I don’t think most people care about that issue, just as most people don’t care about the history of mathematics more broadly. Mathematicians are largely here to prove theorems, not contemplate about the historical and social factors behind what makes certain conjectures famous and notable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693785")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2026")])]

#text("The construction of a non-sofic group is just a clever application of two results derived by Gabor Kun and Andreas Thom in two separate papers:")

#link("https://mathoverflow.net/a/513885")[#text("https://mathoverflow.net/a/513885")]

#text("So it’s like the Jacobian conjecture counterexample in that it relies on previous papers by humans. Once again, something that Quanta Magazine would write about in an article if a human found this non-sofic group, but nothing too earth shattering to warrant all this hype. Andreas Thom himself said at the bottom of his post that he was looking for such a mechanism when the AI beat him to it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693771")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2026")])]

#text("I agree. These results seem to be more interesting than the 3D or higher dimensional Jacobian conjectures")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693786")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2026")])]

#text("Soficity is also not that important in group theory compared to some other more general properties of groups, just like how the multidimensional Jacobian conjecture is not that interesting compared to the two-dimensional Jacobian conjecture. More interesting would be constructing a non-hyperlinear group because it would refute Connes’ embedding problem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693841")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2026")])]

#text("Conjectures don’t lie in a vacuum. They have consequences on the truth or falsehood of other conjectures, and people care about the implications on the other conjectures.")

#text("So there are many algebraic geometers who do care about how the Jacobian conjecture being falsified impacts for instance the Diximer conjecture or the Hessian conjecture or the weak Markus–Yamabe conjecture.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693855")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2026")])]

#text("The proof approaches for the two dimensional Jacobian conjecture have a lot to do with low dimensional topology and singularity theory, so is significantly different from the proof approach for the Jacobian conjecture in more than two dimensions.")

#text("The whole field of low dimensional topology is due to the fact that lower dimensions behave differently than higher dimensions so it shouldn’t be surprising that resolving the Jacobian conjecture in low dimensions requires different techniques than resolving the Jacobian conjecture in higher dimensions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693706")[#strong[#text("Some thoughts about Anthropic’s new cryptanalysis results – A Few Thoughts on Cryptographic Engineering")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2026")]

#text("[…] probably notice that many of the exciting recent mathematical results have had this flavor: they either include a machine-checkable proof of a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71201f395df7767381e6f128fb702b6b806f8684a24a9f379cba33ba9c365fbe-44615daa6b4ed9c2ef237f863a907f77c1fe89e219bd8133ad8fcd03956ddad3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christopher")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693712")[#strong[#text("Christopher")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2026")])]

#text("Instead of guessing which of the three options we should go with, is there a way we could’ve solved for (f,g,h,i) that gives the right affine plane? Like come up with an equation that tells you when (f,g,h,i) satisfies theorem 3? Of course based on the reasoning that followed their would be many solutions (any case the operator has two identical roots) but showing such an equation has at least one solution let’s you jump to theorem 3 with no guessing needed!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0628e99d88c03dc7a8eda32a61da90b9849b07d50b207e2fe026753fc0a5353-f5132be3b6b532ae0e9f8dc93964d1d458c8ca597efe03026405a7434da318f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of info 19tet")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693717")[#strong[#text("info 19tet")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2026")])]

#text("Does this mean we can come up with arbitrary other counterexamples, maybe families of counterexamples? Where has the goalpost moved?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693747")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2026")])]

#text("The goalpost has moved to solving the 2D version of the conjecture. Many people argue that the Jacobian conjecture always was about the 2D version and that this 3D counterexample is irrelevant since it doesn’t affect the status of the 2D version.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693724")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2026")])]

#text("Provenance, since it matters for how much to trust the above: the computations and the write-up were done by Claude (Anthropic) in a working session, and I am posting them rather than vouching for them personally. All of it is machine-checkable and I am happy to share the scripts. If any of this is already in the thread and I have missed it, apologies for the noise.")

#text("Regarding the remark that there is no completely satisfactory geometric explanation for why only the repeated-root hyperplane class works — here is a computation that may add something, though parts of it are probably known to Will Sawin already. Following his observation that on fixing the marked point `(u:v)` both the hyperplane `H` and the ramification divisor `R` cut out *lines* in the `(a:b:c)`-plane, one can descend. Let `E ⊂ O^3` be the rank-two subbundle spanned by the two line-forms. As `μ_p` is linear and `λ_p` quadratic in the marked point, there is a bundle map `O(-1) ⊕ O(-2) → O^3` with image `E`, and evaluating at the base point gives `O^3 ↠ O(3-s)`, where `s` is the number of marked points at which the two lines coincide. Hence `deg E = s – 3`. Writing `B` for the projectivised pencil minus the two sections, `U → B` is an `A^1`-bundle and `#U = q·#B`. Then: – `s = 1` (the `2+1` class): the map drops rank once, `deg E = -2`, and since `E ⊇ O(-1)` with no degree-zero sub-line-bundle (a fixed linear form would have to lie in every pencil), `E ≅ O(-1)^2`, so `P(E) = F_0`. This is exactly Sawin’s trivialisation, and the two sections meet once, giving `B ≅ A^2`. – `s = 0` (the `1+1+1` class): the map is fibrewise injective and degrees agree, so `E ≅ O(-1) ⊕ O(-2)` and `P(E) = F_1`. The sections are disjoint, so `B` is `F_1` minus the zero and infinity sections of a degree-one line bundle, i.e. `B ≅ A^2 ∖ {0}`. So `B` fails to be `A^2` by exactly one point, and the collision in the repeated-root case is what fills that point in; multiplied by the `A^1` fibre this is precisely the `q` points separating `q^3 – q` from `q^3`. In the `1+1+1` case `U` is a non-trivial `A^1`-torsor over `A^2∖{0}` with affine total space, the same shape as `{xz + yw = 1} → A^2∖{0}`. The reason I think this is worth mentioning: the divisor-class criterion from the Secret Blogging Seminar thread has been read in a few places as *the* explanation, and it cannot be. For `2+1` and `1+1+1` the data on `U` is identical — `H` irreducible, two prime divisors removed, classes `(2,1)` and `(1,1)`, unimodular, so `Cl(U) = 0` with constant units — yet the second has `q^3 – q` points. Descending does not rescue it either: both give `Cl(B) = 0` with only constant units, since `A^2∖{0}` is the standard example of a variety passing both tests without being affine space, or affine at all. The criterion accounts cleanly for the reducible (`3`) class, and for `d ≥ 4` and `|a-b| ≠ 1`, but the `2+1` vs `1+1+1` distinction sits in its blind spot at both levels. What separates them is `F_0` versus `F_1`. The invariant is the expected one: the discriminant of the apolar quadratic equals the discriminant of the dual cubic as a polynomial identity, and `s ≥ 1` forces it to vanish (each pairwise resultant of the three cubics cutting out the collision carries the discriminant as a factor). Caveats. The `A^1`-bundle structure and the closed count `#B = q^2 – 1 + s` were verified exhaustively over `F_q` for small `q` rather than derived in general; the degree and splitting computations above are symbolic. Point counts are of course necessary-only, and the affineness in the `2+1` case is your Theorem, not reproved here — the descent just gives `B ≅ A^2` and then triviality of `A^1`-torsors over `A^2`.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7726914a47c4720813c732a8fc1274a7dcdb9d6e74cb7b374296278a41268a63-32a2e47ca41edc52699c9ac98357e6d346253ce94d3376a5b81c03791e2a586d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Fillmore")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693745")[#strong[#text("David Fillmore")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2026")])]

#text("The Alpoge-Fable map appears to be angular momentum addition in disguise via the Majorana stellar representation of spin. Briefly –")

#list(
[#text("A pure spin state can be written as a completely symmetric collection of spin-one-half spinors")],
[#text("Their projective rays are identified as “stars” on the sphere – Bloch, Riemann, or Celestial, depending on your preferred interpretation (quantum, complex-geometric, or relativistic); the number of stars is twice the spin, and coincident stars record repeated factors")],
[#text("A linear binary form is a spin-one-half state with one star; a quadratic is a spin-one state with two stars; a cubic is a spin-three-halves state with three stars. See ")#strong[#text("Penrose & Rindler")]#text(" I, Proposition (3.5.18), pp. 162–163")],
[#text("Tao’s reconstruction encodes each input as the spin-one-half factor together with the spin-one factor: one distinguished star plus an unordered pair. The factor dictionary is P&R I, Proposition (3.5.18), p. 162.")],
[#text("Multiplication is the completely symmetric, highest-spin part of adding spin one-half to spin one. It joins the single star to the pair and produces the three-star spin-three-halves constellation. See P&R I, equations (3.5.19)–(3.5.21), p. 162.")],
[#text("The output retains the constellation but forgets which star came from the spin-one-half factor. A generic triple therefore has three possible preimages.")]
)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693753")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2026")])]

#text("[Provenance: computations and write-up by Claude (Anthropic) in a working session; I am posting rather than personally vouching. Everything below is machine-verified and checkable in minutes with sympy; scripts available on request.] Three findings related to the July 30 comment above: The intrinsic invariant requested there exists at all degrees ")#mi("s \\ge 2")#text(". For ")#mi("X\\varphi = \\{ \\mathrm{Res}(L,Q)=1, \\varphi(LQ)=1 \\} \\subset W \\times \\mathrm{Sym}^s(W)")#text(", the Grothendieck-ring class depends only on the maximal root multiplicity ")#mi("m")#text(" of the dual binary form of ")#mi("\\varphi")#text(": it equals ")#mi("\\mathbb{L}^{s+1}-\\mathbb{L}^{s-1}")#text(" for ")#mi("m \\le s-1")#text(", ")#mi("\\mathbb{L}^{s+1}-\\mathbb{L}^{s}")#text(" for ")#mi("m=s+1")#text(", and ")#mi("\\mathbb{L}^{s+1}+(s-2)\\mathbb{L}^{s}")#text(" for root type ")#mi("(s,1)")#text(". Hence ")#mi("X\\varphi \\cong \\mathbb{A}^{s+1}")#text(" iff ")#mi("s=2")#text(" with type ")#mi("(2,1)")#text(": in every degree, the counterexample’s slice is the only affine-space slice. The mechanism does not descend to the plane through any slice so far tested. In the chart ")#mi("L=ax+By")#text(", ")#mi("Q=Cx^2+Dxy+Ey^2")#text(" with ")#mi("B=1+ay")#text(", ")#mi("C=1-\\tfrac{3}{2}ay+a^2z")#text(", ")#mi("D=\\tfrac{1}{2}y-az+\\tfrac{3}{2}ay^2-a^2yz")#text(", ")#mi("E=-2z+4y^2-4ayz+3ay^3-2a^2y^2z")#text(", write ")#mi("F=(G_1,G_2,G_3)")#text(" for the ")#mi("x^3, xy^2, y^3")#text(" coefficients of ")#mi("LQ")#text(" (then ")#mi("\\det DF \\equiv -1")#text("). One has the exact identities ")#mi("aG_2 = 2B+3W-2")#text(" and ")#mi("a^2G_3 = B(B+2W-1)")#text(" with ")#mi("W = 1-CB^2")#text(". These lead to machine-certified proofs that no fiber of any linear, ")#mi("(h,i)")#text("-only, or ")#mi("f+p(h)")#text(" target coordinate is ")#mi("\\mathbb{A}^2")#text("; sample check: on ")#mi("\\{G_2^2=3G_3\\}")#text(" the function ")#mi("B")#text(" is a nonconstant unit (the ideal ")#mi("(G_2^2-3G_3,\\,B)")#text(" is the unit ideal). Since an ")#mi("\\mathbb{A}^2")#text(" coordinate-fiber would give a degree-3 etale, hence Keller, self-map of the plane, these are conditional planar-JC statements. Still open: coordinates mixing ")#mi("f")#text(" nonlinearly with ")#mi("h,i")#text(". Cheapest check: ")#mi("F")#text(" is already 3-to-1 on real points; the cubic ")#mi("x^3+x^2y-10xy^2+8y^3")#text(" (roots ")#mi("1,2,-4")#text(") has three real marked factorizations with ")#mi("\\mathrm{Res}=1")#text(", in exact rational arithmetic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693760")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2026")])]

#text("Small remark: The phrase “a candidate to be affine” would usually refer to being an affine variety, not isomorphic to an affine space.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693777")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2026")])]

#text("Dear Professor Tao,")#linebreak()#text("Thanks for your blog posts. I didn’t know about the Jacobian conjecture previously. I believe the string method could be used to produce the counterexample also.")#linebreak()#text("Dr Hayes")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693783")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2026")])]

#text("I found a way to derive more counterexample maps from the map posted by Alpöge, even complex coefficient ones, the idea is simple! While the components of these maps have more terms, one question that could be an important endeavor for mathematicians, is whether the original map posted by Alpöge is the minimal structure map that is a counterexample to the JC.")

#text("I’m also focused on the intriguing 1 + xy, to me it is the backbone of the counterexample. Still thinking … I need to discover the idea, then give it to mathematicians to do wonders with it.")

#text("I’m a physicist by the way, I find this problem simple enough to understand but challenging enough to promote creativity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dbba69a0a740487338e519bd596765162d2a7802f158a666c592dc296885c14-1e55983f1e07dca636b0513dc2be0c15dac6b25178fc49c82c470bfb9f084847.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of darkmeerkat276d789e38")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693793")[#strong[#text("darkmeerkat276d789e38")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2026")])]

#text("Thanks to Professor Tao for the blog post where I learned the first counterexample. I worked with Claude Fable 5 to generalize the example to higher dimensions. The outcome is a paper posted at")#linebreak()#text(" ")#link("https://arxiv.org/abs/2608.00222")[#text("https://arxiv.org/abs/2608.00222")]#linebreak()#text(" which gives a general construction (based on parametrized hypersurfaces) for counterexamples in every dimension greater than two and, in each dimension, of arbitrarily large geometric degree.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693795")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2026")])]

#text("How does one express polynomial maps on an n-dimensional vector space and the Jacobian determinant of a polynomial map in a coordinate-free manner?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693803")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2026")])]

#text("There are a number of ways to do this. From an analysis point of view, one can view a degree ")#mi("k")#text(" polynomial map ")#mi("P : V \\to W")#text(" on a vector space to be any smooth map whose ")#mi("(k+1)^{th}")#text(" derivative ")#mi("\\nabla^{k+1} P : V \\times V^{k+1} \\to W")#text(" vanishes (this can be defined in a coordinate-free manner), and the Jacobian is the multiplier of the action of ")#mi("P")#text(" on volume forms. Algebraically, I think these maps can be described in the homogeneous setting as ")#mi("\\mathrm{Sym}^k(V^*) \\otimes W")#text(" (the formula gets a bit trickier in the inhomogeneous case), but perhaps there is a cleaner way to describe it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68557d9abcbd1f65159936bb2139a18f35e4272f09ef8533a58fd6ed1dcda187-fab9b5dddb6ac842f8f48e48d8ac21c57b08657364484654c4ec2be41fe4f700.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Oppel")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693796")[#strong[#text("Christian Oppel")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2026")])]

#text("Excellent article.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693804")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2026")])]

#text("Kossivi Adjamagbo’s separable Jacobian conjecture for positive characteristic fields just got disproven for all dimensions n > 1:")

#link("https://arxiv.org/abs/2607.20968")[#text("https://arxiv.org/abs/2607.20968")]

#link("https://arxiv.org/abs/2608.02634")[#text("https://arxiv.org/abs/2608.02634")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693824")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2026")])]

#text("The first observation about passing to characteristic 2, dimension 3, has been recorded elsewhere; see Timothy Chow ")#link("https://mathoverflow.net/a/513393/297")[#text("https://mathoverflow.net/a/513393/297")]#text(" and N8Programs ")#link("https://xcancel.com/N8Programs/status/2079061392649302185")[#text("https://xcancel.com/N8Programs/status/2079061392649302185")]#text(" . That said, I am in favor of results being recorded in clearly written versions posted to repositories like the arXiv, so good for Irit Huq-Kuruvilla for putting in the work.")

#text("And here is a reward for Huq-Kuruvilla’s work — the two dimensional case in characteristic two! That’s really exciting. Maybe we’ll see the two dimensional case in some other characteristics soon!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693840")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2026")])]

#text("The weak Markus–Yamabe conjecture in algebraic geometry is refuted as a result of the Jacobian conjecture counterexampe:")

#link("https://arxiv.org/abs/2608.05392")[#text("https://arxiv.org/abs/2608.05392")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0f7c7ad06e697fbe5ee8824464a13ca9e0351b393ef4b2a9ebe6a8c8900dba5-d55c28a7783f11fd299245299491e38d844c474a48cc2b9d89acc6089567d5e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693844")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2026")])]

#text("In the (1,2) case with one cut, the two classes other than (2,1) can be ruled out directly: for (3) the cut reads ")#emph[#text("ac")]#text(" = 1, so ")#emph[#text("a")]#text(" is a nonconstant unit on ")#emph[#text("V")]#text(" and ")#emph[#text("V")]#text(" is not affine space of any dimension; for (1,1,1) decomposing by ")#emph[#text("a")]#text(" gives χ(")#emph[#text("V")]#text(") = 0 ≠ 1 = χ(ℂ³). This can be extended to ")#emph[#text("Sym")]#text("¹ × ")#emph[#text("Sym^k")]#text(" with any number of cuts, where the same Euler characteristic argument gives χ(")#emph[#text("V")]#text(") = (")#emph[#text("k")]#text("−1)")#emph[#text("N")]#text(" and hence forces ")#emph[#text("k")]#text(" = 2. Two notes and verification code: ")#link("https://github.com/michaelmross/jacobian")[#text("https://github.com/michaelmross/jacobian")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693852")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2026")])]

#text("The extension to multiplication of a linear polynomial by a degree k polynomial to yield a degree k + 1 polynomial is important as it makes it clear why k = 2 is the only valid option here and why k = 1 (Vitushkin’s idea) or k > 2 doesn’t work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0f7c7ad06e697fbe5ee8824464a13ca9e0351b393ef4b2a9ebe6a8c8900dba5-d55c28a7783f11fd299245299491e38d844c474a48cc2b9d89acc6089567d5e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693870")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2026")])]

#text("Thanks. I didn’t know about Vitushkin’s paper. Looks like his 2D construction produces a ")#emph[#text("rational")]#text(" map with the 1/s fraction, while k = 2 produces a genuine polynomial one.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693857")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2026")])]

#text("The Jacobian conjecture after July 2026 will be like the Poincaré conjecture after Smale’s 1961 proof of the Poincaré conjecture for n > 4 and Freedman’s 1982 proof of the Poincaré conjecture for n = 3.")

#text("People will end up using “Jacobian conjecture” to refer to only the two dimensional Jacobian conjecture, just like they used “Poincaré conjecture” to refer to only the three dimensional Poincaré conjecture after 1982.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65c5e04ee1a502636b69db74fa76bab9c4881887c1e8a15673952f98a6808211-0aa3637d3f7b754aa1b558e5bfa8893ff0f93ca68bccabe12aa172b0090719e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dutifullyb3c31ab42c")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693862")[#strong[#text("dutifullyb3c31ab42c")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2026")])]

#text("The case seems to be different. In the literature, the Poincaré conjecture mostly only referred to the 3D version, even before Smale’s proof, because people suspected the higher-dimensional version at that time. But I agree that the conventions on the names can change, depending on what the major mathematicians in this field think of.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-694102")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2026")])]

#text("Freedman’s 1982 proof of the Poincaré conjecture for n = 4.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693885")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2026")])]

#text("This article from Towards Data Science by a CS professor explains the counter example in simple terms that are mostly easy to understand for non-mathematicians: ")#link("https://towardsdatascience.com/a-simplified-view-of-the-jacobian-conjecture/")[#text("https://towardsdatascience.com/a-simplified-view-of-the-jacobian-conjecture/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693899")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2026")])]

#text("The 2D Jacobian conjecture should really be considered a problem in low dimensional topology. What’s so special about the Euclidean plane vs higher dimensions that Keller maps seem to behave differently on the Euclidean plane?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693950")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2026")])]

#text("Apparently Moh is retired now and so is no longer working on the Jacobian conjecture:")

#link("https://en.wikipedia.org/wiki/Talk:Jacobian_conjecture#Results_in_the_2D_Jacobian_conjecture")[#text("https://en.wikipedia.org/wiki/Talk:Jacobian_conjecture#Results_in_the_2D_Jacobian_conjecture")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-693968")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2026")])]

#text("i don’t understand a single thing but wow math is cool.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-694196")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2026")])]

#text("A coordinate-free proof of the Jacobian conjecture counterexample has appeared in a preprint on an arxiv: ")#link("https://arxiv.org/abs/2608.27341")[#text("https://arxiv.org/abs/2608.27341")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-694198")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2026")])]

#text("This Jacobian conjecture counterexample is separable over a field with characteristic p > 3 and is still a Keller map, and so is a counterexample to the separable Jacobian conjecture for fields with characteristic p > 3.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-694314")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("The separable Jacobian conjecture by Adjamagbo has just been disproven by Alexander Borisov, Ofer Gabber, and Adrian Vasiu for all fields with positive characteristic in all dimensions:")

#link("https://arxiv.org/abs/2609.05746")[#text("https://arxiv.org/abs/2609.05746")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-694326")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Alexander Borisov, Ofer Gabber, and Adrian Vasiu found counterexamples for all fields with positive characteristic in dimensions greater than or equal to 2; the 1D version of the separable Jacobian conjecture should still be true.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-694350")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Since this paper is quite long, let me be more specific: Theorem 28.6 provides, in every finite characteristic, two-dimensional counterexamples to the separable Jacobian conjecture. As the 3:37 PM anonymous points out, in dimensions >= 3, for characteristic >3, this already follows from the Alpoge/Claude example.")

#text("I’d encourage the authors to promote Theorem 28.6 more visibly; I had been vaguely thinking I might try to prove something like this and I imagine that other people are too.")

#text("David Speyer")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-694338")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Your comment “The separable Jacobian conjecture by Adjamagbo has just been disproven by Alexander Borisov, Ofer Gabber, and Adrian Vasiu for all fields with positive characteristic in all dimensions” is just blatently false.")

#text("What actually happened is that separable Jacobian conjecture by Adjamagbo has just been disproven by Alexander Borisov, Ofer Gabber, and Adrian Vasiu for all fields with positive characteristic in all dimensions greater than one. The ‘greater than one’ is very important here because Adjamagbo introduced the separable condition specifically to make the one-dimensional case true.")

#text("To quote the abstract of the paper at ")#link("https://arxiv.org/abs/2609.05746")[#text("https://arxiv.org/abs/2609.05746")]#text(", “Surjective (resp.\\ surjective and non-surjective) counterexamples to Adjamagbo’s Jacobian Conjecture over each k are included in dimension 2 (resp.\\ in all dimensions at least 3);”")

#text("Your falsehood in your comment is causing large language models like google.ai to spit out falsehoods about the status of the separable Jacobian conjecture when they search through the comment sections of blogs like this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-694356")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Do people actually include the 1D case when they talk about “all dimensions” in algebraic geometry, or does “all dimensions” implicitly have a meaning of 2D or above?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-694361")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Yes they do, go take a look at Wikipedia for example where they talk about the 1D case being trivially true for the separable Jacobian conjecture for positive characteristic fields, as well as the 1D case being trivially true for the Jacobian conjecture for characteristic zero fields.")

#text("But large language models are just stochastic parrots and so they just repeat any misinformation by random anonymous people on the internet if it’s in their training data, including it seems the comment by the Anonymous above who falsely claimed that “the separable Jacobian conjecture by Adjamagbo has just been disproven by Alexander Borisov, Ofer Gabber, and Adrian Vasiu for all fields with positive characteristic in all dimensions”. No, the separable Jacobian conjecture has only been disproven in two dimensions and higher.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-694366")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("When you ask google.ai this question they say that")

#text("“")#strong[#text("Yes, absolutely.")]#text(" The 1-dimensional case is heavily included when discussing ")#strong[#text("polynomial maps")]#text(" (often called ")#strong[#text("morphisms")]#text(" or ")#strong[#text("regular maps")]#text(") in algebraic geometry.")

#text("In fact, polynomial maps involving 1D varieties (algebraic curves) provide some of the most fundamental examples, counterexamples, and deep theorems in the entire field.”")

#text("so google.ai is saying that the 1D case matters a lot in algebraic geometry, then google.ai is falsely saying that the separable Jacobian conjecture has “counterexamples for ")#strong[#text("all fields with positive characteristic in all dimensions")]#text("“, when the 1D case is TRUE for the separable Jacobian conjecture (and so has NO counterexamples).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-694360")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Just checked, typing in “separable Jacobian conjecture” in Google search’s AI mode results in the AI spitting out “Alexander Borisov, Ofer Gabber, and Adrian Vasiu published a comprehensive paper completely disproving the separable Jacobian conjecture for ")#strong[#text("all fields of positive characteristic in all dimensions")]#text("” with a link to this blog post as a reference. The AI’s bolded words are false because the 1D case is designed to be true for all fields of positive characteristic.")

#text("So yeah, seems like that anonymous poster from 9 September, 2026 at 6:05 am is doing real damage to the credibility of Google search by his failure to mention that Alexander Borisov, Ofer Gabber, and Adrian Vasiu only disproved the separable Jacobian conjecture for dimensions 2 and above. Now Google search AI mode is going to be constantly spreading misinformation to anybody who uses the Google search AI mode to find information about the separable Jacobian conjecture, because the AI keeps on referencing the anonymous poster’s wrong comments about the conjecture being disproven for all dimensions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-694365")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("google.ai frequently hallucinates stuff. For example the LLM behind google.ai currently claims that Mondello proved the separable Jacobian conjecture is false in two dimensions for all positive characteristics, whereas in reality, Mondello only proved it for characteristic 2. So don’t trust anything that comes out of google.ai.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-694368")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("The problems with Google won’t be solved until Googlebot recrawls this blog post, which may be in a few hours but also may be in a few weeks.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-694211")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2026")])]

#text("You wrote “The implication of local invertibility from ” .Did you mean to say “The implication of local injectivity from”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-694315")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("I would like to point to the final subsection of page 160 of the preprint “On endomorphisms of affine spaces and the Jacobian problem” by Borisov, Gabber, and Vasiu (")#link("https://arxiv.org/pdf/2609.05746")[#text("https://arxiv.org/pdf/2609.05746")]#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phenomenal18e147ff2c")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-696464")[#strong[#text("phenomenal18e147ff2c")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("This is great. I am impressed this is fully mathematical.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Satya")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-696485")[#strong[#text("Satya")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2026")])]

#text("There is a lot of comments on whether $JC(n)$ or $JC(2)$ was the real conjecture. Some people make distinction between Conjecture, Problems, and Questions. To me conjecture means that someone took a “bet” that the statement is valid, and waiting to the proved. I would refer to the comments in the introduction of the book of T-Y Lam entitled “Serre’s Problem …”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Satya")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-696486")[#strong[#text("Satya")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2026")])]

#text("Importance of this problem in the last century is marginalized in some of the comments. Many serious mathematicians took a shot to solve this problem in last century. And, some dedicated their career in pursuit of this problem, and wasted their career.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Satya")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-696500")[#strong[#text("Satya")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2026")])]

#text("Can you construct an epimorphism of polynomial rings, so that the kernel is not generated by variable. A lighter version asks, if the kernel is complete intersection or not?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Satya")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-696550")[#strong[#text("Satya")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("Unless I missed something, there is no evidence that Levent Alpogie did anything sophisticated, other than enumerate the possible universe of examples, of triples ")#mi("(F_1, F_2, F_3)")#text(", machine-compute the Jacobian and then (non)injectivity. No evidence of sophisticated use of AI, nor of use of some smart math technique to narrow down the universe of examples ")#mi("(F_1, F_2, F_3)")#text(". He is clearly working with integer coefficients. ")#strong[#text("Burden of proof is upon Alpogie, and write spomething more than a 3-liner.")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Satya")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-2/#comment-696587")[#strong[#text("Satya")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("I am harping on the same issue of 3-liner of Levent Alpogie. Here T. Tao derived the exact example analytically. So, how far Alpogie knew, and where did AI picked it up? ")#strong[#text("Secrecy builds mistrust – is there any significant AI input in the example of Alpogie")]#text("? If so, Alpogie owes it to the math community.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693504")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#text("Beautiful explanation. Two very small corrections:")

#enum(start: 1, 
[#text("At one point, you write “in coordinates it is given explicitly in coordinates as”; you probably want this to be either “in coordinates it is” or “it is given explicitly in coordinates as”.")],
[#text("You write “the map F is still not surjective…” but I think you meant injective.")]
)

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a09780f27263dbd21cd262466409c186aa49f8dd0953bdb1e69a7f50464152d0-2d50153bf81a828c90b1a5174b68f3fdea904f2bac5b0bcfaa39435b8ab27c06.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jim Balter")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693532")[#strong[#text("Jim Balter")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#text("Likewise, “Recently, it was ")#link("https://www.newscientist.com/article/2580374-ais-solution-to-87-year-old-riddle-takes-mathematicians-by-surprise/")[#text("recently shown")]#text("” is redundant.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a81e82edccce3ce5070054775147cac739e4d9c8c5784019f97676e40eabec46-759ddfd71c1646bb960d6603f553ef54ce811fcc29998846414340401e438b70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of swiftlytacod41af927bc")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693508")[#strong[#text("swiftlytacod41af927bc")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#text("Is there some representation-theoretic or moduli-theoretic intuition — perhaps something about the interaction of the SL₂-orbit stratification of the dual space with the discriminant locus — that would allow one to foresee ahead of time that the double-root stratum (and only that stratum) gives rise to an affine slice, instead of needing to directly check that ? Would one expect this to be a low-dimensional curiosity, or is there some general principle for when a GIT-type quotient construction like this results in affine varieties?”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693529")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#text("In my chatbot discussion I tried to pursue this line of thinking. As far as I could tell, there does not seem to be any plausible known set of computable invariants (including those that somehow take advantage of equivariant structure) that would force affine-ness, though perhaps some weaker “pseudo-affine” structure might be detectable by such a soft approach. But perhaps there are experts in algebraic geometry who will be able to give a more authoritative answer.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693525")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Also, from the fundamental theorem of algebra, once the Jacobian polynomial det(DF) is non-zero, it must be constant.")
]

#text("I might be missing something obvious—I see how the above follows via the Nullstellensatz, but not via the fundamental theorem of algebra per se (save insofar as the latter follows from the former).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693528")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#text("The fundamental theorem of algebra tells us that any one-dimensional polynomial is either constant, or has at least one zero (over the complex numbers). By induction, the same is true in higher dimensions; so if a polynomial ")#mi("P : {\\mathbf C}^n \\to {\\mathbf C}")#text(" has no zeroes, it must be constant.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82076306ffc039da7c330388c61a386c4e0b0b2ecb3556219fe75654f0826907-25077e5a70ea48a13b64e3fa524ad5e305c2e5b78cea3ded4d0eca29cb84750c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ariel")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693527")[#strong[#text("Ariel")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#text("This feels like a too beautiful counterexample, almost too beautiful to be discovered by a human. Polynomial multiplication is the most natural algebraic object that is locally injective but globally non-injective.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ac08578e0edfc897ba8259f941762c2c4419cb63fb57bafed3975794bd8573a-78dfc549694bf79c3787425760bffa7b7a0389839d3af0e3c06010309348dcf7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam Hopkins")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693530")[#strong[#text("Sam Hopkins")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#text("There is also some discussion of this here: ")#link("https://sbseminar.wordpress.com/2026/07/20/the-new-counterexample-to-the-jacobian-conjecture/")[#text("https://sbseminar.wordpress.com/2026/07/20/the-new-counterexample-to-the-jacobian-conjecture/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37432c98750e4022b84c1e02476ca47a145927ff594ef0eb39e820fe7e06b425-ce55d07280b037e17918e2e1908cc9c00ecabf3d55d9d47936fe5043346ccd52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693551")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("Let me state in the language of this post something from that thread: Given the equations ")#mi("a^2e-abd+cb^2=1")#text(" and ")#mi("ad+bc=1")#text(", the key step seems to be to subtract ")#mi("b")#text(" times the second equation from the first to cancel the ")#mi("cb^2")#text(" term, obtaining ")#mi("a( ae-2bd)=1-b")#text(", which motivates using coordinates ")#mi("x=a")#text(" and ")#mi("y=2bd-ae")#text(" since ")#mi("b")#text(" can be expressed as a polynomial function of these coordinates. Then the remaining coordinates ")#mi("c,d,e")#text(" satisfy the two affine equations ")#mi("ad+bc=1")#text(" and ")#mi("2bd-ae=y")#text(" which become ")#mi("xd+(1+xy)c=1")#text(" and ")#mi("2(1+xy) d- x e =y")#text(" which have a one-dimensional affine space of solutions for each ")#mi("x,y")#text(" since ")#mi("x")#text(" and ")#mi("1+xy")#text(" never both vanish, and this enables writing these variables as affine functions of a single remaining variable ")#mi("z")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693534")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#text("It seems that a similar-ish (rational) example was found by Vitushkin in 1999: ")#link("https://link.springer.com/article/10.1007/BF02674884")[#text("https://link.springer.com/article/10.1007/BF02674884")]

#text("See also ")#link("https://x.com/b_shrir/status/2079094004885668003")[#text("https://x.com/b_shrir/status/2079094004885668003")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693536")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#text("Nice! In retrospect the two constructions are rather similar. My chatbot was able to express the variety associated to the Vitushkin example in a form similar, but not identical, to (9), namely")

#mi("\\{ (L, L^{\\prime}) \\in \\mathrm{Sym}^1({\\bf C}^2) \\times \\mathrm{Sym}^1({\\bf C}^2) : \\partial_z L = \\partial_z L^{\\prime} = 1; R(L,L^{\\prime}) \\neq 0 \\}")

#text("with ")#mi("F")#text(" again the multiplication map (now generically two-to-one rather than three-to-one), but this variety is a punctured plane ")#mi("{\\bf C}^2 \\backslash {\\bf C}")#text(" rather than the entire plane, so Vitushkin’s map acquires a pole. I don’t think the traces from the original AI attempt are currently available, but it is possible that it experimented with a large number of variants of this construction until finding the one that worked.")

#text("In the opposite direction, increasing the net degree of the polynomials beyond cubic seems to rapidly make the structure worse, and in particular non-affine. (Once one has more than three roots in play, the Mobius transform group ")#mi("{\\mathrm SL}_2")#text(" is no longer transitive enough to keep the geometry behaving like a homogeneous space, and all sorts of generic algebraic geometry pathologies seem to seep back in.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693574")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("My AI was able to summarize the Vitushkin paper (overcoming the language barrier from Russian to English). After removing various birational changes of variable, the Vitushkin example is extremely simple: it is the sum-product map ")#mi("(z_1, z_2) \\mapsto (z_1+z_2, z_1 z_2)")#text(", which is locally injective on the punctured plane ")#mi("\\{(z_1,z_2) \\in {\\bf C}^2: z_1 \\neq z_2\\}")#text(" but not globally injective (because of the ")#mi("z_1 \\leftrightarrow z_2")#text(" symmetry). It is the puncture that forces Vitushkin to introduce a pole in his final map.")

#text("In the language of factoring polynomials, this corresponds to factorizing a monic quadratic ")#mi("z^2 + az + b")#text(" into linear monic factors ")#mi("(z-z_1)(z-z_2)")#text(", which is two-to-one and locally injective as long as one avoids the repeated root situation ")#mi("z_1 \\neq z_2")#text(", which is equivalent to the resultant ")#mi("z_1-z_2")#text(" of ")#mi("z-z_1")#text(" and ")#mi("z-z_2")#text(" being non-zero. (The two-dimensional case is exceptional in that the scaling symmetry ")#mi("(L,Q) \\mapsto (\\lambda L, \\lambda^{-1} Q)")#text(" cannot be used to normalize the resultant to equal 1. In the n-dimensional case one has ")#mi("\\mathrm{Res}(\\lambda L, \\lambda^{-1} Q) = \\lambda^{n-2} \\mathrm{Res}(L,Q)")#text(", but when ")#mi("n=2")#text(" the resultant becomes an invariant and so cannot be normalized.)")

#text("But it appears that Vitushkin did not explicitly realize the interpretation of this example in terms of multiplying polynomials. In retrospect, polynomial multiplication is a very natural example of a polynomial operation that is not globally injective (because a typical polynomial can be factored in several different ways) but can become locally injective once one removes the possibility of root collisions (by forcing the resultant to be non-zero) and also dealing with the scaling symmetry (by normalizing some coefficient or resultant), in order to make the various factors isolated from each other. What is remarkable is that one can still get an affine domain out of this. In the ")#mi("n=3")#text(" case, one has to intersect a cubic hypersurface (the resultant normalization ")#mi("\\mathrm{Res}(L,Q)=1")#text(") with a quadratic hypersurface ")#mi("F(L,Q) \\in V")#text("), which generates a degree ")#mi("3 \\times 2 = 6")#text(" surface. A priori it is unlikely that any polynomial transformations can lower this degree down to ")#mi("1")#text(". But the key miracle is the improvement over Bezout’s theorem when intersecting the quadric curve ")#mi("bc = 1")#text(" with the cubic curve ")#mi("b^2 c = 1")#text("; projectively this gives six intersection points by Bezout, but affinely there is only one intersection point ")#mi("b=c=1")#text(", which occurs without multiplicity. (The other five projective intersections occur at two points at infinity, one with multiplicity two and the other with multiplicity three.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693640")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2026")])]

#text("There should be almost no language barrier for AI!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693538")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#text("curious how you used chatGPT here to confirm. Looking at your conversation, you did not have to correct it even once. I have too little training in this field to accurately judge it, but in you entire conversation it did not once make a mistake or mischaracetrize anything?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693632")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2026")])]

#text("Recent LLMs can be switched to reasoning mode in the paid versions, where they iterate and validate the answers they produce. This works quite well in most fields where formal validation and linear reasoning can be applied (programming, mathematics primarily, but to a lesser degree other fields as well).")

#text("In other words, if you ask a modern LLM (in paid reasoning mode) a precise question, to which you are reasonable sure a precise an answer exists, you can expect a formally validate, that is correct rely.")

#text("This reply may not be the complete answer, but it will generally not hallucinate.")

#text("You can still make it hallucinate of course, but asking misleading question on ambiguous and imprecise topics, or where knowledge of the physical world or deep causality chains matter. And the cheap free chatbot versions are not be be used for serious work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693635")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2026")])]

#text("It seems ChatGpt was able to converse at this level and even provide insights without going astray. I find it astonishing that it was able to keep up with T.T. at all.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/30f04da10c446afa283e5d2f841b6dda6d2b71d7a8f722c92d4229b036ff0da5-fb78ed172bb2dd8676f18e501669db778f55a8eda04c7b98c3e682981c45544b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of inventive9d19b99cf0")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693539")[#strong[#text("inventive9d19b99cf0")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#strong[#text("Regarding the ‘massive miracle’ of this discovery, I’m curious if the AI was guided by known algebraic structures during its search, or if it stumbled upon this specific polynomial multiplication structure through sheer brute force. I would appreciate your insight as a non-expert.")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/84695016bafdeb331838d7af7594d1d4f46973b9a891b020abd5ceb85406af1e-aa4dbfdeec683ceed77a7f89b286681ed35d8a3129fa58a03dbde91910175355.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of garylangford")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693540")[#strong[#text("garylangford")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#text("One structural feature that struck me is that the multiplication map, the scaling quotient, and the resultant normalization all seem to arise from the same invariant picture rather than as separate constructions.")

#text("If one views as the state, then multiplication is the canonical -equivariant projection, the scaling is a one-dimensional scaling symmetry, and is the natural relative invariant that fixes a unique representative of each regular orbit. In that formulation the construction becomes the fiber of the constraint operator with your variety given by")

#text("This made me wonder whether the remaining “affine miracle” is really a property of the constraint operator rather than of the polynomial map itself. Question")#strong[#text(".")]#text(" Is the double-root orbit characterized invariantly as the unique orbit for which the fiber admits a global polynomial triangularization (equivalently, a polynomial trivialization), whereas the generic and triple-root orbits do not?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693541")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#text("question of the very dummy who cant even fully go over this text:")

#text("Is there a real “underlying theorem” that one can understand rigorously")

#text("that fable actually proved “internally”")

#text("and thus produced the counter example?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693544")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#text("type -> “still a few places were some remarkable phenomena occur”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693547")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("What happened with mathematics rendering in your blog? It used to work fine, but now the font and size don’t match the surrounding text.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693549")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("Minor correction:")

#text("“One way to see this is to check it first for translations {(z,w) \\mapsto (z, w + h z)} (which translate the roots {\\alpha,\\beta_1,\\beta_2} by {h} while leaving {a,c} unchanged)”")

#text("The SL2 transform which translates α and leaves a invariant is actually the lower triangular version, i.e.:")

#text("“One way to see this is to check it first for translations {(z,w) \\mapsto (z + h w, w)} (which translate the roots {\\alpha,\\beta_1,\\beta_2} by {h} while leaving {a,c} unchanged)”")

#text("~~Lillian Ryan Uhl")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693550")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("It does seem as though this problem does admit a very simple reward function: Namely, how close a given polynomial is to being non-injective (ie. has far-away points whose images are close to each other). I wonder whether this was the loss function that was used.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693556")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("However one ends up defining this concretely, to me this seems like it is a global property that is impossible to efficiently evaluate numerically, let alone optimize against.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693553")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text(">> The conjecture remains open in two dimensions.")

#text("Will the 2 dimensions case also resolved? By AI + human collaboration.")

#text("Thanks,")

#text("N. Ganesan")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b8d4cc2c16f777b47c491523f8f2ab02a706d331c8b8480fbd7b311dcace83c-f61e1b5841be164a2db102bec9478002e1c57923eff14cfc52bc8c326ec0c859.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brigham McNaughton")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693555")[#strong[#text("Brigham McNaughton")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#emph[#text("Disclaimer: I’m a complete amateur and have zero formal math training, I’ve just enjoyed exploring the fundamentals with LLMs.")]

#text("Amazing analysis, thank you for sharing!")

#text("It has been helpful for me to think in free magmas to understand the counterexample. I picture a universal infinite field of indistinct free magma ")#emph[#text("(Claude indicates the technical object here would be the free magma on infinitely many generators, with no distinguished element)")]#text(" at the root, then the conversion to zero and naturals means that I have selected a distinct single sub-magma in that field as a fixed observation point (")#emph[#text("Claude translation: a fixed base, which turns out to be a fixed point of the mirror symmetry)")]#text(", which then creates the specific collisions due to symmetry at the “sight lines” of that chosen fixed base in the field. I had the underlying principles formalized in Lean using a custom “AnyMark” type based on the idea behind the Laws of Form, but without any of its imposed laws. I’m nearly complete re-formalizing it onto Mathlib’s FreeMagma to better align with established terms.")

#text("Now a suspicion that goes really far over my amateur skis: this feels parallel to relativity, where selecting a fixed base is what generates a universal constant (Claude translation: the constant Jacobian determinant, the same reading at every point, playing the role of the speed of light) and the collision itself is the spooky action at a distance (Claude: points far apart tied together by the global symmetry) that are difficult to distinguish from the perspective of the selected fixed base.")

#text("Have you seen any similarities in your work on equational laws?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe806025cee6b5142ce7526f350eea8996adfd00fb1136817f7aa7333227c390-4a9933a1235177b4617e70d932b288195b7d8c87d52017eb176ff285843aa777.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felipe")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693557")[#strong[#text("Felipe")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("“By applying the action, we can normalize so that D=D^2_z D_w, thus V is now the affine hyperplane of cubic polynomials […] with g = 1”. Should that be g = 1/2? I guess to keep the computations unchanged the fix should rather be adding a 1/2 to D, using the scaling symmetry you’d thrown away earlier")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693558")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("By July 20, GPT-5.6 Sol/Codex wrote a “paper” giving an entire family of higher-dimensional counterexamples to the Jacobian conjecture (the paper is at ")#link("https://xcancel.com/i/article/2079135211196121363")[#text("https://xcancel.com/i/article/2079135211196121363")]#text("). This might give some insight into how the LLM came up with the initial 3-dimensional counterexample (since that counterexample is the first in this family of counterexamples). The paper gives explicit counterexamples for dimensions 3 through 6 (which it claims are not simple variations of the dimension 3 example).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693573")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("Interesting. After a bit more interaction with a chatbot, it appears the picture is the following. For any ")#mi("n \\geq 3")#text(", one can consider the space")

#mi("\\displaystyle X = \\{ (L, Q) \\in \\mathrm{Sym}^1 \\times \\mathrm{Sym}^{n-1}: \\mathrm{Res}(L,Q) = 1; F(L,Q) \\in V \\}")

#text("where one can for instance take ")#mi("V")#text(" to be the space of homogeneous degree ")#mi("n")#text(" polynomials in ")#mi("z,w")#text(" with ")#mi("zw^{n-1}")#text(" coefficient set equal to ")#mi("1")#text(". For all ")#mi("n \\geq 3")#text(", the polynomial map ")#mi("F")#text(" is locally injective but not globally injective on this space. In the ")#mi("n=3")#text(" case all of ")#mi("X")#text(" is affine. For ")#mi("n>3")#text(", this space is no longer affine (see the previous chatbot discussion I posted); but it turns out that if one removes a specific portion from ")#mi("X")#text(", namely those pairs ")#mi("(L,Q)")#text(" for which ")#mi("L = \\zeta z")#text(" for some non-trivial ")#mi("(n-2)^{th}")#text(" root of unity ")#mi("\\zeta")#text(", then there the space becomes affine again.")

#text("To map it to the discussion in the blog post, recall that in the ")#mi("n=3")#text(" case the ")#mi("a=0")#text(" fiber of ")#mi("X")#text(" was a single plane, because the equations ")#mi("bc = 1")#text(" and ")#mi("b^2 c = 1")#text(" had a unique affine solution ")#mi("b=c=1")#text(". In higher dimensions, it seems that the analogue of the ")#mi("a=0")#text(" fiber is the union of ")#mi("n-2")#text(" subspaces, I think coming from the fact that ")#mi("bc=1")#text(" and ")#mi("b^{n-1}c=1")#text(" has ")#mi("n-2")#text(" solutions ")#mi("b = \\zeta")#text(", ")#mi("c = \\zeta^{-1}")#text(" for the ")#mi("n-2^{th}")#text(" roots of unity) and one has to manually remove all but one of them before one gets an affine space.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d7820bc23f96c4bcf5f02e8555ff3881803b9cbdc4601dc7aedcb24602cfb44-057ac785f17e109adfef90a5a6b0937fe1fbfdfd8779ae2d7f772be25a25be9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jake Levinson")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693577")[#strong[#text("Jake Levinson")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("Hi Terry, I wrote up a short explanation ")#link("https://levjake.wordpress.com/2026/07/22/the-jacobian-conjecture-counterexample/")[#text("here")]#text(" of the counterexample, in coordinate-free terms, using only classical facts about lines and conics in the projective plane, basically first-year graduate algebraic geometry stuff. In fact the whole construction can be carried out this way, without any explicit calculations.")

#text("The only non-elementary fact I use is that A^1 bundles over A^n are trivial. (What I actually worked out is a way to exhibit the counterexample as an iterated A^1-bundle.)")

#text("I thought it might be of interest to you!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad454bd2734f037e8ca383f6d33166862593b771e672bb52bf13d81a2861db6b-f1ae9e9867ced5324fd65bb15716a9e026f00d898a55be6382523fb6c2e88e5c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of darkreally441a803784")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693595")[#strong[#text("darkreally441a803784")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2026")])]

#text("Terry, I am the author of the paper discussed above that you examined.")

#text("Thank you for looking at the construction. Your removal of the nontrivial root-of-unity components matches exactly the exceptional term in our follow-up fiber theorem:")

#tao-math("\\left| K_n^{-1}(P)\\right|=(n-2)s(P)-(n-3)\\mathbf{1}_{\\{P(0)=0\\}}.", block: false)

#text("Thus, over the zero root, only one branch remains in the affine chart, while the other ")#mi("n-3")#text(" branches escape to infinity.")

#text("The follow-up also determines the exact image, the codimension of the omitted locus, and the nonproperness locus:")

#link("https://doi.org/10.5281/zenodo.21506477")[#text("https://doi.org/10.5281/zenodo.21506477")]

#text("Your geometric description provides a very clean invariant explanation for the correction term.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693617")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2026")])]

#text("Let Y be X with the n-2 hypersurfaces removed, so Y = A^n. If I follow you correctly, then (L,Q) –> (zeta L, zeta^{-1} Q) is an action of Z/(n-2) Z on Y with no fixed points.")

#text("That means that this Z/(n-2) Z action would violate the Linearization Conjecture. I’m doing a literature search now to check that the case of cyclic actions is still open, but I think it is.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693618")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2026")])]

#text("Oh sorry, I’m wrong. I didn’t understand that I am supposed to remove L=zeta z for zeta nontrivial, but not L=z itself. So there is no easy cyclic action here.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bfcc6de57016958e56a5d931041c9c472675d01bfce83c0685595c34894c5d38-d9b71049796b69b0d3b62ba9eefcaa3f934e5ba6fa8e438214fe7316f6c5e71e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alejandro Radisic")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693559")[#strong[#text("Alejandro Radisic")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("A small arithmetic postscript to this digestion, machine-verified in Lean over the last two days: the integer polynomial map (1) knows the ")#mi("S_3")#text(" story over finite fields exactly.")

#text("Over any finite field ")#mi("\\mathbb{F}_q")#text(" of odd characteristic, write ")#mi("N_j")#text(" for the number of targets with exactly ")#mi("j")#text(" rational preimages. Then every fiber has ")#mi("0")#text(", ")#mi("1")#text(", or ")#mi("3")#text(" points, and")

#mi("6N_3 = (q-1)(q^2+2),")

#mi("N_1 + 3N_3 = q^3,")

#mi("N_0 = 2N_3.")

#text("In characteristic ")#mi("3")#text(", the first formula instead becomes")

#mi("6N_3 = q^2(q-1).")

#text("Thus the fiber-count distribution")

#mi("(N_0,N_1,N_3)/q^3")

#text("converges to")

#mi("(1/3,1/2,1/6);")

#text("these are the proportions of elements of ")#mi("S_3")#text(" with ")#mi("0")#text(", ")#mi("1")#text(", and ")#mi("3")#text(" fixed points, respectively: the Chebotarev prediction for the generic ")#mi("S_3")#text("-cover, with the finite-")#mi("q")#text(" corrections determined exactly.")

#text("The exactness has a cause visible in your account: targets with three-point fibers are in bijection with admissible unordered triples of distinct points of the projective line, and the slice normalization forces")

#mi("c(t_1+t_2+t_3)=2,")

#text("so the only inadmissible triples are finite triples with vanishing sum. Counting ordered triples is then elementary.")

#text("Characteristic ")#mi("3")#text(" is a genuine special case: the translation ")#mi("T=b+S")#text(" puts the cubic into the form")

#mi("cS^3+S^2+W.")

#text("A triple root becomes impossible, since a cube has no quadratic term in characteristic ")#mi("3")#text(", and the omitted curve is empty. Consequently, over an algebraically closed field of characteristic ")#mi("3")#text(", the same map is surjective while remaining étale and non-injective.")

#text("That final deduction is elementary but not yet formalized; the statistics, the normal form, and the emptiness of the triple-root locus are formalized, using only Mathlib’s axioms.")

#link("https://github.com/alerad/alpoge-lean — v0.3.0. AI-assisted development throughout, as usual.")[#text("https://github.com/alerad/alpoge-lean — v0.3.0. AI-assisted development throughout, as usual.")]#link("https://github.com/alerad/alpoge-lean")[#text("https://github.com/alerad/alpoge-lean")]#text(", v0.3.0. AI-assisted development throughout, as usual.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aadef7bab8f6a229b8438c6dbfe43059655d41a12f4a93b1e64f586389406662-fb8c292a1d13d31d53f2a607289d4b48ba1438ab82090211d4d289fab6b80c02.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jaan.allikvere")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693644")[#strong[#text("jaan.allikvere")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2026")])]

#text("A natural continuation of these fiber statistics: the S_3 census above is the d = 3 case of a derangement law for the higher-degree deformations G_d of the map (1). Their fibers are governed by the fiber polynomial Omega_d(s) = (2/d) p^d s^d + 2p s^3 – q s^2 + 2s – r, and for d in {4,5,6} a Galois-Chebotarev argument (with Morse specializations certified in every characteristic coprime to 2d) gives image density 1 – D_d/d! + O(q^{-1/2}), where D_d is the number of derangements in S_d. In particular G_6, which is surjective over C, asymptotically omits 53/144 of all F_q-targets.")

#text("On the complex side, the exact images of the G_d can be computed: the complement of the image is a rational curve for d = 4, exactly six points for d = 5, and empty for every d >= 6, so the higher members are surjective, non-injective Keller maps of geometric degree d. The general degree-three family (three scalar parameters and an arbitrary polynomial H(x,y)) turns out to be a single left-right equivalence class of the original map, a rigidity statement; the non-properness (Jelonek) sets are computed exactly as well.")

#text("Manuscript and an exact-arithmetic SymPy verification script: doi.org/10.5281/zenodo.21551408 AI-assisted, with disclosure in the manuscript. Comments and corrections are very welcome.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693560")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("During my discussions with GPT, I came across the following possible addition, which may be of interest. Some of it overlaps with the cubic-model discussion linked in the comments, but the following packages the mechanism directly in the final affine coordinates of (1). Write ")#mi("F=(F_1,F_2,F_3)")#text(". The map is equivariant under ")#mi("\\displaystyle (z_1,z_2,z_3)\\mapsto(\\lambda z_1,\\lambda^{-1}z_2,\\lambda^{-2}z_3),")#text(" with target weights ")#mi("(-2,-1,1)")#text(". Hence one can use the invariant coordinates ")#mi("\\displaystyle u=z_1z_2,\\quad v=z_1^2z_3,\\qquad A=F_1F_3^2,\\quad B=F_2F_3.")#text(" The induced quotient map ")#mi("\\overline{F}:(u,v)\\mapsto(A,B)")#text(" factors, after setting ")#mi("\\displaystyle s=2-3u-v,\\qquad t=(1+u)s,")#text(" as ")#mi("\\displaystyle (u,v)\\mapsto(t,s)\\mapsto(A,B)=\\left(t^2+st-t^3,\\,4t+2s-3t^2\\right).")#text(" The first map is birational but not proper. Its rational inverse contains ")#mi("\\displaystyle u=\\frac{t}{s}-1,\\qquad v=5-3\\frac{t}{s}-s,")#text(" so keeping ")#mi("t\\neq0")#text(" fixed while ")#mi("s\\to0")#text(" sends the source point to infinity. The second map is generically three-to-one: eliminating ")#mi("s")#text(" gives ")#mi("\\displaystyle t^3-2t^2+Bt-2A=0.")#text(" Thus the cubic factor accounts for the three generic preimages, while the preceding birational factor isolates how sheets can escape to infinity. This seems to be the final-coordinate counterpart of the three choices of the linear factor in (4). More generally, for generically finite polynomial maps equivariant for these same source and target weights, a function-field calculation gives that the original map and its two-dimensional quotient have the same generic number of preimages. Writing ")#mi("(X,Y,Z)=(F_1,F_2,F_3)")#text(", the quartic ")#mi("\\displaystyle Q(X,Y,Z)=27X^2Z^2-18XYZ+16X+Y^3Z-Y^2")#text(" then appears as the non-properness locus for this example (the finite target values approached by source points going to infinity), recovering the ")#mi("Q=0")#text(" geometry discussed in the linked thread. The displayed identities are exact and directly checkable;")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a775b9110ca902fd093f3e067d912c78d32b7a149f9a25d99d6947120730ee2-e1c7eb34cd9fb3e61976c47a522e4aa322aa291c8d6ac8cd6e17747b3e76d8d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lev Reyzin")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693562")[#strong[#text("Lev Reyzin")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("Not important, but small correction: 21 choose 3 is 1330, not 1300.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693564")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("In fact, wouldn’t it HAVE to find the counter-example by some convergence theorem? Like if we keep one root fixed and the other “quasi-root” inside an anulus away from the first, can’t you apply some sort of Ascoli argument? The prerequisite would be that there is some boundedness condition on the search space (since all is holomorphic here, we don’t even need to consider the derivatives). But if the search space is big enough, and the network manages to find some sort of descent, it would have to terminate.")

#text("Maybe AI wasn’t even necessary here?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693568")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("Thank you for your fascinating discussion of the Jacobian conjecture.")

#text("As a non-expert, I had a question inspired by the appearance of the term 1+XY in the counterexample. This may be only a superficial analogy, but it reminded me of the 3n+1 step in the Collatz problem. In both cases, adding a constant term to an otherwise simple multiplicative structure seems to allow much more complicated global behavior to emerge.")

#text("I was wondering whether there is a general framework in which an invertible high-dimensional polynomial map can realize or encode a discrete dynamical system such as the Collatz map, for example through invariant subsets, projections, or return maps.")

#text("More broadly, are there known results or theories concerning how algebraic dynamical systems can represent discrete dynamics?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693569")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("Does the simpler collision of (-2,1,2) and (0,1,-4) to (0,1,0) follow from your analysis?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693572")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("In the notation of this blog post, your collision corresponds to the factorization of the cubic ")#mi("zw (z+w/2)")#text(" into ")#mi("(-2z-w) \\times (-zw/2)")#text(" and ")#mi("w \\times (z^2+zw/2)")#text(". There is a third factorization ")#mi("2z \\times (zw/2+w^2/4)")#text(" that corresponds to a third preimage ")#mi("(2,-1/2,5/4)")#text(".")

#text("For comparison, the original collision reported corresponds to the factorization of the cubic ")#mi("w (z-w/2) (z+w/2)")#text(" into ")#mi("w \\times (z^2-w^2/4)")#text(", ")#mi("(z-w/2) \\times (zw + w^2/2)")#text(", and ")#mi("(-z-w/2) \\times (-zw+w^2/2)")#text(" respectively.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693606")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2026")])]

#text("The third preimage is (2,-1/2,5/4).")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693570")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("Thanks for the insight, Terry Tao")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693575")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("Hello everyone. For a while, I’ve had the idea that I would go for a masters and then a doctorate in computational physics. With all this progress of llms in math, I feel like it might be better to lean into something more engineering related and make some money quickly till someone is willing to pay me and not have llm do everything. Do you think academic path still has a future (even if you are not a super genius), or is it gonna be just clankers clanking and humans doing their best to understand?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693578")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("I have not seen any indication of what the prompting process that generated the original counterexample looked like. Do you have a sense of how much of the material you expose here the counterexample’s “announcer” might have known or suspected a priori? After reading your discussion with the AI related to this post, I’d be fascinated to see the discussion that led to the counterexample.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1823b8e7c007ea6f5618f31af95f1039711f4a49d00205fc9be7b9158cecb174-9f7d182710f9152ff8c20b5d799be3289bae0cc365c0c8b4c64cbcdf3996749b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of abdakhama")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693582")[#strong[#text("abdakhama")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("An AI says that with the choice F(x,y,z)=(x+y⋅P(q,z), y+Q(q,z), z+R(q,z))")

#text("where q=1+xy, and P, Q, and R are polynomials to be determined, simplifies the number of equations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693583")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("Lovely explanation. Is the fact that the variety is isomorphic to C^3 possibly less miraculous with an algebraic argument?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693586")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("Your higher-degree discussion suggests a precise comparison that may be useful. Consider the universal marked-root map")

#mi("\\displaystyle \\pi_N:\\mathbb P^1\\times\\mathbb P^{N-1}\\longrightarrow\\mathbb P^N,\\qquad ([\\ell],[Q])\\longmapsto[\\ell Q].")

#text("Let ")#mi("R_N")#text(" be its ramification divisor and, for a general target hyperplane ")#mi("H\\subset\\mathbb P^N")#text(", put")

#mi("\\displaystyle U_N=(\\mathbb P^1\\times\\mathbb P^{N-1})\\setminus\\big{\\left(R_N\\cup\\pi_N^{-1}(H)\\right)}.")

#text("Divisor localization gives")

#mi("\\displaystyle \\mathrm{Cl}(U_N)\\cong\\frac{\\mathbb ZA\\oplus\\mathbb ZB}{\\langle (N-1)A+B,\\ A+B\\rangle}\\cong\\mathbb Z/(N-2)\\mathbb Z.")

#text("Thus ")#mi("U_N")#text(" is affine but is not isomorphic to ")#mi("\\mathbb A^N")#text(" for ")#mi("N\\ge4")#text(". This makes precise one obstruction behind the deterioration of the naive higher-degree marked-root construction.")

#text("Separately, we derive the covering structure of an explicit family")

#mi("\\displaystyle F_m:\\mathbb A^3\\longrightarrow\\mathbb A^3,\\qquad \\det JF_m=\\delta_m\\ne0,")

#text("for which")

#mi("\\displaystyle [\\mathbb C(x,y,z):\\mathbb C(F_m)]=2m-1\\qquad(m\\ge2).")

#text("Hence the same affine three-space realizes every odd generic degree.")

#text("After passing to a primitive parameter and splitting the two critical points, the generic cover is affinely equivalent to")

#mi("\\displaystyle P_m(u)=\\frac{(2m-1)!}{((m-1)!)^2}\\int_0^u v^{m-1}(1-v)^{m-1}\\,dv.")#text(" Its passport is ")#mi("\\displaystyle (m,1^{m-1}),\\quad(m,1^{m-1}),\\quad(2m-1),")

#text("and its geometric monodromy is")

#mi("S_{2m-1}")#text(" for even ")#mi("m")#text(" and ")#mi("A_{2m-1}")#text(" for odd ")#mi("m")#text(".")

#text("The class-group obstruction shows that this fixed-")#mi("\\mathbb A^3")#text(" family is not simply the naive degree-")#mi("(2m-1)")#text(" marked-root construction.")

#text("—")

#text("The question I do not yet know how to answer is whether its beta cover arises as a nonlinear three-dimensional pullback of the higher marked-factor cover, or from a distinguished component of an appropriate restriction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693587")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2026")])]

#text("Your resultant-normalized factorization suggests an interpretation of a higher-dimensional family we constructed.")

#text("For a degree-n form P = LQ, with deg(L) = 1 and deg(Q) = n−1,")

#text("Res(λL, λ⁻¹Q) = λⁿ⁻² Res(L,Q).")

#text("Thus a generic P has n choices of marked linear factor and n−2 resultant-normalizing scalings, explaining the generic degree n(n−2).")

#text("Our explicit family realizes this for every n ≥ 3, with the original cubic as its n = 3 member:")

#link("https://x.com/hari65535/status/2079135211196121363")[#text("https://x.com/hari65535/status/2079135211196121363")]

#text("Does this seem like the correct invariant interpretation of the higher-dimensional construction?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693591")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2026")])]

#text("Alpöge’s Jacobian counterexample and Long’s SU(2) construction yield a 5-variable counterexample to the Generalized Vanishing Conjecture. Let P=(t+c)(ad+bt), Λ=∂ₜ(∂ₐ∂_d−∂_b∂꜀), Q=c. Then Λᵐ(Pᵐ)=0 for every m≥1, but Λᵐ(QPᵐ)= k_m * t ≠ 0, for m≥2. GVC(5) fails. — ")#link("https://x.com/mth757t/status/2080177784756842977")[#text("https://x.com/mth757t/status/2080177784756842977")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693594")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2026")])]

#text("Daniel Litt was right, this conjecture is low hanging fruit in hindsight.")

#text("On the other hand the case for N = 2 doesn’t seem to be so easy to disprove, because it isn’t the case (that I know off) that polynomial multiplication of two linear forms to get a quadratic form is non-injective, once you factor out the scaling symmetry. So this proof route isn’t available for N = 2.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693664")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2026")])]

#text("I was looking at the case n = 2 as well and was trying to understand where Terry’s ansatz fails for n = 2.")

#text("When we take the multiplication of two linear functions, I see both violations to injectivity described above: scaling and that F(L_1,L_2)=F(L_2,L_1)")

#text("Can you help me understand how these can be factored out? Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693669")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2026")])]

#text("The resultant is now invariant under the scaling ")#mi("(L_1, L_2) \\mapsto (\\lambda L_1, \\lambda^{-1} L_2)")#text(", so one cannot normalize the resultant to equal 1 any more. As such the construction seems to naturally give a punctured plane as the domain rather than the full affine plane, becoming the Vitushkin example ")#mi("(x, y) \\mapsto (x+y, xy)")#text(" on ")#mi("\\{ (x,y): x \\neq y \\}")#text(" as discussed previously if we normalize the polynomials to be monic instead. There doesn’t seem to be any simple way to get rid of this puncture, other than by making the map rational instead of polynomial.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693670")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2026")])]

#text("Polynomial multiplication of two linear maps is two-to-one, unless the two linear maps are the same. So that’s not the reason why this vector of attack doesn’t work in two dimensions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb616d669d68a830b80590ab307dbe80f37956fae86fd8f48c2144669f7bb0c5-d9dced081d8b167966c2163505f2728b9b09c8a4107662d859a12c189ecc6e57.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vitor Freitas")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693600")[#strong[#text("Vitor Freitas")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2026")])]

#text("Found this with Opus 4.8:")

#text("Let u=1+xy,W=u²z+3y²u+y²,F=(a,b,c)=(uW,y+3xW,x(2−3xy−x²z)). Set P(Y)=2Y³−3bY²+18aY+b³−18ab+27a²c. Then P(Y)=2(Y−y)(Y²−(3b/2−y)Y+9a−y(3b/2−y)). With D=3a+Y²−bY, any root with aD≠0 inverts via x=(b−Y)/D,u=3a/D,W=D/3; z follows. Generic 3:1; det JF=−2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693605")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2026")])]

#text("You shared the Chatbot conversation. Could you disclose which plan you use, which model, and at what “intelligence” level?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693621")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2026")])]

#text("Most of the discussion was using GPT 5.6 Sol in “Instant” mode (to prioritize interactivity), except for one turn in the conversation in which I switched to “Pro” mode instead.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693607")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2026")])]

#text("The Wikipedia article on the Jacobian conjecture says “By the contrapositive of these reductions, the existence of the 2026 counterexample implies the existence of counterexamples of cubic homogeneous type, and indeed of cubic linear type, in sufficiently high dimension.”")

#text("Has anybody constructed a polynomial from C^N to C^N for some N which is of cubic homogeneous type and a counterexample to the Jacobian conjecture? Existence proofs aren’t that satisfying to me compared to constructive proofs.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693634")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2026")])]

#text("This reduction theorem to degree 3 from Bass, Connell, and Wright might be useful to you:")

#link("https://pubs.ams.org/journals/bull/1982-07-02/S0273-0979-1982-15032-7")[#text("https://pubs.ams.org/journals/bull/1982-07-02/S0273-0979-1982-15032-7")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693609")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2026")])]

#text("Nice job. I also verified the work. And in the process likely solved the similar 3D level on Poisson and Dixmier. Take a Look. ")#link("https://x.com/MagnetGP/status/2080370383534883272?s=20")[#text("https://x.com/MagnetGP/status/2080370383534883272?s=20")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693611")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2026")])]

#text("If we choose (Keller’s map)")

#text("F(x,y,z)=(x+y⋅P(xy,z), y+Q(xy,z), z+R(xy,z))")

#text("Where q=1+xy, and P, Q, and R are polynomials to be determined, simplifies the number of equations. For degree 3, the number of equations is 30 to determine P, Q, and R. Once that done, setting the Jacobian to a constant c, a search for c and consequently at least two points (x,y,z) such that the non-injectivity is met.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693612")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2026")])]

#text("I have used an AI agent to create a ")#link("https://teorth.github.io/tao-web/apps/jacobian.html")[#text("visualizer of the counterexample map")]#text(" constructed in the blog, using both ")#mi("(a,y,z)")#text(" and ")#mi("(a,b,c)")#text(" coordinates for the domain and the ")#mi("F(L,Q)=LQ")#text(" coefficients for the range. Note: due to the ongoing ICM I have only been able to very briefly playtest the applet, so there may be some room for improvements to the GUI. As always, any suggestions for such improvements would be greatly appreciated!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693613")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2026")])]

#text("Alejandro Radisic wrote on Mathstodon:")

#text("“Formalized in Lean4:")

#text("The map F : K³ → K³ has constant Jacobian −2 yet identifies three points. This is no accident of algebra: F is, definitionally, the proof is rfl, the map “binary cubic with a marked simple root ↦ forget the marking”, for the family cT³ − 2T²U + bTU² − 2aU³.")

#text("So every fiber is the set of simple roots of one cubic. The Keller condition says the root you stand on is simple, a local fact. It cannot control how many simple roots the cubic has: 3 off the discriminant hypersurface, 1 on it, 0 on its singular curve (the triple roots), which is exactly the locus the image misses. All machine-checked now, including disc = −4W and “missed curve = singular locus of the discriminant”.")

#text("My favorite part is arithmetic: over any field of char ≠ 2, a fiber can never have exactly two rational points, two roots force a third. Vieta, made constructive.")

#text("The Jacobian Conjecture failed because pointwise simplicity of roots doesn’t count roots.”")

#link("https://mathstodon.xyz/@alerad/116958673277338837")[#text("https://mathstodon.xyz/@alerad/116958673277338837")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693628")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2026")])]

#text("Similar visualisations (plus an elementary discussion) by A. Gallagher can be found at ")#link("https://jacobianfun.org/jacobian-explained")[#text("https://jacobianfun.org/jacobian-explained")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693614")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2026")])]

#text("Nice exposition! Just a few minor comments.")

#text("line 1 after (5): factoring -> factorization.")

#text("line 10 after (5): Perhaps change h to -h as we have ")#mi("\\alpha \\mapsto \\alpha-h")#text(" and similarly for the ")#mi("\\beta_i")#text(".")

#text("line 11 after (5): ")#mi("(z,w)\\mapsto (w,z)")#text(" doesn’t belong to ")#mi("\\text{SL}_2")#text(". One should look at ")#mi("(z,w)\\mapsto (w,-z)")#text(" which changes ")#mi("a,c")#text(" to ")#mi("a\\alpha,c\\beta_1\\beta_2")#text(" and ")#mi("\\alpha,\\beta_1,\\beta_2")#text(" to ")#mi("-1/\\alpha,-1/\\beta_1,-1/\\beta_2")#text(".")

#text("line 1 after (9): “The latter” should perhaps be changed to “")#mi("V")#text("“.")

#text("-Kasper Andersen")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02784ab6f273ddcb40e58debf4f654814cf54c21311812074559f1c60808f99c-c06d1829ef099646847554d51707b4ac82dd0074084c8c5df474ea735cd4b7f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693620")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2026")])]

#text("I wonder if the construction could be used to prove that the Koras-Russell cubic is stably isomorphic to an affine space.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693630")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2026")])]

#text("”This already gives (a) and thus completes the proof of Theorem 3.“")

#text("“This already gives (c)” seems to be correct")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693631")[#strong[#text("Various News Items | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2026")]

#text("[…] significant items: The Jacobian conjecture has been disproved (Claude; see this enlightening blog post by Terry Tao); the double cover conjecture has been proved […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693641")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2026")])]

#text("Wasn’t the more interesting case of the Jacobian conjecture to most mathematicians the two variable case? So many mathematicians tried to prove the two variable case but failed. So the AI didn’t really resolve anything in that regards.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693646")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2026")])]

#text("Somewhat confusingly, both the two-dimensional problem and the general-dimensional problem have been referred to in the literature as the “Jacobian conjecture”, and both are of interest; the latter is now resolved in the negative, but the former remains open. I think the current state of the Wikipedia page at ")#link("https://en.wikipedia.org/wiki/Jacobian_conjecture")[#text("https://en.wikipedia.org/wiki/Jacobian_conjecture")]#text(" is making a good effort to disambiguate the two.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693661")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2026")])]

#text("I think going forwards, major progress on the two dimensional Jacobian conjecture will likely come from trying to understand how Keller maps behave similarly and differently between two and three dimensions.")

#text("Right now, the only progress that has been made is eliminating counterexamples to the two dimensional Jacobian conjecture for Keller maps of degree up to 107.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693672")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2026")])]

#text("If you believe the Jacobian conjecture in two dimensions is likely to be false, then your best bet is to continue looking for counterexamples. You’ve only got rid of 100 or so degrees; there are still infinitely many degrees left to check before you’ve exhausted all the possible polynomial degrees for counterexamples.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693647")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2026")])]

#link("https://chatgpt.com/share/6a6162cd-1458-83e8-97cb-27a17121cd5b")[#text("ChatGPT is on to you")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693648")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2026")])]

#text("This is way above my math knowledge, but I would like to understand how helpful talking to ChatGPT actually was. It seems that its output was mostly correct and rather helpful. But was it actually? Were there like complete incorrect statements produced? Where there statements seemingly correct but incorrect on closer inspection (the worst kind of errors / falsehood introduced by LLMs)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693660")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2026")])]

#text("I certainly did not check the LLM output line-by-line, and many of the speculations produced by either myself or the AI turned out to be dead ends (or at least not pursued to the point where some productive insight was realized). But this is actually very typical of the early stages of understanding a mathematical problem, in which the goal is not necessarily to collect 100% correct assertions about the problem, but to brainstorm some approximately correct initial conceptual frameworks, to be refined as the discussion progresses. Counterintuitively, making “mistakes” early on in this process can actually accelerate the convergence of these frameworks to a correct final understanding, even if they initially lead to conceptual models that are technically incorrect in one aspect or another, because the error itself can be highly instructive once located. At such exploratory stages of a problem solving process, the objective is not necessarily to avoid error completely, but to be able to creatively generate somewhat accurate ideas, and then try to zero in on any flaws in such ideas to modify them to come up with a better version of that idea, iterating as needed to converge to a working proof strategy.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0b423fadc513ac0411dd0514ea026a2d16a4135f02398c6cf3e216875f731e7-f10415d608fb7f54446cf1edbfc12d995d6764cec76d613dd19362a166d378a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Justin Bian")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693665")[#strong[#text("Justin Bian")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2026")])]

#text("Thank you Professor Tao!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02784ab6f273ddcb40e58debf4f654814cf54c21311812074559f1c60808f99c-c06d1829ef099646847554d51707b4ac82dd0074084c8c5df474ea735cd4b7f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wlodek")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693653")[#strong[#text("Wlodek")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2026")])]

#text("Note that the hypersurface ")#mi("a^{2}e - abd + b^{2}c = 1")#text(" is isomorphic to ")#mi("\\mathrm{SL}_2 \\times \\mathbb{A}^{1}")#text(". This can be seen using locally nilpotent derivation ")#mi("D = a^{2}\\partial_{c} + 2ab\\partial_{d} + b^{2}\\partial_{e}")#text(" and its global slice ")#mi("s = ce - d^{2}/4, D(s)=1")#text(". The ring of additive group invariants is generated by ")#mi("a, b, u = ae - bd/2, v = ad/2 - bc")#text(", with ")#mi("au - bv = 1")#text(", and using Taylor expansion we have ")#mi("c = v^2 + a^{2}s, d = 2(uv + abs), e = u^2 + b^{2}s")#text(".")

#text("One may also work with two commuting locally nilpotent derivations ")#mi("X = b\\partial_e + a\\partial_d")#text(" and ")#mi("Y = b\\partial_d + a\\partial_c")#text(" and its corresponding slices ")#mi("s = ade - bd^2 + bce = (ad + bc)e - bd^2")#text(" (")#mi("ad + bc")#text(" appears here) and ")#mi("t = ace - ad^2 + bcd")#text(". Note that the quotient of the corresponding ")#mi("\\mathbb{G}_a^2")#text("-action is a punctured plane. See also ")#link("https://arxiv.org/abs/1106.2900")[#text("https://arxiv.org/abs/1106.2900")]#text(" .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693656")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2026")])]

#text("Here is a simple way to demonstrate that three images belong to a")#linebreak()#text("preimage: In the equations F(x,y,z) – (a,b,c) = (0,0,0) replace z by –")#linebreak()#text("(3*x^2*y – 2*x + c)/x^3 obtained from the third equation, and then")#linebreak()#text("replace y by (x*(12*a – b^2) – 9*a*c + 2*b)/(x*(9*a*c – b) + 2); the")#linebreak()#text("equations now contain the cubic factor x^3*(27*a^2*c^2 + 2*a*(8 – 9*b*c)")#linebreak()#text("+ b^2*(b*c – 1)) + x*(4 – 3*b*c) – 2*c, and to every cubic root x")#linebreak()#text("belongs one y and one z. Alternatively, with z replaced as above, on")#linebreak()#text("replacing x by – (2*y + 9*a*c – 2*b)/(y*(9*a*c – b) – 12*a + b^2), the")#linebreak()#text("equations are found to contain the cubic factor 2*y^3 – 3*b*y^2 + 18*a*y")#linebreak()#text("+ 27*a^2*c – 18*a*b + b^3, and to every cubic root y belongs one x and")#linebreak()#text("one z.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693671")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2026")])]

#text("Jacobian conjecture is only interesting because of the numerous drama in the mathematics community that has occurred over the years around the Jacobian conjecture, between the Moh vs Zhang drama and all the false proofs of the conjecture that get published by well established mathematicians and then shown to contain a gap in them. The drama is going to continue because Fable failed to disprove the two dimensional conjecture.")

#text("If you strip away the drama the Jacobian conjecture becomes yet another minor and somewhat irrelevant conjecture, just like most other conjectures in mathematics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693674")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2026")])]

#text("The Jacobian conjectue is related to a whole bunch of other conjectures ranging from algebra to probability theory. The fact that it fails thus changes a lot of things in mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693677")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2026")])]

#text("How similar was your interaction with the LLM to a sequence of questions/suggestions you might have with a student you were supervising? If it is similar, how would the capability of the LLM compare to such students?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693678")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2026")])]

#text("This type of interaction is largely orthogonal with an interaction I might have with a student. Here, the primary objective was to understand a construction provided by a third party. With a student, one might direct that student to read some paper by another author, but the primary objective in our meetings would be to refine the student’s skill at reading challenging papers, rather than trying to understand the paper itself.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693679")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2026")])]

#text("how would you recommend getting better at reading challenging papers?")

#text("for reference, I am a first year masters student trying to read a paper that introduces a bunch of terminology that I haven’t been able to find in other papers/books or really anywhere else online in order to prove some lemmas and eventually a theorem (whose statement is very easy to understand). I am not sure if this is standard as this is the first paper I’m reading seriously")

#text("is it worth it at this stage to rely on chatgpt for understanding, or should I just “raw dog” it? I was planning to just use gpt, because the techniques in the paper will probably prove useful for my research and I don’t want to waste time, but this comment is giving me second thoughts")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/21/a-digestion-of-the-jacobian-conjecture-counterexample/comment-page-1/#comment-693680")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2026")])]

#text("I have some advice on both reading and writing papers at ")#link("https://terrytao.wordpress.com/advice-on-writing-papers/")[#text("https://terrytao.wordpress.com/advice-on-writing-papers/")]#text(" .")

#text("If you do not feel confident in your ability to read papers at this level without AI assistance, then I would advise against relying entirely on AI for these tasks, as this will not give you the opportunity to develop such skills, which will also indirectly help build other mathematical skills that you will need in the future. However, it is relatively safe to use these AI tools to search for additional literature resources for you to read that may be helpful to you, or to perform extremely specific tasks such as stating the definition of an unfamiliar term (as opposed to asking for a summary of the entire paper you are reading) – in short, to use it as an accelerated version of a search engine. One further mode that I find particularly helpful (and relatively safe to use) for developing paper comprehension skills is to first give the AI your own understanding of a particular portion of the paper you are reading and ask it to review whether your understanding was correct or not.")

#text("My ")#link("https://teorth.github.io/tao-web/ai-views.html")[#text("page on views on AI")]#text(" also contains some relevant advice on these topics.")
]
]
]
]
