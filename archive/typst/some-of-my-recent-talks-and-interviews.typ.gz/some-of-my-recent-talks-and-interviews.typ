// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/17/some-of-my-recent-talks-and-interviews/
// Converted to Typst by tao2typ: "2026-10-18T11:27:43.421255+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Some of my recent talks and interviews", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Some of my recent talks and interviews")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/17/some-of-my-recent-talks-and-interviews/")[#text("https://terrytao.wordpress.com/2026/10/17/some-of-my-recent-talks-and-interviews/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-18 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("As readers of this blog have no doubt noticed, I have recently turned over the majority of content on this blog to guest posts from other authors, either within the mathematics community or adjacent to it. In this post I record some content coming from my own talks and interviews in this time period.")

#list(
[#text("“")#link("https://www.youtube.com/watch?v=OOMx2BHHWtE")[#text("The world’s greatest mathematician explains 6 essential concepts of math")]#text("“, an interview for Big Think, August 28, 2026.")],
[#text("“")#link("https://www.youtube.com/watch?v=Boo72U-9u3c")[#text("The integrated explicit analytic number theory network")]#text("“, a talk I gave at an ")#link("https://www.ipam.ucla.edu/programs/workshops/pdes-verification-mathematics-and-algorithms-in-the-age-of-ai/")[#text("IPAM workshop on PDEs: Verification, Mathematics, and Algorithms in the Age of AI")]#text(", on Sep 17. Slides available ")#link("https://teorth.github.io/tao-web/slides/ieantn-ipam-2026.pdf")[#text("here")]#text(".")],
[#text("“")#link("https://newsroom.ucla.edu/magazine/terence-tao-math-artificial-intelligence-alpha-research")[#text("The Tao of Tao")]#text("“. An interview with Stuart Wolpert for UCLA that I gave on Oct 6.")],
[#text("I made a contribution to “")#link("https://proofsandprompts.com/2026/10/08/100-reactions-to-100-solutions/")[#text("100+ reactions to 100+ solutions")]#text("” at Proofs and Prompts on Oct 8.")],
[#text("“")#link("https://aimath.org/videos/terry-tao-pl/")[#text("Math 2.0")]#text("“. This is the video of a public lecture I gave in Caltech on Oct 9. As announced in ")#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/")[#text("this previous post")]#text(", the slides are available ")#link("https://teorth.github.io/tao-web/slides/math-2-0-caltech-2026.pdf")[#text("here")]#text(". (Note that the latest version of the slides are slightly different from the one used at that talk.)")],
[#text("“")#link("https://www.youtube.com/watch?v=bAnwMdfcMVw")[#text("No More Heroes: Terence Tao Talks to Numberphile About AI")]#text("“. An interview with Brady Haran for Numberphile on Oct 15.")],
[#text("“")#link("https://www.nytimes.com/2026/10/16/us/math-ai-terence-tao.html")[#text("I’m on a War Footing’: Terry Tao and the Crisis in Math")]#text("“, An interview with Elisabeth Bumiller for The New York Times, on Oct 16.")]
)

#text("A more complete (AI-maintained) list of my talks, interviews, and other commentary on social media can be found at ")#link("https://teorth.github.io/tao-web/mastodon-posts.html")[#text("this page")]#text(".")

#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a24b6a74da9af0cf5f8041f44f495c07465b8ad27f0b2bbf68d944b31b134a3-79059f37e1715d4e32d3309e2225e87c658c87359e0b45d68f19a7dbdb258020.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dimi")]], [#link("https://terrytao.wordpress.com/2026/10/17/some-of-my-recent-talks-and-interviews/comment-page-1/#comment-698273")[#strong[#text("Dimi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2026")])]

#text("A question that is asked less than what I think it deserves is whether these math LLMs will keep getting better once the 99.9% of the arxiv’s of the world get filled with their output. Right now, the LLMs can extrapolate from the public record of 2’500 years of humans doing axiomatic mathematics. Once they are instead getting trained on basically their output, there are serious concerns about model collapses.")

#text("On the other hand, this is not supervised ML that the math LLMs are trained with, but rather reinforcement learning, which makes the model collapse arguments much weaker.")

#text("Another aspect is that the humans are still needed to pose the problems (not only at inference time: also during training), which is basically a judgement of what kind of mathematical problem is worth pursuing. If that “worth pursuing” gets codified, then these LLMs might really not need us anymore: they ‘ll be able to roam in the infinite universe of mathematical statements and come back to us with anything interesting they find. Both exciting and scary.")

#text("We ‘ll know in a few years I guess. Things move so fast.")
]
