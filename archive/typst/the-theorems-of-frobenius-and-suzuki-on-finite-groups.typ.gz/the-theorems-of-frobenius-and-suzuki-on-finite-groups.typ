// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/
// Converted to Typst by tao2typ: "2026-10-14T15:18:35.488645+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The theorems of Frobenius and Suzuki on finite groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The theorems of Frobenius and Suzuki on finite groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 April 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/")[#text("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://en.wikipedia.org/wiki/Classification_of_finite_simple_groups")[#text("classification of finite simple groups")]#text(" (CFSG), first announced in 1983 but only fully completed in 2004, is one of the monumental achievements of twentieth century mathematics. Spanning hundreds of papers and tens of thousands of pages, it has been called the “enormous theorem”. A “second generation” proof of the theorem is nearly completed which is a little shorter (estimated at about five thousand pages in length), but currently there is no reasonably sized proof of the classification.")

#text("An important precursor of the CFSG is the ")#link("http://en.wikipedia.org/wiki/Odd_order_theorem")[#text("Feit-Thompson theorem")]#text(" from 1962-1963, which asserts that every finite group of odd order is solvable, or equivalently that every non-abelian finite simple group has even order. This is an immediate consequence of CFSG, and conversely the Feit-Thompson theorem is an essential starting point in the proof of the classification, since it allows one to reduce matters to groups of even order for which key additional tools (such as the ")#link("http://en.wikipedia.org/wiki/Brauer%E2%80%93Fowler_theorem")[#text("Brauer-Fowler theorem")]#text(") become available. The original proof of the Feit-Thompson theorem is 255 pages long, which is significantly shorter than the proof of the CFSG, but still far from short. While parts of the proof of the Feit-Thompson theorem have been simplified (and it has ")#link("http://research.microsoft.com/en-us/news/features/gonthierproof-101112.aspx")[#text("recently been converted")]#text(", after six years of effort, into an argument that has been verified by the proof assistant ")#link("http://en.wikipedia.org/wiki/Coq")[#text("Coq")]#text("), the available proofs of this theorem are still extremely lengthy by any reasonable standard.")

#text("However, there is a significantly simpler special case of the Feit-Thompson theorem that was established previously ")#link("http://www.ams.org/mathscinet-getitem?mr=0086818")[#text("by Suzuki")]#text(" in 1957, which was influential in the proof of the more general Feit-Thompson theorem (and thus indirectly to the proof of CFSG). Define a ")#link("http://en.wikipedia.org/wiki/CA-group")[#text("CA-group")]#text(" to be a group ")#mi("{G}")#text(" with the property that the ")#link("http://en.wikipedia.org/wiki/Centralizer_and_normalizer")[#text("centraliser")]#text(" ")#mi("{C_G(x) := \\{ g \\in G: gx=xg \\}}")#text(" of any non-identity element ")#mi("{x \\in G}")#text(" is abelian; equivalently, the ")#emph[#text("commuting relation")]#text(" ")#mi("{x \\sim y}")#text(" (defined as the relation that holds when ")#mi("{x}")#text(" commutes with ")#mi("{y}")#text(", thus ")#mi("{xy=yx}")#text(") is an equivalence relation on the non-identity elements ")#mi("{G \\backslash \\{1\\}}")#text(" of ")#mi("{G}")#text(". Trivially, every abelian group is CA. A non-abelian example of a CA-group is the ")#mi("{ax+b}")#text(" group of invertible affine transformations ")#mi("{x \\mapsto ax+b}")#text(" on a field ")#mi("{F}")#text(". A little less obviously, the special linear group ")#mi("{SL_2(F_q)}")#text(" over a finite field ")#mi("{F_q}")#text(" is a CA-group when ")#mi("{q}")#text(" is a power of two. The finite simple groups of Lie type are not, in general, CA-groups, but when the rank is bounded they tend to behave as if they were “almost CA”; the centraliser of a generic element in ")#mi("{SL_d(F_q)}")#text(", for instance, when ")#mi("{d}")#text(" is bounded and ")#mi("{q}")#text(" is large), is typically a maximal torus (because most elements in ")#mi("{SL_d(F_q)}")#text(" are regular semisimple) which is certainly abelian. In view of the CFSG, we thus see that CA or nearly CA groups form an important subclass of the simple groups, and it is thus of interest to study them separately. To this end, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Suzuki’s theorem on CA-groups)")]#text(" ")#metadata(none) <tao-8517fadd3bce34a35911>#text(" Every finite CA-group of odd order is solvable.")
]

#text("Of course, this theorem is superceded by the more general Feit-Thompson theorem, but Suzuki’s proof is substantially shorter (the original proof is nine pages) and will be given in this post. (See ")#link("http://www.ams.org/mathscinet-getitem?mr=1824893")[#text("this survey of Solomon")]#text(" for some discussion of the link between Suzuki’s argument and the Feit-Thompson argument.) Suzuki’s analysis can be pushed further to give an essentially complete classification of all the finite CA-groups (of either odd or even order), but we will not pursue these matters here.")

#text("Moving even further down the ladder of simple precursors of CSFG is the following theorem of Frobenius from 1901. Define a ")#link("http://en.wikipedia.org/wiki/Frobenius_group")[#text("Frobenius group")]#text(" to be a finite group ")#mi("{G}")#text(" which has a subgroup ")#mi("{H}")#text(" (called the ")#emph[#text("Frobenius complement")]#text(") with the property that all the non-trivial conjugates ")#mi("{gHg^{-1}}")#text(" of ")#mi("{H}")#text(" for ")#mi("{g \\in G \\backslash H}")#text(", intersect ")#mi("{H}")#text(" only at the origin. For instance the ")#mi("{ax+b}")#text(" group is also a Frobenius group (take ")#mi("{H}")#text(" to be the affine transformations that fix a specified point ")#mi("{x_0 \\in F}")#text(", e.g. the origin). This example suggests that there is some overlap between the notions of a Frobenius group and a CA group. Indeed, note that if ")#mi("{G}")#text(" is a CA-group and ")#mi("{H}")#text(" is a maximal abelian subgroup of ")#mi("{G}")#text(", then any conjugate ")#mi("{gHg^{-1}}")#text(" of ")#mi("{H}")#text(" that is not identical to ")#mi("{H}")#text(" will intersect ")#mi("{H}")#text(" only at the origin (because ")#mi("{H}")#text(" and each of its conjugates consist of equivalence classes under the commuting relation ")#mi("{\\sim}")#text(", together with the identity). So if a maximal abelian subgroup ")#mi("{H}")#text(" of a CA-group is its own ")#link("http://en.wikipedia.org/wiki/Centralizer_and_normalizer")[#text("normaliser")]#text(" (thus ")#mi("{N(H) := \\{ g \\in G: gH=Hg\\}}")#text(" is equal to ")#mi("{H}")#text("), then the group is a Frobenius group.")

#text("Frobenius’ theorem places an unexpectedly strong amount of structure on a Frobenius group:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Frobenius’ theorem)")]#text(" ")#metadata(none) <tao-82a9a499531a2e813f59>#text(" Let ")#mi("{G}")#text(" be a Frobenius group with Frobenius complement ")#mi("{H}")#text(". Then there exists a normal subgroup ")#mi("{K}")#text(" of ")#mi("{G}")#text(" (called the ")#emph[#text("Frobenius kernel")]#text(" of ")#mi("{G}")#text(") such that ")#mi("{G}")#text(" is the semi-direct product ")#mi("{H \\ltimes K}")#text(" of ")#mi("{H}")#text(" and ")#mi("{K}")#text(".")
]

#text("Roughly speaking, this theorem indicates that all Frobenius groups “behave” like the ")#mi("{ax+b}")#text(" example (which is a quintessential example of a semi-direct product).")

#text("Note that if every CA-group of odd order was either Frobenius or abelian, then Theorem ")#link(<tao-82a9a499531a2e813f59>)[#text("2")]#text(" would imply Theorem ")#link(<tao-8517fadd3bce34a35911>)[#text("1")]#text(" by an induction on the order of ")#mi("{G}")#text(", since any subgroup of a CA-group is clearly again a CA-group. Indeed, the proof of Suzuki’s theorem does basically proceed by this route (Suzuki’s arguments do indeed imply that CA-groups of odd order are Frobenius or abelian, although we will not quite establish that fact here).")

#text("Frobenius’ theorem can be reformulated in the following concrete combinatorial form:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Frobenius’ theorem, equivalent version)")]#text(" ")#metadata(none) <tao-0ad575af8f2ae562fbcd>#text(" Let ")#mi("{G}")#text(" be a group of permutations acting transitively on a finite set ")#mi("{X}")#text(", with the property that any non-identity permutation in ")#mi("{G}")#text(" fixes at most one point in ")#mi("{X}")#text(". Then the set of permutations in ")#mi("{G}")#text(" that fix no points in ")#mi("{X}")#text(", together with the identity, is closed under composition.")
]

#text("Again, a good example to keep in mind for this theorem is when ")#mi("{G}")#text(" is the group of affine permutations on a field ")#mi("{F}")#text(" (i.e. the ")#mi("{ax+b}")#text(" group for that field), and ")#mi("{X}")#text(" is the set of points on that field. In that case, the set of permutations in ")#mi("{G}")#text(" that do not fix any points are the non-trivial translations.")

#text("To deduce Theorem ")#link(<tao-0ad575af8f2ae562fbcd>)[#text("3")]#text(" from Theorem ")#link(<tao-82a9a499531a2e813f59>)[#text("2")]#text(", one applies Theorem ")#link(<tao-82a9a499531a2e813f59>)[#text("2")]#text(" to the stabiliser of a single point in ")#mi("{X}")#text(". Conversely, to deduce Theorem ")#link(<tao-82a9a499531a2e813f59>)[#text("2")]#text(" from Theorem ")#link(<tao-0ad575af8f2ae562fbcd>)[#text("3")]#text(", set ")#mi("{X := G/H = \\{ gH: g \\in G \\}}")#text(" to be the space of left-cosets of ")#mi("{H}")#text(", with the obvious left ")#mi("{G}")#text("-action; one easily verifies that this action is faithful, transitive, and each non-identity element ")#mi("{g}")#text(" of ")#mi("{G}")#text(" fixes at most one left-coset of ")#mi("{H}")#text(" (basically because it lies in at most one conjugate of ")#mi("{H}")#text("). If we let ")#mi("{K}")#text(" be the elements of ")#mi("{G}")#text(" that do not fix any point in ")#mi("{X}")#text(", plus the identity, then by Theorem ")#link(<tao-0ad575af8f2ae562fbcd>)[#text("3")]#text(" ")#mi("{K}")#text(" is closed under composition; it is also clearly closed under inverse and conjugation, and is hence a normal subgroup of ")#mi("{G}")#text(". From construction ")#mi("{K}")#text(" is the identity plus the complement of all the ")#tao-math("{\\left|G\\right|/\\left|H\\right|}", block: false)#text(" conjugates of ")#mi("{H}")#text(", which are all disjoint except at the identity, so by counting elements we see that")

#align(center)[#tao-fit-display[#tao-math("\\left|K\\right| = \\left|G\\right| - \\frac{\\left|G\\right|}{\\left|H\\right|}(\\left|H\\right|-1) = \\left|G\\right|/\\left|H\\right|.", block: true)]]

#text("As ")#mi("{H}")#text(" normalises ")#mi("{K}")#text(" and is disjoint from ")#mi("{K}")#text(", we thus see that ")#mi("{KH = H \\ltimes K}")#text(" is all of ")#mi("{G}")#text(", giving Theorem ")#link(<tao-82a9a499531a2e813f59>)[#text("2")]#text(".")

#text("Despite the appealingly concrete and elementary form of Theorem ")#link(<tao-0ad575af8f2ae562fbcd>)[#text("3")]#text(", the only known proofs of that theorem (or equivalently, Theorem ")#link(<tao-82a9a499531a2e813f59>)[#text("2")]#text(") in its full generality proceed via the machinery of ")#link("http://en.wikipedia.org/wiki/Character_(mathematics)")[#text("group characters")]#text(" (which one can think of as a version of Fourier analysis for nonabelian groups). On the other hand, once one establishes the basic theory of these characters (reviewed below the fold), the proof of Frobenius’ theorem is very short, which gives quite a striking example of the power of character theory. The proof of Suzuki’s theorem also proceeds via character theory, and is basically a more involved version of the Frobenius argument; again, no character-free proof of Suzuki’s theorem is currently known. (The proofs of Feit-Thompson and CFSG also involve characters, but those proofs also contain many other arguments of much greater complexity than the character-based portions of the proof.)")

#text("It seems to me that the above four theorems (Frobenius, Suzuki, Feit-Thompson, and CFSG) provide a ladder of sorts (with exponentially increasing complexity at each step) to the full classification, and that any new approach to the classification might first begin by revisiting the earlier theorems on this ladder and finding new proofs of these results first (in particular, if one had a “robust” proof of Suzuki’s theorem that also gave non-trivial control on “almost CA-groups” – whatever that means – then this might lead to a new route to classifying the finite simple groups of Lie type and bounded rank). But even for the simplest two results on this ladder – Frobenius and Suzuki – it seems remarkably difficult to find any proof that is not essentially the character-based proof. (Even trying to replace character theory by its close cousin, representation theory, doesn’t seem to work unless one gives in to the temptation to take traces everywhere and put the characters back in; it seems that rather than abandon characters altogether, one needs to find some sort of “robust” generalisation of existing character-based methods.) In any case, I am recording here the standard character-based proofs of the theorems of Frobenius and Suzuki below the fold. There is nothing particularly novel here, but I wanted to collect all the relevant material in one place, largely for my own benefit.")

#metadata(none) <tao-4811732c12ad1adda1cb>

#heading(level: 1)[#strong[#text(" — 1. Basic character theory — ")]]

#metadata(none) <tao-60e74ce4f5e27dd8485c>

#text("Let ")#mi("{G}")#text(" be a finite group. Then we can form the finite-dimensional complex Hilbert space ")#mi("{L^2(G)}")#text(" of functions ")#mi("{f:G \\rightarrow {\\bf C}}")#text(" with the inner product")

#align(center)[#tao-fit-display[#mitex("\\langle f_1, f_2 \\rangle_{L^2(G)} = \\mathop{\\bf E}_{x \\in G} f_1(x) \\overline{f_2(x)}")]]

#text("and thus norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^2(G)} = (\\mathop{\\bf E}_{x \\in G} \\left|f(x)\\right|^2)^{1/2}", block: true)]]

#text("where ")#tao-math("{\\mathop{\\bf E}_{x \\in G} f(x) := \\frac{1}{\\left|G\\right|} \\sum_{x \\in G} f(x)}", block: false)#text(" is the averaging operator. Inside this space, we have the subspace ")#mi("{L^2(G)^G}")#text(" of ")#link("http://en.wikipedia.org/wiki/Class_function")[#text("class functions")]#text(": functions ")#mi("{f \\in L^2(G)}")#text(" which are invariant under the conjugation action of ")#mi("{G}")#text(" on itself, thus")

#align(center)[#tao-fit-display[#mitex("f(gxg^{-1}) = f(x)")]]

#text("for all ")#mi("{x, g \\in G}")#text(". Equivalently, ")#mi("{f}")#text(" is constant on each conjugacy class of ")#mi("{G}")#text(". In particular, we see that the dimension of ")#mi("{L^2(G)^G}")#text(" is equal to the ")#link("http://en.wikipedia.org/wiki/Class_number_(group_theory)")[#text("class number")]#text(" of ")#mi("{G}")#text(" – the number of conjugacy classes of ")#mi("{G}")#text(".")

#text("One way to generate class functions is from taking traces of finite-dimensional unitary representations ")#mi("{\\rho: G \\rightarrow U(V)}")#text(", i.e. a homomorphism from the group ")#mi("{G}")#text(" to unitary operators on a finite-dimensional complex Hilbert space ")#mi("{V}")#text(". We will abbreviate “finite-dimensional unitary representation” as “representation” henceforth. Given any such representation, one has an associated character ")#mi("{\\chi_\\rho \\in L^2(G)^G}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("\\chi_\\rho(g) := \\text{tr}_V( \\rho(g) ).")]]

#text("One easily verifies that this is a class function. For instance, the ")#emph[#text("regular representation")]#text(" ")#mi("{\\tau: G \\rightarrow U(L^2(G))}")#text(", in which ")#mi("{\\tau(g) f(x) := f(g^{-1} x)}")#text(", has character")

#align(center)[#tao-fit-display[#tao-math("\\chi_\\tau(g) = \\left|G\\right| 1_{g = 1_G}", block: true)]]

#text("and every linear character ")#mi("{\\chi: G \\rightarrow S^1 = U({\\bf C})}")#text(" (i.e. a homomorphism to the complex unit circle) is a character associated the obvious one-dimensional representation corresponding to ")#mi("{\\chi}")#text(". In particular, the constant function ")#mi("{1}")#text(" is a character, associated to the principal one-dimensional representation.")

#text("The characters interact well with various representation-theoretic operations. For instance, isomorphic representations clearly have the same character. If ")#mi("{\\rho_1: G \\rightarrow U(V_1), \\rho_2: G \\rightarrow U(V_2)}")#text(" are representations, then the characters of the direct sum ")#mi("{\\rho_1 \\oplus \\rho_2: G \\rightarrow U(V_1 \\oplus U_2)}")#text(" and tensor product ")#mi("{\\rho_1 \\otimes \\rho_2: G \\rightarrow U(V_1 \\otimes V_2)}")#text(" are the sum and product of the individual characters:")

#align(center)[#tao-fit-display[#mitex("\\chi_{\\rho_1 \\oplus \\rho_2} = \\chi_{\\rho_1} + \\chi_{\\rho_2}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\chi_{\\rho_1 \\otimes \\rho_2} = \\chi_{\\rho_1} \\chi_{\\rho_2}.")]]

#text("Also, if ")#mi("{\\overline{V_1}}")#text(" is the Hilbert space ")#mi("{V_1}")#text(" with the conjugated inner product, then the conjugate representation ")#mi("{\\overline{\\rho_1}: G \\rightarrow U(\\overline{V_1})}")#text(" (given by taking ")#mi("{\\rho_1}")#text(" and conjugating the inner product structure) has a conjugated character:")

#align(center)[#tao-fit-display[#mitex("\\chi_{\\overline{\\rho_1}} = \\overline{\\chi_{\\rho_1}}.")]]

#text("Thus the space of characters forms a ")#link("http://en.wikipedia.org/wiki/Semi-ring")[#text("semi-ring")]#text(" in ")#mi("{L^2(G)^G}")#text(" that is closed under complex conjugation. Also, since any element of the ")#link("http://en.wikipedia.org/wiki/Absolute_Galois_group")[#text("absolute Galois group")]#text(" ")#mi("{\\text{Gal}(\\overline{{\\bf Q}}/{\\bf Q})}")#text(" of the rationals can be extended to the complex numbers ")#mi("{{\\bf C}}")#text(", we have the stronger fact that the space of characters is also invariant with respect to the action of ")#mi("{\\text{Gal}(\\overline{{\\bf Q}}/{\\bf Q})}")#text("; we will need this fact somewhat later in this post.")

#text("The space of characters is not a ring, because characters are certainly not preserved with respect to negation: the value of a representation ")#mi("{\\chi_\\rho(1_G)}")#text(" at the identity is the dimension ")#mi("{\\text{dim}(\\rho) := \\text{dim}(V)}")#text(" of the space that ")#mi("{\\rho}")#text(" acts on, and so is non-negative; in particular, ")#mi("{-\\chi_\\rho}")#text(" will not be a character as long as ")#mi("{\\rho}")#text(" is positive dimensional. We can then define the space of ")#emph[#text("generalised characters")]#text(" to be the ring generated by the characters, thus a generalised character is nothing more than a difference of two characters.")

#text("By repeatedly taking orthogonal complements, one can easily see that representations are completely reducible, thus if ")#mi("{\\hat G}")#text(" is a collection of one representative of each of the isomorphism classes of irreducible finite-dimensional representations of ")#mi("{G}")#text(", then every character can be written as a linear combination (over the natural numbers) of the irreducible characters ")#mi("{\\{ \\chi_\\xi: \\xi \\in \\hat G \\}}")#text(".")

#text("From the ergodic theorem (which is a triviality in the case of an action of a finite group ")#mi("{G}")#text("), the average value of a character ")#mi("{\\chi_\\rho}")#text(" of a representation ")#mi("{\\rho: G \\rightarrow U(V)}")#text(" is equal to the dimension of its invariant component ")#mi("{V^G := \\{ v \\in V: \\rho(g)v = v \\text{ for all } g \\in G \\}}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{x \\in G} \\chi_\\rho(x) = \\text{dim}( V^G ).")]]

#text("As a consequence, the inner product ")#mi("{\\langle \\chi_{\\rho_1}, \\chi_{\\rho_2} \\rangle_{L^2(G)^G}}")#text(" of two characters is equal to the dimension of the ")#mi("{G}")#text("-invariant component of ")#mi("{\\rho_1 \\otimes \\overline{\\rho_2}}")#text(". By ")#link("http://en.wikipedia.org/wiki/Schur's_lemma")[#text("Schur’s lemma")]#text(", this implies in particular that the irreducible characters ")#mi("{\\{ \\chi_\\xi: \\xi \\in \\hat G \\}}")#text(" are an orthonormal system in ")#mi("{L^2(G)}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\langle \\chi_\\xi, \\chi_{\\xi^{\\prime}} \\rangle_{L^2(G)^G} = 1_{\\xi=\\xi^{\\prime}}.")]]

#text("In fact, they form an orthonormal ")#emph[#text("basis")]#text(" for ")#mi("{L^2(G)^G}")#text(". (Proof: given any non-trivial ")#mi("{K \\in L^2(G)^G}")#text(", the convolution operator ")#mi("{f \\mapsto K * f}")#text(" is non-trivial in the regular representation, and thus must also be non-trivial with respect to at least one irreducible representation ")#mi("{\\xi}")#text(", which implies that ")#mi("{K}")#text(" has non-zero inner product with ")#mi("{\\chi_\\xi}")#text(". Thus there is no non-zero element of ")#mi("{L^2(G)^G}")#text(" that is orthogonal to all the irreducible characters, giving the claim.) In particular, we see that ")#tao-math("{\\left|\\hat G\\right|}", block: false)#text(" is equal to the class number of ")#mi("{G}")#text(".")

#text("Using this basis, we now have a Fourier transform ")#mi("{f \\mapsto \\hat f}")#text(" that is an isometry between the Hilbert space ")#mi("{L^2(G)^G}")#text(" of class functions, and the Hilbert space ")#mi("{\\ell^2(\\hat G)}")#text(", defined by taking inner products with characters")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) := \\langle f, \\chi_\\xi \\rangle_{L^2(G)}")]]

#text("and with the usual Fourier inversion formula")

#align(center)[#tao-fit-display[#mitex("f = \\sum_{\\xi \\in \\hat G} \\hat f(\\xi) \\chi_\\xi")]]

#text("and Plancherel and Parseval identities")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^2(G)^G} = \\left\\| \\hat f \\right\\|_{\\ell^2(\\hat G)}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\langle f_1,f_2 \\rangle_{L^2(G)^G} = \\langle \\hat f_1, \\hat f_2 \\rangle_{\\ell^2(\\hat G)}.")]]

#text("(One can also relate convolution in ")#mi("{L^2(G)^G}")#text(" with pointwise multiplication in ")#mi("{\\ell^2(\\hat G)}")#text(", and pointwise multiplication in ")#mi("{L^2(G)^G}")#text(" is related to a ")#link("http://en.wikipedia.org/wiki/Plethysm")[#text("plethysm")]#text(" on ")#mi("{\\ell^2(\\hat G)}")#text(" involving tensor product multiplicities, but we will not need these operations here.)")

#text("A character ")#mi("{\\chi_\\rho}")#text(" of a (not necessarily irreducible) representation ")#mi("{\\rho}")#text(" then has Fourier coefficients ")#mi("{\\widehat{\\chi_\\rho}(\\xi)}")#text(" that count the multiplicity of ")#mi("{\\xi}")#text(" in ")#mi("{\\rho}")#text("; in particular, a class function is a character (resp. generalised character) iff its Fourier coefficients are all natural numbers (resp. integers), and any two representations are isomorphic iff they have the same character.")

#text("Thus for instance the regular representation ")#mi("{\\tau}")#text(" has Fourier coefficients ")#mi("{\\hat{\\chi_\\tau}(\\xi) = \\text{dim}(\\xi)}")#text(", leading to the identity")

#align(center)[#tao-fit-display[#mitex("\\chi_\\tau = \\sum_{\\xi \\in \\hat G} \\text{dim}(\\xi) \\chi_\\xi")]]

#text("which gives the ")#link("https://en.wikipedia.org/wiki/Peter-Weyl_theorem")[#text("Peter-Weyl theorem")]#text(" that ")#mi("{\\tau}")#text(" is isomorphic to the direct sum of ")#mi("{\\text{dim}(\\xi)}")#text(" copies of ")#mi("{\\xi}")#text(" for each ")#mi("{\\xi \\in \\hat G}")#text(". In particular we have ")#metadata(none) <tao-5185860e2d4774bdfb3d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|G\\right| = \\sum_{\\xi \\in \\hat G} \\text{dim}(\\xi)^2.", block: true)]]

#text("From these Fourier identities we can now detect whether a representation is irreducible (or a combination of a small number of representations) through the ")#mi("{L^2}")#text(" structure of its character. Indeed, by taking Fourier transforms and working in ")#mi("{\\ell^2(\\hat G)}")#text(" we now have the following immediate corollaries, which will be very useful to us in the sequel:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Small ")#mi("{L^2(G)^G}")#text(" norm and irreducibility)")]#text(" ")#metadata(none) <tao-f2030ff503b84ae45959>#text(" Let ")#mi("{\\chi}")#text(" be a generalised character.")

#list(
[#text("(i) ")#tao-math("{\\left\\|\\chi\\right\\|_{L^2(G)^G}^2}", block: false)#text(" is a natural number.")],
[#text("(ii) ")#tao-math("{\\left\\| \\chi\\right\\|_{L^2(G)^G}^2}", block: false)#text(" equals ")#mi("{1}")#text(" iff ")#mi("{\\chi = \\epsilon \\chi_\\xi}")#text(" for some sign ")#mi("{\\epsilon \\in \\{-1,+1\\}}")#text(" and irreducible character ")#mi("{\\chi_\\xi}")#text(". If we also know that ")#mi("{\\chi(1_G)>0}")#text(", this forces ")#mi("{\\epsilon = +1}")#text(" (since ")#mi("{\\chi_\\xi(1_G) = \\text{dim}(\\xi)}")#text(" is positive).")],
[#text("(iii) ")#tao-math("{\\left\\|\\chi\\right\\|_{L^2(G)^G}^2}", block: false)#text(" equals ")#mi("{2}")#text(" iff ")#mi("{\\chi = \\epsilon \\chi_\\xi - \\epsilon^{\\prime} \\chi_{\\xi^{\\prime}}}")#text(" for some signs ")#mi("{\\epsilon,\\epsilon^{\\prime} \\in \\{-1,+1\\}}")#text(" and distinct irreducible characters ")#mi("{\\chi_\\xi,\\chi_{\\xi^{\\prime}}}")#text(". If we also know that ")#mi("{\\chi(1_G)=0}")#text(", then this forces ")#mi("{\\epsilon=\\epsilon^{\\prime}}")#text(" (again because ")#mi("{\\chi_\\xi(1_G), \\chi_{\\xi^{\\prime}}(1_G)}")#text(" are positive).")]
)
]

#text("One can of course also characterise when ")#tao-math("{\\left\\|\\chi\\right\\|_{L^2(G)^G}^2}", block: false)#text(" is equal to ")#mi("{3}")#text(", ")#mi("{4}")#text(", etc. by this method, although the descriptions rapidly become more complicated and less useful. In practice, this lemma will allow us to construct interesting examples of irreducible representations by first exhibiting a generalised character of small norm (or equivalently, two characters that are close to each other in ")#mi("{L^2(G)^G}")#text(" norm). It seems very difficult to mimic this type of construction by any other means, including non-character-based representation theoretic methods. (But perhaps one could categorify this lemma somehow using ")#link("http://en.wikipedia.org/wiki/K-theory")[#text("K-theory")]#text(".)")

#text("Lemma ")#link(<tao-f2030ff503b84ae45959>)[#text("4")]#text(" is a typical application of the ")#emph[#text("integrality gap")]#text(", which is the trivial but fundamental fact that integers are either zero or have magnitude at least one. It is the interplay between the integrality gap and the Fourier analysis of characters which drives the proof of both Frobenius’ theorem and Suzuki’s theorem, as we shall soon see.")

#text("We also record some additional easy properties of characters which we will need later. Firstly, we have the identity ")#metadata(none) <tao-c2f265f1b2318f317a26>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\chi(g^{-1}) = \\overline{\\chi(g)}")]]

#text("for any ")#mi("{g \\in G}")#text(", since the inverse of a unitary operator is also its adjoint. Secondly, the ")#emph[#text("kernel")]#text(" ")#metadata(none) <tao-6923dd1bc0460082c5d5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\{ x \\in G: \\chi(x) = \\chi(1_G) \\}")]]

#text("of a character is automatically a normal subgroup of ")#mi("{G}")#text(". This is because a unitary operator on a finite-dimensional space ")#mi("{V}")#text(" has trace ")#mi("{\\text{dim}(V)}")#text(" if and only if it is equal to the identity operator, and so ")#link(<tao-6923dd1bc0460082c5d5>)[#text("(3)")]#text(" is also the kernel of the associated representation ")#mi("{\\rho: G \\rightarrow U(V)}")#text(". This latter fact suggests a strategy to prove Frobenius’ theorem by exhibiting a character whose kernel is precisely the complement of the conjugacy classes of ")#mi("{H}")#text(" excluding the identity, and this is in fact exactly what we will do.")

#text("Thus far we have focused on the representation theory of a single group ")#mi("{G}")#text(". However, the situation becomes significantly more interesting when one relates the representation theory of ")#emph[#text("two")]#text(" groups, a finite group ")#mi("{G}")#text(" and a subgroup ")#mi("{H}")#text(" (not necessarily normal). We then have an obvious restriction map ")#mi("{\\text{Res}^H_G: L^2(G)^G \\rightarrow L^2(H)^H}")#text(" that restricts any class function on ")#mi("{G}")#text(" to a class function on ")#mi("{H}")#text(" (since any two elements of ")#mi("{H}")#text(" that are conjugate in ")#mi("{H}")#text(" are clearly also conjugate in ")#mi("{G}")#text("). The adjoint map ")#mi("{\\text{Ind}^G_H: L^2(H)^H \\rightarrow L^2(G)^G}")#text(" can be easily computed: given any class function ")#mi("{f \\in L^2(H)^H}")#text(", the induced class function ")#mi("{\\text{Ind}^G_H f\\in L^2(G)^G}")#text(" is given by the ")#emph[#text("Frobenius formula")]#text(" ")#metadata(none) <tao-701273d7d675901d67fe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\text{Ind}^G_H f(x) = \\frac{1}{\\left|H\\right|} \\sum_{g \\in G} f(gxg^{-1})", block: true)]]

#text("with the convention that ")#mi("{f}")#text(" is extended by zero from ")#mi("{H}")#text(" to ")#mi("{G}")#text(". Equivalently, one has")

#align(center)[#tao-fit-display[#mitex("\\text{Ind}^G_H f(x) = \\sum_{i=1}^k f(g_ixg_i^{-1})")]]

#text("where ")#mi("{g_1 H, \\ldots, g_k H}")#text(" is an enumeration of the left-cosets of ")#mi("{H}")#text(".")

#text("In a similar fashion, given a representation ")#mi("{\\rho: G \\rightarrow U(V)}")#text(" of ")#mi("{G}")#text(", we may restrict it to ")#mi("{H}")#text(" to obtain a representation ")#mi("{\\text{Res}^H_G \\rho: H \\rightarrow U(V)}")#text(" of ")#mi("{H}")#text(". In the adjoint direction, given a representation ")#mi("{\\eta: H \\rightarrow U(V)}")#text(" of ")#mi("{H}")#text(", one can associate an ")#link("https://en.wikipedia.org/wiki/Induced_representation")[#text("induced representation")]#text(" ")#mi("{\\text{Ind}^G_H \\eta: G \\rightarrow U(\\tilde V)}")#text(" of ")#mi("{G}")#text(" by the following construction. One takes ")#mi("{\\tilde V}")#text(" to be the space of functions ")#mi("{v: G \\rightarrow V}")#text(" that ")#mi("{v(gh) = \\eta(h^{-1}) v(g)}")#text(" for all ")#mi("{g \\in G}")#text(" and ")#mi("{h \\in H}")#text(" with inner product")

#align(center)[#tao-fit-display[#mitex("\\langle v_1, v_2 \\rangle_{\\tilde V} := \\mathop{\\bf E}_{x \\in G} \\langle v_1(x), v_2(x) \\rangle_V,")]]

#text("and then lets ")#mi("{G}")#text(" act on ")#mi("{\\tilde V}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\text{Ind}^G_H \\eta(g) v(x) := v(g^{-1} x)")]]

#text("which one can check to indeed give a representation. Thus, for instance, the regular representation on ")#mi("{H}")#text(" induces (an isomorphic copy of) the regular representation on ")#mi("{G}")#text(". It is not difficult to show that these representation-theoretic constructions are compatible with the operations on class functions mentioned earlier, thus")

#align(center)[#tao-fit-display[#mitex("\\text{Res}^H_G \\chi_\\rho = \\chi_{\\text{Res}^H_G \\rho}")]]

#text("for every representation ")#mi("{\\rho}")#text(" of ")#mi("{G}")#text(", and dually")

#align(center)[#tao-fit-display[#mitex("\\text{Ind}^G_H \\chi_\\rho = \\chi_{\\text{Ind}^G_H \\rho}.")]]

#text("In particular, any character of ")#mi("{G}")#text(" restricts to a character of ")#mi("{H}")#text(", and every character of ")#mi("{H}")#text(" induces a character on ")#mi("{G}")#text(". Thus the adjoint relationship between ")#mi("{\\text{Res}^H_G}")#text(" and ")#mi("{\\text{Ind}^G_H}")#text(" for class functions induces a corresponding adjoint relationship for representations, known as ")#emph[#text("Frobenius reciprocity")]#text(".")

#text("In general, the restriction or induction of an irreducible representation will not be irreducible (and the operations of restriction and induction do ")#emph[#text("not")]#text(" invert each other). However, the ")#mi("{L^2}")#text(" geometry of the characters can often be controlled quite precisely (especially for structured groups such as Frobenius groups or CA-groups), and this together with tools such as Lemma ")#link(<tao-f2030ff503b84ae45959>)[#text("4")]#text(" can allow us to create interesting irreducible representations of ")#mi("{G}")#text(" in non-trivial fashion from irreducible representations of ")#mi("{H}")#text(".")

#heading(level: 1)[#strong[#text(" — 2. Frobenius’ theorem — ")]]

#text("We are now ready to prove Frobenius’ theorem. Let ")#mi("{G}")#text(" be a Frobenius group with Frobenius complement ")#mi("{H}")#text(". Then there are ")#tao-math("{\\left|G\\right|/\\left|H\\right|}", block: false)#text(" distinct conjugates ")#mi("{gHg^{-1}}")#text(" of ")#mi("{H}")#text(", which are all disjoint except for the origin, thus one can partition ")#metadata(none) <tao-eeea394806ada3056899>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("G = \\{1_G\\} \\cup \\bigcup_{g \\in G/H} (gHg^{-1} \\backslash \\{1_G\\}) \\cup (K \\backslash \\{1_G\\})")]]

#text("where (by abuse of notation) ")#mi("{g}")#text(" ranges over a set of representatives ")#mi("{gH}")#text(" of the left cosets of ")#mi("{H}")#text(" and ")#mi("{K}")#text(" is the identity together with all the elements that do not lie in any conjugate of ")#mi("{H}")#text(". I like to think of this decomposition by picturing ")#mi("{G}")#text(" as being like a plane, ")#mi("{1_G}")#text(" being the origin in this plane, each conjugate ")#mi("{gHg^{-1}}")#text(" being a non-vertical line through the origin, and ")#mi("{K}")#text(" being the vertical line through the origin (note that in the case of the ")#mi("{ax+b}")#text(" group, this is more or less exactly what ")#link(<tao-eeea394806ada3056899>)[#text("(5)")]#text(" actually looks like). Counting elements in ")#link(<tao-eeea394806ada3056899>)[#text("(5)")]#text(", we thus have")

#align(center)[#tao-fit-display[#tao-math("\\left|G\\right|= 1 + \\frac{\\left|G\\right|}{\\left|H\\right|} (\\left|H\\right|-1) + (\\left|K\\right|-1)", block: true)]]

#text("and so ")#metadata(none) <tao-45a0b93e1524353e6bf1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left|K\\right| = \\frac{\\left|G\\right|}{\\left|H\\right|}.", block: true)]]

#text("We now start inducing characters from ")#mi("{H}")#text(" to ")#mi("{G}")#text(" and determine their geometr;8 Let ")#mi("{\\xi \\in \\hat H}")#text(" be a irreducible character of ")#mi("{H}")#text(" of some dimension ")#mi("{d = \\text{dim}(\\xi)}")#text(", then the character ")#mi("{\\chi_\\xi}")#text(" obeys the identities")

#align(center)[#tao-fit-display[#mitex("\\chi_\\xi(1_G) = d")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\sum_{h \\in H} \\left|\\chi_\\xi(h)\\right|^2 = \\left|H\\right| \\left\\|\\chi_\\xi\\right\\|_{L^2(H)^H}^2 = \\left|H\\right|.", block: true)]]

#text("In particular,")

#align(center)[#tao-fit-display[#tao-math("\\sum_{h \\in H \\backslash \\{0\\}} \\left|\\chi_\\xi(h)\\right|^2 = \\left|H\\right| - d^2.", block: true)]]

#text("Now we consider the induced character")

#align(center)[#tao-fit-display[#mitex("\\text{Ind}^G_H \\chi_\\xi(x) = \\sum_{g \\in G/H} \\chi_\\xi(gxg^{-1}).")]]

#text("Using the above identities and the partition ")#link(<tao-eeea394806ada3056899>)[#text("(5)")]#text(", we see that ")#mi("{\\text{Ind}^G_H \\chi_\\xi}")#text(" equals ")#tao-math("{d \\left|G\\right|/\\left|H\\right|}", block: false)#text(" at ")#mi("{1_G}")#text(", vanishes at all other elements of ")#mi("{K}")#text(", and on each of the ")#tao-math("{\\left|G\\right|/\\left|H\\right|}", block: false)#text(" sets ")#mi("{gHg^{-1} \\backslash \\{1_G\\}}")#text(" is given by a conjugate of ")#mi("{\\chi_\\xi}")#text(". In particular,")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in G \\backslash K} \\left|\\text{Ind}^G_H \\chi_\\xi(x)\\right|^2 = \\frac{\\left|G\\right|}{\\left|H\\right|} (\\left|H\\right|-d^2).", block: true)]]

#text("Similarly, if one induces the trivial character ")#mi("{1}")#text(" on ")#mi("{H}")#text(" to a character ")#mi("{\\text{Ind}^G_H 1}")#text(" on ")#mi("{G}")#text(", this character will equal ")#tao-math("{\\left|G\\right|/\\left|H\\right|}", block: false)#text(" at ")#mi("{1_G}")#text(", vanish at all other elements of ")#mi("{K}")#text(", and will equal ")#mi("{1}")#text(" on ")#mi("{G \\backslash K}")#text(". If we then form the generalised character")

#align(center)[#tao-fit-display[#mitex("\\tilde \\chi_\\xi := \\text{Ind}^G_H \\chi_\\xi - d\\text{Ind}^G_H 1 + d,")]]

#text("then ")#mi("{\\tilde \\chi_\\xi}")#text(" equals ")#mi("{d}")#text(" on ")#mi("{K}")#text(" and is equal to ")#mi("{\\text{Ind}^G_H \\chi_\\xi}")#text(" outside of ")#mi("{K}")#text(". In particular, we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in G} \\left|\\tilde \\chi_\\xi(x)\\right|^2 = d^2 \\left|K\\right| + \\frac{\\left|G\\right|}{\\left|H\\right|} (\\left|H\\right|-d^2).", block: true)]]

#text("Using ")#link(<tao-45a0b93e1524353e6bf1>)[#text("(6)")]#text(", we thus see that ")#mi("{\\tilde \\chi_\\xi}")#text(" has surprisingly small norm:")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\tilde \\chi_\\xi \\right\\|_{L^2(G)^2} = 1.", block: true)]]

#text("We can then apply Lemma ")#link(<tao-f2030ff503b84ae45959>)[#text("4")]#text(" and conclude that ")#mi("{\\tilde \\chi_\\xi = \\chi_{\\tilde \\xi}}")#text(" for some irreducible representation ")#mi("{\\tilde \\xi \\in \\hat G}")#text(" of ")#mi("{G}")#text(". Note that ")#mi("{\\text{Res}^H_G \\tilde \\chi_\\xi = \\chi_\\xi}")#text(". Thus we have shown that every irreducible representation ")#mi("{\\xi}")#text(" of ")#mi("{H}")#text(" is the restriction of an irreducible representation ")#mi("{\\tilde \\xi}")#text(" of ")#mi("{G}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The above analysis shows a little bit more, namely that ")#mi("{\\tilde \\xi}")#text(" arises in ")#mi("{\\text{Ind}^G_H \\xi}")#text(" as the orthogonal complement of a copy of the mean zero component of ")#link("http://en.wikipedia.org/wiki/Quasiregular_representation")[#text("quasiregular representation")]#text(" on ")#mi("{L^2(G/H)}")#text(" (i.e. the induction of the trivial representation on ")#mi("{H}")#text("), although it is not obvious to me how one would demonstrate (other than via an inspection of characters) that the induced representation ")#mi("{\\text{Ind}^G_H \\xi}")#text(" actually contains a copy of this component of the quasiregular representation.")
]

#text("Now we consider the regular character of ")#mi("{H}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\chi_\\tau = \\sum_{\\xi \\in \\hat H} \\text{dim}(\\xi) \\chi_\\xi.")]]

#text("This character equals ")#tao-math("{\\left|H\\right|}", block: false)#text(" at the identity, and vanishes at the other elements of ")#mi("{H}")#text(". If we then form the associated character")

#align(center)[#tao-fit-display[#mitex("\\tilde \\chi_\\tau := \\sum_{\\xi \\in \\hat H} \\text{dim}(\\xi) \\chi_{\\tilde \\xi}")]]

#text("of ")#mi("{G}")#text(", then ")#mi("{\\tilde \\chi_\\tau}")#text(" restricts to ")#mi("{\\chi_\\tau}")#text(" and so also equals ")#tao-math("{\\left|H\\right|}", block: false)#text(" at the identity and vanishes at the other elements of ")#mi("{H}")#text(". By ")#link(<tao-eeea394806ada3056899>)[#text("(5)")]#text(", we conclude that ")#mi("{\\tilde \\chi_\\tau}")#text(" (which is a class function) is supported on ")#mi("{K}")#text(". Also, as each of the ")#mi("{\\chi_{\\tilde \\xi}}")#text(" are constant on ")#mi("{K}")#text(", ")#mi("{\\tilde \\chi_\\tau}")#text(" is also, and so ")#mi("{\\tilde \\chi_\\tau}")#text(" equals ")#tao-math("{\\left|H\\right|}", block: false)#text(" on all of ")#mi("{K}")#text(". Thus ")#mi("{K}")#text(" is the kernel ")#link(<tao-6923dd1bc0460082c5d5>)[#text("(3)")]#text(" of the character ")#mi("{\\tilde \\chi_\\tau}")#text(" and is thus normal. This gives Frobenius’ theorem as discussed in the introduction.")

#heading(level: 1)[#strong[#text(" — 3. More character theory — ")]]

#text("Before we turn to Suzuki’s theorem, we will need some additional facts about characters which go beyond the Fourier-analytic considerations of Section ")#link(<tao-60e74ce4f5e27dd8485c>)[#text("1")]#text(" by also employing some tools from algebraic number theory.")

#text("Let ")#mi("{G}")#text(" be a finite group. Observe that if ")#mi("{\\rho: G \\rightarrow U(V)}")#text(" is a representation, then for any ")#mi("{g \\in G}")#text(", the unitary operator ")#mi("{\\rho(g)}")#text(" can be diagonalised. As ")#mi("{g}")#text(" (and hence ")#mi("{\\rho(g)}")#text(") has finite order, the eigenvalues of ")#mi("{\\rho(g)}")#text(" are roots of unity, and so the trace ")#mi("{\\chi_\\rho(g) = \\text{tr}(\\rho(g))}")#text(" is the sum of finitely many roots of unity. In particular, ")#mi("{\\chi_\\rho(g)}")#text(" is always an ")#link("http://en.wikipedia.org/wiki/Algebraic_integer")[#text("algebraic integer")]#text(". Unlike rational integers, algebraic integers do not directly enjoy an integrality gap; one can have algebraic integers of arbitrarily small nonzero magnitude (e.g. powers of ")#mi("{\\sqrt{2}-1}")#text("). However, we will rely in several places on the basic but fundamental fact that a number which is both an algebraic integer ")#emph[#text("and")]#text(" a rational is necessarily a rational integer, which then ")#emph[#text("is")]#text(" subject to the integrality gap.")

#text("We have a variant of the above fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5")]#text(" Let ")#mi("{G}")#text(" be a finite group, let ")#mi("{\\xi: G \\rightarrow U(V)}")#text(" be a ")#mi("{d}")#text("-dimensional ")#emph[#text("irreducible")]#text(" representation, and let ")#mi("{x \\in G}")#text(". Then ")#tao-math("{\\frac{\\left|\\text{Cl}(x)\\right|}{d} \\chi_\\xi(x)}", block: false)#text(" is an algebraic integer, where ")#mi("{\\text{Cl}(x) := \\{ gxg^{-1}: g \\in G \\}}")#text(" is the conjugacy class of ")#mi("{x}")#text(".")
]

#emph[#text("Proof:")]#text(" The endomorphism ")#mi("{A := \\sum_{y \\in \\text{Cl}(x)} \\rho(y) \\in \\text{End}(V)}")#text(" is ")#mi("{G}")#text("-equivariant and has trace ")#tao-math("{\\left|\\text{Cl}(x)\\right| \\chi_\\xi(x)}", block: false)#text("; by Schur’s lemma, it is thus equal to ")#tao-math("{\\frac{\\left|\\text{Cl}(x)\\right|}{d} \\chi_\\xi(x)}", block: false)#text(" times the identity. It thus suffices to show that the diagonal entries of ")#mi("{A}")#text(" are algebraic integers; thus it will suffice to show that ")#mi("{P(A)=0}")#text(" for some monic polynomial ")#mi("{P}")#text(" with integer coefficients.")

#text("Consider the associated element ")#mi("{a := \\sum_{y \\in \\text{Cl}(x)} y}")#text(" in the ")#link("http://en.wikipedia.org/wiki/Group_ring")[#text("group ring")]#text(" ")#mi("{{\\bf Z} G}")#text(" of ")#mi("{G}")#text(". Then the modules ")#mi("{\\langle 1 \\rangle}")#text(", ")#mi("{\\langle 1, a \\rangle}")#text(", ")#mi("{\\langle 1, a, a^2 \\rangle}")#text(", etc. form an increasing sequence of submodules of ")#mi("{{\\bf Z} G}")#text(". As ")#tao-math("{{\\bf Z} G \\equiv {\\bf Z}^{\\left|G\\right|}}", block: false)#text(" is ")#link("http://en.wikipedia.org/wiki/Noetherian_ring")[#text("Noetherian")]#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("\\langle 1, a, \\ldots, a^n \\rangle = \\langle 1, a, \\ldots, a^{n-1} \\rangle")]]

#text("for some ")#mi("{n \\geq 1}")#text(", or equivalently that ")#mi("{a^n}")#text(" is an integer combination of ")#mi("{1,a,\\ldots,a^{n-1}}")#text(". This implies that ")#mi("{A^n}")#text(" is an integer combination of ")#mi("{1,A,\\ldots,A^{n-1}}")#text(", and the claim follows. ")#mi("\\Box")

#text("This leads to an important corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 6 (Dimension divides order)")]#text(" ")#metadata(none) <tao-c5d4b45934fe1d9c636d>#text(" Let ")#mi("{G}")#text(" be a finite group, and let ")#mi("{\\xi: G \\rightarrow U(V)}")#text(" be an irreducible ")#mi("{d}")#text("-dimensional representation. Then ")#mi("{d}")#text(" divides ")#tao-math("{\\left|G\\right|}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" As the character ")#mi("{\\chi_\\xi}")#text(" has ")#mi("{L^2(G)^G}")#text(" norm one, we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in G} \\left|\\chi_\\xi(x)\\right|^2 = \\left|G\\right|.", block: true)]]

#text("Grouping the ")#mi("{x}")#text(" summation by conjugacy classes ")#mi("{C(g)}")#text(", we can express the left-hand side as the sum of terms of the form ")#mi("{\\text{Cl}(x) \\chi_\\xi(x) \\overline{\\chi_\\xi(x)}}")#text(", which by the preceding lemma and discussion is equal to ")#mi("{d}")#text(" times an algebraic integer. We conclude that ")#tao-math("{\\left|G\\right|/d}", block: false)#text(" is an algebraic integer also; but it is rational, and so must be a rational integer also. ")#mi("\\Box")

#text("In particular, if ")#mi("{G}")#text(" is of odd order, then the dimension of any irreducible representation of ")#mi("{G}")#text(" has odd dimension. This has a further important consequence, due to Burnside:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7 (Odd groups have non-real characters)")]#text(" ")#metadata(none) <tao-990cb8ebd0afb7150da4>#text(" Let ")#mi("{G}")#text(" be a finite group of odd order, and let ")#mi("{\\chi}")#text(" be a non-principal irreducible character of ")#mi("{G}")#text(". Then ")#mi("{\\chi}")#text(" is not a real-valued character. In other words, ")#mi("{\\overline{\\chi} \\neq \\chi}")#text(".")
]

#emph[#text("Proof:")]#text(" Suppose for contradiction that ")#mi("{\\chi}")#text(" is real-valued. By ")#link(<tao-c2f265f1b2318f317a26>)[#text("(2)")]#text(" this implies that ")#mi("{\\chi(x)=\\chi(x^{-1})}")#text(" for all ")#mi("{x \\in G}")#text(".")

#text("As ")#mi("{G}")#text(" is odd, there are no elements in ")#mi("{G}")#text(" of order ")#mi("{2}")#text(". Thus one can partition ")#metadata(none) <tao-f355d997cf86189225a9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("G = \\{1_G\\} \\cup \\bigcup_{g \\in A} \\{g,g^{-1}\\}")]]

#text("for some subset ")#mi("{A}")#text(" of ")#mi("{G}")#text(" of order ")#tao-math("{(\\left|G\\right|-1)/2}", block: false)#text(". On the other hand, as ")#mi("{\\chi}")#text(" is non-principal, we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in G} \\chi(x) = \\left|G\\right| \\langle \\chi,1\\rangle_{L^2(G)^G} = 0.", block: true)]]

#text("By ")#link(<tao-f355d997cf86189225a9>)[#text("(7)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("0 = \\chi(1_G) + 2 \\sum_{g \\in A} \\chi(g).")]]

#text("But ")#mi("{\\chi(1_G)}")#text(" is the dimension of ")#mi("{\\chi}")#text(", which is odd by Corollary ")#link(<tao-c5d4b45934fe1d9c636d>)[#text("6")]#text(", so ")#mi("{\\sum_{g \\in A} \\chi(g)}")#text(" is a half-integer. But it is also an algebraic integer, giving the desired contradiction. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 4. Suzuki’s theorem — ")]]

#text("We can now begin the proof of Suzuki’s theorem; we will basically use an arrangement of this theorem from ")#link("http://www.math.binghamton.edu/grads/wilcox/ms_thesis.pdf")[#text("the thesis of Wilcox")]#text(". We begin with an easy reduction to the simple case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8 (Reduction to the simple case)")]#text(" Let ")#mi("{G}")#text(" be a finite CA-group of odd order which is not simple. Suppose that all CA groups of smaller odd order than ")#mi("{G}")#text(" are solvable. Then ")#mi("{G}")#text(" is solvable also.")
]

#emph[#text("Proof:")]#text(" If ")#mi("{G}")#text(" is not simple, it has a proper normal subgroup ")#mi("{N}")#text(". This group is also of odd order and inherits the CA property from ")#mi("{G}")#text(", so by hypothesis ")#mi("{N}")#text(" is solvable. If we let ")#mi("{A}")#text(" be the last non-trivial group in the ")#link("http://en.wikipedia.org/wiki/Derived_series#Derived_series")[#text("derived series")]#text(" of ")#mi("{N}")#text(", then ")#mi("{A}")#text(" is a non-trivial abelian ")#link("http://en.wikipedia.org/wiki/Characteristic_subgroup")[#text("characteristic")]#text(" subgroup of ")#mi("{N}")#text(", and is thus also a normal subgroup of ")#mi("{G}")#text(". Let ")#mi("{C}")#text(" be the centraliser of ")#mi("{A}")#text(", then ")#mi("{C}")#text(" is also a normal subgroup of ")#mi("{G}")#text(", which is still non-trivial and abelian as ")#mi("{G}")#text(" is a CA-group. Furthermore, ")#mi("{C}")#text(" is maximal abelian (it is not contained in any larger abelian group).")

#text("To show that ")#mi("{G}")#text(" is solvable, it then suffices to show that the quotient ")#mi("{G/C}")#text(" is solvable. As this group has an odd order smaller than that of ")#mi("{G}")#text(", it suffices to show that ")#mi("{G/C}")#text(" is a CA-group. Thus, if ")#mi("{x,y,z}")#text(" are non-identity elements of ")#mi("{G/C}")#text(" with ")#mi("{x,z}")#text(" both commuting with ")#mi("{y}")#text(", we need to show that ")#mi("{x,z}")#text(" commute with each other. Equivalently, if ")#mi("{a,b,c \\in G \\backslash C}")#text(" are such that ")#mi("{a,c}")#text(" both commute with ")#mi("{b}")#text(" modulo ")#mi("{C}")#text(", then ")#mi("{a}")#text(" commutes with ")#mi("{c}")#text(" modulo ")#mi("{C}")#text(".")

#text("If we fix ")#mi("{b}")#text(", then ")#mi("{b}")#text(" acts on ")#mi("{C}")#text(" by conjugation. This action cannot fix any non-identity element ")#mi("{d}")#text(" of ")#mi("{C}")#text(", else the centraliser of ")#mi("{d}")#text(" would contain ")#mi("{b}")#text(" as well as ")#mi("{C}")#text(", contradicting the maximal abelian nature of ")#mi("{C}")#text(". Thus the map ")#mi("{d \\mapsto bdb^{-1}d^{-1}}")#text(", which is a homomorphism on the normal abelian group ")#mi("{C}")#text(", has trivial kernel and is thus an isomorphism. From this we see that if ")#mi("{a}")#text(" commutes with ")#mi("{b}")#text(" modulo ")#mi("{C}")#text(", then one can multiply ")#mi("{a}")#text(" by an element of ")#mi("{C}")#text(" (on the left or right) in order to make it commute with ")#mi("{b}")#text(" ")#emph[#text("exactly")]#text(". Thus, without loss of generality, ")#mi("{a}")#text(" and ")#mi("{c}")#text(" both commute with ")#mi("{b}")#text(" exactly, and so ")#mi("{a,c}")#text(" commute exactly as well as ")#mi("{G}")#text(" is a CA-group, giving the claim. ")#mi("\\Box")

#text("In view of this proposition, we see that to prove Suzuki’s theorem it suffices to show that simple non-abelian CA-groups of odd order do not exist.")

#text("Observe that in a CA-group ")#mi("{G}")#text(", every non-identity element ")#mi("{x}")#text(" of ")#mi("{G}")#text(" is contained in a unique maximal abelian subgroup of ")#mi("{G}")#text(", namely the centraliser ")#mi("{C(x) := \\{ g \\in G: gx=xg\\}}")#text(" of ")#mi("{x}")#text(". Thus the maximal abelian subgroups of ")#mi("{G}")#text(", once one removes the identity, form a partition of ")#mi("{G \\backslash \\{1\\}}")#text(". It is instructive to keep some examples in mind:")

#list(
[#text("In the case of the ")#mi("{ax+b}")#text(" group on a field ")#mi("{F}")#text(", the maximal abelian subgroups are the translation group ")#mi("{\\{ x \\mapsto x+b: b \\in F \\}}")#text(" and the stabilisers ")#mi("{\\text{Stab}(x_0) = \\{ x \\mapsto a(x-x_0)+x_0: a \\in F^\\times\\}}")#text(" of points ")#mi("{x_0 \\in F}")#text(", where ")#mi("{F^\\times}")#text(" is the multiplicative group ")#mi("{F^\\times := F \\backslash \\{0\\}}")#text(".")],
[#text("In the case of the special linear group ")#mi("{SL_2(F_q)}")#text(" with ")#mi("{q}")#text(" a power of two, the maximal abelian groups are conjugates of the ")#emph[#text("split torus")]

#align(center)[#tao-fit-display[#mitex("T := \\{ \\begin{pmatrix} t & 0 \\\\ 0 & t^{-1} \\end{pmatrix}: t \\in F_q^\\times \\},")]]

#text("the ")#emph[#text("non-split torus")]

#align(center)[#tao-fit-display[#mitex("T^{\\prime} := \\{ \\begin{pmatrix} a & b \\\\ bs & a+b \\end{pmatrix}: a,b \\in F_q; a^2+ab+b^2s = 1 \\}")]]

#text("(where ")#mi("{s \\in F_q}")#text(" is any quantity not of the form ")#mi("{x^2+x}")#text(" for some ")#mi("{x \\in F_q}")#text(") or the ")#emph[#text("unipotent group")]

#align(center)[#tao-fit-display[#mitex("U := \\{ \\begin{pmatrix} 1 & x \\\\ 0 & 1 \\end{pmatrix}: x \\in F_q \\}.")]]]
)

#text("As these examples show, while many of the maximal abelian subgroups may be conjugate to each other, there can certainly be several non-conjugate examples of maximal abelian subgroups. Let ")#mi("{H_1,\\ldots,H_n}")#text(" be a set consisting of one representative from each of these conjugacy classes, then we have the following analogue of the partition ")#link(<tao-eeea394806ada3056899>)[#text("(5)")]#text(": ")#metadata(none) <tao-24fe93c9e17cb80452e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("G = \\{1_G\\} \\cup \\bigcup_{i=1}^n \\bigcup_{g \\in G/N(H_i)} (gH_ig^{-1} \\backslash \\{1_G\\}),")]]

#text("where ")#mi("{N(H_i) := \\{ g \\in G: gH_i = H_i g \\}}")#text(" is the normaliser of ")#mi("{H_i}")#text(". This partition turns out to be a somewhat less favourable than ")#link(<tao-eeea394806ada3056899>)[#text("(5)")]#text(", but one can still run analogues of the Frobenius argument, particularly in the case when ")#tao-math("{\\left|G\\right|}", block: false)#text(" is odd (which forces many other related quantities, such as ")#tao-math("{\\left|G/N(H_i)\\right|}", block: false)#text(", to be odd also). I like to think of this decomposition by viewing ")#mi("{G}")#text(" as a plane, ")#mi("{1_G}")#text(" as the origin, and ")#mi("{\\bigcup_{i=1}^n \\bigcup_{g \\in G/N(H_i)} (gH_ig^{-1} \\backslash \\{1_G\\})}")#text(" as sweeping out various sectors of this plane, with each conjugate ")#mi("{gH_i g^{-1}}")#text(" of ")#mi("{H_i}")#text(" being one of the rays in the sector. (This picture is an oversimplification, for instance it does not accurately reflect the closure of ")#mi("{H_i}")#text(" with respect to group inversion, but I still find it a useful picture to have in mind.)")

#text("We first give the analogue of ")#link(<tao-45a0b93e1524353e6bf1>)[#text("(6)")]#text(". Taking cardinalities in ")#link(<tao-24fe93c9e17cb80452e5>)[#text("(8)")]#text(" we obtain the ")#emph[#text("class equation")]

#align(center)[#tao-fit-display[#tao-math("\\left|G\\right| = 1 + \\sum_{i=1}^n \\frac{\\left|G\\right|}{\\left|N(H_i)\\right|} (\\left|H_i\\right|-1)", block: true)]]

#text("for a CA-group, which we can rearrange as ")#metadata(none) <tao-0889113e04d3203f0c40>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("1 = \\frac{1}{\\left|G\\right|} + \\sum_{i=1}^n \\frac{1}{\\left|W_i\\right|} - \\frac{1}{\\left|W_i\\right| \\left|H_i\\right|}", block: true)]]

#text("where ")#mi("{W_i}")#text(" is the group ")#mi("{W_i := N(H_i) / H_i}")#text(" (I like to think of this group as a sort of “")#link("http://en.wikipedia.org/wiki/Weyl_group")[#text("Weyl group")]#text("” associated to ")#mi("{H_i}")#text("). As a first approximation, the right hand side of ")#link(<tao-0889113e04d3203f0c40>)[#text("(9)")]#text(" is close to ")#tao-math("{\\sum_{i=1}^n 1/\\left|W_i\\right|}", block: false)#text(". Thus, if one can somehow prevent ")#tao-math("{\\left|W_i\\right|}", block: false)#text(" from getting too small for too many values of ")#mi("{i}")#text(", one an hope to upper bound the right-hand side of ")#link(<tao-0889113e04d3203f0c40>)[#text("(9)")]#text(" by something less than ")#mi("{1}")#text(", leading to the desired contradiction. (This strategy won’t quite work when ")#mi("{G}")#text(" is very small – ")#tao-math("{\\left|G\\right| \\leq 70}", block: false)#text(" to be precise – but this case can be worked out by hand.) Thus, we will be looking for such things as lower bounds on ")#tao-math("{\\left|W_i\\right|}", block: false)#text(" or upper bounds on ")#mi("{n}")#text(". The fact that ")#tao-math("{\\left|G\\right|}", block: false)#text(" is odd will force the ")#tao-math("{\\left|W_i\\right|}", block: false)#text(" and ")#tao-math("{\\left|H_i\\right|}", block: false)#text(" to be odd as well, which will turn out to be useful in improving these bounds by doubling the power of the integrality gap. (We will also rely on the odd order of ")#tao-math("{\\left|G\\right|}", block: false)#text(" in a number of other places, in particular using Proposition ")#link(<tao-990cb8ebd0afb7150da4>)[#text("7")]#text(".)")

#text("To get started on this strategy, suppose first that ")#mi("{W_i}")#text(" was trivial for some ")#mi("{i}")#text(", thus ")#mi("{N(H_i) = H_i}")#text(", and then all the ")#tao-math("{\\left|G\\right|/\\left|H_i\\right|}", block: false)#text(" conjugates of ")#mi("{H_i}")#text(" are distinct. This makes ")#mi("{G}")#text(" a Frobenius group, and so by Theorem ")#link(<tao-82a9a499531a2e813f59>)[#text("2")]#text(" there is a Frobenius kernel ")#mi("{K}")#text(", which is a normal subgroup of ")#tao-math("{\\left|G\\right|/\\left|H_i\\right|}", block: false)#text(". If ")#mi("{G}")#text(" is simple, then ")#mi("{K}")#text(" has to be trivial, which makes ")#mi("{G=H_i}")#text(" and so ")#mi("{G}")#text(" is abelian. This gives Suzuki’s theorem in this case. Thus we may assume that ")#tao-math("{\\left|W_i\\right| \\geq 2}", block: false)#text(" for all ")#mi("{i}")#text("; as the ")#mi("{W_i}")#text(" are all odd, we may improve this to ")#metadata(none) <tao-eb8f90e771df9356494d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left|W_i\\right| \\geq 3", block: true)]]

#text("for all ")#mi("{i}")#text(". From this and ")#link(<tao-0889113e04d3203f0c40>)[#text("(9)")]#text(" (and bounding ")#tao-math("{1/\\left|G\\right|}", block: false)#text(" by one of the ")#tao-math("{1/\\left|W_i\\right| \\left|H_i\\right|}", block: false)#text(") we thus see that ")#mi("{n}")#text(" is not too small: ")#metadata(none) <tao-672bb8bd1165a0140195>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("n>3.")]]

#text("Next, we use the ")#link("https://en.wikipedia.org/wiki/Sylow_theorems")[#text("Sylow theorems")]#text(" to make the ")#tao-math("{\\left|H_i\\right|}", block: false)#text(" pairwise coprime:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9")]#text(" ")#metadata(none) <tao-65f889b5c3c0a87da208>#text(" For any distinct ")#mi("{i,j}")#text(", ")#tao-math("{\\left|H_i\\right|}", block: false)#text(" and ")#tao-math("{\\left|H_j\\right|}", block: false)#text(" are coprime.")
]

#emph[#text("Proof:")]#text(" Suppose for contradiction that ")#tao-math("{\\left|H_i\\right|}", block: false)#text(" and ")#tao-math("{\\left|H_j\\right|}", block: false)#text(" are divisible by a common prime ")#mi("{p}")#text(". Then ")#mi("{H_i}")#text(" and ")#mi("{H_j}")#text(" both contain groups of order ")#mi("{p}")#text(", and thus both non-trivially intersect a ")#link("https://en.wikipedia.org/wiki/Sylow_theorems")[#text("Sylow ")#mi("{p}")#text("-group")]#text(". On the other hand, non-trivial Sylow ")#mi("{p}")#text("-groups have non-trivial centre (otherwise all conjugacy classes other than the identity would have order divisible by ")#mi("{p}")#text(", contradiction) and so must be abelian in a CA group. By further application of the CA property we thus conclude that ")#mi("{H_i}")#text(" and ")#mi("{H_j}")#text(" both contain a Sylow ")#mi("{p}")#text("-group. But all Sylow ")#mi("{p}")#text("-groups are conjugate, and so ")#mi("{H_i}")#text(" non-trivially intersects a conjugate of ")#mi("{H_j}")#text(", contradicting ")#link(<tao-24fe93c9e17cb80452e5>)[#text("(8)")]#text(". ")#mi("\\Box")

#text("We remark that the above analysis also reveals that ")#metadata(none) <tao-07ed400759a0f606a8b5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\left|G\\right| = \\prod_{i=1}^n \\left|H_i\\right|", block: true)]]

#text("(because the order of a Sylow ")#mi("{p}")#text("-group is the largest power of ")#mi("{p}")#text(" dividing ")#tao-math("{\\left|G\\right|}", block: false)#text("), although we will not need to rely on this fact here. (Actually we will barely use Lemma ")#link(<tao-65f889b5c3c0a87da208>)[#text("9")]#text(" as it is, it being needed to dispose of one technical case in the final analysis.) It is interesting though to see that classical techniques such as Sylow theorems are capable of demonstrating a number of facts about the various quantities appearing in the class equation ")#link(<tao-0889113e04d3203f0c40>)[#text("(9)")]#text(", although without the additional control arising from character theory these facts appear to be insufficient in and of themselves to actually contradict that equation. As an example of ")#link(<tao-07ed400759a0f606a8b5>)[#text("(12)")]#text(" one can take the special linear group ")#mi("{G = SL_2(F_q)}")#text(" with ")#mi("{q}")#text(" a power of two, in which there are three abelian groups ")#mi("{H_1,H_2,H_3}")#text(" (split torus, non-split torus, and unipotent group) of orders ")#mi("{q-1, q+1, q}")#text(" respectively, with the entire group ")#mi("{G}")#text(" being of order ")#mi("{q^3-q = (q-1)(q+1)q}")#text(".")

#text("We do not yet have a sufficiently strong upper bound on the right-hand side of ")#link(<tao-0889113e04d3203f0c40>)[#text("(9)")]#text(", basically because we have no upper bound on the number ")#mi("{n}")#text(" of conjugacy classes (or sufficiently good lower bounds on the ")#mi("{W_i}")#text("). To get further bounds we have to return to character theory. The basic idea will be to construct generalised characters which have small ")#mi("{L^2(G)^G}")#text(" norm but which take non-trivial rational integer values at many places, which when combined with the integrality gap will yield useful bounds on various quantities that appear in ")#link(<tao-0889113e04d3203f0c40>)[#text("(9)")]#text(".")

#text("We turn to the details. Let ")#mi("{H_i}")#text(" be one of the maximal abelian groups. Being abelian, the character theory of ")#mi("{H_i}")#text(" is just Fourier analysis: ")#mi("{\\hat H_i = \\text{Hom}(H_i,S^1)}")#text(" is the group of linear characters on ")#mi("{H_i}")#text(" (i.e. the ")#link("http://en.wikipedia.org/wiki/Pontryagin_duality")[#text("Pontryagin dual of ")#mi("{H_i}")]#text("). (Indeed, from ")#link(<tao-5185860e2d4774bdfb3d>)[#text("(1)")]#text(" and the observation that the class number of an abelian group is the same as its order, we see that all irreducible representations of an abelian group are one-dimensional.)")

#text("The normaliser ")#mi("{N(H_i)}")#text(" acts on ")#mi("{H_i}")#text(" by conjugation; as ")#mi("{H_i}")#text(" is abelian, the action of ")#mi("{H_i}")#text(" on itself is trivial, and so we obtain an action of ")#mi("{W_i = N(H_i)/H_i}")#text(" on ")#mi("{H_i}")#text(" also. Taking adjoints, we obtain an action of ")#mi("{W_i}")#text(" on ")#mi("{\\hat H_i}")#text(" as well. Any non-trivial element of ")#mi("{W_i}")#text(" cannot fix an non-trivial element ")#mi("{h_i}")#text(" of ")#mi("{H_i}")#text(", as the centraliser of ")#mi("{h_i}")#text(" would then contain an element outside of ")#mi("{H_i}")#text(", contradicting the CA-group nature of ")#mi("{G}")#text(". Taking adjoints, we conclude that a non-trivial element ")#mi("{w_i}")#text(" of ")#mi("{W_i}")#text(" cannot fix an non-trivial element ")#mi("{\\xi_i}")#text(" of ")#mi("{\\hat H_i}")#text(" either (otherwise the action of ")#mi("{w_i}")#text(" minus the identity would be non-injective, hence non-surjective, on ")#mi("{\\hat H_i}")#text(", so that the corresponding homomorphism on ")#mi("{H_i}")#text(" is non-injective). Thus we see that the action of ")#mi("{W_i}")#text(" foliates the non-identity elements ")#mi("{\\hat H_i \\backslash \\{1\\}}")#text(" of ")#mi("{\\hat H_i}")#text(" into orbits of size ")#tao-math("{\\left|W_i\\right|}", block: false)#text(". Among other things, this implies that ")#tao-math("{\\left|W_i\\right|}", block: false)#text(" divides ")#tao-math("{\\left|H_i\\right|-1}", block: false)#text(", and that the number of such orbits ")#mi("{w_i}")#text(" is ")#tao-math("{(\\left|H_i\\right|-1)/\\left|W_i\\right|}", block: false)#text(". As ")#tao-math("{\\left|H_i\\right|, \\left|W_i\\right|}", block: false)#text(" are both odd, ")#mi("{w_i}")#text(" is even, and in particular ")#metadata(none) <tao-26fba332169fb62ac0db>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("w_i \\geq 2")]]

#text("for all ")#mi("{i=1,\\ldots,n}")#text(".")

#text("Now let us make some generalised characters. Let ")#mi("{\\xi_i, \\xi^{\\prime}_i}")#text(" be non-identity elements of ")#mi("{\\hat H_i}")#text(" which do ")#emph[#text("not")]#text(" lie in the same ")#mi("{W_i}")#text("-orbit. Then ")#mi("{\\xi_i-\\xi^{\\prime}_i}")#text(" is a generalised character of ")#mi("{H_i}")#text(" that vanishes at the identity. Applying induction and ")#link(<tao-701273d7d675901d67fe>)[#text("(4)")]#text(", we see that ")#metadata(none) <tao-61a54dbfaac2e0c574f4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\text{Ind}^G_{H_i} (\\xi_i - \\xi^{\\prime}_i)")]]

#text("is a generalised character of ")#mi("{G}")#text(" that is supported on the set")

#align(center)[#tao-fit-display[#mitex("\\bigcup_{g \\in G/N(H_i)} g H_i g^{-1} \\backslash \\{1_G \\},")]]

#text("and whose restriction to ")#mi("{H_i}")#text(" takes the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{w \\in W_i} w\\xi_i - w\\xi^{\\prime}_i.")]]

#text("From the Plancherel identity (and the assumption that ")#mi("{\\xi_i, \\xi^{\\prime}_i}")#text(" have disjoint ")#mi("{W_i}")#text("-orbits) we see that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in H_i} \\left|\\sum_{w \\in W_i} w\\xi_i(x) - w\\xi^{\\prime}_i(x)\\right|^2 = 2 \\left|W_i\\right| \\left|H_i\\right|", block: true)]]

#text("and so")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in G} \\left|\\text{Ind}^G_{H_i} (\\xi_i - \\xi^{\\prime}_i)(x)\\right|^2 = \\frac{\\left|G\\right|}{\\left|N(H_i)\\right|} \\times 2 \\left|W_i\\right| \\left|H_i\\right|;", block: true)]]

#text("since ")#tao-math("{\\left|W_i\\right| = \\left|N(H_i)\\right|/\\left|H_i\\right|}", block: false)#text(", we thus have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\text{Ind}^G_{H_i} (\\xi_i - \\xi^{\\prime}_i) \\right\\|_{L^2(G)^G} = 2.", block: true)]]

#text("We can then apply Lemma ")#link(<tao-f2030ff503b84ae45959>)[#text("4")]#text(" and conclude the important fact that ")#mi("{\\text{Ind}^G_{H_i} (\\xi_i - \\xi^{\\prime}_i)}")#text(" is the difference of two distinct irreducible characters of ")#mi("{G}")#text(".")

#text("Let ")#mi("{\\xi_{i,1},\\ldots,\\xi_{i,w_i}}")#text(" be a set of representatives of all the ")#mi("{W_i}")#text(" orbits of ")#mi("{\\hat H_i \\backslash \\{0\\}}")#text(". Then by the above discussion, we see that")

#align(center)[#tao-fit-display[#mitex("\\text{Ind}^G_{H_i} \\xi_{i,a} - \\text{Ind}^G_{H_i} \\xi_{i,b}")]]

#text("is the difference of two distinct irreducible characters of ")#mi("{G}")#text(" whenever ")#mi("{a,b \\in \\{1,\\ldots,w_i\\}}")#text(" are distinct. From the linear independence of the irreducible characters and some easy combinatorics (using ")#link(<tao-26fba332169fb62ac0db>)[#text("(13)")]#text("), we then see that we can find distinct irreducible characters ")#mi("{\\xi_{i,1}^*,\\ldots,\\xi_{i,w_i}^*}")#text(" of ")#mi("{G}")#text(" and a sign ")#mi("{\\epsilon_i \\in \\{-1,+1\\}}")#text(" such that ")#metadata(none) <tao-558211ed72b2d6967037>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\text{Ind}^G_{H_i} \\xi_{i,a} - \\text{Ind}^G_{H_i} \\xi_{i,b} = \\epsilon_i (\\xi_{i,a}^* - \\xi_{i,b}^*)")]]

#text("for all ")#mi("{a,b \\in \\{1,\\ldots,w_i\\}}")#text(". For ")#mi("{w \\geq 3}")#text(", the sign ")#mi("{\\epsilon_i}")#text(" and the characters ")#mi("{\\xi_{i,a}^*}")#text(" are unique. When ")#mi("{w=2}")#text(", there is a non-uniqueness: one then has the freedom to swap ")#mi("{\\xi_{i,1},\\xi_{i,2}}")#text(" while reversing the sign of ")#mi("{\\epsilon_i}")#text(". But the ")#emph[#text("set")]#text(" of characters ")#mi("{\\xi_{i,1}^*,\\ldots,\\xi^*_{i,w_i}}")#text(" remains unique. We will call the ")#mi("{\\xi^*_{i,1},\\ldots,\\xi^*_{i,w_i}}")#text(" the ")#emph[#text("exceptional characters")]#text(" associated to ")#mi("{H_i}")#text(".")

#text("Note that if ")#mi("{\\sigma \\in \\text{Gal}(\\overline{{\\bf Q}}/{\\bf Q})}")#text(" is in the absolute Galois group of the rationals, then ")#mi("{\\sigma}")#text(" permutes the non-trivial linear characters of ")#mi("{H_i}")#text(". Applying ")#mi("{\\sigma}")#text(" to ")#link(<tao-558211ed72b2d6967037>)[#text("(15)")]#text(" and using the uniqueness of the set of exceptional characters, we conclude that ")#mi("{\\sigma}")#text(" also permutes the exceptional characters of ")#mi("{H_i}")#text(". On the other hand, from ")#link(<tao-558211ed72b2d6967037>)[#text("(15)")]#text(" we know that the exceptional characters of ")#mi("{H_i}")#text(" all agree outside of ")#mi("{\\bigcup_{g \\in G/N(H_i)} (gH_ig^{-1} \\backslash \\{1_G\\})}")#text(", and are thus fixed by the absolute Galois group in this region; in other words, they are rational outside of ")#mi("{\\bigcup_{g \\in G/N(H_i)} (gH_ig^{-1} \\backslash \\{1_G\\})}")#text(". On the other hand, as mentioned in the previous section, characters always take the values of algebraic integers. We conclude that")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10")]#text(" ")#metadata(none) <tao-a8961db5510c0f37a224>#text(" Any exceptional character for ")#mi("{H_i}")#text(" takes rational integer values outside of ")#mi("{\\bigcup_{g \\in G/N(H_i)} (gH_ig^{-1} \\backslash \\{1_G\\})}")#text(".")
]

#text("As remarked earlier, from ")#link(<tao-558211ed72b2d6967037>)[#text("(15)")]#text(" we see that ")#mi("{\\xi_{i,a}^* - \\xi_{i,b}^*}")#text(" is supported on the set ")#mi("{\\bigcup_{g \\in G/N(H_i)} (gH_ig^{-1} \\backslash \\{1_G\\})}")#text(". In particular, if ")#mi("{i}")#text(" and ")#mi("{j}")#text(" are distinct, and ")#mi("{a,b \\in \\{1,\\ldots,w_i\\}}")#text(" and ")#mi("{c,d \\in \\{1,\\ldots,w_j\\}}")#text(", then ")#mi("{\\xi_{i,a}^* - \\xi_{i,b}^*}")#text(" and ")#mi("{\\xi_{j,c}^* - \\xi_{j,d}^*}")#text(" are orthogonal. From this and the orthonormality of irreducible characters, we conclude (again using ")#link(<tao-26fba332169fb62ac0db>)[#text("(13)")]#text(") that ")#mi("{\\xi_{i,a}^*}")#text(" and ")#mi("{\\xi_{j,c}^*}")#text(" are distinct. Thus we see that the total number of exceptional characters in ")#mi("{\\sum_{i=1}^k w_i}")#text("; together with the trivial character, this gives ")#mi("{1+\\sum_{i=1}^k w_i}")#text(" distinct irreducible characters of ")#mi("{G}")#text(". On the other hand, observe that ")#mi("{H_i \\backslash \\{1_G\\}}")#text(", and hence ")#mi("{\\bigcup_{g \\in G/N(H_i)} (gH_ig^{-1} \\backslash \\{1_G\\})}")#text(", consists of ")#mi("{w_i}")#text(" conjugacy classes, and so from ")#link(<tao-24fe93c9e17cb80452e5>)[#text("(8)")]#text(" we see that the class number of ")#mi("{G}")#text(" is also ")#mi("{1 + \\sum_{i=1}^k w_i}")#text(". As these numbers match, we see that we have located ")#emph[#text("all")]#text(" of the irreducible characters of ")#mi("{G}")#text("; thus every non-principal irreducible character of ")#mi("{G}")#text(" is an exceptional character for some ")#mi("{H_i}")#text(".")

#text("Now that we have identified the irreducible characters of ")#mi("{G}")#text(", we can analyse other generalised characters in terms of them. We pick ")#mi("{i \\in \\{1,\\ldots,n\\}}")#text(" and consider the generalised character")

#align(center)[#tao-fit-display[#mitex("\\alpha_i = \\text{Ind}^G_{H_i} 1 - \\text{Ind}^G_{H_i} \\xi_{i,1}.")]]

#text("As with ")#link(<tao-61a54dbfaac2e0c574f4>)[#text("(14)")]#text(", ")#mi("{\\alpha_i}")#text(" is supported on ")#mi("{\\bigcup_{g \\in G/N(H_i)} (gH_ig^{-1} \\backslash \\{1_G\\})}")#text(" and when restricted to ")#mi("{H_i}")#text(", is equal to ")#metadata(none) <tao-b260539511e1699624d9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left|W_i\\right| - \\sum_{w \\in W_i} w\\xi_{i,1}.", block: true)]]

#text("In particular, from Plancherel’s theorem we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in G} \\left|\\alpha_i(x)\\right|^2 = \\frac{\\left|G\\right|}{\\left|N(H_i)\\right|} (\\left|W_i\\right|^2 + \\left|W_i\\right|) \\left|H_i\\right|", block: true)]]

#text("and hence (since ")#tao-math("{\\left|G\\right|/\\left|N(H_i)\\right| = \\left|W_i\\right|}", block: false)#text(") ")#metadata(none) <tao-97bb6198b18008ed8707>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\left\\| \\alpha_i \\right\\|_{L^2(G)^G}^2 = \\left|W_i\\right| + 1.", block: true)]]

#text("This is a bit too large of a norm to apply Lemma ")#link(<tao-f2030ff503b84ae45959>)[#text("4")]#text(" again, but ")#mi("{\\alpha_i}")#text(" is still only of moderate size (recall our enemy when trying to contradict ")#link(<tao-0889113e04d3203f0c40>)[#text("(9)")]#text(" is that the ")#tao-math("{\\left|W_i\\right|}", block: false)#text(" are too small, too frequently), and we can nevertheless use the ")#mi("{L^2(G)^G}")#text(" geometry of ")#mi("{\\alpha_i}")#text(" and the other known characters, together with the integrality gap, to limit how ")#mi("{\\alpha_i}")#text(" breaks up into irreducible components. Firstly, since the ")#mi("{w\\xi_{i,1}}")#text(" all have mean zero, we see that ")#link(<tao-b260539511e1699624d9>)[#text("(16)")]#text(" sums to ")#tao-math("{\\left|W_i\\right| \\left|H_i\\right|}", block: false)#text(" on ")#mi("{H_i}")#text(", and thus")

#align(center)[#tao-fit-display[#tao-math("\\langle \\alpha_i, 1 \\rangle_{L^2(G)^G} = \\frac{1}{\\left|G\\right|} \\frac{\\left|G\\right|}{\\left|N(H_i)\\right|} \\left|W_i\\right| \\left|H_i\\right| = 1.", block: true)]]

#text("Thus the Fourier coefficient of ")#mi("{\\alpha_i}")#text(" at the trivial representation is ")#mi("{1}")#text(". Next, we see that ")#link(<tao-b260539511e1699624d9>)[#text("(16)")]#text(" is orthogonal to ")#mi("{v\\xi_{i,a}-v\\xi_{i,b}}")#text(" for any ")#mi("{1 < a,b \\leq w_1}")#text(" and ")#mi("{v \\in W_i}")#text(", which upon summing on the conjugacy classes of ")#mi("{H_i}")#text(" and on ")#mi("{v}")#text(" gives that")

#align(center)[#tao-fit-display[#mitex("\\langle \\alpha_i, \\xi^*_{i,a} - \\xi^*_{i,b} \\rangle = 0.")]]

#text("Thus the Fourier coefficients of ")#mi("{\\alpha_i}")#text(" at the exceptional characters ")#mi("{\\xi^*_{i,a}}")#text(" for ")#mi("{a \\neq 1}")#text(" are all equal. Similarly, we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in H_i} (\\left|W_i\\right| - \\sum_{w \\in W_i} w\\xi_{i,1}(x)) (v\\xi_{i,1}(x)-v\\xi_{i,a}(x)) = - \\left|H_i\\right|", block: true)]]

#text("for any ")#mi("{1 < a \\leq w_1}")#text(" and ")#mi("{v \\in W_i}")#text(", so from ")#link(<tao-558211ed72b2d6967037>)[#text("(15)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\langle \\alpha_i, \\xi^*_{i,1} - \\xi^*_{i,a} \\rangle = - \\epsilon_i,")]]

#text("and so the Fourier coefficient at ")#mi("{\\xi^*_{i,1}}")#text(" is ")#mi("{-\\epsilon_1}")#text(" plus the Fourier coefficients at all the other exceptional characters at ")#mi("{H_i}")#text(". Next, for ")#mi("{j}")#text(" distinct from ")#mi("{i}")#text(" and ")#mi("{a,b \\in \\{1,\\ldots,w_j\\}}")#text(", we see from ")#link(<tao-558211ed72b2d6967037>)[#text("(15)")]#text(" that the generalised character ")#mi("{\\xi^*_{j,a}-\\xi^*_{j,b}}")#text(" is supported on ")#mi("{\\bigcup_{g \\in G/N(H_j)} (gH_jg^{-1} \\backslash \\{1_G\\})}")#text(", which by ")#link(<tao-24fe93c9e17cb80452e5>)[#text("(8)")]#text(" is disjoint from the support of ")#mi("{\\alpha_i}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\langle \\alpha_i, \\xi^*_{j,a} - \\xi^*_{j,b} \\rangle = 0.")]]

#text("Thus all the Fourier coefficients of ")#mi("{\\alpha_i}")#text(" at exceptional characters of ")#mi("{H_j}")#text(" are the same. We thus have obtained a decomposition of the form ")#metadata(none) <tao-e05e637226fb3efafb65>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\alpha_i = 1 + a_i \\sum_{k=1}^{w_i} \\xi^*_{i,k} - \\epsilon_i \\xi^*_{i,1} + \\sum_{j \\neq i} c_{i,j} \\sum_{k=1}^{w_j} \\xi^*_{j,k}")]]

#text("for some natural numbers ")#mi("{a_i, c_{i,j}}")#text(".")

#text("Taking ")#mi("{L^2(G)^G}")#text(" norms using the orthonormality of the irreducible characters, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|W_i\\right|+1 = 1 + (w_i-1) a_i^2 + (a_i-\\epsilon_i)^2 + \\sum_{j \\neq i} c_{i,j}^2 w_j.", block: true)]]

#text("Note that regardless of what ")#mi("{a_i}")#text(" is, the quantity ")#mi("{(w_i-1) a_i^2 + (a_i-\\epsilon_i)^2}")#text(" is always at least one, thanks to ")#link(<tao-26fba332169fb62ac0db>)[#text("(13)")]#text(". We thus obtain an upper bound on the ")#mi("{c_{i,j}}")#text(":")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j \\neq i} c_{i,j}^2 w_j \\leq \\left|W_i\\right| - 1.", block: true)]]

#text("In particular, from ")#link(<tao-26fba332169fb62ac0db>)[#text("(13)")]#text(" we see that there are not many ")#mi("{j}")#text(" for which ")#mi("{c_{i,j}}")#text(" is non-zero: ")#metadata(none) <tao-6c4440fc56c0f332b7c1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("\\left|\\{ j \\neq i: c_{i,j} \\neq 0 \\}\\right| \\leq \\frac{\\left|W_i\\right| - 1}{2}.", block: true)]]

#text("This is progress towards our goal of bounding ")#link(<tao-0889113e04d3203f0c40>)[#text("(9)")]#text(" (because it helps control ")#mi("{n}")#text("), except that we also need to deal with those ")#mi("{j}")#text(" for which ")#mi("{c_{i,j}}")#text(" is zero. For this, the generalised character ")#mi("{\\alpha_i}")#text(" will no longer be useful, but another character of small norm – namely, ")#mi("{\\sum_{k=1}^{w_i} \\xi^*_{i,k}}")#text(" – will be available as a substitute.")

#text("We turn to the details. Let ")#mi("{j}")#text(" be such that ")#mi("{c_{i,j}=0}")#text(". Then we return to ")#link(<tao-e05e637226fb3efafb65>)[#text("(18)")]#text(" and conclude that")

#align(center)[#tao-fit-display[#mitex("0 = 1 + a_i \\sum_{k=1}^{w_i} \\xi^*_{i,k} - \\epsilon_i \\xi^*_{i,1}")]]

#text("on the set ")#mi("{\\bigcup_{g \\in G/N(H_j)} (gH_jg^{-1} \\backslash \\{1_G\\})}")#text(". On this set, we know from Lemma ")#link(<tao-a8961db5510c0f37a224>)[#text("10")]#text(" that ")#mi("{\\sum_{k=1}^{w_i} \\xi^*_{i,k}}")#text(" is an integer. But furthermore, from Proposition ")#link(<tao-990cb8ebd0afb7150da4>)[#text("7")]#text(" we know that the exceptional characters ")#mi("{\\xi^*_{i,1},\\ldots,\\xi^*_{i,w_i}}")#text(" come in conjugate pairs, so in fact Lemma ")#link(<tao-a8961db5510c0f37a224>)[#text("10")]#text(" gives that ")#mi("{\\sum_{k=1}^{w_i} \\xi^*_{i,k}}")#text(" is an ")#emph[#text("even")]#text(" integer. We conclude that ")#mi("{\\xi^*_{i,1}}")#text(" is an odd integer on ")#mi("{\\bigcup_{g \\in G/N(H_j)} (gH_jg^{-1} \\backslash \\{1_G\\})}")#text(", and in particular, has magnitude at least ")#mi("{1}")#text(" on this set. As all the ")#mi("{\\xi^*_{i,1},\\ldots,\\xi^*_{i,w_1}}")#text(" agree outside of ")#mi("{\\bigcup_{g \\in G/N(H_i)} (gH_ig^{-1} \\backslash \\{1_G\\})}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{k=1}^{w_i} \\xi^*_{i,k}\\right| \\geq w_i", block: true)]]

#text("on ")#mi("{\\bigcup_{g \\in G/N(H_j)} (gH_jg^{-1} \\backslash \\{1_G\\})}")#text(". On the other hand, from the orthonormality of the ")#mi("{\\xi^*_{i,k}}")#text(" we know that ")#mi("{\\sum_{k=1}^{w_i} \\xi^*_{i,k}}")#text(" has an ")#mi("{L^2(G)^G}")#text(" norm of ")#mi("{w_i^{1/2}}")#text(". Since each set ")#mi("{\\bigcup_{g \\in G/N(H_j)} (gH_jg^{-1} \\backslash \\{1_G\\})}")#text(" has cardinality ")#tao-math("{\\left|G\\right| (\\frac{1}{\\left|W_j\\right|} - \\frac{1}{\\left|W_j\\right| \\left|H_j\\right|})}", block: false)#text(" (as was shown in the derivation of the class equation ")#link(<tao-0889113e04d3203f0c40>)[#text("(9)")]#text("), we conclude that ")#metadata(none) <tao-1d0f7e15d6ed1142469f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("\\sum_{j \\neq i: c_{i,j} = 0} \\frac{1}{\\left|W_j\\right|} - \\frac{1}{\\left|W_j\\right| \\left|H_j\\right|} \\leq \\frac{1}{w_i}.", block: true)]]

#text("We now have enough bounds on the various terms in ")#link(<tao-0889113e04d3203f0c40>)[#text("(9)")]#text(" to obtain the necessary contradiction to finish Suzuki’s theorem from an elementary (though admittedly ")#emph[#text("ad hoc")]#text(") analysis. It is convenient to order the subgroups ")#mi("{H_1,\\ldots,H_n}")#text(" so that ")#metadata(none) <tao-7c2ecd07f155648431e0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\left|W_1\\right| \\leq \\left|W_2\\right| \\leq \\ldots \\leq \\left|W_n\\right|.", block: true)]]

#text("We then write the right-hand side of ")#link(<tao-0889113e04d3203f0c40>)[#text("(9)")]#text(" as")

#tao-aligned(keep: true)[


#tao-math("\\frac{1}{\\left|G\\right|}  & + \\frac{1}{\\left|W_1\\right|} - \\frac{1}{\\left|W_1\\right| \\left|H_1\\right|}", block: true)



#tao-math(" & + \\sum_{j \\neq 1: c_{1,j}\\neq 0} \\frac{1}{\\left|W_j\\right|} - \\frac{1}{\\left|W_j\\right| \\left|H_j\\right|}", block: true)



#tao-math(" & + \\sum_{j \\neq 1: c_{1,j} = 0} \\frac{1}{\\left|W_j\\right|} - \\frac{1}{\\left|W_j\\right| \\left|H_j\\right|}.", block: true)
]

#text("For the first summation, we crudely bound ")#tao-math("{\\frac{1}{\\left|W_j\\right|} - \\frac{1}{\\left|W_j\\right| \\left|H_j\\right|}}", block: false)#text(" by ")#tao-math("{\\frac{1}{\\left|W_2\\right|}}", block: false)#text(" and use ")#link(<tao-6c4440fc56c0f332b7c1>)[#text("(19)")]#text("; for the second summation we use ")#link(<tao-1d0f7e15d6ed1142469f>)[#text("(20)")]#text(". We conclude from ")#link(<tao-0889113e04d3203f0c40>)[#text("(9)")]#text(" that ")#metadata(none) <tao-7b51cdcdd77c394216d4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#tao-math("1 \\leq \\frac{1}{\\left|G\\right|} + \\frac{1}{\\left|W_1\\right|} - \\frac{1}{\\left|W_1\\right| \\left|H_1\\right|} + \\frac{\\left|W_1\\right|-1}{2} \\frac{1}{\\left|W_2\\right|} + \\frac{1}{w_1}", block: true)]]

#text("and thus (bounding ")#tao-math("{1/\\left|G\\right|}", block: false)#text(" by ")#tao-math("{1/\\left|N(H_1)\\right| = 1/(\\left|W_1\\right| \\left|H_1\\right|)}", block: false)#text(" and ")#tao-math("{\\frac{1}{\\left|W_2\\right|}}", block: false)#text(" by ")#tao-math("{\\frac{1}{\\left|W_1\\right|}}", block: false)#text(")")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} \\leq \\frac{1}{2\\left|W_1\\right|} + \\frac{1}{w_1}.", block: true)]]

#text("Applying ")#link(<tao-eb8f90e771df9356494d>)[#text("(10)")]#text(", we conclude that ")#mi("{w_1 \\leq 3}")#text(", which forces ")#mi("{w_1=2}")#text(" since ")#mi("{w_1}")#text(" is even. Since ")#tao-math("{w_1 = (\\left|H_1\\right|-1)/\\left|W_1\\right|}", block: false)#text(", we conclude that ")#tao-math("{\\left|H_1\\right|=2\\left|W_1\\right|+1}", block: false)#text(". We use this to return to the bound ")#link(<tao-7b51cdcdd77c394216d4>)[#text("(22)")]#text(" to obtain")

#align(center)[#tao-fit-display[#tao-math("1 \\leq \\frac{1}{\\left|G\\right|} + \\frac{1}{\\left|W_1\\right|} - \\frac{1}{\\left|W_1\\right| (2\\left|W_1\\right|+1)} + \\frac{\\left|W_1\\right|-1}{2} \\frac{1}{\\left|W_2\\right|} + \\frac{1}{2}", block: true)]]

#text("and hence")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} \\leq \\frac{1}{\\left|G\\right|} + \\frac{2}{2\\left|W_1\\right|+1} + \\frac{\\left|W_1\\right|-1}{2} \\frac{1}{\\left|W_2\\right|}.", block: true)]]

#text("If ")#tao-math("{\\left|W_2\\right| \\geq \\left|W_1\\right|+2}", block: false)#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\left|W_1\\right|-1}{2} \\frac{1}{\\left|W_2\\right|} \\leq \\frac{1}{2} - \\frac{3}{2\\left|W_1\\right|+4}", block: true)]]

#text("and so")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|G\\right|} \\geq \\frac{3}{2\\left|W_1\\right|+4} - \\frac{2}{2\\left|W_1\\right|+1} = \\frac{2\\left|W_1\\right|-5}{(2\\left|W_1\\right|+4)(2\\left|W_1\\right|+1)}", block: true)]]

#text("and so ")#metadata(none) <tao-1917d730c88ed0f6fd76>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#tao-math("\\left|G\\right| \\leq \\frac{(2\\left|W_1\\right|+4)(2\\left|W_1\\right|+1)}{2\\left|W_1\\right|-5}.", block: true)]]

#text("On the other hand")

#align(center)[#tao-fit-display[#tao-math("\\left|G\\right| \\geq \\left|N(H_1)\\right| = \\left|W_1\\right| (2\\left|W_1\\right|+1).", block: true)]]

#text("The two bounds are inconsistent for ")#tao-math("{\\left|W_1\\right| \\geq 5}", block: false)#text(", so we have ")#tao-math("{\\left|W_1\\right|=3}", block: false)#text(" from ")#link(<tao-eb8f90e771df9356494d>)[#text("(10)")]#text(" (and the odd nature of ")#tao-math("{\\left|W_1\\right|}", block: false)#text("), which then gives the upper bound ")#tao-math("{\\left|G\\right| \\leq 70}", block: false)#text(" from ")#link(<tao-1917d730c88ed0f6fd76>)[#text("(23)")]#text(", and Suzuki’s theorem can be verified by classical computations for the odd non-abelian groups of order less than ")#mi("{70}")#text(" (of which there are actually not that many); alternatively one can use ")#link(<tao-672bb8bd1165a0140195>)[#text("(11)")]#text(", Lemma ")#link(<tao-65f889b5c3c0a87da208>)[#text("9")]#text(", and ")#link(<tao-07ed400759a0f606a8b5>)[#text("(12)")]#text(" to eliminate this case (as no odd number less than ")#mi("{70}")#text(" has more than three prime factors). So the only remaining case is when ")#mi("{w_1=2}")#text(" and ")#tao-math("{\\left|W_2\\right|=\\left|W_1\\right|}", block: false)#text(". In this case we may interchange the indices ")#mi("{1}")#text(" and ")#mi("{2}")#text(" (which does not affect ")#link(<tao-7c2ecd07f155648431e0>)[#text("(21)")]#text(") and repeating the above arguments we may thus also assume that ")#mi("{w_2=2}")#text(". Since ")#tao-math("{w_i = (\\left|H_i\\right|-1)/\\left|W_i\\right|}", block: false)#text(", we conclude that ")#tao-math("{\\left|H_1\\right|=\\left|H_2\\right|}", block: false)#text(". But this contradicts Lemma ")#link(<tao-65f889b5c3c0a87da208>)[#text("9")]#text(", and Suzuki’s theorem is proved.")

#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3a091886de766ef1b7c3e68f9f5c3512017269674ceb526ef44e70e71b2dc39c-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Shved")]], [#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/#comment-224045")[#strong[#text("Daniel Shved")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2013")])]

#text("There seems to be an excess ")#mi("-1")#text(" when counting elements in the Frobenius kernel:")#linebreak()#text(" ")#tao-math("\\left|K\\right| = \\left|G\\right| - 1 - \\frac{\\left|G\\right|}{\\left|H\\right|}(\\left|H\\right|-1) = \\left|G\\right|/\\left|H\\right|", block: false)#text(".")

#emph[#text("[Oops, I see what you’re saying now; corrected, thanks. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/948cf670d00e7f4cdc4970b359b505177558fba4ff6aa6856d78f7040fb0c52c-6ac7ef4a85a3a746437c3c59a65acdadeeef4f38e7d0011a3368e1f09629dbf2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yulanqing")]], [#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/#comment-224054")[#strong[#text("yulanqing")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2013")])]

#text("Reblogged this on ")#link("http://themindsplace.wordpress.com/2013/04/13/the-theorems-of-frobenius-and-suzuki-on-finite-groups/")[#text("The Mind's Place")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3d673fb32d9c24608594a70e088a3b49d1c94b28ccf14d81c0e75ddf8ed1fca-ac25f8bff55160d5ff71baff4d6997f506abbdb2034e48fe84bf880a149ce79d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L’enorme teorema | In teoria")]], [#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/#comment-224087")[#strong[#text("L’enorme teorema | In teoria")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2013")])]

#text("[…] sempre l’ispirazione proviene da questo blog, fonte poderosa di fatti […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6429fa47227555ee0fbc9aa0f6a21d9b4f7e76462d53f1c6133995ff382ef536-6a63e284c3afdca0ee7fd24ff8261cd208690a207a9e7de8501f8af6e0db9db5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.Hahn")]], [#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/#comment-224112")[#strong[#text("J.Hahn")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2013")])]

#text("Hi.")

#text("Being a group theorist at heart and not currently having so much time for group theory anymore, I really enjoyed this blog post.")

#text("I noticed some minor errors:")#linebreak()#text(" * In the proof of Prop. 7 it should be ")#mi("\\chi(1)")#text(" instead of ")#mi("\\chi(0)")#text(".")#linebreak()#text(" * Right after (13) the ")#mi("\\xi")#text(" and ")#mi("\\xi^{\\prime}")#text(" are elements of ")#mi("\\hat{H_i}")#text(" and not elements of ")#mi("H_i")#text(".")#linebreak()#text(" * Between formulas (19) and (20) and in (20) there are some curly braces missing I think.")#linebreak()#text(" * Just before formula (22) the link for formula (19) points to (17) instead of (19).")

#text("Thanks again for this blog post.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a6bee1212dbf833d9ad3435c6b74d5ee33af521466417195fd7b5cf8df6dbc7a-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Shved")]], [#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/#comment-224202")[#strong[#text("Daniel Shved")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2013")])]

#text("I’m working through the post with great interest. Even though I’m familiar with (a very modest) part of the material, it looks much clearer than it was in my head. I especially like your pace which is way faster than usually seen in textbooks. Thanks a lot!")

#text("Here are some more typos I’ve found:")

#text("– In the Parseval identity (or Plancherel, I’m not sure which is which):")#linebreak()#text(" ")#mi("\\displaystyle  \\langle f_1,f_2 \\rangle_{L^2(G)^G} = \\langle f_1, f_2 \\rangle_{\\ell^2(G)}")#linebreak()#text(" It seems like some hats are missing on the right hand side. Also, ")#mi("G")#text(" appears without a hat in ")#mi("\\ell^2(G)")#text(" in these two equalities and in the text right below them.")

#text("– In the equality that states that induced characters are characters of induced representations:")#linebreak()#text(" ")#mi("\\displaystyle  \\text{Ind}^H_G \\chi_\\rho = \\chi_{\\text{Ind}^H_G \\rho}")#linebreak()#text(" ")#mi("\\text{Ind}^H_G")#text(" is upside down (should be ")#mi("\\text{Ind}^G_H")#text(").")

#text("– In the proof of Frobenius theorem, when the induced character ")#mi("{\\text{Ind}^G_H \\chi_\\xi}")#text(" first appears, there is this phrase: “Using the above identities and the partition (5), we see that ")#mi("{\\text{Ind}^G_H \\chi_\\xi}")#text(" equals ")#tao-math("{d \\left|G\\right|/\\left|H\\right|}", block: false)#text(" at ")#mi("{1_G}")#text(".” For some reason the closing | is not displayed in the denominator of |G|/|H|. It is there in the LaTeX code, but doesn’t display correctly. The same quirk happened in my first comment to this post. Maybe this is a wordpress bug? Maybe due to some unimaginable reasons | is ignored when it is the last symbol in a formula?")

#text("– The very next formula says:")#linebreak()#text(" ")#tao-math("\\displaystyle \\sum_{x \\in G \\backslash K} \\left|\\text{Ind}^G_H \\chi_\\xi(x)\\right|^2 = \\frac{\\left|G\\right|}{\\left|H\\right|} (\\left|H\\right|-d).", block: false)#linebreak()#text(" Looks like ")#mi("d")#text(" should be squared.")

#emph[#text("[Corrected, thanks. I was not able to reproduce the issue in your third bullet point, the | signs seem to be rendering fine to me. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da0b0eef4bc9fc2fc8b4c2f5f11e9db93f9ba007cc26e260c5743c2f41510ed6-a9a2604e5dfd7eb6dda7531813f331032f1679105ac4edce0bb9fdcb0dd3a5b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious")]], [#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/#comment-226355")[#strong[#text("Curious")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2013")])]

#text("Dear prof Tao,")#linebreak()#text(" If you were forced to answer, would would you answer to whether the universe is mathematical or whether math is only an approximation? What do you think about string theory?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/#comment-493634")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2018")])]

#text("A possible answer is in Tegmark’s book “Our mathematical universe”. See also the wikipedia article on the mathematical universe hypotheses.")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/Mathematical_universe_hypothesis")[#text("https://en.wikipedia.org/wiki/Mathematical_universe_hypothesis")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quasirandom groups and a cheap version of the Brauer-Fowler theorem | What's new")]], [#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/#comment-227355")[#strong[#text("Quasirandom groups and a cheap version of the Brauer-Fowler theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2013")])]

#text("[…] theorem can be proven by a nice application of character theory, of the type discussed in this recent blog post, ultimately based on analysing the alternating tensor power of representations; I reproduce a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66e1ac16afb6d03d35e1a2eb8c26582906d842f8013fb72d61dfd34b2728df66-efafb9c34f2d60adffb56d5c44bcc4954659b353ae072183d2bd2cb5d70621fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of b98201031")]], [#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/#comment-227409")[#strong[#text("b98201031")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2013")])]

#text("I enjoyed that article.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A Fourier-analytic proof of Frobenius’ theorem | What's new")]], [#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/#comment-231343")[#strong[#text("A Fourier-analytic proof of Frobenius’ theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2013")])]

#text("[…] discussed Frobenius’ theorem and its proof in this recent blog post. This proof uses the theory of characters on a finite group , in particular relying on the fact […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec7c6b0e3060e1c806f619bf4b492030a739cda006aaf0a178402739ff75194-2c3659f7497f4bb1cf1e6e85fafd68a9d10b53737c2f3b03f29c35b080ae39ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/#comment-232449")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2013")])]

#text("I quite like the idea that CA-groups are easier, and groups of Lie type are nearly CA. Too bad CA-groups are never nonabelian simple.")

#text("It makes me wonder whether there’s a measure of how non-CA a group is, such that Suzuki’s arguments might extend to groups that are nearly CA. (Naively, the fraction of elements whose C are not A, but quite likely some subtler version thereof.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/#comment-232459")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2013")])]

#text("Yes, this is something I would like to understand better myself. One of the funny things coming out of Suzuki’s analysis is that to every (Weyl group conjugacy class of a) character ")#mi("\\xi_{i,a}")#text(" on a (conjugacy class of a) maximal abelian subgroup ")#mi("H_i")#text(" of G there is associated an “exceptional character” ")#mi("\\xi^*_{i,a}")#text(" of G which is a component of the induced representation of G coming from the character of ")#mi("H_i")#text(" (or sometimes, a bit weirdly, it is an “anti-component”, if the sign ")#mi("\\epsilon_i")#text(" is negative), and that in a CA group these exceptional characters actually end up occupying all the non-trivial characters of G. So in a Lie group of bounded rank, which is almost CA, one would expect the (Weyl group conjugacy classes of) characters of a maximal torus to be associated somehow with special characters on the Lie group, and that “most” characters on the Lie group should actually arise in this way. Presumably this is what Deligne-Luzstig theory is about, and learning more about that theory is on my “to do” list, but I don’t have much more to say about this at this point. One annoying thing is that the way that the exceptional character ")#mi("\\xi^*_{i,a}")#text(" is generated from ")#mi("\\xi_{i,a}")#text(" is “non-functorial”; it doesn’t come from the categorical operations on representations (induction, direct sum, orthocomplement, etc.) but instead weirdly emerges from the integrality gap (Lemma 4 in the post) which is a way to easily produce characters without saying much of anything about their associated representations. I don’t yet know if this disconnect is really there, or if there are some other ways to construct representations that are somehow behind exceptional character theory (but again Deligne-Luzstig theory is presumably a big clue in this regard).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2265d3131054ee83ce22cb7f77c8da1391dc9b960781e44779facc82ab1e110-d4d61fd903248e1d78236db441cb6ff5e4c58851d1b5e2725bf0a8312dacd308.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DG")]], [#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/#comment-236500")[#strong[#text("DG")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2013")])]

#text("Is there a citable reference to the “theorem of Frobenius from 1901”, and to the original definitions of Frobenius group/kernel/complement? Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/#comment-236505")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2013")])]

#text("The original reference is")

#text("G. Frobenius, “Ueber auflösbare Gruppen IV” Sitzungsber. Preuss. Akad. Wissenschaft. (1901) pp. 1216–1230")

#text("but it may be difficult to locate (see ")#link("http://math.stackexchange.com/questions/222167/where-can-i-find-the-original-papers-by-frobenius-concerning-solutions-to-xn")[#text("http://math.stackexchange.com/questions/222167/where-can-i-find-the-original-papers-by-frobenius-concerning-solutions-to-xn")]#text(" for some related discussion). A somewhat more modern reference is")

#text("I.M. Isaacs, “Character theory of finite groups” , Acad. Press (1976)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2265d3131054ee83ce22cb7f77c8da1391dc9b960781e44779facc82ab1e110-d4d61fd903248e1d78236db441cb6ff5e4c58851d1b5e2725bf0a8312dacd308.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DG")]], [#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/#comment-236511")[#strong[#text("DG")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2013")])]

#text("Thankyou very much!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/#comment-254991")[#strong[#text("Frobenius groups and vibrating molecules (Dec. 2-6) | Bilinear Forms & Group Representations: MATH 5657")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2013")]

#text("[…] help with understanding their structure. The stuff I want to cover is in the intro and Section 2 of this blog post. The rest of the post is quite interesting as well, but is more than we’ll have time to get […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23a76671b6e2742d438378853cca64cbc2cc3dd037a843908eba8a1ac13e3285-b7bc0831a14d4317468eee915248ef4a55a812510f08531b14ae20e203e7e50b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Geline")]], [#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/#comment-493628")[#strong[#text("Michael Geline")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2018")])]

#text("Hi. Another of the “museum piece” applications of characters to finite groups is Burnside’s theorem which says a transitive permutation group of prime degree ")#mi("p")#text(" is either doubly transitive or has a normal Sylow ")#mi("p")#text("-subgroup. This implies right away that a non-abelian finite simple group cannot have a subgroup of prime index for any prime. A group of odd order cannot act doubly transitively! However, I’m pretty sure that arguments like this play no role in Feit Thompson argument.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/#comment-499001")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2018")])]

#text("Thanks for the post. I think I’m misunderstanding something basic or you have a small mistake; when you give the second definition of an induced function, it should be the sum over f(g_i ^-1 x g_i) and not f(g_i x g_i ^-1), or alternatively you can a tranversal over right cosets and not left cosets.")
]
