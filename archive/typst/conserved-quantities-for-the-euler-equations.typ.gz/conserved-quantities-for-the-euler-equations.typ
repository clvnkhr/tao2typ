// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/
// Converted to Typst by tao2typ: "2026-10-14T16:37:21.741047+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Conserved quantities for the Euler equations", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Conserved quantities for the Euler equations")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 February 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/")[#text("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://en.wikipedia.org/wiki/Euler_equations_(fluid_dynamics)")[#text("Euler equations")]#text(" for incompressible inviscid fluids may be written as")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u + (u \\cdot \\nabla) u  & = -\\nabla p", block: true)



#tao-math("\\nabla \\cdot u  & = 0", block: true)
]

#text("where ")#mi("{u: [0,T] \\times {\\bf R}^n \\rightarrow {\\bf R}^n}")#text(" is the velocity field, and ")#mi("{p: [0,T] \\times {\\bf R}^n \\rightarrow {\\bf R}}")#text(" is the pressure field. To avoid technicalities we will assume that both fields are smooth, and that ")#mi("{u}")#text(" is bounded. We will take the dimension ")#mi("{n}")#text(" to be at least two, with the three-dimensional case ")#mi("{n=3}")#text(" being of course especially interesting.")

#text("The Euler equations are the inviscid limit of the Navier-Stokes equations; as discussed in ")#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/")[#text("my previous post")]#text(", one potential route to establishing finite time blowup for the latter equations when ")#mi("{n=3}")#text(" is to be able to construct “computers” solving the Euler equations, which generate smaller replicas of themselves in a noise-tolerant manner (as the viscosity term in the Navier-Stokes equation is to be viewed as perturbative noise).")

#text("Perhaps the most prominent obstacles to this route are the ")#emph[#text("conservation laws")]#text(" for the Euler equations, which limit the types of final states that a putative computer could reach from a given initial state. Most famously, we have the conservation of energy ")#metadata(none) <tao-381cfb6e1e428419d5d6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\int_{{\\bf R}^n} \\left|u\\right|^2\\ dx", block: true)]]



#text(" (assuming sufficient decay of the velocity field at infinity); thus for instance it would not be possible for a computer to generate a replica of itself which had greater total energy than the initial computer. This by itself is not a fatal obstruction (in ")#link("http://arxiv.org/abs/1402.0290")[#text("this paper of mine")]#text(", I constructed such a “computer” for an averaged Euler equation that still obeyed energy conservation). However, there are other conservation laws also, for instance in three dimensions one also has conservation of ")#link("http://en.wikipedia.org/wiki/Helicity_(fluid_mechanics)")[#text("helicity")]#text(" ")#metadata(none) <tao-933c53c574d35179d3f7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\int_{{\\bf R}^3} u \\cdot (\\nabla \\times u)\\ dx")]]



#text(" and (formally, at least) one has conservation of momentum")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^3} u\\ dx")]]

#text("and angular momentum")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^3} x \\times u\\ dx")]]

#text("(although, as we shall discuss below, due to the slow decay of ")#mi("{u}")#text(" at infinity, these integrals have to either be interpreted in a principal value sense, or else replaced with their vorticity-based formulations, namely impulse and moment of impulse). Total vorticity")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^3} \\nabla \\times u\\ dx")]]

#text("is also conserved, although it turns out in three dimensions that this quantity vanishes when one assumes sufficient decay at infinity. Then there are the pointwise conservation laws: the vorticity and the volume form are both transported by the fluid flow, while the velocity field (when viewed as a covector) is transported up to a gradient; among other things, this gives the transport of vortex lines as well as ")#link("http://en.wikipedia.org/wiki/Kelvin's_circulation_theorem")[#text("Kelvin’s circulation theorem")]#text(", and can also be used to deduce the helicity conservation law mentioned above. In my opinion, none of these laws actually prohibits a self-replicating computer from existing within the laws of ideal fluid flow, but they do significantly complicate the task of actually designing such a computer, or of the basic “gates” that such a computer would consist of.")

#text("Below the fold I would like to record and derive all the conservation laws mentioned above, which to my knowledge essentially form the complete set of known conserved quantities for the Euler equations. The material here (although not the notation) is drawn from ")#link("http://www.ams.org/mathscinet-getitem?mr=1867882")[#text("this text of Majda and Bertozzi")]#text(".")

#metadata(none) <tao-75deb27375c9aea860f4>

#text("For reasons which may become clearer later, I will rewrite the Euler equations in the language of Riemannian geometry, in particular, using the ")#link("http://en.wikipedia.org/wiki/Abstract_index_notation")[#text("abstract index notation")]#text(" of Penrose), and using the Euclidean metric ")#mi("{\\eta_{ij}}")#text(" on ")#mi("{{\\bf R}^n}")#text(" to raise and lower indices, and to define the covariant derivative ")#mi("{\\nabla_i}")#text(" through the Levi-Civita connection (which, in Cartesian coordinates, is just the usual partial derivative ")#mi("{\\partial_i}")#text(" evaluated componentwise). The velocity field ")#mi("{u}")#text(" now is written as ")#mi("{u^i}")#text("; contracting against the metric ")#mi("{\\eta}")#text(" gives a ")#mi("{1}")#text("-form ")#mi("{u_i := \\eta_{ij} u^j}")#text(", which I will call the ")#emph[#text("covelocity")]#text(", and also write as ")#mi("{u^*}")#text(". The Euler equations then become")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u^i + u^j \\nabla_j u^i  & = - \\nabla^i p", block: true)



#tao-math("\\nabla_i u^i  & = 0.", block: true)
]

#text("In particular we have")

#tao-aligned(keep: true)[


#tao-math("\\partial_t \\left|u\\right|^2  & = 2 u_i \\partial_t u^i", block: true)



#tao-math(" & = - 2 u_i u^j \\nabla_j u^i - 2 u_i \\nabla^i p", block: true)



#tao-math(" & = - \\nabla_j (u^j u_i u^i) - 2 \\nabla^i (u_i p)", block: true)
]

#text("which leads to the conservation of energy ")#link(<tao-381cfb6e1e428419d5d6>)[#text("(1)")]#text(" upon integrating in space.")

#text("In the usual treatment of the Euler equations, it is common to introduce the ")#link("http://en.wikipedia.org/wiki/Material_derivative")[#text("material derivative")]

#align(center)[#tao-fit-display[#mitex("D_t = \\partial_t + u \\cdot \\nabla.")]]

#text("Here, we shall adopt the subtly different (but closely related) approach of using the ")#emph[#text("material Lie derivative")]

#align(center)[#tao-fit-display[#mitex("{\\cal D}_t := \\partial_t + {\\cal L}_u")]]

#text("where ")#mi("{{\\cal L}_u}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Lie_derivative")[#text("Lie derivative")]#text(" along the vector field ")#mi("{u}")#text(". For scalar fields ")#mi("{f}")#text(", the material Lie derivative is the same as the material derivative:")

#align(center)[#tao-fit-display[#mitex("{\\cal D}_t f = D_t f = \\partial_t f + u^i \\nabla_i f.")]]

#text("However, the two notions differ when applied to vector fields or forms, with the material Lie derivative having better covariance properties than the material derivative. When applied to vector fields ")#mi("{X^i}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("{\\cal L}_u X^i = u^j \\nabla_j X^i - X^j \\nabla_j u^i")]]

#text("and so")

#align(center)[#tao-fit-display[#mitex("{\\cal D}_t X^i = D_t X^i - X^j \\nabla_j u^i.")]]

#text("Similarly, for ")#mi("{1}")#text("-forms ")#mi("{\\lambda_i}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("{\\cal L}_u \\lambda_i = u^j \\nabla_j \\lambda_i + \\lambda_j \\nabla_i u^j,")]]

#text("and similarly for ")#mi("{2}")#text("-forms ")#mi("{\\omega_{ij}}")#text(" we have ")#metadata(none) <tao-cccf52f3d03c5072ee64>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("{\\cal L}_u \\omega_{ij} = u^k \\nabla_k \\omega_{ij} + \\omega_{kj} \\nabla_i u^k + \\omega_{ik} \\nabla_j u^k")]]



#text(" leading to similar formulae comparing ")#mi("{{\\cal D}_t}")#text(" and ")#mi("{D_t}")#text(" for forms.")

#text("Since ")#mi("{{\\cal L}_u u = 0}")#text(", the material Lie derivative of the velocity field ")#mi("{u^i}")#text(" is just the time derivative:")

#align(center)[#tao-fit-display[#mitex("{\\cal D}_t u^i = \\partial_t u^i = - u^j \\nabla_j u^i - \\nabla^i p.")]]

#text("The material Lie derivative of the ")#emph[#text("covelocity")]#text(" field ")#mi("{u_i}")#text(" is however more interesting:")

#tao-aligned(keep: true)[


#tao-math("{\\cal D}_t u_i  & = \\partial_t u_i + u^j \\nabla_j u_i + u^j \\nabla_i u_j", block: true)



#tao-math(" & = - \\nabla_i p + \\nabla_i( \\frac{1}{2} \\left|u\\right|^2 )", block: true)



#tao-math(" & = \\nabla_i( - p + \\frac{1}{2} \\left|u\\right|^2 ).", block: true)
]

#text("In particular, we see that the material Lie derivative of the covelocity is a gradient: ")#metadata(none) <tao-9c94177dd9b5bd1d30ba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("{\\cal D}_t u^* = d( -p + \\frac{1}{2} \\left|u\\right|^2 ).", block: true)]]



#text(" Since the integral of a gradient along any closed loop is zero, we obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Kelvin’s circulation theorem)")]#text(" Let ")#mi("{\\gamma: [0,T] \\times S^1 \\rightarrow {\\bf R}^n}")#text(" be a time-dependent loop in ")#mi("{{\\bf R}^n}")#text(" which is transported by the flow (thus ")#mi("{\\partial_t F(t,\\gamma(t,s)) = {\\cal D}_t F( t, \\gamma(t,s))}")#text(" for any scalar function ")#mi("{F: [0,T] \\times {\\bf R}^n \\rightarrow {\\bf R}}")#text("). Then")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\int_\\gamma u^* = 0.")]]
]

#text("Now we take an exterior derivative of the covelocity ")#mi("{u^*}")#text(" to obtain the ")#emph[#text("vorticity")]

#align(center)[#tao-fit-display[#mitex("\\omega := d u^*.")]]

#text("In abstract index notation, ")#mi("{\\omega}")#text(" is the ")#mi("{2}")#text("-form")

#align(center)[#tao-fit-display[#mitex("\\omega_{ij} = \\nabla_i u_j - \\nabla_j u_i.")]]

#text("As exterior derivatives commute with diffeomorphisms, they also commute with Lie derivatives, so in particular")

#align(center)[#tao-fit-display[#mitex("{\\cal D}_t \\omega = d( {\\cal D}_t u^* ).")]]

#text("Since ")#mi("{{\\cal D}_t u^*}")#text(" was a gradient, its exterior derivative vanishes, and we thus have ")#emph[#text("transport of vorticity")]#text(": ")#metadata(none) <tao-9477dda6f1a441d0c73f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("{\\cal D}_t \\omega = 0.")]]



#text(" (This fact was also interpreted as conservation of exterior momentum in ")#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/")[#text("this previous blog post")]#text(".) This fact also follows from Kelvin’s circulation theorem, after first applying Stokes’ theorem to rewrite ")#mi("{\\int_\\gamma u^*}")#text(" as ")#mi("{\\int_S \\omega}")#text(" for a spanning surface ")#mi("{S}")#text(" that is transported by the flow.")

#text("If we let ")#mi("{\\text{vol}}")#text(" be the usual volume ")#mi("{n}")#text("-form on ")#mi("{{\\bf R}^n}")#text(", then the divergence-free nature of ")#mi("{u}")#text(" (and the time-independent nature of ")#mi("{\\text{vol}}")#text(") implies that ")#mi("{\\text{vol}}")#text(" is also transported by the flow: ")#metadata(none) <tao-e30e2670f20406ab276c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("{\\cal D}_t \\text{vol} = 0.")]]



#text(" If we thus define the ")#emph[#text("polar vorticity")]#text(" ")#mi("{*\\omega}")#text(" to be the ")#mi("{n-2}")#text("-vector that is the Hodge star of ")#mi("{\\omega}")#text(" with respect to this volume form, thus")

#align(center)[#tao-fit-display[#mitex("*\\omega( v ) \\text{vol} = \\omega \\wedge v")]]

#text("for all ")#mi("{n-2}")#text("-forms ")#mi("{v}")#text(", then we see from ")#link(<tao-9477dda6f1a441d0c73f>)[#text("(5)")]#text(", ")#link(<tao-e30e2670f20406ab276c>)[#text("(6)")]#text(" that the polar vorticity is also transported by the flow: ")#metadata(none) <tao-f77f484ce99781cbf892>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("{\\cal D}_t *\\omega = 0.")]]





#text("In two dimensions ")#mi("{n=2}")#text(", the polar vorticity ")#mi("{*\\omega}")#text(" is just a scalar, which by abuse of notation is also denoted ")#mi("{\\omega}")#text(" (in coordinates, ")#mi("{\\omega=\\partial_1 u_2 - \\partial_2 u_1}")#text("), and ")#link(<tao-f77f484ce99781cbf892>)[#text("(7)")]#text(" becomes the well-known transport of scalar vorticity:")

#align(center)[#tao-fit-display[#mitex("D_t \\omega = 0.")]]

#text("In three dimensions ")#mi("{n=3}")#text(", ")#mi("{*\\omega = \\omega^i}")#text(" is a vector field which by abuse of notation is also denoted ")#mi("{\\omega}")#text(" (in coordinates, ")#mi("{\\omega = \\nabla \\times u}")#text("), and ")#link(<tao-f77f484ce99781cbf892>)[#text("(7)")]#text(" becomes the well-known vorticity equation:")

#align(center)[#tao-fit-display[#mitex("D_t \\omega^i = \\omega^j \\nabla_j u^i.")]]

#text("From ")#link(<tao-f77f484ce99781cbf892>)[#text("(7)")]#text(" we also see that the ")#link("http://en.wikipedia.org/wiki/Vortex_line")[#text("vortex lines")]#text(" are transported by the flow; in fact we have the stronger statement that if ")#mi("{\\gamma: [0,T] \\times {\\bf R} \\rightarrow {\\bf R}^3}")#text(" is transported by the flow and obeys")

#align(center)[#tao-fit-display[#mitex("\\partial_s \\gamma^i(t,s) = \\omega^i( \\gamma(t,s) )")]]

#text("at the initial time ")#mi("{t=0}")#text(", then it continues to do so at all later times ")#mi("{t}")#text(".")

#text("In three dimensions, we may contract the polar vorticity ")#mi("{\\omega^i}")#text(" against the covelocity ")#mi("{u_i}")#text(" to obtain a scalar ")#mi("{u \\cdot \\omega}")#text(". We may then combine ")#link(<tao-f77f484ce99781cbf892>)[#text("(7)")]#text(" and ")#link(<tao-9c94177dd9b5bd1d30ba>)[#text("(4)")]#text(" to obtain")

#align(center)[#tao-fit-display[#tao-math("{\\cal D}_t (u \\cdot \\omega) = \\omega^i \\partial_i( -p + \\frac{1}{2} \\left|u\\right|^2 ) = {\\cal L}_{*\\omega}( -p + \\frac{1}{2} \\left|u\\right|^2 ).", block: true)]]

#text("Now the exterior derivative of ")#mi("{\\omega = du^*}")#text(" vanishes, so that ")#mi("{*\\omega}")#text(" is divergence-free, and so ")#mi("{{\\cal L}_{*\\omega}}")#text(" annihilates ")#mi("{\\text{vol}}")#text(". We therefore conclude conservation of helicity ")#link(<tao-933c53c574d35179d3f7>)[#text("(2)")]#text(". In fact we conclude the stronger statement that if ")#mi("{\\Omega}")#text(" is any time-dependent region in ")#mi("{{\\bf R}^3}")#text(" which is preserved by ")#mi("{\\omega}")#text(" (i.e. it is the union of vortex lines) and is transported by the flow, then ")#mi("{\\int_\\Omega (u \\cdot \\omega)\\ \\text{vol}}")#text(" is conserved in time. This is consistent with Kelvin’s circulation theorem, since one can use Fubini’s theorem to compute the integral ")#mi("{\\int_\\Omega (u \\cdot \\omega)\\ \\text{vol}}")#text(" by first computing the integral of ")#mi("{u^*}")#text(" on each of the vortex lines in ")#mi("{\\Omega}")#text(", and then integrating against ")#mi("{\\omega}")#text(" on the space of vortex lines in ")#mi("{\\Omega}")#text(" (which is a two-dimensional space on which ")#mi("{\\omega}")#text(" naturally descends to become an area form. All of these quantities are transported by the flow.")

#text("Finally, we consider the conservation of various moments of the velocity and vorticity. Here it is best to return to material derivatives ")#mi("{D_t}")#text(" instead of material Lie derivatives ")#mi("{{\\cal D}_t}")#text(", basically because the flow along ")#mi("{u}")#text(" does not preserve the Euclidean metric ")#mi("{\\eta_{ij}}")#text(" or the flat connection ")#mi("{\\nabla}")#text(", making the interchange of Lie derivatives with the integration of vector-valued quantities a little tricky.")

#text("Because we will be considering linear integrals of ")#mi("{u}")#text(" or ")#mi("{\\omega}")#text(" rather than quadratic integrals, there can be some difficulty in ensuring absolute integrability of the integrals used; for instance, in three dimensions the ")#link("http://en.wikipedia.org/wiki/Biot-savart_law")[#text("Biot-Savart law")]#text(" ")#mi("{u = -\\nabla \\times \\Delta^{-1} \\omega}")#text(" suggests that ")#mi("{u}")#text(" could decay as slowly as ")#tao-math("{1/\\left|x\\right|^2}", block: false)#text(", even if the vorticity is compactly supported. However, the vorticity transport equation ")#link(<tao-f77f484ce99781cbf892>)[#text("(7)")]#text(" tells us (in any dimension) that if the vorticity is compactly supported at time zero, then it remains compactly supported at later times (with the support being transported by the flow). In practice, this means that we will be able to justify operations such as integration by parts if there is at least one factor of the vorticity present.")

#text("We begin with the total vorticity")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} \\omega_{ij}\\ d\\text{vol},")]]

#text("which is well-defined as a ")#mi("{2}")#text("-form thanks to the flat connection. Formally, if we write ")#mi("{*\\omega = du^*}")#text(" and integrate by parts, this vorticity should vanish; however if ")#mi("{u}")#text(" has slow decay then this is not necessarily the case. For instance, if ")#mi("{u}")#text(" is a smooth mollification of the 2D Biot-Savart kernel ")#tao-math("{\\frac{1}{2\\pi} (-\\frac{x_2}{\\left|x\\right|^2},\\frac{x_1}{\\left|x\\right|^2})}", block: false)#text(" then the total vorticity is one (times the standard ")#mi("{2}")#text("-form). In three dimensions, though, there is a trick that allows one to establish vanishing of the total polar vorticity")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^3} \\omega^i\\ d\\text{vol}")]]

#text("and hence also the total vorticity. Namely, if ")#mi("{x^i}")#text(" is the scaling vector field ")#mi("{x \\cdot \\nabla}")#text(", then")

#tao-aligned(keep: true)[


#tao-math("\\omega^i  & = \\omega^j \\nabla_j x^i", block: true)



#tao-math(" & = \\nabla_j (\\omega^j x^i )", block: true)
]

#text("and integration in parts (now involving the compactly supported vorticity ")#mi("{\\omega^j}")#text(") gives the required vanishing. An application of Fubini’s theorem then shows that the total vorticity also vanishes in four and higher dimensions.")

#text("In any dimension, though, the total vorticity (and hence also total polar vorticity) is conserved. Indeed, from ")#link(<tao-9477dda6f1a441d0c73f>)[#text("(5)")]#text(" and ")#link(<tao-cccf52f3d03c5072ee64>)[#text("(3)")]#text(" we have")

#tao-aligned(keep: true)[


#tao-math("D_t \\omega_{ij}  & = - \\omega_{kj} \\nabla_i u^k - \\omega_{ik} \\nabla_j u^k", block: true)



#tao-math(" & = -\\nabla_i(\\omega_{kj} u^k) - \\nabla_j( \\omega_{ik} u^k ) + u^k (\\nabla_i \\omega_{kj} + \\nabla_j \\omega_{ik})", block: true)



#tao-math(" & = -\\nabla_i(\\omega_{kj} u^k) - \\nabla_j( \\omega_{ik} u^k ) - u^k \\nabla_k \\omega_{ji}", block: true)



#tao-math(" & = -\\nabla_i(\\omega_{kj} u^k) - \\nabla_j( \\omega_{ik} u^k ) - \\nabla_k (u^k \\omega_{ji})", block: true)
]

#text("where we have used the vanishing ")#mi("{d\\omega=0}")#text(" of the exterior derivative of vorticity, as well as the divergence-free nature of ")#mi("{u}")#text(". This expresses ")#mi("{D_t \\omega}")#text(" as a total derivative ")#metadata(none) <tao-d43f6e5178b5d583752e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("D_t \\omega_{ij} = -\\nabla_i(\\omega_{kj} u^k) - \\nabla_j( \\omega_{ik} u^k ) - \\nabla_k (u^k \\omega_{ji}),")]]



#text(" giving conservation of total vorticity.")

#text("Now we look at total velocity")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} u^i\\ d\\text{vol},")]]

#text("which (up to a scaling factor representing the density of the incompressible fluid) has the physical interpretation as the total momentum of the fluid. We have")

#align(center)[#tao-fit-display[#mitex("D_t u^i = - \\nabla^i p")]]

#text("which ")#emph[#text("formally")]#text(" suggests that total velocity is conserved. However, in practice ")#mi("{u}")#text(" usually decays too slowly to justify this calculation, unless one works in a suitable principal value sense. We shall take a different tack, noting that")

#tao-aligned(keep: true)[


#tao-math("x^i \\omega_{ij}  & = x^i \\partial_i u_j - x^i \\partial_j u_i", block: true)



#tao-math(" & = -(n-1) u_j + \\partial_i( x^i u_j ) - \\partial_j( x^i u_i ).", block: true)
]

#text("Thus, ")#emph[#text("when ")#mi("{u}")#text(" has enough decay")]#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} u^i\\ d\\text{vol} = \\frac{-1}{n-1} \\int_{{\\bf R}^n} x^i \\omega_{ij}\\ d\\text{vol};")]]

#text("however, the right-hand side remains well defined even when ")#mi("{u}")#text(" decays slowly, assuming that the vorticity is compactly supported. It is thus natural to then define the ")#link("http://en.wikipedia.org/wiki/Impulse_(physics)")[#text("impulse")]

#align(center)[#tao-fit-display[#mitex("\\frac{-1}{n-1} \\int_{{\\bf R}^n} x^i \\omega_{ij}\\ d\\text{vol};")]]

#text("in three dimensions, this would be ")#mi("{\\frac{1}{2} \\int_{{\\bf R}^3} x \\times \\omega}")#text(". The above considerations suggest that the impulse should be another conserved quantity, and indeed it is. To see this, we first compute using ")#link(<tao-d43f6e5178b5d583752e>)[#text("(8)")]#text(":")

#tao-aligned(keep: true)[


#tao-math("D_t( x^i \\omega_{ij} )  & = (D_t x^i) \\omega_{ij} + x^i D_t \\omega_{ij}", block: true)



#tao-math(" & = u^i \\omega_{ij} - x^i \\nabla_i( \\omega_{kj} u^k ) - x^i \\nabla_j( \\omega_{ik} u^k ) - \\nabla_k (u^k \\omega_{ji}))", block: true)



#tao-math(" & = u^i \\omega_{ij} -\\nabla_i( x^i \\omega_{kj} u^k ) - \\nabla_j ( x^i \\omega_{ik} u^j ) - \\nabla_k ( x^i u^k \\omega_{ji})", block: true)



#tao-math(" & + n \\omega_{kj} u^k + \\omega_{jk} u^j + u^i \\omega_{ji},", block: true)
]

#text("and so it will suffice to show that ")#mi("{u^i \\omega_{ij}}")#text(" is also a total derivative. But it is:")

#align(center)[#tao-fit-display[#mitex("u^i \\omega_{ij} = u^i (\\nabla_i u_j - \\nabla_j u_i)")]]

#metadata(none) <tao-07397d633f25a7101990>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("= \\nabla_i (u^i u_j) - \\nabla_j(\\frac{1}{2} u^i u_i ).")]]





#text("Finally, we look at the total angular momentum")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} u_j x_k - u_k x_j\\ d\\text{vol}.")]]

#text("Again, we have")

#tao-aligned(keep: true)[


#tao-math("D_t( u_j x_k - u_k x_j )  & = (D_t u_j) x_k - (D_t u_k) x_j + u_j D_t x_k - u_k D_t x_j", block: true)



#tao-math(" & = - (\\nabla_j p) x_k + (\\nabla_k p) x_j + u_j u_k - u_k u_j", block: true)



#tao-math(" & = - \\nabla_j(px_k) + \\nabla_k(px_j)", block: true)
]

#text("which as before formally suggests that total angular momentum should be conserved. As with total momentum, in practice the velocity field ")#mi("{u}")#text(" decays too slowly to justify this calculation, unless one works carefully with principal value integrals (and uses quite precise asymptotics on the decay of ")#mi("{u}")#text(" at infinity). Once again, one can avoid these technicalities by recasting this quantity in terms of vorticity. Using ")#mi("{(a_{jk})_{[j,k]} := a_{jk}-a_{kj}}")#text(" to denote antisymmetrisation in the ")#mi("{jk}")#text(" indices, we observe that")

#tao-aligned(keep: true)[


#tao-math("x^i \\omega_{ij} x_k - x^i \\omega_{ik} x_j  & = (x^i \\omega_{ij} x_k)_{[j,k]}", block: true)



#tao-math(" & = ( x^i x_k \\partial_i u_j - x^i x_k \\partial_j u_i )_{[j,k]}", block: true)



#tao-math(" & = ( \\partial_i(x^i x_k u_j) - \\partial_j (x^i x_k u_i) - n x_k u_j - x^i u_i \\eta_{jk} )_{[j,k]}", block: true)



#tao-math(" & = ( \\partial_i(x^i x_k u_j) - \\partial_j (x^i x_k u_i) )_{[j,k]} - n(u_j x_k - u_k x_j)", block: true)
]

#text("and so we have")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} u_j x_k - u_k x_j\\ d\\text{vol} = \\frac{-1}{n} \\int_{{\\bf R}^n} x^i \\omega_{ij} x_k - x^i \\omega_{ik} x_j\\ d\\text{vol}")]]

#text("when there is sufficient decay of the velocity field. Again, the right-hand side makes sense whenever the vorticity is compactly supported. If we then define the ")#emph[#text("moment of impulse")]

#align(center)[#tao-fit-display[#mitex("\\frac{-1}{n} \\int_{{\\bf R}^n} x^i \\omega_{ij} x_k - x^i \\omega_{ik} x_j")]]

#text("then we expect this quantity to also be conserved by the flow. This is indeed the case, and can be verified by a rather lengthy calculation similar to that used to establish conservation of impulse; we omit the details here as they are rather tedious and unenlightening, with a key step being the establishment of the fact that ")#mi("{(u^i \\omega_{ij} x_k)_{[j,k]}}")#text(" is a total derivative, by manipulating the identity ")#link(<tao-07397d633f25a7101990>)[#text("(9)")]#text(".")

#heading(level: 1)[#text("Comments (27)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-272855")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2014")])]

#text("It is as if you dropped leaves on a pond… How unfortunate that energy, angular momentum and vorticity conserved here. What are the corresponding symmetries, by Noether theorem?")

#text("I have been contented with some hand-wavy definitions + illustrations. Glad to learn the Euler equations do indeed conserve twirliness, upon time evolution.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-272859")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2014")])]

#text("Hi, I think that you may have missed embedding the link to Majda’s and Bertozzi’s text at the end of the “Below the fold…” paragraph.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6525d7cd9db10f0f8b9a18fa0e62f21ac78916ee3eed4debea5956daeaf030-72219f07d23f0f1bc893af77a76e1cfd99cff0d2c3626a52796f2e15ac6c7e88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of interested non-expert")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-272860")[#strong[#text("interested non-expert")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2014")])]

#text("1) “is drawn from this text of Majda and Bertozzi.” – the link is missing.")#linebreak()#text(" 2) “I constructed such a “computer” for an averaged Euler equation” – i thought the result was for an averaged Navier-Stokes, instead of euler equation?")

#emph[#text("[The result applies to both equations (the viscosity term should be viewed as a lower order perturbative error), but in the current context, the Euler equation setting is more relevant. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-272894")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2014")])]

#text("What suggested in Section 1.3 of that paper is actually for the Euler equations. The Euler are not the true Navier-Stokes. More baffling, the comments made in the last paragraph of S1.3 imply that a finite-time singularity would have the effect of measure-zero on NS global regularity!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c935d3e0b69c3fe73a864a2de52513750618e1267ad7f7e5046377635d58c4ca-ae25666e2277e547f496e73140b31709b4b8ce234d70b62cbc1c158f9aea36c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomcircle")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-272895")[#strong[#text("tomcircle")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2014")])]

#text("Reblogged this on ")#link("http://tomcircle.wordpress.com/2014/02/26/conserved-quantities-for-the-euler-equations/")[#text("Math Online Tom Circle")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75f6f3d873a4e876da725d564bd2d28431a6640a38912ddb0c1bb9bb519f20f5-67723b66aab6d942050360c69cdd6caaeaa4a7e25805e9bfbd448f912543134d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philip Thrift")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-272970")[#strong[#text("Philip Thrift")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2014")])]

#text("The “fluid computer” model proposed here looks like an interesting one to pursue.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f928d8353edcace713387733c2876f6a1158c7e4f919c1ed4786c7cf82cf0df-4926f01d098053e9f19135f23402eb244f56cb1d1a78b271f511490a86fcab03.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-272994")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2014")])]

#text("Euler’s equations (fluid dynamics) have no sense as the exact vector equations because gradp is not a true vector function! ")#link("http://books.google.com/books?id=FC0QFlx12pwC&pg=PA15%7CDubrovin")[#text("http://books.google.com/books?id=FC0QFlx12pwC&pg=PA15%7CDubrovin")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-273035")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2014")])]

#text("Actually, the more precise statement is that the Euler equations become geometric (coordinate independent) if the Euclidean metric (which is called ")#mi("\\eta_{ij}")#text(" in this post) is included as part of the geometric structure of physical space. Once one has this metric, one can interpret the gradient ")#mi("\\nabla p")#text(" as a vector (rather than a covector or ")#mi("1")#text("-form) by using the raising operator associated with that metric to turn the derivative ")#mi("dp")#text(" of the pressure ")#mi("p")#text(" from a covector to a vector. So the Euler equations make perfect sense in the category of Euclidean spaces (and more generally, in the category of Riemannian manifolds), but not in the coarser category of smooth manifolds.")

#text("In particular, the Euler equations are not covariant with respect to general diffeomorphisms (unless one also transforms the Euclidean metric together with all the other fields); but they are still covariant with respect to Euclidean rigid motions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-273054")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2014")])]

#text("turn the derivative ")#mi("dp")#text(" of the pressure ")#mi("p")#text(" from a covector to a covector?")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d20c2faf00b92e29e07961c027448d5fb3592bc4eb027a7e9f55243a7db9cd-f7f871630eb512b4f840bb9c8b184ed30c5c8883bfb9ab9ca332914b9ddebed1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-273050")[#strong[#text("Nick")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2014")])]

#text("Reading this reminded me a bit of the paper by Benjamin and Olver (1982, Journal of Fluid Mechanics), where the authors completely classified the conservation laws for irrotational surface water waves. This led me to a related paper by Olver that derives the conservation laws for the Euler equations through an examination of its Hamiltonian: ")#link("http://www.sciencedirect.com/science/article/pii/0022247X82901007")[#text("http://www.sciencedirect.com/science/article/pii/0022247X82901007")]#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8622da1b3181b52e060cd7a3652253dcb20baa6db67f20a4baeb3743c7b833d6-5ca7b5bbff7f4fd546b095fbcbfd62fccd5dffc5c7667047e97a2a8d5f28664a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rapunzellindemann")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-273106")[#strong[#text("rapunzellindemann")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2014")])]

#text("Reblogged this on ")#link("http://swethasridharkuwait.wordpress.com/2014/02/27/conserved-quantities-for-the-euler-equations/")[#text("Anakin's reveries in multiverses")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-273112")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2014")])]

#text("This and the previous post are revolutionary works/point of views.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-273248")[#strong[#text("Navier-Stokes Fluid Computers | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2014")]

#text("[…] here is a follow up post on Tao’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-273673")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2014")])]

#text("A thought about the interface between the model and actual physics: Even if Euler’s equation allows for universal computation I don’t think we can expect to see memory and computation emerge in real-life fluids in nature. It is thus possible that “no memory,” “no computation” or “no fault-tolerance” represent a physical principle (perhaps of thermodynamical nature) external to the equations themselves (which accounts also for no realistic finite time blow up). This may lead also to additional conserved physical quantities which are not coming from the equation but from the equation with an added principle of “no long computation.”")

#text("And another thought: We could think about a hypothetical world in which humans are much more mathematically advanced compared to our own world, but they are less advanced in terms of other senses, other forms of understanding, and common sense. In such a world mathematical nerds may have much larger share of wealth, fame, sex, and power compared to our own world. In such a world the universal computing powers of the Euler’s equation are known to kindergarten children. It may be the case that in such a world fish would not be regarded as animals living in seas and oceans but rather as fault-tolerant fluid computers which spontaneously emerged in the oceans.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Noether’s theorem, and the conservation laws for the Euler equations | What's new")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-273682")[#strong[#text("Noether’s theorem, and the conservation laws for the Euler equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2014")])]

#text("[…] locate all of the conserved quantities for the Euler equations of inviscid fluid flow, discussed in this previous post, by interpreting that flow as geodesic flow in an infinite dimensional […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-274071")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("Dear Terry, the following question arose in a ")#link("http://www.scottaaronson.com/blog/?p=1697")[#text("discussion over Scott Aaronson’s Shtetl-optimized")]#text(" in a post on the long reach of computation devoted to your paper and to a paper by Leonard Susskind. The qestion is about the “speeding up and shrinking exponentially” aspect of your work. It looks that it is required to move from universal fault-tolerance computation to finite-time blow up. But is it a crucial aspect of the universal computing part? Namely, do you expect that you will be able to simulate universal computing with computational steps being carried out in constant speed (like ordinary computers).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-274126")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2014")])]

#text("Aspects of this discussion remind me of Freeman Dyson’s speculation on an approach which could enable far-future intelligence in an open universe to perform an infinite amount of computation, ever more slowly, using a finite amount of energy. (I think I saw this in his 1979 book Disturbing the Universe; his 1979 paper on the topic is “”Time without end: Physics and biology in an open universe”).")

#text("(I think it was also Dyson who proposed a mechanism for an infinite amount of computation to take place ever more quickly during the ‘big crunch’ of a *closed* universe, though I don’t have a reference).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-274131")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2014")])]

#text("My feeling (and hope) is that for performing arbitrary computations up to N steps in length, one should be able to build a universal computer that can perform those N steps with a unit time taken for each, but the size, energy, and complexity of this computer will grow quite fast with N (particularly since the “materials” one needs to build the computer out of will need to be stable for time N). Even in the absence of viscosity, I would expect entropy (and energy leakage) to eventually take over and disperse any computer after a sufficient period of time. But if one can get the computer to last for an arbitrary finite amount of time, rather than for an infinite amount of time, this should be enough to execute the finite time blowup scenario via programming the computer to build a smaller, faster replica of itself in a time less than the useful working lifetime of that computer. (But, in the absence of such programming, the computer has no particular propensity to shrink or speed up.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-274357")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2014")])]

#text("Thanks! Often if you can achieve robust computation you can put on top fault-tolerance mechanism based on error-correction that will reduce entropy by discarding some undesired elements. So this may lead to implementations where the size,energy and complexity scales up modestly with N. However, it looks that this aspect is not needed for now for finite-time blow up (perhaps such blowup depends just on the ability to compute and not on the ability to carry out efficient computations efficiently.)")

#text("Another unrealated question: Beside the average model are there other cases where your program might be easier, e.g. in high dimensions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-274368")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2014")])]

#text("Higher dimensions should be a little easier, because the conservation laws are less obstructive (for instance, the 3D phenomenon of vortex lines being transported by the flow, which could potentially produce some topological obstructions, is no longer present; for similar reasons, helicity conservation disappears in higher dimensions). Also the effect of viscosity is less (relative to the nonlinear effects), so one can afford to be a little less energy-efficient with regard to the self-similar blowup scenario. One could also throw out viscosity altogether and just shoot for blowup in the Euler equations, which may be a little simpler technically (in particular, all the conservation laws for the Euler equations hold exactly rather than approximately).")

#text("In the other direction, the two-dimensional surface quasi-geostrophic (SQG) equations (the topic of my most recent blog post) are a somewhat simpler toy model of the Euler equations which may be easier to analyse from a geometric or topological viewpoint, although these equations have more conservation laws and it may be more difficult to perform complex computing within this system (and in two spatial dimensions there may be additional difficulties in building objects such as valves and tubes which we are accustomed to being easily constructible in three dimensions).")

#text("Moving away from the “named equations” of fluid dynamics, one could also look at more artificial fluid-like equations which are closer to the true fluid equations than the averaged Navier-Stokes equations considered in my paper. For instance one could imagine a carefully constructed system of multiple fluids occupying the same region of physical space, and interacting with each other in a manner designed to facilitate computation: for instance one fluid could be a lot “stiffer” than another and could be used as the material for pipes, valves, etc. in which the other fluids would flow. This is sort of how my averaged equation works already, except that in my averaged equation the different fluid components occupy different regions of frequency space, rather than different regions of physical space.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-274287")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2014")])]

#text("I wonder if there should be some kind of continuum version of a symplectic form which stays invariant in the Hamiltonian flow corresponding to the NSE. This is a simple and very fundamental question, but in the few articles considering NSE in Lagrangian coordinates I have seen there has not been a mention of it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-274326")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2014")])]

#text("Well, firstly one would have to work with the Euler equations rather than the Navier-Stokes equations, as the latter are not time-reversible (due to the viscosity term) and thus not Hamiltonian. There is a symplectic form ")#mi("\\omega_{ij}")#text(" that is formally preserved by the Euler flow (when combined with the label map ")#mi("\\Phi")#text(" from Lagrangian space to Eulerian space), namely the canonical symplectic form ")#mi("dp \\wedge dq")#text(" on the cotangent bundle on the infinite-dimensional manifold M of volume-preserving maps from Lagrangian space to Eulerian space. In many texts though, the label map ")#mi("\\Phi")#text(" is dropped (analogous to ignoring (or more precisely, projecting out) a set of angle coordinates in Hamiltonian mechanics), leaving only the velocity field ")#mi("u")#text("; this causes the symplectic form to degenerate. As such, most texts using a Hamiltonian approach to the Euler equations do not deal directly with the symplectic form, but instead consider the inverse symplectic form ")#mi("(\\omega^{-1})^{ij}")#text(", which describes the Hamiltonian vector field ")#mi("X^i = (\\omega^{-1})^{ij} \\partial_j H")#text(" associated to a given Hamiltonian ")#mi("H")#text(", or the Poisson bracket ")#mi("\\{F,G\\} = (\\omega^{-1})^{ij} \\partial_i F \\partial_j G")#text(" of two observables ")#mi("F,G")#text(". (The degeneracy now reflects itself in the fact that some Hamiltonians will have trivial vector field in this projected dynamics, and some functions ")#mi("F")#text(" will be in the nullspace of the Poisson bracket.)")

#text("This ")#link("http://www.ams.org/mathscinet-getitem?mr=672198")[#text("paper of Olver")]#text(" describes the inverse symplectic form through the linear operator ")#mi("{\\cal D}")#text(" defining the Hamiltonian vector field for a given Hamiltonian (ignoring the label map); this ")#link("http://arxiv.org/abs/0711.4875")[#text("paper of Vasylkevych and Marsden")]#text(" describes the Poisson bracket (in the full phase space that includes the label map). (I believe there is also some early work of Holm in the latter direction, but was unable to locate it.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7f21bb1e65ebcfe4721ad210c0b99e14803a24381c1b02ba81b7c12970459b53-6e4a81b19408c60e5ea7d875c26428250a51fb616bfa04304a07d91ea3c0d764.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of benedictsnow")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-276957")[#strong[#text("benedictsnow")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2014")])]

#text("A trivial thing to point out, I know, but should the line “[t]he material Lie derivative of the covelocity field ")#mi("u_i")#text(" is however more interesting")#linebreak()#text(" ")#mi("\\mathcal{D}_tu_i = \\partial_tu_i + u^j\\nabla_ju_i + u_j\\nabla_iu_j")#text("”")#linebreak()#text(" just after equation (3) not have an upper index ")#mi("u^j")#text(" in the last term, as opposed to ")#mi("u_j")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7f21bb1e65ebcfe4721ad210c0b99e14803a24381c1b02ba81b7c12970459b53-6e4a81b19408c60e5ea7d875c26428250a51fb616bfa04304a07d91ea3c0d764.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of benedictsnow")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-276963")[#strong[#text("benedictsnow")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2014")])]

#text("Also noticed “Now we take an exterior derivatives” just after Theorem 1.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8a1b93465f206534514885e74d83b7a722bc66a91e2b7ab5e4a04e6156c52b3-ca1203d3133cb0b48d25bed90fcb5507f03833599d47aef1176c4d6f18246669.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henrik Rasmussen")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-311198")[#strong[#text("Henrik Rasmussen")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2014")])]

#text("Very interesting post. Just a small point: is there not a minus missing in your Biot-Savart law ? (twice curl = – laplacian on solenoidal vector fields).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-362492")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2014")])]

#text("Compared to real fluid flows, it is a different story for inviscid flows governed by the Euler equation. There exists a view that Euler solutions will blow up in finite time. A number of recent preprints suggest that Euler solutions show norm inflation (even in some smooth function spaces). The inflation may be considered as scenarios close to blow-ups. Unfortunately, these claims are misleading as they are based on ill-defined analyses.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2551987295c755ae4e9088ea3905c2000f4566d5079d21f3fa8a5b5aefdcb159-2e30952e52db03835a305c38c6c560e50628dc52177832d7fa34448e176923c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of harmeet1987")]], [#link("https://terrytao.wordpress.com/2014/02/25/conserved-quantities-for-the-euler-equations/#comment-493145")[#strong[#text("harmeet1987")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2018")])]

#text("Looks like there is an index mismatch in your definition of the material lie derivative of vector fields. The index ‘i’ on the first term on the right side should be up (D_t X^i)I suppose.")

#emph[#text("[Corrected, thanks – T.]")]
]
