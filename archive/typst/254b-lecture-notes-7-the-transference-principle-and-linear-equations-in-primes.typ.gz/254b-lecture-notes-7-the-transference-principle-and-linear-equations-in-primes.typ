// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/06/05/254b-lecture-notes-7-the-transference-principle-and-linear-equations-in-primes/
// Converted to Typst by tao2typ: "2026-10-14T16:36:13.235547+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254B, Lecture Notes 7: The transference principle, and linear equations in primes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254B, Lecture Notes 7: The transference principle, and linear equations in primes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 June 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/06/05/254b-lecture-notes-7-the-transference-principle-and-linear-equations-in-primes/")[#text("https://terrytao.wordpress.com/2010/06/05/254b-lecture-notes-7-the-transference-principle-and-linear-equations-in-primes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In this, the final lecture notes of this course, we discuss one of the motivating applications of the theory developed thus far, namely to count solutions to linear equations in primes ")#mi("{{\\mathcal P} = \\{2,3,5,7,\\ldots\\}}")#text(" (or in dense subsets ")#mi("{A}")#text(" of primes ")#mi("{{\\mathcal P}}")#text("). Unfortunately, the most famous linear equations in primes: the twin prime equation ")#mi("{p_2 - p_1 = 2}")#text(" and the even Goldbach equation ")#mi("{p_1+p_2=N}")#text(" – remain out of reach of this technology (because the relevant affine linear forms involved are commensurate, and thus have infinite complexity with respect to the Gowers norms), but most other systems of equations, in particular that of arithmetic progressions ")#mi("{p_i = n+ir}")#text(" for ")#mi("{i=0,\\ldots,k-1}")#text(" (or equivalently, ")#mi("{p_i + p_{i+2} = 2p_{i+1}}")#text(" for ")#mi("{i=0,\\ldots,k-2}")#text(") , as well as the odd Goldbach equation ")#mi("{p_1+p_2+p_3=N}")#text(", are tractable.")

#text("To illustrate the main ideas, we will focus on the following ")#link("http://www.ams.org/mathscinet-getitem?mr=2180408")[#text("result of Green")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Roth’s theorem in the primes)")]#text(" Let ")#mi("{A \\subset {\\mathcal P}}")#text(" be a subset of primes whose upper density ")#tao-math("{\\limsup_{N \\rightarrow \\infty} \\left|A \\cap [N]\\right|/\\left|{\\mathcal P} \\cap [N]\\right|}", block: false)#text(" is positive. Then ")#mi("{A}")#text(" contains infinitely many arithmetic progressions of length three.")
]

#text("This should be compared with Roth’s theorem in the integers (")#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/")[#text("Notes 2")]#text("), which is the same statement but with the primes ")#mi("{{\\mathcal P}}")#text(" replaced by the integers ")#mi("{{\\bf Z}}")#text(" (or natural numbers ")#mi("{{\\bf N}}")#text("). Indeed, Roth’s theorem for the primes is proven by ")#emph[#text("transferring")]#text(" Roth’s theorem for the integers to the prime setting; the latter theorem is used as a “black box”. The key difficulty here in performing this transference is that the primes have zero density inside the integers; indeed, from the prime number theorem we have ")#tao-math("{\\left|{\\mathcal P} \\cap [N]\\right| = (1+o(1)) \\frac{N}{\\log N} = o(N)}", block: false)#text(".")

#text("There are a number of generalisations of this transference technique. In a ")#link("http://www.ams.org/mathscinet-getitem?mr=2415379")[#text("paper of Green and myself")]#text(", we extended the above theorem to progressions of longer length (thus transferring Szemerédi’s theorem to the primes). In a ")#link("http://arxiv.org/abs/math.NT/0606088")[#text("series")]#text(" ")#link("http://arxiv.org/abs/0709.3562")[#text("of")]#text(" ")#link("http://arxiv.org/abs/0807.1736")[#text("papers")]#text(" (culminating in a paper to appear shortly) of Green, myself, and also Ziegler, related methods are also used to obtain an asymptotic for the number of solutions in the primes to any system of linear equations of bounded complexity. This latter result uses the full power of higher order Fourier analysis, in particular relying heavily on the inverse conjecture for the Gowers norms; in contrast, Roth’s theorem and Szemerédi’s theorem in the primes are “softer” results that do not need this conjecture.")

#text("To transfer results from the integers to the primes, there are three basic steps:")

#list(
[#text("A general transference principle, that transfers certain types of additive combinatorial results from dense subsets of the integers to dense subsets of a suitably “pseudorandom set” of integers (or more precisely, to the integers weighted by a suitably “pseudorandom measure”);")],
[#text("An application of sieve theory to show that the primes (or more precisely, an affine modification of the primes) lie inside a suitably pseudorandom set of integers (or more precisely, have significant mass with respect to a suitably pseudorandom measure).")],
[#text("If one is seeking asymptotics for patterns in the primes, and not simply lower bounds, one also needs to control correlations between the primes (or proxies for the primes, such as the Möbius function) with various objects that arise from higher order Fourier analysis, such as nilsequences.")]
)

#text("The former step can be accomplished in a number of ways. For progressions of length three (and more generally, for controlling linear patterns of complexity at most one), transference can be accomplished by Fourier-analytic methods. For more complicated patterns, one can use techniques inspired by ergodic theory; more recently, simplified and more efficient methods based on duality (the Hahn-Banach theorem) have also been used. No number theory is used in this step. (In the case of transference to ")#emph[#text("genuinely")]#text(" random sets, rather than pseudorandom sets, similar ideas appeared earlier in the graph theory setting, see ")#link("http://www.ams.org/mathscinet-getitem?mr=1379396")[#text("this paper of Kohayakawa, Luczak, and Rodl")]#text(".")

#text("The second step is accomplished by fairly standard sieve theory methods (e.g. the Selberg sieve, or the slight variants of this sieve used by Goldston and Yildirim). Remarkably, very little of the formidable apparatus of modern analytic number theory is needed for this step; for instance, the only fact about the Riemann zeta function that is truly needed is that it has a simple pole at ")#mi("{s=1}")#text(", and no knowledge of L-functions is needed.")

#text("The third step does draw more significantly on analytic number theory techniques and results (most notably, the method of Vinogradov to compute oscillatory sums over the primes, and also the Siegel-Walfisz theorem that gives a good error term on the prime number theorem in arithemtic progressions). As these techniques are somewhat orthogonal to the main topic of this course, we shall only touch briefly on this aspect of the transference strategy.")

#metadata(none) <tao-769b4f6584dc8beda596>

#heading(level: 1)[#strong[#text(" — 1. Transference — ")]]

#text("The transference principle is not a single theorem, but is instead a family of related results with a common purpose, namely to show that a sufficiently pseudorandom set, measure, or probability distribution will be “indistinguishable” from the whole set (or the uniform measure or probability distribution) in certain statistical senses. A key tool in this regard is a ")#emph[#text("dense model theorem")]#text(" that allows one to ")#emph[#text("approximate")]#text(" or ")#emph[#text("model")]#text(" any set or function that is dense with respect to a pseudorandom measure, by a set or function which is dense with respect to the uniform measure. It turns out that one can do this as long as the approximation is made with respect to a sufficiently ")#emph[#text("weak")]#text(" topology; for the applications to counting arithmetic patterns, it turns out that the topology given by the Gowers norms is the right one to use. The somewhat complicated nature of these norms, though, does make the verification of the required pseudorandomness properties to be slightly tricky.")

#text("We illustrate these themes with Roth’s theorem, though the general strategy applies to several other results in additive combinatorics. We begin with Roth’s theorem in a cyclic group ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(", which we phrase as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Roth’s theorem in ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(")")]#text(" Let ")#mi("{N}")#text(" be odd. If ")#mi("{f: {\\bf Z}/N{\\bf Z} \\rightarrow {\\bf R}}")#text(" is a function obeying the pointwise bound ")#mi("{0 \\leq f \\leq 1}")#text(" and the lower bound ")#mi("{\\mathop{\\bf E}_{n \\in {\\bf Z}/N{\\bf Z}} f(n) \\geq \\delta > 0}")#text(", then one has ")#mi("{\\Lambda(f,f,f) \\geq c(\\delta)}")#text(" for some ")#mi("{c(\\delta)>0}")#text(", where ")#mi("{\\Lambda(f,g,h) := \\mathop{\\bf E}_{n,r \\in {\\bf Z}/N{\\bf Z}} f(n) g(n+r) h(n+2r)}")#text(".")
]

#text("We assume this theorem as a “black box”, in that we will not care as to how this theorem is proven. As noted in previous notes, this theorem easily implies the existence of non-trivial arithmetic progressions of length three in any subset ")#mi("{A}")#text(" of ")#mi("{[N/3]}")#text(" (say) with ")#tao-math("{\\left|A\\right| \\geq \\delta N}", block: false)#text(", as long as ")#mi("{N}")#text(" is sufficiently large depending on ")#mi("{\\delta}")#text(", as it provides a non-trivial lower bound on ")#mi("{\\Lambda(1_A,1_A,1_A)}")#text(".")

#text("Now we generalise the above theorem. We view ")#mi("{N}")#text(" as an (odd) parameter going off to infinity, and use ")#mi("{o_{N \\rightarrow \\infty}(1)}")#text(" to denote any quantity that goes to zero as ")#mi("{N \\rightarrow \\infty}")#text(". We define a ")#emph[#text("measure")]#text(" (or more precisely, a ")#emph[#text("weight function")]#text(") to be a non-negative function ")#mi("{\\nu: {\\bf Z}/N{\\bf Z} \\rightarrow {\\bf R}^+}")#text(" depending on ")#mi("{N}")#text(", such that ")#mi("{\\mathop{\\bf E}_{n \\in [N]} \\nu(n) = 1 + o_{N \\rightarrow\\infty}(1)}")#text(", thus ")#mi("{\\nu}")#text(" is basically the density function of a probability distribution on ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(". We say that ")#mi("{\\nu}")#text(" is ")#emph[#text("Roth-pseudorandom")]#text(" if for every ")#mi("{\\delta > 0}")#text(" (independent of ")#mi("{N}")#text(") there exists ")#mi("{c_\\nu(\\delta) > 0}")#text(" such that one has the lower bound")

#align(center)[#tao-fit-display[#mitex("\\Lambda(f,f,f) \\geq c_\\nu(\\delta) + o_{N \\rightarrow \\infty;\\delta}(1)")]]

#text("whenever ")#mi("{f: {\\bf Z}/N{\\bf Z} \\rightarrow {\\bf R}}")#text(" is a function obeying the pointwise bound ")#mi("{0 \\leq f \\leq \\nu}")#text(" and the lower bound ")#mi("{\\mathop{\\bf E}_{n \\in {\\bf Z}/N{\\bf Z}} f \\geq \\delta}")#text(", and ")#mi("{o_{N \\rightarrow \\infty;\\delta}(1)}")#text(" goes to zero as ")#mi("{N \\rightarrow \\infty}")#text(" for any fixed ")#mi("{\\delta}")#text(". Thus, Roth’s theorem asserts that the uniform measure ")#mi("{1}")#text(" is Roth-pseudorandom. Observe that if ")#mi("{\\nu}")#text(" is Roth-pseudorandom, then any subset ")#mi("{A}")#text(" of ")#mi("{[N/3]}")#text(" whose ")#emph[#text("weighted density")]#text(" ")#mi("{\\nu(A) := \\mathop{\\bf E}_{n \\in {\\bf Z}/N{\\bf Z}} 1_A(n) \\nu(n)}")#text(" is at least ")#mi("{\\delta}")#text(" will contain a non-trivial arithmetic progression of length three, if ")#mi("{N}")#text(" is sufficiently large depending on ")#mi("{\\delta}")#text(", as we once again obtain a non-trivial lower bound on ")#mi("{\\Lambda(1_A,1_A,1_A)}")#text(" in this case. Thus it is of interest to establish Roth-pseudorandomness for a wide class of measures.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Show that if ")#mi("{\\nu}")#text(" is Roth-pseudorandom, and ")#mi("{\\eta}")#text(" is another measure which is “uniformly absolutely continuous” with respect to ")#mi("{\\nu}")#text(" in the sense that one has the bound ")#mi("{\\eta(A) \\leq f(\\nu(A)) + o_{N \\rightarrow \\infty}(1)}")#text(" all ")#mi("{A \\subset {\\bf Z}/N{\\bf Z}}")#text(" and some function ")#mi("{f: {\\bf R}^+ \\rightarrow {\\bf R}^+}")#text(" with ")#mi("{f(x) \\rightarrow 0}")#text(" as ")#mi("{x \\rightarrow 0}")#text(", then ")#mi("{\\eta}")#text(" is also Roth-pseudorandom.")
]

#text("In view of the above exercise, the case of measures that are absolutely continuous with respect to the uniform distribution is uninteresting: the important case is instead when ")#mi("{\\eta}")#text(" is “singular” with respect to the uniform measure, in the sense that it is concentrated on a set of density ")#mi("{o_{N \\rightarrow \\infty}(1)}")#text(" with respect to uniform measure, as this will allow us to detect progressions of length three in sparse sets.")

#text("A model example to keep in mind of a candidate for a Roth-pseudorandom measure is a random sparse measure of some small density ")#mi("{0 < p \\ll 1}")#text(", in which each ")#mi("{\\nu(n)}")#text(" is an independent random variable that equals ")#mi("{1/p}")#text(" with probability ")#mi("{p}")#text(" and ")#mi("{0}")#text(" otherwise. The case ")#mi("{p = 1/\\log N}")#text(" can be thought of as a crude model for the primes (cf. Cramér’s random model for the primes).")

#text("Recall that the form ")#mi("{\\Lambda(f,g,h)}")#text(" is controlled by the ")#mi("{U^2}")#text(" norm in the sense that one has the inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Lambda(f,g,h)\\right| \\leq \\left\\|f\\right\\|_{U^2({\\bf Z}/N{\\bf Z})}", block: true)]]

#text("whenever ")#mi("{f, g, h: {\\bf Z}/N{\\bf Z} \\rightarrow {\\bf C}}")#text(" are bounded in magnitude by ")#mi("{1}")#text(", and similarly for permutations. Actually one has the slightly more precise inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Lambda(f,g,h)\\right| \\leq \\left\\|f\\right\\|_{u^2({\\bf Z}/N{\\bf Z})}", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{u^2({\\bf Z}/N{\\bf Z})} := \\sup_{\\xi \\in {\\bf Z}/N{\\bf Z}} \\left|\\hat f(\\xi)\\right|", block: true)]]

#text("as can easily be seen from the identity ")#metadata(none) <tao-5400d6b19f4371145577>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\Lambda(f,g,h) = \\sum_{\\xi \\in {\\bf Z}/N{\\bf Z}} \\hat f(\\xi) \\hat g(-2\\xi) \\hat h(\\xi),")]]

#text("Hölder’s inequality, and the Plancherel identity.")

#text("This suggests a strategy to establish the Roth-pseudorandomness of a measure by showing that functions ")#mi("{f}")#text(" dominated that measure can be approximated in ")#mi("{u^2}")#text(" norm by functions dominated instead by the uniform measure ")#mi("{1}")#text(". Indeed, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Criterion for Roth-pseudorandomness)")]#text(" ")#metadata(none) <tao-d5963d22f572ba25cba0>#text(" Suppose we have a measure ")#mi("{\\nu}")#text(" with the following properties:")

#list(
[#text("(Control by ")#mi("{u^2}")#text(") For any ")#mi("{f,g,h: {\\bf Z}/N{\\bf Z} \\rightarrow {\\bf R}}")#text(" with the pointwise bound ")#tao-math("{\\left|f\\right|, \\left|g\\right|, \\left|h\\right| \\leq \\nu+1}", block: false)#text(", one has ")#tao-math("{\\left|\\Lambda(f,g,h)\\right| \\leq \\alpha(\\left\\|f\\right\\|_{u^2({\\bf Z}/N{\\bf Z})}) + o_{N \\rightarrow \\infty}(1)}", block: false)#text(", where ")#mi("{\\alpha: {\\bf R}^+ \\rightarrow {\\bf R}^+}")#text(" is a function with ")#mi("{\\alpha(x) \\rightarrow 0}")#text(" as ")#mi("{x \\rightarrow 0}")#text(", and similarly for permutations.")],
[#text("(Approximation in ")#mi("{u^2}")#text(") For any ")#mi("{f: {\\bf Z}/N{\\bf Z} \\rightarrow {\\bf R}}")#text(" with the pointwise bound ")#mi("{0 \\leq f \\leq \\nu}")#text(", and any ")#mi("{\\epsilon > 0}")#text(", there exists ")#mi("{g: {\\bf Z}/N{\\bf Z} \\rightarrow {\\bf R}}")#text(" with the pointwise bound ")#mi("{0 \\leq g \\leq 1 + o_{n \\rightarrow \\infty;\\epsilon}(1)}")#text(" such that ")#tao-math("{\\left\\|f-g\\right\\|_{u^2({\\bf Z}/N{\\bf Z})} \\leq \\epsilon + o_{n \\rightarrow \\infty; \\epsilon}(1)}", block: false)#text(".")]
)

#text("Then ")#mi("{\\nu}")#text(" is Roth-pseudorandom.")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{f: {\\bf Z}/N{\\bf Z} \\rightarrow {\\bf C}}")#text(" be such that ")#mi("{0 \\leq f \\leq \\nu}")#text(" and ")#mi("{\\mathop{\\bf E}_{n \\in {\\bf Z}/N{\\bf Z}} f \\geq \\delta}")#text(". Let ")#mi("{\\epsilon > 0}")#text(" be a small number to be chosen later. We then use the decomposition to split ")#mi("{f = g + (f-g)}")#text(" with the above stated properties. Since")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{n \\in {\\bf Z}/N{\\bf Z}} f(n) - g(n) \\right| \\leq \\left\\|f-g\\right\\|_{u^2({\\bf Z}/N{\\bf Z})} \\leq \\epsilon + o_{n \\rightarrow \\infty;\\epsilon}(1)", block: true)]]

#text("we have from the triangle inequality that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in {\\bf Z}/N{\\bf Z}} g(n) \\geq \\delta - \\epsilon - o_{n \\rightarrow \\infty;\\epsilon}(1)")]]

#text("and in particular")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in {\\bf Z}/N{\\bf Z}} g(n) \\geq \\delta/2")]]

#text("for ")#mi("{N}")#text(" large enough. Similarly we have ")#mi("{0 \\leq g \\leq 2}")#text(" (say) for ")#mi("{N}")#text(" large enough. From Roth’s theorem we conclude that")

#align(center)[#tao-fit-display[#mitex("\\Lambda(g,g,g) \\gg c(\\delta/4)")]]

#text("for ")#mi("{N}")#text(" large enough. On the other hand, by the first hypothesis, the other seven terms in")

#align(center)[#tao-fit-display[#mitex("\\Lambda(f,f,f) = \\Lambda( g+(f-g), g+(f-g), g+(f-g) )")]]

#text("are ")#mi("{O( \\alpha( O( \\epsilon ) )}")#text(" for ")#mi("{N}")#text(" large enough. If ")#mi("{\\epsilon}")#text(" is sufficiently small depending on ")#mi("{\\delta}")#text(", we obtain the claim. ")#mi("\\Box")

#text("Note that this argument in fact gives a value of ")#mi("{c_\\nu(\\delta)}")#text(" that is essentially the same as ")#mi("{c(\\delta)}")#text(". Also, we see that the ")#mi("{u^2}")#text(" norm here could be replaced by the ")#mi("{U^2}")#text(" norm, or indeed by any other quantity which is strong enough for the control hypothesis to hold, and also weak enough for the approximation property to hold.")

#text("So now we need to find some conditions on ")#mi("{\\nu}")#text(" that will allow us to obtain both the control and approximation properties. We begin with the control property. One way to accomplish this is via a restriction estimate:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Restriction estimate implies control)")]#text(" Let ")#mi("{\\nu}")#text(" be a measure. Suppose there exists an exponent ")#mi("{2 < q < 3}")#text(" such that one has the restriction estimate ")#metadata(none) <tao-2320ebc76aece593ac3a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\|\\hat f \\right\\|_{\\ell^q({\\bf Z}/N{\\bf Z})} \\leq C", block: true)]]

#text("whenever ")#mi("{f: {\\bf Z}/N{\\bf Z} \\rightarrow {\\bf C}}")#text(" obeys the pointwise bound ")#tao-math("{\\left|f\\right| \\leq \\nu}", block: false)#text(", where ")#mi("{C}")#text(" is independent of ")#mi("{n}")#text(". Then ")#mi("{\\nu}")#text(" enjoys the control in ")#mi("{u^2}")#text(" property from Lemma ")#link(<tao-d5963d22f572ba25cba0>)[#text("5")]#text(".")
]

#emph[#text("Proof:")]#text(" From Plancherel’s theorem, we see that ")#link(<tao-2320ebc76aece593ac3a>)[#text("(2)")]#text(" already holds if we have ")#tao-math("{\\left|f\\right| \\leq 1}", block: false)#text(", so by the triangle inequality it also holds (with a slightly different value of ")#mi("{C}")#text(") if ")#tao-math("{\\left|f\\right| \\leq \\nu+1}", block: false)#text(".")

#text("Now suppose that ")#tao-math("{\\left|f\\right|, \\left|g\\right|, \\left|h\\right| \\leq \\nu+1}", block: false)#text(". From ")#link(<tao-5400d6b19f4371145577>)[#text("(1)")]#text(" and Hölder’s inequality one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Lambda(f,g,h)\\right| \\leq \\left\\|f\\right\\|_{\\ell^q({\\bf Z}/N{\\bf Z})}^{q-2} \\left\\|\\hat f \\right\\|_{\\ell^\\infty({\\bf Z}/N{\\bf Z})}^{3-q} \\left\\|g\\right\\|_{\\ell^q({\\bf Z}/N{\\bf Z})} \\left\\|h\\right\\|_{\\ell^q({\\bf Z}/N{\\bf Z})}", block: true)]]

#text("and thus by ")#link(<tao-2320ebc76aece593ac3a>)[#text("(2)")]

#align(center)[#tao-fit-display[#tao-math("\\left|\\Lambda(f,g,h)\\right| \\leq C^q \\left\\|f \\right\\|_{u^2({\\bf Z}/N{\\bf Z})}^{3-q}", block: true)]]

#text("and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Show that the estimate ")#link(<tao-2320ebc76aece593ac3a>)[#text("(2)")]#text(" for ")#mi("{q \\leq 2}")#text(" can only hold when ")#mi("{\\nu}")#text(" is bounded uniformly in ")#mi("{N}")#text("; this explains the presence of the hypothesis ")#mi("{q>2}")#text(" in the above condition.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" ")#metadata(none) <tao-14e2bb80e5ea48fbad04>#text(" Show that the estimate ")#link(<tao-2320ebc76aece593ac3a>)[#text("(2)")]#text(" is equivalent to the estimate")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{n \\in {\\bf Z}/N{\\bf Z}} |\\sum_{\\xi \\in {\\bf Z}/N{\\bf Z}} g(\\xi) e(\\xi n x/N)| \\nu(n) \\leq C \\left\\|g\\right\\|_{\\ell^{q^{\\prime}}({\\bf Z}/N{\\bf Z})}", block: true)]]

#text("for all ")#mi("{g: {\\bf Z}/N{\\bf Z} \\rightarrow {\\bf C}}")#text(", where ")#mi("{q^{\\prime} := q/(q-1)}")#text(" is the dual exponent to ")#mi("{q}")#text(". Informally, this asserts that a Fourier series with ")#mi("{\\ell^{q^{\\prime}}}")#text(" coefficients can be “restricted” to the support of ")#mi("{\\nu}")#text(" in an uniformly absolutely integrable manner (relative to ")#mi("{\\nu}")#text("). Historically, this is the origin of the term “restriction theorem” (in the context where ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" is replaced with a Euclidean space such as ")#mi("{{\\bf R}^n}")#text(", and ")#mi("{\\nu}")#text(" is surface measure on a manifold such as the sphere ")#mi("{S^{n-1}}")#text("). See for instance ")#link("http://front.math.ucdavis.edu/math.CA/0311181")[#text("my notes on this topic")]#text(".")
]

#text("We will briefly discuss the standard method for establishing restriction estimates, namely the ")#emph[#text("Tomas-Stein argument")]#text(" or ")#emph[#text("large sieve inequality")]#text(", later in these notes.")

#text("Now we turn to the approximation property. The approximation ")#mi("{g}")#text(" to ")#mi("{f}")#text(" needs to be close in ")#mi("{u^2}")#text(" norm, i.e. the Fourier coefficients need to be uniformly close. One attempt to accomplish this is ")#emph[#text("hard thresholding")]#text(": one simply discards all Fourier coefficients in the Fourier expansion")

#align(center)[#tao-fit-display[#mitex("f(n) = \\sum_{\\xi \\in {\\bf Z}/N{\\bf Z}} \\hat f(\\xi) e(x \\xi / N )")]]

#text("of ")#mi("{f}")#text(" that are too small, thus setting ")#mi("{g}")#text(" equal to something like")

#align(center)[#tao-fit-display[#tao-math("g(n) = \\sum_{\\xi \\in {\\bf Z}/N{\\bf Z}: \\left|\\hat f(\\xi)\\right| \\geq \\epsilon} \\hat f(\\xi) e(x \\xi / N ).", block: true)]]

#text("The main problem with this choice is that there is no guarantee that the non-negativity of ")#mi("{f}")#text(" will transfer over to the non-negativity of ")#mi("{g}")#text("; also, there is no particular reason why ")#mi("{g}")#text(" would be bounded.")

#text("But a small modification of this idea does work, as follows. Let ")#tao-math("{S := \\{ \\xi \\in {\\bf Z}/N{\\bf Z}: \\left|\\hat f(\\xi)\\right| \\geq \\epsilon \\}}", block: false)#text(" denote the large Fourier coefficients of ")#mi("{f}")#text(". The function ")#mi("{g}")#text(" proposed above can be viewed as a convolution ")#mi("{f*K}")#text(", where ")#mi("{K(n) := \\sum_{\\xi \\in S} e(x \\xi/N)}")#text(" and ")#mi("{f*K(n) := \\mathop{\\bf E}_{m \\in {\\bf Z}/N{\\bf Z}} f(m) K(n-m)}")#text(". The inability to get good pointwise bounds on ")#mi("{f*K}")#text(" can be traced back to the oscillatory nature of the convolution kernel ")#mi("{K}")#text(" (which can be viewed as a generalised Dirichlet kernel).")

#text("But experience with Fourier analysis tells us that the behaviour of such convolutions improves if one replaces the Dirichlet-type kernels with something more like a Fejér type kernel instead. With that in mind, we try")

#align(center)[#tao-fit-display[#mitex("g(n) := \\mathop{\\bf E}_{m_1, m_2 \\in B} f(n+m_1-m_2)")]]

#text("where ")#mi("{B}")#text(" is the ")#emph[#text("Bohr set")]

#align(center)[#tao-fit-display[#tao-math("B := \\{ n \\in {\\bf Z}/N{\\bf Z}: \\left|e( n \\xi / N) - 1\\right| \\leq \\epsilon \\text{ for all } \\xi \\in S \\}.", block: true)]]

#text("Clearly, if ")#mi("{f}")#text(" is non-negative, then ")#mi("{g}")#text(" is also. Now we look at upper bounds on ")#mi("{g}")#text(". Clearly")

#align(center)[#tao-fit-display[#mitex("g(n) \\leq \\mathop{\\bf E}_{m_1, m_2 \\in B} \\nu(n+m_1-m_2)")]]

#text("so by Fourier expansion")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g\\right\\|_{L^\\infty({\\bf Z}/N{\\bf Z})} \\leq \\sum_{\\xi \\in {\\bf Z}/N{\\bf Z}} \\left|\\mathop{\\bf E}_{m \\in B} e(\\xi B)\\right|^2 |\\hat \\nu(\\xi)|.", block: true)]]

#text("Let us make the Fourier-pseudorandomness assumption ")#metadata(none) <tao-6e4f542d909651df3579>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\sup_{\\xi \\neq 0} \\left|\\hat \\nu(\\xi)\\right| = o_{N \\rightarrow \\infty}(1).", block: true)]]

#text("Evaluating the ")#mi("{\\xi=0}")#text(" term on the RHS separately, we conclude")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g\\right\\|_{L^\\infty({\\bf Z}/N{\\bf Z})} \\leq 1 +o_{N \\rightarrow \\infty}( \\sum_{\\xi \\in {\\bf Z}/N{\\bf Z}} \\left|\\mathop{\\bf E}_{m \\in B} e(\\xi B)\\right|^2 ).", block: true)]]

#text("By Plancherel’s theorem we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\xi \\in {\\bf Z}/N{\\bf Z}} \\left|\\mathop{\\bf E}_{m \\in B} e(\\xi B)\\right|^2 = \\left|B\\right|/N.", block: true)]]

#text("From the Kronecker approximation theorem we have")

#align(center)[#tao-fit-display[#tao-math("\\left|B\\right| / N \\gg (\\epsilon/10)^{\\left|S\\right|}", block: true)]]

#text("(say). Finally, if we assume ")#link(<tao-2320ebc76aece593ac3a>)[#text("(2)")]#text(" we have ")#tao-math("{\\left|S\\right| \\ll \\epsilon^{-q}}", block: false)#text(". Putting this all together we obtain the pointwise bound")

#align(center)[#tao-fit-display[#mitex("g \\leq 1 + o_{N \\rightarrow \\infty; q,\\epsilon}(1).")]]

#text("Finally, we see how ")#mi("{g}")#text(" approximates ")#mi("{f}")#text(". From Fourier analysis one has")

#align(center)[#tao-fit-display[#tao-math("\\hat g(\\xi) = \\hat f(\\xi) \\left|\\mathop{\\bf E}_{m \\in B} e(\\xi B)\\right|^2", block: true)]]

#text("and so")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f-g\\right\\|_{u^2({\\bf Z}/N{\\bf Z})} = \\sup_{\\xi \\in {\\bf Z}/N{\\bf Z}} \\left|\\hat f(\\xi)\\right| (1 - \\left|\\mathop{\\bf E}_{m \\in B} e(\\xi B)\\right|^2).", block: true)]]

#text("The frequencies ")#mi("{\\xi}")#text(" that lie outside ")#mi("{\\xi}")#text(" give a contribution of at most ")#mi("{\\epsilon}")#text(" by the definition of ")#mi("{S}")#text(", so we look now at the terms where ")#mi("{\\xi \\in S}")#text(". From the definition of ")#mi("{B}")#text(" and the triangle inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{m \\in B} e(\\xi B) - 1\\right| \\leq \\epsilon", block: true)]]

#text("in such cases, while from the measure nature of ")#mi("{\\nu}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\hat f(\\xi)\\right| \\leq \\mathop{\\bf E}_{n \\in {\\bf Z}/N{\\bf Z}} \\nu(n) = 1 + o_{N \\rightarrow \\infty}(1).", block: true)]]

#text("Putting this all together, we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f-g\\right\\|_{u^2({\\bf Z}/N{\\bf Z})} \\ll \\epsilon + o_{N \\rightarrow \\infty}(1).", block: true)]]

#text("To summarise, we have the following result, which essentially appears in ")#link("http://front.math.ucdavis.edu/math.NT/0405581")[#text("this paper of Green and myself")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Criterion for Roth-pseudorandomness)")]#text(" ")#text(" Let ")#mi("{\\nu}")#text(" be a measure obeying the Fourier-pseudorandomness assumption ")#link(<tao-6e4f542d909651df3579>)[#text("(3)")]#text(" and the restriction estimate ")#link(<tao-2320ebc76aece593ac3a>)[#text("(2)")]#text(" for some ")#mi("{2 < q < 3}")#text(". Then ")#mi("{\\nu}")#text(" is Roth-pseudorandom.")
]

#text("This turns out to be a fairly tractable criterion for establishing the Roth-pseudorandomness of various measures, which in turn can be used to detect progressions of length three (and related patterns) on various sparse sets, such as the primes; see the next section.")

#text("The above arguments to establish Roth-pseudorandomness relied heavily on linear Fourier analysis. Now we give an alternate approach that avoids Fourier analysis entirely; it is less efficient and a bit messier, but will extend in a fairly straightforward (but notationally intensive) manner to higher order patterns. To do this, we replace the ")#mi("{u^2}")#text(" norm in Lemma ")#link(<tao-d5963d22f572ba25cba0>)[#text("5")]#text(" with the ")#mi("{U^2}")#text(" norm, so we now have to verify a control by ")#mi("{U^2}")#text(" hypothesis and an approximation by ")#mi("{U^2}")#text(" hypothesis.")

#text("We begin with the control by ")#mi("{U^2}")#text(" hypothesis. Instead of Fourier analysis, we will rely solely on the Cauchy-Schwarz inequality, using a weighted version of the arguments from ")#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/")[#text("Notes 3")]#text(" that first appeared in ")#link("http://www.ams.org/mathscinet-getitem?mr=2415379")[#text("this paper of Green and myself")]#text(". We wish to control the expression")

#align(center)[#tao-fit-display[#mitex("\\Lambda(f,g,h)=\\mathop{\\bf E}_{n,r \\in {\\bf Z}/N{\\bf Z}} f(n) g(n+r) h(n+2r)")]]

#text("where ")#mi("{f,g,h}")#text(" are bounded in magnitude by ")#mi("{\\nu+1}")#text(". For simplicity we will just assume that ")#mi("{f,g,h}")#text(" are bounded in magnitude by ")#mi("{\\nu}")#text("; the more general case is similar but a little bit messier. For brevity we will also omit the domain ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" in the averages, and also abbreviate ")#mi("{o_{N \\rightarrow \\infty}(1)}")#text(" as ")#mi("{o(1)}")#text(". We make the change of variables ")#mi("{(n,r) = (b+2c,-a-b-c)}")#text(" to write this expression as")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{a,b,c} f(b+2c) g(a-c) h(-2a-b)")]]

#text("the point being that each term involves only two of the three variables ")#mi("{a,b,c}")#text(".")

#text("We can pointwise bound ")#mi("{h}")#text(" by ")#mi("{\\nu}")#text(" and estimate the above expression in magnitude by")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{a,b} |\\mathop{\\bf E}_c f(b+2c) g(a-c)| \\nu(-2a-b).")]]

#text("Since ")#mi("{\\mathop{\\bf E} \\nu = 1+o(1)}")#text(", we can use Cauchy-Schwarz and bound this by")

#align(center)[#tao-fit-display[#tao-math("(1+o(1)) (\\mathop{\\bf E}_{a,b} \\left|\\mathop{\\bf E}_c f(b+2c) g(a-c)\\right|^2 \\nu(-2a-b))^{1/2}", block: true)]]

#text("which we rewrite as")

#align(center)[#tao-fit-display[#mitex("(1+o(1)) (\\mathop{\\bf E}_{a,b,c,c^{\\prime}} f(b+2c) f(b+2c^{\\prime}) g(a-c) g(a-c^{\\prime}) \\nu(-2a-b))^{1/2}.")]]

#text("We now bound ")#mi("{g}")#text(" by ")#mi("{\\nu}")#text(", to obtain")

#align(center)[#tao-fit-display[#tao-math("(1+o(1)) (\\mathop{\\bf E}_{a,c,c^{\\prime}} \\nu(a-c) \\nu(a-c^{\\prime}) \\left|\\mathop{\\bf E}_b f(b+2c) f(b+2c^{\\prime}) \\nu(-2a-b)\\right|)^{1/2}.", block: true)]]

#text("If we make the hypothesis ")#metadata(none) <tao-da1c0047575598b38f69>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\mathop{\\bf E}_{a,c,c^{\\prime}} \\nu(a-c) \\nu(a-c^{\\prime}) = 1+o(1)")]]

#text("(which is a variant of ")#link(<tao-6e4f542d909651df3579>)[#text("(3)")]#text(", as can be seen by expanding out using Fourier analysis), followed by Cauchy-Schwarz, we can bound this by")

#align(center)[#tao-fit-display[#tao-math("(1+o(1)) (\\mathop{\\bf E}_{a,c,c^{\\prime}} \\nu(a-c) \\nu(a-c^{\\prime}) \\left|\\mathop{\\bf E}_b f(b+2c) f(b+2c^{\\prime}) \\nu(-2a-b)\\right|^2)^{1/4}.", block: true)]]

#text("We expand this out as")

#align(center)[#tao-fit-display[#tao-math("(1+o(1)) \\left|\\mathop{\\bf E}_{a,b,b^{\\prime},c,c^{\\prime}} f(b+2c) f(b^{\\prime}+2c) f(b+2c^{\\prime}) f(b^{\\prime}+2c^{\\prime}) F(b,b^{\\prime},c,c^{\\prime})\\right|^{1/4}.", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("F(b,b^{\\prime},c,c^{\\prime}) := \\mathop{\\bf E}_a \\nu(a-c)\\nu(a-c^{\\prime}) \\nu(-2a-b) \\nu(-2a-b^{\\prime}).")]]

#text("If the ")#mi("{F}")#text(" factor could be replaced by ")#mi("{1}")#text(", then the expression inside the absolute values would just be ")#tao-math("{\\left\\|f\\right\\|_{U^2({\\bf Z}/N{\\bf Z})}^4}", block: false)#text(", which is what we wanted. Applying the triangle inequality and bounding ")#mi("{f}")#text(" by ")#mi("{\\nu}")#text(", we can thus bound the previous expression by")

#align(center)[#tao-fit-display[#tao-math("\\ll ( \\left\\|f\\right\\|_{U^2({\\bf Z}/N{\\bf Z})} + \\left|\\mathop{\\bf E}_{a,b,b^{\\prime},c,c^{\\prime}} \\nu(b+2c) \\nu(b^{\\prime}+2c) \\nu(b+2c^{\\prime}) \\nu(b^{\\prime}+2c^{\\prime}) \\right|F(b,b^{\\prime},c,c^{\\prime})-1||^{1/4}.", block: true)]]

#text("If we make the hypotheses ")#metadata(none) <tao-fd7ceb8ef53eafa42faa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\mathop{\\bf E}_{a,b,b^{\\prime},c,c^{\\prime}} \\nu(b+2c) \\nu(b^{\\prime}+2c) \\nu(b+2c^{\\prime}) \\nu(b^{\\prime}+2c^{\\prime}) F(b,b^{\\prime},c,c^{\\prime})^i = 1+o(1)")]]

#text("for ")#mi("{i=0,1,2}")#text(", then another application of Cauchy-Schwarz gives")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{a,b,b^{\\prime},c,c^{\\prime}} \\nu(b+2c) \\nu(b^{\\prime}+2c) \\nu(b+2c^{\\prime}) \\nu(b^{\\prime}+2c^{\\prime}) \\left|F(b,b^{\\prime},c,c^{\\prime})-1\\right| = o(1)", block: true)]]

#text("and so we have obtained the control in ")#mi("{U^2}")#text(" hypothesis (at least for ")#mi("{f}")#text(", and assuming boundedness by ")#mi("{\\nu}")#text(" and ")#mi("{\\nu+1}")#text(" assuming the conditions ")#link(<tao-da1c0047575598b38f69>)[#text("(4)")]#text(", ")#link(<tao-fd7ceb8ef53eafa42faa>)[#text("(5)")]#text("). We refer to such conditions (involving the product of ")#mi("{\\nu}")#text(" evaluated at distinct linear forms on the left-hand side, and a ")#mi("{1+o(1)}")#text(" on the right-hand side) as ")#emph[#text("linear forms conditions")]#text(". Generalising to the case of functions bounded by ")#mi("{\\nu+1}")#text(", and permuting ")#mi("{f,g,h}")#text(", we can soon obtain the following result (stated somewhat informally):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (Generalised von Neumann theorem)")]#text(" If ")#mi("{\\nu}")#text(" obeys a certain finite list of linear forms conditions, then the control by ")#mi("{U^2}")#text(" hypothesis in Lemma ")#link(<tao-d5963d22f572ba25cba0>)[#text("5")]#text(" holds.")
]

#text("Now we turn to the approximation in ")#mi("{U^2}")#text(" property. It is possible to establish this approximation property by an energy increment method, analogous to the energy increment proof of Roth’s theorem in ")#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/")[#text("Notes 2")]#text("; see ")#link("http://www.ams.org/mathscinet-getitem?mr=2415379")[#text("my paper with Green")]#text(" for details. However, this argument turns out to be rather complicated. We give here a simpler approach based on duality (and more precisely, the Hahn-Banach theorem) that yields the same result, due independently ")#link("http://arxiv.org/abs/0811.3103")[#text("to Gowers")]#text(" and ")#link("http://arxiv.org/abs/0806.0381")[#text("to Reingold-Trevisan-Tulsiani-Vadhan")]#text(". This approach also has the benefit of giving somewhat sharper quantitative refinements.")

#text("The first task is to represent the ")#mi("{U^2}")#text(" norm in a dual formulation. The starting point is that the expression")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^2({\\bf Z}/N{\\bf Z})}^4 = \\mathop{\\bf E}_{n,a,b} f(n) f(n+a) f(n+b) f(n+a+b)", block: true)]]

#text("whenever ")#mi("{f: {\\bf Z}/N{\\bf Z} \\rightarrow {\\bf R}}")#text(", can be rewritten as")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^2({\\bf Z}/N{\\bf Z})}^4 = \\langle f, {\\mathcal D} f \\rangle_{L^2({\\bf Z}/N{\\bf Z})}", block: true)]]

#text("where the ")#emph[#text("dual function")]#text(" ")#mi("{{\\mathcal D} f = {\\mathcal D}_2 f: {\\bf Z}/N{\\bf Z} \\rightarrow {\\bf R}}")#text(" is defined by")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D} f(n) := \\mathop{\\bf E}_{a,b} f(n+a) f(n+b) f(n+a+b).")]]

#text("Define a ")#emph[#text("basic anti-uniform function")]#text(" to be any function of the form ")#mi("{{\\mathcal D} F}")#text(", where ")#mi("{F: {\\bf Z}/N{\\bf Z} \\rightarrow {\\bf R}}")#text(" obeys the pointwise bound ")#tao-math("{\\left|F\\right| \\leq \\nu+1}", block: false)#text(". To obtain the approximation property, it thus suffices to show that for every ")#mi("{\\epsilon > 0}")#text(", for ")#mi("{N}")#text(" sufficiently large depending on ")#mi("{\\epsilon}")#text(", and any ")#mi("{f: {\\bf Z}/N{\\bf Z} \\rightarrow {\\bf R}}")#text(" with ")#mi("{0 \\leq f \\leq \\nu}")#text(", one can decompose ")#mi("{f = f_1 + f_2}")#text(" where ")#mi("{0 \\leq f_1 \\leq 1}")#text(" and ")#tao-math("{\\left|\\langle f_2, {\\mathcal D} F \\rangle\\right| \\leq \\epsilon^4}", block: false)#text(" for all basic anti-uniform functions ")#mi("{{\\mathcal D} F}")#text(". Indeed, if one sets ")#mi("{F := f_2}")#text(", the latter bound gives ")#tao-math("{\\left\\|f_2\\right\\|_{U^2({\\bf Z}/N{\\bf Z})}^4 \\leq \\epsilon^4}", block: false)#text(", and the desired decomposition follows.")

#text("In order to apply the Hahn-Banach theorem properly, it is convenient to symmetrise and convexify the space of basic anti-uniform functions. Define an ")#emph[#text("averaged anti-uniform function")]#text(" to be any convex combination of basic anti-uniform functions and their negations, and denote the space of all such averaged anti-uniform functions as ")#mi("{B}")#text(". Thus ")#mi("{B}")#text(" is a compact convex symmetric subset of the finite-dimensional real vector space ")#mi("{L^2({\\bf Z}/N{\\bf Z})}")#text(" that contains a neighbourhood of the origin; equivalently, it defines a norm on ")#mi("{L^2({\\bf Z}/N{\\bf Z})}")#text(". Our task is then to show (for fixed ")#mi("{\\epsilon}")#text(" and large ")#mi("{N}")#text(") that for any ")#mi("{f \\in {\\bf Z}/N{\\bf Z} \\rightarrow {\\bf R}}")#text(" with ")#mi("{0 \\leq f \\leq \\nu+1}")#text(", the sets")

#align(center)[#tao-fit-display[#mitex("U := \\{ (f_1,f_2) \\in L^2({\\bf Z}/N{\\bf Z}) \\cap L^2({\\bf Z}/N{\\bf Z}): f_1 + f_2 = f \\}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("V := \\{ (f_1,f_2) \\in L^2({\\bf Z}/N{\\bf Z}) \\cap L^2({\\bf Z}/N{\\bf Z}): 0 \\leq f_1 \\leq 1; \\langle f_2, \\phi \\rangle \\leq \\epsilon^4 \\text{ for all } \\phi \\in B \\}")]]

#text("have non-empty intersection.")

#text("The point of phrasing things this way is that ")#mi("{U}")#text(" and ")#mi("{V}")#text(" are both closed convex subsets of the finite-dimensional vector space ")#mi("{L^2({\\bf Z}/N{\\bf Z}) \\cap L^2({\\bf Z}/N{\\bf Z})}")#text(", and so the ")#link("http://en.wikipedia.org/wiki/Hahn-Banach_theorem")[#text("Hahn-Banach theorem")]#text(" is applicable. (One could also use closely related results, such as the ")#link("http://en.wikipedia.org/wiki/Farkas'_lemma")[#text("Farkas lemma")]#text(": see ")#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/")[#text("this earlier blog post")]#text(" for more discussion.) Indeed, suppose that there was some ")#mi("{f}")#text(" for which ")#mi("{U}")#text(" and ")#mi("{V}")#text(" were disjoint. Then, by the Hahn-Banach theorem, there must exist some linear functional")

#align(center)[#tao-fit-display[#mitex("(f_1,f_2) \\mapsto \\langle f_1, \\phi_1 \\rangle_{L^2({\\bf Z}/N{\\bf Z})} + \\langle f_2, \\phi_2 \\rangle_{L^2({\\bf Z}/N{\\bf Z})}")]]

#text("which separates the two sets, in the sense that")

#align(center)[#tao-fit-display[#mitex("\\langle f_1, \\phi_1 \\rangle_{L^2({\\bf Z}/N{\\bf Z})} + \\langle f_2, \\phi_2 \\rangle_{L^2({\\bf Z}/N{\\bf Z})} > c")]]

#text("for all ")#mi("{(f_1,f_2) \\in U}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\langle f_1, \\phi_1 \\rangle_{L^2({\\bf Z}/N{\\bf Z})} + \\langle f_2, \\phi_2 \\rangle_{L^2({\\bf Z}/N{\\bf Z})} \\leq c")]]

#text("for all ")#mi("{(f_1,f_2) \\in V}")#text(", where ")#mi("{c}")#text(" is a real number.")

#text("From the form of ")#mi("{U}")#text(", we see that we must have ")#mi("{\\phi_1=\\phi_2}")#text(". In particular, we may normalise ")#mi("{\\phi = \\phi_1 = \\phi_2}")#text(" to be on the boundary of ")#mi("{B}")#text(". As all finite-dimensional spaces are reflexive, we see in that case that ")#mi("{\\langle f_2, \\phi \\rangle}")#text(" can be as large as ")#mi("{\\epsilon^4}")#text(" on ")#mi("{V}")#text(", and independently ")#mi("{\\langle f_1, \\phi \\rangle}")#text(" can be as large as ")#mi("{\\mathop{\\bf E}_{n \\in {\\bf Z}/N{\\bf Z}} \\max(\\phi,0)}")#text(". We conclude that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in {\\bf Z}/N{\\bf Z}} \\max(\\phi,0) + \\epsilon^4 \\leq \\mathop{\\bf E}_{n \\in {\\bf Z}/N{\\bf Z}} f \\phi.")]]

#text("As ")#mi("{0 \\leq f \\leq \\nu}")#text(", we see that ")#mi("{f \\phi \\leq \\nu \\max(\\phi,0)}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in {\\bf Z}/N{\\bf Z}} (\\nu-1) \\max(\\phi,0) \\geq \\epsilon^4.")]]

#text("We now make the hypothesis that the dual function ")#mi("{{\\mathcal D}(\\nu+1)}")#text(" of ")#mi("{\\nu+1}")#text(" is uniformly bounded: ")#metadata(none) <tao-6a0286bf626be7fe4871>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("{\\mathcal D}(\\nu+1) \\leq C.")]]

#text("We remark that the linear forms condition (which we have not specified explicitly) will give this bound with ")#mi("{C = {\\mathcal D}(1+1) + o(1) = 2^{2^2-1} + o(1)}")#text(".")

#text("Since ")#mi("{\\phi}")#text(" is a convex combination of functions of the form ")#mi("{\\pm {\\mathcal D} F}")#text(" and ")#tao-math("{\\left|F\\right| \\leq \\nu+1}", block: false)#text(", this implies that ")#mi("{\\phi}")#text(" is bounded uniformly as well: ")#tao-math("{\\left|\\phi\\right| \\leq C}", block: false)#text(". Applying the Weierstrass approximation theorem to the function ")#mi("{\\max(x,0)}")#text(" for ")#tao-math("{\\left|x\\right| \\leq C}", block: false)#text(" (and noting that the ")#mi("{L^1}")#text(" norm of ")#mi("{\\nu-1}")#text(" is ")#mi("{O(1)}")#text(") we conclude that there exists a polynomial ")#mi("{P: {\\bf R} \\rightarrow {\\bf R}}")#text(" (depending only on ")#mi("{\\epsilon}")#text(" and ")#mi("{C}")#text(") such that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in {\\bf Z}/N{\\bf Z}} (\\nu-1) P(\\phi) \\geq \\epsilon^4/2")]]

#text("(say). Breaking ")#mi("{P}")#text(" into monomials, and using the pigeonhole principle, we conclude that there exists a non-negative integer ")#mi("{k = O_{\\epsilon,C}(1)}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{n \\in {\\bf Z}/N{\\bf Z}} (\\nu-1) \\phi^k\\right| \\gg_{\\epsilon,C} 1;", block: true)]]

#text("since ")#mi("{\\phi}")#text(" was a convex combination of functions of the form ")#mi("{\\pm {\\mathcal D} F}")#text(", we thus conclude that there exist ")#mi("{F_1,\\ldots,F_k}")#text(" with ")#tao-math("{\\left|F_1\\right|,\\ldots,\\left|F_k\\right| \\leq \\nu+1}", block: false)#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{n \\in {\\bf Z}/N{\\bf Z}} (\\nu-1) ({\\mathcal D} F_1) \\ldots ({\\mathcal D} F_k)\\right| \\gg_{\\epsilon,C} 1.", block: true)]]

#text("We shall contradict this by ")#emph[#text("fiat")]#text(", making the hypothesis that ")#metadata(none) <tao-aa58b21b01d6b8a99c1a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\mathop{\\bf E}_{n \\in {\\bf Z}/N{\\bf Z}} (\\nu-1) ({\\mathcal D} F_1) \\ldots ({\\mathcal D} F_k)| = o_{N \\rightarrow \\infty;k}(1)")]]

#text("for all ")#mi("{k \\geq 1}")#text(" and all ")#mi("{F_1,\\ldots,F_k}")#text(" bounded in magnitude by ")#mi("{\\nu+1}")#text(".")

#text("We summarise this discussion as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Dense model theorem)")]#text(" If ")#link(<tao-6a0286bf626be7fe4871>)[#text("(6)")]#text(", ")#link(<tao-aa58b21b01d6b8a99c1a>)[#text("(7)")]#text(" hold, then the approximation in ")#mi("{U^2}")#text(" hypothesis in Lemma ")#link(<tao-d5963d22f572ba25cba0>)[#text("5")]#text(" holds.")
]

#text("There is nothing too special about the ")#mi("{U^2}")#text(" norm here; one could work with higher Gowers norms, or indeed with any other norm for which one has a reasonably explicit description of the dual.")

#text("The abstract version of theorem was first (implicitly) proven ")#link("https://terrytao.wordpress.com/2010/06/05/254b-lecture-notes-7-the-transference-principle-and-linear-equations-in-primes/\\href")[#text("\\href")]#text(", and made more explicit in this paper ")#link("http://www.ams.org/mathscinet-getitem?mr=2461509")[#text("of Ziegler and myself")]#text(". The methods there were different (and somewhat more complicated). To prove approximation, the basic idea was to write ")#mi("{g = \\mathop{\\bf E}(f|{\\mathcal B})}")#text(" for some carefully chosen ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}}")#text(" (built out of dual functions that correlated with things like the residual ")#mi("{f - \\mathop{\\bf E}(f|{\\mathcal B})}")#text("). This automatically gave the non-negativity of ")#mi("{g}")#text("; the upper bound on ")#mi("{g}")#text(" came from the bound ")#mi("{\\mathop{\\bf E}(f|{\\mathcal B}) \\leq \\mathop{\\bf E}(\\nu|{\\mathcal B})}")#text(", with the latter expression then being bounded by the Weierstrass approximation theorem and ")#link(<tao-aa58b21b01d6b8a99c1a>)[#text("(7)")]#text(".")

#text("To summarise, in order to establish the Roth-pseudorandomness of a measure ")#mi("{\\mu}")#text(", we have at least two options. The first (which relies on Fourier analysis, and is thus largely restricted to complexity ")#mi("{1}")#text(" problems) is to establish the Fourier pseudorandomness bound ")#link(<tao-6e4f542d909651df3579>)[#text("(3)")]#text(" and the restriction estimate ")#link(<tao-2320ebc76aece593ac3a>)[#text("(2)")]#text(". The other (which does not require Fourier analysis) is to establish a finite number of linear forms conditions, as well as the estimate ")#link(<tao-aa58b21b01d6b8a99c1a>)[#text("(7)")]#text(".")

#text("Next, we informally sketch how one can deduce ")#link(<tao-aa58b21b01d6b8a99c1a>)[#text("(7)")]#text(" from a finite number of linear forms conditions, as well as a crude estimate ")#metadata(none) <tao-c3ccedf562d9529001d8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\nu = O( N^{o(1)})")]]

#text("and a condition known as the ")#emph[#text("correlation condition")]#text(". At the cost of oversimplifying slightly, we express this condition as the assertion that ")#metadata(none) <tao-84bae4db933bb6e48e3d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\mathop{\\bf E}_{n \\in {\\bf Z}/N{\\bf Z}} \\nu(n+h_1) \\ldots \\nu(n+h_k) \\ll_k 1")]]

#text("whenever ")#mi("{h_1,\\ldots,h_k \\in {\\bf Z}/N{\\bf Z}}")#text(" are distinct, thus the ")#mi("{k}")#text("-point correlation function of ")#mi("{\\nu}")#text(" is bounded for each ")#mi("{k}")#text(". For the number-theoretic applications, one needs to replace the ")#mi("{1}")#text(" on the right-hand side by a more complicated expression, but we will defer this technicality to the exercises. We remark that for each fixed ")#mi("{k}")#text(", the correlation condition would be implied by the linear forms condition, but it is important that we can make ")#mi("{k}")#text(" arbitrarily large.")

#text("For simplicity of notation we assume that the ")#mi("{F_j}")#text(" are bounded in magnitude by ")#mi("{\\nu}")#text(" rather than by ")#mi("{\\nu+1}")#text(". We begin by expanding out ")#link(<tao-aa58b21b01d6b8a99c1a>)[#text("(7)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{n,h_{1,1},\\ldots,h_{2,k}} (\\nu(n)-1) \\prod_{j=1}^k F_j( n + h_{1,j} ) F_j( n + h_{2,j} ) F_j( n + h_{1,j} + h_{2,j} )\\right|.", block: true)]]

#text("Shifting ")#mi("{h_{i,j}}")#text(" by ")#mi("{h_i}")#text(" for some ")#mi("{h_1,h_2}")#text(" and re-averaging, we can rewrite this as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{h_{1,1},\\ldots,h_{2,k}} \\mathop{\\bf E}_{n,h_1,h_2} (\\nu(n)-1) F_{\\vec h_1}( n + h_{1} ) F_{\\vec h_2}( n + h_{2} ) F_{\\vec h_1 + \\vec h_2}( n + h_{1} + h_{2} )\\right|", block: true)]]

#text("where ")#mi("{\\vec h_i := (h_{i,1},\\ldots,h_{i,k})}")#text(" for ")#mi("{i=1,2}")#text(" and")

#align(center)[#tao-fit-display[#mitex("F_{(v_1,\\ldots,v_k)}(n) := \\prod_{j=1}^k F_j(n+v_j).")]]

#text("The inner expectation is the Gowers inner product of ")#mi("{\\nu-1}")#text(", ")#mi("{F_{\\vec h_1}}")#text(", ")#mi("{F_{\\vec h_2}}")#text(", and ")#mi("{F_{\\vec h_1+h_2}}")#text(". Using the linear forms condition we may assume that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|\\nu-1\\right\\|_{U^2({\\bf Z}/N{\\bf Z})} = o(1)", block: true)]]

#text("and so it will suffice by the Cauchy-Schwarz-Gowers inequality, followed by the Hölder inequality, to show that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{h_{1,1},\\ldots,h_{2,k}} F_{\\vec h_1} \\|_{U^2({\\bf Z}/N{\\bf Z})}^4 \\ll_K 1")]]

#text("and similarly for ")#mi("{\\vec h_2}")#text(" and ")#mi("{\\vec h_1+\\vec h_2}")#text(".")

#text("We just prove the claim for ")#mi("{\\vec h_1}")#text(", as the other two cases are similar. We expand the left-hand side as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{n,a,b,h_1,\\ldots,h_k} \\prod_{j=1}^k F_j( n + h_j ) F_j( n + h_j + a ) F_j( n + h_j + b ) F_j( n + h_j + a + b )\\right|", block: true)]]

#text("which we can upper bound by")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{n,a,b,h_1,\\ldots,h_k} \\prod_{j=1}^k \\nu( n + h_j ) \\nu( n + h_j + a ) \\nu( n + h_j + b ) \\nu( n + h_j + a + b )\\right|", block: true)]]

#text("We can factorise this as")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{a,b} \\left|\\mathop{\\bf E}_n \\nu( n ) \\nu( n + a ) \\nu( n + b ) \\nu( n + a + b )\\right|^k.", block: true)]]

#text("Using ")#link(<tao-84bae4db933bb6e48e3d>)[#text("(9)")]#text(", we see that the inner expectation is ")#mi("{O_k(1)}")#text(" as long as ")#mi("{0,a,b,a+b}")#text(" are distinct; in all other cases they are ")#mi("{O(N^{o(1)})}")#text(", by ")#link(<tao-c3ccedf562d9529001d8>)[#text("(8)")]#text(". Combining these two cases we obtain the claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Show that ")#link(<tao-aa58b21b01d6b8a99c1a>)[#text("(7)")]#text(" also follows from a finite number of linear forms conditions and ")#link(<tao-84bae4db933bb6e48e3d>)[#text("(9)")]#text(", if the ")#mi("{F_j}")#text(" are only assumed to be bounded in magnitude by ")#mi("{\\nu+1}")#text(" rather than ")#mi("{\\nu}")#text(", and the right-hand side of ")#link(<tao-84bae4db933bb6e48e3d>)[#text("(9)")]#text(" is weakened to ")#mi("{\\sum_{1 \\leq i < j \\leq m} \\tau(h_i-h_j)}")#text(", where ")#mi("{\\tau:{\\bf Z}/N{\\bf Z} \\rightarrow {\\bf R}^+}")#text(" is a function obeying the moment bounds ")#mi("{\\mathop{\\bf E}_{n \\in {\\bf Z}/N{\\bf Z}} \\tau(n)^q \\ll_q 1}")#text(" for each ")#mi("{q \\geq 1}")#text(".")
]

#text("The above machinery was geared to getting Roth-type lower bounds on ")#mi("{\\Lambda(f,f,f)}")#text("; but it also can be used to give more precise asymptotics:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Suppose that ")#mi("{\\nu}")#text(" obeys the hypotheses of Lemma ")#link(<tao-d5963d22f572ba25cba0>)[#text("5")]#text(" (with the ")#mi("{u^2}")#text(" norm). Let ")#mi("{f: {\\bf Z}/N{\\bf Z} \\rightarrow {\\bf R}}")#text(" obey the pointwise bound ")#mi("{0 \\leq f \\leq 1}")#text(" and has mean ")#mi("{\\mathop{\\bf E}_{n \\in {\\bf Z}/N{\\bf Z}} f(n) = \\delta}")#text("; suppose also that one has the pseudorandomness bound ")#tao-math("{\\sup_{\\xi \\in {\\bf Z}/N{\\bf Z} \\backslash 0}\\left|\\hat f(\\xi)\\right| = o_{N \\rightarrow \\infty}(1)}", block: false)#text(". Show that ")#mi("{\\Lambda(f,f,f) = \\delta^3 + o_{N \\rightarrow \\infty}(1)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Repeat the previous exercise, but with the ")#mi("{u^2}")#text(" norm replaced by the ")#mi("{U^2}")#text(" norm.")
]

#text("Informally, the above exercises show that if one wants to obtain asymptotics for three-term progressions in a set ")#mi("{A}")#text(" which has positive relative density with respect to a Roth-pseudorandom measure, then it suffices to obtain a non-trivial bound on the exponential sums ")#mi("{\\sum_{n \\in A} e( \\xi n )}")#text(" for non-zero frequencies ")#mi("{\\xi}")#text(".")

#text("For longer progressions, one uses higher-order Gowers norms, and a similar argument (using the inverse conjecture for the Gowers norms) shows (roughly speaking) that to obtain asymptotics for ")#mi("{k}")#text("-term progressions (or more generally, linear patterns of complexity ")#mi("{k-1}")#text(") in a ")#mi("{U^{k-1}}")#text("-pseudorandom measure (by which we mean that the analogue of Lemma ")#link(<tao-d5963d22f572ba25cba0>)[#text("5")]#text(" for the ")#mi("{U^{k-1}}")#text(" norm holds) then it suffices to obtain a non-trivial bound on sums of the form ")#mi("{\\sum_{n \\in A} F( g(n) \\Gamma )}")#text(" for ")#mi("{k-2}")#text("-step nilsequences ")#mi("{F(g(n) \\Gamma)}")#text(". See ")#link("http://arxiv.org/abs/math.NT/0606088")[#text("this paper of Green and myself")]#text(" for further discussion.")

#heading(level: 1)[#strong[#text(" — 2. A brief discussion of sieve theory — ")]]

#text("In order to apply the above theory to find patterns in the primes, we need to build a measure ")#mi("{\\nu}")#text(" with respect to which the primes have a positive density, and for which one can verify conditions such as the Fourier pseudorandomness condition ")#link(<tao-6e4f542d909651df3579>)[#text("(3)")]#text(", the restriction estimate ")#link(<tao-2320ebc76aece593ac3a>)[#text("(2)")]#text(", linear forms conditions, and the correlation condition ")#link(<tao-84bae4db933bb6e48e3d>)[#text("(9)")]#text(".")

#text("There is an initial problem with this, namely that the primes themselves are not uniformly distributed with respect to small moduli. For instance, all primes are coprime to two (with one exception). In contrast, any measure ")#mi("{\\nu}")#text(" obeying the Fourier pseudorandomness condition ")#link(<tao-6e4f542d909651df3579>)[#text("(3)")]#text(" (which is implied by the condition ")#tao-math("{\\left\\|\\nu-1\\right\\|_{U^2}=o(1)}", block: false)#text(", which would follow in turn from the linear forms condition), must be evenly distributed in both odd and even residue classes up to ")#mi("{o(1)}")#text(" errors; this forces the density of the primes in ")#mi("{\\nu}")#text(" to be at most ")#mi("{1/2+o(1)}")#text(". A similar argument using all the prime moduli less than some parameter ")#mi("{w}")#text(" shows in fact that the density of primes in ")#mi("{\\nu}")#text(" is at most ")#mi("{\\prod_{p<w} (1-\\frac{1}{p}) + o_{N \\rightarrow \\infty;w}(1)}")#text(". Since ")#mi("{\\sum_p \\frac{1}{p}}")#text(" diverges to ")#mi("{+\\infty}")#text(", ")#mi("{\\prod_p (1-\\frac{1}{p})}")#text(" diverges to zero, and so we see that the primes cannot in fact have a positive density with respect to any pseudorandom measure.")

#text("This difficulty can be overcome by a simple affine change of variables known as the ")#emph[#mi("{W}")#text("-trick")]#text(", where we replace the primes ")#mi("{{\\mathcal P} = \\{ 2, 3, 5, \\ldots \\}}")#text(" by the modified set ")#mi("{{\\mathcal P}_{W,b} := \\{ n \\in {\\bf N}: Wn+b \\in {\\mathcal P} \\}}")#text(", where ")#mi("{W := \\prod_{p<w} p}")#text(" is the product of all the primes less than ")#mi("{w}")#text(", and ")#mi("{1 \\leq b < W}")#text(" is a residue class coprime to ")#mi("{W}")#text(". In practice, ")#mi("{w}")#text(" (and ")#mi("{W}")#text(") are slowly growing functions of ")#mi("{N}")#text(", e.g. one could take ")#mi("{w = \\log \\log \\log N}")#text(". By the pigeonhole principle, for any given ")#mi("{N}")#text(" and ")#mi("{W}")#text(" there will exist a ")#mi("{b}")#text(" for which ")#mi("{{\\mathcal P}_{W,b}}")#text(" is large (of cardinality ")#mi("{\\gg \\frac{N}{\\phi(W) \\log N}}")#text(", where ")#mi("{\\phi(W)}")#text(" is the number of residue classes coprime to ")#mi("{W}")#text("); indeed, thanks to the prime number theorem in arithmetic progressions, any such ")#mi("{b}")#text(" would work (e.g. one can take ")#mi("{b=1}")#text("). Note that every arithmetic progression in ")#mi("{{\\mathcal P}_{W,b}}")#text(" is associated to a corresponding arithmetic progression in ")#mi("{{\\mathcal P}}")#text(". Thus, for the task of locating arithmetic progressions at least, we may as well work with ")#mi("{{\\mathcal P}_{W,b}}")#text("; a similar claim also holds for more complicated tasks, such as counting the number of linear patterns in ")#mi("{{\\mathcal P}}")#text(", though one now has to work with several residue classes at once. The point of passing from ")#mi("{{\\mathcal P}}")#text(" to ")#mi("{{\\mathcal P}_{W,b}}")#text(" is that the latter set no longer has any particular bias to favorr or disfavour any residue class with modulus less than ")#mi("{w}")#text("; there are still biases at higher moduli, but as long as ")#mi("{w}")#text(" goes to infinity with ")#mi("{N}")#text(", the effect of such biases will end up being negligible (ultimately contributing ")#mi("{o(1)}")#text(" terms to things like the linear forms condition).")

#text("To simplify the exposition a bit, though, let us ignore the ")#mi("{W}")#text("-trick and pretend that we are working with the primes themselves rather than the affine-shifted primes. We will also ignore the technical distinctions between the interval ")#mi("{[N]}")#text(" and the cyclic group ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(".")

#text("The most natural candidate for the measure ")#mi("{\\nu}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(" ")#mi("{\\Lambda: {\\bf N} \\rightarrow {\\bf R}^+}")#text(", defined by setting ")#mi("{\\Lambda(n) :=\\log p}")#text(" when ")#mi("{n=p^j}")#text(" is a prime ")#mi("{p}")#text(" or a power of a prime, and ")#mi("{\\Lambda(n)=0}")#text(" otherwise. One hint as to the significance of this function is provided by the identity")

#align(center)[#tao-fit-display[#mitex("\\log n = \\sum_{d|n} \\Lambda(d)")]]

#text("for all natural numbers ")#mi("{n}")#text(", which can be viewed as a generating function of the fundamental theorem of arithmetic.")

#text("The prime number theorem tells us that ")#mi("{\\Lambda}")#text(" is indeed a measure: ")#mi("{\\mathop{\\bf E}_{n \\in [N]} \\Lambda(n) = 1 + o(1)}")#text(". And the primes have full density with respect to this function: ")#mi("{\\mathop{\\bf E}_{n \\in [N]} 1_{\\mathcal P}(n) \\Lambda(n) = 1 + o(1)}")#text(". Furthermore, the von Mangoldt function has good Fourier pseudorandomness properties (after applying the ")#mi("{W}")#text("-trick), thanks to the classical techniques of Hardy-Littlewood and Vinogradov. Indeed, to control exponential sums such as ")#mi("{\\mathop{\\bf E}_{n \\in [N]} \\Lambda(n) e( \\xi n )}")#text(" for some ")#mi("{\\xi \\in {\\bf R}}")#text(", one can use tools such as the Siegel-Walfisz theorem (a quantitative version of the prime number theorem in arithmetic progressions) to control such sums in the “major arc” case when ")#mi("{\\xi}")#text(" is close to a rational of small height, while in the “minor arc” case when ")#mi("{\\xi}")#text(" behaves irrationally, one can use the standard identity ")#metadata(none) <tao-e545c2c24e6463d7c4fe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\Lambda(n) = \\sum_{d|n} \\mu(d) \\log\\frac{n}{d},")]]

#text("where ")#mi("{\\mu}")#text(" is the ")#link("http://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(", to re-express such a sum in terms of expressions roughly of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{d,m} \\mu(d) \\log m e( \\xi dm )")]]

#text("where we are intentionally vague as to what range the ")#mi("{d,m}")#text(" parameters are being summed over. The idea is then to eliminate the ")#mi("{\\mu}")#text(" factor by tools such as the triangle inequality or the Cauchy-Schwarz inequality, leading to expressions such as")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d} \\left|\\sum_m \\log m e( \\xi dm )\\right|;", block: true)]]

#text("the point is that the inner sum does not contain any number-theoretic factors such as ")#mi("{\\Lambda}")#text(" or ")#mi("{\\mu}")#text(", but is still oscillatory (at least if ")#mi("{\\xi}")#text(" is sufficiently irrational), and so one can extract useful cancellation from here. Actually, the situation is more complicated than this, because there are regions of the range of ")#mi("{(d,m)}")#text(" for which this method provides insufficient cancellation, in which case one has to rearrange the sum further using more arithmetic identities such as ")#link(<tao-e545c2c24e6463d7c4fe>)[#text("(10)")]#text(" (for instance, using a truncated version of ")#link(<tao-e545c2c24e6463d7c4fe>)[#text("(10)")]#text(" known as ")#emph[#text("Vaughan’s identity")]#text("). We will not discuss this further here, but any advanced analytic number theory text (e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec-Kowalski")]#text(") will cover this material.")

#text("Unfortunately, while the Fourier-pseudorandomness of ")#mi("{\\Lambda}")#text(" is well-understood, the linear forms and correlation conditions are essentially equivalent to (and in fact slightly harder than) the original problem of obtaining asymptotics for linear patterns in primes, and so using ")#mi("{\\Lambda}")#text(" for the pseudorandom measure would result in a circular argument. Furthermore, correlations such as")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} \\Lambda(n) \\Lambda(n+2)")]]

#text("(which essentially counts the number of twin primes up to ")#mi("{N}")#text(") are notoriously difficult to compute. For instance, if one tries to expand the above sum using ")#link(<tao-e545c2c24e6463d7c4fe>)[#text("(10)")]#text(", one ends up with expressions such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d,d^{\\prime} \\leq N} \\mu(d) \\mu(d^{\\prime}) \\sum_{n \\leq N: d|n, d^{\\prime} | n+2} \\log \\frac{n}{d} \\log \\frac{n+2}{d^{\\prime}}.")]]

#text("By the Chinese remainder theorem, the two residue conditions ")#mi("{d|n, d^{\\prime}|n+2}")#text(" can be combined to a single residue condition for ")#mi("{n}")#text(" modulo the least common multiple ")#mi("{lcm(d,d^{\\prime})}")#text(" of ")#mi("{d}")#text(" and ")#mi("{d^{\\prime}}")#text(". If ")#mi("{d}")#text(" and ")#mi("{d^{\\prime}}")#text(" are both small, e.g. ")#mi("{d, d^{\\prime} \\leq N^{1/10}}")#text(", then this least common multiple is much less than ")#mi("{N}")#text(", and in such a case one can compute the inner sum very precisely; as it turns out, the main term in this estimate is multiplicative in ")#mi("{d,d^{\\prime}}")#text(", which allows the outer sum to be estimated using the techniques of multiplicative number theory (and in particular, using the theory of the Riemann zeta function). Unfortunately, for the bulk of the above sum, ")#mi("{d}")#text(" and ")#mi("{d^{\\prime}}")#text(" are instead comparable to ")#mi("{N}")#text(", and the least common multiple is typically of size ")#mi("{N^2}")#text(", and then it becomes extraordinarily difficult to estimate the inner sum (and hence the entire sum).")

#text("However, if we ")#emph[#text("truncate")]#text(" the divisor sum ")#link(<tao-e545c2c24e6463d7c4fe>)[#text("(10)")]#text(" to restrict ")#mi("{d}")#text(" to a range such as ")#mi("{d \\leq N^{1/10}}")#text(", then the situation improves substantially. This leads to expressions such as ")#metadata(none) <tao-97b595ff18871e5226df>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\nu(n) := \\frac{1}{\\log R} ( \\sum_{d|n; d<R} \\mu(d) \\log\\frac{R}{d} )^2")]]

#text("or more generally ")#metadata(none) <tao-4f75bb3d593b7636558d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\nu(n) := \\log R ( \\sum_{d|n} \\mu(d) \\psi( \\frac{\\log d}{\\log R} ) )^2")]]

#text("for some cutoff function ")#mi("{\\psi}")#text(", where ")#mi("{R}")#text(" is a small power of ")#mi("{N}")#text(" (e.g. ")#mi("{R = N^{1/10}}")#text("); the expression ")#link(<tao-97b595ff18871e5226df>)[#text("(11)")]#text(" corresponds to the case ")#mi("{\\psi(x) := \\max(1-x,0)}")#text(". The presence of the square is to ensure that ")#mi("{\\nu}")#text(" is non-negative, and the presence of the ")#mi("{\\frac{1}{\\log R}}")#text(" is a normalisation factor to ensure that ")#mi("{\\nu}")#text(" has mean close to ")#mi("{1}")#text(". Such expressions were essentially introduced to Selberg (as part of what is now known as the ")#emph[#text("Selberg sieve")]#text("), although the sieve weight factors ")#mi("{\\psi(\\frac{\\log d}{\\log R})}")#text(" are usually modified slightly for the Selberg sieve (see ")#link("http://front.math.ucdavis.edu/math.NT/0405581")[#text("this paper of Green and myself")]#text(" for further discussion). The correlation properties of the particular expression ")#link(<tao-97b595ff18871e5226df>)[#text("(11)")]#text(" were studied intensively by Goldston and Yildirim, and have particularly sharp estimates, although for applications discussed here, one can work instead with a smoother choice of cutoff ")#mi("{\\psi}")#text(", which makes the required correlation estimates on ")#mi("{\\nu}")#text(" easier to prove (but with slightly worse bounds). Indeed, the required linear forms and correlation conditions can be verified for ")#link(<tao-4f75bb3d593b7636558d>)[#text("(12)")]#text(" (or more precisely, a variant of ")#mi("{\\nu}")#text(" in which the ")#mi("{W}")#text("-trick is applied) by a moderately lengthy, but elementary and straightforward calculation, based ultimately on the Chinese remainder theorem, an analysis of the local problem (working mod ")#mi("{q}")#text(" for small ")#mi("{q}")#text("), and the fundamental fact that the Riemann zeta function ")#mi("{\\zeta(s)}")#text(" is approximately equal to ")#mi("{1/(s-1)}")#text(" for ")#mi("{s}")#text(" close to ")#mi("{1}")#text(". See for instance ")#link("http://www.math.ucla.edu/~tao/preprints/Expository/gy-corr.dvi")[#text("this unpublished note of mine")]#text(" for more discussion. (The exact power of ")#mi("{N}")#text(" that one sets ")#mi("{R}")#text(" equal to will depend on the complexity of the linear forms and co")

#text("If one uses ")#link(<tao-97b595ff18871e5226df>)[#text("(11)")]#text(", then we see that ")#mi("{\\nu(n)}")#text(" is equal to ")#mi("{\\log R}")#text(" when ")#mi("{n}")#text(" is any prime larger than ")#mi("{R}")#text("; if ")#mi("{\\log R}")#text(" is comparable to ")#mi("{\\log N}")#text(", we thus see (from the prime number theorem) that the primes in ")#mi("{[N]}")#text(" do indeed have positive density relative to ")#mi("{\\nu}")#text(". This is then enough to be able to invoke the transference principle and extend results such as Szemerédi’s theorem to the primes, establishing in particular that the primes contain arbitrarily long arithmetic progressions; see this ")#link("http://www.ams.org/mathscinet-getitem?mr=2415379")[#text("paper of Green and myself")]#text(" for details.")

#text("To use the Fourier-analytic approach, it turns out to be convenient to replace the above measures ")#mi("{\\nu}")#text(" by a slight variant which looks more complicated in the spatial domain, but is easier to manipulate in the frequency domain. More specifically, the expression ")#link(<tao-97b595ff18871e5226df>)[#text("(11)")]#text(" or ")#link(<tao-4f75bb3d593b7636558d>)[#text("(12)")]#text(" is replaced with a variant such as")

#align(center)[#tao-fit-display[#mitex("\\nu := \\log R ( \\sum_{d|n; d \\leq R} \\mu(d) \\frac{d}{\\phi(d)} \\sum_{q \\leq R/d; (q,d)=1} \\frac{1}{\\phi(q)} )^2")]]

#text("where ")#mi("{\\phi(d)}")#text(" is the Euler totient function (the number of integers from ")#mi("{1}")#text(" to ")#mi("{d}")#text(" that are coprime to ")#mi("{d}")#text("). Some standard multiplicative number theory shows that the weights ")#mi("{\\frac{d}{\\phi(d)} \\sum_{q \\leq R/d; (q,d)=1} \\frac{1}{\\phi(q)}}")#text(" are approximately equal to ")#mi("{\\log \\frac{R}{d}}")#text(" in some sense. With such a representation, it turns out that the Fourier coefficients of ")#mi("{\\nu}")#text(" can be computed more or less explicitly, and is essentially supported on those frequencies of the form ")#mi("{a/q}")#text(" with ")#mi("{q \\leq R^2}")#text(". This makes it easy to verify the required Fourier-pseudorandomness hypothesis ")#link(<tao-6e4f542d909651df3579>)[#text("(3)")]#text(" (once one applies the ")#mi("{W}")#text("-trick). As for the restriction estimate ")#link(<tao-2320ebc76aece593ac3a>)[#text("(2)")]#text(", the first step is to use Exercise ")#link(<tao-14e2bb80e5ea48fbad04>)[#text("(3)")]#text(" and the Cauchy-Schwarz inequality to reduce matters to showing an estimate of the shape")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{n} \\left|\\sum_{\\xi} g(\\xi) e(\\xi n x/N)\\right|^2 \\nu(n) \\ll \\left\\|g\\right\\|_{\\ell^{q^{\\prime}}}.", block: true)]]

#text("The right-hand side can be rearranged to be of the shape")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\xi, \\xi^{\\prime}} g(\\xi) \\overline{g(\\xi^{\\prime})} \\hat \\nu(\\xi - \\xi^{\\prime}).")]]

#text("It is then possible to use the good pointwise control on the Fourier transform ")#mi("{\\hat \\nu}")#text(" of ")#mi("{\\nu}")#text(" (in particular, the fact that it “decays” quite rapidly away from the major arcs) to get a good restriction estimate. See ")#link("http://front.math.ucdavis.edu/math.NT/0405581")[#text("this paper of Green and myself")]#text(" for further discussion.")

#text("As discussed in the previous section, to get asymptotics for patterns in the primes we also need to control exponential sums such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq N} e( \\xi p )")]]

#text("and more generally (for higher complexity patterns)")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq N} F( g(p) \\Gamma )")]]

#text("for various nilsequences ")#mi("{n \\mapsto F(g(n)\\Gamma)}")#text(". Again, it is convenient to use the von Mangoldt function ")#mi("{\\Lambda}")#text(" as a proxy for the primes, thus leading to expressions such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq N} \\Lambda(n) F( g(n) \\Gamma ).")]]

#text("Actually, for technical reasons it is convenient to use identities such as ")#link(<tao-e545c2c24e6463d7c4fe>)[#text("(10)")]#text(" to replace this type of expression with expressions such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq N} \\mu(n) F( g(n) \\Gamma ),")]]

#text("because the Möbius function ")#mi("{\\mu}")#text(" enjoys better boundedness and equidistribution properties than ")#mi("{\\Lambda}")#text(". (For instance, ")#mi("{\\Lambda}")#text(" strongly favours odd numbers over even numbers, whereas the Möbius function has no preference.) It turns out that these expressions can be controlled by a generalisation of the method of Vinogradov used to compute exponential sums over primes, using the equidistribution theory of nilsequences as a substitute for the classical theory of exponential sums over integers. See ")#link("http://arxiv.org/abs/0807.1736")[#text("this paper of Green and myself")]#text(" for details.")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/06/05/254b-lecture-notes-7-the-transference-principle-and-linear-equations-in-primes/#comment-45350")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2010")])]

#text("typo in the first sentence: “we give discuss”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/650b7c8b1a2ea5fbe7f86fc75c75b138fbed3aa0e70922a2ea3d25f5ff6e5fe9-e07bb92e3452285aa4787e1e7a3904351d0fdc59936ebd227e52373545dc7259.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sylvain JULIEN")]], [#link("https://terrytao.wordpress.com/2010/06/05/254b-lecture-notes-7-the-transference-principle-and-linear-equations-in-primes/#comment-46802")[#strong[#text("Sylvain JULIEN")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2010")])]

#text("As you write “the even Goldbach equation {p_1+p_2=N} – remain out of reach of this technology”, must I conclude that Bruckman’s attempt of proof of this conjecture in “International Journal of Mathematical Education in Science and Technology, Volume 39, Issue 8 December 2008 , pages 1102 – 1109” is false ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/06/05/254b-lecture-notes-7-the-transference-principle-and-linear-equations-in-primes/#comment-46810")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2010")])]

#text("I took a quick look at the article. Unfortunately it seems that the author has not handled asymptotic notation properly. (For instance, the conclusion of Theorem 2 does not even make sense, because it involves an asymptotic quantity o(1) but no asymptotic parameter N.) More seriously, it seems that there is an error in the previous paper [1] of the author which is being used here, due to another misuse of asymptotic notation; the author at one point implicitly uses the claim that if ")#mi("f_k(N) \\sim g_k(N)")#text(" for all k, and ")#mi("c_k")#text(" are coefficients, then ")#mi("\\sum_k c_k f_k(N) \\sim \\sum_k c_k g_k(N)")#text(" if both sides converge. This claim is correct if all quantities are positive (and the convergence is sufficiently strong), but is not true in the presence of cancellation. For instance, if ")#mi("f_1(N) := N^2+N, g_1(N) := N^2+1, f_2(N) = g_2(N) := N^2")#text(", then ")#mi("f_1(N) \\sim g_1(N)")#text(" and ")#mi("f_2(N) \\sim g_2(N)")#text(", but ")#mi("f_1(N) - f_2(N) \\not \\sim g_1(N) - g_2(N)")#text(".")

#text("Asymptotic notation is a convenient and time-saving tool when used correctly, but can be dangerous to use if one does not know what one is doing. A good rule of thumb when using any tool of this sort is to see whether one’s arguments could also be rephrased without resorting to this tool (possibly at the cost of making the argument longer and messier). If one does not see how one could do this, then that is a sign that one might not be properly understanding how that tool works, and in particular may not ")#link("https://terrytao.wordpress.com/career-advice/learn-the-limitations-of-your-tools/")[#text("be aware of the limitations of that tool")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/650b7c8b1a2ea5fbe7f86fc75c75b138fbed3aa0e70922a2ea3d25f5ff6e5fe9-e07bb92e3452285aa4787e1e7a3904351d0fdc59936ebd227e52373545dc7259.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sylvain JULIEN")]], [#link("https://terrytao.wordpress.com/2010/06/05/254b-lecture-notes-7-the-transference-principle-and-linear-equations-in-primes/#comment-46813")[#strong[#text("Sylvain JULIEN")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2010")])]

#text("Ok, thank you very much for your quick reply. I had sent an e-mail to you a few weeks ago to ask you this question, but I know that you do not have much time to answer. Thank you again.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/06/05/254b-lecture-notes-7-the-transference-principle-and-linear-equations-in-primes/#comment-685684")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2024")])]

#text("Just amazing")
]
