// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/
// Converted to Typst by tao2typ: "2026-10-14T15:19:38.131304+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A conjectural local Fourier-uniformity of the Liouville function", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A conjectural local Fourier-uniformity of the Liouville function")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 December 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/")[#text("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{\\lambda}")#text(" denote the ")#link("https://en.wikipedia.org/wiki/Liouville_function")[#text("Liouville function")]#text(". The prime number theorem is equivalent to the estimate")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\lambda(n) = o(x)")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(", that is to say that ")#mi("{\\lambda}")#text(" exhibits cancellation on large intervals such as ")#mi("{[1,x]}")#text(". This result can be improved to give cancellation on shorter intervals. For instance, using the known zero density estimates for the Riemann zeta function, one can establish that ")#metadata(none) <tao-adc6e9ebc4eadea7ba44>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\int_X^{2X} |\\sum_{x \\leq n \\leq x+H} \\lambda(n)|\\ dx = o( HX )")]]



#text(" as ")#mi("{X \\rightarrow \\infty}")#text(" if ")#mi("{X^{1/6+\\varepsilon} \\leq H \\leq X}")#text(" for some fixed ")#mi("{\\varepsilon>0}")#text("; I believe this result is ")#link("http://www.ams.org/mathscinet-getitem?mr=424723")[#text("due to Ramachandra")]#text(" (see also Exercise 21 of ")#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/")[#text("this previous blog post")]#text("), and in fact one could obtain a better error term on the right-hand side that for instance gained an arbitrary power of ")#mi("{\\log X}")#text(". On the Riemann hypothesis (or the weaker density hypothesis), it was known that the ")#mi("{X^{1/6+\\varepsilon}}")#text(" could be lowered to ")#mi("{X^\\varepsilon}")#text(".")

#text("Early this year, there was a ")#link("http://arxiv.org/abs/1501.04585")[#text("major breakthrough by Matomaki and Radziwill")]#text(", who (among other things) showed that the asymptotic ")#link(<tao-adc6e9ebc4eadea7ba44>)[#text("(1)")]#text(" was in fact valid for ")#emph[#text("any")]#text(" ")#mi("{H = H(X)}")#text(" with ")#mi("{H \\leq X}")#text(" that went to infinity as ")#mi("{X \\rightarrow \\infty}")#text(", thus yielding cancellation on extremely short intervals. This has many further applications; for instance, this estimate, or more precisely its extension to other “non-pretentious” bounded multiplicative functions, was a key ingredient in ")#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/")[#text("my recent solution of the Erdös discrepancy problem")]#text(", as well as in obtaining logarithmically averaged cases of Chowla’s conjecture, such as ")#metadata(none) <tao-254bb97b57f12e1608fe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{n \\leq x} \\frac{\\lambda(n) \\lambda(n+1)}{n} = o(\\log x).")]]





#text("It is of interest to twist the above estimates by phases such as the linear phase ")#mi("{n \\mapsto e(\\alpha n) := e^{2\\pi i \\alpha n}}")#text(". In 1937, Davenport showed that")

#align(center)[#tao-fit-display[#tao-math("\\sup_\\alpha \\left|\\sum_{n \\leq x} \\lambda(n) e(\\alpha n)\\right| \\ll_A x \\log^{-A} x", block: true)]]

#text("which of course improves the prime number theorem. ")#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/")[#text("Recently with Matomaki and Radziwill")]#text(", we obtained a common generalisation of this estimate with ")#link(<tao-adc6e9ebc4eadea7ba44>)[#text("(1)")]#text(", showing that ")#metadata(none) <tao-fa4b905a71a4f87030fb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sup_\\alpha \\int_X^{2X} |\\sum_{x \\leq n \\leq x+H} \\lambda(n) e(\\alpha n)|\\ dx = o(HX)")]]



#text(" as ")#mi("{X \\rightarrow \\infty}")#text(", for any ")#mi("{H = H(X) \\leq X}")#text(" that went to infinity as ")#mi("{X \\rightarrow \\infty}")#text(". We were able to use this estimate to obtain an averaged form of Chowla’s conjecture.")

#text("In that paper, we asked whether one could improve this estimate further by moving the supremum inside the integral, that is to say to establish the bound ")#metadata(none) <tao-761db75f39c8c8eb42ba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\int_X^{2X} \\sup_\\alpha \\left|\\sum_{x \\leq n \\leq x+H} \\lambda(n) e(\\alpha n)\\right|\\ dx = o(HX)", block: true)]]



#text(" as ")#mi("{X \\rightarrow \\infty}")#text(", for any ")#mi("{H = H(X) \\leq X}")#text(" that went to infinity as ")#mi("{X \\rightarrow \\infty}")#text(". This bound is asserting that ")#mi("{\\lambda}")#text(" is locally Fourier-uniform on most short intervals; it can be written equivalently in terms of the “local Gowers ")#mi("{U^2}")#text(" norm” as")

#align(center)[#tao-fit-display[#tao-math("\\int_X^{2X} \\sum_{1 \\leq a \\leq H} \\left|\\sum_{x \\leq n \\leq x+H} \\lambda(n) \\lambda(n+a)\\right|^2\\ dx = o( H^3 X )", block: true)]]

#text("from which one can see that this is another averaged form of Chowla’s conjecture (stronger than the one I was able to prove with Matomaki and Radziwill, but a consequence of the unaveraged Chowla conjecture). If one inserted such a bound into the machinery I used to solve the Erdös discrepancy problem, it should lead to further averaged cases of Chowla’s conjecture, such as ")#metadata(none) <tao-18ba2cea8c90f815c8f3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_{n \\leq x} \\frac{\\lambda(n) \\lambda(n+1) \\lambda(n+2)}{n} = o(\\log x),")]]



#text(" though I have not fully checked the details of this implication. It should also have a number of new implications for sign patterns of the Liouville function, though we have not explored these in detail yet.")

#text("One can write ")#link(<tao-761db75f39c8c8eb42ba>)[#text("(4)")]#text(" equivalently in the form ")#metadata(none) <tao-9c46149f40d685ebd89c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\int_X^{2X} \\sum_{x \\leq n \\leq x+H} \\lambda(n) e( \\alpha(x) n + \\beta(x) )\\ dx = o(HX)")]]



#text(" uniformly for all ")#mi("{x}")#text("-dependent phases ")#mi("{\\alpha(x), \\beta(x)}")#text(". In contrast, ")#link(<tao-fa4b905a71a4f87030fb>)[#text("(3)")]#text(" is equivalent to the subcase of ")#link(<tao-9c46149f40d685ebd89c>)[#text("(6)")]#text(" when the linear phase coefficient ")#mi("{\\alpha(x)}")#text(" is independent of ")#mi("{x}")#text(". This dependency of ")#mi("{\\alpha(x)}")#text(" on ")#mi("{x}")#text(" seems to necessitate some highly nontrivial additive combinatorial analysis of the function ")#mi("{x \\mapsto \\alpha(x)}")#text(" in order to establish ")#link(<tao-761db75f39c8c8eb42ba>)[#text("(4)")]#text(" when ")#mi("{H}")#text(" is small. To date, this analysis has proven to be elusive, but I would like to record what one can do with more classical methods like Vaughan’s identity, namely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" The estimate ")#link(<tao-761db75f39c8c8eb42ba>)[#text("(4)")]#text(" (or equivalently ")#link(<tao-9c46149f40d685ebd89c>)[#text("(6)")]#text(") holds in the range ")#mi("{X^{2/3+\\varepsilon} \\leq H \\leq X}")#text(" for any fixed ")#mi("{\\varepsilon>0}")#text(". (In fact one can improve the right-hand side by an arbitrary power of ")#mi("{\\log X}")#text(" in this case.)")
]

#text("The values of ")#mi("{H}")#text(" in this range are far too large to yield implications such as new cases of the Chowla conjecture, but it appears that the ")#mi("{2/3}")#text(" exponent is the limit of “classical” methods (at least as far as I was able to apply them), in the sense that one does not do any combinatorial analysis on the function ")#mi("{x \\mapsto \\alpha(x)}")#text(", nor does one use modern equidistribution results on “Type III sums” that require deep estimates on Kloosterman-type sums. The latter may shave a little bit off of the ")#mi("{2/3}")#text(" exponent, but I don’t see how one would ever hope to go below ")#mi("{1/2}")#text(" without doing some non-trivial combinatorics on the function ")#mi("{x \\mapsto \\alpha(x)}")#text(". UPDATE: I have come across ")#link("http://www.ams.org/mathscinet-getitem?mr=1141240")[#text("this paper of Zhan")]#text(" which uses mean-value theorems for L-functions to lower the ")#mi("{2/3}")#text(" exponent to ")#mi("{5/8}")#text(".")

#text("Let me now sketch the proof of the proposition, omitting many of the technical details. We first remark that known estimates on sums of the Liouville function (or similar functions such as the von Mangoldt function) in short arithmetic progressions, based on zero-density estimates for Dirichlet ")#mi("{L}")#text("-functions, can handle the “major arc” case of ")#link(<tao-761db75f39c8c8eb42ba>)[#text("(4)")]#text(" (or ")#link(<tao-9c46149f40d685ebd89c>)[#text("(6)")]#text(") where ")#mi("{\\alpha}")#text(" is restricted to be of the form ")#mi("{\\alpha = \\frac{a}{q} + O( X^{-1/6-\\varepsilon} )}")#text(" for ")#mi("{q = O(\\log^{O(1)} X)}")#text(" (the exponent here being of the same numerology as the ")#mi("{X^{1/6+\\varepsilon}}")#text(" exponent in the classical result of Ramachandra, tied to the best zero density estimates currently available); for instance a modification of the arguments in ")#link("http://arxiv.org/abs/1405.6592")[#text("this recent paper of Koukoulopoulos")]#text(" would suffice. Thus we can restrict attention to “minor arc” values of ")#mi("{\\alpha}")#text(" (or ")#mi("{\\alpha(x)}")#text(", using the interpretation of ")#link(<tao-9c46149f40d685ebd89c>)[#text("(6)")]#text(").")

#text("Next, one breaks up ")#mi("{\\lambda}")#text(" (or the closely related Möbius function) into Dirichlet convolutions using one of the standard identities (e.g. Vaughan’s identity or Heath-Brown’s identity), as discussed for instance in this ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("previous post")]#text(" (which is focused more on the von Mangoldt function, but analogous identities exist for the Liouville and Möbius functions). The exact choice of identity is not terribly important, but the upshot is that ")#mi("{\\lambda(n)}")#text(" can be decomposed into ")#mi("{\\log^{O(1)} X}")#text(" terms, each of which is either of the “Type I” form")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\sim D; m \\sim M: dm=n} a_d")]]

#text("for some coefficients ")#mi("{a_d}")#text(" that are roughly of logarithmic size on the average, and scales ")#mi("{D, M}")#text(" with ")#mi("{D \\ll X^{2/3}}")#text(" and ")#mi("{DM \\sim X}")#text(", or else of the “Type II” form")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\sim D; m \\sim M: dm=n} a_d b_m")]]

#text("for some coefficients ")#mi("{a_d, b_m}")#text(" that are roughly of logarithmic size on the average, and scales ")#mi("{D,M}")#text(" with ")#mi("{X^{1/3} \\ll D,M \\ll X^{2/3}}")#text(" and ")#mi("{DM \\sim X}")#text(". As discussed in ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("the previous post")]#text(", the ")#mi("{2/3}")#text(" exponent is a natural barrier in these identities if one is unwilling to also consider “Type III” type terms which are roughly of the shape of the third divisor function ")#mi("{\\tau_3(n) := \\sum_{d_1d_2d_3=1} 1}")#text(".")

#text("A Type I sum makes a contribution to ")#mi("{ \\sum_{x \\leq n \\leq x+H} \\lambda(n) e( \\alpha(x) n + \\beta(x) )}")#text(" that can be bounded (via Cauchy-Schwarz) in terms of an expression such as")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d \\sim D} \\left| \\sum_{x/d \\leq m \\leq x/d+H/d} e(\\alpha(x) dm )\\right|^2.", block: true)]]

#text("The inner sum exhibits a lot of cancellation unless ")#mi("{\\alpha(x) d}")#text(" is within ")#mi("{O(D/H)}")#text(" of an integer. (Here, “a lot” should be loosely interpreted as “gaining many powers of ")#mi("{\\log X}")#text(" over the trivial bound”.) Since ")#mi("{H}")#text(" is significantly larger than ")#mi("{D}")#text(", standard Vinogradov-type manipulations (see e.g. Lemma 13 of ")#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/")[#text("these previous notes")]#text(") show that this bad case occurs for many ")#mi("{d}")#text(" only when ")#mi("{\\alpha}")#text(" is “major arc”, which is the case we have specifically excluded. This lets us dispose of the Type I contributions.")

#text("A Type II sum makes a contribution to ")#mi("{ \\sum_{x \\leq n \\leq x+H} \\lambda(n) e( \\alpha(x) n + \\beta(x) )}")#text(" roughly of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\sim D} | \\sum_{x/d \\leq m \\leq x/d+H/d} b_m e(\\alpha(x) dm)|.")]]

#text("We can break this up into a number of sums roughly of the form")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d = d_0 + O( H / M )} \\left| \\sum_{x/d_0 \\leq m \\leq x/d_0 + H/D} b_m e(\\alpha(x) dm)\\right|", block: true)]]

#text("for ")#mi("{d_0 \\sim D}")#text("; note that the ")#mi("{d}")#text(" range is non-trivial because ")#mi("{H}")#text(" is much larger than ")#mi("{M}")#text(". Applying the usual bilinear sum Cauchy-Schwarz methods (e.g. Theorem 14 of ")#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/")[#text("these notes")]#text(") we conclude that there is a lot of cancellation unless one has ")#mi("{\\alpha(x) = a/q + O( \\frac{X \\log^{O(1)} X}{H^2} )}")#text(" for some ")#mi("{q = O(\\log^{O(1)} X)}")#text(". But with ")#mi("{H \\geq X^{2/3+\\varepsilon}}")#text(", ")#mi("{X \\log^{O(1)} X/H^2}")#text(" is well below the threshold ")#mi("{X^{-1/6-\\varepsilon}}")#text(" for the definition of major arc, so we can exclude this case and obtain the required cancellation.")

#heading(level: 1)[#text("Comments (22)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-462901")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2015")])]

#text("In the line above the last one, it seems that the argument “")#mi("X")#text("” after “")#mi("\\log ^{O(1)}")#text("” is missing.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-462906")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2015")])]

#text("It seems that the “local Gowers U^2” formulation after (4) can be further reformulated in the following manner (expanding the square): Assume the conjecture is false. Then for each ")#mi("n \\in [X,2X]")#text(" the “additive energy” of the sequence ")#mi("\\lambda(x)")#text(" restricted to the sub-interval ")#mi("[n,n+h]")#text(" is nearly as large as possible (there’s some boundary issues with the endpoints of the intervals that I’m assuming can be ignored here).")

#text("I haven’t thought this through carefully but heuristically it seems that BSG and Freiman type arguments should then imply that there is a large (maybe even proportional?) sized AP in ")#mi("[n,n+h]")#text(" on which ")#mi("\\lambda(x)")#text(" is nearly constant for each ")#mi("n \\in [X,2X]")#text(". This of course is absurd but, more importantly, is a question about ")#mi("\\lambda(x)")#text(" and not its correlations. If the AP’s were proportionally sized, one should then be able to pigeonhole the step sizes to contradict a variant of the original result of Matomaki and Radziwill adapted to APs.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-462925")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2015")])]

#text("The enemy occurs when ")#mi("\\lambda(n)")#text(" is locally constant on Bohr sets such as ")#mi("\\{ n \\in [x,x+H]: \\{ \\alpha n \\} \\in [0,1/2]\\}")#text(", which occupy a positive density fraction of ")#mi("[x,x+H]")#text(". They do contain reasonably long APs, but the length and spacing of these APs is typically of size ")#mi("\\sqrt{H}")#text(" rather than ")#mi("H")#text(", which is beyond the range of the Matomaki-Radziwill theory.")

#text("Here is an example which indicates that the problem needs new ideas beyond the MR results. Consider the completely multiplicative function ")#mi("f(n) := n^{it}")#text(" with ")#mi("t \\sim X^{2-\\varepsilon}")#text(" for some small ")#mi("\\varepsilon")#text(". On the one hand, this function is non-pretentious in the sense that it is not close (in the Granville-Soundararajan sense) on ")#mi("[1,X]")#text(" to a character of the form ")#mi("n \\mapsto \\chi(n) n^{it^{\\prime}}")#text(" for some Dirichlet character ")#mi("\\chi")#text(" of small conductor and some ")#mi("t^{\\prime} = O(X)")#text(". As such, the MR theory kicks in and tells us that ")#mi("f(n)")#text(" has small mean on most intervals of the form ")#mi("[x,x+H]")#text(", and also on most arithmetic progressions of bounded spacing. On the other hand, Taylor expansion shows that ")#mi("f(n)")#text(" has large Gowers ")#mi("U^2")#text(" norm on intervals ")#mi("[x,x+H]")#text(" with ")#mi("x \\sim X")#text(" and ")#mi("H")#text(" as large as ")#mi("X^{\\varepsilon/2}")#text(". Indeed this function is almost constant on fairly large Bohr sets in ")#mi("[x,x+H]")#text(", without contradicting the MR results.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-463034")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2015")])]

#text("That makes a lot of sense, thanks!")

#text("Here’s an amusing observation: Assume that the 3-correlation estimate (and thus (4)) fails. Then on most intervals of the form ")#mi("[n,n+h]")#text(" we have that ")#mi("\\lambda(n)")#text(" correlates with a phase function. Now consider the twisted quantity ")#mi("\\chi(n)\\lambda(n)")#text(" where ")#mi("\\chi(n)")#text(" is a Dirichlet character of modulus near ")#mi("h")#text(". From, say, Poly-Vinogradov (or Burgess) we then have that ")#mi("\\chi(n)\\lambda(n)")#text(" must satisfy a MR-type estimate with a near optimal error term. This isn’t too helpful in obtaining a contradiction, but it seems that this should in turn have some interesting consequences that aren’t known unconditionally (perhaps the error term is then sufficient to deduce some results about primes in short intervals)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-463039")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2015")])]

#text("Well, it is a priori conceivable that ")#mi("\\lambda(n)")#text(" could correlate with both a phase function and a Dirichlet character on short intervals (or correlate with a phase function and be orthogonal to a Dirichlet character), provided that both correlations are not extremely large. There could possibly be a “zero-one law” that lets one say that correlations are either negligible or extremely large (in the spirit of the “all or nothing dichotomy” in Section 3 of ")#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/")[#text("this previous post")]#text(") in which case this scenario could be eliminated, but it is not clear to me at present that one could do this. (On the other hand, one could imagine from some sort of large sieve inequality that after some averaging in h, the inner product with a “typical” Dirichlet character would exhibit random fluctuations.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-462946")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2015")])]

#text("In the sketch of the proof of the proposition, where the decomposition of lambda(n) is described, there is “Type I form [sum over a_d] for some coefficients alpha_d…” I think the alpha_d should be a_d.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-462979")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2015")])]

#text("I am recording an additional observation: the conjecture (4) (or (6)) seems to be a consequence not only of the Chowla conjecture, but of the ostensibly weaker Sarnak conjecture (discussed in ")#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/")[#text("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/")]#text(" ), thus raising the possibility of establishing that the Sarnak and Chowla conjectures are in fact logically equivalent (up to logarithmic averaging, at least). Sketch of proof: suppose (6) failed, then one can find a sequence ")#mi("X_k \\to \\infty")#text(" and also ")#mi("H_k \\to \\infty")#text(" with ")#mi("H_k \\leq X_k")#text(", as well as phases ")#mi("\\alpha_k(x), \\beta_k(x)")#text(" on ")#mi("[X_k,2X_k]")#text(", such that ")#mi("\\lambda(n)")#text(" (or ")#mi("\\mu(n)")#text(", if one prefers) correlates with ")#mi("e(\\alpha_k(x) n + \\beta_k(x))")#text(" on ")#mi("[x,x+H_k]")#text(" for a positive fraction of ")#mi("x \\in [X_k,2X_k]")#text(". In particular, we can partition ")#mi("[X_k,2X_k]")#text(" into intervals ")#mi("I")#text(" of length about ")#mi("H_k")#text(", and place a linear phase ")#mi("e(\\alpha_I n + \\beta_I)")#text(" on each such interval, such that ")#mi("\\mu")#text(" (say) has a large correlation with this piecewise linear phase function on ")#mi("[X_k,2X_k]")#text(".")

#text("By sparsifying in ")#mi("k")#text(", we may assume that ")#mi("H_{k+1} \\geq X_k")#text(" and ")#mi("X_{k+1} \\geq 2 X_k")#text(" for all ")#mi("k")#text(". One can now create a bounded deterministic sequence ")#mi("f(n)")#text(" by defining ")#mi("f(n) := e(\\alpha_I n + \\beta_I)")#text(" for all ")#mi("n")#text(" in one of the subintervals ")#mi("I")#text(" of ")#mi("[X_k,2X_k]")#text(" as defined above, and then repeating this function periodically with period ")#mi("X_k")#text(" to cover the region ")#mi("[2X_k,X_{k+1}]")#text(". If one does this for each ")#mi("k")#text(" and then glues together, one can check (using the local periodicity of ")#mi("f")#text(", as well as the local linear phase behaviour) that the resulting function ")#mi("f")#text(" is indeed bounded and deterministic (i.e. for any fixed ")#mi("\\varepsilon > 0")#text(", the ")#mi("\\varepsilon")#text("-entropy of length-m substrings of ")#mi("f")#text(" is ")#mi("\\exp(o(m))")#text(" as ")#mi("m \\to \\infty")#text("). [Indeed, if ")#mi("H_k \\leq m \\leq H_{k+1}")#text(", one can get an entropy bound roughly of the shape ")#mi("\\exp( O( \\frac{\\log H_k}{H_k} m ) )")#text(" because the behaviour on ")#mi("H_k")#text("-intervals has an entropy that is polynomial in ")#mi("H_k")#text(" rather than exponential.] But ")#mi("\\mu")#text(" correlates strongly with ")#mi("f")#text(" on the intervals ")#mi("[X_k,2X_k]")#text(", contradicting the Sarnak conjecture.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-463005")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2015")])]

#text("What is the precise meaning of “equivalence (up to logarithmic averaging)” of the Sarnak and Chowla conjectures ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-463031")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2015")])]

#text("The usual forms of the Sarnak and Chowla conjectures are phrased using simple averages such as ")#mi("\\frac{1}{x} \\sum_{n \\leq x} \\mu(n) f(n)")#text(" and ")#mi("\\frac{1}{x} \\sum_{n \\leq x} \\mu(n+a_1) \\dots \\mu(n+a_k)")#text(". I don’t see how to demonstrate equivalence of these conjectures (though the implication that the Chowla conjecture implies the Sarnak conjecture is known), but there appears to be a chance that the logarithmically averaged forms of these conjectures, which controls sums such as ")#mi("\\frac{1}{\\log x} \\sum_{n \\leq x} \\frac{\\mu(n) f(n)}{n}")#text(" and ")#mi("\\frac{1}{\\log x} \\sum_{n \\leq x} \\frac{\\mu(n+a_1) \\dots \\mu(n+a_k)}{n}")#text(", can be demonstrated to be logically equivalent.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39d1c4108ce22b9c1e5aa4e441b762e75a110ab954e694543236b1715a3166ec-649b9388325742e1cb9fb188d5e6129be903f08882485ff692cefee8515481b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Y. Lin")]], [#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-463037")[#strong[#text("Y. Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2015")])]

#text("Two random and possibly silly questions: a) For what multiplicative functions, do we have Vaughan’s or Heath-Brown’s identities (other than the Mobius, von Mangoldt and Liouville)? b) Will it be possible or make sense to state Sarnak’s disjointness conjecture, by replacing the Mobius with a certain class of random multiplicative functions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-463041")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2015")])]

#text("One can interpret the various combinatorial identities in terms of identities relating the Dirichlet series of the function one is analysing with Dirichlet series of “smooth” functions such as 1 and ")#mi("n \\mapsto \\log n")#text(", which have Dirichlet series of ")#mi("\\zeta(s)")#text(" and ")#mi("-\\zeta^{\\prime}(s)")#text(" respectively. So the key thing here is that the Dirichlet series of Mobius, von Mangoldt, or Liouville can be expressed in terms of zeta and its derivatives. One can of course do similar things with arithmetic functions whose Dirichlet series are tied to other standard L-functions, e.g. one can twist Mobius, Liouville, or von Mangoldt by a Dirichlet character, or by fancier characters such as those coming from automorphic forms, etc.. In those cases, though, even the “smooth” functions can be hard to sum.")

#text("I’m not sure what model of random multiplicative function you have in mind, but many such models will already almost surely obey the Chowla conjecture, and hence also the Sarnak conjecture.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-463078")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2015")])]

#text("Sorry, I’m not sure, but it may be – ")#mi("N(\\alpha ,T)\\ll T^{\\lambda (1-\\alpha )}\\log^{B}T")#text(" ")#mi("\\lambda < \\frac{1}{1-\\delta +\\epsilon}")#text(" for ")#mi("\\delta=0,525")#text(". From:")#linebreak()#text(" 1) Ingham, A. E.: On the difference between consecutive primes. Quarterly J. Math. (Oxford) 8, 255-266 (1937).")#linebreak()#text(" 2) R. C. Baker, G. Harman and J. Pintz: The difference between consecutive primes, II (2000)")#linebreak()#text(" To reduce the degree of ")#mi("\\chi ^{1/6+\\epsilon }")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-463094")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2015")])]

#text("As far as I am aware, the best value of ")#mi("\\lambda")#text(" in the zero-density estimate is still ")#mi("\\lambda = 12/5 + \\varepsilon")#text(" (corresponding to ")#mi("\\delta= 7/12")#text("), coming from the Ingham estimate, which leads to the ")#mi("1/6 \\approx 1 - \\frac{2}{\\lambda} \\approx 2\\delta - 1")#text(" exponent for primes in short intervals on average, or primes in any short interval ")#mi("[x, x+x^{7/12+\\varepsilon}]")#text(". The Baker-Harman-Pintz arguments use some delicate sieve theory and some improved zero density estimates near ")#mi("\\text{Re}(s)=1")#text(" to improve the ")#mi("7/12")#text(" to ")#mi("0.525")#text(" for the latter problem (primes in a worst-case short interval), but not the former problem (primes in a typical short interval), as they do not directly improve on the zero density estimates of Ingham in the range ")#mi("\\text{Re}(s) < 3/4")#text(", which is much more important for the typical short interval problem than it is for the worst-case short interval problem. Actually, I believe improving upon Ingham's estimates in this range is a major open problem in the field.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-463421")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2015")])]

#text("Returning to Ingham ")#mi("p_{n+1}-p_{n}=O(p_{n}^{\\theta })")#text(", ")#mi("\\zeta (\\frac{1}{2}+it)=O(t^{c})")#text(" for ")#mi("\\theta >\\frac{1+4c}{2+4c}")#text(". This does not mean that the ")#mi("\\zeta (\\frac{1}{2}+it)=O(t^{0.1})")#text(" at ")#mi("\\frac{7}{12}")#text("?")#linebreak()#text(" Last result Bourgain at ")#mi("\\approx 0.1549")#text(".")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/Prime_gap#cite_note-Ingham-10")[#text("https://en.wikipedia.org/wiki/Prime_gap#cite_note-Ingham-10")]

#text("1) Ingham, A. E. (1937). “On the difference between consecutive primes”. Quarterly Journal of Mathematics. Oxford Series 8 (1): 255–266")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-463428")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2015")])]

#text("The implication in Ingham’s paper is that an upper bound on ")#mi("\\zeta(\\frac{1}{2}+it)")#text(" implies an upper bound on ")#mi("p_{n+1}-p_n")#text(". However, the converse implication is not established in that paper.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-463860")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2015")])]

#text("In 1) we see that ")#tao-math("\\int_{0}^{T}\\left|\\zeta (1/2+it)\\sum_{m}^{M}\\frac{\\mu (m)}{m^{1/2+it}}\\right|^{2}dt\\ll T^{\\epsilon }(T+T^{1/2}M^{7/8}+M^{5/3})", block: false)#text(".This expression can take instead of ")#tao-math("max(\\left|\\zeta (1/2+iT)\\right|^2)\\int_{0}^{T}\\left|\\sum_{m}^{M}\\frac{\\mu (m)}{m^{1/2+it}}\\right|^{2}dt", block: false)#text(" in Ingham. Using the method of flat sieve Ingham received the following assessment ")#tao-math("\\int_{0}^{T}\\left|\\zeta (1+\\delta +it)\\sum_{m}^{M}\\frac{\\mu (m)}{m^{1+\\delta +it}}\\right|^{2}dt\\ll A(\\frac{T}{M}+1)^{\\delta ^{-4}}", block: false)#text(" where ")#mi("\\delta=1/log(T+M)")#text(".")#linebreak()#text(" Is it possible to get a better estimate for this expression, if you act like in 1)?")#linebreak()#text(" 1)J.-M. Deshouillers and H. Iwaniec, Power mean values of the Riemann zeta function II, Acta Arith. 48 (1984) 305-312")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-463279")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2015")])]

#text("What is the most interesting piece of work regarding the Riemann Hypothesis equivalent and the Liouville function?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-463301")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2015")])]

#text("Maybe I’m wrong again. The article number 1, you can see that Theorem 4 is improved approach to the hypothesis Lindelof. As I understand Theorem 3 (modified) is used at Huxley (2).Deshouillers and Iwaniec (3) extended ")#mi("\\frac{1}{2}")#text(" to ")#mi("\\frac{4}{7}")#text(" for ")#mi("\\zeta (s)")#text(", one can hope that this is the symmetry , to reduce the degree of ")#mi("T^{1/2}")#text(" to ")#mi("T^{1-4/7}")#text(".")#linebreak()#text(" Theorem 3: By analogy ")#mi("\\zeta (s)")#text(" for ")#mi("\\sigma =0")#linebreak()#text(" Theorem 4: By analogy ")#mi("\\zeta (s)")#text(" for ")#mi("\\sigma =1/2")

#text("1) Montgomery, H. L.: Mean and large values of Dirichlet polynomials. Inventiones math. 8, 334-345 (1969)")#linebreak()#text(" 2) Huxley, M.N.: On the Difference between Consecutive Primes (1972)")#linebreak()#text(" 3)J.-M. Deshouillers and H. Iwaniec, Kloosterman sums and Fourier coefficients of cusp forms, Invent. Math. 70 (1982), 219-288")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-464596")[#strong[#text("Blasts From the Past | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2015")]

#text("[…] to 1932. We have already covered Terry Tao’s stunning proof of his conjecture. The latest news on Tao’s blog from early this month covers attacks on related […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Concatenation theorems for anti-Gowers-uniform functions and Host-Kra characteristic factors; polynomial patterns in primes | What's new")]], [#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-467304")[#strong[#text("Concatenation theorems for anti-Gowers-uniform functions and Host-Kra characteristic factors; polynomial patterns in primes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2016")])]

#text("[…] local Gowers uniformity norms, even with the assistance of the generalised Riemann hypothesis (see this previous blog post for some further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Equivalence of the logarithmically averaged Chowla and Sarnak conjectures | What's new")]], [#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-468688")[#strong[#text("Equivalence of the logarithmically averaged Chowla and Sarnak conjectures | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2016")])]

#text("[…] uniformity norm. (In the case , , this becomes the Fourier-uniformity conjecture discussed in this previous post.) If one then applied the (now proven) inverse conjecture for the Gowers norms, this estimate is in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/#comment-642783")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2022")])]

#text("“No Formula Provided” when reading the comments on Android WordPress app. It shows yellow box with red text.")
]
