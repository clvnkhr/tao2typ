// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/
// Converted to Typst by tao2typ: "2026-10-14T16:38:09.830370+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On the universality of the incompressible Euler equation on compact manifolds", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On the universality of the incompressible Euler equation on compact manifolds")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 July 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/")[#text("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

#text("I’ve just uploaded to the arXiv my paper “")#link("http://arxiv.org/abs/1707.07807")[#text("On the universality of the incompressible Euler equation on compact manifolds")]#text("“, submitted to ")#link("https://aimsciences.org/journals/home.jsp?journalID=1")[#text("Discrete and Continuous Dynamical Systems")]#text(". This is a variant of ")#link("https://terrytao.wordpress.com/2017/07/11/on-the-universality-of-potential-well-dynamics/")[#text("my recent paper on the universality of potential well dynamics")]#text(", but instead of trying to embed dynamical systems into a potential well ")#mi("{\\partial_{tt} u = -\\nabla V(u)}")#text(", here we try to embed dynamical systems into the incompressible Euler equations ")#metadata(none) <tao-c23c23a7c71feb7e0bd8>

#tao-aligned(keep: true)[


#tao-math("\\partial_t u + \\nabla_u u  & = - \\mathrm{grad}_g p", block: true, numbering: n => [#text("(1)")])



#tao-math("\\mathrm{div}_g u  & = 0", block: true)
]

#text("on a Riemannian manifold ")#mi("{(M,g)}")#text(". (One is particularly interested in the case of flat manifolds ")#mi("{M}")#text(", particularly ")#mi("{{\\bf R}^3}")#text(" or ")#mi("{({\\bf R}/{\\bf Z})^3}")#text(", but for the main result of this paper it is essential that one is permitted to consider curved manifolds.) This system, first ")#link("http://www.ams.org/mathscinet-getitem?mr=246328")[#text("studied by Ebin and Marsden")]#text(", is the natural generalisation of the usual incompressible Euler equations to curved space; it can be viewed as the formal geodesic flow equation on the infinite-dimensional manifold of volume-preserving diffeomorphisms on ")#mi("{M}")#text(" (see ")#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/")[#text("this previous post")]#text(" for a discussion of this in the flat space case).")

#text("The Euler equations can be viewed as a nonlinear equation in which the nonlinearity is a quadratic function of the velocity field ")#mi("{u}")#text(". It is thus natural to compare the Euler equations with quadratic ODE of the form ")#metadata(none) <tao-3fce4511ae3f02dc363b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\partial_t y = B(y,y)")]]

#text("where ")#mi("{y: {\\bf R} \\rightarrow {\\bf R}^n}")#text(" is the unknown solution, and ")#mi("{B: {\\bf R}^n \\times {\\bf R}^n \\rightarrow {\\bf R}^n}")#text(" is a bilinear map, which we may assume without loss of generality to be symmetric. One can ask whether such an ODE may be linearly embedded into the Euler equations on some Riemannian manifold ")#mi("{(M,g)}")#text(", which means that there is an injective linear map ")#mi("{U: {\\bf R}^n \\rightarrow \\Gamma(TM)}")#text(" from ")#mi("{{\\bf R}^n}")#text(" to smooth vector fields on ")#mi("{M}")#text(", as well as a bilinear map ")#mi("{P: {\\bf R}^n \\times {\\bf R}^n \\rightarrow C^\\infty(M)}")#text(" to smooth scalar fields on ")#mi("{M}")#text(", such that the map ")#mi("{y \\mapsto (U(y), P(y,y))}")#text(" takes solutions to ")#link(<tao-3fce4511ae3f02dc363b>)[#text("(2)")]#text(" to solutions to ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(1)")]#text(", or equivalently that")

#tao-aligned(keep: true)[


#tao-math("U(B(y,y)) + \\nabla_{U(y)} U(y)  & = - \\mathrm{grad}_g P(y,y)", block: true)



#tao-math("\\mathrm{div}_g U(y)  & = 0", block: true)
]

#text("for all ")#mi("{y \\in {\\bf R}^n}")#text(".")

#text("For simplicity let us restrict ")#mi("{M}")#text(" to be compact. There is an obvious necessary condition for this embeddability to occur, which comes from energy conservation law for the Euler equations; unpacking everything, this implies that the bilinear form ")#mi("{B}")#text(" in ")#link(<tao-3fce4511ae3f02dc363b>)[#text("(2)")]#text(" has to obey a cancellation condition ")#metadata(none) <tao-e9058ab198f6908f7021>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\langle B(y,y), y \\rangle = 0")]]

#text("for some positive definite inner product ")#mi("{\\langle, \\rangle: {\\bf R}^n \\times {\\bf R}^n \\rightarrow {\\bf R}}")#text(" on ")#mi("{{\\bf R}^n}")#text(". The main result of the paper is the converse to this statement: if ")#mi("{B}")#text(" is a symmetric bilinear form obeying a cancellation condition ")#link(<tao-e9058ab198f6908f7021>)[#text("(3)")]#text(", then it is possible to embed the equations ")#link(<tao-3fce4511ae3f02dc363b>)[#text("(2)")]#text(" into the Euler equations ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(1)")]#text(" on some Riemannian manifold ")#mi("{(M,g)}")#text("; the catch is that this manifold will depend on the form ")#mi("{B}")#text(" and on the dimension ")#mi("{n}")#text(" (in fact in the construction I have, ")#mi("{M}")#text(" is given explicitly as ")#mi("{SO(n) \\times ({\\bf R}/{\\bf Z})^{n+1}}")#text(", with a funny metric on it that depends on ")#mi("{B}")#text(").")

#text("As a consequence, any finite dimensional portion of the usual “dyadic shell models” used as simplified toy models of the Euler equation, can actually be embedded into a genuine Euler equation, albeit on a high-dimensional and curved manifold. This includes portions of the self-similar “machine” I used ")#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/")[#text("in a previous paper")]#text(" to establish finite time blowup for an averaged version of the Navier-Stokes (or Euler) equations. Unfortunately, the result in this paper does not apply to infinite-dimensional ODE, so I cannot yet establish finite time blowup for the Euler equations on a (well-chosen) manifold. It does not seem so far beyond the realm of possibility, though, that this could be done in the relatively near future. In particular, the result here suggests that one could construct something resembling a universal Turing machine within an Euler flow on a manifold, which was one ingredient I would need to engineer such a finite time blowup.")

#text("The proof of the main theorem proceeds by an “elimination of variables” strategy that was used in ")#link("https://terrytao.wordpress.com/2017/07/11/on-the-universality-of-potential-well-dynamics/")[#text("some of")]#text(" ")#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/")[#text("my previous")]#text(" ")#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/")[#text("papers in")]#text(" this area, though in this particular case the Nash embedding theorem (or variants thereof) are not required. The first step is to lessen the dependence on the metric ")#mi("{g}")#text(" by partially reformulating the Euler equations ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(1)")]#text(" in terms of the covelocity ")#mi("{g \\cdot u}")#text(" (which is a ")#mi("{1}")#text("-form) instead of the velocity ")#mi("{u}")#text(". Using the freedom to modify the dimension of the underlying manifold ")#mi("{M}")#text(", one can also decouple the metric ")#mi("{g}")#text(" from the volume form that is used to obtain the divergence-free condition. At this point the metric can be eliminated, with a certain positive definiteness condition between the velocity and covelocity taking its place. After a substantial amount of trial and error (motivated by some “two-and-a-half-dimensional” reductions of the three-dimensional Euler equations, and also by playing around with a number of variants of the classic “separation of variables” strategy), I eventually found an ansatz for the velocity and covelocity that automatically solved most of the components of the Euler equations (as well as most of the positive definiteness requirements), as long as one could find a number of scalar fields that obeyed a certain nonlinear system of transport equations, and also obeyed a positive definiteness condition. Here I was stuck for a bit because the system I ended up with was overdetermined – more equations than unknowns. After trying a number of special cases I eventually found a solution to the transport system on the sphere, except that the scalar functions sometimes degenerated and so the positive definiteness property I wanted was only obeyed with positive semi-definiteness. I tried for some time to perturb this example into a strictly positive definite solution before eventually working out that this was not possible. Finally I had the brainwave to lift the solution from the sphere to an even more symmetric space, and this quickly led to the final solution of the problem, using the special orthogonal group rather than the sphere as the underlying domain. The solution ended up being rather simple in form, but it is still somewhat miraculous to me that it exists at all; in retrospect, given the overdetermined nature of the problem, relying on a large amount of symmetry to cut down the number of equations was basically the only hope.")

#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46e630c67c39a02b9f094a9895ab3c82f355484e3b52306cb9a48f7f252f6ead-6d9449ed00bc2d55c364b018b0e4d4115dde5501d3acd162cdf58ade7f6acc06.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabiano789")]], [#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/#comment-484249")[#strong[#text("Fabiano789")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2017")])]

#text("Congratulations on yet another step into your interesting project!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/238ee1d9da8ca3ab25eae81d3aa3599068e23fbed8a22a811722fdb0b83a4260-1a9364bf62fba8adbded36a283de2b887c05430a19bd40074afc7d7e23062258.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony")]], [#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/#comment-484251")[#strong[#text("Anthony")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2017")])]

#text("Thanks for explaining the process by which you arrived at the result.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad4c3e019150b140bc6294f3e40473e219b48a2efe695fd61fffd95ce371b23c-1911117f007cf12d1cf989d9df9995a20201c986ba4c70c42d080735f7970b92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergei Ofitserov")]], [#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/#comment-484273")[#strong[#text("Sergei Ofitserov")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2017")])]

#text("Dear Terence Tao! Your lasts post notes speak by your unusual penetration. Univesality of potential well dynamics-that book,which not yet write. Her in my head(in my thoughts). Universality of that book consists in next: 1.Continuous surgery of restoration region D. 2. Decision of problem smoothness Navier-Stokes equations. 3.Under(sub)nets turbulents lockings. 4. Loops of Feiman. That book have three partitions(sections):green,yellow,red. Red section-that forbidden zone. Independents excursions in forbidden zone no preferably and dangerous! In present(in earnest) to estimate significance of that book be able only you! I am be able begin to write that book already now,today. But no money. In modest casts imperative 2500$ in year,in limits of living wage. There is such possibility of your financing of that plan of actions or no? Thanks.Sergei.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/51e59967bac0c7254f370eb72d788066560f8f5f86d0950554f1aea48c569912-af4bc60f19eda8025b681ceb22e5a2d5cab1347a00e09aec6f31ea8a4f39891c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sadik Shahidain")]], [#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/#comment-485232")[#strong[#text("Sadik Shahidain")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2017")])]

#text("Love this")

#text("Sadik")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TheWitness")]], [#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/#comment-484321")[#strong[#text("TheWitness")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2017")])]

#text("I think it would be great if more researchers would describe the process by which they arrived at their results, and also just provide informal commentary and opinions about the results, as Tao has done here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c7cf24de845e7fba0d65307250c9fab76d195580f9169bbf98f920d5aeca7694-b86d157d8d7c5ec89a5357b3cd5c121df2ea2a4cc64a8e4b7334c031437b83aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Me")]], [#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/#comment-484331")[#strong[#text("Me")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2017")])]

#text("Dear Pr Tao")

#text("Thanks a lot for your post. My understanding of Riemanian manifold is rudimentary at best, but I do not clearly see how you could prove finite-time blow-up of the Euler with this approach.")

#text("As you mention in the paper, the solution of the ODE exists globally, and is presumably smooth. Since the embedding is linear, the image vector field is a linear combination of smooth vector fields, with time-dependent, but smooth, coefficients. So I do not see how you could get a finite-time blow up of in this linear combinations, if everything is smooth and well behaved.")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/#comment-484341")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2017")])]

#text("Yes, this result by itself will not allow one to create finite time blowup for the incompressible Euler equations. But there is hope that the construction can be modified to do so. For instance, one could imagine working on a product manifold ")#mi("M_1 \\times M_2")#text(", in which the dynamics of ")#mi("M_2")#text(" evolve according to a finite-dimensional ODE as in this paper, and hopefully behave like a universal computer, while the dynamics of ")#mi("M_1")#text(" are infinite-dimensional but driven by the ")#mi("M_2")#text(" dynamics. Then one could try to “program” the initial data in the ")#mi("M_2")#text(" direction to create finite time blowup in the ")#mi("M_1")#text(" direction. I’m not able to do this right now, but I’m looking at it; it would be a concrete realisation of my long-term hope that something similar can be done for three-dimensional Navier-Stokes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7d476857d9ea22cecf24fec34d953f4d2ce3d196b948b80e6bd3fbdd5e69720c-8fbc5ad0de5b78a56743a1ebfefe2a9b09e5e61dc67d9a87184b8b96c96f5e60.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Not Me")]], [#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/#comment-484368")[#strong[#text("Not Me")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2017")])]

#text("This motivation – apart from the universal-computer emulation – is reminiscent of the use of small gain theorems in control theory, where the goal is typically the opposite: designing small enough gains of the various sub-systems to prevent blow up in the overall feedback system.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3eea900f7db0889d1101979191e77706a6cd480a6cc40942c0cebade1d955f12-398fb1a0916c28f9e77a4cd4e9f856805d7aa76da52d6feb0beda5f7ad57e8de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of user777")]], [#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/#comment-484396")[#strong[#text("user777")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2017")])]

#text("You state ‘ Finally I had the brainwave to lift the solution from the sphere to an even more symmetric space’. What is this space explicitly and where exactly is it in the paper?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3eea900f7db0889d1101979191e77706a6cd480a6cc40942c0cebade1d955f12-398fb1a0916c28f9e77a4cd4e9f856805d7aa76da52d6feb0beda5f7ad57e8de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of user777")]], [#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/#comment-484402")[#strong[#text("user777")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2017")])]

#text("I see it in paper but do not understand it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db518652cc3070afcdabaa00554b256190b351b0c4b9c71591e17406f7c13d2c-3aeee3abec9d9c13ede67bd756ec0d9e752e956fb03715ee421141933f4762d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of itaibn")]], [#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/#comment-484566")[#strong[#text("itaibn")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2017")])]

#text("Typos:")

#text("In (4.1) ")#mi("V (y, y)")#text(" should be ")#mi("V (B (y, y))")#text(".")

#text("In Theorem 5.1 you should write ")#mi("z \\in \\mathbb{R}^r")#text(" and ")#mi("F : \\mathbb{R}^n \\times \\mathbb{R}^r \\to C^\\infty (M)")#text(" (I assume the second one is a typo since you aren’t using curried notation when applying ")#mi("F")#text(").")

#text("In the second paragraph of section 6, you write “the compact Lie group ")#mi("so (n)")#text(". I think that’s a typo since in the introduction you wrote the group as ")#mi("SO (n)")#text(".")

#text("After (6.2), “self-adjoint” should be “skew-adjoint”.")

#emph[#text("[Thanks, these will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f68fca893cb8e9439872e92b414253a8d981d13788872cec7f5245baa525ac7a-2f0d24cfdde8d31b6f27d9eab662c9a682adfcfa39fac6820520b3663ff69c14.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dpietrobon")]], [#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/#comment-484625")[#strong[#text("dpietrobon")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2017")])]

#text("Hi Terry. A few typographical notes. 1. Below eqn. (1.5) you write “the level sets of ” with an extra comma. 2. In eqn. (3.1) the RHS has P-tilde where previously it had been P’, although perhaps this is not a typo and relates to the method of projections that follows. 3. In the paragraph immediately preceding Theorem 5.1 you write “a bilinear map F: R^n x R^R …” where in Theorem 5.1 you use the notation r for your positive integer. I am unsure, but perhaps this also impacts the first sentence on page 13 where you write “n^2R equations … but only nR independent functions”.")

#emph[#text("[Thanks, these will be corrected in the next revision of the ms – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f68fca893cb8e9439872e92b414253a8d981d13788872cec7f5245baa525ac7a-2f0d24cfdde8d31b6f27d9eab662c9a682adfcfa39fac6820520b3663ff69c14.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dpietrobon")]], [#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/#comment-484636")[#strong[#text("dpietrobon")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2017")])]

#text("*Below eqn. (1.5) you write “the level sets of ")#mi("\\langle y,y, \\rangle")#text(" ” with an extra comma.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7dd7af4166a432d4ebb81b81d19157ca761c3587c642352e6c919df1b3533691-c5b3d772ccd2c76f552cb84e174c7ab8a7e3e7dffe8735b00bdbfc87609a77ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Patrick")]], [#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/#comment-484788")[#strong[#text("Patrick")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2017")])]

#text("Dear Terence,")

#text("let’s say that (hypothetically) it is possible to “program” an initial datum to produce a finite time blow-up for the incompressible Euler equations on a certain manifold endowed with a suitable metric. (In another reply you mentioned something about a product manifold M_1 x M_2 where the dynamics on the infinite dimensional manifold M_1 is driven by the finite dimensional manifold M_2, let’s say one can construct something like this.)")

#text("1. Do you think it is possible to transform this blow-up solution into a blow-up solution on a flat manifold?")#linebreak()#text(" 2. If yes, how large do you think is the step to transform this result into the flat case?")#linebreak()#text(" 3. Could it happen that this blow-up only occurs because the corresponding manifold/metric becomes very singular at the blow-up point? What I am thinking about is whether the tools of how to measure sizes on a manifold blow up or whether the solution itself blows up.")

#text("All the best!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/#comment-484803")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2017")])]

#text("My guess would be that one could not directly adapt a blowup solution on a curved manifold to a blowup solution on a flat manifold. A curved manifold blowup that concentrates at a point might be rescalable to a flat manifold blowup if the blowup rates are just right, but if that was the case then it would be easier to construct the flat manifold blowup directly. My hope though is that a construction of a curved manifold blowup may indirectly help find an analogous flat manifold blowup by developing some tools, intuition, Ansätze, etc. that could transfer over, even if the construction itself does not. In any event it provides evidence in favour of flat manifold blowup (or, at minimum, a barrier to any attempt to prove flat manifold global regularity).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c195df82f0cb86e5741ddae12bb25d1a12e132a42a4bb21e417e7439d7ff1fce-1946e8bd8c6f0c89b86430512693e15474e8d8d670f19688743473b2cef39cbf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MB")]], [#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/#comment-484943")[#strong[#text("MB")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2017")])]

#text("In Section 6, would a similar approach work for other Lie group & Lie algebra? E.g. volume preserving diffeomorphisms & divergence free tangent vector fields over M?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/#comment-485092")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2017")])]

#text("Yes, in fact Tobias Diez (private communication) has shown me some calculations to this effect, in that the Euler equations for any compact Lie group $G$ can be embedded in the Euler equations on the product of the cotangent bundle of $G$ with a circle, by modifying the construction in the paper.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Embedding the Boussinesq equations in the incompressible Euler equations on a manifold | What's new")]], [#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/#comment-489904")[#strong[#text("Embedding the Boussinesq equations in the incompressible Euler equations on a manifold | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2017")])]

#text("[…] condition to conclude that , which implies that and hence . But actually, as already observed in my previous paper, one can replace with “for free”, even if one does not have the Euclidean volume form […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/#comment-626027")[#strong[#text("To cheer you up in difficult times 23: the original hand-written slides of Terry Tao’s 2015 Einstein Lecture in Jerusalem | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2021")]

#text("[…] topic of Tao’s lecture was discussed on Terry’s blog (also here and several other posts), here on my blog, on SO, on GLL, on Quanta Magazine, and in various other places. Tao […]")
]
