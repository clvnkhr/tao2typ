// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/08/07/on-time-management/
// Converted to Typst by tao2typ: "2026-10-14T07:02:32.628001+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On time management", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On time management")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 August 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/")[#text("https://terrytao.wordpress.com/2008/08/07/on-time-management/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Prodded by several comments, I have finally decided to write up some my thoughts on time management here. I actually have been drafting something about this subject for a while, but I soon realised that my own experience with time management is still very much a work in progress (you should see my backlog of papers that need writing up) and I don’t yet have a coherent or definitive philosophy on this topic (other than my ")#link("https://terrytao.wordpress.com/advice-on-writing-papers/")[#text("advice on writing papers")]#text(", for instance my ")#link("https://terrytao.wordpress.com/advice-on-writing-papers/write-a-rapid-prototype-first/")[#text("page on rapid prototyping")]#text("). Also, I can only talk about my own personal experiences, which probably do not generalise to all personality types or work situations, though perhaps readers may wish to contribute their own thoughts, experiences, or suggestions in the comments here. [I should also add that I don’t always follow my own advice on these matters, often to my own regret.]")

#text("I can maybe make some unorganised comments, though. Firstly, I am very lucky to have some excellent collaborators who put a lot of effort into our joint papers; many of the papers appearing recently on this blog, for instance, were to a large extent handled by co-authors. Generally, I find that papers written in collaboration take longer than singly-authored papers, but the net effort expended per author is significantly less (and the quality of writing higher). Also, I find that I can work on many joint papers in parallel (since the ball is often in another co-author’s court, or is pending some other development), but only on one single-authored paper at a time.")

#text("[For reasons having to do with the academic calendar, many more of these papers get finished during the summer than any other time of year, but many of these projects have actually been gestating for quite some time. (There should be a joint paper appearing shortly which we have been working on for about three or four years, for instance; and I have been thinking about the global regularity problem for wave maps problem on and off (mostly off) since about 2000.) So a paper being released every week does not actually correspond to a week being the time needed to conceive and then write up a paper; there is in fact quite a long pipeline of development which mostly happens out of public view.]")

#metadata(none) <tao-37bfff80209d8a7c02dd>

#text("Another thing is that my ability to do any serious mathematics fluctuates greatly from day to day; sometimes I can think hard on a problem for an hour, other times I feel ready to type up the full details of a sketch that I or my coauthors already wrote, and other times I only feel qualified to respond to email and do errands, or just to take a walk or even a nap. I find it very helpful to organise my time to match this fluctuation: for instance, if I have a free afternoon, and feel inspired to do so, I might close my office door, shut off the internet, and begin typing on a languishing paper; or if not, I go and work on a week’s worth of email, referee a paper, write a blog article, or whatever else seems suited to my current levels of energy and enthusiasm. It is fortunate in mathematics that a large fraction of one’s work (with the notable exception of teaching, which one then has to build one’s schedule around) can be flexibly moved from one time slot to another in this manner. [A corollary to this is that one should deal with tasks before they become so urgent that they have to be done immediately, thus disrupting one’s time flexibility.]")

#text("It helps a lot here to be able to honestly and accurately evaluate your work potential (a function of your location, your current level of motivation and energy, your upcoming duties and commitments, availability of resources, and the expected level of distraction) for a given period of time into the future (e.g. the rest of the day): being either overconfident or underconfident about what you can achieve leads to taking on either more or less than you can properly handle, both of which lead to inefficiencies (I have learned both sides of this from direct experience).")

#text("While I have a large number of things on my “to do” list, at various levels of complexity, difficulty, and length, when it comes to any task requiring dedicated thought, I try to focus on it exclusively, postponing or shutting out everything else; I find that multitasking only works for me when none of the tasks requires more than a fraction of my attention (in particular, it seems to work best when I am not inspired to do any one particular task). Quite often, these tasks take longer to complete than I have the energy, time, or patience for, in which case one has to find a natural break point (e.g. proving a key lemma in a paper that one is writing up, or writing down a full sketch of some idea that just came up in conversation or on the blackboard or scratch paper) where one can safely set the task aside and forget about it for a while, and be able to resume later without losing one’s place. The thing to avoid is to drop a task when it is only partially finished, without any good “closure”; it then either gets lost, or weighs on one’s mind and prevents one from fully thinking about something else, or has to be redone from an earlier point when one picks it up again. But one doesn’t have to finish each task off completely as it comes, as long as it can be picked up later. A mundane example: when I get around to writing physical letters (usually a low priority, when I don’t feel ready to do serious mathematics), I type them, print them out, seal them in an envelope, and then deposit them in my “out” tray, but I generally don’t mail them (or process any other paperwork in my out tray) until it piles up and I have nothing better to do, at which point I go out and deal with all of it at once. [I find that a particularly good time for doing this is when my computer needs to reboot or is somehow not easily usable.]")

#text("More generally, tasks that require little concentration seem to be best done in batches if possible, while tasks that require a lot of concentration seem to be best done individually, with as few distractions as one can manage.")

#text("Related to the point about “closure” is the desirability of being able to chop up an extremely long task into smaller, self-contained ones, ideally each with its own immediate “payoff”. To give one example: I doubt I would ever attempt to write (let alone finish) the equivalent of my 19 or so ")#link("https://terrytao.wordpress.com/category/teaching/285g-poincare-conjecture/")[#text("lectures on the Poincaré conjecture")]#text(" if I had decided to write one enormous article or monograph rather than 19 reasonably manageable and self-supporting shorter pieces. (It helped also to “paint myself into a corner” a little bit here by announcing the lectures in advance, and building up some momentum, to stop myself from abandoning the project half-way.)")

#text("[One very nice thing about modern text editors, including the one on this blog, is that it is very easy to save a draft at some intermediate stage and flesh it out or polish it later, which greatly assists the task of writing long papers by chopping up this task into a sequence of much smaller tasks, as discussed above. I am quite impressed by mathematicians from before the computer era who were able to meticulously write out high-quality papers and even books; even with good secretarial support, I would find this extremely difficult to do myself.]")

#text("It also makes good sense to invest a serious amount of time and effort into learning any skill that you are likely to use repeatedly in the future. A good example in mathematics is LaTeX: if you plan to write a lot of papers, it makes sense to go beyond the bare minimum of skill needed to jerry-rig whatever you need to write your paper, and go out and seriously learn how to make tables, figures, arrays, etc. Recently I’ve been playing with using prerecorded macros to type out a standard block of LaTeX code (e.g. \\begin{theorem} … \\end{theorem} \\begin{proof} … \\end{proof}) in a few keystrokes; the actual time saved per instance is probably minimal, but it presumably adds up over time, and in any event ")#emph[#text("feels")]#text(" like you’re being efficient, which is good for morale (which becomes important when writing a long paper).")

#text("There are also many situations in which it makes tactical sense to defer, delay, delegate, or procrastinate on any given task, and go work on something else instead in the meantime; not everything is equally important, and also a given task may in fact become much easier (and be completed in a much better way) if one waits for one’s own skills to get stronger, or for other events to happen that reduce the importance or need for the task in the first place. My current ")#link("http://wordpress.com/tag/project-heatwave/")[#text("papers on wave maps")]#text(", for instance, have been delayed for years, much to my own personal frustration, but in retrospect I can see that it was actually a good idea to let those papers sit for a while, as the project as I had originally conceived it was a technical nightmare, and it really was necessary to wait for the technology and understanding in the field to improve before being able to tackle it in a relatively civilised manner. [Perhaps this very article on time management is an example of this, also. There are also a number of other draft articles hidden in this blog that I felt were not quite working at the time, and are awaiting some further inspiration to complete. It seems that not every idea or topic for an article necessarily leads to a viable end product; cf. “")#link("https://terrytao.wordpress.com/career-advice/use-the-wastebasket/")[#text("use the wastebasket")]#text("“.]")

#text("My final suggestion is to pick some sort of organisational system and make a real effort to stick to it; a half-hearted system is probably worse than no system at all. [A corollary to this is not to try to make an overly ambitious system ")#emph[#text("ab nihilo")]#text(" that one is unlikely to follow faithfully; it is probably better to let such systems evolve over time.] I have my own system involving a PDA synchronised to my laptop, my email account, some in trays, out trays, and other designated spots in my office, and a “reserved” blackboard, that probably only I can understand completely, and I don’t think I can even explain it properly here, but I’m used to it now and it seems to work well enough (though I sure hope nobody ever erases that blackboard!). The choice of system though is presumably a very personal matter and I wouldn’t be able to advise on what would work best for anyone other than myself. But I do find that such systems free up a lot of memory; if I don’t have to worry about what I’m supposed to be doing at 3pm on Tuesday, or what work needs to be done on X, Y, and Z for purposes A, B, and C, I can devote more of my attention to trying to understand a mathematical argument, or proving a tricky lemma, or whatever else I need to work on. [I also find it psychologically satisfying to be able to physically cross off an item from my organisational system, which can be a useful motivation when one feels otherwise uninspired to deal with something.] On the other hand, one should not obsess ")#emph[#text("too")]#text(" much about such systems; as a rule of thumb, I would say to devote about 1-5% of your productive time to time management, and 95-99% of your productive time to actual work.")

#text("Oh, and one final disclaimer: sometimes one should abandon one’s own rules and allow for serendipity. There have been many times, for instance, when I had planned to work on something during my lunch hour (grabbing something quick to eat), when I was interrupted by a colleague or visitor to go out to eat. It has often happened that I got a lot more out of that lunch (mathematically or otherwise) than I would have back at the office, though not in the way I would have anticipated. And it was more enjoyable, too. (Similarly with skipping talks at conferences (or skipping conferences altogether) to go work on one’s own papers, etc.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (101)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0adf523c1c1f9f49ab7d87f1f09eb8f024c12902ca76416bc75b8b47d3109eb-7a397e8ca2e8ca51f720ba3adcba5ef249cb61d547d97a955f869a377799184b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ronald Hell")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-39892")[#strong[#text("Ronald Hell")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2009")])]

#text("“…my own experience with time management is still very much a work in progress…”")

#text("I think, that there are as many time management systems as people using time management, and from my own experience, I agree, it is a work in progress, getting better and more effective with time (however sometimes worse).")

#strong[#text("Using time management not too overearnest:")]#linebreak()#text(" “…[I should also add that I don’t always follow my own advice on these matters, often to my own regret.]…”")

#text("“…There are also many situations in which it makes tactical sense to defer, delay, delegate, or procrastinate on any given task, and go work on something else instead in the meantime; not everything is equally important, and also a given task may in fact become much easier (and be completed in a much better way) if one waits for one’s own skills to get stronger, or for other events to happen that reduce the importance or need for the task in the first place…”")

#text("Many of the strict rules of advanced time management systems do not fit every bodies needs, consistent use of a suitable and even simple system has a lot of positive effects.")

#text("“My final suggestion is to pick some sort of organisational system and make a real effort to stick to it; … [A corollary to this is not to try to make an overly ambitious system ab nihilo that one is unlikely to follow faithfully; it is probably better to let such systems evolve over time.]”")

#text("The Yield Hill Theory on Time Management supports this statement. There exists a point, where managing more costs more time than time gained.")

#text("“…Another thing is that my ability to do any serious mathematics fluctuates greatly from day to day; sometimes I can think hard on a problem for an hour, other times I feel ready to type up the full details of a sketch…”")

#text("Doesn’t this experience from real life show, that planning and scheduling strictly, ignores bad shape of a time management user, which never can be taken into account when making plans for a week, for example. So time management use is a highly dynamic process. Mastering this art primarily is not by following 17 rules 101 tips and 50 laws.")

#text("“The choice of system though is presumably a very personal matter … But I do find that such systems free up a lot of memory; if I don’t have to worry about what I’m supposed to be doing … I can devote more of my attention to trying to understand a mathematical argument, … or whatever else I need to work on. [I also find it psychologically satisfying to be able to physically cross off an item from my organisational system, which can be a useful motivation when one feels otherwise uninspired to deal with something.]”")

#text("Crossing off in the right manner really provides psychological advantages and allows for an ordering means, that doesn’t need to arrange pending tasks in a special manner, just write them down according to some simple guidelines and skim the do do list repeatedly.")

#strong[#text("The final wisdom")]

#text("“Oh, and one final disclaimer: sometimes one should abandon one’s own rules and allow for serendipity.”")

#text("That’s the essence – allow for freedom among all your duties. Don’t forget, that you are living.")

#text("Regards")#linebreak()#text(" Ronald")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-39942")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2009")])]

#text("Dear Terry,")

#text("In regards to converting your blog posts to LaTeX format….how do you change the ‘$latex ‘ tags into the dollar sign tags? I know Texter allows you to type in the hotstrings……but how do allow it to change the hotstrings if you copy and paste them as opposed to typing them?")

#text("Thanks")

#text("John")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c36d1f783d39cf9669029c4fd362bc99c5d090178fcc800859877c0c0a545155-f66ce8fb6a282690a560cb1a048df544a3adc677f756492154c43091d6eb99d8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-41624")[#strong[#text("Joe")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2009")])]

#text("Terence,")

#text("Nice writeup. The last note about serendipity is pretty important. Based on keeping such an organized life, I sometimes crave that aspect of life. It seems that every once in a while, I take a vacation from my planning, just to feel the randomness. I’m assuming now that like others, this is common. Maybe I should plan that in to my schedule.")

#text("Thanks,")#linebreak()#text(" Joe")#linebreak()#text(" <a href=”http://www.thetimemanagementform.com”>The Time Management Forum </a>")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-42906")[#strong[#text("25-Dec-2009 | MohanArun.com")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2009")]

#text("[…] Terry Tao on time management – Link. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f483a62efba9ce48a29f71bc2d6770fff0ae0f1ead70a748d435f3ca6eb89eb4-c3c089abcd891ca733a2f21be2d1012dca7b8b833206be7c33eaca373070e549.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-42975")[#strong[#text("Alan")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2009")])]

#text("Thank you for this information I found it most useful time managment is essential in todays hectic world")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c87e4b48fb315fb960015ff5ee60859300cb12f0ea5224a9208cbe5eb846a08d-b2d1781cf0c37a791c3f34823146d40dbd26fc0d3ab4ad1a10bb3511103d1e70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Smith of Time Management")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-45390")[#strong[#text("Jason Smith of Time Management")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2010")])]

#text("Great site!")

#text("Success comes to those people who can manage their time according to their priorities. It is due to the fact that they can finish doing important tasks at a certain period of time without rushing things and without becoming reckless.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fec100cf6397d4b1cbb398646c5f3438cd3cc5609b227b2452b0c27a67bb899a-5ebf309a9bd297a8ac3482d6fb905ac87cac01eec3a79eb76c574f741e97c5b5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 2Time: Time Management 2.0")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-46187")[#strong[#text("2Time: Time Management 2.0")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2010")])]

#text("What strikes me is that whatever time management system one develops has to be flexible enough to grow and change over time, especially with the availability of new technology such as smartphones.")

#text("Also, as time demands increase (as they have for most people with the availability of email,) it’s impossible to use the old techniques that worked when one only received 10 messages per day.")

#text("What’s needed is a flexible system that can grow — in this sense, time management is not a one time lesson, but a set of techniques that need to be evolved over time, not just to keep up but also in order to stay ahead.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-46824")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2010")])]

#text("Dear Prof. Tao,")

#text("I am a graduate student, but I am still not sure about if I should work the seven days of the week or not.")

#text("At the moment, I work around 6 hours on Sunday but I dont work on Saturdays.")#linebreak()#text(" In general, I feel that if I work on Saturdays I get mentally tired in the middle of the week.")#linebreak()#text(" I also like it because I can use saturdays to do other supporting activities such as laundry, supermarket, clean the house, ….")

#text("Do you think that it is a good strategy to take one day off every week ?")

#text("Best,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8a8ce5b0c30d26bfe5ed83708e3c9f20706f20c581e4b8f8d26aed88c8d3dc4-f58efc2eaf7b083531370ccd55792fbf63f7a56e7e7ffe9fa7cc87faae61e552.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Glenn")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-46986")[#strong[#text("Glenn")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2010")])]

#text("I disagree with the whole concept of time management – check out my blog post why")#linebreak()#text(" ")#link("http://www.beasuccessfulentrepreneur.com/successful-entrepreneurs-manage-themselves-in-time")[#text("http://www.beasuccessfulentrepreneur.com/successful-entrepreneurs-manage-themselves-in-time")]

#text("Glenn “Build A Business That Serves Your Life”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-47184")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2010")])]

#text("Dear Terry,")

#text("Do you have any thoughts if it is optimal to rest one day a week or not ?")

#text("It is hard to know when the work amount is overkilling.")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-47188")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2010")])]

#text("I’m not sure that this is really the right question to be asking; as the cliche goes, it’s not how many hours you put into your work that counts, but how much work you are getting out of each hour.")

#text("As I said in the main post, I find that I sometimes do not have the energy or motivation to do research, and so instead do errands or simply rest; I don’t designate any particular day for these purposes, but adapt my schedule according to my current and anticipated level of energy and focus. But what works for me might not necessarily be suitable for others.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/340b02c273c5b762ff2704091fce6f317819b3440b136110b95ea352717e322c-46821a9b29edbf3b5aa0be1b839f1a6b362cca6dae8eb473253ecab327ad0209.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rgrig")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-167514")[#strong[#text("rgrig")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2012")])]

#text("How do you maximize the (expected) level of energy and focus?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fee8888affee69ddeca79de73d03e1ed0525687ab5818022981e74528321f07-7693dc0db1ee9b226226ae377722305f65a4f31e17cacdd789a263a07fa637bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Umar")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-214648")[#strong[#text("Umar")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2013")])]

#text("Energy: Good food, health, exercise.")#linebreak()#text(" Focus: Less stress, anger etc. Have frequent breaks.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-47509")[#strong[#text("테렌스 타오의 시간관리 | Museum")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2010")]

#text("[…] 출처 : ")#link("http://leemky7.egloos.com/1975663")[#text("http://leemky7.egloos.com/1975663")]#text(" (원문 : ")#link(<tao-37bfff80209d8a7c02dd>)[#text("https://terrytao.wordpress.com/2008/08/07/on-time-management/#more-505")]#text(") […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-48346")[#strong[#text("테렌스 타오의 시간관리 « Cybernetics")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2010")]

#text("[…] On time management […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8bbc22f19756d4d233d777c86509e4f3a078c4b5b7135ca9befd2440ff29eab-d0f5bc0e1c3d0ed08e8866d56e45d1c45133d09afce2714c6fb634efbd89347f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Timothy")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-49189")[#strong[#text("Timothy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2010")])]

#text("Dear Terry,")

#text("Do you tend to look at time going forwards or backwards? In other words, do you look at the “time left” in doing a task to provide some psychological boost?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-49708")[#strong[#text("我如何安排时间（译自陶哲轩博客）[转载自刘小川WordPress] | 宇宙海洋™")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2011")]

#text("[…] （原文：On time management by Terry Tao） […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8aa5e22b855aa298cf5f9491b2ada9a0f22f53f22b8a4860aca64e8630d0caa2-ca2449971c7e091d386c3d447b16d71065c1f7d724b83d0a95974d12ced46898.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tessa")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-50185")[#strong[#text("Tessa")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2011")])]

#text("Yes time management is the key factor in all works. And as a project manager you must get the things done within deadline.")

#text("In order to maintain the time management in my project, I’m using the free project planning software called PlanningForce Express Planner ( ")#link("http://www.planningforce-express.com/free-planning-software.php")[#text("http://www.planningforce-express.com/free-planning-software.php")]#text(" )")

#text("It would be helpful :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f897d6e4a97cd9c5cc82dd78dd5f76ad66f5c53f9f5fdddfd892d6e0121cb821-262a26afaad0ab254898dd61bcb275646600cbaebabd165ae99e8c845e1117d8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 我如何安排时间（译自陶哲轩博客）- (转载自Liu,Xiaochuan的博客) « What's new")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-51231")[#strong[#text("我如何安排时间（译自陶哲轩博客）- (转载自Liu,Xiaochuan的博客) « What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2011")])]

#text("[…] （原文：On time management by Terry Tao）（译文原稿来自这里） […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-51329")[#strong[#text("On time management, suggestions from Terence Tao | Science Library")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2011")]

#text("[…] us see the suggestions from him on time managment, and you may also have the updates on his research and expository papers, discussion of open […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Details")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-53801")[#strong[#text("Details")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2011")])]

#text("Sometimes, some details have to be “professionally” rounded off in the paper; more and more, gaps appear…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-121697")[#strong[#text("4 ways to manage time while at IIT « mitrvani")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2012")]

#text("[…] of the best time management article for academic purposes can be found here at ")#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/")[#text("https://terrytao.wordpress.com/2008/08/07/on-time-management/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-131916")[#strong[#text("On time management (From Terry Tao’s Blog, What’s new) | shuiruge's blog 水如歌的博客")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2012")]

#text("[…] The original address: ")#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/")[#text("https://terrytao.wordpress.com/2008/08/07/on-time-management/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dfrtx")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-133990")[#strong[#text("Dfrtx")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2012")])]

#text("Hello Terry,")#linebreak()#text(" I’m currently a young, amateur mathematician and an aspiring professional one. I’ve learned loads from this!")#linebreak()#text(" Thanks a lot for your thoughts =)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-146699")[#strong[#text("Work hard | Simple is beauty")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2012")]

#text("[…] There will of course be times when one is too frustrated, fatigued, or otherwise not motivated to work on one’s current project. This is perfectly normal, and trying to force oneself to keep at that project can become counterproductive after a while. I find that it helps to have a number of smaller projects (or perhaps some non-mathematical errands) to have at hand when I am unwilling for whatever reason to work on my major projects; conversely, if I get bored with these smaller tasks, I can often convince myself to then tackle one of my bigger ones. See also my thoughts on time management. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-201868")[#strong[#text("[Skills] Làm việc chăm chỉ – GS Terrence Tao | Nguyen Hoai Tuong")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2012")]

#text("[…] làm việc lớn hơn rồi sau đó quay lại. Có nghĩa là cần linh hoạt trong việc quản lý thời gian sao cho phù hợp với mục tiêu. Cuối cùng, cần phân biệt “làm việc chăm […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-227540")[#strong[#text("十一城elevencitys.com » 我如何安排时间（译自陶哲轩博客）")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2013")]

#text("[…] （原文：On time management by Terry Tao） […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-248940")[#strong[#text("Terry Tao: On Time Management | Fahad's Academy")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2013")]

#text("[…] TERRY TAO ON TIME MANAGEMENT […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-248948")[#strong[#text("Terry Tao: On Hard Work | Fahad's Academy")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2013")]

#text("[…] TERRY TAO ON TIME MANAGEMENT […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-260913")[#strong[#text("论缓解拖延症 » Keep Passion")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2014")]

#text("[…] 数学家Terry Tao在博客《On Time Management》中也谈到过相似的观点： […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f7f71beff61bc7eead02b505e1d0134fb4e1388340b9716a5ddf347af55b08f-6dfd4386e13392d4e17aff0d06ddb4b9f8c57e34bce340041f7138394c7f5389.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ilovesweetpiggy")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-284836")[#strong[#text("ilovesweetpiggy")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2014")])]

#text("Reblogged this on ")#link("http://ilovesweetpiggy.wordpress.com/2014/04/02/on-time-management/")[#text("ilovesweetpiggy")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90be308eed25ee97422b84bb02b87e52566d4e296322a811776b8ebbfeb5cf46-92174fba00f66eede65dbb894aba8b12eabf1776e9882fcc866f44f1799e58b2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathtuition88")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-400321")[#strong[#text("mathtuition88")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2014")])]

#text("Reblogged this on ")#link("http://mathtuition88.com/2014/07/26/on-time-management/")[#text("Singapore Maths Tuition")]#text(" and commented:")#linebreak()#text(" Terence Tao (Famous Mathematician and Field’s Medalist) on advice on time management. Suitable for students too!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-420750")[#strong[#text("Econlinks this week | My great WordPress blog")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2014")]

#text("[…] Learn how to manage your (research) time, from Terry Tao. Not only for Maths nerds! […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/977cc6ffdb40b21c5dbdd171672d0910f03023fc9ffa11d40180db2095e2baf1-8d22cc605e944e4e6b1dff7f73ff0efef8d11fd3f7b840a9458dc7cc3b5835a0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of El Tao de la productividad | Homo Minimus")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-439572")[#strong[#text("El Tao de la productividad | Homo Minimus")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2014")])]

#text("[…] On time management […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-446943")[#strong[#text("How to maximize performance in social science PhD program? | CL-UAT")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2014")]

#text("[…] Probably the single most useful skill I’ve learned is to be more aware of my current state (energy level, focus, sleepiness, hunger, emotional state) and try to choose work appropriate for (doable in) that state. For more thoughts on this idea, I recommend the advice given by Terry Tao here: ")#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/")[#text("https://terrytao.wordpress.com/2008/08/07/on-time-management/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-453032")[#strong[#text("The importance of sketching. The best way to learn is to write. | thoughtsonthecommontoad")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2015")]

#text("[…] Tao‘s utterly brilliant blog, and write this post to comment on his advice surrounding time management and the importance of writing things […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-453200")[#strong[#text("1p – On time management(2008) | Profit Goals")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2015")]

#text("[…] ")#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/")[#text("https://terrytao.wordpress.com/2008/08/07/on-time-management/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-453201")[#strong[#text("1p – On time management(2008) – Exploding Ads")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2015")]

#text("[…] ")#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/")[#text("https://terrytao.wordpress.com/2008/08/07/on-time-management/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f1d9dd027004ae214d821bbccb32000e9b18c0a5c30c54e5a7d3a6c2d9e6106-9745a791507e1f324bbfa175213861a9f31a957d5e7310e474c0352cfb5a6f1b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ressonliao")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-454264")[#strong[#text("ressonliao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2015")])]

#text("Reblogged this on ")#link("https://ressonliao.wordpress.com/2015/04/22/on-time-management/")[#text("ressonliao")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-467991")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2016")])]

#text("Emacs Org-Mode works well for time-management")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-492621")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2018")])]

#text("time management post, I discussed how technology will be my biggest distraction. I made a plan of action on how I would easily be able to manage that. I came up with a study plan, to solely focus on my assignments and any course work, it’s been easy to follow it because of my work schedule, which doesn’t change. Technology was a huge distraction in the beginning so I was forced to turn it off or keep my phone away from me. Now it’s a little easier, when my phone goes off, I don’t have that itch to reach for it. I can even have my television on low, if I do notice it’s distracting me, I’ll either change the channel to something less interesting, or turn it off.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-517005")[#strong[#text("陶哲轩的时间管理 – Shaokang's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2019")]

#text("[…] 原文请看 ")#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/")[#text("https://terrytao.wordpress.com/2008/08/07/on-time-management/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-581358")[#strong[#text("How many hours a day can you effectively study? – My WordPress")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2020")]

#text("[…] Terrence Tao, a Fields Medal winner and arguably the best mathematician currently in the world. In his article on the way he manages his time he described that sometimes he is happy if he can do just 2 hours of thinking […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-633331")[#strong[#text("Work Hard by somerandomness - HackTech.news")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2021")]

#text("[…] There will of course be times when one is too frustrated, fatigued, or otherwise not motivated to work on one’s current project. This is perfectly normal, and trying to force oneself to keep at that project can become counterproductive after a while. I find that it helps to have a number of smaller projects (or perhaps some non-mathematical errands) to have at hand when I am unwilling for whatever reason to work on my major projects; conversely, if I get bored with these smaller tasks, I can often convince myself to then tackle one of my bigger ones. See also my thoughts on time management. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-642458")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2022")])]

#text("I would also like to add a strategy which Kakutani followed and invented. He used to take multiple copies of prints of documents, where the number of copies he printed depends on the importance of the document to him. Then he used to scatter them across his office. By doing so he ensured a higher theoretical probability of finding important documents.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-642459")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2022")])]

#text("It would also be interesting to know the time management strategies used by Erdos.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-642461")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2022")])]

#text("In my opinion Paul Erdos was by far the most productive person the world has ever seen. He worked on so many problems simultaneously, and it is widely believed that Erdos could retain precise details of papers he wrote as long as say 5 years back. Of course we know his time management technique: he removed all the burdens of non-mathematical things from top of his shoulders; he had no home he did not sign up for a permanent post at any university, he just solved problems and did mathematics and I believe that this despite being one of the most valuable strategies is a really tough one to choose.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-2/#comment-685416")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2024")])]

#text("Dear Terry, regarding serendipity how would it be possible to write you a letter?")

#text("thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6f35cd52575d3b70420c2058eaed4fd261c8b1f593a75e06fbda8ed59eee972-4f3a90a0bc891b73bfcea4a2b84eab1c9d34401b21aef32cef2ab2be223b7932.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Suresh")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31893")[#strong[#text("Suresh")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2008")])]

#text("Hi Terry,")#linebreak()#text(" regarding using macros for latex: do you use AUCTeX + emacs ? it’s a standard emacs package that usually comes with latex, and merely needs to be enabled in your .emacs file to work automatically. It’s a god-send for saving typing: for example, C-c C-e will create a paired environment like a theorem or proof, and C-c C-s creates a section, and labels it, and depending on the context will instead create subsections etc etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/580ce8e13146ab722e1fab2f69d632ac0fb1be24470e69e5fd169d7b2614e7cc-7048d6debe69027cd610f3556c134fe5017df304ff3b499dc7210c4b26135d69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xocai marketer")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31900")[#strong[#text("xocai marketer")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2008")])]

#text("Hi Terry,")

#text("In Internet, Is there any useful software available for On time management?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fee8888affee69ddeca79de73d03e1ed0525687ab5818022981e74528321f07-7693dc0db1ee9b226226ae377722305f65a4f31e17cacdd789a263a07fa637bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Umar")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-214646")[#strong[#text("Umar")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2013")])]

#text("Stayfocusd, Nanny, Rescuetime. etc. just google it :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c6262112424c0265c5b7a0ca9c807c75fb92880451485851e67159a5beb93e4-528cd358603681216d9589c7c3b784fdc08c97b557ab4671353a6494cd80acb3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nikita Sidorov")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31902")[#strong[#text("Nikita Sidorov")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2008")])]

#text("Hi Terry,")

#text("Thanks for your stimulating article!")

#text("Out of curiosity – how many hours a day on average do you actually do maths? (Judging by the output – 25. ;))")

#text("Regards, Nik")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spam Filter Really Doesn't Like Anonymous Comments Anymore")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31907")[#strong[#text("Spam Filter Really Doesn't Like Anonymous Comments Anymore")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2008")])]

#text("Terry,")

#text("Much of this post seems in the spirit of “getting through your to-do list,” which, of course, is much of what most people mean when they talk about time management.")

#text("In a research environment it seems that there is another crucial aspect to time management. How do you choose which projects/ideas to pursue and invest your limited time in (that is, what gets put on the to do list)? And when to give up on one?")

#text("Also (this is more in the way of curiosity than advice) you seem to have (and maintain) a very large number of collaborators. How do these collaborations come about (in some cases there are large geographical separation)? How do you divide work? Do you have a structured collaboration/communication system? How do you manage delicate issues of credit, work outside of the collaboration, etc.")

#text("Thank You.")#linebreak()#text(" Anonymous")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6dbb388caee534c33f914b537280eb600bbe6bf21d396ce07e221e1b561073b-05efbf875afb17d0655237cf1a1b3f84cfccf6f11ed708175023bd13d505cce8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31908")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2008")])]

#text("Another happy AucTeX user here. Emacs is one of those tools that I should be learning to use more fully than I am. ")#link("http://web.psung.name/emacstips/topten.html")[#text("This")]#text(" was a particularly useful article in that direction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31909")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2008")])]

#text("Dear Professor 陶：")

#text("I learned lot from your blog, both in mathematics and in how to do mathematics. I am always surprised by the fact that you are so real in the my everyday life, as a good teacher in every way. I just want to take this oppotunity to thank you as I always wanted to. And I would translate this article into chinese and put it on may own blog.")

#text("yours,")

#text("刘")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31912")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2008")])]

#text("Dear Professor 陶：")

#text("I got another question here, which may be a little too personal. I want to know whether or not a person’s “family time” could affect his or her work and how to deal with the related problems.")

#text("yours,")

#text("刘")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fee8888affee69ddeca79de73d03e1ed0525687ab5818022981e74528321f07-7693dc0db1ee9b226226ae377722305f65a4f31e17cacdd789a263a07fa637bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Umar")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-214647")[#strong[#text("Umar")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2013")])]

#text("just deal with family time…, like you could ask your wife to help with the chores or something… It’s hard to focus on hard problems all day long so instead of just doing hard math 24 hours a day there’s a need for some breaks, though of course it would be unwise to spend too much time on breaks, you just need to find the balance. If family time is taking too much time then it’s a problem to solve, perhaps you want to hire a babysitter? I don’t know. It is very specific to you, if you feel that family time is taking too long then employ specific strategies to reduce family time in a reasonable way. But still family is important don’t neglect it :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Achille Talon")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31914")[#strong[#text("Achille Talon")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2008")])]

#text("Dear Terence,")#linebreak()#text(" words fail me to express my gratitude for the privilege of")#linebreak()#text(" witnessing some of the inner workings of your mind.")#linebreak()#text(" If I may be so bold as to ask some rather superficial personal questions:")#linebreak()#text(" Do you always work with some material support in front of you (computer, paper, blackboard,…) or do you go for walks")#linebreak()#text(" thinking of some problem?")#linebreak()#text(" Do you work in cafés , as Central Europeans (used to) do?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 我如何安排时间（译自陶哲轩博客） « Liuxiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31916")[#strong[#text("我如何安排时间（译自陶哲轩博客） « Liuxiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2008")])]

#text("[…] August 8, 2008 — liuxiaochuan （原文：On time management by Terry […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leon")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31919")[#strong[#text("Leon")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2008")])]

#text("There is some unnecessary irony in the comments by ‘Achille Talon’ (a comic character known for his self-centeredness).")

#text("I think Terry was simply answering some questions from a reader, and what he wrote could be especially useful for students to become efficient. This blog is read by all kinds of people after all, including beginners.")

#text("Plus I’ve just learned about AUCTeX and some Emacs tricks thanks to the comments on this post and it looks very nice indeed, thanks all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 给自己做计划吧 « Liuxiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31924")[#strong[#text("给自己做计划吧 « Liuxiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2008")])]

#text("[…] 给自己做计划吧 August 8, 2008 — liuxiaochuan 刚看到陶哲轩教授的这篇文章On time management，我就一口气翻译了下来。这篇文章写出了我的很多心里话，甚至一些我平时想过的问题，它可以说给出了解答。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31925")[#strong[#text("Jeff Barr’s Blog » Links for Friday, August 8, 2008")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2008")]

#text("[…] Terry Tao: On Time Management – “There are also many situations in which it makes tactical sense to defer, delay, delegate, or procrastinate on any given task, and go work on something else instead in the meantime; not everything is equally important, and also a given task may in fact become much easier (and be completed in a much better way) if one waits for one’s own skills to get stronger, or for other events to happen that reduce the importance or need for the task in the first place.“ […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Achille Talon")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31926")[#strong[#text("Achille Talon")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2008")])]

#text("@Leon")#linebreak()#text(" There was absolutely no irony in my comment, only curiosity about the working habits of Professor Tao, who happens to be my absolute mathematical hero.")#linebreak()#text(" Could you please mind your own business and stop trolling?")

#text("@Professor Tao")#linebreak()#text(" Dear Terence,")#linebreak()#text(" I am quite upset by Leon’s malicious and totally false remarks.")#linebreak()#text(" I hope they will not prevent you from answering my questions,")#linebreak()#text(" which are motivated by my overwhelming admiration for your work, or more accurately by the small part of which that I understand.")#linebreak()#text(" Best wishes, A.T.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe3d938f442a5a71f3c813cc4ecf1bfcfe5666ead1f5ad841df4e461310f3160-f0aa20858c55486e6c88ff70a5132d1d9e0356bc75bb89f80be8383948710e2a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tao on time management « Casting Out Nines")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31929")[#strong[#text("Tao on time management « Casting Out Nines")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2008")])]

#text("[…] 2008 · No Comments Have you ever wondered how a Fields Medalist does time management? Terry Tao is happy to oblige. It’s not your standard GTD-esque post, as Terry discusses some of the pecuilarities of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00b37b3bd2700898ae9ca434698144ea434d8c335d5829d546f90efdeb91189d-5be501c88940f0a18a0ee12bfba84980c9c600182898f2aade0bc5062d4e2ff0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bordishki")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31930")[#strong[#text("bordishki")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2008")])]

#text("Hmm…interesting SOOO bad with PDAs!!! what should I do? Am I lazy or just dumb?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b1a49c59b96f3c2948f86aa04a4802d0015fc6d9bdea53f7c1dbd76200051f76-d2fc500b58c8a3993dc1fece64a3e4936fbebc4656365659e18219338c0a58b3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hilbertthm90")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31932")[#strong[#text("hilbertthm90")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2008")])]

#text("I personally cannot work on things as my mood suits me. If I plan to work on something and start working on it, then I get in the right frame of mind and end up really enjoying it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13757d3f8706ba554d8b911868cecf6192e916dc5775c0e8bf23d81cddf960f0-7120244f5649d2af1c4bbe8b79f4ce6f24cbcb7c4f08952589e3e85cc034fe65.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rohit Vaish")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31933")[#strong[#text("Rohit Vaish")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2008")])]

#text("Dear Professor Tao,")

#text("The above account of your experiences reminds of these precious words – ” Its not the hours you put into your work that counts, but the work that you put into those hours. ”")

#text("Thank you,")

#text("Rohit")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8035795d40bc2efb5e356698c3391a8d8b85bb7c132ba3c76e924e842b2094f7-23e30f0a734e7249bc7b540f94ffcbf9f1d97d212ac30e89292b7fdd2d81f8d9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Saqib Ali")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31964")[#strong[#text("Saqib Ali")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2008")])]

#text("@Xocai")

#text("You may want to try rescuetime.com . rescuetime allows to track where you are spending most of your time when you are on a computer e.g. browsing web (including the history of the websites you visit), reading email, creating powerpoints etc. It installs a agent on your computer that keeps track of what you do. After collecting data for few weeks and charting it you can re-align your schedule if need be.")

#text("Another cool online tool is jott.com. It turns your voice into emails, text messages, reminders, lists and appointments etc. This is a just a time saver NOT a time management tool")

#text("Disclaimer: I am no way associated with any of these companies.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d53eb0e335d776b5815eb61fa01115d87e17e9b60853db3c891dc3c26b3e883-359da6cb7dab071a54ac2b5f56e3d7923e69785f7245c69a2b88ae2308fe7b05.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of masteranza")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31971")[#strong[#text("masteranza")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2008")])]

#text("Thank you for your Article!")

#text("I will remember those remarkable words: “…a half-hearted system is probably worse than no system at all.”")#linebreak()#text(" I’ve been trying to keep my vacation time organized, but I often had no enough will to follow it all the time and the results were totally invert.")

#text("What I notice in order to have an organized day is to plan your day strictly every evening for a half of hour, although you can’t forget about putting some entertainment into it or abandon your social life.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7daca428a56f9121ad56618b057c2b9c6bbc20727d7d5fead912d5316e959905-68be785d5565f3c4d7c95b6bcff9952d1c6f81c18445a91ad541fe7437970326.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of syaerah")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-413723")[#strong[#text("syaerah")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2014")])]

#text("i cant manage my time during my math exam.. when the teacher says time’s up im just at number 21 and there are 40 questions.. i need hepl asap.. because i live in malaysia and i am 12 years old.. this year i have a very important exam called upsr.. and i need help please")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31974")[#strong[#text("Cómo el genio Terence Tao puede escribir un artículo a la semana: planificando su tiempo [ENG]")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2008")]

#text("[…] Cómo el genio Terence Tao puede escribir un artículo a la semana: planificando su tiempo [ENG]terrytao.wordpress.com/2008/08/07/on-time-management/ por emulenews hace pocos segundos […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31979")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2008")])]

#text("Dear Suresh,")

#text("I use an external text replacement utility (more precisely, ")#link("http://lifehacker.com/software/texter/lifehacker-code-texter-windows-238306.php")[#text("Texter")]#text(") for my macros. I also find it useful for form letters, and I am planning to use it the next time I need to semi-automatically convert my blog posts into LaTeX format.")

#text("Dear anonymous: Regarding how I choose my projects, this is to some extent a function of what I learn from conferences, conversations with colleagues, etc., but my general philosophy on what to work on is discussed on my ")#link("https://terrytao.wordpress.com/career-advice/")[#text("career advice page")]#text(", for instance ")#link("https://terrytao.wordpress.com/career-advice/continually-aim-just-beyond-your-current-range/")[#text("here")]#text(", ")#link("https://terrytao.wordpress.com/career-advice/learn-the-power-of-other-mathematicians-tools/")[#text("here")]#text(", and ")#link("https://terrytao.wordpress.com/career-advice/dont-prematurely-obsess-on-a-single-big-problem-or-big-theory/")[#text("here")]#text(".")

#text("As for collaborations, each collaboration has proven to be uniquely different from every other, but I have never found it necessary to try to negotiate any formal rules to apportion credit etc.; we simply work jointly and publish jointly, and discuss the (rare, and usually minor) issues that crop up as they arise. (See also the ")#link("http://www.math.ufl.edu/misc/hlrules.html")[#text("Hardy-Littlewood rules of collaboration")]#text(", although only one of my co-authors actually insists on adhering strictly to these rules.)")

#text("Dear Achille Talon: I find that pacing can help me concentrate sometimes, but other times I need to be next to paper, blackboard, or computer. As for cafes, I find that I can read mathematical papers in them, or type up material that I already understand reasonably well, but in order to think on a problem that I don’t fully know how to solve, I find the ambient noise in such environments to be too distracting. But I know other mathematicians who can work creatively in these conditions, so your mileage may vary.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31981")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2008")])]

#text("I don’t go to cafes, but there is a restaurant that I’ll go to by myself that has just the right kind of warm and cozy atmosphere for contemplating math. I’ve made progress there on questions that had otherwise stymied me, while enjoying good food at the same time.")

#text("There is one potential hazard with this however. Every once in a while someone notices that you’re actually working on math. One night the couple behind me got up to leave, and when the guy walked by my table, he looked down at my papers, and declared loudly “You’re doing math in a restaurant!” Suddenly I was no longer anonymous as heads turned. Just before they went out the door, he turned and gave me a big thumbs up.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31984")[#strong[#text("Mark")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2008")])]

#text("Dear Terence,")#linebreak()#text(" many thanks for this post, it was really nice of you to write it.")#linebreak()#text(" If I may ask, on which timescales is it important for you to plan? (in my case this would be day-week-academic term, but not month, say)")#linebreak()#text(" Mark")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31987")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2008")])]

#text("Dear Terry,")

#text("Do you listen to music while doing math?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd3adb8edf4ab5b2d8e1e9f443ce53a5392a0d5d02c3d02d78929a2b066eb421-f3568eab3d9188f7134810145bf67eb44bc4833059aec829dd79d10716ddd722.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Louis")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31997")[#strong[#text("Louis")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2008")])]

#text("Just repeating a previous question, I am curious. How long do you spend working/thinking in math each week on average? Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63ae68b8c0756f87e0cccfedaeedb4f6e43896ef30dd95c2693270f9d59bea1d-134dceb6c9ce4a058a6daa35a3ea9c0f03759db9745464686fd598ba52e1768b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of prog12")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-31999")[#strong[#text("prog12")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2008")])]

#text("loooool")#linebreak()#text(" interseting. thank alot")#linebreak()#text(" and also I want say thanks to Terence Tao")

#link("http://games.dlu3at.com")[#linebreak()#text(" العاب بنات")]#text(",")#linebreak()#text(" ")#link("http://www.dlu3at.com")[#text("بنات")]#text(",")#linebreak()#text(" ")#link("http://prog12.wordpress.com/")[#text("برامج")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fec100cf6397d4b1cbb398646c5f3438cd3cc5609b227b2452b0c27a67bb899a-5ebf309a9bd297a8ac3482d6fb905ac87cac01eec3a79eb76c574f741e97c5b5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Francis Wade")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-32034")[#strong[#text("Francis Wade")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2008")])]

#text("I believe that each person must look beyond trying to adapt a system defined by others, and build their own time management system.")

#text("This might seem complex, but when the fundamentals are understood, then anyone can use the best from systems that exist in one place or another in order to modify a personalized, custom time management system.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9527221cf63bd4a5ac1f0e76087c731571e5acbde5ea461aa6d3471ce0f082bf-b9942300c0dfbea1968210e9c7f2791a4549089efbe07d6ae798d63b07ee5fc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vishal Lama")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-32046")[#strong[#text("Vishal Lama")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2008")])]

#emph[#text("“Do you listen to music while doing math?”")]

#text("I know the above question was directed toward Prof Tao, but I hope he doesn’t mind if I respond to it. I think listening to music while doing math is at best distracting and at worst counterproductive! Learning and absorbing new concepts in math require tremendous “processing” power on the part of the brain, and though listening to music may seem to soothe the “mind”, I think one only tends to get distracted by such “noise”, unless one is listening to western classical music (Chopin, Bach, Mozart and others). I certainly don’t mean that such music enhances the brain’s processing power; I only mean that the distraction is at best almost non-existent and at worst very minimal. Listening to Rap while doing math is certainly not recommended. I just think that’s a bad idea.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-32049")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2008")])]

#text("My thought about Vishal Lama’s response:")

#text("Classical music of specific kinds indeed enhances brain power, or better to say “brain arosal”, “associative patern matching” or something like that. Specially Bach’s contrapunctus, in my opinion. As well, most of this effect is very local in time.")

#text("However, listening to it during other activity is not good to both: Classical Music should be listened to with concetration, and thinking about it as “peaceful background” is a huge misunderstanding. I do not see any “bonus” which it brings to math activity while played quietly in the background.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-32055")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2008")])]

#text("Vishal, you’re showing your academic snobbery. The Western Canon? Seriously?")

#text("Everything you’ve said goes just as well for Brian Eno, or Phillip Glass, or Mike Oldfield, or Tangerine Dream, or any of the dozens of other modern electronic/ambient artists I’ll have on while I’m doing mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9527221cf63bd4a5ac1f0e76087c731571e5acbde5ea461aa6d3471ce0f082bf-b9942300c0dfbea1968210e9c7f2791a4549089efbe07d6ae798d63b07ee5fc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vishal Lama")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-32056")[#strong[#text("Vishal Lama")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2008")])]

#text("Anonymous:")

#text("I think my earlier post probably may have given a wrong impression about how I “view” western classical music. Just to be sure, I absolutely ")#emph[#text("don’t")]#text(" think it should be considered as some kind of “peaceful background” music. I was just trying to point out that if one really ")#emph[#text("had")]#text(" to listen to music while doing math, then western classical would be a “safe” choice. Let me also add that (surprisingly) listening to the psychedelic era music of Pink Floyd (vintage Syd Barrett) is also a good bet. That is, listening to those two kinds of music doesn’t distract the mind at all while doing mathematics. Those are my personal observations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9527221cf63bd4a5ac1f0e76087c731571e5acbde5ea461aa6d3471ce0f082bf-b9942300c0dfbea1968210e9c7f2791a4549089efbe07d6ae798d63b07ee5fc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vishal Lama")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-32057")[#strong[#text("Vishal Lama")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2008")])]

#text("Dr Armstrong:")

#text("I stand corrected. Indeed I should have been more careful with my earlier statements. To be honest, I haven’t really listened to any of the modern electronic/ambient artists thus far, but I will make it a point to listen to a few of them now. Anyway, thanks for that piece of info!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-32063")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2008")])]

#text("There’s some discussion on the “Does one have to be a genius to do maths?” thread about how much time it takes to reach proficiency (I say 10^4 hours) , and whether the public confuses inspiration with perspiration.")

#text("Time-management, to me (as an ex-professor and high-tech executive) is dual to collaborator-management. “Man-hours” (I don’t mean to exclude women) can be constant on a project if you either spend more solo time on it until you solve it, or if you break it into pieces distributed between co-workers, and then synthesize the solved subproblems.")

#text("Hence there is a strategic component (what’s the optimal team size?) and a tactical component (what critical path method is best for us?).")

#text("My time as software/systems engineer on Galileo to Jupiter were blighted by an adequate PhD engineer who’d been promoted to Manager (despite obvious lack of “people skills”). The Macintosh computer was new, and he fell in love with one of its Critical Path management programs. Rather than getting anything done for some months, we had daily meetings, each with a new set of time-management task-breakdown schedule printouts of his.")

#text("Then he tried to catch up on schedule by ordering me to risk the multibillion dollar spacecraft via throwing out my ground-software Euler angle solutions to the dual-spinner multigyroscope attitude control, and simply renaming the variables of the existing quaternion-based flight software (undoing the whole point of independent Validation & Verification by risking duplication of conceptual or computational errors from the flight software to the ground software needed to ensure correctness of the flight software).")

#text("So I jumped ship to being Mission Planning Engineer on the Voyager fly-by of Uranus.")

#text("But my point is: time management is more deeply about YOUR time and that of those with whom you work well. If Minsky’s “Society of Mind” theory is correct, these are really the same, when different parts of yourself collaborate. The “you” doing Math and the “you” listening to electronic/ambient music at the same time, for example.")

#text("I very much agree with Terry Tao about serendipity. So did a subset of my mentors including Richard Feynman, Herb Keller, and Herman Kahn. These were all super-productive people (also geniuses) so I listened very carefully to what they shared about time-management. Feynman’s approach has been mentioned in this blog, to always having roughly 10 problems in mind, as an ideal level of parallelism, and rubbing them all against any new theorem or method you chanced upon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-32070")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2008")])]

#text("With the approval of his family and friends, I spoke for a couple of minutes at the Athenaeum (Caltech’s faculty club) in late February 2008 (see below announcement from then) about how Herb Keller was not my #1 teacher of numerical methods (that being the late John “Jack” Todd), but was coequal with Richard Feynman in encouraging my “chutzpah.”")

#text("It doesn’t matter what your background or label or training is, he’d say, if the problem is interesting, go for it!")

#text("I could not keep up with him on a bicycle — he was a fearless international cyclist, with many accidents. When I also rode a motorcycle, he acted as if I’d betrayed the cause. When my motorcycle accident broke both my wrists he said, “I told you so! That would never have happened on a bicycle!”")

#text("My life would be mundane and boring without his guidance. His encouragement was not just a pat on the back — it was more like being")#linebreak()#text(" shot out of a cannon.")

#text("Thank you, Herb.")

#text("====================")

#text("Memorial Service for Herbert B. Keller")

#text("A memorial service for Herb Keller, Caltech professor of applied mathematics, emeritus, will be held from 11 a.m. to 2 p.m. on Sunday,")#linebreak()#text(" February 24, in the Athenaeum. Born in Paterson, New Jersey, Keller")#linebreak()#text(" earned his PhD in mathematics from New York University in 1954. After")#linebreak()#text(" working as a research scientist and associate professor at the Courant")#linebreak()#text(" Institute of Mathematical Sciences at NYU, he came to Caltech in 1965")#linebreak()#text(" as a visiting professor. He became a full professor two years later.")#linebreak()#text(" At Caltech, Keller served as an executive officer for Applied")#linebreak()#text(" Mathematics and director of the Center for Research on Parallel")#linebreak()#text(" Computation at Caltech. He retired in 2000 but remained an active")#linebreak()#text(" researcher, attending seminars, workshops, and conferences related to")#linebreak()#text(" his fields of interest. He is also credited with pioneering")#linebreak()#text(" developments in bifurcation theory. Keller’s methods are the basis for")#linebreak()#text(" computer software that is widely used to derive numerical solutions to")#linebreak()#text(" nonlinear equations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b1a49c59b96f3c2948f86aa04a4802d0015fc6d9bdea53f7c1dbd76200051f76-d2fc500b58c8a3993dc1fece64a3e4936fbebc4656365659e18219338c0a58b3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hilbertthm90")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-32125")[#strong[#text("hilbertthm90")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2008")])]

#text("When you say 10^4 hours, when do you consider this to start? Is this 10^4 hours of math total, in which probably a factor of 10 gets shaved off during grade school learning silly things like 8×9, or do you think that the time starts when you start learning more abstract things? Maybe as in after your first proof based class. Or does it not even start until very serious studying gets done at say first year of grad school?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-32129")[#strong[#text("Study Hacks » Blog Archive » How Many Hours Do You Have to Work to Feel Productive?")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2008")]

#text("[…] Medal winner and arguably the world’s most talented mathematician. Terrence recently wrote an article about his time management habits. Here’s what caught my attention: Another thing is that my ability to do any serious […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d462171b316f271710c9d465db8dcc14eaef376a3a899b0a5d83b31dd811715-4879073d7a2217c811484ecdeafc8a7fccaa7566eb6b4e162247451b1380e64b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Todd Trimble")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-32135")[#strong[#text("Todd Trimble")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2008")])]

#text("The “10000 hours” (rough number of hours it takes to achieve mastery in a nontrivial field of human endeavor) is a popular ")#link("http://tidehorizon.blogspot.com/2007/10/10000-hours-to-ding.html")[#text("meme ")]#text(" which needs to be taken with a grain of salt, but which I think has a kernel of sense to it. That’s about 3 hours a day for 10 years. I’d say that should include the “silly things” (I strongly question the “silly”) like learning the times tables: a kid going through grade school might spend half the school year (3/4 x 5/7, not including holidays) spending a max of two hours actively studying math each school day; two hours is probably generous. At that rate it would take him 30 years to become a master mathematician, so I don’t think you shave off a factor of 10 by discounting the so-called silly stuff. (Those people bent on mastery will ramp up the time spent as they get more into it; they pack in the hours much more than they did in grade school, but you should still factor in grade school.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae6d39fabf13b25c1867be55ab302ffc04c3a31c2a97e3e5ba3fc16c95d8e81f-1cc41e62aeea861d3ca6c9899a64049f8d9f2925b29f05833c6b97292aaac116.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ouboub")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-32492")[#strong[#text("ouboub")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2008")])]

#text("Hello")

#text("I would just like to make a couple of remarks concerning collaboration, which, as Terry said, can me more time consuming than single authored articles. My comments mostly boil down to a review of existing software or the lack of it. (If someone comes up with a solution I would be grateful).")

#text("First let me confirm that indeed (X)emacs+auctex+reftex+… Is (for me) the fastest tool to write latex documents, I am aware of. Sure winedit is perhaps easier to use, Lyx more intuitive, but these tools are all slower.")

#text("Second I find it strange that till now there does not exist any")#linebreak()#text(" collaborative software, which results in standard latex")#linebreak()#text(" documents. Something like mediawiki with latex import and export filter.")

#text("Since this does not exist, I am using a couple of tools, which I find")#linebreak()#text(" useful for collaboration. First a version control system which allows me to track down changes. The next thing is a utility called latexdiff,")#linebreak()#text(" which compares 2 documents word by word, and generates a latex file in which the differences are colored. This comes very close to how a human reader would mark corrections. Last but not least there are 2 tools, ediff within (X)emacs and meld a unix tool which are useful for merging 2 documents. That might happen if at least 2 authors changed a document simultaneously.")

#text("Uwe Brauer")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pieter")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-32505")[#strong[#text("Pieter")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2008")])]

#text("@oubob: There are certainly tools to collaborate on text documents. In fact, they are used all the time in open source projects. These systems are agnostic to the type of files, any plain text file (like Latex files) will do. Popular choices are subversion (svn) and CVS. There are also numerous front-ends, which allow for example for comparing revisions of a document. This might also be useful for your own projects.")

#text("There is however one downside: the learning curve to take fully advantage of such a system is quite steep. It also requires some work in setting up a server for collaboration for example.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae6d39fabf13b25c1867be55ab302ffc04c3a31c2a97e3e5ba3fc16c95d8e81f-1cc41e62aeea861d3ca6c9899a64049f8d9f2925b29f05833c6b97292aaac116.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ouboub")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-32538")[#strong[#text("ouboub")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2008")])]

#text("@Pieter,")

#text("could you please give me some links concerning front-ends??")#linebreak()#text(" I know about CVS, which I don’t think my collaborators are willing to learn and have heard about SVN.")#linebreak()#text(" What I have in mind is some LaTeX specific software which is comparable to mediawiki.")#linebreak()#text(" That is a database a webserver and an interface with an editor, also")#linebreak()#text(" one could use an external editor, as one can do with emacs for mediawiki.")#linebreak()#text(" In that case the learning curve would be")#linebreak()#text(" flat.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pieter")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-32551")[#strong[#text("Pieter")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2008")])]

#text("@oubob:")#linebreak()#text(" Toirtoise CVS (")#link("http://www.tortoisecvs.org")[#text("http://www.tortoisecvs.org")]#text(") and Tortoise SVN (")#link("http://tortoisesvn.tigris.org")[#text("http://tortoisesvn.tigris.org")]#text(") are common frontends on Windows. It makes things easier. But indeed, you’d still have to convince your collaborators to put some time into learning it, which can be hard I think.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f897d6e4a97cd9c5cc82dd78dd5f76ad66f5c53f9f5fdddfd892d6e0121cb821-262a26afaad0ab254898dd61bcb275646600cbaebabd165ae99e8c845e1117d8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On Time Management « What’s New")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-32647")[#strong[#text("On Time Management « What’s New")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2008")])]

#text("[…] 14, 2008 in Miscellaneous | Tags: Time Management | The following is the article about time management written by Terrence Tao. Very worthy of save. I usually only cite an article using a link, but this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbaced59cfb4f4ac6ad4368e474cd55c698ff55c2cb2ab402ab0ef022350aa24-40ec592f75c234b8812bd93db3b76e82171e8db081526f8306b73f77051ffe97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-32653")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2008")])]

#text("If you’d like a tool for managing your time and projects, you can use this application:")

#link("http://www.Gtdagenda.com")[#text("http://www.Gtdagenda.com")]

#text("You can use it to manage and prioritize your goals, projects and tasks, set next actions and contexts, use checklists, schedules and a calendar.")#linebreak()#text(" A mobile version and iCal are available too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbaced59cfb4f4ac6ad4368e474cd55c698ff55c2cb2ab402ab0ef022350aa24-40ec592f75c234b8812bd93db3b76e82171e8db081526f8306b73f77051ffe97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-33422")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2008")])]

#text("If you’d like a tool for managing your time and projects, you can use this application inspired by David Allen’s GTD:")

#link("http://www.Gtdagenda.com")[#text("http://www.Gtdagenda.com")]

#text("You can use it to manage and prioritize your goals, projects and tasks, set next actions and contexts, use checklists, schedules and a calendar.")#linebreak()#text(" A mobile version and iCal are available too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3933e44c246f5e25647bdcc12aa2eb33b4a542cf110a1216d6db2858b7e97ec2-42be16bce1000d4c9ae95eac52b22e77e60d92a6d2bc527b30acbec38191d787.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-33609")[#strong[#text("Paul")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2008")])]

#text("For actual time management, I find that outlook + a blackberry works the best, outlook is a single tool that can manage all of your workload in the one single place, all of your scheduling, tasks, and information in one place. When it is sync’ed with a blackberry you can have all of your information available to you when you are mobile as well, with the advantage of effective mobile email. For more on using outlook as a management tool see my blog, ")#link("mailto:paulrasmussen@blogspot.com")[#text("paulrasmussen@blogspot.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-33619")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2008")])]

#text("“… you can have all of your information available to you…”")

#text("Yeah. Right. Once I digitize the 5,000+ books in my personal library, and scan the roughly 10^6 pages of hardcopy in my 11-room house, my storage shed, my garage, my classroom, and my laboratory.")

#text("Time management is intimately bound to to how one manages the collection of personally owned texts that one references: clipboards, paper pads of handwritten notes, journals, magazines, newspaper clippings, books, monographs, file-folders of photocopies, photographs, audio cassettes, videocasettes, CD-ROMs, diskettes, DVDs, notebooks, tax records, business records, contracts, snail-mail, cancelled checks, bills, invoices, licenses, medical records, employment records, school records, and the like.")

#text("There does not yet exist a tool that handles all of this for genuinely busy professionals.")

#text("President-elect Obama may have to surrender his beloved Blackberry when he moves into the White House, to comply with security and government records laws.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-33689")[#strong[#text("Matt")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2008")])]

#text("Terry,")

#text("I guess I have a question for you or any other person willing to answer it on here. I am a young mathematics student who will be starting a PhD in mathematics mid next-year. I guess my question has to do with how much time does one need to put into mathematics to succeed in a PhD and afterwards in academia.")

#text("As somebody who is genuinely interested in mathematics finding time to ‘think’ about mathematics is not hard and a lot of my idle time is done doing it, but sitting around idly thinking about maths isn’t the whole picture. I still need to actually sit down and study and learn new maths, concentrate extremely hard on problems and things of that kind if I am to get anywhere in mathematics.")

#text("Now I know I can not work 24 hours a day. However, it doesn’t matter how much I work I always feel that I should be doing more. I am not going to ask how much time I should be working (actually sitting down and doing maths) because I understand that everybody is different. However, I am just curious how much time did you put in, actually sitting down doing mathematics, when you were working on your PhD?")

#text("Of course I would appreciate if anybody else who has successfully completed a PhD in mathematics or something related would like to answer.")

#text("Regards,")#linebreak()#text(" Matt")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-34273")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2008")])]

#text("For all of you here, I have shared my tips on time-management here:")

#link("http://gopalkrishna-mission.blogspot.com/2008/11/time-management-is-life-management.html")[#text("http://gopalkrishna-mission.blogspot.com/2008/11/time-management-is-life-management.html")]#text(" – I learnt and validated many things on time-management from Prof. Tao’s post apart from a bit from my own experience and a bit from reading other great books/articles – as usual, Prof. Tao is very down-to-earth, real and inspiring. Feel free to give your feedback for further improvement.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-37927")[#strong[#text("Academic Time Management « Academic Career Links")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2009")]

#text("[…] Time Management By Academic Career Links As usual, there is a great advice on the subject from Terence Tao. See also a paper in the Science Careers. The comments with further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2e3681e3e77891b8b4abf16fa3068f507a377af838a8c736a3e64be125d34a1-d196b713fd012a8cc05dfcea38acf574cd45557c01a3bc4bcec13f08005bcc64.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terry Tao on time management « Vesvegen")]], [#link("https://terrytao.wordpress.com/2008/08/07/on-time-management/comment-page-1/#comment-39092")[#strong[#text("Terry Tao on time management « Vesvegen")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2009")])]

#text("[…] leave a comment » Here are some quotes from Terry Tao’s notes on time management: […]")
]
