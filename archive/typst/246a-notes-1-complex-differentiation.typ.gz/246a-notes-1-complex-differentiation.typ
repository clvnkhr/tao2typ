// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/
// Converted to Typst by tao2typ: "2026-10-14T10:36:52.257847+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "246A, Notes 1: complex differentiation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("246A, Notes 1: complex differentiation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 September 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/")[#text("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Previous set of notes: ")#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/")[#text("Notes 0")]#text(". Next set of notes: ")#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/")[#text("Notes 2")]#text(".")#linebreak()#text(" At the core of almost any undergraduate real analysis course are the concepts of differentiation and integration, with these two basic operations being tied together by the ")#link("https://en.wikipedia.org/wiki/Fundamental_theorem_of_calculus")[#text("fundamental theorem of calculus")]#text(" (and its higher dimensional generalisations, such as ")#link("https://en.wikipedia.org/wiki/Stokes%27_theorem")[#text("Stokes’ theorem")]#text("). Similarly, the notion of the complex derivative and the complex line integral (that is to say, the ")#link("https://en.wikipedia.org/wiki/Methods_of_contour_integration")[#text("contour integral")]#text(") lie at the core of any introductory complex analysis course. Once again, they are tied to each other by the fundamental theorem of calculus; but in the complex case there is a further variant of the fundamental theorem, namely ")#link("https://en.wikipedia.org/wiki/Cauchy%27s_integral_theorem")[#text("Cauchy’s theorem")]#text(", which endows complex differentiable functions with many important and surprising properties that are often not shared by their real differentiable counterparts. We will give complex differentiable functions another name to emphasise this extra structure, by referring to such functions as ")#link("https://en.wikipedia.org/wiki/Holomorphic_function")[#text("holomorphic functions")]#text(". (This term is also useful to distinguish these functions from the slightly less well-behaved ")#link("https://en.wikipedia.org/wiki/Meromorphic_function")[#text("meromorphic functions")]#text(", which we will discuss in later notes.)")#linebreak()#text(" In this set of notes we will focus solely on the concept of complex differentiation, deferring the discussion of contour integration to the next set of notes. To begin with, the theory of complex differentiation will greatly resemble the theory of real differentiation; the definitions look almost identical, and well known laws of differential calculus such as the product rule, quotient rule, and chain rule carry over ")#emph[#text("verbatim")]#text(" to the complex setting, and the theory of complex power series is similarly almost identical to the theory of real power series. However, when one compares the “one-dimensional” differentiation theory of the complex numbers with the “two-dimensional” differentiation theory of two real variables, we find that the dimensional discrepancy forces complex differentiable functions to obey a real-variable constraint, namely the ")#link("https://en.wikipedia.org/wiki/Cauchy%E2%80%93Riemann_equations")[#text("Cauchy-Riemann equations")]#text(". These equations make complex differentiable functions substantially more “rigid” than their real-variable counterparts; they imply for instance that the imaginary part of a complex differentiable function is essentially determined (up to constants) by the real part, and vice versa. Furthermore, even when considered separately, the real and imaginary components of complex differentiable functions are forced to obey the strong constraint of being ")#emph[#text("harmonic")]#text(". In later notes we will see these constraints manifest themselves in integral form, particularly through Cauchy’s theorem and the closely related ")#link("https://en.wikipedia.org/wiki/Cauchy%27s_integral_formula")[#text("Cauchy integral formula")]#text(".")#linebreak()#text(" Despite all the constraints that holomorphic functions have to obey, a surprisingly large number of the functions of a complex variable that one actually encounters in applications turn out to be holomorphic. For instance, any polynomial ")#mi("{z \\mapsto P(z)}")#text(" with complex coefficients will be holomorphic, as will the complex exponential ")#mi("{z \\mapsto \\exp(z)}")#text(". From this and the laws of differential calculus one can then generate many further holomorphic functions. Also, as we will show presently, complex power series will automatically be holomorphic inside their disk of convergence. On the other hand, there are certainly basic complex functions of interest that are ")#emph[#text("not")]#text(" holomorphic, such as the complex conjugation function ")#mi("{z \\mapsto \\overline{z}}")#text(", the absolute value function ")#tao-math("{z \\mapsto \\left|z\\right|}", block: false)#text(", or the real and imaginary part functions ")#mi("{z \\mapsto \\mathrm{Re}(z), z \\mapsto \\mathrm{Im}(z)}")#text(". We will also encounter functions that are only holomorphic at some portions of the complex plane, but not on others; for instance, rational functions will be holomorphic except at those few points where the denominator vanishes, and are prime examples of the ")#emph[#text("meromorphic")]#text(" functions mentioned previously. Later on we will also consider functions such as branches of the logarithm or square root, which will be holomorphic outside of a ")#emph[#text("branch cut")]#text(" corresponding to the choice of branch. It is a basic but important skill in complex analysis to be able to quickly recognise which functions are holomorphic and which ones are not, as many of useful theorems available to the former (such as Cauchy’s theorem) break down spectacularly for the latter. Indeed, in my experience, one of the most common “rookie errors” that beginning complex analysis students make is the error of attempting to apply a theorem about holomorphic functions to a function that is not at all holomorphic. This stands in contrast to the situation in real analysis, in which one can often obtain correct conclusions by formally applying the laws of differential or integral calculus to functions that might not actually be differentiable or integrable in a classical sense. (This latter phenomenon, by the way, can be largely explained using the theory of distributions, as covered for instance in ")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("this previous post")]#text(", but this is beyond the scope of the current course.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" In this set of notes it will be convenient to impose some unnecessarily generous regularity hypotheses (e.g. continuous second differentiability) on the holomorphic functions one is studying in order to make the proofs simpler. In later notes, we will discover that these hypotheses are in fact redundant, due to the phenomenon of ")#emph[#text("elliptic regularity")]#text(" that ensures that holomorphic functions are automatically smooth.")
]

#metadata(none) <tao-1e2c114113deb2859343>

#heading(level: 1)[#strong[#text(" — 1. Complex differentiation and power series — ")]]

#text("Recall in real analysis that if ")#mi("{f: U \\rightarrow {\\bf R}}")#text(" is a function defined on some subset ")#mi("{U}")#text(" of the real line ")#mi("{{\\bf R}}")#text(", and ")#mi("{x_0}")#text(" is an interior point of ")#mi("{U}")#text(" (that is to say, ")#mi("{U}")#text(" contains an interval of the form ")#mi("{(x_0-\\varepsilon,x_0+\\varepsilon)}")#text(" for some ")#mi("{\\varepsilon>0}")#text("), then we say that ")#mi("{f}")#text(" is ")#emph[#text("differentiable")]#text(" at ")#mi("{x_0}")#text(" if the limit")

#align(center)[#tao-fit-display[#mitex("\\lim_{x \\rightarrow x_0; x \\in U \\backslash \\{x_0\\}} \\frac{f(x)-f(x_0)}{x-x_0}")]]

#text("exists (note we have to exclude ")#mi("{x_0}")#text(" from the possible values of ")#mi("{x}")#text(" to avoid division by zero. If ")#mi("{f}")#text(" is differentiable at ")#mi("{x_0}")#text(", we denote the above limit as ")#mi("{f^{\\prime}(x_0)}")#text(" or ")#mi("{\\frac{df}{dx}(x_0)}")#text(", and refer to this as the ")#emph[#text("derivative")]#text(" of ")#mi("{f}")#text(" at ")#mi("{x_0}")#text(". If ")#mi("{U}")#text(" is open (that is to say, every element of ")#mi("{U}")#text(" is an interior point), and ")#mi("{f}")#text(" is differentiable at every point of ")#mi("{U}")#text(", then we say that ")#mi("{f}")#text(" is differentiable on ")#mi("{U}")#text(", and call ")#mi("{f^{\\prime}: U \\rightarrow {\\bf R}}")#text(" the ")#emph[#text("derivative")]#text(" of ")#mi("{f}")#text(". (One can also define differentiability at non-interior points if they are not isolated, but for simplicity we will restrict attention to interior derivatives only.)")#linebreak()#text(" We can adapt this definition to the complex setting without any difficulty:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2 (Complex differentiability)")]#text(" Let ")#mi("{U}")#text(" be a subset of the complex numbers ")#mi("{{\\bf C}}")#text(", and let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be a function. If ")#mi("{z_0}")#text(" is an interior point of ")#mi("{U}")#text(" (that is to say, ")#mi("{U}")#text(" contains a disk ")#tao-math("{D(z_0,\\varepsilon) := \\{ z \\in {\\bf C}: \\left|z-z_0\\right| < \\varepsilon\\}}", block: false)#text(" for some ")#mi("{\\varepsilon>0}")#text("), we say that ")#mi("{f}")#text(" is ")#emph[#text("complex differentiable")]#text(" at ")#mi("{z_0}")#text(" if the limit")

#align(center)[#tao-fit-display[#mitex("\\lim_{z \\rightarrow z_0; z \\in U \\backslash \\{z_0\\}} \\frac{f(z)-f(z_0)}{z-z_0}")]]

#text("exists, in which case we denote this limit as ")#mi("{f^{\\prime}(z_0)}")#text(", ")#mi("{\\frac{df}{dz}(z_0)}")#text(", or ")#mi("{\\frac{d}{dz} f(z_0)}")#text(", and refer to this as the ")#emph[#text("complex derivative")]#text(" of ")#mi("{f}")#text(" at ")#mi("{z_0}")#text(". If ")#mi("{U}")#text(" is open (that is to say, every point in ")#mi("{U}")#text(" is an interior point), and ")#mi("{f}")#text(" is complex differentiable at every point at ")#mi("{U}")#text(", we say that ")#mi("{f}")#text(" is ")#emph[#text("complex differentiable")]#text(" on ")#mi("{U}")#text(", or ")#emph[#text("holomorphic")]#text(" on ")#mi("{U}")#text(".")
]

#text("In terms of epsilons and deltas: ")#mi("{f}")#text(" is complex differentiable at ")#mi("{z_0}")#text(" with derivative ")#mi("{f^{\\prime}(z_0)}")#text(" if and only if, for every ")#mi("{\\varepsilon>0}")#text(", there exists ")#mi("{\\delta>0}")#text(" such that ")#tao-math("{\\left|\\frac{f(z)-f(z_0)}{z-z_0} - f^{\\prime}(z_0)\\right| < \\varepsilon}", block: false)#text(" whenever ")#mi("{z \\in U}")#text(" is such that ")#tao-math("{0 < \\left|z-z_0\\right| < \\delta}", block: false)#text(". Another way of writing this is that we have an approximate ")#emph[#text("linearisation")]#text(" ")#metadata(none) <tao-7f2fe580edb35154041f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("f(z) = f(z_0) + f^{\\prime}(z_0) (z-z_0) + o( \\left|z-z_0\\right| )", block: true)]]

#text("as ")#mi("{z}")#text(" approaches ")#mi("{z_0}")#text(", where ")#tao-math("{o(\\left|z-z_0\\right|)}", block: false)#text(" denotes a quantity of the form ")#tao-math("{\\left|z-z_0\\right| c(z)}", block: false)#text(" for ")#mi("{z}")#text(" in a neighbourhood of ")#mi("{z_0}")#text(", where ")#mi("{c(z)}")#text(" goes to zero as ")#mi("{z}")#text(" goes to ")#mi("{z_0}")#text(". Making the change of variables ")#mi("{z = z_0 + h}")#text(", one can also write the derivative ")#mi("{f^{\\prime}(z_0)}")#text(" in the familiar form")

#align(center)[#tao-fit-display[#mitex("f^{\\prime}(z_0) = \\lim_{h \\rightarrow 0; h \\in (U - z_0) \\backslash \\{0\\}} \\frac{f(z_0+h) - f(z_0)}{h}")]]

#text("where ")#mi("{U-z_0 := \\{ z - z_0: z \\in U \\}}")#text(" is the translation of ")#mi("{U}")#text(" by ")#mi("{-z_0}")#text(".")#linebreak()#text(" If ")#mi("{f}")#text(" is differentiable at ")#mi("{z_0}")#text(", then from the limit laws we see that")

#align(center)[#tao-fit-display[#mitex("\\lim_{z \\rightarrow z_0: z \\in U \\backslash \\{z_0\\}} f(z) - f(z_0) = f^{\\prime}(z_0) \\lim_{z \\rightarrow z_0}(z-z_0) = 0")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\lim_{z \\rightarrow z_0: z \\in U} f(z) = f(z_0),")]]

#text("that is to say that ")#mi("{f}")#text(" is continuous at ")#mi("{z_0}")#text(". In particular, holomorphic functions are automatically continuous. (Later on we will see that they are in fact far more regular than this, being smooth and even analytic.)")#linebreak()#text(" It is usually quite tedious to verify complex differentiability of a function, and to compute its derivative, from first principles. We will give just one example of this:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3")]#text(" ")#metadata(none) <tao-4f240c3fce857e766bc5>#text(" Let ")#mi("{n}")#text(" be a non-negative integer. Then the function ")#mi("{z \\mapsto z^n}")#text(" is holomorphic on the entire complex plane ")#mi("{{\\bf C}}")#text(", with derivative ")#mi("{z \\mapsto n z^{n-1}}")#text(" (with the convention that ")#mi("{n z^{n-1}}")#text(" is zero when ")#mi("{n=0}")#text(").")
]

#emph[#text("Proof:")]#text(" This is clear for ")#mi("{n=0}")#text(", so suppose ")#mi("{n \\geq 1}")#text(". We need to show that for any complex number ")#mi("{z_0}")#text(", that")

#align(center)[#tao-fit-display[#mitex("\\lim_{z \\rightarrow z_0; z \\neq z_0} \\frac{z^n - z_0^n}{z - z_0} = n z_0^{n-1}.")]]

#text("But we have the geometric series identity")

#align(center)[#tao-fit-display[#mitex("\\frac{z^n - z_0^n}{z - z_0} = z^{n-1} + z^{n-2} z_0 + \\dots + z z_0^{n-2} + z_0^{n-1},")]]

#text("which is valid (in any field) whenever ")#mi("{z \\neq z_0}")#text(", as can be seen either by induction or by multiplying both sides by ")#mi("{z-z_0}")#text(" and cancelling the telescoping series on the right-hand side. The claim then follows from the usual limit laws. ")#mi("\\Box")#linebreak()#text(" Fortunately, we have the familiar laws of differential calculus, that allow us to more quickly establish the differentiability of functions if they arise as various combinations of functions that are already known to be differentiable, and to compute the derivative:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4 (Laws of differentiation)")]#text(" ")#metadata(none) <tao-8954b4ce200e1b105945>#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", let ")#mi("{z_0}")#text(" be a point in ")#mi("{U}")#text(", and let ")#mi("{f, g: U \\rightarrow {\\bf C}}")#text(" be functions that are complex differentiable at ")#mi("{z_0}")#text(".")

#list(
[#text("(i) (Linearity) Show that ")#mi("{f+g}")#text(" is complex differentiable at ")#mi("{z_0}")#text(", with derivative ")#mi("{f^{\\prime}(z_0)+g^{\\prime}(z_0)}")#text(". For any constant ")#mi("{c \\in {\\bf C}}")#text(", show that ")#mi("{cf}")#text(" is differentiable at ")#mi("{z_0}")#text(", with derivative ")#mi("{cf^{\\prime}(z_0)}")#text(".")],
[#text("(ii) (Product rule) Show that ")#mi("{fg}")#text(" is complex differentiable at ")#mi("{z_0}")#text(", with derivative ")#mi("{f^{\\prime}(z_0) g(z_0) + f(z_0) g^{\\prime}(z_0)}")#text(".")],
[#text("(iii) (Quotient rule) If ")#mi("{g(z_0)}")#text(" is non-zero, show that ")#mi("{f/g}")#text(" (which is defined in a neighbourhood of ")#mi("{z_0}")#text(", by continuity) is complex differentiable at ")#mi("{z_0}")#text(", with derivative ")#mi("{\\frac{f^{\\prime}(z_0) g(z_0) - f(z_0) g^{\\prime}(z_0)}{g(z_0)^2}}")#text(".")],
[#text("(iv) (Chain rule) If ")#mi("{V}")#text(" is a neighbourhood of ")#mi("{f(z_0)}")#text(", and ")#mi("{g: V \\rightarrow {\\bf C}}")#text(" is a function that is complex differentiable at ")#mi("{f(z_0)}")#text(", show that the composition ")#mi("{g \\circ f}")#text(" (which is defined in a neighbourhood of ")#mi("{z_0}")#text(") is complex differentiable at ")#mi("{z_0}")#text(", with derivative")

#align(center)[#tao-fit-display[#mitex("(g \\circ f)^{\\prime}(z_0) = g^{\\prime}(f(z_0)) f^{\\prime}(z_0).")]]]
)

#text("(")#emph[#text("Hint:")]#text(" take your favourite proof of the real-variable version of these facts and adapt them to the complex setting.)")
]

#text("One could also state and prove a complex-variable form of the ")#link("https://en.wikipedia.org/wiki/Inverse_function_theorem")[#text("inverse function theorem")]#text(" here, but the proof of that statement is a bit more complicated than the ones in the above exercise, so we defer it until later in the course when it becomes needed.")#linebreak()#text(" If a function ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" is holomorphic on the entire complex plane, we call it an ")#link("https://en.wikipedia.org/wiki/Entire_function")[#text("entire function")]#text("; clearly such functions remain holomorphic when restricted to any open subset ")#mi("{U}")#text(" of the complex plane. Thus for instance Proposition ")#link(<tao-4f240c3fce857e766bc5>)[#text("3")]#text(" tells us that the functions ")#mi("{z \\mapsto z^n}")#text(" are entire, and from linearity we then see that any complex polynomial")

#align(center)[#tao-fit-display[#mitex("P(z) = a_n z^n + \\dots + a_1 z + a_0")]]

#text("will be an entire function, with derivative given by the familiar formula ")#metadata(none) <tao-a4d09a83611dab0ad49d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("P^{\\prime}(z) = n a_n z^{n-1} + \\dots + a_1.")]]

#text("A function of the form ")#mi("{P(z)/Q(z)}")#text(", where ")#mi("{P,Q}")#text(" are polynomials with ")#mi("{Q}")#text(" not identically zero, is called a ")#link("https://en.wikipedia.org/wiki/Rational_function")[#text("rational function")]#text(", being to polynomials as rational numbers are to integers. Such a rational function is well defined as long as ")#mi("{Q}")#text(" is not zero. From the ")#link("https://en.wikipedia.org/wiki/Factor_theorem")[#text("factor theorem")]#text(" (which works over any field, and in particular over the complex numbers) we know that the number of zeroes of ")#mi("{Q}")#text(" is finite, being bounded by the degree of ")#mi("{Q}")#text(" (of course we will be able to say something stronger once we have the ")#link("https://en.wikipedia.org/wiki/Fundamental_theorem_of_algebra")[#text("fundamental theorem of algebra")]#text("). Because of these singularities, rational functions are rarely entire; but from the quotient rule we do at least see that ")#mi("{P(z)/Q(z)}")#text(" is complex differentiable wherever the denominator is non-zero. Such functions are prime examples of ")#link("https://en.wikipedia.org/wiki/Meromorphic_function")[#text("meromorphic functions")]#text(", which we will discuss later in the course.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5 (Gauss-Lucas theorem)")]#text(" Let ")#mi("{P(z)}")#text(" be a complex polynomial that is factored as")

#align(center)[#tao-fit-display[#mitex("P(z) = c (z-z_1) \\dots (z-z_n)")]]

#text("for some non-zero constant ")#mi("{c \\in {\\bf C}}")#text(" and roots ")#mi("{z_1,\\dots,z_n \\in {\\bf C}}")#text(" (not necessarily distinct) with ")#mi("{n \\geq 1}")#text(".")

#list(
[#text("(i) Suppose that ")#mi("{z_1,\\dots,z_n}")#text(" all lie in the upper half-plane ")#mi("{\\{ z \\in {\\bf C}: \\mathrm{Im}(z) \\geq 0 \\}}")#text(". Show that any root of the derivative ")#mi("{P^{\\prime}(z)}")#text(" also lies in the upper half-plane. (")#emph[#text("Hint:")]#text(" use the product rule to decompose the ")#emph[#text("log-derivative")]#text(" ")#mi("{\\frac{P^{\\prime}(z)}{P(z)}}")#text(" into partial fractions, and then investigate the sign of the imaginary part of this log-derivative for ")#mi("{z}")#text(" outside the upper half-plane.)")],
[#text("(ii) Show that all the roots of ")#mi("{P^{\\prime}}")#text(" lie in the ")#link("https://en.wikipedia.org/wiki/Convex_hull")[#text("convex hull")]#text(" of the set ")#mi("{z_1,\\dots,z_n}")#text(" of roots of ")#mi("{P}")#text(", that is to say the smallest convex polygon that contains ")#mi("{z_1,\\dots,z_n}")#text(".")]
)
]

#text("Now we discuss ")#link("https://en.wikipedia.org/wiki/Power_series")[#text("power series")]#text(", which are infinite degree variants of polynomials, and which turn out to inherit many of the algebraic and analytic properties of such polynomials, at least if one stays within the disk of convergence.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 6 (Power series)")]#text(" Let ")#mi("{z_0}")#text(" be a complex number. A ")#emph[#text("formal power series")]#text(" with complex coefficients around the point ")#mi("{z_0}")#text(" is a formal series of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=0}^\\infty a_n (\\mathrm{z}-z_0)^n")]]

#text("for some complex numbers ")#mi("{a_0, a_1, \\dots}")#text(", with ")#mi("{\\mathrm{z}}")#text(" an indeterminate.")
]

#text("One can attempt to evaluate a formal power series ")#mi("{\\sum_{n=0}^\\infty a_n (\\mathrm{z}-z_0)^n}")#text(" at a given complex number ")#mi("{z}")#text(" by replacing the formal indeterminate ")#mi("{\\mathrm{z}}")#text(" with the complex number ")#mi("{z}")#text(". This may or may not produce a convergent (or absolutely convergent) series, depending on where ")#mi("{z}")#text(" is; for instance, the power series ")#mi("{\\sum_{n=0}^\\infty a_n (\\mathrm{z}-z_0)^n}")#text(" is always absolutely convergent at ")#mi("{z=z_0}")#text(", but the geometric power series ")#mi("{\\sum_{n=0}^\\infty z^n}")#text(" fails to be even conditionally convergent whenever ")#tao-math("{\\left|z\\right| > 1}", block: false)#text(" (since the summands do not go to zero). As it turns out, the region of convergence is always essentially a disk, the size of which depends on how rapidly the coefficients ")#mi("{a_n}")#text(" decay (or how slowly they grow):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7 (Convergence of power series)")]#text(" Let ")#mi("{\\sum_{n=0}^\\infty a_n (\\mathrm{z}-z_0)^n}")#text(" be a formal power series, and define the ")#link("https://en.wikipedia.org/wiki/Radius_of_convergence")[#text("radius of convergence")]#text(" ")#mi("{R \\in [0,+\\infty]}")#text(" of the series to be the quantity ")#metadata(none) <tao-1465aa50582962a986d2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("R := \\liminf_{n \\rightarrow \\infty} \\left|a_n\\right|^{-1/n}", block: true)]]

#text("with the convention that ")#tao-math("{\\left|a_n\\right|^{-1/n}}", block: false)#text(" is infinite if ")#mi("{a_n=0}")#text(". (Note that ")#mi("{R}")#text(" is allowed to be zero or infinite.) Then the formal power series is absolutely convergent for any ")#mi("{z}")#text(" in the disk ")#tao-math("{D(z_0,R) := \\{ z: \\left|z-z_0\\right| < R \\}}", block: false)#text(" (known as the ")#emph[#text("disk of convergence")]#text("), and is divergent (i.e., not convergent) for any ")#mi("{z}")#text(" in the exterior region ")#tao-math("{\\{ z: \\left|z-z_0\\right| > R \\}}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" The proof is nearly identical to the analogous result for real power series. First suppose that ")#mi("{z}")#text(" is a complex number with ")#tao-math("{\\left|z-z_0\\right| > R}", block: false)#text(" (this of course implies that ")#mi("{R}")#text(" is finite). Then by ")#link(<tao-1465aa50582962a986d2>)[#text("(3)")]#text(", we have ")#tao-math("{\\left|a_n\\right|^{-1/n} < \\left|z-z_0\\right|}", block: false)#text(" for infinitely many ")#mi("{n}")#text(", which after some rearranging implies that ")#tao-math("{\\left| a_n (z-z_0)^n \\right| > 1}", block: false)#text(" for infinitely many ")#mi("{n}")#text(". In particular, the sequence ")#mi("{a_n (z-z_0)^n}")#text(" does not go to zero as ")#mi("{n \\rightarrow \\infty}")#text(", which implies that ")#mi("{\\sum_{n=0}^\\infty a_n (z-z_0)^n}")#text(" is divergent.")#linebreak()#text(" Now suppose that ")#mi("{z}")#text(" is a complex number with ")#tao-math("{\\left|z-z_0\\right| < R}", block: false)#text(" (this of course implies that ")#mi("{R}")#text(" is non-zero). Choose a real number ")#mi("{r}")#text(" with ")#tao-math("{\\left|z-z_0\\right| < r < R}", block: false)#text(", then by ")#link(<tao-1465aa50582962a986d2>)[#text("(3)")]#text(", we have ")#tao-math("{\\left|a_n\\right|^{-1/n} > r}", block: false)#text(" for all sufficiently large ")#mi("{n}")#text(", which after some rearranging implies that")

#align(center)[#tao-fit-display[#tao-math("\\left|a_n (z-z_0)^n \\right| < (\\frac{\\left|z-z_0\\right|}{r})^n", block: true)]]

#text("for all sufficiently large ")#mi("{n}")#text(". Since the geometric series ")#tao-math("{\\sum_{n=0}^\\infty (\\frac{\\left|z-z_0\\right|}{r})^n}", block: false)#text(" is absolutely convergent, this implies that ")#mi("{\\sum_{n=0}^\\infty a_n (z-z_0)^n}")#text(" is absolutely convergent also, as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" Note that this proposition does not say what happens on the boundary ")#tao-math("{\\{ z: \\left|z-z_0\\right| = R \\}}", block: false)#text(" of this disk (assuming for sake of discussion that the radius of convergence ")#mi("{R}")#text(" is finite and non-zero). The behaviour of power series on and near the boundary of the disk of convergence is in fact remarkably subtle; see for instance Example ")#link(<tao-b23bdd6952cda0417398>)[#text("11")]#text(" below.")
]

#text("The above proposition gives a “")#link("https://en.wikipedia.org/wiki/Root_test")[#text("root test")]#text("” formula for the radius of convergence. The following “")#link("https://en.wikipedia.org/wiki/Ratio_test")[#text("ratio test")]#text("” variant gives convenient lower and upper bounds for the radius of convergence which suffices in many applications:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9 (Ratio test)")]#text(" If ")#mi("{\\sum_{n=0}^\\infty a_n (\\mathrm{z}-z_0)^n}")#text(" is a formal power series with the ")#mi("{a_n}")#text(" non-zero for all sufficiently large ")#mi("{n}")#text(", show that the radius of convergence ")#mi("{R}")#text(" of the series obeys the lower bound ")#metadata(none) <tao-64f232610aa64e4f7f03>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\limsup_{n \\rightarrow \\infty} \\frac{\\left|a_n\\right|}{\\left|a_{n+1}\\right|} \\geq R \\geq \\liminf_{n \\rightarrow \\infty} \\frac{\\left|a_n\\right|}{\\left|a_{n+1}\\right|}.", block: true)]]

#text("In particular, if the limit ")#tao-math("{\\lim_{n \\rightarrow \\infty} \\frac{\\left|a_n\\right|}{\\left|a_{n+1}\\right|}}", block: false)#text(" exists, then it is equal to ")#mi("{R}")#text(". Give examples to show that strict inequality can hold in either of the bounds in ")#link(<tao-64f232610aa64e4f7f03>)[#text("(4)")]#text(". (For an extra challenge, provide an example where ")#emph[#text("both")]#text(" bounds are simultaneously strict.)")
]

#text("If a formal power series ")#mi("{\\sum_{n=0}^\\infty a_n (\\mathrm{z}-z_0)^n}")#text(" has a positive radius of convergence, then it defines a function ")#mi("{F: D(z_0,R) \\rightarrow {\\bf C}}")#text(" in the disk of convergence by setting")

#align(center)[#tao-fit-display[#mitex("F(z) := \\sum_{n=0}^\\infty a_n (z-z_0)^n.")]]

#text("We refer to such a function as a ")#emph[#text("power series")]#text(", and refer to ")#mi("{R}")#text(" as the ")#emph[#text("radius of convergence")]#text(" of that power series. (Strictly speaking, a formal power series and a power series are different concepts, but there is little actual harm in conflating them together in practice, because of the uniqueness property established in Exercise ")#link(<tao-d81b294034bae18f4659>)[#text("17")]#text(" below.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 10")]#text(" The formal power series ")#mi("{\\sum_{n=0}^\\infty n! \\mathrm{z}^n}")#text(" has a zero radius of convergence, thanks to the ratio test, and so only converges at ")#mi("{z=0}")#text(". Conversely, the exponential formal power series ")#mi("{\\sum_{n=0}^\\infty \\frac{\\mathrm{z}^n}{n!}}")#text(" has an infinite radius of convergence (thanks to the ratio test), and converges of course to ")#mi("{\\exp(z)}")#text(" when evaluated at any complex number ")#mi("{z}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 11 (Geometric series)")]#text(" ")#metadata(none) <tao-b23bdd6952cda0417398>#text(" The formal power series ")#mi("{\\sum_{n=0}^\\infty \\mathrm{z}^n}")#text(" has radius of convergence ")#mi("{1}")#text(". If ")#mi("{z}")#text(" lies in the disk of convergence ")#tao-math("{D(0,1) = \\{ z \\in {\\bf C}: \\left|z\\right| < 1 \\}}", block: false)#text(", then we have")

#tao-aligned(keep: true)[


#tao-math("z \\sum_{n=0}^\\infty z^n  & = \\sum_{n=0}^\\infty z^{n+1}", block: true)



#tao-math(" & = \\sum_{n=1}^\\infty z^n", block: true)



#tao-math(" & = \\sum_{n=0}^\\infty z^n - 1", block: true)
]

#text("and thus after some algebra we obtain the ")#link("https://en.wikipedia.org/wiki/Geometric_series")[#text("geometric series formula")]#text(" ")#metadata(none) <tao-92e4accd3d41d63fe769>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_{n=0}^\\infty z^n = \\frac{1}{1-z}")]]

#text("as long as ")#mi("{z}")#text(" is inside the disk ")#mi("{D(0,1)}")#text(". The function ")#mi("{z \\mapsto \\frac{1}{1-z}}")#text(" does not extend continuously to the boundary point ")#mi("{z=1}")#text(" of the disk, but does extend continuously (and even smoothly) to the rest of the boundary, and is in fact holomorphic on the remainder ")#mi("{{\\bf C} \\backslash \\{1\\}}")#text(" of the complex plane. However, the geometric series ")#mi("{\\sum_{n=0}^\\infty z^n}")#text(" diverges at every single point of this boundary (when ")#tao-math("{\\left|z\\right|=1}", block: false)#text(", the coefficients ")#mi("{z^n}")#text(" of the series do not converge to zero), and of course definitely diverge outside of the disk as well. Thus we see that the function that a power series converges to can extend well beyond the disk of convergence, which thus may only capture a portion of the domain of definition of that function. For instance, if one ")#emph[#text("formally")]#text(" applies ")#link(<tao-92e4accd3d41d63fe769>)[#text("(5)")]#text(" with, say, ")#mi("{z=2}")#text(", one ends up with the apparent identity")

#align(center)[#tao-fit-display[#mitex("1 + 2 + 2^2 + 2^3 + \\dots = -1.")]]

#text("This identity does not make sense if one interprets infinite series in the classical fashion, as the series ")#mi("{1 + 2 + 2^2 + \\dots}")#text(" is definitely divergent. However, by formally extending identities such as ")#link(<tao-92e4accd3d41d63fe769>)[#text("(5)")]#text(" beyond their disk of convergence, we can ")#emph[#text("generalise")]#text(" the notion of summation of infinite series to assign meaningful values to such series even if they do not converge in the classical sense. This leads to ")#link("https://en.wikipedia.org/wiki/Summation_method")[#text("generalised summation methods")]#text(" such as ")#link("https://en.wikipedia.org/wiki/Zeta_function_regularization")[#text("zeta function regularisation")]#text(", which are discussed in ")#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/")[#text("this previous blog post")]#text(". However, we will not use such generalised interpretations of summation very much in this course.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" For any complex numbers ")#mi("{a, r, z_0}")#text(", show that the formal power series ")#mi("{\\sum_{n=0}^\\infty a r^n (\\mathrm{z}-z_0)^n}")#text(" has radius of convergence ")#tao-math("{1/\\left|r\\right|}", block: false)#text(" (with the convention that this is infinite for ")#mi("{r=0}")#text("), and is equal to the function ")#mi("{z \\mapsto \\frac{a}{1 - r(z-z_0)}}")#text(" inside the disk of convergence.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" For any positive integer ")#mi("{m}")#text(", show that the formal power series")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=0}^\\infty \\binom{n+m}{m} \\mathrm{z}^n")]]

#text("has radius of convergence ")#mi("{1}")#text(", and converges to the function ")#mi("{z \\mapsto \\frac{1}{(1-z)^{m+1}}}")#text(" in the disk ")#mi("{D(0,1)}")#text(". Here of course ")#mi("{\\binom{n+m}{m} := \\frac{(n+m)!}{n! m!}}")#text(" is the usual binomial coefficient.")
]

#text("We have seen above that power series can be well behaved as one approaches the boundary of the disk of convergence, while being divergent at the boundary. However, the converse scenario, in which the power series converges at the boundary but does not behave well as one approaches the boundary, does not occur:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]

#text("(i) (")#link("https://en.wikipedia.org/wiki/Summation_by_parts")[#text("Summation by parts formula")]#text(") Let ")#mi("{a_0,a_1,a_2,\\dots,a_N}")#text(" be a finite sequence of complex numbers, and let ")#mi("{A_n := a_0 + \\dots + a_n}")#text(" be the partial sums for ")#mi("{n=0,\\dots,N}")#text(". Show that for any complex numbers ")#mi("{b_0,\\dots,b_N}")#text(", that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=0}^N a_n b_n = \\sum_{n=0}^{N-1} A_n (b_n - b_{n+1}) + b_N A_N.")]]

#text("(ii) Let ")#mi("{a_0,a_1,\\dots}")#text(" be a sequence of complex numbers such that ")#mi("{\\sum_{n=0}^\\infty a_n}")#text(" is convergent (not necessarily absolutely) to zero. Show that for any ")#mi("{0 < r < 1}")#text(", the series ")#mi("{\\sum_{n=0}^\\infty a_n r^n}")#text(" is absolutely convergent, and")

#align(center)[#tao-fit-display[#mitex("\\lim_{r \\rightarrow 1^-} \\sum_{n=0}^\\infty a_n r^n = 0.")]]

#text("(")#emph[#text("Hint:")]#text(" use summation by parts and a limiting argument to express ")#mi("{\\sum_{n=0}^\\infty a_n r^n}")#text(" in terms of the partial sums ")#mi("{A_n = a_0 + \\dots + a_n}")#text(".)")

#text("(iii) (")#link("https://en.wikipedia.org/wiki/Abel%27s_theorem")[#text("Abel’s theorem")]#text(") Let ")#mi("{F(z) = \\sum_{n=0}^\\infty a_n (z-z_0)^n}")#text(" be a power series with a finite positive radius of convergence ")#mi("{R}")#text(", and let ")#mi("{z_1 := z_0+Re^{i\\theta}}")#text(" be a point on the boundary of the disk of convergence at which the series ")#mi("{\\sum_{n=0}^\\infty a_n (z_1 - z_0)^n}")#text(" converges (not necessarily absolutely). Show that ")#mi("{\\lim_{r \\rightarrow R^-} F(z_0 + r e^{i\\theta}) = F(z_1)}")#text(". (")#emph[#text("Hint:")]#text(" use various translations and rotations to reduce to the case considered in (ii).)")
]

#text("As a general rule of thumb, as long as one is inside the disk of convergence, power series behave very similarly to polynomials. In particular, we can generalise the differentiation formula ")#link(<tao-a4d09a83611dab0ad49d>)[#text("(2)")]#text(" to such power series:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 15")]#text(" ")#metadata(none) <tao-3d6780af3250f8de07aa>#text(" Let ")#mi("{F(z) = \\sum_{n=0}^\\infty a_n (z-z_0)^n}")#text(" be a power series with a positive radius of convergence ")#mi("{R}")#text(". Then ")#mi("{F}")#text(" is holomorphic on the disk of convergence ")#mi("{D(z_0,R)}")#text(", and the derivative ")#mi("{F^{\\prime}}")#text(" is given by the power series")

#align(center)[#tao-fit-display[#mitex("F^{\\prime}(z) = \\sum_{n=1}^\\infty n a_n (z-z_0)^{n-1} = \\sum_{n=0}^\\infty (n+1) a_{n+1} (z-z_0)^n")]]

#text("that has the same radius of convergence ")#mi("{R}")#text(" as ")#mi("{F}")#text(".")
]

#emph[#text("Proof:")]#text(" From ")#link(<tao-1465aa50582962a986d2>)[#text("(3)")]#text(", the standard limit ")#mi("{\\lim_{n \\rightarrow \\infty} n^{1/n} = 1}")#text(" and the usual limit laws, it is easy to see that the power series ")#mi("{\\sum_{n=0}^\\infty (n+1) a_{n+1} (z-z_0)^n}")#text(" has the same radius of convergence ")#mi("{R}")#text(" as ")#mi("{\\sum_{n=0}^\\infty a_n (z-z_0)^n}")#text(". To show that this series is actually the derivative of ")#mi("{F}")#text(", we use first principles. If ")#mi("{z_1}")#text(" lies in the disk of convergence, we consider the Newton quotient")

#align(center)[#tao-fit-display[#mitex("\\frac{F(z)-F(z_1)}{z-z_1}")]]

#text("for ")#mi("{z \\in D(z_0,R) \\backslash \\{z_1\\}}")#text(". Expanding out the absolutely convergent series ")#mi("{F(z)}")#text(" and ")#mi("{F(z_1)}")#text(", we can write")

#align(center)[#tao-fit-display[#mitex("\\frac{F(z)-F(z_1)}{z-z_1} = \\sum_{n=0}^\\infty a_n \\frac{(z-z_0)^n - (z_1-z_0)^n}{z-z_1}.")]]

#text("The ratio ")#mi("{\\frac{z^n - z_1^n}{z-z_1}}")#text(" vanishes for ")#mi("{n=0}")#text(", and for ")#mi("{n \\geq 1}")#text(" it is equal to ")#mi("{(z-z_0)^{n-1} + (z-z_0)^{n-2} (z_1-z_0) + \\dots + (z_1-z_0)^{n-1}}")#text(" as in the proof of Proposition ")#link(<tao-4f240c3fce857e766bc5>)[#text("3")]#text(". Thus")

#tao-aligned(keep: true)[


#tao-math("\\frac{F(z)-F(z_1)}{z-z_1}  & = \\sum_{n=1}^\\infty a_n ((z-z_0)^{n-1} + (z-z_0)^{n-2} (z_1-z_0)", block: true)



#tao-math(" & + \\dots + (z_1-z_0)^{n-1}).", block: true)
]

#text("As ")#mi("{z}")#text(" approaches ")#mi("{z_1}")#text(", each summand ")#mi("{a_n ((z-z_0)^{n-1} + (z-z_0)^{n-2} (z_1-z_0) + \\dots + (z_1-z_0)^{n-1})}")#text(" converges to ")#mi("{n a_n (z_1-z_0)^{n-1}}")#text(". This ")#emph[#text("almost")]#text(" proves the desired limiting formula")

#align(center)[#tao-fit-display[#mitex("\\lim_{z \\rightarrow z_1: z \\in D(z_0,R) \\backslash \\{z_1\\}} \\frac{F(z)-F(z_1)}{z-z_1} = \\sum_{n=1}^\\infty n a_n (z_1-z_0)^{n-1},")]]

#text("but we need to justify the interchange of a sum and limit. Fortunately we have a standard tool for this, namely the ")#link("https://en.wikipedia.org/wiki/Weierstrass_M-test")[#text("Weierstrass ")#mi("{M}")#text("-test")]#text(" (which works for complex-valued functions exactly as it does for real-valued functions; one could also use the ")#link("https://en.wikipedia.org/wiki/Dominated_convergence_theorem")[#text("dominated convergence theorem")]#text(" here). It will be convenient to select two real numbers ")#mi("{r_1,r_2}")#text(" with ")#tao-math("{\\left|z_1-z_0\\right| < r_1 < r_2 < R}", block: false)#text(". Clearly, for ")#mi("{z}")#text(" close enough to ")#mi("{z_1}")#text(", we have ")#tao-math("{\\left|z-z_0\\right| < r_1}", block: false)#text(". By the triangle inequality we then have")

#align(center)[#tao-fit-display[#tao-math("\\left|a_n ((z-z_0)^{n-1} + (z-z_0)^{n-2} (z_1-z_0) + \\dots + (z_1-z_0)^{n-1})\\right| \\leq n a_n r_1^{n-1}.", block: true)]]

#text("On the other hand, from ")#link(<tao-1465aa50582962a986d2>)[#text("(3)")]#text(" we know that ")#tao-math("{\\left|a_n\\right|^{-1/n} \\geq r_2}", block: false)#text(" for sufficiently large ")#mi("{n}")#text(", hence ")#tao-math("{\\left|a_n\\right| \\leq r_2^{-n}}", block: false)#text(" for sufficiently large ")#mi("{n}")#text(". From the ratio test we know that the series ")#mi("{\\sum_{n=1}^\\infty n r_2^{-n} r_1^{n-1}}")#text(" is absolutely convergent, hence the series ")#mi("{\\sum_{n=1}^\\infty n a_n r_1^{n-1}}")#text(" is also. Thus, for ")#mi("{z}")#text(" sufficiently close to ")#mi("{z_1}")#text(", the summands ")#tao-math("{\\left|a_n ((z-z_0)^{n-1} + (z-z_0)^{n-2} (z_1-z_0) + \\dots + (z_1-z_0)^{n-1})\\right|}", block: false)#text(" are uniformly dominated by an absolutely summable sequence of numbers ")#mi("{n a_n r_1^{n-1}}")#text(". Applying the Weierstrass ")#mi("{M}")#text("-test (or dominated convergence theorem), we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Prove the above theorem directly using epsilon and delta type arguments, rather than invoking the ")#mi("{M}")#text("-test or the dominated convergence theorem.")
]

#text("We remark that the above theorem is a little easier to prove once we have the complex version of the fundamental theorem of calculus, but this will have to wait until the next set of notes, where we will also prove a remarkable converse to the above theorem, in that ")#emph[#text("any")]#text(" holomorphic function can be expanded as a power series around any point in its domain.")#linebreak()#text(" A convenient feature of power series is the ability to ")#emph[#text("equate coefficients")]#text(": if two power series around the same point ")#mi("{z_0}")#text(" agree, then their coefficients must also agree. More precisely, we have:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17 (Taylor expansion and uniqueness of power series)")]#text(" ")#metadata(none) <tao-d81b294034bae18f4659>#text(" Let ")#mi("{F(z) = \\sum_{n=0}^\\infty a_n (z-z_0)^n}")#text(" be a power series with a positive radius of convergence. Show that ")#mi("{a_n = \\frac{1}{n!} F^{(n)}(z_0)}")#text(", where ")#mi("{F^{(n)}}")#text(" denotes the ")#mi("{n^{\\mathrm{th}}}")#text(" complex derivative of ")#mi("{F}")#text(". In particular, if ")#mi("{G(z) = \\sum_{n=0}^\\infty b_n (z-z_0)^n}")#text(" is another power series around ")#mi("{z_0}")#text(" with a positive radius of convergence which agrees with ")#mi("{F}")#text(" on some neighbourhood ")#mi("{U}")#text(" of ")#mi("{z_0}")#text(" (thus, ")#mi("{F(z)=G(z)}")#text(" for all ")#mi("{z \\in U}")#text("), show that the coefficients of ")#mi("{F}")#text(" and ")#mi("{G}")#text(" are identical, that is to say that ")#mi("{a_n = b_n}")#text(" for all ")#mi("{n \\geq 0}")#text(".")
]

#text("Of course, one can no longer compare coefficients so easily if the power series are based around two different points. For instance, from Exercise ")#link(<tao-b23bdd6952cda0417398>)[#text("11")]#text(" we see that the geometric series ")#mi("{\\sum_{n=0}^\\infty z^n}")#text(" and ")#mi("{\\sum_{n=0}^\\infty \\frac{1}{2^{n-1}} (z+1)^n}")#text(" both converge to the same function ")#mi("{\\frac{1}{1-z}}")#text(" on the unit disk ")#mi("{D(0,1)}")#text(", but have differing coefficients. The precise relation between the coefficients of power series of the same function is given as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18 (Changing the origin of a power series)")]#text(" Let ")#mi("{F(z) = \\sum_{n=0}^\\infty a_n (z-z_0)^n}")#text(" be a power series with a positive radius of convergence ")#mi("{R}")#text(". Let ")#mi("{z_1}")#text(" be an element of the disk of convergence ")#mi("{D(z_0,R)}")#text(". Show that the formal power series ")#mi("{\\sum_{n=0}^\\infty b_n (z-z_1)^n}")#text(", where")

#align(center)[#tao-fit-display[#mitex("b_n := \\sum_{m=n}^\\infty \\binom{m}{n} a_m (z_1-z_0)^{m-n},")]]

#text("has radius of convergence at least ")#tao-math("{R - \\left|z_1-z_0\\right|}", block: false)#text(", and converges to ")#mi("{F(z)}")#text(" on the disk ")#tao-math("{D(z_1, R - \\left|z_1-z_0\\right|)}", block: false)#text(". Here of course ")#mi("{\\binom{m}{n} = \\frac{m!}{n!(m-n)!}}")#text(" is the usual binomial coefficient.")
]

#text("Theorem ")#link(<tao-3d6780af3250f8de07aa>)[#text("15")]#text(" gives us a rich supply of complex differentiable functions, particularly when combined with Exercise ")#link(<tao-8954b4ce200e1b105945>)[#text("4")]#text(". For instance, the complex exponential function")

#align(center)[#tao-fit-display[#mitex("e^z = \\sum_{n=0}^\\infty \\frac{z^n}{n!}")]]

#text("has an infinite radius of convergence, and so is entire, and is its own derivative:")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dz} e^z = \\sum_{n=1}^\\infty n \\frac{z^{n-1}}{n!} = \\sum_{n=0}^\\infty \\frac{z^n}{n!} = e^z.")]]

#text("This makes the complex trigonometric functions")

#align(center)[#tao-fit-display[#mitex("\\sin(z) := \\frac{e^{iz} - e^{-iz}}{2i}, \\quad \\cos(z) := \\frac{e^{iz} + e^{-iz}}{2}")]]

#text("entire as well, and from the chain rule we recover the familiar formulae")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dz} \\sin(z) = \\cos(z); \\quad \\frac{d}{dz} \\cos(z) = - \\sin(z).")]]

#text("Of course, one can combine these functions together in many ways to create countless other complex differentiable functions with explicitly computable derivatives, e.g. ")#mi("{\\sin(z^2)}")#text(" is an entire function with derivative ")#mi("{2z \\cos(z^2)}")#text(", the tangent function ")#mi("{\\tan(z) := \\sin(z) / \\cos(z)}")#text(" is holomorphic outside of the discrete set ")#mi("{\\{ (2k+1) \\pi/2: k \\in {\\bf Z}\\}}")#text(" with derivative ")#mi("{\\mathrm{sec}(z)^2 = 1/\\cos(z)^2}")#text(", and so forth.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19 (Multiplication of power series)")]#text(" Let ")#mi("{F(z) = \\sum_{n=0}^\\infty a_n(z-z_0)^n}")#text(" and ")#mi("{G(z) = \\sum_{n=0}^\\infty b_n (z-z_0)^n}")#text(" be power series that both have radius of convergence at least ")#mi("{R}")#text(". Show that on the disk ")#mi("{D(z_0,r)}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("F(z) G(z) = \\sum_{n=0}^\\infty c_n (z-z_0)^n")]]

#text("where the right-hand side is another power series of radius of convergence at least ")#mi("{R}")#text(", with coefficients ")#mi("{c_n}")#text(" given as the ")#link("https://en.wikipedia.org/wiki/Convolution")[#text("convolution")]

#align(center)[#tao-fit-display[#mitex("c_n := \\sum_{m=0}^n a_m b_{n-m}")]]

#text("of the sequences ")#mi("{a_n}")#text(" and ")#mi("{b_n}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 2. The Cauchy-Riemann equations — ")]]

#text("Thus far, the theory of complex differentiation closely resembles the analogous theory of real differentiation that one sees in an introductory real analysis class. But now we take advantage of the Argand plane representation of ")#mi("{{\\bf C}}")#text(" to view a function ")#mi("{z \\mapsto f(z)}")#text(" of one complex variable as a function ")#mi("{(x,y) \\mapsto f(x+iy)}")#text(" of two real variables. This gives rise to some further notions of differentiation. Indeed, if ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" is a function defined on an open subset of ")#mi("{{\\bf C}}")#text(", and ")#mi("{z_0 = x_0 + i y_0}")#text(" is a point in ")#mi("{U}")#text(", then in addition to the complex derivative ")#metadata(none) <tao-ac1ab4a66c7f113bb66c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("f^{\\prime}(z_0) := \\lim_{z \\rightarrow z_0: z \\in U \\backslash \\{z_0\\}} \\frac{f(z)-f(z_0)}{z-z_0}")]]

#text("already discussed, we can also define (if they exist) the ")#link("https://en.wikipedia.org/wiki/Partial_derivative")[#text("partial derivatives")]

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial f}{\\partial x}(z_0) := \\lim_{h \\rightarrow 0: h \\in {\\bf R} \\backslash \\{0\\}} \\frac{f((x_0+h) + i y_0) - f(x_0+iy_0)}{h}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial f}{\\partial y}(z_0) := \\lim_{h \\rightarrow 0: h \\in {\\bf R} \\backslash \\{0\\}} \\frac{f(x_0 + i (y_0+h)) - f(x_0+iy_0)}{h};")]]

#text("these will be complex numbers if the limits on the right-hand side exist. There is also (if it exists) the ")#link("https://en.wikipedia.org/wiki/Gradient")[#text("gradient")]#text(" (or ")#link("https://en.wikipedia.org/wiki/Fr%C3%A9chet_derivative")[#text("Fréchet derivative")]#text(") ")#mi("{Df(z_0) \\in {\\bf C}^2}")#text(", defined as the vector ")#mi("{(D_1 f(z_0), D_2 f(z_0)) \\in {\\bf C}^2}")#text(" with the property that ")#metadata(none) <tao-eeea394806ada3056899>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\lim_{(h_1,h_2) \\rightarrow 0: (h_1,h_2) \\in {\\bf R}^2 \\backslash \\{0\\}}")]]

#align(center)[#tao-fit-display[#tao-math("\\frac{\\left|f((x_0+h_1)+i(y_0+h_2)) - f(z_0) - h_1 D_1f(z_0) - h_2 D_2f(z_0)\\right|}{\\left|(h_1,h_2)\\right|} = 0", block: true)]]

#text("where ")#tao-math("{\\left|(h_1,h_2)\\right| := \\sqrt{h_1^2+h_2^2}}", block: false)#text(" is the Euclidean norm of ")#mi("{(h_1,h_2)}")#text(".")#linebreak()#text(" These notions of derivative are of course closely related to each other. If a function ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" is ")#emph[#text("Fréchet differentiable")]#text(" at ")#mi("{z_0}")#text(", in the sense that the gradient ")#mi("{Df(z_0)}")#text(" exists, then on specialising the limit in ")#link(<tao-eeea394806ada3056899>)[#text("(7)")]#text(" to vectors ")#mi("{(h_1,h_2)}")#text(" of the form ")#mi("{(h,0)}")#text(" or ")#mi("{(0,h)}")#text(" we see that")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial f}{\\partial x}(z_0) = D_1 f(z_0)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial f}{\\partial y}(z_0) = D_2 f(z_0)")]]

#text("leading to the familiar formula ")#metadata(none) <tao-32c220482c68413fbf82>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("Df(z_0) = ( \\frac{\\partial f}{\\partial x}(z_0), \\frac{\\partial f}{\\partial y}(z_0))")]]

#text("for the gradient ")#mi("{Df(z_0)}")#text(" of a function ")#mi("{f}")#text(" that is Fréchet differentiable at ")#mi("{z_0}")#text(". We caution however that it is possible for the partial derivatives ")#mi("{ \\frac{\\partial f}{\\partial x}(z_0), \\frac{\\partial f}{\\partial y}(z_0)}")#text(" of a function to exist without the function being Fréchet differentiable, in which case the formula ")#link(<tao-32c220482c68413fbf82>)[#text("(8)")]#text(" is of course not valid. (A typical example is the function ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" defined by setting ")#mi("{f(x+iy) := \\frac{xy}{x^2+y^2}}")#text(" for ")#mi("{x+iy \\neq 0}")#text(", with ")#mi("{f(0) := 0}")#text("; this function has both partial derivatives ")#mi("{\\frac{\\partial f}{\\partial x}, \\frac{\\partial f}{\\partial y}}")#text(" existing at ")#mi("{z_0=0}")#text(", but ")#mi("{f}")#text(" is not differentiable here.) On the other hand, if the partial derivatives ")#mi("{ \\frac{\\partial f}{\\partial x}(z_0), \\frac{\\partial f}{\\partial y}(z_0)}")#text(" exist everywhere on ")#mi("{U}")#text(" and are additionally known to be continuous, then the fundamental theorem of calculus gives the identity")

#tao-aligned(keep: true)[


#tao-math("f((x_0+h_1) + i(y_0+h_2))  & = f(x_0,y_0) + \\int_0^{h_1} \\frac{\\partial f}{\\partial x}(x_0+t+iy_0)\\ dt", block: true)



#tao-math(" & + \\int_0^{h_2} \\frac{\\partial f}{\\partial y}(x_0 + h_1 + i(y_0+t))\\ dt", block: true)
]

#text("for ")#mi("{x_0+iy_0 \\in U}")#text(" and ")#mi("{h_1,h_2}")#text(" sufficiently small (with the convention that ")#mi("{\\int_a^b = -\\int_b^a}")#text(" if ")#mi("{a>b}")#text("), and from this it is not difficult to see that ")#mi("{f}")#text(" is then Fréchet differentiable everywhere on ")#mi("{U}")#text(".")#linebreak()#text(" Similarly, if ")#mi("{f}")#text(" is complex differentiable at ")#mi("{z_0}")#text(", then by specialising the limit ")#link(<tao-ac1ab4a66c7f113bb66c>)[#text("(6)")]#text(" to variables ")#mi("{z}")#text(" of the form ")#mi("{z = z_0 + h}")#text(" or ")#mi("{z = z_0 + ih}")#text(" for some non-zero real ")#mi("{h}")#text(" near zero, we see that")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial f}{\\partial x}(z_0) = f^{\\prime}(z_0)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial f}{\\partial y}(z_0) = i f^{\\prime}(z_0)")]]

#text("leading in particular to the Cauchy-Riemann equations ")#metadata(none) <tao-27368d421f0ff4d182b6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\frac{\\partial f}{\\partial x}(z_0) = \\frac{1}{i} \\frac{\\partial f}{\\partial y}(z_0)")]]

#text("that must be satisfied in order for ")#mi("{f}")#text(" to be complex differentiable. More generally, from ")#link(<tao-ac1ab4a66c7f113bb66c>)[#text("(6)")]#text(" we see that if ")#mi("{f}")#text(" is complex differentiable at ")#mi("{z_0}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\lim_{h \\rightarrow 0: h \\neq 0} \\frac{\\left|f(z_0+h) - f(z_0) - f^{\\prime}(z_0) h\\right|}{\\left|h\\right|} = 0,", block: true)]]

#text("which on comparison with ")#link(<tao-eeea394806ada3056899>)[#text("(7)")]#text(" shows that ")#mi("{f}")#text(" is also Fréchet differentiable with")

#align(center)[#tao-fit-display[#mitex("Df(z_0) = (f^{\\prime}(z_0), i f^{\\prime}(z_0)).")]]

#text("Finally, if ")#mi("{f}")#text(" is Fréchet differentiable at ")#mi("{z_0}")#text(" and one has the Cauchy-Riemann equations ")#link(<tao-27368d421f0ff4d182b6>)[#text("(9)")]#text(", then from ")#link(<tao-eeea394806ada3056899>)[#text("(7)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\lim_{(h_1,h_2) \\rightarrow 0: (h_1,h_2) \\in {\\bf R}^2 \\backslash \\{0\\}}")]]

#align(center)[#tao-fit-display[#tao-math("\\frac{\\left|f((x_0+h_1)+i(y_0+h_2)) - f(x_0+iy_0) - (h_1+ih_2) \\frac{\\partial f}{\\partial x}(z_0)\\right|}{\\left|(h_1,h_2)\\right|} = 0", block: true)]]

#text("which after making the substitution ")#mi("{z := (x_0+h_1)+i(y_0+h_2)}")#text(" gives")

#align(center)[#tao-fit-display[#tao-math("\\lim_{z \\rightarrow z_0: z \\in U \\backslash \\{z_0\\}} \\frac{\\left|f(z) - f(z_0) - (z-z_0) \\frac{\\partial f}{\\partial x}(z_0)\\right|}{\\left|z-z_0\\right|} = 0", block: true)]]

#text("which on comparison with ")#link(<tao-ac1ab4a66c7f113bb66c>)[#text("(6)")]#text(" shows that ")#mi("{f}")#text(" is complex differentiable with")

#align(center)[#tao-fit-display[#mitex("f^{\\prime}(z_0) =\\frac{\\partial f}{\\partial x}(z_0).")]]

#text("We summarise the above discussion as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 20 (Differentiability and the Cauchy-Riemann equations)")]#text(" ")#metadata(none) <tao-109e3945b5072c8e7626>#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be a function, and let ")#mi("{z_0}")#text(" be an element of ")#mi("{U}")#text(".")

#list(
[#text("(i) If ")#mi("{f}")#text(" is complex differentiable at ")#mi("{z_0}")#text(", then it is also Fréchet differentiable at ")#mi("{z_0}")#text(", with")

#align(center)[#tao-fit-display[#mitex("f^{\\prime}(z_0) = \\frac{\\partial f}{\\partial x}(z_0) = \\frac{1}{i} \\frac{\\partial f}{\\partial y}(z_0).")]]

#text("In particular, the Cauchy-Riemann equations ")#link(<tao-27368d421f0ff4d182b6>)[#text("(9)")]#text(" hold at ")#mi("{z_0}")#text(".")],
[#text("(ii) Conversely, if ")#mi("{f}")#text(" is Fréchet differentiable at ")#mi("{z_0}")#text(" and obeys the Cauchy-Riemann equations at ")#mi("{z_0}")#text(", then ")#mi("{f}")#text(" is complex differentiable at ")#mi("{z_0}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 21")]#text(" From part (ii) of the above proposition we see that if ")#mi("{f}")#text(" is Fréchet differentiable on ")#mi("{U}")#text(" and obeys the Cauchy-Riemann equations on ")#mi("{U}")#text(", then it is holomorphic on ")#mi("{U}")#text(". One can ask whether the requirement of Fréchet differentiability can be weakened. It cannot be omitted entirely; one can show, for instance, that the function ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" defined by ")#mi("{f(z) := e^{-1/z^4}}")#text(" for non-zero ")#mi("{z}")#text(" and ")#mi("{f(0) := 0}")#text(" obeys the Cauchy-Riemann equations at every point ")#mi("{z_0 \\in {\\bf C}}")#text(", but is not complex differentiable (or even continuous) at the origin. But there is a somewhat difficult ")#link("https://en.wikipedia.org/wiki/Looman%E2%80%93Menchoff_theorem")[#text("theorem of Looman and Menchoff")]#text(" that asserts that if ")#mi("{f}")#text(" is continuous on ")#mi("{U}")#text(" and obeys the Cauchy-Riemann equations on ")#mi("{U}")#text(", then it is holomorphic. We will not prove or use this theorem in this course; generally in modern applications, when one wants to weaken the regularity hypotheses of a theorem involving classical differentiation, the best way to do so is to replace the notion of a classical derivative with that of a ")#link("https://en.wikipedia.org/wiki/Weak_derivative")[#text("weak derivative")]#text(", rather than insist on computing derivatives in the classical pointwise sense. See ")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("this blog post")]#text(" for more discussion.")#linebreak()#text(" Combining part (i) of the above proposition with Theorem ")#link(<tao-3d6780af3250f8de07aa>)[#text("15")]#text(", we also conclude as a corollary that any power series will be smooth inside its disk of convergence, in the sense all partial derivatives to all orders of this power series exist.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 22")]#text(" From the geometric perspective, one can interpret complex differentiability at a point ")#mi("{z_0}")#text(" as a requirement that a map ")#mi("{f}")#text(" is ")#link("https://en.wikipedia.org/wiki/Conformal_map")[#text("conformal")]#text(" and orientation-preserving at ")#mi("{z_0}")#text(", at least in the non-degenerate case when ")#mi("{f^{\\prime}(z_0)}")#text(" is non-zero. In more detail: suppose that ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" is a map that is complex differentiable at some point ")#mi("{z_0 \\in U}")#text(" with ")#mi("{f^{\\prime}(z_0) \\neq 0}")#text(". Let ")#mi("{\\gamma: (-\\varepsilon,\\varepsilon) \\rightarrow U}")#text(" be a differentiable curve with ")#mi("{\\gamma(0)=z_0}")#text("; we view this as the trajectory of some particle which passes through ")#mi("{z_0}")#text(" at time ")#mi("{t=0}")#text(". The derivative ")#mi("{\\gamma^{\\prime}(0)}")#text(" (defined in the usual manner by limits of Newton quotients) can then be viewed as the velocity of the particle as it passes through ")#mi("{z_0}")#text(". The map ")#mi("{f}")#text(" takes this particle to a new particle parameterised by the curve ")#mi("{f \\circ \\gamma: (-\\varepsilon,\\varepsilon) \\rightarrow {\\bf C}}")#text("; at time ")#mi("{t=0}")#text(", this new particle passes through ")#mi("{f(z_0)}")#text(", and by the chain rule we see that the velocity of the new particle at this time is given by")

#align(center)[#tao-fit-display[#mitex("(f \\circ \\gamma)^{\\prime}(0) = f^{\\prime}(z_0) \\gamma^{\\prime}(0).")]]

#text("Thus, if we write ")#mi("{f^{\\prime}(z_0)}")#text(" in polar coordinates as ")#mi("{f^{\\prime}(z_0) = r e^{i\\theta}}")#text(", the map ")#mi("{f}")#text(" transforms the velocity of the particle by multiplying the speed by a factor of ")#mi("{r}")#text(" and rotating the direction of travel counter-clockwise by ")#mi("{\\theta}")#text(". In particular, we consider two differentiable trajectories ")#mi("{\\gamma_1, \\gamma_2}")#text(" both passing through ")#mi("{z_0}")#text(" at time ")#mi("{t=0}")#text(" (with non-zero speeds), then the map ")#mi("{f}")#text(" preserves the angle between the two velocity vectors ")#mi("{\\gamma^{\\prime}_1(0), \\gamma^{\\prime}_2(0)}")#text(", as well as their orientation (e.g. if ")#mi("{\\gamma^{\\prime}_2(0)}")#text(" is counterclockwise to ")#mi("{\\gamma^{\\prime}_1(0)}")#text(", then ")#mi("{(f \\circ \\gamma_2)^{\\prime}(0)}")#text(" is counterclockwise to ")#mi("{(f \\circ \\gamma_1)^{\\prime}(0)}")#text(". This is in contrast to, for instance, shear transformations such as ")#mi("{f(x+iy) := x + i(x+y)}")#text(", which preserve orientation but not angle, or the complex conjugation map ")#mi("{f(x+iy) := x-iy}")#text(", which preserve angle but not orientation. The same preservation of angle is present for real differentiable functions ")#mi("{f: I \\rightarrow {\\bf R}}")#text(" on an interval ")#mi("{I}")#text(", but is much less impressive in that case since the only angles possible between two vectors on the real line are ")#mi("{0}")#text(" and ")#mi("{\\pi}")#text("; it is the geometric two-dimensionality of the complex plane that makes conformality a much stronger and more “rigid” property for complex differentiable functions.")
]

#text("One consequence of the first component ")#mi("{f^{\\prime} = \\frac{\\partial f}{\\partial x}}")#text(" of Proposition ")#link(<tao-109e3945b5072c8e7626>)[#text("20")]#text("(i) is that the complex notion of differentiation and the real notion of differentiation are compatible with each other. More precisely, if ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" is holomorphic and ")#mi("{g: U \\cap {\\bf R} \\rightarrow {\\bf C}}")#text(" is the restriction of ")#mi("{f}")#text(" to the real line, then the real derivative ")#mi("{\\frac{dg}{dx}: U \\cap {\\bf R} \\rightarrow {\\bf C}}")#text(" of ")#mi("{g}")#text(" exists and is equal to the restriction of the complex derivative ")#mi("{\\frac{df}{dz}: U \\rightarrow {\\bf C}}")#text(" to the real line. For instance, since ")#mi("{\\frac{d}{dz} e^{iz} = i e^{iz}}")#text(" for a complex variable ")#mi("{z}")#text(", we also have ")#mi("{\\frac{d}{dt} e^{it} = i e^{it}}")#text(" for a real variable ")#mi("{t}")#text(". For similar reasons, it will be a safe “abuse of notation” to use the notation ")#mi("{f^{\\prime}}")#text(" both to refer to the complex derivative of a function ")#mi("{f}")#text(", and also the real derivative of the restriction of that function to the real line.")#linebreak()#text(" If one breaks up a complex function ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" into real and imaginary parts ")#mi("{f = u+iv}")#text(" for some ")#mi("{u,v: U \\rightarrow {\\bf R}}")#text(", then on taking real and imaginary parts one can express the Cauchy-Riemann equations as a system ")#metadata(none) <tao-e9fd42802bc228568089>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\frac{\\partial u}{\\partial x}(z_0) = \\frac{\\partial v}{\\partial y}(z_0)")]]

#metadata(none) <tao-ecadbe47a2c827d8a72a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\frac{\\partial v}{\\partial x}(z_0) = -\\frac{\\partial u}{\\partial y}(z_0)")]]

#text("of two partial differential equations for two functions ")#mi("{u,v}")#text(". This gives a quick way to test if various functions are differentiable. Consider for instance the conjugation function ")#mi("{f: z \\mapsto \\overline{z}}")#text(". In this case, ")#mi("{u(x+iy) = x}")#text(" and ")#mi("{v(x+iy) = -y}")#text(". These functions, being polynomial in ")#mi("{x,y}")#text(", is certainly Fréchet differentiable everywhere; the equation ")#link(<tao-ecadbe47a2c827d8a72a>)[#text("(11)")]#text(" is always satisfied, but the equation ")#link(<tao-e9fd42802bc228568089>)[#text("(10)")]#text(" is never satisfied. As such, the conjugation function is never complex differentiable. Similarly for the real part function ")#mi("{z \\mapsto \\mathrm{Re}(z)}")#text(", the imaginary part function ")#mi("{z \\mapsto \\mathrm{Im}(z)}")#text(", or the absolute value function ")#tao-math("{z \\mapsto \\left|z\\right|}", block: false)#text(". The function ")#tao-math("{z \\mapsto \\left|z\\right|^2}", block: false)#text(" has real part ")#mi("{u(x+iy) = x^2+y^2}")#text(" and imaginary part ")#mi("{v(x+iy)=0}")#text("; one easily checks that the system ")#link(<tao-e9fd42802bc228568089>)[#text("(10)")]#text(", ")#link(<tao-ecadbe47a2c827d8a72a>)[#text("(11)")]#text(" is only satisfied when ")#mi("{x=y=0}")#text(", so this function is only complex differentiable at the origin. In particular, it is not holomorphic on any non-empty open set.")#linebreak()#text(" The general rule of thumb that one should take away from these examples is that complex functions that are constructed purely out of “good” functions such as polynomials, the complex exponential, complex trigonometric functions, or other convergent power series are likely to be holomorphic, whereas functions that involve “bad” functions such as complex conjugation, the real and imaginary part, or the absolute value, are unlikely to be holomorphic.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23 (Wirtinger derivatives)")]#text(" ")#metadata(none) <tao-5d5f3d996b44b5324480>#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be a Fréchet differentiable function. Define the ")#link("https://en.wikipedia.org/wiki/Wirtinger_derivatives")[#text("Wirtinger derivatives")]#text(" ")#mi("{\\frac{\\partial f}{\\partial z}: U \\rightarrow {\\bf C}}")#text(", ")#mi("{\\frac{\\partial f}{\\partial \\overline{z}}: U \\rightarrow {\\bf C}}")#text(" by the formulae")

#tao-aligned(keep: true)[


#tao-math("\\frac{\\partial f}{\\partial z}  & := \\frac{1}{2}( \\frac{\\partial f}{\\partial x} + \\frac{1}{i} \\frac{\\partial f}{\\partial y} )", block: true)



#tao-math("\\frac{\\partial f}{\\partial \\overline{z}}  & := \\frac{1}{2}( \\frac{\\partial f}{\\partial x} - \\frac{1}{i} \\frac{\\partial f}{\\partial y} ).", block: true)
]

#list(
[#text("(i) Show that ")#mi("{f}")#text(" is holomorphic on ")#mi("{U}")#text(" if and only if the Wirtinger derivative ")#mi("{\\frac{\\partial f}{\\partial \\overline{z}}}")#text(" vanishes identically on ")#mi("{U}")#text(".")],
[#text("(ii) If ")#mi("{f}")#text(" is given by a polynomial")

#metadata(none) <tao-ad38816045829dfd1c07>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("f(z) = \\sum_{n,m \\geq 0: n+m \\leq d} c_{n,m} z^n \\overline{z}^m")]]

#text("in both ")#mi("{z}")#text(" and ")#mi("{\\overline{z}}")#text(" for some complex coefficients ")#mi("{c_{n,m}}")#text(" and some natural number ")#mi("{d}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial f}{\\partial z}(z) = \\sum_{n,m \\geq 0: n+m \\leq d} c_{n,m} (n z^{n-1}) \\overline{z}^m")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial f}{\\partial \\overline{z}}(z) = \\sum_{n,m \\geq 0: n+m \\leq d} c_{n,m} z^{n} (m \\overline{z}^{m-1}).")]]

#text("(")#emph[#text("Hint:")]#text(" first establish a ")#link("https://en.wikipedia.org/wiki/General_Leibniz_rule")[#text("Leibniz rule")]#text(" for Wirtinger derivatives.) Conclude in particular that ")#mi("{f}")#text(" is holomorphic if and only if ")#mi("{c_{n,m}}")#text(" vanishes whenever ")#mi("{m \\geq 1}")#text(" (i.e. ")#mi("{f}")#text(" does not contain any terms that involve ")#mi("{\\overline{z}}")#text(").")],
[#text("(iii) If ")#mi("{z_0}")#text(" is a point in ")#mi("{U}")#text(", show that one has the Taylor expansion")

#align(center)[#tao-fit-display[#tao-math("f(z) = f(z_0) + \\frac{\\partial f}{\\partial z}(z_0) (z-z_0) + \\frac{\\partial f}{\\partial \\overline{z}}(z_0) \\overline{(z-z_0)} + o(\\left|z-z_0\\right|)", block: true)]]

#text("as ")#mi("{z \\rightarrow z_0}")#text(", where ")#tao-math("{o(\\left|z-z_0\\right|)}", block: false)#text(" denotes a quantity of the form ")#tao-math("{\\left|z-z_0\\right| c(z)}", block: false)#text(", where ")#mi("{c(z)}")#text(" goes to zero as ")#mi("{z}")#text(" goes to ")#mi("{z_0}")#text(" (compare with ")#link(<tao-7f2fe580edb35154041f>)[#text("(1)")]#text("). Conversely, show that this property determines the numbers ")#mi("{\\frac{\\partial f}{\\partial z}(z_0)}")#text(" and ")#mi("{\\frac{\\partial f}{\\partial \\overline{z}}(z_0)}")#text(" uniquely (and thus can be used as an alternate definition of the Wirtinger derivatives).")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 24")]#text(" Any polynomial")

#align(center)[#tao-fit-display[#mitex("f(x+iy) = \\sum_{n,m \\geq 0: n+m \\leq d} a_{n,m} x^n y^m")]]

#text("in the real and imaginary parts ")#mi("{x,y}")#text(" of ")#mi("{x+iy}")#text(" can be rewritten as a polynomial in ")#mi("{z}")#text(" and ")#mi("{\\overline{z}}")#text(" as per ")#link(<tao-ad38816045829dfd1c07>)[#text("(17)")]#text(", using the usual identities")

#align(center)[#tao-fit-display[#mitex("x = \\frac{z+\\overline{z}}{2}, y = \\frac{z - \\overline{z}}{2i}")]]

#text("for ")#mi("{z = x+iy}")#text(". Thus such a non-holomorphic polynomial of one complex variable ")#mi("{z=x+iy}")#text(" can be viewed as the restriction of a holomorphic polynomial")

#align(center)[#tao-fit-display[#mitex("P(z_1,z_2) := \\sum_{n,m \\geq 0: n+m \\leq d} c_{n,m} z_1^n z_2^m")]]

#text("of two complex variables ")#mi("{z_1,z_2 \\in {\\bf C}}")#text(" to the anti-diagonal ")#mi("{\\{ (z_1,z_2) \\in {\\bf C}^2: z_2 = \\overline{z_1}\\}}")#text(", and the Wirtinger derivatives can then be interpreted as genuine (complex) partial derivatives in these two complex variables. More generally, Wirtinger derivatives are convenient tools in the subject of ")#link("https://en.wikipedia.org/wiki/Several_complex_variables")[#text("several complex variables")]#text(", which we will not cover in this course.")
]

#text("The Cauchy-Riemann equations couple the real and imaginary parts ")#mi("{u,v: U \\rightarrow {\\bf R}}")#text(" of a holomorphic function to each other. But it is also possible to eliminate one of these components from the equations and obtain a constraint on just the real part ")#mi("{u}")#text(", or just the imaginary part ")#mi("{v}")#text(". Suppose for the moment that ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" is a holomorphic function which is twice continuously differentiable (thus the second partial derivatives ")#mi("{\\frac{\\partial^2 f}{\\partial x^2}}")#text(", ")#mi("{\\frac{\\partial^2 f}{\\partial y\\partial x}}")#text(", ")#mi("{\\frac{\\partial^2 f}{\\partial x \\partial y}}")#text(", ")#mi("{\\frac{\\partial^2 f}{\\partial y^2}}")#text(" all exist and are continuous on ")#mi("{U}")#text("); we will show in the next set of notes that this extra hypothesis is in fact redundant. Assuming continuous second differentiability for now, we have ")#link("https://en.wikipedia.org/wiki/Symmetry_of_second_derivatives")[#text("Clairaut’s theorem")]

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial^2 f}{\\partial x \\partial y} = \\frac{\\partial^2 f}{\\partial y \\partial x}")]]

#text("everywhere on ")#mi("{U}")#text(". Similarly for the real and imaginary parts ")#mi("{u,v}")#text(". If we then differentiate ")#link(<tao-e9fd42802bc228568089>)[#text("(10)")]#text(" in the ")#mi("{x}")#text(" direction, ")#link(<tao-ecadbe47a2c827d8a72a>)[#text("(11)")]#text(" in the ")#mi("{y}")#text(" direction, and then sum, the derivatives of ")#mi("{v}")#text(" cancel thanks to Clairaut’s theorem, and we obtain ")#link("https://en.wikipedia.org/wiki/Laplace%27s_equation")[#text("Laplace’s equation")]#text(" ")#metadata(none) <tao-066addf6741e4a75b484>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\frac{\\partial^2 u}{\\partial x^2} + \\frac{\\partial^2 u}{\\partial y^2} = 0")]]

#text("which is often written more compactly as")

#align(center)[#tao-fit-display[#mitex("\\Delta u = 0")]]

#text("where ")#mi("{\\Delta}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Laplace_operator")[#text("Laplacian operator")]

#align(center)[#tao-fit-display[#mitex("\\Delta := \\frac{\\partial^2}{\\partial x^2} + \\frac{\\partial^2}{\\partial y^2}.")]]

#text("A similar argument gives ")#mi("{\\Delta v = 0}")#text("; by linearity we then also have ")#mi("{\\Delta f=0}")#text(".")#linebreak()#text(" Functions ")#mi("{u}")#text(" for which ")#mi("{u}")#text(" is continuously twice differentiable and ")#mi("{\\Delta u = 0}")#text(" are known as ")#link("https://en.wikipedia.org/wiki/Harmonic_function")[#text("harmonic functions")]#text(": thus we have shown that (continuously twice differentiable) holomorphic functions are automatically harmonic, as are the real and imaginary parts of such functions. The converse is not true: not every harmonic function ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" is holomorphic. For instance, the conjugate function ")#mi("{z \\mapsto \\overline{z}}")#text(" is clearly harmonic on ")#mi("{{\\bf C}}")#text(", but not holomorphic. We will return to the precise relationship between harmonic and holomorphic functions shortly.")#linebreak()#text(" Harmonic functions have many remarkable properties. Since the second derivative in a given direction is a local measure of “convexity” of a function, we see from ")#link(<tao-066addf6741e4a75b484>)[#text("(13)")]#text(" that any convex behaviour of a harmonic function in one direction has to be balanced by an equal and opposite amount of concave behaviour in the orthogonal direction. A good example of a harmonic function to keep in mind is the function")

#align(center)[#tao-fit-display[#mitex("u(x+iy) := x^2 - y^2")]]

#text("which exhibits convex behavior in ")#mi("{x}")#text(" and concave behavior in ")#mi("{y}")#text(" in exactly opposite amounts. This function is the real part of the holomorphic function ")#mi("{f(z) :=z^2}")#text(", which is of course consistent with the previous observation that the real parts of holomorphic functions are harmonic.")#linebreak()#text(" We will discuss harmonic functions more in later notes. For now, we record just one important property of these functions, namely the ")#link("https://en.wikipedia.org/wiki/Maximum_principle")[#text("maximum principle")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 25 (Maximum principle)")]#text(" ")#metadata(none) <tao-9baf3a40312f39849f46>#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{u: U \\rightarrow {\\bf R}}")#text(" be a harmonic function. Let ")#mi("{K}")#text(" be a ")#link("https://en.wikipedia.org/wiki/Compact_space")[#text("compact")]#text(" subset of ")#mi("{U}")#text(", and let ")#mi("{\\partial K}")#text(" be the boundary of ")#mi("{K}")#text(". Then ")#metadata(none) <tao-7a9c94a8c201bcc22857>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\sup_{z \\in K} u(z) = \\sup_{z \\in \\partial K} u(z)")]]

#text("and similarly ")#metadata(none) <tao-7f1f073d8bb9b2e3ad6c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\inf_{z \\in K} u(z) = \\inf_{z \\in \\partial K} u(z)")]]
]

#text("Informally, the maximum principle asserts that the maximum of a real-valued harmonic function on a compact set is always attained on the boundary, and similarly for the minimum. In particular, any bound on the harmonic function that one can obtain on the boundary is automatically inherited by the interior. Compare this with a non-harmonic function such as ")#mi("{u(x+iy) := 1 - x^2 - y^2}")#text(", which is bounded by ")#mi("{0}")#text(" on the boundary of the compact unit disk ")#tao-math("{\\overline{D(0,1)} := \\{ z \\in {\\bf C}: \\left|z\\right| \\leq 1 \\}}", block: false)#text(", but is not bounded by ")#mi("{0}")#text(" on the interior of this disk.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" We begin with an “almost proof” of this principle, and then repair this attempted proof so that it is an actual proof.")#linebreak()#text(" We will just prove ")#link(<tao-7a9c94a8c201bcc22857>)[#text("(14)")]#text(", as ")#link(<tao-7f1f073d8bb9b2e3ad6c>)[#text("(15)")]#text(" is proven similarly (or one can just observe that if ")#mi("{u}")#text(" is harmonic then so is ")#mi("{-u}")#text("). Clearly we have")

#align(center)[#tao-fit-display[#mitex("\\sup_{z \\in K} u(z) \\geq \\sup_{z \\in \\partial K} u(z)")]]

#text("so the only scenario that needs to be excluded is when ")#metadata(none) <tao-396ee989f7947bdca9c4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\sup_{z \\in K} u(z) > \\sup_{z \\in \\partial K} u(z).")]]

#text("Suppose that this is the case. As ")#mi("{u}")#text(" is continuous and ")#mi("{K}")#text(" is compact, ")#mi("{u}")#text(" must attain its maximum at some point ")#mi("{z_0}")#text(" in ")#mi("{K}")#text("; from ")#link(<tao-396ee989f7947bdca9c4>)[#text("(16)")]#text(" we see that ")#mi("{z_0}")#text(" must be an interior point. Since ")#mi("{z_0}")#text(" is a local maximum of ")#mi("{u}")#text(", and ")#mi("{u}")#text(" is twice differentiable, we must have")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial^2 u}{\\partial x^2}(z_0) \\leq 0")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial^2 u}{\\partial y^2}(z_0) \\leq 0.")]]

#text("This ")#emph[#text("almost")]#text(", but does not quite, contradict the harmonicity of ")#mi("{u}")#text(", since it is still possible that both of these partial derivatives vanish. To get around this problem we use the trick of ")#link("http://www.tricki.org/article/Create_an_epsilon_of_room")[#text("creating an epsilon of room")]#text(", adding a tiny bit of convexity to ")#mi("{u}")#text(". Let ")#mi("{\\varepsilon>0}")#text(" be a small number to be chosen later, and let ")#mi("{u_\\varepsilon: U \\rightarrow {\\bf R}}")#text(" be the modified function")

#align(center)[#tao-fit-display[#mitex("u_\\varepsilon(x+iy) := u(x+iy) + \\varepsilon(x^2+y^2).")]]

#text("Since ")#mi("{K}")#text(" is compact, the function ")#mi("{x^2+y^2}")#text(" is bounded on ")#mi("{K}")#text(". Thus, from ")#link(<tao-396ee989f7947bdca9c4>)[#text("(16)")]#text(", we see that if ")#mi("{\\varepsilon>0}")#text(" is small enough we have")

#align(center)[#tao-fit-display[#mitex("\\sup_{z \\in K} u_\\varepsilon(z) > \\sup_{z \\in \\partial K} u_\\varepsilon(z).")]]

#text("Arguing as before, ")#mi("{u_\\varepsilon}")#text(" must attain its maximum at some interior point ")#mi("{z_\\varepsilon}")#text(" of ")#mi("{K}")#text(", and so we again have")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial^2 u_\\varepsilon}{\\partial x^2}(z_\\varepsilon) \\leq 0")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial^2 u_\\varepsilon}{\\partial y^2}(z_\\varepsilon) \\leq 0.")]]

#text("On the other hand, since ")#mi("{u}")#text(" is harmonic, we have")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial^2 u_\\varepsilon}{\\partial x^2} + \\frac{\\partial^2 u_\\varepsilon}{\\partial y^2} = \\frac{\\partial^2 u}{\\partial x^2} + 2 \\varepsilon + \\frac{\\partial^2 u}{\\partial y^2} + 2\\varepsilon = 4 \\varepsilon > 0")]]

#text("on ")#mi("{U}")#text(". These facts contradict each other, and we are done. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26 (Maximum principle for holomorphic functions)")]#text(" If ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" is a continuously twice differentiable holomorphic function on an open set ")#mi("{U}")#text(", and ")#mi("{K}")#text(" is a compact subset of ")#mi("{U}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\sup_{z \\in K} \\left|f(z)\\right| = \\sup_{z \\in \\partial K} \\left|f(z)\\right|.", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" use Theorem ")#link(<tao-9baf3a40312f39849f46>)[#text("25")]#text(" and the fact that ")#tao-math("{\\left|w\\right| = \\sup_{\\theta \\in {\\bf R}} \\mathrm{Re} w e^{i\\theta}}", block: false)#text(" for any complex number ")#mi("{w}")#text(". You may find the proof of Lemma 8 in the ")#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/")[#text("next set of notes")]#text(" to be helpful as inspiration.) What happens if we replace the suprema on both sides by infima? This result is also known as the ")#link("https://en.wikipedia.org/wiki/Maximum_modulus_principle")[#text("maximum modulus principle")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" ")#metadata(none) <tao-5afab9a620f6f1128450>#text(" Recall the Wirtinger derivatives defined in Exercise ")#link(<tao-5d5f3d996b44b5324480>)[#text("23")]#text("(i).")

#list(
[#text("(i) If ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" is twice continuously differentiable on an open subset ")#mi("{U}")#text(" of ")#mi("{{\\bf C}}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\Delta f = 4 \\frac{\\partial}{\\partial z} \\frac{\\partial f}{\\partial \\overline{z}} = 4 \\frac{\\partial}{\\partial \\overline{z}} \\frac{\\partial f}{\\partial z}.")]]

#text("Use this to give an alternate proof that (")#mi("{C^2}")#text(") holomorphic functions are harmonic.")],
[#text("(ii) If ")#mi("{f}")#text(" is given by a polynomial")



#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("f(z) = \\sum_{n,m \\geq 0: n+m \\leq d} c_{n,m} z^n \\overline{z}^m")]]

#text("in both ")#mi("{z}")#text(" and ")#mi("{\\overline{z}}")#text(" for some complex coefficients ")#mi("{c_{n,m}}")#text(" and some natural number ")#mi("{d}")#text(", show that ")#mi("{f}")#text(" is harmonic on ")#mi("{{\\bf C}}")#text(" if and only if ")#mi("{c_{n,m}}")#text(" vanishes whenever ")#mi("{n}")#text(" and ")#mi("{m}")#text(" are both positive (i.e. ")#mi("{f}")#text(" only contains terms ")#mi("{c_{n,0} z^n}")#text(" or ")#mi("{c_{0,m} \\overline{z}^m}")#text(" that only involve one of ")#mi("{z}")#text(" or ")#mi("{\\overline{z}}")#text(").")],
[#text("(iii) If ")#mi("{u: U \\rightarrow {\\bf R}}")#text(" is a real polynomial")

#align(center)[#tao-fit-display[#mitex("u(x+iy) = \\sum_{n,m \\geq 0: n+m \\leq d} a_{n,m} x^n y^m")]]

#text("in ")#mi("{x}")#text(" and ")#mi("{y}")#text(" for some real coefficients ")#mi("{a_{n,m}}")#text(" and some natural number ")#mi("{d}")#text(", show that ")#mi("{u}")#text(" is harmonic if and only if it is the real part of a polynomial ")#mi("{f(z) = \\sum_{n=0}^d c_n z^n}")#text(" of one complex variable ")#mi("{z}")#text(".")]
)
]

#text("We have seen that the real and imaginary parts ")#mi("{u,v: U \\rightarrow {\\bf R}}")#text(" of any holomorphic function ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" are harmonic functions. Conversely, let us call a harmonic function ")#mi("{v:U \\rightarrow {\\bf R}}")#text(" a ")#link("https://en.wikipedia.org/wiki/Harmonic_conjugate")[#text("harmonic conjugate")]#text(" of another harmonic function ")#mi("{u: U \\rightarrow {\\bf R}}")#text(" if ")#mi("{u+iv}")#text(" is holomorphic on ")#mi("{U}")#text("; this is equivalent by Proposition ")#link(<tao-109e3945b5072c8e7626>)[#text("20")]#text(" to ")#mi("{u,v}")#text(" satisfying the Cauchy-Riemann equations ")#link(<tao-e9fd42802bc228568089>)[#text("(10)")]#text(", ")#link(<tao-ecadbe47a2c827d8a72a>)[#text("(11)")]#text(". Here is a short table giving some examples of harmonic conjugates:")

#table(columns: 3, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#mi("{u}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{v}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{u+iv}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{x}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{y}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{z}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{x}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{y+1}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{z+i}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{y}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-x}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-iz}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{x^2-y^2}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2xy}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{z^2}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{e^x \\cos y}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{e^x \\sin y}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{e^z}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\frac{x}{x^2+y^2}}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\frac{-y}{x^2+y^2}}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\frac{1}{z}}")]
)

#text("(for the last example one of course has to exclude the origin from the domain ")#mi("{U}")#text(").")#linebreak()#text(" From Exercise ")#link(<tao-5afab9a620f6f1128450>)[#text("27")]#text("(ii) we know that every harmonic polynomial has at least one harmonic conjugate; it is natural to ask whether the same fact is true for more general harmonic functions than polynomials. In the case that the domain ")#mi("{U}")#text(" is the entire complex plane, the answer is affirmative:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 28")]#text(" Let ")#mi("{u: {\\bf C} \\rightarrow {\\bf R}}")#text(" be a harmonic function. Then there exists a harmonic conjugate ")#mi("{v: {\\bf C} \\rightarrow {\\bf R}}")#text(" of ")#mi("{u}")#text(". Furthermore, this harmonic conjugate is unique up to constants: if ")#mi("{v,v^{\\prime}}")#text(" are two harmonic conjugates of ")#mi("{u}")#text(", then ")#mi("{v^{\\prime}-v}")#text(" is a constant function.")
]

#emph[#text("Proof:")]#text(" We first prove uniqueness. If ")#mi("{v}")#text(" is a harmonic conjugate of ")#mi("{u}")#text(", then from the fundamental theorem of calculus, we have")

#align(center)[#tao-fit-display[#mitex("v(x+iy) = v(0) + \\int_0^x \\frac{\\partial v}{\\partial x}(t)\\ dt + \\int_0^y \\frac{\\partial v}{\\partial y}(x+it)\\ dt")]]

#text("and hence by the Cauchy-Riemann equations ")#link(<tao-e9fd42802bc228568089>)[#text("(10)")]#text(", ")#link(<tao-ecadbe47a2c827d8a72a>)[#text("(11)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("v(x+iy) = v(0) - \\int_0^x \\frac{\\partial u}{\\partial y}(t)\\ dt + \\int_0^y \\frac{\\partial u}{\\partial x}(x+it)\\ dt.")]]

#text("Similarly for any other harmonic conjugate ")#mi("{v^{\\prime}}")#text(" of ")#mi("{v}")#text(". It is now clear that ")#mi("{v.}")#text(" and ")#mi("{v^{\\prime}}")#text(" differ by a constant.")#linebreak()#text(" Now we prove existence. Inspired by the above calculations, we define ")#mi("{v: {\\bf C} \\rightarrow {\\bf R}}")#text(" to be the define ")#mi("{v}")#text(" explicitly by the formula ")#metadata(none) <tao-1c1480e67eee52c17293>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("v(x+iy) := -\\int_0^x \\frac{\\partial u}{\\partial y}(t)\\ dt + \\int_0^y \\frac{\\partial u}{\\partial x}(x+it)\\ dt.")]]

#text("From the fundamental theorem of calculus, we see that ")#mi("{v}")#text(" is differentiable in the ")#mi("{y}")#text(" direction with")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial v}{\\partial y}(x+it) = \\frac{\\partial u}{\\partial x}(x+it).")]]

#text("This is one of the two Cauchy-Riemann equations needed. To obtain the other one, we differentiate ")#link(<tao-1c1480e67eee52c17293>)[#text("(18)")]#text(" in the ")#mi("{x}")#text(" variable. The fact that ")#mi("{u}")#text(" is continuously twice differentiable allows one to differentiate under the integral sign (exercise!) and conclude that")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial v}{\\partial x}(x+iy) = - \\frac{\\partial u}{\\partial y}(x) + \\int_0^y \\frac{\\partial^2 u}{\\partial x^2}(x+it)\\ dt.")]]

#text("As ")#mi("{u}")#text(" is harmonic, we have ")#mi("{\\frac{\\partial^2 u}{\\partial x^2} = - \\frac{\\partial^2 u}{\\partial y^2}}")#text(", so by the fundamental theorem of calculus we conclude that")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial v}{\\partial x}(x+iy) = -\\frac{\\partial u}{\\partial y}(x+iy).")]]

#text("Thus we now have both of the Cauchy-Riemann equations ")#link(<tao-e9fd42802bc228568089>)[#text("(10)")]#text(", ")#link(<tao-ecadbe47a2c827d8a72a>)[#text("(11)")]#text(" in ")#mi("{{\\bf C}}")#text(". Differentiating these equations again, we conclude that ")#mi("{v}")#text(" is twice continuously differentiable, and hence by Proposition ")#link(<tao-109e3945b5072c8e7626>)[#text("20")]#text(" we have ")#mi("{u+iv}")#text(" holomorphic on ")#mi("{{\\bf C}}")#text(", giving the claim. ")#mi("\\Box")#linebreak()#text(" The same argument would also work for some other domains than ")#mi("{{\\bf C}}")#text(", such as rectangles ")#mi("{\\{ z: a < \\mathrm{Re}(z) < b; c < \\mathrm{Im}(z) < d \\}}")#text(". To handle the general case, though, it becomes convenient to introduce the notion of contour integration, which we will do in the next set of notes. In some cases (specifically, when the underlying domain ")#mi("{U}")#text(" fails to be simply connected), it will turn out that some harmonic functions do not have conjugates!")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29")]#text(" Show that an entire function ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" can be real-valued on ")#mi("{{\\bf C}}")#text(" only if it is constant.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30")]#text(" Let ")#mi("{c}")#text(" be a complex number. Show that if ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" is an entire function such that ")#mi("{\\frac{df}{dz}(z) = cf(z)}")#text(" for all ")#mi("{z \\in {\\bf C}}")#text(", then ")#mi("{f(z) = f(0) \\exp( cz)}")#text(" for all ")#mi("{z \\in {\\bf C}}")#text(".")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (80)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a382183d3ed7cf33b841b9044414e6aa0b91df1f4ea991fed59aa4ff2caf406-aa091041e3d91f48464237b83b2439f11d347b3a9aaa0c27dc2e4ef3724cb570.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of g")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-472509")[#strong[#text("g")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2016")])]

#text("Typo in exercise 13: you have a fraction instead of a binomial coefficient. (Either that or there’s a TeX rendering bug somewhere.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6bebd98d6fb28065cabd1b1618ff7d8ff03f47981ad044597a620e6f8790c6da-bd4052c844a2be42dadd0acc697e56dc90bd6b726b72c33c598c10dd49c2260b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sébastien Boisgérault")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-472510")[#strong[#text("Sébastien Boisgérault")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2016")])]

#text("Could you categorize this document as “246A — complex analysis” ?")#linebreak()#text(" (otherwise it won’t be listed in ).")#linebreak()#text(" Regards, SB.")

#emph[#text("[Done, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-472517")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2016")])]

#text("In exercise 5(ii), it seems that the convex hull of the roots of ")#mi("P")#text(" is the smallest possible convex set containing the roots of ")#mi("P^{\\prime}")#text(" if and only if ")#mi("P")#text(" has multiple(!) roots on all the vertices of the convex hull of its roots.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-472519")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2016")])]

#text("In the second line of definition 6, “is” is missing before “a formal”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98d192abd70f5311db8ec60dec56a48604f76cb7ff6a4cf4f5df43803680c3ff-cb5dcadf7bcf8b56cb8857c450f2fddd18645e59e478b53d2f6ab76b378a6646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jhon Manugal")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-472520")[#strong[#text("Jhon Manugal")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2016")])]

#text("I would hardly debate the Maximum principle as stated here and yet it has such profound consequences. I never quite see it coming. It is a bit like following a game of 3 card monte.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-472521")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2016")])]

#text("In remark 21, it seems that ")#mi("f(z)")#text(" should be ")#mi("e^{-1/z^4}")#text(" for ")#mi("z \\neq 0")#text(" (in order to be smooth on the real and imaginary axes.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/189645cfb9f987222d0b04916d637c0d7d22cb0862a5c0332a675455da60310a-25f80fcdd5dcf840dec644ed463dfe8ca0b1ce04ea6ad905ac886aee64ed7685.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dirk")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-472522")[#strong[#text("Dirk")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2016")])]

#text("When reading the notes, it appeared to my that the fact that holomorphic functions are so rigid can be seen also (and probably most clearly) in the formulation of complex differentiability by linearization: If we view ")#mi("f")#text(" as mapping from ")#mi("\\mathbb{R}^2")#text(" to itself, we would allow for an arbitrary linear map as derivative. However, we view ")#mi("f")#text(" as map from ")#mi("\\mathbb{C}")#text(" to itself and only allow for very special linear maps, namely those given by complex multiplication. This greatly restricts the class of linear maps that are allowed to use for linearization, namely to ")#mi("2\\times 2")#text(" matrices which have constant diagonal and are skew symmetric. As far as I remember, I haven’t seen this view in any textbook – do you know any book where complex differentiability is discussed this way?")

#emph[#text("[Ah, I had forgotten to add a remark on precisely this; done so now. I think this is discussed for instance in Ahlfors’ book. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-472524")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2016")])]

#text("In exercise 26(ii), it seems that “whenever ")#mi("n, m \\geq 1")#text("” should be “whenever ")#mi("n \\geq 1")#text(" or ")#mi("m \\geq 1")#text("“.")

#emph[#text("[Remark clarified – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-472537")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2016")])]

#text("Dear Terry,")#linebreak()#text(" I am a female teacher of math.Iam 32.Iam still alone.I admire and like(even I love you,but what a pity you have got married).I always care and follow you,I wonder that this september(nearly end of 2016 ),I do not still your breakththrough,while every year your name attached with great events(2013-Terry Tao and Twin primes,2014-Terry Tao and Navier Stokes,2015-Terry Tao and Erdos problem,2016-?????)")#linebreak()#text(" Best wishes,")#linebreak()#text(" Natasha,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-472540")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2016")])]

#text("Suppose that ")#mi("(x^{\\prime}, y^{\\prime})")#text(" is any(!) local coordinate system for a neighborhood of the origin in ")#mi("\\mathbb R^2")#text(", is it possible by defining ")#mi("z^{\\prime}=x^{\\prime}+ i y^{\\prime}")#text(" to develop a completely analogous theory for holomorphic and analytic functions with respect to the complex variable ")#mi("z^{\\prime}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-472552")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2016")])]

#text("Certainly! Of course, the underlying vector space, topological, or smooth structure of ")#mi("{\\mathbb R}^2")#text(" may have little to do with the complex structure thus created if the local coordinate system used is nonlinear, discontinuous, or non-smooth respectively.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-472553")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2016")])]

#text("As a nice application, suppose that the new coordinates ")#mi("x^{\\prime}, y^{\\prime}")#text(" are sufficiently smooth functions of the (“reference”) coordinates ")#mi("x,y")#text(" (e.g. ")#mi("x^{\\prime} = x + y^2, y^{\\prime} = y+x^2")#text(" with nonsingular Jacobian matrix near the origin) and ")#mi("u^{\\prime}, v^{\\prime}")#text(" are also smooth functions of ")#mi("x, y")#text(". Then to check if the complex variable $w’ = u’ + v’$ can be represented as a power series of $z’ = x’ + i y’$ near the origin, one needs only to check if ")#mi("w^{\\prime}")#text(" satisfy the Cauchy-Riemann equations (with respect to ")#mi("z^{\\prime}")#text(") near the origin.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-472554")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2016")])]

#text("Correction: it should be ")#mi("w^{\\prime} = u^{\\prime} + i v^{\\prime}")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-472595")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2016")])]

#text("Remark 21 : There seems to be a missing link under “this blog post”")

#text("A bit later : “\\href{harmonic conjugate}” should probably link to something as well.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd20f1db240a2ba555cf144343c4bb6ea253b6ed3f20681eda8b0174a8e7df5e-b7f7f5c88d67fa1446eebb7a311ec2befe3263b37121f50574c251c2bd60b9a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven Gubkin")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-472615")[#strong[#text("Steven Gubkin")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2016")])]

#text("I remember being frustrated by the definition of Wirtinger derivatives when I was learning this subject. Two points which might be helpful:")

#text("Any real linear map ")#mi("L:\\mathbb{C} \\to \\mathbb{C}")#text(" can be uniquely decomposed into a complex linear map and a complex antilinear map. When you apply this to the real linear derivative of a complex function ")#mi("f: \\mathbb{C} \\to \\mathbb{C}")#text(" at a point ")#mi("p")#text(", you obtain exactly the formulas for the Wirtinger derivatives: ")#mi("df = \\frac{\\partial f}{\\partial z} \\mathrm{d}z+ \\frac{\\partial f}{\\partial \\bar{z}} \\mathrm{d}\\bar{z}")#text(".")

#text("Another thing: the Wirtinger derivatives are perhaps more clearly written as")

#mi("\\frac{\\partial f}{\\partial z} = \\frac{1}{2} (\\frac{\\partial f}{\\partial x}+\\frac{1}{i}\\frac{\\partial f}{\\partial y})")

#text("and")

#mi("\\frac{\\partial f}{\\partial z} = \\frac{1}{2} (\\frac{\\partial f}{\\partial x}-\\frac{1}{i}\\frac{\\partial f}{\\partial y})")

#emph[#text("[Good suggestions, I have added them to the text – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-472632")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2016")])]

#text("Typo in the delta-epsilon definition near beginning: should say |z – z0| < delta.")

#text("Thanks for making these notes!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-472643")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2016")])]

#text("It seems that in exercise 26 (and also in theorem 25), one can assume (without loss of generality) that ")#mi("K")#text(" is closed (not necessarily compact), since by appropriate bilinear transformation it can be mapped to a compact set.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-472644")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2016")])]

#text("This is only true if one works in the Riemann sphere (with its attendant topological and complex structures), which is where bilinear transformations live as complex automorphisms. Otherwise there are many counterexamples, e.g. ")#mi("e^{-iz}")#text(" is unbounded on the upper half-plane, but is bounded on the boundary of that half-plane. (See however the ")#link("https://en.wikipedia.org/wiki/Phragm%C3%A9n%E2%80%93Lindel%C3%B6f_principle")[#text("Phragmen-Lindelof principle")]#text(" for an important partial result in this direction.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-472777")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2016")])]

#text("Hello professor, for the ratio test (Ex 9), we also have ")#tao-math("\\limsup \\frac{\\left|a_n\\right|}{\\left|a_{n+1}\\right|} \\geq \\limsup \\left|a_n\\right|^{-\\frac{1}{n}}", block: false)#text(", right? Thank you for your time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Math 246A, Notes 3: Cauchy’s theorem and its consequences | What's new")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-472787")[#strong[#text("Math 246A, Notes 3: Cauchy’s theorem and its consequences | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2016")])]

#text("[…] this and Proposition 7 of Notes 1, we see that the radius of convergence of is indeed at least […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-473038")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2016")])]

#text("Following equn. (8) —")#linebreak()#text(" for “existing at {z_0}, but {f} is not differentiable here”")#linebreak()#text(" read “existing at {z_0 = 0}, but {f} is not differentiable here”")

#text("prop. 20, remark 21 — “Fréchet” (3 times)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bd6ea7a3f3159b5c25545b4327d962c250bf5b6fef87c17c2d17f7d8e41e3c3-edd023a28d61769277b23e32b81a8031f0cb96ef8e31541dd95131d8bfa6192c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-473244")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2016")])]

#text("May be in Proposition 20 “")#mi("F")#text("” and “")#mi("z_0")#text(" be an element of ")#mi("C")#text(".” are typos and they should be “")#mi("f")#text("” and “element of ")#mi("U")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246A, Notes 5: conformal mapping | What's new")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-473440")[#strong[#text("246A, Notes 5: conformal mapping | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("[…] Exercise 2 Establish Lemma 1(ii) by direct calculation, avoiding the use of holomorphic functions. (Hint: the calculations are cleanest if one uses Wirtinger derivatives, as per Exercise 27 of Notes 1.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fba7098f7286623bf3673657f1ff96e3be67e69487e67018084add49c3ba031-5aa510afc990f970bb1801ee33b9d7ffaae5f7cd3249f3ff8927bd3e0b9d5b8d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Venky")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-475207")[#strong[#text("Venky")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2016")])]

#text("Great notes! Two typos: in the proof of Proposition 7, there is a badly formed expression ")#tao-math("\\left|a_n\\right|^{-1/n}1", block: false)#text(", and there is an extra ")#mi("dt")#text(" in the equation right after equation (18).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-477768")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2017")])]

#text("There is also (if it exists) the gradient (or Fréchet derivative) {Df(z_0) \\in {\\bf C}^2}, defined as the vector {(D_1 f(z_0), D_2 f(z_0)) \\in {\\bf C}^2} with the property that…")

#text("Should ")#mi("{\\bf C}^2")#text(" be ")#mi("{\\bf R}^2")#text(" instead? I cannot make sense of this part.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-477777")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2017")])]

#text("No, I intend ")#mi("Df(z_0)")#text(" to lie in ")#mi("{\\bf C}^2")#text(" (thus each of the components ")#mi("D_1 f(z_0)")#text(", ")#mi("D_2 f(z_0)")#text(" of this vector are complex numbers). For instance, if ")#mi("f(z) = 3iz")#text(" and ")#mi("z_0 = 1")#text(", then ")#mi("D_1 f(z_0) = 3i")#text(", ")#mi("D_2 f(z_0) = -3")#text(", and ")#mi("Df(z_0) = (3i, -3) \\in {\\bf C}^2")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-477780")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2017")])]

#text("Ah. When you ")#emph[#text("define")]#text(" ")#mi("Df(z_0)")#text(", ")#mi("D_1")#text(" and ")#mi("D_2")#text(" are used without having a definition… And later, it is said that")

#text("we see that")

#mi("\\displaystyle  \\frac{\\partial f}{\\partial x}(z_0) = D_1 f(z_0)")

#text("and")

#mi("\\displaystyle  \\frac{\\partial f}{\\partial y}(z_0) = D_2 f(z_0)")

#text("This looks circular. Would you please elaborate what definition do you use for ")#mi("D_1")#text(" and ")#mi("D_2")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db070355fdb640ad2c7e83f2901c04633b4e24c7b6e1d2ee2589133350895006-f9da2e26c1544e14f1a4e3e3f414c5d1d407558530a6ed84bd66e870340def56.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nightmartyr")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-477784")[#strong[#text("nightmartyr")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2017")])]

#mi("D_1")#text(" and ")#mi("D_2")#text(" are defined in Equation (7) and the sentence preceding it. That limit is the definition of this vector, and it turns out the components of the vector satisfy being just these partial derivatives.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-477786")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2017")])]

#text("Maybe typos in (7). ")#mi("Df_1")#text(" and ")#mi("Df_2")#text(" should be ")#mi("D_1f")#text(" and ")#mi("D_2f")#text(" I think.")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6389ce7c3593c0b3fdeda317075cb3e693dae6b75f92170f2c10b5142adf7e37-9361ed76527be549df139beb8553b55a70326b3ee557f14c7cc2cd27658be283.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Five-Value Theorem of Nevanlinna – Elmar Klausmeier's Weblog")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-481925")[#strong[#text("Five-Value Theorem of Nevanlinna – Elmar Klausmeier's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2017")])]

#text("[…] 246A, Notes 1: complex differentiation […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-485849")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2017")])]

#text("Do we have the mean value theorem and L’Hopital rule as in real analysis?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-485887")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2017")])]

#text("L’Hopital’s rule carries over (with basically the same proof), but the mean value theorem is now false. For instance, if ")#mi("f(z) = \\exp(z)")#text(" is the exponential function, there is no complex number ")#mi("z")#text(" for which ")#mi("f^{\\prime}(z) = \\frac{f(2\\pi i) -f(0)}{2\\pi i - 0}")#text(", despite ")#mi("f")#text(" being complex differentiable on the entire complex plane. (It is instructive to figure out what property of the real line, that is not shared by the complex numbers, is responsible for the mean value theorem being true for real-valued functions but not complex-valued functions. It is a good exercise to revisit the proof of the real-variable mean value theorem to answer this question.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-485898")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2017")])]

#text("I’m a bit confused with the L’Hopital rule. Rudin gave an example that ")#mi("g, f: (0,1)\\to{\\bf C}")#text(" with ")#mi("f(x)=x")#text(" and ")#mi("g(x)=x+x^2e^{i/x^2}")#text(" and")

#mi("\\displaystyle \\lim_{x\\to 0}\\frac{f(x)}{g(x)}=1,\\quad \\lim_{x\\to 0}\\frac{f^{\\prime}(x)}{g^{\\prime}(x)}=0")

#text("Is this a contradiction to the L’Hopital rule in complex analysis?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-485909")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2017")])]

#text("Hmm, you’re right. The argument I had in mind assumed that the denominator was analytic at the limit point, which is not the case in Rudin’s example.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b190aade593307db150f060728101b44390f149bf712bf76cbc3d4cc27cde43f-1247e413442aafd49839e313e76a9cfd80cd875c9df3e3aed058985028db0db8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cong Ma")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-488360")[#strong[#text("Cong Ma")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2017")])]

#text("I wonder whether the mean value theorem carries over to the Wirtinger derivative. That is for ")#mi("f:\\mathcal{C}^n \\rightarrow \\mathcal{C}^d")#text(", do we have ")#mi("f(z_1)-f(z_2) = \\int_{0}^{1}\\nabla f(z(\\tau))d\\tau \\left[\\begin{array}{c} z_{1}-z_{2}\\\\ \\overline{z_{1}-z_{2}} \\end{array}\\right]")#text(", where ")#mi("z(\\tau) = z_2 + \\tau (z_1 - z_2)")#text(", ")#mi("\\overline{z_1 - z_2}")#text(" denotes the conjugate of ")#mi("z_1 -z_2")#text(" and ")#mi("\\nabla f(z(\\tau))")#text(" is the Wirtinger Jacobian.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-488574")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2017")])]

#text("This identity is true (for continuously differentiable functions ")#mi("f")#text("), as can be seen from the fundamental theorem of calculus and the chain rule, but I am not sure if it deserves to be named the mean value theorem.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b190aade593307db150f060728101b44390f149bf712bf76cbc3d4cc27cde43f-1247e413442aafd49839e313e76a9cfd80cd875c9df3e3aed058985028db0db8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cong Ma")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-488578")[#strong[#text("Cong Ma")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2017")])]

#text("Thank you very much!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-594309")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("Does the mean value theorem fail mainly because we don’t have an ordering of the complex numbers anymore, and so things like the intermediate value property or Rolle’s theorem fail.")#linebreak()#text(" In other words, we cannot say that the derivative is zero at a point of extremum because now the extremum doesn’t make sense for a complex valued function anymore.")

#text("Is that correct ?")

#emph[#text("[Yes – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-485892")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2017")])]

#text("Probably there is a type in Exercise 29 “can real-valued”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Fullwood")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-493792")[#strong[#text("James Fullwood")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2018")])]

#text("In the definition of radius of convergence, should lim inf be replaced with lim sup? (If not, then I am curious as to why most references use lim sup.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-493800")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2018")])]

#text("One can write the radius of convergence either as the limit inferior of ")#tao-math("\\left|a_n\\right|^{-1/n}", block: false)#text(", or as the reciprocal of the limit superior of ")#tao-math("\\left|a_n\\right|^{1/n}", block: false)#text("; the two definitions are equivalent.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5507dc88edaa9b9caf2a30af7617d3389c4507fa2ffadcf7c6f22a5391f71fc7-e1d95aaacf2d7dfb5e5cb8c3b29258b14fad459fa9cbf5659412ecd6fb13af55.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of অরিত্র")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-501878")[#strong[#text("অরিত্র")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2018")])]

#text("There’s a typo in exercise 4(iv): the g’s should be replaced by h")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/341c133653f61e5a4ef6fdfb5c0aa4659af29a209c233db0c4d318289620585b-fd56eed046234e950c4b3fd0c7aa98bbdbca8973e15d977545cd8fef37fb4e48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aritra Bhattacharya")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-502038")[#strong[#text("Aritra Bhattacharya")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2018")])]

#text("What is that ")#tao-math("\\left|a_n\\right|^{1/n}1", block: false)#text(" in line 3 of proof of proposition 7?")

#emph[#text("[HTML formatting error; should be fixed now – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cdbf5f5cd112dc5cdf0cf0c007d4554d3dd68f0acaf19381258b2b58724e8b97-dc613c769f3ff2fcb43de27a58002b249bf2e4d4af411478399c22d3ebce2e14.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aritra Biswas")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-507366")[#strong[#text("Aritra Biswas")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2018")])]

#text("Respected Sir,")#linebreak()#text(" As you mention in the ‘power Series’ section “As it turns out, the region of convergence is always essentially a disk”, I am wandering as to why the region of convergence is essentially a disk and nothing else, i.e I am curious to know if there is any topological subtle reason for such uniform behavior of the region of convergence. Since I am a new-learner, it may happen that my question bears some logical error or pointless per se. I am apologetic beforehand for such occurrences. Pleasr help me go through.")#linebreak()#text(" Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-507478")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2018")])]

#text("The fact that the region of convergence is a disk (possibly with or without portions of the circular boundary of the disk) is a corollary of the ")#link("https://en.wikipedia.org/wiki/Root_test")[#text("root test")]#text(". It reflects the fact that if a series converges conditionally, then any other series with exponentially smaller summands will converge absolutely.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cdbf5f5cd112dc5cdf0cf0c007d4554d3dd68f0acaf19381258b2b58724e8b97-dc613c769f3ff2fcb43de27a58002b249bf2e4d4af411478399c22d3ebce2e14.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aritra Biswas")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-508371")[#strong[#text("Aritra Biswas")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2018")])]

#text("Thank you Sir. Thanks a lot.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keej")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-509273")[#strong[#text("keej")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2018")])]

#text("Thank you for posting these notes. I have a question (possible typo?)")

#text("In Remark 22, regarding the statement “The same preservation of angle is present for real differentiable functions”, do you mean functions from complex numbers to reals, as written, or do you mean functions from reals to reals? If the former, I’m not sure how to interpret what it means for such a map to be conformal.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-509290")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2018")])]

#text("I meant the latter; I have modified the text to clarify this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b7372863f1c5025505c2f0e372bc199488ae50a5b564ba938f96378b1e5c3c9f-201989625023f416037f6f9558889b2717dcd99ac36fd4269049bb986d79e922.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maxis Jaisi")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-550564")[#strong[#text("Maxis Jaisi")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2020")])]

#text("I’ve never seen gradient defined for a complex valued function. How do you define the gradient of a map ")#mi("f: \\mathbf{C}^n \\to \\mathbf{C}")#text(", for example?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-550629")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2020")])]

#text("There would be two possible gradients one could use here. In analogy to the gradient ")#mi("Df")#text(" used in these notes, one could define the gradient ")#mi("\\nabla_{{\\bf R}^{2n}} f: {\\bf C}^n \\to {\\bf C}^{2n}")#text(" of a continuously (real) differentiable ")#mi("f: {\\bf C}^n \\to {\\bf C}")#text(" by identifying ")#mi("{\\bf C}^n")#text(" with ")#mi("{\\bf R}^{2n}")#text(" and taking the usual real gradient. If the function ")#mi("f")#text(" depends holomorphically on its inputs ")#mi("z_1,\\dots,z_n")#text(" (or equivalently if ")#mi("\\nabla_{{\\bf R}^{2n}} f")#text(" obeys the Cauchy-Riemann equations in each variable separately), one can also define the complex gradient ")#mi("\\nabla_{{\\bf C}^n} f: {\\bf C}^n\\to {\\bf C}^n")#text(" as ")#mi("\\nabla_{{\\bf C}^n} = (\\partial f/ \\partial z_1, \\dots, \\partial f / \\partial z_n)")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9b11d26ae58dded1416e6414b0383ac5f2ff9d038b90523eb5f56f4865eeb10-008e9b6334b27bdc64c6ad5c3946cb11b3d35cbd0586b3257e67455b6c2a7c66.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jiayun Meng")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-594118")[#strong[#text("Jiayun Meng")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("At the beginning of section two, shall the denominator of partial derivative in direction of y be ih instead of h?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9b11d26ae58dded1416e6414b0383ac5f2ff9d038b90523eb5f56f4865eeb10-008e9b6334b27bdc64c6ad5c3946cb11b3d35cbd0586b3257e67455b6c2a7c66.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jiayun Meng")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-594128")[#strong[#text("Jiayun Meng")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("Sorry! I understood the material wrongly. It should be h. But I am a bit confused about why it is defined like this. Can I view it as the partial derivative in sense of R^2 plane? Thanks in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69f78ca84676cd596cc590c6317f8ff7b2f20f23ad01251f1373e9c45950429d-939f3e1dfca2696608dd916944f50d7f61d1824cab438612049e6384ee35f0c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-595095")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("Yes, it’s just a partial derivative in the usual sense of a function on R^2 (taking values in the complex plane), the vertical partial derivative. – Ben")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-594307")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("Yesterday during the lectures the following question was asked :")#linebreak()#text(" “Does there exist a function which satisfies the Cauchy Riemann equations at a point but is not holomorphic there ?”")

#text("The answer is yes (as we all agreed), and here is an example (I will leave the verification for the reader) :")

#text("The function ")#mi("f(x+ iy) = \\frac{(1+i) x^3 - (1-i)y^3}{x^2+y^2}")#text(" satisfies the Cauchy Riemann conditions at ")#mi("0")#text(" but is NOT holomorphic there.")

#text("The easiest way to verify is to go via the definition of complex differentiability to verify that ")#mi("f")#text(" is indeed not holomorphic at 0, and the Cauchy Riemann conditions can be verified in a straightforward manner.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-594308")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("I just forgot to mention that we should have ")#mi("f(0) = 0")#text(" in the above example.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/33b26edc4ef5e000529026ac77dd839231886a7bffaa8c1dd07531e238933100-5f9603ca0a37873cafc810cfe8dd5f2e70a532324b85eb4e9b217e39c16faaaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Prateek P Kulkarni")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-594327")[#strong[#text("Prateek P Kulkarni")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("Well,it was me who asked the question. My question wasn’t exactly about one point, but your answer has got it all. Thanks for the examples @adityaguharoy")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-594737")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2020")])]

#text("There are three notions of differentiability at a point ")#mi("z_0")#text(" in this set of notes and Stein-Shakarchi’s book.")

#text("(I) The “gradient” (or Fréchet derivative) ")#mi("{Df(z_0) \\in {\\bf C}^2}")#text(", defined as the vector ")#mi("{(D_1 f(z_0), D_2 f(z_0)) \\in {\\bf C}^2}")#text(" with the property that")

#mi("\\displaystyle \\lim_{(h_1,h_2) \\rightarrow 0: (h_1,h_2) \\in {\\bf R}^2 \\backslash \\{0\\}} \\ \\ \\ \\ \\ (7)")#linebreak()#text(" ")#tao-math("\\displaystyle \\frac{\\left|f((x_0+h_1)+i(y_0+h_2)) - f(x_0+iy_0) - h_1 D_1f(z_0) - h_2 D_2f(z_0)\\right|}{\\left|(h_1,h_2)\\right|} = 0", block: false)

#text("where ")#tao-math("{\\left|(h_1,h_2)\\right| := \\sqrt{h_1^2+h_2^2}}", block: false)#text(" is the Euclidean norm of ")#mi("{(h_1,h_2)}")#text(".")

#text("In this definition, ")#mi("{Df(z_0)\\in {\\bf C}^2}")#text(".")

#text("(II) The complex derivative in Definition 2.")

#text("In this definition ")#mi("f^{\\prime}(z_0)")#text(" is a ")#mi("{\\bf C}")#text("-linear map from ")#mi("{\\bf C}")#text(" to ")#mi("{\\bf C}")#text(".")

#text("(III) In Stein-Shakarchi, the complex-valued function ")#mi("f=u+iv")#text(" is associated with the mapping ")#mi("F:{\\bf R}^2\\to{\\bf R}^2")#text(" where ")#mi("F(x,y)=(u(x,y),v(x,y))")#text(". In this definition, ")#mi("DF(x_0,y_0)")#text(" is a ")#mi("{\\bf R}")#text("-linear map from ")#mi("{\\bf R}^2")#text(" to ")#mi("{\\bf R}^2")#text(".")

#text("Are the notions in (I) and (III) equivalent?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-594742")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2020")])]

#text("Yes; the linear map ")#mi("DF(z_0)")#text(" in (III) corresponds in the notation of (I) to the map ")#mi("(h_1,h_2) \\mapsto h_1 Df_1(z_0) + h_2 Df_2(z_0)")#text(" (identifying ")#mi("{\\bf C}")#text(" with ")#mi("{\\bf R}^2")#text(" as necessary).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-594774")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2020")])]

#text("Ah. I was confused when trying to identify ")#mi("Df(z_0)\\in{\\bf C}^2")#text(" in notion (I) with the ")#mi("{\\bf R}")#text("-linear map ")#mi("DF(x_0,y_0):{\\bf R}^2\\to{\\bf R}^2")#text(" in notion (III).")

#text("So the map ")#mi("Df(z_0)\\in{\\bf C}^2")#text(" is a ")#mi("{\\bf C}")#text("-linear map from ")#mi("{\\bf C}")#text(" to ")#mi("{\\bf C}^2")#text(", not ")#mi("{\\bf C}^2")#text(" to ")#mi("{\\bf C}^2")#text(". The ")#mi("{\\bf R}")#text(" dimensions then match in the two notions.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-594801")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2020")])]

#text("Maybe it is better to mention that the Fréchet differentiable defined in part two is the real Fréchet differentiable which is a generalization real differentiable so it is weaker than complex differentiable. Nevertheless the complex Fréchet differentiability of a function from ")#mi("\\mathbb{C}")#text(" to ")#mi("\\mathbb{C}")#text(" is exactly the complex differentiability in Definition 2 and same for the derivative because complex Fréchet derivative is a generalization of complex derivative.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-595024")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("Can one adapt the proof of Theorem 25 to show the strong version of the maximum principle?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-595028")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("Hmm, with a fair amount of additional effort, yes, but I don’t know of a proof of comparable length to this one. (At a bare minimum, one now has to use the fact that the domain is connected.) If one has an additional tool such as the mean value theorem or Harnack’s inequality then it is straightforward, but the “first principles” proofs I am aware of are somewhat lengthy.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-595562")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2020")])]

#text("I am confused by the statement ")#mi("f(x+iy)=\\frac{xy}{x^2+y^2}")#text(" has partial derivatives ")#mi("\\frac{\\partial f}{\\partial x}")#text(" and ")#mi("\\frac{\\partial f}{\\partial y}")#text(" exist at f(0). Aren’t they both 0/0?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-595606")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2020")])]

#text("No; try computing the partial derivatives from first principles.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-595616")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2020")])]

#text("Thank you! Now that makes sense. Why do the two processes give different results?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-595629")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2020")])]

#text("Because partial derivatives need not be the same.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of max_principle")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-595697")[#strong[#text("max_principle")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2020")])]

#text("In the proof of maximum principle, we have , clearly ")#mi("sup_{z \\in k}(z) \\geq sup_{z \\in \\partial k} u(z)")#text(".why?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-595843")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2020")])]

#text("K is compact, so attains its sup (either in interior of K or on boundary of K). Think of it as a generalization of Bolzano–Weierstrass theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-595865")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2020")])]

#text("Simply because ")#mi("\\partial K")#text(" is a ")#emph[#text("subset")]#text(" of ")#mi("K")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-596228")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2020")])]

#text("In the proof of Theorem 15, as ")#mi("z \\to z_{1}")#text(", you said each summand converges to ")#mi("na_{n}(z-z_{0})^{n-1}")#text(". Where does the ")#mi("n")#text(" come from? I thought it is just ")#mi("a_{n}(z-z_{0})^{n-1}")#text(".")

#emph[#text("[Here the summand refers to the summand of the series ")#mi("\\sum_{n=1}^\\infty")#text(". (The summand is itself a sum of ")#mi("n")#text(" sub-summands, each of which converge individually to ")#mi("a_n (z-z_0)^{n-1}")#text(".) -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-598490")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2020")])]

#text("In the proof Proposition 28,")

#emph[#linebreak()#text(" … The fact that ")#mi("{u}")#text(" is continuously twice differentiable allows one to differentiate under the integral sign (exercise!) and conclude that")#linebreak()#text(" ")#mi("\\displaystyle \\frac{\\partial v}{\\partial x}(x+iy) := - \\frac{\\partial u}{\\partial y}(x) + \\int_0^y \\frac{\\partial^2 u}{\\partial x^2}(x+it)\\ dt.")#linebreak()#text(" ")]

#text("I think here “")#mi(":=")#text("” should be “")#mi("=")#text("” since one is not defining the partial derivative on the left but concluding it from (18).")

#emph[#text("[Corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-610023")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2020")])]

#text("The Newton quotient is also used in the proof of Theorem 27 and 30 (the two fundamental theorems of calculus) in Notes 2. Instead of proving from the first principle as in this set of notes, can one somehow use the FTCs to show Theorem 15 in a non-circular way? (It seems that Theorem 15 has been used in various places in later notes.)")

#emph[#text("[Yes, this is possible, and I encourage you to work out this as an exercise -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-610028")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2020")])]

#emph[#linebreak()#text(" As ")#mi("{z}")#text(" approaches ")#mi("{z_1}")#text(", each summand … converges to ")#mi("{n a_n (z-z_0)^{n-1}}")#text(".")#linebreak()#text(" ")]#linebreak()#text(" should be")#linebreak()#text(" … converges to ")#mi("{n a_n (z_1-z_0)^{n-1}}")#text("?")

#emph[#linebreak()#text(" This almost proves the desired limiting formula")#linebreak()#text(" ")#mi("\\displaystyle \\lim_{z \\rightarrow z_1: z \\in D(z_0,R) \\backslash \\{z_1\\}} \\frac{F(z)-F(z_1)}{z-z_1} = \\sum_{n=1}^\\infty n a_n (z-z_0)^{n-1},")#linebreak()#text(" but we need to justify the interchange of a sum and limit.")#linebreak()#text(" ")]

#text("The right-hand side should be ")#mi("\\sum_{n=1}^\\infty n a_n (z_1-z_0)^{n-1}")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 2: Some connections with the Fourier transform | What's new")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-620194")[#strong[#text("246B, Notes 2: Some connections with the Fourier transform | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2021")])]

#text("[…] maximum modulus principle (Exercise 26 from 246A Notes 1) for holomorphic functions asserts that if a function continuous on a compact subset of the plane […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246A, Notes 0: the complex numbers | What's new")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-634687")[#strong[#text("246A, Notes 0: the complex numbers | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2021")])]

#text("[…] Next set of notes: Notes 1. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246A, Notes 2: complex integration | What's new")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-634690")[#strong[#text("246A, Notes 2: complex integration | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2021")])]

#text("[…] set of notes: Notes 1. Next set of notes: Notes […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9282a509941731102f6869f9f985d754dbe20aa8f864b1d84709eeb0977dd9c-9751713200e5044d48b898db0f9a0e38aaf4a5bf070669874dad533eb60a9290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kirtanvora")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-639292")[#strong[#text("kirtanvora")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2022")])]

#text("There’s a typo in a paragraph after exercise 17, 2^{n-1} should be 2^{n+1}")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-671012")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2022")])]

#text("By Exercise 17, given a sequence ")#mi("(a_n)")#text(", if ")#mi("G(z)=\\sum_{n=0}^\\infty \\frac{a_n}{n!}(z-z_0)^n")#text(" is a power series with a positive radius of convergence, then ")#mi("G^{(n)}(z_0)=a_n")#text(" for all ")#mi("n")#text(". If the mentioned power series fails to have a positive radius of convergence, can one still construct a smooth function ")#mi("G")#text(" with ")#mi("G^{(n)}(z_0)=a_n")#text(" for all ")#mi("n")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-671247")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2022")])]

#text("For real-variable functions, this is the zero-dimensional case of ")#link("https://en.wikipedia.org/wiki/Borel%27s_lemma")[#text("Borel’s lemma")]#text(". For complex-variable functions, it hinges on what you mean by “smooth”. Functions that are complex differentiable in a neighbourhood of ")#mi("z_0")#text(" are analytic and so the Taylor series has to have a positive radius of convergence.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/#comment-671109")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2022")])]

#text("Some part of the formula is missing in (7)")#linebreak()#text(" ")#mi("\\displaystyle \\lim_{(h_1,h_2) \\rightarrow 0: (h_1,h_2) \\in {\\bf R}^2 \\backslash \\{0\\}} \\ \\ \\ \\ \\ (7)")#linebreak()#text(" ")#tao-math("\\displaystyle \\frac{|f((x_0+h_1)+i(y_0+h_2)) - f(x_0+iy_0)}{\\left|(h_1,h_2)\\right|}-", block: false)#linebreak()#text(" ")#tao-math("\\displaystyle \\frac{ h_1 D_1f(z_0) + h_2 D_2f(z_0)|}{\\left|(h_1,h_2)\\right|} = 0", block: false)

#emph[#text("[Changed ")#mi("x_0+iy_0")#text(" to ")#mi("z_0")#text(" -T.]")]
]
