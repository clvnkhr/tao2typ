// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/
// Converted to Typst by tao2typ: "2026-10-14T15:20:57.343828+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On a conjecture of Marton", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On a conjecture of Marton")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 November 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/")[#text("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://www.dpmms.cam.ac.uk/~wtg10/")[#text("Tim Gowers")]#text(", ")#link("https://people.maths.ox.ac.uk/greenbj/")[#text("Ben Green")]#text(", ")#link("https://mathweb.ucsd.edu/~fmanners/")[#text("Freddie Manners")]#text(", and I have just uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/2311.05762")[#text("On a conjecture of Marton")]#text("“. This paper establishes a version of the notorious ")#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/")[#text("Polynomial Freiman–Ruzsa conjecture")]#text(" (first proposed by Katalin Marton):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Polynomial Freiman–Ruzsa conjecture)")]#text(" Let ")#mi("{A \\subset {\\bf F}_2^n}")#text(" be such that ")#tao-math("{\\left|A+A\\right| \\leq K\\left|A\\right|}", block: false)#text(". Then ")#mi("{A}")#text(" can be covered by at most ")#mi("{2K^{12}}")#text(" translates of a subspace ")#mi("{H}")#text(" of ")#mi("{{\\bf F}_2^n}")#text(" of cardinality at most ")#mi("{A}")#text(".")
]

#text("The previous best known result towards this conjecture was by Konyagin (as communicated in ")#link("https://zbmath.org/1337.11014")[#text("this paper of Sanders")]#text("), who obtained a similar result but with ")#mi("{2K^{12}}")#text(" replaced by ")#mi("{\\exp(O_\\varepsilon(\\log^{3+\\varepsilon} K))}")#text(" for any ")#mi("{\\varepsilon>0}")#text(" (assuming that say ")#mi("{K \\geq 3/2}")#text(" to avoid some degeneracies as ")#mi("{K}")#text(" approaches ")#mi("{1}")#text(", which is not the difficult case of the conjecture). The conjecture (with ")#mi("{12}")#text(" replaced by an unspecified constant ")#mi("{C}")#text(") has a number of equivalent forms; see this ")#link("https://zbmath.org/1155.11306")[#text("survey of Green")]#text(", and these papers ")#link("https://zbmath.org/1274.11158")[#text("of Lovett")]#text(" and ")#link("https://zbmath.org/1229.11132")[#text("of Green and myself")]#text(" for some examples; in particular, as discussed in the latter two references, the constants in the inverse ")#mi("{U^3({\\bf F}_2^n)}")#text(" theorem are now polynomial in nature (although we did not try to optimize the constant).")

#text("The exponent ")#mi("{12}")#text(" here was the product of a large number of optimizations to the argument (our original exponent here was closer to ")#mi("{1000}")#text("), but can be improved even further with additional effort (our current argument, for instance, allows one to replace it with ")#mi("{7+\\sqrt{17} = 11.123\\dots}")#text(", but we decided to state our result using integer exponents instead).")

#text("In this paper we will focus exclusively on the characteristic ")#mi("{2}")#text(" case (so we will be cavalier in identifying addition and subtraction), but in a followup paper we will establish similar results in other finite characteristics.")

#text("Much of the prior progress on this sort of result has proceeded via Fourier analysis. Perhaps surprisingly, our approach uses no Fourier analysis whatsoever, being conducted instead entirely in “physical space”. Broadly speaking, it follows a natural strategy, which is to induct on the doubling constant ")#tao-math("{\\left|A+A\\right|/\\left|A\\right|}", block: false)#text(". Indeed, suppose for instance that one could show that every set ")#mi("{A}")#text(" of doubling constant ")#mi("{K}")#text(" was “commensurate” in some sense to a set ")#mi("{A^{\\prime}}")#text(" of doubling constant at most ")#mi("{K^{0.99}}")#text(". One measure of commensurability, for instance, might be the ")#emph[#text("Ruzsa distance")]#text(" ")#tao-math("{\\log \\frac{\\left|A+A^{\\prime}\\right|}{\\left|A\\right|^{1/2} \\left|A^{\\prime}\\right|^{1/2}}}", block: false)#text(", which one might hope to control by ")#mi("{O(\\log K)}")#text(". Then one could iterate this procedure until doubling constant dropped below say ")#mi("{3/2}")#text(", at which point the conjecture is known to hold (there is an elementary argument that if ")#mi("{A}")#text(" has doubling constant less than ")#mi("{3/2}")#text(", then ")#mi("{A+A}")#text(" is in fact a subspace of ")#mi("{{\\bf F}_2^n}")#text("). One can then use several applications of the ")#emph[#text("Ruzsa triangle inequality")]

#align(center)[#tao-fit-display[#tao-math("\\log \\frac{\\left|A+C\\right|}{\\left|A\\right|^{1/2} \\left|C\\right|^{1/2}} \\leq \\log \\frac{\\left|A+B\\right|}{\\left|A\\right|^{1/2} \\left|B\\right|^{1/2}} + \\log \\frac{\\left|B+C\\right|}{\\left|B\\right|^{1/2} \\left|C\\right|^{1/2}}", block: true)]]

#text("to conclude (the fact that we reduce ")#mi("{K}")#text(" to ")#mi("{K^{0.99}}")#text(" means that the various Ruzsa distances that need to be summed are controlled by a convergent geometric series).")

#text("There are a number of possible ways to try to “improve” a set ")#mi("{A}")#text(" of not too large doubling by replacing it with a commensurate set of better doubling. We note two particular potential improvements:")

#list(
[#text("(i) Replacing ")#mi("{A}")#text(" with ")#mi("{A+A}")#text(". For instance, if ")#mi("{A}")#text(" was a random subset (of density ")#mi("{1/K}")#text(") of a large subspace ")#mi("{H}")#text(" of ")#mi("{{\\bf F}_2^n}")#text(", then replacing ")#mi("{A}")#text(" with ")#mi("{A+A}")#text(" usually drops the doubling constant from ")#mi("{K}")#text(" down to nearly ")#mi("{1}")#text(" (under reasonable choices of parameters).")],
[#text("(ii) Replacing ")#mi("{A}")#text(" with ")#mi("{A \\cap (A+h)}")#text(" for a “typical” ")#mi("{h \\in A+A}")#text(". For instance, if ")#mi("{A}")#text(" was the union of ")#mi("{K}")#text(" random cosets of a subspace ")#mi("{H}")#text(" of large codimension, then replacing ")#mi("{A}")#text(" with ")#mi("{A \\cap (A+h)}")#text(" again usually drops the doubling constant from ")#mi("{K}")#text(" down to nearly ")#mi("{1}")#text(".")]
)

#text("Unfortunately, there are sets ")#mi("{A}")#text(" where neither of the above two operations (i), (ii) significantly improves the doubling constant. For instance, if ")#mi("{A}")#text(" is a random density ")#mi("{1/\\sqrt{K}}")#text(" subset of ")#mi("{\\sqrt{K}}")#text(" random translates of a medium-sized subspace ")#mi("{H}")#text(", one can check that the doubling constant stays close to ")#mi("{K}")#text(" if one applies either operation (i) or operation (ii). But in this case these operations don’t actually worsen the doubling constant much either, and by applying some combination of (i) and (ii) (either intersecting ")#mi("{A+A}")#text(" with a translate, or taking a sumset of ")#mi("{A \\cap (A+h)}")#text(" with itself) one can start lowering the doubling constant again.")

#text("This begins to suggest a potential strategy: show that at least one of the operations (i) or (ii) will improve the doubling constant, or at least not worsen it too much; and in the latter case, perform some more complicated operation to locate the desired doubling constant improvement.")

#text("A sign that this strategy might have a chance of working is provided by the following heuristic argument. If ")#mi("{A}")#text(" has doubling constant ")#mi("{K}")#text(", then the Cartesian product ")#mi("{A \\times A}")#text(" has doubling constant ")#mi("{K^2}")#text(". On the other hand, by using the projection map ")#mi("{\\pi: {\\bf F}_2^n \\times {\\bf F}_2^n \\rightarrow {\\bf F}_2^n}")#text(" defined by ")#mi("{\\pi(x,y) := x+y}")#text(", we see that ")#mi("{A \\times A}")#text(" projects to ")#mi("{\\pi(A \\times A) = A+A}")#text(", with fibres ")#mi("{\\pi^{-1}(\\{h\\})}")#text(" being essentially a copy of ")#mi("{A \\cap (A+h)}")#text(". So, morally, ")#mi("{A \\times A}")#text(" also behaves like a “skew product” of ")#mi("{A+A}")#text(" and the fibres ")#mi("{A \\cap (A+h)}")#text(", which suggests (non-rigorously) that the doubling constant ")#mi("{K^2}")#text(" of ")#mi("{A \\times A}")#text(" is also something like the doubling constant of ")#mi("{A + A}")#text(", times the doubling constant of a typical fibre ")#mi("{A \\cap (A+h)}")#text(". This would imply that at least one of ")#mi("{A +A}")#text(" and ")#mi("{A \\cap (A+h)}")#text(" would have doubling constant at most ")#mi("{K}")#text(", and thus that at least one of operations (i), (ii) would not worsen the doubling constant.")

#text("Unfortunately, this argument does not seem to be easily made rigorous using the traditional doubling constant; even the significantly weaker statement that ")#mi("{A+A}")#text(" has doubling constant at most ")#mi("{K^2}")#text(" is false (see comments for more discussion). However, it turns out (as discussed in ")#link("https://terrytao.wordpress.com/2023/06/27/sumsets-and-entropy-revisited/")[#text("this recent paper of myself with Green and Manners")]#text(") that things are much better. Here, the analogue of a subset ")#mi("{A}")#text(" in ")#mi("{{\\bf F}_2^n}")#text(" is a random variable ")#mi("{X}")#text(" taking values in ")#mi("{{\\bf F}_2^n}")#text(", and the analogue of the (logarithmic) doubling constant ")#tao-math("{\\log \\frac{\\left|A+A\\right|}{\\left|A\\right|}}", block: false)#text(" is the entropic doubling constant ")#mi("{d(X;X) := {\\bf H}(X_1+X_2)-{\\bf H}(X)}")#text(", where ")#mi("{X_1,X_2}")#text(" are independent copies of ")#mi("{X}")#text(". If ")#mi("{X}")#text(" is a random variable in some additive group ")#mi("{G}")#text(" and ")#mi("{\\pi: G \\rightarrow H}")#text(" is a homomorphism, one then has what we call the ")#emph[#text("fibring inequality")]

#align(center)[#tao-fit-display[#mitex("d(X;X) \\geq d(\\pi(X);\\pi(X)) + d(X|\\pi(X); X|\\pi(X)),")]]

#text("where the conditional doubling constant ")#mi("{d(X|\\pi(X); X|\\pi(X))}")#text(" is defined as")

#align(center)[#tao-fit-display[#mitex("d(X|\\pi(X); X|\\pi(X)) = {\\bf H}(X_1 + X_2 | \\pi(X_1), \\pi(X_2)) - {\\bf H}( X | \\pi(X) ).")]]

#text("Indeed, from the chain rule for Shannon entropy one has")

#align(center)[#tao-fit-display[#mitex("{\\bf H}(X) = {\\bf H}(\\pi(X)) + {\\bf H}(X|\\pi(X))")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("{\\bf H}(X_1+X_2) = {\\bf H}(\\pi(X_1) + \\pi(X_2)) + {\\bf H}(X_1 + X_2|\\pi(X_1) + \\pi(X_2))")]]

#text("while from the non-negativity of conditional mutual information one has")

#align(center)[#tao-fit-display[#mitex("{\\bf H}(X_1 + X_2|\\pi(X_1) + \\pi(X_2)) \\geq {\\bf H}(X_1 + X_2|\\pi(X_1), \\pi(X_2))")]]

#text("and it is an easy matter to combine all these identities and inequalities to obtain the claim.")

#text("Applying this inequality with ")#mi("{X}")#text(" replaced by two independent copies ")#mi("{(X_1,X_2)}")#text(" of itself, and using the addition map ")#mi("{(x,y) \\mapsto x+y}")#text(" for ")#mi("{\\pi}")#text(", we obtain in particular that")

#align(center)[#tao-fit-display[#mitex("2 d(X;X) \\geq d(X_1+X_2; X_1+X_2) + d(X_1,X_2|X_1+X_2; X_1,X_2|X_1+X_2)")]]

#text("or (since ")#mi("{X_2}")#text(" is determined by ")#mi("{X_1}")#text(" once one fixes ")#mi("{X_1+X_2}")#text(")")

#align(center)[#tao-fit-display[#mitex("2 d(X;X) \\geq d(X_1+X_2; X_1+X_2) + d(X_1|X_1+X_2; X_1|X_1+X_2).")]]

#text("So if ")#mi("{d(X;X) = \\log K}")#text(", then at least one of ")#mi("{d(X_1+X_2; X_1+X_2)}")#text(" or ")#mi("{d(X_1|X_1+X_2; X_1|X_1+X_2)}")#text(" will be less than or equal to ")#mi("{\\log K}")#text(". This is the entropy analogue of at least one of (i) or (ii) improving, or at least not degrading the doubling constant, although there are some minor technicalities involving how one deals with the conditioning to ")#mi("{X_1+X_2}")#text(" in the second term ")#mi("{d(X_1|X_1+X_2; X_1|X_1+X_2)}")#text(" that we will gloss over here (one can pigeonhole the instances of ")#mi("{X_1}")#text(" to different events ")#mi("{X_1+X_2=x}")#text(", ")#mi("{X_1+X_2=x^{\\prime}}")#text(", and “depolarise” the induction hypothesis to deal with distances ")#mi("{d(X;Y)}")#text(" between pairs of random variables ")#mi("{X,Y}")#text(" that do not necessarily have the same distribution). Furthermore, we can even calculate the defect in the above inequality: a careful inspection of the above argument eventually reveals that")

#tao-aligned(keep: true)[


#tao-math("2 d(X;X)  & = d(X_1+X_2; X_1+X_2) + d(X_1|X_1+X_2; X_1|X_1+X_2)", block: true)



#tao-math(" & + {\\bf I}( X_1 + X_2 : X_1 + X_3 | X_1 + X_2 + X_3 + X_4)", block: true)
]

#text("where we now take four independent copies ")#mi("{X_1,X_2,X_3,X_4}")#text(". This leads (modulo some technicalities) to the following interesting conclusion: if neither (i) nor (ii) leads to an improvement in the entropic doubling constant, then ")#mi("{X_1+X_2}")#text(" and ")#mi("{X_2+X_3}")#text(" are conditionally independent relative to ")#mi("{X_1+X_2+X_3+X_4}")#text(". This situation (or an approximation to this situation) is what we refer to in the paper as the “endgame”.")

#text("A version of this endgame conclusion is in fact valid in any characteristic. But in characteristic ")#mi("{2}")#text(", we can take advantage of the identity")

#align(center)[#tao-fit-display[#mitex("(X_1+X_2) + (X_2+X_3) = X_1 + X_3.")]]

#text("Conditioning on ")#mi("{X_1+X_2+X_3+X_4}")#text(", and using symmetry we now conclude that if we are in the endgame exactly (so that the mutual information is zero), then the independent sum of two copies of ")#mi("{(X_1+X_2|X_1+X_2+X_3+X_4)}")#text(" has exactly the same distribution; in particular, the entropic doubling constant here is zero, which is certainly a reduction in the doubling constant.")

#text("To deal with the situation where the conditional mutual information is small but not completely zero, we have to use an entropic version of the Balog-Szemeredi-Gowers lemma, but fortunately this was already worked out in an ")#link("https://zbmath.org/1239.11015")[#text("old paper of mine")]#text(" (although in order to optimise the final constant, we ended up using a slight variant of that lemma).")

#text("I am planning to formalize this paper in the ")#link("https://leanprover-community.github.io/index.html")[#text("Lean4 language")]#text(". Further discussion of this project will take place on ")#link("https://leanprover.zulipchat.com/#narrow/stream/412902-Polynomial-Freiman-Ruzsa-conjecture")[#text("this Zulip stream")]#text(", and the project itself will be held at ")#link("https://github.com/teorth/pfr")[#text("this Github repository.")]

#heading(level: 1)[#text("Comments (35)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682243")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2023")])]

#text("Congrats on the result. The argument was a nice read.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682244")[#strong[#text("Ruzsa distance and Ruzsa entropy warmup")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2023")]

#text("[…] That earlier post would make a good warmup for reading Terence Tao’s latest post On a conjecture of Martin. […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f484d77d438d13f931857ce7d7696d009bea9a7dd8452d902e7fe9addb6682e-3b3756c5a5d35ab8a438f3170bfe9d4e660aadf7eb6d0d778b3cfa9c5db8787c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mmshvartsman")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682293")[#strong[#text("mmshvartsman")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2023")])]

#text("Why 3 opinions negative??")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682246")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2023")])]

#text("Great read! Very excited to see that this will be formalised in Lean.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682247")[#strong[#text("Marton’s “Polynomial Freiman-Ruzsa” Conjecture was Settled by the A-Team. | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2023")]

#text("[…] A subsequent paper of the same team will contain a proof for odd characteristics. (As far as I understand the conjecture over the integers remains a challenge.) Update: For more background and for some ideas of the proof see this post in Terry Tao’s blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682249")[#strong[#text("Ruzsa distance and Ruzsa entropy warmup - SoatDev IT Consulting")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2023")]

#text("[…] That earlier post would make a good warmup for reading Terence Tao’s latest post On a conjecture of Martin. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682253")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2023")])]

#text("Congratulations on the remarkable result!")

#text("I’m curious what is known about lower bounds on the exponent in Theorem 1.1? In the other direction, given that you say the argument reflects a large number of optimizations, can the argument be substantially simplified if one doesn’t care about the exponent?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682257")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2023")])]

#text("I actually know very little about lower bounds; maybe someone else knows if there is literature on this. For the entropic version, the “standard” examples of random dense subsets or random dissociated sets show that C=11 cannot be less than 1. By taking n=1 and optimizing the distributions you can do a bit better — by my arithmetic you cannot improve C=11 to better than something like 2.34, using P[X_1=0] = P[X_2=0] = 0.89 or so. Presumably a computer search for n>1 could do better, though I have no reason to think the truth is close to our current constant.")

#text("Re the optimizations: for the most part they don’t make the argument significantly harder — it’s often a question of just not using wasteful bounds. For instance, when we see terms such as H[X_1]-H[X_2], we can bound this immediately by 2 d[X_1,X_2] — or more efficiently, we can try to cancel it with an H[X_2]-H[X_1] elsewhere.")

#text("It is probably a bit easier to see why the argument *deserves to work* by first trying to show something much cruder: for instance, show that given X_1,X_2 with d[X_1,X_2]=k, you can find X_1′, X_2′ such that d[X_1′, X_2′] <= 0.99 k and d[X_1,X_1'] + d[X_2, X_2'] <= 10000 k. The key steps are essentially the same, but you might get a clearer impression of which bounds are truly important, and which only matter for optimization. In particular, many quantities can be put in a bucket called \"can be shown to be O(k) by some sequence of 'Ruzsa calculus' inequalities\", and if you are willing to take such inequalities on trust, many estimates can be skipped.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682270")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2023")])]

#text("I could imagine that one could work out the optimal constant for the 99% version of Theorem 1.2 could be evaluated exactly. That is, if ")#mi("d[X;X] \\leq \\varepsilon")#text(" for small $\\varepsilon$, find the best constant ")#mi("C")#text(" for which we have ")#mi("d[X;U_H] \\leq C\\varepsilon")#text(" for some subgroup ")#mi("H")#text(". We get ")#mi("C=11/2")#text(" (in our previous paper we had ")#mi("C=12")#text("), but in this perturbative situation where ")#mi("X")#text(" is so close to ")#mi("U_H")#text(" already it should be possible to get very precise information, for instance by using the fibring identity to quotient out ")#mi("H")#text(" and using various perturbative analyses to discard anything that contributes ")#mi("o(\\varepsilon)")#text(" to the Ruzsa distance. (One obstacle perhaps is that an efficient 99% version of the entropic Balog-Szemeredi-Gowers lemma may be needed; we still lose a constant of 5 or so over the best lower bounds.) A tentative conjecture could then be that the asymptotic constant is actually the global constant for this inequality.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682268")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2023")])]

#text("Actually we lucked out somewhat in that the optimizations mostly either kept the length of proof about the same, or increased it very slightly, or in some cases actually decreased the length of the argument (though perhaps that the expense of conceptual clarity). For instance we found it shorter and more quantitatively optimal to run a “show that the minimizer of this functional is well-behaved” type argument, rather than the contrapositive “either there is some way to decrease the functional, or good things happen” style of argument that is more common in additive combinatorics. There are some quantities that we take three or four lines to bound that we could bound in one line with a worse constant (mostly by appealing to off-the-shelf “Ruzsa calculus” inequalities such as the Ruzsa triangle inequality) but they don’t really simplify the global flow of the proof (all the versions of the argument we have involve starting with the fibring identity, analyzing when that doesn’t lead to an immediate win, and then performing an endgame).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682276")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2023")])]

#text("Thanks Terry (and the anonymous co-author) for the thoughtful reply.")

#text("The question in your heuristic summary above is a bit curious. I think you’re asking if |A+A| <= k|A| implies |4A| <= k^2 |2A|. If true, this would imply |4A| <=k^3|A|, which would be an improvement on Plünnecke–Ruzsa which gives that |4A| <=k^4|A|. I have always been under the impression that these sorts of Plünnecke–Ruzsa inequalities are sharp, however maybe that isn't so? In fact it isn't even immediately clear to me that |4A| <= k^{1.99} |2A| is false. This seems tangential to the entropic approach, but curious if you have sorted any of this out?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682277")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2023")])]

#text("As far as I know, the optimal constants for pretty much all of the “Ruzsa calculus” inequalities remain undetermined; the best upper bounds and the best counterexamples usually do not have matching exponents. There were several papers by Ruzsa and others devoted to this topic over the years, but I do not know what the current state of the art is. Plunnecke’s inequality is sharp in some formulations, but not in the one regarding bounding the quadrupling constant by the doubling constant.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682283")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2023")])]

#text("such inequalities are sharp, up to multiplicative constants. this is just a minor generalization or Theorem 9.5 from some notes of Ruzsa (which Terry mentioned here a while ago: ")#link("https://mathoverflow.net/questions/284398/optimality-of-the-plünnecke-ruzsa-inequality")[#text("https://mathoverflow.net/questions/284398/optimality-of-the-plünnecke-ruzsa-inequality")]#text(").")

#text("the construction (for fourth sums) is: take ")#mi("A \\subset \\mathbb{Z}^4")#text(" to be the union of ")#mi("4")#text(" lines each of length ")#mi("l:=Kn^{1/4}")#text(" (aligned along different axes) and a box with side lengths ")#mi("k:= n^{1/4}")#text(". we have that ")#tao-math("\\left|A\\right|\\approx 4l+k^4\\approx n", block: false)#text(", ")#tao-math("\\left|A+A\\right| \\approx 4l^2+4lk^3\\approx 4Kn", block: false)#text(" and ")#tao-math("\\left|4A\\right| \\approx l^4=K^4n", block: false)#text(".")

#text("for higher iterated sums you essentially do the same. -ZH")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682291")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2023")])]

#text("Ha, I had forgotten that I had already looked into this question when writing the book with Van in 2006 (and when answering that MathOverflow question from 2017)! I’ll update the discussion in the blog post accordingly.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682255")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2023")])]

#text("Very very nice!")

#text("Do you think that this could have some links to the Katznelson conjecture?")

#text("This states that if (F_2)^n is partitioned into K sets A_1,…,A_K, then the union of all of the A_i+A_i contains a codimension O_K(1) subspace. So, if you have a Cayley graph over the Boolean hypercube with chromatic number at most K, then it has a codimension O_K(1) subspace which is independent (one can take the complement of the union of A_i+A_i to be the generating set).")

#text("I was wondering if some kind of techniques like this could be applied here. Probably the assumption that the A_i cover the cube could be weakened. If the A_i are all the same Niveau set then it’s false, but I suspect that this is the only obstacle in some sense. So you would move them around, and instead ask that the A_i cover 99% of a subspace or something. The A cap A+h is fine; translating an A_i doesn’t affect anything. But the A+A operation might be bad.")

#text("Still, I think it’s worth asking if you can do some set of operations to get some sort of reduction the way you do here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682267")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2023")])]

#text("I meant “the A_i cover 99% of ANY subspace”, of course if the A_i cover 99% of a single subspace they could be Niveau set translates.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682269")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2023")])]

#text("We’ve had trouble trying to adapt our methods to create subspaces inside sumsets (i.e., Bogulybov type theorems). It might be possible to create such spaces inside iterated sumsets (involving sums of ")#mi("\\log^{O(1)} K")#text(" or so copies of the sets involved) but that is weaker than what is needed for most applications including this one. My feeling is that we lucked out to some extent that a pure entropy method was able to handle PFR; for these other problems I imagine one would have to augment this method with some other method or idea.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-689593")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2026")])]

#text("The answer to Katznelson is likely negative which would explain the difficulty.")

#link("https://arxiv.org/abs/2511.21680")[#text("https://arxiv.org/abs/2511.21680")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682262")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2023")])]

#text("This is awesome. One of the top questions that I had wanted to see an answer to.")

#text("The paper states that there is a future paper that will resolve for F_p with odd characteristic? Does it also extend to other finite groups such as integers modulo a composite integer n?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ced3e9ca3ac3a4fbeaeabc78fa033428f6c52d4fc05409e4794cca44ef22915-4b1027730e02d9a8b7abbf37c1479c0807765e6c4c27325ed00f142e0bf7e916.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zach Hunter")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682264")[#strong[#text("Zach Hunter")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2023")])]

#text("I am fairly sure that it should also work for groups of bounded exponent. the reason is that there is a reasonable version of “the Endgame” which should be reachable (presumably, as I haven’t seen their exact definition of partite entropy). gun to my head, I bet one could bash out a proof of the bounded exponent case based off this paper within the next month. but I look forward to their presentation of the general argument.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682271")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2023")])]

#text("Good question! Our current argument does rely at one key point on the exponent being prime (and in fact on being odd – our more general argument doesn’t directly cover the ")#mi("p=2")#text(" case, though it only requires a slight modification here), but there are a lot of different things to try, and it is possible that by being a little more sophisticated one can handle composite exponents as well.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ced3e9ca3ac3a4fbeaeabc78fa033428f6c52d4fc05409e4794cca44ef22915-4b1027730e02d9a8b7abbf37c1479c0807765e6c4c27325ed00f142e0bf7e916.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zach Hunter")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682263")[#strong[#text("Zach Hunter")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2023")])]

#text("I will mention: an important implicit corollary of your argument is that if ")#tao-math("\\left|A+A\\right|\\le K\\left|A\\right|", block: false)#text(", then ")#mi("rA-rA")#text(" contains a subspace ")#mi("V")#text(" with ")#tao-math("\\left|V\\right|\\ge f(K)\\left|A\\right|", block: false)#text(" where ")#mi("f(K) \\gg K^{-O(1)}")#text(" with ")#mi("r = O(\\log^6(K))")#text(" (actually, using PFR as a blackbox, you can take ")#mi("r=O(log(K))")#text(" or a bit better, but you give a fully combinatorial argument). by a simple (but in my opinion, non-obvious) bootstrapping argument from my Master’s thesis, results of this form are closely related to finding subspaces inside ")#mi("2A-2A")#text(" (i.e., the usual Bogolyubov-Ruzsa-type results).")

#text("for example, if you could take ")#mi("r = O(\\log^{1/4-\\Omega(1)}(K))")#text(" (with the two implicit constants in ")#mi("f(K)")#text(" potentially changing), then this should imply some exponent improvement to the result Sanders, which has lasted ~15 years now. and presumably, for each ")#mi("c>0")#text(", we should be able to take ")#mi("r = O_c(\\log^c(K))")#text(" and get such a result (again letting the constants in ")#mi("f(K)")#text(" change wrt ")#mi("c")#text("). this would imply that ")#mi("2A-2A")#text(" contains subspaces ")#mi("V")#text(" with ")#tao-math("\\left|V\\right|\\gg_{\\epsilon} |A|\\exp(-O_{\\epsilon}(\\log^{2+\\epsilon}(K)))", block: false)#text(" for all ")#mi("\\epsilon>0")#text(".")

#text("as you mentioned, the argument presented on arXiv is optimized to minimize the exponent for PFR. if you are aware of older arguments, which allow you to reduce the number of steps you take where ")#mi("X_1^{\\prime},X_2^{\\prime}")#text(" is a “non-fibre step” (meaning that their supports are not contained in the supports of ")#mi("X_1,X_2")#text(", but rather their sumsets), do let me know! basically you want to say that ")#mi("d[X_1^{\\prime};X_2^{\\prime}] > ck")#text(" for all of the non-fibre steps from your paper, then there is some reweighting of the support where ")#mi("d[X_1^{\\prime};X_2^{\\prime}]<(1-\\delta_c)k")#text(" and ")#mi("d[X_1^{\\prime};X_1],d[X_2^{\\prime};X_2] \\ll_c k")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682272")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2023")])]

#text("I can certainly believe that our arguments can be combined with other combinatorial bootstrap arguments to give results like the ones you mentioned. Nice observation!")

#text("All of the previous (working) iterations of our argument use the same basic strategy: fibre, grab quick wins if possible, if not proceed to endgame. If one doesn’t write the argument in terms of optimizing our functional ")#mi("\\tau[X_1;X_2]")#text(" but instead proceeds by a more traditional “if this happens, then we get this win; otherwise we do this to get another type of win” type of “distance decrement” argument then I can certainly imagine by tweaking the weights to favor one sort of win over another one can do better, though we found that our constants tended to degrade when writing the argument in such a form.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Formalizing the proof of PFR in Lean4 using Blueprint: a short tour | What's new")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682292")[#strong[#text("Formalizing the proof of PFR in Lean4 using Blueprint: a short tour | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2023")])]

#text("[…] the release of my preprint with Tim, Ben, and Freddie proving the Polynomial Freiman-Ruzsa (PFR) conjecture over , I have started a collaborative project […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/897eee87301797018b497f9b53891d73b5518d6ba8dce28b07f1d1bd545b57ae-eab771cd6573a24c605b4d57692803de5c8eff25bfcfbc94ebaceec24023ccb8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jyun-Jie Liao")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682353")[#strong[#text("Jyun-Jie Liao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2023")])]

#text("Congratulations on the amazing result! The proof is so elegant!")

#text("By the way, I tried the calculation a bit and I think the exponent can be improved to exactly 11 (if I didn’t do anything wrong). In the endgame, the choice of ")#mi("X_1^{\\prime},X_2^{\\prime}")#text(" is ")#mi("A,B")#text(" conditioned on ")#mi("C,S")#text(", for ")#mi("(A,B,C)")#text(" being a permutation of ")#mi("(U,V,W)")#text(", and I think the bound for ")#mi("d[X_1^0; X_1^{\\prime}]+d[X_2^0;X_2^{\\prime}]")#text(" can be improved a little bits by the following argument.")#linebreak()#text(" First of all, Lemma 5.2 shows that")

#mi("\\displaystyle d[X_1^0; A_1+A_2]+d[X_2^0; A_1+A_2]\\le d[X_1^0; A_1]")#linebreak()#text(" ")#mi("\\displaystyle +d[X_2^0; A_2]+d[A_1;A_2],")

#text("so by taking ")#mi("A_1=X_1|V")#text(" and ")#mi("A_2=X_2|S-V")#text(" we get that")

#mi("\\displaystyle d[X_1^0; U | V,S]+d[X_2^0; U | V,S]\\le d[X_1^0; X_1| V]")#linebreak()#text(" ")#mi("\\displaystyle + d[X_2^0; X_2 | S-V] + d[X_1|V ; X_2|S-V].")

#text("On the other hand, by Lemma 5.1 we have")

#mi("\\displaystyle d[X_1^0; U| V,S] + d[X_2^0; U|V,S]\\le d[X_1^0; U| S] + d[X_2^0; U| S]")#linebreak()#text(" ")#mi("\\displaystyle + I(U:V|S).")

#text("And another formula in Lemma 5.2 shows that")

#mi("\\displaystyle d[X_1^0; A_1 | A_1+A_2]+d[X_2^0; A_2 | A_1+A_2]\\le d[X_1^0; A_1]")#linebreak()#text(" ")#mi("\\displaystyle +d[X_2^0; A_2]+d[A_1;A_2],")

#text("so by taking ")#mi("A_1=U,A_2=S-U")#text(" we get")

#mi("\\displaystyle d[X_1^0; U| V,S] + d[X_2^0; U|V,S] \\le d[X_1^0; U] + d[X_2^0; S-U]")#linebreak()#text(" ")#mi("\\displaystyle +d[U;S-U]+I(U:V|S).")

#text("Then apply similar arguments for all 6 choices of ordered pairs in {U,V,W}, and take the average of all the inequalities. The LHS is exactly the average of ")#mi("d[X_1^0; X_1^{\\prime}]+d[X_2^0;X_2]")#text(". For the RHS, first observe that the terms without ")#mi("X_1^0")#text(" and ")#mi("X_2^0")#text(" is exactly ")#mi("k+(I_2-I_1)/6")#text(" by Corollary 4.2. For the terms involving ")#mi("X_1^0")#text(" and ")#mi("X_2^0")#text(", it has been shown in Section 5 and Section 6 that their sum is bounded by")

#mi("\\displaystyle d[X_1^0;X_1]+d[X_2^0;X_2]+k+(I_2-I_1)/6.")

#text("(Here we use the fact that ")#mi("I_2-I_1=d[X_1;X_1]+d[X_2;X_2]-2k")#text(" to simplify the notation a bit.)")#linebreak()#text(" Therefore the average of ")#mi("d[X_1^0; X_1^{\\prime}]+d[X_2^0;X_2^{\\prime}] -d[X_1^0;X_1]-d[X_2^0;X_2]")#text(" is at most ")#mi("2k+(I_2-I_1)/3")#text(". The maximum of the upperbound for ")#mi("\\psi[X_1^{\\prime};X_2^{\\prime}]")#text(" again occurs at ")#mi("I_1=2\\eta k")#text(" and is ")#mi("8\\eta k")#text(", so taking any ")#mi("\\eta<1/8")#text(" suffices.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682382")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2023")])]

#text("Very nice! It is great that one can use the fibring identity one last time to squeeze an additional gain in the constants.")

#text("I talked with my coauthors and we would like to include this improvement as an appendix to the paper, with acknowledgment to you of course for providing the argument. Would you be agreeable to that?")

#text("On a separate note, we have wondered if it may be amenable to use computer-assisted methods to try to optimize the constant here; the idea would be to write down a large number of entropic quantities and use the Shannon entropy inequalities (and all of their consequences) to generate a huge list of linear inequalities between them, at which point the problem is “just” a linear programming optimization. However, some thought would need to go into avoiding the combinatorial explosion (and in focusing on “useful” inequalities rather than “true, but too weak for applications” inequalities). Making some symmetry assumptions during the search (e.g., that ")#mi("X_1 \\equiv X_2")#text(") may cut down on the complexity somewhat. A related task would be to try to optimize the constants in the entropic Balog-Szemeredi-Gowers inequality.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/897eee87301797018b497f9b53891d73b5518d6ba8dce28b07f1d1bd545b57ae-eab771cd6573a24c605b4d57692803de5c8eff25bfcfbc94ebaceec24023ccb8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jyun-Jie Liao")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682387")[#strong[#text("Jyun-Jie Liao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2023")])]

#text("Of course, it’s my pleasure!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682424")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2023")])]

#text("Does the proof indicate a way to think about constructing H (the covering subgroup)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682600")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2023")])]

#text("“this paper of Sanders” has no link.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682634")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2023")])]

#text("Great result! Does this proof immediately generalize to Z^d so that one can get a bunch of nice applications outlined by Chang in ")#link("http://www.numdam.org/item/10.1016/j.crma.2009.04.006.pdf")[#text("http://www.numdam.org/item/10.1016/j.crma.2009.04.006.pdf")]#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682645")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2023")])]

#text("Somewhat weirdly, only half of the proof seems to generalize to the torsion-free setting; one can set up the same entropy decrement strategy, and for random variables that extremize (or almost extremize) a suitable distance-like functional, the “first estimate” and “second estimate” arguments go through and establish various non-trivial approximate conditional independence relations between various linear combinations of copies of the random variables. However the “endgame” step relies very heavily on finite characteristic, and we do not know what to replace it with. One indication that something very different has to be done in this step is that the conclusion is different: in bounded characteristic, the extremizers are expected to be uniformly distributed on cosets of subgroups, but in ")#mi("{\\bf Z}^d")#text(" the extremizer should instead be (discrete) gaussians. There are intriguing hints that gaussian behavior might be detectable via entropic means (for instance, a real (continuous) gaussian ")#mi("X")#text(" is more or less characterized by the property that ")#mi("X_1+X_2, X_1-X_2")#text(" are independent when ")#mi("X_1,X_2")#text(" are copies of ")#mi("X")#text("), but we have not been able to convert this intuition into an actual argument.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a6ffb8fc292930bc7e13650b8d87f86b2e278c0248e6205f455e5b206f530b-1165ef80ce0292beb5d0409261d2b0c0b9c45e0720b1ebeede0aea021f7e38d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcel Goh")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682894")[#strong[#text("Marcel Goh")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2024")])]

#text("In the appendix, it is stated that Lemma A.2 is related to Lemma 3.3 of your older paper. Does it directly imply (possibly a stronger version of) Lemma 3.3, or perhaps Theorem 3.1 directly? I am not quite sure how to relate the two statements, since the conditioning is slightly different (one is on ")#mi("X+Y")#text(" and the other is on ")#mi("X_1, Y")#text("). Perhaps I’m missing something obvious.")

#emph[#text("[The two are not directly comparable, since as you say the conditioning is slightly different, but both are useful in basically the same way in applications, although the verison we have in the new paper gives slightly better constants in practice. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a6ffb8fc292930bc7e13650b8d87f86b2e278c0248e6205f455e5b206f530b-1165ef80ce0292beb5d0409261d2b0c0b9c45e0720b1ebeede0aea021f7e38d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcel Goh")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-682896")[#strong[#text("Marcel Goh")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2024")])]

#text("Elaborating on my earlier comment, letting ")#mi("(X_1, Y_1)")#text(" and ")#mi("(X_2, Y_2)")#text(" be conditionally independent trials of ")#mi("(X,Y)")#text(", I think I can show that ")#mi("H(X_1, Y_2 | X+Y) \\le H(X)/2 + H(Y)/2 + \\log K")#text(" assuming Lemma A.2 as well as (24) and (25) from Theorem 3.1 in the older paper. This is not exactly (28), and I’m not sure how to transform the ")#mi("-")#text(" into a ")#mi("+")#text(", since ")#mi("X_1-Y_2")#text(" gives us a lot more information than ")#mi("X_1 + Y_2")#text(" from the coupling $X_1+Y_1 = X_2+Y_2$. (At least I think it does.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marton’s conjecture in abelian groups with bounded torsion | What's new")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-684660")[#strong[#text("Marton’s conjecture in abelian groups with bounded torsion | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2024")])]

#text("[…] had previously established the case of this result, with the number of translates bounded by (which was subsequently […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An abridged proof of Marton’s conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/#comment-685196")[#strong[#text("An abridged proof of Marton’s conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2024")])]

#text("[…] Timothy Gowers, Ben Green, Freddie Manners, and I were able to establish the following […]")
]
