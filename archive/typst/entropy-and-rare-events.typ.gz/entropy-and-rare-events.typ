// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/09/20/entropy-and-rare-events/
// Converted to Typst by tao2typ: "2026-10-14T16:37:46.617302+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Entropy and rare events", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Entropy and rare events")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 September 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/09/20/entropy-and-rare-events/")[#text("https://terrytao.wordpress.com/2015/09/20/entropy-and-rare-events/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" be two random variables taking values in the same (discrete) range ")#mi("{R}")#text(", and let ")#mi("{E}")#text(" be some subset of ")#mi("{R}")#text(", which we think of as the set of “bad” outcomes for either ")#mi("{X}")#text(" or ")#mi("{Y}")#text(". If ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" have the same probability distribution, then clearly")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( X \\in E ) = {\\bf P}( Y \\in E ).")]]

#text("In particular, if it is rare for ")#mi("{Y}")#text(" to lie in ")#mi("{E}")#text(", then it is also rare for ")#mi("{X}")#text(" to lie in ")#mi("{E}")#text(".")

#text("If ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" do not have exactly the same probability distribution, but their probability distributions are ")#emph[#text("close")]#text(" to each other in some sense, then we can expect to have an approximate version of the above statement. For instance, from the definition of the ")#link("https://en.wikipedia.org/wiki/Total_variation_distance_of_probability_measures")[#text("total variation distance")]#text(" ")#mi("{\\delta(X,Y)}")#text(" between two random variables (or more precisely, the total variation distance between the probability distributions of two random variables), we see that ")#metadata(none) <tao-142fc721c513e90cb65e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("{\\bf P}(Y \\in E) - \\delta(X,Y) \\leq {\\bf P}(X \\in E) \\leq {\\bf P}(Y \\in E) + \\delta(X,Y)")]]

#text("for any ")#mi("{E \\subset R}")#text(". In particular, if it is rare for ")#mi("{Y}")#text(" to lie in ")#mi("{E}")#text(", and ")#mi("{X,Y}")#text(" are close in total variation, then it is also rare for ")#mi("{X}")#text(" to lie in ")#mi("{E}")#text(".")

#text("A basic inequality in information theory is ")#link("https://en.wikipedia.org/wiki/Pinsker%27s_inequality")[#text("Pinsker’s inequality")]

#align(center)[#tao-fit-display[#mitex("\\delta(X,Y) \\leq \\sqrt{\\frac{1}{2} D_{KL}(X||Y)}")]]

#text("where the ")#link("https://en.wikipedia.org/wiki/Kullback%E2%80%93Leibler_divergence")[#text("Kullback-Leibler divergence")]#text(" ")#mi("{D_{KL}(X||Y)}")#text(" is defined by the formula")

#align(center)[#tao-fit-display[#mitex("D_{KL}(X||Y) = \\sum_{x \\in R} {\\bf P}( X=x ) \\log \\frac{{\\bf P}(X=x)}{{\\bf P}(Y=x)}.")]]

#text("(See ")#link("https://terrytao.wordpress.com/2013/02/05/some-notes-on-bakry-emery-theory/")[#text("this previous blog post")]#text(" for a proof of this inequality.) A standard application of ")#link("https://en.wikipedia.org/wiki/Jensen%27s_inequality")[#text("Jensen’s inequality")]#text(" reveals that ")#mi("{D_{KL}(X||Y)}")#text(" is non-negative (")#link("https://en.wikipedia.org/wiki/Gibbs%27_inequality")[#text("Gibbs’ inequality")]#text("), and vanishes if and only if ")#mi("{X}")#text(", ")#mi("{Y}")#text(" have the same distribution; thus one can think of ")#mi("{D_{KL}(X||Y)}")#text(" as a measure of how close the distributions of ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are to each other, although one should caution that this is not a symmetric notion of distance, as ")#mi("{D_{KL}(X||Y) \\neq D_{KL}(Y||X)}")#text(" in general. Inserting Pinsker’s inequality into ")#link(<tao-142fc721c513e90cb65e>)[#text("(1)")]#text(", we see for instance that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(X \\in E) \\leq {\\bf P}(Y \\in E) + \\sqrt{\\frac{1}{2} D_{KL}(X||Y)}.")]]

#text("Thus, if ")#mi("{X}")#text(" is close to ")#mi("{Y}")#text(" in the Kullback-Leibler sense, and it is rare for ")#mi("{Y}")#text(" to lie in ")#mi("{E}")#text(", then it is rare for ")#mi("{X}")#text(" to lie in ")#mi("{E}")#text(" as well.")

#text("We can specialise this inequality to the case when ")#mi("{Y}")#text(" a uniform random variable ")#mi("{U}")#text(" on a finite range ")#mi("{R}")#text(" of some cardinality ")#mi("{N}")#text(", in which case the Kullback-Leibler divergence ")#mi("{D_{KL}(X||U)}")#text(" simplifies to")

#align(center)[#tao-fit-display[#mitex("D_{KL}(X||U) = \\log N - {\\bf H}(X)")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("{\\bf H}(X) := \\sum_{x \\in R} {\\bf P}(X=x) \\log \\frac{1}{{\\bf P}(X=x)}")]]

#text("is the ")#link("https://en.wikipedia.org/wiki/Entropy_(information_theory)")[#text("Shannon entropy")]#text(" of ")#mi("{X}")#text(". Again, a routine application of Jensen’s inequality shows that ")#mi("{{\\bf H}(X) \\leq \\log N}")#text(", with equality if and only if ")#mi("{X}")#text(" is uniformly distributed on ")#mi("{R}")#text(". The above inequality then becomes ")#metadata(none) <tao-e387866de7696fa23d83>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("{\\bf P}(X \\in E) \\leq {\\bf P}(U \\in E) + \\sqrt{\\frac{1}{2}(\\log N - {\\bf H}(X))}.")]]

#text("Thus, if ")#mi("{E}")#text(" is a small fraction of ")#mi("{R}")#text(" (so that it is rare for ")#mi("{U}")#text(" to lie in ")#mi("{E}")#text("), and the entropy of ")#mi("{X}")#text(" is very close to the maximum possible value of ")#mi("{\\log N}")#text(", then it is rare for ")#mi("{X}")#text(" to lie in ")#mi("{E}")#text(" also.")

#text("The inequality ")#link(<tao-e387866de7696fa23d83>)[#text("(2)")]#text(" is only useful when the entropy ")#mi("{{\\bf H}(X)}")#text(" is close to ")#mi("{\\log N}")#text(" in the sense that ")#mi("{{\\bf H}(X) = \\log N - O(1)}")#text(", otherwise the bound is worse than the trivial bound of ")#mi("{{\\bf P}(X \\in E) \\leq 1}")#text(". In my ")#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/")[#text("recent paper on the Chowla and Elliott conjectures")]#text(", I ended up using a variant of ")#link(<tao-e387866de7696fa23d83>)[#text("(2)")]#text(" which was still non-trivial when the entropy ")#mi("{{\\bf H}(X)}")#text(" was allowed to be smaller than ")#mi("{\\log N - O(1)}")#text(". More precisely, I used the following simple inequality, which is implicit in the arguments of that paper but which I would like to make more explicit in this post:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Pinsker-type inequality)")]#text(" Let ")#mi("{X}")#text(" be a random variable taking values in a finite range ")#mi("{R}")#text(" of cardinality ")#mi("{N}")#text(", let ")#mi("{U}")#text(" be a uniformly distributed random variable in ")#mi("{R}")#text(", and let ")#mi("{E}")#text(" be a subset of ")#mi("{R}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(X \\in E) \\leq \\frac{(\\log N - {\\bf H}(X)) + \\log 2}{\\log 1/{\\bf P}(U \\in E)}.")]]
]

#emph[#text("Proof:")]#text(" Consider the ")#link("https://en.wikipedia.org/wiki/Conditional_entropy")[#text("conditional entropy")]#text(" ")#mi("{{\\bf H}(X | 1_{X \\in E} )}")#text(". On the one hand, we have")

#tao-aligned(keep: true)[


#tao-math("{\\bf H}(X | 1_{X \\in E} )  & = {\\bf H}(X, 1_{X \\in E}) - {\\bf H}(1_{X \\in E} )", block: true)



#tao-math(" & = {\\bf H}(X) - {\\bf H}(1_{X \\in E})", block: true)



#tao-math(" & \\geq {\\bf H}(X) - \\log 2", block: true)
]

#text("by Jensen’s inequality. On the other hand, one has")

#tao-aligned(keep: true)[


#tao-math("{\\bf H}(X | 1_{X \\in E} )  & = {\\bf P}(X \\in E) {\\bf H}(X | X \\in E )", block: true)



#tao-math(" & + (1-{\\bf P}(X \\in E)) {\\bf H}(X | X \\not \\in E)", block: true)



#tao-math(" & \\leq {\\bf P}(X \\in E) \\log \\left|E\\right| + (1-{\\bf P}(X \\in E)) \\log N", block: true)



#tao-math(" & = \\log N - {\\bf P}(X \\in E) \\log \\frac{N}{\\left|E\\right|}", block: true)



#tao-math(" & = \\log N - {\\bf P}(X \\in E) \\log \\frac{1}{{\\bf P}(U \\in E)},", block: true)
]

#text("where we have again used Jensen’s inequality. Putting the two inequalities together, we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" As noted in comments, this inequality can be viewed as a special case of the more general inequality")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(X \\in E) \\leq \\frac{D(X||Y) + \\log 2}{\\log 1/{\\bf P}(Y \\in E)}")]]

#text("for arbitrary random variables ")#mi("{X,Y}")#text(" taking values in the same discrete range ")#mi("{R}")#text(", which follows from the data processing inequality")

#align(center)[#tao-fit-display[#mitex("D( f(X)||f(Y)) \\leq D(X|| Y)")]]

#text("for arbitrary functions ")#mi("{f}")#text(", applied to the indicator function ")#mi("{f = 1_E}")#text(". Indeed one has")

#tao-aligned(keep: true)[


#tao-math("D( 1_E(X) || 1_E(Y) )  & = {\\bf P}(X \\in E) \\log \\frac{{\\bf P}(X \\in E)}{{\\bf P}(Y \\in E)}", block: true)



#tao-math(" & + {\\bf P}(X \\not \\in E) \\log \\frac{{\\bf P}(X \\not \\in E)}{{\\bf P}(Y \\not \\in E)}", block: true)



#tao-math(" & \\geq {\\bf P}(X \\in E) \\log \\frac{1}{{\\bf P}(Y \\in E)} - h( {\\bf P}(X \\in E) )", block: true)



#tao-math(" & \\geq {\\bf P}(X \\in E) \\log \\frac{1}{{\\bf P}(Y \\in E)} - \\log 2", block: true)
]

#text("where ")#mi("{h(u) := u \\log \\frac{1}{u} + (1-u) \\log \\frac{1}{1-u}}")#text(" is the entropy function.")
]

#text("Thus, for instance, if one has")

#align(center)[#tao-fit-display[#mitex("{\\bf H}(X) \\geq \\log N - o(K)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(U \\in E) \\leq \\exp( - K )")]]

#text("for some ")#mi("{K}")#text(" much larger than ")#mi("{1}")#text(" (so that ")#mi("{1/K = o(1)}")#text("), then")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(X \\in E) = o(1).")]]

#text("More informally: if the entropy of ")#mi("{X}")#text(" is ")#emph[#text("somewhat")]#text(" close to the maximum possible value of ")#mi("{\\log N}")#text(", and it is ")#emph[#text("exponentially")]#text(" rare for a uniform variable to lie in ")#mi("{E}")#text(", then it is still ")#emph[#text("somewhat")]#text(" rare for ")#mi("{X}")#text(" to lie in ")#mi("{E}")#text(". The estimate given is close to sharp in this regime, as can be seen by calculating the entropy of a random variable ")#mi("{X}")#text(" which is uniformly distributed inside a small set ")#mi("{E}")#text(" with some probability ")#mi("{p}")#text(" and uniformly distributed outside of ")#mi("{E}")#text(" with probability ")#mi("{1-p}")#text(", for some parameter ")#mi("{0 \\leq p \\leq 1}")#text(".")

#text("It turns out that the above lemma combines well with concentration of measure estimates; in my paper, I used one of the simplest such estimates, namely ")#link("https://en.wikipedia.org/wiki/Hoeffding%27s_inequality")[#text("Hoeffding’s inequality")]#text(", but there are of course many other estimates of this type (see e.g. this ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("previous blog post")]#text(" for some others). Roughly speaking, concentration of measure inequalities allow one to make approximations such as")

#align(center)[#tao-fit-display[#mitex("F(U) \\approx {\\bf E} F(U)")]]

#text("with exponentially high probability, where ")#mi("{U}")#text(" is a uniform distribution and ")#mi("{F}")#text(" is some reasonable function of ")#mi("{U}")#text(". Combining this with the above lemma, we can then obtain approximations of the form ")#metadata(none) <tao-8500dfd92c7701e240c4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("F(X) \\approx {\\bf E} F(U)")]]

#text("with somewhat high probability, if the entropy of ")#mi("{X}")#text(" is somewhat close to maximum. This observation, combined with an “entropy decrement argument” that allowed one to arrive at a situation in which the relevant random variable ")#mi("{X}")#text(" did have a near-maximum entropy, is the key new idea in my recent paper; for instance, one can use the approximation ")#link(<tao-8500dfd92c7701e240c4>)[#text("(3)")]#text(" to obtain an approximation of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^H \\sum_{p \\in {\\mathcal P}} \\lambda(n+j) \\lambda(n+j+p) 1_{p|n+j}")]]

#align(center)[#tao-fit-display[#mitex("\\approx \\sum_{j=1}^H \\sum_{p \\in {\\mathcal P}} \\frac{\\lambda(n+j) \\lambda(n+j+p)}{p}")]]

#text("for “most” choices of ")#mi("{n}")#text(" and a suitable choice of ")#mi("{H}")#text(" (with the latter being provided by the entropy decrement argument). The left-hand side is tied to Chowla-type sums such as ")#mi("{\\sum_{n \\leq x} \\frac{\\lambda(n)\\lambda(n+1)}{n}}")#text(" through the multiplicativity of ")#mi("{\\lambda}")#text(", while the right-hand side, being a linear correlation involving two parameters ")#mi("{j,p}")#text(" rather than just one, has “finite complexity” and can be treated by existing techniques such as the Hardy-Littlewood circle method. One could hope that one could similarly use approximations such as ")#link(<tao-8500dfd92c7701e240c4>)[#text("(3)")]#text(" in other problems in analytic number theory or combinatorics.")

#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/20/entropy-and-rare-events/#comment-459507")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2015")])]

#text("Dear Prof. Tao,")

#text("There is a simple exponential version of Pinsker’s inequality that almost gives what you want, even without the assumption that one of the RV’s is uniform:")

#text("\\delta(X,Y) \\le 1 – (1/2).exp(-KL(X,Y))")

#text("(This is proved for instance in Tsybakov’s book “Introduction to Nonparametric Estimation” (eq. 2.25).) Unfortunately this only gives constant bounds, instead of o(1), in your setting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64a10c163e634cc43e2995fdce39a0040ded2ce9debaa48ee9a1396cabded53d-e2729b491f49bf837a7c4b5153d140d602bd4dd7a2258a0b475deeb0c306e225.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yihong")]], [#link("https://terrytao.wordpress.com/2015/09/20/entropy-and-rare-events/#comment-459509")[#strong[#text("Yihong")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2015")])]

#text("A side remark on Lemma 1: (2) also follows from the “data processing” inequality in information theory, namely, ")#mi("D_{KL}(f(X) \\|f(Y)) \\leq D(X\\|Y)")#text(", for any function ")#mi("f")#text(". Taking ")#mi("f = 1_E")#text(" implies (2). Furthermore, instead of deterministic ")#mi("f")#text(", one can replace ")#mi("f")#text(" by any Markov kernel. Lemma 1 is useful in information-theoretic treatment of large deviation. For example, taking ")#mi("X=(X_1,...,X_n)")#text(" and ")#mi("Y=(Y_1,...,Y_n)")#text(" with iid components and ")#mi("f=1_{\\sum x_i > n a}")#text(" shows that the large deviation exponent cannot exceed something, an idea due to Csiszar, see, e.g., ")#link("http://www.emis.de/journals/em/docs/boletim/vol374/v37-4-a2-2006.pdf")[#text("http://www.emis.de/journals/em/docs/boletim/vol374/v37-4-a2-2006.pdf")]

#emph[#text("[Nice! I’ve added this alternate argument to the main post. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1fba2dec28a8e4d1b233936bebc595cd57eed616c23c66e67cdd0a6868dcccd6-04332b5676c7228a89c28b23c08139b9deb4335ef00954c67491155f5e2be8b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2015/09/20/entropy-and-rare-events/#comment-459532")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2015")])]

#text("What was the motivation from data processing for their inequality?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2015/09/20/entropy-and-rare-events/#comment-459517")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2015")])]

#text("The Remark 2 box has a broken equation. Also, at one point, shortly after KL-divergence is defined, you’ve got D_{KL}(X|Y).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d9e338e0cd3c5854d68f121b5bf4dd9161377bdb81e3cdc27ffbef30ef3227b-78ebb2d5d5bd8641134d35ec8cda100165b35ec3350266a25bb780abe9cd2e13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2015/09/20/entropy-and-rare-events/#comment-459548")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2015")])]

#text("Can the prime number theorem as a kind of concentration of measure phenomenon? E.g. we can show Möbius valued coin-flips are not biased.")

#text("I don’t know how to formulate this precisely. Even the law of large numbers itself is fraught with difficult philosophical questions like “what is a typical infinite random sequence of coin flips?”")

#text("All proofs of PNT I have seen so far, ultimately lose their combinatorial flavor and either become delicate (but common) maneuvers of the zeta function with contour integrals or, equally challenging estimates about ")#mi("\\times 2")#text(" (starting with Bertrand’s postulate).")

#text("In either case you can’t just conclude “gee that is the max-ent distribution” but you have to prove that entropy is increasing – this is hard. I find many expositions of PNT start off great, but wind up sweeping important sources of complexity under the rug. Sadly, I have not said very much.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jesper")]], [#link("https://terrytao.wordpress.com/2015/09/20/entropy-and-rare-events/#comment-459673")[#strong[#text("Jesper")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2015")])]

#text("If you use the definition of total variation distance given on Wikipedia, then the constant in Pinsker’s inequality can be improved to 1/2. A constant of 2 is only needed if one defines the total variation distance to be the L_1 distance (in the Wikipedia definition, the total variation distance is half the L_1 distance).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/09/20/entropy-and-rare-events/#comment-460050")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("Since there are several kinds of entropies (e.g. Gibbs, Shannon, Perelman), is there some unifying definition of entropy for general (for both stochastic or deterministic) dynamical systems ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e41a655a43fd81844baa8c4f3ca019946f619b05e1629676fc0ef441fc8e775-727dab67ebceb17c501056072241b00fde24bbfdceb166aeb0301d41e8f6543e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PerryZhao")]], [#link("https://terrytao.wordpress.com/2015/09/20/entropy-and-rare-events/#comment-460098")[#strong[#text("PerryZhao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2015")])]

#text("Reblogged this on ")#link("https://perryzhao.wordpress.com/2015/10/04/entropy-and-rare-events/")[#text("木秀于林")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72d944cf8d81ff1846255410bebf88d831207cbc6f13c3a99769873a3e61f863-11b87f14ced601a058637c707aaeccabf04ff23b9d4ef367dc8b714833764df2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bowen")]], [#link("https://terrytao.wordpress.com/2015/09/20/entropy-and-rare-events/#comment-460509")[#strong[#text("Bowen")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2015")])]

#text("Reblogged this on ")#link("https://bowen0701.wordpress.com/2015/10/14/entropy-and-rare-events/")[#text("Statistics & ML Hack")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9fe37471f7a934331c4386edf57b5e65a3052f8c3f71b87ae875149b94be71b-20c43104ab6bcb2bd1fdac2268f5abe6c570abc709b9f0b4116fc5b9f2464213.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven Heilman")]], [#link("https://terrytao.wordpress.com/2015/09/20/entropy-and-rare-events/#comment-460601")[#strong[#text("Steven Heilman")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2015")])]

#text("Is it possible to re-interpret your Pinsker inequalities using the Ricci curvature of the graph G_n,H discussed in the previous post? It is known (Theorem 1.10, ")#link("http://arxiv.org/pdf/1509.07160v1.pdf")[#text("http://arxiv.org/pdf/1509.07160v1.pdf")]#text(") that if a graph has “positive Ricci curvature,” then the graph satisfies a Pinsker inequality. (See also: ")#link("http://cedricvillani.org/wp-content/uploads/2012/07/031.BV-CKP.pdf")[#text("http://cedricvillani.org/wp-content/uploads/2012/07/031.BV-CKP.pdf")]#text("). Checking for “positive Ricci curvature” typically amounts to showing that the graph has many short cycles, and it seems that the graph G_n,H has many short cycles. Unfortunately, maybe each of you has a different definition of a Pinsker inequality, so it may be difficult to connect these topics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/09/20/entropy-and-rare-events/#comment-460603")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2015")])]

#text("As far as I can tell, these are unrelated uses of graphs. In the papers you cite, the Pinsker inequality is generalised by placing a graph metric on the underlying sample space that the probability measures are supported on, sand then replacing total variation norm with Wasserstein distance. With the random graphs G_n, the graphs are not used as sample spaces, but instead each outcome in the sample space is associated to one such graph. The metric geometry of these graphs is somewhat related to their expansion properties (e.g. expanders tend to have very small diameter, and the spectral gap property of expanders is closely tied to the existence of a Poincare inequality), but it’s unclear to me how to take advantage of this if one wishes to establish expansion of these graphs.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f94c4dd4f21770e69715f2816f0321226f0cf1cff74d1f09eeca9472aac58969-ff895f8c530351f6234ed16d30d179e52ce455089c1e3483643af00bb33ffbc7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grisou")]], [#link("https://terrytao.wordpress.com/2015/09/20/entropy-and-rare-events/#comment-461075")[#strong[#text("Grisou")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2015")])]

#text("Hello,")#linebreak()#text(" Very interesting.")

#text("Is there any similar result for continuous random variables X and Y ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Furstenberg limits of the Liouville function | What's new")]], [#link("https://terrytao.wordpress.com/2015/09/20/entropy-and-rare-events/#comment-478890")[#strong[#text("Furstenberg limits of the Liouville function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2017")])]

#text("[…] some . Using the Pinsker-type inequality from this previous blog post, we conclude the lower […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3205d8eeb9c554b4dd0cc3d073ee0fccb7caa8f5245405e7db9ef43dfd7e2b5-a4d99c4307912feff11c653ffa27243560eff8a237c725adfd34835995912cc1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tao’s Proof of (logarithmically averaged) Chowla’s conjecture for two point correlations | I Can't Believe It's Not Random!")]], [#link("https://terrytao.wordpress.com/2015/09/20/entropy-and-rare-events/#comment-506807")[#strong[#text("Tao’s Proof of (logarithmically averaged) Chowla’s conjecture for two point correlations | I Can't Believe It's Not Random!")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2018")])]

#text("[…] Proof: This is Lemma 1 in this post of Tao. […]")
]
