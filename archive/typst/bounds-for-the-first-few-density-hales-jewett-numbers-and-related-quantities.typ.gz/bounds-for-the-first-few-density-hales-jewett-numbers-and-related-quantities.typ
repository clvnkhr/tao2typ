// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/
// Converted to Typst by tao2typ: "2026-10-14T15:17:03.344892+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Bounds for the first few density Hales-Jewett numbers, and related quantities", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Bounds for the first few density Hales-Jewett numbers, and related quantities")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 February 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/")[#text("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This thread is a continuation of the ")#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/")[#text("previous thread here")]#text(" on the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("polymath1 project")]#text(". Currently, activity is focusing on the following problems:")

#strong[#text("1. Upper and lower bounds for ")#mi("c_n")#text(" for small n.")]

#text("Let ")#mi("c_n")#text(" be the largest size of a set in ")#mi("{}[3]^n")#text(" without a ")#link("http://michaelnielsen.org/polymath1/index.php?title=Line")[#text("combinatorial line")]#text(". Thanks to efforts from previous threads, we have the first five values of ")#mi("c_n")#text(":")

#align(center)[#mi("c_0=1; c_1=2; c_2=6; c_3=18; c_4=52")#text(".")]

#text("We also know that ")#mi("150 \\leq c_5 \\leq 154")#text(", and are working to narrow this further. The arguments justifying these bounds can be ")#link("http://michaelnielsen.org/polymath1/index.php?title=Upper_and_lower_bounds")[#text("found here")]#text(". The latest bounds for the next few values of ")#mi("c_n")#text(" can be ")#link("http://spreadsheets.google.com/ccc?key=p5T0SktZY9DsU-uZ1tK7VEg")[#text("found here")]#text(".")

#strong[#text("2. A hyper-optimistic conjecture")]

#text("Consider a variant of the above problem in which each element of ")#mi("{}[3]^n")#text(" with a 1s, b 2s, and c 3s is weighted by the factor ")#mi("\\frac{a! b! c!}{n!}")#text("; this gives ")#mi("{}[3]^n")#text(" a total weight of ")#mi("\\frac{(n+1)(n+2)}{2}")#text(". Let ")#mi("c^\\mu_n")#text(" be the largest weight of a line-free set of ")#mi("{}[3]^n")#text(", and let ")#mi("\\overline{c}^\\mu_n")#text(" be the largest size of a subset of")

#align(center)[#tao-fit-display[#mitex("\\Delta_n := \\{ (a,b,c) \\in {\\Bbb Z}_+^3: a+b+c=n \\}")]]

#text("which contains no upward-pointing equilateral triangles ")#mi("(a+r,b,c), (a,b+r,c), (a,b,c+r)")#text(" with ")#mi("r>0")#text(". It is known that ")#mi("c^\\mu_n \\geq \\overline{c}^\\mu_n")#text("; the “")#link("http://michaelnielsen.org/polymath1/index.php?title=Hyper-optimistic_conjecture")[#text("hyper-optimistic conjecture")]#text("” is that one in fact has ")#mi("c^\\mu_n = \\overline{c}^\\mu_n")#text(". This would imply density Hales-Jewett for k=3.")

#text("Currently, we know the following values for these sequences:")

#align(center)[#tao-fit-display[#mitex("c^\\mu_0 = 1; c^\\mu_1 = 2; c^\\mu_2 = 4")]]

#text("and")

#align(center)[#mi("\\overline{c}^\\mu_0 = 1; \\overline{c}^\\mu_1 = 2; \\overline{c}^\\mu_2 = 4; \\overline{c}^\\mu_3 = 6; \\overline{c}^\\mu_4 = 9; \\overline{c}^\\mu_5 = 12")#text(".")]

#text("There are also some further upper and lower bounds known; see ")#link("http://spreadsheets.google.com/ccc?key=p5T0SktZY9DsU-uZ1tK7VEg")[#text("this spreadsheet")]#text(" for the latest bounds, and ")#link("http://michaelnielsen.org/polymath1/index.php?title=Fujimura's_problem")[#text("this page")]#text(" for proofs of the bounds. The data so far is consistent with the conjecture, but more work would be needed to obtain a more convincing case for it.")

#strong[#text("3. Asymptotics for Moser’s cube problem")]

#link("http://michaelnielsen.org/polymath1/index.php?title=Moser%27s_cube_problem")[#text("Moser’s cube problem")]#text(" asks to compute the largest size ")#mi("c^{\\prime}_n")#text(" of a subset of the cube ")#mi("{}[3]^n")#text(" without geometric lines. The first few values of ")#mi("c^{\\prime}_n")#text(" are known:")

#align(center)[#mi("c^{\\prime}_0=1; c^{\\prime}_1 = 2; c^{\\prime}_2 = 6; c^{\\prime}_3 = 14; c^{\\prime}_4 = 43")#text(".")]

#text("The best asymptotic lower bound known is ")#mi("c^{\\prime}_n \\gg 3^n/\\sqrt{n}")#text(". Given that we have a significantly superior lower bound of ")#mi("c_n \\geq 3^{n-O(\\sqrt{\\log n})}")#text(" for ")#mi("c_n")#text(", one might hope to similarly improve the lower bound for Moser’s problem. But there seems to be a technical snag, based on the observation that between two slices ")#mi("\\Gamma_{a,b,c}")#text(" and ")#mi("\\Gamma_{a^{\\prime},b^{\\prime},c^{\\prime}}")#text(" with the ")#mi("c-a=c^{\\prime}-a^{\\prime}")#text(", there are in fact quite a few combinatorial lines connecting them, and so it is not obvious how to create a geometric line-free set that involves more than one slice per value of c-a.")

#text("It is also of interest to work out what asymptotic lower bound for ")#mi("c_n")#text(" one can get for larger values of k than 3.")

#text("Comments on this thread should start at 700. We will also try to record progress made at the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("polymath1 wiki")]#text(" and at the ")#link("http://spreadsheets.google.com/ccc?key=p5T0SktZY9DsU-uZ1tK7VEg")[#text("polymath1 spreadsheet")]#text(", as appropriate.")

#heading(level: 1)[#text("Comments (103)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-3/#comment-36323")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("796. Moser(3)")

#text("Thanks Kristal! Looks like we are in very good shape now. In particular we now have the situation described in 795; I’ll put that argument on the wiki now.")

#text("As this thread is now basically full, I am closing it and we will be moving to the 900 thread at")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers/")[#text("DHJ(3): 900-999 (Density Hales-Jewett type numbers)")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36045")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2009")])]

#text("751. ")#mi("c_5 \\leq 151")#text(" by hand")

#text("I used Terry’s classification, in comment 745, of 50pt, 51pt and 52pt subsets of ")#mi("{}[3]^4")#text(" to show ")#mi("c_5 \\leq 151")#text(". My proof")#linebreak()#text(" is in the wiki.")

#text("In 743, one group of 16 solutions had five points with no 2s.")#linebreak()#text(" One of these solutions is the union of the following, and the other fifteen are reflections of it in one or more of the axes.")

#mi("\\Gamma_{0,0,4} + \\Gamma_{0,1,3} + \\Gamma_{0,2,2} + \\Gamma_{1,2,1} + \\Gamma_{2,1,1} + \\Gamma_{3,0,1} + \\Gamma_{3,1,0}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seva")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36050")[#strong[#text("Seva")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2009")])]

#text("752. An algebraic DHJ(3)")

#text("Not quite following the mainstream of this thread, and perhaps already discussed elsewhere — but anyway. There seems to be a nice version of the DHJ(3), which may be easier to attack and which looks (almost) equally exciting to me.")

#text("Let’s say that a vector in ")#mi("F_3^r")#text(" is ")#emph[#text("simple")]#text(" if either ")#mi("1")#text(", or ")#mi("2")#text(" does not appear among its coordinates; say, ")#mi("(1,0,0,1,0)")#text(" and ")#mi("(2,2,2,0,2)")#text(" are simple vectors, while ")#mi("(1,2,1,1,1)")#text(" is not. Furthermore, call a three-term progression in ")#mi("F_3^r")#text(" simple if its difference is simple. Thus, a simple progression is a triple ")#mi("a,b,c")#text(" of distinct elements of ")#mi("F_3^r")#text(" with ")#mi("a+b+c=0")#text(" and ")#mi("a-b,b-c,c-a")#text(" all simple. The DHJ(3) implies that any positive density subset of ")#mi("F_3^r")#text(" contains a simple progression. Is there any combinatorial or Fourier-theoretic proof of this fact?")

#text("Notice that by the integer Roth theorem, any set ")#mi("A\\subseteq[N]")#text(" of positive density contains a three-term progression with the difference, say, at most ")#mi("N^{0.1}")#text("; however, the corresponding argument does not seem to extend onto simple progressions in ")#mi("F_3^r")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36051")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2009")])]

#text("752. ")#mi("c_5 \\leq 150")#text(" by hand")

#text("I think I have finished the long-winded proof that ")#mi("c_5 \\leq 150")#text(", in the wiki.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36059")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2009")])]

#text("753.")

#text("Michael: Excellent! Now we have two independent confirmations that ")#mi("c_5=150")#text(" and thus ")#mi("c_6=450")#text(", and also quite a good understanding of the extremisers and near-extremisers (though probably not enough to completely close the gaps in the bounds ")#mi("1302 \\leq c_7 \\leq 1348")#text("). Incidentally, I placed this sequence on the OEIS at")

#link("http://www.research.att.com/~njas/sequences/A156989")[#text("http://www.research.att.com/~njas/sequences/A156989")]

#text("and c”_n at")

#link("http://www.research.att.com/~njas/sequences/A156990")[#text("http://www.research.att.com/~njas/sequences/A156990")]

#text("Seva: Thanks for the question, which I have added to ")#link("http://michaelnielsen.org/polymath1/index.php?title=Tidy_problem_page")[#text("the wiki")]#text(". The same question was also posed, incidentally, by Randall in 480. I think the problem is similar to that of finding arithmetic progressions of length three in dense sets of [N] whose difference is a square. Ben observed once that such a result could be deduced from known results in “quadratic Fourier analysis” (in particular, the U^3 inverse theorem) and so there is a chance that something similar can be done here.")

#text("Re: Moser: it may be helpful to try to find a non-computer-assisted proof of the upper bound ")#mi("c^{\\prime}_4 \\leq 43")#text(", as this may help us understand the structure of the extremisers and near-extremisers better (given that this strategy seems to have been quite successful for ")#mi("c_n")#text("). Actually, do we even have a human proof of ")#mi("c^{\\prime}_3 \\leq 16")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6aee136dbc4c0bc79c68cbcf7d17f526cce6319a8e6e98ec412127af7d47f3a8-376867c974a73315b8452903740c9fc3635e43fe0fc86f758644077298bb8a0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Elsholtz")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36060")[#strong[#text("Christian Elsholtz")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2009")])]

#text("754 Human proofs of Moser’s problem in dimension 3 and 4")#linebreak()#text(" (with regard to terry’s question in 753)")

#text("1) L. Moser, Problem P.170 in Canad. Math. Bull. 13 (1970), 268.")#linebreak()#text(" Origin of problem.")

#text("2) Komlos, solution to problem P.170 by Leo Moser,")#linebreak()#text(" Canad. Math.. Bull. vol (??check) (1972), 312-313, 1970.")

#text("gives a solution like fixing n/3 coefficients, i.e. a lower bound of ")#mi("\\frac{3^n}{\\sqrt{n}}")#text(".")

#text("3) V. Chvatal, Remarks on a problem of Moser, Canad. Math. Bull. 15 (1972),")#linebreak()#text(" 19-21.")

#text("improves the constant in Komlos construction, essentially taking a union of slices,")#linebreak()#text(" gives a lower bound of ")#mi("c^{\\prime}_4\\geq 42")#text(" and implicitly $c’_5\\geq 124$ etc,")#linebreak()#text(" by. relating the problem to a coding theory problem.")#linebreak()#text(" but is aware of the solution with 43 points in dimension 4.")

#text("4) V. Chvatal,")#linebreak()#text(" Edmonds polytopes and a hierarchy of combinatorial problems")#linebreak()#text(" Discrete Math. 4 (1973) 305-337.")#linebreak()#text(" Reprinted: Discrete Mathematics, 306, 2006, 886-904.")

#text("gives a human proof of ")#mi("c^{\\prime}_3=16")#text(", it’s actually a linear programming method, with some geometrically motivated clever scalings. perhaps this can be generalized.")

#text("5) A.K. Chandra, On the solution of Moser’s problem in four dimensions,")#linebreak()#text(" Canad. Math. Bull. 16 (1973), 507-511.")

#text("gives a human proof of ")#mi("c^{\\prime}_4=43")#text(" with some useful info on number of points in certain sub-configurations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9946c9121e0cb957d136b5263170c8a16bc3714a9752b67f86f1a8e55f6903c-d05b29fec6ff76805e2997f2a2e0fd4a3c2f601ae9c890328792ae8a4468c320.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jozsef")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36061")[#strong[#text("jozsef")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2009")])]

#text("754. Exact bounds")

#text("It is great that you find the exact values of ")#mi("c_5")#text(" and ")#mi("c_6")#text(" !")#linebreak()#text(" I was wondering if you could check if the extremal configurations are “corner-free” or not. By corner-free I meant that if for every point you assign a 3-dimensional point (a,b,c) where a is the number of 0-s, b is the number of 1-s, and c is the number of c-s then there is no triple of the form (x+d,y,z), (x,y+d,z),(x,y,z+d). It would be also interesting to know if there is at least one such extremal configuration exists for k=6. It is for checking if our present lower bound strategy is optimal or not. (Probably not)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36064")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2009")])]

#text("I tried these two links")

#link("http://www.research.att.com/~njas/sequences/A156989")[#text("http://www.research.att.com/~njas/sequences/A156989")]

#link("http://www.research.att.com/~njas/sequences/A156990")[#text("http://www.research.att.com/~njas/sequences/A156990")]

#text("and the I didn’t get a sequence for the second one which")#linebreak()#text(" I think is for ")#mi("c^{\\prime\\prime}_n")#text(" even though I tried it twice.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6aee136dbc4c0bc79c68cbcf7d17f526cce6319a8e6e98ec412127af7d47f3a8-376867c974a73315b8452903740c9fc3635e43fe0fc86f758644077298bb8a0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Elsholtz")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36071")[#strong[#text("Christian Elsholtz")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2009")])]

#text("757 Moser, n=5")

#text("Comment on the example that shows ")#mi("c^{\\prime}_5 \\geq 154")#text(":")

#text("If one shifts the digits from {1,2,3} to {-1,0,1}, then one observes that")#linebreak()#text(" the example has all 80 vectors with “sum of coordinate entry squares=3,")#linebreak()#text(" i.e. two zeros and three times ")#mi("\\pm 1")#linebreak()#text(" all 40 vectors with sum of entry squares=4, i.e. one zeros and four ")#mi("\\pm 1")#text(" entries, and four more vectors with all entries being ")#mi("\\pm 1")#text(".")

#text("In other words, this is a union of two Behrend spheres and a third partial sphere.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36072")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2009")])]

#text("Dear Kristal, the sequence got moved to")

#link("http://www.research.att.com/~njas/sequences/A090245")[#text("http://www.research.att.com/~njas/sequences/A090245")]

#text("because of a duplication.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36102")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2009")])]

#text("758. Contains on ")#tao-math("(\\left|A\\right|, \\left|B\\right|, \\left|C\\right|)", block: false)#text(".")#linebreak()#text(" Let ")#mi("S := \\Gamma_{a+r,b,c} \\cup \\Gamma_{a,b+r,c} \\cup \\Gamma_{a,b,c+r} \\subset [3]^n")#text(", where ")#mi("r>0")#text(", and let ")#mi("A \\cup B \\cup C")#text(" be a (combinatorial-)line-free subset of ")#mi("S")#text(", such that ")#mi("A \\subset \\Gamma_{a+r,b,c}, B \\subset \\Gamma_{a,b+r,c}, C \\subset \\Gamma_{a,b,c+r}")#text(". Now we want to find the contains on ")#tao-math("(\\left|A\\right|, \\left|B\\right|, \\left|C\\right|)", block: false)#text(".")

#text("It is possible to show that ")#tao-math("\\frac{\\left|A\\right|}{\\binom n{a+r,b,c}}+\\frac{\\left|B\\right|}{\\binom n{a,b+r,c}}+\\frac{\\left|C\\right|}{\\binom n{a,b,c+r}}\\leq 2", block: false)#text(" (216). That is: The equal-slice measure of ")#mi("A \\cup B \\cup C")#text(" is at most ")#mi("2")#text(". I thought this inequality was sharp when none of A, B, and C are empty, but this was disproved in Michael.220 in the case ")#mi("a=b=c=r=1")#text(". The following is a general counterexample except for the case where ")#mi("a=b=c=0")#text(" where it is trivially true. Assume WLOG that ")#mi("c \\neq 0")#text(", and let M be a proper non-empty subset of ")#mi("\\binom {[n]}{c}")#text(" (such a set M exist since ")#mi("n\\geq 2")#text(", because ")#mi("c,r>0")#text("). Now let ")#mi("C=\\Gamma_{a,b,c+r}")#text(", let A be the set of elements ")#mi("x\\in\\Gamma_{a+r,b,c}")#text(" where the set of i’s such that ")#mi("x_i=3")#text(" is an element in M, and let B be the set of elements ")#mi("x\\in\\Gamma_{a,b+r,c}")#text(" where the set of i’s such that ")#mi("x_i=3")#text(" is _not_ an element in M. Now ")#mi("A \\cup B \\cup C")#text(" contains 2 elements of every line, and thus ")#tao-math("\\frac{\\left|A\\right|}{\\binom n{a+r,b,c}}+\\frac{\\left|B\\right|}{\\binom n{a,b+r,c}}+\\frac{\\left|C\\right|}{\\binom n{a,b,c+r}}= 2", block: false)#text(".")

#text("Notice that the example in 220 is not a special case of the above example.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36104")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2009")])]

#text("759. Moser(3)")

#text("I found the ")#mi("c^{\\prime}_4 = 43")#text(" paper online at")

#text("ftp://reports.stanford.edu/pub/cstr/reports/cs/tr/72/286/CS-TR-72-286.pdf")

#text("I also reconstructed the ")#mi("c^{\\prime}_3 \\leq 16")#text(" argument as follows. For every ")#mi("0 \\leq m \\leq n")#text(", let ")#mi("\\alpha_m")#text(" be the density of A inside the set of points with exactly m 2s. Thus for instance when n=3 we have ")#tao-math("\\left|A\\right| = 8 \\alpha_0 + 12 \\alpha_1 + 6 \\alpha_2 + \\alpha_3", block: false)#text(". We also have the linear inequalities ")#mi("2\\alpha_i + \\alpha_j \\leq 2")#text(" for ")#mi("i < j")#text(", as can be seen by double-counting those geometric lines with j-i wildcards and i fixed 2s. There is also the refinement ")#mi("2 \\alpha_0 + \\alpha_1 + \\alpha_2/2 \\leq 2")#text(", formed by checking this inequality by hand in the two-dimensional case, which then implies the general case by an averaging argument. In three dimensions, one can get ")#tao-math("\\left|A\\right| \\leq 16", block: false)#text(" by a suitable linear combination of these inequalities.")

#text("The same argument only seems to give ")#mi("c^{\\prime}_4 \\leq 48")#text(" in four dimensions. I haven’t yet digested the paper above to see how to do better.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36105")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2009")])]

#text("760. Moser(3)")

#text("There is an additional inequality in 3 and higher dimensions, namely ")#mi("\\alpha_0 + \\alpha_2 \\leq 4/3")#text(". This can be proven by first verifying it inside the six-element set {333, 322, 311, 223, 113, 212} and then averaging over all the symmetries of the Moser cube. This seems to lower the upper bound for ")#mi("c^{\\prime}_4")#text(" to 46 2/3 (and hence to 46, by integrality).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36107")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2009")])]

#text("761. Moser(3)")

#text("In 743 it was remarked that the ")#mi("c^{\\prime}_4 = 43")#text(" extremisers were distributed in the patterns (3,16,24,0,0), (4,15,24,0,0), (4,16,23,0,0), or (5,20,18,0,0), where (a,b,c,d,e) means that there are a numbers with 0 2s, b numbers with 1 2, etc. (For comparison, the entire cube ")#mi("[3]^4")#text(" has distribution (16,32,24,8,1)). It is not so surprising that the d and e slots are empty (putting a point in there tends to be very expensive with regard to the higher slices), but it is interesting that there is such a huge bulge in the c position; as noted in 744, this already shows that one cannot have three parallel slices of 43-point sets, leading to the bound ")#mi("c^{\\prime}_5 \\leq 3 c^{\\prime}_4 - 1 = 128")#text(".")

#text("It should be straightforward to compute the distributions of the 42-point sets provided in 747. If the bulge persists,then there should not be any parallel slices of three 42-point sets either, which would let us shave the upper bound from 128 to 127 and put significant constraints on any 126-point set.")

#text("Eventually, one may want to work in (a,b,c,d,e) space. Let ")#mi("\\Omega")#text(" be the convex hull of all (a,b,c,d,e) that are attainable from Moser sets in ")#mi("[3]^4")#text(", then the cardinality of a Moser set A in ")#mi("[3]^5")#text(" is equal to ")#mi("3(a^{\\prime}+b^{\\prime}+c^{\\prime}+d^{\\prime}+e^{\\prime})")#text(", where ")#mi("(a^{\\prime},b^{\\prime},c^{\\prime},d^{\\prime},e^{\\prime})")#text(" is the average of three points ")#mi("(a_1,\\ldots,e_1), (a_2,\\ldots,e_2), (a_3,\\ldots,e_3)")#text(" in ")#mi("\\Omega")#text(" (corresponding to the 3 slices of ")#mi("A")#text(") and thus also lies in ")#mi("\\Omega")#text(". On the other hand, by considering vertical lines (which can each intersect at most two of the three slices of A) we see that ")#mi("(a^{\\prime},b^{\\prime},c^{\\prime},d^{\\prime},e^{\\prime}) \\leq \\frac{2}{3} (16,32,24,8,1)")#text(", in the sense that each component on the left is less than the corresponding component on the right. Linear programming should then give us some bound on ")#mi("3(a^{\\prime}+b^{\\prime}+c^{\\prime}+d^{\\prime}+e^{\\prime})")#text(", but first we need to understand the shape of ")#mi("\\Omega")#text(". As a first approximation we might make the simplifying assumption that d=e=0 (so that ")#mi("\\Omega")#text(" is some three-dimensional polyhedron), given that this is what happens in the 43-point extremisers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6aee136dbc4c0bc79c68cbcf7d17f526cce6319a8e6e98ec412127af7d47f3a8-376867c974a73315b8452903740c9fc3635e43fe0fc86f758644077298bb8a0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Elsholtz")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36111")[#strong[#text("Christian Elsholtz")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2009")])]

#text("762 Moser, in dimension 2,3,4,5")#linebreak()#text(" We can assume that e=0 (in Terry’s notation in 761) for a very simple reason:")#linebreak()#text(" Suppose that e=1, meaning the central points is used, then there can be at most")#linebreak()#text(" ")#mi("\\frac{3^n-1}{2}+1")#text(" points in the set, since for each non-central point there is a forbidden point by symmetry.")#linebreak()#text(" In dimension 2,3,4,5 the lower bounds are larger than the bound above, so that the central point is not used.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36112")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2009")])]

#text("763. Moser(3)")#linebreak()#text(" The statistics for the number of 2s in the point of the 42 point sets can be found here")

#link("http://abel.math.umu.se/~klasm/Moser-42-stat.pdf")[#text("Click to access Moser-42-stat.pdf")]

#text("As you can see there is a small group of solutions with only 12 2s, but the rest have at least 17. There is also a group of solutions with 2 in the d slot.")

#text("The solutions with 12 2s can be found here")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/moser-n=4-42-12")[#text("http://abel.math.umu.se/~klasm/moser-n=4-42-12")]#linebreak()#text(" and the solutions with non-zero d slot here")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/moser-n=4-42-e=2")[#text("http://abel.math.umu.se/~klasm/moser-n=4-42-e=2")]

#emph[#text("[“e” corrected to “d” – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36114")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2009")])]

#text("764: Moser(3)")

#text("Klas: thanks, this is very interesting! It means in particular that the only 43+43+42 = 128 point solutions in ")#mi("[3]^5")#text(" can come when the 42-point slice is one of the eight c=12 solutions, and one of the 42-point slices is one of the six c=18 point solutions. This looks like enough reduction in the entropy to eliminate this case by computer search, and maybe even by hand if one is clever enough. (It also suggests that we should understand the structure of these anomalously low-c solutions better. Given how few they are, it is likely that there is just one solution up to isomorphism in both cases). That should lower the upper bound for ")#mi("124 \\leq c^{\\prime}_5 \\leq 128")#text(" to 127.")

#text("Presumably the number of 41-point solutions is too enormous to list explicitly… but perhaps the number of low-c solutions is small, and could be worth searching for by an integer program. Note for instance in a 42+42+41=125 type solution, if the 42-point solutions are not from the c=12 class, then they each have c >= 17, and so the 41 point solution has c <= 14. So perhaps it is worth trying to enumerate the 41-point solutions with c <=14? From the 42-point and 43-point data one may hope that there are relatively few of these. [It would be good, though, to have some explanation of why c tends to be high. Note that there is a 40-point solution with (a,b,c,d,e) = (8,32,0,0,0), so this phenomenon may well be very transient.]")

#text("Christian: It is true that if one has e=1 in a Moser set in ")#mi("[3]^4")#text(" then the number of points is at most ")#mi("\\frac{3^4-1}{2}+1 = 41")#text(", which is less than ")#mi("c_4 = 43")#text(". But this does not yet rule out the possibility that one of the 3-slices of, say, a 125-point Moser set in ")#mi("[3]^5")#text(" could have e=1, since the distribution could be (say) 42+42+41 or 43+43+39. (The argument does tell us, though, that the ")#emph[#text("middle")]#text(" slice has e=0). But presumably we can improve on the upper bound, which leads to a subquestion: what’s the largest size of a Moser set in ")#mi("[3]^4")#text(" that contains the centre 2222? If we can improve the easy upper bound 41 to 38 then we can rule out this case completely, or failing that if we get a reasonable description of the 39+ point sets with the centre then we should be able to eliminate it by hand. [Also, if we know that every slice of a Moser set has e=0, this implies after rotation of the cube that the middle slice of the Moser set has d=0. Similarly, if we learn that every slice of a Moser set has to have small d, then this should imply that at least one middle slice has small c, which by the previous discussion should be helpful in limiting the number of possibilities.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36115")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2009")])]

#text("765. Moser(3)")

#text("In fact, I can now rule out 128-point sets as follows. If one had a 128-point set, then the set must slice as 43+43+42 (or a permutation thereof) in every direction. But all 43-point slices have d=0 and all 42-point slices have d <= 2. Thus, there are at most two points amongst the sixteen points x222y, x22y2, x2y22, xy222 with x,y = 1,3 that lie in the set. Averaging this over all orientations we see that at most one eighth of all points with exactly 3 2s lie in the set. Thus, by the pigeonhole principle and a double counting argument, there exists a middle slice of the set with this property, i.e. a slice with c <= 24/8 = 3, but we know from the 43-point and 42-point distribution data that this is impossible.")

#text("To push this argument further, it would be helpful to classify the large-d 41-point solutions (as well as the large-e and low-c); presumably there are not very many of these.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57785d9b4bc8e25821f692ee3d435bb796adfed7394ad4ed0e523e2ca28c2248-7fa311f9e8852af89c8f8bbee0f6630fd2a26ed5a470dbfc0120dfbb7d2d752e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KS Chua")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36126")[#strong[#text("KS Chua")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2009")])]

#text("766 Moser(3)")

#text("From 762, there are at most 2^13=8192 subsets of size 14 in [3]^3 containing (222) which may be line free. This can be checked and they all contain at least 2 lines. So all such set has size <=13. Doing the n=4 case this way requires checking 2^41.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36127")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2009")])]

#text("767 Moser(3)")

#text("Dear KS: Thanks! Actually, knowing that 3-dimensional Moser sets with 222 have at most 13 points automatically implies that 4-dimensional Moser sets with 2222 have at most 40 points, because if they had 41 points, then every pair of antipodal points in the cube have exactly one representative in the set, which implies that every middle slice of the set has 14 points, which you have just ruled out.")

#text("In fact, if a 4D Moser set contains 2222, we now know that every middle slice must be missing at least one antipodal pair of points. There are four middle slices, and every antipodal pair belongs to at most three of them, so we must miss at least two antipodal pairs and so Moser sets with 2222 can have at most 39 points. This is right on the edge of what we need to rule them out for 125 = 43 + 43 + 39-point 5D Moser sets; perhaps a slightly more sophisticated analysis can eliminate them completely. If so, this would imply that a 125-point 5D Moser set cannot contain any point with 4 or 5 2s. In any event, we have already established this for 126-point sets.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36150")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2009")])]

#text("768 Moser(3)")

#text("I can almost eliminate points with four 2s completely from the 5D Moser problem.")

#text("By 767, we know that any 4D Moser set with 2222 has at most 39 points. Hence, the only way a 5D Moser can have a point (say 12222) with four 2s is if the 1****, 2****, 3**** slices have 39+43+43=125 points between them. But by 743, the 43-point slices have c = 24, 23, or 18. Meanwhile, the 39-point slice must have c at least 10, because it is allowed to miss at most two of the 12 antipodal pairs in c (and all antipodal pairs have at most one point in the set). Looking at vertical lines, we see that the total of the three c’s from the three slices is at most 2*24. This is only possible if the two 43-point slices have c=18.")

#text("So we are now in a position where the 2**** and 3**** slices are one of the 16 solutions with (a,b,c,d,e) = (5,20,18,0,0). This looks like a lot of information available, but to proceed further we would need to understand the structure of these 16 exceptional solutions (presumably they are all isomorphic to each other).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36152")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2009")])]

#text("768. Counting problems")

#text("There are ")#mi("4^n-3^n")#text(" sets of 3 distinct points x, y, z in ")#mi("[3]^n")#text(" such that they form a combinatorial line.")

#text("Therefore there are ")#mi("3^n(3^n-1)(3^n-2)-4^n+3^n")#text(" sets that do ")#strong[#text("not")]#text(" form a combinatorial line. Take those sets, and consider the pairs x and y, y and z, and x and z.")

#text("Counting Problem A: How many of those sets have all three pairs form partial combinatorial lines? (I’m using “partial combinatorial line” to mean given a pair there’s a third point in ")#mi("[3]^n")#text(" that will make it a combinatorial line.)")

#text("Counting Problem B: How many of those sets have exactly two pairs form partial combinatorial lines?")

#text("Counting Problem C: How many of those sets have exactly one pair form a partial combinatorial line?")

#text("Counting Problem D: How many of those sets have no pairs form a partial combinatorial line?")

#text("I have made progress on B by making a “fake wildcard” (using the symbol #). For example, take a sequence like *#212. Given x = both wildcards set at 1 (11212) then y = 21312 or 31312 and z = 12312 or 13312. Repeat this for all possible wildcard settings, remove all duplicates, and all sequences ..212 are accounted for.")

#text("Then it just is a matter of counting how many possible settings it is with both * and # wildcards and removing duplicates from there (*#212 will yield the same results as #*212), and problem B is solved. But that’s a messy calculation so I wanted to share here my current progress before I went any farther. (Also someone might point out where we have the solution to this already 600 posts back.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36157")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2009")])]

#text("769. The 18 points with 2 2’s in the 2**** slot will produce 18 points")#linebreak()#text(" with 3 2’s in the total configuration moreover they will all have")#linebreak()#text(" 2’s in one coordinate x(the one in which the point with 4 2’s has")#linebreak()#text(" a coordinate not equal to 2. These 18 points will have 36")#linebreak()#text(" coordinates not equal to 2 among the four coordinates not equal")#linebreak()#text(" to x but that means there must be at least 9 coordinates")#linebreak()#text(" not equal to 2 at one of these coordinates. A majority of these coordinates")#linebreak()#text(" must be equal to a value not equal to 2 without loss of generality say 1")#linebreak()#text(" then at most six of these points can be equal to 1 since the ramaining")#linebreak()#text(" coordinate not equal to 2 can take one of two values at the remaining")#linebreak()#text(" 3 coordinates giving a total of 6. thus we have one coordinate with")#linebreak()#text(" three 1’s and three 3’s among the 18 triples. Then we slice at this coordinate")#linebreak()#text(" the 3 triples of two in the one and three block makes these slices have")#linebreak()#text(" size 41 the point with four twos becomes a point with three twos in")#linebreak()#text(" the 2 slice thus forcing it to have value 42 or less so the sum is 124.")#linebreak()#text(" Thus if there is one point with four 2’s the value is 124 or less.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36158")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2009")])]

#text("770. Moser(3)")

#text("Kristal: thanks! I wrote up your argument on the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Moser%27s_cube_problem")[#text("wiki page")]#text(". In fact the argument shows that any 125-point Moser set cannot have 43 points in its 2**** slice, and in fact cannot have 42 points either unless it is one of the eight anomalous (a,b,c,d,e) = (6,24,12,0,0) solutions at that level.")

#text("If we can eliminate those anomalous solutions, it implies that 125-point Moser sets must always have their thin slice in the middle, i.e. they must slice as 43+39+43, 43+40+42, 42+40+43, or 42+41+42.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36165")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2009")])]

#text("771. Moser(3)")

#text("One solution of the (6,24,12,0,0) set is made of the following slices.")#linebreak()#text(" the other solutions would be reflections in one or more axes")

#mi("\\Gamma_{220}+\\Gamma_{202}+\\Gamma_{022}+\\Gamma_{112}+\\Gamma_{211}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36171")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2009")])]

#text("772. Moser(3)")

#text("Terry, in your writeup of Kristal’s proof, you said that any solution with d>2 had at most 40 points. From reading this blog and the wiki, I can only tell that such a solution has at most 41 points. What have I missed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36174")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2009")])]

#text("773. Oops, you’re right, which means that my strengthening of Kristal’s argument doesn’t quite work (at least for the problem of getting the bound 124 on the nose; it still works if one just wants to prove ")#mi("c^{\\prime}_5 \\leq 125")#text("). I’ve readjusted the wiki appropriately.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36182")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2009")])]

#text("774. Strategy for Moser(3)")

#text("I think we have a decent shot at pushing the upper bound for ")#mi("c^{\\prime}_5")#text(" (currently at 127) all the way down to the lower bound of 124. The idea is to exploit the numerically observed phenomenon that large four-dimensional slices (particularly those with 42 and 43 points) tend to have very large “c” values (points with two 2s) but very low “d” values (points with three 2s). In particular, middle slices such as 2**** (if large) tend to have large “c”, and side slices such as 1**** or 3**** tend to have small “d”.")

#text("But (as implicitly observed in Kristal’s argument) one middle slice’s “c” is another side slice’s “d”. For instance, if the 2xxxx slice contains an element with two additional 2s, e.g. 21223, then this contributes a “d” point to the side slices *1*** and ****3. More generally, double counting tells us that the total “c”‘s of all the five middle slices put together, is equal to 3/2 times the total “d”s of all the ten side slices put together. By the pigeonhole principle, there must therefore exist one coordinate such that the “c” of the middle slice of that coordinate is at most 3/2 the sum of the “d” of the two side slices of that coordinate. Without loss of generality we may assume this is the first coordinate; thus")

#text("c(2****) <= 3/2 [ d(1****) + d(3****) ] (1)")

#text("where I use c(2****) to denote the “c” count of the 2**** slice (i.e. the number of points in this slice with two additional 2s), etc.")

#text("The listing of 43 and 42-point slices tells us that for such slices, c is at least 12 and d is at most 2. Comparing this with (1) we already see that not all slices can have 42 or more points, which already recovers our existing upper bound of 127=43+43+41. But I think we can do better. Firstly, it seems that having a lot of “d”s really does push down the total size of a slice. In the extreme case, if d is equal to its maximal value of 8, then it is easy to see that c is at most 12, b is at most 8 (note for instance that at most one of 2111, 2133, 2313, 2331 can lie in the set if every point with 3 2s lie in the set), and a is at most 8, leading to only 36 points.")

#text("Conversely, if c is really small (and d=e=0, which we know to be true for the middle slice), this also pushes down the size of a slice. For instance, in the extreme case when c=0, the bound b+4a <= 64 (coming from double counting lines such as 1111, 1112, 1113) and the trivial bound b <= 32 gives at most 40 points in the slice.")

#text("I’m hopeful that if we get good enough upper bounds on the size of slices for various small values of c or large values of d, we should be able to solve the problem. (For comparison, in the 124-point examples given in 736, the middle slice is (8,32,0,0,0) (thus c=0) and the side slices are (1,16,24,0,0), (2,16,24,0,0) or (3,16,24,0,0) (thus d=0).)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6aee136dbc4c0bc79c68cbcf7d17f526cce6319a8e6e98ec412127af7d47f3a8-376867c974a73315b8452903740c9fc3635e43fe0fc86f758644077298bb8a0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Elsholtz")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36188")[#strong[#text("Christian Elsholtz")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2009")])]

#text("775 Moser:")#linebreak()#text(" I have typed some notes (to use Latex) and have put them here:")

#link("http://www.ma.rhul.ac.uk/~elsholtz/WWW/blog/mosertablogv01.pdf")[#text("Click to access mosertablogv01.pdf")]

#text("This contains two parts:")#linebreak()#text(" 1) A human proof that a Moser set in dimension 3 with centre point 222 contains at most 13 points. Earlier proved by KS Chua 766 (by computer).")

#text("2) A sketch to prove that in dimension 4 a Moser set with centre 2222 contains at most 39 points. Proved earlier by Terry in 767.")#linebreak()#text(" Essentially I proved that the two missing pairs of antipodal points must be included")#linebreak()#text(" in sets of the form 22xy or xy22, which means I have localized them somewhat. possibly one can squeeze more of the argument.")

#text("Is there actually a set with 39 points? (those computer programmes that classified the")#linebreak()#text(" Moser sets with 43 points can possibly be adapted).")

#text("Perhaps the arguments prove useful for the discussions on dimension 5.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36195")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2009")])]

#text("We can show that any line free configuration")#linebreak()#text(" Has 126 or less points")

#text("If there is a 42 or 43 in the center")#linebreak()#text(" Then the value is 125")#linebreak()#text(" Case 1")#linebreak()#text(" There are 17 or more points with 3 2’s and two 1 or 3’s one coordinate has all")#linebreak()#text(" 2’s the 34 or more non two coordinates are divided among")#linebreak()#text(" four coordinates one must contain 9 or more but at most six can have")#linebreak()#text(" the one value so there will be at least three points with value one and")#linebreak()#text(" three with value 3 at that coordinate we slice at that coordinate")#linebreak()#text(" and get the slices associated with one and three")#linebreak()#text(" having three or more points with three 2’s and hence")#linebreak()#text(" having 41 points or less thus the value is 41 + 41 +43")#linebreak()#text(" Case 2 there is one remaining anamolous case which from")#linebreak()#text(" Note 771 contains")#linebreak()#text(" all points with two coordinates equal to")#linebreak()#text(" 2 and two points equal to one of the values 1 or three")#linebreak()#text(" then the set of points 1122 1212 1221 3322 3232 3223 which is in every configuration of this case has three points")#linebreak()#text(" with value 1 and three with value 2 which have two twos in the center slice")#linebreak()#text(" and hence three 2’s overall we can slice at this coordinate and get by similar reasoning")#linebreak()#text(" to the above the two noncenter cubes having 41 points or less and hence")#linebreak()#text(" the entire configuration having 125 points or less")

#text("Now we assume we have a line free configuration with 127 points")#linebreak()#text(" Center must be 41")#linebreak()#text(" Then other two edges must be 43")#linebreak()#text(" Next we note that if the center slice")#linebreak()#text(" contains no point with 2 or more 2’s it must have 40")#linebreak()#text(" points or less and we are done")#linebreak()#text(" we use the inequality")#linebreak()#text(" ")#mi("2\\alpha_i + \\alpha_j \\leq 2")#linebreak()#text(" for i less than j")#linebreak()#text(" mentioned in 759 for the center cube for i = 0")#linebreak()#text(" and j =1. Then it implies that a center slice")#linebreak()#text(" with no points with 2 or more twos can have at most")#linebreak()#text(" 40 points. Now using the above")#linebreak()#text(" any configuration with 127 or more points")#linebreak()#text(" must have a slice in the center with 41 points or less")#linebreak()#text(" and also its center slice must contain at least one point with")#linebreak()#text(" two twos in the coordinates of the slice and three overall")#linebreak()#text(" (or else we have 43 + 43 +40 points and that is less than 127")#linebreak()#text(" and we are done) that slice must have one coordinate not equal")#linebreak()#text(" to 2 or else the configuration will have less than 127 points")#linebreak()#text(" we can slice along that coordinate and get one of the non-center")#linebreak()#text(" slices having a point with three coordinates equal to 2 and thus")#linebreak()#text(" having value less than or equal 42 now by the above the center slice")#linebreak()#text(" is 41 or less and we have less than 127 points at most 41 + 42")#linebreak()#text(" +43 is 126 points")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36197")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2009")])]

#text("777. Moser(3)")

#text("Thanks, Kristal! Now we are down to ")#mi("124 \\leq c^{\\prime}_5 \\leq 126")#text(". I’ve written up your proof on the wiki.")

#text("Christian: Thanks for the human proof of these facts; it is good to have independent confirmation of these things. I’ve also linked your notes to the wiki.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57785d9b4bc8e25821f692ee3d435bb796adfed7394ad4ed0e523e2ca28c2248-7fa311f9e8852af89c8f8bbee0f6630fd2a26ed5a470dbfc0120dfbb7d2d752e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KS Chua")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36203")[#strong[#text("KS Chua")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2009")])]

#text("778 Moser(3)")

#text("Here is a Moser set containing (2222) of size 36.")#linebreak()#text(" 0,2,3,5,7,9,11,15,17,19,21,23,24,26,27,29,33,35,36,38,40,")#linebreak()#text(" 41,46,48,50,52,55,58,60,62,64,66,68,70,76,79")

#text("It seems the upper bound of 39 is too high.")#linebreak()#text(" One can classify 13-point Moser containg (222) and 12 points.")#linebreak()#text(" Call a point odd if the sum of coordinates in (123-form) is odd and even")#linebreak()#text(" otherwise. Then the omitted antipodal must be odd ie. the omitted point is")#linebreak()#text(" either the corner or center of a side slice or the complement of this in the")#linebreak()#text(" middle slice.")

#text("If there are only 2 omitted points in [3]^4 Moser with center. They must together account for the four 2 in the center slices. The above rule out")#linebreak()#text(" the case when both have two 2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36216")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2009")])]

#text("779. Moser(3)")#linebreak()#text(" After waiting for some fre time on a Linux-cluster I have now constructed the 41 point solutions. There are quite a few of them, 2 765 200.")#linebreak()#text(" Here are the statistics for the number of 2:s")

#link("http://abel.math.umu.se/~klasm/Moser-41-stat.pdf")[#text("Click to access Moser-41-stat.pdf")]

#text("and here are the solutions.")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/solutions-4-t=3-41-moser.gz")[#text("http://abel.math.umu.se/~klasm/solutions-4-t=3-41-moser.gz")]#linebreak()#text(" In order to make thing more compact each point is now given by its number in the lexicografic ordering and solutions are separated by a line with a single “Y”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36217")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2009")])]

#text("780 Moser (3).")

#text("Thanks Klas! Scanning through the statistics, I see two things which look quite encouraging:")

#text("1. d is always small; the largest value of d among any 41-point set is at most 3 (and in fact is at most 2, with just one family of 256 exceptions).")

#text("2. c is usually large. There are 16 anomalous solutions with c=6 (which are worth taking a closer look at), but everyone else has c at least 11.")

#text("Inserting this into my equation (1) from 774, we see that not all of the three slices here can have 41 or more points, unless the middle slice is one of the 16 anomalous c=6 solutions, and in the latter case the other two slices can’t have 43 points (because then they won’t contribute enough d’s to (1)). Unfortunately this is not enough to improve the 126 upper bound because of the 43+40+43 and 40+43+43 cases, but we understand the 43 point slices pretty well and so perhaps we can do something else to eliminate these cases also. For instance, if (1) holds and we are in the 43+40+43 case then d(1****)=d(3****)=0 and so c(2****)=0, which forces b(2****)=32 and a(2****)=8, which is looking pretty incompatible with the 43-point slices, though I cannot rule them out completely yet.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36224")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2009")])]

#text("781. Moser(3)")#linebreak()#text(" I let a script run during the evening to pick out some of the more interesting solutions. The flies are in the original format.")

#text("Here are the solutions with c=6")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/moser-n=3-t=3-41-c=6.gz")[#text("http://abel.math.umu.se/~klasm/moser-n=3-t=3-41-c=6.gz")]

#text("Here are the solutions with d=1")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/moser-n=3-t=3-41-d=1.gz")[#text("http://abel.math.umu.se/~klasm/moser-n=3-t=3-41-d=1.gz")]#linebreak()#text(" the solutions with d=2")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/moser-n=3-t=3-41-d=2.gz")[#text("http://abel.math.umu.se/~klasm/moser-n=3-t=3-41-d=2.gz")]#linebreak()#text(" the solutions with d=3")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/moser-n=3-t=3-41-d=3.gz")[#text("http://abel.math.umu.se/~klasm/moser-n=3-t=3-41-d=3.gz")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36241")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2009")])]

#text("Did my posting of the low-c solutions just get stuck in the spam filter or did it disappear? ")#emph[#text("[It got stuck in the spam filter – I think any comment which has too many hyperlinks in it gets flagged as spam. I’ve fished it out. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36246")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2009")])]

#text("782. Any line free configuration has 125 or less points.")

#text("The center slice is less than 42 because we have shown that a center slice of 42 or more means a total of 125 points or less.")

#text("The center slice is 40 or more since if it is 39 or less the total is at most 125.")

#text("Then the center is 40 or 41 and we have two cases with the center 40 or 41 and the sum 125")#linebreak()#text(" 43 40 43")#linebreak()#text(" 43 41 42")#linebreak()#text(" let us first look at the case in which the center is 41.")

#text("Now this must have a point p with 3 2’s in the center slice since 4a + b must be less than")#linebreak()#text(" 64 and b must be 32 or less so if it is not then there are only 40 points in the center")#linebreak()#text(" slice. Then we can slice on one of the coordinates of p not equal to two")#linebreak()#text(" and get a non-center cube with 42 points with a point with with three twos or a point a non-center")#linebreak()#text(" cube with 41 points which together with the center cube in the new slice")#linebreak()#text(" which must have 41 points gives a total of 125 or less 41 43 or 41 41 43 but this 125 and we are done.")#linebreak()#text(" So we must have a side cube with 42 points and two points with three two’s")#linebreak()#text(" and I have checked all cases of these 42 point configurations")#linebreak()#text(" they are available at ")#link("http://abel.math.umu.se/~klasm/moser-n=4-42-e=2")[#text("http://abel.math.umu.se/~klasm/moser-n=4-42-e=2")]#linebreak()#text(" and in each case the two points with three twos have a coordinate at which one point has a one and the other a three")#linebreak()#text(" so we can slice at this coordinate and we get two noncenter cubes that must have at least one point with")#linebreak()#text(" three coordinates equal to 2 and hence the these two cubes")#linebreak()#text(" must have value 42 or less and since the center cube has value")#linebreak()#text(" 41 we have a total of 125 and we are done with this case.")

#text("the only case left is one in which the center is 40 and the remaining cubes")#linebreak()#text(" are 43 now we divide this into two cases")#linebreak()#text(" first the center contains a point with two threes")#linebreak()#text(" then we can cut at a coordinate at which this point is not two")#linebreak()#text(" and force the case 43 41 42 which we have just done.")

#text("now it must a 43 40 43 division must occur in every slice")#linebreak()#text(" or we are back to the previous case")#linebreak()#text(" since 4a + b must be less than")#linebreak()#text(" 64 and b must be 32 or less")#linebreak()#text(" we must have all 32 points with one two must be in the center slice")#linebreak()#text(" and all 32 points must be in all center slices so")#linebreak()#text(" we must have all points with exactly two coordinates equal to 2 in the configuration.")

#text("Now we note that in the division of the configuration into cubes with each cube corresponding to a fixed choice")#linebreak()#text(" of the first two coordinates we have the following all the points with first two coordinates equal to")#linebreak()#text(" one of 1 or 3( there are four of these) must have the center cube occupied hand hence by must have 13 or less see post 775")#linebreak()#text(" points the center cube can only have 8 points as the remaining points have 3 or more twos, the remaining cubes")#linebreak()#text(" can have at most 16 points this gives a total of 4*13 + 8 +4*16 = 124 and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36248")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2009")])]

#text("783. Moser(3)")

#text("Kristal, I’ve written up most of your proof on the wiki, but I had trouble with the last paragraph. I agree that the only case left is when all slices are 43+40+43, and that the 126-point set contains every point with two 2s, and no point with three or more 2s. But I don’t think that this implies that the corner slices 11***, 13***, 31***, 33*** contain their center. Instead, they seem to contain all six points with two 2s, and perhaps half of the 12 points with one 2 and at most 2 of the 8 points with no 2s (because we can divide these 8 points into two quadruplets ***=111,133,313,331 and ***=333,311,131,113, each of which can have at most one point), leading to as many as 14 points which is not quite good enough.")

#text("We are beginning to brush up against the sphere packing problem that Michael observed back in 737, 738. Once we have all of the 80 points in ")#mi("[3]^5")#text(" with exactly two 2s, we have at most 40 of the 80 points with one 2, and we have to show that there are at most 4 points (or 5 points, if one is willing to settle for the 125 upper bound) remaining amongst the 32 points with no 2s. Note that any two points in this final component cannot differ in exactly two positions, but they may possibly differ in one position, so it isn’t quite a classical sphere packing problem here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36250")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2009")])]

#text("784. Moser(3)")

#text("If all 80 points with two 2s are included, then at most 4 points from ")#mi("{}[1,3]^5")#text(" can be chosen.")#linebreak()#text(" Two of these have an even number of 1s, and two have an odd number.")

#text("Suppose 11111 is one of the points. All points with two 3s are excluded, so the only points allowed with an odd number of 1s are those with four 3s. But all those points differ from each other in two positions, so at most")#linebreak()#text(" one of them is allowed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36251")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2009")])]

#text("785. Moser(3)")

#text("Thanks Michael! I’ve completed the proof of the 125 upper bound on the wiki. Only one more improvement left before we pin down ")#mi("c^{\\prime}_5")#text(" exactly…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36277")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2009")])]

#text("786. ")#mi("\\overline{c}^\\mu_6 < 18")

#text("First note that there are eight extremal solutions to ")#mi("\\overline{c}^\\mu_3")#text(":")

#text("Solution I: remove 300, 020, 111, 003")#linebreak()#text(" Solution II: remove 030, 111, 201, 102")#linebreak()#text(" Solution III (and 2 rotations): remove 030, 021, 210, 102")#linebreak()#text(" Solution III’ (and 2 rotations): remove 030, 120, 012, 201")

#text("Also consider the same triangular lattice with the point 020 removed, making a trapezoid. Solutions based on I-III are")#linebreak()#text(" Solution IV: remove 300, 111, 003")#linebreak()#text(" Solution V: remove 201, 111, 102")#linebreak()#text(" Solution VI: remove 210, 021, 102")#linebreak()#text(" Soltuion VI’: remove 120, 012, 201")

#text("Suppose we can remove all equilateral triangles on our 7x7x7 triangular lattice with only 10 removals.")

#text("The triangle 141-411-114 must have at least one point removed. Remove 141, and note because of symmetry any logic that follows also applies to 411 and 114. (1 removal total)")

#text("There are three disjoint triangles 060-150-051, 240-231-330, 042-132-033, so each must have a point removed.")

#text("(Now only six removals remaining.)")

#text("The remainder of the triangle includes the overlapping trapezoids 600-420-321-303 and 303-123-024-006.")#linebreak()#text(" If the solutions of these trapezoids come from V, VI, or VI’, then 6 points have been removed.")#linebreak()#text(" Suppose the trapezoid 600-420-321-303 uses the solution IV (by symmetry the same logic will work with the other trapezoid). Then there are 3 disjoint triangles 402-222-204, 213-123-114, and 105-015-006. Then 6 points have been removed.")#linebreak()#text(" Therefore the remaining six removals must all come from the bottom three rows of the lattice.")

#text("Note this means the “top triangle” 060-330-033 must have only four points removed so it must conform to solution either I or II, because of the removal of 141.")

#text("Suppose the solution of the trapezoid 600-420-321-303 is VI or VI’. Both solutions I and II on the “top triangle” leave 240 open, and hence the equilateral triangle 240-420-222 remains. So the trapezoid can’t be VI or VI’.")

#text("Suppose the solution of the trapezoid 600-420-321-303 is V. This leaves an equilateral triangle 420-321-330 which forces the “top triangle” to be solution I. This leaves the equilateral triangle 201-321-222. So the trapezoid can’t be V.")

#text("Therefore the solution of the trapezoid 600-420-321-303 is IV.")

#text("Since the disjoint triangles 402-222-204, 213-123-114, and 105-015-006 must all have points removed, that means the remaining points in the bottom three rows (420, 321, 510, 501, 312, 024) must be left open. 420 and 321 force 330 to be removed, so the “top triangle” is solution I. This leaves triangle 321-024-051 open, and we have reached a contradiction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36287")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2009")])]

#text("787. Any Moser set with at least 42 points in the middle slice has at most 124 points.")

#text("There are two cases one the c value of the middle slice is 17 or more.")#linebreak()#text(" Then these points have 34 or more coordinate values not equal to 2 divided")#linebreak()#text(" among four coordinates one of these must have 9 of these coordinates")#linebreak()#text(" at most six of these can have value 1 or 3 thus at least 3 must be 3 and three must be one and also there must be more than 5 of either one or three. Now we slice at this coordinate then both slices have three points with three coordinates equal to 2. Then they must have at most 41 points.")#linebreak()#text(" Now since the most points with three coordinates equal to 2 in a slice")#linebreak()#text(" of 41 is 4 and we have one slice with 5 or more of these points that slice")#linebreak()#text(" must have at most 40 points. Now since one slice is of size 40 or less the other")#linebreak()#text(" 41 or less and the remain slice trivially has 43 or less we have at most 124 points.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36298")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("788. HOC(3)")#linebreak()#text(" I have now found the extremal solutions for the weighted problem in the hyper-optimistic conjecture, again using integer programming.")#linebreak()#text(" The first few values are")#linebreak()#text(" c^{\\mu}_2=4 with 3 solutions")#linebreak()#text(" c^{\\mu}_3=6 with 9 solutions")#linebreak()#text(" c^{\\mu}_4=9 with 1 solution")#linebreak()#text(" c^{\\mu}_5=12 with 1 solution")

#text("The solution for n=5 is here")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/solutions-n=5-k=3-HOC")[#text("http://abel.math.umu.se/~klasm/solutions-n=5-k=3-HOC")]

#text("The solution for n=4 is here")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/solutions-n=4-k=3-HOC")[#text("http://abel.math.umu.se/~klasm/solutions-n=4-k=3-HOC")]

#text("I’ll see if I can do n=6 as well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36299")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("789 HOC(3)")

#text("The solutions for n=3 are here")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/solutions-n=3-k=3-HOC")[#text("http://abel.math.umu.se/~klasm/solutions-n=3-k=3-HOC")]

#text("The solutions for n=2 are here")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/solutions-n=2-k=3-HOC")[#text("http://abel.math.umu.se/~klasm/solutions-n=2-k=3-HOC")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36302")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("790. A super-optimist conjecture")

#text("For ")#mi("n > 2")#text(", ")#mi("c^\\mu_n = \\overline{c}^\\mu_n = 3(n-1)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/38e8f69d6f200ee7243740ac5e87467d31fa8d1b3433679eaa873036c5867abd-e0f53db03691d9f66957e2526706a7bef9a028f55bdd056514cf9226eaf5d615.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marc")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36303")[#strong[#text("Marc")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("791. ")#mi("\\bar{c}^\\mu_{10} \\ge 29")

#text("028,046,055,064,073,118,172,181,190,208,217,235,262,")#linebreak()#text(" 316,334,352,361,406,433,442,541,550,604,613,622,")#linebreak()#text(" 721,730,901,1000")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36309")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("792. ")#mi("\\bar{c}^\\mu_10")

#text("Well, *that* was a short-lived conjecture. (re: Marc.791 in response to Dyer.790 — I just confirmed, and changed the spreadsheet) Was that done with random fiddling or was there a method?")

#text("Also I would like to remind people of the optimist conjecture in ")#link("http://gowers.wordpress.com/2009/02/23/brief-review-of-polymath1/#comment-2405")[#text("Jakobsen.813")]#text(", which seems quite (well, moreso than other things) reasonable to prove.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36310")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("793. Various")

#text("A lot of progress! I will have to start a new thread soon, this one is being used up.")

#text("Kristal: it seems the second case (when c(2****) < 17) is missing from your 787. I’ve tentatively updated Lemma 2 on the wiki to reflect this improved bound, but we’ll need to check that second case.")

#text("Assuming this improvement, it means that 125-point Moser sets have at most 41 points in the middle slice, which forces them to have at least 41 points in the side slices. This is good news, because we’ve got a computer list of all of these points. In fact I have the following strategy to propose. We know that a 125-point Moser set does not contain 22222, and so all the points in the Moser set are contained in at least one side slice. More precisely, points with four 2s are contained in one side slice, points with three 2s are contained in two side slices, and so forth up to points with no 2s, which are contained in five side slices. Double-counting this fact, we see that")

#text("125 = sum_S a(S)/5 + b(S)/4 + c(S)/3 + d(S)/2 + e(S)")

#text("where S ranges over the 10 side slices. Dividing the side slices into five pairs (1****,3****), etc., and using the pigeonhole principle, we may thus assume without loss of generality that")

#text("a(1****) + 5 b(1****)/4 + 5 c(1****) / 3 + 5 d(1****) / 2 + 5 e(1*****)")

#text("and")

#text("a(3****) + 5 b(3****)/4 + 5 c(3****) / 3 + 5 d(3****) / 2 + 5 e(3*****)")

#text("sum to at least 125.")

#text("Now, we know (contingent on Kristal’s lemma) that the 1**** and 3**** slices have at least 41 points. On the spreadsheet")

#link("http://spreadsheets.google.com/ccc?key=p5T0SktZY9DuqNcxJ171Bbw&hl=en")[#text("http://spreadsheets.google.com/ccc?key=p5T0SktZY9DuqNcxJ171Bbw&hl=en")]

#text("I’ve computed a+5b/4+5c/3+5d/2+5e for the 43 and 42-point solutions. Encouragingly, the largest this quantity is is 63, and almost all of these numbers are less than 62; only the (4,16,23,0,0), (3,16,24,0,0), (4,15,24,0,0), (2,16,24,0,0) configurations are 62 or higher. I haven’t entered in the 41-point data but I would assume the quantity is smaller than 62 in all those cases. If so, that pins down the 1**** and 3**** slices quite precisely, and I would hope that this gets us close to finishing off the problem.")

#text("Klas: Great! I’ve updated the hyper-optimistic conjecture page and the spreadsheet to reflect your new data. Thus far the HOC is holding up very nicely, we’ve verified it up to n=5. If we get n=6 for either c^\\mu_n or \\overline{c}^\\mu_n then it might be time to send this sequence to the OEIS also. (The latter sequence is an integer sequence, and if HOC is true, the former is also.)")

#text("Marc: I’ve added your example to the wiki and spreadsheet too. Looks like Jason’s super-optimistic conjecture didn’t make it, unfortunately.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36311")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("794. HOC")#linebreak()#text(" From the comment in the wiki on using Behrend sets we have a super-linear lower bound for Fujimuras problem. So the nice pattern behind the super-optimistic conjecture is a small n effect.")

#text("The HOC for n=6 seems a lot harder than the previous cases but I’ll see what I can do.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36313")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("795. Moser(3)")

#text("I’ve updated the Moser spreadsheet,")

#link("http://spreadsheets.google.com/ccc?key=p5T0SktZY9DuqNcxJ171Bbw&hl=en")[#text("http://spreadsheets.google.com/ccc?key=p5T0SktZY9DuqNcxJ171Bbw&hl=en")]

#text("to input the 41-point data, and as expected the “score” a+5b/4+5c/3+5d/2+5e never reached 62 (though the anomalous d=3 solution got close, at 61.5). Assuming Kristal’s lemma, this implies that there is a coordinate whose two side slices have one of the following statistics:")

#text("* (4,16,23,0,0) [score: 62 1/3]")#linebreak()#text(" * (3,16,24,0,0) [score: 63]")#linebreak()#text(" * (4,15,24,0,0) [score: 62 3/4]")#linebreak()#text(" * (2,16,24,0,0) [score: 62]")

#text("and furthermore the total score must add up to at least 125. (For comparison, in the known 124 point example, the side slices have statistics (3,16,24,0,0), (2,16,24,0,0), or (1,16,24,0,0), with scores 63, 62, and 61 respectively.) This looks like quite a bit of information with which one can work with.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36319")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("We have already shown that if")#linebreak()#text(" the center slice is 42 or 43 and it has")#linebreak()#text(" 17 or more points then there at most 124.")

#text("Case 2")

#text("The center slice is 42 c less that 17")#linebreak()#text(" Then we must have c is 12")#linebreak()#text(" And we must have on of the 8")#linebreak()#text(" (6, 24, 12, 0, 0) sets.")#linebreak()#text(" without less of generality")#linebreak()#text(" we can assume it to be ")#mi("\\Gamma _{220}+\\Gamma _{202}+\\Gamma _{022}+\\Gamma _{112}+\\Gamma _{211}")#linebreak()#text(" In particular the middle slice")#linebreak()#text(" Contains the points")#linebreak()#text(" 2122 21212 21221")#linebreak()#text(" 23322 23232 23223 and the *1*** and *3*** slices")#linebreak()#text(" have a d value of at least three and so have at most")#linebreak()#text(" 41 points now if the center slice is 42 we have 124 points")#linebreak()#text(" and we are done so it must be 43 but then it has value 18 or more")#linebreak()#text(" and and by case 1 we have 124 points or less so we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DHJ(3): 900-999 (Density Hales-Jewett type numbers) « What’s new")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-2/#comment-36322")[#strong[#text("DHJ(3): 900-999 (Density Hales-Jewett type numbers) « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("[…] Hales-Jewett, Moser cube problem, polymath1 | by Terence Tao This is a continuation of the 700-799 thread of the polymath1 project, which is now full. During the course of that thread, we have made […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0370d1a896797a6c35d6dcfd44d6754e09ccd8bbc0700b42d12133888202801f-a1c7c2ca13b5ac992b05a7c9dda2638098396ea50fd31bf4c95069b66ad37a4a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Sauvaget")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35807")[#strong[#text("Thomas Sauvaget")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("700. bound on ")#mi("c_5")#text(", then on ")#mi("c_n")

#text("in order not to burden this thread I’m inviting any other attempts along the lines of 275 to be discussed at:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://thomas1111.wordpress.com/2009/02/14/a-proof-that-c_5154/")[#text("A proof that c_5=154 (?)")]
]

#text("and if things work out we’ll report a brief summary back here and in the wiki, after the (possibly longish) trial/error period. Currently I’ve found a new pattern for ")#mi("c_5")#text(" which requires independent confirmation/infirmation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35809")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("701. bound on ")#mi("c_5")#text(".")

#text("By the way, one cautionary note: I think any line-free subset of the 162-element set ")#mi("D_5 = \\{ x_1 x_2 x_3 x_4 x_5: x_1+\\ldots+x_5 \\neq 0 \\text{ mod } 3 \\}")#text(" must have at most 150 points. Proof: one can view ")#mi("D_5")#text(" as ")#mi("{}[3]^5")#text(" with ")#mi("\\Gamma_{(a,b,c)}")#text(" deleted for the triples ")#mi("(a,b,c) = (0,0,5), (1,1,3), (2,2,1), (0,3,2), (1,4,0), (3,0,2), (4,1,0)")#text(". From the triples ")#mi("(5,0,0), (2,0,3), (2,3,0)")#text(" one more point needs to be deleted, and similarly for ")#mi("(0,5,0), (2,0,3), (0,3,2)")#text(". Meanwhile, from the triples ")#mi("(4,0,1), (1,0,4), (1,3,1)")#text(" five more points need to be deleted, and similarly for ")#mi("(0,4,1), (0,1,4), (3,1,1)")#text(", leading to at most 150 points overall.")

#text("at least one point needs to be deleted from")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35842")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("702. Lower bound for Moser’s cube")

#text("The following set gives a lower bound of ")#mi("n(n+1)2^{n-3}")#text(" points for Moser’s cube:")

#text("Take all points with two 2s, and all those with one 2 and an odd number of 1s.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35843")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("703. Lower bound for Moser’s cube")

#text("Should the asymptotic lower bound for Moser’s cube be ")#mi("12^{n/3}/\\sqrt{n}")#text(" ?")

#text("Now that I’ve read the page on Moser’s cube, you can take all points with q 2s, and all those with q-1 2s and an odd number of 1s, to give ")#mi("\\binom{N+1}{q}2^{N-q}")#text(" points, where q is the nearest integer to N/3")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35844")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("704. Lower bound for Moser’s cube")

#text("Dear Michael, I think Stirling’s formula will show that ")#mi("\\binom{N+1}{q} 2^{N-q}")#text(" is roughly ")#mi("3^N / \\sqrt{N}")#text(". (One can also see this from the binomial formula ")#mi("3^{N+1} = \\sum_{q=0}^{N+1} \\binom{N+1}{q} 2^{N-q+1}")#text(" and the law of large numbers, which shows that the bulk of the sum comes from the region ")#mi("q = N/3 + O(\\sqrt{N})")#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35847")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2009")])]

#text("705. Bounds for ")#mi("c^{\\prime}_n")

#text("Oh, I see. Thanks.")

#text("I think I can squeeze in some more points with N/6-1 1s, and N/6 2s,")#linebreak()#text(" but they will be relatively few.")

#text("BTW it must be a quarter century since we last met, at Vern’s classes.")#linebreak()#text(" I’m delighted to be in this, which is sort of one of your classes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35853")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2009")])]

#text("706. The value of c_5 is 150")

#text("I formulated the problem as an integer programing instance and solved it using some of my linear programming tools. The program quickly finds a solutions with 150 points and then reduces the upper bound to 150 in less than 2 minutes")

#text("My program correctly gives the known values for the lower c_n and the correct number of solutions for them as well.")

#text("There are 12 different extremal configurations for c_5.")

#text("I have started a run for c_6")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35862")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2009")])]

#text("707. ")#mi("c_5")

#text("Klas, that’s quite impressive! (For comparison, the fact that ")#mi("c^{\\prime\\prime}_6 = 112")#text(" took some time to be done by hand.) It would be great if some data or source code for the run could be made available somewhere (e.g. on the wiki).")

#text("The Moser number c’_5 might also be in reach now (it is somewhere between 120 and 129, according to the spreadsheet). [By the way, to the anonymous contributor of the lower bounds for the Moser problem: if you could describe the examples either here or on the wiki page for the Moser problem, that would be great!]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35865")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2009")])]

#text("708. If c_5 is 150 than if the spreadsheet is correct c_6 is 450. Clearly")#linebreak()#text(" c_6 is less than or equal to 3 times c_5 and we have a lower bound")#linebreak()#text(" of 450 so that forces c_6 to be 450. c_7 is between 1302 and 1350 since we have a lower bound of 1302 and by the same reasoning 3 times 450 is")#linebreak()#text(" 1350.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35866")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2009")])]

#text("709. A052979 was the last sequence in the OEIS which might have been equal to the sequence c_n but the two sequences diverge if c_5 equals 150.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35868")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2009")])]

#text("710. I’ve provisionally updated the spreadsheet to reflect the upper bound for ")#mi("c_5")#text(". (It seems consistent with the difficulties Thomas has been experiencing in trying to improve the lower bound below 150.) If we have a complete list of all the extremisers for ")#mi("c_5")#text(", then it looks likely that one will be able to shave a couple points off of the upper bound 1350 from ")#mi("c_7")#text(", though it seems rather unlikely that we will be able to close the gap with the lower bound of ")#mi("1302")#text(" without a massive computational effort. Still, this is much more of the sequence ")#mi("c_n")#text(" computed than I would have initially thought possible, if it all checks out…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35869")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2009")])]

#text("711. c_5")

#text("Terry, I can upload the file with the linear program in a standard format which can be read by e.g. the open source linear programing solver glpk from gnu.")#linebreak()#text(" The integer programing formulation is quite simple. One 0/1-variable for each point in the cube, and one linear inequality for each combinatorial line.")

#text("I have a file with the 12 extremal sets for c_5 which I can also upload.")

#text("I am running the c_6 case to see if I can find the extremal sets there too, but it is considerably harder and I have moved it to a linux cluster where it will run over night. (It’s now late in the evening in Sweden)")

#text("I did a quick check for the Moser-problem and it seem less well suited for integer programing. I could quickly verify the value of 43 for n=4, but for n=5 the integer gap is much larger than it was for c_5, and that means that it will take a lot longer to run. But I can give it a try later.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35870")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2009")])]

#text("712. ")#mi("c_6")

#text("If ")#mi("c_5 = 150")#text(", then as noted in 708, ")#mi("c_6=450")#text(" and so every ")#mi("c_6")#text(" extremiser is formed from three ")#mi("c_5")#text(" extremisers. If there are only 12 ")#mi("c_5")#text(" extremisers, then one should be able to fairly quickly exhaust the ")#mi("12^3=1728")#text(" combinations to find all the ")#mi("c_6")#text(" extremisers. (There are also some symmetries of the problem that might be deployable to cut down the search space by a factor of 6 or so.)")

#text("It may also be possible to get the computer to classify near-extremisers, e.g. 149-element line-free subsets of ")#mi("[3]^5")#text(". This may then be able to lower the upper bound of ")#mi("c_7 \\leq 1350")#text(" somewhat.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35874")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2009")])]

#text("713. Lower bounds for Moser cubes")

#text("Dear Terry.707,")

#text("I am sorry, that was me who entered the lower bounds. I forgot to log into Google before I did so.")

#text("My logic was as I described in 702 and 703. You can include all points with q 2s and half of those with q-1 2s.")

#text("Any combinatorial line can only have one entry vary. In one of the endpoints, it has an odd number of 1s. So all combinatorial lines are excluded.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9946c9121e0cb957d136b5263170c8a16bc3714a9752b67f86f1a8e55f6903c-d05b29fec6ff76805e2997f2a2e0fd4a3c2f601ae9c890328792ae8a4468c320.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jozsef")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35875")[#strong[#text("jozsef")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2009")])]

#text("714. Lower bound for Moser’s cube")

#text("We would like to find some restriction on the number of 0-s, 1-s, and 2-s that makes the appearance of a geometric line impossible, but still allows many points. If ")#mi("a")#text(" denotes the number of 0-s and ")#mi("c")#text(" denotes the number of 2-s, then fixing the number of 1-s means that we select a,b pairs that a+c = constant. (this is our best solution so far) There is another way to avoid lines; If A and C denote the sets of a-s and c-s, then if the difference set of A, A-A , and the difference set C-C are disjoint then triples (a,*,c) won’t form geometric lines. Now, if ")#mi("A , C \\subset [m]")#text(" then it is easy to choose them being “difference-disjoint” and that the product |A||C| is about m. This gives the same bound as the a+c=constant trick. But I’m not sure that one can’t find two larger difference-disjoint sets A and C. That would improve our lower bound instantly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35876")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2009")])]

#text("715. Lower bound for Moser’s problem")

#text("Dear Jozsef, if ")#mi("A, C \\subset [m]")#text(" are such that ")#tao-math("\\left|A\\right| \\left|C\\right| > 2m", block: false)#text(", then by the pigeonhole principle there must be a collision in the sumset A+C, i.e. a non-trivial solution to a+c=a’+c’ with ")#mi("a,a^{\\prime} \\in A")#text(" and ")#mi("c,c^{\\prime} \\in C")#text(". Then a-a’=c’-c, and so A-A and C-C have non-trivial intersection. So I think this method may not give a substantial improvement over the current example.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35877")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2009")])]

#text("716. Genetic algorithms")

#text("This is perhaps not something to pursue too seriously here (it would take a non-trivial programming effort, unless someone just happens to have an off-the-shelf piece of GA software lying around), but it would be amusing to see how well a ")#link("http://en.wikipedia.org/wiki/Genetic_algorithm")[#text("genetic algorithm")]#text(" would fare with trying to maximise the size of a line-free set. It’s tempting to use blocks of, say, ")#mi("[3]^2")#text(" as “genes” that can be swapped around between competitor sets, possibly with some ")#link("http://en.wikipedia.org/wiki/Transposon")[#text("transposon")]#text(" genes to mix the blocks up a little. (The evolution of the “phenotype” in ")#link("http://thomas1111.wordpress.com/2009/02/14/a-proof-that-c_5154/")[#text("Thomas’s blog post")]#text(" might give an illustration of how such an algorithm would develop, sans the “intelligent designer” of course ;-) .)")

#text("More generally, this problem might serve as a reasonable one for benchmarking a number of standard algorithms (we’ve discussed greedy algorithms, integer programming, genetic algorithms, SAT solvers, and quadratic programming in previous comments).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9946c9121e0cb957d136b5263170c8a16bc3714a9752b67f86f1a8e55f6903c-d05b29fec6ff76805e2997f2a2e0fd4a3c2f601ae9c890328792ae8a4468c320.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jozsef")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35878")[#strong[#text("jozsef")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2009")])]

#text("717. Lower bound")

#text("Terry, re. 715, yes you are right, however we might handle such cases by considering only some a, c pairs. In general, we can ask what is the max number of edges in a bipartite graph between A and B which still avoids lines. (i.e. by taking (a,*,c) points only where a,c is an edge can’t form lines) If it true that the number of edges of such graph is always at most m?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9946c9121e0cb957d136b5263170c8a16bc3714a9752b67f86f1a8e55f6903c-d05b29fec6ff76805e2997f2a2e0fd4a3c2f601ae9c890328792ae8a4468c320.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jozsef")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35879")[#strong[#text("jozsef")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2009")])]

#text("718. Lower bound")

#text("Well, it seems that any bipartite graph between ")#mi("A\\subset [m]")#text(" and ")#mi("C\\subset [m]")#text(" which avoids lines has at most m edges. A graph avoids lines iff there are no parallel edges; one edge between a and c and another connecting a+d and c+d. This shows that simply considering the number of 0-s, 1-s, and 2-s can’t give us a better bound than what we have.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35889")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("719. Lower bound for Moser, k=4")

#text("A straightforward lower bound for Moser’s cube k=4 (values 0,1,2,3) is:")#linebreak()#text(" q entries are 1 or 2; or q-1 entries are 1 or 2 and an odd number of entries are 0.")

#mi("\\binom{N}{N/2}2^N + \\binom{N}{N/2-1}2^{N-1}")

#text("I think this is ")#mi("O(4^N/\\sqrt{N})")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35890")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("720. Multi-dimensional tic-tac-toe")

#text("Busy weekend! Are we ready for the OEIS, or should we try a proof by hand that c_5 = 150 first?")

#text("I haven’t done much other than realize there might be something about our problem in the literature relating to multi-dimensional tic-tac-toe, and indeed the very first to explore it were Hales and Jewett. (Was this how DHJ was started, or did this occur later?)")

#link("http://books.google.com/books?hl=en&lr=&id=PZV6yhwa_ZQC&oi=fnd&pg=PA93")[#text("This article")]#text(" from ")#emph[#text("Contemporary Combinatorics")]#text(" seems to be the most recent treatment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9946c9121e0cb957d136b5263170c8a16bc3714a9752b67f86f1a8e55f6903c-d05b29fec6ff76805e2997f2a2e0fd4a3c2f601ae9c890328792ae8a4468c320.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jozsef")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35907")[#strong[#text("jozsef")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("721. Lower bound for Moser, k=4")

#text("Michael, re. 719, you have a better bound by selecting elements where the total number of 1-s and 2-s is n/2. Similar to the k=3 case, one can argue that this is the best possible bound if you only consider the numbers of 0-s,1-s,2-s, and 3-s. For k=5 the situation is better, there we have an arithmetic progression-like sequence just by considering the sizes of digits.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9946c9121e0cb957d136b5263170c8a16bc3714a9752b67f86f1a8e55f6903c-d05b29fec6ff76805e2997f2a2e0fd4a3c2f601ae9c890328792ae8a4468c320.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jozsef")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35908")[#strong[#text("jozsef")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("722. Lower bound for Moser, k=4")

#text("contd. It seems that this is practically the same bound as yours, Michael. Sorry for not noticing. I’ll have a morning coffee before writing anything more …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9946c9121e0cb957d136b5263170c8a16bc3714a9752b67f86f1a8e55f6903c-d05b29fec6ff76805e2997f2a2e0fd4a3c2f601ae9c890328792ae8a4468c320.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jozsef")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35910")[#strong[#text("jozsef")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("723. Lower bound for Moser, k=5")

#text("If A, B, C, D, and E denote the numbers of 0-s, 1-s, 2-s, 3-s, and 4-s then the first three points of a geometric line form a 3-term arithmetic progression in A+E+2(B+D)+3C. So, for k=5 we have a similar lower bound for the Moser’s problem as for DHJ k=3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35911")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("721. Files for c_5=150")#linebreak()#text(" I’m a bit short on time today but I want to make the data for c_5 available. I have put the two files on my webserver, temporarily.")#linebreak()#text(" If someone is willing to put them in a suitable place in the wiki then that would be great.")

#text("This file contains the extermisers. One point per line and different extermisers separated by a line with “—”")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/extremal-c5")[#text("http://abel.math.umu.se/~klasm/extremal-c5")]

#text("This is the linear program, readable by Gnu’s glpsol linear programing solver, which also quickly proves that 150 is the optimum.")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/linprog-d=5-t=3.lpt")[#text("http://abel.math.umu.se/~klasm/linprog-d=5-t=3.lpt")]#linebreak()#text(" Each variable corresponds to a point in the cube, numbered according to their lexicografic ordering. If a variable is 1 then the point is in the set, if it is 0 then it is not in the set.")#linebreak()#text(" There is one linear inequality for each combinatorial line, stating that at least one point must be missing from the line.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35913")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("725. c_6")#linebreak()#text(" I’m aware that the value of c_6 follows from c_5 and that the extermisers can be constructed from the c_5 extermisers. However when doing computer work for these kinds of things I try to follow the cautious strategy that if one can get the same answer in two different ways then it is best to try them both. This gives a good insurance against mistakes and other errors.")

#text("It would be good if someone else would be willing to combine the c_5 extermisers into c_6 extermisers. That way we would have an independent construction by that method as well as the pure integer programming run I am doing for the problem now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35915")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("726.")

#text("I’ve put the recent progress on c_n and Moser’s problem on the wiki. Please feel free to edit.")

#text("I think as soon as we have a second confirmation of the 150 result (either by hand or by computer) we can send the sequence (up to 450) to the OEIS. I doubt we will pin down ")#mi("1302 \\leq c_7 \\leq 1350")#text(" exactly any time soon, though we may be able to narrow the bounds by a bit.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35917")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("727.")

#text("Have anyone tried to generalize the construction in 220? (Michael’s answer to Terry.219)")#linebreak()#text(" Do there exist similar examples when a, b and c are not equal? or when r>1?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35920")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("728. Fujimura’s problem")

#text("Thinking about the multi-dimensional tic-tac-toe led to attempting this problem as an n-queens variant.")

#text("Imagine each removed point as a “queen” that attacks in all six possible directions (and is able to pass over other queens).")

#text("For there to be no equilateral triangles, it is necessary but not sufficient for each point without a queen to be attacked by at least n queens. This corresponds with the removal of all n triangles from that point.")

#text("To be a sufficient condition, each available distance and direction must contain at least one queen. (The three directions are (a+k,b,c) (a,b+k,c) (a,b,c+k) with k>0.)")

#text("There is also a limit to how many queens any individual queen may be attacked by, but I haven’t gone through the calculations yet.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/951516ab72f8eb7e1f0e5e8704dfba7b644383ab92421ee28d997a0921673a9c-4b054f158dec8d55eb32281674b0ca879dfb2ab9a4d79ab87ace095e613c8875.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dima")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35925")[#strong[#text("Dima")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("729.Geometric hyperplanes.")

#text("(studied mostly in a different context, for geometries related to finite simple groups, buildings, etc)")

#text("As the name suggests, a geometric hyperplane is a subset such that every line (combinatorial line, that is, in our case) either lies in it, or intersects it in a point (i.e. an ")#mi("n-")#text("word over {1,2,3}, in our case). So the complement of a geometric hyperplane does not contain a combinatorial line. The opposite need not be true, as a combinatorial line can intersect the complement of a line-free set in 2 points (the latter looks like a “waste of lines”, though, and one would hope (too optimistically, perhaps) that in the extremal examples of line-free sets this does not happen)")

#text("A geometric hyperplane of any “partial linear space with line size 3” (we have our combinatorial lines as an example) is obtained from a so-called universal embedding into ")#mi("\\mathbb{F}_2 P^{N-1},")#text(" where ")#mi("N")#text(" is the number of points, ")#mi("\\mathbb{F}_2")#text(" are integers mod 2, and in our case ")#mi("N=3^n,")#text(" provided certain natural condition is satisfied. This is a result due to M.Ronan (“Embeddings and hyperplanes of discrete geometries”, Europ. J. Combin. 8 (1987), 179–185.)")#linebreak()#text(" As far as I can recall (I can’t easily lay my hands on this text here), for our examples this condition trivially holds.")

#text("The universal embedding is the following natural contruction: take the vectorspace ")#mi("\\mathbb{F}_2^N")#text(" modulo the relations ")#mi("x_i+x_j+x_k=0,")#text(" for each line ")#mi("\\{i,j,k\\}.")#text(" This maps each point the geometry to a nonzero vector of ")#mi("\\mathbb{F}_2^M,")#text(" and each line to a 2-space of ")#mi("\\mathbb{F}_2^M")#text(" (here ")#mi("M")#text(" is the dimension of the quotient space).")#linebreak()#text(" The geometric hyperplanes then are just hyperplanes of the space ")#mi("\\mathbb{F}_2^M.")

#text("One way or another, this is a nice and sometimes useful construction, although I am not too optimistic for it being useful here. Perhaps it would lead to better understanding of construtions of particular line-free sets.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35926")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("730. List of ")#mi("c_5")#text(" solutions")

#text("The twelve solutions are in three types.")

#text("In the notation of Kristal.247 and Terry.248, all twelve can be formed by removing points from")

#text("yzx zxy xyz")#linebreak()#text(" xyz yzx zxy")#linebreak()#text(" zxy xyz yzx")

#text("or a cyclic permutation of that.")

#text("The number of points remaining in each cube is either")

#text("3 solutions from permutations of this")#linebreak()#text(" 17 17 18")#linebreak()#text(" 18 14 17")#linebreak()#text(" 14 18 17")

#text("6 solutions from permutations of this")#linebreak()#text(" 17 17 15")#linebreak()#text(" 18 14 17")#linebreak()#text(" 17 18 17")

#text("3 solutions from permutations of this")#linebreak()#text(" 17 17 12")#linebreak()#text(" 18 17 17")#linebreak()#text(" 17 18 17")

#text("In each solution, one number on the rising diagonal is a multiple of 3;")#linebreak()#text(" that cube was xyz before the removal of points.")

#text("All twelve solutions are formed from complete ")#mi("\\Gamma_{a,b,c}")#text(" slices.")

#text("If my program is right, there is only one ")#mi("c_6")#text(" solution, the one we know, and it is built from the last three solutions above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35927")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("731. ")#mi("c_5 \\leq 152")

#text("I was able to show by hand that ")#mi("c_5 \\leq 152")#text(", basically by using a precise description of the 52 and 51-point line-free sets in ")#mi("[3]^4")#text(", followed by a rather tedious case analysis. See")

#link("http://michaelnielsen.org/polymath1/index.php?title=Upper_and_lower_bounds")[#text("http://michaelnielsen.org/polymath1/index.php?title=Upper_and_lower_bounds")]

#text("The key point seems to be that extremal sets have a very strong tendency to be trapped in one of the sets")

#mi("D_{n,j} := \\{ (x_1,\\ldots,x_n): x_1+\\ldots+x_n = j \\text{ mod } 3 \\}")

#text("for j=0,1,2, and any attempt to deviate from these sets by adding a point or two outside of the set tends to be “punished” by the forcible removal of many points from inside that set.")

#text("Much of the analysis seems like it can be pushed to 150. For instance, I know that if two parallel slices of the set have 51 points or more, then the set as a whole can have at most 150 points. One still has to rule out 52-50-49 and 51-50-50 slice patterns, though, if one is to get all the way to 150.")

#text("Michael: If there is only one ")#mi("c_6")#text(" solution, then we have ")#mi("c_7 \\leq 3c_6 - 2 = 1348")#text(", by the same argument that gave us ")#mi("c_4 \\leq 3 c_3 - 2 = 52")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/951516ab72f8eb7e1f0e5e8704dfba7b644383ab92421ee28d997a0921673a9c-4b054f158dec8d55eb32281674b0ca879dfb2ab9a4d79ab87ace095e613c8875.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dima")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35928")[#strong[#text("Dima")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("732. Symmetries.")

#text("Klas, Terence,")#linebreak()#text(" when you talk about cutting down the search space, it can be cut down by the full automorphism group of the set of combinatorial lines, that is by the direct product of ")#mi("\\mathbb{Z}_3")#text(" and ")#mi("S_n,")#text(" the symmetric group on ")#mi("n")#text(" letters. (It is easy to see that adding 1 to each coordinate, thinking of coordinates being in ")#mi("\\mathbb{Z}_3,")#text(" maps a combinatorial line to a combinatorial line, and gives ")#mi("\\mathbb{Z}_3,")#text(" whereas permuting the coordinates gives ")#mi("S_n.")#text(" That there are no more symmetries, can be seen by observing that there are different numbers of combinatorial lines on points with different numbers of symbols equal to each other.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35930")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("733. Moser, k=5, equals DHJ, k=3")

#text("joszef.723 noted that we get the same density for the Moser cube with k=5 as we got for DHJ with k=3. That is because the restriction of the k=5 Moser’s cube to ")#mi("{}[0,1,2]^N")#text(" is the same problem as DHJ. It also explains why Moser’s k=3 cube gets the same density as Spurner’s lemma.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35931")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("734. Moser, k=5 doesn’t equal DHJ, k=3")

#text("No, I don’t think my previous comment is correct, although the densities do match.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9946c9121e0cb957d136b5263170c8a16bc3714a9752b67f86f1a8e55f6903c-d05b29fec6ff76805e2997f2a2e0fd4a3c2f601ae9c890328792ae8a4468c320.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jozsef")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35934")[#strong[#text("jozsef")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2009")])]

#text("735. Re:734. Moser, k=5 doesn’t equal DHJ, k=3")

#text("Michael, the k=6 case is the first one where I see some simple correlation between the Moser and DHJ problems. By the map P: P(0)=P(5)=0, P(1)=P(4)=1, P(2)=P(3)=2 a line-free grid maps to a combinatorial-line-free cube. So, Moser k=6 is at least ")#mi("2^n")#text(" times DHJ k=3. For k=5 we would need an asymmetric map, I’m not sure if one can get a relation between the two problems similar to the k=6 case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57785d9b4bc8e25821f692ee3d435bb796adfed7394ad4ed0e523e2ca28c2248-7fa311f9e8852af89c8f8bbee0f6630fd2a26ed5a470dbfc0120dfbb7d2d752e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KS Chua")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35945")[#strong[#text("KS Chua")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2009")])]

#text("736. ")#mi("c^{\\prime}_5  \\ge 124")

#text("Using the optimization method described in 229. I found a geometric line free set of size 124. (")#mi("k=3,n=5")#text("). The program is implemented in MATLAB using the builtin minimization routine (which does not use the fact that the objective function is a cubic polynomial). Because there is no apparent structure to the set found, I list the 124 integers below (whose ternary expansions give the set) so that it may be checked independently.")

#text("1 , 4 , 5 , 9 , 10 , 12 , 14 , 16 , 17 , 21 , 22 , 25 , 28 , 29 , 30 , 32 , 33 , 34 , 36 , 38 , 42 , 44 , 45 , 46 , 48 , 50 , 52 , 53 , 57 , 58 , 61 , 62 , 64 , 65 , 66 , 68 , 69 , 70 , 73 , 76 , 77 , 80 , 81 , 82, 84 , 86 , 88 , 89 , 90 , 92 , 96 , 98 , 100 , 101 , 102 , 104 , 105 , 106 , 108 , 110 , 114 , 116 , 126 , 128 , 132 , 134, 136 , 137 , 138 , 140 , 141 , 142 , 144 , 146 ,150 , 152 , 153 , 154 , 156 , 158 , 160 , 161 , 164 , 165 , 166 , 169 , 172 , 173,")#linebreak()#text(" 174 , 176 , 177 , 178 , 181 , 184 , 185 , 186 , 189 , 190 , 192 , 194 , 196 , 197, 198 , 200, 204 , 206 , 208 , 209 , 210 , 212,")#linebreak()#text(" 213 , 214 , 217 , 220 , 221 , 225 , 226 , 228 , 230 , 232 , 233 , 237, 238 , 241.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35946")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2009")])]

#text("737. c5′")

#text("Chua.736’s solution contains all points with two 1s, or one 1 and an even number of 0s.")#linebreak()#text(" It also contains four points with no 1s and two or three 0s. Any two of these four points differ in three places, except for one pair of points that differ in one place.")#linebreak()#text(" For these reasons, I agree that this is a solution to Moser’s problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Pea")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35951")[#strong[#text("Michael Pea")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2009")])]

#text("738. Moser’s cube, k=3")

#text("This suggests further solutions for ")#mi("c^{\\prime}_N")

#text("q 1s, all points from ")#mi("A(N-q,1)")#linebreak()#text(" q-1 1s, points from ")#mi("A(N-q+1,2)")#linebreak()#text(" q-2 1s, points from ")#mi("A(N-q+2,3)")#linebreak()#text(" etc.")

#text("where ")#mi("A(m,d)")#text(" is a subset of ")#mi("[0,2]^m")#text(" for which any two points differ from each other in at least d places.")

#text("Mathworld’s entry on error-correcting codes suggests it might be NP-complete to find the size of A(m,d) in general.")

#tao-math("\\left|A(m,1)\\right| = 2^m", block: false)#text(" because it includes all points in ")#mi("[0,2]^m")#linebreak()#text(" ")#tao-math("\\left|A(m,2)\\right| = 2^{m-1}", block: false)#text(" because it can include all points in ")#mi("[0,2]^m")#text(" with an odd number of 0s")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35963")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2009")])]

#text("739. c_6")#linebreak()#text(" My integer programing run has now finished and as expected it found the optimum to be c_6=450 and found a unique one solution.")

#text("This case required a lot more CPU-time than c_5. I had to split the problem into many subcases and ran them in parallell ona linux cluster. My guess would that it used around 1000 CPU-hours.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-35996")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2009")])]

#text("740.")

#text("That’s a huge effort, and I’m guessing we won’t be able to find ")#mi("c_7")#text(" by this method.")

#text("In 738, I can at least estimate the size of A(m,d) by sphere packing.")

#text("In A(m,3), each selected point and its m immediate neighbours form disjoint sets, so ")#tao-math("\\left|A(m,3)\\right| <= \\frac{2^m}{m+1}", block: false)#linebreak()#text(" Also ")#tao-math("\\left|A(m,4)\\right| <= \\frac{2^m}{m+1}", block: false)

#text("In A(m,5) and A(m,6), each selected point and two layers of neighbours form disjoint sets, so ")#tao-math("\\left|A(m,5)\\right|(1+m+\\binom{m}{2}) \\leq 2^m", block: false)#text(".")

#text("Using these inequalities, it seems that only a tiny fraction of points from lower layers are included in the method described in 738. So this method still only has ")#mi("O(3^N/\\sqrt{N})")#text(" points.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-36005")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2009")])]

#text("741. Moser")

#text("It occurs to me that if we have a good enough understanding of the ")#mi("c^{\\prime}_4=43")#text(" result, and in particular we can classify 43-point Moser sets, then we may be able to improve the upper bound on ")#mi("c^{\\prime}_5")#text(" from 129 to ")#mi("127 = 43 + 42 + 42")#text(" as was done for the ")#mi("c_4")#text(" and ")#mi("c_7")#text(" upper bounds, bringing us closer to the lower bound of 124. If we also can classify the 42-point Moser sets then in principle we can hit ")#mi("124 = 42 + 41 + 41")#text(" exactly.")

#text("(Similarly, if we get a good classification of 50-point line-free subsets of ")#mi("[3]^4")#text(", then we should be able to finish off a non-computer-assisted proof that c_5 = 150.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-36011")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2009")])]

#text("742. Moser.")#linebreak()#text(" I ran my program for the Moser problem. For n=4 I get 43 as the optimum and the program found 1552 extremisers. However a quick heuristic test suggest that most might be isomorphic.")#linebreak()#text(" The solutions can be found here")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/extremal-moser-n=5-t=3")[#text("http://abel.math.umu.se/~klasm/extremal-moser-n=5-t=3")]#linebreak()#text(" The file format is the same as before.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-36017")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2009")])]

#text("743. Moser")

#text("At a first glance, there are four types of solution")

#text("512 solutions: 24 points contain two 2s, 16 contain one 2, 3 contain no 2s")#linebreak()#text(" 768 solutions: 23 points contain two 2s, 16 contain one 2, 4 contain no 2s")#linebreak()#text(" 256 solutions: 24 points contain two 2s, 15 contain one 2, 4 contain no 2s")#linebreak()#text(" 16 solutions: 18 points contain two 2s, 20 contain one 2, 5 contain no 2s")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-36018")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2009")])]

#text("744. If the following:")

#text("512 solutions: 24 points contain two 2s, 16 contain one 2, 3 contain no 2s")#linebreak()#text(" 768 solutions: 23 points contain two 2s, 16 contain one 2, 4 contain no 2s")#linebreak()#text(" 256 solutions: 24 points contain two 2s, 15 contain one 2, 4 contain no 2s")#linebreak()#text(" 16 solutions: 18 points contain two 2s, 20 contain one 2, 5 contain no 2s")

#text("are the only possible values for c_4′ = 43. Then I think that c_5′")#linebreak()#text(" must be 128 or less. There are only 24 points possible with two 2’s")#linebreak()#text(" so if there are three in a row the first one must have at least 18 of these")#linebreak()#text(" points the second cube must also have at least 18 so there must be at least")#linebreak()#text(" 12 in both final the third must have at least 18 so there must be")#linebreak()#text(" at least 6 in all three which results in a line. So the maximum value for")#linebreak()#text(" c_5′ is 128 or less.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-36024")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2009")])]

#text("745. ")#mi("c_4")

#text("I’ve managed to classify all 52-point, 51-point, and 50-point line-free subsets of ")#mi("[3]^4")#text("; the details are somewhat tedious but they are on the wiki, see Lemma 2 of")

#link("http://michaelnielsen.org/polymath1/index.php?title=Upper_and_lower_bounds#n.3D4")[#text("http://michaelnielsen.org/polymath1/index.php?title=Upper_and_lower_bounds#n.3D4")]

#text("At the 50-point level we see for the first time a set which is not contained in one of the ")#mi("D_{4,j}")#text(" sets, which I have called X.")

#text("In principle, it should now be possible to establish the upper bound ")#mi("c_5 \\leq 150")#text(", using Lemmas 2, 3, 4 on the wiki, though I will not have the time to verify this in the near future.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6aee136dbc4c0bc79c68cbcf7d17f526cce6319a8e6e98ec412127af7d47f3a8-376867c974a73315b8452903740c9fc3635e43fe0fc86f758644077298bb8a0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Elsholtz")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-36030")[#strong[#text("Christian Elsholtz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2009")])]

#text("746, Mosers problem in dimension 4 and 5.")

#text("From Klas’ list in 742 it appears to me (just by a visual inspection, not by computer count) that possibly the distributions of the 43 vectors in the 3 planes are like")#linebreak()#text(" (13, 16,14) and (14,15,14) (only?)")#linebreak()#text(" This would mean that the middle layer is quite full,")#linebreak()#text(" so, when constructing a 5 dimensional array out of the 4 dimensional configurations,")#linebreak()#text(" like")#linebreak()#text(" (a b c)")#linebreak()#text(" (d e f)")#linebreak()#text(" (g h i), where ")#mi("a+b+c  \\leq  43")#text(", etc, and also")#linebreak()#text(" ")#mi("b +e+h \\leq 43")#linebreak()#text(" one should indeed be able to get a better upper bound.")#linebreak()#text(" Perhaps one of you can count the number of ones, twos and threes in the first column, for each solution and report the distributions?")

#text("Given that for dimension 3 the extremal example is of type (6,4,6), i.e. middle layer is not dense, in dimension 4 we have (possibly) the opposite, so that for dimension 5 one could expect again the middle layer is less dense,")#linebreak()#text(" The example by KS Chua in 736 has a distribution of")#linebreak()#text(" {{42, 40, 42}, {42, 40, 42}, {42, 40, 42}, {41, 40, 43}, {41, 40, 43}}")#linebreak()#text(" in the 5 parallel layers, so is in the spirit of this philosophy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-36031")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2009")])]

#text("747. Moser n=4")

#text("Over night I ran the program to find all solutions for Moser’s problem for n=4 and 42 points.")#linebreak()#text(" The solutions can be found here")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/moser-n=4-t=3-p=42.gz")[#text("http://abel.math.umu.se/~klasm/moser-n=4-t=3-p=42.gz")]#linebreak()#text(" There are of course a large number of solutions, 86232, but again it seems that the number of non-isomorphic solutions might be quite small.")

#text("A question for those analysing the solutions. Are all the 42 point solutions subsets of the 43 point extremisers or are there other maximal solutions as well?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6aee136dbc4c0bc79c68cbcf7d17f526cce6319a8e6e98ec412127af7d47f3a8-376867c974a73315b8452903740c9fc3635e43fe0fc86f758644077298bb8a0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Elsholtz")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-36035")[#strong[#text("Christian Elsholtz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2009")])]

#text("748 Moser")#linebreak()#text(" The observation made by Michael, in 738 and 740 has also been made")#linebreak()#text(" by V Chvatal, Canadian Math Bulletin, Vol 15, 1972, 19-21. “Remarks on a problem of Moser”.")#linebreak()#text(" That paper, however, is more difficult to read, and rewriting that observation in modern notation, as done by Michael, was certainly useful.")

#text("That paper also comments that the construction only gives ")#mi("O( \\frac{3^n}{\\sqrt{n}})")#text(", the reason being indeed that ")#mi("A(n,d)\\leq 2^{n-d+1}")

#text("It can also be observed that the method gives for dimension 4 only 42 points, so that one should not expect that construction to be optimal, since ")#mi("c_4^{\\prime}=43")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57785d9b4bc8e25821f692ee3d435bb796adfed7394ad4ed0e523e2ca28c2248-7fa311f9e8852af89c8f8bbee0f6630fd2a26ed5a470dbfc0120dfbb7d2d752e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KS Chua")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-36036")[#strong[#text("KS Chua")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2009")])]

#text("749. ")#mi("c_n^{\\mu}")#text(" by optimization and LYM")

#text("The optimization approach can be applied to the weighted version")#linebreak()#text(" ")#mi("c_n^{\\mu}")#text(". The argument in 229 (minus the confusing")#linebreak()#text(" indexing) is :")

#text("Let ")#mi("G")#text(" be a uniform k graph with vertex set ")#mi("V=\\{v_1,...,v_m\\}")#text(" and edge set ")#mi("E_k")#text(" together with a weight")#linebreak()#text(" function ")#mi("0 \\le w_i \\le 1")#text(" for each vertex ")#mi("v_i")#text(" and set")

#mi("f(x)= \\sum_{i=1}^m x_i w_i-\\sum_{(i_1,...,i_k) \\in E_k} x_{i_1}...x_{i_k} .")

#text("Then the maximal total weight ")#mi("\\alpha")#text(" of an independent set")#linebreak()#text(" of vertices (no k of which is an edge) in ")#mi("G")#text(" is given by")

#mi("\\alpha=MAX_{x \\in \\{0,1\\}^n}f(x)=MAX_{x \\in [0,1]^n}f(x).")

#text("Applied to subset relation , with variables ")#mi("x_I, I \\subset [n]")#text(" weighted by ")#mi("1/\\begin{pmatrix} n \\cr |I| \\end{pmatrix}")#text(" and the known ")#mi("c_n^{\\mu}=1")#text(" for ")#mi("k=2")#text(", it gives the")#linebreak()#text(" following interpolation of the LYM equality. For all ")#mi("x \\in [0,1]^{2^n}")#text(",")

#mi("\\sum_{I \\subset [n]} \\frac{x_I}{\\begin{pmatrix} n \\cr |I| \\end{pmatrix}}-\\sum_{I \\subset J \\;\\; or \\;\\; J \\subset I} x_I x_J \\le 1.")

#text("Choosing a 0-1 ")#mi("x")#text(" corresponding to an antchain gives the usual LYM.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/comment-page-1/#comment-36043")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2009")])]

#text("750. If there are 1552 43-point solutions and 86232 42-point solutions")#linebreak()#text(" then there must be one 42-point solution which is not a subset of any of the 43-point solutions, since each 43-point solution has 43 42-point subsets and 43*1552 is less than 86232.")
]
