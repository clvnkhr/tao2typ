// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/02/02/random-matrices-the-universality-phenomenon-for-wigner-ensembles/
// Converted to Typst by tao2typ: "2026-10-14T15:18:22.126474+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Random matrices: The Universality phenomenon for Wigner ensembles", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Random matrices: The Universality phenomenon for Wigner ensembles")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 February 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/02/02/random-matrices-the-universality-phenomenon-for-wigner-ensembles/")[#text("https://terrytao.wordpress.com/2012/02/02/random-matrices-the-universality-phenomenon-for-wigner-ensembles/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Van Vu and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/1202.0068")[#text("Random matrices: The Universality phenomenon for Wigner ensembles")]#text("“. This survey is a longer version (58 pages) of a previous short survey ")#link("https://terrytao.wordpress.com/2011/12/12/random-matrices-the-four-moment-theorem-for-wigner-ensembles/")[#text("we wrote up a few months ago")]#text(". The survey focuses on recent progress in understanding the universality phenomenon for Hermitian Wigner ensembles, of which the Gaussian Unitary Ensemble (GUE) is the most well known. The one-sentence summary of this progress is that many of the asymptotic spectral statistics (e.g. correlation functions, eigenvalue gaps, determinants, etc.) that were previously known for GUE matrices, are now known for very large classes of Wigner ensembles as well. There are however a wide variety of results of this type, due to the large number of interesting spectral statistics, the varying hypotheses placed on the ensemble, and the different modes of convergence studied, and it is difficult to isolate a single such result currently as ")#emph[#text("the")]#text(" definitive universality result. (In particular, there is at present a tradeoff between generality of ensemble and strength of convergence; the universality results that are available for the most general classes of ensemble are only presently able to demonstrate a rather weak sense of convergence to the universal distribution (involving an additional averaging in the energy parameter), which limits the applicability of such results to a number of interesting questions in which energy averaging is not permissible, such as the study of the least singular value of a Wigner matrix, or of related quantities such as the condition number or determinant. But it is conceivable that this tradeoff is a temporary phenomenon and may be eliminated by future work in this area; in the case of Hermitian matrices whose entries have the same second moments as that of the GUE ensemble, for instance, the need for energy averaging has already been removed.)")

#text("Nevertheless, throughout the family of results that have been obtained recently, there are two main methods which have been fundamental to almost all of the recent progress in extending from special ensembles such as GUE to general ensembles. The first method, developed extensively by Erdos, Schlein, Yau, Yin, and others (and building on an initial breakthrough by Johansson), is the ")#emph[#text("heat flow method")]#text(", which exploits the rapid convergence to equilibrium of the spectral statistics of matrices undergoing Dyson-type flows towards GUE. (An important aspect to this method is the ability to accelerate the convergence to equilibrium by localising the Hamiltonian, in order to eliminate the slowest modes of the flow; this refinement of the method is known as the “local relaxation flow” method. Unfortunately, the translation mode is not accelerated by this process, which is the principal reason why results obtained by pure heat flow methods still require an energy averaging in the final conclusion; it would of interest to find a way around this difficulty.) The other method, which goes all the way back to Lindeberg in his classical proof of the central limit theorem, and which was introduced to random matrix theory by Chatterjee and then developed for the universality problem by Van Vu and myself, is the ")#emph[#text("swapping method")]#text(", which is based on the observation that spectral statistics of Wigner matrices tend to be stable if one replaces just one or two entries of the matrix with another distribution, with the stability of the swapping process becoming stronger if one assumes that the old and new entries have many matching moments. The main formalisations of this observation are known as ")#emph[#text("four moment theorems")]#text(", because they require four matching moments between the entries, although there are some variant three moment theorems and two moment theorems in the literature as well. Our initial four moment theorems were focused on individual eigenvalues (and later also to eigenvectors), but it was later observed by Erdos, Yau, and Yin that simpler four moment theorems could also be established for aggregate spectral statistics, such as the coefficients of the Greens function, and Knowles and Yin also subsequently observed that these latter theorems could be used to recover a four moment theorem for eigenvalues and eigenvectors, giving an alternate approach to proving such theorems.")

#text("Interestingly, it seems that the heat flow and swapping methods are complementary to each other; the heat flow methods are good at removing moment hypotheses on the coefficients, while the swapping methods are good at removing regularity hypotheses. To handle general ensembles with minimal moment or regularity hypotheses, it is thus necessary to combine the two methods (though perhaps in the future a third method, or a unification of the two existing methods, might emerge).")

#text("Besides the heat flow and swapping methods, there are also a number of other basic tools that are also needed in these results, such as local semicircle laws and eigenvalue rigidity, which are also discussed in the survey. We also survey how universality has been established for wide variety of spectral statistics; the ")#mi("{k}")#text("-point correlation functions are the most well known of these statistics, but they do not tell the whole story (particularly if one can only control these functions after an averaging in the energy), and there are a number of other statistics, such as eigenvalue counting functions, determinants, or spectral gaps, for which the above methods can be applied.")

#text("In order to prevent the survey from becoming too enormous, we decided to restrict attention to Hermitian matrix ensembles, whose entries off the diagonal are identically distributed, as this is the case in which the strongest results are available. There are several results that are applicable to more general ensembles than these which are briefly mentioned in the survey, but they are not covered in detail.")

#text("We plan to submit this survey eventually to the proceedings of a workshop on random matrix theory, and will continue to update the references on the arXiv version until the time comes to actually submit the paper.")

#text("Finally, in the survey we issue some errata for previous papers of Van and myself in this area, mostly centering around the three moment theorem (a variant of the more widely used four moment theorem), for which the original proof of Van and myself was incomplete. (Fortunately, as the three moment theorem had many fewer applications than the four moment theorem, and most of the applications that it did have ended up being superseded by subsequent papers, the actual impact of this issue was limited, but still an erratum is in order.)")

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f527d4d8c677c0099707d7d6d4d3af8fe0202ca4c96c3b7bb00e01730373de16-80f1269ae3ae2df178c4e4cb58713f3d5cebb42e7182a958f52a6b55b9895c17.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hernandezgomez")]], [#link("https://terrytao.wordpress.com/2012/02/02/random-matrices-the-universality-phenomenon-for-wigner-ensembles/#comment-132061")[#strong[#text("hernandezgomez")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2012")])]

#text("Reblogged this on ")#link("http://masejerciciosresueltos.wordpress.com/2012/03/07/563/")[#text("+ Ejercicios Resueltos")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random matrices: Universality of local spectral statistics of non-Hermitian matrices « What’s new")]], [#link("https://terrytao.wordpress.com/2012/02/02/random-matrices-the-universality-phenomenon-for-wigner-ensembles/#comment-146838")[#strong[#text("Random matrices: Universality of local spectral statistics of non-Hermitian matrices « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2012")])]

#text("[…] universality of local statistics in the Hermitian case (as discussed for instance in this recent survey of Van and myself, and also in several other […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/269e0f04eeb9c6602bd5ad78e5c0a538043d91eb4f2f77251c269338f1d32b82-ed8b5478c73e9d6b85bd1da7f3316c0b7f677b5574d7751f0c4d041cac965b9c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Long Cong Đuôi")]], [#link("https://terrytao.wordpress.com/2012/02/02/random-matrices-the-universality-phenomenon-for-wigner-ensembles/#comment-467739")[#strong[#text("Long Cong Đuôi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2016")])]

#text("In the page 11 , a factor 1/n for the trace and a factor (1/n) to the power k for the formula (20) are missed")

#emph[#text("[Thanks, this will appear in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/02/random-matrices-the-universality-phenomenon-for-wigner-ensembles/#comment-515374")[#strong[#text("The (Random) Matrix and more | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2019")]

#text("[…] is not a computer simulation—that we can’t be living in the Matrix? (Shtetl-Optimized); A related 2012 post on What’s […]")
]
