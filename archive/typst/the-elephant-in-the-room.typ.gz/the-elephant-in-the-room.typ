// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/
// Converted to Typst by tao2typ: "2026-10-14T16:39:14.914569+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The elephant in the room", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The elephant in the room")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 November 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/")[#text("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The day after the election, I found myself struggling with how to approach the complex analysis class I was teaching. Could I ignore the (almost literal) elephant in the room? Would my students be in the right mental state to learn math? Would I be in the right mental state to teach it?")

#text("I opened with the statement that usually in math we have the luxury of working in abstractions far removed from the real world. We are familiar with addressing mathematical problems with the (inessential) connections to the real world stripped away, leaving only the essential features to focus one’s attention. An election, for instance, might be treated as the outcome of ")#mi("N")#text(" people, each of which has a probability ")#mi("p")#text(" of voting for one candidate, and ")#mi("1-p")#text(" for another… and one can then try to analyze the problem from a dispassionate mathematical perspective. This type of mindset can be illuminating in many contexts. Real world events have real consequences, however, and in light of an event as consequential as the last election, a math lecture on contour integration or the central limit theorem may seem meaningless.")

#text("But there is one precious thing mathematics has, that almost no other field currently enjoys: a consensus on what the ground truth is, and how to reach it. Because of this, even the strongest differences of opinion in mathematics can eventually be resolved, and mistakes realized and corrected. This consensus is so strong, we simply take it for granted: a solution is correct or incorrect, a theorem is proved or not proved, and when a problem is solved, we simply move on to the next one. This is, sadly, not a state of affairs elsewhere. But if my students can learn from this and carry these skills— such as distinguishing an overly simple but mathematically flawed “solution” from a more complex, but accurate actual solution—to other spheres that have more contact with the real world, then my math lectures have consequence. Even—or perhaps, especially—in times like these.")

#heading(level: 1)[#text("Comments (90)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686602")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("While I do plan to keep this blog primarily about mathematics topics, I will also be posting more thoughts of a personal nature on ")#link("https://mathstodon.xyz/@tao")[#text("my Mastodon account")]#text("; see for instance ")#link("https://mathstodon.xyz/@tao/113444728490902451")[#text("my post there from yesterday")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eecd66a337c2a4e86e826a83728d9e8eafa931528e06c8e39a12720fd9c72ab9-a2f288599044367771d0e441dea02b25f62c0a5c58b10e26624a15bcdd990a33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orr Shalit")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686603")[#strong[#text("Orr Shalit")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("A very thoughtful post, thank you. Since in Israel we have had 5 elections in the past 5 years, I have had this dilemma on average every other term… Of course I try to keep politics out of class, but on one of the mornings after in a lecture on integration I could not help myself and made my little protest by calculating the velocity required to escape from earth.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686604")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("It seems that it would be way more helpful if you can first try to carry these skills to the real world yourself and then teach your students (and also your long-term audience like me) how to actually do it. At this time, I really hope there is a teacher telling me how to actually apply the pure math skills to the real world: not applied math for some industrial problems, but really applying pure math like you said to the understanding of the deep and imminent problems in the real world.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686607")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("I actually have made efforts to do that, both here (e.g., in ")#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/")[#text("my recent post on the Venezuelan election")]#text("), and on my ")#link("https://mathstodon.xyz/@tao")[#text("Mastodon account")]#text(" (I have collected some of those posts ")#link("https://terrytao.wordpress.com/mastodon-posts/")[#text("here")]#text("). I am definitely planning on posting quite frequently on my Mastodon on many topics going forward, including on the intersection of math with the real world.")

#text("Previously, when I ventured too far from the abstract world of pure mathematics, I got pushback of various types, including ones along the lines of “You should stay in your lane”. Perhaps my most notorious example of this was my surprisingly topical 2016 post “")#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/")[#text("It ought to be common knowledge that Donald Trump is not fit for the presidency of the United States of America")]#text("“. Staying in one’s lane can be considered reasonable advice under normal traffic conditions. But the traffic ahead will be the complete opposite of normal, and so we have to change our driving habits now.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/019f42a59b6ca94852de5993fa2f55b0b33e03a0361190a58d45dc04a65c4f45-5ee34391d5eae5863d0cf4b67ae05dce32f64f3efa1c3bcb0e4969b0c8391690.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kairui Zhang")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686654")[#strong[#text("Kairui Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("As a physicist, I also find this kind of pushback deeply unsettling. Politics influences every aspect of everyone’s daily lives, including the lives of mathematicians and scientists. ‘Staying in your lane’ sounds to me like we are not part of the society. It dismisses the reality that political decisions shape the frameworks within which we all operate. Politics is inherently open and participatory; engaging, questioning, and advocating are what a healthy democracy should have.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686738")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2024")])]

#text("As a Trump supporter I appreciate your restraint, especially since as an academic, you probably don’t even know anyone who voted for him. Yes, in a very real sense Trump is not fit to be president. I wish that, say, Ted Cruz were heading to the White House in January instead. But for all his faults, Trump is, for me, a better choice than Harris.")

#text("I was once on a jury where an elderly woman was on trial for drunk driving. She denied having consumed any alcohol on the night in question. But the arresting officer said she was weaving wildly side to side down the street, and when he stopped her, and she rolled down her window, there was a strong odor of alcohol on her breath. The two accounts were incompatible, and as a jury we concluded that the woman was lying. I think it was the right call, but it felt strange to think that our finding rested on the assumption that the woman was lying.")

#text("That strange feeling returned to me while reading the NYT’s Oct 25 editorial, “Believe Him,” which outlined 5 or 6 things Trump had threatened to do if elected. The NYT was counseling to vote in the belief that, if given the chance, Trump would follow through with these threats. But in fact, I voted for Trump on the assumption, for instance, that he would NOT start a mass deportation of illegal immigrants. There was a big uptick in Hispanics voting for Trump, and I have to believe that in voting for him they took didn’t really believe that he would do it. We’ll see. Bullshit political speech — and I use the term in its rigorous philosophical sense à la Harry Frankfurt — is subject to misinterpretation and this quite dangerous. “Bullshit” as a term of art refers to language which is intended to arouse an emotional response, not a rational assent.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686773")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2024")])]

#text("Even if you’re sure that he won’t really do the things he says he will (which, to be honest, I don’t believe — others had to prevent his worst impulses from being carried out when he suggested to authorities to have protestors shot in the legs, for example), isn’t allowing his statements to become accepted in mainstream harmful enough? Most politicians spew bullshit, but ")#emph[#text("hateful")]#text(" bullshit, especially used to the extent that Trump has, can cause serious problems for the groups involved without ever actually turning into policy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-688450")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2025")])]

#text("Anonymous, what do you think of your comment now that the rubber has met the road?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/563fc415e61a3bc0b1e2432bc02876ae64af4eb65ac2b28d4fd965645fd1bd1c-2b857b97ebc4abc7e7c637f1d86d4ea461ea13294f1fa6cef496488eb34d9e0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KKK")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686800")[#strong[#text("KKK")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2024")])]

#text("While not directly related, I am curious to hear your opinion on the job losses in Australian universities and the disestablishment of certain schools, including mathematics and physics departments at some institutions. These changes appear to be driven by government restrictions on international student numbers. For example: ")#link("https://www.abc.net.au/news/2024-11-05/university-of-wollongong-cuts-academic-jobs-international-cap/104560250")[#text("https://www.abc.net.au/news/2024-11-05/university-of-wollongong-cuts-academic-jobs-international-cap/104560250")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686829")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2024")])]

#text("I don’t know of any _good_ reason why somebody wouldn’t want an accomplished mathematician to check their work in social science or politics. Anyway, according to the First Amendment a cliche like “stay in your lane” is at most a request, one which you are under no obligation to heed.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686666")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2024")])]

#text("Why would you expect a math teacher to be able to tell you how to apply pure math to the understanding of the “deep and imminent problems in the real world”?")#linebreak()#text("Do you think math teachers know why people are being killed in different parts of the world to decide who is going to rule where for the next 100 years or so? Or do you think they know whether or not such and such viruses are/were being created in some labs somewhere and might leak (or might have leaked) or be used as a weapon? ")#linebreak()#text("Do you really think math teachers should understand more than anyone else, including you, as a grown up human being, about violence, poverty, racism, hate, fear, conflicts of interest, civil rights, freedom of speech, censorship and so on?")#linebreak()#text("Otherwise I guess it is not really clear what you mean by deep and imminent problems of the real world.")#linebreak()#text("This blog is wonderful, and I also like that there is room for non-mathematical discussions. But let’s be clear guys, mathematicians are not super-heroes. When we are about those topics they are just like anyone else.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686695")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2024")])]

#text("Obviously no one profession, or one skill, is going to solve all the world’s problems. But they can certainly contribute to solutions to at least some of these problems, even if they do not handle everything. To give just one example, having at least one math-literate person in the room when making a major change in economic policy (e.g., a sweeping imposition of tariffs) could be quite consequential.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686700")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2024")])]

#text("Well I guess this is undeniable. But it happens already, any ministry has technicians at their disposal with some rather deep understanding of economics, and they certainly know the needed math. But this is more in the direction of the “applied math for some industrial problems” rather than “really applying pure math to the understanding of the deep and imminent problems in the real world” as the poster was asking.")

#text("Mathematicians can be great at deriving consequences within a given model based on certain assumptions, but 99% of the difficulty in solving the “deep and imminent problems in the real world” indeed relies in being able to come up with the right model, which requires knowledge and deep understanding of economics, history, anthropology, psychology, chemistry, geology, religion, you name it. A large part of those being non-exact sciences and requiring deep understanding of the … real, practical world!")

#text("And let me say that from my experience a large majority of the mathematicians have a rather limited understanding of the real world, precisely because, as someone already mentioned in this page, they spend most of their time applying rigorous logical and rational thinking within an isolated ideal world which does not face any of the practical non-idealities and irrational behaviors which instead rule the real world.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686734")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2024")])]

#text("This reminds me of what Benjamin Franklin said about mathematicians: “But he [Thomas Godfrey] knew little out of his way, and was not a pleasing companion; as, like most great mathematicians I have met with, he expected universal precision in everything said, or was forever denying or distinguishing upon trifles, to the disturbance of all conversation.”")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686701")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2024")])]

#text("Yes, I do think that some of the best mathematicians and physicists genuinely have a deeper understanding of the structure of the world. Because their job is to study the most complicated kinds of structures, and the structure of our world is arguably the most difficult one. Examples include Plato, Weyl, Einstein, Russell, Whitehead, and Grothendieck. After all, why enter academia, if not in search of the truth?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686713")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2024")])]

#text("Yes, _some_ mathematicians and _some_physicists have a deep understanding of the structure of the world as _some_ sociologists and _some_ philosophers and _some_ historians and _some_ plumbers and _some_ postmen do. There is little to nothing inherently mathematical in the dynamics which govern the most serious issues that humanity has to face. Furthermore, it is a rather different story to be able to point out what is wrong with a given approach and to be able to give an alternative practically viable one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686719")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2024")])]

#text("The problem with this deeply flawed worldview is that it approaches knowledge as a one-way collection and distillation of information. It assumes that increasing your knowledge in one domain can’t harm your understanding of other domains, which is empirically false. There are many robust studies showing how experts in one domain often perform worse than the average layman in other seemingly related domains. The problem, when it arises, is clearly caused by a lack of humility and reflection. In many cases, someone who knows that they know nothing is in a better position to make decisions than someone who knows a little but thinks they know a lot.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686721")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2024")])]

#text("The important thing, in my view, is to have decision making involve people with diverse intellectual backgrounds (including, but emphatically not limited to, mathematical backgrounds) who can interact in good faith and with some base level of trust and respect in a setting with healthy group dynamics. Certainly a hypothetical “mathocracy” where mathematicians somehow became the sole arbiters of policy (in the vein of Plato’s “philosopher-kings”) would be a terrible idea, but this is not exactly a realistic possibility in any case. A much more reasonable goal, as I said before, is to have at least some math-literate people in the room with a voice when important decisions are made; similarly, people with expertise in the social sciences, economics, politics, communication, design, local communities, and so forth would also ideally also be present.")

#text("I will say that my service on the President’s Council of Advisors on Science and Technology (PCAST) has managed to achieve this to a relatively high level. One can see some videos of some of our public meetings ")#link("https://www.whitehouse.gov/pcast/meetings/2024-meetings/")[#text("here")]#text(". At the risk of self-promotion, I would like to say that I am particularly proud of co-chairing ")#link("https://www.whitehouse.gov/pcast/briefing-room/2024/04/29/pcast-releases-report-on-supercharging-research-harnessing-artificial-intelligence-to-meet-global-challenges/")[#text("the PCAST report on how AI, when used responsibly, could be used to supercharge science")]#text(". Our working group had in its membership and its interviewees many deep domain experts on the fields in science and technology (such as materials science, chip design, the social sciences, climate modeling, and so forth) that were being transformed by AI; I myself was not a domain expert in any of these, but I believe my background in pure math was helpful in being able to help abstract the common themes in all of these developments and distil them into a coherent conceptual framework for the report.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686709")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2024")])]

#text("IDK, to me mathematicians are super-heroes. I’m just an Engineer professionally. However, learning Galois theory and proving general quintics couldn’t be solved by radicals was mindblowing. (Engineer by profession here)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686739")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2024")])]

#text("Well, that is pure math, and it is spectacular of course.")#linebreak()#text("Super-heroes I meant in the sense of having the right thoughts for every kind of problem. You would not let Galois educate your children about how to handle disputes, I guess.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686717")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2024")])]

#text("Don’t ever forgot what mathematicians and other scientists did back in WWII. They contributed a lot to the Manhattan Project, British ULTRA project, US office of navy intelligence…… Even Albert Einstein himself helped to improve US navy torpedo. Scientists could play a huge, sometimes decisive role in changing the course of history when they reach a consensus. While public like you seems obliviate that period of history partly because its top secrecy. I suggest you read <The Secret War: Spies, Codes and Guerrillas 1939–1945>by Max Hastings to recollect the historic fragments.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686740")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2024")])]

#text("This is also undeniable, but the poster was referring to something else, that is “pure math like you said to the understanding of the deep and imminent problems in the real world” and “not applied math for some industrial problems”, which is instead precisely what you and Terry give as examples.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686605")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("HI Professor Tao,")#linebreak()#text(" So I found myself in a similar position just that I had to interact with a bunch of people I expected to talk about elections.")#linebreak()#text(" So I figured out right before i met them (in a shower) that this election is a screaming example of how any election and change of parties can be used as an informal justification for the (right or wrong) claim that humans tend to choose political parties in an election in a way that resembles a Markov chain.")#linebreak()#text(" (Their reactions were pretty wholesome in a sense, but I think that’s for Mastodon.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686606")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Thanks for sharing. It’s nice to know that mathematicans even great ones are human too and are often thinking about things outside of math. You’re not alone on how you feel about this but a thought I’ve found comforting is that the future is often unpredicable and sometimes in a good way.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/868a3840b54fb10464c175f352d0bb3750e102828410daf8a7f91f7f2ad6b20d-18540e05e1e9e8d4afb445eb548e090f1e810132eb6f56384a1014192b642445.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of E.")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686610")[#strong[#text("E.")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Is your complex analysis course streamed? I am trying to get a feeling for what a complex analysis course ought to be if taught with access to a CAS. I am sure you might have something to say about this, and that there is something to learn from such a course taught by you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686621")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Currently at UCLA, classes are in-person, and are usually not recorded. The lecture notes for this course are available on my blog ")#text("here")#text(". I do have one pre-recorded lecture this quarter, on the Jordan curve theorem; I have now uploaded my annotated notes for it ")#link("https://terrytao.wordpress.com/wp-content/uploads/2024/11/jordan-theorem-lecture-notes-1.pdf")[#text("here")]#text(". However, the video recording is rather large. I normally do not feel the need to make these sorts of video recordings public; but as an experiment, I have put this lecture on my (otherwise extremely inactive) Youtube channel ")#link("https://youtu.be/8gBfnEpBAzM")[#text("here")]#text(". [EDIT: unfortunately, it appears the recording exceeds the size limit for the Youtube account.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686622")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Thanks! Later I would like to ask about experiences you might have had, if at all, with having students use a (suitable) LLM for learning/study purposes. But I am getting ahead of myself!")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686627")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("In my next class for the winter quarter, I am considering some experimental addition of Lean formalization as an alternate way to obtain course credit. But the most interesting experiment I have seen so far to integrate LLMs into an advanced math course is ")#link("https://www.youtube.com/watch?v=om7VpIK90vE")[#text("this one by Michael Brenner")]#text(".")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686609")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Something seems badly off here…your government is directly complicit in an ongoing genocide and somehow the elephant only appears now?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686615")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("To be frank, there have been undercurrents of sickness in societies across the world for some time now, that have prevented real dialogue and the difficult, realistic path towards actual reconciliation. There are examples of world conflicts in times past where even the most hardened enemies have made peace with each other and acknowledged that there is middle ground between both sides. I remember the Good Friday agreement that largely ended the Troubles in Northern Ireland, for instance, or the (admittedly imperfect) dismantling of the apartheid system in South Africa, and even in the seemingly intractable conflict between Israel and Palestine you presumably allude to, the Oslo peace accords are well within living memory.")

#text("But true reconciliation is hard, hard work, full of nuance and complexity and compromise. As in mathematics, it requires both sides to adopt a common source of ground truth that they can use to resolve disagreements. It is easier to “pick a side” and see one side of a conflict as pure heroes, victims, or martyrs, and the other side as pure, inhuman villians, and weaponize individual facts and principles accordingly. And so any attempt at engaging with the positive aspects of the “wrong” side are seen as morally disqualifying.")

#text("The Hippocratic oath for doctors is popularly phrased as “first, do no harm”. A well-meaning effort to take a stance on a conflict in which one has been primarily presented with the point of view favoring one side and not the other can cause more harm than good. This is not to say that everyone should stay silent on contentious issues; but there are productive ways to speak out, and then there are those that disrupt, but do not actually advance the process forwards.")

#text("There were extensive protests and counter-protests on my campus on the crisis in Palestine earlier this year. Mostly they were strongly favoring one side or another, but there was a small group, “")#link("https://www.standing-together.org/en")[#text("Standing Together")]#text("“, involving people of both Jewish and Palestinian descent, who were advocating dialogue and mutual understanding. This was the group that I resonated with the most; however, they were much smaller than other groups, and received almost no attention proportionally in the media.")

#text("In a world where any statement on a topic as contentious as this quickly becomes overrun with heated discourse from all sides, I did not see a way forward to productively insert myself publicly in these discussions, in the classroom or elsewhere, although I did support some messages that our department sent to the University Senate during their deliberations. I still do not have a reasonable proposal to actually alleviate the suffering (of Palestinians for sure, but actually for many groups in the middle east). But I do hope that there are more platforms for sincere and constructive discussions in good faith that can actually move things forward. I feel I am not exactly the right person to try to initiate such a platform, but if someone else on this blog such knows of a venue, they are welcome to share it here; dialogue is needed everywhere, more than ever. I plan to focus primarily on issues closer to my personal experience, in particular my lived experience in the United States.")

#text("EDIT: As I expected, the comments advocating the position of one side or another on this conflict have started arriving. I have approved a small number of these as illustrative examples of the current state of discourse (and to the point I was actually making in the blog post), but I do not see the repetition of the same talking points seen in countless other venues across the internet to be a productive use of my blog here, and do not plan to let such discussion take over the space.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686632")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Do you think that developing a skill in “distinguishing an overly simple but mathematically flawed ‘solution’ from a more complex, but accurate actual solution” would be helpful for commentators on this conflict, or on similar issues? It strikes me as something of a very different nature.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686637")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("That particular skill is more useful for problems with a quantitative component, such as those involving economic policies, but I only listed that as one example; there are other mathematical skills beyond that which I believe are portable. For example, in ")#link("https://mathstodon.xyz/@tao/110838506450468613")[#text("this Mastodon post from last year")]#text(", I talk about how mathematicians have learned to value “partial progress” – something that does not fully solve the problem, but can handle a special case, or rule out a possible approach, or otherwise give insight as to what will be needed to reach a full solution. This is another precious advantage that mathematics has over many other fields, including politics. In many areas, attempting to try something, and not achieving full success, is derided as a “failure”, and often the people who perform such attempt receive more criticism than those people in a position to try something that instead played it too safe by doing nothing at all. The “freedom to fail” is an important principle that makes mathematics as successful as it is; and it is a mindset that I believe can be helpful beyond mathematics as well, and possibly even to these most difficult of political problems.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686651")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("I feel like that principle is already widely recognized across most fields. In particular I think it’s been one of the core planks of Democratic Party (and, in different ways, Republican Party) messaging for a long time, but that the degree to which it’s employed legitimately – the key question – is highly political.")

#text("For example, I feel that this principle is often pushed rather cynically to cover for work which is either a failure or (in some cases) which actually has very different true aims — but surely this perspective is strongly reflective of the fact that I’m rather left of center. Although I recognize that the “partial progress is good” principle is good, I don’t feel like my PhD in math (or any of the work which went into it) is what equips me to think about this kind of problem, much less the concrete ways it comes up.")

#text("In some cases I actually feel like it works in the opposite direction. In ways that I think have become very important in recent years, the desire for intellectual nuance can often act as a blocker of moral clarity. (Not to suggest that moral clarity can’t have nuance!)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686611")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Dear Terry,")

#text("It is good to see mathematicians coming out of their bubble and addressing real world problems. But why now, and why this particular event? Surely a democratically elected president should be the least contentious issue to speak out on? Where are the mathematicians speaking out on the ongoing genocide (recgonized by all measures, recognized by all humanitarian organizations) on Gaza? I don’t see them speak.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686616")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("I don’t agree that 40,000 people killed in a year (a third of whom are terrorists) fighting terrorists hiding in civilians and warning them to evacuate is a “genocide”. The ICJ does not call it a genocide. This says more about these left-wing NGOs than anything else.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686624")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Thanks for this wonderful post. I’m definitely going to repeat this sentiment in my own lecture this afternoon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74680e7d3505909b839e02876787114ece6d405420a7f2300d37b3dd517a4f6f-fbf38a77840ab3fd42b17849361d7edcde9aba5701ff9729ca5f853dd7bf42dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cody roux")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686626")[#strong[#text("cody roux")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("I admire your bravery and conviction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d340339cbc25e13afb404a68620ca4c9ced5a72939928744cf39de9cb22e6de9-b1f3d2c41974b8626397d605e8f85022ee2e3b1ffa07472e344413487c82c7d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pauljung")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686628")[#strong[#text("pauljung")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Thanks for this post. I’m teaching an AI/Data Science class right now, and one project I assigned was to build an election model. Today is my first class since the election, and given the project I assigned them, it’s hard to not say anything, and move on to the next topic without saying anything. I struggled about how to address it, but after reading your post, I’ve decided that this is exactly the perfect thing to say. So, a true thanks for this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686629")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("The main issue with Trump is not Trump himself. It is how such a conman and a felon can be elected President of the USA instead of being put in jail 3 or 4 decades ago already or some days after the 6th of January 4 years ago. Moreover, the electoral system of the USA is not really democratic and provides too much power to the Republicans and to the conservative States. Pootine has won.")

#text("Another issue also is that dozens of millions of Americans are unable to think.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686635")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("I disagree that the vast majority of working-class Americans are unable to think. I postulate most everyone is aware of Republican tendencies towards fascism, but they are tired of Democrats blowing off their chances every time they get elected. Grocery prices are soaring (they tripled in the last five or so years), mass immigration affects Hispanic communities (it is in fact where immigrants live to stay, not in posh cities of the blue states), minimum wage is not raised but academics get paid a ton, black communities are not helped with housing (downpayment would immediately resolve all crises).")

#text("This vote was a vote of working-class anger. Plakhanov used to say “The worse it gets, the better it gets”. People are tired of epsilon-improvements to their lives while career Democrats block progressive bills from getting passed in the senate. Academics like us live in a bubble, and the working class anger will take us down with them if we keep averting our eyes from ground reality.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686646")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Progressive bills can’t pass if the U.S. House is run by a Republican majority.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686767")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2024")])]

#text("I’m not from the US so I don’t know if there’s some nuances I’m missing here, but using data from ")#link("https://tradingeconomics.com/united-states/food-inflation")[#text("https://tradingeconomics.com/united-states/food-inflation")]#text(" it seems food prices have gone up roughly 40% in the last 5 years, not 200%.")

#text("(If I had to guess, a talking point is that “inflation has tripled” – which is far more defensible, but mathematicians will understand is a very different assertion).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/570044150d90f16b29a8906a025b503d65d3e14a01875d7060feb010b2389eda-8889ae34c3458b08263a584cc4e3fede321bd8e83a5b6950c428b5dc9f3d5fd8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jon Awbrey")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686633")[#strong[#text("Jon Awbrey")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("One place where a theory in mathematics and a theory of society come together is over the concept of ")#emph[#text("representation")]#text(", especially if we recall the old school definition of a republic as a representative democracy.")

#text("The connections deepen and expand to the disciplines of statistics, systems theory, and cybernetics (cognate in Greek with government itself). Statistics were originally the data a ship of state needed for stationkeeping and staying on course. The statistical data our governments collect are “supposed to represent” the real state the world and our society’s course through it. Our representatives in government are “supposed to represent” the will of the people who make up their constituencies.")

#text("In my reflections on the many faces of representation I find myself returning again and again to the following questions.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("What are the forces distorting our representations of what’s observed, what’s expected, and what’s intended?")

#text("What can we do to address the gap between what ought to be and what is?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ae709e4351caa78ecb5c5549127c27fe0e141b6036127389255b322082e9370-db00375cebf01103110634c72b4d811f003c27af23eb63b299d8694bceaf1b0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guanyuming He")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686640")[#strong[#text("Guanyuming He")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Dear Prof. Tao,")

#text("It is so nice to see this post of yours, which gives me more strength to fight for what I believe in, despite the past election result that was beyond our influence. It makes me feel more connected in this (perhaps) more separated world.")

#text("In the meantime, I do have some take on the topic, inspired by your post:")

#text("Although the truths are the same for everyone in mathematics, how one expresses it can contain one’s own take and may inspire other people who read it. For example, considering so many Americans didn’t vote for either of the two primary candidates, adding another probability for this in your model might inspire people who didn’t want Trump to win but still didn’t vote for Harris either because she wasn’t exactly what they wanted.")

#text("It is very sad that things have turned out to be this way, that to make a difference one has to either vote for the Republic candidate or the Democratic one, even if there are other candidates that one needs the most, because they won’t have a good chance of winning anyway. In other words, when someone like Trump can be assumed to be able to gather about half of the votes, then the only way for the rest of the people to stop him is to unite and vote for a same person other than him. Essentially, his existence and ability to gather half of the votes has limited other voters’ freedom to choose freely on who they want, which I find as an interesting phenomenon, despite being a sad fact.")

#text("Speaking of this, I recalled some vague ideas that I had while studying your Analysis I, about constructing number systems. Intuitively, when I read about the gaps in the rational numbers which led to the construction of the real numbers, I felt that perhaps it was that the each rational number are more “free” than the real numbers. That is, assume ")#mi("\\sqrt{2}")#text(" is a nasty place no number wants to be. Then in the rational numbers system, there’s still some freedom so that every number can not be it, while still satisfying the properties. However, if we add more numbers to it, then the new number’s existence will limit the other’s freedom, and eventually cause someone to be in the nasty place ")#mi("\\sqrt{2}")#text(".")

#text("I know the above idea is very informal and I haven’t given too much serious thoughts about it. I just recalled it while I am writing this comment. May I ask you if you have seen things in the current math literature that may be similar to my idea? I am sorry that I am not from a Maths Science background so I know very little of the literature.")

#text("Thank you for your time and reply in advance. Yours truly, Guanyuming He")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686641")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Thank you, Terry. Having followed your blog for over a decade, I really appreciate this post 👍")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686642")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Any such message is useful, and I always start my calculus, precalculus, and “math for poets” courses with a similar statement about the usefulness of critical thinking, both in mathematics and in other endeavors. However, surely you do not believe that the people who truly need critical thinking skills and reminding of their social value are upper-division math majors in a complex analysis course, do you? If mathematics has a role in improving the critical thinking skills of a (large fraction of) citizens, it is through lower-level courses. I know that you do a lot to reach out and educate people at a broader level. However, for some mathematicians, it would be good to remember this and pitch in with lower-level teaching (and public outreach, and training future high-school math teachers, etc.).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686644")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Here I would point to another highly mathematical principle (which technically is classified as an economic law), namely ")#link("https://en.wikipedia.org/wiki/Comparative_advantage")[#text("Ricardo’s law of comparative advantage")]#text(". The most positive impact an individual may have by investing their time and energy is not necessarily in the area of greatest absolute need, or where the individual has the greatest absolute advantage; but where they have the greatest ")#emph[#text("comparative advantage")]#text(" relative to others who could step in to perform the same task. I have done a relatively modest amount of math outreach to, say, high school students, or members of the general public; this has been important and fulfilling to me, and I believe I have a certain amount of absolute advantage in this area. But it is not my area of comparative advantage; there are many other public speakers in mathematics who could do the job either better or worse than I, but in either case be still more effective than they would be if they took over my complex analysis classes instead.")

#text("In this particular time and place, I think in fact that the ability to use platforms such as this blog to spread my thoughts on mathematics and the “real world” is currently one of my comparative advantages, though I suspect that many other academics who normally shy away from such platforms could also be surprisingly effective if they also chose to share their thoughts.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686647")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("My name showed up in the previous comment as “anonymous” (I must have forgotten to click a button), but these comments are from Jason Starr. I guess I was really speaking to a “typical” math faculty member, not to you! Many of my colleagues do not feel there is much value in public outreach, in training high school teachers, or in teaching lower-level courses. Exaggerating a bit, they think they should only be asked to teach and train graduate students, and to teach a moderate amount of upper-division undergraduate courses. Whether or not somebody else could do a better job with public outreach, etc., if a mathematician in no way engages with the broader community, they are going to feel frustrated at times like these. Engaging is a better way to deal with frustration than railing against the world and cloistering deeper in the ivory tower (again, intended for my typical colleagues, not for you!).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686650")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("That there are irreconciliabile differences of opinion is not a “sad” state of affairs.")

#text("We should not conflate consensus with truth.")

#text("We should not only celebrate democracy when our party wins.")

#text("In “times like these” we can afford some differences of opinion while maintaining a surprisingly high (for historical standards) level of tolerance, in one of the wealthiest societies ever existed.")

#text("These are seemingly obvious statements, but then maybe they aren’t, if one of our best mathematicians worries about his mental state and that of his students.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686652")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("I was getting a Lyft drive couple of months back. The lady driver (a Latino married to a black man) was indicating how the Trump administration gave Covid money to people while the Biden administration is not doing anything for price increase, letting people in with money given to them while her Latino father had to work two jobs to make it and was complaining about Harris was given a chance after making assurance Bidens will not be prosecuted and how behind the scenes it was Obama running the administration as Biden was senile. I asked the lady where she gets her news. She mentioned she watches all the channels. She mentioned ‘She really wants the job’ and Trump will be elected. ‘Trump is a businessman and his only problem was his mouth’ was also the comment. I didn’t believe it then and until election day evening I thought Kamala would win.")

#text("Similar incident happened with a Mideastern Muslim cab driver in Virginia in 2022 telling Trump economy was better as inflation was ok.")

#text("I do not know much about monetary policy, fiscal policy and their relation to inflation (neither do vast majority of Americans who likely put the blame on the Biden admin and it rhymed well with ‘what did she do for 3-4 years?’ comment) but the seeds of inflation were already cast between 2020 and 2021 with the fiscal stimulus and covid time trade difficulties. Perhaps this election was to be lost by the ruling party. How else can we explain 4-5 million popular vote loss in this election given it has taken a generation for republicans to get the popular vote majority?")

#text("Somehow the angry message of Trump resonated with the people.")

#text("Last time around the judicial system and checks were strong enough to prevent major difficulties. This time they are planning project 2025 and sweep and surrender of the administrative infrastructure seems very much realistic. There are some moderate republicans still around and we will have to see what comes in the next four years.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686653")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Is there any desire to move back to Australia where the political climate is somewhat less intense?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686655")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Do you think that it would be good to have more prediction markets and websites in decision making? In politics but in other things. I say X, you say Y, we can agree if some future events happen it gives Bayesian evidence toward this or that view of the world, we set up a market. This should tell us a lot. I think that this is something we should be promoting more. Perhaps with fake money like on manifold.markets given the regulatory issues around real money.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686660")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("There is some limited utility for these markets, although one should always be wary of institutionalizing any reliance on such markets due to the risk of invoking ")#link("https://en.wikipedia.org/wiki/Goodhart%27s_law")[#text("Goodhart’s law")]#text(". In particular, if a prediction market becomes known to be a significant factor in influencing decision making at the government level, this opens up the possibility of some foreign agency aiming to manipulate such markets in order to mainpulate policy. But as long as they stay below a certain level of importance, they can provide some additional information, and perhaps some early warning signs that other more traditional metrics cannot catch.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686656")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Do you think math funding will be cut?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686658")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("“Would my students be in the right mental state to learn math?”")

#text("is it clear that your students have your same concerns? Is it inconceivable that for some of them it might have been “a great day”? I was told of a Princeton student going around with a MAGA hat (not for the same reason Larry David did…).")

#text("Also is it safe in the US to make even a very moderate allusion to the election as you did in your class (by the way: very elegantly I think)? [Lets say for a respectable prof that is though not a super-star like yourself, and hence more “dispensable”].")

#text("does it depend on which side is the University on and which side are the allusions with?")

#text("what would have happened if a nutty prof at UCLA, after the last election would have made an indirect allusion to “rigged elections” expressing clear sympathy for that viewpoint?")

#text("sorry for the annoying questions! I don’t understand yet the USA, and, given the political climate, I am generally terrified to express any political sympathy in interactions with American academics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686659")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Well, after the 2016 election, I had not planned anything in particular for my next class, but I still got questions about the election from the students. But in 2016 I did not have students ask if they were going to be deported, or be persecuted for their gender identity, or whether the nature of an academic career would fundamentally change. Now, I do. For better or for worse, we are no longer near the equilibrium (or at least metastable) state of US politics. For some people, this may be an improvement in some ways over the status quo. For others, it will be worse, at least in the short term. But I think it is appropriate at this time to acknowledge – even in a class in pure math – that there is a substantial probability of significant change in the next few years (not just from the election, but from other global trends, for instance in AI and climate change). What remains to be seen is the precise nature of the change, and to what extent individuals and communities can help shape it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686712")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2024")])]

#text("As far as future plans and elephants in the room, do you have any plans of what to do if there is a China-Taiwan war? Obviously it would be very bad for the Taiwanese first and foremost, and it could also be very bad for Chinese academics in the US.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686741")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2024")])]

#text("This is rather surprising in my opinion.")

#text("Why would students ask their math teacher whether they are going to be deported, or be persecuted for their gender identity? It seems to me a strong indication of misjudgment both of what is really at stake with this election and of the role and knowledge of their teacher. Even assuming I am wrong about the former, I find it rather hard to think I might be wrong on the latter.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686742")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2024")])]

#text("I meet with graduate students on a one-on-one basis as part of various mentoring activities. In the past, these activities were purely mathematical in nature, but I have found (pretty much ever since the COVID pandemic) that they have acquired a personal component as well; teachers and students are humans too, and in times of uncertainty, and decreased social support from other sources, it is natural to seek out connections in places where they might not need to go look for in more secure times.")

#text("I have taken to keeping a box of tissues and other self-care items in my office. Thankfully, they have only been necessary one or two times a year so far. I hope that this frequency does not increase.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686657")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Dear professor Tao:")

#text("I just want to take this rare opportunity to thank you for your constant effort all these years not only in teaching mathematical knowledge, but also in communicating the mathematical language and imparting the mathematical way of thinking to the general public through this blog. I myself have benefited tremendously from following many of your lecture notes posted here. Together with the enlightening discussions in the comment section, they undoubtedly form one of the most valuable sources of self-learning available. I am most amazed both by your uncanny ability as an expert to break many complicated concepts into relatively approachable parts, as well as your willingness as a great teacher to get rid of the “curse of knowledge” by imagining the many possible obstacles and struggles encountered by those who are much less talented. As of the chaos in the real world, it might just be the case as you point out in your article “E pluribus num: From Complexity, Universality”, that the underlying assumption of rational human agent is an oversimplification, that people are arbitrageurs in nature, led not only by statistical facts but also by a variety of cognitive biases and personal preferences, that in view of this any short-term regularity tends to disappear in the long run. However, I still believe the logical framework of analyzing even the most complicated real-world problems can yield far-reaching results, possibly by laying a common foundation for people to rest their common sense upon, or at least prompting the public to realize the importance and urgency of having such a foundation in place. Anyway, it is really an honor to have you occasionally voice your opinions on these matters.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3458cc1d6dc3d5bbb735a2ba5169f56a77751d169b3a5fcae72671e24569f4f-bfcc572518d2b07cd31a63634318c9b68e42aef2776c75dc2c91875a08885dff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gracefullydreamb91e6cbdb2")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686663")[#strong[#text("gracefullydreamb91e6cbdb2")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Professor Tao, your observation about consensus in mathematics is compelling; however, the abc conjecture and Mochizuki’s proof provide a notable counterexample. For nearly a decade, respected mathematicians have held divergent views—Mochizuki and Scholze among them—illustrating that even in mathematics, consensus can sometimes be elusive. Perhaps a formalization of Mochizuki’s proof in Lean—by those who claim to understand it—could offer a definitive resolution to this debate.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686664")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("When after 12 years there is not only no consensus but not a single new idea in such grandiose announcements (to be exemplified in a more modest but previously unreachable progress on the problem) then consensus of the mathematical community is that there is no proof at all.")

#text("The burden to convince the community to have had a new idea is on the prover. SM had all kind of opportunities to convince a lot of smart people that he had a breakthrough idea. He failed to convey a single new idea towards abc.")

#text("The people claiming to understand this work are not even able to convey the proof in the current (still very liberal) language of practiced mathematics: forget about Lean! There is no point trying to make the recipe of the cake precise when you don’t even know a practical plan on what cake you want to bake.")

#text("The fact that some crazy billionaire covered SM of money is only further shame for the Japanese mathematical tradition, rather than a counter example to TT viewpoint here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c4d982784b9831d1c4b11982b62a5da5af40e9e9122c681a5554b03d550fca2e-ce98b74d14adc3f0aa29743aa6519e70f9f8d12f5279f62877a2df40eb81c649.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hollis Williams")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686672")[#strong[#text("Hollis Williams")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2024")])]

#text("I don’t think this is a good example of ”elusiveness of consensus” in mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686669")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2024")])]

#text("This is completely true for elementary mathematics (first year graduate mathematics and below) but is a false and propagandistic view of how the maths research community operates (or at least how it did when I was a graduate student thirty years ago).")

#text("If a mathematician is interested in an important result, it is impossible to “understand a proof” for the vast majority of interested mathematicians. The reader meets plenty of statements like “it follows that..” but the reader can not work out why it follows.")

#text("When others are consulted to explain the details, they either don’t understand it themselves or don’t have the time to explain it, or claim that they don’t have the time to explain it.")

#text("Almost all explanations of how we know that a modern mathematical proof is correct are of the form “It must be right because X says so” — exactly the type of argument that is wrongly said to be absent from maths and only present in less pure and pristine endeavours.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686694")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2024")])]

#text("This is one area where we have seen real progress in the last thirty years (though definitely still with room for further improvement). Firstly, the exposition of papers has improved, particularly with the younger generation of mathematicians, with more attention to making the results modular, motivated with examples and informal outlines of proofs, and so forth. The need for enduring formal foundations in the early twentieth century did lead to a somewhat excessively formal and abstract style by the Bourbaki era, sometimes at the cost of exposition, but the pendulum has swung back to what I believe to be a more balanced and healthy state. I think this is part due, not only to generational change, but also the increasingly collaborative and interdisciplinary nature of mathematical research, which naturally favors good communication and expository skills (in contrast to the more traditional model of a single-author work in a specialist field, where one only needs to convince an editor and some referees, as opposed to co-authors and colleagues, that the exposition is “good enough”).")

#text("Secondly, we have the promising advances in formal proof assistants (Lean, Coq, Isabelle, etc.). There are experimental efforts to use such proof assistants to create interactive human readable proofs, in which any of the notorious “it follows that…” type statements can be double-clicked to expand to a more detailed explanation, going all the way down to the fundamental axioms of mathematics if desired (see ")#link("https://www.youtube.com/watch?v=tp_h3vzkObo")[#text("this talk of Patrick Massot")]#text(" for one such effort). Lean’s Mathlib already has formalized almost all of undergraduate mathematics, and a reasonable chunk of graduate mathematics. As just one example, see ")#link("https://mathoverflow.net/questions/65729/what-are-perfectoid-spaces/307239#307239")[#text("Kevin Buzzard’s answer to the MathOverflow question")]#text(" “What is a perfectoid space?” by providing the precise definition of this concept in Lean. There is still substantial work to do in order to make these proof assistants user-friendly enough to be as widely adopted among mathematicians as, say, LaTeX or computer algebra packages such as MATLAB, SAGE, etc., but I think we will get there, particularly as AI technology improves to help make formalization of informal mathematics easier and more efficient.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686670")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2024")])]

#text("I think a quotation of Isaac Newton is relevant here: ”I can calculate the motion of heavenly bodies, but not the madness of people”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686698")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2024")])]

#text("Would you make these sorts of posts if a more normal and non-crazy Republican like JD Vance won? Say one who conceded the election when he lost and so on, doesn’t brag about getting away sexual assault, was moderate on the abortion issue, and so on.")

#text("I hope that in 2028 once Trump is gone we’ll have less partisanship.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686728")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2024")])]

#text("In twenty years, academics and intellectuals will gather in comfortable rooms to discuss the atrocities of today—the occupation of Palestine, exploitation in the Congo, the systemic oppression of Black and immigrant communities in the U.S., environmental destruction—all at a safe distance, in the luxury of hindsight. They’ll publish books, host seminars, and create curricula around today’s suffering, reaping awards and career accolades for their dissections of colonialism, oppression, and inequality. But what good is this intellectual dissection if it only happens after the damage is done? If we speak up only when it’s too late—when lands are already seized, when children’s lives are shattered, when communities are erased—then we are complicit in the devastation. We are aiding the machine of oppression by our very silence.")

#text("Consider Palestine, where children live under occupation, stripped of basic rights and human dignity. Surveillance, military algorithms, and precision weaponry enforce this control, all backed by mathematical models created by experts, used to refine efficiency and reinforce domination. The global arms industry, driven by advanced mathematics and data science, profits directly from their suffering. This is no hypothetical: the occupation, enabled by powerful mathematical and technological systems, happens every day. Meanwhile, where are the mathematicians and scientists who could challenge these systems, who could speak against the exploitation their work supports? Silent. Complicit.")

#text("But the oppression does not end at any single border. Look at the Congo, where millions are exploited to extract the rare minerals demanded by the technology industry—minerals such as cobalt, lithium, and coltan, obtained through brutal labor practices that tear lives apart. These minerals power the very devices we use in our research, our teaching, our careers. Congolese children and adults work in conditions close to slavery, caught in a cycle of poverty and violence to fuel the “innovation” and “progress” that we in mathematics and STEM fields take pride in. Our mathematics, our technology, our science build and sustain a world in which entire populations are sacrificed for the comfort and advancement of a privileged few. This is colonialism in a new form, hidden under the guise of progress but rooted in the same exploitation and disregard for human lives.")

#text("And closer to home, we see how these systems uphold and exacerbate inequality for Black and immigrant communities. Mathematical algorithms and models structure our financial, judicial, and policing systems in the U.S. They are not neutral tools but bearers of racial and economic bias. Predictive policing algorithms, risk assessment models in courts, facial recognition software—each is a mechanism of control used disproportionately against communities of color. The same society that brutalized and enslaved Black people centuries ago now uses mathematical tools to enforce poverty, inequality, and violence. For immigrant communities, including the undocumented, these algorithms lead to surveillance, criminalization, and exploitation. These are not merely technical flaws; they are mathematical weapons designed and implemented to maintain a social order rooted in racial and economic oppression.")

#text("Yet, as mathematicians, we often cling to the myth of “objectivity,” comforting ourselves with the idea that mathematics exists outside of politics, that it is immune to the injustices of the world. But this so-called neutrality is a lie—a shield that allows us to ignore the consequences of our work. Mathematics has never been neutral. It has always been shaped by political forces, often used as a tool by the powerful to justify and reinforce hierarchies. From the colonial expansion supported by resource extraction metrics to the financial models that continue to strip wealth from poor communities today, mathematics has been instrumental in justifying exploitation. When we deny this reality, we don’t remain impartial; we align ourselves with the powerful by default.")

#text("Even within our own field, we perpetuate systems of exclusion. Who has access to advanced mathematics? Who has the chance to study and build careers in STEM? The gates are closed to many, determined by factors such as race, gender, class, and socioeconomic background. Mathematics education has become a gatekeeping mechanism, only accessible to those with the resources, representation, and social support to navigate the barriers. The high cost of education, biases embedded in curricula, and a lack of mentorship for marginalized communities all conspire to limit who gets to participate in this field. Mathematics is access to power, yet we restrict this access, ensuring that marginalized communities stay marginalized, cut off from the economic and social opportunities this discipline can provide.")

#text("And for those of us already within the field, we often remain willfully ignorant of the ways our work is used. We tell ourselves that mathematics is “pure,” that our duty is to knowledge alone, not the application of our findings. This convenient excuse blinds us to the suffering our work enables. For instance, the algorithms designed in our labs become tools of war, of surveillance, of exploitation in real-world applications. Children in Gaza live under constant monitoring, their lives controlled by a military-industrial complex that uses mathematics to enhance its grip. Children in the Congo work themselves to the bone to mine materials essential to our research and teaching, sacrificed to an industry that places profit above human dignity.")

#text("In our universities and labs, we present ourselves as seekers of truth, publishing papers, attending conferences, building careers, while ignoring the exploitation that sustains it all. We host discussions on “algorithmic bias” and “equity in education” but do nothing to challenge the systemic barriers that restrict access to education and justice. We enjoy the benefits of an academic and professional system that upholds the status quo, yet we claim to be powerless, as though we are mere observers rather than active participants in a machine of exploitation.")

#text("Our cowardice in the face of injustice is complicity. By claiming “neutrality,” by refusing to engage with the political dimensions of our work, we side with the oppressors. Historians will look back on the genocide in Palestine, the resource extraction in Congo, the subjugation of Black and immigrant communities, and they will ask why we—the so-called intellectuals and experts—did nothing. Why did we allow our work to be used to oppress, rather than liberate? Why did we prioritize personal success over human rights, our careers over justice?")

#text("To “do no harm” is not enough. If we truly believe in justice, we must actively dismantle the structures of oppression that our field upholds. We must question the role of mathematics in these systems, challenge the institutions that exploit our work, and refuse to contribute to projects that perpetuate suffering. Pursuing knowledge comes with the responsibility to ensure that knowledge serves humanity, not just the powerful.")

#text("We must abandon the illusion of neutrality. Mathematics is, and always has been, political. When we pretend otherwise, we surrender the power we hold to make a difference. The comfort and security of our careers are built on a foundation of inequality and exploitation. Until we face this reality and take responsibility for the impact of our work, we are no better than the oppressors we claim to oppose.")

#text("There is no neutral ground. There are those who wield power and those who suffer under it. As mathematicians, scientists, and academics, we have a choice: to use our skills to uphold systems of oppression, or to challenge and dismantle them. This choice is not easy; it requires us to take risks, to face criticism, and to question the very systems that benefit us. But if we believe in justice, in human dignity, in a world where all can live freely, we cannot afford to remain silent. The discipline we hold so dear has power, and with that power comes a profound responsibility: to use mathematics not as a tool of oppression, but as a force for liberation and justice. The time to act is now.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ae709e4351caa78ecb5c5549127c27fe0e141b6036127389255b322082e9370-db00375cebf01103110634c72b4d811f003c27af23eb63b299d8694bceaf1b0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guanyuming He")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686747")[#strong[#text("Guanyuming He")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2024")])]

#text("Dear Anonymous,")

#text("While I agree that many math discoveries have been used for oppression, and many did indeed suffer so that we can have these good products in prestigious universities, I think there still is no good way to predict if a math discovery will be used by oppressors.")

#text("It is (perhaps) easy to decide if a company or a government is evil, and refuse to collaborate in any of its projects. However, it is hard to foresee what applications can some theorems proven today have.")

#text("Although I am not a mathematician and study computer science instead, if one day I am to enter academia, I also won’t want my discoveries to cause the suffering of others. However, apart from not collaborating with obvious evil actors, I cannot think of other ways to directly control how my discoveries are used once they are published. It is also arguable if spreading some knowledge will still be comparably good, even if some evil actors will use the knowledge to their advantage.")

#text("Could you suggest some possible ways to “use our skills to challenge and dismantle” the systems of oppression? Perhaps, many scholars knew that their discoveries were used by oppressors, but they didn’t know good ways to stop it.")

#text("I know and support your opinion that experts should speak more, and not after tragedies have happened. However, that has nothing to do with the expert’s specialized skills. I meant my comment as a friendly discussion, to potentially derive good principles which can inspire all people who see these.")

#text("Yours truly, Guanyuming He")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686743")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2024")])]

#text("I regret saying that I think there is something wrong with what you write here.")

#text("The question “Would my students be in the right mental state to learn math?” is in my opinion similar to an attitude I have seen many times and which I find inappropriate, which is talking to someone you clearly mean to respect, while at the same time giving for granted that they must surely have your same opinions about politics (or other dividing topics), because they are too clever/educated/etc to be on the other side. I have seen this error being made repeatedly, even by clever mathematicians (I know it was technically an error because I knew the opinions of the other person they were talking to). It typically creates a disrespectful effect opposite to the highest respect one meant to express.")

#text("I guess you wouldn’t have asked yourself the same question had the result been the opposite. But that means you essentially are in a state of believing you know what your students find good or bad. Perhaps you would like to think that whoever in your class is happy about Trump winning must surely be someone not very clever which would benefit from hearing why he/she is wrong.")

#text("But I think this is wrong. What is a good or bad reason to vote for one or another is not a mathematical issue, it is based on the different importance people attribute to different things. For example, is by now clear that president Biden has not been in a condition to govern for a number of months/years, much earlier than Ju 24 (there is plenty of video evidence which in retrospect cannot be considered as fake news anymore). So, who has been governing in the last period? Who is taking the important decisions? This is a very serious democracy issue. For someone, voting for a vice-president which participated in keeping this situation secret from the public might be totally unacceptable, because it goes against one of the fundamental principles of democracy.")

#text("Finally. I think, no matter who is right and who is wrong, that this kind of discussions should remain out of the classes. It is wonderful that professors decide to express their political thoughts in public as you are doing here, that is truly admirable and I would like many more professor do that. But not in class, because people pay to get in that class to be taught about math, that is our job when we are in there.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686744")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2024")])]

#text("Of course, I don’t view my students as a monolithic, homogeneous group. In fact, when I came to class that day, I was immediately greeted by some cheerful mathematical questions. But there were also some conspicuous empty seats, and the more anxious questions emerged later, in one-on-one mentoring sessions. At the risk of falling into pedantic mathematician stereotypes, I might amend the rhetorical question I addressed to myself with a universal quantifier: “Would all of my students be in the right mental state to learn math?”.")

#text("As regards the “stay in one’s lane” advice of keeping classroom activity strictly to the class topic: I agree that this is sensible advice in normal situations, which encompass at least 99% of my classes. But occasionally, the real world intrudes to an extent that some acknowledgement of it is warranted, if only to address the “elephant in the room” and allow one to return to the task at hand. To give a hypothetical example: suppose that while teaching, a violent altercation occurs on campus that can be viewed from the classroom windows. If it is not an imminent safety threat to the class, should it be acknowledged at all? Or should one deliberately ignore it and stick to what “one is paid to do”, which in this case might be to continue teaching contour integration? Personally, I view the remit of education rather broadly, and that occasionally teachable moments may occur that would not have been anticipated by the formal curriculum.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efe3aef1a4113c7ab0d47cb9b1f8f3da021a33007aad6d3e256931b095193953-c2466aab748bc7239b1c9355f20cba01cead50fd8c89a02a4ae9ac70cb555e7b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686748")[#strong[#text("Brian")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2024")])]

#text("2016 was my first year of graduate school, and I felt the same way the day after election. In the morning I attended an algebraic topology class. I had exactly the feeling you describe, where my mind was not really in the right state to learn mathematics. There was an elephant in the room, and math seemed absurd in that moment. And yet, when it was time for class to start, the professor came in and continued from where he had left off previously, just as he would on any other day. That was a profound experience for me, and one that I have thought about many times in the last 8 years; the sun still rises, and we still need to do the things that are important to us, and live our lives.")

#text("With all the fear, anger, and sadness that I have felt in the last week, I have also remembered that day, and what it meant for me to see a more experienced mathematician come to work the next day and simply continue living, despite it all. I found it important to fill that role for my students this year, and to simply come to work the next day, and continue our discussion of the fundamental theorem of calculus.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686755")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2024")])]

#text("I’m in my first year of graduate school, am a student the complex analysis class mentioned in the blog post, and funnily my experience is the opposite of yours: it had a tremendous impact on me that Prof. Tao did ")#emph[#text("not")]#text(" act as if it were just another day. I may have looked normal last Wednesday, but I arrived to class distracted and distraught. His few minutes of humanity and vulnerability before he began the lecture allowed me to regain my balance. I guess it went a long way to know that my professor empathized with how I was feeling — and it reminded me in turn to empathize with him (giving a lecture on that day was surely tough). I felt the distance between student and teacher shrink, and I’ll remember that moment when I’m at the blackboard rather than in the seat.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686758")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2024")])]

#text("Very important reflection. Plus, some thoughts when resonating with social overexcitement easily tend to become self-sustaining obsessions, and examples like yours are very important for young people to learn how to stop them.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c6aaecd7eb601e22a1d21386cbaaa626351e3683eee65137fe283fa44d37e61-414bd727857a6b10adb02690964c8b9b8124f0e0062f318860ca8759264ffe53.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gikonyo Leah")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686756")[#strong[#text("Gikonyo Leah")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2024")])]

#text("this was a good read indeed. if you missed his point of view, you simply missed it!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686759")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2024")])]

#text("There seems to be a contradiction amongst academics and mathematicians in general. We pride ourselves on objectivity and the ability to standardize the notion of progress, and yet when we are asked to evaluate our own value we rely on subjectivity. How can one justify studying math to such an extent that most professionals do, if it does not yield clear benefits to others? Surely it gives pleasure to mathematician and the ones who understand their work, but typically this is capped at a few dozen people for the true titans of the field. Let us say, for the sake of argument, tomorrow I posted a full solution of the Restriction Conjecture. How many people who read and understand that paper? How much sway would it have over their lives, and over the world at large?")

#text("Given the intellectual and emotional capital required to achieve such a result, I wonder if mathematicians are always getting a fair trade for their skills and expertise. I (through somewhat lucky circumstances) am involved in a rewrite of my state’s math curriculum. This project takes up some of my free time, but pales in comparison to the investment required to publish a research paper. If I contribute positively to this project at all, the benefits will greatly outweigh the moral impact of my entire future research career. At some point, is there not a moral market inefficiency when it comes to academics?")

#text("It was often presented to me that academia is, in and of itself, a moral endeavor. That “advancing human knowledge” or “reinventing a field” was sufficient justification to spend one’s life surround by books and manuscripts. I now seriously doubt this. Moments like this election are an opportunity for self reflection, and I believe that academia as a whole, and especially mathematicians, need to look themselves in the mirror and ask, “What is it exactly we do, here?”.")

#text("This isn’t to say mathematics is worthless and, please Tao, if you have a proof of the Restriction Conjecture in your Overleaf feel free to post it. I will, for one, get much value from it. But what does it say about the efficiency of mathematicians that their side projects (my helping with the curriculum, any Numberphile video ever made, this blog in a way) far outstrip their profession in terms of impact? It is something, I think, that at least warrants further analysis.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686760")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2024")])]

#text("There are a lot of good questions here; I can try to take a stab at some of them.")

#text("Firstly, as with many other disciplines, there is a distinction between the “positive” aspect of the field – establishing objective (or as close to objective as feasible) truths about the field, and the “normative” aspects – assigning subjective value to the importance and impact of various objective claims. Mathematics is fortunate in that it has a precise and nearly universally agreed upon framework to evaluate the former, but as with most other fields, the latter is much more fluid and human. This is necessary due to the fact that the future development and applicability of mathematics is quite uncertain, and so one cannot prescribe unduly rigid rules in advance as to how to direct progress in the field. This is in contrast to a more artificial setting, such as a chess tournament, where the rules for what constitute a “win” are set in advance, and one has clear guidance regarding, for instance, what types of chess strategies should be supported and which ones should not be. (Though, even in the fields of competitive sports such as chess, the very rules of a competition do sometimes evolve over time, through the same messy, human process one sees in any other sphere of human endeavor.)")

#text("It is always a tricky question to ask what mathematics really is, and what mathematicians actually do. I attempted to address these sorts of questions many years ago when I was solicited to write an essay on the topic of “")#link("https://arxiv.org/abs/math/0702396")[#text("What is good mathematics?")]#text("“. Another answer I would give is the apparently tautological one: “Mathematics is what mathematicians study, and mathematicians are those people who study mathematics”. This sounds like an utterly vacuous answer, but I view it as describing (in informal terms) the coupled dynamical system between mathematical results in the literature on one hand, and mathematicians on the other. Sometimes, a mathematical field uncovers an interesting new technique or phenomenon or result, which leads many human mathematicians to become excited and pour into the subject, elevating its profile and activity; conversely, sometimes a field stops producing results of broader interest, and gradually mathematicians drift away to other fields. The dynamics is hard to predict in advance, and can sometimes give the impression that mathematics is evolving in a purely random way, or primarily dictated by the personal tastes of a few particularly influential leaders or schools. But, as I argue in that essay, there appears to be some underlying structures in the mathematical space of results that we are slowly trying to explore that seem to guide us towards some notion of “inherently good” mathematics, even if we are not consciously aware that we are doing so. In particular, we have the “unreasonable effectiveness” phenomenon that purely curiosity-driven mathematical research has repeatedly shown to “accidentally” have some real world application some years down the line, though often in a very indirect sense. You mention the restriction conjecture; as ")#link("https://arxiv.org/abs/math/0008098")[#text("I wrote in an old Notices article")]#text(", previous work on the restriction conjecture has led to the ability to study nonlinear waves (via Strichartz estimates and their relatives), and has very indirectly impacted modern scientific areas such as gravitational astronomy; in recent years researchers in the general area of restriction theory have discovered a powerful cousin of that theory, namely decoupling theorems, which have resolved outstanding conjectures in number theory, combinatorial incidence geometry, and PDE. The work on the Kakeya conjecture that was in large part motivated by the restriction conjecture has led to new pseudorandomness extractors in computer science. And so forth. These developments are often unanticipated, and the best way we know to stumble upon them is to have a relatively small number of academics pursue basic, curiosity-driven research as their area of comparative advantage (even as a much larger (and typically better funded) body of more practically oriented scientists and engineers in both academia and industry pursue more applications-oriented technologies).")

#text("That said, I certainly believe that the outreach activities of pure mathematicians should be valued more by the mathematical community (and, in particular, be taken into consideration as part of cases for hiring and promotion), and that we could do much more to build meaningful connections with the broader public. I am particularly excited about the possibility for modern technologies to truly enable “citizen mathematics”, in which mathematical research can be opened up, at least in part, to a broader community than academic PhD-holding mathematicians, as I believe this will help reduce the disconnect between the academic community and the rest of society that you allude to.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db070355fdb640ad2c7e83f2901c04633b4e24c7b6e1d2ee2589133350895006-f9da2e26c1544e14f1a4e3e3f414c5d1d407558530a6ed84bd66e870340def56.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Krause")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686774")[#strong[#text("Andrew Krause")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2024")])]

#text("This is very well-written, and I appreciate both the human sentiment needed in the direction and impact of mathematics, as well as embracing the fluidity of how the field changes.")

#text("One area where mathematics has not evolved quite as rapidly as other fields is in embracing computational approaches, particularly in terms of communciating ideas. My collaborators and my own work touches on this a bit. We have recently developed the real-time interactive PDE simulation website ")#link("https://visualpde.com/")[#text("VisualPDE.com")]#text(", which is hopefully helping to bring quite ‘advanced’ topics like solitons, nonlinear waves, pattern formation etc to wider audiences without needing as much background to appreciate or interact with these things at an intuitive level. I think the current efforts with Lean/AI and other diagrammatic approaches are also very helpful to make mathematics more accessible and easier to communicate, both within ourselves and with others who may benefit from it.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686786")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2024")])]

#text("Mathematics offers a rare clarity: consensus on truth and method. Teaching this skill can resonate far beyond equations, helping navigate complex real-world challenges with precision and insight.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d5fe7fc8f0924d55a0ec7e61908a120ffbf4e311ee87e6e11e6c3fa34b790b38-a2dd7101d53f27222dc84e3ac81f2055c79014f4f255c3758486b7fcebbc9ee9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rich")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686790")[#strong[#text("rich")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2024")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("But there is one precious thing mathematics has, that almost no other field currently enjoys: a consensus on what the ground truth is, and how to reach it")
]

#text("I’m always embarrassed to tell people that I’m a math major, since I don’t think that I’m very good at math- and my transcript agrees. However, it was the pursuit of truth that brought me to math, and I couldn’t have imagine studying anything else for 4 years. Math is so beautiful, and yet it feels so apathetic- especially in times like these. This was a really lovely read!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686799")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2024")])]

#text("A sense of community is important, even among mathematicians. One source of inspiration: ")#link("https://youtu.be/4Gykqp0grE0?si=zEWn1KhwPJoTQu-x")[#text("Leelavati Prize — Ali Nesin — ICM2018")]#text(" (a YouTube video on the origins of the Nesin Mathematics Village).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686801")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2024")])]

#text("I think the problem is that (I readed your post in Mastodon, about what you thought), but i think obviously anybody can agreed about one proposition or another, at least in Math, the difference is that aren’t based tacit knowledge or subjetive appreciation. Most of them, obviously can be proof. But unlike many Social Science even Natural Sciences at some extent can happen that. Because causality has a role prommently about real world, nobody can control causalities of social world. For example to answer if a behavior for a human acts aggresively with its ideals, if it’s true or false. Obviously, one can thought if it’s rational to own or other people to find that he does is right. But since Subjetive affirmations are still hold at Social Sciences, can’t be like an universal agreement about what is true or not. Obviously, in the hypothetical case about we know that factor are objetive that control human behavior or any social values, then it’s plausible to made if it’s true or not, to achieve a consensus. Otherwise, Biology never have reached that point of being a Natural Science, since most people thought at that time that a human species can’t be studied at from point of view objectively (see it, Darwin and its theory about human population or any population).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/570044150d90f16b29a8906a025b503d65d3e14a01875d7060feb010b2389eda-8889ae34c3458b08263a584cc4e3fede321bd8e83a5b6950c428b5dc9f3d5fd8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jon Awbrey")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686837")[#strong[#text("Jon Awbrey")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2024")])]

#text("The only question now is how big a crime he will have to commit before everyone realizes how big a criminal he’s always been.")

#text("The only certainty is that he will keep pushing the envelope.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686863")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2024")])]

#text("If the one thing mathematician had is the consensus about truth, this consensus is valid on the long run only. What about Kronecker attacking the mental state of Cantor, or Scholtz/Mochizuki feud ? Maths is about concept creation as famously said Cantor then his essence is freedom.Or is it anything else ? Maths is about fruitfullness of starting point and results thought Peirce pragmaticism… «")#link("https://www.azquotes.com/quote/254928")[#text("Mathematics may be defined as the subject in which we never know what we are talking about, nor whether what we are saying is true.")]#text("» Russell.")

#text("Maths is idea of God nothing else said Ramanujan.")

#text("Maths is only a tool said some ….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686875")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2024")])]

#text("I think you certainly have a right to vote and voice your concerns but please remember that you are only one out of hundreds of millions of Americans. Even though you are an elite and I value your voice and opinion but please be aware of the people who voiced a different opinion this election. Even if they are less intelligent, their voice matters.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-686944")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2024")])]

#text("Dear Terry,")

#text("As a previous trained mathematician (ex-postdoc at UCLA) who is now working in a coorporate world, I feel lucky to see maths everyday: in business, finance, in how people interract, etc.")

#text("Math is really beautiful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-687085")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2025")])]

#text("This question is Godel style. Removing Birthright citizenship? Is it axiomatically possible without the USA becoming something else first (like a dictatorship or maybe some other union)? Is becoming like a dictatorship or maybe some other union axiomatically possible?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-687235")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2025")])]

#text("Many schools are undergoing funding and graduate student cuts. How much would UCLA be impacted? Would it face 25% cut in graduate admissions and funding cuts too?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-688554")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2025")])]

#text("UCLA funding cut. very bad. Will we survive till next midterm?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/08/the-elephant-in-the-room/#comment-689211")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2025")])]

#text("A long time ago I was an undergrad in your analysis honors series. Now (and for the last decade) I have been a career scientist at the NIH. As a small consolation I would say that you and others have succeeded.")
]
