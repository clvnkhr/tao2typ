// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/
// Converted to Typst by tao2typ: "2026-10-14T16:38:33.988306+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The alternative hypothesis for unitary matrices", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The alternative hypothesis for unitary matrices")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 May 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/")[#text("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In a ")#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/")[#text("recent post")]#text(" I discussed how the Riemann zeta function ")#mi("{\\zeta}")#text(" can be locally approximated by a polynomial, in the sense that for randomly chosen ")#mi("{t \\in [T,2T]}")#text(" one has an approximation ")#metadata(none) <tao-4a70fe9aa6436e02c2de>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\zeta(\\frac{1}{2} + it - \\frac{2\\pi i z}{\\log T}) \\approx P_t( e^{2\\pi i z/N} )")]]

#text("where ")#mi("{N}")#text(" grows slowly with ")#mi("{T}")#text(", and ")#mi("{P_t}")#text(" is a polynomial of degree ")#mi("{N}")#text(". Assuming the Riemann hypothesis (as we will throughout this post), the zeroes of ")#mi("{P_t}")#text(" should all lie on the unit circle, and one should then be able to write ")#mi("{P_t}")#text(" as a scalar multiple of the characteristic polynomial of (the inverse of) a unitary matrix ")#mi("{U = U_t \\in U(N)}")#text(", which we normalise as ")#metadata(none) <tao-75a1b65144b46b8739e3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("P_t(Z) = \\exp(A_t) \\mathrm{det}(1 - ZU).")]]

#text("Here ")#mi("{A_t}")#text(" is some quantity depending on ")#mi("{t}")#text(". We view ")#mi("{U}")#text(" as a random element of ")#mi("{U(N)}")#text("; in the limit ")#mi("{T \\rightarrow \\infty}")#text(", the GUE hypothesis is equivalent to ")#mi("{U}")#text(" becoming equidistributed with respect to Haar measure on ")#mi("{U(N)}")#text(" (also known as the ")#link("https://en.wikipedia.org/wiki/Circular_ensemble")[#text("Circular Unitary Ensemble")]#text(", CUE; it is to the unit circle what the ")#link("https://en.wikipedia.org/wiki/Gaussian_unitary_ensemble")[#text("Gaussian Unitary Ensemble")]#text(" (GUE) is on the real line). One can also view ")#mi("{U}")#text(" as analogous to the “")#link("https://en.wikipedia.org/wiki/Arithmetic_and_geometric_Frobenius")[#text("geometric Frobenius")]#text("” operator in the function field setting, though unfortunately it is difficult at present to make this analogy any more precise (due, among other things, to the lack of a sufficiently satisfactory theory of the “")#link("https://en.wikipedia.org/wiki/Field_with_one_element")[#text("field of one element")]#text("“).")

#text("Taking logarithmic derivatives of ")#link(<tao-75a1b65144b46b8739e3>)[#text("(2)")]#text(", we have ")#metadata(none) <tao-762c0bc8c300e14b6ecd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("-\\frac{P^{\\prime}_t(Z)}{P_t(Z)} = \\mathrm{tr}( U (1-ZU)^{-1} ) = \\sum_{j=1}^\\infty Z^{j-1} \\mathrm{tr} U^j")]]

#text("and hence on taking logarithmic derivatives of ")#link(<tao-4a70fe9aa6436e02c2de>)[#text("(1)")]#text(" in the ")#mi("{z}")#text(" variable we (heuristically) have")

#align(center)[#tao-fit-display[#mitex("-\\frac{2\\pi i}{\\log T} \\frac{\\zeta^{\\prime}}{\\zeta}( \\frac{1}{2} + it - \\frac{2\\pi i z}{\\log T}) \\approx \\frac{2\\pi i}{N} \\sum_{j=1}^\\infty e^{2\\pi i jz/N} \\mathrm{tr} U^j.")]]

#text("Morally speaking, we have")

#align(center)[#tao-fit-display[#mitex("- \\frac{\\zeta^{\\prime}}{\\zeta}( \\frac{1}{2} + it - \\frac{2\\pi i z}{\\log T}) = \\sum_{n=1}^\\infty \\frac{\\Lambda(n)}{n^{1/2+it}} e^{2\\pi i z (\\log n/\\log T)}")]]

#text("so on comparing coefficients we expect to interpret the moments ")#mi("{\\mathrm{tr} U^j}")#text(" of ")#mi("{U}")#text(" as a finite Dirichlet series: ")#metadata(none) <tao-bdd6b1b225fd2cb37095>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\mathrm{tr} U^j \\approx \\frac{N}{\\log T} \\sum_{T^{(j-1)/N} < n \\leq T^{j/N}} \\frac{\\Lambda(n)}{n^{1/2+it}}.")]]

#text("To understand the distribution of ")#mi("{U}")#text(" in the unitary group ")#mi("{U(N)}")#text(", it suffices to understand the distribution of the moments ")#metadata(none) <tao-6397a1438f96981870ce>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("{\\bf E}_t \\prod_{j=1}^k (\\mathrm{tr} U^j)^{a_j} (\\overline{\\mathrm{tr} U^j})^{b_j}")]]

#text("where ")#mi("{{\\bf E}_t}")#text(" denotes averaging over ")#mi("{t \\in [T,2T]}")#text(", and ")#mi("{k, a_1,\\dots,a_k, b_1,\\dots,b_k \\geq 0}")#text(". The GUE hypothesis asserts that in the limit ")#mi("{T \\rightarrow \\infty}")#text(", these moments converge to their CUE counterparts ")#metadata(none) <tao-90702519477f8ad8adee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("{\\bf E}_{\\mathrm{CUE}} \\prod_{j=1}^k (\\mathrm{tr} U^j)^{a_j} (\\overline{\\mathrm{tr} U^j})^{b_j}")]]

#text("where ")#mi("{U}")#text(" is now drawn uniformly in ")#mi("{U(n)}")#text(" with respect to the CUE ensemble, and ")#mi("{{\\bf E}_{\\mathrm{CUE}}}")#text(" denotes expectation with respect to that measure.")

#text("The moment ")#link(<tao-90702519477f8ad8adee>)[#text("(6)")]#text(" vanishes unless one has the homogeneity condition ")#metadata(none) <tao-2eca094654ff645c50cf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\sum_{j=1}^k j a_j = \\sum_{j=1}^k j b_j.")]]

#text("This follows from the fact that for any phase ")#mi("{\\theta \\in {\\bf R}}")#text(", ")#mi("{e(\\theta) U}")#text(" has the same distribution as ")#mi("{U}")#text(", where we use the number theory notation ")#mi("{e(\\theta) := e^{2\\pi i\\theta}}")#text(".")

#text("In the case when the degree ")#mi("{\\sum_{j=1}^k j a_j}")#text(" is low, we can use representation theory to establish the following simple formula for the moment ")#link(<tao-90702519477f8ad8adee>)[#text("(6)")]#text(", as evaluated ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1274717")[#text("by Diaconis and Shahshahani")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Low moments in CUE model)")]#text(" ")#metadata(none) <tao-db8a7e5d2e270256ff94>#text(" If ")#metadata(none) <tao-7afee126181838479e85>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\sum_{j=1}^k j a_j \\leq N,")]]

#text("then the moment ")#link(<tao-90702519477f8ad8adee>)[#text("(6)")]#text(" vanishes unless ")#mi("{a_j=b_j}")#text(" for all ")#mi("{j}")#text(", in which case it is equal to ")#metadata(none) <tao-21b5932ed6a0c67b7991>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\prod_{j=1}^k j^{a_j} a_j!.")]]
]

#text("Another way of viewing this proposition is that for ")#mi("{U}")#text(" distributed according to CUE, the random variables ")#mi("{\\mathrm{tr} U^j}")#text(" are distributed like independent complex random variables of mean zero and variance ")#mi("{j}")#text(", as long as one only considers moments obeying ")#link(<tao-7afee126181838479e85>)[#text("(8)")]#text(". This identity definitely breaks down for larger values of ")#mi("{a_j}")#text(", so one only obtains central limit theorems in certain limiting regimes, notably when one only considers a fixed number of ")#mi("{j}")#text("‘s and lets ")#mi("{N}")#text(" go to infinity. (The paper of Diaconis and Shahshahani writes ")#mi("{\\sum_{j=1}^k a_j + b_j}")#text(" in place of ")#mi("{\\sum_{j=1}^k j a_j}")#text(", but I believe this to be a typo.)")

#emph[#text("Proof:")]#text(" Let ")#mi("{D}")#text(" be the left-hand side of ")#link(<tao-7afee126181838479e85>)[#text("(8)")]#text(". We may assume that ")#link(<tao-2eca094654ff645c50cf>)[#text("(7)")]#text(" holds since we are done otherwise, hence")

#align(center)[#tao-fit-display[#mitex("D = \\sum_{j=1}^k j a_j = \\sum_{j=1}^k j b_j.")]]

#text("Our starting point is ")#link("https://en.wikipedia.org/wiki/Schur%E2%80%93Weyl_duality")[#text("Schur-Weyl duality")]#text(". Namely, we consider the ")#mi("{n^D}")#text("-dimensional complex vector space")

#align(center)[#tao-fit-display[#mitex("({\\bf C}^n)^{\\otimes D} = {\\bf C}^n \\otimes \\dots \\otimes {\\bf C}^n.")]]

#text("This space has an action of the product group ")#mi("{S_D \\times GL_n({\\bf C})}")#text(": the symmetric group ")#mi("{S_D}")#text(" acts by permutation on the ")#mi("{D}")#text(" tensor factors, while the general linear group ")#mi("{GL_n({\\bf C})}")#text(" acts diagonally on the ")#mi("{{\\bf C}^n}")#text(" factors, and the two actions commute with each other. Schur-Weyl duality gives a decomposition ")#metadata(none) <tao-eafe895eb8119e6e5d06>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("({\\bf C}^n)^{\\otimes D} \\equiv \\bigoplus_\\lambda V^\\lambda_{S_D} \\otimes V^\\lambda_{GL_n({\\bf C})}")]]

#text("where ")#mi("{\\lambda}")#text(" ranges over Young tableaux of size ")#mi("{D}")#text(" with at most ")#mi("{n}")#text(" rows, ")#mi("{V^\\lambda_{S_D}}")#text(" is the ")#mi("{S_D}")#text("-irreducible unitary representation corresponding to ")#mi("{\\lambda}")#text(" (which can be constructed for instance using ")#link("https://en.wikipedia.org/wiki/Specht_module")[#text("Specht modules")]#text("), and ")#mi("{V^\\lambda_{GL_n({\\bf C})}}")#text(" is the ")#mi("{GL_n({\\bf C})}")#text("-irreducible polynomial representation corresponding with highest weight ")#mi("{\\lambda}")#text(".")

#text("Let ")#mi("{\\pi \\in S_D}")#text(" be a permutation consisting of ")#mi("{a_j}")#text(" cycles of length ")#mi("{j}")#text(" (this is uniquely determined up to conjugation), and let ")#mi("{g \\in GL_n({\\bf C})}")#text(". The pair ")#mi("{(\\pi,g)}")#text(" then acts on ")#mi("{({\\bf C}^n)^{\\otimes D}}")#text(", with the action on basis elements ")#mi("{e_{i_1} \\otimes \\dots \\otimes e_{i_D}}")#text(" given by")

#align(center)[#tao-fit-display[#mitex("g e_{\\pi(i_1)} \\otimes \\dots \\otimes g_{\\pi(i_D)}.")]]

#text("The trace of this action can then be computed as")

#align(center)[#tao-fit-display[#mitex("\\sum_{i_1,\\dots,i_D \\in \\{1,\\dots,n\\}} g_{\\pi(i_1),i_1} \\dots g_{\\pi(i_D),i_D}")]]

#text("where ")#mi("{g_{i,j}}")#text(" is the ")#mi("{ij}")#text(" matrix coefficient of ")#mi("{g}")#text(". Breaking up into cycles and summing, this is just")

#align(center)[#tao-fit-display[#mitex("\\prod_{j=1}^k \\mathrm{tr}(g^j)^{a_j}.")]]

#text("But we can also compute this trace using the Schur-Weyl decomposition ")#link(<tao-eafe895eb8119e6e5d06>)[#text("(10)")]#text(", yielding the identity ")#metadata(none) <tao-e77c4b3f81059b97c4d2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\prod_{j=1}^k \\mathrm{tr}(g^j)^{a_j} = \\sum_\\lambda \\chi_\\lambda(\\pi) s_\\lambda(g)")]]

#text("where ")#mi("{\\chi_\\lambda: S_D \\rightarrow {\\bf C}}")#text(" is the character on ")#mi("{S_D}")#text(" associated to ")#mi("{V^\\lambda_{S_D}}")#text(", and ")#mi("{s_\\lambda: GL_n({\\bf C}) \\rightarrow {\\bf C}}")#text(" is the character on ")#mi("{GL_n({\\bf C})}")#text(" associated to ")#mi("{V^\\lambda_{GL_n({\\bf C})}}")#text(". As is well known, ")#mi("{s_\\lambda(g)}")#text(" is just the ")#link("https://en.wikipedia.org/wiki/Schur_polynomial")[#text("Schur polynomial")]#text(" of weight ")#mi("{\\lambda}")#text(" applied to the (algebraic, generalised) eigenvalues of ")#mi("{g}")#text(". We can specialise to unitary matrices to conclude that")

#align(center)[#tao-fit-display[#mitex("\\prod_{j=1}^k \\mathrm{tr}(U^j)^{a_j} = \\sum_\\lambda \\chi_\\lambda(\\pi) s_\\lambda(U)")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("\\prod_{j=1}^k \\mathrm{tr}(U^j)^{b_j} = \\sum_\\lambda \\chi_\\lambda(\\pi^{\\prime}) s_\\lambda(U)")]]

#text("where ")#mi("{\\pi^{\\prime} \\in S_D}")#text(" consists of ")#mi("{b_j}")#text(" cycles of length ")#mi("{j}")#text(" for each ")#mi("{j=1,\\dots,k}")#text(". On the other hand, the characters ")#mi("{s_\\lambda}")#text(" are an orthonormal system on ")#mi("{L^2(U(N))}")#text(" with the CUE measure. Thus we can write the expectation ")#link(<tao-90702519477f8ad8adee>)[#text("(6)")]#text(" as ")#metadata(none) <tao-09f5ffef28309853265c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\sum_\\lambda \\chi_\\lambda(\\pi) \\overline{\\chi_\\lambda(\\pi^{\\prime})}.")]]

#text("Now recall that ")#mi("{\\lambda}")#text(" ranges over all the Young tableaux of size ")#mi("{D}")#text(" with at most ")#mi("{N}")#text(" rows. But by ")#link(<tao-7afee126181838479e85>)[#text("(8)")]#text(" we have ")#mi("{D \\leq N}")#text(", and so the condition of having ")#mi("{N}")#text(" rows is redundant. Hence ")#mi("{\\lambda}")#text(" now ranges over ")#emph[#text("all")]#text(" Young tableaux of size ")#mi("{D}")#text(", which as is well known enumerates all the irreducible representations of ")#mi("{S_D}")#text(". One can then use the standard orthogonality properties of characters to show that the sum ")#link(<tao-09f5ffef28309853265c>)[#text("(12)")]#text(" vanishes if ")#mi("{\\pi}")#text(", ")#mi("{\\pi^{\\prime}}")#text(" are not conjugate, and is equal to ")#mi("{D!}")#text(" divided by the size of the conjugacy class of ")#mi("{\\pi}")#text(" (or equivalently, by the size of the centraliser of ")#mi("{\\pi}")#text(") otherwise. But the latter expression is easily computed to be ")#mi("{\\prod_{j=1}^k j^{a_j} a_j!}")#text(", giving the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" We illustrate the identity ")#link(<tao-e77c4b3f81059b97c4d2>)[#text("(11)")]#text(" when ")#mi("{D=3}")#text(", ")#mi("{n \\geq 3}")#text(". The Schur polynomials are given as")

#tao-aligned(keep: true)[


#tao-math("s_{3}(g)  & = \\sum_i \\lambda_i^3 + \\sum_{i<j} \\lambda_i^2 \\lambda_j + \\lambda_i \\lambda_j^2 + \\sum_{i<j<k} \\lambda_i \\lambda_j \\lambda_k", block: true)



#tao-math("s_{2,1}(g)  & = \\sum_{i < j} \\lambda_i^2 \\lambda_j + \\sum_{i < j,k} \\lambda_i \\lambda_j \\lambda_k", block: true)



#tao-math("s_{1,1,1}(g)  & = \\sum_{i<j<k} \\lambda_i \\lambda_j \\lambda_k", block: true)
]

#text("where ")#mi("{\\lambda_1,\\dots,\\lambda_n}")#text(" are the (generalised) eigenvalues of ")#mi("{g}")#text(", and the formula ")#link(<tao-e77c4b3f81059b97c4d2>)[#text("(11)")]#text(" in this case becomes")

#tao-aligned(keep: true)[


#tao-math("\\mathrm{tr}(g^3)  & = s_{3}(g) - s_{2,1}(g) + s_{1,1,1}(g)", block: true)



#tao-math("\\mathrm{tr}(g^2) \\mathrm{tr}(g)  & = s_{3}(g) - s_{1,1,1}(g)", block: true)



#tao-math("\\mathrm{tr}(g)^3  & = s_{3}(g) + 2 s_{2,1}(g) + s_{1,1,1}(g).", block: true)
]

#text("The functions ")#mi("{s_{1,1,1}, s_{2,1}, s_3}")#text(" are orthonormal on ")#mi("{U(n)}")#text(", so the three functions ")#mi("{\\mathrm{tr}(g^3), \\mathrm{tr}(g^2) \\mathrm{tr}(g), \\mathrm{tr}(g)^3}")#text(" are also, and their ")#mi("{L^2}")#text(" norms are ")#mi("{\\sqrt{3}}")#text(", ")#mi("{\\sqrt{2}}")#text(", and ")#mi("{\\sqrt{6}}")#text(" respectively, reflecting the size in ")#mi("{S_3}")#text(" of the centralisers of the permutations ")#mi("{(123)}")#text(", ")#mi("{(12)}")#text(", and ")#mi("{\\mathrm{id}}")#text(" respectively. If ")#mi("{n}")#text(" is instead set to say ")#mi("{2}")#text(", then the ")#mi("{s_{1,1,1}}")#text(" terms now disappear (the Young tableau here has too many rows), and the three quantities here now have some non-trivial covariance.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" Consider the moment ")#tao-math("{{\\bf E}_{\\mathrm{CUE}} \\left|\\mathrm{tr} U^j\\right|^2}", block: false)#text(". For ")#mi("{j \\leq N}")#text(", the above proposition shows us that this moment is equal to ")#mi("{D}")#text(". What happens for ")#mi("{j>N}")#text("? The formula ")#link(<tao-09f5ffef28309853265c>)[#text("(12)")]#text(" computes this moment as")

#align(center)[#tao-fit-display[#tao-math("\\sum_\\lambda \\left|\\chi_\\lambda(\\pi)\\right|^2", block: true)]]

#text("where ")#mi("{\\pi}")#text(" is a cycle of length ")#mi("{j}")#text(" in ")#mi("{S_j}")#text(", and ")#mi("{\\lambda}")#text(" ranges over all Young tableaux with size ")#mi("{j}")#text(" and at most ")#mi("{N}")#text(" rows. The ")#link("https://en.wikipedia.org/wiki/Murnaghan%E2%80%93Nakayama_rule")[#text("Murnaghan-Nakayama rule")]#text(" tells us that ")#mi("{\\chi_\\lambda(\\pi)}")#text(" vanishes unless ")#mi("{\\lambda}")#text(" is a hook (all but one of the non-zero rows consisting of just a single box; this also can be interpreted as an exterior power representation on the space ")#mi("{{\\bf C}^j_{\\sum=0}}")#text(" of vectors in ")#mi("{{\\bf C}^j}")#text(" whose coordinates sum to zero), in which case it is equal to ")#mi("{\\pm 1}")#text(" (depending on the parity of the number of non-zero rows). As such we see that this moment is equal to ")#mi("{N}")#text(". Thus in general we have ")#metadata(none) <tao-81b637d8fcd2c6da6359>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("{\\bf E}_{\\mathrm{CUE}} \\left|\\mathrm{tr} U^j\\right|^2 = \\min(j,N).", block: true)]]
]

#text("Now we discuss what is known for the analogous moments ")#link(<tao-6397a1438f96981870ce>)[#text("(5)")]#text(". Here we shall be rather non-rigorous, in particular ignoring an annoying “Archimedean” issue that the product of the ranges ")#mi("{T^{(j-1)/N} < n \\leq T^{j/N}}")#text(" and ")#mi("{T^{(k-1)/N} < n \\leq T^{k/N}}")#text(" is not quite the range ")#mi("{T^{(j+k-1)/N} < n \\leq T^{j+k/N}}")#text(" but instead leaks into the adjacent range ")#mi("{T^{(j+k-2)/N} < n \\leq T^{j+k-1/N}}")#text(". This issue can be addressed by working in a “weak\" sense in which parameters such as ")#mi("{j,k}")#text(" are averaged over fairly long scales, or by passing to a function field analogue of these questions, but we shall simply ignore the issue completely and work at a heuristic level only. For similar reasons we will ignore some technical issues arising from the sharp cutoff of ")#mi("{t}")#text(" to the range ")#mi("{[T,2T]}")#text(" (it would be slightly better technically to use a smooth cutoff).")

#text("One can morally expand out ")#link(<tao-6397a1438f96981870ce>)[#text("(5)")]#text(" using ")#link(<tao-bdd6b1b225fd2cb37095>)[#text("(4)")]#text(" as ")#metadata(none) <tao-43385991f0be5fed6db7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("(\\frac{N}{\\log T})^{J+K} \\sum_{n_1,\\dots,n_J,m_1,\\dots,m_K} \\frac{\\Lambda(n_1) \\dots \\Lambda(n_J) \\Lambda(m_1) \\dots \\Lambda(m_K)}{n_1^{1/2} \\dots n_J^{1/2} m_1^{1/2} \\dots m_K^{1/2}} \\times")]]

#align(center)[#tao-fit-display[#mitex("\\times {\\bf E}_t (m_1 \\dots m_K / n_1 \\dots n_J)^{it}")]]

#text("where ")#mi("{J := \\sum_{j=1}^k a_j}")#text(", ")#mi("{K := \\sum_{j=1}^k b_j}")#text(", and the integers ")#mi("{n_i,m_i}")#text(" are in the ranges")

#align(center)[#tao-fit-display[#mitex("T^{(j-1)/N} < n_{a_1 + \\dots + a_{j-1} + i} \\leq T^{j/N}")]]

#text("for ")#mi("{j=1,\\dots,k}")#text(" and ")#mi("{1 \\leq i \\leq a_j}")#text(", and")

#align(center)[#tao-fit-display[#mitex("T^{(j-1)/N} < m_{b_1 + \\dots + b_{j-1} + i} \\leq T^{j/N}")]]

#text("for ")#mi("{j=1,\\dots,k}")#text(" and ")#mi("{1 \\leq i \\leq b_j}")#text(". Morally, the expectation here is negligible unless ")#metadata(none) <tao-3a56ed4c4e3906afa099>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("m_1 \\dots m_K = (1 + O(1/T)) n_1 \\dots n_J")]]

#text("in which case the expecation is oscillates with magnitude one. In particular, if ")#link(<tao-2eca094654ff645c50cf>)[#text("(7)")]#text(" fails (with some room to spare) then the moment ")#link(<tao-6397a1438f96981870ce>)[#text("(5)")]#text(" should be negligible, which is consistent with the analogous behaviour for the moments ")#link(<tao-90702519477f8ad8adee>)[#text("(6)")]#text(". Now suppose that ")#link(<tao-7afee126181838479e85>)[#text("(8)")]#text(" holds (with some room to spare). Then ")#mi("{n_1 \\dots n_J}")#text(" is significantly less than ")#mi("{T}")#text(", so the ")#mi("{O(1/T)}")#text(" multiplicative error in ")#link(<tao-3a56ed4c4e3906afa099>)[#text("(15)")]#text(" becomes an additive error of ")#mi("{o(1)}")#text(". On the other hand, because of the fundamental ")#emph[#text("integrality gap")]#text(" – that the integers are always separated from each other by a distance of at least ")#mi("{1}")#text(" – this forces the integers ")#mi("{m_1 \\dots m_K}")#text(", ")#mi("{n_1 \\dots n_J}")#text(" to in fact be equal: ")#metadata(none) <tao-771728d4801d53be6894>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("m_1 \\dots m_K = n_1 \\dots n_J.")]]

#text("The von Mangoldt factors ")#mi("{\\Lambda(n_1) \\dots \\Lambda(n_J) \\Lambda(m_1) \\dots \\Lambda(m_K)}")#text(" effectively restrict ")#mi("{n_1,\\dots,n_J,m_1,\\dots,m_K}")#text(" to be prime (the effect of prime powers is negligible). By the fundamental theorem of arithmetic, the constraint ")#link(<tao-771728d4801d53be6894>)[#text("(16)")]#text(" then forces ")#mi("{J=K}")#text(", and ")#mi("{n_1,\\dots,n_J}")#text(" to be a permutation of ")#mi("{m_1,\\dots,m_K}")#text(", which then forces ")#mi("{a_j = b_j}")#text(" for all ")#mi("{j=1,\\dots,k}")#text("._ For a given ")#mi("{n_1,\\dots,n_J}")#text(", the number of possible ")#mi("{m_1 \\dots m_K}")#text(" is then ")#mi("{\\prod_{j=1}^k a_j!}")#text(", and the expectation in ")#link(<tao-43385991f0be5fed6db7>)[#text("(14)")]#text(" is equal to ")#mi("{1}")#text(". Thus this expectation is morally")

#align(center)[#tao-fit-display[#mitex("(\\frac{N}{\\log T})^{J+K} \\sum_{n_1,\\dots,n_J} \\frac{\\Lambda^2(n_1) \\dots \\Lambda^2(n_J) }{n_1 \\dots n_J} \\prod_{j=1}^k a_j!")]]

#text("and using Mertens’ theorem this soon simplifies asymptotically to the same quantity in Proposition ")#link(<tao-db8a7e5d2e270256ff94>)[#text("1")]#text(". Thus we see that (morally at least) the moments ")#link(<tao-6397a1438f96981870ce>)[#text("(5)")]#text(" associated to the zeta function asymptotically match the moments ")#link(<tao-90702519477f8ad8adee>)[#text("(6)")]#text(" coming from the CUE model in the low degree case ")#link(<tao-7afee126181838479e85>)[#text("(8)")]#text(", thus lending support to the GUE hypothesis. (These observations are basically ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1395406")[#text("due to Rudnick and Sarnak")]#text(", with the degree ")#mi("{1}")#text(" case of pair correlations ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=337821")[#text("due to Montgomery")]#text(", and the degree ")#mi("{2}")#text(" case ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1283025")[#text("due to Hejhal")]#text(".)")

#text("With some rare exceptions (such as those estimates coming from “Kloostermania”), the moment estimates of Rudnick and Sarnak basically represent the state of the art for what is known for the moments ")#link(<tao-6397a1438f96981870ce>)[#text("(5)")]#text(". For instance, ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=337821")[#text("Montgomery’s pair correlation conjecture")]#text(", in our language, is basically the analogue of ")#link(<tao-81b637d8fcd2c6da6359>)[#text("(13)")]#text(" for ")#mi("{{\\mathbf E}_t}")#text(", thus ")#metadata(none) <tao-a9137698d8d3fdbf27ef>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("{\\bf E}_{t} \\left|\\mathrm{tr} U^j\\right|^2 \\approx \\min(j,N)", block: true)]]

#text("for all ")#mi("{j \\geq 0}")#text(". Montgomery showed this for (essentially) the range ")#mi("{j \\leq N}")#text(" (as remarked above, this is a special case of the Rudnick-Sarnak result), but no further cases of this conjecture are known.")

#text("These estimates can be used to give some non-trivial information on the largest and smallest spacings between zeroes of the zeta function, which in our notation corresponds to spacing between eigenvalues of ")#mi("{U}")#text(". One such method used today for this is ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=781177")[#text("due to Montgomery and Odlyzko")]#text(" and was ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=749453")[#text("greatly simplified by Conrey, Ghosh, and Gonek")]#text(". The basic idea, translated to our random matrix notation, is as follows. Suppose ")#mi("{Q_t(Z)}")#text(" is some random polynomial depending on ")#mi("{t}")#text(" of degree at most ")#mi("{N}")#text(". Let ")#mi("{\\lambda_1,\\dots,\\lambda_n}")#text(" denote the eigenvalues of ")#mi("{U}")#text(", and let ")#mi("{c > 0}")#text(" be a parameter. Observe from the pigeonhole principle that if the quantity ")#metadata(none) <tao-505be4613ba4e4596e0f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\sum_{j=1}^n \\int_0^{c/N} \\left|Q_t( e(\\theta) \\lambda_j )\\right|^2\\ d\\theta", block: true)]]

#text("exceeds the quantity ")#metadata(none) <tao-c17bf2ccc60ae19889ec>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("\\int_{0}^{2\\pi} \\left|Q_t(e(\\theta))\\right|^2\\ d\\theta,", block: true)]]

#text("then the arcs ")#mi("{\\{ e(\\theta) \\lambda_j: 0 \\leq \\theta \\leq c \\}}")#text(" cannot all be disjoint, and hence there exists a pair of eigenvalues making an angle of less than ")#mi("{c/N}")#text(" (")#mi("{c}")#text(" times the mean angle separation). Similarly, if the quantity ")#link(<tao-505be4613ba4e4596e0f>)[#text("(18)")]#text(" falls below that of ")#link(<tao-c17bf2ccc60ae19889ec>)[#text("(19)")]#text(", then these arcs cannot cover the unit circle, and hence there exists a pair of eigenvalues making an angle of greater than ")#mi("{c}")#text(" times the mean angle separation. By judiciously choosing the coefficients of ")#mi("{Q_t}")#text(" as functions of the moments ")#mi("{\\mathrm{tr}(U^j)}")#text(", one can ensure that both quantities ")#link(<tao-505be4613ba4e4596e0f>)[#text("(18)")]#text(", ")#link(<tao-c17bf2ccc60ae19889ec>)[#text("(19)")]#text(" can be computed by the Rudnick-Sarnak estimates (or estimates of equivalent strength); indeed, from the residue theorem one can write ")#link(<tao-505be4613ba4e4596e0f>)[#text("(18)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2\\pi i} \\int_0^{c/N} (\\int_{\\left|z\\right| = 1+\\varepsilon} - \\int_{\\left|z\\right|=1-\\varepsilon}) Q_t( e(\\theta) z ) \\overline{Q_t}( \\frac{1}{e(\\theta) z} ) \\frac{P^{\\prime}_t(z)}{P_t(z)}\\ dz", block: true)]]

#text("for sufficiently small ")#mi("{\\varepsilon>0}")#text(", and this can be computed (in principle, at least) using ")#link(<tao-762c0bc8c300e14b6ecd>)[#text("(3)")]#text(" if the coefficients of ")#mi("{Q_t}")#text(" are in an appropriate form. Using this sort of technology (translated back to the Riemann zeta function setting), one can show that gaps between consecutive zeroes of zeta are less than ")#mi("{\\mu}")#text(" times the mean spacing and greater than ")#mi("{\\lambda}")#text(" times the mean spacing infinitely often for certain ")#mi("{0 < \\mu < 1 < \\lambda}")#text("; the current records are ")#mi("{\\mu = 0.50412}")#text(" (due ")#link("https://arxiv.org/abs/1904.06001")[#text("to Goldston and Turnage-Butterbaugh")]#text(") and ")#mi("{\\lambda = 3.18}")#text(" (due ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3811585")[#text("to Bui and Milinovich")]#text(", who input some additional estimates beyond the Rudnick-Sarnak set, namely the ")#link("http://arxiv.org/abs/1609.02539")[#text("twisted fourth moment estimates of Bettin, Bui, Li, and Radziwill")]#text(", and using a technique based on ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2261847")[#text("Hall’s method")]#text(" rather than the Montgomery-Odlyzko method).")

#text("It would be of great interest if one could push the upper bound ")#mi("{\\mu}")#text(" for the smallest gap below ")#mi("{1/2}")#text(". The reason for this is that this would then exclude the ")#link("http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.66.3584&rep=rep1&type=pdf")[#text("Alternative Hypothesis")]#text(" that the spacing between zeroes are asymptotically always (or almost always) a non-zero half-integer multiple of the mean spacing, or in our language that the gaps between the phases ")#mi("{\\theta}")#text(" of the eigenvalues ")#mi("{e^{2\\pi i\\theta}}")#text(" of ")#mi("{U}")#text(" are nasymptotically always non-zero integer multiples of ")#mi("{1/2N}")#text(". The significance of this hypothesis is that it is implied by the existence of a Siegel zero (of conductor a small power of ")#mi("{T}")#text("); see ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1905090")[#text("this paper of Conrey and Iwaniec")]#text(". (In our language, what is going on is that if there is a ")#link("https://en.wikipedia.org/wiki/Siegel_zero")[#text("Siegel zero")]#text(" in which ")#mi("{L(1,\\chi)}")#text(" is very close to zero, then ")#mi("{1*\\chi}")#text(" behaves like the Kronecker delta, and hence (by the Riemann-Siegel formula) the combined ")#mi("{L}")#text("-function ")#mi("{\\zeta(s) L(s,\\chi)}")#text(" will have a polynomial approximation which in our language looks like a scalar multiple of ")#mi("{1 + e(\\theta) Z^{2N+M}}")#text(", where ")#mi("{q \\approx T^{M/N}}")#text(" and ")#mi("{\\theta}")#text(" is a phase. The zeroes of this approximation lie on a coset of the ")#mi("{(2N+M)^{th}}")#text(" roots of unity; the polynomial ")#mi("{P}")#text(" is a factor of this approximation and hence will also lie in this coset, implying in particular that all eigenvalue spacings are multiples of ")#mi("{1/(2N+M)}")#text(". Taking ")#mi("{M = o(N)}")#text(" then gives the claim.)")

#text("Unfortunately, the known methods do not seem to break this barrier without some significant new input; already the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=781177")[#text("original paper of Montgomery and Odlyzko")]#text(" observed this limitation for their particular technique (and in fact fall very slightly short, as observed in unpublished work of Goldston and of Milinovich). In this post I would like to record another way to see this, by providing an “alternative” probability distribution to the CUE distribution (which one might dub the ")#emph[#text("Alternative Circular Unitary Ensemble")]#text(" (ACUE) which is indistinguishable in low moments in the sense that the expectation ")#mi("{{\\bf E}_{ACUE}}")#text(" for this model also obeys Proposition ")#link(<tao-db8a7e5d2e270256ff94>)[#text("1")]#text(", but for which the phase spacings are always a multiple of ")#mi("{1/2N}")#text(". This shows that if one is to rule out the Alternative Hypothesis (and thus in particular rule out Siegel zeroes), one needs to input some additional moment information beyond Proposition ")#link(<tao-db8a7e5d2e270256ff94>)[#text("1")]#text(". It would be interesting to see if any of the other known moment estimates that go beyond this proposition are consistent with this alternative distribution. (UPDATE: it looks like they are, see Remark ")#link(<tao-2937013f2181810606b2>)[#text("7")]#text(" below.)")

#text("To describe this alternative distribution, let us first recall the Weyl description of the CUE measure on the unitary group ")#mi("{U(n)}")#text(" in terms of the distribution of the phases ")#mi("{\\theta_1,\\dots,\\theta_N \\in {\\bf R}/{\\bf Z}}")#text(" of the eigenvalues, randomly permuted in any order. This distribution is given by the probability measure ")#metadata(none) <tao-5de212ab0494f6e91365>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("\\frac{1}{N!} \\left|V(\\theta)\\right|^2\\ d\\theta_1 \\dots d\\theta_N;", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("V(\\theta) := \\prod_{1 \\leq i<j \\leq N} (e(\\theta_i)-e(\\theta_j))")]]

#text("is the ")#link("https://en.wikipedia.org/wiki/Vandermonde_matrix")[#text("Vandermonde determinant")]#text("; see for instance ")#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/")[#text("this previous blog post")]#text(" for the derivation of a very similar formula for the GUE distribution, which can be adapted to CUE without much difficulty. To see that this is a probability measure, first observe the Vandermonde determinant identity")

#align(center)[#tao-fit-display[#mitex("V(\\theta) = \\sum_{\\pi \\in S_N} \\mathrm{sgn}(\\pi) e(\\theta \\cdot \\pi(\\rho))")]]

#text("where ")#mi("{\\theta := (\\theta_1,\\dots,\\theta_N)}")#text(", ")#mi("{\\cdot}")#text(" denotes the dot product, and ")#mi("{\\rho := (1,2,\\dots,N)}")#text(" is the “long word”, which implies that ")#link(<tao-5de212ab0494f6e91365>)[#text("(20)")]#text(" is a trigonometric series with constant term ")#mi("{1}")#text("; it is also clearly non-negative, so it is a probability measure. One can thus generate a random CUE matrix by first drawing ")#mi("{(\\theta_1,\\dots,\\theta_n) \\in ({\\bf R}/{\\bf Z})^N}")#text(" using the probability measure ")#link(<tao-5de212ab0494f6e91365>)[#text("(20)")]#text(", and then generating ")#mi("{U}")#text(" to be a random unitary matrix with eigenvalues ")#mi("{e(\\theta_1),\\dots,e(\\theta_N)}")#text(".")

#text("For the alternative distribution, we first draw ")#mi("{(\\theta_1,\\dots,\\theta_N)}")#text(" on the discrete torus ")#mi("{(\\frac{1}{2N}{\\bf Z}/{\\bf Z})^N}")#text(" (thus each ")#mi("{\\theta_j}")#text(" is a ")#mi("{2N^{th}}")#text(" root of unity) with probability density function ")#metadata(none) <tao-ee5c6a02463f6cf1cb10>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\frac{1}{(2N)^N} \\frac{1}{N!} \\left|V(\\theta)\\right|^2", block: true)]]

#text("shift by a phase ")#mi("{\\alpha \\in {\\bf R}/{\\bf Z}}")#text(" drawn uniformly at random, and then select ")#mi("{U}")#text(" to be a random unitary matrix with eigenvalues ")#mi("{e^{i(\\theta_1+\\alpha)}, \\dots, e^{i(\\theta_N+\\alpha)}}")#text(". Let us first verify that ")#link(<tao-ee5c6a02463f6cf1cb10>)[#text("(21)")]#text(" is a probability density function. Clearly it is non-negative. It is the linear combination of exponentials of the form ")#mi("{e(\\theta \\cdot (\\pi(\\rho)-\\pi^{\\prime}(\\rho))}")#text(" for ")#mi("{\\pi,\\pi^{\\prime} \\in S_N}")#text(". The diagonal contribution ")#mi("{\\pi=\\pi^{\\prime}}")#text(" gives the constant function ")#mi("{\\frac{1}{(2N)^N}}")#text(", which has total mass one. All of the other exponentials have a frequency ")#mi("{\\pi(\\rho)-\\pi^{\\prime}(\\rho)}")#text(" that is not a multiple of ")#mi("{2N}")#text(", and hence will have mean zero on ")#mi("{(\\frac{1}{2N}{\\bf Z}/{\\bf Z})^N}")#text(". The claim follows.")

#text("From construction it is clear that the matrix ")#mi("{U}")#text(" drawn from this alternative distribution will have all eigenvalue phase spacings be a non-zero multiple of ")#mi("{1/2N}")#text(". Now we verify that the alternative distribution also obeys Proposition ")#link(<tao-db8a7e5d2e270256ff94>)[#text("1")]#text(". The alternative distribution remains invariant under rotation by phases, so the claim is again clear when ")#link(<tao-7afee126181838479e85>)[#text("(8)")]#text(" fails. Inspecting the proof of that proposition, we see that it suffices to show that the Schur polynomials ")#mi("{s_\\lambda}")#text(" with ")#mi("{\\lambda}")#text(" of size at most ")#mi("{N}")#text(" and of equal size remain orthonormal with respect to the alternative measure. That is to say,")

#align(center)[#tao-fit-display[#mitex("\\int_{U(N)} s_\\lambda(U) \\overline{s_{\\lambda^{\\prime}}(U)}\\ d\\mu_{\\mathrm{CUE}}(U) = \\int_{U(N)} s_\\lambda(U) \\overline{s_{\\lambda^{\\prime}}(U)}\\ d\\mu_{\\mathrm{ACUE}}(U)")]]

#text("when ")#mi("{\\lambda,\\lambda^{\\prime}}")#text(" have size equal to each other and at most ")#mi("{N}")#text(". In this case the phase ")#mi("{\\alpha}")#text(" in the definition of ")#mi("{U}")#text(" is irrelevant. In terms of eigenvalue measures, we are then reduced to showing that")

#align(center)[#tao-fit-display[#tao-math("\\int_{({\\bf R}/{\\bf Z})^N} s_\\lambda(\\theta) \\overline{s_{\\lambda^{\\prime}}(\\theta)} \\left|V(\\theta)\\right|^2\\ d\\theta = \\frac{1}{(2N)^N} \\sum_{\\theta \\in (\\frac{1}{2N}{\\bf Z}/{\\bf Z})^N} s_\\lambda(\\theta) \\overline{s_{\\lambda^{\\prime}}(\\theta)} \\left|V(\\theta)\\right|^2.", block: true)]]

#text("By Fourier decomposition, it then suffices to show that the trigonometric polynomial ")#tao-math("{s_\\lambda(\\theta) \\overline{s_{\\lambda^{\\prime}}(\\theta)} \\left|V(\\theta)\\right|^2}", block: false)#text(" does not contain any components of the form ")#mi("{e( \\theta \\cdot 2N k)}")#text(" for some non-zero lattice vector ")#mi("{k \\in {\\bf Z}^N}")#text(". But we have already observed that ")#tao-math("{\\left|V(\\theta)\\right|^2}", block: false)#text(" is a linear combination of plane waves of the form ")#mi("{e(\\theta \\cdot (\\pi(\\rho)-\\pi^{\\prime}(\\rho))}")#text(" for ")#mi("{\\pi,\\pi^{\\prime} \\in S_N}")#text(". Also, as is well known, ")#mi("{s_\\lambda(\\theta)}")#text(" is a linear combination of plane waves ")#mi("{e( \\theta \\cdot \\kappa )}")#text(" where ")#mi("{\\kappa}")#text(" is ")#link("https://en.wikipedia.org/wiki/Majorization")[#text("majorised")]#text(" by ")#mi("{\\lambda}")#text(", and similarly ")#mi("{s_{\\lambda^{\\prime}}(\\theta)}")#text(" is a linear combination of plane waves ")#mi("{e( \\theta \\cdot \\kappa^{\\prime} )}")#text(" where ")#mi("{\\kappa^{\\prime}}")#text(" is majorised by ")#mi("{\\lambda^{\\prime}}")#text(". So the product ")#tao-math("{s_\\lambda(\\theta) \\overline{s_{\\lambda^{\\prime}}(\\theta)} \\left|V(\\theta)\\right|^2}", block: false)#text(" is a linear combination of plane waves of the form ")#mi("{e(\\theta \\cdot (\\kappa - \\kappa^{\\prime} + \\pi(\\rho) - \\pi^{\\prime}(\\rho)))}")#text(". But every coefficient of the vector ")#mi("{\\kappa - \\kappa^{\\prime} + \\pi(\\rho) - \\pi^{\\prime}(\\rho)}")#text(" lies between ")#mi("{1-2N}")#text(" and ")#mi("{2N-1}")#text(", and so cannot be of the form ")#mi("{2Nk}")#text(" for any non-zero lattice vector ")#mi("{k}")#text(", giving the claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4")]#text(" If ")#mi("{N=2}")#text(", then the distribution ")#link(<tao-ee5c6a02463f6cf1cb10>)[#text("(21)")]#text(" assigns a probability of ")#mi("{\\frac{1}{4^2 2!} 2}")#text(" to any pair ")#mi("{(\\theta_1,\\theta_2) \\in (\\frac{1}{4} {\\bf Z}/{\\bf Z})^2}")#text(" that is a permuted rotation of ")#mi("{(0,\\frac{1}{4})}")#text(", and a probability of ")#mi("{\\frac{1}{4^2 2!} 4}")#text(" to any pair that is a permuted rotation of ")#mi("{(0,\\frac{1}{2})}")#text(". Thus, a matrix ")#mi("{U}")#text(" drawn from the alternative distribution will be conjugate to a phase rotation of ")#mi("{\\mathrm{diag}(1, i)}")#text(" with probability ")#mi("{1/2}")#text(", and to ")#mi("{\\mathrm{diag}(1,-1)}")#text(" with probability ")#mi("{1/2}")#text(".")

#text("A similar computation when ")#mi("{N=3}")#text(" gives ")#mi("{U}")#text(" conjugate to a phase rotation of ")#mi("{\\mathrm{diag}(1, e(1/6), e(1/3))}")#text(" with probability ")#mi("{1/12}")#text(", to a phase rotation of ")#mi("{\\mathrm{diag}( 1, e(1/6), -1)}")#text(" or its adjoint with probability of ")#mi("{1/3}")#text(" each, and a phase rotation of ")#mi("{\\mathrm{diag}(1, e(1/3), e(2/3))}")#text(" with probability ")#mi("{1/4}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" For large ")#mi("{N}")#text(" it does not seem that this specific alternative distribution is the only distribution consistent with Proposition ")#link(<tao-db8a7e5d2e270256ff94>)[#text("1")]#text(" and which has all phase spacings a non-zero multiple of ")#mi("{1/2N}")#text("; in particular, it may not be the only distribution consistent with a Siegel zero. Still, it is a very explicit distribution that might serve as a test case for the limitations of various arguments for controlling quantities such as the largest or smallest spacing between zeroes of zeta. The ACUE is in some sense the distribution that maximally resembles CUE (in the sense that it has the greatest number of Fourier coefficients agreeing) while still also being consistent with the Alternative Hypothesis, and so should be the most difficult enemy to eliminate if one wishes to disprove that hypothesis.")
]

#text("In some cases, even just a tiny improvement in known results would be able to exclude the alternative hypothesis. For instance, if the alternative hypothesis held, then ")#tao-math("{\\left|\\mathrm{tr}(U^j)\\right|}", block: false)#text(" is periodic in ")#mi("{j}")#text(" with period ")#mi("{2N}")#text(", so from Proposition ")#link(<tao-db8a7e5d2e270256ff94>)[#text("1")]#text(" for the alternative distribution one has")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_{\\mathrm{ACUE}} \\left|\\mathrm{tr} U^j\\right|^2 = \\min_{k \\in {\\bf Z}} \\left|j-2Nk\\right|", block: true)]]

#text("which differs from ")#link(<tao-81b637d8fcd2c6da6359>)[#text("(13)")]#text(" for any ")#tao-math("{\\left|j\\right| > N}", block: false)#text(". (This fact was implicitly observed recently ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3531237")[#text("by Baluyot")]#text(", in the original context of the zeta function.) Thus a verification of the pair correlation conjecture ")#link(<tao-a9137698d8d3fdbf27ef>)[#text("(17)")]#text(" for even a single ")#mi("{j}")#text(" with ")#tao-math("{\\left|j\\right| > N}", block: false)#text(" would rule out the alternative hypothesis. Unfortunately, such a verification appears to be on comparable difficulty with (an averaged version of) the Hardy-Littlewood conjecture, with power saving error term. (This is consistent with the fact that Siegel zeroes can cause distortions in the Hardy-Littlewood conjecture, as (implicitly) discussed in ")#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/")[#text("this previous blog post")]#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" One can view the CUE as normalised Lebesgue measure on ")#mi("{U(N)}")#text(" (viewed as a smooth submanifold of ")#mi("{{\\bf C}^{N^2}}")#text("). One can similarly view ACUE as normalised Lebesgue measure on the (disconnected) smooth submanifold of ")#mi("{U(N)}")#text(" consisting of those unitary matrices whose phase spacings are non-zero integer multiples of ")#mi("{1/2N}")#text("; informally, ACUE is CUE restricted to this lower dimensional submanifold. As is well known, the phases of CUE eigenvalues form a determinantal point process with kernel ")#mi("{K(\\theta,\\theta^{\\prime}) = \\frac{1}{N} \\sum_{j=0}^{N-1} e(j(\\theta - \\theta^{\\prime}))}")#text(" (or one can equivalently take ")#mi("{K(\\theta,\\theta^{\\prime}) = \\frac{\\sin(\\pi N (\\theta-\\theta^{\\prime}))}{N\\sin(\\pi(\\theta-\\theta^{\\prime}))}}")#text("; in a similar spirit, the phases of ACUE eigenvalues, once they are rotated to be ")#mi("{2N^{th}}")#text(" roots of unity, become a discrete determinantal point process on those roots of unity with exactly the same kernel (except for a normalising factor of ")#mi("{\\frac{1}{2}}")#text("). In particular, the ")#mi("{k}")#text("-point correlation functions of ACUE (after this rotation) are precisely the restriction of the ")#mi("{k}")#text("-point correlation functions of CUE after normalisation, that is to say they are proportional to ")#mi("{\\mathrm{det}( K( \\theta_i,\\theta_j) )_{1 \\leq i,j \\leq k}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" ")#metadata(none) <tao-2937013f2181810606b2>#text(" One family of estimates that go beyond the Rudnick-Sarnak family of estimates are twisted moment estimates for the zeta function, such as ones that give asymptotics for")

#align(center)[#tao-fit-display[#tao-math("\\int_T^{2T} \\left|\\zeta(\\frac{1}{2}+it)\\right|^{2k} \\left|Q(\\frac{1}{2}+it)\\right|^2\\ dt", block: true)]]

#text("for some small even exponent ")#mi("{2k}")#text(" (almost always ")#mi("{2}")#text(" or ")#mi("{4}")#text(") and some short Dirichlet polynomial ")#mi("{Q}")#text("; see for instance this paper of ")#link("https://arxiv.org/abs/1609.02539")[#text("Bettin, Bui, Li, and Radziwill")]#text(" for some examples of such estimates. The analogous unitary matrix average would be something like")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_t \\left|P_t(1)\\right|^{2k} \\left|Q_t(1)\\right|^2", block: true)]]

#text("where ")#mi("{Q_t}")#text(" is now some random medium degree polynomial that depends on the unitary matrix ")#mi("{U}")#text(" associated to ")#mi("{P_t}")#text(" (and in applications will typically also contain some negative power of ")#mi("{\\exp(A_t)}")#text(" to cancel the corresponding powers of ")#mi("{\\exp(A_t)}")#text(" in ")#tao-math("{\\left|P_t(1)\\right|^{2k}}", block: false)#text("). Unfortunately such averages generally are unable to distinguish the CUE from the ACUE. For instance, if all the coefficients of ")#mi("{Q}")#text(" involve products of traces ")#mi("{\\mathrm{tr}(U^k)}")#text(" of total order less than ")#mi("{N-k}")#text(", then in terms of the eigenvalue phases ")#mi("{\\theta}")#text(", ")#tao-math("{\\left|Q(1)\\right|^2}", block: false)#text(" is a linear combination of plane waves ")#mi("{e(\\theta \\cdot \\xi)}")#text(" where the frequencies ")#mi("{\\xi}")#text(" have coefficients of magnitude less than ")#mi("{N-k}")#text(". On the other hand, as each coefficient of ")#mi("{P_t}")#text(" is an elementary symmetric function of the eigenvalues, ")#mi("{P_t(1)}")#text(" is a linear combination of plane waves ")#mi("{e(\\theta \\cdot \\xi)}")#text(" where the frequencies ")#mi("{\\xi}")#text(" have coefficients of magnitude at most ")#mi("{1}")#text(". Thus ")#tao-math("{\\left|P_t(1)\\right|^{2k} \\left|Q_t(1)\\right|^2}", block: false)#text(" is a linear combination of plane waves where the frequencies ")#mi("{\\xi}")#text(" have coefficients of magnitude less than ")#mi("{N}")#text(", and thus is orthogonal to the difference between the CUE and ACUE measures on the phase torus ")#mi("{({\\bf R}/{\\bf Z})^n}")#text(" by the previous arguments. In other words, ")#tao-math("{\\left|P_t(1)\\right|^{2k} \\left|Q_t(1)\\right|^2}", block: false)#text(" has the same expectation with respect to ACUE as it does with respect to CUE. Thus one can only start distinguishing CUE from ACUE if the mollifier ")#mi("{Q_t}")#text(" has degree close to or exceeding ")#mi("{N}")#text(", which corresponds to Dirichlet polynomials ")#mi("{Q}")#text(" of length close to or exceeding ")#mi("{T}")#text(", which is far beyond current technology for such moment estimates.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" The GUE hypothesis for the zeta function asserts that the average ")#metadata(none) <tao-c55d1b05c8e96b4c9270>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\lim_{T \\rightarrow \\infty} \\frac{1}{T} \\int_T^{2T} \\sum_{\\gamma_1,\\dots,\\gamma_n \\text{ distinct}} \\eta( \\frac{\\log T}{2\\pi}(\\gamma_1-t),\\dots, \\frac{\\log T}{2\\pi}(\\gamma_k-t))\\ dt")]]

#text("is equal to ")#metadata(none) <tao-6da88c34ba124c41f977>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\int_{{\\bf R}^n} \\eta(x) \\det(K(x_i-x_j))_{1 \\leq i,j \\leq k}\\ dx_1 \\dots dx_k")]]

#text("for any ")#mi("{k \\geq 1}")#text(" and any test function ")#mi("{\\eta: {\\bf R}^k \\rightarrow {\\bf C}}")#text(", where ")#mi("{K(x) := \\frac{\\sin \\pi x}{\\pi x}}")#text(" is the Dyson sine kernel and ")#mi("{\\gamma_i}")#text(" are the ordinates of zeroes of the zeta function. This corresponds to the CUE distribution for ")#mi("{U}")#text(". The ACUE distribution then corresponds to an “alternative gaussian unitary ensemble (AGUE)” hypothesis, in which the average ")#link(<tao-c55d1b05c8e96b4c9270>)[#text("(22)")]#text(" is instead predicted to equal a Riemann sum version of the integral ")#link(<tao-6da88c34ba124c41f977>)[#text("(23)")]#text(":")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 2^{-k} \\sum_{x_1,\\dots,x_k \\in \\frac{1}{2} {\\bf Z} + \\theta} \\eta(x) \\det(K(x_i-x_j))_{1 \\leq i,j \\leq k}\\ d\\theta.")]]

#text("This is a stronger version of the alternative hypothesis that the spacing between adjacent zeroes is almost always approximately a half-integer multiple of the mean spacing. I do not know of any known moment estimates for Dirichlet series that is able to eliminate this AGUE hypothesis (even assuming GRH). (UPDATE: These facts have also been independently observed in forthcoming work of Lagarias and Rodgers.)")
]

#heading(level: 1)[#text("Comments (30)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-515919")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2019")])]

#text("I like that N grow slowly with N in the introduction ;-)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-515923")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2019")])]

#text("It should be added that the bounds ")#mi("\\lambda, \\mu")#text(" for consecutive nontrivial zeta zeros are only in the “infinitely often” sense.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/131d5639e45253d3b32884a17344a26f0f34a81116a3ca10ed5d5a083d97b99a-a23dacb03b67e3ebd00a069edbb99797d1ed657d23d2266b042fea78cc26217a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-515924")[#strong[#text("Joseph")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2019")])]

#text("Is it expected that there is a similar limitation for larger gaps, i.e. one can construct a random matrix model such that the Schur functions of size at most ")#mi("N")#text(" remain orthonormal, and the maximal gap is bounded by ")#mi("C/N")#text(" for some constant ")#mi("C")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-515928")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2019")])]

#text("I don’t know of such a limitation, and indeed there seems to be considerably more scope to improve the bounds on ")#mi("\\lambda")#text(" than on ")#mi("\\mu")#text(". For instance, the current best bound 0.515396 for ")#mi("\\mu")#text(" only improves very slightly on the previous record 0.515398 ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2903162")[#text("of Feng and Xu")]#text(", and does not seem to use any moment information beyond the Rudnick-Sarnak level if I am not mistaken, whereas the current record 3.18 for ")#mi("\\lambda")#text(" is considerable improvement over the previous record 2.76 ")#link("https://arxiv.org/abs/1101.3197")[#text("of Bredberg")]#text(" (or of the bound 3.072 on GRH ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3045202")[#text("of Feng and Xu")]#text("), and uses additional moment information. (I intend to work out what the analogues of such information is in the unitary matrix setting, perhaps in a followup blog post.)")

#text("A few years ago there was an attempt (at an AIM workshop) to use the sieve that James Maynard and I discovered for detecting short intervals with many primes, to see if they could somehow be adapted to improve the bound on ")#mi("\\lambda")#text(", but my understanding was that this attempt ran into some serious obstacles (I was not directly involved in it though).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/786bcf953810bafb45f18f2c350f39582403d310b235d08ffad38ffa19dad548-34f48a033bc3a8f733ffae5bb8ef5ea9e7361be35e3f78f527bf459235a28e9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Caroline Turnage-Butterbaugh")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-515939")[#strong[#text("Caroline Turnage-Butterbaugh")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2019")])]

#text("Dan Goldston and I recently posted a preprint on arXiv (")#link("https://arxiv.org/abs/1904.06001")[#text("https://arxiv.org/abs/1904.06001")]#text(") where we improve the bound on mu to 0.50412 using the Montgomery-Odlyzko / Conrey-Ghosh-Gonek method with weights that are supported on numbers with a small number of prime factors.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-515950")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2019")])]

#text("Congratulations on your recent result! I’ve updated the blog post accordingly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-516075")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2019")])]

#text("How is it possible that unlike Goldston-Turnage-Butterbaugh weights, Conrey-Ghosh-Gonek weights involve ")#mi("d_r(k)")#text(" with the optimal r>1 so the latter weights, when optimized, are supported mainly on numbers with a ")#emph[#text("large")]#text(" number of prime factors?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b569ab6e7e3d7906c75b26228bb124f88e299a60f22618bcb8846df553ea7ad-f4d6150803cd83679d270d45b0ebd17630784da51d524022a26e5ab5e18ca754.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Goldston")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-516137")[#strong[#text("Daniel Goldston")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2019")])]

#text("For small gaps if you replace ")#mi("d_r(k)")#text(" with ")#mi("1")#text(" you get the result ")#mi("\\mu < 0.5182")#text(" in place of ")#mi("\\mu < 0.5171")#text(", so the effect of the divisor function is rather small. Where ")#mi("d_r(k)")#text(" leads to dramatic improvements is when you look for large or small gaps between ")#mi("r")#text(" zeros (")#mi("r")#text("-gaps) when ")#mi("r")#text(" is large. See the recent paper of Conrey-Turnage-Butterbaugh ")#link("https://arxiv.org/abs/1708.00030")[#text("https://arxiv.org/abs/1708.00030")]#text(" .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xu")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-516334")[#strong[#text("Xu")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2019")])]

#text("If we take Feng-Wu weights with a few terms, with ")#mi("r")#text(" in ")#mi("d_r(k)")#text(" ")#emph[#text("close to zero")]#text(", and then optimize (a small number of) the terms related to prime factors, then we seem to get Goldston-Turnage-Butterbaugh bound. This is strange, since Feng-Wu optimal value is ")#mi("r>1")#text(", not ")#mi("r")#text(" close to zero.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xu")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-516343")[#strong[#text("Xu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2019")])]

#text("Dear Professor Goldston,")#linebreak()#text(" I was able to model your weights, that are supported on numbers with a small number of prime factors, by general Feng-Wu weights with ")#mi("r")#text(" in ")#mi("d_r(k)")#text(" close to zero.")#linebreak()#text(" For weights supported on 1 and primes my bound matches your bound ")#mi("\\mu \\le 0{.}667702086\\ldots")#text(" But for weights supported on numbers with ")#mi("\\Omega(k) \\le 4")#text(" your bound ")#mi("\\mu \\le 0{.}50412")#text(" seems to be incorrect.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b569ab6e7e3d7906c75b26228bb124f88e299a60f22618bcb8846df553ea7ad-f4d6150803cd83679d270d45b0ebd17630784da51d524022a26e5ab5e18ca754.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Goldston")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-528142")[#strong[#text("Daniel Goldston")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2019")])]

#text("We found a mistake in our preprint which invalidates our calculations which gave 0.50412. While the Wu weights are correct, our generalization only holds with functions (or polynomials) which are symmetric in all their variables. We do not yet know whether this restriction allows this method to improve on the earlier results or not.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-515944")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2019")])]

#text("spacing been zeroes -> spacing between zeroes?")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-515956")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2019")])]

#text("In example 2, what does $i < j,k$ mean?")#linebreak()#text(" (1) $i < j$ and $i < k$")#linebreak()#text(" (2) $i < j$")

#emph[#text("[The former – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/041e0d8efb404a6a2cf18b2270a848edf2c64e454a9f79bc7b5042d769355180-62fe160b29fccbce5500ff3d0ac989c0d3a0e9678d38be9c88331b114d02c1d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-515986")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2019")])]

#text("Getting \\mu T / \\log T up to T). This is unfortunately a more difficult problem where the quality of the results is worse.")

#emph[#text("[You may be experiencing the wordpress issue of < and > being interpreted as HTML delimiters. Try using &lt; and &gt; instead – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-515992")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2019")])]

#text("Do (non-symmetric) expressions such as ")#mi("\\sum_{i < j} x_ix_j^2")#text(" ever pop up in combinatorial contexts?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-516071")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2019")])]

#text("Sometimes it is convenient to express symmetric polynomials combinatorially in terms of non-symmetric objects. For instance the Schur polynomial ")#mi("s_\\lambda(x)")#text(" is a symmetric polynomial in the variables ")#mi("x_1,\\dots,x_n")#text(", but it can be split into non-symmetric monomials as ")#mi("s_\\lambda(x) = \\sum_T x^T")#text(", where ")#mi("T")#text(" ranges over all semi-standard tableaux of shape ")#mi("\\lambda")#text(" and entries in ")#mi("\\{1,\\dots,n\\}")#text(", which is what I am implicitly using in this blog post to compute the Schur polynomials. (With this definition it is not immediately obvious that the Schur polynomials are symmetric; there are other equivalent definitions, such as the Jacobi-Trudi identities, which make this more obvious.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-516018")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2019")])]

#text("“the the Vandermonde determinant”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f7f245429786040bab910d040af71dcd754ff66c0c1e02810caa2f67291c05b-60777bb901483cddaae165fe8145af6a6b1b99174a69ed17e7bedad40be7b46f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-516245")[#strong[#text("L")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2019")])]

#text("Sorry all these seem like a problem that can be encoded in quantified real formula with small number of quantifiers. Why can’t we just encode that way and run cook book algorithms or obtain approximations (small quantifiers should not blow up run time too much)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-516253")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2019")])]

#text("For any fixed ")#mi("N")#text(", the problems here are indeed finitary in nature, and could potentially be used to provide some numerical ways to explore the consequences of various moment estimates. For instance, one can pose the question for any fixed ")#mi("N")#text(" of what the most extreme values of ")#mi("\\lambda")#text(" and ")#mi("\\mu")#text(" for probability measures on ")#mi("U(N)")#text(" that obey the analogue of Proposition 1 (or equivalently, the ")#mi("N")#text("-point correlation function agrees with that for CUE when tested against any plane wave ")#mi("e^{i\\theta \\cdot \\xi}")#text(" with either ")#tao-math("\\left|\\xi\\right|_{\\ell^1} \\leq 2N", block: false)#text(" or ")#mi("\\sum_j \\xi_j \\neq 0")#text("). But one is eventually interested in taking the limit as ")#mi("N \\to \\infty")#text(" and here one would need some theoretical analysis and not simply numerical computation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f7f245429786040bab910d040af71dcd754ff66c0c1e02810caa2f67291c05b-60777bb901483cddaae165fe8145af6a6b1b99174a69ed17e7bedad40be7b46f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-516263")[#strong[#text("L")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2019")])]

#text("So ")#mi("\\exists\\lambda\\mu\\forall N\\dots")#text(" type is not something that yields amenable valid quantified formula (I understand need for precise closed form expression but here at end of day you are just looking for ")#mi("0.5...")#text(" or some new tighter bound)? We are looking for extremal value and is there no expression for ")#mi("\\dots")#text(" that can do this and reduce to a computation (or is that the point of the whole research in this direction)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-516304")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2019")])]

#text("It is possible that there is some monotonicity in ")#mi("N")#text(", for instance if one gets an upper bound for ")#mi("\\mu")#text(" at a given value of ")#mi("N")#text(", this may imply also the same upper bound for ")#mi("\\mu")#text(" in the limit ")#mi("N \\to \\infty")#text(". If so then one could imagine for instance that for each ")#mi("\\varepsilon > 0")#text(" there would be a value of ")#mi("N_\\varepsilon")#text(" for which one could use this monotonicity to prove a bound ")#mi("\\mu \\leq 0.5 + \\varepsilon")#text(", but that this value would go to infinity as ")#mi("\\varepsilon \\to 0")#text(" and so one could not establish ")#mi("\\mu \\leq 0.5")#text(" this way without an infinite amount of computation, unless one could somehow find a way to verify ")#mi("\\mu \\leq 0.5 + \\varepsilon")#text(" that was uniform in ")#mi("\\varepsilon")#text(" (as opposed to requiring an increasingly large amount of computation as ")#mi("\\varepsilon \\to 0")#text(").")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f7f245429786040bab910d040af71dcd754ff66c0c1e02810caa2f67291c05b-60777bb901483cddaae165fe8145af6a6b1b99174a69ed17e7bedad40be7b46f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-516315")[#strong[#text("L")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2019")])]

#text("Perhaps then the question would be would it be easy to get necessary and sufficient conditions that would apply to ‘broadly’ speaking these monotone conditions in general situations so that answering that would establish a path for (if not this problem) perhaps problems easier than this?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a778b2ba58f0a83758d062a31b82125493a164e454bac4ed73a5f0b4cb8b8e89-caa1cd9f5051dd9589cb04a35a3d8e1d4fec68bd79393a9eb54194c68326ea90.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brad Rodgers")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-516248")[#strong[#text("Brad Rodgers")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2019")])]

#text("This is a nice post! One quick comment is about the discrete CUE in remark 6: there are a few other places it seems to have cropped up in the literature (though for very different reasons!). Harold Widom made use of it for analytic reasons in “Random Hermitian Matrices and (Nonrandom) Toeplitz Matrices”, and pretty curiously it also came up in work of Johansson on domino tilings (sec 2.5 of ")#link("https://arxiv.org/pdf/math/0011250.pdf")[#text("https://arxiv.org/pdf/math/0011250.pdf")]#text(") and in work of the Russian school of asymptotic rep theorists (e.g. ")#link("https://projecteuclid.org/euclid.dmj/1194547695")[#text("https://projecteuclid.org/euclid.dmj/1194547695")]#text(").")

#text("In fact Jeff Lagarias and I have recently been thinking about some closely related topics to this post, though using slightly different methods. We had independently obtained something like the process you construct in Remark 8. I’ve just now put on my website one of the drafts we’ve been working on: ")#link("https://mast.queensu.ca/~br66/bandlimited-mimickry.draft.pdf")[#text("https://mast.queensu.ca/~br66/bandlimited-mimickry.draft.pdf")]#text(". Theorem 1.8 there was motivated with the idea of showing that even knowing (23) here for test functions ")#mi("\\eta")#text(" with Fourier support in ")#mi("[-1,1]^k")#text(" for all ")#mi("k")#text(" is not enough to eliminate a distribution akin to AGUE. (This Fourier support entails knowing the Rudnick-Sarnak information.) Our methods are slightly different; instead of symmetric function theory we use an expansion of determinants and Poisson summation. We listed a few of the questions we were not able to resolve in section 5. I think the finitary perspective you give here (with N points rather than an infinite number) is probably the right one to use for thinking about things like this!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A function field analogue of Riemann zeta statistics | What's new")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-516397")[#strong[#text("A function field analogue of Riemann zeta statistics | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2019")])]

#text("[…] this with Proposition 1 from this previous post, we thus see that all the low moments of are consistent with the CUE hypothesis (and also with the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-516487")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2019")])]

#text("Sorry if this is explained someplace that I missed it, but why not more generally sample matrices with eigenvalues of the form ")#mi("\\exp(2 \\pi i k/M)")#text(" in ")#mi("U(N)")#text(" (with the same Vandermonde weighting, and same translation by a random scalar)? Why take ")#mi("M = 2N")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-516490")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2019")])]

#mi("M=2N")#text(" is the only choice which (a) is consistent with the “low frequency” moment estimates of Rudnick-Sarnak type, and (b) is consistent which the Alternative Hypothesis that the phase gaps are multiples of ")#mi("1/2N")#text(" (which is what happens in particular in the presence of a Siegel zero). Taking ")#mi("M")#text(" to be a smaller factor of ")#mi("2N")#text(" would retain (b) but not (a); taking a larger choice of ")#mi("M")#text(" would retain (a) but not (b).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/194105e631c13b708ce27cb5ad66fbb6e7595bc0753e82e0f81abe1f23052c39-4fcc6c22f956a142cfade6ba231966a75896eea2635e0c01ff85010b4e24146d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-516557")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2019")])]

#text("My question is philosophically related, at least, to the theme of these several recent posts: what bearing, if any, does the Alternative Hypothesis have on the moments of the Riemann zeta function?")

#text("Keating-Snaith and others have formulated well-known conjectures about the shape of the ")#mi("2k")#text("-th moment of the zeta function based on random matrix theory. For instance, model the zeta function by a characteristic polynomial and integrate with respect to the GUE measure and see what comes out. What happens if you do this same computation with an Alternative measure? In light of your discussion one might guess the predictions are the same for low moments, but that the predictions begin to diverge for larger moments.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-516565")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2019")])]

#text("Remarkably, CUE and ACUE are virtually indistinguishable from moments: Remark 7 in particular shows that the ")#mi("2k^{th}")#text(" moments agree for all ")#mi("k < N")#text(". Given that the analogue of ")#mi("N")#text(" in the Riemann zeta case is something like ")#mi("\\log T")#text(", this means that one needs to go up to something like the ")#mi("2 \\log T^{th}")#text(" moment of zeta before one should start seeing a distinction between the GUE hypothesis and the alternative GUE hypothesis!")

#text("Terry")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a38854493e27c50d837de05abb595219d0ada05b22e7af38e994d5235ff0a1a8-f16382018288d9b9e409fbf60c2e8cc4506867fc9e4f0853b9f4a34b444d1555.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-516569")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2019")])]

#text("Terry, this can’t be right because the log T moment of the zeta function is dominated by the single largest value of zeta which is conjectured to be exp(sqrt(log T)). But even if you don’t believe this conjecture and only assume RH then the largest value of zeta is at most exp(log T / loglog T) and it still dominates the game.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/#comment-516600")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2019")])]

#text("Fair point; at such high moments the distribution of zeroes at the microscale becomes less relevant and the behaviour is dominated instead by the oscillation of small primes. (Though in such situations it would still be the case that it would not be possible to use these moments to distinguish GUE from AGUE.) One could work instead with mollified moments in which one first multiplies the zeta function by a suitable mollifier to damp out the effect of small primes and only retain the effect of the nearby zeroes, before raising to high powers. (Though, as mentioned in Remark 7, once one allows for mollifiers then it becomes easier to distinguish GUE/CUE from AGUE/ACUE using lower moments.)")
]
]
