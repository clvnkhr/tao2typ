// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/
// Converted to Typst by tao2typ: "2026-10-14T11:07:07.128555+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Request for comments from the ICM Structure Committee", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Request for comments from the ICM Structure Committee")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 July 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/")[#text("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("[")#emph[#text("This post is collectively authored by the ")#link("https://www.mathunion.org/icm/next-icm")[#text("ICM structure committee")]#text(", whom I am currently chairing – T.")]#text("]")

#text("The ICM structure committee ")#link("https://www.mathunion.org/fileadmin/IMU/SC_Guidelines.pdf")[#text("is responsible for")]#text(" the preparation of the Scientific Program of the ")#link("https://en.wikipedia.org/wiki/International_Congress_of_Mathematicians")[#text("International Congress of Mathematicians")]#text(" (ICM). It decides the structure of the Scientific Program, in particular,")

#list(
[#text("the number of plenary lectures,")],
[#text("the sections and their precise definition,")],
[#text("the target number of talks in each section,")],
[#text("other kind of lectures, and")],
[#text("the arrangement of sections.")]
)

#text("(The actual selection of speakers and the local organization of the ICM are handled separately by the Program Committee and Organizing Comittee respectively.)")

#text("Our committee can also propose more radical changes to the format of the congress, although certain components of the congress, such as the prize lectures and satellite events, are outside the jurisdiction of this committee. For instance, ")#link("https://www.mathunion.org/fileadmin/IMU/Report/SC/2019/structure_committee_final.pdf")[#text("in 2019 we proposed")]#text(" the addition of two new categories of lectures, “special sectional lectures” and “special plenary lectures”, which are broad and experimental categories of lectures that do not fall under the traditional format of a mathematician presenting their recent advances in a given section, but can instead highlight (for instance) emerging connections between two areas of mathematics, or present a “big picture” talk on a “hot topic” from an expert with the appropriate perspective. These new categories made their debut at the recently concluded ")#link("https://www.mathunion.org/icm/virtual-icm-2022")[#text("virtual ICM")]#text(", held on July 6-14, 2022.")

#text("Over the next year or so, our committee will conduct our deliberations on proposed changes to the structure of the congress for the next ICM (to be held in-person in Philadelphia in 2026) and beyond. As part of the preparation for these deliberations, we are soliciting feedback from the general mathematics community (on this blog and elsewhere) on the current state of the ICM, and any proposals to improve that state for the subsequent congresses; we had issued a ")#link("https://terrytao.wordpress.com/2019/02/05/request-for-comments-from-the-icm-structure-committee/")[#text("similar call on this blog back in 2019")]#text(". This time around, of course, the situation is complicated by the extraordinary and exceptional circumstances that led to the 2022 ICM being moved to a virtual platform on short notice, and so it is difficult for many reasons to hold the 2022 virtual ICM as a model for subsequent congresses. On the other hand, the scientific program had already been selected by the 2022 ICM Program Committee prior to the invasion of Ukraine, and feedback on the content of that program will be of great value to our committee.")

#text("Among the specific questions (in no particular order) for which we seek comments are the following:")

#enum(start: 1, 
[#text("Are there suggestions to change the format of the ICM that would increase its value to the mathematical community?")],
[#text("Are there suggestions to change the format of the ICM that would encourage greater participation and interest in attending, particularly with regards to junior researchers and mathematicians from developing countries?")],
[#text("The special sectional and special plenary lectures were introduced in part to increase the emphasis on the quality of exposition at ICM lectures. Has this in fact resulted in a notable improvement in exposition, and should any alternations be made to the special lecture component of the ICM?")],
[#text("Is the balance between plenary talks, sectional talks, special plenary and sectional talks, and public talks at an optimal level? There is only a finite amount of space in the calendar, so any increase in the number or length of one of these types of talks will come at the expense of another.")],
[#text("The ICM is generally perceived to be more important to pure mathematics than to applied mathematics. In what ways can the ICM be made more relevant and attractive to applied mathematicians, or should one not try to do so?")],
[#text("Are there structural barriers that cause certain areas or styles of mathematics (such as applied or interdisciplinary mathematics) or certain groups of mathematicians to be under-represented at the ICM? What, if anything, can be done to mitigate these barriers?")],
[#text("The recently concluded virtual ICM had a ")#emph[#text("sui generis")]#text(" format, in which the core virtual program was supplemented by a number of physical “overlay” satellite events. Are there any positive features of that format which could potentially be usefully adapted to such congresses? For instance, should there be any virtual or hybrid components at the next ICM?")]
)

#text("Of course, we do not expect these complex and difficult questions to be resolved within this blog post, and debating these and other issues would likely be a major component of our internal committee discussions. Nevertheless, we would value constructive comments towards the above questions (or on other topics within the scope of our committee) to help inform these subsequent discussions. We therefore welcome and invite such commentary, either as responses to this blog post, or sent privately to one of the members of our committee. We would also be interested in having readers share their personal experiences at past congresses, and how it compares with other major conferences of this type. (But in order to keep the discussion focused and constructive, we request that comments here refrain from discussing topics that are out of the scope of this committee, such as suggesting specific potential speakers for the next congress, which is a task instead for the 2022 ICM Program Committee. Comments that are specific to the recently concluded virtual ICM can be made instead ")#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/")[#text("at this blog post")]#text(".)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (25)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-649310")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2022")])]

#text("1. Where it is thin and torn. I discovered ordered semigroup actions (OSA) and (more generally) ordered precategory actions and their use for general topology (that every kind of space in general topology from metric spaces to locales/frames is fully described as an element of an ordered semigroup with action), fully revolutionising general topology. But I don’t see the mathematical community to make use of my research. I foresee the scenario that ordered semigroup actions won’t be researched by anyone except me. I also “backsee” that if I didn’t discover it first but it would be discovered by a reputable doctor, the world would catch this and begin scrutinising consequences. That is it seems that I blocked development of science instead of advancing it. (I believe that OSA are as important as groups, it is like as if group theory would be removed from math knowledge.) So, an amateur can block development of science (because of the pseudoscientific “religion” scientificism expressed in words “PhDs build on works of other PhDs”). You must do something to salvage your science. A possible way to solution is to assign a person (PhD) that would read amateurs’ works and present at ICM. Here is my 500 pages “amateur” research monograph: ")#link("https://science.vporton.name/2021/10/06/algebraic-general-topology-book/")[#text("https://science.vporton.name/2021/10/06/algebraic-general-topology-book/")]#text(" (it can be valued more easily by first reading without reading proofs, if reading it is too much work, moreover, first reading may skip some chapters).")#linebreak()#text(" You are sewing where it’s thick, that’s an obvious error – You should emphasise marginalised research, not the mainstream that will be known anyway. You are like throwing lifeline to the coast when there are drowning research(ers). That’s an inefficient algorithm; as inefficient as Stalin who removed genetics and cybernetics from scientific discourse.")

#text("6. Amateurs are underrepresented. See above.")

#text("Yes, I know that many amateurs are crackpots. If you are lazy to filter out crackpots’ works, you can’t manage science.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae1a15924ecffbfe4f5f8e75e247f39de58f8d43bb5e028db84cc17352e7b32d-c97dcf0db8928f7e68039ec371cb68c67e365ba87ae96864304fe5af988a0880.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nofail")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-650119")[#strong[#text("Nofail")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2022")])]

#text("For any Aylan it is very unbalanced to keep trying to contribute to the 2022 ICM. Up to 2022 they should contribute to the Black Sea navigability. So IMHO ,contempling Greece from that beach is a seemingly remote problem from topology and reality of platonic máthēma.")#linebreak()#text(" A fortiori is not worth for crackpots to ask for a peer review of mathematics very remote from the solution they need.")#linebreak()#text(" There may be couterexamples of awarded then crackpots mathematicians but i dont think “mathematician” defines a person and crying ‘Listen to me I am a mathematician” belongs to the ICM security staff’s bulk apperception problem. Wild west world …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-650124")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2022")])]

#text("A possible solution is to develop an AI software to do the required filtering.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-650125")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2022")])]

#text("I am instead developing blockchain software to obtain money for advertising of fundamental science projects: ")#link("https://science.vporton.name/2022/07/27/my-plan-to-distribute-crypto-to-scientists-and-free-software-authors/")[#text("https://science.vporton.name/2022/07/27/my-plan-to-distribute-crypto-to-scientists-and-free-software-authors/")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-649316")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2022")])]

#text("In addition to pure and applied mathematics, it is suggested to include also certain conjectures based on “experimental mathematics” (e.g. linear dependence of certain trancendental numbers,over the rationals)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9dee4bbece38102a360661203b8b1e0aad61e6a8ec1d91a83ed056d3ac6b7dd9-8b905d0902ecc5afe017e30cda60b95de6e478462f2125a00691d669cf530405.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous (not a a Logician)")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-649332")[#strong[#text("Anonymous (not a a Logician)")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2022")])]

#text("I think that logic is underrepresented in the ICM, and it has fallen “out of fashion” in many places. Someone told me that this is because logicians made their own professional societies and so on. I guess theoretical computer scientists have done the same but they are well integrated into the ICM. Probably with logicians a lot of the problem is that they are relatively insular, and this might be their culture. I guess it could also be that people with certain personalities are more likely to go into logic or something like this. Maybe another problem is just that the field has slowed down, and just isn’t proving as many interesting things as fields like number theory, probability, and combinatorics. This is possibly also the case. Anyway, I’m not a logician, but I’d be interested in hearing more about logic, as well as the connection between logic and other fields. Hrushovski, Shelah, Malliaris, etcetera would be great ICM speakers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-649335")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2022")])]

#text("Terry, it might be useful to include a brief descriptions of the changes in 2022 compared to earlier congresses, (and perhaps a link to a fuller description).")

#emph[#text("[Our ")#link("https://www.mathunion.org/fileadmin/IMU/Report/SC/2019/structure_committee_final.pdf")[#text("2019 report")]#text(" describes the changes. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/14ac0ae7fd696758a9c386bf25d6f755a15b3ba9f6e91e2bad88627dc33b5220-0d542ae24deb3e921bbaf2dcafc24588f536c35e46e558dd7e594c07af00a649.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mason Porter")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-649383")[#strong[#text("Mason Porter")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2022")])]

#text("Of the various items above, I think that I am most placed to comment intelligently about item (5), given that I am an applied mathematician (and “very applied” on that spectrum), Something that would be nice would be items that are not just at the interface between two (or more) areas of mathematics, but also ones that are at the interface between mathematics and other fields. Sessions on ‘mathematical modeling’ would also be welcome and would naturally bring many of these things.")

#text("The AMS has recently supplemented the two-digit MSC numbers for the JMM, so using some of those extra parent classifications (which help applied mathematics, which often gets stuck in purgatory with the standard two-level MSC ontology) and having sessions related to those could also help.")

#text("I certainly would hope that applied mathematics can be expanded at the ICM (and I agree with the statement that at present it’s a much bigger deal in theoretical (“pure”) mathematics than in applied mathematics). I do hope that efforts are made in this direction. Many applied mathematicians — myself very much included — feel extremely disconnected with (and even unwelcome by) the broader mathematics community.")

#text("Other small notes:")

#text("(1) Philadelphia is the headquarter of the Society for Industrial and Applied Mathematics (SIAM), so the specific 2026 location could be helpful.")

#text("(2) I may do this at some point after I have a chance to collect my thoughts and look at the 2019 update document, but for now I am purposely commenting in a way that minimally gets into “structural issues” or other things where the fact that I have not attended an ICM would make it harder for me to comment in an optimally helpful way.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-649415")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2022")])]

#text("Isn’t there an ICIAM specifically for applied and industrial mathematics? ICM should be reserved for pure mathematics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/14ac0ae7fd696758a9c386bf25d6f755a15b3ba9f6e91e2bad88627dc33b5220-0d542ae24deb3e921bbaf2dcafc24588f536c35e46e558dd7e594c07af00a649.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mason Porter")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-649475")[#strong[#text("Mason Porter")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2022")])]

#text("It may be desirable to change the acronym to ICTM if one wants to be exclusionary in that way. Truth in advertising is important.")

#text("Another issue is how mathematics departments view those events and associated consequences for things like promotions and hiring. Do they view those events on equal footing?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-649419")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2022")])]

#text("I like the “special plenary lectures” and wish there were more talks aimed toward a general research mathematician (rather than ones aimed at people who are already well-versed in a particular area). If the ICM really is for all of us, then there should be more talks which can be appreciated by all of us. It is a very big stage to devote to talk which can only be understood by a relatively small fraction of mathematicians.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-649424")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2022")])]

#text("What about probability? Probability has huge potential in terms of research and application to other branches of math.")

#text("Now why is it an unwanted stepchild in pure maths?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d3f3f347a7b10f10ed00a073d27a6a782b68fe64db3137033118f00a93c55ab-956416f7ec8ae648e224ec3aa663df7c74ba2d2ac89fa20ba9892e64ddd51878.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-649451")[#strong[#text("Andy")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2022")])]

#text("How is probability not represented at the ICM? One of the Field’s medalists this year (Hugo Duminil-Copin) was a probabilist, there were two plenary speakers whose work is in probability (Alice Guionnet, Scott Sheffield), and there were tons of invited lectures in probability (Section 12).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-652336")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2022")])]

#text("This is the opposite of the truth. Over the last twenty years, there’s been a steady increase in the presence in probability at ICM and in the top math journals because of the progress in the area and its power providing insight into “pure maths” and mathematical physics.")

#text("Many introductory graduate courses in real and complex analysis now include considerable discussions of probability theory, so I have no idea where anyone could get this idea.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e64b37470c2f1b3a4b4a69fd3437b3a087ffb6423974c1169ceee55ac72481-d42be15bd53754fcc449f3c9a16d337cd279cfd1559c5295eb1a174b5717dfaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Russ Lyons")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-650409")[#strong[#text("Russ Lyons")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2022")])]

#text("[Apologies if this is a duplicate; my first attempt at posting has not shown up.] I found the level of exposition in both plenary and sectional talks very high. It was a pleasure to watch so many and inspiring to see so much great mathematics. I don’t know to what extent the expository quality was influenced by the “expository helpers” mentioned in the 2019 report, nor can I compare to the 2018 ICM. I watched many more talks in the 2022 ICM than even in the 2014 ICM that I attended. Of course, this was due to the online format, which made it extremely convenient: not only could I watch at a preferred time, but also I could speed up, pause, and leave at will. It also resolved conflicts with parallel sessions. Furthermore, I would expect that having high-quality online recordings would contribute greatly to the goal of “encourag[ing] greater participation and interest in attending, particularly with regards to junior researchers and mathematicians from developing countries”. At the same time, those of us concerned about the environmental effects of traveling could watch with negligible negative effects. High-quality online recordings also help those who cannot afford to leave home due to familial obligations.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-650599")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2022")])]

#text("Plus it helps many students (like me, and people I have spoken with, about this) for whom, being able to listen to ICM talks, were only a dream till this time. Of course, I don’t think there was a single student who could understand all the talks, but there were specific talks which were a delight to listen to.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-650600")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2022")])]

#text("Translating your comment indicates that you want some expository material on the Green-Tao theorem. The closest I have got for you is: ")#link("http://www.scholarpedia.org/article/Szemer%C3%A9di%27s_Theorem")[#text("http://www.scholarpedia.org/article/Szemer%C3%A9di%27s_Theorem")]#text(" ; there is also a note on the Green-Tao theorem by Yufei Zhao and others, which you may find on the internet.")

#text("(Pardon, if this was not your query.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9778c20e80a1105875d56d8eaf41c8b8252c7b18b5942e9e59978f67c2116e8e-9085592e445c6af1c4b2f484dc94b05060ed9d69274b72def50b6f3bab77d91c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of math postdoc")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-650602")[#strong[#text("math postdoc")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2022")])]

#text("When you choose platforms for live streaming the lectures, it might be good to take into account that some colleagues and mathematicians in certain nations (e.g., mainland China) might not have access to them (e.g., YouTube, google). Maybe the IMU should make sure participants in many places of the world have equal access to the research and educational resources.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-650604")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2022")])]

#text("I think that is more of an issue between certain nations and YouTube/ Google or other similar platforms. Afterall, no one can ensure that a certain platform is accessible throughout the globe. Thus, posting the videos on the platform which has the broadest scope and is reliable, seems quite the right approach.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-650606")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2022")])]

#text("Blockchain platforms are very hard to block. If inside a firewall there is one node of a blockchain, the entire blockchain is accessible.")

#text("So, to be most accessible materials of ICM can be uploaded to a blockchain-based file archive such as FileCoin or Arweave.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-650615")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2022")])]

#text("It would be nice to have the comments open on Youtube of each presentation. Then people can post comments, and the speaker can also respond if he/she wants, as well as others can help the questions. The Discord Server at the ICM2022 was not very productive, and it is closed now. If the comments were left on Youtube, then people can access them whenever it is convenient for them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e13bfab949f3db20ffe1fc209a818d75f5b06faefbdd5fc67d653b4862c39bbf-0c11c4a06581317394cb6fa5adcb8d85128369de33feb06e0883cf9e3b5b58a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Barany")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-650703")[#strong[#text("Michael Barany")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2022")])]

#text("Re question 6, the biggest barrier to diversity and representation among speakers is the antiquated* practice of dividing invitations by subject area. The ICM could be a distinctive venue to platform work from around the world if it deliberately adopted a structure built on highlighting exciting work from around the world, for instance plenary lectures allocated by continent/region rather than mathematical specialties.")

#text("* antiquated, because even in the early ICMs a century+ ago it was clear that the division by research specialties was leaving out significant areas of research and undercutting potentially exciting speakers while limiting international representativeness.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-652335")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2022")])]

#text("Why are people still so stingy about making their slides available? It should be a no brainer unless they don’t want others to follow the contents of their presentation. Availability of slides should be required as part of the presentation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5c635470cba757e4b2423bf068cde9be1c656615f91c68ce6ac0f6b21c54841e-86a5348dab63c539330e37ef44d546c27246b6bbfb5550b142d1dd5de2f39924.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ob letošnji Fieldsovi medalji za področje verjetnosti: Isingov model v današnjih dimenzijah in času | Udomačena statistika")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-657177")[#strong[#text("Ob letošnji Fieldsovi medalji za področje verjetnosti: Isingov model v današnjih dimenzijah in času | Udomačena statistika")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2022")])]

#text("[…] trenutno so zelo živa in pogosta raziskovanja na meji verjetnosti in strojnega učenja. V ospredju pogovorov je tudi bodoča vloga »uporabne matematike« (kamor bi lahko šteli tudi statistiko), kjer pa […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/17/request-for-comments-from-the-icm-structure-committee-2/#comment-691767")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2026")])]

#text("How is the organization of the ICM going to guarantee the safety of mathematicians from South and Central America and the Middle East? What about the trans community? What about the mathematicians with political ties in their home country? Why is the organization not moving ICM 2026 to a virtual conference for the safety of the participants?")
]
