// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/11/12/new-nikodym-set-constructions-over-finite-fields/
// Converted to Typst by tao2typ: "2026-10-14T16:39:19.501646+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "New Nikodym set constructions over finite fields", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("New Nikodym set constructions over finite fields")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 November 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/11/12/new-nikodym-set-constructions-over-finite-fields/")[#text("https://terrytao.wordpress.com/2025/11/12/new-nikodym-set-constructions-over-finite-fields/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I have uploaded to the arXiv my paper “")#link("http://arxiv.org/abs/2511.07721")[#text("New Nikodym set constructions over finite fields")]#text("“. This is a spinoff of my previous project with Bogdan Georgiev, Javier Gómez–Serrano, and Adam Zsolt Wagner that I ")#link("https://terrytao.wordpress.com/2025/11/05/mathematical-exploration-and-discovery-at-scale/")[#text("recently posted about")]#text(". In that project we experimented with using AlphaEvolve (and other tools, such as DeepThink and AlphaProof) to explore various mathematical problems which were connected somehow to an optimization problem. For one of these — the finite field Nikodym set problem — these experiments led (by a somewhat convoluted process) to an improved asymptotic construction of such sets, the details of which are written up (by myself rather than by AI tools) in this paper.")

#text("Let ")#mi("{{\\mathbb F}_q}")#text(" be a finite field of some order ")#mi("{q}")#text(" (which must be a prime or a power of a prime), and let ")#mi("{d}")#text(" be a fixed dimension. A ")#emph[#text("Nikodym set")]#text(" in ")#mi("{{\\mathbb F}_q^d}")#text(" is a subset ")#mi("{N}")#text(" of ")#mi("{{\\mathbb F}_q^d}")#text(" with the property that for every point ")#mi("{x \\in {\\mathbb F}_q^d}")#text(", there exists a line ")#mi("{\\ell}")#text(" passing through ")#mi("{x}")#text(" such that all points of ")#mi("{\\ell}")#text(" other than ")#mi("{x}")#text(" lie in ")#mi("{N}")#text(". Such sets are close cousins of ")#emph[#text("Kakeya sets")]#text(" (which contain a line in every direction); indeed, roughly speaking, applying a random projective transformation to a Nikodym set will yield (most of) a Kakeya set. As a consequence, any lower bound on Kakeya sets implies a similar bound on Nikodym sets; in particular, one has a lower bound")

#align(center)[#tao-fit-display[#tao-math("\\left|N\\right| \\geq \\frac{q^d}{2^{d-1}} + O(q^{d-1})", block: true)]]

#text("on the size of a Nikodym set ")#mi("{N}")#text(", coming from a similar bound on Kakeya sets due to ")#link("https://discreteanalysisjournal.com/article/30707-sharp-density-bounds-on-the-finite-field-kakeya-problem")[#text("Bukh and Chao")]#text(" using the polynomial method.")

#text("For Kakeya sets, Bukh and Chao showed this bound to be sharp up to the lower order error ")#mi("{O(q^{d-1})}")#text("; but for Nikodym sets it is conjectured that in fact such sets should asymptotically have full density, in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\left|N\\right| \\geq q^d - o(q^d).", block: true)]]

#text("This is known in two dimensions thanks to ")#link("https://zbmath.org/1064.51008")[#text("work by Szönyi et al.")]#text(" on blocking sets, and was also established in bounded torsion cases (and in particular for even ")#mi("{q}")#text(") ")#link("https://arxiv.org/abs/1208.5413")[#text("by Guo, Kopparty, and Sudan")]#text(" by combining the polynomial method with the theory of linear codes. But in other cases this conjecture remains open in three and higher dimensions.")

#text("In our experiments we focused on the opposite problem of ")#emph[#text("constructing")]#text(" Nikodym sets of size as small as possible. In the plane ")#mi("{d=2}")#text(", constructions of size ")#metadata(none) <tao-bccb8ebe06c46c3598bd>#tao-math("\\displaystyle  \\left|N\\right| = q^2 - q^{3/2} + O(q \\log q) \\ \\ \\ \\ \\ (1)", block: false)#text(" ")#text(" when ")#mi("{q}")#text(" is a perfect square were constructed ")#link("https://terrytao.wordpress.com/2025/11/12/new-nikodym-set-constructions-over-finite-fields/linkinghub.elsevier.com/retrieve/pii/S1071579715000179")[#text("by Blokhuis et al")]#text(", again using the theory of blocking sets; by taking Cartesian products of such sets, one can also make similar constructions in higher dimensions, again assuming ")#mi("{q}")#text(" is a perfect square. Apart from this, though, there are few such constructions in the literature.")

#text("We set AlphaEvolve to try to optimize the three dimensional problem with a variable field size ")#mi("{q}")#text(" (which we took to be prime for simplicity), with the intent to get this tool to come up with a construction that worked asymptotically for large ")#mi("{q}")#text(", rather than just for any fixed value of ")#mi("{q}")#text(". After some rounds of evolution, ")#link("https://github.com/google-deepmind/alphaevolve_repository_of_problems/blob/main/experiments/finite_field_nikodym_problem/finite_field_nikodym.ipynb")[#text("it arrived at a construction")]#text(" which empirically had size about ")#mi("{q^3 - 8q^2}")#text(". Inspecting the code, it turned out that AlphaEvolve had constructed a Nikodym set ")#mi("{N}")#text(" by (mostly) removing eight low-degree algebraic surfaces (all of the form ")#mi("{\\{ (x,y,x^i y)\\}}")#text(" for various ")#mi("{i}")#text("). We used the tool DeepThink ")#link("https://github.com/google-deepmind/alphaevolve_repository_of_problems/blob/main/experiments/finite_field_nikodym_problem/deep_think_docs/nikodym.tex")[#text("to confirm the Nikodym property")]#text(" and to verify the construction, and then asked it to generalize the method. By removing many more than eight surfaces, and using some heuristic arguments based on the Chebotarev density theorem, DeepThink ")#link("https://github.com/google-deepmind/alphaevolve_repository_of_problems/blob/main/experiments/finite_field_nikodym_problem/deep_think_docs/nikodym2.tex")[#text("claimed a construction of size")]#text(" ")#metadata(none) <tao-5d7f4cf6343a238ae036>#tao-math("\\displaystyle  \\left|N\\right| = q^3 - 2 q^2 \\log q + o(q^2 \\log q) \\ \\ \\ \\ \\ (2)", block: false)#text(" ")#text(" formed by removing several higher degree surfaces, but it acknowledged that the arguments were non-rigorous.")

#text("The arguments can be sketched here as follows. Let ")#mi("{V}")#text(" be a random surface of degree ")#mi("{D}")#text(", and let ")#mi("{x}")#text(" be a point in ")#mi("{{\\mathbb F}_q^3}")#text(" which does not lie in ")#mi("{V}")#text(". A random line through ")#mi("{x}")#text(" then meets ")#mi("{V}")#text(" in a number of points, which is basically the set of zeroes in ")#mi("{{\\mathbb F}_q}")#text(" of a random polynomial of degree ")#mi("{D}")#text(". The (function field analogue of the) ")#link("https://en.wikipedia.org/wiki/Chebotarev_density_theorem")[#text("Chebotarev density theorem")]#text(" predicts that the probability that this polynomial has no roots in ")#mi("{{\\mathbb F}_q}")#text(" is about ")#mi("{\\delta_D}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\delta_D = 1 - \\frac{1}{1!} + \\frac{1}{2!} - \\dots + \\frac{(-1)^D}{D!}")]]

#text("is the proportion of permutations on ")#mi("{D}")#text(" elements that are ")#link("https://en.wikipedia.org/wiki/Derangement")[#text("derangements")]#text(" (no fixed points). So, if one removes ")#mi("{k}")#text(" random surfaces of degrees ")#mi("{D_1,\\dots,D_k}")#text(", the probability that a random line avoids all of these surfaces is about ")#mi("{\\delta_{D_1} \\dots \\delta_{D_k}}")#text(". If this product is significantly greater than ")#mi("{1/q^2}")#text(", then the law of large numbers (and concentration of measure) then predicts (with high probability) that out of the ")#mi("{\\sim q^2}")#text(" lines through ")#mi("{x}")#text(", at least one will avoid the removed surfaces, thus giving (most of) a Nikodym set. The ")#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/")[#text("Lang-Weil estimate")]#text(" predicts that each surface has cardinality about ")#mi("{q^2}")#text(", so this should give a Nikodym set of size about ")#mi("{q^3 - kq^2}")#text(".")

#text("DeepThink took the degrees ")#mi("{D_1,\\dots,D_k}")#text(" to be large, so that the derangement probabilities ")#mi("{\\delta_{D_i}}")#text(" were close to ")#mi("{1/e}")#text(". This led it to predict that ")#mi("{k}")#text(" could be taken to be as large as ")#mi("{2 \\log q}")#text(", leading to the claimed bound ")#link(<tao-5d7f4cf6343a238ae036>)[#text("(2)")]#text(". However, on inspecting this argument we realized that these moderately high degree surfaces were effectively acting as random sets, so one could dramatically simplify DeepThink’s argument by simply taking ")#mi("{N}")#text(" to be a completely random set of the desired cardinality ")#link(<tao-5d7f4cf6343a238ae036>)[#text("(2)")]#text(", in which case the verification of the Nikodym set property (with positive probability) could be established by a standard Chernoff bound-type argument (actually, I ended up using ")#link("https://en.wikipedia.org/wiki/Bennett%27s_inequality")[#text("Bennett’s inequality")]#text(" rather than Chernoff’s inequality, but this is a minor technical detail).")

#text("On the other hand, the derangement probabilities ")#mi("{\\delta_D}")#text(" oscillate around ")#mi("{1/e}")#text(", and in fact are as large as ")#mi("{1/2}")#text(" when ")#mi("{D=2}")#text(". This suggested that one could do better than the purely random construction if one only removed quadratic surfaces instead of higher degree surfaces, and heuristically predicted the improvement ")#metadata(none) <tao-2b35ed6944dd2e8f7462>#tao-math("\\displaystyle  \\left|N\\right| = q^3 - \\frac{2}{\\log 2} q^2 \\log q + o(q^2 \\log q). \\ \\ \\ \\ \\ (3)", block: false)#text(" ")#text(" However, our experiments with both AlphaEvolve and DeepThink to try to make this idea work either empirically, heuristically, or rigorously were all unsuccessful! Eventually ")#link("https://github.com/google-deepmind/alphaevolve_repository_of_problems/blob/main/experiments/finite_field_nikodym_problem/deep_think_docs/nikodym2.tex")[#text("Deepthink discovered the problem")]#text(": random quadratic polynomials often had two or zero roots (depending on whether the discriminant was a non-zero quadratic residue, or a nonresidue), but would only very rarely have just one root (the discriminant would have to vanish). As a consequence, if ")#mi("{x}")#text(" happened to lie on one of the removed quadratic surfaces ")#mi("{V}")#text(", it was extremely likely that most lines through ")#mi("{x}")#text(" would intersect ")#mi("{V}")#text(" in a further point; only the small minority of lines that were tangent to ")#mi("{V}")#text(" and ")#mi("{x}")#text(" would avoid this. None of the AI tools we tried were able to overcome this obstacle.")

#text("However, I realized that one could repair the construction by adding back a small random portion of the removed quadratic surfaces, to allow for a non-zero number of lines through ")#mi("{x}")#text(" to stay inside the putative Nikodym set even when ")#mi("{x}")#text(" was in one of the surfaces ")#mi("{V}")#text(", and the line was not tangent to ")#mi("{V}")#text(". Pursuing this idea, and performing various standard probabilistic calculations and projective changes of variable, the problem essentially reduced to the following: given ")#mi("{k}")#text(" random quadratic polynomials in the plane ")#mi("{{\\mathbb F}_q^2}")#text(", is it true that these polynomials simultaneously take quadratic residue values for ")#mi("{\\gg 2^{-k}}")#text(" of the points in that plane? Heuristically this should be true even for ")#mi("{2^{-k}}")#text(" close to ")#mi("{1/q^2}")#text(". However, it proved difficult to accurately control this simultaneous quadratic residue event; standard algebraic geometry tools such as the ")#link("https://en.wikipedia.org/wiki/Weil_conjectures")[#text("Weil conjectures")]#text(" seemed to require some vanishing of étale cohomology groups in order to obtain adequate error terms, and this was not something I was eager to try to work out. However, by exploiting projective symmetry (and the ")#mi("{2}")#text("-transitive nature of the projective linear group), I could get satisfactory control of such intersections as long as ")#mi("{2^{-k}}")#text(" was a little bit larger than ")#mi("{1/q}")#text(" rather than ")#mi("{1/q^2}")#text(". This gave an intermediate construction of size")

#align(center)[#tao-fit-display[#tao-math("\\left|N\\right| = q^3 - (\\frac{1}{\\log 2} + 1) q^2 \\log q + o(q^2 \\log q),", block: true)]]

#text("which still beat the purely random construction, but fell short of heuristic predictions. This argument (generalized to higher dimensions) is what is contained in the paper. I pose the question of locating a construction with the improved bound ")#link(<tao-2b35ed6944dd2e8f7462>)[#text("(3)")]#text(" (perhaps by some modification of the strategy of removing quadratic varieties) as an open question.")

#text("We also looked at the two-dimensional case to see how well AlphaEvolve could recover known results, in the case that ")#mi("{q}")#text(" was a perfect square. It ")#link("https://github.com/google-deepmind/alphaevolve_repository_of_problems/blob/main/experiments/finite_field_nikodym_problem/finite_field_nikodym.ipynb")[#text("was able to come up with a construction")]#text(" that was slightly worse than the best known construction, in which one removed a large number of parabolas from the plane; after manually optimizing the construction we were able to recover the known bound ")#link(<tao-bccb8ebe06c46c3598bd>)[#text("(1)")]#text(". This final construction is somewhat similar to existing constructions (it has a strong resemblance to a standard construction formed by taking the complement of a ")#link("https://en.wikipedia.org/wiki/Unital_(geometry)")[#text("Hermitian unital")]#text("), but is still technically a new construction, so we have also added it to this paper.")

#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/11/12/new-nikodym-set-constructions-over-finite-fields/#comment-689059")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2025")])]

#text("Wow ! Get an idea from AI and then develop a paper from it !! We have a new business model !!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/11/12/new-nikodym-set-constructions-over-finite-fields/#comment-689064")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2025")])]

#text("fun arguments. I noticed some minor typos you may wish to correct:")

#text("-On pages 5-6, throughout the proof of Lemma 2.1, the sign of epsilon is wrong. To see this, at the end you have exp(-c q^{-ep}), which is very close to 1, while you wish it to be very small.")

#text("-On page 6, “log(2)” is written rather than “log(2)”.")

#text("-On pages 8-9, when justifying Step 2, ‘p’ is written rather than ‘q’ twice.")

#text("-On page 11, “q^{2ep^2}” is written rather than “q^{1+2ep^2}” on two occasions.")

#text("-(nitpick) On page 11, you say that the chance Q_k vanishes on a fixed line containing the origin is is O(1/q^2). But we have already conditioned on vanishing in the origin, so the conditional probability of the event is Theta(1/q). I would just phrase the sentence slightly less ambiguous (though of course this is a subjective preference).")

#text("-On page 14, when recalling Lemma 3.6, you square the denominator inside of the expectation, which should not be done.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/11/12/new-nikodym-set-constructions-over-finite-fields/#comment-689065")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2025")])]

#text("Thanks for the corrections! They will be implemented in the next revision of the manuscript.")

#text("Regarding the “nitpick”: I think the probability of ")#mi("O(1/q^2)")#text(" (after conditioning on ")#mi("Q_k(0)=0")#text(") is correct as stated, as we need two additional vanishing conditions ")#mi("D_\\omega Q_k(0) = D_\\omega^2 Q_k(0) = 0")#text(" in order to get ")#mi("Q_k")#text(" to vanish identically on the line in the direction ")#mi("\\omega")#text(". Without the conditioning, the probability would in fact be of order ")#mi("1/q^3")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/11/12/new-nikodym-set-constructions-over-finite-fields/#comment-689067")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2025")])]

#text("ah yes of course. if what I was saying was true, then ")#tao-fit-display[#mitex("Q_k")]#text(" would have density ")#tao-fit-display[#mitex("1/2+\\Omega(1)")]#text("…")

#text("in any case, perhaps you could insert a parenthetical like (conditional) somewhere appropriate? but as written it is largely clear.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/11/12/new-nikodym-set-constructions-over-finite-fields/#comment-689068")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2025")])]

#text("That’s good to see what’s going on. thank you")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2012b6135b45cac63d35b9bd8c81bf95cb591596b76c826fa2a4adf0049718d2-3b843ddfe0611b39de10e584527432998e3ef7958bfbccc9faa356ef89b70d42.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Pezzi")]], [#link("https://terrytao.wordpress.com/2025/11/12/new-nikodym-set-constructions-over-finite-fields/#comment-689069")[#strong[#text("Daniel Pezzi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2025")])]

#text("How is authorship decided for a project like this? Did it come naturally out of the work, or was there a discussion about how results inspired by the project would be divided up? I feel this is something that will become more relevant as AI and scale collaboration increases.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/11/12/new-nikodym-set-constructions-over-finite-fields/#comment-689071")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2025")])]

#text("Each collaboration is different, but we discussed all the options together and eventually agreed on the setup where the main paper was jointly authored, but the spinoff papers inspired by the data generated by the project would be authored by those who would be working directly on those papers (which in this case ended up just being myself).")

#text("The AMS has some ")#link("https://www.ams.org/about-us/governance/policy-statements/sec-ethics")[#text("general guidelines")]#text(" on ethical considerations in this regard.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/11/12/new-nikodym-set-constructions-over-finite-fields/#comment-689072")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2025")])]

#text("Shouldnt the AI get co authorship?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/11/12/new-nikodym-set-constructions-over-finite-fields/#comment-689078")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2025")])]

#text("Its not a person so no, in the same why Python or Overleaf do not get coauthorship")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36522f1d982e6aaf9911c21b59a531cbb335a13dc742d5ad8e5e7f70cdb73924-3c80298975e2ae4851b3075af6465d18f4da0e51a5fcdd6c891839135c01efe1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ferdinand Ihringer")]], [#link("https://terrytao.wordpress.com/2025/11/12/new-nikodym-set-constructions-over-finite-fields/#comment-689076")[#strong[#text("Ferdinand Ihringer")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2025")])]

#text("The construction in Section 4 is not new. For instance, you find it in “R.D. Baker and G.L. Ebert, On Buekenhout-Metz unitals of odd order. J. Combin. Theory Ser. A, 60 (1992) 67–84”. For a link in the internet, ")#link("https://arxiv.org/pdf/2210.10228")[#text("this paper")]#text(" is a convenient reference. For the arXiv link, Result 1, taking alpha=sqrt(c) and beta=0 gives the set which you constructed. Here sqrt(c) is the value from your paper. (Up to me making calculation errors, but it is clearly the same construction.)")

#text("In general, the book “Unitals in Projective Planes”, 2008, Springer, by Barwick and Ebert is a good reference for constructions of unitals. Including all the construction by taking a unions of parabolas which share one point at infinity.")

#text("Indeed, Section 4.1 in your reference [3] (see Remark 4.1 in your paper) does not assume that the unital under consideration is a Hermitian unital.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/11/12/new-nikodym-set-constructions-over-finite-fields/#comment-689079")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2025")])]

#text("Thanks for this! It was challenging for me to navigate the literature on unitals as the notation is rather different from that in the Nikodym set literature, and the emphasis is often on general constructions rather than simpler special cases (such as the union of parabolas). (I also did not realize that, despite the title of the Blokhuis et al. paper, that the probabilistic blocking set constructed in that paper did not require the unital to be classical.) I will incorporate this reference into the next version of the paper; I think it is still worth noting it explicitly as a relatively simple construction of a two-dimensional Nikodym set that can be verified in a self-contained fashion without needing to first set up a more general theory of unitals. (Also, this construction provides a bridge between the higher-dimensional construction and the known two-dimensional constructions, as this special case of the 2D construction is formed by removing quadratic varieties from the entire space and then doing some probabilistic cleanup, just like the higher dimensional construction.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37432c98750e4022b84c1e02476ca47a145927ff594ef0eb39e820fe7e06b425-ce55d07280b037e17918e2e1908cc9c00ecabf3d55d9d47936fe5043346ccd52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2025/11/12/new-nikodym-set-constructions-over-finite-fields/#comment-689090")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2025")])]

#text("Nice!")

#text("A few more typos: you reference Theorem 3.4 and Theorem 3.5 but 3.4 is a Proposition and 3.5 is a Lemma.")

#text("Before 3.4 I think you claim that a homogeneous quadratic polynomial is absolutely irreducible if and only if it is not a scalar multiple of a perfect square. But ")#mi("xy")#text(" has neither property.")

#emph[#text("[I meant to say that ")#mi("Q_i")#text(" is absolutely irreducible iff ")#mi("\\tilde Q_i")#text(" is a perfect square. I’ll expand upon this in the next version of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37432c98750e4022b84c1e02476ca47a145927ff594ef0eb39e820fe7e06b425-ce55d07280b037e17918e2e1908cc9c00ecabf3d55d9d47936fe5043346ccd52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2025/11/12/new-nikodym-set-constructions-over-finite-fields/#comment-689091")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2025")])]

#text("The proof of 3.4 is an induction that ultimately relies on a second moment estimate. Based on this, I think it might be simpler to bound directly the second moment of ")#mi("E_1 \\cap \\dots \\cap E_k")#text(". This reduces to computing the probability that two points both lie in this intersection, which is the ")#mi("k")#text("th power of the probability that a single quadratic polynomial takes quadratic nonresidue values at two points. If we didn’t throw out the reducible polynomials this would be independent leading to Poisson variance and I think throwing out the reducibles makes this probability smaller, leading to a smaller variance. Higher moments could enable handling larger values of ")#mi("k")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/11/12/new-nikodym-set-constructions-over-finite-fields/#comment-689094")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2025")])]

#text("Very nice, this does indeed simplify Step 5 of the argument considerably! I will incorporate this into the next revision of the manuscript (with acknowledgment, of course).")
]
]
