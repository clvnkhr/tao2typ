// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/
// Converted to Typst by tao2typ: "2026-10-14T16:34:51.537880+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Open question: the Mahler conjecture on convex bodies", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Open question: the Mahler conjecture on convex bodies")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 March 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/")[#text("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("It seems that I have unwittingly started an “open problem of the week” column here; certainly it seems easier for me to pose unsolved problems than to write papers :-) .")

#text("This question in convex geometry has been around for a while; I am fond of it because it attempts to capture the intuitively obvious fact that cubes and octahedra are the “pointiest” possible symmetric convex bodies one can create. Sadly, we still have very few tools to make this intuition rigorous (especially when compared against the assertion that the Euclidean ball is the “roundest” possible convex body, for which we have many rigorous and useful formulations).")

#text("To state the conjecture I need a little notation. Suppose we have a symmetric convex body ")#mi("B \\subset {\\Bbb R}^d")#text(" in a Euclidean space, thus B is open, convex, bounded, and symmetric around the origin. We can define the ")#emph[#text("polar body")]#text(" ")#mi("B^\\circ \\subset {\\Bbb R}^d")#text(" by")

#align(center)[#mi("B^\\circ := \\{ \\xi \\in {\\Bbb R}^d: x \\cdot \\xi < 1 \\text{ for all } x \\in B \\}")#text(".")]

#text("This is another symmetric convex body. One can interpret B as the unit ball of a Banach space norm on ")#mi("{\\Bbb R}^d")#text(", in which case ")#mi("B^\\circ")#text(" is simply the unit ball of the dual norm. The ")#emph[#text("Mahler volume")]#text(" ")#mi("M(B)")#text(" of the body is defined as the product of the volumes of B and its polar body:")

#align(center)[#tao-fit-display[#mitex("M(B) := \\text{vol}(B) \\text{vol}(B^\\circ).")]]

#metadata(none) <tao-c5ee33a4b4a5bc76df1d>#text("One feature of this Mahler volume is that it is an affine invariant: if ")#mi("T: {\\Bbb R}^d \\to {\\Bbb R}^d")#text(" is any invertible linear transformation, then TB has the same Mahler volume as B. It is also clear that a body has the same Mahler volume as its polar body. Finally the Mahler volume reacts well to Cartesian products: if ")#mi("B_1 \\subset {\\Bbb R}^{d_1}, B_2 \\subset {\\Bbb R}^{d_2}")#text(" are convex bodies, one can check that")

#align(center)[#mi("M(B_1 \\times B_2) = M(B_1) M(B_2) / \\binom{d_1+d_2}{d_1}")#text(".")]

#text("For the unit Euclidean ball ")#mi("B^d")#text(" one can easily compute the Mahler volume as")

#align(center)[#tao-fit-display[#mitex("M(B^d) = \\frac{\\Gamma(3/2)^{2d} 4^d}{\\Gamma(\\frac{d}{2} + 1)^2} = (2\\pi e + o(1))^d d^{-d}")]]

#text("while for the unit cube ")#mi("Q^d")#text(" or the unit octahedron ")#mi("O_d = (Q^d)^\\circ")#text(" the Mahler volume is")

#align(center)[#mi("M(Q^d) = M(O_d) = \\frac{4^d}{\\Gamma(d+1)} = (4e + o(1))^d d^{-d} = (\\frac{4}{2\\pi} + o(1))^d M(B^d)")#text(".")]

#text("One can also think of ")#mi("Q^d, B^d, O_d")#text(" as the unit balls of the ")#mi("l^\\infty, l^2, l^1")#text(" norms respectively.")

#text("The Mahler conjecture asserts that these are the two extreme possibilities for the Mahler volume, thus for all convex bodies ")#mi("B \\subset {\\Bbb R}^d")#text(" we should have")

#align(center)[#tao-fit-display[#mitex("M(Q^d) = M(O_d) \\leq M(B) \\leq M(B^d).")]]

#text("Intuitively, this means that the Mahler volume is capturing the “roundness” of a convex body, with balls (and affine images of balls, i.e. ellipsoids) being the roundest, and cubes and octahedra (and affine images thereof) being the pointiest.")

#text("The upper bound was established by ")#link("http://www.ams.org/mathscinet-getitem?mr=39293")[#text("Santaló")]#text(" (with the three-dimensional case settled much earlier by Blaschke), using the powerful tool of ")#emph[#text("Steiner symmetrisation")]#text(", which basically is a mechanism for making a convex body rounder and rounder, converging towards a ball. One can quickly verifies that each application of Steiner symmetrisation does not decrease the Mahler volume, and the result easily follows. As a corollary one can show that the ellipsoids are the only bodies which actually attain the maximal Mahler volume. (Several other proofs of this result, now known as the ")#emph[#text("Blaschke-Santaló inequality")]#text(", exist in the literature. It plays an important role in affine geometry, being a model example of an ")#emph[#text("affine isoperimetric inequality")]#text(".) Somewhat amusingly, one can use Plancherel’s theorem to quickly obtain a crude version of this inequality, losing a factor of ")#mi("O(d)^d")#text("; more generally, though, I doubt that these sorts of “sharp constant” problems (for which one cannot afford to lose unspecified absolute constants) are amenable to a Fourier-analytic approach.")

#text("The lower inequality remains open. In my opinion, the main reason why this conjecture is so difficult is that unlike the upper bound, in which there is essentially only one extremiser up to affine transformations (namely the ball), there are many distinct extremisers for the lower bound – not only the cube and the octahedron, but also products of cubes and octahedra, polar bodies of products of cubes and octahedra, products of polar bodies of… well, you get the idea. It is really difficult to conceive of any sort of flow or optimisation procedure which would converge to exactly these bodies and no others; a radically different type of argument might be needed.")

#text("If one is willing to lose some factors in the inequality, then some partial results are known. Firstly, from ")#link("http://www.ams.org/mathscinet-getitem?mr=30135")[#text("John’s theorem")]#text(" one trivially gets a bound of the form ")#mi("M(B) \\geq d^{-d/2} M(B^d)")#text(". A significantly deeper ")#link("http://www.ams.org/mathscinet-getitem?mr=880954")[#text("argument of Bourgain and Milman")]#text(", using the theory of cotype (which roughly speaking controls the size of long random sums in a normed vector space), gives a bound of the form ")#mi("M(B) \\geq C^{-d} M(B^d)")#text(" for some absolute constant C; this bound is now known as the ")#emph[#text("reverse Santaló inequality")]#text(". A slightly weaker “low-tech” bound of ")#mi("M(B) \\geq (\\log_2 d)^{-d} M(B^d)")#text(" was given ")#link("http://www.ams.org/mathscinet-getitem?mr=1185832")[#text("by Kuperberg")]#text(", using only elementary methods. The best result currently known is again ")#link("http://arxiv.org/abs/math.MG/0610904")[#text("by Kuperberg")]#text(", who showed that")

#align(center)[#tao-fit-display[#mitex("M(B) \\geq (\\pi/4)^{d-1} M(Q^d)")]]

#text("using some Gauss-type linking integrals associated to a Minkowski metric in ")#mi("{\\Bbb R}^{d+d}")#text(".")

#text("In another direction, the Mahler conjecture has also been verified for some special classes of convex bodies, ")#link("http://www.ams.org/mathscinet-getitem?mr=845207")[#text("such as zonoids")]#text(" (limits of finite Minkowski sums of line segments) ")#link("http://www.ams.org/mathscinet-getitem?mr=670798")[#text("and 1-unconditional convex bodies")]#text(" (those which are symmetric around all coordinate hyperplanes).")

#text("There seem to be some other directions to pursue. For instance, it might be possible to show that (say) the unit cube is a ")#emph[#text("local")]#text(" minimiser of Mahler volume, or at least that the Mahler volume is stationary with respect to small perturbations of the cube (whatever that means). Another possibility is to locate some reasonable measure of “pointiness” for convex bodies, which is extremised precisely at cubes, octahedra, and products or polar products thereof. Then the task would be reduced to controlling the Mahler volume by this measure of pointiness.")

#text("Some time ago I wrote ")#link("http://www.math.ucla.edu/~tao/preprints/Expository/santalo.dvi")[#text("some notes")]#text(" on the more elementary aspects of the above theory; it was intended for my ")#link("http://www.math.ucla.edu/~tao/preprints/books.html")[#text("book with Van Vu")]#text(" but eventually got deleted as the book was already too big and getting unfocused.")

#heading(level: 1)[#text("Comments (60)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec63391549c20d029fe21f24716b8bf7c797cc520cdf14ccc475d1457e87685b-bda1615a15b7fa1158807c8db0b663b704f5a1b2b51defec7dddf7cba622952c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fedja")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-2/#comment-203672")[#strong[#text("fedja")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2012")])]

#text("A small but very nice update. Artem’s student Jaegil Kim finally proved that all Hanner polytopes give you local minima. See ")#link("http://arxiv.org/abs/1212.2544")[#text("http://arxiv.org/abs/1212.2544")]#text(". Comments are welcome :).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cda70684e71a2722e031678e0d75e0c9d624279f0784ec8e10570e612c8d2027-a441725d75afeb53f9fd983598fba4a8be3b73a86440b3925a3a2d9a78eae5ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samuel Reid")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-2/#comment-267324")[#strong[#text("Samuel Reid")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2014")])]

#text("I have a proof of the Mahler conjecture which I have uploaded to arXiv. I have been working for about 6 months on the conjecture and managed to solve it with an insight regarding the representation of d-dimensional metric quantities in terms of 2d-dimensional metric quantities.")

#text("E-mail me if you are interested in the proof before it appears on arXiv under")#linebreak()#text(" “Minimizing the Mahler Volume of Symmetric Convex Bodies”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a1fce5b3db0d8291b82ea918d1009d1c88ec16bbad30ec19d1cd86e634054ac0-36285a660e5a4b319dad4138e0e27a48be0c8c859097bee6a57c73a91c497ef8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samuel Reid")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-2/#comment-267368")[#strong[#text("Samuel Reid")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2014")])]

#text("Well, I realized I claimed an inequality that I still need to prove, so I will try and fix it and then make a comment regarding my correct or failed proof strategy after I have done more work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf0f4fe3d65881c1ad21d60ba0e774d589f6f787f894ab946103cf10365f226b-34b024389300d1880228e2e2ddde17baee90233e8d99d7bfa9da7957950def26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-2/#comment-519313")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2019")])]

#text("It has been proved that if the isotropic constant conjecture/Bourgain`s slicing conjecture is fails, the Mahler conjecture fails, and an exact bound to the isotopic constant implies the Mahler conjecture. I have proved the isotropic constant conjecture. The proof can be found in here: ")#link("http://vixra.org/pdf/1810.0303vA.pdf")[#text("http://vixra.org/pdf/1810.0303vA.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2431725da0423db949a76c4e81cfbee1b08d03cea22908cfa86ee7dd3a4a32a-01ef04b5ef1b58a71fbe0cc8f3b459639a6650f6e3bd441f92d2281551b7dd30.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-2/#comment-519510")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2019")])]

#text("This reply of mine contained some thinkos/typos. An exact bound should be exact bound with respect to dimension. I couldn`t find reference for the first claim, but it is quite easy to proof. This is a bit risky for me, because there seems to be no edit button and I can`t see my comment in it`s final form as in some other blogs. Let ")#mi("K")#text(" be an isotropic unit ball. Then the isotropic constant is")

#tao-math("\\displaystyle L_K^2 = \\frac{\\int_K \\left|x\\right|^2}{n\\left|K\\right|}*\\left|K\\right|^{-2/n} \\leq \\frac{\\left|K\\right|}{\\left|K\\right|}*\\left|K\\right|^{-2/n} = \\frac{1}{\\left|K\\right|^{2/n}}.", block: false)

#text("The proof works the same if ")#mi("K^{\\prime}")#text(" is the isotropic version of ")#mi("K^{\\circ}")#text(" with ")#tao-math("\\left|K^{\\prime}\\right| = \\left|K^{\\circ}\\right|.", block: false)#text(" Let ")#mi("B_2")#text(" be the euclidean unit ball. Thus,")

#tao-math("\\displaystyle L_{B_2}L_K \\leq L_{K^{\\circ}}L_K \\leq (\\left|K\\right|\\left|K^{\\circ}\\right|)^{1/n},", block: false)

#text("as it is well known that ")#mi("L_{B_2} \\leq L_{K}")#text(" for any ")#mi("K.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/acc0087dd97d6dd95107914b2f1478cba8fa8d5dc5126796a11aff22a2c05b3c-51efdb7e1e6e2b05dbe987a4d15ee798562ab897def7b673d5a9793b900b8b39.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Affine Restriction estimates imply Affine Isoperimetric inequalities | Almost Originality")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-2/#comment-536167")[#strong[#text("Affine Restriction estimates imply Affine Isoperimetric inequalities | Almost Originality")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2020")])]

#text("[…] about this topic, the reader should check out these lecture notes by Ryabogin and Zvavitch and also this post by Tao where you can find other interesting contributions by other experts in the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e9c151f448f1565890afe20fe4f3a0246c519f1e7ed415976be0f31a38e445a-744e0d6fa1f8c093c2f3250ac4fdedb90502869debfeba16e81abd46e318a5cc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alejandro Vicente")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-2/#comment-658649")[#strong[#text("Alejandro Vicente")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2022")])]

#text("In 2013 it was shown a deep connection between the Mahler Conjecture and another Conjecture in Symplectic Geometry, namely, the Viterbo isoperimetric Conjecture. It turns out that the former is equivalent to a special case fo the latter.")

#text("This Viterbo Conjecture deals with the relation between symplectic capacities (some sort of two dimensional “measures” that can be taken in symplectic manifolds, dependent on the symplectic form) and the volume of this manifold (the volume form provided by the symplectic form), roughly speaking, it claims that the ratio of this quantities is bounded. These symplectic capacities can be varied in nature, they can be defined using symplectic embeddings, action selectors in dynamics associated to the symplectic manifolds, etc.")

#text("There is a particular one, the Hofer-Zehnder capacity, defined from dynamical information. It has been proven that the Mahler Conjecture holds if and only if the Viterbo Conjecture holds for the Hofer-Zehnder capacity on the class of symplectic submanifolds of ")#mi("K\\times K^{\\circ}\\subset \\mathbb{R}^{2n}")#text(" for ")#mi("K\\subset \\mathbb{R}^n")#text(" a convex body.")

#text("This Viterbo Conjecture is (obviously) still wide open, only proven in a few selected cases, which do not include the equivalent setting to the Mahler Conjecture.")

#text("Here is the arxiv link to the paper from Arstein-Avidan, Karasev and Ostrover proving the equivalence:")#linebreak()#text(" ")#link("https://arxiv.org/abs/1303.4197")[#text("https://arxiv.org/abs/1303.4197")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e8ba354408860d8a4ca0ae8876cbc0985f27eaf398d29c43e21204e683a22e1-d4977aa11be9be9ab76c3109a2bdaa15515638b9b0c6337e424a5e50fe638f0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-2/#comment-658711")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2022")])]

#text("In my previous comments I spoke about the nonsymmetric Mahler conjecture. There indeed is a unique minimizer (the simplex) for the inner volume-ratio in the nonsymmetric case. Suppose that the cross polytope ")#mi("P")#text(" (the dual of the cube) would be the unique minimizer for the inner volume ratio in the symmetric case. This is defined up to affine transformation as")

#tao-math("\\displaystyle (v(K,B_n))^n = \\max_{B \\subset K}\\frac{\\left|K\\right|}{\\left|B\\right|},", block: false)

#text("where ")#mi("B_n")#text(" is the standard unit ball. It is an established fact that the cube ")#mi("C_n")#text(" is the unique maximizer for ")#mi("v(K,B_n).")#text(" Thus, if the ")#mi("P")#text(" would be the unique minimizer of the volume ratio then for any ")#mi("K")#text(" we would have")

#tao-math("\\displaystyle (A) \\frac{\\left|P\\right|}{|B(0,(\\sqrt{(}n))^{-1})|} \\leq v(K,B_n) \\leq v(K^{\\circ}, B_n) < \\frac{2^n\\left|C_n\\right|}{\\left|B_n\\right|}.", block: false)

#text("The above (A) would easily imply the Mahler conjecture because both the standard cross polytope and the standard cube have the maximal Banach-Mazur distance to the Euclidean unit ball. In the case if there is a set inclusion for the unit balls ")#mi("P \\subset K")#text(" then (A) will still hold. But because ")#mi("P")#text(" is not the unique minimizer, it actually shows that ")#mi("P")#text(" is not even minimizer for the inner volume ratio ")#mi("v(K,B_n).")

#text("Now to the point: the cross polytope ")#mi("P")#text(" maximises the outer volume ratio")

#tao-math("\\displaystyle (v^{\\circ}(K,B_n))^n = \\min_{K \\subset B}\\frac{\\left|B\\right|}{\\left|K\\right|}.", block: false)

#text("So it minimizes ")#mi("(v^{\\circ}(K,B_n))^{-1}.")#text(" It's then clear that the ratio ")#mi("\\frac{v(K,B_n)}{v^{\\circ}(K^{\\circ},B_n)}")#text(" is maximized when ")#mi("K=P")#text(". This ratio is at least in that case the Mahler product of the cross polytope.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e8ba354408860d8a4ca0ae8876cbc0985f27eaf398d29c43e21204e683a22e1-d4977aa11be9be9ab76c3109a2bdaa15515638b9b0c6337e424a5e50fe638f0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-2/#comment-658715")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2022")])]

#text("Ok. In the ratio calculation: The unit ball should have been the unit cube and the ratio should have been the other way around, so that the ratio gets minimized not maximised. And the ratio in a fixed dimension is a scaled version of the Mahler Volume.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-2/#comment-685647")[#strong[#text("Open problem session of HUJI-COMBSEM: Problem #5, Gil Kalai – the 3ᵈ problem | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2024")]

#text("[…] Gideon asked about the connections with Mahler’s conjecture that for every d-dimentional centrally symmetric body K, . Indeed the cases of equality are conjectured to be the same – the class of Hanner polytopes. (Mahler’s conjecture and its relations to combinatorics would deserve a separate post.) The recent paper Flag numbers and floating bodies‏ by F Besau, C Schütt, EM Werner looks very relevant. (Update (2024): I forgot to mention this nice 2007 post by Terry Tao about Mahler’s conjecture.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2e69fe991008100445ec71dcce3acc2dd72f160b39f34a569b2669354396f85-1909c969e8c28926f573b796901e14bbf8458eb0ecb81c2ff446a678aa5879f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy D")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-51")[#strong[#text("Andy D")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2007")])]

#text("Terence, it is really valuable to have informal expository writing from an experienced mathematician, interspersing accurate descriptions of problems with your perspectives on why they are difficult and where various techniques are likely to apply (e.g., what you said about the strengths of analytic vs. algebraic number theory).")

#text("So thanks! Also, I think your readers will not be at all disappointed if you blog about math that is not new or open but that deserves to be better known –or for its Tomb Raider interpretation to be better known :) –or affords a good opportunity for learning/problem solving.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/202468adb23de6adbd67cc852aaa06ab8372594313f1f5b38ef263a041805a73-0581efa7ca7b2a9e94629f11ef58dc253e3c758544ce747e9780e33e6f6577e4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sirix")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-52")[#strong[#text("sirix")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2007")])]

#text("I totally agree with Andy D. So, big thank You from me as well!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6ec46f139ccfe2527934c440b71bf63d4a7454637fe51a67f6d301289cd8a81-ed0feae4e37e419f1da4150da44efc7bb857350be1859015d797974bc35b0c29.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. Eppstein")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-54")[#strong[#text("D. Eppstein")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2007")])]

#text("I found some references indicating that the conjecture was known to be true for d=2, but not for d=3. Is it still unknown in that case? Can it be proven that the local minimizing shapes for this conjecture are polyhedra, and if so are there any known constraints on the extremal polyhedra (e.g. they should have edges tangent to a sphere)? I am wondering whether enough constraints can be made on the form of the solution to reduce the problem to calculation over a finite number of cases in bounded dimensions; e.g., only over polyhedra with a bounded number of facets.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-55")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2007")])]

#text("As far as I know, the d=3 case is open. It does seem intuitively plausible that local minimisers of Mahler volume should have lots of “flat” sides, and thus presumably be a polyhedron, and it may well be that any rigorous proof of that fact may even come with an upper bound on the complexity of that polyhedron. But I am not aware of any actual results in this direction. Note that as Mahler volume is an affine invariant, it is unlikely that the Euclidean sphere (or any other fixed shape) is involved unless one first normalises the body (e.g. to make the John ellipsoid Euclidean).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo'az Klartag")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-56")[#strong[#text("Bo'az Klartag")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2007")])]

#text("Suppose we remove the assumption that B is symmetric about the origin.")#linebreak()#text(" It seems reasonable to guess that the minimal mahler volume is now attained for a simplex whose barycenter is at the origin. The mahler volume of the simplex is roughly (e/4)^d times that of the cube.")

#text("This non-symmetric Mahler conjecture might be a little bit easier, since the set of conjectured minimizers is more approachable: I think it should be only simplices. Is there a process that a) preserves simplices whose barycenter lies at the origin b) does not increase the volume product and c) converges to a simplex?")

#text("Also, Santalo’s inequality holds for any centrally-symmetric set B, not necessarily convex (taking the convex hull just increases the volume and doesn’t change the polar), while for the Mahler problem, you actually need to use the convexity of B somehow. This might make the problem more difficult.")

#text("Finally, about Bourgain-Milman’s proof: I am not completely sure whether the type and cotype arguments are really the main ingredient there. At least the proof that that is given in Pisier’s book doesn’t have much relation to type and cotype.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-57")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2007")])]

#text("Thanks, Bo’az, for the comments!")

#text("It does indeed look like the non-symmetric problem is going to be an easier one (and in fact embodies the idea that Mahler volume is minimised for “pointy” bodies even better than the symmetric problem), as it does look a little easier to make a process that converges to a simplex than to a cube/octahedron. Here’s one crazy idea: it suffices by limiting arguments to prove the claim for polyhedra. But every polyhedron is the projection of a simplex – perhaps a lifting argument (suitably normalising the Mahler volume as the dimension increases) might work? One may need to work with log-concave functions instead of polyhedra to get better behaviour with respect to projections, though one then has to figure out what the analogue of polar body becomes. (Young dual?)")

#text("In Kuperberg’s papers, one of the key ideas is to try to work with the product ")#mi("B \\times B^\\circ")#text(" as a unified object sitting in “phase space” ")#mi("{\\Bbb R}^d \\times {\\Bbb R}^d")#text(", and specifically inside the set ")#tao-math("\\{ (x,\\xi): \\left|x \\cdot \\xi\\right| \\leq 1 \\}", block: false)#text(". It may be that one may have to run the process at this level rather than purely in “physical space”. On the other hand, the above set is not convex, which creates a certain amount of difficulty.")

#text("I looked through Pisier’s book briefly – it seems he deduces the reverse Santalo inequality from Milman’s quotient-subspace theorem, which appears to be a slightly different route than the original Bourgain-Milman approach (but I don’t have the original papers handy right now to check).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-58")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2007")])]

#text("Dear all, This is a very beautiful problem and it is great that Greg Kuperberg had this recent breakthrough putting the bound at ")#mi("(4/\\pi)^n")#text(". Maybe, in view of Greg’s result hoping for a gap of ")#mi("(1+\\epsilon)^n")#text(" is realistic.")

#text("The known extremal cases are called Hanner polytopes, and as explained in the post they are obtained from intervals symmetric around 0 by the operations: 1) Cartesian product, and 2) moving from P to its polar.")

#text("Hanner Polytopes are known or conjectured to be the only extreme examples to several other problems.")

#text("1) Attaining the maximum Banach-Mazur distance to the unit ball. (I am not sure about the precise status of this problem.)")

#text("This suggests to try to find the maximum of ")#mi("\\text{vol}(P) \\times \\text{vol}(P^\\circ)")#text(" when there is an upper bound on the Banach-Mazur distance between and a unit ball.")

#text("2) The number of non empty faces (of all dimension; including P itself) of every Hanner n-dimensional polytopes is ")#mi("3^n")#text(". This is conjectured (but embarrassingly not known) to be the minimum for centrally-symmetric n-dimensional polytopes.")

#text("3) Every Hanner polytopes has the property that if two of three translates have a point in common then all three have a point in common. (This was proved by Hanner himself.) A difficult result by Lima (I think, maybe with Hansen) shows that this Helly-type property characterizes Hanner polytopes.")

#text("(There is also a more general notion of weak Hanner polytopes arising in graph theory (Fulkerson, Chvatal, Hansen).)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d509e4a67398165676196d672585ced90e7a9aff3d5e153a8ae82ca3a3719829-6913ece6216ee2882ebb73ce44bcf73b0437e510ad495f289d6450d43f808d08.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Danny Calegari")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-61")[#strong[#text("Danny Calegari")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2007")])]

#text("Is it really inconceivable that some flow might find exactly the desired minima?")#linebreak()#text(" It’s true that they come in interesting, complicated families, but aren’t")#linebreak()#text(" these families all symmetric spaces for the natural orthogonal group")#linebreak()#text(" action on the “space of convex bodies”? Couldn’t the flow be O-equivariantly")#linebreak()#text(" Morse-Smale, or whatever it’s called? Of course, there would (presumably)")#linebreak()#text(" be other critical points, i.e. products of cubes (or polar bodies thereof) with")#linebreak()#text(" spheres but presumably enough is known about the equivariant cohomology")#linebreak()#text(" of spaces with orthogonal group actions, and about the homotopy type of")#linebreak()#text(" the “space of convex bodies” to see if this makes sense. Just a question at")#linebreak()#text(" the “village idiot” level – what does grad M look like on the space of convex")#linebreak()#text(" bodies (thought of as a subspace of the space of smooth functions on RP^n)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo'az Klartag")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-62")[#strong[#text("Bo'az Klartag")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2007")])]

#text("Yes, you’re right, maybe the problem is a little bit simpler with log-concave functions. Write ")#mi("L(f)")#text(" for the Legendre transform of ")#mi("f")#text(".")#linebreak()#text(" Then Santalo’s inequality is equivalent to")#linebreak()#text(" ")#mi("\\int_{\\mathbb{R}^n} \\exp(-f)  \\int_{\\mathbb{R}^n} \\exp(-L(f)) \\leq (2 \\pi)^n")#linebreak()#text(" for any convex function ")#mi("f")#text(" for which the barycenter of the density ")#mi("\\exp(-f)")#text(" is at the ")#link("http://www.ams.org/mathscinet-getitem?mr=2220210")[#text("origin")]#text(". The conjectured Mahler inequality is equivalent to")#linebreak()#text(" ")#mi("\\int_{\\mathbb{R}^n} \\exp(-f)  \\int_{\\mathbb{R}^n} \\exp(-L(f)) \\geq e^n")#linebreak()#text(" for any convex function ")#mi("f")#text(". The function ")#mi("f")#text(" for which")#linebreak()#text(" ")#mi("f(x_1,\\ldots,x_n) = -n/2 + \\sum_i x_i")#text(" when all ")#mi("x_i > -1")#text(", and that equals infinity elsewhere, should be a minimizer. That’s our “simplex”.")

#text("A nice thing with this log-concave formulation, is that the polar of the product is just the product of the polars. With convex bodies it’s a more messy. Also, denote by ")#mi("M_n")#text(" the minimal Mahler volume in dimension ")#mi("n")#text(", for log-concave functions. Then we see that")#linebreak()#text(" ")#mi("M_{2n}^{1/2n} \\leq M_n^{1/n}")#text(". So, the desired conjecture would follow if we could show that ")#mi("M_n \\geq (e - o(1))^n")#text(". Does it somehow help for the “lifting”?")

#text("If we work in the phase space, the Mahler inequality we want looks a little bit like some exact uncertainty principle. So, maybe the Fourier analysis approach has still something to contribute? The Legendre transform is some degenaration of the the Laplace transform, in some vague sense. I don’t know.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo'az Klartag")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-63")[#strong[#text("Bo'az Klartag")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2007")])]

#text("My formulae have already failed on the html level, let alone mathematically.")#linebreak()#text(" Is there a way to test the way a formula would appear, before posting a comment?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-64")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2007")])]

#text("Hi folks. It is very, very nice to have this discussion about my recent paper.")

#text("As Terry alludes, the first important idea is to consider another body, the “diamond body” ")#mi("K^\\diamondsuit \\subseteq K \\times K^\\circ")#text(". I do not know how widely important this body is in convex geometry in general, but I it seems like a basic structure in convex geometry. If it is useful for the Bourgain-Milman theorem, then it may well be useful for some other problems.")

#text("I came up with ")#mi("K^\\diamondsuit")#text(", and the conjecture that its volume is minimized when ")#mi("K")#text(" is an ellipsoid, when I was a senior at Harvard. My dad suggested the name “the bottleneck conjecture”. David Kazhdan assigned me the Bourgain-Milman theorem for my senior thesis, and eventually I mentioned this idea to Joseph Bernstein, who was my reader. Bernstein estimated that my program had a 1 in 10 chance of working, but that these were actually very respectable odds for such an optimistic idea. Later I wrote two papers with partial results that were inspired by the conjecture that I really wanted to solve, but obviously fell short. I also found some “warning signs” in d=3 that suggested that my conjecture might not be true. I felt very discouraged and basically shelved the question.")

#text("In 2006, I figured that since differential geometry is in such great shape because of Perelman, I might as well give the “bottleneck” conjecture another try. It made all the difference that I had learned about linking integrals both from working on Kontsevich’s configuration space integrals, and from a paper of Gluck and DeTurck on the Biot-Savart law in ")#mi("S^3")#text(". I had actually thought of using a homological method for the conjecture before — from examples such as Gromov and Thurston norms. But I had thought that it wouldn’t work because there are no ")#emph[#text("closed")]#text(" differential forms available for the argument. But, as the Gluck-DeTurck example shows, Gauss linking forms may be weakly closed double forms rather than closed forms.")

#text("I spent the most time thinking about parabolic flows, as Terry says, to prove the bottleneck conjecture. Conceivably these could still work, but the structure of the linking form that appears in my paper is some evidence against. On the other hand, one of the two forms of the (generalized) bottleneck conjecture is still open, and who knows what methods it needs. I think that it is an interesting question in indefinite geometry.")

#text("Sorry to go on with all of the egotistical details of this question. As it happens, I was almost exactly twice as old when I proved the bottleneck conjecture as when I proposed it, 19 1/2 versus 39. I also did a key last step when I was in the hospital after surgery on my ankle, unable to sleep. I have no idea how I managed to accomplish anything in those circumstances. (“I thank Sutter-Davis hospital for its hospitality.”) During the 3 months of recovery (I am fully recovered now), I figured maybe I can prove another good theorem, but no such thing happened. Anyway it really has been a non-trivial personal journey.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-65")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2007")])]

#text("Dear Bo’az: I manually repaired the LaTeX. In order to get the ability to preview a post or comment it seems you need to get a wordpress account (which, incidentally, is trivial), but in the meantime the manual approach seems to work. The Legendre formulation looks quite promising, as does the trick of working in the asymptotic regime ")#mi("n \\to \\infty")#text(". At that level there may be an asymptotically equivalent formulation which is more tractable (e.g. involving entropy – but now I’m just throwing out buzzwords randomly). This sort of “tensor product trick” has proven effective in a number of other contexts.")

#text("The Mahler conjecture is indeed reminiscent of an uncertainty principle. I had discarded the Fourier approach in part because it seemed highly unlikely that any Fourier inequality would be optimised for, say, the indicator function of a cube or simplex (it’s more typical to see Gaussians or something as the extremisers). But now that we have an asymptotic formulation, which gives us a bit more wiggle room, this objection might start to disappear.")

#text("Dear Danny: Thanks for the comments! One minor quibble: the relevant structure group here is ")#mi("GL_n({\\Bbb R})")#text(" rather than ")#mi("O_n({\\Bbb R})")#text(", as Mahler volume is an affine invariant and not just a Euclidean invariant. There may indeed be an affinely equivariant Morse function which has the moduli space of Hanner polytopes as the minimal points, but it would be a rather strange function, in particular it is likely to contain some other exotic critical points. If one could actually write down a function which looked critical at these polytopes then one is probably already more than halfway done to solve the problem.")

#text("Incidentally, I think your “villages” are more mathematically literate than most :-) . Computing grad M in terms of the graphing function of the body is likely to be a bit messy because the polar body is given in this non-local manner. Using the log-concave formulation may be a bit more pleasant; it may be cleverer still to somehow “relax” the problem from a product of a body and its polar, to a more general class of objects (or functions) in phase space, in which it is easier to move around in a purely “local” fashion (both in physical space and in the dual space). It may be feasible at least to show using this method that a smooth, ")#emph[#text("strictly")]#text(" convex body cannot be a local minimum.")

#text("Dear Gil: thanks for the post! The fact that there are indeed other quantities which are known or conjectured to be extremised at these polytopes does give one some hope. At the bare minimum it should allow one to “factor” the Mahler conjecture into two presumably simpler conjectures…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-66")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2007")])]

#text("Also I should mention that I got a lot of very good negative advice in Madrid from differential geometers about just how non-trivial the moduli space of metrics and submanifolds are. Maybe they didn’t think of their advice as negative, but they had a lot of non-trivial things to say and I took it as warnings against naivete. There may be a PDE flow to solve the remaining open version of the bottleneck conjecture. But it is clear that optimizing flows don’t just “grow on trees”. Besides just parabolic flows, I was considering geodesics in moduli spaces of submanifolds of a manifold. The problem is that the formal Riemannian metric structure that you get on submanifolds of a Riemannian manifold is pathological in some ways.")

#text("Since there is no preview button here, I ended up with a TeX-o in my previous message, \\otimes should be \\times. [")#emph[#text("Fixed now")]#text(" – T.]")

#text("Terry points out that the set in phase space between the positive and negative unit hyperboloids is not convex, and he astutely points out that this makes the analysis harder. This is true, but actually I do not know whether ")#mi("K^\\diamondsuit")#text(" is ever non-convex when ")#mi("K")#text(" is a convex body. By definition, the boundary of ")#mi("K^\\diamondsuit")#text(" is the join (with straight line segments) of two necks ")#mi("K^+")#text(" and ")#mi("K^-")#text(" of the hyperboloids. I am not completely sure, but I sort-of see that the hyperboloids are contact manifolds, and that the necks ")#mi("K^\\pm")#text(" are Legendrian submanifolds. If these necks are interesting objects of study, as I think they are, then the fact that they are Legendrian would give you a lot of geometry to work with. This is in addition to what I prove in the paper, that ")#mi("K^\\pm")#text(" are spacelike and timelike submanifolds of the hyperboloids ")#mi("H^\\pm")#text(" as well as topological cores.")

#text("By the way, Terry uses my somewhat unlucky old notation for the Mahler volume, ")#mi("M(K)")#text(". This is almost the same notation as a different constant defined by Milman. In my new paper I write ")#mi("v(K)")#text(" for the Mahler volume. The formula that Terry gives is in my paper, but it is very slightly off from the real bound:")

#mi("v(K) \\ge \\frac{2^d v(B^d)}{\\binom{2d}{d}}")

#text("Gil points out that the Hanner polytopes have the same Mahler volume as the cube. Hanner polytopes also seem special in my paper, because they have the property that ")#mi("K^\\diamondsuit = K \\times K^\\circ")#text(". I know of no other convex bodies with this property. Very optimistically, this is a hint at completely proving the Mahler conjecture. The whole point of my paper is that ")#mi("K^\\diamondsuit")#text(" approximately grows as ")#mi("K \\times K^\\circ")#text(" shrinks, despite the fact that the former is a subset of the latter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-67")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2007")])]

#text("By the way, to answer David and Danny, I am optimistic that there is a variational proof of the Mahler conjecture in 3 dimension from a Morse perspective. In fact, I would be tempted to ask David and Danny themselves about the geometry relevant to this approach.")

#text("You shoud look at the proof of the Mahler conjecture in 2 dimensions. The Mahler volume of a polygon is concave down as you pivot a pair of opposite sides. If you try to maximize the Mahler volume, the polygon limits to a regular polygon as you repeatedly pivot all pairs of sides. If you try to minimize it, then you end up losing a pair of sides. This shows you that parallelograms have the least Mahler volume among centrally symmetric polygons.")

#text("I believe that this proof can work in 3 dimensions. There is a happy theorem that the moduli space of polyhedra in 3D with any fixed combinatorial type is homotopy equivalent to SO(3). (Of course you have to mark the polyehdron to eliminate any symmetries.) This theorem is still true in the centrally symmetric case, and it is (a small) part of the grand scheme of Thurston’s ideas. I conjecture that Mahler volume is “Morse trivial” on any such moduli space, and that with a suitable metric, the downward gradient flow must eliminate an opposite pair of edges of the polyhedron. As Terry says, the right argument would be fully GL(3,R)-invariant.")

#text("Unfortunately, the moduli space of a polytope type in higher dimensions can be anything. Or it may not be so unfortunate, if you believe that 3D is a special world that yields special arguments.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-68")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2007")])]

#text("Incidentally, the proof of Mahler’s conjecture in 2D seems to first appear in")

#text("K. Mahler, Ein Minimalproblem fur konvexe Polygone, Mathematica (Zutphen) B, 118-127 (1939);")

#text("it unfortunately predates MathSci (and certainly MathSciNet).")

#text("Several people have asked me now for the ability to preview comments. I hear that there is some way to change the wordpress settings to do so, but I was unable to locate one. If there are any wordpress experts out there who could help, I would greatly appreciate a tip :-) .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-69")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2007")])]

#text("Scott Aaronson uses WordPress and found a way to have instant preview.")

#text("To answer Danny’s question about gradient flows: Unless you choose a Riemannian metric on the space of convex bodies, the Mahler volume does not have a gradient, but rather a differential which is a 1-form. There are all too many choices for this metric; it is non-trivial to come up with one that doesn’t look like trash. As Terry noted, the Mahler business is GL(n,R)-invariant, so it already looks problematic if you make a metric on convex bodies by modelling them as polar functions on a round sphere.")

#text("I have looked for metrics of this sort not to minimize Mahler volume, but rather ")#mi("\\mathrm{Vol} K^\\diamond")#text(". Unlike Mahler volume, this volume is minimized for ellipsoids. Nonetheless, I never found a useful downhill flow. The inequality that I did find has an oscillatory factor that makes me wonder whether there is any reasonable flow-based proof of my result.")

#text("Well, you can make interesting uphill flows for Mahler volume using infinitesimal Steiner symmetrization. Such a flow is not unique and is at best O(n)-invariant, but I think that it still works. However, I don’t think that anything good happens if you try to reverse such a flow. It should be parabolic in the uphill direction (or parabolic-ish since it is non-local), so that the downhill flow would be pathological.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-70")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2007")])]

#text("Also, Dave Bacon uses WordPress and somehow has a preview button.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-71")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2007")])]

#text("Dear Bo’az,")

#text("I’m increasingly excited about the Fourier-analytic (or Laplace-analytic) approach to the problem, coupled perhaps with the idea of working in the asymptotically high dimensional regime to deal with ")#mi("(1+o(1))^n")#text(" losses.")

#text("If f is convex and t is large, then the Laplace transform of ")#mi("\\exp(-tf(x))")#text(" is essentially ")#mi("\\exp(-t L(f)(\\xi/t) )")#text(", ignoring lower order corrections. (The slogan here is that Legendre is the “zero-temperature” limit of Laplace; rather perversely, one can also say “tropical” instead of “zero-temperature”.) If I wave my hands and mumble either “Wick rotation” or “stationary phase”, then there is some sort of similar statement for the Fourier transform instead of the Laplace transform. In which case Bo’az’s formulation of Santalo’s inequality begins to look quite a lot like Beckner’s sharp Hausdorff-Young inequality in the limit as ")#mi("t \\to \\infty")#text(" and ")#mi("p \\to 1")#text(". This also fits with the ball being the extremiser, given that the Gaussian is the extremiser for Beckner’s inequality. It also fits well with the ")#mi("(2\\pi)^n")#text(" factor.")

#text("Now to get back to Mahler’s conjecture, we would need some reverse Hausdorff-Young inequality. This isn’t available in general, of course, but we have a lot of convexity and positivity to exploit. An obvious thing to do is now try to flow along the temperature parameter t. If one looks at, say ")#mi("t^{n} (\\int_{{\\Bbb R}^n} e^{-tf}) (\\int_{{\\Bbb R}^n} e^{-tL(f)})")#text(" and differentiates in t, one begins to get expressions which look like the entropy uncertainty principle, and it is quite likely that indeed one could get yet another proof of Santalo’s inequality from that principle. So now one needs some sort of reverse entropy uncertainty principle for Laplace transforms of log-concave functions… there is a hope that having differentiated along the temperature, one has “linearised” the problem enough that some new techniques (log Sobolev inequalities??) might come into play…")

#text("What is appealing about this whole approach is that everything is set up to be invariant under the three symmetries of the problem: linear transformations, polar duality, and Cartesian products.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-72")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2007")])]

#text("Despite having written three papers on the Mahler conjecture, I apparently never thought properly about the asymmetric case. I had thought that it was off from the symmetric case by a factorial factor.")

#text("Milman mentioned to me by e-mail that my inequality is false for asymmetric convex bodies. But I didn’t realize that it’s a close call. My lower bound is roughly ")#mi("(\\pi/4)^d")#text(" times the Mahler volume of a cube. As Boaz says, the Mahler volume of a simplex is roughly ")#mi("(e/4)^d")#text(" times that of a cube. So it’s a matter of replacing ")#mi("e")#text(" by ")#mi("\\pi")#text("!")

#text("I have to then agree that the Hanner polytope story could be taken as a red herring. There are some theorems in convex geometry where people can show that a simplex is the worst case. For example, Keith Ball has shown that a simplex has the worst isoperimetric constant among convex bodies, when each body is placed in its best affine position.")

#text("I just scrambled to check what my inequality implies for asymmetric convex bodies. I can’t think of any better idea than to convert from asymmetric to symmetric. Rogers and Shephard proved in 1957 that if ")#mi("K")#text(" is convex and ")#mi("K-K")#text(" is its difference body, then")

#mi("\\mathrm{Vol}(K-K) \\le \\binom{2d}{d} \\mathrm{Vol}(K),")

#text("with equality for simplices only. Using the difference body, we get that the asymmetric Mahler conjecture is true up to a factor of roughly ")#mi("(\\frac{\\pi}{4e})^d")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-73")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2007")])]

#text("Terry and Boaz are masters at combining approximate estimates, whereas my paper has just a single, elementary approximation followed by a geometric argument. The point of the approximation is what I call “table-turning” in the paper. Given a statistic ")#mi("f(K)")#text(" of convex bodies which is supposed to be maximized for ellipsoids and minimized for less nice shapes, maybe you can find another statistic ")#mi("g(K) \\le f(K)")#text(" that is minimized for ellipsoids instead, but nonetheless gives you a good lower bound for ")#mi("f(K)")#text(". Of course you can also reverse all of the inequalities in this approach.")

#text("Here then is another table-turning conjecture. Terry already mentioned the elementary relation")

#tao-math("K \\times K^\\circ \\subset \\{\\left|\\xi \\cdot x\\right| \\le 1\\},", block: false)

#text("which is important in my paper. In any fixed dimension, then, which ")#mi("K")#text(" maximizes the average value of ")#tao-math("\\left|\\xi \\cdot x\\right|^2", block: false)#text(" on ")#mi("K \\times K^\\circ")#text("? Several people have conjectured that it is the ellipsoid, at least in the symmetic case. So is there some nice flow or symmetrization that proves this? It would imply the well-known isoperimetric constant conjecture, moreover with a good value of the constant.")

#text("If the average value is too difficult, what about just the integral? I have the impression that you can prove that the ellipsoid maximizes the integral of ")#tao-math("\\left|\\xi \\cdot x\\right|^2", block: false)#text(" just by standard Steiner symmetrization. This would be a warm-up to the harder problem of maximizing the average value. (Maybe it is only a luke-warm-up. Even so, it would be a start.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-74")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2007")])]

#text("Ugh. My previous post was full of rather bad sign errors, and hence contains a large fraction of rubbish (particularly all the stuff involving Hausdorff-Young, and thence the entropy uncertainty principle). :-( I still feel there should be some sort of “detropicalised” version of the Mahler conjecture which involves the Laplace transform rather than Legendre, but I will have to think much more carefully to try to formulate it properly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-75")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2007")])]

#text("OK, I think I weeded out the sign errors. Given an exponentially decaying log-concave function ")#mi("F: {\\Bbb R}^n \\to {\\Bbb R}^+")#text(", define the Laplace transform ")#mi("{\\mathcal L} F: {\\Bbb R}^n \\to {\\Bbb R}^+")#text(" by")

#mi("{\\mathcal L} F(\\xi) := \\int_{{\\Bbb R}^n} f(x) e^{-x \\cdot \\xi}\\ dx.")

#text("Suppose we have the Hausdorff-Young like inequality")

#tao-math("\\left\\| {\\mathcal L} F \\right\\|_{L^{p^\\prime}({\\Bbb R}^n)} \\leq (e + o(1))^{-n/p} \\left\\| F \\right\\|_{L^p({\\Bbb R}^n)}", block: false)

#text("where ")#mi("0 < p < 1")#text(" (!), ")#mi("p^\\prime := p/(p-1)")#text(", and o(1) is a quantity depending only on n and p which goes to zero in the joint limit ")#mi("n \\to \\infty, p \\to 0")#text(".")

#text("Note that p is ")#emph[#text("less")]#text(" than 1, so the right-hand side norm is only a quasinorm, but what is weirder, p’ is ")#emph[#text("negative")]#text(", so the left-hand side norm is really a quasinorm of the reciprocal of the Laplace transform rather than the Laplace transform itself. (It kind of makes sense, since the Laplace transform of a non-negative exponentially decaying function is going to be exponentially growing, in general.) Such an inequality, if true, would have to heavily exploit the log-concavity of F. On the other hand, the inequality is consistent with affine symmetry and Cartesian products, and we shall soon see that it has the Mahler conjecture as its tropical limit, so it is not immediately false.")

#text("Anyway, if we have such an inequality, we can apply it to ")#mi("F(x) := e^{-f(x)/p}")#text(" for a convex f which grows superlinearly at infinity. Then the Laplace transform has the asymptotic ")#mi("{\\mathcal L} F(\\xi) = e^{(Lf(-\\xi/p) + o(1))/p}")#text(" and so a little bit of computation in the asymptotic limit ")#mi("p \\to 0")#text(" then gets")

#mi("\\int_{{\\Bbb R}^n} e^{-f} \\int_{{\\Bbb R}^n} e^{-Lf} \\geq (e + o(1))^n")

#text("and the o(1) term can then be eliminated by taking Cartesian products and passing to the asymptotic limit ")#mi("n \\to \\infty")#text(" (this step can be combined with the preceding asymptotic limit to create a joint limit). The requirement that f grow superlinearly at infinity can then be removed by the usual limiting argument.")

#text("I’m not entirely sure that the Hausdorff-Young formulation is better, now that I see the negative norms, but it certainly looks rather different.")

#text("p.s. Regarding one of Gil’s remarks, if one can get within an epsilon of the Mahler conjecture, then one automatically gets the conjecture itself by the “tensor power trick”. Indeed if one knew that")#linebreak()#text(" ")#mi("M(B) \\geq c_\\epsilon (1-\\epsilon)^n M(Q^n)")#text(" for any ")#mi("\\epsilon > 0")#text(", then by replacing B with the Cartesian product ")#mi("B^k")#text(" one easily sees that ")#mi("M(B)^k \\geq c_\\epsilon (1-\\epsilon)^{nk} M(Q^n)^k")#text(" for any k. Taking ")#mi("k^{th}")#text(" roots and then letting k go to infinity, and ")#emph[#text("then")]#text(" letting ")#mi("\\epsilon")#text(" go to zero, we obtain the Mahler conjecture.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-76")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2007")])]

#text("Terry: Since you are interested in detropicalizations, there is a published detropicalization of the Blaschke-Santalo inequality due to Lutwak and Zhang. Their paper is ")#link("http://nyjm.albany.edu:8000/jdg/archive/vol.47/1_1.ps")[#text("Blaschke-Santalo inequalities")]#text(".")

#text("On a substantially unrelated topic, if you are just generally a fan of p-norm inequalities, I have a quantum version of the pigeonhole principle which takes the form of a Holder inequality with complementary norms. It is Theorem 4.1 in ")#link("http://front.math.ucdavis.edu/quant-ph/0203105")[#text("quant-ph/0203105")]#text(". The form of the pigeonhole principle that I generalize says that if you write a symbol from an alphabet of size n in a shorthand alphabet of size k < n, then you cannot expect to decode it correctly with probability better than k/n.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-77")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2007")])]

#text("Also, another non-mathematical comment: The Bourgain-Milman theorem was once mentioned in the New York Times! A Gina Kolata article in 1994 on ")#link("http://select.nytimes.com/search/restricted/article?res=F30D10FF38550C778CDDA10894DC494D81")[#text("the Fields Medalists")]#text(" said the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Dr. Bourgain, who is 40, is known as “a powerful problem solver,” said Dr. Charles Fefferman of Princeton University. He said that Dr. Bourgain’s work was so sweeping that different mathematicians would choose different favorite results. But, Dr. Fefferman said, his own favorite is Dr. Bourgain’s solution to a thorny problem involving the geometry of infinite dimensional space.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The problem was to understand the volumes of convex objects, like a disk in ordinary two-dimensional space, in infinite dimensions. Mathematicians have found that every convex set of points has associated with it another set, which is called the polar set. Dr. Bourgain showed that if a convex set is small its polar set has to be big. Dr. Fefferman said that solution to this problem gave mathematicians insight into the geometry of infinite-dimensional spaces.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-80")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2007")])]

#text("Also, an emendation to my previous comment about the conversion from the asymmetric case to the symmetric case: What I said before is not optimized. Instead of the difference body ")#mi("K-K")#text(", you can use the symmetrized body ")#mi("D = (K-K)/2")#text(". The dual norm induced by ")#mi("D^\\circ")#text(" is then the average of the norms induced by ")#mi("K^\\circ")#text(" and ")#mi("-K^\\circ")#text(". So it is easy to see by concavity of the integrand that")

#mi("\\mathrm{Vol} D^\\circ \\le \\mathrm{Vol} K^\\circ.")

#text("Thus, using the Rogers-Shephard inequality, the simplex has the least Mahler volume among asymmetric convex bodies up to a factor of ")#mi("(\\pi/2e)^n")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-82")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2007")])]

#text("How small can Vol(K) (equivalently M(K)) be for a self-dual centrally symmetric convex body? Namely for a body K such that the polar of K equals to -K.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-84")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2007")])]

#text("Gil: Given two symmetric convex bodies ")#mi("A")#text(" and ")#mi("B")#text(", you can define the p-norm Cartesian product ")#mi("A \\times_p B")#text(". If ")#mi("A")#text(" and ")#mi("B")#text(" are dual, then ")#mi("A \\times_2 B")#text(" is isodual. This construction is the best that I can think for your question. To optimize the construction, you should to let ")#mi("A")#text(" (equivalently ")#mi("B")#text(") be a Hanner polytope.")

#text("I do not know how much this construction says about the full Mahler conjecture. However, it does mean that the Bourgain-Milman theorem for isodual symmetric convex bodies is equivalent to the theorem for all symmetric convex bodies. A similar consideration tells you that the Bourgain-Milman theorem implies the bottleneck conjecture for symmetric convex bodies up to an exponential factor. (Of course the converse implication motivated the botttleneck conjecture.) Happily the bottleneck conjecture turns out to be true with no fudge factor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-96")[#strong[#text("Gil")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2007")])]

#text("Well, we have here (HU; Jerusalem at our local IAS) a special semester (March-August) on Polytopes, complexes and connections to combinatorics and topology and we devoted the first seminar to a lecture by Semyon Alesker on Greg Kuperberg’s ingenious and mysterious proof. It was very nice!")

#text("Michael Larsen and Ayelet Lindenstrauss came to the lecture and to add to Greg’s nice personal account above, let me mention that Michael even remembered some of this stuff from the time when he and Greg studied in Harvard and worked on their junior thesis (it should be in plural thesise (?) thesa(?), whatever).")

#text("Semyon being the speaker inspired Imre Barany and me to ask about minimizing the product of other mixed volumes (say surface area). Here, in the plane the circle bits the square. Tom Braden and Victor Batyrev who will be speaking along with Sasha Zvonkin on Sunday, in the little workshop on toric varieties, polytope duality, and relation to Koszul duality and mirror symmetry, where also in the lecture.")

#text("So it looks that relations between metric/combinatoric/arithmetic and their combinations of convex bodies and their polars will still occupy us for a while. For the local combinatorialists like Ehud Friedgut and Irit Dinur this was the third combinatorics seminar of the week. And the CS theory seminar is yet to come tomorrow.")

#text("We had fierce competition from the little conference at the same time in the adjacent lecture hall on “sex, biology and game theory” ! followed by a lecture on “what is a language”. Tough!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-97")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2007")])]

#emph[#text("Michael Larsen and Ayelet Lindenstrauss came to the lecture and to add to Greg’s nice personal account above, let me mention that Michael even remembered some of this stuff from the time when he and Greg studied in Harvard and worked on their junior thesis (it should be in plural thesise (?) thesa(?), whatever).")]

#text("That has to be a little out of order, because Michael was a senior at Harvard when I was a freshman. He was in graduate school at Princeton when I started this work. But I probably did talk to him about it later; in the 1990s I cared about the problem a lot.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/743ec659e95a03c26d192883fa7bbe7647704868ea113c827a627daa82ded8e0-dbc98e08ce176ef4ec67b629e09f1f3d2786817a4f2ebdb07194ca7cd341d047.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-35275")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2009")])]

#text("While the conjecture that every centrally symmetric polytope has at least as many non empty faces as a Hanner polytope (")#mi("3^d")#text(") is still open, stronger conjectures that I made were disproved by Sanyal, Werner and Ziegler ")#link("http://front.math.ucdavis.edu/0708.3661")[#text("http://front.math.ucdavis.edu/0708.3661")]#text(" . The so called “Hansen polytopes derived from perfect graphs” discussed in the paper are of interest also in the context of Mahler’s conjecture.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-35305")[#strong[#text("Mathematics, Science, and Blogs « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2009")]

#text("[…] Michael’s post triggered Tim Gowers to present his thoughts about massive collaboration in mathematics, and this post is also very interesting with interesting follow-up remarks. Tim Gowers mentioned the n-category cafe as a place where a whole research programme is advanced on a blog. Terry Tao mentioned comments on posts on his open-problems series as having some value. He mentioned, in particular, the post on Mahler’s conjecture. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83d96e7c8c96d50373c16adc05ffdc481068318f19d01c35f33dbf86af20cc59-49eb4a9ab4a203065f352353af9896244ac4db2c7bdcf7e3cc5be30ab6ba8c3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fedja")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-35881")[#strong[#text("fedja")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2009")])]

#text("Returning to the original topic: to show that something like the cube is a local minimizer is actually not hard at all. The whole difficulty lies in the global minimization. The reason is, of course, that the conjectured minimizers are not smooth points of the functional but rather “corner points”, which allows one to get away with making rather rough estimates for the first differential. One should “factor out” the neighboring parallelepipeds, of course, to see this corner effect, but just taking the circumscribed parallelepiped of the least volume turns out to be good enough. If there is enough interest in the local minimum problem and somebody would like to see the details, we (I, Ryabogin, Zvavitch, and Petrov) will make a small preprint and put it on the archive; otherwise just take my word for it…")

#text("By now we have at least 3 old “elementary” geometric problems when the assumed extrema have been shown to be local ones but not global ones yet: Reinhardt’s problem about the symmetric convex plane domain with the lowest density of the densest lattice packing, Erdos’ lemniscate problem, and Mahler’s conjecture (all three being the corner extrema). It’s high time to finish off at least one of them…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/743ec659e95a03c26d192883fa7bbe7647704868ea113c827a627daa82ded8e0-dbc98e08ce176ef4ec67b629e09f1f3d2786817a4f2ebdb07194ca7cd341d047.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-36262")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2009")])]

#text("Here are links with statements of the problems fedja referred to:")

#text("Erdos lemniscate problem:")#linebreak()#text(" ")#link("http://en.wikipedia.org/wiki/Polynomial_lemniscate")[#text("http://en.wikipedia.org/wiki/Polynomial_lemniscate")]

#text("Reingardt’s problem")#linebreak()#text(" ")#link("http://www.springerlink.com/content/g21630q36l2w1082/fulltext.pdf?page=1")[#text("http://www.springerlink.com/content/g21630q36l2w1082/fulltext.pdf?page=1")]

#text("(Yes, if the local minimality argument is not written elswhere, it would be nice and of interest to have it on record.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83d96e7c8c96d50373c16adc05ffdc481068318f19d01c35f33dbf86af20cc59-49eb4a9ab4a203065f352353af9896244ac4db2c7bdcf7e3cc5be30ab6ba8c3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fedja")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-38589")[#strong[#text("fedja")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2009")])]

#text("OK. Here is the arXiv link: ")#link("http://arxiv.org/abs/0905.0867")[#text("http://arxiv.org/abs/0905.0867")]#text(". If you have trouble following the link, the authors are Nazarov, Petrov, Ryabogin, and Zvavitch and the title is “A remark on the Mahler conjecture: local minimality of the unit cube”. This should be enough to locate the paper using the arXiv search option.")

#text("I cannot guarantee it has never been written elsewhere though I’m pretty sure it has never been published in a refereed journal (MathSciNet search did not produce any result). On the other hand, given the simplicity of the proof, it is quite conceivable that many other people found the result earlier but just discarded it as too trivial to publish.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83d96e7c8c96d50373c16adc05ffdc481068318f19d01c35f33dbf86af20cc59-49eb4a9ab4a203065f352353af9896244ac4db2c7bdcf7e3cc5be30ab6ba8c3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fedja")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-38773")[#strong[#text("fedja")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2009")])]

#text("Somehow for the last week Mahler’s conjecture didn’t want to go out of my poor head. I thought of using some harmonic analysis/several complex variable tools but, unfortunately, the only thing I (or rather we, because I consulted my friends a lot during this attempt) could do was yet another proof of the Bourgain-Milman theorem with constant ")#mi("\\left(\\frac\\pi 4\\right)^3")#text(" for the symmetric case, which is 3 times worse (on the logarithmic scale) than Kuperberg’s estimate (though our constant for the non-symmetric case may be slightly better than what he posted above; I need to check the computation to tell for sure). The proof is rather “high-tech” because it relies on the Hormander theorem on the existence of solutions of the d-bar problem with good ")#mi("L^2")#text("-estimates. Like Kuperberg, we found the exact minimum of some other quantity that equals to the Mahler product volume up to an exponential factor. Unlike him, we have a quantity that is minimized by the cube, not by the ball…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-38783")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2009")])]

#text("I’m impressed! Of course it’s a new result, even if the application to the Bourgain-Milman theorem is slightly below the best current bound.")

#text("Can you also solve the variance conjecture, say up to a constant? That is, the conjecture that I posted in the comment on 9 March, 2007 at 7:58 pm. Maybe I understated the significance of that conjecture. The variance conjecture plus the Bourgain-Milman theorem imply the isotropic constant conjecture, which is equivalent to the slice conjecture. The isotropic constant conjecture implies Milman’s M-ellipsoid theorem, because it would mean that the Legendre ellipsoid is an M-ellipsoid. The M-ellipsoid theorem implies Milman’s subquotient theorem.")

#text("So if you found a short proof of the variance conjecture, or the conjecture up to a good constant, it would imply a nest of important conjectures and theorems in asymptotic geometry, with good constants.")

#text("I have a paper that I have been meaning to write up on the variance conjecture. I can show that an ellipsoid is a local minimum in the centrally symmetric case. This is not an earth-shaking result, but it seems good enough to me for a publication. The same calculation shows that the ellipsoid is *not* a local minimum with respect to asymmetric perturbations; the only culprit is harmonic perturbations of degree 3.")

#text("Meanwhile David Alonso-Gutierrez, in arXiv:0710.5907, shows the following: If A and B are two fixed centrally symmetric convex bodies, then the variance constant for the p-norm product body A x_p B is largest when p=2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-38784")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2009")])]

#text("By the way, Fedja, some years ago I also thought about Reinhardt’s problem. First of all, there is a remarkable theorem (Fejes Toth) that the densest packing of a 0-symmetric convex body K in the plane is a lattice packing, and that you make the lattice packing by looking at the smallest centrally symmetric hexagon that contains K. Suppose that the smallest such hexagon has unit area and suppose that K has the least area among all such bodies. Then every point on the boundary of K is a kissing point of some circumscribing centrally symmetric hexagon with area 1. These remarks about K are due to Tammela, and I believe led to the conjecture for the best K, a certain rounded octagon.")

#text("Now the set of centered ellipses in the plane with unit area is isomorphic (as a homogeneous space) to the hyperbolic plane. The set of these hexagons is then a certain circle bundle over the hyperbolic plane, one which is the sixth power of the tautological circle bundle given by the ellipses. So a Tammela body K, i.e. one which is circumscribed by a circle of symmetric hexagons with the same area, defines a certain loop in the hyperbolic plane, and the loop lifts to this circle bundle over it. If I remember correctly, I checked that the area encircled by this loop determines the area of K. Tammela’s candidate for K is morally a square. I do not know whether it is a geometric square, or whether there is some other condition to define curved “sides”. (By analogy, a Rouleaux “triangle” is not really a triangle. I am not sure whether this shape is a hyperbolic square or merely a “square”. I should check.) It seems very possible that there is a variational argument for all such shapes in the hyperbolic plane to reduce the number of sides to 4.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83d96e7c8c96d50373c16adc05ffdc481068318f19d01c35f33dbf86af20cc59-49eb4a9ab4a203065f352353af9896244ac4db2c7bdcf7e3cc5be30ab6ba8c3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fedja")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-38790")[#strong[#text("fedja")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2009")])]

#text("Thanks, Greg! The variance conjecture seems very interesting, indeed, but you need to be much more careful with it than with the Bourgain-Milman theorem. So, at this point I have no really good idea of how to approach something like that. Here is one more question I thought of recently (without much success so far) that is somewhat related to this circle of problems. Suppose ")#mi("K\\subset\\mathbb R^d")#text(" is origin-symmetric and you have two sets ")#mi("X\\subset K")#text(" and ")#mi("Y\\subset K^*")#text(" such that ")#tao-math("\\left|\\langle x,y\\rangle\\right|\\le r<1", block: false)#text(" for all ")#mi("x\\in X, y\\in Y")#text(". Can we conclude that ")#mi("V(X)V(Y)\\le c(r)^d V(K)V(K^*)")#text(" with some ")#mi("c(r)<1")#text("? If we can, what is the best possible value of ")#mi("c(r)")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-38803")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2009")])]

#text("fedya: I suspect for your question that you wanted something good to happen for every ")#mi("r  \\sqrt{2/3}")#text(".")

#text("On the other hand, if ")#mi("b")#text(" is the best Bourgain-Milman constant (in their normalization, relative to a round ball), you obtain ")#mi("c(r) < r/b")#text(", so that ")#mi("c(r)")#text(" is bounded away from 1 when ")#mi("r < b")#text(".")

#text("I had some misattributions in my comments about Reinhardt’s problem. The result that there is a critical hexagon touching every point on the boundary of this convex body C is actually due to Mahler, not Tammela. You obtain a “Mahler curve” in the hyperbolic plane. I think that this curve does not have to be convex or even embedded, rather it satisfies the weaker condition that it cannot bend more than a horocycle bends. I did once calculate that the area enclosed by this curve determines the area of C, but this should be rechecked.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-38806")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2009")])]

#text("Sigh, my comment got chopped because I had an inequality in an equation, which interfered with the HTML.")

#text("fedya: I suspect for your question that you want ")#mi("c(r) < 1")#text(" for every ")#mi("r < 1")#text(". But I think that I have a counterexample when ")#mi("r > \\sqrt{2/3}")#text(". Namely, let ")#mi("K")#text(" be a cube, so that ")#mi("K^*")#text(" is a cross-polytope. Then the typical point in ")#mi("K")#text(" is at distance roughly ")#mi("\\sqrt{d/3}")#text(", while the typical point in ")#mi("K^*")#text(" is at distance roughly ")#mi("\\sqrt{2/d}")#text(". So let ")#mi("X")#text(" be the intersection of ")#mi("K")#text(" with a round ball of radius more than the radius of a typical point, and the same for ")#mi("K^*")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83d96e7c8c96d50373c16adc05ffdc481068318f19d01c35f33dbf86af20cc59-49eb4a9ab4a203065f352353af9896244ac4db2c7bdcf7e3cc5be30ab6ba8c3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fedja")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-38807")[#strong[#text("fedja")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2009")])]

#text("Yes, you’re right! OK, this means that I’ll have to do something else if I want to improve the constant in our approach. The main loss there comes from replacing the Legendre transform of the characteristic function of a convex body with its Laplace transform, so it would be interesting to try to compare the two directly. Anyway, all these words of mine probably sound like I’m speaking gibberish now. This will certainly change after you see the details, so let me write the proof down and show it to you before making any further comments…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-38808")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2009")])]

#text("A remark concerning Laplace and Legendre transforms: There is a generalization of duality of convex bodies to duality of log-concave functions, as Boaz Klartag mentions above. Two log-concave functions are dual if their logarithms are Legendre transforms of each other.")

#text("A 0-symmetric convex body ")#mi("K")#text(" has a 1-parameter family of interpretations as a log-concave function. Namely, if ")#tao-math("\\left|\\left|x\\right|\\right|_K", block: false)#text(" is the norm corresponding to ")#mi("K")#text(", one can let ")#tao-math("f(x) = \\exp(-\\left|\\left|x\\right|\\right|_K^p)", block: false)#text(" for any ")#mi("1 \\le p \\le \\infty")#text(". Then the dual function is the same expression for ")#mi("K^*")#text(", except with ")#mi("p")#text(" replaced by its reciprocal complement ")#mi("q")#text(". If Legendre or Laplace transforms are useful to you, you may obtain better results (or at least a clearer explanation) if you first convert ")#mi("K")#text(" to a log-concave function, and more specifically if you take ")#mi("p = q = 2")#text(" in order to make the conversion self-dual.")

#text("It seems interesting that the statement of the 0-symmetric Mahler conjecture simplifies in the setting of log-concave measures. Namely, it says that if ")#mi("f")#text(" and ")#mi("f^*")#text(" are dual log-concave functions, then the product of their integrals is at least ")#mi("4^n")#text(". Likewise the log-concave Santalo inequality says that the product is at most ")#mi("(2\\pi)^n")#text(". These statements are equivalent to the usual versions for convex bodies. Also, the log-concave analogue of an ellipsoid is a Gaussian. It seems interesting that their logarithms form a linear subspace in the cone of all concave functions. However, I haven’t seen a way to make good use of these simplifications.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-38838")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2009")])]

#text("A comment on some of the terminology above, which had me confused for a while. Greg refers to the problem of maximizing the variance of the random variable ")#mi("x \\cdot \\xi")#text(", where ")#mi("x")#text(" is uniform in ")#mi("K")#text(" and ")#mi("\\xi")#text(" is uniform in ")#mi("K^\\circ")#text(", as the “variance conjecture”.")

#text("On the other hand, it has recently become common to refer to the problem of maximizing the variance of ")#tao-math("\\left|x\\right|^2", block: false)#text(" (with appropriate normalization on ")#mi("K")#text(") as the “variance hypothesis” in convex geometry (see e.g. Conjecture 1 ")#link("http://www.cc.gatech.edu/~lrademac/dispersion.pdf")[#text("here")]#text(". There is no direct relationship between these two problems that I see, but they do belong to the same broad circle of ideas.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-38841")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2009")])]

#text("Mark: Good point.")

#text("There seems to be a proliferation of variances associated to random points in convex bodies, and conjectures bounding them. They certainly can’t all be called “the variance conjecture” or “the variance hypothesis”. Maybe none of them should have that name. However, the conjecture that you cite appeared in Giannpoulos’ notes in 2003, so you could certainly then argue that the name is taken.")

#text("Besides, the conjecture that I am promoting (which was already implicit in Keith Ball’s work), if interpreted up to a constant factor, is simply equivalent to the isotropic constant conjecture and the slice conjecture. So maybe a better name is “self-dual and round form of the isotropic constant conjecture”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-38847")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2009")])]

#text("Greg: Given the vagueness of “variance hypothesis” and “variance conjecture”, it would probably be best not to use either name for any of these conjectures. But I think the name is already stuck for the conjecture I mentioned.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2664ae10bb0a03c23841ce5ac8679264ff448a88cc3713e1b1db7a1c3f32e853-c61352870039b50027c965cb8c841177676fabfba93cae916fc8cc29215b69bb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of NathanaelNerode")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-39904")[#strong[#text("NathanaelNerode")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2009")])]

#text("“I am fond of it because it attempts to capture the intuitively obvious fact that cubes and octahedra are the “pointiest” possible symmetric convex bodies one can create.”")

#text("This seems to me to require deeply unintuitive definitions of either “pointiness” or “symmetric”. After all, a regular tetrahedron is very pointy (occupying a smaller percentage of its bounding sphere than a cube) and very symmetric (many non-identity rigid transformations which map it to itself). Using an alternate definition of pointiness, having the “most points”, the icosahedron is pointier than the cube… so this conjecture, interesting though it is, fails to capture anything intuitive at all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-39912")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2009")])]

#text("“Deeply unintuitive” is a little harsh, isn’t it? “Symmetric” here means “fixed by negation” (although I agree that this isn’t obvious if you aren’t used to this meaning of the word – it’s an overloaded word), which a regular tetrahedron isn’t. Your first implicit definition of pointiness works fine.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-40015")[#strong[#text("Vitali Fest « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2009")]

#text("[…] while floating near Semyon Alesker in the Dead Sea we saw a large cluster of experts on the Mahler conjecture- Shlomo Reisner, Dimitry Ryabogin and Artem Zvaivichand — and we decided to swim towards […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-49716")[#strong[#text("507- Problem list (III) « Teaching blog")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2011")]

#text("[…] Mahler’s conjecture. Possibly related posts: (automatically generated)507 – Problem list (II)Lists Part (III)Future Let’s Plays List…Who’s The Coach? Part DEUX 43.614000 -116.202000 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/comment-page-1/#comment-164072")[#strong[#text("507- Problem list (III) « A kind of library")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2012")]

#text("[…] Mahler’s conjecture on convex bodies. […]")
]
