// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/
// Converted to Typst by tao2typ: "2026-10-14T16:39:25.904615+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Palomar – a registry of Lean verified mathematics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Palomar – a registry of Lean verified mathematics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 August 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/")[#text("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In recent months there has been a proliferation of AI-generated proofs of various old and new results, some of which have been formalized in the proof assistant language Lean. However, checking that a given Lean repository actually proves the claimed statement is somewhat non-trivial, especially for an audience which is not expert in the use of Lean: one has to first check that the claimed formal Lean statements have proofs that typecheck, that the proofs do not contain any “cheats” such as adding additional axioms, and that the formal statements also match (in a semantic sense) the informal description of the claimed results.")

#text("To help bring some clarity to this situation, I am happy to announce that ")#link("https://palomar-registry.org/")[#text("Palomar registry of Lean verified mathematics")]#text(", which is an initiative incubated by the ")#link("https://lean-lang.org/fro/")[#text("Lean FRO")]#text(" and by ")#link("https://icarm.io/")[#text("ICARM")]#text(", is now open for submissions. I am serving in several roles on this registry, including on the scientific advisory board, together with ")#link("https://www.andrew.cmu.edu/user/avigad/")[#text("Jeremy Avigad")]#text(", ")#link("https://www.matthewrobertballard.com/")[#text("Matthew Ballard")]#text(", ")#link("https://jaume.dedios.cat/")[#text("Jaume de Dios")]#text(", ")#link("https://www.ndguillen.com/")[#text("Nestor Guillen")]#text(", ")#link("https://en.wikipedia.org/wiki/Bryna_Kra")[#text("Bryna Kra")]#text(", ")#link("https://tqft.net/")[#text("Kim Morrison")]#text(", ")#link("https://math.stanford.edu/~vakil/")[#text("Ravi Vakil")]#text(", and ")#link("https://www.math.ias.edu/~akshay/")[#text("Akshay Venkatesh")]#text(".")

#text("A detailed motivation for Palomar can be found ")#link("https://palomar-registry.org/statement")[#text("here")]#text(", and further information about Palomar can be found ")#link("https://palomar-registry.org/about")[#text("here")]#text(". A zeroth approximation of what Palomar intends to be is the analogue of a preprint server for Lean proofs. More precisely, Palomar (which is named after the ")#link("https://sites.astro.caltech.edu/palomar/homepage.html")[#text("astronomical observatory")]#text(") is a registry of external Github repositories (or more precisely, “snapshots” of such repositories, as represented by a specific Github commit) containing Lean code adhering to the current best practices for such formalizations, in particular containing")

#list(
[#text("A “challenge file” containing a short, human readable description in Lean of the results claimed.")],
[#text("A “solution module” containing an (arbitrarily long) proof of the results claimed in the challenge file.")],
[#text("A “")#link("https://github.com/mathlib-initiative/formalization.yaml")[#text("formalization.yaml")]#text("” file describing the results in informal language, and also containing a number of other relevant metadata and disclosures.")]
)

#text("(There are also some additional technical requirements for the repository which I will omit here.) If a snapshot of a repository is submitted to Palomar, it will check both (a) that the solution module typechecks and proves exactly the results claimed in the challenge file, and that (b) the informal description of the result in the formalization.yaml file appears to match the result claimed in the challenge file, and that the repository meets various minimal standards required for a registry entry. The first check (a) is purely mechanical, using the Lean tool ")#link("https://github.com/leanprover/comparator")[#text("Comparator")]#text("; the second check (b) is non-deterministic, being performed by a large language model. If a repository passes both checks, it can be registered on Palomar. It is worth stressing that the checks in (a) and (b) fall well short of what a proper human peer review of a submission for novelty, interest, and accuracy would give; in particular, Palomar is ")#strong[#text("not")]#text(" a peer-reviewed journal.")

#text("The submission process is thorough, but achievable: as a test, I ")#link("https://palomar-registry.org/entry?id=PALOMAR-2026-08-13-000001&version=1")[#text("successfully managed")]#text(" to submit my own ")#link("https://github.com/teorth/sendov")[#text("recent formalization of the proof of Sendov’s conjecture")]#text(" to Palomar, and also plan to submit some older formalizations to the registry soon.")

#text("In any event, the registry is now open for formalizations of both old and new results. Submissions (whether human-generated, AI-generated, or some mixture of both) are welcome; please read the (somewhat detailed) instructions ")#link("https://palomar-registry.org/how-to-submit")[#text("here")]#text(" before starting a submission. (I will however note that modern AI agents are quite helpful in assisting with the mechanical details of the submission, though a human review is still strongly recommended.)")

#text("Discussion and feedback on Palomar will occur on ")#link("https://leanprover.zulipchat.com/#narrow/channel/621638-Palomar")[#text("this Zulip channel")]#text(".")

#heading(level: 1)[#text("Comments (47)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-693973")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2026")])]

#text("cool")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-693974")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2026")])]

#text("> the second check (b) is non-deterministic, being performed by a large language model")

#text("Shouldn’t this be just preliminary? I think submissions should have an additional, human-performed level of verification.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-693983")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("As stated above, Palomar does not perform human review of repositories, which will not scale to the volume of repositories we envisage processing. (This is similar to the arXiv, which performs minimal checks of acceptability for the preprints it accepts, but also does not perform human review.) However, we would be fine with a third-party service performing additional review on top of the minimal checks that Palomar performs.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cb24f7663e0a2ba8650a94e831b6fca1d8e1ca4fa972ef7c3dd588998ddefbb-1375764a6794b51625caeb74aba106e20bdde210561fc5cfd0b340f00099c1d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tanay Wakhare")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694227")[#strong[#text("Tanay Wakhare")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2026")])]

#text("The main issue here is the relatively small number of people with experience reading/writing good quality Lean. There’s less than 1000 core contributors to mathlib, and it’s not common in industry. LLMs can catch some of the misformalization errors, with the caveat that they often still miss errors.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-693978")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("As GitHub is becoming less reliable every year, have you considered alternate git forges or hosting the repositories yourself instead of relying on external companies to keep their services available in the future?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-693985")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("We do not have the resources to host and maintain repositories directly, but would be open to expanding the whitelist of approved repository hosting services beyond Github if there is sufficient demand for doing so.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b4f5d99aac7261cf146c2fcfb9ee07e0df920243e6d9e27792b42b42b3834b74-3fffaeab9d64d163a1127d51be5f95f65af3c1e654dded4e00556a857488fbd8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bevan")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-693980")[#strong[#text("David Bevan")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("A very quick look at Palomar suggests that it would be much more helpful if each submission required (a) a meaningful Title, and (b) a (well-written) Abstract explaining what is proved — just as one sees in arXiv. At present, the titles and descriptions do not enable me to understand what many of the submissions achieve.")

#text("To be honest, I’m rather shocked that this went live without a requirement of this sort. (Who is the main interface actually supposed to be for if it’s impossible to work out what entries are about?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694007")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("I’ll pass this suggestion on to the maintainers. Currently we rely on the `project.name` and `project.description` fields of the repository `formalization.yaml` to provide the informal description of the project, although this does not perfectly map on to the title and abstract of a preprint because the claims being registered may only form a subset of the content of the repository, rather than represent the full repository project itself. So there may be a need to add separate title and abstract fields, but this will need some discussion to implement properly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694035")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2026")])]

#text("This is not related to your project, but I have been considering implementing a standard that would formalize a bit this kind of process, pinning a claim to a computation. See claimpins.org.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-693981")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("Such a good idea! Do you think that there is a chance of integration with Androma? If so, please get in touch with ")#link("mailto:viktor@androma.org")[#text("viktor@androma.org")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21015fe9e7b0cbbdef87896fddebe244ae88b6d3652bf88ebaab810f3677a96e-6e3f0917dbc784e80ef2d7047d17b942a7ac6142e8e60860577f3950cd2ce7c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ygtisik")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694010")[#strong[#text("ygtisik")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("nice idea overall for setting a level. I work on ")#link("http://whataifound.org")[#text("whataifound.org ")]#text("to maintain a documented registry of AI usage and contributions in math and science. Palomar will definitely be something we integrate for data checks and validation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694014")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("Is there consideration of requiring or at least marking submissions that include a human readable explanation of the proof(which can be higher level than a normal paper since the proof is formalized alongside it). I’m concerned that the machinery behind them will become much less accessible for reuse.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694017")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("This registry is not designed to assess informal proofs (see item 3 of ")#link("https://palomar-registry.org/about#what-palomar-is-not")[#text("https://palomar-registry.org/about#what-palomar-is-not")]#text("). However, we have no objection to having third-party services that build upon the registry to perform assessments of this type.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb27f379fdc576c1dab62a8d3e0be2588f736ebff635634a8c4f33fba4cddcf-b66495a3b2483b5f82096cfbac6e41287d131accac08e88190032a808eb63ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Warren Ericson")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694020")[#strong[#text("Lars Warren Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("How would you handle ")#link("https://github.com/catskillsresearch/scott1972")[#text("this repo")]#text(" with ")#link("https://arxiv.org/pdf/2606.30782")[#text("this arXiv writeup")]#text(" and this ")#link("https://github.com/catskillsresearch/scott1972/tree/main/Scott1972/ContinuousLattice")[#text("Lean proof code directory")]#text(". It formalizes an ")#link("https://github.com/catskillsresearch/scott1972/blob/main/sources/ScottContinLatt1972.pdf")[#text("entire paper")]#text(" which has multiple definitions and theorems. In general how would you approach Lean formalizations of whole papers, especially very long ones with hundred of results?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694022")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("We have a hard cap of 1000 lines (and 100KB) on the size of the challenge Lean file, which we very much want to keep human-readable (and AI-reviewable). (We in fact have a preference for challenge files that are significantly shorter than this hard cap, e.g., 300 lines.) For a large repository with multiple theorems which cannot all be stated in Lean within this cap, this would mean that multiple registry entries would be required to register separate statements for each major results.")

#text("If the results require extensive definitions to import that are not currently in Mathlib and whose constructions are too large to fit within the cap, then another option is to set up the required definitions in a ")#link("https://taucetiproject.github.io/TauCeti/")[#text("Tau Ceti repository")]#text(", which can then be imported as a dependency for the challenge file.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb27f379fdc576c1dab62a8d3e0be2588f736ebff635634a8c4f33fba4cddcf-b66495a3b2483b5f82096cfbac6e41287d131accac08e88190032a808eb63ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Warren Ericson")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694064")[#strong[#text("Lars Warren Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2026")])]

#text("Regarding Tau Ceti, the workflow there seems to be: (a) propose a topic, (b) get it approved and allocated to you, (c) input an AI workload to formalize, (d) AI formalizes the work hands-free, (e) it gets saved publicly if that works. That is quite different from storing the work already done for a difficult formalization. Lean Pool, as an option, saves submitted Lean code. It does not save documentation or articles written about the code. It only indirectly points back to the original repo, through GitHub cloning links. It actively golfs the code, which can eliminate comments and original proof structure in favor of more opaque tactics like “simp all”, which can erase or restructure the originally written proof from the source article. So: neither TauCeti nor Lean Pool is an option for building on authored repos with Lean formalizations. The only option for Palomar is to vendor all dependent repos into the submission. Please correct me if I’m wrong about this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vasily Ilin")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694449")[#strong[#text("Vasily Ilin")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("I am the maintainer of Lean Pool. Do you have any suggestions for how to make it better or more useful?")

#text("-Vasily Ilin")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64bfb95f8ea7c3cd7fbd87d25a6c20483295e63847dc39317ab0d8dc8a1364e2-cb51cd96e53b6b52b1e81659b822d372cd05a7aac3ae567cc041ae345895bc60.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694021")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("Do you think it is acceptable to register important results on Palomar before a preprint is submitted (while the writing is still in progress)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694024")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("I have (reluctantly) come to the conclusion that authorship of the different stages of a proof development cycle – generation, verification, exposition, publication, and canonicalization – will become increasingly decoupled, that an author may be responsible for one part of this cycle but not be involved in another. In particular, much as we already normalize the submission of a preprint to a server such as the arXiv before formal publication, or the publication of a paper before the definitive textbook containing the result is written, we will increasingly have to also permit the registration of formal proofs before a preprint written to professional standards is available. I do not view this decoupling of authorship as ideal – there are advantages to having a single group of authors be responsible for a proof throughout its development, much as there are advantages to having a single group of parents raise a child from conception to adulthood – but non-traditional authorship arrangements may be manageable as long as the incentives are such that the separate groups of authors can each be recognized for their particular contributions to the proof development cycle. (In particular, we may need a more explicit process to “hand off” the responsibility of authorship from one group to another in such cases.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694025")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("How likely is it that AI can start reading through textbooks and autoformalizing results by following the arguments line by line (possibly up to issues with canonicalizing with the current Lean library)? For example Stacks Project.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694027")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("There has been a very significant improvement in autoformalization capabilities in the last six months alone, at least if one focuses on the narrow goal of *only* certifying that a formal proof exists. I expect that (at least in some subfields of mathematics) a large fraction of textbooks and papers will soon be technically autoformalizable in that they can produce formalized versions of the statements of the main results of such texts, and provide typechecked proofs, though the proofs may not literally follow the informal proof “line by line” and may be inefficient, not human-readable, or otherwise not completely satisfactory in terms of code quality.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694026")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("Terry, this is a very nice project!")

#text("I run a site called ")#link("https://theoremdb.org")[#text("TheoremDB")]#text(", which approaches some of the same questions from a different angle and may be of interest to you. I think there is a large engineering design space here that is worth exploring, so seeing how another site approaches the problem may yield some useful ideas for Palomar.")

#text("Some specific differences:")

#text("TheoremDB gives a theorem an identifier independent of any particular repository or Lean declaration, so several proofs, formalizations, computations, and failed attempts can be collected under the same statement. This separates “has this artifact been checked?” from “what is already known about this theorem?”")

#text("I am especially interested in what this permits for “negative traces.” Human mathematical literature preserves only a small fraction of this material. With machine mathematics, such traces can be produced as a routine by-product of search, stored systematically, and returned to the next agent before it repeats the same work. This gives us reusable research memory at a scale that was previously impractical. Here is an ")#link("https://theoremdb.org/statements/fib-problem-determinant-range/#lean-verification")[#text("example packet")]#text("; the underlying artifacts are in the Work tab.")

#text("TheoremDB exposes its agent workflow through MCP. Palomar organizes submission around a GitHub repository, so this gives agents a somewhat different way into the system. An agent can fetch the exact statement and previous work, check a private Lean draft, submit the exact source that passed, and later check its verification status. A Palomar MCP could plausibly expose its existing preflight and submission process in the same way. I also created a ")#link("https://theoremdb.org/agents/")[#text("custom GPT")]#text(" as a ready-made client, making it easier to create entries with very little setup.")

#text("One further difference is repeated private checking before submission. Palomar already uses GitHub Actions for public verification. TheoremDB also keeps Lean environments ready for private draft checks, which makes iteration considerably faster. If Palomar eventually wanted this kind of draft lane, it could sit before the current public verification process.")

#text("Anyway, I think Palomar is a wonderful and rigorous initiative. There is a large engineering design space here, and I think it will be valuable to see several approaches explored.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694028")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("“The submission process is thorough, but achievable:”")

#text("This is AI.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694029")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("Sorry to disappoint any AI detectives, but the text here was human-generated. (The use of a “but” after a comma (or the ")#link("https://en.wikipedia.org/wiki/Antithesis#Rhetorical_antithesis")[#text("rhetorical device of antithesis")]#text(" in general) predates the advent of AI by several millennia, although AI models likely have trained extensively on that particular rhetorical pattern in the literature, most infamously in the “Not X, but Y” construction. But this does not justify ")#link("https://en.wikipedia.org/wiki/Affirming_the_consequent")[#text("affirming the consequent")]#text(".)")

#text("As a side note, integrating AI workflows into WordPress directly currently requires more authorization of my AI agents over my computer than I am currently willing to grant, and I don’t see a major efficiency gain in delegating the writing of short blog posts like this to AI to be worth the various costs. I have managed however to use AI to improve Luca Trevisan’s old LaTeX to WordPress HTML converter Python script, which I now use for lengthier blog posts (for instance, my version of the script now handles images, which I previously had to input by hand); and it has also created a tool to semi-automatically repair mangled text in comments arising from the quirks in WordPress’s hybrid LaTeX/HTML parser.")

#emph[#text("(All uses of rhetorical antithesis in this comment were also human-generated.)")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e67157ea741e1ba3c0da464df698fd36a9d8d41fb070d2bd547360244c568b42-18fd1c8a937d728522b0ab67e5edbed8be7757c3c1a8770fd6894c88d7537245.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vinicius Rodrigues")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694030")[#strong[#text("Vinicius Rodrigues")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2026")])]

#text("Interesting project!")

#text("Last week we sucessfully used GPT-5.6 Sol to solve Wallace’s question, a 73 year old problem on the structure of topological groups and semigroups. We also produced a formal proof. This morning I submitted it to Palomar to try it out, and it was accepted in less than a hour. It will be interesting to see how the project evolves!")

#text("Cheers!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694036")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2026")])]

#text("Is a one theorem to many formalizations, or perhaps simpler to manage one formalized theorem to many formalized proofs supported?")

#text("At some point, with a large enough database, it would be interesting to use the formalized proofs to study measures of quality. Some fuzzy and hard to define, like elegance, some more objective, like containing lemmas that are used in many other proofs. Perhaps the comparative study could detect lemmas, or proof patterns, which applicability has been overlooked.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694039")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2026")])]

#text("Palomar is organized around individual theorems that have a designated proof, although the proof itself is only checked to establish a type-identical statement to the claimed theorem, and no further analysis of the proof is provided. So a theorem with N different formal proofs would give more or less identical Palomar registry items. But I certainly agree that other qualities of formal proofs should be studied systematically; this is out of scope of this particular registry though.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb27f379fdc576c1dab62a8d3e0be2588f736ebff635634a8c4f33fba4cddcf-b66495a3b2483b5f82096cfbac6e41287d131accac08e88190032a808eb63ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Warren Ericson")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694037")[#strong[#text("Lars Warren Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2026")])]

#text("If a submission requires revision, e.g. for a metadata update, is the right workflow to push “Abandon this submission” for the prior submit after revising? The workflow available for revising a submission is for registered and accepted submissions, not new ones.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694040")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2026")])]

#text("Starting a new submission for the same repository automatically closes any previous open submissions, so it is not necessary to explicitly abandon the previous submission. (We don’t yet have a separate mechanism for updates that only change metadata, so unfortunately any such change will need to rerun comparator etc.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb27f379fdc576c1dab62a8d3e0be2588f736ebff635634a8c4f33fba4cddcf-b66495a3b2483b5f82096cfbac6e41287d131accac08e88190032a808eb63ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Warren Ericson")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694043")[#strong[#text("Lars Warren Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2026")])]

#text("Today I registered bridge theorems between 3 presentations of Scott domain theory (lattices, information systems and neighborhoods). It took 3 tries. First it asked me to revise the bridge theorems. Then it said everything was OK but my metadata. I initially had one repo for 1972, 1980/81 and 1982 papers and then I split it into 3 because of complexity and then I wrote a 4th with the bridge theorems. The first 3 repos were formalisations and the bridge theorems I have not seen elsewhere. Formalization and novel get different keywords. I had to describe this provenance exactly right in the metadata. Then I submitted again and the reviewer engine failed to complete 2 times before succeeding. Finally I got the Register button. Which is awesome! But history of why each submit got changed is buried in the final inducted repo, which is OK but not as easy to track in your system if you want to look back and see for example what are the most common causes are of resubmit. Also, versus an earlier comment, getting the bridge theorems accepted is in a way a hack that gets the underlying formalizations into the system. All told around 90,000 lines of Lean code. But the bridge theorems under 400!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694048")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2026")])]

#text("This project makes me realize that at some point in the coming crisis, all our papers and books will probably get autoformalized. It would be not great if it happens in a complete chaos. I am not super happy with the idea of having anyone (or several people) autoformalizing my papers and their machines possibly finding mistakes. Ideally I would prefer having a colleague trying to understand it and possibly pointing mistakes (but let’s be realistic: my existing papers get seriously read by maybe 2-3 people so far, and it will not get better with the flood, though I have had the chance to have some serious referees on a few past occasions). So it’s not inconceivable to put them here (if co-authors agree), knowing that it’s at least managed by the community. Let me specify that I am not at all an AI-enthusiast, much to the contrary, neither a supporter of autoformalization, and I am not willing to contribute myself in the coming flood by using LLMs.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694120")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2026")])]

#text("A rigorous verifiable Theorem in a strict Kernel built by LLM is still better than the text generated by the LLM for the journal. I am neutral and I believe what is important is guardrails.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb27f379fdc576c1dab62a8d3e0be2588f736ebff635634a8c4f33fba4cddcf-b66495a3b2483b5f82096cfbac6e41287d131accac08e88190032a808eb63ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Warren Ericson")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694052")[#strong[#text("Lars Warren Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2026")])]

#text("The Palomar registration function is broken. I have a validated submission that is stuck waiting for operator attention since 2026-08-20T18:44:33Z. I put a note on the Zulip Palomar channel: ")#link("https://leanprover.zulipchat.com/#narrow/channel/621638-Palomar/topic/Registration.20queue.20jammed/near/617968602")[#text("#Palomar > Registration queue jammed @ 💬")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb27f379fdc576c1dab62a8d3e0be2588f736ebff635634a8c4f33fba4cddcf-b66495a3b2483b5f82096cfbac6e41287d131accac08e88190032a808eb63ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Warren Ericson")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694063")[#strong[#text("Lars Warren Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2026")])]

#text("If a new theorem to be registered depends on a previously registered theorem, and it is in a different github repo from the first one, what is the correct pattern to build on a previously registered result? Should it involve placing both in TauCeti? Or can one claim build on the Palomar copy of the first repo? It would be very helpful to provide a formal guideline for the approved and respected methodology.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694065")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2026")])]

#text("Palomar’s whitelist for library imports for the challenge file currently consists of Mathlib, CSlib, and Tau Ceti; in particular it cannot use arbitrary definitions imported from arbitrary repositories, which is a very intentional choice on our part. However, the solution file may use external imports beyond this whitelist.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/069b47c5bb1a265ffe160a2ff1e0e57e57991cb0b1e055fd1d852ee28b3345fd-92ca8b383c5e71f4239a4c1053d92c2a4c302108516d7873c946f7c55d524535.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alonsoquixano")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694093")[#strong[#text("alonsoquixano")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2026")])]

#text("Thank you for the pointer. A few questions/comments:")#linebreak()#text(" – One clicks on an article, clons the corresponding GitHub repository, and then tries to verify the proof using one’s own Lean installation and the instructions [https://lean-lang.org/doc/reference/latest/ValidatingProofs/#validating-proofs](")#link("https://lean-lang.org/doc/reference/latest/ValidatingProofs/#validating-proofs")[#text("https://lean-lang.org/doc/reference/latest/ValidatingProofs/#validating-proofs")]#text(")?")#linebreak()#text(" – There was some talk of using converters. I assume this refers to translating informal theorems into Lean. What about the reverse direction — for example, converting a theorem in Lean into an informal version?")#linebreak()#text(" – A general suggestion for the blog, from someone who is only comfortable mainly with ZFC and first-order logic: how about a post explaining the advantages of Lean, perhaps with a comparison with Isabelle (or Metamath)?")#linebreak()#text(" Uwe Brauer")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694119")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2026")])]

#text("My Collatz Palomar submission is now registered.")

#text("Title: polylogarithmic descent for almost all collatz orbits in natural density")

#link("https://palomar-registry.org/entry?id=PALOMAR-2026-08-26-000005&version=1")[#text("https://palomar-registry.org/entry?id=PALOMAR-2026-08-26-000005&version=1")]

#text("The community was incredibly helpful, especially Kim Morrison, who was remarkably available and supportive throughout.")

#text("As an independent researcher and a software developer for over 2 decades, I feel genuinely empowered by this. I’ve faced journal desk rejections, so I’ll allow myself one small and slightly petty victory lap here.")

#text("Thank you Dr Tao and the whole Lean FRO and ICARM for bringing Math to coders now.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694154")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2026")])]

#text("Can you point us to the paper?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694146")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2026")])]

#text("Has anyone seen the purported AI solution to Hopf’s problem that Levent Alpöge posted to twitter a few days ago? There are now two separate Lean formalizations but IDK what reservations might exist about them. They were apparently also done by AI, though the problem statement itself was done by humans some time ago.")

#text("More info at the comment thread: ")#link("https://mathoverflow.net/a/514604/129086")[#text("https://mathoverflow.net/a/514604/129086")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb27f379fdc576c1dab62a8d3e0be2588f736ebff635634a8c4f33fba4cddcf-b66495a3b2483b5f82096cfbac6e41287d131accac08e88190032a808eb63ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Warren Ericson")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694158")[#strong[#text("Lars Warren Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2026")])]

#text("I have been using Palomar to validate and register ")#link("https://leanprover.zulipchat.com/#narrow/channel/287929-mathlib4/topic/Domain.20Theory.20Library/near/619257805")[#text("a set of formalizations")]#text(" of Dana Scott’s presentations of a topological model of untyped lambda calculus, and bridge theorems between the presentations. I was impressed by the ability of the Palomar review to detect differences between the informal English statement of a claim and the Lean 4 formal statement. Palomar uses OpenAI’s frontier general purpose LLM GPT-5.6, and a ")#link("https://github.com/PalomarRegistry/PalomarPolicy")[#text("thorough set of policy prompts")]#text(". I am proud of my successful registrations. Do you agree with Kim Morrison’s belief that ")#link("https://leanprover.zulipchat.com/#narrow/channel/287929-mathlib4/topic/Domain.20Theory.20Library/near/619164781")[#text("“Palomar does not “review” code, it only rejects or doesn’t reject it using some simple fubrics. :woman_shrugging: Please don’t pretend it is some editorial stamp of approval: your work can be in Palomar and still might be crap and irrelevant!”")]#text("? If so, what percentage of the 116 results registered to date would be found to be “crap and irrelevant” upon your review or the review of a mathematician of similar skill and training?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694167")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2026")])]

#text("As stated in Palomar’s ")#link("https://palomar-registry.org/about")[#text("about page")]#text(" (see in particular “What Palomar is not”), Palomar does not perform actual peer review on its submissions; the automated checks it supplies can flag some obvious alignment issues with a formalization, but is not a substitute for genuine human review, which we do not have the resources to conduct on the volume of submissions received.")

#text("There are plans by other parties to implement a “Palomar overlay journal”, which would conduct peer review on Palomar repositories submitted to that journal, but this would be a separate project. We are intentionally keeping Palomar lightweight in order to allow for reliable maintainance and quality control.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb27f379fdc576c1dab62a8d3e0be2588f736ebff635634a8c4f33fba4cddcf-b66495a3b2483b5f82096cfbac6e41287d131accac08e88190032a808eb63ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Warren Ericson")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694168")[#strong[#text("Lars Warren Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2026")])]

#text("In formalizing whole papers like ")#link("https://github.com/catskillsresearch/scott1964")[#text("Scott ")#strong[#text("1964")]#text(" ")#emph[#text("Measurement Structures and Linear Inequalities")]]#text(" with GPT 5.6 Sol, my process is to do a ")#link("https://github.com/catskillsresearch/scott1964/blob/main/scripts/ocr_pdf_pipeline.sh")[#text("reliable OCR process")]#text(" followed by a single prompt of form “Formalize all definitions, notations, and theorems in Lean 4 for text paper.md”. Then run a Palomar registration, which is a way to put the formalized paper out into the world. Palomar doesn’t index the formalization in Google Scholar. The process itself doesn’t merit a paper in arXiv because the act of pushing the button on an autoformalization is no longer notable. I can put the formalization and a short methodology note in HAL.science, which does index in Google Scholar and allows a wider range of artifacts than arXiv. What do you recommend as a template for methodology notes, and as the best way to get the pairing of the autoformalization with the original paper into Google Scholar?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694190")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2026")])]

#text("I am hoping soon Palomar becomes a mainstream academic research registry. It already supports bib citation, that means the board has a vision to make it mainstream registry may be not soon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb27f379fdc576c1dab62a8d3e0be2588f736ebff635634a8c4f33fba4cddcf-b66495a3b2483b5f82096cfbac6e41287d131accac08e88190032a808eb63ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Warren Ericson")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694201")[#strong[#text("Lars Warren Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2026")])]

#text("Cooldown penalties are excessive. I am up to 5 days between submits for a repo that was blocked by ")#link("https://leanprover.zulipchat.com/#narrow/channel/621638-Palomar/topic/Palomar.20could.20not.20complete.20mechanical.20verification/with/619233142")[#text("system problems that needed to be fixed by Palomar developer pull requests")]#text(". The net effect is punitive gatekeeping. Is this the desired effect?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e68a162bee7da5754dcb3d9d27ed512a6ee95dbf89f19ac5344079ef0345e348-3e4e72da186f83a0b981add28b492ef04450ac680dcd3e430b2ba87de800afe2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arnaudmayeuxmath")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694210")[#strong[#text("arnaudmayeuxmath")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2026")])]

#text("I have built an index that runs from published mathematics to Lean: the entry point is a paper, not a repository.")

#text("It covers roughly 5M records, with formalization artifacts attached to the papers they formalize (e.g. Palomar entries, arXiv formalization papers). Each link is verified individually against the authors of the source paper. Every record carries a permanent code, such as MiNDS3MDGRHZCD5.")

#link("https://mathinsid.org")[#text("https://mathinsid.org")]

#text("It is still early. Such an index should become more useful as the formalized corpus grows in size and level.")

#text("Corrections and suggestions are very welcome.")

#text("Method: arXiv:2606.11430 (v1 9 Jun 2026)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb27f379fdc576c1dab62a8d3e0be2588f736ebff635634a8c4f33fba4cddcf-b66495a3b2483b5f82096cfbac6e41287d131accac08e88190032a808eb63ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Warren Ericson")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694221")[#strong[#text("Lars Warren Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2026")])]

#text("Arnaud, please index HAL.science preprints as well as arXiv preprints. arXiv is inconsistent about accepting formalization notes. Of two notes both describing formalizations of two papers by the same author on the same subject, one could be deemed to be in scope for the arXiv category and the other out of scope, when both formalization notes are similarly prepared and both Lean codes accepted by Palomar. I am putting new formalization notes in HAL.science from now on. Your site picked up two of my arXiv Lean papers. I’m worried it won’t pick up any archived in HAL.science.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e68a162bee7da5754dcb3d9d27ed512a6ee95dbf89f19ac5344079ef0345e348-3e4e72da186f83a0b981add28b492ef04450ac680dcd3e430b2ba87de800afe2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arnaudmayeuxmath")]], [#link("https://terrytao.wordpress.com/2026/08/18/palomar-a-registry-of-lean-verified-mathematics/#comment-694307")[#strong[#text("arnaudmayeuxmath")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2026")])]

#text("Lars, thank you for the note. MathINsiD is designed to index HAL papers, subject to the same conditions as any other source: a real published or preprint paper, with formalization artifacts individually verified. More generally: MathINsiD aims to stay open to any proof system and any index, current or future, including but not limited to Lean, Isabelle, Coq, arXiv, HAL, Palomar, and mathlib, all of which we value. The totem here is the published literature; MathINsiD will adapt on the formalization side as that landscape keeps advancing. The entry point is the paper; verified formalization artifacts pointing to it can come from any serious source. Please click “Contact” on the site to submit an entry if needed.")
]
]
]
