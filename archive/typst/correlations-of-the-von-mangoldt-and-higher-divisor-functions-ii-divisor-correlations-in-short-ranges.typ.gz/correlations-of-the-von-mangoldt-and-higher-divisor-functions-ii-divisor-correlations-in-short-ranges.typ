// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/12/27/correlations-of-the-von-mangoldt-and-higher-divisor-functions-ii-divisor-correlations-in-short-ranges/
// Converted to Typst by tao2typ: "2026-10-14T16:38:15.236108+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Correlations of the von Mangoldt and higher divisor functions II.  Divisor correlations in short ranges", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Correlations of the von Mangoldt and higher divisor functions II.  Divisor correlations in short ranges")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 December 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/12/27/correlations-of-the-von-mangoldt-and-higher-divisor-functions-ii-divisor-correlations-in-short-ranges/")[#text("https://terrytao.wordpress.com/2017/12/27/correlations-of-the-von-mangoldt-and-higher-divisor-functions-ii-divisor-correlations-in-short-ranges/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://users.utu.fi/ksmato/")[#text("Kaisa Matomaki")]#text(", ")#link("http://www.math.mcgill.ca/radziwill/")[#text("Maksym Radziwill")]#text(", and I have uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/1712.08840")[#text("Correlations of the von Mangoldt and higher divisor functions II. Divisor correlations in short ranges")]#text("“. This is a sequel of sorts to our ")#link("https://terrytao.wordpress.com/2017/07/06/correlations-of-the-von-mangoldt-and-higher-divisor-functions-i-long-shift-ranges/")[#text("previous paper on divisor correlations")]#text(", though the proof techniques in this paper are rather different. As with the previous paper, our interest is in correlations such as ")#metadata(none) <tao-eedd861ec911535e8123>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{n \\leq X} d_k(n) d_l(n+h)")]]

#text("for medium-sized ")#mi("{h}")#text(" and large ")#mi("{X}")#text(", where ")#mi("{k \\geq l \\geq 1}")#text(" are natural numbers and ")#mi("{d_k(n) = \\sum_{n = m_1 \\dots m_k} 1}")#text(" is the ")#mi("{k^{th}}")#text(" divisor function (actually our methods can also treat a generalisation in which ")#mi("{k}")#text(" is non-integer, but for simplicity let us stick with the integer case for this discussion). Our methods also allow for one of the divisor function factors to be replaced with a von Mangoldt function, but (in contrast to the previous paper) we cannot treat the case when both factors are von Mangoldt.")

#text("As discussed in ")#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/")[#text("this previous post")]#text(", one heuristically expects an asymptotic of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq X} d_k(n) d_l(n+h) = P_{k,l,h}( \\log X ) X + O( X^{1/2+\\varepsilon})")]]

#text("for any fixed ")#mi("{\\varepsilon>0}")#text(", where ")#mi("{P_{k,l,h}}")#text(" is a certain explicit (but rather complicated) polynomial of degree ")#mi("{k+l-1}")#text(". Such asymptotics are known when ")#mi("{l \\leq 2}")#text(", but remain open for ")#mi("{k \\geq l \\geq 3}")#text(". In the previous paper, we were able to obtain a weaker bound of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq X} d_k(n) d_l(n+h) = P_{k,l,h}( \\log X ) X + O_A( X \\log^{-A} X)")]]

#text("for ")#mi("{1-O_A(\\log^{-A} X)}")#text(" of the shifts ")#mi("{-H \\leq h \\leq H}")#text(", whenever the shift range ")#mi("{H}")#text(" lies between ")#mi("{X^{8/33+\\varepsilon}}")#text(" and ")#mi("{X^{1-\\varepsilon}}")#text(". But the methods become increasingly hard to use as ")#mi("{H}")#text(" gets smaller. In this paper, we use a rather different method to obtain the even weaker bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq X} d_k(n) d_l(n+h) = (1+o(1)) P_{k,l,h}( \\log X ) X")]]

#text("for ")#mi("{1-o(1)}")#text(" of the shifts ")#mi("{-H \\leq h \\leq H}")#text(", where ")#mi("{H}")#text(" can now be as short as ")#mi("{H = \\log^{10^4 k \\log k} X}")#text(". The constant ")#mi("{10^4}")#text(" can be improved, but there are serious obstacles to using our method to go below ")#mi("{\\log^{k \\log k} X}")#text(" (as the exceptionally large values of ")#mi("{d_k}")#text(" then begin to dominate). This can be viewed as an analogue to ")#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/")[#text("our previous paper on correlations of bounded multiplicative functions on average")]#text(", in which the functions ")#mi("{d_k,d_l}")#text(" are now unbounded, and indeed our proof strategy is based in large part on that paper (but with many significant new technical complications).")

#text("We now discuss some of the ingredients of the proof. Unsurprisingly, the first step is the circle method, expressing ")#link(<tao-eedd861ec911535e8123>)[#text("(1)")]#text(" in terms of exponential sums such as")

#align(center)[#tao-fit-display[#mitex("S(\\alpha) := \\sum_{n \\leq X} d_k(n) e(\\alpha).")]]

#text("Actually, it is convenient to first prune ")#mi("{d_k}")#text(" slightly by zeroing out this function on “atypical” numbers ")#mi("{n}")#text(" that have an unusually small or large number of factors in a certain sense, but let us ignore this technicality for this discussion. The contribution of ")#mi("{S(\\alpha)}")#text(" for “major arc” ")#mi("{\\alpha}")#text(" can be treated by standard techniques (and is the source of the main term ")#mi("{P_{k,l,h}(\\log X) X}")#text("; the main difficulty comes from treating the contribution of “minor arc” ")#mi("{\\alpha}")#text(".")

#text("In our previous paper on bounded multiplicative functions, we used Plancherel’s theorem to estimate the global ")#mi("{L^2}")#text(" norm ")#tao-math("{\\int_{{\\bf R}/{\\bf Z}} \\left|S(\\alpha)\\right|^2\\ d\\alpha}", block: false)#text(", and then also used the ")#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/")[#text("Katai-Bourgain-Sarnak-Ziegler orthogonality criterion")]#text(" to control local ")#mi("{L^2}")#text(" norms ")#tao-math("{\\int_I \\left|S(\\alpha)\\right|^2\\ d\\alpha}", block: false)#text(", where ")#mi("{I}")#text(" was a minor arc interval of length about ")#mi("{1/H}")#text(", and these two estimates together were sufficient to get a good bound on correlations by an application of Hölder’s inequality. For ")#mi("{d_k}")#text(", it is more convenient to use Dirichlet series methods (and Ramaré-type factorisations of such Dirichlet series) to control local ")#mi("{L^2}")#text(" norms on minor arcs, in the spirit of the proof of the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3488742")[#text("Matomaki-Radziwill theorem")]#text("; a key point is to develop “log-free” mean value theorems for Dirichlet series associated to functions such as ")#mi("{d_k}")#text(", so as not to wipe out the (rather small) savings one will get over the trivial bound from this method. On the other hand, the global ")#mi("{L^2}")#text(" bound will definitely be unusable, because the ")#mi("{\\ell^2}")#text(" sum ")#mi("{\\sum_{n \\leq X} d_k(n)^2}")#text(" has too many unwanted factors of ")#mi("{\\log X}")#text(". Fortunately, we can substitute this global ")#mi("{L^2}")#text(" bound with a “large values” bound that controls expressions such as")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i=1}^J \\int_{I_i} \\left|S(\\alpha)\\right|^2\\ d\\alpha", block: true)]]

#text("for a moderate number of disjoint intervals ")#mi("{I_1,\\dots,I_J}")#text(", with a bound that is slightly better (for ")#mi("{J}")#text(" a medium-sized power of ")#mi("{\\log X}")#text(") than what one would have obtained by bounding each integral ")#tao-math("{\\int_{I_i} \\left|S(\\alpha)\\right|^2\\ d\\alpha}", block: false)#text(" separately. (One needs to save more than ")#mi("{J^{1/2}}")#text(" for the argument to work; we end up saving a factor of about ")#mi("{J^{3/4}}")#text(".) This large values estimate is probably the most novel contribution of the paper. After taking the Fourier transform, matters basically reduce to getting a good estimate for")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i=1}^J (\\int_X^{2X} \\left|\\sum_{x \\leq n \\leq x+H} d_k(n) e(\\alpha_i n)\\right|^2\\ dx)^{1/2},", block: true)]]

#text("where ")#mi("{\\alpha_i}")#text(" is the midpoint of ")#mi("{I_i}")#text("; thus we need some upper bound on the large local Fourier coefficients of ")#mi("{d_k}")#text(". These coefficients are difficult to calculate directly, but, in the spirit of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2245880")[#text("a paper of Ben Green and myself")]#text(", we can try to replace ")#mi("{d_k}")#text(" by a more tractable and “pseudorandom” majorant ")#mi("{\\tilde d_k}")#text(" for which the local Fourier coefficients are computable (on average). After a standard duality argument, one ends up having to control expressions such as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{x \\leq n \\leq x+H} \\tilde d_k(n) e((\\alpha_i -\\alpha_{i^{\\prime}}) n)\\right|", block: true)]]

#text("after various averaging in the ")#mi("{x, i,i^{\\prime}}")#text(" parameters. These local Fourier coefficients of ")#mi("{\\tilde d_k}")#text(" turn out to be small on average unless ")#mi("{\\alpha_i -\\alpha_{i^{\\prime}}}")#text(" is “major arc”. One then is left with a mostly combinatorial problem of trying to bound how often this major arc scenario occurs. This is very close to a computation in the previously mentioned paper of Ben and myself; there is a technical wrinkle in that the ")#mi("{\\alpha_i}")#text(" are not as well separated as they were in my paper with Ben, but it turns out that one can modify the arguments in that paper to still obtain a satisfactory estimate in this case (after first grouping nearby frequencies ")#mi("{\\alpha_i}")#text(" together, and modifying the duality argument accordingly).")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/27/correlations-of-the-von-mangoldt-and-higher-divisor-functions-ii-divisor-correlations-in-short-ranges/#comment-490845")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2017")])]

#text("Which applications are known to require estimates with such small order of ")#mi("H")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/27/correlations-of-the-von-mangoldt-and-higher-divisor-functions-ii-divisor-correlations-in-short-ranges/#comment-490851")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2017")])]

#text("If one could obtain estimates of this form with a power savings, then one could likely improve upon higher moment estimates for the zeta function; unfortunately, our techniques don’t even save a power of a logarithm. Estimates for fixed H should allow one to count solutions to Diophantine equations such as ")#mi("abc-def=1")#text(" (with ")#mi("a,b,c,d")#text(" in a fixed range), which is out of reach of current technology. Of course, if one could also replace the divisor functions with the von Mangoldt function, one would also start resolving conjectures such as the twin prime conjecture.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a98f3df9b6a5632a4bf0a0fd81541d05b67cf74565788c0ac7e2b54344839a8-9f492533d2b15b4f3760c8e5384c0b7fc68e7d2905a9a6ffcacc05f60becac33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hxypqr")]], [#link("https://terrytao.wordpress.com/2017/12/27/correlations-of-the-von-mangoldt-and-higher-divisor-functions-ii-divisor-correlations-in-short-ranges/#comment-490897")[#strong[#text("hxypqr")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2017")])]

#text("Dear terry:")#linebreak()#text(" Along the idea you have point out in article “correlations of bounded multiplicative functions on average” , to get the higher pattern of log average chowla conjecture is true, the key point is to establish following theorem:")#linebreak()#text(" ……………………………………………………………………………………………………….")#linebreak()#text(" ")#mi("f(n): \\mathbb N\\to \\mathbb C")#text(" is a multiplicative function, i.e. ")#mi("f(mn)=f(n)f(m), \\forall m,n\\in \\mathbb N")#text(". ")#mi("g(n)=a_n^m+...+a_1n+a_0")#text(" is a polynomial function then we have the following result,")

#tao-math("\\int_{1\\leq n \\leq X}\\left|f(n)e^{2\\pi i g(n)}\\right|=o(X)", block: false)#text(".")#linebreak()#text(" …………………………………………………………………………………………………………..")#linebreak()#text(" I")#linebreak()#text(" in my understanding, the main obstacle is we could not combine the method of B-S-Z critition and the proof idea of Matomaki and Raziwill to get a good estimate on the correlation of multiplication function and nil-sequence in short interval because of the way of decomposition a global sum into fragment and use some reasonable way to combine them again is different.")

#text("In the story of higher divisor function ")#mi("d_k")#text(", morally speaking ")#mi("d_k")#text(" is come from the high dimension hyperbola, there is a lot of symmetry with the high dimension hyperbola, which is the key point of why dirichlet hyperbola method could be powerful. Could the symmetry help us go a little further to say something beyond any general multiplication function? And even, in the best case, could we use the symmetry to combine the different decomposition way in B-S-Z critition and the proof idea of Matomaki and Raziwill, then say something with the even pattern large than 2 correlation of ")#mi("d_k")#text(" itself?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/12/27/correlations-of-the-von-mangoldt-and-higher-divisor-functions-ii-divisor-correlations-in-short-ranges/#comment-490923")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2017")])]

#text("The specific result you state here is covered by the work of Frantzikinakis and Host in ")#link("https://arxiv.org/abs/1403.0945")[#text("https://arxiv.org/abs/1403.0945")]#text(" (see Theorem 2.2), basically using the Katai-Bourgain-Sarnak-Ziegler method. What appears to be much more difficult and important though is to control local averages such as ")#tao-math("\\int_X^{2X} \\sup_\\alpha \\left|\\sum_{x \\leq n \\leq x+H} \\lambda(n) e(\\alpha n)\\right|\\ dx", block: false)#text(" for small values of ")#mi("H")#text("; the KBSZ method does not seem to be sufficient.")

#text("There are ways to exploit the finer geometry of the hyperbola to sharpen the error term in sums such as ")#mi("\\sum_{n \\leq X} d_2(n)")#text(" or ")#mi("\\sum_{n \\leq X} d_2(n) d_2(n+h)")#text(", for instance using automorphic forms to exploit the ")#mi("SL_2")#text(" symmetries, but extending these ideas to the ")#mi("k \\geq 3")#text(" case has proven to be rather difficult.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a98f3df9b6a5632a4bf0a0fd81541d05b67cf74565788c0ac7e2b54344839a8-9f492533d2b15b4f3760c8e5384c0b7fc68e7d2905a9a6ffcacc05f60becac33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hxypqr")]], [#link("https://terrytao.wordpress.com/2017/12/27/correlations-of-the-von-mangoldt-and-higher-divisor-functions-ii-divisor-correlations-in-short-ranges/#comment-490956")[#strong[#text("hxypqr")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2017")])]

#text("Many thanks for the reference and advice, I do not know the approach of ")#mi("SL_2")#text(" before you point out it, I will consider your advice to have a more refine understanding on ")#mi("d_k(n)")#text("., ")#mi("d_2(n)")#text(" at least.")

#text("I am sorry… I misleading you and myself, I take a note a couple of days ago and I pasted a wrong theorem, the right thing to consider is the following:")

#text("………………………………………………………………………………………………………………….")#linebreak()#text(" Theorem (do not established) :(correlation of Mobius function and nil-sequences in short interval)")

#mi("\\lambda(n)")#text(" is the liouville function we wish the following estimate is true.")

#mi("\\int_{0\\leq x\\leq X}|\\sup_{f\\in \\Omega^m}\\sum_{x\\leq n\\leq x+H}\\lambda(n)e^{2\\pi if(x)}|dx =o(XH)")#text(".")

#text("Where we have ")#mi("H\\to \\infty")#text(" as ")#mi("x\\to \\infty")#text(", ")#mi("\\Omega^m=\\{a_mx^m+a_{m-1}x^{m-1}+...+a_1x+a_0 | a_m,...,a_1,a_0\\in [0,1]\\}")#text(" is a compact space")#linebreak()#text(" ………………………………………………………………………………………………………………………………………")

#text("If we can establish the estimate in the theorem, then we consider following identity:")

#tao-math("\\int_{T^m}(\\int_{R}^X\\left|\\sum_{x\\leq n\\leq n+H}\\lambda(n)e^{2\\pi if(n)}\\right|^2dx)^2d\\alpha_1...\\alpha_m=\\sum_{\\left|h\\right|\\leq H}\\left|\\Pi_{(\\delta_1,...,\\delta_m)\\in (0,1)^{m}}\\lambda^{w(\\delta_1,...,\\delta_m)}(n+\\delta_1h_1+...+\\delta_mh_m)\\right|^2+error \\ term", block: false)#text(".")

#text("Where $latex \\lambda^{w(\\delta_1,…,\\delta_m)}=\\lambda$ if ")#mi("2|\\sum_i \\delta_i")#text(", else ")#mi("\\lambda^{w(\\delta_1,...,\\delta_m)}=\\overline \\lambda")#text(".")

#text("Then thanks to the entropy decrement method, we can gain the log average chola conjecture. In my, opinion, I think, the main obstacle to establish such a result is at the major arc, although now we need to decomposition in ")#mi("2^m")#text(" cases, depending on whether ")#mi("\\alpha_i, 1\\leq i\\leq m")#text(" is in a minor arc. If we are in the situation of minor arc, the argument to get a suffice estimate involve three things:")

#text("The combinatorics identity to write the sum into bilinear sum, but we now need to write it into multilinear sum, this could be done. ")#linebreak()#text(" The holder inequality, but with different index, this is standard.")#linebreak()#text(" The key argument is transform to consider a high moment of the correlation of n-order nil-sequence and the multiplication function, in fact ")#mi("m")#text(" order there, and expansion it into a linear sum, directly compute it and then use the assumption on ")#mi("\\alpha")#text(", this argument still make sense.")#linebreak()#text(" Now I wish to explain the difficult occur in the major term part, this part is extremely difficult, I think it is not only due to we need a uniformly estimate, i.e. independent of ")#mi("\\alpha")#text(", but also due to the nil-sequences do not compatible with the multiplication at all. The second difficulty, as I thought, The standard approach is to establish a uniformly distribution result on prime and nil-sequences, this is nearly the conjecture of the Dirchlet theorem of irreducible polynomial (in a best case, a weak version could be enough)… Anyway if there is such a result, then we can decomposition the neutral number on every piece into several nil-sequences part ")#mi("[x,x+H]=\\cup_{i}I_i")#text(", and try to proof a version of the result of Matomaki and Raziwill in the nil-sequences setting, I do not know if it is possible to get a proof by this way…")
]
