// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/06/03/the-furstenberg-multiple-recurrence-theorem-and-finite-extensions/
// Converted to Typst by tao2typ: "2026-10-14T16:36:31.414341+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Furstenberg multiple recurrence theorem and finite extensions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Furstenberg multiple recurrence theorem and finite extensions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 June 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/06/03/the-furstenberg-multiple-recurrence-theorem-and-finite-extensions/")[#text("https://terrytao.wordpress.com/2011/06/03/the-furstenberg-multiple-recurrence-theorem-and-finite-extensions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In 1977, ")#link("http://www.ams.org/mathscinet-getitem?mr=498471")[#text("Furstenberg established")]#text(" his multiple recurrence theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Furstenberg multiple recurrence)")]#text(" Let ")#mi("{(X, {\\mathcal B}, \\mu, T)}")#text(" be a measure-preserving system, thus ")#mi("{(X,{\\mathcal B},\\mu)}")#text(" is a probability space and ")#mi("{T: X \\rightarrow X}")#text(" is a measure-preserving bijection such that ")#mi("{T}")#text(" and ")#mi("{T^{-1}}")#text(" are both measurable. Let ")#mi("{E}")#text(" be a measurable subset of ")#mi("{X}")#text(" of positive measure ")#mi("{\\mu(E) > 0}")#text(". Then for any ")#mi("{k \\geq 1}")#text(", there exists ")#mi("{n > 0}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("E \\cap T^{-n} E \\cap \\ldots \\cap T^{-(k-1)n} E \\neq \\emptyset.")]]

#text("Equivalently, there exists ")#mi("{n > 0}")#text(" and ")#mi("{x \\in X}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("x, T^n x, \\ldots, T^{(k-1)n} x \\in E.")]]
]

#text("As is well known, the Furstenberg multiple recurrence theorem is equivalent to ")#link("http://www.scholarpedia.org/article/Szemeredi%27s_Theorem")[#text("Szemerédi’s theorem")]#text(", thanks to the Furstenberg correspondence principle; see for instance ")#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/")[#text("these lecture notes of mine")]#text(".")

#text("The multiple recurrence theorem is proven, roughly speaking, by an induction on the “complexity” of the system ")#mi("{(X,{\\mathcal X},\\mu,T)}")#text(". Indeed, for very simple systems, such as periodic systems (in which ")#mi("{T^n}")#text(" is the identity for some ")#mi("{n>0}")#text(", which is for instance the case for the circle shift ")#mi("{X = {\\bf R}/{\\bf Z}}")#text(", ")#mi("{Tx := x+\\alpha}")#text(" with a rational shift ")#mi("{\\alpha}")#text("), the theorem is trivial; at a slightly more advanced level, ")#emph[#text("almost periodic")]#text(" (or ")#emph[#text("compact")]#text(") systems (in which ")#mi("{\\{ T^n f: n \\in {\\bf Z} \\}}")#text(" is a precompact subset of ")#mi("{L^2(X)}")#text(" for every ")#mi("{f \\in L^2(X)}")#text(", which is for instance the case for irrational circle shifts), is also quite easy. One then shows that the multiple recurrence property is preserved under various ")#emph[#text("extension")]#text(" operations (specifically, compact extensions, weakly mixing extensions, and limits of chains of extensions), which then gives the multiple recurrence theorem as a consequence of the ")#emph[#text("Furstenberg-Zimmer structure theorem")]#text(" for measure-preserving systems. See ")#link("https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/")[#text("these lecture notes")]#text(" for further discussion.")

#text("From a high-level perspective, this is still one of the most conceptual proofs known of Szemerédi’s theorem. However, the individual components of the proof are still somewhat intricate. Perhaps the most difficult step is the demonstration that the multiple recurrence property is preserved under ")#emph[#text("compact extensions")]#text("; see for instance ")#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/")[#text("these lecture notes")]#text(", which is devoted entirely to this step. This step requires quite a bit of measure-theoretic and/or functional analytic machinery, such as the theory of disintegrations, relatively almost periodic functions, or Hilbert modules.")

#text("However, I recently realised that there is a special case of the compact extension step – namely that of ")#emph[#text("finite")]#text(" extensions – which avoids almost all of these technical issues while still capturing the essence of the argument (and in particular, the key idea of using ")#link("http://en.wikipedia.org/wiki/Van_der_Waerden%27s_theorem")[#text("van der Waerden’s theorem")]#text("). As such, this may serve as a pedagogical device for motivating this step of the proof of the multiple recurrence theorem.")

#text("Let us first explain what a finite extension is. Given a measure-preserving system ")#mi("{X = (X,{\\mathcal X},\\mu,T)}")#text(", a finite set ")#mi("{Y}")#text(", and a measurable map ")#mi("{\\rho: X \\rightarrow \\text{Sym}(Y)}")#text(" from ")#mi("{X}")#text(" to the permutation group of ")#mi("{Y}")#text(", one can form the ")#emph[#text("finite extension")]

#align(center)[#tao-fit-display[#mitex("X \\ltimes_\\rho Y = (X \\times Y, {\\mathcal X} \\times {\\mathcal Y}, \\mu \\times \\nu, S),")]]

#text("which as a probability space is the product of ")#mi("{(X,{\\mathcal X},\\mu)}")#text(" with the finite probability space ")#mi("{Y = (Y, {\\mathcal Y},\\nu)}")#text(" (with the discrete ")#mi("{\\sigma}")#text("-algebra and uniform probability measure), and with shift map ")#metadata(none) <tao-a4cf5e703ea05d936c9c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("S(x, y) := (Tx, \\rho(x) y).")]]

#text("One easily verifies that this is indeed a measure-preserving system. We refer to ")#mi("{\\rho}")#text(" as the ")#emph[#text("cocycle")]#text(" of the system.")

#text("An example of finite extensions comes from group theory. Suppose we have a short exact sequence")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow K \\rightarrow G \\rightarrow H \\rightarrow 0")]]

#text("of finite groups. Let ")#mi("{g}")#text(" be a group element of ")#mi("{G}")#text(", and let ")#mi("{h}")#text(" be its projection in ")#mi("{H}")#text(". Then the shift map ")#mi("{x \\mapsto gx}")#text(" on ")#mi("{G}")#text(" (with the discrete ")#mi("{\\sigma}")#text("-algebra and uniform probability measure) can be viewed as a finite extension of the shift map ")#mi("{y \\mapsto hy}")#text(" on ")#mi("{H}")#text(" (again with the discrete ")#mi("{\\sigma}")#text("-algebra and uniform probability measure), by arbitrarily selecting a section ")#mi("{\\phi: H \\rightarrow G}")#text(" that inverts the projection map, identifying ")#mi("{G}")#text(" with ")#mi("{H \\times K}")#text(" by identifying ")#mi("{k \\phi(y)}")#text(" with ")#mi("{(y,k)}")#text(" for ")#mi("{y \\in H, k \\in K}")#text(", and using the cocycle")

#align(center)[#tao-fit-display[#mitex("\\rho(y) := \\phi(hy)^{-1} g \\phi(y).")]]

#text("Thus, for instance, the unit shift ")#mi("{x \\mapsto x+1}")#text(" on ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" can be thought of as a finite extension of the unit shift ")#mi("{x \\mapsto x+1}")#text(" on ")#mi("{{\\bf Z}/M{\\bf Z}}")#text(" whenever ")#mi("{N}")#text(" is a multiple of ")#mi("{M}")#text(".")

#text("Another example comes from Riemannian geometry. If ")#mi("{M}")#text(" is a Riemannian manifold that is a finite cover of another Riemannian manifold ")#mi("{N}")#text(" (with the metric on ")#mi("{M}")#text(" being the pullback of that on ")#mi("{N}")#text("), then (unit time) geodesic flow on the cosphere bundle of ")#mi("{M}")#text(" is a finite extension of the corresponding flow on ")#mi("{N}")#text(".")

#text("Here, then, is the finite extension special case of the compact extension step in the proof of the multiple recurrence theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Finite extensions)")]#text(" ")#metadata(none) <tao-d4f568b800c6a61b3ba2>#text(" Let ")#mi("{X \\rtimes_\\rho Y}")#text(" be a finite extension of a measure-preserving system ")#mi("{X}")#text(". If ")#mi("{X}")#text(" obeys the conclusion of the Furstenberg multiple recurrence theorem, then so does ")#mi("{X \\rtimes_\\rho Y}")#text(".")
]

#text("Before we prove this proposition, let us first give the combinatorial analogue.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" ")#metadata(none) <tao-e340ddbffe550c8b647b>#text(" Let ")#mi("{A}")#text(" be a subset of the integers that contains arbitrarily long arithmetic progressions, and let ")#mi("{A = A_1 \\cup \\ldots \\cup A_M}")#text(" be a colouring of ")#mi("{A}")#text(" by ")#mi("{M}")#text(" colours (or equivalently, a partition of ")#mi("{A}")#text(" into ")#mi("{M}")#text(" colour classes ")#mi("{A_i}")#text("). Then at least one of the ")#mi("{A_i}")#text(" contains arbitrarily long arithmetic progressions.")
]

#emph[#text("Proof:")]#text(" By the infinite pigeonhole principle, it suffices to show that for each ")#mi("{k \\geq 1}")#text(", one of the colour classes ")#mi("{A_i}")#text(" contains an arithmetic progression of length ")#mi("{k}")#text(".")

#text("Let ")#mi("{N}")#text(" be a large integer (depending on ")#mi("{k}")#text(" and ")#mi("{M}")#text(") to be chosen later. Then ")#mi("{A}")#text(" contains an arithmetic progression of length ")#mi("{N}")#text(", which may be identified with ")#mi("{\\{0,\\ldots,N-1\\}}")#text(". The colouring of ")#mi("{A}")#text(" then induces a colouring on ")#mi("{\\{0,\\ldots,N-1\\}}")#text(" into ")#mi("{M}")#text(" colour classes. Applying (the finitary form of) ")#link("http://en.wikipedia.org/wiki/Van_der_Waerden%27s_theorem")[#text("van der Waerden’s theorem")]#text(", we conclude that if ")#mi("{N}")#text(" is sufficiently large depending on ")#mi("{M}")#text(" and ")#mi("{k}")#text(", then one of these colouring classes contains an arithmetic progression of length ")#mi("{k}")#text("; undoing the identification, we conclude that one of the ")#mi("{A_i}")#text(" contains an arithmetic progression of length ")#mi("{k}")#text(", as desired. ")#mi("\\Box")

#text("Of course, by specialising to the case ")#mi("{A={\\bf Z}}")#text(", we see that the above Lemma is in fact equivalent to van der Waerden’s theorem.")

#text("Now we prove Proposition ")#link(<tao-d4f568b800c6a61b3ba2>)[#text("2")]#text(".")

#emph[#text("Proof:")]#text(" Fix ")#mi("{k}")#text(". Let ")#mi("{E}")#text(" be a positive measure subset of ")#mi("{X \\rtimes_\\rho Y = (X \\times Y, {\\mathcal X} \\times {\\mathcal Y}, \\mu \\times \\nu, S)}")#text(". By Fubini’s theorem, we have")

#align(center)[#tao-fit-display[#mitex("\\mu \\times \\nu(E) = \\int_X f(x)\\ d\\mu(x)")]]

#text("where ")#mi("{f(x) := \\nu(E_x)}")#text(" and ")#mi("{E_x := \\{ y \\in Y: (x,y) \\in E \\}}")#text(" is the fibre of ")#mi("{E}")#text(" at ")#mi("{x}")#text(". Since ")#mi("{\\mu \\times \\nu(E)}")#text(" is positive, we conclude that the set")

#align(center)[#tao-fit-display[#mitex("F := \\{ x \\in X: f(x) > 0 \\} = \\{ x \\in X: E_x \\neq \\emptyset \\}")]]

#text("is a positive measure subset of ")#mi("{X}")#text(". Note for each ")#mi("{x \\in F}")#text(", we can find an element ")#mi("{g(x) \\in Y}")#text(" such that ")#mi("{(x,g(x)) \\in E}")#text(". While not strictly necessary for this argument, one can ensure if one wishes that the function ")#mi("{g}")#text(" is measurable by totally ordering ")#mi("{Y}")#text(", and then letting ")#mi("{g(x)}")#text(" the minimal element of ")#mi("{Y}")#text(" for which ")#mi("{(x,g(x)) \\in E}")#text(".")

#text("Let ")#mi("{N}")#text(" be a large integer (which will depend on ")#mi("{k}")#text(" and the cardinality ")#mi("{M}")#text(" of ")#mi("{Y}")#text(") to be chosen later. Because ")#mi("{X}")#text(" obeys the multiple recurrence theorem, we can find a positive integer ")#mi("{n}")#text(" and ")#mi("{x \\in X}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("x, T^n x, T^{2n} x, \\ldots, T^{(N-1) n} x \\in F.")]]

#text("Now consider the sequence of ")#mi("{N}")#text(" points")

#align(center)[#tao-fit-display[#mitex("S^{-mn}( T^{mn} x, g(T^{mn} x) )")]]

#text("for ")#mi("{m = 0,\\ldots,N-1}")#text(". From ")#link(<tao-a4cf5e703ea05d936c9c>)[#text("(1)")]#text(", we see that ")#metadata(none) <tao-e96e02d8e47f2a7c03be>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("S^{-mn}( T^{mn} x, g(T^{mn} x) ) = (x, c(m))")]]

#text("for some sequence ")#mi("{c(0),\\ldots,c(N-1) \\in Y}")#text(". This can be viewed as a colouring of ")#mi("{\\{0,\\ldots,N-1\\}}")#text(" by ")#mi("{M}")#text(" colours, where ")#mi("{M}")#text(" is the cardinality of ")#mi("{Y}")#text(". Applying ")#link("http://en.wikipedia.org/wiki/Van_der_Waerden%27s_theorem")[#text("van der Waerden’s theorem")]#text(", we conclude (if ")#mi("{N}")#text(" is sufficiently large depending on ")#mi("{k}")#text(" and ")#tao-math("{\\left|Y\\right|}", block: false)#text(") that there is an arithmetic progression ")#mi("{a, a+r,\\ldots,a+(k-1)r}")#text(" in ")#mi("{\\{0,\\ldots,N-1\\}}")#text(" with ")#mi("{r>0}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("c(a) = c(a+r) = \\ldots = c(a+(k-1)r) = c")]]

#text("for some ")#mi("{c \\in Y}")#text(". If we then let ")#mi("{y = (x,c)}")#text(", we see from ")#link(<tao-e96e02d8e47f2a7c03be>)[#text("(2)")]#text(" that")

#align(center)[#tao-fit-display[#mitex("S^{an + irn} y = ( T^{(a+ir)n} x, g(T^{(a+ir)n} x) ) \\in E")]]

#text("for all ")#mi("{i=0,\\ldots,k-1}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The precise connection between Lemma ")#link(<tao-e340ddbffe550c8b647b>)[#text("3")]#text(" and Proposition ")#link(<tao-d4f568b800c6a61b3ba2>)[#text("2")]#text(" arises from the following observation: with ")#mi("{E, F, g}")#text(" as in the proof of Proposition ")#link(<tao-d4f568b800c6a61b3ba2>)[#text("2")]#text(", and ")#mi("{x \\in X}")#text(", the set")

#align(center)[#tao-fit-display[#mitex("A := \\{ n \\in {\\bf Z}: T^n x \\in F \\}")]]

#text("can be partitioned into the classes")

#align(center)[#tao-fit-display[#mitex("A_i := \\{ n \\in {\\bf Z}: S^n (x,i) \\in E^{\\prime} \\}")]]

#text("where ")#mi("{E^{\\prime} := \\{ (x,g(x)): x \\in F \\} \\subset E}")#text(" is the graph of ")#mi("{g}")#text(". The multiple recurrence property for ")#mi("{X}")#text(" ensures that ")#mi("{A}")#text(" contains arbitrarily long arithmetic progressions, and so therefore one of the ")#mi("{A_i}")#text(" must also, which gives the multiple recurrence property for ")#mi("{Y}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" Compact extensions can be viewed as a generalisation of finite extensions, in which the fibres are no longer finite sets, but are themselves measure spaces obeying an additional property, which roughly speaking asserts that for many functions ")#mi("{f}")#text(" on the extension, the shifts ")#mi("{T^n f}")#text(" of ")#mi("{f}")#text(" behave in an almost periodic fashion on most fibres, so that the orbits ")#mi("{T^n f}")#text(" become totally bounded on each fibre. This total boundedness allows one to obtain an analogue of the above colouring map ")#mi("{c()}")#text(" to which van der Waerden’s theorem can be applied.")
]

#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/06/03/the-furstenberg-multiple-recurrence-theorem-and-finite-extensions/#comment-53795")[#strong[#text("Seventh Linkfest")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2011")]

#text("[…] Terence Tao: The Cotlar-Stein Lemma, Locally compact groups with faithful finite-dimensional representations, van Dantzig’s Theorem, The Furstenberg multiple recurrence theorem and finite extensions […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78f7e299f96dc2496345ee39db3b60b9b2c4d82789f9253b4f00f7474cf258fa-b1b06005f9a98f629fa9b48712e19202c09229059afad0d11317357c1c9b4e71.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/06/03/the-furstenberg-multiple-recurrence-theorem-and-finite-extensions/#comment-249996")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2013")])]

#text("I happend to login this website. Proposition 2 is also known by Kokoro Inoue in Israel J.Math, 2002.")

#text("Toshihiro Hamachi")
]
