// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/
// Converted to Typst by tao2typ: "2026-10-14T15:19:59.866184+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Lehmer pairs and GUE", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Lehmer pairs and GUE")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 January 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/")[#text("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In this post we assume the Riemann hypothesis and the simplicity of zeroes, thus the zeroes of ")#mi("{\\zeta}")#text(" in the critical strip take the form ")#mi("{\\frac{1}{2} \\pm i \\gamma_j}")#text(" for some real number ordinates ")#mi("{0 < \\gamma_1 < \\gamma_2 < \\dots}")#text(". From the ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93von_Mangoldt_formula")[#text("Riemann-von Mangoldt formula")]#text(", one has the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\gamma_n = (1+o(1)) \\frac{2\\pi}{\\log n} n")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text("; in particular, the spacing ")#mi("{\\gamma_{n+1} - \\gamma_n}")#text(" should behave like ")#mi("{\\frac{2\\pi}{\\log n}}")#text(" on the average. However, it can happen that some gaps are unusually small compared to other nearby gaps. For the sake of concreteness, let us define a ")#link("http://mathworld.wolfram.com/LehmersPhenomenon.html")[#text("Lehmer pair")]#text(" to be a pair of adjacent ordinates ")#mi("{\\gamma_n, \\gamma_{n+1}}")#text(" such that ")#metadata(none) <tao-3cebcc27f7e75c0f10e6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{1}{(\\gamma_{n+1} - \\gamma_n)^2} \\geq 1.3 \\sum_{m \\neq n,n+1} \\frac{1}{(\\gamma_m - \\gamma_n)^2} + \\frac{1}{(\\gamma_m - \\gamma_{n+1})^2}.")]]

#text("The specific value of constant ")#mi("{1.3}")#text(" is not particularly important here; anything larger than ")#mi("{\\frac{5}{4}}")#text(" would suffice. An example of such a pair would be the classical pair")

#tao-aligned(keep: true)[


#tao-math("\\gamma_{6709}  & = 7005.062866\\dots", block: true)



#tao-math("\\gamma_{6710}  & = 7005.100564\\dots", block: true)
]

#text("discovered by Lehmer. It follows easily from the main ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1260363")[#text("results of Csordas, Smith, and Varga")]#text(" that if an infinite number of Lehmer pairs (in the above sense) existed, then the de Bruijn-Newman constant ")#mi("{\\Lambda}")#text(" is non-negative. This implication is now redundant in view of the unconditional results of ")#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/")[#text("this recent paper of Rodgers and myself")]#text("; however, the question of whether an infinite number of Lehmer pairs exist remain open.")

#text("In this post, I sketch an argument that Brad and I came up with (as initially suggested ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1827160")[#text("by Odlyzko")]#text(") the GUE hypothesis implies the existence of infinitely many Lehmer pairs. We argue probabilistically: pick a sufficiently large number ")#mi("{T}")#text(", pick ")#mi("{n}")#text(" at random from ")#mi("{T \\log T}")#text(" to ")#mi("{2 T \\log T}")#text(" (so that the average gap size is close to ")#mi("{\\frac{2\\pi}{\\log T}}")#text("), and prove that the Lehmer pair condition ")#link(<tao-3cebcc27f7e75c0f10e6>)[#text("(1)")]#text(" occurs with positive probability.")

#text("Introduce the renormalised ordinates ")#mi("{x_n := \\frac{\\log T}{2\\pi} \\gamma_n}")#text(" for ")#mi("{T \\log T \\leq n \\leq 2 T \\log T}")#text(", and let ")#mi("{\\varepsilon > 0}")#text(" be a small absolute constant (independent of ")#mi("{T}")#text("). It will then suffice to show that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{(x_{n+1} - x_n)^2} \\geq")]]

#tao-aligned(keep: true)[


#tao-math("1.3 \\sum_{m \\in [T \\log T, 2T \\log T]: m \\neq n,n+1} \\frac{1}{(x_m - x_n)^2}  & + \\frac{1}{(x_m - x_{n+1})^2}", block: true)



#tao-math(" & + \\frac{1}{6\\varepsilon^2}", block: true)
]

#text("(say) with probability ")#mi("{\\gg \\varepsilon^4 - o(1)}")#text(", since the contribution of those ")#mi("{m}")#text(" outside of ")#mi("{[T \\log T, 2T \\log T]}")#text(" can be absorbed by the ")#mi("{\\frac{1}{\\varepsilon^2}}")#text(" factor with probability ")#mi("{o(1)}")#text(".")

#text("As one consequence of the GUE hypothesis, we have ")#mi("{x_{n+1} - x_n \\leq \\varepsilon^2}")#text(" with probability ")#mi("{O(\\varepsilon^6)}")#text(". Thus, if ")#mi("{E := \\{ m \\in [T \\log T, 2T \\log T]: x_{m+1} - x_m \\leq \\varepsilon^2 \\}}")#text(", then ")#mi("{E}")#text(" has density ")#mi("{O( \\varepsilon^6 )}")#text(". Applying the ")#link("https://en.wikipedia.org/wiki/Hardy%E2%80%93Littlewood_maximal_function")[#text("Hardy-Littlewood maximal inequality")]#text(", we see that with probability ")#mi("{O(\\varepsilon^6)}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\sup_{h \\geq 1} \\left| \\# E \\cap [n+h, n-h] \\right| \\leq \\frac{1}{10}", block: true)]]

#text("which implies in particular that")

#align(center)[#tao-fit-display[#tao-math("\\left|x_m - x_n\\right|, \\left|x_{m} - x_{n+1}\\right| \\gg \\varepsilon^2 \\left|m-n\\right|", block: true)]]

#text("for all ")#mi("{m \\in [T \\log T, 2 T \\log T] \\backslash \\{ n, n+1\\}}")#text(". This implies in particular that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{m \\in [T \\log T, 2T \\log T]: \\left|m-n\\right| \\geq \\varepsilon^{-3}} \\frac{1}{(x_m - x_n)^2} + \\frac{1}{(x_m - x_{n+1})^2} \\ll \\varepsilon^{-1}", block: true)]]

#text("and so it will suffice to show that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{(x_{n+1} - x_n)^2}")]]

#align(center)[#tao-fit-display[#tao-math("\\geq 1.3 \\sum_{m \\in [T \\log T, 2T \\log T]: m \\neq n,n+1; \\left|m-n\\right| < \\varepsilon^{-3}} \\frac{1}{(x_m - x_n)^2} + \\frac{1}{(x_m - x_{n+1})^2} + \\frac{1}{5\\varepsilon^2}", block: true)]]

#text("(say) with probability ")#mi("{\\gg \\varepsilon^4 - o(1)}")#text(".")

#text("By the GUE hypothesis (and the fact that ")#mi("{\\varepsilon}")#text(" is independent of ")#mi("{T}")#text("), it suffices to show that a Dyson sine process ")#mi("{(x_n)_{n \\in {\\bf Z}}}")#text(", normalised so that ")#mi("{x_0}")#text(" is the first positive point in the process, obeys the inequality ")#metadata(none) <tao-05669361000669df75ba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\frac{1}{(x_{1} - x_0)^2} \\geq 1.3 \\sum_{\\left|m\\right| < \\varepsilon^{-3}: m \\neq 0,1} \\frac{1}{(x_m - x_0)^2} + \\frac{1}{(x_m - x_1)^2}", block: true)]]

#text("with probability ")#mi("{\\gg \\varepsilon^4}")#text(". However, if we let ")#mi("{A > 0}")#text(" be a moderately large constant (and assume ")#mi("{\\varepsilon}")#text(" small depending on ")#mi("{A}")#text("), one can show using ")#mi("{k}")#text("-point correlation functions for the Dyson sine process (and the fact that the Dyson kernel ")#mi("{K(x,y) = \\sin(\\pi(x-y))/\\pi(x-y)}")#text(" equals ")#mi("{1}")#text(" to second order at the origin) that")

#tao-aligned(keep: true)[


#tao-math("{\\bf E} N_{[-\\varepsilon,0]} N_{[0,\\varepsilon]}  & \\gg \\varepsilon^4", block: true)



#tao-math("{\\bf E} N_{[-\\varepsilon,0]} \\binom{N_{[0,\\varepsilon]}}{2}  & \\ll \\varepsilon^7", block: true)



#tao-math("{\\bf E} \\binom{N_{[-\\varepsilon,0]}}{2} N_{[0,\\varepsilon]}  & \\ll \\varepsilon^7", block: true)



#tao-math("{\\bf E} N_{[-\\varepsilon,0]} N_{[0,\\varepsilon]} N_{[\\varepsilon,A^{-1}]}  & \\ll A^{-3} \\varepsilon^4", block: true)



#tao-math("{\\bf E} N_{[-\\varepsilon,0]} N_{[0,\\varepsilon]} N_{[-A^{-1}, -\\varepsilon]}  & \\ll A^{-3} \\varepsilon^4", block: true)
]

#metadata(none) <tao-1774b8eebdec58c5f119>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("{\\bf E} N_{[-\\varepsilon,0]} N_{[0,\\varepsilon]} N_{[-k, k]}^2 \\ll k^2 \\varepsilon^4")]]

#text("for any natural number ")#mi("{k}")#text(", where ")#mi("{N_{I}}")#text(" denotes the number of elements of the process in ")#mi("{I}")#text(". For instance, the expression ")#mi("{{\\bf E} N_{[-\\varepsilon,0]} \\binom{N_{[0,\\varepsilon]}}{2} }")#text(" can be written in terms of the three-point correlation function ")#mi("{\\rho_3(x_1,x_2,x_3) = \\mathrm{det}(K(x_i,x_j))_{1 \\leq i,j \\leq 3}}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\int_{-\\varepsilon \\leq x_1 \\leq 0 \\leq x_2 \\leq x_3 \\leq \\varepsilon} \\rho_3( x_1, x_2, x_3 )\\ dx_1 dx_2 dx_3")]]

#text("which can easily be estimated to be ")#mi("{O(\\varepsilon^7)}")#text(" (since ")#mi("{\\rho_3 = O(\\varepsilon^4)}")#text(" in this region), and similarly for the other estimates claimed above.")

#text("Since for natural numbers ")#mi("{a,b}")#text(", the quantity ")#mi("{ab - 2 a \\binom{b}{2} - 2 b \\binom{a}{2} = ab (5-2a-2b)}")#text(" is only positive when ")#mi("{a=b=1}")#text(", we see from the first three estimates that the event ")#mi("{E}")#text(" that ")#mi("{N_{[-\\varepsilon,0]} = N_{[0,\\varepsilon]} = 1}")#text(" occurs with probability ")#mi("{\\gg \\varepsilon^4}")#text(". In particular, by Markov’s inequality we have the conditional probabilities")

#tao-aligned(keep: true)[


#tao-math("{\\bf P} ( N_{[\\varepsilon,A^{-1}]} \\geq 1 | E )  & \\ll A^{-3}", block: true)



#tao-math("{\\bf P} ( N_{[-A^{-1}, -\\varepsilon]} \\geq 1 | E )  & \\ll A^{-3}", block: true)



#tao-math("{\\bf P} ( N_{[-k, k]} \\geq A k^{5/3} | E )  & \\ll A^{-4} k^{-4/3}", block: true)
]

#text("and thus, if ")#mi("{A}")#text(" is large enough, and ")#mi("{\\varepsilon}")#text(" small enough, it will be true with probability ")#mi("{\\gg \\varepsilon^4}")#text(" that")

#align(center)[#tao-fit-display[#mitex("N_{[-\\varepsilon,0]}, N_{[0,\\varepsilon]} = 1")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("N_{[A^{-1}, \\varepsilon]} = N_{[\\varepsilon, A^{-1}]} = 0")]]

#text("and simultaneously that")

#align(center)[#tao-fit-display[#mitex("N_{[-k,k]} \\leq A k^{5/3}")]]

#text("for all natural numbers ")#mi("{k}")#text(". This implies in particular that")

#align(center)[#tao-fit-display[#mitex("x_1 - x_0 \\leq 2\\varepsilon")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|x_m - x_0\\right|, \\left|x_m - x_1\\right| \\gg_A \\left|m\\right|^{3/5}", block: true)]]

#text("for all ")#mi("{m \\neq 0,1}")#text(", which gives ")#link(<tao-05669361000669df75ba>)[#text("(2)")]#text(" for ")#mi("{\\varepsilon}")#text(" small enough.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The above argument needed the GUE hypothesis for correlations up to fourth order (in order to establish ")#link(<tao-1774b8eebdec58c5f119>)[#text("(3)")]#text("). It might be possible to reduce the number of correlations needed, but I do not see how to obtain the claim just using pair correlations only.")
]

#heading(level: 1)[#text("Comments (28)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c9922ef884a925c2ef30bfd921c2576b8d7ce1f6e48fd33a485b6605d85d516-da74e966c9f95f06157b9459617424430f9f8a71219eb03c13f5cebdf36f5d44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zgtzsj")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491571")[#strong[#text("zgtzsj")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2018")])]

#text("The link to Riemann-von Mangoldt formula seems not correct. Should be this one: ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93von_Mangoldt_formula")[#text("https://en.wikipedia.org/wiki/Riemann%E2%80%93von_Mangoldt_formula")]

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c9922ef884a925c2ef30bfd921c2576b8d7ce1f6e48fd33a485b6605d85d516-da74e966c9f95f06157b9459617424430f9f8a71219eb03c13f5cebdf36f5d44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zgtzsj")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491692")[#strong[#text("zgtzsj")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2018")])]

#text("seems that you still haven’t changed it. It is: ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93von_Mangoldt_formula")[#text("https://en.wikipedia.org/wiki/Riemann%E2%80%93von_Mangoldt_formula")]

#emph[#text("[Should be OK now – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aula")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491587")[#strong[#text("Aula")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2018")])]

#text("In (1) the constant is 1.3 but in all later appearances it is 1.4. Also, there are two displays that are too wide to be shown completely; the second one is obvious because it cuts off in the middle of a fraction, but the first one looks fine until you start to wonder why it doesn’t have the error term mentioned in the text.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8fb88b9c85cff49905a4a08f9defee4345d1ae33aa4464a5fe3eb4e42104a258-cd26d923642a27fef48eb0d584bb97f78345d31bd21f420ab730f6276ba25739.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian Tennesob")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491597")[#strong[#text("Brian Tennesob")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2018")])]

#text("Hello professor Tao,")

#text("My name is Brian.")

#text("I only have a masters in math so I do not have a PhD. I can follow your arguments to some extent but as I have only taken a few analysis courses, I don’t fully comprehend everything here.")

#text("I was wondering how can I get up to speed on the Riemann hypothesis which seems that if it is true then it is only “barely so” as you explaned previously.")

#text("Do you think that is why it’s resolution has been so elusive over the years?")

#text("Also, I have another question and I hope it doesn’t appear as naive as I think it might sound to you.")

#text("I am very interested in automated theorem proving. There are many difficulties with ATP’s and proof assistants and the like. However with breakthroughs in machine learning, there has been some (but not much) discussion about applying machine learning to automated theorem provers, mainly in the heurisitcs of how the computer attempts to approach the proof.")

#text("Of course one extremely important problem is correctly formalizing the RH into a way the would avail itself to even begin the process of conducting a search for a proof of RH or the negation of RH, whatever the case may be. Also, even the best ATP might take longer than the age of the universe to decide RH or not RH. And, on top of all that, the proof or disproof of RH might be a proof that is so long that it takes petabytes upon petabytes to store in machine level formalized proof.")

#text("So from what little I know of analysis and automated theorem proving, deciding RH, even with the best heuristics and software, its proof may be literally impossible for even the smartest humans to ever check.")

#text("This kind of solution to RH would thus be extremely unsatisfying to me and probably everyone else who is involved in RH. And if no one can fully check the proof or disproof of RH, we humans will perhaps gain nothing at all from a formal proof that is petabytes in length, if it is even that small!")

#text("Do you think I should go for a PhD in an analysis-related field for RH, number theory, or (and this is going to sound dreadful) computer science?")

#text("Finally, if I did get so far as to have an ATP decide the RH, would I be eligible for the Clay institute’s $1,000,000 prize if my ATP’s proof is so long that no human can check it?")

#text("I hope this is the right place to ask due to the subject of the last two of your posts connected to the zeta function, though admittedly I am not asking about this post directly.")

#text("I appreciate your time. Though I don’t fully understand your post, I know just enough about writing proofs to be able to see that each and every one of your posts is literally a masters class in how to write sharp and elegant proofs, something that is way off from a brute force computer search for a decision on RH which, I am certain, would leave everyone quite unsatisfied to say the least!")

#text("In fact, even if my computer decided RH, I would not be very satisfied with such an inelegant proof!")

#text("Any thoughts at all that you might have would be immensely appreciated professor Tao and if you would be so kind as to provide me guidance by providing good references on RH or automated heorem proving, I would forever be in your debt.")

#text("Thanks, Brian")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-495205")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2018")])]

#text("Lot of downvotes, because a little bit of rambling, but the question is quite clear, I think, and fair:")

#text("Go with whatever you would go, if there was no Riemann Hypothesis. If you love math, then study pure math.")

#text("If your computer code, which eventually yields the RH, is very clear and bullet proof, then this will be a proof of the RH, and you will have proven the RH. And then get the price. The price doesn’t say anything about HOW you should proof it. A proof is a proof.")

#text("Now, whether your code will be a proof, it depends on the specific code. People don’t need to understand the write-up of the proof, if they can believe that the code checked it correctly.")

#text("Finally, there is no reason to believe that deep learning can prove anything (noteworthy). If you use classical approaches, where do you find the data which form the basis? Deep Learning in its classic form is only good at producing quickly a result, which a human with some time could produce himself.")

#text("Now, you could think about Reinforcement Learning, where you set up the reward function in such a way that you move towards the RH, but … , I dont see how…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68b2b057f9d296967dfbfd5c092a04c78fb1474b0d1a126ef6dbb482525770fc-965994263b210d9eeabf059f613992693973dd84a4480a0e645699950b6e521e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tennesb")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491599")[#strong[#text("tennesb")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2018")])]

#text("Reblogged this on ")#link("https://briantenneson.wordpress.com/2018/01/21/lehmer-pairs-and-gue/")[#text("briantenneson")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a830450fdc42640734c399aefa8d8f69203b5cf003a6fb3d85c05a81a6dcced-6aa92d6fbc6161814fa75065d6b8ebec555852a948f8c3d0155ac32fac6aeb95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491600")[#strong[#text("Joseph")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2018")])]

#text("I think that 3-correlations are sufficient: we can remove the square in (3), getting a bound with ")#mi("k")#text(" instead of ")#mi("k^2")#text(". We can then deduce in the same way, with large conditional probability given ")#mi("E")#text(", the bound ")#mi("N_{[-k,k]} \\leq A k ^{5/3}")#text(" for ")#mi("k")#text(" equal to (say) a power of two. This gives ")#mi("N_{[-k,k]} \\leq A (2k)^{5/3}")#text(" for all integers ")#mi("k")#text(".")#linebreak()#text(" However, my guess would be that the pair correlations are not enough: it seems to me that one can respect these correlations with a point process such that small gaps come by groups of two.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491616")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2018")])]

#text("Nice! I forgot about the trick of sparsifying the ")#mi("k")#text(" to be dyadic (also the key trick in proving the strong law of large numbers). I think find your argument that pair correlations are not sufficient to be plausible, though I don’t know how to actually construct such a process as you describe…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6803f451a822a44c3357dffe0946273ac8b678c1381d8f6f15471f78bf5064e-c0cdd6fbf9fa11cb38f669d32e0c33214ced4ab5f9e837265aa2a25f482e13f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of BR")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491646")[#strong[#text("BR")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2018")])]

#text("To go at somewhat of a tangent, a related question is whether one can even write down a translation invariant point process with 1 and 2 level correlations mimicking the sine process but which is not actually the sine-process? (Leaving aside for the moment whether you can force small gaps to come in pairs.) That is, does there exist a translation invariant point process with configurations ")#mi("(\\xi_i)")#text(" such that")

#mi("\\mathbb{E} \\sum f(\\xi_i) = \\int f(x) dx")

#mi("\\mathbb{E} \\sum_{i\\neq j} f(\\xi_i,\\xi_j) = \\int f(x,y) \\Big{\\left[1-\\Big{\\left(\\frac{\\sin \\pi (x-y)}{\\pi (x-y)}\\right)} \\right]} \\, dx dy")

#text("which is not the sine process? I think almost certainly there exist processes of this sort, but constructing one seems difficult… Note that such a point process can’t be determinantal.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491618")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2018")])]

#text("Since an infinite number of Lehmer pairs (which now seems likely) imply that RH almost fails infinitely often, assuming RH is true, it means there is likely some deeper structure which prevents that from happening every time.")

#text("One relatively simpler but not rigorous argument seems to come from Riemann von Mangoldt formula. If there is a zero off the critical line, it would need an infinite number of counterparts on the same “off-line”, since a finite number of large oscillations would make the prime number distribution chaotic in small intervals. Also Ingham style results show that non-critical line zeroes have low density, which makes it even more difficult to have a complete off-line with infinite number of zeroes.")#linebreak()#text(" But it’s likely this structural constraint is already suspected. Is there a notion of a deeper constraint than this?")

#text("This situation seems analogous to Fermat’s last theorem where there are many near misses, but I think Wiles’ proof shows a strong geometric restriction and hence a structure against those.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491624")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2018")])]

#text("It think that a finite number of “large oscillations” (caused by a finite set of zeros attaining the supremum over the zeros real parts – which, in such a case, should be < 1) would make the primes distribution less chaotic asymptotically (with a much better finite series approximation in the PNT theorem). The observed chaotic behavior of the primes distribution over short intervals, seems to indicate that if the supremum of the zeros real parts is attained, it must be attained by infinitely many zeros.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491634")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2018")])]

#text("Well by chaotic behaviour in the RvM formula, I meant both large positive and negative deviations (greater than sqrt(x)) from the average x estimate occuring in a short range (x,x+h) where h could even be as low as 2 (such sharp reversals are of course not observed in reality). With a finite number of zeroes with large real parts, asymptotically the critical line zeroes will become irrelevant in RvM, and such reversals will occur infinitely often.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491635")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2018")])]

#text("The last line may need further elaboration. With an infinite number of zeroes with large supremum real part, such reversals can be mitigated. But the likelihood of having such a line is quite low.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491649")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2018")])]

#text("My vague feeling on this is that even though zeroes of the zeta function can occasionally be close to each other, there is a “repulsion” effect that keeps them from colliding off of the critical line and into the rest of the complex plane. Unfortunately, given the lack of dynamics in zeta (in particular, the lack of any time-like parameter one can vary), I can’t see any way to rigorously describe this repulsion. But it certainly exists in the random matrix models, see e.g. my previous blog post ")#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/")[#text("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/")]#text(" (or observe the repulsion term in the equations for Dyson Brownian motion). There is also the old Polya-Hilbert dream of somehow interpreting the zeroes of zeta as (a suitable renormalisation of) the eigenvalues of a self-adjoint operator, so that the self-adjointness would supply the constraint that keeps the zeroes on the critical line, even though they could still be permitted to approach each other. Perhaps one should proceed first by improving our understanding of the function field Riemann Hypothesis, which is actually a theorem…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491721")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2018")])]

#text("When it comes to transitioning results from function field settings to larger fields, there has been some great work going on recently, for eg. using perfectoid spaces for proving weight monodromy in p-adic fields, among other results. Do you think such ideas have potential for the more regular fields?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491747")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2018")])]

#text("I am not all that familiar with perfectoids, but as a general rule, progress in the function field case has mostly served as an analogy or guide for what ought to be true in the number field case (and vice versa), but it is rare that a technique that was first developed in function field settings has transferred over to the number field setting (though the converse seems to be significantly easier to accomplish), because number fields don’t seem to have as much geometric structure as function fields (e.g. no analogue of the Frobenius automorphism). (There is the dream of the “field of one element” being able to supply such geometric structure to number fields, but this is still largely a dream at the present time.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491756")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2018")])]

#text("I found the link I was referring to")

#link("http://www.math.uni-bonn.de/people/scholze/PerfectoidSpaces.pdf")[#text("Click to access PerfectoidSpaces.pdf")]

#text("The author mentions in the introduction, ‘aim of this paper is to establish a general framework for reducing certain problems about mixed")#linebreak()#text(" characteristic rings to problems about rings in characteristic p’, which I feel is quite exciting.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e129a68dcf0bb46ecba772753b8f9af1ec273d49cbd7ace8069058648b03b58-7eb33440dcbae163fc1d170d08c9c52deb82d4eb4253cf0fbe7e8b13997f3aa7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491640")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2018")])]

#text("I’m a bit confused as to how you get your third summation to be bounded by ")#mi("\\epsilon^{-1}")#text(". From the prior line, it looks like you should get ")#tao-math("\\epsilon^{-4} \\sum_{\\left|m-n\\right| > \\epsilon^{-1}} \\frac{1}{(m-n)^2}", block: false)#text(" — or a bound of ")#mi("\\epsilon^{-3}")#text(". That would mess up the argument completely, since you’re trying to show that the overall sum is bounded by ")#mi("\\epsilon^{-2}")#text(".")

#emph[#text("[Oops, the cutoff should have been at ")#mi("\\varepsilon^{-3}")#text(" rather than ")#mi("\\varepsilon^{-1}")#text("; should be fixed now. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeffrey Stopple")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491695")[#strong[#text("Jeffrey Stopple")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2018")])]

#text("I don’t recognize the notation ")#mi("N_{0,\\epsilon}")#text("? (I get that the bold E is expected value.)")

#emph[#text("[As stated in the text, ")#mi("N_I")#text(" denotes the number of zeroes in the interval ")#mi("I")#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e129a68dcf0bb46ecba772753b8f9af1ec273d49cbd7ace8069058648b03b58-7eb33440dcbae163fc1d170d08c9c52deb82d4eb4253cf0fbe7e8b13997f3aa7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491696")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2018")])]

#text("Okay — I’d like to track powers of \\epsilon in the last bit, especially when it comes to A. In your treatment, it looks like you’re formally treating A and \\epsilon as independent, but I’m not sure they are. If you want your probabilities to be \\gg \\epsilon^4, then for N_{[-k,k]} \\leq A k^{5/3}, you need A \\gg \\epsilon^{-1}.")

#text("Now, you conclude from the latter that |x_m – x_0| \\gg_A |m|^{3/5}. Let’s make the A-dependence explicit — |x_m – x_0| \\gg A^{-3/5} |m|^{3/5} with probability \\gg \\epsilon^4 if A \\gg \\epsilon^{-1}, so really |x_m – x_0| \\gg \\epsilon^{3/5} |m|^{3/5}.")

#text("Then the LHS of (2) is \\gg \\epsilon^{-2}, and the RHS is \\ll \\epsilon^{-6/5}, and everything checks out.")

#text("Cool!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491702")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2018")])]

#text("One does not need to take ")#mi("A")#text(" that large. As long as the conditional probabilities ")#mi("{\\bf P}(N_{[\\varepsilon, A^{-1}]} \\geq 1 | E)")#text(", ")#mi("{\\bf P}(N_{[-A^{-1}, -\\varepsilon]} \\geq 1 | E)")#text(", and ")#mi("{\\bf P}(N_{[-k,k]} \\geq A k^{5/3} | E)")#text(" (as ")#mi("k")#text(" ranges over the natural numbers) sum to less than (say) ")#mi("1/2")#text(", then on at least half of the event ")#mi("E")#text(" (and thus on an event of absolute probability ")#mi("\\gg \\varepsilon^4")#text("), one will have all the required properties. (As noted above by Joseph, one can do better here by restricting ")#mi("k")#text(" to be a power of 2, which is all that is needed for the rest of the argument.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e129a68dcf0bb46ecba772753b8f9af1ec273d49cbd7ace8069058648b03b58-7eb33440dcbae163fc1d170d08c9c52deb82d4eb4253cf0fbe7e8b13997f3aa7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491697")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2018")])]

#text("Note specifically that you can’t make A too large, as that shrinks |x_m – x_0| and increases the RHS of (2).")#linebreak()#text(" Fortunately the bound is A \\ll \\epsilon^{5/3}, which is larger than you need for your probabilities to work out.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92de18753b09812cfe78cbce04b76697dc7573ea3c4722016f2b8a9b4502f3a4-5e12eff0f87d0e218c957596559df00bf9c36b15eba61d0bb1667c6f3b57e4e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit Nair")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491724")[#strong[#text("Sujit Nair")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2018")])]

#text("If ")#mi("n")#text(" is picked at random from ")#mi("[T\\log T,2T \\log T]")#text(", then ")#mi("\\gamma_n")#text(" is in ")#mi("[2\\pi T, 4\\pi T]")#text(".")

#text("Does this imply that something like Bertrand’s postulate also holds true for the Riemann zeros, i.e., there is always a zero in ")#mi("[2\\pi T, 4\\pi T]")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491740")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2018")])]

#text("For ")#mi("T")#text(" large enough, certainly, but not for very small ")#mi("T")#text("; for instance, there is no non-trivial zero of height between zero and ")#mi("\\gamma_1 = 14.13\\dots")#text(". (But presumably one has a Bertrand-like result once ")#mi("4\\pi T")#text(" exceeds ")#mi("\\gamma_1")#text(", which can probably be derived from effective versions of the Riemann-von Mangoldt formula, combined with some numerical verification for medium values of ")#mi("T")#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491893")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2018")])]

#text("A question regarding the GUE analogy: I suppose you can apply the heat kernet to the set of eigenvalues of a random GUE matrix. Is there a nice way to describe the outcome as actual eigenvalues for some noisy version of the random matrix?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491894")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2018")])]

#text("Nice question! My immediate guess would be no – most ensembles of real numbers don’t have a good random matrix theory interpretation, especially if there isn’t any nice structure such as determinantal structure (and I’m pretty sure applying heat flow to the characteristic polynomial of GUE will not yield a determinantal point process). Even if a matrix model did exist, it would be hard to find – I think for instance that there are random matrix models for beta ensembles for the non-classical values ")#mi("\\beta \\neq 1,2,4")#text(", but they are not immediately obvious (nor do they resemble GUE, GOE, or GSE in the classical cases); see ")#link("https://arxiv.org/abs/math-ph/0206043")[#text("https://arxiv.org/abs/math-ph/0206043")]#text(" .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-491908")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2018")])]

#text("Many thanks for the answer. It might be the case that heat-kernel eigenvalues correspond not to the eigenvalues of a single noisy random version of the matrix but to the expectation (or something like it) of the eigenvalues over noisy versions of the random version. The simplest such gadget would be to take the expected eigenvalues of ")#mi("aA+bN")#text(" where ")#mi("A")#text(" is the random GUE matrix, ")#mi("B")#text(" is an independent random GUE matrix, ")#mi("a=\\sqrt {1-b^2}")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/01/20/lehmer-pairs-and-gue/#comment-505899")[#strong[#text("Watching Over the Zeroes | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2018")]

#text("[…] argument that the RH is false. In January of this year, Brad Rogers and Terence Tao turned up the heat on this connection by proving that the GUE conjecture entails the existence of infinitely many […]")
]
