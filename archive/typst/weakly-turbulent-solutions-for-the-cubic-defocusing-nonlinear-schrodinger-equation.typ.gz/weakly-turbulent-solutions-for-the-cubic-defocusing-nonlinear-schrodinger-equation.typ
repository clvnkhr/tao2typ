// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/08/14/weakly-turbulent-solutions-for-the-cubic-defocusing-nonlinear-schrodinger-equation/
// Converted to Typst by tao2typ: "2026-10-14T07:02:39.034746+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Weakly turbulent solutions for the cubic defocusing nonlinear Schrödinger equation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Weakly turbulent solutions for the cubic defocusing nonlinear Schrödinger equation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 August 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/08/14/weakly-turbulent-solutions-for-the-cubic-defocusing-nonlinear-schrodinger-equation/")[#text("https://terrytao.wordpress.com/2008/08/14/weakly-turbulent-solutions-for-the-cubic-defocusing-nonlinear-schrodinger-equation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.toronto.edu/colliand/")[#text("Jim Colliander")]#text(", ")#link("http://www.math.umn.edu/~keel/")[#text("Mark Keel")]#text(", ")#link("http://www-math.mit.edu/~gigliola/")[#text("Gigliola Staffilani")]#text(", ")#link("http://www.math.kobe-u.ac.jp/HOME/takaoka/takaoka.html")[#text("Hideo Takaoka")]#text(", and I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" the paper “")#link("http://arxiv.org/abs/0808.1742")[#text("Weakly turbulent solutions for the cubic defocusing nonlinear Schrödinger equation")]#text("“, which we have submitted to ")#link("http://www.springer.com/math/journal/222")[#text("Inventiones Mathematicae")]#text(". This paper concerns the numerically observed phenomenon of ")#emph[#text("weak turbulence")]#text(" for the ")#link("http://tosio.math.toronto.edu/wiki/index.php/Cubic_NLS_on_2d_manifolds")[#text("periodic defocusing cubic non-linear Schrödinger equation")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("-i u_t + \\Delta u = \\left|u\\right|^2 u", block: true)]]

#text("in two spatial dimensions, thus u is a function from ")#mi("{\\Bbb R} \\times {\\Bbb T}^2")#text(" to ")#mi("{\\Bbb C}")#text(". This equation has three important conserved quantities: the ")#emph[#text("mass")]

#align(center)[#tao-fit-display[#tao-math("M(u) = M(u(t)) := \\int_{{\\Bbb T}^2} \\left|u(t,x)\\right|^2\\ dx", block: true)]]

#text("the ")#emph[#text("momentum")]

#align(center)[#tao-fit-display[#mitex("\\vec p(u) = \\vec p(u(t)) = \\int_{{\\Bbb T}^2} \\text{Im}( \\nabla u(t,x) \\overline{u(t,x)} )\\ dx")]]

#text("and the ")#emph[#text("energy")]

#align(center)[#tao-math("E(u) = E(u(t)) := \\int_{{\\Bbb T}^2} \\frac{1}{2} \\left|\\nabla u(t,x)\\right|^2 + \\frac{1}{4} \\left|u(t,x)\\right|^4\\ dx", block: false)#text(".")]

#text("(These conservation laws, incidentally, are related to the basic symmetries of phase rotation, spatial translation, and time translation, via ")#link("http://en.wikipedia.org/wiki/Noether%27s_theorem")[#text("Noether’s theorem")]#text(".) Using these conservation laws and some standard PDE technology (specifically, some Strichartz estimates for the periodic Schrödinger equation), one can establish global wellposedness for the initial value problem for this equation in (say) the smooth category; thus for every smooth ")#mi("u_0: {\\Bbb T}^2 \\to {\\Bbb C}")#text(" there is a unique global smooth solution ")#mi("u: {\\Bbb R} \\times {\\Bbb T}^2 \\to {\\Bbb C}")#text(" to (1) with initial data ")#mi("u(0,x) = u_0(x)")#text(", whose mass, momentum, and energy remain constant for all time.")

#text("However, the mass, momentum, and energy only control three of the infinitely many degrees of freedom available to a function on the torus, and so the above result does not fully describe the dynamics of solutions over time. In particular, the three conserved quantities inhibit, but do not fully prevent the possibility of a ")#emph[#text("low-to-high frequency cascade")]#text(", in which the mass, momentum, and energy of the solution remain conserved, but shift to increasingly higher frequencies (or equivalently, to finer spatial scales) as time goes to infinity. This phenomenon has been observed numerically, and is sometimes referred to as ")#emph[#text("weak turbulence")]#text(" (in contrast to ")#emph[#text("strong turbulence")]#text(", which is similar but happens within a finite time span rather than asymptotically).")

#text("To illustrate how this can happen, let us normalise the torus as ")#mi("{\\Bbb T}^2 = ({\\Bbb R}/2\\pi {\\Bbb Z})^2")#text(". A simple example of a frequency cascade would be a scenario in which solution ")#mi("u(t,x) = u(t,x_1,x_2)")#text(" starts off at a low frequency at time zero, e.g. ")#mi("u(0,x) = A e^{i x_1}")#text(" for some constant amplitude A, and ends up at a high frequency at a later time T, e.g. ")#mi("u(T,x) = A e^{i N x_1}")#text(" for some large frequency N. This scenario is consistent with conservation of mass, but not conservation of energy or momentum and thus does not actually occur for solutions to (1). A more complicated example would be a solution supported on two low frequencies at time zero, e.g. ")#mi("u(0,x) = A e^{ix_1} + A e^{-ix_1}")#text(", and ends up at two high frequencies later, e.g. ")#mi("u(T,x) = A e^{iNx_1} + A e^{-iNx_1}")#text(". This scenario is consistent with conservation of mass and momentum, but not energy. Finally, consider the scenario which starts off at ")#mi("u(0,x) = A e^{i Nx_1} + A e^{iNx_2}")#text(" and ends up at ")#mi("u(T,x) = A + A e^{i(N x_1 + N x_2)}")#text(". This scenario is consistent with all three conservation laws, and exhibits a mild example of a low-to-high frequency cascade, in which the solution starts off at frequency N and ends up with half of its mass at the slightly higher frequency ")#mi("\\sqrt{2} N")#text(", with the other half of its mass at the zero frequency. More generally, given four frequencies ")#mi("n_1, n_2, n_3, n_4 \\in {\\Bbb Z}^2")#text(" which form the four vertices of a rectangle in order, one can concoct a similar scenario, compatible with all conservation laws, in which the solution starts off at frequencies ")#mi("n_1, n_3")#text(" and propagates to frequencies ")#mi("n_2, n_4")#text(".")

#text("One way to measure a frequency cascade quantitatively is to use the Sobolev norms ")#mi("H^s({\\Bbb T}^2)")#text(" for ")#mi("s > 1")#text("; roughly speaking, a low-to-high frequency cascade occurs precisely when these Sobolev norms get large. (Note that mass and energy conservation ensure that the ")#mi("H^s({\\Bbb T}^2)")#text(" norms stay bounded for ")#mi("0 \\leq s \\leq 1")#text(".) For instance, in the cascade from ")#mi("u(0,x) = A e^{i Nx_1} + A e^{iNx_2}")#text(" to ")#mi("u(T,x) = A + A e^{i(N x_1 + N x_2)}")#text(", the ")#mi("H^s({\\Bbb T}^2)")#text(" norm is roughly ")#mi("2^{1/2} A N^s")#text(" at time zero and ")#mi("2^{s/2} A N^s")#text(" at time T, leading to a slight increase in that norm for ")#mi("s > 1")#text(". Numerical evidence then suggests the following")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture.")]#text(" (Weak turbulence) There exist smooth solutions ")#mi("u(t,x)")#text(" to (1) such that ")#tao-math("\\left\\|u(t)\\right\\|_{H^s({\\Bbb T}^2)}", block: false)#text(" goes to infinity as ")#mi("t \\to \\infty")#text(" for any ")#mi("s > 1")#text(".")
]

#text("We were not able to establish this conjecture, but we have the following partial result (“weak weak turbulence”, if you will):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem.")]#text(" Given any ")#mi("\\varepsilon > 0, K > 0, s > 1")#text(", there exists a smooth solution ")#mi("u(t,x)")#text(" to (1) such that ")#tao-math("\\left\\|u(0)\\right\\|_{H^s({\\Bbb T}^2)} \\leq \\epsilon", block: false)#text(" and ")#tao-math("\\left\\|u(T)\\right\\|_{H^s({\\Bbb T}^2)} > K", block: false)#text(" for some time T.")
]

#text("This is in marked contrast to (1) in one spatial dimension ")#mi("{\\Bbb T}")#text(", which is completely integrable and has an infinite number of conservation laws beyond the mass, energy, and momentum which serve to keep all ")#mi("H^s({\\Bbb T}^2)")#text(" norms bounded in time. It is also in contrast to the linear Schrödinger equation, in which all Sobolev norms are preserved, and to the non-periodic analogue of (1), which is conjectured to disperse to a linear solution (i.e. to scatter) from any finite mass data (see ")#link("https://terrytao.wordpress.com/2007/07/23/the-cubic-nonlinear-schrodinger-equation-in-two-dimensions-with-radial-data/")[#text("this earlier post")]#text(" for the current status of that conjecture). Thus our theorem can be viewed as evidence that the 2D periodic cubic NLS does not behave at all like a completely integrable system or a linear solution, even for small data. (An earlier ")#link("http://www.ams.org/mathscinet-getitem?mr=1465602")[#text("result of Kuksin")]#text(" gives (in our notation) the weaker result that the ratio ")#tao-math("\\left\\|u(T)\\right\\|_{H^s({\\Bbb T}^2)} / \\left\\|u(0)\\right\\|_{H^s({\\Bbb T}^2)}", block: false)#text(" can be made arbitrarily large when ")#mi("s > 1")#text(", thus showing that large initial data can exhibit movement to higher frequencies; the point of our paper is that we can achieve the same for arbitrarily small data.) Intuitively, the problem is that the torus is compact and so there is no place for the solution to disperse its mass; instead, it must continually interact nonlinearly with itself, which is what eventually causes the weak turbulence.")

#metadata(none) <tao-789365447b681b22396b>

#text("As mentioned earlier, the three conservation laws of mass, momentum, and energy work to inhibit the low-to-high frequency cascade necessary to prove the theorem. For instance, one can easily show that any cascade involving three or fewer frequencies is morally incompatible with the three conservation laws (since three equations in three unknowns gives basically just one possible value for the amplitudes at the three frequencies). The simplest cascade is the four-wave model discussed earlier, in which four frequencies at the corners of a rectangle transfer their mass, energy, and momentum from two diagonally opposite corners to the other two diagonally opposite corners. One can in fact rigorously show that such four-wave cascades (plus negligible noise terms) can actually occur in (1) in the high frequency limit, by using perturbation theory to eliminate all frequencies except the four frequencies of the rectangle (thus reducing the PDE to an ODE), using symmetry to assume that diagonally opposite frequencies have the same Fourier coefficients, and then using the conservation laws to reduce the dimension of the ODE down to a scalar first-order ODE that can be solved more or less exactly. The dynamics of the resulting solution (for the model ODE, rather than the PDE that it approximates) resembles an “Arnold whisker” in the theory of Arnold diffusion – it asymptotically converges to a “two-wave” periodic orbit based on one diagonal of the rectangle as ")#mi("t \\to -\\infty")#text(", and to a two-wave periodic orbit on the other diagonal as ")#mi("t \\to +\\infty")#text(", lying in the unstable manifold of the former orbit and stable manifold of the latter.")

#text("This four-wave solution can be constructed from arbitrarily small initial data, but it only gets us a little way towards our theorem, as it only bumps up the ")#mi("H^s")#text(" norm by a factor of about ")#mi("2^{(s-1)/2}")#text(". To establish the theorem, we needed to chain a lot of these four-wave solutions together, in the spirit of the classic ")#link("http://www.ams.org/mathscinet-getitem?mr=163026")[#text("paper of Arnold")]#text(" that established the possibility of diffusion from one invariant torus in a certain Hamiltonian system to another. In terms of the approximating ODE (which was now more complicated, although still manageable thanks to symmetry reductions), the main task was to concoct a solution that started out near one invariant torus, bounced towards another torus, did a ricochet off of that to the next torus, and so on until one reached a torus extremely far away from the original torus. The best way we could describe this procedure succinctly was by citing a classic Super Bowl commercial for McDonald’s featuring Michael Jordan and Larry Bird:")

#text("(This citation, of course, appears in the bibliography to the paper, like any other reference.)")

#text("Actually showing such a solution exists turned out to require a very delicate stability and control theory analysis, in which stable, neutral, and unstable directions were treated in very different ways. As one might imagine, the initial data has to be extremely special in order to obtain a multi-ricochet solution.")

#text("Once such a solution for the approximating ODE is constructed, one still has to embed it somehow back into the PDE (1). Here one faces a combinatorial and number-theoretic problem of being able to place a large number of frequencies in the lattice ")#mi("{\\Bbb Z}^2")#text(", such that certain specific quadruples of these frequencies form rectangles, and all other quadruples do not. [The frequencies turn out to be organised in a series of “generations”, in which a pair of “parent” frequencies from each generation pass on their mass to a pair of “child” frequencies to the next generation, with one child inheriting virtually all of the energy, and the other child inheriting close to nothing; the children in that generation then pair up and become parents themselves, and so forth. In the first generation, all frequencies initially have the same energy (having comparable magnitudes and amplitudes), but by the end of the process, almost all the energy in the last generation is concentrated in a single, extremely large, frequency.] As is well known, the problem of constructing rectangles in the lattice is closely related to that of constructing ")#link("http://en.wikipedia.org/wiki/Pythagorean_triple")[#text("Pythagorean triples")]#text(" ")#mi("a^2+b^2=c^2")#text(", and so our construction ultimately relies on some basic facts about those triples (basically, we need that the unit vectors ")#mi("(a/c, b/c)")#text(" arising from Pythagorean triples are dense on the unit circle).")

#text("There are still some further directions to pursue here. Most obviously, the conjecture stated above remains open; the perturbation theory we use stops working after a long, but finite, amount of time, which has prevented us so far from resolving the conjecture, though the task may not be completely hopeless with current technology. The other thing is that the solutions we construct for our Theorem, much like the shots in the above video, are ")#emph[#text("extremely")]#text(" special, and do not really indicate what is going on for generic data. The only non-trivial result we have for such data is that they do not scatter to a linear solution even after quotienting out by phase rotations, unless they are one of the explicit “one-wave” solutions ")#tao-math("u(t,x) = A e^{i(\\left|n\\right|^2 t + n \\cdot x - A^2 t + \\theta)}", block: false)#text(". This is done by a simple compactness argument involving, of all things, ")#link("http://en.wikipedia.org/wiki/Liouville%27s_theorem_(complex_analysis)")[#text("Liouville’s theorem")]#text(" that harmonic functions of polynomial growth are in fact polynomial.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/14/weakly-turbulent-solutions-for-the-cubic-defocusing-nonlinear-schrodinger-equation/#comment-32062")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2008")])]

#text("Dear Professor Tao,")

#text("Will you begin accepting requests for items/persons that we would like to see cited in your research papers? :-D")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2008/08/14/weakly-turbulent-solutions-for-the-cubic-defocusing-nonlinear-schrodinger-equation/#comment-32087")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2008")])]

#text("Dear Prof. Tao,")

#text("Thank you very much for your so nice blog!")

#text("I have several questions (probably stupid) about this article:")

#text("1. Now a lot of people are working on NLS, what is the motivation for studying NLS?")

#text("2. Under the Fourier transform, we obtain a very complex ODE from NLS. My understanding is you construct in this article a very special solution according to the three conservation laws, do we have any other solutions with the three conservation laws holding?")

#text("3. Is the stable directions in the article is the high frequency Fourier modes? (My understanding is when Fourier modes are very high, the linear part (Laplacian) could probably control the nonlinear terms).")

#text("Thanks a lot,")

#text("Yours sincerely,")

#text("PDEbeginner")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/14/weakly-turbulent-solutions-for-the-cubic-defocusing-nonlinear-schrodinger-equation/#comment-32090")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2008")])]

#text("Dear PDEbeginner,")

#text("I think there are two main reasons NLS is studied. Firstly, it is one of the simplest and most symmetric models of nonlinear dispersion and soliton formation, and it has turned out that many insights, methods, and techniques were first developed for NLS and then later generalised to other models. Secondly, NLS is an approximating model for a variety of systems in physics, most notably Bose-Einstein condensates but also various plasma fields and meson fields.")

#text("There are of course an infinite-dimensional family of solutions to NLS, wandering around in an infinite dimensional phase space; the three conservation laws cut down the dimension of this space by three, but this still leaves a lot of room to move around. But if one can restrict the number of active frequencies to a sufficiently small number, and also impose as much symmetry as one can, then one can reduce to a reasonably manageable ODE, with relatively few degrees of freedom, to describe the evolution. This is what we do in our paper, but even within that simplified dynamics, the multi-ricochet solution is extremely special, with initial data lying in a very small (but open) portion of phase space.")

#text("We don’t understand very well what happens for general solutions, though Bourgain and Kuksin (and later Tzvetkov) have constructed invariant measures for the flow here, which may well capture the “generic” behaviour of the solution (though very little is known as to how unique these measures are, and whether they are attractors in any sense).")

#text("It is true in general that for subcritical equations (such as 2D cubic NLS), the high frequency components of the solution act in a nearly linear manner for short periods of time, and in non-periodic settings these components tend to disperse to infinity, escaping the region of nonlinear effects, and thus scatter to a linear solution for large times. In the periodic setting, though, dispersion to infinity is impossible, and the high-frequency components have to stick around and interact with other frequencies indefinitely. As such, they will eventually experience nonlinear effects, although it can take some time for this to happen. (In our model, we have components with a large frequency ~N and a small amplitude ")#mi("\\sim N^{-s}")#text(" (in order to keep the ")#mi("H^s")#text(" norm bounded), and it takes about ")#mi("T \\sim N^{2s}")#text(" units of time before nonlinear effects begin to make their presence felt.) Because of this, we end up renormalising away the dispersive effects of the linear evolution when transforming from the PDE to the ODE, and indeed the latter only exhibit the “resonant” effects of the nonlinearity and no linear effects whatsoever. So the stability and instability is caused purely by the nonlinearity. A toy “two-generation” example of this ODE, by the way, is the ")#mi("2 \\times 2")#text(" system")

#tao-math("-i\\partial_t b_0 = -\\left|b_0\\right|^2 b_0 + 2 b_1^2 \\overline{b_1}", block: false)

#tao-math("-i\\partial_t b_1 = -\\left|b_1\\right|^2 b_1 + 2 b_0^2 \\overline{b_0}", block: false)#text(".")

#text("There are two special periodic solutions here, ")#mi("(b_0(t),b_1(t)) = (e^{-it},0)")#text(" and ")#mi("(b_0(t),b_1(t)) = (0,e^{-it})")#text(", which trace out two invariant tori (or just invariant circles, actually). But it turns out that there is a “slider” solution")

#mi("\\displaystyle (b_0(t), b_1(t)) = \\left( \\frac{e^{-it} \\omega}{\\sqrt{1+e^{2\\sqrt{3}t}}}, \\frac{e^{-it} \\omega^2}{\\sqrt{1+e^{-2\\sqrt{3}t}}}\\right),")

#text("where ")#mi("\\omega = e^{2\\pi i/3}")#text(" is a cube root of unity, which is repelled exponentially fast away from the first invariant torus and is attracted exponentially fast to the second torus, lying as it does in the unstable manifold of the latter and stable manifold of the former. This slider solution forms the model for one “hop” of our eventual multi-hop solution from one torus to the next that exhibits the turbulence, though we have to perturb this solution in just the right way in order to set up the “shot”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2008/08/14/weakly-turbulent-solutions-for-the-cubic-defocusing-nonlinear-schrodinger-equation/#comment-32093")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2008")])]

#text("Dear Prof. Tao,")

#text("Thank you very much for your so detailed answer!")

#text("I have carefully read the answer, but still have some problems:")

#text("1. Did Bourgain and Kuksin construct the invariant measure on some subspace of ")#mi("H^s")#text("? (Because you asked if the invariant measures are attractors) .")

#text("2. 2D NLS is subcritical in the Sobolev space of ")#mi("H^s (s>0)")#text("? It seems it is critical in ")#mi("L^2")#text(".")

#text("3. I still didn’t understand the time ")#mi("N^{2s}")#text(" for the nonlinearity made felt. I was wondering if you could explain it in a little more detail or give some literatures to understand it.")

#text("4. There seems some problems for the toy models:")

#text("(1) the equations have no interacting terms.")

#text("(2) the two special solutions don’t solve the second equation (it seems we need to change the equations and add some interacting terms)")

#text("(3) for the ’slider solution’, when ")#mi("t=0")#text(", ")#mi("b_1(t)=\\infty")#text(", shall we change it as ")#mi("e^{it}\\omega^2 \\sqrt{1-e^{-2\\sqrt{3}t}}")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/14/weakly-turbulent-solutions-for-the-cubic-defocusing-nonlinear-schrodinger-equation/#comment-32097")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2008")])]

#text("Dear PDEbeginner,")

#text("There were some sign errors in my earlier comment which I think I have corrected now.")

#text("Regarding subcriticality, this is with respect to the regularity class of the initial data, in this case ")#mi("H^s")#text(". To see the time scale ")#mi("N^{2s}")#text(" emerging from initial data of frequency N and amplitude ")#mi("N^{-s}")#text(", e.g. ")#mi("u(0,x) = N^{-s} e^{i Nx_1}")#text(", observe that the cubic nonlinearity ")#tao-math("\\left|u\\right|^2 u", block: false)#text(" is about ")#mi("N^{-2s}")#text(" as large as u itself, and so by inspecting the NLS equation we expect the nonlinear effects to become significant by time ")#mi("N^{2s}")#text(". In this particular case we can also see this time scale by comparing the linear solution ")#mi("N^{-s} e^{i N x_1} e^{i N^2 t}")#text(" from this data with the nonlinear solution ")#mi("N^{-s} e^{iN x_1} e^{iN^2 t} e^{i N^{-2s} t}")#text(".")

#text("Regarding what it means for a measure to be an attractor, this is a little different from what it means for a set to be an attractor, and would presumably be stated in some sort of statistical mechanics sense, for instance one might start with a random ensemble of data, evolve it with some stochastic forcing term, and ask whether the probability distribution of that ensemble converges (in some suitable topology) to one of the standard invariant measures. This type of result is already difficult at the level of ODE and is probably a little bit beyond our current technology for dispersive PDE, though perhaps not hopelessly so.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/14/weakly-turbulent-solutions-for-the-cubic-defocusing-nonlinear-schrodinger-equation/#comment-32102")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2008")])]

#text("Dear Prof. Tao,")

#text("Now I understand much more on the toy model and the time scale. Thank you so much for your help and your patience!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/297ba35fceba57126d9613193c7cd9b835407adfe13d536390a27ced310e32e2-a380eea33e7db527042e9dcd6848d8e1ec0adf2e9b8d886dab8b90081140dfe3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter")]], [#link("https://terrytao.wordpress.com/2008/08/14/weakly-turbulent-solutions-for-the-cubic-defocusing-nonlinear-schrodinger-equation/#comment-32149")[#strong[#text("Peter")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2008")])]

#text("Is there any hope of taking some kind of limit of solutions with a finite number of ricochets to obtain a solution with an infinite number of ricochets?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/14/weakly-turbulent-solutions-for-the-cubic-defocusing-nonlinear-schrodinger-equation/#comment-32222")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2008")])]

#text("Dear Peter,")

#text("That’s a good question. At the level of the model ODE, I think we can construct a solution which has an infinite number of richochets (over an infinite period of time), but it is extremely unstable, and as such I don’t think we can use perturbation theory to create a corresponding solution to the PDE with infinitely many ricochets. (Also, the number theoretic portion of the argument only allows one to embed in finitely many dimensions of the ODE into the PDE at a time; if one wants more ricochets, one has to use a different embedding involving many more (and much larger) frequencies.)")

#text("It’s perhaps possible that taking some sort of superposition of the finitely richocheting solutions, that one could create a solution that is weakly turbulent, but a nontrivial amount of perturbation theory would still be needed as the underlying equation is nonlinear and so does not perfectly obey the principle of superposition.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5a2b3e0f59bce690471944b686d95b66061e80b0c7b8a54602cb6dab01b3f725-e67d7a9d2237ebdf48c3690b19a6af90d1c4e21d4917735de9b07adabd72ff62.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blogging Professors: Big Boffins with Blogs « O’Really? at Duncan.Hull.name")]], [#link("https://terrytao.wordpress.com/2008/08/14/weakly-turbulent-solutions-for-the-cubic-defocusing-nonlinear-schrodinger-equation/#comment-32570")[#strong[#text("Blogging Professors: Big Boffins with Blogs « O’Really? at Duncan.Hull.name")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2008")])]

#text("[…] What’s new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d06299797b9fca591bc5534f9523312f8c374e1fa795c163b19dd3e733c84e35-6844ad4992191b1d90536e8a0039bdd993790e28334dcabc7521a650d39d5aae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M. Majdoub")]], [#link("https://terrytao.wordpress.com/2008/08/14/weakly-turbulent-solutions-for-the-cubic-defocusing-nonlinear-schrodinger-equation/#comment-32592")[#strong[#text("M. Majdoub")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2008")])]

#text("Dear Prof. Tao,")

#text("I have two questions:")

#text("1. Have you an example where the conjecture is true?")

#text("2. It seems that your result “weak weak turbulence” still holds for other examples of NLS. What do you think?")

#text("Thanks a lot,")

#text("M. Majdoub")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/14/weakly-turbulent-solutions-for-the-cubic-defocusing-nonlinear-schrodinger-equation/#comment-32594")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2008")])]

#text("Dear M. Majdoub,")

#text("There are slightly artificial examples of Hamiltonian systems that have been shown to exhibit weak turbulence properties, but I do not know of a “natural” dispersive PDE (such as NLS) for which this result is known (excepting of course those equations which can develop singularities in finite time). Nevertheless it is reasonable to expect that any natural dispersive PDE on bounded domains which is not completely integrable and which does not develop singularities in finite time, should exhibit weak turbulence for generic choices of initial data.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98b23c4196acfa6564ef5e79617da921ba376cc06723917873a9fd534ddad830-bdfafe91a20c3eb367174102f902fa706e1cccf18d79facb38e10ae44e3af1db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Hillman")]], [#link("https://terrytao.wordpress.com/2008/08/14/weakly-turbulent-solutions-for-the-cubic-defocusing-nonlinear-schrodinger-equation/#comment-32656")[#strong[#text("Chris Hillman")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2008")])]

#text("I find this all very interesting, and would particularly enjoy any further comments you might have on (i) Arnold diffusion (ii) dimensionality vs. completely integrable (iii) torus versus plane.")

#text("Minor nit: are you sure about the +1/4 in your energy density up above? Shouldn’t it be -1/4? I determined the conserved flux-density pairs for the 1D NLS (with one sign change which interchanges real and imaginary parts) following the methods given in Olver’s book and got exactly the results quoted on Dispersive Wiki (same as you wrote above) except for that sign. I did check that the divergence of each flux-density pair vanishes, of course. I would be surprised if 1D -> 2D changes the sign -1/4.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/14/weakly-turbulent-solutions-for-the-cubic-defocusing-nonlinear-schrodinger-equation/#comment-33122")[#strong[#text("Recent Links Tagged With \"solution\" - JabberTags")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2008")]

#text("[…] public links >> solution Weakly turbulent solutions for the cubic defocusing nonlinear Schr … Saved by ROC1993 on Sat 18-10-2008 The Spiritual Solution to Materialism Saved by RubberRuffy on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/14/weakly-turbulent-solutions-for-the-cubic-defocusing-nonlinear-schrodinger-equation/#comment-486647")[#strong[#text("Chapter 0. Introduction – On the theories of Wave Turbulence and Quantum Kinetics")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2017")]

#text("[…] of this derivation is a subject of rapidly growing interest and has been studied in . See Terrence Tao’s blog for an excellent […]")
]
