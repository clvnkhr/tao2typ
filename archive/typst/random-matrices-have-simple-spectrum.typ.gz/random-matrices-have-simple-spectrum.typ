// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/
// Converted to Typst by tao2typ: "2026-10-14T15:19:15.424525+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Random matrices have simple spectrum", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Random matrices have simple spectrum")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 December 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/")[#text("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Van Vu and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/1412.1438")[#text("Random matrices have simple spectrum")]#text("“. Recall that an ")#mi("{n \\times n}")#text(" Hermitian matrix is said to have simple eigenvalues if all of its ")#mi("{n}")#text(" eigenvalues are distinct. This is a very typical property of matrices to have: for instance, as discussed in ")#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/")[#text("this previous post")]#text(", in the space of all ")#mi("{n \\times n}")#text(" Hermitian matrices, the space of matrices without all eigenvalues simple has codimension three, and for real symmetric cases this space has codimension two. In particular, given any random matrix ensemble of Hermitian or real symmetric matrices with an absolutely continuous distribution, we conclude that random matrices drawn from this ensemble will almost surely have simple eigenvalues.")

#text("For discrete random matrix ensembles, though, the above argument breaks down, even though general universality heuristics predict that the statistics of discrete ensembles should behave similarly to those of continuous ensembles. A model case here is the adjacency matrix ")#mi("{M_n}")#text(" of an ")#link("http://en.wikipedia.org/wiki/Erd%C5%91s%E2%80%93R%C3%A9nyi_model")[#text("Erdös-Rényi graph")]#text(" – a graph on ")#mi("{n}")#text(" vertices in which any pair of vertices has an independent probability ")#mi("{p}")#text(" of being in the graph. For the purposes of this paper one should view ")#mi("{p}")#text(" as fixed, e.g. ")#mi("{p=1/2}")#text(", while ")#mi("{n}")#text(" is an asymptotic parameter going to infinity. In this context, our main result is the following (answering a question of Babai):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" With probability ")#mi("{1-o(1)}")#text(", ")#mi("{M_n}")#text(" has simple eigenvalues.")
]

#text("Our argument works for more general Wigner-type matrix ensembles, but for sake of illustration we will stick with the Erdös-Renyi case. Previous work on local universality for such matrix models (e.g. the ")#link("http://www.ams.org/mathscinet-getitem?mr=2964770")[#text("work of Erdos, Knowles, Yau, and Yin")]#text(") was able to show that any individual eigenvalue gap ")#mi("{\\lambda_{i+1}(M)-\\lambda_i(M)}")#text(" did not vanish with probability ")#mi("{1-o(1)}")#text(" (in fact ")#mi("{1-O(n^{-c})}")#text(" for some absolute constant ")#mi("{c>0}")#text("), but because there are ")#mi("{n}")#text(" different gaps that one has to simultaneously ensure to be non-zero, this did not give Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" as one is forced to apply the union bound.")

#text("Our argument in fact gives simplicity of the spectrum with probability ")#mi("{1-O(n^{-A})}")#text(" for any fixed ")#mi("{A}")#text("; in a subsequent paper we also show that it gives a quantitative lower bound on the eigenvalue gaps (analogous to how many results on the singularity probability of random matrices can be upgraded to a bound on the least singular value).")

#text("The basic idea of argument can be sketched as follows. Suppose that ")#mi("{M_n}")#text(" has a repeated eigenvalue ")#mi("{\\lambda}")#text(". We split")

#align(center)[#tao-fit-display[#mitex("M_n = \\begin{pmatrix} M_{n-1} & X \\\\ X^T & 0 \\end{pmatrix}")]]

#text("for a random ")#mi("{n-1 \\times n-1}")#text(" minor ")#mi("{M_{n-1}}")#text(" and a random sign vector ")#mi("{X}")#text("; crucially, ")#mi("{X}")#text(" and ")#mi("{M_{n-1}}")#text(" are independent. If ")#mi("{M_n}")#text(" has a repeated eigenvalue ")#mi("{\\lambda}")#text(", then by the ")#link("http://en.wikipedia.org/wiki/Min-max_theorem#Cauchy_interlacing_theorem")[#text("Cauchy interlacing law")]#text(", ")#mi("{M_{n-1}}")#text(" also has an eigenvalue ")#mi("{\\lambda}")#text(". We now write down the eigenvector equation for ")#mi("{M_n}")#text(" at ")#mi("{\\lambda}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} M_{n-1} & X \\\\ X^T & 0 \\end{pmatrix} \\begin{pmatrix} v \\\\ a \\end{pmatrix} = \\lambda \\begin{pmatrix} v \\\\ a \\end{pmatrix}.")]]

#text("Extracting the top ")#mi("{n-1}")#text(" coefficients, we obtain")

#align(center)[#tao-fit-display[#mitex("(M_{n-1} - \\lambda) v + a X = 0.")]]

#text("If we let ")#mi("{w}")#text(" be the ")#mi("{\\lambda}")#text("-eigenvector of ")#mi("{M_{n-1}}")#text(", then by taking inner products with ")#mi("{w}")#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("a (w \\cdot X) = 0;")]]

#text("we typically expect ")#mi("{a}")#text(" to be non-zero, in which case we arrive at")

#align(center)[#tao-fit-display[#mitex("w \\cdot X = 0.")]]

#text("In other words, in order for ")#mi("{M_n}")#text(" to have a repeated eigenvalue, the top right column ")#mi("{X}")#text(" of ")#mi("{M_n}")#text(" has to be orthogonal to an eigenvector ")#mi("{w}")#text(" of the minor ")#mi("{M_{n-1}}")#text(". Note that ")#mi("{X}")#text(" and ")#mi("{w}")#text(" are going to be independent (once we specify which eigenvector of ")#mi("{M_{n-1}}")#text(" to take as ")#mi("{w}")#text("). On the other hand, thanks to inverse Littlewood-Offord theory (specifically, we use an ")#link("http://www.ams.org/mathscinet-getitem?mr=2775902")[#text("inverse Littlewood-Offord theorem of Nguyen and Vu")]#text("), we know that the vector ")#mi("{X}")#text(" is unlikely to be orthogonal to any given vector ")#mi("{w}")#text(" independent of ")#mi("{X}")#text(", unless the coefficients of ")#mi("{w}")#text(" are extremely special (specifically, that most of them lie in a generalised arithmetic progression). The main remaining difficulty is then to show that eigenvectors of a random matrix are typically not of this special form, and this relies on a conditioning argument ")#link("http://www.ams.org/mathscinet-getitem?mr=221962")[#text("originally used by Komlós")]#text(" to bound the singularity probability of a random sign matrix. (Basically, if an eigenvector has this special form, then one can use a fraction of the rows and columns of the random matrix to determine the eigenvector completely, while still preserving enough randomness in the remaining portion of the matrix so that this vector will in fact not be an eigenvector with high probability.)")

#heading(level: 1)[#text("Comments (22)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39d042cd343763a0074f825ecdf61ade3a1f833c09d7322d7ed33b69d91748e0-004ee65ff1042e640b0bfa8bf9563704de056663a81b46994f471f2da9bfde76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bogdan")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-443967")[#strong[#text("Bogdan")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2014")])]

#text("Great. In particular, your result implies that Isomorphism problem is in P for a class of graphs containing almost all graphs. Is this the first results of this type? I mean, are graphs whose matrices have non-repeated eithenvalues is the first class of graphs for which 1) Isomorphism in known to be in P, and 2) Almost all graphs are known to belong to this class.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fcd20a9e253e17f771e4d3b5fe70e5fec74713ffbd3998fa560cc20eced7bd1d-b58389ada956c4c773df128c06ad86453e6d639395f3c90ade7dca752c85e444.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quentin")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-444071")[#strong[#text("Quentin")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2014")])]

#text("Actually, it was already known, by using the fact that the largest n^0.15 degrees are unique (which turns out to be sufficient). A paper by Babai, Erdos, and Selkow is a good reference, but there might be more recent results.")

#link("http://vlsicad.eecs.umich.edu/BK/SAUCY/papers/1980-35.pdf")[#text("Click to access 1980-35.pdf")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-443971")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2014")])]

#text("“…not be an eigenvector with high probability” can be ambiguous to a newbie:-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96afe3eda5ed3466e140b8e093dcdbdb6ec8fc6400d007f3aa93ed6d5b7f29b9-f583a89de5bdea1d49a8ad091c6a1c4f5a6e52a677176dc561089c9444eafdbd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lingnaodai11")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-444456")[#strong[#text("lingnaodai11")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2014")])]

#text("Reblogged this on ")#link("http://lingnaodai.wordpress.com/2014/12/09/random-matrices-have-simple-spectrum/")[#text("lingnaodai")]#text(" and commented:")#linebreak()#text(" Omg.. cool.. i feel like this is very interesting area of research.. I can finally see how the linear algebra and graph theory are used in this., i hope..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82f01d671742a0b0a486906e0d75c671482bc1c9ec0bc7a843ce62133d4ebc82-0db19942fb673add80cb332e38485e8689376158fca6d9e2595d8ae535cf88ae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Interested_nonexpert")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-444724")[#strong[#text("Interested_nonexpert")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2014")])]

#text("Given the conjectures that 1) all zeta zeroes are simple, and 2) zeta zeroes behave like eigenvalues of random matrices, they both seem to be consistent with this result :) is operator theory still an active research area to tackle RH?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-444727")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2014")])]

#text("In the function field case, one can interpret the zeroes of the zeta function as (essentially) the eigenvalues of a Frobenius operator acting on certain cohomology groups, and this is the route taken in Deligne’s proof of the RH for varieties over finite fields (or, for that matter, Weil’s earlier proof of RH for curves). Some of the motivation of trying to rigorously develop a theory of the “field of one element” is to try to mimic this approach for the Riemann zeta function; see for instance ")#link("http://arxiv.org/abs/1405.4527")[#text("some recent work by Connes and Consani")]#text(" in this direction. However, as I understand from talking to Connes, there is still a huge input missing, namely we do not currently have an F_1 analogue of the Riemann-Roch theorem.")

#text("My personal feeling, though, is that the empirical fact that zeta zero statistics appear to asymptotically resemble random matrix statistics is not primarily due to any random matrix (or Hilbert-Polya) type interpretation of the zeta function. Rather, I believe it is a manifestation of the universality of these sorts of statistical laws, in that these statistics are the generic behaviour for zeroes of many classes of random or deterministic polynomials or analytic functions (not just those polynomials that happen to be characteristic polynomials of random matrices), after restricting of course to those functions that obey a functional equation across the critical line.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29791369e405a15a6a462c12d4fb89dcece41040a88f7a734ab60ac173a39070-63a5372ee0856e3f955c5e0f0387775a97bc2155bbb8f66e4195d6f5f887cac7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Strohmer")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-445062")[#strong[#text("Thomas Strohmer")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2014")])]

#text("It may be worthwhile to mention that the first result of this kind is probably due to von Neumann and Wigner, see “Über das Verhalten von Eigenwerten bei adiabatischen Prozessen”, J. von Neumann, E. P. Wigner, Z. Phys. A, 1929.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9fe37471f7a934331c4386edf57b5e65a3052f8c3f71b87ae875149b94be71b-20c43104ab6bcb2bd1fdac2268f5abe6c570abc709b9f0b4116fc5b9f2464213.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven Heilman")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-450510")[#strong[#text("Steven Heilman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2015")])]

#text("Can your subsequent paper also improve on the result of Erdos-Knowles-Yau-Yin, that the second largest eigenvalue follows the Tracy-Widow distribution? That is, can you improve on the restriction that they place on the parameter p, where each edge in the Erdos-Renyi model occurs with probability p? If so, that would be nice!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-450518")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2015")])]

#text("We haven’t done all the computations yet, but the range of sparsities ")#mi("p")#text(" that we can handle is probably going to be comparable to what is needed in EKYY. Also, our arguments do not establish universality of eigenvalue or spacing distributions; they are instead getting good bounds on the event of having an exceptionally small eigenvalue gap, which is a somewhat different question (more about the error term in universality than the main term).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/53a2135c0ebe096a4152662b155e52927b2750f48328081b64f136c80c89611b-f872b08e02366d16b5b26986630762c9033c75b1a1d30f0ad4a6122e8d6ca14a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edith")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-451410")[#strong[#text("Edith")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2015")])]

#text("Definition 1.1 is not correct. First it is required for all entries i<=j to be jointly independent and later, in the same definition, is stated that the elements of the diagonal can be correlated. All marginals of the joint independent distribution are also independent, obviously this is true for the bivariate marginals. This means that the elements of the diagonal have to be uncorrelated.")

#emph[#text("[This is a typo and will be corrected in the next revision of the ms – only the upper triangular entries are required to be jointly independent. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78bd6cfda47b8bbe2f9d6d0bb6d956cbd5bb01eedffe63ccfee8991b67203e63-b5df62526bf4bb70be183e5de8e39168a72d02d3df5aa23945f9af4c05e55f40.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of New findings | jeevarajs")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-451449")[#strong[#text("New findings | jeevarajs")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2015")])]

#text("[…] Addendum: He has blogged about it at – ")#link("https://terrytao.wordpress.com/…/random-matrices-have-simp…/")[#text("https://terrytao.wordpress.com/…/random-matrices-have-simp…/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random matrices: tail bounds for gaps between eigenvalues | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-453769")[#strong[#text("Random matrices: tail bounds for gaps between eigenvalues | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2015")])]

#text("[…] matrices: tail bounds for gaps between eigenvalues“. This is a followup paper to my recent paper with Van in which we showed that random matrices of Wigner type (such as the adjacency graph of an […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benjamin Peterson")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-453781")[#strong[#text("Benjamin Peterson")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2015")])]

#text("Small correction: The link in the first sentence says the paper title “Random matrices have simple eigenvalues” when the paper title is actually “Random matrices have simple spectrum”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29d3fae4c923c89142c794895e8cb1349e887c30833a5c71ce664b35ed2480a1-cb657d8af08b64bd90e5c779b4061f2ba0f49f8b8586e5cdc233393a1e037138.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lam")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-453923")[#strong[#text("Lam")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2015")])]

#text("Dear Terry,")

#text("there are two arguments which I do not manage to understand.")

#text("1. In the last paragraph of the proof of Proposition 3.4, you apply the pigeonhole principle to get the existence of a GAP P’ which contains at least k-m elements of P_I with probability >n^{-O(1)}. (Also, should P_I be replaced by V_I, even if that still holds, and epsilon by epsilon/2 in the volume?) I don’t get how to get such a GAP. Do you fix one P_I and call it P’? Then how does it follow that uniformly at random, another P_I intersects this P’ with size at least k-m, with high probability?")

#text("2. In the main proof of Proposition 2.3, in bounding P(E_3′), after embedding H in a hyperplane, how does it follow that each row has independent probability (1-mu) of lying in H?")

#text("Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-453925")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2015")])]

#text("1. Yes, ")#mi("P_I")#text(" should be ")#mi("V_I")#text(", and the exponent ")#mi("\\varepsilon")#text(" should be ")#mi("\\varepsilon/2")#text(".")

#text("The pigeonholing argument is going like this: for each ")#mi("I")#text(", we have a progression ")#mi("P_I")#text(", which is drawn from a set of ")#mi("O(n^{O(1)})")#text(" possible progressions. Thus, by the pigeonhole principle, there exists one of these progressions, call it ")#mi("P^{\\prime}")#text(", such that ")#mi("P_I = P^{\\prime}")#text(" with probability at least ")#mi("\\gg n^{-O(1)}")#text(" if ")#mi("I")#text(" is chosen uniformly at random.")

#text("2. This is the Odlyzko argument. As stated in the text, the hyperplane H is expressible as a graph of one of the coordinates, say ")#mi("x_n")#text(", in terms of the other coordinates, in this case ")#mi("x_1,\\dots,x_{n-1}")#text(". Now take one of the rows and condition on the coordinates ")#mi("x_1,\\dots,x_{n-1}")#text(" to be fixed. The remaining coordinate ")#mi("x_n")#text(" is still random, and by hypothesis it attains any given value with probability at most ")#mi("1-\\mu")#text(", so in particular it attains the value required to lie in ")#mi("H")#text(" with probability at most ")#mi("1-\\mu")#text(". Now integrate out the conditioning to obtain the result.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29d3fae4c923c89142c794895e8cb1349e887c30833a5c71ce664b35ed2480a1-cb657d8af08b64bd90e5c779b4061f2ba0f49f8b8586e5cdc233393a1e037138.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lam")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-453928")[#strong[#text("Lam")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2015")])]

#text("Thank you!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-453940")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2015")])]

#text("If the dimension ")#mi("n")#text(" is random, is it possible to extend theorem 1 (with appropriate condition on the probability distribution of ")#mi("n")#text(" values) such that ")#mi("M_n")#text(" has simple spectrum with probability 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-477480")[#strong[#text("Mike")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("This may seem pedantic, but I’m trying to attach a specific meaning to the statement that the space of Hermitian matrices with repeated eigenvalues has codimension 3. It seems that this space should be a finite union of submanifolds all having codimension at least 3. Is this true? And is there a simple way to see this more rigorously (or a reference that does so)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-477577")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2017")])]

#text("One way to do this is to describe this space as the image (under some smooth or algebraic map) of a space of (real) dimension ")#mi("n^2-3")#text(". For instance, to describe a Hermitian matrix with repeated eigenvalues, one can list ")#mi("n-1")#text(" eigenvalues (one of which is repeated), and ")#mi("n-2")#text(" orthogonal eigenlines together with a further eigenplane orthogonal to the eigenlines. Actually one doesn’t need to specify the eigenplane as it is determined as the orthogonal complement of the span of the other eigenlines. Clearly the space of possible eigenvalues is ")#mi("n-1")#text(" dimensional. The first eigenline is ")#mi("2n-2")#text(" dimensional (also the real dimension of ")#mi("{\\bf CP}^{n-1}")#text("), then once that eigenline is fixed, the dimension of the possible options for the next eigenline is ")#mi("2n-4")#text(", and so forth, giving a total dimension of ")#mi("n-1 + (2n-2) + (2n-4) + \\dots + 2 = n^2-3")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-477613")[#strong[#text("Mike")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2017")])]

#text("Thanks very much!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-477493")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("This seems to follow from the fact that this space (Hermitian matrices with repeated eigenvalues) can be represented as a (closed) semialgebraic subset of ")#mi("\\mathbb R^{2 n}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/#comment-494128")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2018")])]

#text("I have a question: Are you aware of a discussion of a possible connection between random matrix theory and the recent Bender-Brody-Müller approach?")

#text("One thought about that: It seems, ideally random matrix theory would be exactly the Heisenberg matrix formulation of the BBM “Schrödinger type” formulation.")

#text("The Heisenberg uncertainty principle tells us that no quantum object can have a defined momentum and position in the same state. Measuring momentum and position one after the other leads inevitably to a result for which only probability distributions rather than defined values can be given.")

#text("Would it make sense to interpret the Berry-Keating (or therefrom derived) operators containing products like p̂x̂ such that one would force the system into eigenstates with localised (defined) product of momentum and position?")

#text("One then would have to read these terms like p̂(x̂(ψ)),")#linebreak()#text(" leading to operators with kind of a paradoxical eigenstates, which reflects itself already in that these operators are not self-adjoint.")
]
