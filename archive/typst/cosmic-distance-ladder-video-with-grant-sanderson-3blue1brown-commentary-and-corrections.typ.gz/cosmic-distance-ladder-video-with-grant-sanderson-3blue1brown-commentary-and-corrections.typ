// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/
// Converted to Typst by tao2typ: "2026-10-14T15:21:03.932401+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Cosmic Distance Ladder videos with Grant Sanderson (3blue1brown): commentary and corrections", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Cosmic Distance Ladder videos with Grant Sanderson (3blue1brown): commentary and corrections")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 February 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/")[#text("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Grant Sanderson (who runs, and creates most of the content for, the website and Youtube channel ")#link("https://www.3blue1brown.com/")[#text("3blue1brown")]#text(") has been collaborating with myself and others (including my coauthor ")#link("https://courtauld.ac.uk/people/tanya-klowden/")[#text("Tanya Klowden")]#text(") on producing a two-part video giving an account of some of the history of the cosmic distance ladder, building upon a ")#link("https://terrytao.wordpress.com/wp-content/uploads/2020/10/cosmic-distance-ladder.pdf")[#text("previous public lecture")]#text(" I gave on this topic, and also relating to a ")#link("https://terrytao.wordpress.com/books/climbing-the-cosmic-distance-ladder/")[#text("forthcoming popular book")]#text(" with Tanya on this topic. The first part of this video is ")#link("https://www.youtube.com/watch?v=YdOXS_9_P4U")[#text("available here")]#text("; the second part is ")#link("https://www.youtube.com/watch?v=hFMaT9oRbs4")[#text("available here")]#text(".")

#text("The videos were based on a somewhat unscripted interview that Grant conducted with me some months ago, and as such contained some minor inaccuracies and omissions (including some made for editing reasons to keep the overall narrative coherent and within a reasonable length). They also generated many good questions from the viewers of the Youtube video. I am therefore compiling here a “FAQ” of various clarifications and corrections to the videos; this was originally placed as a series of comments on the Youtube channel, but the blog post format here will be easier to maintain going forward. Some related content will also be posted on the ")#link("https://www.instagram.com/cosmic_distance_ladder/")[#text("Instagram page")]#text(" for the forthcoming book with Tanya.")

#text("Questions on the two main videos are marked with an appropriate timestamp to the video.")

#heading(level: 1)[#text("Comments on ")#link("https://www.youtube.com/watch?v=YdOXS_9_P4U")[#text("part 1 of the video")]]

#list(
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=266s")[#text("4:26")]#text(" ")#strong[#text("Did Eratosthenes really check a local well in Alexandria?")]#linebreak()#linebreak()#text("This was a narrative embellishment on my part. Eratosthenes’s original work is lost to us. The most detailed contemperaneous account, by Cleomedes, gives a simplified version of the method, and makes reference only to sundials (gnomons) rather than wells. However, a secondary account of Pliny states (using ")#link("https://www.attalus.org/translate/pliny_hn2c.html")[#text("this English translation")]#text("), “Similarly it is reported that at the town of Syene, 5000 stades South of Alexandria, at noon in midsummer no shadow is cast, and that in a well made for the sake of testing this the light reaches to the bottom, clearly showing that the sun is vertically above that place at the time”. However, no mention is made of any well in Alexandria in either account.")],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=290s")[#text("4:50")]#text(" ")#strong[#text("How did Eratosthenes know that the Sun was so far away that its light rays were close to parallel")]#text("? ")#linebreak()#linebreak()#text("This was not made so clear in our discussions or in the video (other than a brief glimpse of the timeline at ")#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=1107s")[#text("18:27")]#text("), but Eratosthenes’s work actually came after Aristarchus, so it is very likely that Eratosthenes was aware of Aristarchus’s conclusions about how distant the Sun was from the Earth. Even if Aristarchus’s heliocentric model was disputed by the other Greeks, at least some of his other conclusions appear to have attracted some support. Also, after Eratosthenes’s time, there was further work by Greek, Indian, and Islamic astronomers (such as ")#link("https://en.wikipedia.org/wiki/Hipparchus")[#text("Hipparchus")]#text(", ")#link("https://en.wikipedia.org/wiki/Ptolemy")[#text("Ptolemy")]#text(", ")#link("https://en.wikipedia.org/wiki/Aryabhata")[#text("Aryabhata")]#text(", and ")#link("https://en.wikipedia.org/wiki/Al-Battani")[#text("Al-Battani")]#text(") to measure the same distances that Aristarchus did, although these subsequent measurements for the Sun also were somewhat far from modern accepted values. ")#linebreak()],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=317s")[#text("5:17")]#text(" ")#strong[#text("Is it completely accurate to say that on the summer solstice, the Earth’s axis of rotation is tilted “directly towards the Sun”")]#text("? ")#linebreak()#linebreak()#text("Strictly speaking, “in the direction towards the Sun” is more accurate than “directly towards the Sun”; it tilts at about 23.5 degrees towards the Sun, but it is not a total 90-degree tilt towards the Sun. ")#linebreak()],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=339s")[#text("5:39")]#text(" ")#strong[#text("Wait, aren’t there two tropics? The tropic of Cancer and the tropic of Capricorn? ")]#linebreak()#linebreak()#text("Yes! This corresponds to the two summers Earth experiences, one in the Northern hemisphere and one in the Southern hemisphere. The ")#link("https://en.wikipedia.org/wiki/Tropic_of_Cancer")[#text("tropic of Cancer")]#text(", at a latitude of about 23 degrees north, is where the Sun is directly overhead at noon during the Northern summer solstice (around June 21); the ")#link("https://en.wikipedia.org/wiki/Tropic_of_Capricorn")[#text("tropic of Capricorn")]#text(", at a latitude of about 23 degrees south, is where the Sun is directly overhead at noon during the Southern summer solstice (around December 21). But Alexandria and Syene were both in the Northern Hemisphere, so it is the tropic of Cancer that is relevant to Eratosthenes’ calculations.")#linebreak()],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=281s")[#text("5:41")]#text(" ")#strong[#text("Isn’t it kind of a massive coincidence that Syene was on the tropic of Cancer?")]#linebreak()#linebreak()#text("Actually, Syene (now known as ")#link("https://en.wikipedia.org/wiki/Aswan")[#text("Aswan")]#text(") was about half a degree of latitude away from the tropic of Cancer, which was one of the sources of inaccuracy in Eratosthenes’ calculations. But one should take the ")#link("https://en.wikipedia.org/wiki/Look-elsewhere_effect")[#text("“look-elsewhere effect")]#text("” into account: because the Nile cuts across the tropic of Cancer, it was quite likely to happen that the Nile would intersect the tropic near ")#emph[#text("some")]#text(" inhabited town. It might not necessarily have been Syene, but that would just mean that Syene would have been substituted by this other town in Eratosthenes’s account. ")#linebreak()#linebreak()#text("On the other hand, it was fortunate that the Nile ran from South to North, so that distances between towns were a good proxy for the differences in latitude. Apparently, Eratosthenes actually had a more complicated argument that would also work if the two towns in question were not necessarily oriented along the North-South direction, and if neither town was on the tropic of Cancer; but unfortunately the original writings of Eratosthenes are lost to us, and we do not know the details of this more general argument. (But some variants of the method can be found in later work of ")#link("https://en.wikipedia.org/wiki/Posidonius")[#text("Posidonius")]#text(", ")#link("https://en.wikipedia.org/wiki/Aryabhata")[#text("Aryabhata")]#text(", and others.)")#linebreak()#linebreak()#text("Nowadays, the “")#link("https://eratosthenes.ea.gr/")[#text("Eratosthenes experiment")]#text("” is run every year on the March equinox, in which schools at the same longitude are paired up to measure the elevation of the Sun at the same point in time, in order to obtain a measurement of the circumference of the Earth. (The equinox is more convenient than the solstice when neither location is on a tropic, due to the simple motion of the Sun at that date.) With modern timekeeping, communications, surveying, and navigation, this is a far easier task to accomplish today than it was in Eratosthenes’ time.")#linebreak()],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=390s")[#text("6:30")]#text(" ")#strong[#text("I thought the Earth wasn’t a perfect sphere. Does this affect this calculation? ")]#linebreak()#linebreak()#text("Yes, but only by a small amount. The centrifugal forces caused by the Earth’s rotation along its axis cause an ")#link("https://en.wikipedia.org/wiki/Equatorial_bulge")[#text("equatorial bulge")]#text(" and a polar flattening so that the radius of the Earth fluctuates by about 20 kilometers from pole to equator. This sounds like a lot, but it is only about 0.3% of the mean Earth radius of 6371 km and is not the primary source of error in Eratosthenes’ calculations.")#linebreak()],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=447s")[#text("7:27")]#text(" ")#strong[#text("Are the riverboat merchants and the “grad student” the leading theories for how Eratosthenes measured the distance from Alexandria to Syene? ")]#linebreak()#linebreak()#text("There is some ")#link("https://doi.org/10.1007/978-3-642-18904-3")[#text("recent research")]#text(" that suggests that Eratosthenes may have drawn on the work of professional ")#link("https://en.wikipedia.org/wiki/Bematist")[#text("bematists")]#text(" (step measurers – a precursor to the modern profession of surveyor) for this calculation. This somewhat ruins the “grad student” joke, but perhaps should be disclosed for the sake of completeness. ")#linebreak()],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=531s")[#text("8:51")]#text(" ")#strong[#text("How long is a “lunar month” in this context? Is it really 28 days?")]#text(" ")#linebreak()#linebreak()#text("In this context the correct notion of a lunar month is a “")#link("https://en.wikipedia.org/wiki/Lunar_month#Synodic_month")[#text("synodic month")]#text("” – the length of a lunar cycle relative to the Sun – which is actually about 29 days and 12 hours. It differs from the “")#link("https://en.wikipedia.org/wiki/Lunar_month#Sidereal_month")[#text("sidereal month")]#text("” – the length of a lunar cycle relative to the fixed stars – which is about 27 days and 8 hours – due to the motion of the Earth around the Sun (or the Sun around the Earth, in the geocentric model). [A similar correction needs to be made around ")#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=899s")[#text("14:59")]#text(", using the synodic month of 29 days and 12 hours rather than the “English lunar month” of 28 days (4 weeks).] ")#linebreak()],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=647s")[#text("10:47")]#text(" ")#strong[#text("Is the time taken for the Moon to complete an observed rotation around the Earth slightly less than 24 hours as claimed?")]#text(" ")#linebreak()#linebreak()#text("Actually, I made a sign error: the ")#link("https://en.wikipedia.org/wiki/Lunar_day#Alternate_usage")[#text("lunar day")]#text(" (also known as a tidal day) is actually 24 hours and 50 minutes, because the Moon rotates in the same direction as the spinning of Earth around its axis. The animation therefore is also moving in the wrong direction as well (related to this, the line of sight is covering up the Moon in the wrong direction to the Moon rising at around ")#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=638s")[#text("10:38")]#text(").")#linebreak()],
[#link("https://youtu.be/YdOXS_9_P4U?t=692")[#text("11:32")]#text(" ")#strong[#text("Is this really just a coincidence that the Moon and Sun have almost the same angular width?")]#linebreak()#linebreak()#text("I believe so. First of all, the agreement is not ")#emph[#text("that")]#text(" good: due to the non-circular nature of the orbit of the Moon around the Earth, and Earth around the Sun, the angular width of the Moon actually fluctuates to be as much as 10% larger or smaller than the Sun at various times (cf. the “")#link("https://en.wikipedia.org/wiki/Supermoon")[#text("supermoon")]#text("” phenomenon). All other known planets with known moons do not exhibit this sort of agreement, so there does not appear to be any universal law of nature that would enforce this coincidence. (This is in contrast with the empirical fact that the Moon always presents the same side to the Earth, which occurs in all other known large moons (as well as Pluto), and is well explained by the physical phenomenon of ")#link("https://en.wikipedia.org/wiki/Tidal_locking")[#text("tidal locking")]#text(".)")#linebreak()#linebreak()#text("On the other hand, as the video hopefully demonstrates, the existence of the Moon was extremely helpful in allowing the ancients to understand the basic nature of the solar system. Without the Moon, their task would have been significantly more difficult; but in this hypothetical alternate universe, it is likely that modern cosmology would have still become possible once advanced technology such as telescopes, spaceflight, and computers became available, especially when combined with the modern mathematics of data science. Without giving away too many spoilers, a scenario similar to this was explored in the classic short story and novel “")#link("https://en.wikipedia.org/wiki/Nightfall_(Asimov_novelette_and_novel)")[#text("Nightfall")]#text("” by Isaac Asimov.")],
[#link("https://youtu.be/YdOXS_9_P4U?t=778")[#text("12:58")]#text(" ")#strong[#text("Isn’t the illuminated portion of the Moon, as well as the visible portion of the Moon, slightly smaller than half of the entire Moon, because the Earth and Sun are not an infinite distance away from the Moon?")]#linebreak()#linebreak()#text("Technically yes (and this is actually for a very similar reason to why half Moons don’t quite occur halfway between the new Moon and the full Moon); but this fact turns out to have only a very small effect on the calculations, and is not the major source of error. In reality, the Sun turns out to be about 86,000 Moon radii away from the Moon, so asserting that half of the Moon is illuminated by the Sun is actually a very good first approximation. (The Earth is “only” about 220 Moon radii away, so the visible portion of the Moon is a bit more noticeably less than half; but this doesn’t actually affect Aristarchus’s arguments much.)")#linebreak()#linebreak()#text("The angular diameter of the Sun also creates an additional thin band between the fully illuminated and fully non-illuminated portions of the Moon, in which the Sun is intersecting the lunar horizon and so only illuminates the Moon with a portion of its light, but this is also a relatively minor effect (and the midpoints of this band can still be used to define the terminator between illuminated and non-illuminated for the purposes of Aristarchus’s arguments).")#linebreak()],
[#link("https://youtu.be/YdOXS_9_P4U?t=807")[#text("13:27")]#text(" ")#strong[#text("What is the difference between a half Moon and a quarter Moon?")]#linebreak()#linebreak()#text("If one divides the lunar month, starting and ending at a new Moon, into quarters (weeks), then half moons occur both near the end of the first quarter (a week after the new Moon, and a week before the full Moon), and near the end of the third quarter (a week after the full Moon, and a week before the new Moon). So, somewhat confusingly, half Moons come in two types, known as “first quarter Moons” and “third quarter Moons”.")],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=889s")[#text("14:49")]#text(" ")#strong[#text("I thought the sine function was introduced well after the ancient Greeks.")]#linebreak()#linebreak()#text("It’s true that the modern sine function only dates back to the ")#link("https://en.wikipedia.org/wiki/%C4%80ryabha%E1%B9%ADa%27s_sine_table")[#text("Indian")]#text(" and ")#link("https://en.wikipedia.org/wiki/Al-Khwarizmi#Trigonometry")[#text("Islamic")]#text(" mathematical traditions in the first millennium CE, several centuries after Aristarchus. However, he still had Euclidean geometry at his disposal, which provided tools such as similar triangles that could be used to reach basically the same conclusions, albeit with significantly more effort than would be needed if one could use modern trigonometry.")#linebreak()#linebreak()#text("On the other hand, Aristarchus was somewhat hampered by not knowing an accurate value for ")#mi("\\pi")#text(", which is also known as Archimedes’ constant: the ")#link("https://en.wikipedia.org/wiki/Pi#Polygon_approximation_era")[#text("fundamental work of Archimedes")]#text(" on this constant actually took place a few decades after that of Aristarchus!")#linebreak()],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=917s")[#text("15:17")]#text(" ")#strong[#text("I plugged in the modern values for the distances to the Sun and Moon and got 18 minutes for the discrepancy, instead of half an hour. ")]#linebreak()#linebreak()#text("Yes; I quoted the wrong number here. In 1630, ")#link("https://en.wikipedia.org/wiki/Godfried_Wendelen")[#text("Godfried Wendelen")]#text(" replicated Aristarchus’s experiment. With improved timekeeping and the then-recent invention of the telescope, Wendelen obtained a measurement of half an hour for the discrepancy, which is significantly better than Aristarchus’s calculation of six hours, but still a little bit off from the true value of 18 minutes. (As such, Wendelinus’s estimate for the distance to the Sun was 60% of the true value.)")#linebreak()],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=927s")[#text("15:27")]#text(" ")#strong[#text("Wouldn’t Aristarchus also have access to other timekeeping devices than sundials?")]#linebreak()#linebreak()#text("Yes, for instance ")#link("https://en.wikipedia.org/wiki/Water_clock")[#text("clepsydrae")]#text(" (water clocks) were available by that time; but they were of limited accuracy. It is also possible that Aristarchus could have used measurements of star elevations to also estimate time; it is not clear whether the ")#link("https://en.wikipedia.org/wiki/Astrolabe")[#text("astrolabe")]#text(" or the ")#link("https://en.wikipedia.org/wiki/Armillary_sphere")[#text("armillary sphere")]#text(" was available to him, but he would have had some other more primitive astronomical instruments such as the ")#link("https://en.wikipedia.org/wiki/Dioptra")[#text("dioptra")]#text(" at his disposal. But again, the accuracy and calibration of these timekeeping tools would have been poor.")#linebreak()#linebreak()#text("However, most likely the more important limiting factor was the ability to determine the precise moment at which a perfect half Moon (or new Moon, or full Moon) occurs; this is extremely difficult to do with the naked eye. (The telescope would not be invented for almost two more millennia.)")#linebreak()],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=1057s")[#text("17:37")]#text(" ")#strong[#text("Could the parallax problem be solved by assuming that the stars are not distributed in a three-dimensional space, but instead on a celestial sphere?")]#text(" ")#linebreak()#linebreak()#text("Putting all the stars on a fixed sphere would make the parallax effects less visible, as the stars in a given portion of the sky would now all move together at the same apparent velocity – but there would still be visible large-scale distortions in the shape of the constellations because the Earth would be closer to some portions of the celestial sphere than others; there would also be variability in the brightness of the stars, and (if they were very close) the apparent angular diameter of the stars. (These problems would be solved if the celestial sphere was somehow centered around the moving Earth rather than the fixed Sun, but then this basically becomes the geocentric model with extra steps.) ")#linebreak()],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=1109s")[#text("18:29")]#text(" ")#strong[#text("Did nothing of note happen in astronomy between Eratosthenes and Copernicus?")]#text(" ")#linebreak()#linebreak()#text("Not at all! There were significant mathematical, technological, theoretical, and observational advances by astronomers from many cultures (Greek, Islamic, Indian, Chinese, European, and others) during this time, for instance improving some of the previous measurements on the distance ladder, a better understanding of eclipses, axial tilt, and even axial precession, more sophisticated trigonometry, and the development of new astronomical tools such as the astrolabe. See for instance ")#link("https://www.youtube.com/shorts/uT4-WVa-YfU")[#text("this “deleted scene”")]#text(" from the video, as well as the FAQ entry for ")#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=889s")[#text("14:49")]#text(" for this video and ")#link("https://youtu.be/hFMaT9oRbs4?t=1494")[#text("24:54")]#text(" for the second video, or ")#link("https://www.instagram.com/p/DGzJs02AbBA")[#text("this instagram post")]#text(". But in order to make the overall story of the cosmic distance ladder fit into a two-part video, we chose to focus primarily on the first time each rung of the ladder was climbed. ")#linebreak()],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=1109s")[#text("18:30")]#text(" ")#strong[#text("Is that really Kepler’s portrait?")]#linebreak()#linebreak()#text("We have ")#link("https://pubs.aip.org/physicstoday/article/74/9/10/928309/How-a-fake-Kepler-portrait-became-iconic")[#text("since learned")]#text(" that this portrait was most likely painted in the 19th century, and may have been based more on Kepler’s mentor, ")#link("https://en.wikipedia.org/wiki/Michael_Maestlin")[#text("Michael Mästlin")]#text(". A more commonly accepted portrait of Kepler may be found at his current ")#link("https://en.wikipedia.org/wiki/Johannes_Kepler")[#text("Wikipedia page")]#text(".")#linebreak()],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=1147s")[#text("19:07")]#text(" ")#strong[#text("Isn’t it tautological to say that the Earth takes one year to perform a full orbit around the Sun?")]#linebreak()#linebreak()#text("Technically yes, but this is an illustration of the philosophical concept of “")#link("https://en.wikipedia.org/wiki/Opaque_context")[#text("referential opacity")]#text("“: the content of a sentence can change when substituting one term for another (e.g., “1 year” and “365 days”), even when both terms refer to the same object. Amusingly, the classic illustration of this, known as ")#link("https://en.wikipedia.org/wiki/Frege%27s_puzzles")[#text("Frege’s puzzles")]#text(", also comes from astronomy: it is an informative statement that ")#link("https://en.wikipedia.org/wiki/Hesperus")[#text("Hesperus")]#text(" (the evening star) and")#link("https://en.wikipedia.org/wiki/Phosphorus_(morning_star)")[#text(" Phosphorus")]#text(" (the morning star, also known as Lucifer) are the same object (which nowadays we call Venus), but it is a mere tautology that Hesperus and Hesperus are the same object: changing the reference from Phosphorus to Hesperus changes the meaning. ")#linebreak()],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=1150s")[#text("19:10")]#text(" ")#strong[#text("How did Copernicus figure out the crucial fact that Mars takes 687 days to go around the Sun? Was it directly drawn from Babylonian data? ")]#linebreak()#linebreak()#text("Technically, Copernicus drew from tables by European astronomers that were largely based on earlier tables from the Islamic golden age, which in turn drew from earlier tables by Indian and Greek astronomers, the latter of which also incorporated data from the ancient Babylonians, so it is more accurate to say that Copernicus relied on centuries of data, at least some of which went all the way back to the Babylonians. Among all of this data was the times when Mars was in opposition to the Sun; if one imagines the Earth and Mars as being like runners going around a race track circling the Sun, with Earth on an inner track and Mars on an outer track, oppositions are analogous to when the Earth runner “laps” the Mars runner. From the centuries of observational data, such “laps” were known to occur about once every 780 days (this is known as the ")#link("https://en.wikipedia.org/wiki/Orbital_period#Synodic_period")[#text("synodic period")]#text(" of Mars). Because the Earth takes roughly 365 days to perform a “lap”, it is possible to do a little math and conclude that Mars must therefore complete its own “lap” in 687 days (this is known as the ")#link("https://en.wikipedia.org/wiki/Orbital_period")[#text("sidereal period")]#text(" of Mars). (See also this ")#link("https://www.instagram.com/p/DF_fiYoogW2")[#text("post on the cosmic distance ladder Instagram")]#text(" for some further elaboration.)")#linebreak()],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=1252s")[#text("20:52")]#text(" ")#strong[#text("Did Kepler really steal data from Brahe?")]#linebreak()#linebreak()#text("The situation is complex. When Kepler served as Brahe’s assistant, Brahe only provided Kepler with a limited amount of data, primarily involving Mars, in order to confirm Brahe’s ")#link("https://en.wikipedia.org/wiki/Tychonic_system")[#text("own geo-heliocentric model")]#text(". After Brahe’s death, the data was inherited by Brahe’s son-in-law and other relatives, who intended to publish Brahe’s work separately; however, Kepler, who was appointed as Imperial Mathematician to succeed Brahe, had at least some partial access to the data, and many historians believe he secretly copied portions of this data to aid his own research before finally securing complete access to the data from Brahe’s heirs after several years of disputes. On the other hand, as intellectual property rights laws were not well developed at this time, Kepler’s actions were technically legal, if ethically questionable.")#linebreak()],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=1299s")[#text("21:39")]#text(" ")#strong[#text("What is that funny loop in the orbit of Mars?")]#text(" ")#linebreak()#linebreak()#text("This is known as ")#link("https://en.wikipedia.org/wiki/Retrograde_and_prograde_motion")[#text("retrograde motion")]#text(". This arises because the orbital velocity of Earth (about 30 km/sec) is a little bit larger than that of Mars (about 24 km/sec). So, in opposition (when Mars is in the opposite position in the sky than the Sun), Earth will briefly overtake Mars, causing its observed position to move westward rather than eastward. But in most other times, the motion of Earth and Mars are at a sufficient angle that Mars will continue its apparent eastward motion despite the slightly faster speed of the Earth.")#linebreak()],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=1319s")[#text("21:59")]#text(" ")#strong[#text("Couldn’t one also work out the direction to other celestial objects in addition to the Sun and Mars, such as the stars, the Moon, or the other planets? Would that have helped?")]#linebreak()#linebreak()#text("Actually, the directions to the fixed stars were implicitly used in all of these observations to determine how the celestial sphere was positioned, and all the other directions were taken relative to that celestial sphere. (Otherwise, all the calculations would be taken on a rotating frame of reference in which the unknown orbits of the planets were themselves rotating, which would have been an even more complex task.) But the stars are too far away to be useful as one of the two landmarks to triangulate from, as they generate almost no parallax and so cannot distinguish one location from another.")#linebreak()#linebreak()#text("Measuring the direction to the Moon would tell you which portion of the lunar cycle one was in, and would determine the phase of the Moon, but this information would not help one triangulate, because the Moon’s position in the heliocentric model varies over time in a somewhat complicated fashion, and is too tied to the motion of the Earth to be a useful “landmark” to one to determine the Earth’s orbit around the Sun.")#linebreak()#linebreak()#text("In principle, using the measurements to all the planets at once could allow for some multidimensional analysis that would be more accurate than analyzing each of the planets separately, but this would require some sophisticated statistical analysis and modeling, as well as non-trivial amounts of compute – neither of which were available in Kepler’s time.")#linebreak()],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=1377s")[#text("22:57")]#text(" ")#strong[#text("Can you elaborate on how we know that the planets all move on a plane?")]#text(" ")#linebreak()#linebreak()#text("The Earth’s orbit lies in a plane known as the ")#link("https://en.wikipedia.org/wiki/Ecliptic")[#text("ecliptic")]#text(" (it is where the lunar and solar eclipses occur). Different cultures have divided up the ecliptic in various ways; in Western astrology, for instance, the twelve main constellations that cross the ecliptic are known as the Zodiac. The planets can be observed to only wander along the Zodiac, but not other constellations: for instance, Mars can be observed to be in Cancer or Libra, but never in Orion or Ursa Major. From this, one can conclude (as a first approximation, at least), that the planets all lie on the ecliptic. ")#linebreak()#linebreak()#text("However, this isn’t perfectly true, and the planets will deviate from the ecliptic by a small angle known as the ")#link("https://en.wikipedia.org/wiki/Ecliptic_coordinate_system#Spherical_coordinates")[#text("ecliptic latitude")]#text(". Tycho Brahe’s observations on these latitudes for Mars were an additional useful piece of data that helped Kepler complete his calculations (basically by suggesting how to join together the different “jigsaw pieces”), but the math here gets somewhat complicated, so the story here has been somewhat simplified to convey the main ideas.")#linebreak()],
[#link("https://youtu.be/YdOXS_9_P4U?t=1384")[#text("23:04")]#text(" ")#strong[#text("What are the other universal problem solving tips?")]#linebreak()#linebreak()#text("Grant Sanderson has a list (in a somewhat different order) in ")#link("https://www.youtube.com/watch?v=QvuQH4_05LI")[#text("this previous video")]#text(".")],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=1408s")[#text("23:28")]#text(" ")#strong[#text("Can one work out the position of Earth from fixed locations of the Sun and Mars when the Sun and Mars are in conjunction (the same location in the sky) or opposition (opposite locations in the sky)?")]#text(" ")#linebreak()#linebreak()#text("Technically, these are two times when the technique of triangulation fails to be accurate; and also in the former case it is extremely difficult to observe Mars due to the proximity to the Sun. But again, following the Universal Problem Solving Tip from ")#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=1387s")[#text("23:07")]#text(", one should initially ignore these difficulties to locate a viable method, and correct for these issues later. This ")#link("https://www.youtube.com/watch?v=Phscjl0u6TI")[#text("video")]#text(" ")#link("https://www.youtube.com/watch?v=MprJN5teQxc")[#text("series")]#text(" by Welch Labs goes into Kepler’s methods in more detail.")#linebreak()],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=1444s")[#text("24:04")]#text(" ")#strong[#text("So Kepler used Copernicus’s calculation of 687 days for the period of Mars. But didn’t Kepler discard Copernicus’s theory of circular orbits?")]#text(" ")#linebreak()#linebreak()#text("Good question! It turns out that Copernicus’s calculations of orbital periods are quite robust (especially with centuries of data), and continue to work even when the orbits are not perfectly circular. But even if the calculations did depend on the circular orbit hypothesis, it would have been possible to use the Copernican model as a first approximation for the period, in order to get a better, but still approximate, description of the orbits of the planets. This in turn can be fed back into the Copernican calculations to give a second approximation to the period, which can then give a further refinement of the orbits. Thanks to the branch of mathematics known as ")#link("https://en.wikipedia.org/wiki/Perturbation_theory")[#text("perturbation theory")]#text(", one can often make this type of iterative process converge to an exact answer, with the error in each successive approximation being smaller than the previous one. (But performing such an iteration would probably have been beyond the computational resources available in Kepler’s time; also, the foundations of perturbation theory require calculus, which only was developed several decades after Kepler.)")#linebreak()],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=1461s")[#text("24:21")]#text(" ")#strong[#text("Did Brahe have exactly 10 years of data on Mars’s positions? ")]#linebreak()#linebreak()#text("Actually, it was more like 17 years, but with many gaps, due both to inclement weather, as well as Brahe turning his attention to other astronomical objects than Mars in some years; also, in times of conjunction, Mars might only be visible in the daytime sky instead of the night sky, again complicating measurements. So the “jigsaw puzzle pieces” in ")#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=1526s")[#text("25:26")]#text(" are in fact more complicated than always just five locations equally spaced in time; there are gaps and also observational errors to grapple with. But to understand the method one should ignore these complications; again, see “Universal Problem Solving Tip #1”. Even with his “idea of true genius”, it took many years of further painstaking calculation for Kepler to tease out his laws of planetary motion from Brahe’s messy and incomplete observational data.")#linebreak()],
[#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=1604s")[#text("26:44")]#text(" ")#strong[#text("Shouldn’t the Earth’s orbit be spread out at perihelion and clustered closer together at aphelion, to be consistent with Kepler’s laws?")]#linebreak()#linebreak()#text("Yes, you are right; there was a coding error here.")],
[#link("https://youtu.be/YdOXS_9_P4U?t=1613")[#text("26:53")]#text(" ")#strong[#text("What is the reference for Einstein’s “idea of pure genius”?")]#linebreak()#linebreak()#text("Actually, the precise quote was “an idea of true genius”, and can be found in the introduction to Carola Baumgardt’s “")#link("https://archive.org/details/johanneskeplerli0000caro/page/n5/mode/2up")[#text("Life of Kepler")]#text("“.")#linebreak()]
)

#heading(level: 1)[#text("Comments on the ")#link("https://www.youtube.com/shorts/uT4-WVa-YfU")[#text("“deleted scene” on Al-Biruni")]]

#list(
[#strong[#text("Was Al-Biruni really of Arab origin?")]#linebreak()#linebreak()#text("Strictly speaking; no; his writings are all in Arabic, and he was nominally a subject of the Abbasid Caliphate whose rulers were Arab; but he was born in Khwarazm (in modern day Uzbekistan), and would have been a subject of either the Samanid empire or the Khrawazmian empire, both of which were largely self-governed and primarily Persian in culture and ethnic makeup, despite being technically vassals of the Caliphate. So he would have been part of what is sometimes called “Greater Persia” or “Greater Iran”.")#linebreak()#linebreak()#text("Another minor correction: while Al-Biruni was born in the tenth century, his work on the measurement of the Earth was published in the early eleventh century.")],
[#strong[#text("Is ")#mi("\\theta")#text(" really called the angle of declination?")]#linebreak()#linebreak()#text("This was a misnomer on my part; this angle is more commonly called the dip angle.")],
[#strong[#text("But the height of the mountain would be so small compared to the radius of the Earth! How could this method work?")]#linebreak()#linebreak()#text("Using the Taylor approximation ")#mi("\\cos \\theta \\approx 1 - \\theta^2/2")#text(", one can approximately write the relationship ")#mi("R = \\frac{h \\cos \\theta}{1-\\cos \\theta}")#text(" between the mountain height ")#mi("h")#text(", the Earth radius ")#mi("R")#text(", and the dip angle ")#mi("\\theta")#text(" (in radians) as ")#mi("R \\approx 2 h / \\theta^2")#text(". The key point here is the inverse quadratic dependence on ")#mi("\\theta")#text(", which allows for even relatively small values of ")#mi("h")#text(" to still be realistically useful for computing ")#mi("R")#text(". Al-Biruni’s measurement of the dip angle ")#mi("\\theta")#text(" was about ")#mi("0.01")#text(" radians, leading to an estimate of ")#mi("R")#text(" that is about four orders of magnitude larger than ")#mi("h")#text(", which is within ballpark at least of a typical height of a mountain (on the order of a kilometer) and the radius of the Earth (6400 kilometers).")],
[#strong[#text("Was the method really accurate to within a percentage point?")#linebreak()]#linebreak()#text("This is disputed, somewhat similarly to the previous calculations of Eratosthenes. Al-Biruni’s measurements were in cubits, but there were multiple incompatible types of cubit in use at the time. It has also been pointed out that atmospheric refraction effects would have created noticeable changes in the observed dip angle ")#mi("\\theta")#text(". It is thus likely that the true accuracy of Al-Biruni’s method was poorer than 1%, but that this was somehow compensated for by choosing a favorable conversion between cubits and modern units.")]
)

#heading(level: 1)[#text("Comments on the ")#link("https://www.youtube.com/watch?v=hFMaT9oRbs4")[#text("second part of the video")]]

#list(
[#link("https://youtu.be/hFMaT9oRbs4?t=73")[#text("1:13")]#text(" ")#strong[#text("Did Captain Cook set out to discover Australia?")]#linebreak()#linebreak()#text("One of the objectives of Cook’s first voyage was to discover the hypothetical continent of ")#link("https://en.wikipedia.org/wiki/Terra_Australis")[#text("Terra Australis")]#text(". This was considered to be distinct from Australia, which at the time was known as ")#link("https://en.wikipedia.org/wiki/New_Holland_(Australia)")[#text("New Holland")]#text(". As this name might suggest, prior to Cook’s voyage, the northwest coastline of New Holland had been explored by the Dutch; Cook instead explored the eastern coastline, naming this portion New South Wales. The entire continent was later renamed to Australia by the British government, following a suggestion of Matthew Flinders; and the concept of Terra Australis was abandoned.")],
[#link("https://youtu.be/hFMaT9oRbs4?t=280")[#text("4:40")]#text(" ")#strong[#text("The relative position of the Northern and Southern hemisphere observations is reversed from those earlier in the video.")]#linebreak()#linebreak()#text("Yes, this was a slight error in the animation; the labels here should be swapped for consistency of orientation.")],
[#link("https://youtu.be/hFMaT9oRbs4?t=426")[#text("7:06")]#text(" ")#strong[#text("So, when did they finally manage to measure the transit of Venus, and use this to compute the astronomical unit?")]#linebreak()#linebreak()#text("While Le Gentil had the misfortune to not be able to measure either the 1761 or 1769 transits, other expeditions of astronomers (led by Dixon-Mason, Chappe d’Auteroche, and Cook) did take measurements of one or both of these transits with varying degrees of success, with the measurements of Cook’s team of the 1769 transit in Tahiti being of particularly high quality. All of this data was assembled later by Lalande in 1771, leading to the most accurate measurement of the astronomical unit at the time (within 2.3% of modern values, which was about three times more accurate than any previous measurement).")],
[#link("https://youtu.be/hFMaT9oRbs4?t=533")[#text("8:53")]#text(" ")#strong[#text("What does it mean for the transit of Io to be “twenty minutes ahead of schedule” when Jupiter is in opposition (Jupiter is opposite to the Sun when viewed from the Earth)?")]#linebreak()#linebreak()#text("Actually, it should be halved to “ten minutes ahead of schedule”, with the transit being “ten minutes behind schedule” when Jupiter is in conjunction, with the net discrepancy being twenty minutes (or actually closer to 16 minutes when measured with modern technology). Both transits are being compared against an idealized periodic schedule in which the transits are occuring at a perfectly regular rate (about 42 hours), where the period is chosen to be the best fit to the actual data. This discrepancy is only noticeable after carefully comparing transit times over a period of months; at any given position of Jupiter, the Doppler effects of Earth moving towards or away from Jupiter would only affect shift each transit by just a few seconds compared to the previous transit, with the delays or accelerations only becoming cumulatively noticeable after many such transits.")#linebreak()#linebreak()#text("Also, the presentation here is oversimplified: at times of conjunction, Jupiter and Io are too close to the Sun for observation of the transit. Rømer actually observed the transits at other times than conjunction, and Huygens used more complicated trigonometry than what was presented here to infer a measurement for the speed of light in terms of the astronomical unit (which they had begun to measure a bit more accurately than in Aristarchus’s time; see the FAQ entry for ")#link("https://www.youtube.com/watch?v=YdOXS_9_P4U&t=917s")[#text("15:17")]#text(" in the first video).")],
[#link("https://youtu.be/hFMaT9oRbs4?t=605")[#text("10:05")]#text(" ")#strong[#text("Are the astrological signs for Earth and Venus swapped here?")]#linebreak()#linebreak()#text("Yes, this was a small mistake in the animation.")],
[#link("https://en.wikipedia.org/wiki/Proper_motion")[#text("10:34")]#text(" ")#strong[#text("Shouldn’t one have to account for the elliptical orbit of the Earth, as well as the proper motion of the star being observed, or the effects of general relativity?")]#linebreak()#linebreak()#text("Yes; the presentation given here is a simplified one to convey the idea of the method, but in the most advanced parallax measurements, such as the ones taken by the ")#link("https://en.wikipedia.org/wiki/Hipparcos")[#text("Hipparcos")]#text(" and ")#link("https://en.wikipedia.org/wiki/Gaia_(spacecraft)")[#text("Gaia")]#text(" spacecraft, these factors are taken into account, basically by taking as many measurements (not just two) as possible of a single star, and locating the best fit of that data to a multi-parameter model that incorporates the (known) orbit of the Earth with the (unknown) distance and motion of the star, as well as additional gravitational effects from other celestial bodies, such as the Sun and other planets.")],
[#link("https://youtu.be/hFMaT9oRbs4?t=893")[#text("14:53")]#text(" ")#strong[#text("The formula I was taught for apparent magnitude of stars looks a bit different from the one here.")]#linebreak()#linebreak()#text("This is because astronomers use a logarithmic scale to measure both ")#link("https://en.wikipedia.org/wiki/Apparent_magnitude")[#text("apparent magnitude")]#text(" ")#mi("m")#text(" and ")#link("https://en.wikipedia.org/wiki/Absolute_magnitude")[#text("absolute magnitude")]#text(" ")#mi("M")#text(". If one takes the logarithm of the inverse square law in the video, and performs the normalizations used by astronomers to define magnitude, one arrives at the standard relation ")#mi("M = m - 5 \\log_{10} d_{pc} + 5")#text(" between absolute and apparent magnitude.")#linebreak()#linebreak()#text("But this is an oversimplification, most notably due to neglect of the effects of ")#link("https://en.wikipedia.org/wiki/Extinction_(astronomy)")[#text("extinction")]#text(" effects caused by interstellar dust. This is not a major issue for the relatively short distances observable via parallax, but causes problems at larger scales of the ladder (see for instance the FAQ entry here for ")#link("https://youtu.be/hFMaT9oRbs4?t=1088")[#text("18:08")]#text("). To compensate for this, one can work in multiple frequencies of the spectrum (visible, x-ray, radio, etc.), as some frequencies are less susceptible to extinction than others. From the discrepancies between these frequencies one can infer the amount of extinction, leading to “dust maps” that can then be used to facilitate such corrections for subsequent measurements in the same area of the universe. (More generally, the trend in modern astronomy is towards “")#link("https://en.wikipedia.org/wiki/Multi-messenger_astronomy")[#text("multi-messenger astronomy")]#text("” in which one combines together very different types of measurements of the same object to obtain a more accurate understanding of that object and its surroundings.)")],
[#link("https://youtu.be/hFMaT9oRbs4?t=1088")[#text("18:08")]#text(" ")#strong[#text("Can we really measure the entire Milky Way with this method?")]#linebreak()#linebreak()#text("Strictly speaking, there is a “")#link("https://en.wikipedia.org/wiki/Zone_of_Avoidance")[#text("zone of avoidance")]#text("” on the far side of the Milky way that is very difficult to measure in the visible portion of the spectrum, due to the large amount of intervening stars, dust, and even a supermassive black hole in the galactic center. However, in recent years it has become possible to explore this zone to some extent using the radio, infrared, and x-ray portions of the spectrum, which are less affected by these factors.")#linebreak()],
[#link("https://youtu.be/hFMaT9oRbs4?t=1099")[#text("18:19")]#text(" ")#strong[#text("How did astronomers know that the Milky Way was only a small portion of the entire universe?")]#linebreak()#linebreak()#text("This issue was the topic of the “")#link("https://en.wikipedia.org/wiki/Great_Debate_(astronomy)")[#text("Great Debate")]#text("” in the early twentieth century. It was only with the work of Hubble using Leavitt’s law to measure distances to Magellanic clouds and “spiral nebulae” (that we now know to be other galaxies), building on earlier work of Leavitt and Hertzsprung, that it was conclusively established that these clouds and nebulae in fact were at much greater distances than the diameter of the Milky Way.")#linebreak()],
[#link("https://youtu.be/hFMaT9oRbs4?t=1125")[#text("18:45")]#text(" ")#strong[#text("How can one compensate for light blending effects when measuring the apparent magnitude of Cepheids?")]#linebreak()#linebreak()#text("This is a non-trivial task, especially if one demands a high level of accuracy. Using the highest resolution telescopes available (such as HST or JWST) is of course helpful, as is switching to other frequencies, such as near-infrared, where Cepheids are even brighter relative to nearby non-Cepheid stars. One can also apply sophisticated statistical methods to fit to models of the point spread of light from unwanted sources, and use nearby measurements of the same galaxy without the Cepheid as a reference to help calibrate those models. Improving the accuracy of the Cepheid portion of the distance ladder is an ongoing research activity in modern astronomy.")],
[#link("https://youtu.be/hFMaT9oRbs4?t=1134")[#text("18:54")]#text(" ")#strong[#text("What is the mechanism that causes Cepheids to oscillate?")]#linebreak()#linebreak()#text("For most stars, there is an equilibrium size: if the star’s radius collapses, then the reduced potential energy is converted to heat, creating pressure to pushing the star outward again; and conversely, if the star expands, then it cools, causing a reduction in pressure that no longer counteracts gravitational forces. But for Cepheids, there is an additional mechanism called the ")#link("https://en.wikipedia.org/wiki/Kappa%E2%80%93mechanism")[#text("kappa mechanism")]#text(": the increased temperature caused by contraction increases ionization of helium, which drains energy from the star and accelerates the contraction; conversely, the cooling caused by expansion causes the ionized helium to recombine, with the energy released accelerating the expansion. If the parameters of the Cepheid are in a certain “instability strip”, then the interaction of the kappa mechanism with the other mechanisms of stellar dynamics create a periodic oscillation in the Cepheid’s radius, which increases with the mass and brightness of the Cepheid.")#linebreak()#linebreak()#text("For a recent re-analysis of Leavitt’s original Cepheid data, see ")#link("https://arxiv.org/abs/2502.17438")[#text("this paper")]#text(".")],
[#link("https://youtu.be/hFMaT9oRbs4?t=1150")[#text("19:10")]#text(" ")#strong[#text("Did Leavitt mainly study the Cepheids in our own galaxy?")]#linebreak()#linebreak()#text("This was an inaccuracy in the presentation. Leavitt’s original breakthrough paper studied Cepheids in the ")#link("https://en.wikipedia.org/wiki/Small_Magellanic_Cloud")[#text("Small Magellanic Cloud")]#text(". At the time, the distance to this cloud was not known; indeed, it was a matter of debate whether this cloud was in the Milky Way, or some distance away from it. However, Leavitt (correctly) assumed that all the Cepheids in this cloud were roughly the same distance away from our solar system, so that the apparent brightness was proportional to the absolute brightness. This gave an uncalibrated form of Leavitt’s law between absolute brightness and period, subject to the (then unknown) distance to the Small Magellanic Cloud. After Leavitt’s work, there were several efforts (by Hertzsprung, Russell, and Shapley) to calibrate the law by using the few Cepheids for which other distance methods were available, such as parallax. (Main sequence fitting to the Hertzsprung-Russell diagram was not directly usable, as Cepheids did not lie on the main sequence; but in some cases one could indirectly use this method if the Cepheid was in the same stellar cluster as a main sequence star.) Once the law was calibrated, it could be used to measure distances to other Cepheids, and in particular to compute distances to extragalactic objects such as the Magellanic clouds.")],
[#link("https://youtu.be/hFMaT9oRbs4?t=1155")[#text("19:15")]#text(" ")#strong[#text("Was Leavitt’s law really a linear law between period and luminosity?")]#linebreak()#linebreak()#text("Strictly speaking, the ")#link("https://en.wikipedia.org/wiki/Period-luminosity_relation")[#text("period-luminosity relation")]#text(" commonly known as Leavitt’s law was a linear relation between the absolute magnitude of the Cepheid and the ")#emph[#text("logarithm")]#text(" of the period; undoing the logarithms, this becomes a ")#link("https://en.wikipedia.org/wiki/Power_law")[#text("power law")]#text(" between the luminosity and the period.")],
[#link("https://youtu.be/hFMaT9oRbs4?t=1226")[#text("20:26")]#text(" ")#strong[#text("Was Hubble the one to discover the redshift of galaxies?")]#linebreak()#linebreak()#text("This was an error on my part; Hubble was using earlier work of ")#link("https://en.wikipedia.org/wiki/Vesto_Slipher")[#text("Vesto Slipher")]#text(" on these redshifts, and combining it with his own measurements of distances using Leavitt’s law to arrive at the law that now bears his name; he was also assisted in his observations by ")#link("https://en.wikipedia.org/wiki/Milton_L._Humason")[#text("Milton Humason")]#text(". It should also be noted that Georges Lemaître had also independently arrived at essentially the same law a few years prior, but his work was published in a somewhat obscure journal and did not receive broad recognition until some time later.")#linebreak()],
[#link("https://youtu.be/hFMaT9oRbs4?t=1237")[#text("20:37")]#text(" ")#strong[#text("Hubble’s original graph doesn’t look like a very good fit to a linear law.")]#linebreak()#linebreak()#text("Hubble’s original data was somewhat noisy and inaccurate by modern standards, and the redshifts were affected by the ")#link("https://en.wikipedia.org/wiki/Peculiar_velocity")[#text("peculiar velocities")]#text(" of individual galaxies in addition to the expanding nature of the universe. However, as the data was extended to more galaxies, it became increasingly possible to compensate for these effects and obtain a much tighter fit, particularly at larger scales where the effects of peculiar velocity are less significant. See for instance ")#link("https://www.pnas.org/doi/10.1073/pnas.1424299112")[#text("this article from 2015")]#text(" where Hubble’s original graph is compared with a more modern graph. This more recent graph also reveals a slight nonlinear correction to Hubble’s law at very large scales that has led to the remarkable discovery that the expansion of the universe is in fact accelerating over time, a phenomenon that is attributed to a positive ")#link("https://en.wikipedia.org/wiki/Cosmological_constant")[#text("cosmological constant")]#text(" (or perhaps a more complex form of ")#link("https://en.wikipedia.org/wiki/Dark_energy")[#text("dark energy")]#text(" in the universe). On the other hand, even with this nonlinear correction, there continues to be a roughly 10% discrepancy of this law with predictions based primarily on the cosmic microwave background radiation; see the FAQ entry for ")#link("https://youtu.be/hFMaT9oRbs4?t=1429")[#text("23:49")]#text(".")],
[#link("https://youtu.be/hFMaT9oRbs4?t=1246")[#text("20:46")]#text(" ")#strong[#text("Does general relativity alone predict a uniformly expanding universe?")]#linebreak()#linebreak()#text("This was an oversimplification. ")#link("https://en.wikipedia.org/wiki/Einstein_field_equations")[#text("Einstein’s equations of general relativity")]#text(" contain a parameter ")#mi("\\Lambda")#text(", known as the ")#link("https://en.wikipedia.org/wiki/Cosmological_constant")[#text("cosmological constant")]#text(", which currently is only computable indirectly from fitting to experimental data. But even with this constant fixed, there are multiple solutions to these equations (basically because there are multiple possible initial conditions for the universe). For the purposes of cosmology, a particularly successful family of solutions are the solutions given by the ")#link("https://en.wikipedia.org/wiki/Lambda-CDM_model")[#text("Lambda-CDM model")]#text(". This family of solutions contains additional parameters, such as the density of dark matter in the universe. Depending on the precise values of these parameters, the universe could be expanding or contracting, with the rate of expansion or contraction either increasing, decreasing, or staying roughly constant. But if one fits this model to all available data (including not just red shift measurements, but also measurements on the cosmic microwave background radiation and the spatial distribution of galaxies), one deduces a version of Hubble’s law which is nearly linear, but with an additional correction at very large scales; see the next item of this FAQ.")],
[#link("https://youtu.be/hFMaT9oRbs4?t=1267")[#text("21:07")]#text(" ")#strong[#text("Is Hubble’s original law sufficiently accurate to allow for good measurements of distances at the scale of the observable universe?")]#linebreak()#linebreak()#text("Not really; as mentioned in the end of the video, there were additional efforts to cross-check and calibrate Hubble’s law at intermediate scales between the range of Cepheid methods (about 100 million light years) and observable universe scales (about 100 billion light years) by using further “")#link("https://en.wikipedia.org/wiki/Cosmic_distance_ladder#Standard_candles")[#text("standard candles")]#text("” than Cepheids, most notably ")#link("https://en.wikipedia.org/wiki/Type_Ia_supernova")[#text("Type Ia supernovae")]#text(" (which are bright enough and predictable enough to be usable out to about 10 billion light years), the ")#link("https://en.wikipedia.org/wiki/Tully%E2%80%93Fisher_relation")[#text("Tully-Fisher relation")]#text(" between the luminosity of a galaxy and its rotational speed, and ")#link("https://en.wikipedia.org/wiki/Gamma-ray_burst")[#text("gamma ray bursts")]#text(". It turns out that due to the accelerating nature of the universe’s expansion, Hubble’s law is not completely linear at these large scales; this important correction cannot be discerned purely from Cepheid data, but also requires the other standard candles, as well as fitting that data (as well as other observational data, such as the cosmic microwave background radiation) to the cosmological models provided by general relativity (with the best fitting models to date being some version of the ")#link("https://en.wikipedia.org/wiki/Lambda-CDM_model")[#text("Lambda-CDM model")]#text(").")#linebreak()#linebreak()#text("On the other hand, a naive linear extrapolation of Hubble’s original law to all larger scales does provide a very rough picture of the observable universe which, while too inaccurate for cutting edge research in astronomy, does give some general idea of its large-scale structure.")],
[#link("https://youtu.be/hFMaT9oRbs4?t=1275")[#text("21:15")]#text(" ")#strong[#text("Where did this guess of the observable universe being about 20% of the full universe come from?")]#linebreak()#linebreak()#text("There are some ways to get a lower bound on the size of the entire universe that go beyond the edge of the observable universe. One is through analysis of the ")#link("https://en.wikipedia.org/wiki/Cosmic_microwave_background")[#text("cosmic microwave background radiation")]#text(" (CMB), that has been carefully mapped out by several satellite observatories, most notably ")#link("https://en.wikipedia.org/wiki/Wilkinson_Microwave_Anisotropy_Probe")[#text("WMAP")]#text(" and ")#link("https://en.wikipedia.org/wiki/Planck_(spacecraft)")[#text("Planck")]#text(". Roughly speaking, a universe that was less than twice the size of the observable universe would create certain periodicities in the CMB data; such periodicities are not observed, so this provides a lower bound (see for instance ")#link("https://arxiv.org/abs/astro-ph/0604616")[#text("this paper")]#text(" for an example of such a calculation). The 20% number was a guess based on my vague recollection of these works, but there is no consensus currently on what the ratio truly is; there are some proposals that the entire universe is in fact several orders of magnitude larger than the observable one, and possibly even infinite. ")#linebreak()#linebreak()#text("The situation is somewhat analogous to Aristarchus’s measurement of the distance to the Sun, which was very sensitive to a small angle (the half-moon discrepancy). Here, the predicted size of the universe under the standard cosmological model is similarly dependent in a highly sensitive fashion on a measure ")#mi("\\Omega_k")#text(" of the flatness of the universe which, for reasons still not fully understood (but likely caused by some sort of inflation mechanism), happens to be extremely close to zero. As such, predictions for the size of the universe remain highly volatile at the current level of measurement accuracy.")],
[#link("https://youtu.be/hFMaT9oRbs4?t=1424")[#text("23:44")]#text(" ")#strong[#text("Was it a black hole collision that allowed for an independent measurement of Hubble’s law?")]#linebreak()#linebreak()#text("This was a slight error in the presentation. While the first gravitational wave observation by LIGO in 2015 was of a black hole collision, it did not come with an electromagnetic counterpart that allowed for a redshift calculation that would yield a Hubble’s law measurement. However, a later collision of neutron stars, observed in 2017, did come with an associated kilonova in which a redshift was calculated, and led to a Hubble measurement which was independent of most of the rungs of the distance ladder.")],
[#link("https://youtu.be/hFMaT9oRbs4?t=1429")[#text("23:49")]#text(" ")#strong[#text("Where can I learn more about this 10% discrepancy in Hubble’s law?")]#linebreak()#linebreak()#text("This is known as the ")#link("https://youtu.be/hFMaT9oRbs4?t=1431")[#text("Hubble tension")]#text(" (or, in more sensational media, the “crisis in cosmology”): roughly speaking, the various measurements of Hubble’s constant (either from climbing the cosmic distance ladder, or by fitting various observational data to standard cosmological models) tend to arrive at one of two values, that are about 10% apart from each other. The values based on gravitational wave observations are currently consistent with both values, due to significant error bars in this extremely sensitive method; but other more mature methods are now of sufficient accuracy that they are basically only consistent with one of the two values. Currently there is no consensus on the origin of this tension: possibilities include systemic biases in the observational data, subtle statistical issues with the methodology used to interpret the data, a correction to the standard cosmological model, the influence of some previously undiscovered law of physics, or some partial breakdown of the Copernican principle.")#linebreak()#linebreak()#text("For an accessible recent summary of the situation, see ")#link("https://youtu.be/I84skRsDO4M?t=649")[#text("this video")]#text(" by Becky Smethurst (“Dr. Becky”).")],
[#link("https://youtu.be/hFMaT9oRbs4?t=1489")[#text("24:49")]#text(" ")#strong[#text("So, what is a Type Ia supernova and why is it so useful in the distance ladder?")]#linebreak()#linebreak()#text("A ")#link("https://en.wikipedia.org/wiki/Type_Ia_supernova")[#text("Type Ia supernova")]#text(" occurs when a ")#link("https://en.wikipedia.org/wiki/White_dwarf")[#text("white dwarf")]#text(" in a binary system draws more and more mass from its companion star, until it reaches the ")#link("https://en.wikipedia.org/wiki/Chandrasekhar_limit")[#text("Chandrasekhar limit")]#text(", at which point its gravitational forces are strong enough to cause a collapse that increases the pressure to the point where a supernova is triggered via a process known as ")#link("https://en.wikipedia.org/wiki/Carbon_detonation")[#text("carbon detonation")]#text(". Because of the universal nature of the Chandrasekhar limit, all such supernovae have (as a first approximation) the same absolute brightness and can thus be used as standard candles in a similar fashion to Cepheids (but without the need to first measure any auxiliary observable, such as a period). But these supernovae are also far brighter than Cepheids, and can so this method can be used at significantly larger distances than the Cepheid method (roughly speaking it can handle distances of up to ~10 billion light years, whereas Cepheids are reliable out to ~100 million light years). Among other things, the supernovae measurements were the key to detecting an important nonlinear correction to Hubble’s law at these scales, leading to the remarkable conclusion that the expansion of the universe is in fact accelerating over time, which in the ")#link("https://en.wikipedia.org/wiki/Lambda-CDM_model")[#text("Lambda-CDM model")]#text(" corresponds to a positive ")#link("https://en.wikipedia.org/wiki/Cosmological_constant")[#text("cosmological constant")]#text(", though there are more complex “")#link("https://en.wikipedia.org/wiki/Dark_energy")[#text("dark energy")]#text("” models that are also proposed to explain this acceleration.")#linebreak()#linebreak()],
[#link("https://youtu.be/hFMaT9oRbs4?t=1494")[#text("24:54")]#text(" ")#strong[#text("Besides ")#link("https://en.wikipedia.org/wiki/Type_Ia_supernova")[#text("Type Ia supernovae")]#text(", I felt that a lot of other topics relevant to the modern distance ladder (e.g., the ")#link("https://en.wikipedia.org/wiki/Cosmic_microwave_background")[#text("cosmic microwave background radiation")]#text(", the ")#link("https://en.wikipedia.org/wiki/Lambda-CDM_model")[#text("Lambda CDM model")]#text(", ")#link("https://en.wikipedia.org/wiki/Dark_matter")[#text("dark matter")]#text(", ")#link("https://en.wikipedia.org/wiki/Dark_energy")[#text("dark energy")]#text(", ")#link("https://en.wikipedia.org/wiki/Cosmic_inflation")[#text("inflation")]#text(", ")#link("https://en.wikipedia.org/wiki/Multi-messenger_astronomy")[#text("multi-messenger astronomy")]#text(", etc.) were omitted.")]#linebreak()#linebreak()#text("This is partly due to time constraints, and the need for editing to tighten the narrative, but was also a conscious decision on my part. Advanced classes on the distance ladder will naturally focus on the most modern, sophisticated, and precise ways to measure distances, backed up by the latest mathematics, physics, technology, observational data, and cosmological models. However, the focus in this video series was rather different; we sought to portray the cosmic distance ladder as evolving in a fully synergestic way, across many historical eras, with the evolution of mathematics, science, and technology, as opposed to being a mere byproduct of the current state of these other disciplines. As one specific consequence of this change of focus, we emphasized the ")#emph[#text("first")]#text(" time any rung of the distance ladder was achieved, at the expense of more accurate and sophisticated later measurements at that rung. For instance, refinements in the measurement of the radius of the Earth since Eratosthenes, improvements in the measurement of the astronomical unit between Aristarchus and Cook, or the refinements of Hubble’s law and the cosmological model of the universe in the twentieth and twenty-first centuries, were largely omitted (though some of the answers in this FAQ are intended to address these omissions).")#linebreak()#linebreak()#text("Many of the topics not covered here (or only given a simplified treatment) are discussed in depth in other expositions, including other Youtube videos. I would welcome suggestions from readers for links to such resources in the comments to this post. Here is a partial list:")

#list(
[#text("“")#link("https://www.youtube.com/watch?v=G8cbIWMv0rI")[#text("Eratosthenes")]#text("” – Cosmos (Carl Sagan), video posted Apr 24, 2009 (originally released Oct 1, 1980, as part of the episode “The Shores of the Cosmic Ocean”).")],
[#text("“")#link("https://www.youtube.com/watch?v=HgNJwg2GISs&list=PLpH1IDQEoE8QWWTnWG5cK4ePCqg9W2608")[#text("How Far Away Is It")]#text("” – David Butler, a multi-part series beginning Aug 16 2013.")],
[#text("“")#link("https://www.youtube.com/watch?v=Phscjl0u6TI")[#text("How the Bizarre Path of Mars Reshaped Astronomy [Kepler’s Laws Part 1]")]#text("“, Welch Labs, May 8, 2024. See also ")#link("https://www.youtube.com/watch?v=MprJN5teQxc")[#text("Part 2")]#text(".")],
[#text("“")#link("https://youtu.be/I84skRsDO4M?t=649")[#text("An ASTROPHYSICIST’S TOP 5 space news stories of 2024")]#text("“, Becky Smethurst (Dr. Becky), Dec 26, 2024 – covers the Hubble tension as one of the stories.")],
[#text("“")#link("https://www.youtube.com/watch?v=038AkmPvltA")[#text("Measuring the Earth… from a vacation photo")]#text("“, George Lowther (Almost sure), Feb 22 2025.")],
[#text("“")#link("https://www.youtube.com/watch?v=shkcVDHOvAI")[#text("How Did This Ancient Genius Measure The Sun?")]#text("“, Ben Syversen, Feb 28 2025.")#linebreak()#linebreak()]
)]
)

#heading(level: 1)[#text("Comments (126)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/821b3243d8e188271fa328a40d99271860e254d65d4bd4dfbf4b411c5436803e-1d1580e916970774302f665eb1a552a66082e2025afb152e600282ee611c06be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dipuptk")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-687839")[#strong[#text("Dipuptk")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2025")])]

#list(
[#text("Hi! I’m a high school student.")],
[#text("My question is-")],
[#text("If time is based on gravity according to time dilation from theory of relativity,")],
[#text("Will humans gain an increased lifetime if they inhabit in a planet which has a stronger gravity than earth’s?")]
)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-687840")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2025")])]

#text("A human who travels to an extremely high gravity well and returns to Earth will have aged for less time subjectively than a “twin” who stayed on Earth the entire time, but from that traveller’s own perspective, time (and the aging process) would proceed at the usual rate (this is part of the general principle of relativity).")

#text("Without going into too many spoilers, this time dilation effect becomes a plot point in the (reasonably scientifically accurate, by Hollywood standards) movie “Interstellar”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/821b3243d8e188271fa328a40d99271860e254d65d4bd4dfbf4b411c5436803e-1d1580e916970774302f665eb1a552a66082e2025afb152e600282ee611c06be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dipuptk")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-687879")[#strong[#text("Dipuptk")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2025")])]

#text("Can we have triangled shapes inscribed in the topological shapes and all the points would meet the point of centre of mass created in a triangle usually. Why rectangles are chosen only, can’t we consider other shapes too like parallelograms?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-688197")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2025")])]

#text("Has this been proved correct")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-688199")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2025")])]

#text("In science (in contrast to pure mathematics), no fact is ever conclusively “proved”; however, the predictions of a theory can be tested repeatedly by experiment. The astronaut twin-paradox thought-experiment has not been replicated exactly of course, but there are smaller-scale experiments which do observe the time dilation predicted by theory. Most famously, the accuracy of modern GPS satellites require corrections to the clocks on the GPS satellites that match those predicted by general relativity.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/821b3243d8e188271fa328a40d99271860e254d65d4bd4dfbf4b411c5436803e-1d1580e916970774302f665eb1a552a66082e2025afb152e600282ee611c06be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dipuptk")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-687842")[#strong[#text("Dipuptk")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2025")])]

#text("Thank you for the information.")

#text("I actually didn’t mean that.I learnt theory of relativity and I know that it only seems like that but It’s only relative and velocity of light causes it.")

#text("Still, one thing confuses me here.Does gravity have any impact on time and how?")

#text("I also found one thing very intriguing… that is our solar system….")

#text("All planets do not orbit the sun as well as their own orbits at the same period and so the time sunlight takes to reach earth doesn’t match with other planets.That’s why, the duration of a day varies from planet to planet.Do we face relativity here anyhow!")

#text("For example, we calculate our ages with respect to earth’s orbit around the sun, it takes 365 days which we consider an year.But, other planets take either less or more of that time.If we lived in any of these planets, would our lifetime change by years?")

#text("I learnt through an article that Eddington had doubted Einstein’s relativity due to mercury’s strange behaviour towards sunlight. However, it later proved Einstein was right.I don’t know how and why it was proved that he was right, I Just want to know how they are related!")

#text("Well, I’m sorry…. I may be messing up things here but it’s just an awkward curiosity of mine.")

#text("I’ve another curiosity….. Are you really Terence Tao or his assistant or an AI!")

#text("It’s because It’s hard to believe that I’m speaking to one of the greatest mathematicians of the current world!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32002354fdb1af37590072a0a38e93f057a369cccc2396507811dc5470c5b52e-1c59676e2f898556da047f1478aaaabd7899daf8578c8c6b27876565c0f5147c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joris Ketelaars")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-688191")[#strong[#text("Joris Ketelaars")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2025")])]

#text("Was it a typo when you wrote “Cepheids are reliable out to ~10 billion light years” in the reaction to penultimate question? (The 24:49 one) Since it’s two orders of magnitude more than the 100Mly figure from the reaction to the 21:07 question just above it, which corresponds to the most distant measurement of a Cepheid at 29 Mpc")

#emph[#text("[Typos corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-688268")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2025")])]

#text("Just calculated the ")#link("https://en.wikipedia.org/wiki/Orbital_period")[#text("sidereal period")]#text(" of Mars.")

#text("$(780*2pi/365) – (780*2pi/x) = 2pi$")

#text("x = 780/((780/365) – 1) = 686.024096385542")

#text("there must be other things missing for that 1 day error.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-688270")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2025")])]

#text("An Earth year is closer to 365.25 days than 365 days (this is why we have leap years).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1254bf551f7ad0ce3035cb9ce7194c3b215a1759fe09a9e6d7dfa948a67aaa2c-84a5a20557cb204f997022c87bc079d8472191118455cdefdf6dabc0b48fc55d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of crispygracefully36b92a3bed")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-688501")[#strong[#text("crispygracefully36b92a3bed")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2025")])]

#text("Olá, terry. Muito bom o video. Tenho uma duvida. Como os antigos chegaram a conclusão que a terra não era plana e sim esferica? Isso passa meio batido no video, onde voce diz que aristoteles deduziu e isso e Erastotenes usou isso como base para medir o raio da terra. Mas medir o raio só faz sentido em uma terra esferica. Então, se ele partisse da ideia de uma terra plan com o sol pequeno, ele estaria medindo outra coisa que não seja o raio de uma esfera. espero que tenha tenha entendido. Esse questionamento é só para saber como as ideias foram construidas, pois nessa parte em especifico ficou muito vago para mim.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-688505")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2025")])]

#text("One such argument for the sphericity of the Earth that was available in Eratosthenes’ time is discussed ")#link("https://youtu.be/YdOXS_9_P4U?t=133")[#text("starting at 2:13 in the first video")]#text(", based on the shape of the Earth’s shadow on the Moon during lunar eclipses. Other arguments for sphericity known in that era include the fact that the set of constellations visible in, say, Egypt, were different from those in, say, Greece; that ships departing from a port would disappear below the horizon after travelling a certain distance in any direction; and that the radius of the visible portion of the Earth increased (again equally in all directions) as one increased the altitude of one’s viewing position.")

#text("See also the commentary in the blog post associated to the 4:50 timestamp of the first video.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-688523")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2025")])]

#text("When one stands on the summit of Uluru (Ayres rock) in Australia, which is high in the middle of a vast ‘flat’ plain, one can see that the horizon is curved and one can sense one is standing on a big ball about 4756 km diameter .. awesome feeling .. but it still feels like u are standing upright on top of that ball .. as distinct from hanging off the bottom by one’s feet .. which is what everybody else thinks .. when they say “we come from the land ‘downunder’ ” .. and the Southern Cross is above us….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-688730")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2025")])]

#text("my question is how the oberved and calculated wavelength of spectrum are diffeerent")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-688734")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2025")])]

#text("Common spectral lines, such as the ")#link("https://en.wikipedia.org/wiki/Balmer_series")[#text("hydrogen Balmer lines")]#text(" have a known value when not red-shifted that can be calculated from theory or laboratory experiment. This can then be checked against the corresponding spectral lines for the astronomical object being measured to determine the red shift. This can be a somewhat inaccurate measurement when only using a single spectral line, but becomes more precise when one uses multiple spectral lines simultaneously.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-688762")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2025")])]

#text("Are there any reasons (other than philosophical) to suppose that “the entire universe” has finite size?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-688767")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2025")])]

#text("At this point we don’t have enough experimental evidence to say either way; the standard Lambda-CDM model admits both positively curved (finite) and negatively curved (infinite) solutions, but observationally the curvature of the universe is remarkably close to zero – so, either very large but finite, or actually infinite, but we do not have strong evidence to rule out either case currently.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-688920")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2025")])]

#text("Hello! I have two questions:")#linebreak()#text("At 25:26 in the first video, it was said that Kepler obtained the orbit of Mars by “piecing together a giant jigsaw puzzle”, which confused me a bit because it seemed a bit “random”. Is there a more precise explanation?")

#text("Could there be some stars or even galaxies that are gradually approaching us on a macroscopic scale?")#linebreak()#text("Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-688937")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2025")])]

#text("The presentation in this video is oversimplified. The actual method of Kepler is actually quite sophisticated; I recommend the ")#link("https://www.youtube.com/watch?v=Phscjl0u6TI")[#text("series of")]#text(" ")#link("https://www.youtube.com/watch?v=MprJN5teQxc&t=767s")[#text("videos by WelchLabs")]#text(" on this topic.")

#text("Stars and galaxies do indeed have significant secular motion, both towards us, away from us, as well as in lateral directions, which can be picked up by various modern astronomical methods (such as redshift calculations, or long-term observations of the same star). One famous example is the Andromeda Galaxy, which is moving towards us at about 110 km/sec and is predicted to possibly collide with the Milky Way in about four billion years.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-688938")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2025")])]

#text("Why are cosmic collisions of galaxies rare but not so rare compared to stellar collisions within a galaxy?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-688940")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2025")])]

#text("A “collision” of galaxies actually does not result in that much matter actually coming in physical contact with each other, due to the vast emptiness of space; most of the stars in Andromeda, for instance, would not come anywhere close to any star in the Milky way, although their trajectories will very much be distorted by the gravitational effects of both galaxies. There is also a significant difference in distance ratios: the distance to Andromeda is roughly fifty times the radius of the Milky Way, but the distance to (say) Alpha Centauri is about sixty million Sun radii away.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-689003")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2025")])]

#text("Wonderfull presentation.")

#text("A comment: In the Copernican model, the planets did not actually move around the Sun following circles.")

#text("Each planet moves in its own ")#strong[#text("circular orbit (deferent)")]#text(" around the Sun, at a fixed distance and uniform speed.")#strong[#text("Inner planets (Mercury and Venus):")]

#list(
[#text("Always appear close to the Sun in the sky.")],
[#text("Their apparent motion results from their orbits being ")#strong[#text("inside")]#text(" Earth’s orbit.")],
[#text("They never appear opposite the Sun (never seen at midnight).")],
[#text("Their ")#strong[#text("phases")]#text(" (like the Moon’s) could be explained naturally by their geometry relative to the Sun and Earth.")]
)

#strong[#text("Outer planets (Mars, Jupiter, Saturn):")]

#list(
[#text("Move ")#strong[#text("outside")]#text(" Earth’s orbit.")],
[#text("Normally drift eastward against the stars, but occasionally appear to move ")#strong[#text("backward (retrograde motion)")]#text(" for a short time.")],
[#text("In Copernicus’s model, retrograde motion occurs ")#strong[#text("when Earth overtakes")]#text(" a slower-moving outer planet in its orbit—no epicycles needed to explain it geometrically.")]
)

#text("Role of Epicycles")

#text("Although Copernicus greatly ")#strong[#text("simplified")]#text(" planetary motion, he ")#strong[#text("still used small epicycles")]#text(" to achieve better numerical accuracy because he insisted on ")#strong[#text("perfect circular orbits")]#text(".")

#text("That’s why Kepler’s leap beyond Ptolemy was actually much greater. The Copernican revolution was accomplished by Kepler.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-689007")[#strong[#text("Einstein’s archives at the Einstein Paper Project, Pasadena (LA) – M A A")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2025")]

#text("[…] of “pure genius”, as recently highlighted in 3B1B video featuring Prof. Tao. In this blog, in the comment section, it was being made clear that in fact, the actual comment was “an […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Climbing the cosmic distance ladder: another sample chapter | What's new")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-689113")[#strong[#text("Climbing the cosmic distance ladder: another sample chapter | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2025")])]

#text("[…] We welcome feedback of course, and are continuing to work to complete the book despite the various delays. In the mean time, you can check out our instagram account for the project, or the pair of videos that Grant Sanderson (3blue1brown) produced with us on this topic, which I previously blogged about here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-689129")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2025")])]

#text("Wow, tremendous amount of scholarship! One little grammar error in the post; “an uniformly” should be “a uniformly” since even though u is a vowel letter it is pronounced as “you” here rather than “uh” as in “uninformed”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-689340")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2025")])]

#text("If we couple the Sun-Earth and Earth-Moon system why has the triple system been stable for 3+ billion years even though we know the orbits themselves have evolved?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-689341")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2025")])]

#text("This is a great question! It turns out that while n-body systems are not exactly solvable in general, and will eventually exhibit chaotic behavior, there is also a surprising amount of stability present as well. Mathematically, this can be quantified through results such as ")#link("https://en.wikipedia.org/wiki/Nekhoroshev_estimates")[#text("Nekhoroshev stability")]#text(" or the ")#link("https://en.wikipedia.org/wiki/Kolmogorov%E2%80%93Arnold%E2%80%93Moser_theorem")[#text("KAM theorem")]#text(", and relates to the phenomena of resonances between frequencies whose ratios have certain number-theoretic properties.")

#text("One should also bear in mind the strong effect of survivor bias here. It is likely that the Solar System contained, in the past, other subsystems that eventually degenerated and for which little trace remains today, but obviously there are no contributions to current astronomical observations from inhabitants of such subsystems. (For instance, I believe the current belief is that the present-day asteroid belt is a remnant of a more massive system from the early history of the Solar System, though I do not know if this protosystem is believed to have had contained planet-sized objects.) The planets that we see today (and their major moons) all have stable orbits (at least on the time scales up to a million years or so), but this does not mean that the majority of potential orbits are stable. For instance, I think there is recent research suggesting that some of the minor inner moons of Uranus may experience orbital decay or collisions within a few million years. The orbit of Phobos around Mars is also unstable, though this orbit is not expected to decay completely until about 50 million years from now. And comets are perhaps the main remaining source of instability in the Solar System, occasionally even colliding with planets as seen for instance in the Shoemaker-Levy impact with Jupiter in 1994.")

#text("The distance to the Moon from the Earth also lies safely between the outer limit of the ")#link("https://en.wikipedia.org/wiki/Hill_sphere")[#text("Hill sphere")]#text(" and the lower ")#text("Roche limit")#text(", which already explains a lot of the long-term stability. The reason that the Moon does this is again likely due to survivor bias; any other satellite that ventured too close to either the Roche limit or the Hill sphere would probably have ceased to orbit the Earth many millions of years ago. (The fact that the lunar month is not in any particular resonance with other relevant periods such as the solar year, the solar day, or the orbital periods of Jupiter or Saturn, may also be a (minor) additional stabilizing factor.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-689345")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2025")])]

#enum(start: 1, 
[#text("“The reason that the Moon does this is again likely due to survivor bias; any other satellite that ventured too close to either the Roche limit or the Hill sphere would probably have ceased to orbit the Earth many millions of years ago.”")

#text("Implies: Other moons would have collided with earth (any evidence?) or their trajectories would have altered (unlikely to have any evidence).")

#text("Other planets also have stable moons. Odds may be tiny to have stable moons but we are one of many solar systems. Evidence of likeliness of moon appearances in exoplanets might question reliance on survivor bias as way out.")],
[#text("“orbit of Phobos around Mars is also unstable, though this orbit is not expected to decay completely until about 50 million years from now” “I think there is recent research suggesting that some of the minor inner moons of Uranus may experience orbital decay or collisions within a few million years.”")

#text("Millions of years is still a fraction in the billions of years scale of solar systems. So why suddenly now (millions of years from now)? Does it mean there were many more moons around planets over the scale of billions of years? Maybe analysis of exoplanet moon distributions and age say something.")]
)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-689350")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2025")])]

#text("There is a seriously considered hypothesis that the current Moon was in fact created by such a major collision with Earth in the distant past: ")#link("https://en.wikipedia.org/wiki/Theia_(hypothetical_planet)")[#text("https://en.wikipedia.org/wiki/Theia_(hypothetical_planet)")]#text(" . Similarly, Saturn is hypothesized to also have had an additional major moon in the past: ")#link("https://en.wikipedia.org/wiki/Chrysalis_(hypothetical_moon)")[#text("https://en.wikipedia.org/wiki/Chrysalis_(hypothetical_moon)")]#text(" . Most likely there have been major changes to the Solar System over many epochs in its history (particularly in its very early stages of evolution), though with the frequency of such events gradually decreasing over time as the most unstable components of the system eventually meet some violent end. Currently it seems the only main instabilities are confined to comets, asteroids, and some minor moons, with the absorption of most of Chrysalis by Saturn (and with the remainder ending up forming Saturn’s famous rings) ~200 million years ago the last (hypothetical) major change to the composition of the Solar System that has been proposed. The scientific literature focuses predominantly on the dynamics which are recent in astronomical terms (within a million years of the present, for instance), but this is recency bias, caused in part by the fact that we simply do not have enough data to make fine-scaled predictions about the precise makeup of the Solar System at larger time scales than these. I agree though that as more exoplanet data comes in, we should have a better statistical understanding at least of the mechanics and outcome of planetary evolution.")

#text("One possibly anomalous feature of the Earth-Moon system is that the Moon is a relatively sizeable fraction of the Earth in mass. Many other planets of the Solar System have moons, but in almost all other cases these moons are of negligible mass compared to the planet that they orbit. (The Pluto-Charon system is the closest example similar to Earth-Moon, though of course Pluto is now classified as a dwarf planet rather than a true planet, due to its inability to clear its orbit of other masses.) It is theorized that this is related to the Theia impact hypothesis mentioned earlier.")

#text("Finally, the enormous number of impact craters observed on our Moon (or other astronomical bodies not subject to the forces of erosion) are further evidence that there were more astronomical bodies in the early history of the Solar System than they are now (particularly during the Late Heavy Bombardment, ")#link("https://en.wikipedia.org/wiki/Late_Heavy_Bombardment")[#text("https://en.wikipedia.org/wiki/Late_Heavy_Bombardment")]#text(" , although there is still scientific debate as to the magnitude and timing of this bombardment), but they have largely been cleared by now, with many being absorbed or captured by Jupiter and Saturn, for instance.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-689352")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2025")])]

#text("The rebuttal of evidence that craters on moon corresponds to collision with other ‘moons’ or former neighbors of earth is the lack on 5 (picking a small number) or more large 500 or so mile crater features on moon. If earth had former neighbors it is likely mars had too but the crater features on mars are not prominent and nothing suggesting planetary scale impacts. But the rebuttal to the rebuttal is that on radius of ‘moon’ to radius of planet ratio scale earth’s moon is an anomaly but it could be larger moons were absorbed by the larger planets they orbit. If indeed our moon had siblings moons of other planets should also have had siblings. Looking for evidence in other rocky moons of bigger planets for their former siblings might be a stretch since the planets themselves are much larger than earth and there is much room to collide with the homing planet rather than other moons. And these planets themselves are gas giants. Data from atmosphere less moons of exoplanets where the planets themselves are small might be the best hope towards a ‘direct’ evidence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-689354")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2025")])]

#text("The Martian atmosphere is not as dense as Earth’s, however it has served to erode a significant amount of past crater impacts, so its record is not directly comparable with the Moon.")

#text("In any event, due to the complex interplay of all the different physical and dynamical effects in play here, extrapolating based on one or two pieces of data can only get one so far. In the absence of sufficient exoplanet data, comprehensive mathematical simulations of the early Solar System that attempt to incorporate as many relevant factors as possible are the most scientific way to proceed currently. My understanding is that the current leading model is the ")#text("five-planet Nice model")#text(", which has reasonably good agreement with all the current observed features of the solar system, including crater impact data, distribution of planets and moons, etc..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-689355")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2025")])]

#text("Interesting. Does the nice model explain exoplanetary systems?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-689500")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2025")])]

#text("LIGO interferometry can resolve 10^-19 mtrs between mirrors and I believe LISA can do better.")

#text("1. If we had a resolution capability better than h (planck’s constant) what would change in astronomy?")

#text("2. Conversely is there large scale phenomenon which can nail resolution below h (which would indicate h is not the correct limit)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-689546")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2026")])]

#text("For at least a century Europeans dominated global sea trade before colonialism set foothold in Asia. Asian entities were arguably on par with Europeans in military and technological power then. Is it because of advances in mathematical celestial mechanics in Europe in the 16th century which did not happen in Asian countries only Europeans dominated sea trade after medieval Europe which gave rise to seeds of colonialism in one direction?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-689613")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2026")])]

#text("Regarding the example shown in the video of Kepler’s method for deducing the shape of an orbit, I was curious if using a different planet than Mars with a shorter orbit would simplify the calculations by providing more data points in the set used by Kepler? Or are there other issues with the obvservations of these planets that would make it more difficult to use them?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-689616")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2026")])]

#text("Kepler’s method in principle works for all the planets, although Jupiter and Saturn’s orbits took considerable time for Kepler to work out due to the large orbital period. The inner planets of Mercury and Venus have shorter periods, but are often difficult to measure (especially with the naked eye astronomy that was practiced by Brahe) due to their angular proximity to the Sun, so Mars was probably the best available planet to work with initially.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-2/#comment-692838")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2026")])]

#text("Dear Prof. Tao,")

#text("Thank you to you and Grant for the phenomenal video series, and particularly for this detailed errata and commentary post. Your discussion regarding the precise boundaries of cosmological claims—and the deliberate separation of historical geometric intuition from modern Lambda-CDM parametrizations—deeply resonated with a formal verification project our team just concluded.")

#text("In the video, you highlighted Kepler’s ")#emph[#text("Mysterium Cosmographicum")]#text(" and his attempt to use the Platonic solids (including the tetrahedron) to dictate the physical distance ladder of the solar system. I have recently encountered a striking mathematical inversion of this idea: using distance dilations of a tetrahedron to uncover an intrinsic algebraic truth.")

#text("I was analyzing a 12-point projective configuration obtained by extending the vertices of a tetrahedral normal form along incident edge directions, using the lengths of the opposite edges (L_{ij}) as the dilation parameters. When applying the quadratic Veronese embedding to these 12 points, the resulting $12 \\times 10$ matrix naturally collapses to rank 9, placing the points in a unique projective hyperplane {P}^8 subset {P}^9.")

#text("What surprised us—and where your commentary on careful claim-scoping hits home—was the algebraic foundation of this collapse. We initially assumed the rank-deficiency relied heavily on the physical geometry of the shape. However, the exact right-kernel identity M . q = 0 is actually established generically over the ")#strong[#text("free rational-function field")]#text(" K = {Frac}({Q}[x_2, ….., z_4, L_{12}, ….., L_{34}])$. It does not require a quotient by the Euclidean metric ideal to force the rank drop. The algebraic dependency is intrinsic to the combinatorial structure itself.")

#text("Furthermore, your point about the historical limits of technology (e.g., Aristarchus lacking clocks that work in the dark) mirrors the modern limits of formal verification. To prove this theorem, the expanded polynomial witnesses were simply too massive to normalize natively inside a formal proof assistant. I had to adopt a strict “Trust but Verify” epistemological boundary: I used Macaulay2 to compute and verify the massive symbolic witnesses (the right-kernel vector and the non-zero 9 * 9 minor determinant), and then used Lean 4 strictly to kernel-check the abstract rank-sandwich certificate.")

#text("Thank you for continuing to beautifully articulate the intersection of geometric intuition, raw calculation, and formal rigor. This video series—and the corrections here—were a fantastic watch for me .")

#text("Thank You for your time")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687180")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2025")])]

#text("I really enjoyed the video and I found that the animations are very helpful. I am eager to watch the second part : thank you !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687182")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2025")])]

#text("What is remarkable in the parallel rays thought is the embedding of corpuscular theory of light in ancient Greek thought. Without an ultimate philosophical underpinning of the nature of light parallel rays theory of light can be assumed. Do you know the philosophical reasonings in Greek thought behind the assumption of parallel rays theory of light without any physics experiments? It seems to be different from other ancient civilizations view. It might be argued that the origin of the quest to identify distances themselves were a way to justify the corpuscular philosophy. Is there any evidence for this?")

#text("Also other civilizations had period of orbits of planets in their astrological beliefs long before the middle ages without knowledge of distances. However the video states that period of Mars was known only in the modern European era post 16th century. Do you know other civilizations had guessed period of orbits of planets integrated into their astrological works with or without an heliocentric view?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687183")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2025")])]

#text("Euclid’s second best known book ")#emph[#text("Optics")]#text(" postulates that light travels in straight lines, which is the most important axiom needed for this analysis, but does get other fundamental facts about light wrong, in particular subscribing to the emission theory of light rather than an intromission theory, with the debate not being conclusively settled until the Islamic golden age. Still, the idea of starting with an axiomatic approach at all, however flawed, seemed to have been somewhat unique to the Greek school in this era.")

#text("It is the sidereal period of Mars (687 days) that was first computed correctly by Copernicus, as even the very concept of this period for any planet other than the Earth basically requires the heliocentric model to begin with. But the synodic period of Mars (780 days) was significantly easier to discern from observational data, and seems to have been known to reasonable accuracy even to the ancient Babylonians.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687187")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2025")])]

#text("I think you might be wrong with Copernicus being the first. Check ")#link("https://en.wikipedia.org/wiki/Surya_Siddhanta")[#text("https://en.wikipedia.org/wiki/Surya_Siddhanta")]#text(" and ")#link("https://en.wikipedia.org/wiki/Aryabhata")[#text("https://en.wikipedia.org/wiki/Aryabhata")]#text(". If there were Greek influences, 1) they should be after 350BC and 2) there should be transfer of knowledge of astronomical distances (which does not seem to be the case) and lesser errors in the Surya Siddhanta for measurement of sizes of astronomical objects (which I am not sure is the case). Tilts are important in astrology and it is not clear how the measurements were achieved.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687189")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2025")])]

#text("Interesting! It appears that these works did contain several calculations that are closely related to Copernicus’s computation of sidereal periods of planets in a heliocentric model (such as the computation of extremely long periods (“yuga”) for the solar system as a whole, on the order of millions of years), but they were working instead in a geocentric model (with Ptolemaic-style epicycles), and it takes a certain amount of mathematical conversion between the models to extract, for instance, the 687 day sidereal period of Mars from those works, though it can be done. (Most likely some of the Islamic-era tables that Copernicus was drawing from to perform the same calculations included some input from these Indian sources, in addition to the older Greek and Babylonian sources.)")

#text("In principle, the sidereal period of (say) Mars could even be extracted purely from Babylonian data (albeit with lower accuracy) once one had the heliocentric model in which all planets moved in periodic orbits around the Sun, but I have not found a source prior to Copernicus where this extraction was explicitly performed within that source (as opposed to in a modern re-interpretation of that source). These sidereal periods were “hidden in plain sight” in the data for millennia, but it required the perspective of the heliocentric model to bring them to prominence.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687190")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2025")])]

#text("Also note wiki says Ptolemy (Millennium before Copernicus) knew (")#link("https://en.wikipedia.org/wiki/Surya_Siddhanta#Importance_in_history_of_science")[#text("https://en.wikipedia.org/wiki/Surya_Siddhanta#Importance_in_history_of_science")]#text(") the sidereal period of Mars before Hindu-Arabic decimals were provided and before sophisticated Trigonometry was available. But Ptolemy lived after Alexander left what was India then for 100s of years. So it is possible Surya Siddhanta is independent of Ptolemy. But it is not clear how two independent teams arrived at similar mechanisms of mathematical techniques in the pre-internet era. We do not know if Aryabhatta himself (unlikely) made all the calculations of orbits etc that were known to Ptolemy (likely built on the shoulder of Greek giants) but were derived from even earlier (possibly) independent calculations. We do know Greek planetary God names and Hindu God names had common roots. But the position of the Gods in their relative hierarchy changes in Hinduism as it evolved (For example post 1000AD we cannot find temples of Indra (who can be compared with Zeus in Greek culture) but temples in Thailand continued to be maintained.. although it is now sensible to compare Zeus with Brihaspati (Jupiter) who is significant in Hindu astrology).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687192")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2025")])]

#text("The numbers in the table of implied sidereal periods given in the Wikipedia article come from the 1935 work of Burgess (see pages 27-28 of ")#link("https://archive.org/details/SuryaSiddhantaTranslation/page/n69/mode/2up?view=theater")[#text("this link")]#text(") in which he translates the models of Ptolemy and the Siddhanta into a modern, post-Copernican form, for instance correcting for Ptolemy’s incorrect value of the motion of the equinox to infer a mean sidereal angular motion for each planet, and in the case of the Siddhanta, deducing the sidereal period of the planets by fitting the Copernican heliocentric model to the data actually provided in the Siddhanta, namely the length of a yuga and the number of conjunctions of each planet within that yuga (see page 17). However, these sidereal periods are not explicit in either reference; they are only extracted in a post-Copernican analysis from the modern era. To quote from page 17 of the Burgess reference: “But the apparent motions of the planets are greatly complicated by the fact, unknown to the Greek and the Hindu, that they are revolving around a center about which the earth is also revolving.”")

#text("As mentioned in my previous comment, the raw data and computation necessary to compute the sidereal period of Mars and the other planets (with a low level of accuracy) was already available in principle even to the ancient Babylonians, who possessed enough mathematical skill to verify for instance that ")#mi("1/365 - 1/780")#text(" was very close to ")#mi("1/689")#text(" (though of course they would not have used Hindu-Arabic numerals for this calculation). What was missing though was the heliocentric perspective that elevated the fundamental importance of these sidereal periods above more observationally evident quantities such as the synodic periods of the planets (or the number of conjunctions in a fixed period of time such as a yuga).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687193")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2025")])]

#text("“As quoted on page 17 of the Burgess reference: “But the apparent motions of the planets are greatly complicated by the fact, unknown to the Greek and the Hindu, that they are revolving around a center about which the earth is also revolving.”")

#text("I am not sure of this. Because all the temples which has an abode for the Navagrahas (Nine planets) have the abode constructed with Sun as the center. I am unable to find when the worship started and how old it is. But it is reasonable to say the Cholas knew of it (")#link("https://en.wikipedia.org/wiki/Navagraha_temples#Navagraha_temples_in_Tamil_Nadu")[#text("https://en.wikipedia.org/wiki/Navagraha_temples#Navagraha_temples_in_Tamil_Nadu")]#text(") and Cholas peaked well before European renaissance (")#link("https://en.wikipedia.org/wiki/Chola_Empire")[#text("https://en.wikipedia.org/wiki/Chola_Empire")]#text("). All one needs for evidence is a picture from a temple from the Chola dynasty of such a Navagraha worship abode but I am unable to find this on the internet.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687195")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2025")])]

#text("The Navagrahas omits the Earth – an absolutely crucial component of any heliocentric model – and also includes two “shadow planets” to generate eclipses, which are not present in the heliocentric model. In particular, the most important insight of the heliocentric model – namely, that the Earth has much the same status as the other planets in the Solar System – is not indicated at all from these displays; if anything, the absence of the Earth only serves to reinforce a geocentric perspective. Given that the major astronomical texts in this period such as the Siddhanta explicitly adopt a geocentric model, I would not view these religious arrangements as strong evidence that geocentrism was anything other than the norm in the Indian astronomy of the period.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687194")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2025")])]

#text("This should suffice ")#link("https://en.wikipedia.org/wiki/Kapaleeshwarar_Temple")[#text("https://en.wikipedia.org/wiki/Kapaleeshwarar_Temple")]#text(" as there is a Navagraha worship abode but I cannot find pictures on internet.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687196")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2025")])]

#text("Thank you that clarifies a lot. ")#link("https://www.quora.com/Who-proposed-heliocentrism-first-Aryabhatta-or-Copernicus")[#text("https://www.quora.com/Who-proposed-heliocentrism-first-Aryabhatta-or-Copernicus")]#text(" clarifies influence of Greek astronomers on Aryabhatta too. Still it would be nice if we had access to documents such as those in the library of Alexandria or if the ancient Hindu temples were not plundered. And Sun in the center of the Navagrahas at least indicates that the Hindus were aware of the size of the Sun. I do not know what additional things it could indicate.. as to whether it indicates if they already knew before the 1st millennia that the other grahas had apparent orbit around the Sun and whether such tweaks were consistent with geocentrism and whether Hindus were ready to accept inconsistencies into the religious frameworks (and whether they were ready to accept consistencies from the Greek knowledge such as relative size of the Sun (unlike the Greeks themselves)).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687188")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2025")])]

#text("Also arguably Hinduism as practiced (but not as philosophized) is about worship of deities of planets and planets themselves directly. There is an age old tradition for worshipping Navagrahas (nine planets) by circling their representative statues in a square (in south Indian temples) with 8 statues representing 8 planets (Moon and two lunar nodes are considered planets) and the Sun in the center. It would be interesting to know how old this tradition of heliocentric model has been worshipped.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fde0676455d8e524e39020afbe2fcb930a65feaf1a0afa8d5d929e9e3fd6851-76b68ed859d779a6b5a1a90e0bf6deed7f91652e7643b64e1fa4173a1684b074.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Πώς μετράμε το σύμπαν; – physicsgg")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687199")[#strong[#text("Πώς μετράμε το σύμπαν; – physicsgg")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2025")])]

#text("[…] ιστότοπο του Terence Taο (ΕΔΩ) περιέχονται περαιτέρω διευκρινίσεις και απαντήσεις […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687201")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2025")])]

#text("I was curious about how Kepler pieced together the orbit of Earth from those disjoint pieces he obtained from the orbit of Mars. To me, this seems like a superhuman effort.")

#text("However, it is rather frustrating to find sources confirming exactly how this was done. From what I gathered, Kepler never actually figured out that the orbit of the earth was an ellipse! He only assumed this after he had figured out that the orbit of Mars is an ellipse. He figured out that the orbit of Mars caved in slightly from the circular orbit; his idea of measuring the angles every 683 days was instrumental in his disproof that Mars had a circular orbit. But from what I gathered (and I couldn’t find a source explicitly confirming this), he just worked with the model that Earth had a circular orbit which obeyed his second (area) law and used that with various trial and error with mathematical models to deduce that the orbit of Mars is an ellipse.")

#text("Perhaps you have more insight on this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687208")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2025")])]

#text("Kepler worked for many years on this problem, with several incomplete results and dead ends – I believe at an early stage he had even tried fitting the data to an ellipse, but had discarded this approach due to an unfortunate numerical miscalculation.")

#text("The fact that Mars’s orbit was not perfectly in the ecliptic plane actually helped Kepler fix at least some pieces of this “jigsaw puzzle”, despite apparently adding more complexity to the problem. In particular, Brahe’s measurements of ecliptic latitude of Mars at times of opposition would allow Kepler to work out the location to Mars at those times in terms of Mars’s orbital plane with respect to the ecliptic plane. Some further data fitting would have needed to be done to determine that orbital plane, but this is a significantly simpler problem than determining the full orbit, as there are much fewer degrees of freedom.")

#text("Another fact that would have been helpful in piecing together the “jigsaw puzzle” was that the Earth would have had to return to the same position every 365 days, which allowed some of these “jigsaw pieces” to connect to each other.")

#text("Each “jigsaw piece” also would have provided evidence of Kepler’s second law even without fitting those individual pieces into a larger orbit, so once he had grasped the universality and significance of that law, that would have provided further clues to gluing these pieces together. But it is unlikely that he proceeded in a purely deductive fashion from such axioms; as you say, most likely he kept trying different hypotheses that slowly revealed more and more of the structure of the solution, until he found one that fit all the partial information and laws that he had already worked out to astonishing accuracy.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687215")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2025")])]

#text("Was there any sort of inverse square law available when Kepler was around or was it brought up by Newton? Would it have helped Kepler if there was any idea of inverse square law floating around?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687222")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2025")])]

#text("Given that neither Newtonian mechanics nor differential calculus was available in anything resembling modern form at Kepler’s time, I doubt that even such an explicit hint would have been usable by Kepler. Historically, the arrow of causality went the other way: Kepler’s laws helped guide Newton to his universal law of gravitation based on an inverse square force.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687445")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2025")])]

#text("Given the limited and error-prone data, Kepler got really lucky that his task was the orbit of Mars. It has 6 times the eccentricity as Earth, and more than all the other reasonable options.")

#text("Thank you kindly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/783951f401dd6bbdf6dea2e0d64c1cd714a7b55ca0d370eb3580222d1e382811-6cb9b57ee1135b4cae7af134c9c8306bdbc6234f041bd5b19ecec23066c14038.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Klein-Baer")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687221")[#strong[#text("Nick Klein-Baer")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2025")])]

#text("I was glad to see that the question of how Eratosthenes knew that the sun’s rays are (effectively) parallel is addressed here, and just wanted to share this ")#link("https://physics.stackexchange.com/a/81855")[#text("excellent physics stack exchange post")]#text(" I came across years ago when wondering about that very question. It’s particularly apt here as it provides a nice ")#emph[#text("visual")]#text(" explanation of how this can be deduced from simple celestial observations.")

#text("When I first came across that post I don’t recall having the impression that it was saying “this is literally how they knew”, so much as “this is one way they might have known”. But as I revisit it now I see that the poster does indicate that this was in fact the line of reasoning presented by Aristarchus in ")#link("https://en.wikipedia.org/wiki/On_the_Sizes_and_Distances_(Aristarchus)")[#text("On the Sizes and Distances (of the Sun and Moon)")]#text(".")

#text("Thanks so much for the excellent video and blog post!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bcf76f63440f7d79f4d6a36dd9618b4808d330395daf5d19dcbec4f77b09c78-49c4881b95c0d221d329660a593af13b6c9d9adf71763763ef5974b85918a77d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jmdpark")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687227")[#strong[#text("jmdpark")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2025")])]

#text("Nice popularized expansion on the old cosmic distance ladder lecture, thanks for more details.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687240")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("Too bad there wasn’t enough time to dive deeper into standard sirens, especially multi-messenger astronomy and GW170817—the only gravitational wave source we’ve been able to pinpoint. Thanks to their gamma ray emmited during the collision of the two neutron stars that luckily crossed earth some 144 millions years later.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687259")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("I am sure there are other videos or other popular presentations by professional astronomers who would do such a deep dive; I would welcome any such links by readers of this blog to be posted as comments here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cc0aa7e37d1fe50bd4a986870ffa0dfb6dabee23e75d94c7762e62a14b994363-9532059c6a4b146746a81b453ee8b34576d653b945d7c61f44aa08260cb4a35a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig Cahillane")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687379")[#strong[#text("Craig Cahillane")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2025")])]

#text("Hi Terence, thanks to you and Grant for this wonderful video! I was very excited to see LIGO and standard sirens mentioned in the video as an independent measure of the Hubble constant.")

#text("Here is the link to the paper where the famous GW170817 LIGO gravitational-wave from a neutron-star merger detected at nearly the same time as a GRB was used to estimate the Hubble constant:")#linebreak()#text("Nature: ")#link("https://www.nature.com/articles/nature24471")[#text("https://www.nature.com/articles/nature24471")]#text(" ")#linebreak()#text("arXiv: ")#link("https://arxiv.org/abs/1710.05835")[#text("https://arxiv.org/abs/1710.05835")]

#text("Some cliff notes from the paper:")

#enum(start: 1, 
[#text("In the near universe, ")#mi("v_H = H_0 d")#text(", ")#linebreak()#text("where ")#mi("v_H")#text(" is the “Hubble flow” velocity of the source away from us, ")#linebreak()#mi("H_0")#text(" is the Hubble constant, ")#linebreak()#text("and ")#mi("d")#text(" is the distance from us to the source.")],
[#text("Gravitational wave detections are ")#emph[#text("very good")]#text(" at specifying the distance $d$ that the astrophysical source merged away from us. This is due to the very predictable GW waveform of a binary neutron star merger, which precisely constrains the energy that the source can emit.")#linebreak()#text("From this, a decreasing amplitude of GW detected tells us how far away the GW source was.")],
[#text("Thanks to the GW, GRB, and subsequent telescope follow-up, we were able to pinpoint the source galaxy as NGC 4993. This galaxy has been part of some telescopic surveys, whose results were used to precisely estimate ")#mi("v_H")#text(".")]
)

#text("I like this paper because while it represents the culmination of an enormous level of work and preparedness, the physics itself is so straightforward. We hope to catch more multimessenger sources in the very near future to further constrain the Hubble constant.")

#text("Another option is the so-called ")#emph[#text("dark sirens")]#text(" which rely on binary black hole mergers distance and sky locations estimates convolved with galaxy catalogs to estimate the Hubble constant: ")#link("https://arxiv.org/abs/1901.01540")[#text("https://arxiv.org/abs/1901.01540")]#text(". ")#linebreak()#text("While each individual estimate is lightly constraining, once you pile on a hundred detections, a good estimate might be converged upon.")

#text("Very interesting stuff, and thanks again for the wonderful explainer.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687241")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("Hi Terrence, hope you read this comment. I have always wondered how much relativity plays a role in the way light get’s affected by it. If light was affected by say density from a cosmological point of view and not just empty space in our solar system point of view, we would have to take into account the density of galaxies depending on the direction we are looking at (measuring the distance of stars). What I mean by that is, I think that light is affected by relativity even based on the mass of the galaxy. So light would behave differently based on the Milky Way’s mass compared to if we were in Andromeda or some other galaxy. This would also be true depending on the direction of the sky we are looking at. If we are looking perpendicular to the arms of the Milky Way then there’s not enough density compared to looking through the arms of the Milky Way and seeing how much light bends or changes. And then this when blown up to the edge of the visible universe, we would have to take into account the red shift of the light we receive from distant galaxies (depending on how many galaxies are around the path of light and the relative density of galaxy [as in the number of galaxies surrounding that ray of light]), thus adding more error to our calculations. I don’t know how much analysis we have done on this but is it potentially something worth looking into? This could maybe explain the Dark Matter observations we see in the universe. Maybe gravity (thus our observations) are different at cosmological scales relating to space between galaxies and galaxy densities. Why do spiral galaxy arms behave the way they do? Could this explain it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687256")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("Yes, variation in the gravitational field does lead to measurable effects, most notably ")#link("https://en.wikipedia.org/wiki/Gravitational_lens")[#text("gravitational lensing")]#text(", that add some additional complexity to the observations, though to my understanding the measurement of these additional effects have ended up confirming the standard cosmological model (which contains both dark matter and dark energy) rather than suggesting a replacement for it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687258")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("I believe such theories are generally known as “")#link("https://en.wikipedia.org/wiki/Tired_light")[#text("tired light")]#text("” theories. As I mentioned in another comment, one can use such theories to “fix” an individual observational anomaly that is not explained by the standard model, but to my knowledge every such proposed fix has actually created worse problems in other observations that fit the standard model very well, but not the newly proposed model. Improving a model that already explains a large number of disparate phenomena to reasonable accuracy is actually quite difficult!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/078b02a45a297601402835ba70c21f5e31b73995cb81fe1f89ad05d0a3b5c4bc-124a5ebd335ba0e219c4395f60e6fe44b9c0dae0ea8ab5eeaf933a0b01529784.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sahil Gupta")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687377")[#strong[#text("Sahil Gupta")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2025")])]

#text("Hi Terence, the standard model does critique ‘tired light’, but with straw man arguments. Each of the tired light criticisms can be debunked (lack of blurriness, SN light curves, and CMB).")

#text("For starters, there’s the straw man argument that tired light by interaction with intergalactic electrons would cause blurring. But Point 1: it is already known that photons interact with intergalactic electrons (see dispersion measure, dispersion slope), and evidently galaxies are not blurred. So that knocks out that argument. And Point 2: it is not a hard-and-fast claim of tired light that the redshift is caused by interaction with intergalactic electrons. The model leaves open the cause. It might even be the case that the photon simply decays on its own, somewhat like nuclear decay (which too is well-modeled by exponential decay).")

#link("https://cosmology.info/redshift/rebut/errorswright.html")[#text("https://cosmology.info/redshift/rebut/errorswright.html")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687386")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2025")])]

#text("The tired light theories have so far failed to follow the Lambda-CDM model into the modern era of high-precision cosmology, in which extremely detailed data sets from WMAP, Planck, JWST, SDSS, etc. are available. With the best-fit parameters, Lambda-CDM fits most data (in particular, CMB power spectrum, galactic structure, and baryon acoustic oscillations) to within 1% accuracy, with the one main outlier – the “Hubble tension” of the predicted value of ")#mi("H_0")#text(" being about 10% off from more direct measurements – being of sufficient inaccuracy to be deemed a “crisis in cosmology” in some circles. There is no proposed tired light model of sufficient mathematicial precision that achieves anywhere close to even this “crisis-level” 10% accuracy against ")#emph[#text("all")]#text(" available data, though one can imagine that for any particular cherry-picked piece of data one can tailor a model to explain just that one individual measurement accurately, at the expense of accuracy in all other measurements. (But many proposed models are so qualitative in nature that no meaningful numerical measure of accuracy can even be assigned at all.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/078b02a45a297601402835ba70c21f5e31b73995cb81fe1f89ad05d0a3b5c4bc-124a5ebd335ba0e219c4395f60e6fe44b9c0dae0ea8ab5eeaf933a0b01529784.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sahil Gupta")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687387")[#strong[#text("Sahil Gupta")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2025")])]

#text("Hi — You’ve extended the discussion without commenting on how the criticisms of tired light (like the lack of blurriness criticism) I mentioned are wrong.")

#text("Even still, I can answer your new points.")

#text("On WMAP and Planck and more generally the CMB: The instruments are precise but have not proven that the source of the incoming microwave radiation is some multi-billion-light-year distance away from the Milky Way. Can you prove otherwise? If you look into how “z=1100” is determined, it is not actually independently confirmed. If you list the stack of supporting ideas, the “z=1100 redshift of the CMB” is a claim that assumes the incoming microwave radiation was from a big bang and got redshifted. The claim of “z=1100” hides a premise. Alternatively, in non-big-bang cosmology, there remains a possibility the CMB-emitter is nearer the Milky Way, as in within a 100 Mly radius. And on a historical note, a single-digit Kelvin background was predicted before the proposal of the Big Bang Theory and ")#link("https://www.ifi.unicamp.br/~assis/Apeiron-V2-p79-84(1995).pdf")[#text("long before")]#text(" the measurements of Penzias and Wilson. Big bang cosmologists were not the first to predict the incoming microwave radiation, and neither the most accurate. This history, ")#link("https://www.ifi.unicamp.br/~assis/Apeiron-V2-p79-84(1995).pdf")[#text("https://www.ifi.unicamp.br/~assis/Apeiron-V2-p79-84(1995).pdf")]#text(", is super important.")

#text("On baryon acoustic oscillations: BAOs are grandiose label for what is de facto a interesting statistical pattern of galaxies and a pattern of the peaks and troughs of the microwave radiation angular power spectrum. It’s a general phenomenon that does not strictly favor Big Bang LCDM.")

#text("On JWST: JWST images of the distant universe, which show fully developed disc and spiral galaxies, strictly contradict pre-2022 predictions of big bang cosmology. This is the bigger ")#link("https://www.youtube.com/watch?v=qjo7VrR3puA")[#text("crisis in cosmology")]#text(". Now, big bang cosmologists are post-facto creating galaxy formation models. Isn’t it astonishing that they’re fabricating ad hoc free parameters instead of pondering that maybe the Big Bang theory is deeply in error, and that we have to debug the entire stack of ideas, starting with the redshift interpretation?")

#text("I do understand how strange it is to see a blog post commenter trying to convey to you that the Big Bang Theory is completely false, but I hope you might understand why he’s trying to reach Terence Tao to break through.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687389")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2025")])]

#text("To quote George Box, all models are wrong; the more important question is which ones are useful.")

#text("As I mentioned before, for any specific piece of data, it is possible to locate an alternative explanation using hypotheses and parameters tailored to that data that can match or outperform the standard Lambda-CDM model. But that does not provide a coherent competing alternative to that model. For that, one would need a mathematically precise cosmological model, with explicit numerical values (complete with error bars) of key parameters that are consistently chosen across all tests of the theory, that can give falsifiable predictions for each of the major cosmological data sets (as interpreted using the hypotheses of the model, of course), which one can then test against each of these sets in order to report the error between the model predictions and the actual data (after performing reasonable fitting of local unknown parameters). Until that occurs, one only has a hypothetical competitor to Lambda-CDM, rather than an actual one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/078b02a45a297601402835ba70c21f5e31b73995cb81fe1f89ad05d0a3b5c4bc-124a5ebd335ba0e219c4395f60e6fe44b9c0dae0ea8ab5eeaf933a0b01529784.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sahil Gupta")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687390")[#strong[#text("Sahil Gupta")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2025")])]

#text("I’m disappointed you again mischaracterized a photon continuous decay redshift model as an “explanation using parameters tailored to that data” when tailoring parameters to data is the unabashed behavior of Big Bang LCDM (tailoring parameters to data is literally what inflation is, what dark matter is (2 free parameters per galaxy), what dark energy is, and what is going on with the ad hoc galaxy formation models for the mature spiral galaxies JWST observed).")

#text("Do you know what the TL model is?")

#text("The TL redshift model is")

#emph[#text("E_t / E_0 = e^(-Ht) = e^(-d/(c/H))")]

#text("where ")#emph[#text("E")]#text(" is energy of the photon, ")#emph[#text("t")]#text(" is time of travel, or ")#emph[#text("d")]#text(" is distance of travel,")

#text("and ")#emph[#text("H")]#text(" is one parameter (the only parameter the model asks for), which derived from uncalibrated supernovae data is ≈ 1/(13.8 Gy).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687242")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("Curious, so we know that some of the data came from India – are there any records of possibly parallel endaeavours in ancuent China or Japan?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687260")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("I believe there are Chinese records from the first millennium of planetary motions and eclipses of roughly comparable levels of thoroughness to the Greek, Indian, and Islamic traditions, although there was less emphasis on geometric measurements and modeling, or of the type of deductive reasoning favored by the Greeks. However, they did seem to have a sophisticated ability to make calendrical calculations and predict eclipses, for instance having accurate values of the axial tilt of the Earth.")

#text("I am not familiar with the Japanese astronomy of the period, but I would imagine it was strongly influenced by the Chinese tradition.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687243")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("Hello! I’m a 12 grader, I had a question.")

#text("The expansion of the universe by hubble, is it in a 3d or 4d form?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687262")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("The special and general theories of relativity make it natural to view the universe as a four-dimensional ")#link("https://en.wikipedia.org/wiki/Spacetime")[#text("spacetime")]#text(", though one can take “slices” of this spacetime to create more familiar three-dimensional “snapshots” of the universe at a given instant of time (here there is some subtlety due to the fact that time and space are measured differently by different observers, but ignore this for now). So one can view the universe either as a “static” four dimensional object, or a “dynamic” three dimensional object. Neither perspective is “wrong”, but the former is a more convenient perspective in some contexts, and the latter in others. One analogy is with a flip book: this can either be thought of as a three-dimensional object (consisting of pages that contain static images), or as a moving two-dimensional object, which changes as one flips through the pages of the book.")

#text("From the dynamic three-dimensional point of view, the universe is expanding, somewhat similarly to a balloon being inflated over time (except that the balloon is essentially two-dimensional instead of three-dimensional, and also sits inside an ambient three-dimensional space, whereas there is no reason to believe the universe sits inside a larger-dimensional space at cosmological scales). If one instead adopts the static four-dimensional point of view, the expansion of the universe is reflected in a certain “curvature” of spacetime, although describing exactly what curvature means here requires some rather sophisticated Lorentzian geometry. (But roughly speaking, much as curvature of a surface would cause bends in what would otherwise be a “straight” line on that surface, the curvature of spacetime will cause bends in the geometry of light rays, and other worldlines of inertial (free-falling) objects.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687244")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("According to Matt O’Dowd, the scientific consensus on the size of the universe is more like 500 times larger in each direction than the observable universe. I have also heard this figure from Don Lincoln. The reasoning is that the flatness of the universe makes it at least 500 times larger in each direction, giving it a total of 125,000,000 times larger than the observable universe.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687245")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("Truly awesome. Thank you _so much_ for your time, knowledge, and enthusiasm!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687246")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("I really enjoyed these videos, but I believe there are a few inaccuracies in the discussion of Hubble’s Law that your comment on Part 2, timestamp 21:07 doesn’t quite address, and that weaken the claim that this video shows how you can measure distances across the full observable universe. In 20:35 you say that Hubble measured a linear relationship between galaxies’ recessional velocities and distances, and in 20:45, you say this proportionality exists because “the universe is expanding at a uniform rate.” You then say we can apply this (assumed to be linear) law to determine the distance to a galaxy, having measured its redshift.")

#text("But as we see it, the universe is not expanding at a uniform rate; the expansion is accelerating, so the recessional velocity that we observe for distant galaxies is not simply proportional to their distance (no matter what measure of distance you want to use–luminosity distance, comoving distance, or angular diameter distance). The linear approximation of Hubble’s Law is really only accurate for quite nearby sources (z<~0.1), which doesn’t get you much farther out (a few hundred megaparsecs) than Cepheids. We can use the full, nonlinear version of Hubble’s Law (which requires assumed/measured values for the densities of matter, dark energy, and curvature) to calculate how far away a truly distant source is, having measured its redshift. But making that full version of Hubble’s Law requires Type Ia supernovae to get some estimates for those cosmological parameters. I know it’s mentioned why the video left out discussion of Type 1a supernovae. However, even if the video doesn’t discuss how these supernovae allow you to build up the nonlinear version of Hubble’s Law that actually extends to the scale of the observable universe, it seems important to add a correction that you can’t just apply the linear approximation of Hubble’s law at these scales and that the expansion of the universe is actually accelerating.")

#text("With the linear version of Hubble’s Law, you’re still pretty stuck to the relatively nearby, recent universe.")

#emph[#text("[Some clarifications added to this portion of the FAQ -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687247")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("Hi Terry. For the comment at the end it might be worth mentioning the ")#link("https://en.wikipedia.org/wiki/Tully%E2%80%93Fisher_relation?wprov=sfla1")[#text("Tully–Fisher")]#text(" and ")#link("https://en.wikipedia.org/wiki/Faber%E2%80%93Jackson_relation?wprov=sfla1")[#text("Faber–Jackson")]#text(" relations (on top of the Type Ia SN), as additional standard candles.")

#text("I haven’t worked in cosmology other than in my undergrad thesis, so discount appropriately.")

#emph[#text("[Thanks, this is now added to the relevant FAQ entry. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90a461bb7d074e500728bee9dad25cd21c51e477758d25535f510e5107cfd31a-4637a6bf05cd392b4f09b547bd11c6d8913c2f753cef909c2cd5080deeea8abe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthijs van Duin")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687248")[#strong[#text("Matthijs van Duin")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("Regarding the size of the observable vs entire universe, my understanding of the research you linked is that they’re looking for evidence (or absence thereof) that the universe is finite without boundary (e.g. a 3-torus) with a total size that’s ")#emph[#text("smaller")]#text(" than the observable universe, which would mean it loops in a way that is potentially observable.")

#text("The smaller the total universe, the easier it should be to detect such looping, so when attempts to detect this turn out negative (as they have been) this non-detection can then be quantified by putting a lower bound on the size of the universe.")

#text("If the total universe is larger than the observable universe (which seems most likely) then it seems to me that the actual size would be inherently unknowable, including whether it is finite or infinite?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b08a1dbbce5c54a4fa84b09883a9d8134a6eb55da540723c81ff8c1652a58fa0-afbafbcf49bfd84d2e8eb6f4159a1373d1289241b3ac8f83aaa4b460280d1ef1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chocolatewhispersa7adabc2d6")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687251")[#strong[#text("chocolatewhispersa7adabc2d6")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("/I have a question, Mr. Terrance Tao (if this is a repeated question, please ignore. I think my first comment was not uploaded properly). At the end of the video, it was mentioned that there’s always a 10 % error using Hubble’s constant. Assuming that everything else is sound, could it be that some measurements cause a deviation because there’re pockets of “more concentrated” dark energy, causing them to deviate from the constant? That is, could it be that dark energy is not evenly distributed on the Universe?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687257")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("There are some “local void” proposals along these lines, but my understanding is that it has been difficult to reconcile such proposals with the extreme uniformity of the cosmic microwave background radiation, as well as some other observed data on the distribution of galaxies that are otherwise well explained by the standard cosmological model. In general, there are a variety of ways to add one or more tweaks to this model to resolve any given observational anomaly, but in many cases this tends to create several more anomalous deviations from observed data for each anomaly resolved, and so I don’t believe there is yet a comprehensive rival model to the standard Lambda-CDM model that has widespread acceptance.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687252")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("Thank you so much for this 2 part series it is amazing to have everything bundled up and so easily accessible.")

#text("With regards to Rhomer method of calculating the speed of light if I get it right the 20 minutes or so are cumulative differences in Io’s orbits as they appear to a moving Earth. Cumulative differences from when Earth moves away from Jupiter vs from when Earth moves towards Jupiter.")

#text("There is not a 10 minute aparent difference when we are closer than when we are further away. If Earth would be stationary at the closest point or stationary at the further away point the time between Io’s eclipses would be the same (even if light has to travel a longer path).")

#text("Am I missing something?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687255")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("I have a question about the 20 min ahead schedule when Jupiter is in opposition of the Sun. I don´t understand how they perceived it, shouldn’t he also be 20 min ahead when disappearing and thus canceling out?")

#text("I would like to say the video was phenomenal and one of the beast videos I ever saw.")

#emph[#text("[Some additional text added to the FAQ entry to help explain this. From one transit to the next, the effects of finite light speed do indeed largely cancel, leaving only a very small shift of seconds in the period; but cumulatively over months, the light speed delays begin to accumulate. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687261")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("Parallax remains the only direct measurement of distance, all others rely on relationships that are statistical, with non-measurement related uncertainties, and require various corrections. When I was a graduate student, the Hipparcos satellite hadn’t flown yet, and so your statement about “a thousand” stars with measured parallax was about the right order of magnitude. However, Hipparcos, and then Gaia have achieved measurements I thought would be impossible in my lifetime – direct measurements of distance and proper motion of 6 orders of magnitude more stars!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf06dfb7584375aed2564321ee8f72558fbd9ea515a6ecb6f7913d7958c1042-4a42b755059e3cb31b4ed2513a1655dfa27afb6828f0c0d9dcf98a6363572524.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dmiller")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687268")[#strong[#text("dmiller")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("From my understanding, spacetime can warp due to gravitational forces. Could this have affected the parallax measurements for the super far away distances?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687269")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("This does have some small impacts that become important at higher levels of precision, and the most modern parallax measurements (such as those coming from ")#link("https://en.wikipedia.org/wiki/Gaia_(spacecraft)")[#text("Gaia")]#text(") take into account gravitational lensing effects from the Sun, other stars, and even the planets.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687270")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("Dear Terry. Maybe it is a big ask at this moment but I was wondering if you have somewhere a bibliography to share regarding your book project, or in the understandable absence of one at this moment a short list of the books you have found more useful/interesting about the cosmic ladder history.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687363")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2025")])]

#text("This only concerns one aspect of the distance ladder, but I can recommend “The Glass Universe” by Dana Sobel.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687272")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("Very enjoyable and informative videos! Too often, we are just asked to trust the science – i.e. an argument from authority – but it is more important to explain ")#emph[#text("why")]#text(" we believe what we believe, and to propose experiments that at least in principle could be performed to confirm our beliefs.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687280")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2025")])]

#text("Really cool!")

#text("Also, “with corrections” is a typical thing for people like us, isn’t it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687358")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2025")])]

#text("Hi, would it be conceivable or, at least in theory make sense to measure some sort of apparent size of the universe based on the behaviour of our observable universe? so:")

#text("I’ve always imagined our observable universe as its own bubble – just like a planet orbits its sun, so does our observable universe some sort of larger structure. thus if we could observe how the whole obeservable universe behave, maybe we can infer some sort of direction of our bubble – maybe based on some global redshift direction, or perhaps a differential in the overall direction everything moves galaxies moving in in one way, and moving out in the opposite diretion? so basically using the observable universe a staging ground for the next level paralax?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/14c11219d7a998465ae26e387f00d40792281d3c07e9eab38ff5e1d2de1b832c-d51c1ea969207f0fce4b142bd79fbaa7b2b1b2956c937519c1caa9933424be2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Petar Knezevich")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687359")[#strong[#text("Petar Knezevich")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2025")])]

#text("Thank you for such a nice review of the cosmic distance ladder. It is inspiring to be reminded how many millennia of observing, analyzing and theorizing have been dedicated to furthering knowledge. We should have all been taught these histories of mathematics and science when we were in school.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687360")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2025")])]

#text("Quick question; you write that “the Nile ran from North to South” but it actually ran from South to North, right? This doesn’t affect the rest of that section, of course.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f749570d94b67d3a96f31a805c7d84aff9323fd31a126b0798b905c5b390b773-b597971f90fb9f5aebd2850a10f8cf0d7d31388ba1c5d373613abc0c6f579b07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of deliciouslye7bcae2778")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687361")[#strong[#text("deliciouslye7bcae2778")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2025")])]

#text("Hi, would it make sense to imagine the sphere of our observable universe, like planet orbiting the sun, orbiting through space and infer some larger structure or and apparent size of the universe? Basically, we should see new things come into the observable universe on one side, and something else disappear on the other side, or something similar to that effect that perhaps could allow us to infer something about the behaviour of the observable universe as a whole?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687364")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2025")])]

#text("This is roughly how the cosmic microwave background radiation is used to infer some lower bounds on the size of the actual universe, as mentioned in the 21:15 entry of the FAQ. There is an important complication to bear in mind, though: because of the finite speed of light, the observable universe should not be viewed as a sphere that moves instantaneously with us, but rather as a “backwards light cone” that extends further into the past as one moves further into the edge of the observable universe. In particular, at the edges of the observable universe we are now observing the very early stages of the universe, which is why the cosmic microwave background radiation, the features of which also mostly originate from that era, are the most important data source we have for that edge.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687362")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2025")])]

#text("These two videos were a treat! Grant’s videos are always excellent and Terence’s exposition was a beautiful fit.")

#text("How do astronomers compensate for attenuation in brightness due to intervening dust/gas clouds (when using standard candles)?")

#text("Is the redshift due to expansion of the universe “obvious”? I thought the expansion is sort of happening “between” galaxies. Also, that the speed of light “locally” (as it were), through space, is indeed still c. — I’m obviously not being clear here, almost deliberately confusing myself, but “the expansion of space” (ie. “the metric”) isn’t clearly analogous to the Doppler shift of a siren. Is it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687365")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2025")])]

#text("To compensate for attentuation (also known as ")#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/extinction")[#text("https://en.wikipedia.org/wiki/Extinction_(astronomy)")]#text(") one can work in multiple frequencies of the spectrum (visible, x-ray, radio, etc.), as some frequencies are less susceptible to extinction than others. From the discrepancies between these frequencies one can infer the amount of extinction, leading to “dust maps” that can then be used to facilitate such corrections for subsequent measurements in the same area of the universe. (More generally, the trend in modern astronomy is towards “")#link("https://en.wikipedia.org/wiki/Multi-messenger_astronomy")[#text("multi-messenger astronomy")]#text("” in which one combines together very different types of measurements of the same object to obtain a more accurate understanding of that object and its surroundings.)")

#text("As for your second question: it is true that an observed redshift could, in isolation, be explainable purely by the Doppler effect of a galaxy receding in a flat background universe, rather than by expansion in the intervening spacetime metric. However, this would not explain why distant galaxies would have a greater redshift than nearby galaxies, as in the absence of an expanding universe, there would be no mechanism to ensure that recessional velocities should be proportional to distance from the observer.")

#text("The “expanding universe” model was not immediately accepted after the discovery of Hubble’s law (somewhat analogously to how the heliocentric model was not immediately accepted after Aristarchus’s measurements of the Sun), as it was initially possible to explain this law from some other rival models. The later discovery of the cosmic microwave background, which was highly consistent with a “Big Bang” model but difficult to explain in other models, was a major factor in achieving consensus adoption of this model among astronomers; there is also other supporting evidence consistent with the standard cosmological model, such as the observed distribution of the galaxies and the abundance of hydrogen and helium.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687367")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2025")])]

#text("I liked the part of the “story”, where Kepler`s motivations were mentioned.")

#text("The fact that Platonic solids can be inscribed in the orbits was in itself so beautiful and meaningful to him that he approached it also from a theological perspective (of course, a somewhat typical thing for his period).")

#text("This didn`t stop him though from conducting his research in the most honest way, paving the way to a discovery of another beautiful and unobvious thing, namely that orbits are in fact conic sections, which I find quite funny.")

#text("It is also a nice parallel of current scientific research, where there can be a lot of apparent elegance and beauty in a particular model, which can be a great motivator, but should never hinder the actuall pursuit of truth.")

#text("Thanks for all the work on this!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687369")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2025")])]

#text("This was such a fun read with many points to tangent off into. I’d like to highlight a ")#link("https://youtu.be/T1JuCPhONlg?t=814")[#text("video")]#text(" on recent(ish) advancements on the “crisis in cosmology” by Dr. Becky Smethurst. Starting from 13:34, they give an introduction on the question, and then delve into how different teams of researchers came up with different estimates of the hubble constant using JWST data. I felt if anyone wanted to delve deeper into this topic it would be a good place to start.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687372")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2025")])]

#text("Hello Terry, thanks for these fascinating videos. On part II, a the 12:40 mark one see a very distinct moving star against a background of more distant stars. There is no way this motion is produced by parallax, at least not by the Earth moving around its orbit. Indeed at the distance of Proxima Centauri, the total parallax angle seen from Earth is less than 2″ of arc, which is only about the FWHM visible diameter of a bright star taken from Earth even in good seeing conditions. The motion shown in the video is much more likely produced by the proper motion of the star as it orbits the centre of the galaxy.")

#text("The only such motion due to parallax so clearly visible on a photograph was taken by the probe New Horizon as it was cruising well beyond the orbit of Pluto. See this:")

#link("https://cdn.mos.cms.futurecdn.net/z3pC8PmqTZWxwBcHyHRkWZ-1200-80.gif")[#text("https://cdn.mos.cms.futurecdn.net/z3pC8PmqTZWxwBcHyHRkWZ-1200-80.gif")]

#text("Indeed the Wikipedia page on star proper motion shows the example of Barnard’s star, which is similar in magnitude to the motion you show in the video.")

#text("This does not deter in any way from the quality of your exchanges. I was just bothered by this. All the best !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687373")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2025")])]

#text("Wow! I am only 13 and most of this went completely over my head, but I loved it you are answering so many questions and taking the time to explain these incremental beautiful discoveries to everyone!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/741966e08f1a66ab24e1b49d34f390d2ac617bb29e132b28e8c19ca09bcf3851-474653f29668f27074c96baaeb558d6ec8498e60898759dce21224c240764c30.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mr Chris")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687378")[#strong[#text("Mr Chris")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2025")])]

#text("Possibly uneducated comment here, but;")

#text("Does the coalescing of matter in the universe into these “strands” impact the measurement of their red shift? If a galaxy were on the other side of a strand being drawn in our direction, would that movement have an effect on the red shift? Or is it too slow/big/etc.?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687380")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2025")])]

#text("There are some local motions of clusters of galaxies, known as bulk flows, that do make some noticeable impact on red shifts for nearby galaxies, but I don’t believe they make a significant impact for very distant galaxies, particularly if one performs statistical averaging over many such galaxies to reduce the net magnitude of these effects.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/618cf1f04f8a18eecb1f10f266821e7393feeb97598d32289f48ad8030cb9938-cfc0ce0b3d592e30da34d56ba5b8e4e05f67604304a8cea7731d51a12818b5ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687396")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2025")])]

#text("At a “local” level, surveys do indeed reveal overdensities of matter (eg ")#link("https://en.wikipedia.org/wiki/Great_Attractor")[#text("The Great Attractor")]#text(") towards which the motions (ie redshifts) of more-than-statistically-expected galaxies redshifts “point”.")

#text("Even larger scale galaxy clusters are revealed by the ")#link("https://en.wikipedia.org/wiki/Sunyaev%E2%80%93Zeldovich_effect")[#text("Sunyaev–Zeldovich effect")]#text(" on the cosmic microwave background radiation.")

#text("At the most cosmological levels, the ")#link("https://en.wikipedia.org/wiki/Sachs%E2%80%93Wolfe_effect#Integrated_Sachs%E2%80%93Wolfe_effect")[#text("Sachs–Wolfe effect")]#text(" causes uneven gravitational redshift of the cosmic microwave background in a dark-energy-dominated universe (one in which expansion is accelerating, which is our present")#strong[#text(" ")]#text("“ΛCDM” consenus model), revealing the ")#link("https://en.wikipedia.org/wiki/Galaxy_filament")[#text("largest structures")]#text(" of the observable universe. CMB photons on their way to us from the Big Bang take so long to traverse these enormous structures (filaments or voids between filaments) that the ")#emph[#text("acceleration")]#text(" of the expansion of the universe ")#emph[#text("during")]#text(" the light traversal decays the gravitational potential of the structure and so blueshifts (or redshifts through voids) CMB photons’ energy.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687382")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2025")])]

#text("This may not be useful to many people, but for those who speak Spanish, you can go to the QuantumFracture YouTube channels to see more videos on this topic, including more information on type 1a supernovae and other “candles” used in the cosmic ladder.")

#link("https://www.youtube.com/@QuantumFracture")[#text("https://www.youtube.com/@QuantumFracture")]

#link("https://www.youtube.com/watch?v=LR_Gz1LsUpM")[#text("https://www.youtube.com/watch?v=LR_Gz1LsUpM")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11f931dd9890a02d8ebd972ea7cf3b7f9cfe2e4941f590cb667ab81d141093ed-4e3d8cd61b523f516f3957e76988066bb06bbc5eaa152d99d5a970d9587e5c29.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pinktotallya7d9f24ba6")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687385")[#strong[#text("pinktotallya7d9f24ba6")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2025")])]

#text("Fabulous talks. This extraordinary history has often been told but never with such concision. We get to get the gist and axsense of belonging. I think this might also be calling into question traditional schooling models as there is so much knowledge out there for the curious, even in deprived areas. We can work a lot out by ourselves with the right guidance. The collaborative format is a step towards this as well. Looking forward to the upcoming book for more nitty-gritty details indeed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687388")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2025")])]

#text("Kepler’s discoveries were paved by an immense amount of preparatory work with no guarantee of an outcome in the end. The planets orbit the common center of mass at/near the sun in an ellipse. In school I learned that an ellipse can be described by putting two pins in a board and tying each end of a string to the pins and then a pencil can be used in the stretched out string to scribe out the ellipse. The sun is at one pin, or focus, with nothing at the other pin, or focus. It has always bothered me that there is nothing at the other focus. Why should the orbit be an ellipse if there is nothing at the other focus? This has always bothered me. Intuitively it made no sense to me to have two foci with nothing at one of them. My AI does not seem to help resolve this. So it won’t keep me up at nights, I have decided that the sun is at one focus and the system is balanced at the other focus by time. I’m not used to sensing time in the same way as I sense mass so maybe that is why intuitively it seemed wrong to have nothing at the other focus. Why should it make intuitive sense that there is nothing at one focus? Jimmy Ellis at ")#link("mailto:utgeek@earthlink.net")[#text("utgeek@earthlink.net")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687408")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("The orbit is not symmetrical – when Earth is closest to the focal point populated by the Sun (or more accurately by the center of mass of the system), it has the highest kinetic energy and lowest potential energy, with the opposite on the far side. Thus, there is really no reason for anything to be in the other focus.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687392")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2025")])]

#text("Really appreciate all the work and thought and insight in this post and the videos; thank you to the team that put it together!")

#text("Sending fond greetings from Sydney! 👋")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687394")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2025")])]

#text("Very curious where “the observable universe is 20% of the universe” (paraphrasing) came from!?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff37444df748e55999f1767cb50973c7e56750967c335b995ecf30f2ed864ef-66b333ce5b3d35c280ed6265c7f49b647483475518658e64f0145134a65bb85c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tara Li")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687395")[#strong[#text("Tara Li")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2025")])]

#text("How do the various levels of uncertainty between the different rungs on the ladder interact? It seems like these uncertainties could add up quickly, since each rung depends on the one before it. I’ve seen estimates of the distance to various stars (pre-Gaia data, I presume) that differed by a factor of two or more – and they’re relatively close stars, such as Betelgeuse or Polaris. Wouldn’t that kind of inaccuracy affect the next step – Cephids (ignoring the T1/T2 Cephid discrepancy), leading to even more uncertainty. Then there’s things like 1a Supernovae, which keep getting glossed over as being the same brightness – but surely there would be at least some variation, even if just 1-5%.")

#text("How does this climbing accumulation of error ranges get resolved?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687413")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("There is a lot of work on cross-calibrating between different distance measurement methods. For instance, if a single galaxy contains both Cepheids and tips of red giants then one can compare the two measurements to see if either of them contain undesirable variability. For errors that are not systemic in nature, statistical averaging over many different measurements can also reduce relative error. For errors that themselves can be modeled with reasonable precision, e.g., extinction effects modeled through dust map measurements, one can compensate for those contributions by inferring the parameters of the error model.")

#text("As gravitational wave distance measurements become more plentiful and accurate, this should provide a way to calibrate many rungs of the ladder at once, since this type of measurement avoids a lot of the problems you mentioned.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687397")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2025")])]

#text("Terry I believe the visualizations in the last section of part 1 are incorrect; they show that the synodic position of mars is fixed for several relative earth positions; when the sidereal position of mars should have been fixed. It would have been impossible for Kepler to have known that mars was in the same place *a priori* that can only happen *a posteriori*")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687414")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("Kepler was using Copernicus’s value for the sidereal period of Mars (687 days), not the synodic period (780 days). (In the video I had somehow managed to average these numbers and quote the period as 729 days, but this was an error.)")

#text("In short, the original Copernican model does indeed predict that Mars returns to the same location in the Solar system every 687 days. It turns out that even though the orbits are not perfectly circular, they do not exhibit significant precession (at least at the level of accuracy available in Kepler’s day; there is of course the famous issue of Mercury’s precession due to relativistic effects that was discovered later); because of this fortunate lack of precession, the Copernican sidereal periods could still be used to high accuracy in Kepler’s analysis. (However, in an alternate universe where the law of gravity was sufficiently different that orbits did experience significant precession, then Kepler’s task would have been significantly harder, and perhaps even impossible with the technology and mathematics of the era.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687407")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("Cool video / conversation! You mention that Rømer’s estimates have been updated from about 20 minutes to about 16 with modern technology. How does modern technology help here? Is it just more precise clocks? It doesn’t seem like this calculation should be downstream of much else that could’ve been fuzzy at the time (unlike e.g. the speed of light, which is downstream of this time measurement + distance from earth to sun), and I’m surprised that the timing measurements alone would’ve been so far off.")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687415")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("There were several sources of error in Romer’s original calculations. In addition to possible timekeeping errors, there were also measurement errors in timing the transits of Io perfectly. It is also difficult to measure transits accurately at times of conjunction (because the Sun is obstructing the transit) and to a lesser extent in opposition (because now Jupiter is obstructing the transit). So Romer actually relied on data coming from intermediate times between conjunction and opposition in which there was a viewing angle that avoided these difficulties. But then one has to do some trigonometric calculations to compensate for this angle. My understanding is that Romer made a simple assumption of circular orbits for both Earth and Jupiter, which of course is not quite right due to Kepler’s laws.")

#text("Finally, with the passage of time, more and more transits can be observed, and non-systemic measurement errors can be averaged out. Romer’s method was replicated by Jean Baptiste Joseph Delambre in 1809, and by that time there was enough data (as well as a precise value of the AU) that a quite accurate measurement of the speed of light was obtained (close to 300,000 km/sec), as well as the time needed for light to traverse an AU (just over 8 minutes). I believe modern recreations of the method match very closely with other measurements of light speed and the AU.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687409")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("Hello Mr. Tao,")

#text("I was wondering if you could share:")

#text("(a) your own personal interpretation of the result of the Michelson-Morley experiment")

#text("(b) why the result of the Michelson-Morley experiment was called a “null result”")

#text("(Def: In science, a “null result” is a result without the expected content.)")

#text("Thanks very much.")

#text("KB")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/701b8a233b20ba73d22cd81220a35883816999128a987263fc89ce6490efda8d-47bf3bee5cf14dea4f8a3c59282d5f0cf4a7ecfb4ad0584f33307c74a937c604.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687425")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("Is there a formula or some sort of equation to estimate or to deduce the distance between the milky way and the nearby galaxies?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687427")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("Pretty much every rung of the modern distance ladder is basically an equation relating the distance to a given galaxy in terms of other things that we can measure. For instance, Hubble’s law is an equation relating the distance to the redshift. If the galaxy contains a standard candle, then we have an equation relating the distance to the apparent magnitude and absolute magnitude of the standard candle; and similarly for standard sirens and standard rulers.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687452")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2025")])]

#text("Thank you both, Terry and Grant, for the videos and this write-up. Beautiful and diligent work, much needed today!")

#text("Looking forward to your book about the Ladder, and I have a humble wish/suggestion:")

#text("If not happening already, can you perhaps collaborate with Grant to jazz up the book with some stunning and accurate graphics?")

#enum(start: 1, 
[#text("I think Grant’s expertise in precise animations will translate well into making consistent still images for print, he already has a lot of the base code done, and it may well be his next new challenge as an educator to fit his work to the print medium.")],
[#text("Too many pop-sci books nowadays end up being walls of text, by trying to avoid “technical” tools of explanation, like diagrams and equations. IMO they underestimate how excited the average reader can be to see things they don’t necessarily immediately understand but are willing to learn, and miss a great opportunity that way.")]
)

#enum(start: 1, 

)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687454")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2025")])]

#text("Are there other problems that you’ve enjoyed using the Cosmic Distance Ladder as a model for while thinking about it? To me it has the feeling of a metaphor for scientific discovery in general, slowly incrementing one’s knowledge over time. But the metaphor is a little hollow, I’m struggling to populate it with specific examples.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0d0e801c63af78a972ead42c0dabd6580013ff45c7700cc0d51147aa50a24a6-f11f451c7a8a3c4038c7de35c505d288f7d925587e81320e9e77a39a0cfc3548.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Lowther")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687458")[#strong[#text("George Lowther")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2025")])]

#text("Hi Terence,")

#text("I really enjoyed watching the videos and learned some new stuff.")

#text("Btw, I’m George. Not important, but just mentioning as you called me Greg in the links at the end!")

#text("Thanks")

#text("George (I.e., Almost Sure)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/414f8602835cbcadec4754ebdc4ac0b7791cd1ba04442a5aa9179195db6e5e30-1535b706a118d01bc197f88f76405e172e91d7e4d77da38eb718319df8052111.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of March ’25 Links | The Tao of Gaming")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687484")[#strong[#text("March ’25 Links | The Tao of Gaming")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2025")])]

#text("[…] the Cosmic Ladder — how do we deduce astronomical distances? Part 1. Part 2. The (other) Tao’s FAQ on the videos. Terence Tao lecture on the state of the art on Machine-assisted […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c4387322beabdecea3f85088a266553e58ed63baead184e4cc0d83836f25679e-7f941fe956a142cc8f3c5430b53a2f9af99238378d2f93d0aa48f4d26df08fe2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MP")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687495")[#strong[#text("MP")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2025")])]

#text("Professor Tao, thank you very much for the effort put here.")

#text("I tried discussing the topic of periodicities in the cosmic microwave radiation with ChatGPT, but I am not sure I 100% understood. Apparently, the idea is that if the universe would be finite, a photon would be able to go back to the same place in the universe just by going straight, just like one does in a sphere.")

#text("But how can physicists be sure that it’d be the case? From my humble vantage point, it seems like a big extrapolation just from the fact we don’t see periodicities in the CMR.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687500")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2025")])]

#text("The lack of periodicities in the CBR is evidence against the universe being too small – roughly speaking, it can rule out certain scenarios in which the diameter of the universe is smaller than twice the diameter of the observable universe (assuming a standard cosmological model like Lambda-CDM). But it is consistent with other scenarios in which the universe is finite, but significantly larger than the observable universe.")

#text("More recently, experimental evidence from Planck suggests that the flatness of the universe is surprisingly close to zero, which suggests an extremely large inflationary effect in the early universe which in turn hints that the universe is indeed much larger than the observable universe, or possibly even infinite; but the error bars are still too large to draw definitive conclusions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687561")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2025")])]

#text("“Redshift” is the speed. Explain please how, knowing the speed, you can calculate the distance? If a car is traveling at 100 km/h at the other end of the city, can you calculate the distance to it?")

#text("“The second point” is, explain how the stars and the clouds of hydrogen that surround them move together at the same speed – how the redshift does work?")

#text("“The third one.” Has anyone measured the blue shift of Andromeda, which is approaching us?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687567")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2025")])]

#text("Yes, redshift only directly computes recession velocity, not distance. However, as observed by Hubble after computing both the redshift (and thus implied recession velocity) and distance of multiple nearby galaxies and nebulae, he found that the redshift or recession velocity was approximately linearly proportional to the distance; more distant galaxies tended to have more distant recession velocities. See for instance the graphs at ")#link("https://www.pnas.org/doi/10.1073/pnas.1424299112")[#text("this link")]#text(".")

#text("This empirical finding was later explained by the famous “Big Bang” model of the universe, later refined to the modern “")#link("https://en.wikipedia.org/wiki/Lambda-CDM_model")[#text("Lambda-CDM")]#text("” model which also incorporates a “dark energy” term that generates some additional acceleration in the expansion of the universe.")

#text("As you note in your other questions, galaxies also exhibit ")#link("https://en.wikipedia.org/wiki/Peculiar_velocity")[#text("peculiar velocities")]#text(" that are in addition to the general recession caused by Hubble’s law, so the law is not a perfect fit for the nearest galaxies. However, as one moves out to further and further distances, the effects of the expanding universe dominate the effects of peculiar velocities (which stay more or less the same magnitude across the universe), and so the law becomes more accurate (in terms of relative error) as one goes further out (again, see the graph in the previous link provided, or even the original graph of Hubble displayed in the video). Also, if one statistically averages over many galaxies instead of focusing on individual galaxies, the effects of peculiar velocities (which can either increase or decrease the redshift) tend to cancel out, and so the reliability of Hubble’s law improves if one works with statistical averages.")

#text("(See also the FAQ entries at 20:37, 20:46, and 21:07 of part 2.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687590")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2025")])]

#text(">")#strong[#text("Isn’t the illuminated portion of the Moon, as well as the visible portion of the Moon, slightly smaller than half of the entire Moon")]

#text(">In reality, the Sun turns out to be about 86,000 Moon radii away from the Moon, so asserting that half of the Moon is illuminated by the Sun is actually a very good first approximation.")

#text("As the sun is somewhat larger than the moon, one might expect the illuminated portion of the moon to be *larger* than half, rather than smaller. If the sun is a plane, for instance, there is exactly one point on the moon that is not illuminated by it.")

#emph[#text("[Fair point; I expanded the FAQ entry to mention this. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/comment-page-1/#comment-687600")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2025")])]

#text("You could argue that the moon is illuminated by the sun only when the full sun is visible, I suppose, but for me the distinction between being able to see some portion of the sun, and no portion of the sun, is night and day.")
]
]
