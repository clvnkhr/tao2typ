// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/
// Converted to Typst by tao2typ: "2026-10-14T15:17:36.237253+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 3: The operator norm of a random matrix", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 3: The operator norm of a random matrix")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 January 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")[#text("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Now that we have developed the basic probabilistic tools that we will need, we now turn to the main subject of this course, namely the study of random matrices. There are many random matrix models (aka matrix ensembles) of interest – far too many to all be discussed in a single course. We will thus focus on just a few simple models. First of all, we shall restrict attention to square matrices ")#mi("{M = (\\xi_{ij})_{1 \\leq i,j \\leq n}}")#text(", where ")#mi("{n}")#text(" is a (large) integer and the ")#mi("{\\xi_{ij}}")#text(" are real or complex random variables. (One can certainly study rectangular matrices as well, but for simplicity we will only look at the square case.) Then, we shall restrict to three main models:")

#list(
[#strong[#text("Iid matrix ensembles")]#text(", in which the coefficients ")#mi("{\\xi_{ij}}")#text(" are iid random variables with a single distribution ")#mi("{\\xi_{ij} \\equiv \\xi}")#text(". We will often normalise ")#mi("{\\xi}")#text(" to have mean zero and unit variance. Examples of iid models include the ")#emph[#text("Bernouli ensemble")]#text(" (aka ")#emph[#text("random sign matrices")]#text(") in which the ")#mi("{\\xi_{ij}}")#text(" are signed Bernoulli variables, the ")#emph[#text("real gaussian matrix ensemble")]#text(" in which ")#mi("{\\xi_{ij} \\equiv N(0,1)_{\\bf R}}")#text(", and the ")#emph[#text("complex gaussian matrix ensemble")]#text(" in which ")#mi("{\\xi_{ij} \\equiv N(0,1)_{\\bf C}}")#text(".")],
[#strong[#text("Symmetric Wigner matrix ensembles")]#text(", in which the upper triangular coefficients ")#mi("{\\xi_{ij}}")#text(", ")#mi("{j \\geq i}")#text(" are jointly independent and real, but the lower triangular coefficients ")#mi("{\\xi_{ij}}")#text(", ")#mi("{j<i}")#text(" are constrained to equal their transposes: ")#mi("{\\xi_{ij}=\\xi_{ji}}")#text(". Thus ")#mi("{M}")#text(" by construction is always a real symmetric matrix. Typically, the strictly upper triangular coefficients will be iid, as will the diagonal coefficients, but the two classes of coefficients may have a different distribution. One example here is the ")#emph[#text("symmetric Bernoulli ensemble")]#text(", in which both the strictly upper triangular and the diagonal entries are signed Bernoulli variables; another important example is the ")#emph[#text("Gaussian Orthogonal Ensemble (GOE)")]#text(", in which the upper triangular entries have distribution ")#mi("{N(0,1)_{\\bf R}}")#text(" and the diagonal entries have distribution ")#mi("{N(0,2)_{\\bf R}}")#text(". (We will explain the reason for this discrepancy later.)")],
[#strong[#text("Hermitian Wigner matrix ensembles")]#text(", in which the upper triangular coefficients are jointly independent, with the diagonal entries being real and the strictly upper triangular entries complex, and the lower triangular coefficients ")#mi("{\\xi_{ij}}")#text(", ")#mi("{j<i}")#text(" are constrained to equal their adjoints: ")#mi("{\\xi_{ij} = \\overline{\\xi_{ji}}}")#text(". Thus ")#mi("{M}")#text(" by construction is always a Hermitian matrix. This class of ensembles contains the symmetric Wigner ensembles as a subclass. Another very important example is the ")#link("http://en.wikipedia.org/wiki/Gaussian_Unitary_Ensemble")[#text("Gaussian Unitary Ensemble (GUE)")]#text(", in which all off-diagional entries have distribution ")#mi("{N(0,1)_{\\bf C}}")#text(", but the diagonal entries have distribution ")#mi("{N(0,1)_{\\bf R}}")#text(".")]
)

#text("Given a matrix ensemble ")#mi("{M}")#text(", there are many statistics of ")#mi("{M}")#text(" that one may wish to consider, e.g. the eigenvalues or singular values of ")#mi("{M}")#text(", the trace and determinant, etc. In these notes we will focus on a basic statistic, namely the ")#emph[#text("operator norm")]#text(" ")#metadata(none) <tao-40685fd53d8eb3b1e921>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| M \\right\\|_{op} := \\sup_{x \\in {\\bf C}^n: \\left|x\\right|=1} \\left|Mx\\right|", block: true)]]

#text(" of the matrix ")#mi("{M}")#text(". This is an interesting quantity in its own right, but also serves as a basic upper bound on many other quantities. (For instance, ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(" is also the largest singular value ")#mi("{\\sigma_1(M)}")#text(" of ")#mi("{M}")#text(" and thus dominates the other singular values; similarly, all eigenvalues ")#mi("{\\lambda_i(M)}")#text(" of ")#mi("{M}")#text(" clearly have magnitude at most ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(".) Because of this, it is particularly important to get good ")#emph[#text("upper tail bounds")]

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left\\|M\\right\\|_{op} \\geq \\lambda ) \\leq \\ldots", block: true)]]

#text("on this quantity, for various thresholds ")#mi("{\\lambda}")#text(". (Lower tail bounds are also of interest, of course; for instance, they give us confidence that the upper tail bounds are sharp.) Also, as we shall see, the problem of upper bounding ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(" can be viewed as a non-commutative analogue of upper bounding the quantity ")#tao-math("{\\left|S_n\\right|}", block: false)#text(" studied in ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text(". (The analogue of the central limit theorem in Notes 2 is the ")#emph[#text("Wigner semi-circular law")]#text(", which will be studied in the next set of notes.)")#linebreak()#text(" An ")#mi("{n \\times n}")#text(" matrix consisting entirely of ")#mi("{1}")#text("s has an operator norm of exactly ")#mi("{n}")#text(", as can for instance be seen from the Cauchy-Schwarz inequality. More generally, any matrix whose entries are all uniformly ")#mi("{O(1)}")#text(" will have an operator norm of ")#mi("{O(n)}")#text(" (which can again be seen from Cauchy-Schwarz, or alternatively from ")#link("http://en.wikipedia.org/wiki/Schur_test")[#text("Schur’s test")]#text(", or from a computation of the ")#link("http://en.wikipedia.org/wiki/Matrix_norm#Frobenius_norm")[#text("Frobenius norm")]#text("). However, this argument does not take advantage of possible cancellations in ")#mi("{M}")#text(". Indeed, from analogy with concentration of measure, when the entries of the matrix ")#mi("{M}")#text(" are independent, bounded and have mean zero, we expect the operator norm to be of size ")#mi("{O(\\sqrt{n})}")#text(" rather than ")#mi("{O(n)}")#text(". We shall see shortly that this intuition is indeed correct. (One can see, though, that the mean zero hypothesis is important; from the triangle inequality we see that if we add the all-ones matrix (for instance) to a random matrix with mean zero, to obtain a random matrix whose coefficients all have mean ")#mi("{1}")#text(", then at least one of the two random matrices necessarily has operator norm at least ")#mi("{n/2}")#text(".)")#linebreak()#text(" As mentioned before, there is an analogy here with the concentration of measure phenomenon, and many of the tools used in the latter (e.g. the moment method) will also appear here. (Indeed, we will be able to use some of the concentration inequalities from ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text(" directly to help control ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(" and related quantities.) Similarly, just as many of the tools from concentration of measure could be adapted to help prove the central limit theorem, several the tools seen here will be of use in deriving the semi-circular law.")#linebreak()#text(" The most advanced knowledge we have on the operator norm is given by the ")#emph[#text("Tracy-Widom law")]#text(", which not only tells us where the operator norm is concentrated in (it turns out, for instance, that for a Wigner matrix (with some additional technical assumptions), it is concentrated in the range ")#mi("{[2\\sqrt{n} - O(n^{-1/6}), 2\\sqrt{n} + O(n^{-1/6})]}")#text("), but what its distribution in that range is. While the methods in this set of notes can eventually be pushed to establish this result, this is far from trivial, and will only be briefly discussed here. (We may return to the Tracy-Widom law later in this course, though.)")#linebreak()#text(" ")#metadata(none) <tao-3befdf2e5ec42b218549>

#heading(level: 1)[#strong[#text(" — 1. The epsilon net argument — ")]]

#text("The slickest way to control ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(" is via the moment method. But let us defer using this method for the moment, and work with a more “naive” way to control the operator norm, namely by working with the definition ")#link(<tao-40685fd53d8eb3b1e921>)[#text("(1)")]#text(". From that definition, we see that we can view the upper tail event ")#tao-math("{\\left\\|M\\right\\|_{op} > \\lambda}", block: false)#text(" as a union of many simpler events: ")#metadata(none) <tao-0ac2ce2e7616feae5762>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("{\\bf P}( \\left\\|M\\right\\|_{op} > \\lambda ) = {\\bf P}( \\bigvee_{x \\in S} \\left|Mx\\right| > \\lambda )", block: true)]]

#text(" where ")#tao-math("{S := \\{x \\in {\\bf C}^d: \\left|x\\right|=1\\}}", block: false)#text(" is the unit sphere in the complex space ")#mi("{{\\bf C}^d}")#text(".")#linebreak()#text(" The point of doing this is that the event ")#tao-math("{\\left|Mx\\right| > \\lambda}", block: false)#text(" is easier to control than the event ")#tao-math("{\\left\\|M\\right\\|_{op} > \\lambda}", block: false)#text(", and can in fact be handled by the concentration of measure estimates we already have. For instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(" ")#metadata(none) <tao-bb54068aea85faa7e487>#text(" Suppose that the coefficients ")#mi("{\\xi_{ij}}")#text(" of ")#mi("{M}")#text(" are independent, have mean zero, and uniformly bounded in magnitude by ")#mi("{1}")#text(". Let ")#mi("{x}")#text(" be a unit vector in ")#mi("{{\\bf C}^n}")#text(". Then for sufficiently large ")#mi("{A}")#text(" (larger than some absolute constant), one has")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|Mx\\right| \\geq A \\sqrt{n} ) \\leq C \\exp( - c A^2 n )", block: true)]]

#text("for some absolute constants ")#mi("{C, c > 0}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{X_1,\\ldots,X_n}")#text(" be the ")#mi("{n}")#text(" rows of ")#mi("{M}")#text(", then the column vector ")#mi("{Mx}")#text(" has coefficients ")#mi("{X_i \\cdot x}")#text(" for ")#mi("{i=1,\\ldots,n}")#text(". if we let ")#mi("{x_1,\\ldots,x_n}")#text(" be the coefficients of ")#mi("{x}")#text(", so that ")#tao-math("{\\sum_{j=1}^n \\left|x_j\\right|^2 = 1}", block: false)#text(", then ")#mi("{X_i \\cdot x}")#text(" is just ")#mi("{\\sum_{j=1}^n \\xi_{ij} x_j}")#text(". Applying standard concentration of measure results (e.g. Exercise 4, Exercise 5, or Theorem 9 from ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text("), we see that each ")#mi("{X_i \\cdot x}")#text(" is uniformly subgaussian, thus")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|X_i \\cdot x\\right| \\geq \\lambda ) \\leq C \\exp( - c \\lambda^2 )", block: true)]]

#text("for some absolute constants ")#mi("{C, c > 0}")#text(". In particular, we have")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} e^{c \\left|X_i \\cdot x\\right|^2} \\leq C", block: true)]]

#text("for some (slightly different) absolute constants ")#mi("{C, c > 0}")#text(". Multiplying these inequalities together for all ")#mi("{i}")#text(", we obtain")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} e^{c \\left|Mx\\right|^2} \\leq C^n", block: true)]]

#text("and the claim then follows from Markov’s inequality. ")#mi("\\Box")#linebreak()#text(" Thus (with the hypotheses of Proposition ")#link(<tao-bb54068aea85faa7e487>)[#text("1")]#text("), we see that for each individual unit vector ")#mi("{x}")#text(", we have ")#tao-math("{\\left|Mx\\right| = O(\\sqrt{n})}", block: false)#text(" with overwhelming probability. It is then tempting to apply the union bound and try to conclude that ")#tao-math("{\\left\\|M\\right\\|_{op} = O(\\sqrt{n})}", block: false)#text(" with overwhelming probability also. However, we encounter a difficulty: the unit sphere ")#mi("{S}")#text(" is uncountable, and so we are taking the union over an uncountable number of events. Even though each event occurs with exponentially small probability, the union could well be everything.")#linebreak()#text(" Of course, it is extremely wasteful to apply the union bound to an uncountable union. One can pass to a countable union just by working with a countable dense subset of the unit sphere ")#mi("{S}")#text(" instead of the sphere itself, since the map ")#tao-math("{x \\mapsto \\left|Mx\\right|}", block: false)#text(" is continuous. Of course, this is still an infinite set and so we still cannot usefully apply the union bound. However, the map ")#tao-math("{x \\mapsto \\left|Mx\\right|}", block: false)#text(" is not just continuous; it is ")#emph[#text("Lipschitz")]#text(" continuous, with a Lipschitz constant of ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(". Now, of course there is some circularity here because ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(" is precisely the quantity we are trying to bound. Nevertheless, we can use this stronger continuity to refine the countable dense subset further, to a ")#emph[#text("finite")]#text(" dense subset of ")#mi("{S}")#text(", at the slight cost of modifying the threshold ")#mi("{\\lambda}")#text(" by a constant factor. Namely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" ")#metadata(none) <tao-507a9a8be3d145a86daa>#text(" Let ")#mi("{\\Sigma}")#text(" be a ")#emph[#text("maximal ")#mi("{1/2}")#text("-net")]#text(" of the sphere ")#mi("{S}")#text(", i.e. a set of points in ")#mi("{S}")#text(" that are separated from each other by a distance of at least ")#mi("{1/2}")#text(", and which is maximal with respect to set inclusion. Then for any ")#mi("{n \\times n}")#text(" matrix ")#mi("{M}")#text(" with complex coefficients, and any ")#mi("{\\lambda > 0}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left\\|M\\right\\|_{op} > \\lambda ) \\leq {\\bf P}( \\bigvee_{y \\in \\Sigma} \\left|My\\right| > \\lambda/2 ).", block: true)]]
]

#emph[#text("Proof:")]#text(" By ")#link(<tao-40685fd53d8eb3b1e921>)[#text("(1)")]#text(" (and compactness) we can find ")#mi("{x \\in S}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|Mx\\right| = \\left\\|M\\right\\|_{op}.", block: true)]]

#text("This point ")#mi("{x}")#text(" need not lie in ")#mi("{\\Sigma}")#text(". However, as ")#mi("{\\Sigma}")#text(" is a maximal ")#mi("{1/2}")#text("-net of ")#mi("{S}")#text(", we know that ")#mi("{x}")#text(" lies within ")#mi("{1/2}")#text(" of some point ")#mi("{y}")#text(" in ")#mi("{\\Sigma}")#text(" (since otherwise we could add ")#mi("{x}")#text(" to ")#mi("{\\Sigma}")#text(" and contradict maximality). Since ")#tao-math("{\\left|x-y\\right| \\leq 1/2}", block: false)#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|M(x-y)\\right| \\leq \\left\\|M\\right\\|_{op}/2.", block: true)]]

#text("By the triangle inequality we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|My\\right| \\geq \\left\\|M\\right\\|_{op}/2.", block: true)]]

#text("In particular, if ")#tao-math("{\\left\\|M\\right\\|_{op} > \\lambda}", block: false)#text(", then ")#tao-math("{\\left|My\\right| > \\lambda/2}", block: false)#text(" for some ")#mi("{y \\in \\Sigma}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" Clearly, if one replaces the maximal ")#mi("{1/2}")#text("-net here with an maximal ")#mi("{\\varepsilon}")#text("-net for some other ")#mi("{0<\\varepsilon<1}")#text(" (defined in the obvious manner), then we get the same conclusion, but with ")#mi("{\\lambda/2}")#text(" replaced by ")#mi("{\\lambda (1-\\varepsilon)}")#text(".")
]

#text("Now that we have discretised the range of points ")#mi("{y}")#text(" to be finite, the union bound becomes viable again. We first make the following basic observation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Volume packing argument)")]#text(" ")#metadata(none) <tao-62d7a6b1211d627650e2>#text(" Let ")#mi("{0 < \\varepsilon < 1}")#text(", and let ")#mi("{\\Sigma}")#text(" be a ")#mi("{\\varepsilon}")#text("-net of the sphere ")#mi("{S}")#text(". Then ")#mi("{\\Sigma}")#text(" has cardinality at most ")#mi("{(C/\\varepsilon)^{2n}}")#text(" for some absolute constant ")#mi("{C>0}")#text(".")
]

#emph[#text("Proof:")]#text(" Consider the balls of radius ")#mi("{\\varepsilon/2}")#text(" centred around each point in ")#mi("{\\Sigma}")#text("; by hypothesis, these are disjoint. On the other hand, by the triangle inequality, they are all contained in the ball of radius ")#mi("{3/2}")#text(" centred at the origin. The volume of the latter ball is at most ")#mi("{(C/\\varepsilon)^{2n}}")#text(" the volume of any of the small balls, and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Conversely, if ")#mi("{\\Sigma}")#text(" is a ")#emph[#text("maximal")]#text(" ")#mi("{\\varepsilon}")#text("-net, show that ")#mi("{\\Sigma}")#text(" has cardinality ")#emph[#text("at least")]#text(" ")#mi("{(c/\\varepsilon)^n}")#text(" for some absolute constant ")#mi("{c>0}")#text(".")
]

#text("And now we get an upper tail estimate:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 6 (Upper tail estimate for iid ensembles)")]#text(" ")#metadata(none) <tao-7f810f1ac2a25ddc1c79>#text(" Suppose that the coefficients ")#mi("{\\xi_{ij}}")#text(" of ")#mi("{M}")#text(" are independent, have mean zero, and uniformly bounded in magnitude by ")#mi("{1}")#text(". Then there exists absolute constants ")#mi("{C, c > 0}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left\\|M\\right\\|_{op} > A \\sqrt{n} ) \\leq C \\exp( - c A^2 n )", block: true)]]

#text("for all ")#mi("{A \\geq C}")#text(". In particular, we have ")#tao-math("{\\left\\|M\\right\\|_{op} = O( \\sqrt{n} )}", block: false)#text(" with overwhelming probability.")
]

#emph[#text("Proof:")]#text(" From Lemma ")#link(<tao-507a9a8be3d145a86daa>)[#text("2")]#text(" and the union bound, we have")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left\\|M\\right\\|_{op} > A \\sqrt{n} ) \\leq \\sum_{y \\in \\Sigma} {\\bf P}( \\left|My\\right| > A \\sqrt{n}/2 )", block: true)]]

#text("where ")#mi("{\\Sigma}")#text(" is a maximal ")#mi("{1/2}")#text("-net of ")#mi("{S}")#text(". By Lemma ")#link(<tao-bb54068aea85faa7e487>)[#text("1")]#text(", each of the probabilities ")#tao-math("{{\\bf P}( \\left|My\\right| > A \\sqrt{n}/2 )}", block: false)#text(" is bounded by ")#mi("{C \\exp( - c A^2 n )}")#text(" if ")#mi("{A}")#text(" is large enough. Meanwhile, from Lemma ")#link(<tao-62d7a6b1211d627650e2>)[#text("4")]#text(", ")#mi("{\\Sigma}")#text(" has cardinality ")#mi("{O(1)^n}")#text(". If ")#mi("{A}")#text(" is large enough, the ")#emph[#text("entropy loss")]#text(" of ")#mi("{O(1)^n}")#text(" can be absorbed into the exponential gain of ")#mi("{\\exp(-c A^2 n)}")#text(" by modifying ")#mi("{c}")#text(" slightly, and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" If ")#mi("{\\Sigma}")#text(" is a maximal ")#mi("{1/4}")#text("-net instead of a maximal ")#mi("{1/2}")#text("-net, establish the following variant")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left\\|M\\right\\|_{op} > \\lambda ) \\leq {\\bf P}( \\bigvee_{x,y \\in \\Sigma} \\left|x^*My\\right| > \\lambda/4 )", block: true)]]

#text("of Lemma ")#link(<tao-507a9a8be3d145a86daa>)[#text("2")]#text(". Use this to provide an alternate proof of Corollary ")#link(<tao-7f810f1ac2a25ddc1c79>)[#text("6")]#text(".")
]

#text("The above result was for matrices with independent entries, but it easily extends to the Wigner case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 8 (Upper tail estimate for Wigner ensembles)")]#text(" ")#metadata(none) <tao-3e2d79e439889c550654>#text(" Suppose that the coefficients ")#mi("{\\xi_{ij}}")#text(" of ")#mi("{M}")#text(" are independent for ")#mi("{j \\geq i}")#text(", mean zero, and uniformly bounded in magnitude by ")#mi("{1}")#text(", and let ")#mi("{\\xi_{ij} := \\overline{\\xi_{ji}}}")#text(" for ")#mi("{j<i}")#text(". Then there exists absolute constants ")#mi("{C, c > 0}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left\\|M\\right\\|_{op} > A \\sqrt{n} ) \\leq C \\exp( - c A n )", block: true)]]

#text("for all ")#mi("{A \\geq C}")#text(". In particular, we have ")#tao-math("{\\left\\|M\\right\\|_{op} = O( \\sqrt{n} )}", block: false)#text(" with overwhelming probability.")
]

#emph[#text("Proof:")]#text(" From Corollary ")#link(<tao-7f810f1ac2a25ddc1c79>)[#text("6")]#text(", the claim already holds for the upper-triangular portion of ")#mi("{M}")#text(", as well as for the strict lower-triangular portion of ")#mi("{M}")#text(". The claim then follows from the triangle inequality (adjusting the constants ")#mi("{C, c}")#text(" appropriately). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Generalise Corollary ")#link(<tao-7f810f1ac2a25ddc1c79>)[#text("6")]#text(" and Corollary ")#link(<tao-3e2d79e439889c550654>)[#text("8")]#text(" to the case where the coefficients ")#mi("{\\xi_{ij}}")#text(" have uniform subgaussian tails, rather than being uniformly bounded in magnitude by ")#mi("{1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 10")]#text(" What we have just seen is a simple example of an ")#emph[#text("epsilon net argument")]#text(", which is useful when controlling a supremum of random variables ")#mi("{\\sup_{x \\in S} X_x}")#text(" such as ")#link(<tao-40685fd53d8eb3b1e921>)[#text("(1)")]#text(", where each individual random variable ")#mi("{X_x}")#text(" is known to obey a large deviation inequality (in this case, Lemma ")#link(<tao-bb54068aea85faa7e487>)[#text("1")]#text("). The idea is to use metric arguments (e.g. the triangle inequality, see Lemma ")#link(<tao-507a9a8be3d145a86daa>)[#text("2")]#text(") to refine the set of parameters ")#mi("{S}")#text(" to take the supremum over to an ")#mi("{\\varepsilon}")#text("-net ")#mi("{\\Sigma = \\Sigma_\\varepsilon}")#text(" for some suitable ")#mi("{\\varepsilon}")#text(", and then apply the union bound. One takes a loss based on the cardinality of the ")#mi("{\\varepsilon}")#text("-net (which is basically the ")#link("http://mathworld.wolfram.com/KolmogorovEntropy.html")[#text("metric entropy")]#text(" or ")#link("http://en.wikipedia.org/wiki/Covering_number")[#text("covering number")]#text(" of the original parameter space at scale ")#mi("{\\varepsilon}")#text("), but one can hope that the bounds from the large deviation inequality are strong enough (and the metric entropy bounds sufficiently accurate) to overcome this entropy loss.")#linebreak()#text(" There is of course the question of what scale ")#mi("{\\varepsilon}")#text(" to use. In this simple example, the scale ")#mi("{\\varepsilon=1/2}")#text(" sufficed. In other contexts, one has to choose the scale ")#mi("{\\varepsilon}")#text(" more carefully. In more complicated examples with no natural preferred scale, it often makes sense to take a large range of scales (e.g. ")#mi("{\\varepsilon = 2^{-j}}")#text(" for ")#mi("{j=1,\\ldots,J}")#text(") and ")#emph[#text("chain")]#text(" them together by using telescoping series such as ")#mi("{X_x = X_{x_1} + \\sum_{j=1}^J X_{x_{j+1}} - X_{x_j}}")#text(" (where ")#mi("{x_j}")#text(" is the nearest point in ")#mi("{\\Sigma_j}")#text(" to ")#mi("{x}")#text(" for ")#mi("{j=1,\\ldots,J}")#text(", and ")#mi("{x_{J+1}}")#text(" is ")#mi("{x}")#text(" by convention) to estimate the supremum, the point being that one can hope to exploit cancellations between adjacent elements of the sequence ")#mi("{X_{x_j}}")#text(". This is known as the method of ")#emph[#text("chaining")]#text(". There is an even more powerful refinement of this method, known as the method of ")#emph[#text("generic chaining")]#text(", which has a large number of applications; see ")#link("http://www.ams.org/mathscinet-getitem?mr=2133757")[#text("this book by Talagrand")]#text(" for a beautiful and systematic treatment of the subject. However, we will not use this method in this course.")
]

#heading(level: 1)[#strong[#text(" — 2. A symmetrisation argument (optional) — ")]]

#text("We pause here to record an elegant ")#emph[#text("symmetrisation argument")]#text(" that exploits convexity to allow us to reduce without loss of generality to the symmetric case ")#mi("{M \\equiv -M}")#text(", albeit at the cost of losing a factor of ")#mi("{2}")#text(". We will not use this type of argument directly in these notes, but it is often used elsewhere in the literature.")#linebreak()#text(" Let ")#mi("{M}")#text(" be any random matrix with mean zero, and let ")#mi("{\\tilde M}")#text(" be an independent copy of ")#mi("{M}")#text(". Then, conditioning on ")#mi("{M}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} ( M - \\tilde M | M ) = M.")]]

#text("As the operator norm ")#tao-math("{M \\mapsto \\left\\|M\\right\\|_{op}}", block: false)#text(" is convex, we can then apply ")#link("http://en.wikipedia.org/wiki/Jensen%27s_inequality")[#text("Jensen’s inequality")]#text(" to conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} ( \\left\\|M - \\tilde M\\right\\|_{op} | M ) \\geq \\left\\|M\\right\\|_{op}.", block: true)]]

#text("Undoing the conditioning over ")#mi("{M}")#text(", we conclude that ")#metadata(none) <tao-168c4311daef6c51ee30>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("{\\bf E} \\left\\|M - \\tilde M\\right\\|_{op} \\geq {\\bf E} \\left\\|M\\right\\|_{op}.", block: true)]]

#text(" Thus, to upper bound the expected operator norm of ")#mi("{M}")#text(", it suffices to upper bound the expected operator norm of ")#mi("{M-\\tilde M}")#text(". The point is that even if ")#mi("{M}")#text(" is not symmetric (")#mi("{M \\not \\equiv -M}")#text("), ")#mi("{M - \\tilde M}")#text(" is automatically symmetric.")#linebreak()#text(" One can modify ")#link(<tao-168c4311daef6c51ee30>)[#text("(3)")]#text(" in a few ways, given some more hypotheses on ")#mi("{M}")#text(". Suppose now that ")#mi("{M=(\\xi_{ij})_{1 \\leq i,j \\leq n}}")#text(" is a matrix with independent entries, thus ")#mi("{M-\\tilde M}")#text(" has coefficients ")#mi("{\\xi_{ij}-\\tilde \\xi_{ij}}")#text(" where ")#mi("{\\tilde \\xi_{ij}}")#text(" is an independent copy of ")#mi("{\\xi_{ij}}")#text(". Introduce a random sign matrix ")#mi("{E = (\\varepsilon_{ij})_{1 \\leq i,j\\leq n}}")#text(" which is (jointly) independent of ")#mi("{M, \\tilde M}")#text(". Observe that as the distribution of ")#mi("{\\xi_{ij}-\\tilde \\xi_{ij}}")#text(" is symmetric, that")

#align(center)[#tao-fit-display[#mitex("(\\xi_{ij}-\\tilde \\xi_{ij}) \\equiv (\\xi_{ij}-\\tilde \\xi_{ij}) \\varepsilon_{ij},")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("(M-\\tilde M) \\equiv (M - \\tilde M) \\cdot E")]]

#text("where ")#mi("{A \\cdot B := (a_{ij} b_{ij})_{1\\leq i,j \\leq n}}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Hadamard_product#Hadamard_product")[#text("Hadamard product")]#text(" of ")#mi("{A = (a_{ij})_{1 \\leq i,j \\leq n}}")#text(" and ")#mi("{B = (b_{ij})_{1 \\leq i,j \\leq n}}")#text(". We conclude from ")#link(<tao-168c4311daef6c51ee30>)[#text("(3)")]#text(" that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left\\|M\\right\\|_{op} \\leq {\\bf E} \\left\\|(M - \\tilde M) \\cdot E\\right\\|_{op}.", block: true)]]

#text("By the distributive law and the triangle inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|(M - \\tilde M) \\cdot E\\right\\|_{op} \\leq \\left\\|M \\cdot E\\right\\|_{op} + \\left\\|\\tilde M \\cdot E\\right\\|_{op}.", block: true)]]

#text("But as ")#mi("{M \\cdot E \\equiv \\tilde M \\cdot E}")#text(", the quantities ")#tao-math("{\\left\\|M \\cdot E\\right\\|_{op}}", block: false)#text(" and ")#tao-math("{\\left\\|\\tilde M \\cdot E\\right\\|_{op}}", block: false)#text(" have the same expectation. We conclude the ")#emph[#text("symmetrisation inequality")]#text(" ")#metadata(none) <tao-828256d1b86c30b43b31>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("{\\bf E} \\left\\|M\\right\\|_{op} \\leq 2 {\\bf E} \\left\\| M \\cdot E\\right\\|_{op}.", block: true)]]

#linebreak()#text(" Thus, if one does not mind losing a factor of two, one has the freedom to randomise the sign of each entry of ")#mi("{M}")#text(" independently (assuming that the entries were already independent). Thus, in proving Corollary ")#link(<tao-7f810f1ac2a25ddc1c79>)[#text("6")]#text(", one could have reduced to the case when the ")#mi("{\\xi_{ij}}")#text(" were symmetric, though in this case this would not have made the argument that much simpler.")#linebreak()#text(" Sometimes it is preferable to multiply the coefficients by a Gaussian rather than by a random sign. Again, let ")#mi("{M = (\\xi_{ij})_{1 \\leq i,j \\leq n}}")#text(" have independent entries with mean zero. Let ")#mi("{G = (g_{ij})_{1 \\leq i,j \\leq n}}")#text(" be a real gaussian matrix independent of ")#mi("{M}")#text(", thus the ")#mi("{g_{ij} \\equiv N(0,1)_{\\bf R}}")#text(" are iid. We can split ")#tao-math("{G = E \\cdot \\left|G\\right|}", block: false)#text(", where ")#mi("{E := ( \\text{signum}(g_{ij}) )_{1 \\leq i,j \\leq n}}")#text(" and ")#tao-math("{\\left|G\\right| = (\\left|g_{ij}\\right|)_{1 \\leq i,j \\leq n}}", block: false)#text(". Note that ")#mi("{E}")#text(", ")#mi("{M}")#text(", ")#tao-math("{\\left|G\\right|}", block: false)#text(" are independent, and ")#mi("{E}")#text(" is a random sign matrix. In particular, ")#link(<tao-828256d1b86c30b43b31>)[#text("(4)")]#text(" holds. We now use")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" If ")#mi("{g \\equiv N(0,1)_{\\bf R}}")#text(", show that ")#tao-math("{{\\bf E} \\left|g\\right| = \\sqrt{\\frac{2}{\\pi}}}", block: false)#text(".")
]

#text("From this exercise we see that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} (M \\cdot E \\cdot \\left|G\\right| | M, E ) = \\sqrt{\\frac{2}{\\pi}} M \\cdot E", block: true)]]

#text("and hence by Jensen’s inequality again")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} (\\left\\| M \\cdot E \\cdot \\left|G\\right|\\right\\|_{op} | M, E ) \\geq \\sqrt{\\frac{2}{\\pi}} \\left\\|M \\cdot E\\right\\|_{op}.", block: true)]]

#text("Undoing the conditional expectation in ")#mi("{M, E}")#text(" and applying ")#link(<tao-828256d1b86c30b43b31>)[#text("(4)")]#text(" we conclude the ")#emph[#text("gaussian symmetrisation inequality")]#text(" ")#metadata(none) <tao-ed5e003e5051c269faf7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("{\\bf E} \\left\\|M\\right\\|_{op} \\leq \\sqrt{2\\pi} {\\bf E} \\left\\| M \\cdot G\\right\\|_{op}.", block: true)]]

#linebreak()#text(" Thus, for instance, when proving Corollary ")#link(<tao-7f810f1ac2a25ddc1c79>)[#text("6")]#text(", one could have inserted a random gaussian in front of each coefficient. This would have made the proof of Lemma ")#link(<tao-bb54068aea85faa7e487>)[#text("1")]#text(" marginally simpler (as one could compute directly with gaussians, and reduce the number of appeals to concentration of measure results) but in this case the improvement is negligible. In other situations though it can be quite helpful to have the additional random sign or random gaussian factor present. For instance, we have the following ")#link("http://www.ams.org/mathscinet-getitem?mr=2111932")[#text("result of Latala")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 12")]#text(" ")#metadata(none) <tao-473c3cba6f0b66454d76>#text(" Let ")#mi("{M = (\\xi_{ij})_{1 \\leq i,j \\leq n}}")#text(" be a matrix with independent mean zero entries, obeying the second moment bounds")

#tao-aligned(keep: true)[


#tao-math("\\sup_i \\sum_{j=1}^n {\\bf E} \\left|\\xi_{ij}\\right|^2  & \\leq K^2 n", block: true)



#tao-math("\\sup_j \\sum_{i=1}^n {\\bf E} \\left|\\xi_{ij}\\right|^2  & \\leq K^2 n", block: true)
]

#text("and the fourth moment bound")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i=1}^n \\sum_{j=1}^n {\\bf E} \\left|\\xi_{ij}\\right|^4 \\leq K^4 n^2", block: true)]]

#text("for some ")#mi("{K>0}")#text(". Then ")#tao-math("{{\\bf E} \\left\\|M\\right\\|_{op} = O( K \\sqrt{n} )}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" (Sketch only) Using ")#link(<tao-ed5e003e5051c269faf7>)[#text("(5)")]#text(" one can replace ")#mi("{\\xi_{ij}}")#text(" by ")#mi("{\\xi_{ij} \\cdot g_{ij}}")#text(" without much penalty. One then runs the epsilon-net argument with an explicit net, and uses concentration of measure results for gaussians (such as Theorem 8 from ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text(") to obtain the analogue of Lemma ")#link(<tao-bb54068aea85faa7e487>)[#text("1")]#text(". The details are rather intricate, and we refer the interested reader to ")#link("http://www.ams.org/mathscinet-getitem?mr=2111932")[#text("Latala’s paper")]#text(". ")#mi("\\Box")#linebreak()#text(" As a corollary of Theorem ")#link(<tao-473c3cba6f0b66454d76>)[#text("12")]#text(", we see that if we have an iid matrix (or Wigner matrix) of mean zero whose entries have a fourth moment of ")#mi("{O(1)}")#text(", then the expected operator norm is ")#mi("{O(\\sqrt{n})}")#text(". The fourth moment hypothesis is sharp. To see this, we make the trivial observation that the operator norm of a matrix ")#mi("{M = (\\xi_{ij})_{1 \\leq i,j \\leq n}}")#text(" bounds the magnitude of any of its coefficients, thus")

#align(center)[#tao-fit-display[#tao-math("\\sup_{1 \\leq i,j \\leq n} \\left|\\xi_{ij}\\right| \\leq \\left\\|M\\right\\|_{op}", block: true)]]

#text("or equivalently that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}(\\left\\|M\\right\\|_{op} \\leq \\lambda ) \\leq {\\bf P}(\\bigvee_{1 \\leq i,j \\leq n} \\left|\\xi_{ij}\\right| \\leq \\lambda).", block: true)]]

#text("In the iid case ")#mi("{\\xi_{ij} \\equiv \\xi}")#text(", and setting ")#mi("{\\lambda = A \\sqrt{n}}")#text(" for some fixed ")#mi("{A}")#text(" independent of ")#mi("{n}")#text(", we thus have ")#metadata(none) <tao-eebc18e08dec7f51cc59>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("{\\bf P}(\\left\\|M\\right\\|_{op} \\leq A \\sqrt{n} ) \\leq {\\bf P}(\\left|\\xi\\right| \\leq A \\sqrt{n})^{n^2}", block: true)]]

#text(" With the fourth moment hypothesis, one has from dominated convergence that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}(\\left|\\xi\\right| \\leq A \\sqrt{n}) \\geq 1 - o_A(1/n^2),", block: true)]]

#text("and so the right-hand side of ")#link(<tao-eebc18e08dec7f51cc59>)[#text("(6)")]#text(" is asymptotically trivial. But with weaker hypotheses than the fourth moment hypothesis, the rate of convergence of ")#tao-math("{{\\bf P}(\\left|\\xi\\right| \\leq A \\sqrt{n})}", block: false)#text(" to ")#mi("{1}")#text(" can be slower, and one can easily build examples for which the right-hand side of ")#link(<tao-eebc18e08dec7f51cc59>)[#text("(6)")]#text(" is ")#mi("{o_A(1)}")#text(" for every ")#mi("{A}")#text(", which forces ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(" to typically be much larger than ")#mi("{\\sqrt{n}}")#text(" on the average.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 13")]#text(" The symmetrisation inequalities remain valid with the operator norm replaced by any other convex norm on the space of matrices. The results are also just as valid for rectangular matrices as for square ones.")
]

#heading(level: 1)[#strong[#text(" — 3. Concentration of measure — ")]]

#text("Consider a random matrix ")#mi("{M}")#text(" of the type considered in Corollary ")#link(<tao-7f810f1ac2a25ddc1c79>)[#text("6")]#text(" (e.g. a random sign matrix). We now know that the operator norm ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(" is of size ")#mi("{O(\\sqrt{n})}")#text(" with overwhelming probability. But there is much more that can be said. For instance, by taking advantage of the convexity and Lipschitz properties of ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(", we have the following quick application of Talagrand’s inequality (Theorem 9 from ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 14")]#text(" Let ")#mi("{M}")#text(" be as in Corollary ")#link(<tao-7f810f1ac2a25ddc1c79>)[#text("6")]#text(". Then for any ")#mi("{\\lambda > 0}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left| \\left\\| M \\right\\|_{op} - {\\bf M} \\left\\| M \\right\\|_{op} \\right| \\geq \\lambda ) \\leq C \\exp(- c \\lambda^2 )", block: true)]]

#text("for some absolute constants ")#mi("{C, c > 0}")#text(", where ")#tao-math("{{\\bf M} \\left\\|M\\right\\|_{op}}", block: false)#text(" is a median value for ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(". The same result also holds with ")#tao-math("{{\\bf M} \\left\\| M\\right\\|_{op}}", block: false)#text(" replaced by the expectation ")#tao-math("{{\\bf E} \\left\\|M\\right\\|_{op}}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" We view ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(" as a function ")#mi("{F( (\\xi_{ij})_{1 \\leq i,j \\leq n} )}")#text(" of the independent complex variables ")#mi("{\\xi_{ij}}")#text(", thus ")#mi("{F}")#text(" is a function from ")#mi("{{\\bf C}^{n^2}}")#text(" to ")#mi("{{\\bf R}}")#text(". The convexity of the operator norm tells us that ")#mi("{F}")#text(" is convex. The triangle inequality, together with the elementary bound ")#metadata(none) <tao-26b7c362884170e0ba38>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left\\|M\\right\\|_{op} \\leq \\left\\|M\\right\\|_F", block: true)]]

#text(" (easily proven by Cauchy-Schwarz), where")

#align(center)[#tao-fit-display[#tao-math("\\left\\|M\\right\\|_F := (\\sum_{i=1}^n \\sum_{j=1}^n \\left|\\xi_{ij}\\right|^2)^{1/2}", block: true)]]

#text("is the ")#link("http://en.wikipedia.org/wiki/Matrix_norm#Frobenius_norm")[#text("Frobenius norm")]#text(" (also known as the ")#link("http://en.wikipedia.org/wiki/Hilbert-Schmidt_operator")[#text("Hilbert-Schmidt norm")]#text(" or ")#link("http://en.wikipedia.org/wiki/Schatten_norm")[#mi("{2}")#text("-Schatten norm")]#text("), tells us that ")#mi("{F}")#text(" is Lipschitz with constant ")#mi("{1}")#text(". The claim then follows directly from Talagrand’s inequality. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" ")#metadata(none) <tao-f1cf1224414e1a144fbb>#text(" Establish a similar result for the matrices in Corollary ")#link(<tao-3e2d79e439889c550654>)[#text("8")]#text(".")
]

#text("From Corollary ")#link(<tao-7f810f1ac2a25ddc1c79>)[#text("6")]#text(" we know that the median or expectation of ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(" is of size ")#mi("{O(\\sqrt{n})}")#text("; we now know that ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(" concentrates around this median to width at most ")#mi("{O(1)}")#text(". (This turns out to be non-optimal; the Tracy-Widom law actually gives a concentration of ")#mi("{O(n^{-1/6})}")#text(", under some additional assumptions on ")#mi("{M}")#text(". Nevertheless this level of concentration is already non-trivial.)")#linebreak()#text(" However, this argument does not tell us much about what the median or expected value of ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(" actually ")#emph[#text("is")]#text(". For this, we will need to use other methods, such as the moment method which we turn to next.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 16")]#text(" Talagrand’s inequality, as formulated in these notes, relies heavily on convexity. Because of this, we cannot apply this argument directly to non-convex matrix statistics, such as singular values ")#mi("{\\sigma_j(M)}")#text(" other than the largest singular value ")#mi("{\\sigma_1(M)}")#text(". Nevertheless, one can still use this inequality to obtain good concentration results, by using the convexity of related quantities, such as the partial sums ")#mi("{\\sum_{j=1}^J \\sigma_j(M)}")#text("; see ")#link("http://www.ams.org/mathscinet-getitem?mr=2057479")[#text("this paper of Meckes")]#text(". Other approaches include the use of alternate large deviation inequalities, such as those arising from log-Sobolev inequalities (see e.g. this ")#link("http://www.ams.org/mathscinet-getitem?mr=2498298")[#text("book by Guionnet")]#text("), or by using more abstract versions of Talagrand’s inequality (see ")#link("http://www.ams.org/mathscinet-getitem?mr=1942311")[#text("this paper of Alon, Krivelevich, and Vu")]#text(").")
]

#heading(level: 1)[#strong[#text(" — 4. The moment method — ")]]

#text("We now bring the moment method to bear on the problem, starting with the easy moments and working one’s way up to the more sophisticated moments. It turns out that it is easier to work first with the case when ")#mi("{M}")#text(" is symmetric or Hermitian; we will discuss the non-symmetric case near the end of these notes.")#linebreak()#text(" The starting point for the moment method is the observation that for symmetric or Hermitian ")#mi("{M}")#text(", the operator norm ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(" is equal to the ")#mi("{\\ell^\\infty}")#text(" norm ")#metadata(none) <tao-ff93962d1f90f030b5a8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left\\|M\\right\\|_{op} = \\max_{1 \\leq i \\leq n} \\left|\\lambda_i\\right|", block: true)]]

#text(" of the eigenvalues ")#mi("{\\lambda_1,\\ldots,\\lambda_n\\in {\\bf R}}")#text(" of ")#mi("{M}")#text(". On the other hand, we have the standard linear algebra identity")

#align(center)[#tao-fit-display[#mitex("\\text{tr}(M) = \\sum_{i=1}^n \\lambda_i")]]

#text("and more generally")

#align(center)[#tao-fit-display[#mitex("\\text{tr}(M^k) = \\sum_{i=1}^n \\lambda_i^k.")]]

#text("In particular, if ")#mi("{k=2,4,\\ldots}")#text(" is an even integer, then ")#mi("{\\text{tr}(M^k)^{1/k}}")#text(" is just the ")#mi("{\\ell^k}")#text(" norm of these eigenvalues, and we have the inequalities ")#metadata(none) <tao-035a1315c0e41f550313>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left\\| M \\right\\|_{op}^k \\leq \\text{tr}(M^k) \\leq n \\left\\|M\\right\\|_{op}^k.", block: true)]]

#text(" To put this another way, knowledge of the ")#mi("{k^{th}}")#text(" moment ")#mi("{\\text{tr}(M^k)}")#text(" controls the operator norm up to a multiplicative factor of ")#mi("{n^{1/k}}")#text(". Taking larger and larger ")#mi("{k}")#text(", we should thus obtain more accurate control on the operator norm. (This is basically the philosophy underlying the ")#link("http://en.wikipedia.org/wiki/Power_iteration")[#text("power method")]#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 17")]#text(" In most cases, one expects the eigenvalues to be reasonably uniformly distributed, in which case the upper bound in ")#link(<tao-035a1315c0e41f550313>)[#text("(9)")]#text(" is closer to the truth than the lower bound. One scenario in which this can be rigorously established is if it is known that the eigenvalues of ")#mi("{M}")#text(" all come with a high multiplicity. This is often the case for matrices associated with group actions (particularly those which are ")#emph[#text("quasirandom")]#text(" in the ")#link("http://www.ams.org/mathscinet-getitem?mr=2410393")[#text("sense of Gowers")]#text("). However, this is usually not the case with most random matrix ensembles, and we must instead proceed by increasing ")#mi("{k}")#text(" as described above.")
]

#text("Let’s see how this method works in practice. The simplest case is that of the second moment ")#mi("{\\text{tr}(M^2)}")#text(", which in the Hermitian case works out to")

#align(center)[#tao-fit-display[#tao-math("\\text{tr}(M^2) = \\sum_{i=1}^n \\sum_{j=1}^n \\left|\\xi_{ij}\\right|^2 = \\left\\|M\\right\\|_F^2.", block: true)]]

#text("(Thus we see that ")#link(<tao-26b7c362884170e0ba38>)[#text("(7)")]#text(" is just the ")#mi("{k=2}")#text(" case of the lower inequality in ")#link(<tao-035a1315c0e41f550313>)[#text("(9)")]#text(", at least in the Hermitian case.)")#linebreak()#text(" The expression ")#tao-math("{\\sum_{i=1}^n \\sum_{j=1}^n \\left|\\xi_{ij}\\right|^2}", block: false)#text(" is easy to compute in practice. For instance, for the symmetric Bernoulli ensemble, this expression is exactly equal to ")#mi("{n^2}")#text(". More generally, if we have a Wigner matrix in which all off-diagonal entries have mean zero and unit variance, and the diagonal entries have mean zero and bounded variance (this is the case for instance for GOE), then the off-diagonal entries have mean ")#mi("{1}")#text(", and by the law of large numbers we see that this expression is almost surely asymptotic to ")#mi("{n^2}")#text(". (There is of course a dependence between the upper triangular and lower triangular entries, but this is easy to deal with by folding the sum into twice the upper triangular portion (plus the diagonal portion, which is lower order).)")#linebreak()#text(" From the weak law of large numbers, we see in particular that one has ")#metadata(none) <tao-7a5419284a6a1f5ba2bf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\sum_{i=1}^n \\sum_{j=1}^n \\left|\\xi_{ij}\\right|^2 = (1+o(1)) n^2", block: true)]]

#text(" asymptotically almost surely.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" If the ")#mi("{\\xi_{ij}}")#text(" have uniformly sub-exponential tail, show that we in fact have ")#link(<tao-7a5419284a6a1f5ba2bf>)[#text("(10)")]#text(" with overwhelming probability.")
]

#text("Applying ")#link(<tao-035a1315c0e41f550313>)[#text("(9)")]#text(", we obtain the bounds ")#metadata(none) <tao-a02b7d60358d492c935c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("(1+o(1)) \\sqrt{n} \\leq \\left\\|M\\right\\|_{op} \\leq (1+o(1)) n", block: true)]]

#text(" asymptotically almost surely. This is already enough to show that the median of ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(" is at least ")#mi("{(1+o(1)) \\sqrt{n}}")#text(", which complements (up to constants) the upper bound of ")#mi("{O(\\sqrt{n})}")#text(" obtained from the epsilon net argument. But the upper bound here is terrible; we will need to move to higher moments to improve it.")#linebreak()#text(" Accordingly, we now turn to the fourth moment. For simplicity let us assume that all entries ")#mi("{\\xi_{ij}}")#text(" have zero mean and unit variance. To control moments beyond the second moment, we will also assume that all entries are bounded in magnitude by some ")#mi("{K}")#text(". We expand")

#align(center)[#tao-fit-display[#mitex("\\text{tr}(M^4) = \\sum_{1 \\leq i_1,i_2,i_3,i_4 \\leq n} \\xi_{i_1 i_2} \\xi_{i_2 i_3} \\xi_{i_3 i_4} \\xi_{i_4 i_1}.")]]

#text("To understand this expression, we take expectations:")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\text{tr}(M^4) = \\sum_{1 \\leq i_1,i_2,i_3,i_4 \\leq n} {\\bf E} \\xi_{i_1 i_2} \\xi_{i_2 i_3} \\xi_{i_3 i_4} \\xi_{i_4 i_1}.")]]

#text("One can view this sum graphically, as a sum over length four cycles in the vertex set ")#mi("{\\{1,\\ldots,n\\}}")#text("; note that the four edges ")#mi("{\\{i_1,i_2\\}, \\{i_2,i_3\\}, \\{i_3,i_4\\}, \\{i_4,i_1\\}}")#text(" are allowed to be degenerate if two adjacent ")#mi("{\\xi_i}")#text(" are equal. The value of each term ")#metadata(none) <tao-599f7703547e9c8e980f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("{\\bf E} \\xi_{i_1 i_2} \\xi_{i_2 i_3} \\xi_{i_3 i_4} \\xi_{i_4 i_1}")]]

#text(" in this sum depends on what the cycle does.")#linebreak()#text(" Firstly, there is the case when all the four edges ")#mi("{\\{i_1,i_2\\}, \\{i_2,i_3\\}, \\{i_3,i_4\\}, \\{i_4,i_1\\}}")#text(" are distinct. Then the four factors ")#mi("{\\xi_{i_1 i_2},\\ldots,\\xi_{i_4 i_1}}")#text(" are independent; since we are assuming them to have mean zero, the term ")#link(<tao-599f7703547e9c8e980f>)[#text("(12)")]#text(" vanishes. Indeed, the same argument shows that the only terms that do not vanish are those in which each edge is repeated at least twice. A short combinatorial case check then shows that, up to cyclic permutations of the ")#mi("{i_1,i_2,i_3,i_4}")#text(" indices there are now only a few types of cycles in which the term ")#link(<tao-599f7703547e9c8e980f>)[#text("(12)")]#text(" does not automatically vanish:")

#list(
[#mi("{i_1=i_3}")#text(", but ")#mi("{i_2, i_4}")#text(" are distinct from each other and from ")#mi("{i_1}")#text(".")],
[#mi("{i_1=i_3}")#text(" and ")#mi("{i_2=i_4}")#text(".")],
[#mi("{i_1=i_2=i_3}")#text(", but ")#mi("{i_4}")#text(" is distinct from ")#mi("{i_1}")#text(".")],
[#mi("{i_1=i_2=i_3=i_4}")#text(".")]
)

#text("In the first case, the independence and unit variance assumptions tells us that ")#link(<tao-599f7703547e9c8e980f>)[#text("(12)")]#text(" is ")#mi("{1}")#text(", and there are ")#mi("{O(n^3)}")#text(" such terms, so the total contribution here to ")#mi("{{\\bf E} \\text{tr}(M^4)}")#text(" is at most ")#mi("{O(n^3)}")#text(". In the second case, the unit variance and bounded by ")#mi("{K}")#text(" tells us that the term is ")#mi("{O(K^2)}")#text(", and there are ")#mi("{O(n^2)}")#text(" such terms, so the contribution here is ")#mi("{O(n^2 K^2)}")#text(". Similarly, the contribution of the third type of cycle is ")#mi("{O(n^2)}")#text(", and the fourth type of cycle is ")#mi("{O(n K^2)}")#text(", so we can put it all together to get")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\text{tr}(M^4) \\leq O( n^3 ) + O( n^2 K^2 ).")]]

#text("In particular, if we make the hypothesis ")#mi("{K = O(\\sqrt{n})}")#text(", then we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\text{tr}(M^4) \\leq O(n^3),")]]

#text("and thus by Markov’s inequality we see that for any ")#mi("{\\varepsilon > 0}")#text(", ")#mi("{\\text{tr}(M^4) \\leq O_\\varepsilon(n^3)}")#text(" with probability at least ")#mi("{1-\\varepsilon}")#text(". Applying ")#link(<tao-035a1315c0e41f550313>)[#text("(9)")]#text(", this leads to the upper bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| M \\right\\|_{op} \\leq O_\\varepsilon( n^{3/4} )", block: true)]]

#text("with probability at least ")#mi("{1-\\varepsilon}")#text("; a similar argument shows that for any fixed ")#mi("{\\varepsilon > 0}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| M \\right\\|_{op} \\leq n^{3/4+\\varepsilon}", block: true)]]

#text("with high probability. This is better than the upper bound obtained from the second moment method, but still non-optimal.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" ")#metadata(none) <tao-dc81b1d371a4072be7fc>#text(" If ")#mi("{K = o(\\sqrt{n})}")#text(", use the above argument to show that")

#align(center)[#tao-fit-display[#tao-math("({\\bf E} \\left\\|M\\right\\|_{op}^4)^{1/4} \\geq (2^{1/4}+o(1)) \\sqrt{n}", block: true)]]

#text("which in some sense improves upon ")#link(<tao-a02b7d60358d492c935c>)[#text("(11)")]#text(" by a factor of ")#mi("{2^{1/4}}")#text(". In particular, if ")#mi("{K = O(1)}")#text(", conclude that the median of ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(" is at least ")#mi("{(2^{1/4}+o(1)) \\sqrt{n}}")#text(".")
]

#text("Now let us take a quick look at the sixth moment, again with the running assumption of a Wigner matrix in which all entries have mean zero, unit variance, and bounded in magnitude by ")#mi("{K}")#text(". We have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\text{tr}(M^6) = \\sum_{1 \\leq i_1,\\ldots,i_6 \\leq n} {\\bf E} \\xi_{i_1 i_2} \\ldots \\xi_{i_5 i_6} \\xi_{i_6 i_1},")]]

#text("a sum over cycles of length ")#mi("{6}")#text(" in ")#mi("{\\{1,\\ldots,n\\}}")#text(". Again, most of the summands here vanish; the only ones which do not are those cycles in which each edge occurs at least twice (so in particular, there are at most three distinct edges).")#linebreak()#text(" Classifying all the types of cycles that could occur here is somewhat tedious, but it is clear that there are going to be ")#mi("{O(1)}")#text(" different types of cycles. But we can organise things by the multiplicity of each edge, leaving us with four classes of cycles to deal with:")

#list(
[#text("Cycles in which there are three distinct edges, each occuring two times.")],
[#text("Cycles in which there are two distinct edges, one occuring twice and one occuring four times.")],
[#text("Cycles in which there are two distinct edges, each occuring three times. (Actually, this case ends up being impossible, due to a “")#link("http://en.wikipedia.org/wiki/Seven_Bridges_of_K%C3%B6nigsberg")[#text("bridges of Königsberg")]#text("” type of obstruction, but we will retain it for this discussion.)")],
[#text("Cycles in which a single edge occurs six times.")]
)

#text("It is not hard to see that summands coming from the first type of cycle give a contribution of ")#mi("{1}")#text(", and there are ")#mi("{O(n^4)}")#text(" of these (because such cycles span at most four vertices). Similarly, the second and third types of cycles give a contribution of ")#mi("{O( K^2 )}")#text(" per summand, and there are ")#mi("{O( n^3 )}")#text(" summands; finally, the fourth type of cycle gives a contribution of ")#mi("{O( K^4 )}")#text(", with ")#mi("{O(n^2)}")#text(" summands. Putting this together we see that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\text{tr}(M^6) \\leq O( n^4 ) + O( n^3 K^2 ) + O( n^2 K^4 );")]]

#text("so in particular if we assume ")#mi("{K = O(\\sqrt{n})}")#text(" as before, we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\text{tr}(M^6) \\leq O( n^4 )")]]

#text("and if we then use ")#link(<tao-035a1315c0e41f550313>)[#text("(9)")]#text(" as before we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| M \\right\\|_{op} \\leq O_\\varepsilon( n^{2/3} )", block: true)]]

#text("with probability ")#mi("{1-\\varepsilon}")#text(", for any ")#mi("{\\varepsilon > 0}")#text("; so we are continuing to make progress towards what we suspect (from the epsilon net argument) to be the correct bound of ")#mi("{n^{1/2}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" ")#metadata(none) <tao-effaa68d28df27c55812>#text(" If ")#mi("{K = o(\\sqrt{n})}")#text(", use the above argument to show that")

#align(center)[#tao-fit-display[#tao-math("({\\bf E} \\left\\|M\\right\\|_{op}^6)^{1/6} \\geq (5^{1/6}+o(1)) \\sqrt{n}.", block: true)]]

#text("In particular, if ")#mi("{K = O(1)}")#text(", conclude that the median of ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(" is at least ")#mi("{(5^{1/6}+o(1)) \\sqrt{n}}")#text(". Thus this is a (slight) improvement over Exercise ")#link(<tao-dc81b1d371a4072be7fc>)[#text("19")]#text(".")
]

#text("Let us now consider the general ")#mi("{k^{th}}")#text(" moment computation under the same hypotheses as before, with ")#mi("{k}")#text(" an even integer, and make some modest attempt to track the dependency of the constants on ")#mi("{k}")#text(". Again, we have ")#metadata(none) <tao-0505061109343cf72346>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("{\\bf E} \\text{tr}(M^k) = \\sum_{1 \\leq i_1,\\ldots,i_k \\leq n} {\\bf E} \\xi_{i_1 i_2} \\ldots \\xi_{i_k i_1},")]]

#text(" which is a sum over cycles of length ")#mi("{k}")#text(". Again, the only non-vanishing expectations are those for which each edge occurs twice; in particular, there are at most ")#mi("{k/2}")#text(" edges, and thus at most ")#mi("{k/2+1}")#text(" vertices.")#linebreak()#text(" We divide the cycles into various classes, depending on which edges are equal to each other. (More formally, a class is an equivalence relation ")#mi("{\\sim}")#text(" on a set of ")#mi("{k}")#text(" labels, say ")#mi("{\\{1,\\ldots,k\\}}")#text(" in which each equivalence class contains at least two elements, and a cycle of ")#mi("{k}")#text(" edges ")#mi("{\\{i_1,i_2\\},\\ldots,\\{i_k,i_1\\}}")#text(" lies in the class associated to ")#mi("{\\sim}")#text(" when we have that ")#mi("{\\{ i_j,i_{j+1} \\} = \\{i_{j^{\\prime}},i_{j^{\\prime}+1}\\}}")#text(" iff ")#mi("{j \\sim j^{\\prime}}")#text(", where we adopt the cyclic notation ")#mi("{i_{k+1} := i_1}")#text(".)")#linebreak()#text(" How many different classes could there be? We have to assign up to ")#mi("{k/2}")#text(" labels to ")#mi("{k}")#text(" edges, so a crude upper bound here is ")#mi("{(k/2)^{k}}")#text(".")#linebreak()#text(" Now consider a given class of cycle. It has ")#mi("{j}")#text(" edges ")#mi("{e_1,\\ldots,e_j}")#text(" for some ")#mi("{1 \\leq j \\leq k/2}")#text(", with multiplicities ")#mi("{a_1,\\ldots,a_j}")#text(", where ")#mi("{a_1,\\ldots,a_j}")#text(" are at least ")#mi("{2}")#text(" and add up to ")#mi("{k}")#text(". The ")#mi("{j}")#text(" edges span at most ")#mi("{j+1}")#text(" vertices; indeed, in addition to the first vertex ")#mi("{i_1}")#text(", one can specify all the other vertices by looking at the first appearance of each of the ")#mi("{j}")#text(" edges ")#mi("{e_1,\\ldots,e_j}")#text(" in the path from ")#mi("{i_1}")#text(" to ")#mi("{i_k}")#text(", and recording the final vertex of each such edge. From this, we see that the total number of cycles in this particular class is at most ")#mi("{n^{j+1}}")#text(". On the other hand, because each ")#mi("{\\xi_{ij}}")#text(" has mean zero, unit variance and is bounded by ")#mi("{K}")#text(", the ")#mi("{a^{th}}")#text(" moment of this coefficient is at most ")#mi("{K^{a-2}}")#text(" for any ")#mi("{a \\geq 2}")#text(". Thus each summand in ")#link(<tao-0505061109343cf72346>)[#text("(13)")]#text(" coming from a cycle in this class has magnitude at most")

#align(center)[#tao-fit-display[#mitex("K^{a_1-2} \\ldots K^{a_j-2} = K^{a_1+\\ldots+a_j-2j} = K^{k-2j}.")]]

#text("Thus the total contribution of this class to ")#link(<tao-0505061109343cf72346>)[#text("(13)")]#text(" is ")#mi("{n^{j+1} K^{k-2j}}")#text(", which we can upper bound by")

#align(center)[#tao-fit-display[#mitex("\\max(n^{\\frac{k}{2}+1}, n^2 K^{k-2} ) = n^{k/2 + 1} \\max( 1, K/\\sqrt{n} )^{k-2}.")]]

#text("Summign up over all classes, we obtain the (somewhat crude) bound")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\text{tr}(M^k) \\leq (k/2)^k n^{k/2+1} \\max( 1, K/\\sqrt{n} )^{k-2}")]]

#text("and thus by ")#link(<tao-035a1315c0e41f550313>)[#text("(9)")]

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left\\|M\\right\\|_{op}^k \\leq (k/2)^k n^{k/2+1} \\max( 1, K/\\sqrt{n} )^{k-2}", block: true)]]

#text("and so by Markov’s inequality we have")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left\\|M\\right\\|_{op} \\geq \\lambda ) \\leq \\lambda^{-k} (k/2)^k n^{k/2+1} \\max( 1, K/\\sqrt{n} )^{k-2}", block: true)]]

#text("for all ")#mi("{\\lambda > 0}")#text(". This, for instance, places the median of ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(" at ")#mi("{O( n^{1/k} k \\sqrt{n} \\max(1, K/\\sqrt{n}) )}")#text(". We can optimise this in ")#mi("{k}")#text(" by choosing ")#mi("{k}")#text(" to be comparable to ")#mi("{\\log n}")#text(", and so we obtain an upper bound of ")#mi("{O( \\sqrt{n} \\log n \\max(1, K/\\sqrt{n}) )}")#text(" for the median; indeed, a slight tweaking of the constants tells us that ")#tao-math("{\\left\\|M\\right\\|_{op} = O( \\sqrt{n} \\log n \\max(1, K/\\sqrt{n}) )}", block: false)#text(" with high probability.")#linebreak()#text(" The same argument works if the entries have at most unit variance rather than unit variance, thus we have shown")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 21 (Weak upper bound)")]#text(" ")#metadata(none) <tao-c089986327c6a2b409bb>#text(" Let ")#mi("{M}")#text(" be a random Hermitian matrix, with the upper triangular entries ")#mi("{\\xi_{ij}}")#text(", ")#mi("{i \\leq j}")#text(" being independent with mean zero and variance at most ")#mi("{1}")#text(", and bounded in magnitude by ")#mi("{K}")#text(". Then ")#tao-math("{\\left\\|M\\right\\|_{op} = O( \\sqrt{n} \\log n \\max(1, K/\\sqrt{n}) )}", block: false)#text(" with high probability.")
]

#text("When ")#mi("{K \\leq \\sqrt{n}}")#text(", this gives an upper bound of ")#mi("{O(\\sqrt{n} \\log n)}")#text(", which is still off by half a logarithm from the expected bound of ")#mi("{O(\\sqrt{n})}")#text(". We will remove this half-logarithmic loss later in these notes.")

#heading(level: 1)[#strong[#text(" — 5. Computing the moment to top order — ")]]

#text("Now let us consider the case when ")#mi("{K = o(\\sqrt{n})}")#text(", and each entry has variance exactly ")#mi("{1}")#text(". We have an upper bound")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\text{tr}(M^k) \\leq (k/2)^k n^{k/2+1};")]]

#text("let us try to get a more precise answer here (as in Exercises ")#link(<tao-dc81b1d371a4072be7fc>)[#text("19")]#text(", ")#link(<tao-effaa68d28df27c55812>)[#text("20")]#text("). Recall that each class of cycle contributed a bound of ")#mi("{n^{j+1} K^{k-2j}}")#text(" to this expression. If ")#mi("{K = o(\\sqrt{n})}")#text(", we see that such expressions are ")#mi("{o_k(n^{k/2+1})}")#text(" whenever ")#mi("{j < k/2}")#text(", where the ")#mi("{o_k()}")#text(" notation means that the decay rate as ")#mi("{n \\rightarrow \\infty}")#text(" can depend on ")#mi("{k}")#text(". So the total contribution of all such classes is ")#mi("{o_k(n^{k/2+1})}")#text(".")#linebreak()#text(" Now we consider the remaining classes with ")#mi("{j=k/2}")#text(". For such classes, each equivalence class of edges contains exactly two representatives, thus each edge is repeated exactly once. The contribution of each such cycle to ")#link(<tao-0505061109343cf72346>)[#text("(13)")]#text(" is exactly ")#mi("{1}")#text(", thanks to the unit variance and independence hypothesis. Thus, the total contribution of these classes to ")#mi("{{\\bf E} \\text{tr}(M^k)}")#text(" is equal to a purely combinatorial quantity, namely the number of cycles of length ")#mi("{k}")#text(" on ")#mi("{\\{1,\\ldots,n\\}}")#text(" in which each edge is repeated exactly once, yielding ")#mi("{k/2}")#text(" unique edges. We are thus faced with the enumerative combinatorics problem of bounding this quantity as precisely as possible.")#linebreak()#text(" With ")#mi("{k/2}")#text(" edges, there are at most ")#mi("{k/2+1}")#text(" vertices traversed by the cycle. If there are fewer than ")#mi("{k/2+1}")#text(" vertices traversed, then there are at most ")#mi("{O_k(n^{k/2}) = o_k(n^{k/2+1})}")#text(" cycles of this type, since one can specify such cycles by identifying up to ")#mi("{k/2}")#text(" vertices in ")#mi("{\\{1,\\ldots,n\\}}")#text(" and then matching those coordinates with the ")#mi("{k}")#text(" vertices of the cycle. So we set aside these cycles, and only consider those cycles which traverse exactly ")#mi("{k/2+1}")#text(" vertices. Let us call such cycles (i.e. cycles of length ")#mi("{k}")#text(" with each edge repeated exactly once, and traversing exactly ")#mi("{k/2+1}")#text(" vertices) ")#emph[#text("non-crossing cycles")]#text(" of length ")#mi("{k}")#text(" in ")#mi("{\\{1,\\ldots,n\\}}")#text(". Our remaining task is then to count the number of non-crossing cycles.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 22")]#text(" ")#metadata(none) <tao-4801a65632db73daea89>#text(" Let ")#mi("{a,b,c,d}")#text(" be distinct elements of ")#mi("{\\{1,\\ldots,n\\}}")#text(". Then ")#mi("{(i_1,\\ldots,i_6) = (a,b,c,d,c,b)}")#text(" is a non-crossing cycle of length ")#mi("{k}")#text(", as is ")#mi("{(a,b,a,c,a,d)}")#text(". Any cyclic permutation of a non-crossing cycle is again a non-crossing cycle.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Show that a cycle of length ")#mi("{k}")#text(" is non-crossing if and only if there exists a ")#link("http://en.wikipedia.org/wiki/Tree_(graph_theory)")[#text("tree")]#text(" in ")#mi("{\\{1,\\ldots,n\\}}")#text(" of ")#mi("{k/2}")#text(" edges and ")#mi("{k/2+1}")#text(" vertices, such that the cycle lies in the tree and traverses each edge in the tree exactly twice.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" ")#metadata(none) <tao-1e5677b32282ff4ec5ce>#text(" Let ")#mi("{i_1,\\ldots,i_k}")#text(" be a cycle of length ")#mi("{k}")#text(". Arrange the integers ")#mi("{1,\\ldots,k}")#text(" around a circle, and draw a line segment between two distinct integers ")#mi("{1 \\leq a < b \\leq k}")#text(" whenever ")#mi("{i_a=i_b}")#text(", with no ")#mi("{c}")#text(" between ")#mi("{a,b}")#text(" for which ")#mi("{i_a=i_c=i_b}")#text(". Show that the cycle is non-crossing if and only if the number of line segments is exactly ")#mi("{k/2-1}")#text(", and the line segments do not cross each other. This may help explain the terminology “non-crossing”.")
]

#text("Now we can complete the count. If ")#mi("{k}")#text(" is a positive even integer, define a ")#link("http://en.wikipedia.org/wiki/Dyck_language")[#text("Dyck word")]#text(" of length ")#mi("{k}")#text(" to be the number of words consisting of left and right parentheses (, ) of length ")#mi("{k}")#text(", such that when one reads from left to right, there are always at least as many left parentheses as right parentheses (or in other words, the parentheses define a valid nesting). For instance, the only Dyck word of length ")#mi("{2}")#text(" is ")#mi("{()}")#text(", the two Dyck words of length ")#mi("{4}")#text(" are ")#mi("{(())}")#text(" and ")#mi("{()()}")#text(", and the five Dyck words of length ")#mi("{6}")#text(" are")

#align(center)[#tao-fit-display[#mitex("()()(), (())(), ()(()), (()()), ((())),")]]

#text("and so forth. (Dyck words are also closely related to ")#link("http://mathworld.wolfram.com/DyckPath.html")[#text("Dyck paths")]#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 25")]#text(" The number of non-crossing cycles of length ")#mi("{k}")#text(" in ")#mi("{\\{1,\\ldots,n\\}}")#text(" is equal to ")#mi("{C_{k/2} n (n-1) \\ldots (n-k/2)}")#text(", where ")#mi("{C_{k/2}}")#text(" is the number of Dyck words of length ")#mi("{k}")#text(". (The number ")#mi("{C_{k/2}}")#text(" is also known as the ")#mi("{(k/2)^{th}}")#text(" ")#link("http://en.wikipedia.org/wiki/Catalan_number")[#text("Catalan number")]#text(".)")
]

#emph[#text("Proof:")]#text(" We will give a ")#link("http://en.wikipedia.org/wiki/Bijective_proof")[#text("bijective proof")]#text(". Namely, we will find a way to store a non-crossing cycle as a Dyck word, together with an (ordered) sequence of ")#mi("{k/2+1}")#text(" distinct elements from ")#mi("{\\{1,\\ldots,n\\}}")#text(", in such a way that any such pair of a Dyck word and ordered sequence generates exactly one non-crossing cycle. This will clearly give the claim.")#linebreak()#text(" So, let us take a non-crossing cycle ")#mi("{i_1,\\ldots,i_k}")#text(". We imagine traversing this cycle from ")#mi("{i_1}")#text(" to ")#mi("{i_2}")#text(", then from ")#mi("{i_2}")#text(" to ")#mi("{i_3}")#text(", and so forth until we finally return to ")#mi("{i_1}")#text(" from ")#mi("{i_k}")#text(". On each leg of this journey, say from ")#mi("{i_j}")#text(" to ")#mi("{i_{j+1}}")#text(", we either use an edge that we have not seen before, or else we are using an edge for the second time. Let us say that the leg from ")#mi("{i_j}")#text(" to ")#mi("{i_{j+1}}")#text(" is an ")#emph[#text("innovative")]#text(" leg if it is in the first category, and a ")#emph[#text("returning")]#text(" leg otherwise. Thus there are ")#mi("{k/2}")#text(" innovative legs and ")#mi("{k/2}")#text(" returning legs. Clearly, it is only the innovative legs that can bring us to vertices that we have not seen before. Since we have to visit ")#mi("{k/2+1}")#text(" distinct vertices (including the vertex ")#mi("{i_1}")#text(" we start at), we conclude that each innovative leg must take us to a new vertex. We thus record, in order, each of the new vertices we visit, starting at ")#mi("{i_1}")#text(" and adding another vertex for each innovative leg; this is an ordered sequence of ")#mi("{k/2+1}")#text(" distinct elements of ")#mi("{\\{1,\\ldots,n\\}}")#text(". Next, traversing the cycle again, we write down a ")#mi("{(}")#text(" whenever we traverse an innovative leg, and an ")#mi("{)}")#text(" otherwise. This is clearly a Dyck word. For instance, using the examples in Example ")#link(<tao-4801a65632db73daea89>)[#text("22")]#text(", the non-crossing cycle ")#mi("{(a,b,c,d,c,b)}")#text(" gives us the ordered sequence ")#mi("{(a,b,c,d)}")#text(" and the Dyck word ")#mi("{((()))}")#text(", while ")#mi("{(a,b,a,c,a,d)}")#text(" gives us the ordered sequence ")#mi("{(a,b,c,d)}")#text(" and the Dyck word ")#mi("{()()()}")#text(".")#linebreak()#text(" We have seen that every non-crossing cycle gives rise to an ordered sequence and a Dyck word. A little thought shows that the cycle can be uniquely reconstructed from this ordered sequence and Dyck word (the key point being that whenever one is performing a returning leg from a vertex ")#mi("{v}")#text(", one is forced to return along the unique innovative leg that discovered ")#mi("{v}")#text("). A slight variant of this thought also shows that every Dyck word of length ")#mi("{k}")#text(" and ordered sequence of ")#mi("{k/2+1}")#text(" distinct elements gives rise to a non-crossing cycle. This gives the required bijection, and the claim follows. ")#mi("\\Box")#linebreak()#text(" Next, we recall the classical formula for the Catalan number:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" Establish the recurrence")

#align(center)[#tao-fit-display[#mitex("C_{n+1} = \\sum_{i=0}^{n} C_i C_{n-i}")]]

#text("for any ")#mi("{n \\geq 1}")#text(" (with the convention ")#mi("{C_0=1}")#text("), and use this to deduce that ")#metadata(none) <tao-13d528e410a2c0766c0e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("C_{k/2} := \\frac{k!}{(k/2+1)! (k/2)!}")]]

#text(" for all ")#mi("{k=2,4,6,\\ldots}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" Let ")#mi("{k}")#text(" be a positive even integer. Given a string of ")#mi("{k/2}")#text(" left parentheses and ")#mi("{k/2}")#text(" right parentheses which is ")#emph[#text("not")]#text(" a Dyck word, define the ")#emph[#text("reflection")]#text(" of this string by taking the first right parenthesis which does not have a matching left parenthesis, and then reversing all the parentheses after that right parenthesis. Thus, for instance, the reflection of ")#mi("{())(()}")#text(" is ")#mi("{())))(}")#text(". Show that there is a bijection between non-Dyck words with ")#mi("{k/2}")#text(" left parentheses and ")#mi("{k/2}")#text(" right parentheses, and arbitrary words with ")#mi("{k/2-1}")#text(" left parentheses and ")#mi("{k/2+1}")#text(" right parentheses. Use this to give an alternate proof of ")#link(<tao-13d528e410a2c0766c0e>)[#text("(14)")]#text(".")
]

#text("Note that ")#mi("{n(n-1)\\ldots(n-k/2) = (1+o_k(1)) n^{k/2+1}}")#text(". Putting all the above computations together, we conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 28 (Moment computation)")]#text(" ")#metadata(none) <tao-72110207b6499adb0ff6>#text(" Let ")#mi("{M}")#text(" be a real symmetric random matrix, with the upper triangular elements ")#mi("{\\xi_{ij}}")#text(", ")#mi("{i \\leq j}")#text(" jointly independent with mean zero and variance one, and bounded in magnitude by ")#mi("{o( \\sqrt{n})}")#text(". Let ")#mi("{k}")#text(" be a positive even integer. Then we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\text{tr}(M^k) = (C_{k/2} + o_k(1)) n^{k/2+1}")]]

#text("where ")#mi("{C_{k/2}}")#text(" is given by ")#link(<tao-13d528e410a2c0766c0e>)[#text("(14)")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 29")]#text(" An inspection of the proof also shows that if we allow the ")#mi("{\\xi_{ij}}")#text(" to have variance at most one, rather than equal to one, we obtain the upper bound")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\text{tr}(M^k) \\leq (C_{k/2} + o_k(1)) n^{k/2+1}.")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30")]#text(" ")#metadata(none) <tao-ab3754007c87b1437469>#text(" Show that Theorem ")#link(<tao-72110207b6499adb0ff6>)[#text("28")]#text(" also holds for Hermitian random matrices. (")#emph[#text("Hint")]#text(": The main point is that with non-crossing cycles, each non-innovative leg goes in the reverse direction to the corresponding innovative leg – why?)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 31")]#text(" Theorem ")#link(<tao-72110207b6499adb0ff6>)[#text("28")]#text(" can be compared with the formula")

#align(center)[#tao-fit-display[#mitex("{\\bf E} S^k = (C^{\\prime}_{k/2} + o_k(1)) n^{k/2}")]]

#text("derived in Notes 1, where ")#mi("{S = X_1 + \\ldots + X_n}")#text(" is the sum of ")#mi("{n}")#text(" iid random variables of mean zero and variance one, and")

#align(center)[#tao-fit-display[#mitex("C^{\\prime}_{k/2} := \\frac{k!}{2^{k/2} (k/2)!}.")]]

#text("Exercise ")#link(<tao-1e5677b32282ff4ec5ce>)[#text("24")]#text(" shows that ")#mi("{C_{k/2}}")#text(" can be interpreted as the number of ways to join ")#mi("{k}")#text(" points on the circle by ")#mi("{k/2-1}")#text(" non-crossing chords. In a similar vein, ")#mi("{C^{\\prime}_{k/2}}")#text(" can be interpreted as the number of ways to join ")#mi("{k}")#text(" points on the circle by ")#mi("{k/2}")#text(" chords which are allowed to cross each other (except at the endpoints). Thus moments of Wigner-type matrices are in some sense the “non-crossing” version of moments of sums of random variables. We will discuss this phenomenon more when we turn to free probability in later notes.")
]

#text("Combining Theorem ")#link(<tao-72110207b6499adb0ff6>)[#text("28")]#text(" with ")#link(<tao-035a1315c0e41f550313>)[#text("(9)")]#text(" we obtain a lower bound")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left\\|M\\right\\|_{op}^k \\geq (C_{k/2}+o_k(1)) n^{k/2}.", block: true)]]

#text("In the bounded case ")#mi("{K=O(1)}")#text(", we can combine this with Exercise ")#link(<tao-f1cf1224414e1a144fbb>)[#text("15")]#text(" to conclude that the median (or mean) of ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(" is at least ")#mi("{(C_{k/2}^{1/k}+o_k(1)) \\sqrt{n}}")#text(". On the other hand, from Stirling’s formula (")#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/")[#text("Notes 0a")]#text(") we see that ")#mi("{C_{k/2}^{1/k}}")#text(" converges to ")#mi("{2}")#text(" as ")#mi("{k \\rightarrow \\infty}")#text(". Taking ")#mi("{k}")#text(" to be a slowly growing function of ")#mi("{n}")#text(", we conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 32 (Lower bound)")]#text(" ")#metadata(none) <tao-2d24c9d4a6b65772ca58>#text(" Let ")#mi("{M}")#text(" be a real symmetric random matrix, with the upper triangular elements ")#mi("{\\xi_{ij}}")#text(", ")#mi("{i \\leq j}")#text(" jointly independent with mean zero and variance one, and bounded in magnitude by ")#mi("{O(1)}")#text(". Then the median (or mean) of ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(" is at least ")#mi("{(2-o(1)) \\sqrt{n}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 33")]#text(" One can in fact obtain an exact asymptotic expansion of the moments ")#mi("{{\\bf E} \\text{tr}(M^k)}")#text(" as a polynomial in ")#mi("{n}")#text(", known as the ")#emph[#text("genus expansion")]#text(" of the moments. This expansion is however somewhat difficult to work with from a combinatorial perspective (except at top order) and will not be used here.")
]

#heading(level: 1)[#strong[#text(" — 6. Removing the logarithm — ")]]

#text("The upper bound in Proposition ")#link(<tao-c089986327c6a2b409bb>)[#text("21")]#text(" loses a logarithm in comparison to the lower bound coming from Theorem ")#link(<tao-72110207b6499adb0ff6>)[#text("28")]#text(". We now discuss how to remove this logarithm.")#linebreak()#text(" Suppose that we could eliminate the ")#mi("{o_k(1)}")#text(" error in Theorem ")#link(<tao-72110207b6499adb0ff6>)[#text("28")]#text(". Then from ")#link(<tao-035a1315c0e41f550313>)[#text("(9)")]#text(" we would have")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left\\|M\\right\\|_{op}^k \\leq C_{k/2} n^{k/2+1}", block: true)]]

#text("and hence by Markov’s inequality")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}(\\left\\|M\\right\\|_{op} > \\lambda) \\leq \\lambda^{-k} C_{k/2} n^{k/2+1}.", block: true)]]

#text("Applying this with ")#mi("{\\lambda = (2+\\varepsilon) \\sqrt{n}}")#text(" for some fixed ")#mi("{\\varepsilon > 0}")#text(", and setting ")#mi("{k}")#text(" to be a large multiple of ")#mi("{\\log n}")#text(", we see that ")#tao-math("{\\left\\|M\\right\\|_{op} \\leq (2 + O(\\varepsilon)) \\sqrt{n}}", block: false)#text(" asymptotically almost surely, which on selecting ")#mi("{\\varepsilon}")#text(" to grow slowly in ")#mi("{n}")#text(" gives in fact that ")#tao-math("{\\left\\|M\\right\\|_{op} \\leq (2+o(1)) \\sqrt{n}}", block: false)#text(" asymptotically almost surely, thus complementing the lower bound in Proposition ")#link(<tao-2d24c9d4a6b65772ca58>)[#text("32")]#text(".")#linebreak()#text(" This argument was not rigorous because it did not address the ")#mi("{o_k(1)}")#text(" error. Without a more quantitative accounting of this error, one cannot set ")#mi("{k}")#text(" as large as ")#mi("{\\log n}")#text(" without losing control of the error terms; and indeed, a crude accounting of this nature will lose factors of ")#mi("{k^k}")#text(" which are unacceptable. Nevertheless, by tightening the hypotheses a little bit and arguing more carefully, we can get a good bound, for ")#mi("{k}")#text(" in the region of interest:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 34 (Improved moment bound)")]#text(" ")#metadata(none) <tao-50a04d3c554ef71e2a26>#text(" Let ")#mi("{M}")#text(" be a real symmetric random matrix, with the upper triangular elements ")#mi("{\\xi_{ij}}")#text(", ")#mi("{i \\leq j}")#text(" jointly independent with mean zero and variance one, and bounded in magnitude by ")#mi("{O(n^{0.49})}")#text(" (say). Let ")#mi("{k}")#text(" be a positive even integer of size ")#mi("{k=O(\\log^2 n)}")#text(" (say). Then we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\text{tr}(M^k) = C_{k/2} n^{k/2+1} + O( k^{O(1)} 2^k n^{k/2 + 0.98} )")]]

#text("where ")#mi("{C_{k/2}}")#text(" is given by ")#link(<tao-13d528e410a2c0766c0e>)[#text("(14)")]#text(". In particular, from the trivial bound ")#mi("{C_{k/2} \\leq 2^k}")#text(" (which is obvious from the Dyck words definition) one has ")#metadata(none) <tao-7f95ee312cdf03730d7b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("{\\bf E} \\text{tr}(M^k) \\leq (2+o(1))^k n^{k/2+1}.")]]


]

#text("One can of course adjust the parameters ")#mi("{n^{0.49}}")#text(" and ")#mi("{\\log^2 n}")#text(" in the above theorem, but we have tailored these parameters for our application to simplify the exposition slightly.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" We may assume ")#mi("{n}")#text(" large, as the claim is vacuous for bounded ")#mi("{n}")#text(".")#linebreak()#text(" We again expand using ")#link(<tao-0505061109343cf72346>)[#text("(13)")]#text(", and discard all the cycles in which there is an edge that only appears once. The contribution of the non-crossing cycles was already computed in the previous section to be")

#align(center)[#tao-fit-display[#mitex("C_{k/2} n (n-1) \\ldots (n-k/2),")]]

#text("which can easily be computed (e.g. by taking logarithms, or using Stirling’s formula) to be ")#mi("{(C_{k/2}+o(1)) n^{k/2+1}}")#text(". So the only task is to show that the net contribution of the remaining cycles is ")#mi("{O( k^{O(1)} 2^k n^{k/2} )}")#text(".")#linebreak()#text(" Consider one of these cycles ")#mi("{(i_1,\\ldots,i_k)}")#text("; it has ")#mi("{j}")#text(" distinct edges for some ")#mi("{1 \\leq j \\leq k/2}")#text(" (with each edge repeated at least once).")#linebreak()#text(" We order the ")#mi("{j}")#text(" distinct edges ")#mi("{e_1,\\ldots,e_j}")#text(" by their first appearance in the cycle. Let ")#mi("{a_1,\\ldots,a_j}")#text(" be the multiplicities of these edges, thus the ")#mi("{a_1,\\ldots,a_j}")#text(" are all at least ")#mi("{2}")#text(" and add up to ")#mi("{k}")#text(". Observe from the moment hypotheses that the moment ")#tao-math("{{\\bf E} \\left|\\xi_{ij}\\right|^a}", block: false)#text(" is bounded by ")#mi("{O(n^{0.49})^{a-2}}")#text(" for ")#mi("{a \\geq 2}")#text(". Since ")#mi("{a_1+\\ldots+a_j=k}")#text(", we conclude that the expression")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\xi_{i_1 i_2} \\ldots \\xi_{i_k i_1}")]]

#text("in ")#link(<tao-0505061109343cf72346>)[#text("(13)")]#text(" has magnitude at most ")#mi("{O(n^{0.49})^{k-2j}}")#text(", and so the net contribution of the cycles that are not non-crossing is bounded in magnitude by ")#metadata(none) <tao-1b99395b2df86d02b01f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\sum_{j=1}^{k/2} O(n^{0.49})^{k-2j} \\sum_{a_1,\\ldots,a_j} N_{a_1,\\ldots,a_j}")]]

#text(" where ")#mi("{a_1,\\ldots,a_j}")#text(" range over integers that are at least ")#mi("{2}")#text(" and which add up to ")#mi("{k}")#text(", and ")#mi("{N_{a_1,\\ldots,a_j}}")#text(" is the number of cycles that are not non-crossing and have ")#mi("{j}")#text(" distinct edges with multiplicity ")#mi("{a_1,\\ldots,a_j}")#text(" (in order of appearance). It thus suffices to show that ")#link(<tao-1b99395b2df86d02b01f>)[#text("(16)")]#text(" is ")#mi("{O( k^{O(1)} 2^k n^{k/2 + 0.98} )}")#text(".")#linebreak()#text(" Next, we estimate ")#mi("{N_{a_1,\\ldots,a_j}}")#text(" for a fixed ")#mi("{a_1,\\ldots,a_j}")#text(". Given a cycle ")#mi("{(i_1,\\ldots,i_k)}")#text(", we traverse its ")#mi("{k}")#text(" legs (which each traverse one of the edges ")#mi("{e_1,\\ldots,e_j}")#text(") one at a time and classify them into various categories:")

#list(
[#emph[#text("High-multiplicity legs")]#text(", which use an edge ")#mi("{e_i}")#text(" whose multiplicity ")#mi("{a_i}")#text(" is larger than two.")],
[#emph[#text("Fresh legs")]#text(", which use an edge ")#mi("{e_i}")#text(" with ")#mi("{a_i=2}")#text(" for the first time.")],
[#emph[#text("Return legs")]#text(", which use an edge ")#mi("{e_i}")#text(" with ")#mi("{a_i=2}")#text(" that has already been traversed by a previous fresh leg.")]
)

#text("We also subdivide fresh legs into ")#emph[#text("innovative")]#text(" legs, which take one to a vertex one has not visited before, and ")#emph[#text("non-innovative")]#text(" legs, which take one to a vertex that one has visited before.")#linebreak()#text(" At any given point in time when traversing this cycle, we define an ")#emph[#text("available")]#text(" edge to be an edge ")#mi("{e_i}")#text(" of multiplicity ")#mi("{a_i=2}")#text(" that has already been traversed by its fresh leg, but not by its return leg. Thus, at any given point in time, one travels along either a high-multiplicity leg, a fresh leg (thus creating a new available edge), or one returns along an available edge (thus removing that edge from availability).")#linebreak()#text(" Call a return leg starting from a vertex ")#mi("{v}")#text(" ")#emph[#text("forced")]#text(" if, at the time one is performing that leg, there is only one available edge from ")#mi("{v}")#text(", and ")#emph[#text("unforced")]#text(" otherwise (i.e. there are two or more available edges to choose from).")#linebreak()#text(" We suppose that there are ")#mi("{l := \\# \\{ 1 \\leq i \\leq j: a_i > 2 \\}}")#text(" high-multiplicity edges among the ")#mi("{e_1,\\ldots,e_j}")#text(", leading to ")#mi("{j-l}")#text(" fresh legs and their ")#mi("{j-l}")#text(" return leg counterparts. In particular, the total number of high-multiplicity legs is ")#metadata(none) <tao-1e0afa83c8f066fd3f94>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\sum_{a_i>2} a_i = k-2(j-l).")]]

#text(" Since ")#mi("{\\sum_{a_i>2} a_i \\geq 3l}")#text(", we conclude the bound ")#metadata(none) <tao-7d200356c3e1ed44efbf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("l \\leq k-2j.")]]

#linebreak()#text(" We assume that there are ")#mi("{m}")#text(" non-innovative legs among the ")#mi("{j-l}")#text(" fresh legs, leaving ")#mi("{j-l-m}")#text(" innovative legs. As the cycle is not non-crossing, we either have ")#mi("{j < k/2}")#text(" or ")#mi("{m > 0}")#text(".")#linebreak()#text(" Similarly, we assume that there are ")#mi("{r}")#text(" unforced return legs among the ")#mi("{j-l}")#text(" total return legs. We have an important estimate:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 35 (Not too many unforced return legs)")]#text(" ")#metadata(none) <tao-64f232610aa64e4f7f03>#text(" We have")

#align(center)[#tao-fit-display[#mitex("r \\leq 2 ( m + \\sum_{a_i>2} a_i ).")]]

#text("In particular, from ")#link(<tao-1e0afa83c8f066fd3f94>)[#text("(17)")]#text(", ")#link(<tao-7d200356c3e1ed44efbf>)[#text("(18)")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("r \\leq O(k-2j) + O(m).")]]
]

#emph[#text("Proof:")]#text(" Let ")#mi("{v}")#text(" be a vertex visited by the cycle which is not the initial vertex ")#mi("{i_1}")#text(". Then the very first arrival at ")#mi("{v}")#text(" comes from a fresh leg, which immediately becomes available. Each departure from ")#mi("{v}")#text(" may create another available edge from ")#mi("{v}")#text(", but each subsequent arrival at ")#mi("{v}")#text(" will delete an available leg from ")#mi("{v}")#text(", unless the arrival is along a non-innovative or high-multiplicity edge. (Note that one can loop from ")#mi("{v}")#text(" to itself and create an available edge, but this is along a non-innovative edge and so is not inconsistent with the previous statements.) Finally, any returning leg that departs from ")#mi("{v}")#text(" will also delete an available edge from ")#mi("{v}")#text(".")#linebreak()#text(" This has two consequences. Firstly, if there are no non-innovative or high-multiplicity edges arriving at ")#mi("{v}")#text(", then whenever one arrives at ")#mi("{v}")#text(", there is at most one available edge from ")#mi("{v}")#text(", and so every return leg from ")#mi("{v}")#text(" is forced. (And there will be only one such return leg.) If instead there are non-innovative or high-multiplicity edges arriving at ")#mi("{v}")#text(", then we see that the total number of return legs from ")#mi("{v}")#text(" is at most one plus the number of such edges. In both cases, we conclude that the number of unforced return legs from ")#mi("{v}")#text(" is bounded by twice the number of non-innovative or high-multiplicity edges arriving at ")#mi("{v}")#text(". Summing over ")#mi("{v}")#text(", one obtains the claim. ")#mi("\\Box")#linebreak()#text(" Now we return to the task of counting ")#mi("{N_{a_1,\\ldots,a_j}}")#text(", by recording various data associated to any given cycle ")#mi("{(i_1,\\ldots,i_k)}")#text(" contributing to this number. First, fix ")#mi("{m,r}")#text(". We record the initial vertex ")#mi("{i_1}")#text(" of the cycle, for which there are ")#mi("{n}")#text(" possibilities. Next, for each high-multiplicity edge ")#mi("{e_i}")#text(" (in increasing order of ")#mi("{i}")#text("), we record all the ")#mi("{a_i}")#text(" locations in the cycle where this edge is used; the total number of ways this can occur for each such edge can be bounded above by ")#mi("{k^{a_i}}")#text(", so the total entropy cost here is ")#mi("{k^{\\sum_{a_i>2} a_i} = k^{k-2(j-l)}}")#text(". We also record the final endpoint of the first occurrence of the edge ")#mi("{e_i}")#text(" for each such ")#mi("{i}")#text("; this list of ")#mi("{l}")#text(" vertices in ")#mi("{\\{1,\\ldots,n\\}}")#text(" has at most ")#mi("{n^l}")#text(" possibilities.")#linebreak()#text(" For each innovative leg, we record the final endpoint of that leg, leading to an additional list of ")#mi("{j-l-m}")#text(" vertices with at most ")#mi("{n^{j-l-m}}")#text(" possibilities.")#linebreak()#text(" For each non-innovative leg, we record the position of that leg, leading to a list of ")#mi("{m}")#text(" numbers from ")#mi("{\\{1,\\ldots,k\\}}")#text(", which has at most ")#mi("{k^m}")#text(" possibilities. We also record the position of the first time one already visited the vertex that the non-innovative leg is returning to, leading to a further list of ")#mi("{m}")#text(" numbers from ")#mi("{\\{1,\\dots,k\\}}")#text(", and another ")#mi("{k^m}")#text(" possibilities.")#linebreak()#text(" For each unforced return leg, we record the position of the corresponding fresh leg, leading to a list of ")#mi("{r}")#text(" numbers from ")#mi("{\\{1,\\ldots,k\\}}")#text(", which has at most ")#mi("{k^r}")#text(" possibilities.")#linebreak()#text(" Finally, we record a Dyck-like word of length ")#mi("{k}")#text(", in which we place a ")#mi("{(}")#text(" whenever the leg is innovative, and ")#mi("{)}")#text(" otherwise (the brackets need not match here). The total entropy cost here can be bounded above by ")#mi("{2^k}")#text(".")#linebreak()#text(" We now observe that all this data (together with ")#mi("{l,m,r}")#text(") can be used to completely reconstruct the original cycle. Indeed, as one traverses the cycle, the data already tells us which edges are high-multiplicity, which ones are innovative, which ones are non-innovative, and which ones are return legs. In all edges in which one could possibly visit a new vertex, the location of that vertex has been recorded. For all unforced returns, the data tells us which fresh leg to backtrack upon to return to. Finally, for forced returns, there is only one available leg to backtrack to, and so one can reconstruct the entire cycle from this data.")#linebreak()#text(" As a consequence, for fixed ")#mi("{l, m}")#text(" and ")#mi("{r}")#text(", there are at most")

#align(center)[#tao-fit-display[#mitex("n k^{k-2(j-l)} n^l n^{j-l-m} k^m k^m k^r 2^k")]]

#text("contributions to ")#mi("{N_{a_1,\\ldots,a_j}}")#text("; using ")#link(<tao-7d200356c3e1ed44efbf>)[#text("(18)")]#text(", ")#link(<tao-64f232610aa64e4f7f03>)[#text("(35)")]#text(" we can bound this by")

#align(center)[#tao-fit-display[#mitex("k^{O(k-2j)+O(m)} n^{j-m+1} 2^k.")]]

#text("Summing over the possible values of ")#mi("{m,r}")#text(" (recalling that we either have ")#mi("{j < k/2}")#text(" or ")#mi("{m>0}")#text(", and also that ")#mi("{k = O(\\log^2 n)}")#text(") we obtain")

#align(center)[#tao-fit-display[#mitex("N_{a_1,\\ldots,a_j} \\leq k^{O(k-2j) + O(1)} n^{\\max(j+1, k/2)} 2^k.")]]

#text("The expression ")#link(<tao-1b99395b2df86d02b01f>)[#text("(16)")]#text(" can then be bounded by")

#align(center)[#tao-fit-display[#mitex("2^k \\sum_{j=1}^{k/2} O(n^{0.49})^{k-2j} k^{O(k-2j) + O(1)} n^{\\max(j+1, k/2)} \\sum_{a_1,\\ldots,a_j} 1.")]]

#text("When ")#mi("{j}")#text(" is exactly ")#mi("{k/2}")#text(", then all the ")#mi("{a_1,\\ldots,a_j}")#text(" must equal ")#mi("{2}")#text(", and so the contribution of this case simplifies to ")#mi("{2^k k^{O(1)} n^{k/2}}")#text(". For ")#mi("{j < k/2}")#text(", the numbers ")#mi("{a_1-2,\\ldots,a_j-2}")#text(" are non-negative and add up to ")#mi("{k-2j}")#text(", and so the total number of possible values for these numbers (for fixed ")#mi("{j}")#text(") can be bounded crudely by ")#mi("{j^{k-2j} \\leq k^{k-2j}}")#text(" (for instance). Putting all this together, we can bound ")#link(<tao-1b99395b2df86d02b01f>)[#text("(16)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("2^k [ k^{O(1)} n^{k/2} + \\sum_{j=1}^{k/2-1} O(n^{0.49})^{k-2j} k^{O(k-2j) + O(1)} n^{j+1} k^{k-2j} ]")]]

#text("which simplifies by the geometric series formula (and the hypothesis ")#mi("{k = O(\\log^2 n)}")#text(") to")

#align(center)[#tao-fit-display[#mitex("O( 2^k k^{O(1)} n^{k/2 + 0.98} )")]]

#text("as required. ")#mi("\\Box")#linebreak()#text(" We can use this to conclude the following matching upper bound to Proposition ")#link(<tao-2d24c9d4a6b65772ca58>)[#text("32")]#text(", due ")#link("http://www.ams.org/mathscinet-getitem?mr=958213")[#text("to Bai and Yin")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 36 (Weak Bai-Yin theorem, upper bound)")]#text(" ")#metadata(none) <tao-4efe3bd75a7ee482d11a>#text(" Let ")#mi("{M = (\\xi_{ij})_{1 \\leq i,j \\leq n}}")#text(" be a real symmetric matrix whose entries all have the same distribution ")#mi("{\\xi}")#text(", with mean zero, variance one, and fourth moment ")#mi("{O(1)}")#text(". Then for every ")#mi("{\\varepsilon > 0}")#text(" independent of ")#mi("{n}")#text(", one has ")#tao-math("{\\left\\|M\\right\\|_{op} \\leq (2+\\varepsilon) \\sqrt{n}}", block: false)#text(" asymptotically almost surely. In particular, ")#tao-math("{\\left\\|M\\right\\|_{op} \\leq (2+o(1))\\sqrt{n}}", block: false)#text(" asymptotically almost surely; as another consequence, the median of ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(" is at most ")#mi("{(2+o(1))\\sqrt{n}}")#text(". (If ")#mi("{\\xi}")#text(" is bounded, we see in particular from Proposition ")#link(<tao-2d24c9d4a6b65772ca58>)[#text("32")]#text(" that the median is in fact equal to ")#mi("{(2+o(1))\\sqrt{n}}")#text(".)")
]

#text("The fourth moment hypothesis is best possible, as seen in the discussion after Theorem ")#link(<tao-473c3cba6f0b66454d76>)[#text("12")]#text(". We will discuss some generalisations and improvements of this theorem in other directions below.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" To obtain Theorem ")#link(<tao-4efe3bd75a7ee482d11a>)[#text("36")]#text(" from Theorem ")#link(<tao-50a04d3c554ef71e2a26>)[#text("34")]#text(" we use the truncation method. We split each ")#mi("{\\xi_{ij}}")#text(" as ")#mi("{\\xi_{ij,\\leq n^{0.49}} + \\xi_{ij,>n^{0.49}}}")#text(" in the usual manner, and split ")#mi("{M = M_{\\leq n^{0.49}} + M_{>n^{0.49}}}")#text(" accordingly. We would like to apply Theorem ")#link(<tao-50a04d3c554ef71e2a26>)[#text("34")]#text(" to ")#mi("{M_{\\leq n^{0.49}}}")#text(", but unfortunately the truncation causes some slight adjustment to the mean and variance of the ")#mi("{\\xi_{ij,\\leq n^{0.49}}}")#text(". The variance is not much of a problem; since ")#mi("{\\xi_{ij}}")#text(" had variance ")#mi("{1}")#text(", it is clear that ")#mi("{\\xi_{ij,\\leq n^{0.49}}}")#text(" has variance at most ")#mi("{1}")#text(", and it is easy to see that reducing the variance only serves to improve the bound ")#link(<tao-7f95ee312cdf03730d7b>)[#text("(15)")]#text(". As for the mean, we use the mean zero nature of ")#mi("{\\xi_{ij}}")#text(" to write")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\xi_{ij,\\leq n^{0.49}} = - {\\bf E} \\xi_{ij,> n^{0.49}}.")]]

#text("To control the right-hand side, we use the trivial inequality ")#tao-math("{\\left|\\xi_{ij,\\leq n^{0.49}}\\right| \\leq n^{- 3\\times 0.49} \\left|\\xi_{ij}\\right|^4}", block: false)#text(" and the bounded fourth moment hypothesis to conclude that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\xi_{ij,\\leq n^{0.49}} = O( n^{-1.47} ).")]]

#text("Thus we can write ")#mi("{M_{\\leq n^{0.49}} = \\tilde M_{\\leq n^{0.49}} + {\\bf E} M_{\\leq n^{0.49}}}")#text(", where ")#mi("{\\tilde M_{\\leq n^{0.49}}}")#text(" is the random matrix with coefficients")

#align(center)[#tao-fit-display[#mitex("\\tilde \\xi_{ij,\\leq n^{0.49}} := \\xi_{ij,\\leq n^{0.49}} - {\\bf E} \\xi_{ij,\\leq n^{0.49}}")]]

#text("and ")#mi("{{\\bf E} M_{\\leq n^{0.49}}}")#text(" is a matrix whose entries have magnitude ")#mi("{O(n^{-1.47})}")#text(". In particular, by Schur’s test this matrix has operator norm ")#mi("{O(n^{-0.47})}")#text(", and so by the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|M\\right\\|_{op} \\leq \\left\\| \\tilde M_{\\leq n^{0.49}} \\right\\|_{op} + \\left\\| M_{>n^{0.49}}\\right\\|_{op} + O( n^{-0.47} ).", block: true)]]

#text("The error term ")#mi("{O(n^{-0.47})}")#text(" is clearly negligible for ")#mi("{n}")#text(" large, and it will suffice to show that ")#metadata(none) <tao-2df6857e3f5c81323403>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("\\left\\| \\tilde M_{\\leq n^{0.49}} \\right\\|_{op} \\leq (2+\\varepsilon/3) \\sqrt{n}", block: true)]]

#text(" and ")#metadata(none) <tao-9159d6b8f61c99fb86be>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("\\left\\| M_{> n^{0.49}} \\right\\|_{op} \\leq \\frac{\\varepsilon}{3} \\sqrt{n}", block: true)]]

#text(" asymptotically almost surely.")#linebreak()#text(" We first show ")#link(<tao-2df6857e3f5c81323403>)[#text("(19)")]#text(". We can now apply Theorem ")#link(<tao-50a04d3c554ef71e2a26>)[#text("34")]#text(" to conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left\\| \\tilde M_{\\leq n^{0.49}} \\right\\|_{op}^k \\leq (2+o(1))^k n^{k/2+1}", block: true)]]

#text("for any ")#mi("{k = O(\\log^2 n)}")#text(". In particular, we see from Markov’s inequality that ")#link(<tao-2df6857e3f5c81323403>)[#text("(19)")]#text(" holds with probability at most")

#align(center)[#tao-fit-display[#mitex("(\\frac{2+o(1)}{2+\\varepsilon/3})^k n.")]]

#text("Setting ")#mi("{k}")#text(" to be a large enough multiple of ")#mi("{\\log n}")#text(" (depending on ")#mi("{\\varepsilon}")#text("), we thus see that this event ")#link(<tao-2df6857e3f5c81323403>)[#text("(19)")]#text(" indeed holds asymptotically almost surely (indeed, one can ensure it happens with overwhelming probability, by letting ")#mi("{k/\\log n}")#text(" grow slowly to infinity).")#linebreak()#text(" Now we turn to ")#link(<tao-9159d6b8f61c99fb86be>)[#text("(20)")]#text(". The idea here is to exploit the sparseness of the matrix ")#mi("{M_{> n^{0.49}}}")#text(". First let us dispose of the event that one of the entries ")#mi("{\\xi_{ij}}")#text(" has magnitude larger than ")#mi("{\\frac{\\varepsilon}{3} \\sqrt{n}}")#text(" (which would certainly cause ")#link(<tao-9159d6b8f61c99fb86be>)[#text("(20)")]#text(" to fail). By the union bound, the probability of this event is at most")

#align(center)[#tao-fit-display[#tao-math("n^2 {\\bf P}(\\left|\\xi\\right| \\geq \\frac{\\varepsilon}{3} \\sqrt{n}).", block: true)]]

#text("By the fourth moment bound on ")#mi("{\\xi}")#text(" and dominated convergence, this expression goes to zero as ")#mi("{n \\rightarrow \\infty}")#text(". Thus, asymptotically almost surely, all entries are less than ")#mi("{\\frac{\\varepsilon}{3} \\sqrt{n}}")#text(".")#linebreak()#text(" Now let us see how many non-zero entries there are in ")#mi("{M_{>n^{0.49}}}")#text(". By Markov’s inequality and the fourth moment hypothesis, each entry has a probability ")#mi("{O( n^{- 4 \\times 0.49} ) = O( n^{-1.96} )}")#text(" of being non-zero; by the first moment method, we see that the expected number of entries is ")#mi("{O( n^{0.04} )}")#text(". As this is much less than ")#mi("{n}")#text(", we expect it to be unlikely that any row or column has more than one entry. Indeed, from the union bound and independence, we see that the probability that any given row and column has at least two non-zero entries is at most")

#align(center)[#tao-fit-display[#mitex("n^2 \\times O( n^{-1.96})^2 = O( n^{-1.92} )")]]

#text("and so by the union bound again, we see that with probability at least ")#mi("{1-O(n^{-0.92})}")#text(" (and in particular, asymptotically almost surely), none of the rows or columns have more than one non-zero entry. As the entries have magnitude at most ")#mi("{\\frac{\\varepsilon}{3} \\sqrt{n}}")#text(", the bound ")#link(<tao-9159d6b8f61c99fb86be>)[#text("(20)")]#text(" now follows from Schur’s test, and the claim follows. ")#mi("\\Box")#linebreak()#text(" We can upgrade the asymptotic almost sure bound to almost sure boundedness:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 37 (Strong Bai-Yin theorem, upper bound)")]#text(" ")#metadata(none) <tao-1b6a652c24c2ca88c2e6>#text(" Let ")#mi("{\\xi}")#text(" be a real random variable with mean zero, variance ")#mi("{1}")#text(", and finite fourth moment, and for all ")#mi("{1 \\leq i \\leq j}")#text(", let ")#mi("{\\xi_{ij}}")#text(" be an iid sequence with distribution ")#mi("{\\xi}")#text(", and set ")#mi("{\\xi_{ji} := \\xi_{ij}}")#text(". Let ")#mi("{M_n := (\\xi_{ij})_{1 \\leq i,j \\leq n}}")#text(" be the random matrix formed by the top left ")#mi("{n \\times n}")#text(" block. Then almost surely one has ")#tao-math("{\\limsup_{n \\rightarrow \\infty} \\left\\|M_n\\right\\|_{op}/\\sqrt{n} \\leq 2}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38")]#text(" By combining the above results with Proposition ")#link(<tao-2d24c9d4a6b65772ca58>)[#text("32")]#text(" and Exercise ")#link(<tao-f1cf1224414e1a144fbb>)[#text("15")]#text(", show that with the hypotheses of Theorem ")#link(<tao-1b6a652c24c2ca88c2e6>)[#text("37")]#text(" with ")#mi("{\\xi}")#text(" bounded, one has ")#tao-math("{\\lim_{n \\rightarrow \\infty} \\left\\|M_n\\right\\|_{op}/\\sqrt{n} =2}", block: false)#text(" almost surely. (The same claim is true without the boundedness hypothesis; we will see this in the next set of notes, after we establish the semicircle law.)")
]

#emph[#text("Proof:")]#text(" We first ")#link("http://www.tricki.org/article/Create_an_epsilon_of_room")[#text("give ourselves an epsilon of room")]#text(". It suffices to show that for each ")#mi("{\\varepsilon > 0}")#text(", one has ")#metadata(none) <tao-3cba5ed7b7406ad73554>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\limsup_{n \\rightarrow \\infty} \\left\\|M_n\\right\\|_{op}/\\sqrt{n} \\leq 2+\\varepsilon", block: true)]]

#text(" almost surely.")#linebreak()#text(" Next, we perform dyadic sparsification (as was done in the proof of the strong law of large numbers in ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text("). Observe that any minor of a matrix has its operator norm bounded by that of the larger matrix; and so ")#tao-math("{\\left\\|M_n\\right\\|_{op}}", block: false)#text(" is increasing in ")#mi("{n}")#text(". Because of this, it will suffice to show ")#link(<tao-3cba5ed7b7406ad73554>)[#text("(21)")]#text(" almost surely for ")#mi("{n}")#text(" restricted to a ")#emph[#text("lacunary")]#text(" sequence, such as ")#mi("{n = n_m := \\lfloor (1+\\varepsilon)^m \\rfloor}")#text(" for ")#mi("{m=1,2,\\ldots}")#text(", as the general case then follows by rounding ")#mi("{n}")#text(" upwards to the nearest ")#mi("{n_m}")#text(" (and adjusting ")#mi("{\\varepsilon}")#text(" a little bit as necessary).")#linebreak()#text(" Once we sparsified, it is now safe to apply the Borel-Cantelli lemma (Exercise 1 of ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("Notes 0")]#text("), and it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{m=1}^\\infty {\\bf P}( \\left\\|M_{n_m}\\right\\|_{op} \\geq (2+\\varepsilon) \\sqrt{n_m} ) < \\infty.", block: true)]]

#text("To bound the probabilities ")#tao-math("{{\\bf P}( \\left\\|M_{n_m}\\right\\|_{op} \\geq (2+\\varepsilon) \\sqrt{n_m})}", block: false)#text(", we inspect the proof of Theorem ")#link(<tao-4efe3bd75a7ee482d11a>)[#text("36")]#text(". Most of the contributions to this probability decay polynomially in ")#mi("{n_m}")#text(" (i.e. are of the form ")#mi("{O(n_m^{-c})}")#text(" for some ")#mi("{c>0}")#text(") and so are summable. The only contribution which can cause difficulty is the contribution of the event that one of the entries of ")#mi("{M_{n_m}}")#text(" exceeds ")#mi("{\\frac{\\varepsilon}{3} \\sqrt{n_m}}")#text(" in magnitude; this event was bounded by")

#align(center)[#tao-fit-display[#tao-math("n_m^2 {\\bf P}(\\left|\\xi\\right| \\geq \\frac{\\varepsilon}{3} \\sqrt{n_m}).", block: true)]]

#text("But if one sums over ")#mi("{m}")#text(" using Fubini’s theorem and the geometric series formula, we see that this expression is bounded by ")#tao-math("{O_\\varepsilon({\\bf E} \\left|\\xi\\right|^4)}", block: false)#text(", which is finite by hypothesis, and the claim follows. ")#mi("\\Box")#linebreak()#text(" Now we discuss some variants and generalisations of the Bai-Yin result.")#linebreak()#text(" Firstly, we note that the results stated above require the diagonal and off-diagonal terms to have the same distribution. This is not the case for important ensembles such as the Gaussian Orthogonal Ensemble (GOE), in which the diagonal entries have twice as much variance as the off-diagonal ones. But this can easily be handled by considering the diagonal separately. For instance, consider a diagonal matrix ")#mi("{D = \\text{diag}(\\xi_{11},\\ldots,\\xi_{nn})}")#text(" where the ")#mi("{\\xi_{ii} \\equiv \\xi}")#text(" are identically distributed with finite second moment. The operator norm of this matrix is just ")#tao-math("{\\sup_{1 \\leq i \\leq n} \\left|\\xi_{ii}\\right|}", block: false)#text(", and so by the union bound")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}(\\left\\|D\\right\\|_{op} > \\varepsilon \\sqrt{n}) \\leq n {\\bf P}(\\left|\\xi\\right| > \\varepsilon \\sqrt{n}).", block: true)]]

#text("From the finite second moment and dominated convergence, the right-hand side is ")#mi("{o_\\varepsilon(1)}")#text(", and so we conclude that for for every fixed ")#mi("{\\varepsilon > 0}")#text(", ")#tao-math("{\\left\\|D\\right\\|_{op} \\leq \\varepsilon \\sqrt{n}}", block: false)#text(" asymptotically almost surely; diagonalising, we conclude that ")#tao-math("{\\left\\|D\\right\\|_{op} = o(\\sqrt{n})}", block: false)#text(" asymptotically almost surely. Because of this and the triangle inequality, we can modify the diagonal by any amount with identical distribution and bounded second moment (a similar argument also works for non-identical distributions if one has uniform control of some moment beyond the second, such as the fourth moment) while only affecting all operator norms by ")#mi("{o(\\sqrt{n})}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39")]#text(" Modify this observation to extend the weak and strong Bai-Yin theorems to the case where the diagonal entries are allowed to have different distribution than the off-diagonal terms, and need not be independent of each other or of the off-diagonal terms, but have uniformly bounded fourth moment.")
]

#text("Secondly, it is a routine matter to generalise the Bai-Yin result from real symmetric matrices to Hermitian matrices, basically for the same reasons that Exercise ")#link(<tao-ab3754007c87b1437469>)[#text("30")]#text(" works. We leave the details to the interested reader.")#linebreak()#text(" The Bai-Yin results also hold for iid random matrices, where ")#mi("{\\xi_{ij} \\equiv \\xi}")#text(" has mean zero, unit variance, and bounded fourth moment; this is a ")#link("http://www.ams.org/mathscinet-getitem?mr=950344")[#text("result of Yin, Bai, and Krishnaiah")]#text(". Because of the lack of symmetry, the eigenvalues need not be real, and the bounds ")#link(<tao-035a1315c0e41f550313>)[#text("(9)")]#text(" no longer apply. However, there is a substitute, namely the bound ")#metadata(none) <tao-e11e643662417d89182f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#tao-math("\\left\\| M \\right\\|_{op}^k \\leq \\text{tr}((MM^*)^{k/2}) \\leq n \\left\\|M\\right\\|_{op}^k,", block: true)]]

#text(" valid for any ")#mi("{n \\times n}")#text(" matrix ")#mi("{M}")#text(" with complex entries and every even positive integer ")#mi("{k}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 40")]#text(" Prove ")#link(<tao-e11e643662417d89182f>)[#text("(22)")]#text(".")
]

#text("It is possible to adapt all of the above moment calculations for ")#mi("{\\text{tr}(M^k)}")#text(" in the symmetric or Hermitian cases to give analogous results for ")#mi("{\\text{tr}((MM^*)^{k/2})}")#text(" in the non-symmetric cases; we do not give the details here, but mention that the cycles now go back and forth along a bipartite graph with ")#mi("{n}")#text(" vertices in each class, rather than in the complete graph on ")#mi("{n}")#text(" vertices, although this ends up not to affect the enumerative combinatorics significantly. Another way of viewing this is through the simple observation that the operator norm of a non-symmetric matrix ")#mi("{M}")#text(" is equal to the operator norm of the ")#emph[#text("augmented matrix")]#text(" ")#metadata(none) <tao-5d69825fe9a39338c74c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\tilde M := \\begin{pmatrix} 0 & M \\\\ M^* & 0 \\end{pmatrix}")]]

#text(" which is a ")#mi("{2n \\times 2n}")#text(" Hermitian matrix. Thus one can to some extent identify an ")#mi("{n \\times n}")#text(" iid matrix ")#mi("{M}")#text(" with a ")#mi("{2n \\times 2n}")#text(" Wigner-type matrix ")#mi("{\\tilde M}")#text(", in which two ")#mi("{n \\times n}")#text(" blocks of that matrix are set to zero.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 41")]#text(" If ")#mi("{M}")#text(" has singular values ")#mi("{\\sigma_1,\\ldots,\\sigma_n}")#text(", show that ")#mi("{\\tilde M}")#text(" has eigenvalues ")#mi("{\\pm \\sigma_1,\\ldots,\\pm \\sigma_n}")#text(". This suggests that the theory of the singular values of an iid matrix should resemble to some extent the theory of eigenvalues of a Wigner matrix; we will see several examples of this phenomenon in later notes.")
]

#text("When one assumes more moment conditions on ")#mi("{\\xi}")#text(" than bounded fourth moment, one can obtain substantially more precise asymptotics on ")#mi("{\\text{tr}(M^k)}")#text(" than given by results such as Theorem ")#link(<tao-50a04d3c554ef71e2a26>)[#text("34")]#text(", particularly if one also assumes that the underlying random variable ")#mi("{\\xi}")#text(" is symmetric (i.e. ")#mi("{\\xi \\equiv -\\xi}")#text("). At a practical level, the advantage of symmetry is that it allows one to assume that the high-multiplicity edges in a cycle are traversed an ")#emph[#text("even")]#text(" number of times; see the following exercise.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42")]#text(" Let ")#mi("{X}")#text(" be a bounded real random variable. Show that ")#mi("{X}")#text(" is symmetric if and only if ")#mi("{{\\bf E} X^k=0}")#text(" for all positive odd integers ")#mi("{k}")#text(".")#linebreak()#text(" Next, extend the previous result to the case when ")#mi("{X}")#text(" is subgaussian rather than bounded. (")#strong[#text("Hint:")]#text(" The slickest way to do this is via the characteristic function ")#mi("{e^{itX}}")#text(" and analytic continuation; it is also instructive to find a “real-variable” proof that avoids the use of this function.)")
]

#text("By using these methods, it is in fact possible to show that under various hypotheses, ")#tao-math("{\\left\\|M\\right\\|_{op}}", block: false)#text(" is concentrated in the range ")#mi("{[2\\sqrt{n}-O(n^{-1/6}), 2\\sqrt{n}+O(n^{-1/6})]}")#text(", and even to get a universal distribution for the normalised expression ")#tao-math("{(\\left\\|M\\right\\|_{op}-2\\sqrt{n}) n^{1/6}}", block: false)#text(", known as the ")#emph[#text("Tracy-Widom law")]#text(". See this ")#link("http://www.ams.org/mathscinet-getitem?mr=1727234")[#text("paper of Soshnikov")]#text(" for details. There has also been a number of subsequent variants and refinements of this result (as well as counterexamples when not enough moment hypotheses are assumed); see for instance these papers of ")#link("http://www.ams.org/mathscinet-getitem?mr=2081462")[#text("Soshnikov")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2125574")[#text("Soshnikov-Fyodorov")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2191882")[#text("Ruzmaikina")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2221787")[#text("Péché")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2384414")[#text("Vu")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2415136")[#text("Soshnikov-Péché")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2475670")[#text("Péché")]#text(", ")#link("http://arxiv.org/abs/0907.3743")[#text("Khorunzhiy")]#text(" and ")#link("http://arxiv.org/abs/0908.1982")[#text("Tao-Vu")]#text(" for an (incomplete) sample of the work in this area. (Similar results for some non-independent distributions are also available, see e.g. this ")#link("http://www.ams.org/mathscinet-getitem?mr=2306224")[#text("paper of Deift and Gioev")]#text(", which (like many of the other references just cited) builds upon the original work of ")#link("http://www.ams.org/mathscinet-getitem?mr=1989209")[#text("Tracy and Widom")]#text(" that handled special ensembles such as GOE and GUE.)")

#heading(level: 1)[#text("Comments (74)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-43169")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("Regarding the end of Remark 4, if you’ll forgive the immodesty, in ")#link("http://arxiv.org/abs/math/0211192")[#text("this paper")]#text(", I showed that one can get better concentration results for eigenvalues of symmetric matrices than Alon, Krivelevich, and Vu, by using actually the same version of Talagrand’s inequality you quoted previously (i.e. the more abstract version used by AKV is not necessary here).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-43173")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("Thanks for the reference! I’ve updated the remark accordingly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-43182")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("By the way, this post is by far the pedagogically nicest presentation I’ve ever seen of the moment method for random matrices. Beautiful!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ec2f78ceb57d9bd64b34cc4b78429f1c5eac54c83816135c602986374a75021-e038760ba298b6b7b263cacae9f591e1977f4216ef31f5659d7913e113c583d0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Leopardi")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-43190")[#strong[#text("Paul Leopardi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("Nice notes. I haven’t worked through them yet, but it looks like they would apply to the symmetric Wigner case where the diagonal entries are constant and the upper triangle is iid N(0,1), or iid with mean 0, variance 1 and bounded values: “Typically, the strictly upper triangular coefficients will be iid, as will the diagonal coefficients, but the two classes of coefficients may have a different distribution”. Working through the notes would then help me understand the moments of the Gram matrices for ")#link("http://wwwmaths.anu.edu.au/~leopardi/Stoc-Spec-2009-Random-Gram.pdf")[#text("polynomial interpolation on the sphere.")]#linebreak()#text(" Best, Paul")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3a: Eigenvalues and sums of Hermitian matrices « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-43225")[#strong[#text("254A, Notes 3a: Eigenvalues and sums of Hermitian matrices « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2010")])]

#text("[…] values of non-Hermitian matrices (which is consistent with the discussion near Exercise 16 of Notes 3). However, the situation is markedly different when dealing with eigenvalues of non-Hermitian […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orr")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-43226")[#strong[#text("Orr")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2010")])]

#text("I am having trouble understanding Lemma 1 and its proof:")#linebreak()#text(" Exercise 4, Exercise 5, or Theorem 9 from Notes 1 that you use do not have ")#mi("n")#text(" appearing on the right hand side, so it is not clear how you get the ")#mi("n")#text(" in ")#mi("exp(-cAn)")#text(".")#linebreak()#text(" And in the claim that ")#tao-math("\\left|X_i \\cdot x\\right| \\geq A", block: false)#text(" occurs with probability at most ")#mi("exp(-cAn)")#text(" seems inappropriate that there should be dependence on ")#mi("n")#text(". For instance, if the entries of the matrix are iid and taking ")#mi("x = 1/ \\sqrt{n} (1,1,\\ldots,1)")#text(", the probability of the event $|X_i \\cdot x| \\geq A$ converges to the probability that a Gaussian is greater than $A$, and that should remain bounded from below.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-43231")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2010")])]

#text("Oops, you’re right, this is not the correct argument. I’ve replaced it with one which should be more correct (and which only holds for A sufficiently large, as it should.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aab534a8f210b7cf9df4446d8db37ac4c66c9daafd983558d524c978586bd377-240112ddbb705ed9e4227fe8af6e34f039e5a6a1a89b991de7041335fc3c4c1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven Heilman")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-43363")[#strong[#text("Steven Heilman")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2010")])]

#text("Some minor typos?")

#text("1. Proof of Corollary 4: “…from Lemma 3, \\Sigma [h]as cardinality…”")

#text("2. Section 2: “Suppose now that M={…} [is] a matrix”")

#text("3. After Exercise 4: Application of Jensen’s, needs \\geq")

#text("4. Section 4, after (12): application of Markov’s inequality has extraneous E symbol?: “and thus by Markov’s inequality…”")

#text("{{\\bf E} \\hbox{tr}(M^4) \\leq O_\\epsilon(n^3)}")

#text("5. Beginning of Section 5: Now let [us?] consider…")

#text("6. Section 5, Example 1: If I’m not mistaken, the partition (a,b,c,d,b,c) is crossing. I think you meant (a,b,c,d,c,b), since this has the combinatorial label specified in the Proof of Lemma 9?")

#text("7. Is there any known connection between the expected operator norm of a random matrix and the projection constant of a finite dimensional Banach space? Maybe it is only vaguely related, but \\lambda(X)\\leq\\sqrt{dim X} holds, where \\lambda(X) is the projection constant of a Banach space X.")

#text("8. Near end of proof of Theorem 14: “each entry has a probability … probability[sic]”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e24ee2e882f070d7de3f5a47986fb4330de3646b652ae80ecf4450cd3ecef968-88dddfe7a6bac82c2281f2b10bf8859797e697c2757a48de75ef7163e2049212.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anand Rajagopalan")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-43429")[#strong[#text("Anand Rajagopalan")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2010")])]

#text("Hi Professor,")

#text("Great notes!")#linebreak()#text(" A couple of minor typos:")#linebreak()#text(" -The occurrence of (a,b,c,d,b,c) in the proof of lemma 9 should be (a,b,c,d,c,b).")#linebreak()#text(" -The first inequality in section 6 should be reversed I think.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 4: The semi-circular law « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-43460")[#strong[#text("254A, Notes 4: The semi-circular law « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2010")])]

#text("[…] results in random matrix theory, namely the Wigner semi-circle law for Wigner matrices. Recall from previous notes that a Wigner Hermitian matrix ensemble is a random matrix ensemble of Hermitian matrices (thus ; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 5: Free probability « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-43568")[#strong[#text("245A, Notes 5: Free probability « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2010")])]

#text("[…] a complex number). As before, we see that is a -linear functional that maps to . As we saw in Notes 3, the moment method for random matrices is based on a computation of the moments […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 7: The least singular value « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-43788")[#strong[#text("254A, Notes 7: The least singular value « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2010")])]

#text("[…] the “soft edge” of the spectrum, that was discussed back in Notes 3, so one may at first think that the methods that were effective in controlling the latter, namely […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The circular law « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-43887")[#strong[#text("254A, Notes 8: The circular law « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2010")])]

#text("[…] the origin. Indeed, for iid matrices with subgaussian entries, one can show (using the methods from Notes 3) that the operator norm of is almost surely; this, combined with (2) and Laurent expansion, tells […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-44056")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2010")])]

#text("Dear Prof. Tao,")

#text("I have some problems on how to estimate the median by the moments:")

#text("1. Ex 8: I don’t see how to obtain that the median of ")#tao-math("\\left|\\left|M\\right|\\right|_{op}", block: false)#text(" is at least ")#mi("(5^{1/6}+o(1)) \\sqrt{n}")#text(" from the bounds therein and the assumption ")#mi("K=O(1)")#text(".")

#text("2. Argument immediately above Prop 8: I understood the estimate of sixth moments and that by Markov inequality, but didn’t know how to get the median estimate.")

#text("My questions are most probably very trivial, it would be very appreciated if you could give some hints.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-44058")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2010")])]

#text("For exercise 8, use concentration of measure (Prop 7) to extract information about the median from the fourth moment.")

#text("For the second argument: if ")#tao-math("{\\bf P}( \\left\\|M\\right\\|_{op} > \\lambda ) < 1/2", block: false)#text(", then the median of ")#tao-math("\\left\\|M\\right\\|_{op}", block: false)#text(" is necessarily at most ")#mi("\\lambda")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-44067")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2010")])]

#text("Dear Prof. Tao,")

#text("Thanks a lot for your help!")

#text("I think I got it. I think the condition ")#mi("K=O(1)")#text(" is for applying Talagrand’s inequality.")

#text("As for the Talagrand’s inequality in note 1, I would like to give an immature suggestion (maybe it is wrong):")

#text("It seems that the ")#mi("1")#text("-Lipschitz condition is a little confusing. At the first glance, one might think that the Talagrand’s inequality holds only when Lipschitz constant of ")#mi("F")#text(" is 1. After checking the proof, I think we only need that Lipschitz constant is bounded. So I think it could be better to add some remark near the Talagrand’s Theorem (if I am right).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-44057")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2010")])]

#text("sorry, the problem 2 is ")#mi("k")#text("-th moment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e14070aaf61842c0399191a9bb95788359f444b55267237580b942af839d574f-5dbdb8aba3911f781f4bd724deb9f69ac307ad1183c7a744942ebc691dd981f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-45090")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2010")])]

#text("I have one question. Close to the end of this note, there is “From the finite second moment and dominated convergence, the right hand side is o_{\\epsilon}(1)”.")

#text("I used the markov inequality to see that actually that right hand side is bounded by a constant, rather than o_{\\epsilon}(1)”.")

#text("Could you expand on this argument? Thank you very much.")

#text("a typo: before “we inspect the proof of Theorem 14″, a right bracket is missing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-45092")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2010")])]

#text("From dominated convergence, ")#tao-math("{\\bf E}(\\lambda^2 {\\bf I}( \\left|\\xi\\right| \\geq \\lambda ) )", block: false)#text(" goes to zero as ")#mi("\\lambda \\to \\infty")#text(", if ")#tao-math("{\\bf E} \\left|\\xi\\right|^2", block: false)#text(" is finite.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6da0ce2b0589fe8a35b4fd1ed0383f44d268ff4b98575ec4e732457fc724f6f6-6cbd2318eaeeeabb0ae62eb31c999e148aa2e0bed374690aad4ff228578390cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guillaume")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-48114")[#strong[#text("Guillaume")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2010")])]

#text("Dear Prof. Tao,")

#text("Unless I missed something, there appears to be a misprint in Lemma 9 (and at several subsequent places), the product should be ")#mi("n(n-1)\\cdots (n-k/2)")#text(" instead of ")#mi("n(n-1)\\cdots (n-k/2-1)")#text(" …")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf26713002fa10900036d67b632bd78ae3e37e3f04e7a0cac861eda189f57120-24cf8a5491f62e6272938aca7a9ef8b77531bd47e636633948c65f4a095f25ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dai")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-48208")[#strong[#text("Dai")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2010")])]

#text("Dear Prof. Tao,")

#text("At the end of section 4, you said “How many different classes could there be? We have to assign up to ")#mi("k/2")#text(" labels to ")#mi("k")#text(" edges, so a crude upper bound here is ")#mi("k^{k/2}")#text(".”")

#text("Why this is true? I think by this argument the crude upper bound should be ")#mi("(k/2)^k")#text(". Maybe this problem is trivial for you. Thank you very much in advance.")

#emph[#text("[Oops, this was a typo (which unfortunately propagated throughout the section. Fixed now, – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cd3293b17fc4102811ce87a71f982a006bff024f4fadf65e5afe06087907fc0-4ba76bf4fed42f8a2ca5c337f3ef79cd4db842b060b6a124a522d20c80bf75fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mustafa Said")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-223669")[#strong[#text("Mustafa Said")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2013")])]

#text("Terry,")#linebreak()#text(" In the symmetrisation inequality (4), I think one can find an upper bound on the operator norm of the right hand side since when you introduce the random sign matrix E, it acts as an operator on M. There is a paper, “Restricted Schur Multipliers and their Applications,” by Timur Oikhberg that may help on this end.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Real stable polynomials and the Kadison-Singer problem | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-249984")[#strong[#text("Real stable polynomials and the Kadison-Singer problem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2013")])]

#text("[…] be, one might first try to compute the expected operator norm and then apply Proposition 1; see this previous blog post for examples of this strategy (and related strategies, based on comparing with more tractable […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e992c9d6bd69dd80732ca5390a35dcd2f41def765f7553ed62128e4fb9b21ecb-4768d42197c2c4f660569b64d7705d69c7ec4ef2e7e1cbee040f09e195407ee1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Relatings turings use of norm (statistics) to eigenvalues | Peter's ruminations")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-252971")[#strong[#text("Relatings turings use of norm (statistics) to eigenvalues | Peter's ruminations")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2013")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")[#text("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f164b02a3bd9948dc4c26dafea7b9121061d9f2fd04dfe4b9c8e9f2e57a9f741-c896be6ad5bd70ce3a96085cca15a5ba3a9b0f8b0da50b97022a3a027dcc92b6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yash Deshpande")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-402895")[#strong[#text("Yash Deshpande")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2014")])]

#text("A question regarding the estimate for ")#mi("N_{a_1, a_2 \\dots a_j}")#text(":")#linebreak()#text(" while recording the data for reconstructing the cycle ")#mi("i_1 \\dots i_k")#text(", it appears to me that one would need the end point of each non-innovative leg. This can be recorded using (for instance) the position of the innovative leg that first visited that vertex and incurs additional ")#mi("k^m")#text(" entropy cost. This does not change significantly the bound, in particular the estimate used ultimately is correct even with this modification.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af6636ba1d32fd7a62ee15d9775578fd27e63c93c1067d86fbb5d6fa67e7130a-fa17e49e447d3ca4725ee9a2803b93d7650bea3da0b2b90958ff4a46a452860e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marwin Mayer")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-434011")[#strong[#text("Marwin Mayer")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2014")])]

#text("Dear Prof. Tao,")

#text("I have a problem understanding a proof. (Here it is Proposition 11). You say “[…] we can combine this with Exercise 5 to conclude that the median (or mean) of {\\|M\\|_{op}} is at least {(C_{k/2}^{1/k}+o_k(1)) \\sqrt{n}}”. But how can you use exercise 5 to conclude that?")

#text("Sincerely yours,")

#text("Marwin Mayer")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-434015")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2014")])]

#text("If the median of ")#tao-math("\\left\\|M\\right\\|_{op}", block: false)#text(" was less than ")#mi("(C_{k/2}-\\varepsilon)^{1/k} \\sqrt{n}")#text(" for some fixed ")#mi("\\varepsilon > 0")#text(", then by using Exercise 5 one would have ")#tao-math("\\left\\|M\\right\\|_{op}", block: false)#text(" bounded by ")#mi("(C_{k/2}-\\varepsilon/2)^{1/k} \\sqrt{n}")#text(" with overwhelming probability. One could then obtain an upper bound on the k^th moment that was of the form ")#mi("(C_{k/2}-\\varepsilon/2+o(1)) n^{k/2}")#text(", contradicting the lower bound on this moment.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af6636ba1d32fd7a62ee15d9775578fd27e63c93c1067d86fbb5d6fa67e7130a-fa17e49e447d3ca4725ee9a2803b93d7650bea3da0b2b90958ff4a46a452860e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marwin Mayer")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-434188")[#strong[#text("Marwin Mayer")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2014")])]

#text("Thank you very much! Now I understand it.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/011e1f147f2e11d6db93ea960717623aea28753b7c0d7e54d69bc9d87581e44b-6d1209f377e032df9cd3a1992c3077d3ce9e5eb08d43d6f52691baa36226f33a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of elegantrium")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-452513")[#strong[#text("elegantrium")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2015")])]

#text("Hi Dear Prof. Tao,")#linebreak()#text(" Is there any sharp result on the concentration inequality for schatten norm of a random matrix, where the Schatten norm is defined as in ")#link("http://en.wikipedia.org/wiki/Schatten_norm")[#text("http://en.wikipedia.org/wiki/Schatten_norm")]#text("?")

#text("Sincerely yours,")#linebreak()#text(" Jason")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-452515")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2015")])]

#text("I would have a look at the article of Meckes ")#link("http://www.ams.org/mathscinet-getitem?mr=2057479")[#text("http://www.ams.org/mathscinet-getitem?mr=2057479")]#text(" (which considers general convex norms of random matrices).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 3: The weak and strong law of large numbers | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-460851")[#strong[#text("275A, Notes 3: The weak and strong law of large numbers | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2015")])]

#text("[…] can obtain much sharper information on quantities such as the operator norm of a random matrix; see this previous blog post for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0d8061d5813ee28dc473b4bedb157c5ba0a5bb310d48d6f06939a3ab3a39525-23d7cbd318301f087aac6070c2ea3b8069b870a3af6d8d4bf06135900b54fe03.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Canyi")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-462006")[#strong[#text("Canyi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2015")])]

#text("Dear Prof. Tao,")

#text("It is known that for a matrix ")#mi("A\\in\\mathbb{R}^{n\\times n}")#text(" which is i.i.d., its spectral norm ")#tao-math("\\left|\\left|A\\right|\\right|\\leq C\\sqrt{n}", block: false)#text(".")

#text("Now, I have a related and interesting about the spectral norm of the block circulant matrix defined as")

#mi("\\displaystyle A= \\begin{bmatrix} A_{1} &A_{m} &\\cdots &A_{2} \\\\ A_{2} &A_{1} & \\cdots &A_{3} \\\\ \\vdots & \\vdots & \\ddots & \\vdots \\\\ A_{m} & A_{m-1} & \\cdots & A_{1} \\end{bmatrix} \\in\\mathbb{R}^{nm\\times nm}.")

#text("where each ")#mi("A_i\\in\\mathbb{R}^{n\\times n}")#text(" is an i.i.d. matrix, and its elements have the distribution")

#mi("[A_i]_{a,b} =  \\begin{cases} 1, & \\text{w.p. } \\rho/2, \\\\ 0, & \\text{w.p. } 1-\\rho,\\\\ -1, & \\text{w.p. } \\rho/2. \\end{cases}")

#text("for some ")#mi("0<\\rho<1")#text(".")

#text("Can we prove that ")#tao-math("\\left\\|A\\right\\| \\leq C\\sqrt{nm}", block: false)#text(" for some constant ")#mi("C")#text(" with large probability?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-462023")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2015")])]

#text("I expect that this should be provable by several of the methods in this post (e.g. I believe the moment method will eventually work, although the combinatorics are messy). There may be a more elegant approach using more advanced matrix inequalities (e.g. noncommutative Khinchin) or free probability methods, but I don’t immediately see such an argument.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f39c2fbaf76a91ad69eb799476370d9410de21b432ac27f64099dac530297bf-5a8669e921690d18a1ace7473d472ba74a01e88ef6850d69dfeabae89521779e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vj")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-466012")[#strong[#text("vj")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2016")])]

#text("Hi Prof. Tao,")

#text("The covering method gives a guarantee with probability 1-exp(-Omega(n)).")#linebreak()#text(" Can’t one get a similar probability bound in the trace power method by using")#linebreak()#text(" polynomial concentration results?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-466029")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2016")])]

#text("In principle yes, but one would have to apply concentration of measure results to polynomials of degree about ")#mi("O(\\log n)")#text(", so one has to be careful regarding how the constants depend on degree. (But if one was content with an upper bound of the form ")#mi("O_{\\varepsilon}(n^{1/2+\\varepsilon})")#text(" rather than ")#mi("O(n^{1/2})")#text(" then one could work with polynomials of degree ")#mi("O(1)")#text(", in which case standard concentration of measure results would work without difficulty.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cbe1a79d45e98c38d3514b9ab7e5fff6eda87c5e45022be8f2fff617e207e01-5a5e249a5b631e2c37515a5357e588c106d85dd66b55eb050dc0b5eb7a5b28c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-470249")[#strong[#text("M")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2016")])]

#text("Dear Prof. Tao;")#linebreak()#text(" Would you please give me a hint on Exercise 1?")#linebreak()#text(" Thanks.")

#emph[#text("[Adapt the volume packing arguments used to prove Lemma 3. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cbe1a79d45e98c38d3514b9ab7e5fff6eda87c5e45022be8f2fff617e207e01-5a5e249a5b631e2c37515a5357e588c106d85dd66b55eb050dc0b5eb7a5b28c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-470261")[#strong[#text("M")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2016")])]

#text("OK, Thank you!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e963dd240687ba0a12cece810619031597e9c944f4a19257c1852cd04600e0de-4d3ef9896e5e3782974cc5be4fac2fd19a24736074cfd4bbf10ee32236478638.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-474521")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2016")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I have a question. For a matrix ")#mi("A\\in R^{n\\times n}")#text(" whose entries obey")

#mi("A_{ij} = \\begin{cases} 1, & \\text{w.p.} \\ 1/2, \\\\ -1, & \\text{w.p.} \\ 1/2, \\end{cases}")

#text("we have ")#tao-math("\\left\\|A\\right\\|_{op}\\leq c\\sqrt{n}", block: false)#text(".")

#text("Now my question is that for a matrix ")#mi("A\\in R^{n\\times n}")#text(" whose entries obey")

#mi("A_{ij} = \\begin{cases} 1, & \\text{w.p.} \\ \\rho/2, \\\\ 0, & \\text{w.p.} \\ 1-\\rho, \\\\ -1, & \\text{w.p.} \\ \\rho/2, \\end{cases}")

#text("how could we prove ")#tao-math("\\left\\|A\\right\\|_{op}\\leq c\\sqrt{\\rho n}", block: false)#text(" (this conclusion is right, but I do not know how to prove it)? Thanks a lot!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-476392")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2017")])]

#text("Minor typo in Lemma 3: the sphere in the lemma should be n-dimensional, should it not?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keej")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-478958")[#strong[#text("keej")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2017")])]

#text("I’m probably missing something simple, but I do not see why Exercise 7 requires ")#mi("K = o(\\sqrt{n})")#text(". Each term (12) ends up being nonnegative, so to lower bound the sum it suffices to consider only the terms in the “first case,” of which there are 2n(n-1)(n-2) and each has value 1. By (9) it suffices to divide this by n and take the fourth root, which yields ")#mi("2^{1/4} (1 + o(1)) \\sqrt{n}")#text(" as desired.")

#text("Could someone who did this please help me out?")

#emph[#text("[Fair enough; but this positivity is a special feature of the fourth moment and would not be available for the analogous assertions for higher moments. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keej")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-479423")[#strong[#text("keej")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2017")])]

#text("I see, thanks for the clarification!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ba29a862b0b4ae4e7846c5df2a5a0301b43d49d7ccaffeea104fd9665bb7eaa-ebafc85aa20d7f671bbb3d7dbe9d796428a370fc86c598b3a243cd370c26f51d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AL Ray")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-490743")[#strong[#text("AL Ray")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2017")])]

#text("Regarding Remark 1, I think that ")#mi("\\lambda/(1-\\epsilon)")#text(" should actually be ")#mi("\\lambda (1-\\epsilon)")#text(". I assume that the definition of 1/2-net coincides with \\epsilon – net, in which case when plugging \\epsilon = 1/2 we should be getting a factor of half and not 2.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2aaa243f177a4fe4db888b7c63e9addfc103b24e7d3534f0283bb182b0bd5822-2bd10728a1bc19b64e161e4731b2dd91b2684dcc03a8caaacd1c55e180eeae41.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-491190")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2018")])]

#text("A typo: In proposition 7, ")#tao-math("M\\left\\|M\\right\\|_{op}", block: false)#text(" should be ")#tao-math("\\mathbf{M}\\left\\|M\\right\\|_{op}", block: false)#text(". ")#emph[#text("[Corrected, thanks – T.]")]#linebreak()#text(" A question: I really do not know how to prove that ")#mi("C_{k/2} n(n-1)\\cdots (n-k/2)=(C_{k/2}+o(1))n^{k/2+1}")#text(". Any hints?")#linebreak()#text(" Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2aaa243f177a4fe4db888b7c63e9addfc103b24e7d3534f0283bb182b0bd5822-2bd10728a1bc19b64e161e4731b2dd91b2684dcc03a8caaacd1c55e180eeae41.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-491191")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2018")])]

#text("PS: The difficulty is that ")#mi("k")#text(" could be large if ")#mi("n")#text(" is large.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2aaa243f177a4fe4db888b7c63e9addfc103b24e7d3534f0283bb182b0bd5822-2bd10728a1bc19b64e161e4731b2dd91b2684dcc03a8caaacd1c55e180eeae41.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-491192")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2018")])]

#text("PSS: I can only show that ")#mi("C_{k/2}n(n-1))\\cdots (n-k/2)=C_{k/2}(1+o(1))n^{k/2+1}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-491194")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2018")])]

#text("The decay rate in ")#mi("o_k(1)")#text(" is allowed to depend on ")#mi("k")#text(" (see the beginning of section 5).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2aaa243f177a4fe4db888b7c63e9addfc103b24e7d3534f0283bb182b0bd5822-2bd10728a1bc19b64e161e4731b2dd91b2684dcc03a8caaacd1c55e180eeae41.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-491202")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2018")])]

#text("I am sorry, but I am concerned with the beginning of the proof of Theorem 12. There it is ")#mi("o(1)")#text(" but not $o_k(1)$. I don’t know how the independence on ")#mi("k")#text(" disappears, since ")#mi("k=O(\\log^2 n)")#text(" could be very large when ")#mi("n")#text(" is large. Could you please have a check? Thanks!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-491405")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2018")])]

#text("Dear Terry,")

#text("In this post, you used the argument multiple times that")#linebreak()#text(" ")#tao-math("n^2 {\\bf P}(\\left|\\xi\\right| \\geq \\frac{\\epsilon}{3} \\sqrt{n})", block: false)#linebreak()#text(" goes to 0 when ")#mi("n\\rightarrow \\infty")#text(" due to the existence of ")#mi("{\\bf E}\\xi^4")#text(" . But Markov inequality will only give us ")#mi("n^{-2}")#text(" which is canceled by ")#mi("n^2")#text(" ahead. Do we need ")#mi("4+\\epsilon")#text("-th moment here? Or do I miss something?")

#text("Best,")#linebreak()#text(" Jeffrey")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-491422")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2018")])]

#text("Apply dominated convergence to the random variables ")#tao-math("n^2 1_{\\left|\\xi\\right| \\geq \\frac{\\epsilon}{3} \\sqrt{n}}", block: false)#text(", which are pointwise dominated by ")#tao-math("(\\frac{3}{\\epsilon})^4 \\left|\\xi\\right|^4", block: false)#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/039c22851bbeda3d7a2d7c6840e9cbc5c58e76f6d4633ea66f90db1675384e32-f386244423de87ee4f4a69d6163c8196db8b2dbcdfdad5261387af1542e2322a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Drew Brady")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-505598")[#strong[#text("Drew Brady")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2018")])]

#text("Is Prop 7 correct? I.e., Your argument shows that ")#tao-math("\\left\\|A - B\\right\\|_{op} \\leq \\left\\|(a_{ij}) - (b_{ij})\\right\\|", block: false)#text(", where the norm on the right hand side is the Euclidean norm on ")#mi("\\mathbf{C}^{2n}")#text(". Don’t you need, however that ")#tao-math("\\left|\\left\\|A\\right\\|_{op} - \\left\\|B\\right\\|_{op}\\right| \\leq \\left\\|A - B\\right\\|_{op}", block: false)#text(", in order for this argument to work out?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-505616")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2018")])]

#text("Yes, but this is immediate from the triangle inequality for the operator norm.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0102fa758f30f6ee2759f534a173bea1a7bfbb35baca2df439358104b016e9d6-48a646b778874a4110249647e34f39466c49d254477ca48642f83cac90347667.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-616309")[#strong[#text("Tim")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2021")])]

#text("I have a question about Exercise 10. It seems that the cycle 1, 2, 1, 3, 1, 4, 1 (4 vertices, 6 edges) is a valid cycle to be counted, but it does not satisfy the condition in Exercise 10?")

#emph[#text("[Oops, there was an extra condition for the edges, now added. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-617920")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2021")])]

#text("This is just a thought on the volume packing argument (Lemma 4). Each of the balls of radius ")#mi("\\epsilon/2")#text(" centered points of the net accounts for some volume, but this volume in enclosed inside the larger ball of radius ")#mi("3/2")#text(". So is the upper bound on the cardinality just the ratio of the volume of the larger ball over the volume of a ball of radius ")#mi("\\epsilon/2")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-686058")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2024")])]

#text("Exactly")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-623573")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2021")])]

#text("Dear Professor Tao,")

#text("Do you know of some recent papers where finer volume packing arguments are used for things such as the operator norm, condition number etc. I was curious to learn more about these arguments.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-639261")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2022")])]

#text("Numerous occurrences in analysis, enumerative geometry, combinatorics, probability, and physics of the sequence of double factorials of odd numbers in Remark 31 are noted in ")#link("https://oeis.org/A001147")[#text("https://oeis.org/A001147")]#text(" and refs therein, as well as associations to other number sequences, such as the Catalans. For the benefit of others, it would be nice to ref this post in the OEIS entry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a8b0718d5bdceefedd2ec82eac8adb1012818790a19ce092ee31486b2f3c2ee3-5219d0f51398c36e45ebbad3d9b14e855d4d1db4b2c3a66cd3417ac08cfcda9d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aurelien")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-645103")[#strong[#text("Aurelien")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2022")])]

#text("Very minor comment: In Lemma 1 in the RHS, shouldn’t A be squared? (as a result of applying Markov’s inequality)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-684574")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2024")])]

#text("Dear Professor Tao,")

#text("I am very confused about the bound before weak Bai-Yin theorem, you said that")

#text("by the geometric series formula (and the hypothesis ")#mi("{k = O(\\log^2 n)}")#text("), we can get the following bound, here I have two questions. The first is that the geometric series doesn’t converge here and the bound I get is of the form O(2^kk^O(1)n^0.99k) and I can’t get rid of the 0.49k. The second is I’m not sure how to use the log bound for k. I would appreciate it very much if you could bother to answer it. Thanks a lot!")

#link("https://s0.wp.com/latex.php?latex=%5Cdisplaystyle+O%28+2%5Ek+k%5E%7BO%281%29%7D+n%5E%7Bk%2F2+%2B+0.98%7D+%29&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%5Cdisplaystyle+O%28+2%5Ek+k%5E%7BO%281%29%7D+n%5E%7Bk%2F2+%2B+0.98%7D+%29&bg=ffffff&fg=000000&s=0&c=20201002")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-684627")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2024")])]

#text("I’m not sure if I’m following the use of Markov’s inequality in lemma 2.3.1. We have that ")#tao-math("E[e^{c\\left|Mx\\right|^{2}}] \\leq C^{n}", block: false)#text(". My understanding of the application of Markov’s inequality is as follows:")

#tao-math("P[ \\left|Mx\\right| \\geq A\\sqrt{n} ] = P[ e^{c\\left|Mx\\right|^{2}} \\geq e^{c(A\\sqrt{n})^{2}} \\leq C^{n} e^{-c(A\\sqrt{n})^{2}}", block: false)

#text("I must be doing something wrong?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-684630")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2024")])]

#text("Nevermind, I think the constants are different in the proof and in the statement.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-684631")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2024")])]

#text("Dear Professor Tao,")

#text("I’m very confused about the bound before the weak Bai-Yin theorem. You said that by the geometric series formula and ")#mi("k=O(log^2n)")#text(", we can get the bound ")#mi("O(2^kk^{O(1)}n^{k/2+0.98})")#text(". My question is that the geometric series doesn’t converge here and the bound I get is of the form ")#mi("O(2^kk^{O(1)}n^{0.99k})")#text(". I would appreciate it very much if you could bother to answer it. Thanks a lot!")

#emph[#text("[The dominant term here is when ")#mi("j = k/2-1")#text(", which gives the ")#mi("O(2^kk^{O(1)}n^{k/2+0.98})")#text(" bound; the other terms decay at an exponential rate away from this value. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-686029")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2024")])]

#text("In the sphere packing argument shouldn’t it be ")#mi("\\varepsilon^2")#text(" since we are considering balls in ")#mi("\\mathbb{C}^n")#text(" which one can view as ")#mi("\\mathbb{R}^{2n}")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-686062")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2024")])]

#text("In Lemma 1 where are we using that ")#mi("A")#text(" is large?")

#text("I also can’t see where are we using it in corollary 8 (")#mi("A \\geq C")#text(") but I guess it follows from that lemma.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-686120")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2024")])]

#text("The concentration of measure results would not give the required exponential decay if ")#mi("A")#text(" were too small (in particular, if ")#mi("A < 1")#text(" then the threshold is now below the location where concentration occurs, and the result is highly false).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-686379")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2024")])]

#text("Isn’t equation (2) actually an equality? I know it doesn’t matter too much though.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-686393")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2024")])]

#text("In lemma 1, in the next line after we bound the tails of ")#tao-math("\\left|X_i \\cdot x\\right|", block: false)#text(" using concentration of measure results, how do we conclude that that expectation is bounded by a constant? I’m really stuck in that. Thanks :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-686417")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2024")])]

#text("This follows from the ")#link("https://en.wikipedia.org/wiki/Layer_cake_representation")[#text("layer cake representation")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ede116570f87130639d3d4f56894f18e9569065987a6a2e344ed45d9a7ca0631-e2be5956d4ff3e92c7e5f84a4aed1c56a75271313d163d9019fca7a12f27adde.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pablo de la Fuente")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-686493")[#strong[#text("Pablo de la Fuente")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2024")])]

#text("Hi Professor Tao!")

#text("In the last step of Lemma 1, how do we get rid of the dependence on n of the constant C? Or is that irrelevant?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-686494")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2024")])]

#text("The exponential gain ")#mi("\\exp(-c A^2 n)")#text(" can be used to absorb the loss ")#mi("C^n")#text(" by taking ")#mi("A")#text(" large enough. (Indeed one could even then dispense with the initial ")#mi("C")#text(" out the front, though I prefer to retain it for notational consistency with other estimates.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a088354025cc37e93d0b43209b397631d62a2bb6a7c9e87367ed63af9e9c085c-985753fee8cae15c1f8c8ae5f08e6372eb2a160fdcdd71d96f3d6f94d7b986a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pablo de la Fuente")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-686495")[#strong[#text("Pablo de la Fuente")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2024")])]

#text("Thanks for you response it is way more clear now :)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a088354025cc37e93d0b43209b397631d62a2bb6a7c9e87367ed63af9e9c085c-985753fee8cae15c1f8c8ae5f08e6372eb2a160fdcdd71d96f3d6f94d7b986a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pablo de la Fuente")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-687094")[#strong[#text("Pablo de la Fuente")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2025")])]

#text("In corollary 6 isn’t it ")#mi("A^2")#text(" instead of just $A$?")

#emph[#text("[Bound strengthened, though in practice the slightly weaker bound given here is already sufficient for all applications. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a088354025cc37e93d0b43209b397631d62a2bb6a7c9e87367ed63af9e9c085c-985753fee8cae15c1f8c8ae5f08e6372eb2a160fdcdd71d96f3d6f94d7b986a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pablo de la Fuente")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-687095")[#strong[#text("Pablo de la Fuente")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2025")])]

#text("Also, what’s the underlying reason for ")#mi("n")#text(" appearing in the bound for the tails of the operator norm in contrast with say the concentration of measure results of sums of random variables?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-687111")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2025")])]

#text("Ultimately this is a manifestation of eigenvalue (or singular value) rigidity: the operator norm of a matrix is also its largest singular value, and this singular value concentrates at a significantly smaller scale than its size, leading to improved tail bounds. For instance, the ")#link("https://en.wikipedia.org/wiki/Tracy%E2%80%93Widom_distribution")[#text("Tracy-Widom law")]#text(" implies that the largest singular value of this matrix fluctuates at a scale of about ")#mi("O(n^{-1/6})")#text(" rather than ")#mi("O(n^{1/2})")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a088354025cc37e93d0b43209b397631d62a2bb6a7c9e87367ed63af9e9c085c-985753fee8cae15c1f8c8ae5f08e6372eb2a160fdcdd71d96f3d6f94d7b986a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pablo de la Fuente")]], [#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/#comment-688831")[#strong[#text("Pablo de la Fuente")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2025")])]

#text("Hi Professor Tao!")

#text("I wrote my undergraduate thesis on this topic and I wanted to thank you for always responding to my comments and questions. I got my diploma yesterday.")

#text("It was fascinating for me to learn about the operator norm of random matrices (and later on the semicircle law) with your notes.")

#text("Best,")

#text("Pablo from Mexico City")
]
