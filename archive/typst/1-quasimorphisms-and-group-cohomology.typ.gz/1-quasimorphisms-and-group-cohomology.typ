// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/07/07/1-quasimorphisms-and-group-cohomology/
// Converted to Typst by tao2typ: "2026-10-14T16:38:22.963434+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "1% quasimorphisms and group cohomology", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("1% quasimorphisms and group cohomology")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 July 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/07/07/1-quasimorphisms-and-group-cohomology/")[#text("https://terrytao.wordpress.com/2018/07/07/1-quasimorphisms-and-group-cohomology/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{G = (G,+)}")#text(", ")#mi("{H = (H,+)}")#text(" be additive groups (i.e., groups with an abelian addition group law). A map ")#mi("{f: G \\rightarrow H}")#text(" is a homomorphism if one has")

#align(center)[#tao-fit-display[#mitex("f(x+y) - f(x) - f(y) = 0")]]

#text("for all ")#mi("{x,y \\in G}")#text(". A map ")#mi("{f: G \\rightarrow H}")#text(" is an ")#emph[#text("affine")]#text(" homomorphism if one has ")#metadata(none) <tao-543b4bb6a59be2120f33>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("f(x_1) - f(x_2) + f(x_3) - f(x_4) = 0")]]

#text("for all ")#emph[#text("additive quadruples")]#text(" ")#mi("{(x_1,x_2,x_3,x_4)}")#text(" in ")#mi("{G}")#text(", by which we mean that ")#mi("{x_1,x_2,x_3,x_4 \\in G}")#text(" and ")#mi("{x_1-x_2+x_3-x_4=0}")#text(". The two notions are closely related; it is easy to verify that ")#mi("{f}")#text(" is an affine homomorphism if and only if ")#mi("{f}")#text(" is the sum of a homomorphism and a constant.")

#text("Now suppose that ")#mi("{H}")#text(" also has a translation-invariant metric ")#mi("{d}")#text(". A map ")#mi("{f: G \\rightarrow H}")#text(" is said to be a ")#link("https://groupprops.subwiki.org/wiki/Quasimorphism")[#text("quasimorphism")]#text(" if one has ")#metadata(none) <tao-8bda670c0fd677f51186>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("f(x+y) - f(x) - f(y) = O(1)")]]

#text("for all ")#mi("{x,y \\in G}")#text(", where ")#mi("{O(1)}")#text(" denotes a quantity at a bounded distance from the origin. Similarly, ")#mi("{f: G \\rightarrow H}")#text(" is an ")#emph[#text("affine quasimorphism")]#text(" if ")#metadata(none) <tao-4fc82b26aecb47d2868c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("f(x_1) - f(x_2) + f(x_3) - f(x_4) = O(1)")]]

#text("for all additive quadruples ")#mi("{(x_1,x_2,x_3,x_4)}")#text(" in ")#mi("{G}")#text(". Again, one can check that ")#mi("{f}")#text(" is an affine quasimorphism if and only if it is the sum of a quasimorphism and a constant (with the implied constant of the quasimorphism controlled by the implied constant of the affine quasimorphism). (Since every constant is itself a quasimorphism, it is in fact the case that affine quasimorphisms are quasimorphisms, but now the implied constant in the latter is not controlled by the implied constant of the former.)")

#text("“Trivial” examples of quasimorphisms include the sum of a homomorphism and a bounded function. Are there others? In some cases, the answer is no. For instance, suppose we have a quasimorphism ")#mi("{f: {\\bf Z} \\rightarrow {\\bf R}}")#text(". Iterating ")#link(<tao-8bda670c0fd677f51186>)[#text("(2)")]#text(", we see that ")#mi("{f(kx) = kf(x) + O(k)}")#text(" for any integer ")#mi("{x}")#text(" and natural number ")#mi("{k}")#text(", which we can rewrite as ")#tao-math("{f(kx)/kx = f(x)/x + O(1/\\left|x\\right|)}", block: false)#text(" for non-zero ")#mi("{x}")#text(". Also, ")#mi("{f}")#text(" is Lipschitz. Sending ")#mi("{k \\rightarrow \\infty}")#text(", we can verify that ")#mi("{f(x)/x}")#text(" is a Cauchy sequence as ")#mi("{x \\rightarrow \\infty}")#text(" and thus tends to some limit ")#mi("{\\alpha}")#text("; we have ")#mi("{\\alpha = f(x)/x + O(1/x)}")#text(" for ")#mi("{x \\geq 1}")#text(", hence ")#mi("{f(x) = \\alpha x + O(1)}")#text(" for positive ")#mi("{x}")#text(", and then one can use ")#link(<tao-8bda670c0fd677f51186>)[#text("(2)")]#text(" one last time to obtain ")#mi("{f(x) = \\alpha x + O(1)}")#text(" for all ")#mi("{x}")#text(". Thus ")#mi("{f}")#text(" is the sum of the homomorphism ")#mi("{x \\mapsto \\alpha x}")#text(" and a bounded sequence.")

#text("In general, one can phrase this problem in the language of ")#link("https://en.wikipedia.org/wiki/Group_cohomology")[#text("group cohomology")]#text(" (discussed in ")#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/")[#text("this previous post")]#text("). Call a map ")#mi("{f: G \\rightarrow H}")#text(" a ")#emph[#mi("{0}")#text("-cocycle")]#text(". A ")#emph[#mi("{1}")#text("-cocycle")]#text(" is a map ")#mi("{\\rho: G \\times G \\rightarrow H}")#text(" obeying the identity")

#align(center)[#tao-fit-display[#mitex("\\rho(x,y+z) + \\rho(y,z) = \\rho(x,y) + \\rho(x+y,z)")]]

#text("for all ")#mi("{x,y,z \\in G}")#text(". Given a ")#mi("{0}")#text("-cocycle ")#mi("{f: G \\rightarrow H}")#text(", one can form its ")#emph[#text("derivative")]#text(" ")#mi("{\\partial f: G \\times G \\rightarrow H}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\partial f(x,y) := f(x+y)-f(x)-f(y).")]]

#text("Such functions are called ")#emph[#mi("{1}")#text("-coboundaries")]#text(". It is easy to see that the abelian group of ")#mi("{1}")#text("-coboundaries is a subgroup of the abelian group of ")#mi("{1}")#text("-cocycles. The quotient of these two groups is the first group cohomology of ")#mi("{G}")#text(" with coefficients in ")#mi("{H}")#text(", and is denoted ")#mi("{H^1(G; H)}")#text(".")

#text("If a ")#mi("{0}")#text("-cocycle is bounded then its derivative is a bounded ")#mi("{1}")#text("-coboundary. The quotient of the group of bounded ")#mi("{1}")#text("-cocycles by the derivatives of bounded ")#mi("{0}")#text("-cocycles is called the ")#emph[#text("bounded first group cohomology")]#text(" of ")#mi("{G}")#text(" with coefficients in ")#mi("{H}")#text(", and is denoted ")#mi("{H^1_b(G; H)}")#text(". There is an obvious homomorphism ")#mi("{\\phi}")#text(" from ")#mi("{H^1_b(G; H)}")#text(" to ")#mi("{H^1(G; H)}")#text(", formed by taking a coset of the space of derivatives of bounded ")#mi("{0}")#text("-cocycles, and enlarging it to a coset of the space of ")#mi("{1}")#text("-coboundaries. By chasing all the definitions, we see that all quasimorphism from ")#mi("{G}")#text(" to ")#mi("{H}")#text(" are the sum of a homomorphism and a bounded function if and only if this homomorphism ")#mi("{\\phi}")#text(" is injective; in fact the quotient of the space of quasimorphisms by the sum of homomorphisms and bounded functions is isomorphic to the kernel of ")#mi("{\\phi}")#text(".")

#text("In additive combinatorics, one is often working with functions which only have additive structure a fraction of the time, thus for instance ")#link(<tao-543b4bb6a59be2120f33>)[#text("(1)")]#text(" or ")#link(<tao-4fc82b26aecb47d2868c>)[#text("(3)")]#text(" might only hold “")#mi("{1\\%}")#text(" of the time”. This makes it somewhat difficult to directly interpret the situation in terms of group cohomology. However, thanks to tools such as the Balog-Szemerédi-Gowers lemma, one can upgrade this sort of ")#mi("{1\\%}")#text("-structure to ")#mi("{100\\%}")#text("-structure – at the cost of restricting the domain to a smaller set. Here I record one such instance of this phenomenon, thus giving a tentative link between additive combinatorics and group cohomology. (I thank Yuval Wigderson for suggesting the problem of locating such a link.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" Let ")#mi("{G = (G,+)}")#text(", ")#mi("{H = (H,+)}")#text(" be additive groups with ")#tao-math("{\\left|G\\right|=N}", block: false)#text(", let ")#mi("{S}")#text(" be a subset of ")#mi("{H}")#text(", let ")#mi("{E \\subset G}")#text(", and let ")#mi("{f: E \\rightarrow H}")#text(" be a function such that")

#align(center)[#tao-fit-display[#mitex("f(x_1) - f(x_2) + f(x_3) - f(x_4) \\in S")]]

#text("for ")#mi("{\\geq K^{-1} N^3}")#text(" additive quadruples ")#mi("{(x_1,x_2,x_3,x_4)}")#text(" in ")#mi("{E}")#text(". Then there exists a subset ")#mi("{A}")#text(" of ")#mi("{G}")#text(" containing ")#mi("{0}")#text(" with ")#tao-math("{\\left|A\\right| \\gg K^{-O(1)} N}", block: false)#text(", a subset ")#mi("{X}")#text(" of ")#mi("{H}")#text(" with ")#tao-math("{\\left|X\\right| \\ll K^{O(1)}}", block: false)#text(", and a function ")#mi("{g: 4A-4A \\rightarrow H}")#text(" such that ")#metadata(none) <tao-35bbce4007c5cd57a4c6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("g(x+y) - g(x)-g(y) \\in X + 496S - 496S")]]

#text("for all ")#mi("{x, y \\in 2A-2A}")#text(" (thus, the derivative ")#mi("{\\partial g}")#text(" takes values in ")#mi("{X + 496 S - 496 S}")#text(" on ")#mi("{2A - 2A}")#text("), and such that for each ")#mi("{h \\in A}")#text(", one has ")#metadata(none) <tao-fd95c625a3dcbf66c8cb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("f(x+h) - f(x) - g(h) \\in 8S - 8S")]]

#text("for ")#mi("{\\gg K^{-O(1)} N}")#text(" values of ")#mi("{x \\in E}")#text(".")
]

#text("Presumably the constants ")#mi("{8}")#text(" and ")#mi("{496}")#text(" can be improved further, but we have not attempted to optimise these constants. We chose ")#mi("{2A-2A}")#text(" as the domain on which one has a bounded derivative, as one can use the Bogulybov lemma (see e.g, Proposition 4.39 of ")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("my book with Van Vu")]#text(") to find a large Bohr set inside ")#mi("{2A-2A}")#text(". In applications, the set ")#mi("{S}")#text(" need not have bounded size, or even bounded doubling; for instance, in the inverse ")#mi("{U^4}")#text(" theory over a small finite fields ")#mi("{F}")#text(", one would be interested in the situation where ")#mi("{H}")#text(" is the group of ")#mi("{n \\times n}")#text(" matrices with coefficients in ")#mi("{F}")#text(" (for some large ")#mi("{n}")#text(", and ")#mi("{S}")#text(" being the subset consisting of those matrices of rank bounded by some bound ")#mi("{C = O(1)}")#text(".")

#emph[#text("Proof:")]#text(" By hypothesis, there are ")#mi("{\\geq K N^3}")#text(" triples ")#mi("{(h,x,y) \\in G^3}")#text(" such that ")#mi("{x,x+h,y,y+h \\in E}")#text(" and ")#metadata(none) <tao-8b2a41705b9a6f588286>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("f(x+h) - f(x) \\in f(y+h)-f(y) + S.")]]

#text("Thus, there is a set ")#mi("{B \\subset G}")#text(" with ")#tao-math("{\\left|B\\right| \\gg K^{-1} N}", block: false)#text(" such that for all ")#mi("{h \\in B}")#text(", one has ")#link(<tao-8b2a41705b9a6f588286>)[#text("(6)")]#text(" for ")#mi("{\\gg K^{-1} N^2}")#text(" pairs ")#mi("{(x,y) \\in G^2}")#text(" with ")#mi("{x,x+h,y,y+h \\in E}")#text("; in particular, there exists ")#mi("{y = y(h) \\in E \\cap (E-h)}")#text(" such that ")#link(<tao-8b2a41705b9a6f588286>)[#text("(6)")]#text(" holds for ")#mi("{\\gg K^{-1} N}")#text(" values of ")#mi("{x \\in E \\cap (E-h)}")#text(". Setting ")#mi("{g_0(h) := f(y(h)+h) - f(y(h))}")#text(", we conclude that for each ")#mi("{h \\in B}")#text(", one has ")#metadata(none) <tao-192e7dca3b4522e2ebc5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("f(x+h) - f(x) \\in g_0(h) + S")]]

#text("for ")#mi("{\\gg K^{-1} N}")#text(" values of ")#mi("{x \\in E \\cap (E-h)}")#text(".")

#text("Consider the bipartite graph whose vertex sets are two copies of ")#mi("{E}")#text(", and ")#mi("{x}")#text(" and ")#mi("{x+h}")#text(" connected by a (directed) edge if ")#mi("{h \\in B}")#text(" and ")#link(<tao-192e7dca3b4522e2ebc5>)[#text("(7)")]#text(" holds. Then this graph has ")#mi("{\\gg K^{-2} N^2}")#text(" edges. Applying (a slight modification of) the Balog-Szemerédi-Gowers theorem (for instance by modifying the proof of Corollary 5.19 of ")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("my book with Van Vu")]#text("), we can then find a subset ")#mi("{C}")#text(" of ")#mi("{E}")#text(" with ")#tao-math("{\\left|C\\right| \\gg K^{-O(1)} N}", block: false)#text(" with the property that for any ")#mi("{x_1,x_3 \\in C}")#text(", there exist ")#mi("{\\gg K^{-O(1)} N^3}")#text(" triples ")#mi("{(x_2,y_1,y_2) \\in E^3}")#text(" such that the edges ")#mi("{(x_1,y_1), (x_2,y_1), (x_2,y_2), (x_3,y_2)}")#text(" all lie in this bipartite graph. This implies that, for all ")#mi("{x_1,x_3 \\in C}")#text(", there exist ")#mi("{\\gg K^{-O(1)} N^7}")#text(" septuples ")#mi("{(x_2,y_1,y_2,z_{11},z_{21},z_{22},z_{32}) \\in G^7}")#text(" obeying the constraints")

#align(center)[#tao-fit-display[#mitex("f(y_j) - f(x_i), f(y_j+z_{ij}) - f(x_i+z_{ij}) \\in g_0(y_j-x_i) + S")]]

#text("and ")#mi("{y_j, x_i, y_j+z_{ij}, x_i+z_{ij} \\in E}")#text(" for ")#mi("{ij = 11, 21, 22, 32}")#text(". These constraints imply in particular that")

#align(center)[#tao-fit-display[#mitex("f(x_3) - f(x_1) \\in f(x_3+z_{32}) - f(y_2+z_{32}) + f(y_2+z_{22}) - f(x_2+z_{22}) + f(x_2+z_{21}) - f(y_1+z_{21}) + f(y_1+z_{11}) - f(x_1+z_{11}) + 4S - 4S.")]]

#text("Also observe that")

#align(center)[#tao-fit-display[#mitex("x_3 - x_1 = (x_3+z_{32}) - (y_2+z_{32}) + (y_2+z_{22}) - (x_2+z_{22}) + (x_2+z_{21}) - (y_1+z_{21}) + (y_1+z_{11}) - (x_1+z_{11}).")]]

#text("Thus, if ")#mi("{h \\in G}")#text(" and ")#mi("{x_3,x_1 \\in C}")#text(" are such that ")#mi("{x_3-x_1 = h}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("f(w_1) - f(w_2) + f(w_3) - f(w_4) + f(w_5) - f(w_6) + f(w_7) - f(w_8) \\in f(x_3) - f(x_1) + 4S - 4S")]]

#text("for ")#mi("{\\gg K^{-O(1)} N^7}")#text(" octuples ")#mi("{(w_1,w_2,w_3,w_4,w_5,w_6,w_7,w_8) \\in E^8}")#text(" in the hyperplane")

#align(center)[#tao-fit-display[#mitex("h = w_1 - w_2 + w_3 - w_4 + w_5 - w_6 + w_7 - w_8.")]]

#text("By the pigeonhole principle, this implies that for any fixed ")#mi("{h \\in G}")#text(", there can be at most ")#mi("{O(K^{O(1)})}")#text(" sets of the form ")#mi("{f(x_3)-f(x_1) + 3S-3S}")#text(" with ")#mi("{x_3-x_1=h}")#text(", ")#mi("{x_1,x_3 \\in C}")#text(" that are pairwise disjoint. Using a greedy algorithm, we conclude that there is a set ")#mi("{W_h}")#text(" of cardinality ")#mi("{O(K^{O(1)})}")#text(", such that each set ")#mi("{f(x_3) - f(x_1) + 3S-3S}")#text(" with ")#mi("{x_3-x_1=h}")#text(", ")#mi("{x_1,x_3 \\in C}")#text(" intersects ")#mi("{w+4S -4S}")#text(" for some ")#mi("{w \\in W_h}")#text(", or in other words that ")#metadata(none) <tao-3aabdb56bc4db64ce49d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("f(x_3) - f(x_1) \\in W_{x_3-x_1} + 8S-8S")]]

#text("whenever ")#mi("{x_1,x_3 \\in C}")#text(". In particular,")

#align(center)[#tao-fit-display[#tao-math("\\sum_{h \\in G} \\sum_{w \\in W_h} \\left| \\{ (x_1,x_3) \\in C^2: x_3-x_1 = h; f(x_3) - f(x_1) \\in w + 8S-8S \\}\\right| \\geq \\left|C\\right|^2 \\gg K^{-O(1)} N^2.", block: true)]]

#text("This implies that there exists a subset ")#mi("{A}")#text(" of ")#mi("{G}")#text(" with ")#tao-math("{\\left|A\\right| \\gg K^{-O(1)} N}", block: false)#text(", and an element ")#mi("{g_1(h) \\in W_h}")#text(" for each ")#mi("{h \\in A}")#text(", such that ")#metadata(none) <tao-17057013652043f03365>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left| \\{ (x_1,x_3) \\in C^2: x_3-x_1 = h; f(x_3) - f(x_1) \\in g_1(h) + 8S-8S \\}\\right| \\gg K^{-O(1)} N", block: true)]]

#text("for all ")#mi("{h \\in A}")#text(". Note we may assume without loss of generality that ")#mi("{0 \\in A}")#text(" and ")#mi("{g_1(0)=0}")#text(".")

#text("Suppose that ")#mi("{h_1,\\dots,h_{16} \\in A}")#text(" are such that ")#metadata(none) <tao-4c1dc1f491eb4e4e3e5e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\sum_{i=1}^{16} (-1)^{i-1} h_i = 0.")]]

#text("By construction of ")#mi("{A}")#text(", and permuting labels, we can find ")#mi("{\\gg K^{-O(1)} N^{16}}")#text(" 16-tuples ")#mi("{(x_1,\\dots,x_{16},y_1,\\dots,y_{16}) \\in C^{32}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("y_i - x_i = (-1)^{i-1} h_i")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("f(y_i) - f(x_i) \\in (-1)^{i-1} g_i(h) + 8S - 8S")]]

#text("for ")#mi("{i=1,\\dots,16}")#text(". We sum this to obtain")

#align(center)[#tao-fit-display[#mitex("f(y_1) + \\sum_{i=1}^{15} f(y_{i+1})-f(x_i) - f(x_8) \\in \\sum_{i=1}^{16} (-1)^{i-1} g_1(h_i) + 128 S - 128 S")]]

#text("and hence by ")#link(<tao-3aabdb56bc4db64ce49d>)[#text("(8)")]

#align(center)[#tao-fit-display[#mitex("f(y_1) - f(x_{16}) + \\sum_{i=1}^{15} W_{k_i} \\in \\sum_{i=1}^{16} (-1)^{i-1} g_1(h_i) + 248 S - 248 S")]]

#text("where ")#mi("{k_i := y_{i+1}-x_i}")#text(". Since")

#align(center)[#tao-fit-display[#mitex("y_1 - x_{16} + \\sum_{i=1}^{15} k_i = 0")]]

#text("we see that there are only ")#mi("{N^{16}}")#text(" possible values of ")#mi("{(y_1,x_{16},k_1,\\dots,k_{15})}")#text(". By the pigeonhole principle, we conclude that at most ")#mi("{O(K^{O(1)})}")#text(" of the sets ")#mi("{\\sum_{i=1}^{16} (-1)^i g_1(h_i) + 248 S - 248 S}")#text(" can be disjoint. Arguing as before, we conclude that there exists a set ")#mi("{X}")#text(" of cardinality ")#mi("{O(K^{O(1)})}")#text(" such that ")#metadata(none) <tao-b17ef6d19c7a5b1ee83b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\sum_{i=1}^{16} (-1)^{i-1} g_1(h_i) \\in X + 496 S - 496 S")]]

#text("whenever ")#link(<tao-4c1dc1f491eb4e4e3e5e>)[#text("(10)")]#text(" holds.")

#text("For any ")#mi("{h \\in 4A-4A}")#text(", write ")#mi("{h}")#text(" arbitrarily as ")#mi("{h = \\sum_{i=1}^8 (-1)^{i-1} h_i}")#text(" for some ")#mi("{h_1,\\dots,h_8 \\in A}")#text(" (with ")#mi("{h_5=\\dots=h_8=0}")#text(" if ")#mi("{h \\in 2A-2A}")#text(", and ")#mi("{h_2 = \\dots = h_8 = 0}")#text(" if ")#mi("{h \\in A}")#text(") and then set")

#align(center)[#tao-fit-display[#mitex("g(h) := \\sum_{i=1}^8 (-1)^i g_1(h_i).")]]

#text("Then from ")#link(<tao-b17ef6d19c7a5b1ee83b>)[#text("(11)")]#text(" we have ")#link(<tao-35bbce4007c5cd57a4c6>)[#text("(4)")]#text(". For ")#mi("{h \\in A}")#text(" we have ")#mi("{g(h) = g_1(h)}")#text(", and ")#link(<tao-fd95c625a3dcbf66c8cb>)[#text("(5)")]#text(" then follows from ")#link(<tao-17057013652043f03365>)[#text("(9)")]#text(". ")#mi("\\Box")

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/592328592e6f8a7fcd628ab0532a9a2ba6e6bc4cfb4ce66f2165b137ccaeb899-fbfb17680288dafb857602249be63bbeea4f6fea48196f0472ba19fd37d92edc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harry Crimmins")]], [#link("https://terrytao.wordpress.com/2018/07/07/1-quasimorphisms-and-group-cohomology/#comment-502448")[#strong[#text("Harry Crimmins")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2018")])]

#text("The link to the previous post re cohomology appears to be broken.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2018/07/07/1-quasimorphisms-and-group-cohomology/#comment-502485")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2018")])]

#text("The circle ")#mi("X = \\{ x^2 + y^2 - 1 = 0 \\} \\subseteq \\mathbb{R}^2")#text(" has rotational symmetry. We could call this group ")#mi("\\text{SO}_2(\\mathbb{R})")#text(". The rational points on the circle should be “sort-of” rotationally symmetric. How can we express that mathematically?")

#text("We have ")#mi("(a,b) \\in \\mathbb{Q}^2")#text(" with ")#mi("a^2 + b^2 = 1")#text(" and the height of ")#mi("ht(a),h(b) < N")#text(". I'm even straining to find the definition of \"height\" here… if ")#mi("a = \\frac{p_1}{q_1}, b = \\frac{p_2}{q_2}")#text(" as reduced fractions, then we have ")#mi("ht[(a,b)] = \\text{max}(p_1, q_1, p_2, q_2)")#text(".")

#text("This is a set of measure zero, ")#mi("\\mu[X(\\mathbb{Q})] = 0")#text(" but maybe I can cover each rational point with a small interval? If I rotate this circle by 45 degrees, none of this set overlaps with itself, so this circle is definitely not rotationally symmetric.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1cf9bca2192232d4297f7b4c4c3154b2431c06ad2f7a16c673fe84f712f2fdaa-3d1a76bfd473a1d5ac82f8787ed68bd884c3a935313f346df281882fcdd5efd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allan van Hulst")]], [#link("https://terrytao.wordpress.com/2018/07/07/1-quasimorphisms-and-group-cohomology/#comment-502503")[#strong[#text("Allan van Hulst")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2018")])]

#text("Three lines below Z -> R in bold: “we can then one can verify that”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/07/07/1-quasimorphisms-and-group-cohomology/#comment-502524")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2018")])]

#text("two lines above theorem 1, it seems that “think” should be “thank”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ba47469313497327de3de34efa15122c0b7b7351949fd77046cd325c79354966-3499be251a3e5f87ef149fc193557ab0bd43ccb934695cb53c5677db06058e9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of majdoddin")]], [#link("https://terrytao.wordpress.com/2018/07/07/1-quasimorphisms-and-group-cohomology/#comment-502540")[#strong[#text("majdoddin")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2018")])]

#text("“one can check that ")#mi("f")#text(" is an affine quasimorphism if and only if it is the sum of a quasimorphism and a constant.”")#linebreak()#text(" But isn’t the sum of quasimorphism and a constant simply a quasimorphism?")

#text("Let ")#mi("f:G\\rightarrow H")#text(" be a quasimorphism and let ")#mi("g(x) = f(x) + D")#text(" for all ")#mi("x \\in G")#text(" and for a constant ")#mi("D \\in H")#text(".")#linebreak()#text(" Now ")#mi("g(x+y) - g(x) - g(y) = f(x+y) - f(x) - f(y) - D")#text(".")

#text("By triangle-inequality we have ")#mi("d(f(x+y)-f(x)-f(y)-D, 0) \\le d(f(x+y)-f(x)-f(y), 0) +")#linebreak()#text(" ")#mi("d(f(x+y)-f(x)-f(y), f(x+y)-f(x)-f(y)-D)")#text(".")

#text("Now because ")#mi("d")#text(" is a translation invariant metric, the right side is equal to ")#mi("O(1) + d(-D, 0)= O(1)")#text(".")

#emph[#text("[This is technically true, but only if one is willing to lose control of the quasimorphism constants; I have reworded this paragraph to address this point. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf0f4fe3d65881c1ad21d60ba0e774d589f6f787f894ab946103cf10365f226b-34b024389300d1880228e2e2ddde17baee90233e8d99d7bfa9da7957950def26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of OneGuy")]], [#link("https://terrytao.wordpress.com/2018/07/07/1-quasimorphisms-and-group-cohomology/#comment-502739")[#strong[#text("OneGuy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2018")])]

#text("OT: Are you gonna write on the Kakeya conjecture anytime soon? My")#linebreak()#text(" ")#link("http://vixra.org/pdf/1709.0113v6.pdf")[#text(" paper ")]#text(" was on the editors table for almost 10 months, but the experts on the field wouldn`t referee it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ba47469313497327de3de34efa15122c0b7b7351949fd77046cd325c79354966-3499be251a3e5f87ef149fc193557ab0bd43ccb934695cb53c5677db06058e9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of majdoddin")]], [#link("https://terrytao.wordpress.com/2018/07/07/1-quasimorphisms-and-group-cohomology/#comment-502747")[#strong[#text("majdoddin")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2018")])]

#text("In calculations of the quasimorphism ")#mi("f:Z\\rightarrow R")#text(", there is no need to use (2) a second time.")#linebreak()#text(" To see it, first notice that your usage of ")#mi("O(1)")#text(" in (2) is implying this definition of Big-O notation (see also ")#link("http://web.mit.edu/16.070/www/lecture/big_o.pdf")[#text("here")]#text("):")

#mi("f(x)=O(g(x))")#text(" if and only if there exist constants ")#mi("N")#text(" and ")#mi("C")#text(" such that ")#tao-math("\\left|f(x)\\right| \\le C \\left|g(x)\\right|", block: false)#text(" for all ")#mi("x > N")#text(".")

#text("Using this notation, we have ")#mi("f(kx)/kx = f(x)/x + O(1/x)")#text(" for ")#emph[#mi("x \\ne 0")]#text(", then ")#mi("\\alpha = f(x)/x + O(1/x)")#text(" for ")#emph[]#emph[#mi("x\\ne 0")#text(", and then ")#mi("f(x)=\\alpha x + O(1)")#text(" for all ")#mi("x")#text(".")]

#emph[#text("[The final use of (2) is needed to control ")#mi("f")#text(" for negative ")#mi("x")#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/07/07/1-quasimorphisms-and-group-cohomology/#comment-503074")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2018")])]

#text("Dear Terry,")#linebreak()#text(" Today is 17th july 1975")#linebreak()#text(" Happy birthday to you,I am expecting your new breakthrough works.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2018/07/07/1-quasimorphisms-and-group-cohomology/#comment-504374")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2018")])]

#text("The goal in many papers (or a Theorem in a book) pages and pages to show that ")#mi("f(x) = x + o(1)")#text(" for some definition of “approximate” or “close” or “looks good” or “kinda-sorta”. Well… we could show that ")#mi("f(x+y) = f(x) + f(y) + o(1)")#text(" like you said.")

#text("Rarely do they use Additive Combinatorics. Sources suggest it could be a good a resource as any. They just don’t.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/07/07/1-quasimorphisms-and-group-cohomology/#comment-506625")[#strong[#text("1% Quasimorphisms and group cohomology – BeingProWorld")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2018")]

#text("[…] Link to the original work […]")
]
