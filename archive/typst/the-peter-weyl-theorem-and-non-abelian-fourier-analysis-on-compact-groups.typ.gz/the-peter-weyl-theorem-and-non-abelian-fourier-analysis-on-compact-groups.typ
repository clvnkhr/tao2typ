// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/
// Converted to Typst by tao2typ: "2026-10-14T15:17:59.572618+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Peter-Weyl theorem, and non-abelian Fourier analysis on compact groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Peter-Weyl theorem, and non-abelian Fourier analysis on compact groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 January 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/")[#text("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{G}")#text(" be a compact group. (Throughout this post, all ")#link("http://en.wikipedia.org/wiki/Topological_group")[#text("topological groups")]#text(" are assumed to be Hausdorff.) Then ")#mi("{G}")#text(" has a number of ")#link("http://en.wikipedia.org/wiki/Unitary_representation")[#text("unitary representations")]#text(", i.e. continuous homomorphisms ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" to the group ")#mi("{U(H)}")#text(" of unitary operators on a Hilbert space ")#mi("{H}")#text(", equipped with the strong operator topology. In particular, one has the ")#emph[#text("left-regular representation")]#text(" ")#mi("{\\tau: G \\rightarrow U(L^2(G))}")#text(", where we equip ")#mi("{G}")#text(" with its normalised Haar measure ")#mi("{\\mu}")#text(" (and the Borel ")#mi("{\\sigma}")#text("-algebra) to form the Hilbert space ")#mi("{L^2(G)}")#text(", and ")#mi("{\\tau}")#text(" is the translation operation")

#align(center)[#tao-fit-display[#mitex("\\tau(g) f(x) := f(g^{-1} x).")]]

#text("We call two unitary representations ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" and ")#mi("{\\rho^{\\prime}: G \\rightarrow U(H^{\\prime})}")#text(" ")#emph[#text("isomorphic")]#text(" if one has ")#mi("{\\rho^{\\prime}(g) = U \\rho(g) U^{-1}}")#text(" for some unitary transformation ")#mi("{U: H \\rightarrow H^{\\prime}}")#text(", in which case we write ")#mi("{\\rho \\equiv \\rho^{\\prime}}")#text(".")

#text("Given two unitary representations ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" and ")#mi("{\\rho^{\\prime}: G \\rightarrow U(H^{\\prime})}")#text(", one can form their direct sum ")#mi("{\\rho \\oplus \\rho^{\\prime}: G \\rightarrow U(H \\oplus H^{\\prime})}")#text(" in the obvious manner: ")#mi("{\\rho \\oplus \\rho^{\\prime}(g)(v) := (\\rho(g) v, \\rho^{\\prime}(g) v)}")#text(". Conversely, if a unitary representation ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" has a closed invariant subspace ")#mi("{V \\subset H}")#text(" of ")#mi("{H}")#text(" (thus ")#mi("{\\rho(g) V \\subset V}")#text(" for all ")#mi("{g \\in G}")#text("), then the orthogonal complement ")#mi("{V^\\perp}")#text(" is also invariant, leading to a decomposition ")#mi("{\\rho \\equiv \\rho\\downharpoonright_V \\oplus \\rho\\downharpoonright_{V^\\perp}}")#text(" of ")#mi("{\\rho}")#text(" into the ")#emph[#text("subrepresentations")]#text(" ")#mi("{\\rho\\downharpoonright_V: G \\rightarrow U(V)}")#text(", ")#mi("{\\rho\\downharpoonright_{V^\\perp}: G \\rightarrow U(V^\\perp)}")#text(". Accordingly, we will call a unitary representation ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" ")#emph[#text("irreducible")]#text(" if ")#mi("{H}")#text(" is nontrivial (i.e. ")#mi("{H \\neq \\{0\\}}")#text(") and there are no nontrivial invariant subspaces (i.e. no invariant subspaces other than ")#mi("{\\{0\\}}")#text(" and ")#mi("{H}")#text("); the irreducible representations play a role in the subject analogous to those of prime numbers in multiplicative number theory. By the principle of infinite descent, every finite-dimensional unitary representation is then expressible (perhaps non-uniquely) as the direct sum of irreducible representations.")

#text("The ")#link("http://en.wikipedia.org/wiki/Peter-Weyl_theorem")[#text("Peter-Weyl theorem")]#text(" asserts, among other things, that the same claim is true for the regular representation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Peter-Weyl theorem)")]#text(" ")#metadata(none) <tao-026ad9b14a7453b7488d>#text(" Let ")#mi("{G}")#text(" be a compact group. Then the regular representation ")#mi("{\\tau: G \\rightarrow U(L^2(G))}")#text(" is isomorphic to the direct sum of irreducible representations. In fact, one has ")#mi("{\\tau \\equiv \\bigoplus_{\\xi \\in \\hat G} \\rho_\\xi^{\\oplus \\text{dim}(V_\\xi)}}")#text(", where ")#mi("{(\\rho_\\xi)_{\\xi \\in \\hat G}}")#text(" is an enumeration of the irreducible finite-dimensional unitary representations ")#mi("{\\rho_\\xi: G \\rightarrow U(V_\\xi)}")#text(" of ")#mi("{G}")#text(" (up to isomorphism). (It is not difficult to see that such an enumeration exists.)")
]

#text("In the case when ")#mi("{G}")#text(" is abelian, the Peter-Weyl theorem is a consequence of the ")#link("http://en.wikipedia.org/wiki/Plancherel_theorem")[#text("Plancherel theorem")]#text("; in that case, the irreducible representations are all one dimensional, and are thus indexed by the space ")#mi("{\\hat G}")#text(" of ")#emph[#text("characters")]#text(" ")#mi("{\\xi: G \\rightarrow {\\bf R}/{\\bf Z}}")#text(" (i.e. continuous homomorphisms into the unit circle ")#mi("{{\\bf R}/{\\bf Z}}")#text("), known as the ")#link("http://en.wikipedia.org/wiki/Pontryagin_duality")[#text("Pontryagin dual")]#text(" of ")#mi("{G}")#text(". (See for instance ")#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")[#text("my lecture notes on the Fourier transform")]#text(".) Conversely, the Peter-Weyl theorem can be used to deduce the Plancherel theorem for compact groups, as well as other basic results in Fourier analysis on these groups, such as the Fourier inversion formula.")

#text("Because the regular representation is ")#link("http://en.wikipedia.org/wiki/Faithful_representation")[#text("faithful")]#text(" (i.e. injective), a corollary of the Peter-Weyl theorem (and a ")#link("http://en.wikipedia.org/wiki/Cartan's_theorem")[#text("classical theorem of Cartan")]#text(") is that every compact group can be expressed as the ")#link("http://en.wikipedia.org/wiki/Inverse_limit")[#text("inverse limit")]#text(" of Lie groups, leading to a solution to ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_fifth_problem")[#text("Hilbert’s fifth problem")]#text(" in the compact case. Furthermore, the compact case is then an important building block in the more general theory surrounding Hilbert’s fifth problem, and in particular a ")#link("http://www.ams.org/mathscinet-getitem?mr=58607")[#text("result of Yamabe")]#text(" that any ")#emph[#text("locally")]#text(" compact group contains an open subgroup that is the inverse limit of Lie groups.")

#text("I’ve recently become interested in the theory around Hilbert’s fifth problem, due to the existence of a ")#emph[#text("correspondence principle")]#text(" between locally compact groups and ")#emph[#text("approximate groups")]#text(", which play a fundamental role in ")#link("http://en.wikipedia.org/wiki/Arithmetic_combinatorics")[#text("arithmetic combinatorics")]#text(". I hope to elaborate upon this correspondence in a subsequent post, but I will mention that versions of this principle play a crucial role in Gromov’s proof of ")#link("http://en.wikipedia.org/wiki/Gromov%27s_theorem_on_groups_of_polynomial_growth")[#text("his theorem on groups of polynomial growth")]#text(" (discussed ")#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")[#text("previously")]#text(" ")#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/")[#text("on")]#text(" ")#link("https://terrytao.wordpress.com/2009/10/23/a-finitary-version-of-gromovs-polynomial-growth-theorem/")[#text("this")]#text(" ")#link("https://terrytao.wordpress.com/2010/02/18/a-proof-of-gromovs-theorem/")[#text("blog")]#text("), and in a ")#link("http://arxiv.org/abs/0909.2190")[#text("more recent paper of Hrushovski on approximate groups")]#text(" (also ")#link("https://terrytao.wordpress.com/category/teaching/logic-reading-seminar/")[#text("discussed")]#text(" ")#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/")[#text("previously")]#text("). It is also analogous in many ways to the more well-known ")#emph[#text("Furstenberg correspondence principle")]#text(" between ergodic theory and combinatorics (also ")#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")[#text("discussed")]#text(" ")#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/")[#text("previously")]#text(").")

#text("Because of the above motivation, I have decided to write some notes on how the Peter-Weyl theorem is proven. This is utterly standard stuff in abstract harmonic analysis; these notes are primarily for my own benefit, but perhaps they may be of interest to some readers also.")

#metadata(none) <tao-24680f50bec3fe183033>

#heading(level: 1)[#strong[#text(" — 1. Proof of the Peter-Weyl theorem — ")]]

#text("Throughout these notes, ")#mi("{G}")#text(" is a fixed compact group.")

#text("Let ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" and ")#mi("{\\rho^{\\prime}: G \\rightarrow U(H^{\\prime})}")#text(" be unitary representations. An ")#link("http://en.wikipedia.org/wiki/Equivariant")[#text("(linear) equivariant map")]#text(" ")#mi("{T: H \\rightarrow H^{\\prime}}")#text(" is defined to be a continuous linear transformation such that ")#mi("{T \\rho(g) = \\rho^{\\prime}(g) T}")#text(" for all ")#mi("{g \\in G}")#text(".")

#text("A fundamental fact in representation theory, known as ")#link("http://en.wikipedia.org/wiki/Schur's_lemma")[#text("Schur’s lemma")]#text(", asserts (roughly speaking) that equivariant maps cannot mix irreducible representations together unless they are isomorphic. More precisely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Schur’s lemma for unitary representations)")]#text(" Suppose that ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" and ")#mi("{\\rho^{\\prime}: G \\rightarrow U(H^{\\prime})}")#text(" are irreducible unitary representations, and let ")#mi("{T: H \\rightarrow H^{\\prime}}")#text(" be an equivariant map. Then ")#mi("{T}")#text(" is either the zero transformation, or a constant multiple of an isomorphism. In particular, if ")#mi("{\\rho \\not \\equiv \\rho^{\\prime}}")#text(", then there are no non-trivial equivariant maps between ")#mi("{H}")#text(" and ")#mi("{H^{\\prime}}")#text(".")
]

#emph[#text("Proof:")]#text(" The adjoint map ")#mi("{T^*: H^{\\prime} \\rightarrow H}")#text(" of the equivariant map ")#mi("{T}")#text(" is also equivariant, and thus so is ")#mi("{T^* T: H \\rightarrow H}")#text(". As ")#mi("{T^* T}")#text(" is also a bounded self-adjoint operator, we can apply the ")#link("http://en.wikipedia.org/wiki/Spectral_theorem")[#text("spectral theorem")]#text(" to it. Observe that any closed invariant space of ")#mi("{T^* T}")#text(" is ")#mi("{G}")#text("-invariant, and is thus either ")#mi("{\\{0\\}}")#text(" or ")#mi("{H}")#text(". By the spectral theorem, this forces ")#mi("{T^* T}")#text(" to be a constant multiple of the identity. Similarly for ")#mi("{T T^*}")#text(". This forces ")#mi("{T}")#text(" to either be zero or a constant multiple of a unitary map, and the claim follows. (Thanks to Frederick Goodman for this proof.) ")#mi("\\Box")

#text("Schur’s lemma has many foundational applications in the subject. For instance, we have the following generalisation of the well-known fact that eigenvectors of a unitary operator with distinct eigenvalues are necessarily orthogonal:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3")]#text(" ")#metadata(none) <tao-0d45f5fd462b8c70bffb>#text(" Let ")#mi("{\\rho\\downharpoonright_V: G \\rightarrow U(V)}")#text(" and ")#mi("{\\rho\\downharpoonright_W: G \\rightarrow U(W)}")#text(" be two irreducible subrepresentations of a unitary representation ")#mi("{\\rho: G \\rightarrow U(H)}")#text(". Then one either has ")#mi("{\\rho\\downharpoonright_V \\equiv \\rho\\downharpoonright_W}")#text(" or ")#mi("{V \\perp W}")#text(".")
]

#emph[#text("Proof:")]#text(" Apply Schur’s lemma to the orthogonal projection from ")#mi("{W}")#text(" to ")#mi("{V}")#text(". ")#mi("\\Box")

#text("Another application shows that finite-dimensional ")#emph[#text("linear")]#text(" representations can be canonically identified (up to constants) with finite-dimensional unitary representations:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 4")]#text(" ")#metadata(none) <tao-d4f568b800c6a61b3ba2>#text(" Let ")#mi("{\\rho: G \\rightarrow GL(V)}")#text(" be a linear representation on a finite-dimensional space ")#mi("{V}")#text(". Then there exists a Hermitian inner product ")#mi("{\\langle,\\rangle}")#text(" on ")#mi("{V}")#text(" that makes this representation unitary. Furthermore, if ")#mi("{V}")#text(" is irreducible, then this inner product is unique up to constants.")
]

#emph[#text("Proof:")]#text(" To show existence of the Hermitian inner product that unitarises ")#mi("{\\rho}")#text(", take an arbitrary Hermitian inner product ")#mi("{\\langle,\\rangle_0}")#text(" and then form the average")

#align(center)[#tao-fit-display[#mitex("\\langle v, w \\rangle := \\int_G \\langle \\rho(g) v, \\rho(g) w \\rangle_0\\ d\\mu(g).")]]

#text("(this is the “Weyl averaging trick”, which crucially exploits compactness of ")#mi("{G}")#text("). Then one easily checks (using the fact that ")#mi("{V}")#text(" is finite dimensional and thus locally compact) that ")#mi("{\\langle,\\rangle}")#text(" is also Hermitian, and that ")#mi("{\\rho}")#text(" is unitary with respect to this inner product, as desired. (This part of the argument does not use finite dimensionality.)")

#text("To show uniqueness up to constants, assume that one has two such inner products ")#mi("{\\langle,\\rangle}")#text(", ")#mi("{\\langle,\\rangle^{\\prime}}")#text(" on ")#mi("{V}")#text(", and apply Schur’s lemma to the identity map between the two Hilbert spaces ")#mi("{(V, \\langle,\\rangle)}")#text(" and ")#mi("{(V, \\langle,\\rangle^{\\prime})}")#text(". (Here, finite dimensionality is used to establish ")#mi("\\Box")

#text("A third application of Schur’s lemma allows us to express the trace of a linear operator as an average:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 5")]#text(" ")#metadata(none) <tao-eafe895eb8119e6e5d06>#text(" Let ")#mi("{\\rho: G \\rightarrow GL(H)}")#text(" be an irreducible unitary representation on a non-trivial finite-dimensional space ")#mi("{H}")#text(", and let ")#mi("{T: H \\rightarrow H}")#text(" be a linear transformation. Then")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\text{dim}(H)} \\text{tr}_H(T) I_H = \\int_G \\rho(g) T \\rho(g)^*\\ d\\mu(g),")]]

#text("where ")#mi("{I_H: H \\rightarrow H}")#text(" is the identity operator.")
]

#emph[#text("Proof:")]#text(" The right-hand side is equivariant, and hence by Schur’s lemma is a multiple of the identity. Taking traces, we see that the right-hand side also has the same trace as ")#mi("{T}")#text(". The claim follows. ")#mi("\\Box")

#text("Let us now consider the irreducible subrepresentations ")#mi("{\\rho\\downharpoonright_V: G \\rightarrow U(V)}")#text(" of the left-regular representation ")#mi("{\\rho: G \\rightarrow U(L^2(G))}")#text(". From Corollary ")#link(<tao-0d45f5fd462b8c70bffb>)[#text("3")]#text(", we know that those subrepresentations coming from different isomorphism classes in ")#mi("{\\hat G}")#text(" are orthogonal, so we now focus attention on those subrepresentations coming from a single class ")#mi("{\\xi \\in \\hat G}")#text(". Define the ")#emph[#mi("{\\xi}")#text("-isotypic component")]#text(" ")#mi("{L^2(G)_\\xi}")#text(" of the regular representation to be the finite-dimensional subspace of ")#mi("{L^2(G)}")#text(" spanned by the functions of the form")

#align(center)[#tao-fit-display[#mitex("f_{\\xi,v,w}: g \\mapsto \\langle v, \\rho_\\xi(g) w \\rangle_{V_\\xi}")]]

#text("where ")#mi("{v, w}")#text(" are arbitrary vectors in ")#mi("{V_\\xi}")#text(". This is clearly a left-invariant subspace of ")#mi("{L^2(G)}")#text(" (in fact, it is bi-invariant, a point which we will return to later), and thus induces a subrepresentation of the left-regular representation. In fact, it captures precisely all the subrepresentations of the left-regular representation that are isomorphic to ")#mi("{\\rho_\\xi}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6")]#text(" ")#metadata(none) <tao-5eff41ee0a1f0785ec39>#text(" Let ")#mi("{\\xi \\in \\hat G}")#text(". Then every irreducible subrepresentation ")#mi("{\\tau\\downharpoonright_V: G \\rightarrow U(V)}")#text(" of the left-regular representation ")#mi("{\\tau: G \\rightarrow U(L^2(G))}")#text(" that is isomorphic to ")#mi("{\\rho_\\xi}")#text(" is a subrepresentation of ")#mi("{L^2(G)_\\xi}")#text(". Conversely, ")#mi("{L^2(G)_\\xi}")#text(" is isomorphic to the direct sum ")#mi("{\\rho_\\xi^{\\text{dim}(V_\\xi)}}")#text(" of ")#mi("{\\text{dim}(V_\\xi)}")#text(" copies of ")#mi("{\\rho_\\xi: G \\rightarrow U(V_\\xi)}")#text(". (In particular, ")#mi("{L^2(G)_\\xi}")#text(" has dimension ")#mi("{\\text{dim}(V_\\xi)^2}")#text(").")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{\\tau\\downharpoonright_V: G \\rightarrow U(V)}")#text(" be a subrepresentation of the left-regular representation that is isomorphic to ")#mi("{\\rho_\\xi}")#text(". Thus, we have an equivariant isometry ")#mi("{\\iota: V_\\xi \\rightarrow L^2(G)}")#text(" whose image is ")#mi("{V}")#text("; it has an adjoint ")#mi("{\\iota^*: L^2(G) \\rightarrow V_\\xi}")#text(".")

#text("Let ")#mi("{v \\in V_\\xi}")#text(" and ")#mi("{K \\in L^2(G)}")#text(". The convolution")

#align(center)[#tao-fit-display[#mitex("\\iota(v) * K(g) := \\int_G \\iota(v)(gh) K(h^{-1})\\ d\\mu(h)")]]

#text("can be re-arranged as")

#align(center)[#tao-fit-display[#mitex("\\int_G \\tau(g^{-1})(\\iota(v))(h) \\overline{\\tilde K(h)}\\ d\\mu(h)")]]

#tao-aligned(keep: true)[


#tao-math(" & = \\langle \\tau(g^{-1})(\\iota(v)), \\tilde K \\rangle_{L^2(G)}", block: true)



#tao-math(" & = \\langle \\iota(\\rho_\\xi(g^{-1}) v), \\tilde K \\rangle_{L^2(G)}", block: true)



#tao-math(" & = \\langle \\rho_\\xi(g^{-1}) v, \\iota^* \\tilde K \\rangle_{V_\\xi}", block: true)



#tao-math(" & = \\langle v, \\rho_\\xi(g) \\iota^* \\tilde K \\rangle_{V_\\xi}", block: true)
]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\tilde K(g) := \\overline{K(g^{-1})}.")]]

#text("In particular, we see that ")#mi("{\\iota(v) * K \\in L^2(G)_\\xi}")#text(" for every ")#mi("{K}")#text(". Letting ")#mi("{K}")#text(" be a sequence (or net) of approximations to the identity, we conclude that ")#mi("{\\iota(v) \\in L^2(G)_\\xi}")#text(" as well, and so ")#mi("{V \\subset L^2(G)_\\xi}")#text(", which is the first claim.")

#text("To prove the converse claim, write ")#mi("{n := \\text{dim}(V_\\xi)}")#text(", and let ")#mi("{e_1,\\ldots,e_n}")#text(" be an orthonormal basis for ")#mi("{V_\\xi}")#text(". Observe that we may then decompose ")#mi("{L^2(G)_\\xi}")#text(" as the direct sum of the spaces")

#align(center)[#tao-fit-display[#mitex("L^2(G)_{\\xi,e_i} := \\{ f_{\\xi,v,e_i}: v \\in V_\\xi\\}")]]

#text("for ")#mi("{i=1,\\ldots,n}")#text(". The claim follows. ")#mi("\\Box")

#text("From Corollary ")#link(<tao-0d45f5fd462b8c70bffb>)[#text("3")]#text(", the ")#mi("{\\xi}")#text("-isotypic components ")#mi("{L^2(G)_\\xi}")#text(" for ")#mi("{\\xi \\in \\hat G}")#text(" are pairwise orthogonal, and so we can form the direct sum ")#mi("{\\oplus_{\\xi \\in \\hat G} L^2(G)_\\xi \\equiv \\oplus_{\\xi \\in \\hat G} \\rho_\\xi^{\\oplus \\text{dim}(G)}}")#text(", which is an invariant subspace of ")#mi("{L^2(G)}")#text(" that contains all the finite-dimensional irreducible subrepresentations (and hence also all the finite-dimensional representations, period). The essence of the Peter-Weyl theorem is then the assertion that this direct sum in fact occupies all of ")#mi("{L^2(G)}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7")]#text(" We have ")#mi("{L^2(G) = \\oplus_{\\xi \\in \\hat G} L^2(G)_\\xi}")#text(".")
]

#emph[#text("Proof:")]#text(" Suppose this is not the case. Taking orthogonal complements, we conclude that there exists a non-trivial ")#mi("{f \\in L^2(G)}")#text(" which is orthogonal to all ")#mi("{L^2(G)_\\xi}")#text(", and is in particular orthogonal to all finite-dimensional subrepresentations of ")#mi("{L^2(G)}")#text(".")

#text("Now let ")#mi("{K \\in L^2(G)}")#text(" be an arbitrary self-adjoint kernel, thus ")#mi("{\\overline{K(g^{-1})} = K(g)}")#text(" for all ")#mi("{g \\in G}")#text(". The convolution operator ")#mi("{T: f \\mapsto f*K}")#text(" is then a self-adjoint Hilbert-Schmidt operator and is thus compact. (Here, we have crucially used the compactness of ")#mi("{G}")#text(".) By the spectral theorem, the cokernel ")#mi("{\\text{ker}(T)^\\perp}")#text(" of this operator then splits as the direct sum of finite-dimensional eigenspaces. As ")#mi("{T}")#text(" is equivariant, all these eigenspaces are invariant, and thus orthogonal to ")#mi("{f}")#text("; thus ")#mi("{f}")#text(" must lie in the kernel of ")#mi("{T}")#text(", and thus ")#mi("{f*K}")#text(" vanishes for all self-adjoint ")#mi("{K \\in L^2(G)}")#text(". Using a sequence (or net) of approximations to the identity, we conclude that ")#mi("{f}")#text(" vanishes also, a contradiction. ")#mi("\\Box")

#text("Theorem ")#link(<tao-026ad9b14a7453b7488d>)[#text("1")]#text(" follows by combining this proposition with ")#link(<tao-5eff41ee0a1f0785ec39>)[#text("6")]#text(".")

#heading(level: 1)[#strong[#text(" — 2. Nonabelian Fourier analysis — ")]]

#text("Given ")#mi("{\\xi \\in \\hat G}")#text(", the space ")#mi("{HS(V_\\xi)}")#text(" of linear transformations from ")#mi("{V_\\xi}")#text(" to ")#mi("{V_\\xi}")#text(" is a finite-dimensional Hilbert space, with the Hilbert-Schmidt inner product ")#mi("{\\langle S, T \\rangle_{HS(V_\\xi)} := \\text{tr}_{V_\\xi} S T^*}")#text("; it has a unitary action of ")#mi("{G}")#text(" as defined by ")#mi("{\\rho_{HS(V_\\xi)}(g): T \\mapsto \\rho_\\xi(g) T}")#text(". For any ")#mi("{T \\in HS(V_\\xi)}")#text(", the function ")#mi("{g \\mapsto \\langle T, \\rho_\\xi(g)^* \\rangle_{HS(V_\\xi)}}")#text(" can be easily seen to lie in ")#mi("{L^2(G)_\\xi}")#text(", giving rise to a map ")#mi("{\\iota_\\xi: HS(V_\\xi) \\rightarrow L^2(G)_\\xi}")#text(". It is easy to see that this map is equivariant.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8")]#text(" ")#metadata(none) <tao-8d9315fc224d877fa15d>#text(" For each ")#mi("{\\xi \\in \\hat G}")#text(", the map ")#mi("{\\text{dim}(V_\\xi)^{1/2} \\iota_\\xi}")#text(" is unitary.")
]

#emph[#text("Proof:")]#text(" As ")#mi("{HS(V_\\xi)}")#text(" and ")#mi("{L^2(G)_\\xi}")#text(" are finite-dimensional spaces with the same dimension ")#mi("{\\text{dim}(V_\\xi)^2}")#text(", it suffices to show that this map is an isometry, thus we need to show that")

#align(center)[#tao-fit-display[#mitex("\\langle {\\mathcal F}_\\xi^*(S), {\\mathcal F}_\\xi^*(T) \\rangle_{L^2(G)} = \\frac{1}{\\text{dim}(V_\\xi)} \\langle S, T\\rangle_{HS(V_\\xi)}")]]

#text("for all ")#mi("{S, T \\in HS(V_\\xi)}")#text(". By bilinearity, we may reduce to the case when ")#mi("{S, T}")#text(" are rank one operators")

#align(center)[#tao-fit-display[#mitex("S := ab^*; \\quad T := cd^*")]]

#text("for some ")#mi("{a,b,c,d \\in V_\\xi}")#text(", where ")#mi("{b^*: V_\\xi \\rightarrow {\\bf C}}")#text(" is the dual vector ")#mi("{b^*: v \\mapsto \\langle v, b \\rangle}")#text(" to ")#mi("{b}")#text(", and similarly for ")#mi("{d}")#text(". Then we have")

#align(center)[#tao-fit-display[#mitex("\\langle S, T\\rangle_{HS(V_\\xi)} = \\text{tr}_{V_\\xi} ab^* d c^* = (c^* a) (b^* d)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\langle {\\mathcal F}_\\xi^*(S), {\\mathcal F}_\\xi^*(T) \\rangle_{L^2(G)} = \\int_G (b^* \\rho_\\xi(g)^* a) \\overline{(d^* \\rho_\\xi(g)^* c)}\\ d\\mu(G).")]]

#text("The latter expression can be rewritten as")

#align(center)[#tao-fit-display[#mitex("\\int_G \\langle \\rho_\\xi(g) db^* \\rho_\\xi(g)^*, ca^* \\rangle_{HS(V_\\xi)}\\ d\\mu(g).")]]

#text("Applying Fubini’s theorem, followed by Corollary ")#link(<tao-eafe895eb8119e6e5d06>)[#text("5")]#text(", this simplifies to")

#align(center)[#tao-fit-display[#mitex("\\langle \\frac{1}{\\text{dim}(V_\\xi)} \\text{tr}(db^*) I_{V_\\xi}, ca^* \\rangle_{HS(V_\\xi)},")]]

#text("which simplifies to ")#mi("{\\frac{1}{\\text{dim}(V_\\xi)} (c^* a) (b^* d)}")#text(", and the claim follows.")

#text("As a corollary of the above proposition, the orthogonal projection of a function ")#mi("{f \\in L^2(G)}")#text(" to ")#mi("{L^2(G)_\\xi}")#text(" can be expressed as")

#align(center)[#tao-fit-display[#mitex("\\text{dim}(V_\\xi) \\iota_\\xi \\iota_\\xi^* f.")]]

#text("We call")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) := \\iota_\\xi^* f = \\int_G f(g) \\rho(g)^*\\ d\\mu(g) \\in HS(V_\\xi)")]]

#text("the ")#emph[#text("Fourier coefficient")]#text(" of ")#mi("{f}")#text(" at ")#mi("{\\xi}")#text(", thus the projection of ")#mi("{f}")#text(" to ")#mi("{L^2(G)_\\xi}")#text(" is the function")

#align(center)[#tao-fit-display[#mitex("g \\mapsto \\text{dim}(V_\\xi) \\langle \\hat f(\\xi), \\rho(g)^* \\rangle")]]

#text("which has an ")#mi("{L^2(G)}")#text(" norm of ")#tao-math("{\\text{dim}(V_\\xi)^{1/2} \\left\\| \\hat f(\\xi) \\right\\|_{HS(V_\\xi)}}", block: false)#text(". From the Peter-Weyl theorem we thus obtain the ")#emph[#text("Fourier inversion formula")]

#align(center)[#tao-fit-display[#mitex("f(g) = \\sum_{\\xi \\in \\hat G} \\text{dim}(V_\\xi) \\langle \\hat f(\\xi), \\rho(g)^* \\rangle")]]

#text("and the ")#emph[#text("Plancherel identity")]

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^2(G)}^2 = \\sum_{\\xi \\in \\hat G} \\text{dim}(V_\\xi) \\left\\| \\hat f(\\xi) \\right\\|_{HS(V_\\xi)}^2.", block: true)]]

#text("We can write these identities more compactly as an isomorphism ")#metadata(none) <tao-73f615112038fbbbada6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("L^2(G) \\equiv \\bigoplus_{\\xi \\in \\hat G} \\text{dim}(V_\\xi) \\cdot HS(V_\\xi)")]]

#text(" where the dilation ")#mi("{c \\cdot H}")#text(" of a Hilbert space ")#mi("{H}")#text(" is formed by using the inner product ")#mi("{\\langle v, w \\rangle_{c \\cdot H} := c \\langle v,w \\rangle_H}")#text(". This is an isomorphism not only of Hilbert spaces, but of the left-action of ")#mi("{G}")#text(". Indeed, it is an isomorphism of the bi-action of ")#mi("{G \\times G}")#text(" on both the left and right of both ")#mi("{L^2(G)}")#text(" and ")#mi("{HS(V_\\xi)}")#text(", defined by")

#align(center)[#tao-fit-display[#mitex("\\rho_{L^2(G), G \\times G}(g,h)(f)(x) := f(g^{-1} x h)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\rho_{\\xi, G \\times G}(g,h)(T) := \\rho_\\xi(h) T \\rho_\\xi(g)^*.")]]

#text("It is easy to see that each of the ")#mi("{HS(V_\\xi)}")#text(" are irreducible with respect to the ")#mi("{G \\times G}")#text(" action. Indeed, first observe from Proposition ")#link(<tao-8d9315fc224d877fa15d>)[#text("8")]#text(" that ")#mi("{\\iota_\\xi^*}")#text(" is surjective, and thus ")#mi("{\\rho_\\xi(g) \\in HS(V_\\xi)}")#text(" must span all of ")#mi("{HS(V_\\xi)}")#text(". Thus, any bi-invariant subspace of ")#mi("{HS(V_\\xi)}")#text(" must also be invariant with respect to left and right multiplication by arbitrary elements of ")#mi("{HS(V_\\xi)}")#text(", and in particular by rank one operators; from this one easily sees that there are no non-trivial bi-invariant subspaces. Thus we can view the Peter-Weyl theorem as also describing the irreducible decomposition of ")#mi("{L^2(G)}")#text(" into ")#mi("{G \\times G}")#text("-irreducible components.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" In view of ")#link(<tao-73f615112038fbbbada6>)[#text("(1)")]#text(", it is natural to view ")#mi("{\\hat G}")#text(" as being the “spectrum” of ")#mi("{G}")#text(", with each “frequency” ")#mi("{\\xi \\in \\hat G}")#text(" occuring with “multiplicity” ")#mi("{\\text{dim}(V_\\xi)}")#text(".")
]

#text("In the abelian case, any eigenspace of one unitary operator ")#mi("{\\rho(g)}")#text(" is automatically an invariant subspace of all other ")#mi("{\\rho(h)}")#text(", which quickly implies (from the spectral theorem) that all irreducible finite-dimensional unitary representations must be one-dimensional, in which case we see that the above formulae collapse to the usual Fourier inversion and Plancherel theorems for compact abelian groups.")

#text("In the case of a finite group ")#mi("{G}")#text(", we can take dimensions in ")#link(<tao-73f615112038fbbbada6>)[#text("(1)")]#text(" to obtain the identity")

#align(center)[#tao-fit-display[#tao-math("\\left|G\\right| = \\sum_{\\xi \\in \\hat G} \\text{dim}(V_\\xi)^2.", block: true)]]

#text("In the finite abelian case, we see in particular that ")#mi("{G}")#text(" and ")#mi("{\\hat G}")#text(" have the same cardinality.")

#text("Direct computation also shows other basic Fourier identities, such as the convolution identity")

#align(center)[#tao-fit-display[#mitex("\\widehat{f_1*f_2}(\\xi) = \\hat f_1(\\xi) \\hat f_2(\\xi)")]]

#text("for ")#mi("{f_1, f_2 \\in L^2(G)}")#text(", thus partially diagonalising convolution into multiplication of linear operators on finite-dimensional vector spaces ")#mi("{V_\\xi}")#text(". (Of course, one cannot expect complete diagonalisation in the non-abelian case, since convolution would then also be non-abelian, whereas diagonalised operators must always commute with each other.)")

#text("Call a function ")#mi("{f \\in L^2(G)}")#text(" a ")#link("http://en.wikipedia.org/wiki/Class_function")[#text("class function")]#text(" if it is conjugation-invariant, thus ")#mi("{f(gxg^{-1}) = f(x)}")#text(" for all ")#mi("{x, g \\in G}")#text(". It is easy to see that this is equivalent to each of the Fourier coefficients ")#mi("{\\hat f(\\xi)}")#text(" also being conjugation-invariant: ")#mi("{\\rho_\\xi(g) \\hat f(\\xi) \\rho_\\xi(g)^* = \\hat f(\\xi)}")#text(". By Lemma ")#link(<tao-eafe895eb8119e6e5d06>)[#text("5")]#text(", this is in turn equivalent to ")#mi("{\\hat f(\\xi)}")#text(" being equal to a multiple of the identity:")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) = \\frac{1}{\\text{dim}(V_\\xi)} \\text{tr}(\\hat f(\\xi)) I_{V_\\xi} = \\frac{1}{\\text{dim}(V_\\xi)} \\langle f, \\chi_\\xi \\rangle_{L^2(G)} I_{V_\\xi}")]]

#text("where the ")#link("http://en.wikipedia.org/wiki/Character_theory")[#text("character")]#text(" ")#mi("{\\chi_\\xi \\in L^2(G)}")#text(" of the representation ")#mi("{\\rho_\\xi}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#mitex("\\chi_\\xi(g) := \\text{tr}_{V_\\xi} \\rho_\\xi(g).")]]

#text("The Plancherel identity then simplifies to")

#align(center)[#tao-fit-display[#mitex("f = \\sum_{\\xi \\in \\hat G} \\langle f, \\chi_\\xi \\rangle_{L^2(G)} \\chi_\\xi,")]]

#text("thus the ")#mi("{\\chi_\\xi}")#text(" form an orthonormal basis for the space ")#mi("{L^2(G)^G}")#text(" of class functions. Analogously to ")#link(<tao-73f615112038fbbbada6>)[#text("(1)")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("L^2(G)^G \\equiv \\bigoplus_{\\xi \\in \\hat G} {\\bf C}.")]]

#text("(In particular, in the case of finite groups ")#mi("{G}")#text(", ")#mi("{\\hat G}")#text(" has the same cardinality as the space of conjugacy classes of ")#mi("{G}")#text(".)")

#text("Characters are a fundamentally important tool in analysing finite-dimensional representations ")#mi("{V}")#text(" of ")#mi("{G}")#text(" that are not necessarily irreducible; indeed, if ")#mi("{V}")#text(" decomposes into irreducibles as ")#mi("{\\bigoplus_{\\xi \\in \\hat G} V_\\xi^{\\oplus m_\\xi}}")#text(", then the character ")#mi("{\\chi_V(g) := \\text{tr}_V( \\rho_g )}")#text(" then similarly splits as")

#align(center)[#tao-fit-display[#mitex("\\chi_V = \\sum_{\\xi \\in \\hat G} m_\\xi \\chi_\\xi")]]

#text("and so the multiplicities ")#mi("{m_\\xi}")#text(" of each component ")#mi("{V_\\xi}")#text(" in ")#mi("{V}")#text(" can be given by the formula")

#align(center)[#tao-fit-display[#mitex("m_\\xi = \\langle \\chi_V, \\chi_\\xi \\rangle_{L^2(G)}.")]]

#text("In particular, these multiplicities are unique: all decompositions of ")#mi("{V}")#text(" into irreducibles have the same multiplicities.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 10")]#text(" Representation theory becomes much more complicated once one leaves the compact case; convolution operators ")#mi("{f \\mapsto f*K}")#text(" are no longer compact, and can now admit continuous spectrum in addition to pure point spectrum. Furthermore, even when one has pure point spectrum, the eigenspaces can now be infinite dimensional. Thus, one must now grapple with infinite-dimensional irreducible representations, as well as continuous combinations of representations that cannot be readily resolved into irreducible components. Nevertheless, in the important case of ")#emph[#text("locally compact groups")]#text(", it is still the case that there are “enough” irreducible unitary representations to recover a significant portion of the above theory. The fundamental theorem here is the ")#emph[#text("Gelfand-Raikov theorem")]#text(", which asserts that given any non-trivial group element ")#mi("{g}")#text(" in a locally compact group, there exists a irreducible unitary representation (possibly infinite-dimensional) on which ")#mi("{g}")#text(" acts non-trivially. Very roughly speaking, this theorem is first proven by observing that ")#mi("{g}")#text(" acts non-trivially on the regular representation, which (by the ")#link("http://en.wikipedia.org/wiki/Gelfand%E2%80%93Naimark%E2%80%93Segal_construction")[#text("Gelfand-Naimark-Segal (GNS) construction")]#text(") gives a state on the *-algebra of measures on ")#mi("{G}")#text(" that distinguishes the Dirac mass ")#mi("{\\delta_g}")#text(" at ")#mi("{g}")#text(" from the Dirac mass ")#mi("{\\delta_0}")#text(" from the origin. Applying the ")#link("http://en.wikipedia.org/wiki/Krein-Milman_theorem")[#text("Krein-Milman theorem")]#text(", one then finds an ")#emph[#text("extreme")]#text(" state with this property; applying the GNS construction, one then obtains the desired irreducible representation.")
]

#heading(level: 1)[#text("Comments (30)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec7c6b0e3060e1c806f619bf4b492030a739cda006aaf0a178402739ff75194-2c3659f7497f4bb1cf1e6e85fafd68a9d10b53737c2f3b03f29c35b080ae39ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-49783")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2011")])]

#text("I do not understand why one ever states Peter-Weyl as an isomorphism of G-reps, rather than GxG-reps, where the isotypic components are actually irreducible. (That’s a good place to stop, though I suppose one could move on to the wreath product.) And yet I almost never see it presented as a GxG-theorem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-49793")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2011")])]

#text("Yes, I remember you emphasising this point to me way back in grad school :-). I think that in most applications, one either needs only the G-rep version, or else one may as well go all the way to the nonabelian Fourier inversion formula. The fact that the xi-isotypic components are GxG irreducible is nice, but I don’t know of many places where this fact is actually used very much.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c45d95545d9303dedec72888413f2d4408484c100a771a35dc4a06e785046599-b3ad9ebdd8bc4081a071e4378a63d9bc7b4a3d713350a4ad4eecf47085da7caa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Donley")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-120953")[#strong[#text("Robert Donley")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2012")])]

#text("One step back from Peter-Weyl are the non-vanishing Schur Orthogonality Relations. The irreducible GxG-type $V\\otimes V^*$ is the matrix coefficient span for V, and the tensor is unitary for GxG if the G-rep is unitary. We have two GxG-invariant inner products: one on tensors, and one on matrix coefficients.")

#text("From there, the SORs follow from Schur’s Lemma for GxG. We can think of biinvariant integration as an intertwinor of unique trivial GxG-types.")

#text("This scenario can be posed without compactness, square integrability, or even unitarity. The question becomes: what takes the place of invariant integration in the SORs? Midorikawa answers this for some classes of tempered unitary reps on semisimple Lie groups, but the general case is wide open.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec7c6b0e3060e1c806f619bf4b492030a739cda006aaf0a178402739ff75194-2c3659f7497f4bb1cf1e6e85fafd68a9d10b53737c2f3b03f29c35b080ae39ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-49797")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2011")])]

#text("I don’t understand why you portray the nonabelian Fourier inversion formula as being further than the GxG-version, insofar as it still has a “dim(V)” factor in it.")

#text("There are other statements of the form “")#mi("G\\times H")#text(" acts on X, such that Fun(X) is a sum of ")#mi("V_\\lambda \\otimes W_\\lambda")#text(", where neither the ")#mi("V_\\lambda")#text(" nor ")#mi("W_\\lambda")#text(" repeat. For example, ")#mi("O(n) \\times Sp(k)")#text(" acting on ")#mi("Fun(A^n \\otimes A^{2k})")#text(". I don’t know a uniform statement that would include Peter-Weyl, but wouldn’t be surprised if there is one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-49809")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2011")])]

#text("Well, the dim(V) factor is now only in the normalisation of the inner product, rather than in the Cartesian exponent.")

#text("Here’s roughly how I see the three facts:")

#text("G-rep Peter-Weyl: ")#mi("L^2(G) \\equiv \\sum_{\\xi \\in \\hat G} V_\\xi^{\\text{dim}(V_\\xi)}")#text(" as ")#mi("G")#text("-vector spaces, with no canonical identification.")

#text("Fourier inversion: ")#mi("L^2(G) \\equiv \\sum_{\\xi \\in \\hat G} \\text{dim}(V_\\xi) \\cdot HS(V_\\xi)")#text(" as ")#mi("G \\times G")#text("–")#emph[#text("Hilbert")]#text(" spaces, with identification given by the Fourier transform.")

#mi("G \\times G")#text("-rep Peter-Weyl: ")#mi("L^2(G) \\equiv \\sum_{\\xi \\in \\hat G} V_\\xi \\otimes V_\\xi^*")#text(" as ")#mi("G \\times G")#text("-vector spaces. The ")#mi("G \\times G")#text("-vector spaces ")#mi("V_\\xi \\otimes V_\\xi^*")#text(" are irreducible.")

#text("Note that the Fourier map ")#mi("f \\mapsto \\hat f(\\xi)")#text(" from ")#mi("L^2(G)")#text(" to ")#mi("HS(V_\\xi)")#text(" (or ")#mi("\\text{dim}(V_\\xi) \\cdot HS(V_\\xi)")#text(") is already ")#mi("G \\times G")#text("-equivariant, so the Fourier transform is providing the canonical decomposition of ")#mi("L^2(G)")#text(" into ")#mi("G \\times G")#text("-isotypic components.")

#text("As I see it, the main thing that the ")#mi("G \\times G")#text("-rep version of Peter-Weyl brings to the table beyond the Fourier inversion formula is the ")#mi("G \\times G")#text("-irreducibility of the components, which in the vector space category are ")#mi("V_\\xi \\otimes V_\\xi^*")#text(" and in the Hilbert space category are ")#mi("\\text{dim}(V_\\xi) \\cdot HS(V_\\xi)")#text(". This irreducibility can be deduced from the inversion formula (as I do above) but I don’t know of many situations where one would need to use it, and for which one could not easily substitute the inversion formula in its place instead.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ef267ee10255c7aa9b8c5a4407ef538c8c4127c84beb45c59228e7cbe9033c0-eddb9040c87b17f43d78b50096ad241d5d19c7b3c09452667878b675adf574c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ben-Zvi")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-49816")[#strong[#text("David Ben-Zvi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2011")])]

#text("One thing that the ")#mi("G\\times G")#text(" version adds (that I also learned from Allen in grad school!) is that it encodes simultaneously the harmonic analysis for all homogeneous spaces for ")#mi("G")#text(": for ")#mi("H\\subset G")#text(" we can describe functions on ")#mi("G/H")#text(" (by taking ")#mi("H")#text("-invariants on one side in Peter-Weyl) as the sum of irreps of ")#mi("G")#text(" with multiplicity spaces given by the ")#mi("H")#text("-invariants on their duals.")

#text("This might be even more useful in the complexified form of Peter-Weyl (as decomposing regular functions on the complex group ")#mi("G_C")#text("): a great example of this is to take the maximal nilpotent ")#mi("H=N\\subset G_C")#text(", which by the theorem of highest weight has a unique invariant (up to scale) on any irrep, so we recover that ")#mi("G_C/N")#text(" is a “model space” for ")#mi("G")#text(", with functions given by the sum of all irreps with multiplicity one, labeled by highest weights (the torus action on this line of invariants) – this is a restatement of Borel-Weil.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-50619")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2011")])]

#text("Here is a neat example I just ran across where the ")#mi("G \\times G")#text(" version gets you something that the ")#mi("G")#text("-version doesn’t.")

#text("Suppose we want to compute the deRham cohomology of a compact Lie group.")

#text("If we only keep track of one ")#mi("G")#text("-action, the ")#mi("k")#text("-forms are ")#mi("\\bigwedge^k \\mathfrak{g} \\otimes L^2(G) = \\bigoplus (\\dim V_{\\lambda}) \\mathfrak{g} \\otimes V_{\\lambda}")#text(". It is not obvious that this has any cohomology at all: The dimensions are completely consistent with the complex being exact. For example, if we are looking at ")#mi("G=SU(2)")#text(", and we label a representation by the generating function of its highest weight vectors, then we are dealing with")

#mi("0 \\to \\frac{1}{1-x} \\to \\frac{3}{1-x} \\to \\frac{3}{1-x} \\to \\frac{1}{1-x} \\to 0")#text(".")

#text("Now, suppose we keep track of the ")#mi("G \\times G")#text(" action. Then it turns out that the multiplicity of ")#mi("V_{\\lambda} \\boxtimes V_{\\mu}^*")#text(" in ")#mi("\\Omega^k(G)")#text(" is ")#mi("\\dim \\mathrm{Hom}_G(\\bigwedge^k \\mathfrak{g} \\otimes V_{\\lambda}, V_{\\mu})")#text(". For example, when you look at ")#mi("SU(2)")#text(", you get")

#mi("0 \\to \\frac{1}{1-xy} \\to \\frac{x^2+y^2+xy}{1-xy} \\to \\frac{x^2+y^2+xy}{1-xy} \\to \\frac{1}{1-xy} \\to 0")#text(".")

#text("Now it is obvious that we get cohomology in degrees ")#mi("0")#text(" and ")#mi("3")#text(": There is no place for the trivial terms to go! And, if you recall that the ")#mi("G")#text("-action on ")#mi("H^*(G)")#text(" is trivial, it is obvious that all the other terms are exact.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8c2016a95d7871dcb511ae984e701ed78c8c69bcbea8aed09b3f13b3dbc827a-acbdc4f59b530120b45a1ec4380cb421d042b21bae300a1a2688683d5cfce060.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joel Moreira")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-52666")[#strong[#text("Joel Moreira")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2011")])]

#text("In the proof of proposition 6, is ")#mi("K\\in L^1")#text(" (instead of L^2) a typo or there is a reason I don’t see?")#linebreak()#text(" Also I think the ")#mi("d\\mu(g)")#text(" should be ")#mi("d\\mu(h)")#text(".")

#text("Thank you")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of van Dantzig’s theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-53231")[#strong[#text("van Dantzig’s theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2011")])]

#text("[…] (for instance, one can start analysing them using the Peter-Weyl theorem, as discussed in this previous post). The global behaviour however remains more complicated, in part because the compact open subgroup […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-53292")[#strong[#text("Laplace算子与表示论 « Fight with Infinity")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2011")]

#text("[…] Tao The Peter-Weyl theorem, and non-abelian Fourier analysis on compact groups […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hilbert’s fifth problem and Gleason metrics « What’s new")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-54021")[#strong[#text("Hilbert’s fifth problem and Gleason metrics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2011")])]

#text("[…] Theorem 5 and Theorem 6 proceed by some elementary combinatorial analysis, together with the use of Haar measure (to build convolutions, and thence to build “smooth” bump functions with which to create a metric, in a variant of the analysis used to prove the Birkhoff-Kakutani theorem); Theorem 5 also requires Peter-Weyl theorem (to dispose of certain compact subgroups that arise en route to the reduction to the NSS case), which was discussed previously on this blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3: Haar measure and the Peter-Weyl theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-85826")[#strong[#text("254A, Notes 3: Haar measure and the Peter-Weyl theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2011")])]

#text("[…] sharpest form of the theorem, as it only describes the left -action and not the right -action; see this previous blog post for a precise statement and proof of the Peter-Weyl theorem in its strongest form. This form is of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 3: Quasirandom groups, expansion, and Selberg’s 3/16 theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-116197")[#strong[#text("254B, Notes 3: Quasirandom groups, expansion, and Selberg’s 3/16 theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2011")])]

#text("[…] (which is based on the Peter-Weyl theorem combined with Schur’s lemma, and is developed in this blog post); we leave this as an exercise for the interested reader. Exercise 10 Let be subsets of a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-116206")[#strong[#text("254B, Notes 3: Quasirandom groups, expansion, and Selberg’s 3/16 theorem | t1u")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2011")]

#text("[…] (which is based on the Peter-Weyl theorem combined with Schur’s lemma, and is developed in this blog post); we leave this as an exercise for the interested […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b7ac4d8d6b90921bd17857e7d4afbbf8fc4699f6df1a9bfdb59e9f3e95dee15-c53e09183d4cbc3aaddcdd0901e816e8138dcf9c8299aa5577361e563d194cfc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of benbrawn")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-255694")[#strong[#text("benbrawn")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("Hi Terry,")#linebreak()#text(" in the statement of Theorem 1 (Peter-Weyl theorem), I think the \\oplus in the exponent is a typo. Maybe?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-255698")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("No; I use ")#mi("\\rho^{\\oplus k}")#text(" to denote the direct sum of ")#mi("k")#text(" copies of ")#mi("\\rho")#text(" (and ")#mi("\\rho^{\\otimes k}")#text(" to denote the tensor product of ")#mi("k")#text(" copies of ")#mi("\\rho")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-263114")[#strong[#text("Draft notes | alexchervov")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2014")]

#text("[…] ")#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-&#8230")[#text("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28b6abe6e330f945806803a4b897171d8295578e39967d8b5fdd04e9b7d42672-b6ab20e545b6a2a88585cc511b9f95d74808fa77e014eb9dc2df2f635a1d9259.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Group limits – Random Permutations")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-505189")[#strong[#text("Group limits – Random Permutations")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2018")])]

#text("[…] We borrow nonabelian harmonic analysis notation from Tao. Certainly we may assume that and are internal, say and . Then by nonabelian […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/89074309aa2c7459425eb7fbb3ca3b0dd107b44d4699c406931e81f57cb5419a-0147edc58cf6dfa032f1ea8e2300f3c850f1ffeb67496ac54562b5917a8ce3c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frederik vom Ende")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-518153")[#strong[#text("Frederik vom Ende")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2019")])]

#text("Dear Prof. Tao, thank you for this comprehensive and nice blog entry! At the beginning of section 2 you write that “")#mi("{g \\mapsto \\langle T, \\rho(g) \\rangle_{HS(V_\\xi)}}")#text(" can be easily seen to lie in ")#mi("{L^2(G)_\\xi}")#text("“. But—also after checking with some further literature—it seems to me that ")#mi("g \\mapsto \\langle T, (\\rho(g))^* \\rangle_{HS(V_\\xi)}=\\mathrm{tr}(\\rho(g) T)")#text(" should be correct here (or is it evident that maps of the form ")#mi("{\\overline{f_{\\xi,v,w}}}")#text(" also lie in the subspace ")#mi("{L^2(G)_\\xi})")#text("? This of course would not change anything substantial about the follow-up statements and proofs aside from handing out a few extra ")#mi("*")#text(". Kind regards")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9c6e84336f1d453e3b241e2954358ddcb2e554fc9a0fd6bc37798361d0c4e2d-23faeebf7ce7b111ec879f148457ee54d8effb18466072ee3ca747c5dced10e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Amin")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-553679")[#strong[#text("Amin")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2020")])]

#text("Dear Professor Tao,")#linebreak()#text(" Are you sure that with your convention of Fourier inverse i_ξ , it entertwinnes (L,R) with the action on operators as you defined? I think it works when the Fourier inverse maps T in HS(V_ξ ) to the function on G : Tr(T ξ(g^(-1) ) .")#linebreak()#text(" Best Regards")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-553762")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2020")])]

#text("Can you be more precise (e.g., by pointing out a specific line in the blog post that may require clarification or correction)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9c6e84336f1d453e3b241e2954358ddcb2e554fc9a0fd6bc37798361d0c4e2d-23faeebf7ce7b111ec879f148457ee54d8effb18466072ee3ca747c5dced10e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Amin")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-553858")[#strong[#text("Amin")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2020")])]

#text("Yes, it is in the part on non abelian Fourier analysis, after equation 1 :")#linebreak()#text(" “This is an isomorphism not only of Hilbert spaces, but of the left-action of {G}. Indeed, it is an isomorphism of the bi-action of {G \\times G} on both the left and right of both {L^2(G)} and {HS(V_\\xi)}, defined by…”")#linebreak()#text(" I suppose, after now looking at the comment of F. Vom Ende, that it is due to a change that you made in the function on G that you associate to an operator on a representation space (the i_ξ).")#linebreak()#text(" It’s a minor point anyway, and more importantly, thank you for sharing your insights on your blog.")

#emph[#text("[Action should be fixed now, thanks – T.>]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b31557f9ce19da00a4e230673c03e7d001fd9b1fcb92753eb8c34d3c8c36fb2-144bbb2861d07677056f45a9cf6d5bd3e005fd139d410484677adfa8f99f0bd6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leon")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-563569")[#strong[#text("Leon")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2020")])]

#text("Dear Prof. Tao,")

#text("thank you for this helpful right-up! I have two questions on Lemma 2, Schur’s Lemma for unitary representations:")

#text("1.: “Observe that any closed invariant subspace of {T^* T} is {G}-invariant”")

#text("How can we see this? If {X} is closed and invariant under {T^* T} and we look at {g \\in G}, we can deduce that {\\rho(g)X} is closed and invariant under {T^* T} as well, but I don’t see how this helps us in showing that it is a subset of {X}. Am I missing something?")

#text("2.: Does this Lemma also work if we look at representations over the real numbers, instead of the complex numbers, and replace “unitary” by “orthogonal”? After all, the constant multiple seems to be a real number, and I don’t see what else might go wrong.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-563753")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2020")])]

#text("Sorry. “invariant subspace” should be “eigenspace” here. The problem in the real case is that eigenspaces can be complex even when the operators are real and orthogonal (consider for instance a rotation matrix).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fff32c528c0b5329d661a4e6e81d43b0903bf07bcac96ff4bbbbb9b256dc464c-fc6f91dad444fe58b5a3757251d56e1777d67538dab6fa41524d74773bf650d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leon")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-563818")[#strong[#text("Leon")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2020")])]

#text("Dear Prof. Tao,")

#text("thank you for the correction!")

#text("In the real case, since we’re considering self-adjoint operators I don’t see the problem you’re stating. Assume for simplicity that we already knew that all irreducible representations were finite-dimensional. Then ")#mi("T^* T")#text(" is self-adjoint, i.e. symmetric, and thus diagonalizable over ")#mi("\\mathbb{R}")#text(". Can’t we proceed from there as in your proof and obtain the same result?")

#text("In general, I’m wondering how far we can take this and what goes wrong about Peter-Weyl in the real case. As far as I can see, the only thing that goes wrong is that we can’t conclude that the multiplicity of each irreducible representation equals its dimension, but the basic decomposition of the regular representation into irreducible representations should hold.")

#text("Best wishes,")#linebreak()#text(" Leon")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-564129")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2020")])]

#text("Ah, I see now where things are hiding. Lemma 2 is true in the real case as well, but when applied to equivariant maps of an irrep ")#mi("H")#text(" to itself only gives an orthogonal map on ")#mi("H")#text(", not a constant multiple of the identity. In the complex case the only unitary equivariant maps on ")#mi("H")#text(" are multiples of the identity because of the spectral theorem (any non-trivial eigenspace would break irreducibility), but in the real case one can have non-trivial orthogonal equivariant maps (e.g. consider the tautological orthogonal rep of ")#mi("SO(2)")#text(" on ")#mi("{\\bf R}^2")#text(", which is irreducible but has all the rotations as equivariant orthogonal maps).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-594485")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2020")])]

#text("I think there’s still something wrong with your proof of Schur’s lemma (Lemma 2). Why do you speak of eigenspaces? It may happen that a bounded linear operator on a Hilbert space has no eigenvalues (so no eigenspaces), but is not a constant multiple of the identity.")

#text("I think you rather mean spectral subspaces, and the argument may be like this: suppose that the spectrum of ")#mi("T^*T")#text(" is not a point, then it can be decomposed as a union of two non-empty Borel subsets. Consider the orthogonal projector ")#mi("P")#text(" onto the spectral subspace corresponding to one of them; it is a Borel function of ")#mi("T^*T")#text(", so it commutes with all operators of the representation as well as ")#mi("T^*T")#text(" (because 1. polynomials in ")#mi("T^*T")#text(" commute with the representation operators, 2. continuous functions can be approximated by polynomials, and 3. indicator functions can be approximated by continuous functions). Now this implies that the corresponding spectral subspace is ")#mi("G")#text("-invariant, so the representation is reducible.")

#text("Or maybe I am missing something and there is a simpler proof?")

#emph[#text("[“Eigenspace” changed to “invariant space” – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/12f0f1b16acf39bd0794aac4a04f7dc422952ce02f0260c92307cc7a9a5f9213-7481f98591322244eeb71739b78c23666fbfbc2f355049cb6ec8cb104c826e04.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leon Lang")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-597922")[#strong[#text("Leon Lang")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2020")])]

#text("Thanks again for the article!")

#text("It helped me to figure out a version of the Peter-Weyl Theorem for real representations (which has all the properties except that the multiplicity of the irreps can be smaller than their dimension).")

#text("We have used this to prove a “Wigner-Eckart Theorem” for equivariant convolution kernels in deep learning, which allows to parameterize these kernels for arbitrary compact groups and their homogeneous spaces:")

#link("https://arxiv.org/abs/2010.10952")[#text("https://arxiv.org/abs/2010.10952")]

#text("Originally, the Wigner-Eckart Theorem is used to figure out the degrees of freedom of spherical tensor operators:")

#link("https://en.wikipedia.org/wiki/Wigner%E2%80%93Eckart_theorem")[#text("https://en.wikipedia.org/wiki/Wigner%E2%80%93Eckart_theorem")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37920acd89b4a6f6c3959029580b54c6b8527e7a718d8ec8be07663aa3fe35fd-b9465dbafe1d26f5a2bb7440584cbfdc96669436f68e7b7937306ca436b290c0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-686987")[#strong[#text("Alexander")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2025")])]

#text("Can Carleson’s theorem be generalized to non-Abelian compact groups?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/#comment-686988")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2025")])]

#text("Actually it is quite challenging to even properly formulate Carleson’s theorem beyond the one-dimensional setting, because the theorem implicitly requires some ordering on the space of frequencies in order to define a partial Fourier series or partial Fourier integral. For instance, on the two-torus, Carleson’s theorem is true if one sums over squares, false if one sums over rectangles, and open if one sums over disks; see Sections 9.7, 9.8 of ")#link("https://arxiv.org/abs/math/0307008")[#text("this survey of Lacey")]#text(". Given the unsettled state of affairs even in this simple case, it is probably premature to consider non-abelian groups (other than to look for counterexamples).")
]
]
