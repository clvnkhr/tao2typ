// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:36:39.440297+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 3: Haar measure and the Peter-Weyl theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 3: Haar measure and the Peter-Weyl theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 September 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/")[#text("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the ")#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")[#text("last")]#text(" ")#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/")[#text("few notes")]#text(", we have been steadily reducing the amount of regularity needed on a topological group in order to be able to show that it is in fact a Lie group, in the spirit of ")#link("http://en.wikipedia.org/wiki/Hilbert's_fifth_problem")[#text("Hilbert’s fifth problem")]#text(". Now, we will work on Hilbert’s fifth problem from the other end, starting with the minimal assumption of ")#link("http://en.wikipedia.org/wiki/Locally_compact_group")[#text("local compactness")]#text(" on a topological group ")#mi("{G}")#text(", and seeing what kind of structures one can build using this assumption. (For simplicity we shall mostly confine our discussion to global groups rather than local groups for now.) In view of the preceding notes, we would like to see two types of structures emerge in particular:")

#list(
[#emph[#text("representations")]#text(" of ")#mi("{G}")#text(" into some more structured group, such as a matrix group ")#mi("{GL_n({\\bf C})}")#text("; and")],
[#emph[#text("metrics")]#text(" on ")#mi("{G}")#text(" that capture the escape and commutator structure of ")#mi("{G}")#text(" (i.e. Gleason metrics).")]
)

#text("To build either of these structures, a fundamentally useful tool is that of (left-) ")#link("http://en.wikipedia.org/wiki/Haar_measure")[#text("Haar measure")]#text(" – a left-invariant ")#link("http://en.wikipedia.org/wiki/Radon_measure")[#text("Radon measure")]#text(" ")#mi("{\\mu}")#text(" on ")#mi("{G}")#text(". (One can of course also consider right-Haar measures; in many cases (such as for compact or abelian groups), the two concepts are the same, but this is not always the case.) This concept generalises the concept of ")#link("http://en.wikipedia.org/wiki/Lebesgue_measure")[#text("Lebesgue measure")]#text(" on Euclidean spaces ")#mi("{{\\bf R}^d}")#text(", which is of course fundamental in analysis on those spaces.")

#text("Haar measures will help us build useful representations and useful metrics on locally compact groups ")#mi("{G}")#text(". For instance, a Haar measure ")#mi("{\\mu}")#text(" gives rise to the ")#link("http://en.wikipedia.org/wiki/Regular_representation")[#text("regular representation")]#text(" ")#mi("{\\tau: G \\rightarrow U(L^2(G,d\\mu))}")#text(" that maps each element ")#mi("{g \\in G}")#text(" of ")#mi("{G}")#text(" to the unitary translation operator ")#mi("{\\rho(g): L^2(G,d\\mu) \\rightarrow L^2(G,d\\mu)}")#text(" on the Hilbert space ")#mi("{L^2(G,d\\mu)}")#text(" of square-integrable measurable functions on ")#mi("{G}")#text(" with respect to this Haar measure by the formula")

#align(center)[#tao-fit-display[#mitex("\\tau(g) f(x) := f(g^{-1} x).")]]

#text("(The presence of the inverse ")#mi("{g^{-1}}")#text(" is convenient in order to obtain the homomorphism property ")#mi("{\\tau(gh) = \\tau(g)\\tau(h)}")#text(" without a reversal in the group multiplication.) In general, this is an infinite-dimensional representation; but in many cases (and in particular, in the case when ")#mi("{G}")#text(" is compact) we can decompose this representation into a useful collection of finite-dimensional representations, leading to the ")#link("http://en.wikipedia.org/wiki/Peter%E2%80%93Weyl_theorem")[#text("Peter-Weyl theorem")]#text(", which is a fundamental tool for understanding the structure of compact groups. This theorem is particularly simple in the compact abelian case, where it turns out that the representations can be decomposed into one-dimensional representations ")#mi("{\\chi: G \\rightarrow U({\\bf C}) \\equiv S^1}")#text(", better known as ")#link("http://en.wikipedia.org/wiki/Character_(mathematics)")[#text("characters")]#text(", leading to the theory of Fourier analysis on general compact abelian groups. With this and some additional (largely combinatorial) arguments, we will also be able to obtain satisfactory structural control on locally compact abelian groups as well.")

#text("The link between Haar measure and useful metrics on ")#mi("{G}")#text(" is a little more complicated. Firstly, once one has the regular representation ")#mi("{\\tau: G\\rightarrow U(L^2(G,d\\mu))}")#text(", and given a suitable “test” function ")#mi("{\\psi: G \\rightarrow {\\bf C}}")#text(", one can then embed ")#mi("{G}")#text(" into ")#mi("{L^2(G,d\\mu)}")#text(" (or into other function spaces on ")#mi("{G}")#text(", such as ")#mi("{C_c(G)}")#text(" or ")#mi("{L^\\infty(G)}")#text(") by mapping a group element ")#mi("{g \\in G}")#text(" to the translate ")#mi("{\\tau(g) \\psi}")#text(" of ")#mi("{\\psi}")#text(" in that function space. (This map might not actually be an embedding if ")#mi("{\\psi}")#text(" enjoys a non-trivial translation symmetry ")#mi("{\\tau(g)\\psi=\\psi}")#text(", but let us ignore this possibility for now.) One can then pull the metric structure on the function space back to a metric on ")#mi("{G}")#text(", for instance defining an ")#mi("{L^2(G,d\\mu)}")#text("-based metric")

#align(center)[#tao-fit-display[#tao-math("d(g,h) := \\left\\| \\tau(g) \\psi - \\tau(h) \\psi \\right\\|_{L^2(G,d\\mu)}", block: true)]]

#text("if ")#mi("{\\psi}")#text(" is square-integrable, or perhaps a ")#mi("{C_c(G)}")#text("-based metric ")#metadata(none) <tao-c02cac674c8edc980fab>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("d(g,h) := \\left\\| \\tau(g) \\psi - \\tau(h) \\psi \\right\\|_{C_c(G)}", block: true)]]



#text(" if ")#mi("{\\psi}")#text(" is continuous and compactly supported (with ")#tao-math("{\\left\\|f \\right\\|_{C_c(G)} := \\sup_{x \\in G} \\left|f(x)\\right|}", block: false)#text(" denoting the supremum norm). These metrics tend to have several nice properties (for instance, they are automatically left-invariant), particularly if the test function is chosen to be sufficiently “smooth”. For instance, if we introduce the differentiation (or more precisely, finite difference) operators")

#align(center)[#tao-fit-display[#mitex("\\partial_g := 1-\\tau(g)")]]

#text("(so that ")#mi("{\\partial_g f(x) = f(x) - f(g^{-1} x)}")#text(") and use the metric ")#link(<tao-c02cac674c8edc980fab>)[#text("(1)")]#text(", then a short computation (relying on the translation-invariance of the ")#mi("{C_c(G)}")#text(" norm) shows that")

#align(center)[#tao-fit-display[#tao-math("d([g,h], \\text{id}) = \\left\\| \\partial_g \\partial_h \\psi - \\partial_h \\partial_g \\psi \\right\\|_{C_c(G)}", block: true)]]

#text("for all ")#mi("{g,h \\in G}")#text(". This suggests that commutator estimates, such as those appearing in the definition of a Gleason metric in ")#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/")[#text("Notes 2")]#text(", might be available if one can control “second derivatives” of ")#mi("{\\psi}")#text("; informally, we would like our test functions ")#mi("{\\psi}")#text(" to have a “")#mi("{C^{1,1}}")#text("” type regularity.")

#text("If ")#mi("{G}")#text(" was already a Lie group (or something similar, such as a ")#mi("{C^{1,1}}")#text(" local group) then it would not be too difficult to concoct such a function ")#mi("{\\psi}")#text(" by using local coordinates. But of course the whole point of Hilbert’s fifth problem is to do without such regularity hypotheses, and so we need to build ")#mi("{C^{1,1}}")#text(" test functions ")#mi("{\\psi}")#text(" by other means. And here is where the Haar measure comes in: it provides the fundamental tool of ")#link("http://en.wikipedia.org/wiki/Convolution")[#text("convolution")]

#align(center)[#tao-fit-display[#mitex("\\phi * \\psi(x) := \\int_G \\phi(y) \\psi(y^{-1}x) d\\mu(y)")]]

#text("between two suitable functions ")#mi("{\\phi, \\psi: G \\rightarrow {\\bf C}}")#text(", which can be used to build smoother functions out of rougher ones. For instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Let ")#mi("{\\phi, \\psi: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be continuous, compactly supported functions which are Lipschitz continuous. Show that the convolution ")#mi("{\\phi * \\psi}")#text(" using Lebesgue measure on ")#mi("{{\\bf R}^d}")#text(" obeys the ")#mi("{C^{1,1}}")#text("-type commutator estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\partial_g \\partial_h (\\phi * \\psi) \\right\\|_{C_c({\\bf R}^d)} \\leq C \\left\\|g\\right\\| \\left\\|h\\right\\|", block: true)]]

#text("for all ")#mi("{g,h \\in {\\bf R}^d}")#text(" and some finite quantity ")#mi("{C}")#text(" depending only on ")#mi("{\\phi, \\psi}")#text(".")
]

#text("This exercise suggests a strategy to build Gleason metrics by convolving together some “Lipschitz” test functions and then using the resulting convolution as a test function to define a metric. This strategy may seem somewhat circular because one needs a notion of metric in order to define Lipschitz continuity in the first place, but it turns out that the properties required on that metric are weaker than those that the Gleason metric will satisfy, and so one will be able to break the circularity by using a “bootstrap” or “induction” argument.")

#text("We will discuss this strategy – which is due to Gleason, and is fundamental to all currently known solutions to Hilbert’s fifth problem – in later posts. In this post, we will construct Haar measure on general locally compact groups, and then establish the Peter-Weyl theorem, which in turn can be used to obtain a reasonably satisfactory structural classification of both compact groups and locally compact abelian groups.")

#metadata(none) <tao-6167c976d8d4706c295f>

#heading(level: 1)[#strong[#text(" — 1. Haar measure — ")]]

#text("For technical reasons, it is convenient to not work with an absolutely general locally compact group, but to restrict attention to those groups that are both ")#link("http://en.wikipedia.org/wiki/%CE%A3-compact_space")[#mi("{\\sigma}")#text("-compact")]#text(" and ")#link("http://en.wikipedia.org/wiki/Hausdorff_space")[#text("Hausdorff")]#text(", in order to access measure-theoretic tools such as the ")#link("http://en.wikipedia.org/wiki/Fubini%27s_theorem")[#text("Fubini-Tonelli theorem")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem")[#text("Riesz representation theorem")]#text(" without bumping into unwanted technical difficulties. Intuitively, ")#mi("{\\sigma}")#text("-compact groups are those groups that do not have enormously “large” scales – scales are too coarse to be “seen” by any compact set. Similarly, Hausdorff groups are those groups that do not have enormously “small” scales – scales that are too small to be “seen” by any open set. A simple example of a locally compact group that fails to be ")#mi("{\\sigma}")#text("-compact is the real line ")#mi("{{\\bf R} = ({\\bf R},+)}")#text(" with the discrete topology; conversely, a simple example of a locally compact group that fails to be Hausdorff is the real line ")#mi("{{\\bf R}}")#text(" with the trivial topology.")

#text("As the two exercises below show, one can reduce to the ")#mi("{\\sigma}")#text("-compact Hausdorff case without much difficulty, either by restricting to an open subgroup to eliminate the largest scales and recover ")#mi("{\\sigma}")#text("-compactness, or to quotient out by a compact normal subgroup to eliminate the smallest scales and recover the Hausdorff property.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Let ")#mi("{G}")#text(" be a locally compact group. Show that there exists an open subgroup ")#mi("{G_0}")#text(" which is locally compact and ")#mi("{\\sigma}")#text("-compact. (")#emph[#text("Hint:")]#text(" take the group generated by a compact neighbourhood of the identity.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" ")#metadata(none) <tao-c5375f9278b18d2308ed>#text(" Let ")#mi("{G}")#text(" be a locally compact group. Let ")#mi("{H = \\overline{\\{\\text{id}\\}}}")#text(" be the topological closure of the identity element.")

#enum(start: 1, 
[#text("(i) Show that given any open neighbourhood ")#mi("{U}")#text(" of a point ")#mi("{x}")#text(" in ")#mi("{G}")#text(", there exists a neighbourhood ")#mi("{V}")#text(" of ")#mi("{x}")#text(" whose closure lies in ")#mi("{U}")#text(". (")#emph[#text("Hint:")]#text(" translate ")#mi("{x}")#text(" to the identity and select ")#mi("{V}")#text(" so that ")#mi("{V^2 \\subset U}")#text(".) In other words, ")#mi("{G}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Regular_space")[#text("regular space")]#text(".")],
[#text("(ii) Show that for any group element ")#mi("{g \\in G}")#text(", that the sets ")#mi("{gH}")#text(" and ")#mi("{H}")#text(" are either equal or disjoint.")],
[#text("(iii) Show that ")#mi("{H}")#text(" is a compact normal subgroup of ")#mi("{G}")#text(".")],
[#text("(iv) Show that the quotient group ")#mi("{G/H}")#text(" (equipped with the quotient topology) is a locally compact Hausdorff group.")],
[#text("(v) Show that a subset of ")#mi("{G}")#text(" is open if and only if it is the preimage of an open set in ")#mi("{G/H}")#text(".")]
)
]

#text("Now that we have restricted attention to the ")#mi("{\\sigma}")#text("-compact Hausdorff case, we can now define the notion of a Haar measure.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Radon measure)")]#text(" Let ")#mi("{X}")#text(" be a ")#mi("{\\sigma}")#text("-compact locally compact Hausdorff topological space. The ")#link("http://en.wikipedia.org/wiki/Borel_set")[#text("Borel ")#mi("{\\sigma}")#text("-algebra")]#text(" ")#mi("{{\\mathcal B}[X]}")#text(" on ")#mi("{X}")#text(" is the ")#mi("{\\sigma}")#text("-algebra generated by the open subsets of ")#mi("{X}")#text(". A ")#link("http://en.wikipedia.org/wiki/Borel_measure")[#text("Borel measure")]#text(" is a countably additive non-negative measure ")#mi("{\\mu: {\\mathcal B}[X] \\rightarrow [0,+\\infty]}")#text(" on the Borel ")#mi("{\\sigma}")#text("-algebra. A ")#link("http://en.wikipedia.org/wiki/Radon_measure")[#text("Radon measure")]#text(" is a Borel measure obeying three additional axioms:")

#enum(start: 1, 
[#text("(i) (Local finiteness) One has ")#mi("{\\mu(K) < \\infty}")#text(" for every compact set ")#mi("{K}")#text(".")],
[#text("(ii) (Inner regularity) One has ")#mi("{\\mu(E) = \\sup_{K \\subset E, K \\text{ compact}} \\mu(K)}")#text(" for every Borel measurable set ")#mi("{E}")#text(".")],
[#text("(iii) (Outer regularity) One has ")#mi("{\\mu(E) = \\inf_{U \\supset E, U \\text{ open}} \\mu(U)}")#text(" for every Borel measurable set ")#mi("{E}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2 (Haar measure)")]#text(" Let ")#mi("{G = (G,\\cdot)}")#text(" be a ")#mi("{\\sigma}")#text("-compact locally compact Hausdorff group. A Radon measure ")#mi("{\\mu}")#text(" is ")#emph[#text("left-invariant")]#text(" (resp. ")#emph[#text("right-invariant")]#text(") if one has ")#mi("{\\mu(gE) = \\mu(E)}")#text(" (resp. ")#mi("{\\mu(Eg) = \\mu(E)}")#text(") for all ")#mi("{g \\in G}")#text(" and Borel measurable sets ")#mi("{E}")#text(". A ")#emph[#text("left-invariant Haar measure")]#text(" is a non-zero Radon measure which is left-invariant; a right-invariant Haar measure is defined similarly. A ")#emph[#text("bi-invariant Haar measure")]#text(" is a Haar measure which is both left-invariant and right-invariant.")
]

#text("Note that we do not consider the zero measure to be a Haar measure.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" A large part of the foundations of Lebesgue measure theory (e.g. most of ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("these lecture notes of mine")]#text(") can be summed up in the single statement that Lebesgue measure is a (bi-invariant) Haar measure on Euclidean spaces ")#mi("{{\\bf R}^d = ({\\bf R}^d,+)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" If ")#mi("{G}")#text(" is a countable discrete group, then ")#link("http://en.wikipedia.org/wiki/Counting_measure")[#text("counting measure")]#text(" is a bi-invariant Haar measure.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" ")#metadata(none) <tao-4e448897946ead9e39e8>#text(" If ")#mi("{\\mu}")#text(" is a left-invariant Haar measure on a ")#mi("{\\sigma}")#text("-compact locally compact Hausdorff group ")#mi("{G}")#text(", then the reflection ")#mi("{\\tilde \\mu}")#text(" defined by ")#mi("{\\tilde \\mu(E) := \\mu(E^{-1})}")#text(" is a right-invariant Haar measure on ")#mi("{G}")#text(", and the scalar multiple ")#mi("{\\lambda \\mu}")#text(" is a left-invariant Haar measure on ")#mi("{G}")#text(" for any ")#mi("{0 < \\lambda < \\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" ")#metadata(none) <tao-fa62ec8bdf57acae92fc>#text(" If ")#mi("{\\mu}")#text(" is a left-invariant Haar measure on a ")#mi("{\\sigma}")#text("-compact locally compact Hausdorff group ")#mi("{G}")#text(", show that ")#mi("{\\mu(U) > 0}")#text(" for any non-empty open set ")#mi("{U}")#text(".")
]

#text("Let ")#mi("{\\mu}")#text(" be a left-invariant Haar measure on a ")#mi("{\\sigma}")#text("-compact locally compact Hausdorff group. Let ")#mi("{C_c(G)}")#text(" be the space of all continuous, compactly supported complex-valued functions ")#mi("{f: G \\rightarrow {\\bf C}}")#text("; then ")#mi("{f}")#text(" is absolutely integrable with respect to ")#mi("{\\mu}")#text(" (thanks to local finiteness), and one has")

#align(center)[#tao-fit-display[#mitex("\\int_G f(gx)\\ d\\mu(x) = \\int_G f(x)\\ dx")]]

#text("for all ")#mi("{g \\in G}")#text(" (thanks to left-invariance). Similarly for right-invariant Haar measures (but now replacing ")#mi("{gx}")#text(" by ")#mi("{xg}")#text(").")

#text("The fundamental theorem regarding Haar measures is:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Existence and uniqueness of Haar measure)")]#text(" ")#metadata(none) <tao-aff67f3419aedcabf966>#text(" Let ")#mi("{G}")#text(" be a ")#mi("{\\sigma}")#text("-compact locally compact Hausdorff group. Then there exists a left-invariant Haar measure ")#mi("{\\mu}")#text(" on ")#mi("{G}")#text(". Furthermore, this measure is unique up to scalars: if ")#mi("{\\mu, \\nu}")#text(" are two left-invariant Haar measures on ")#mi("{G}")#text(", then ")#mi("{\\nu = \\lambda \\mu}")#text(" for some scalar ")#mi("{\\lambda>0}")#text(".")

#text("Similarly if “left-invariant” is replaced by “right-invariant” throughout. (However, we do ")#emph[#text("not")]#text(" claim that every left-invariant Haar measure is automatically right-invariant, or vice versa.)")
]

#text("To prove this theorem, we will rely on the ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem")[#text("Riesz representation theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Riesz representation theorem)")]#text(" Let ")#mi("{X}")#text(" be a ")#mi("{\\sigma}")#text("-compact locally compact Hausdorff space. Then to every linear functional ")#mi("{I: C_c(X) \\rightarrow {\\bf R}}")#text(" which is non-negative (thus ")#mi("{I(f) \\geq 0}")#text(" whenever ")#mi("{f \\geq 0}")#text("), one can associate a unique Radon measure ")#mi("{\\mu}")#text(" such that ")#mi("{I(f) = \\int_X f\\ d\\mu}")#text(" for all ")#mi("{f \\in C_c(X)}")#text(". Conversely, for each Radon measure ")#mi("{\\mu}")#text(", the functional ")#mi("{I_\\mu: f \\mapsto \\int_X f\\ d\\mu}")#text(" is a non-negative linear functional on ")#mi("{C_c(X)}")#text(".")
]

#text("We now establish the uniqueness component of Theorem ")#link(<tao-aff67f3419aedcabf966>)[#text("3")]#text(". We shall just prove the uniqueness of left-invariant Haar measure, as the right-invariant case is similar (and also follows from the left-invariant case by Example ")#link(<tao-4e448897946ead9e39e8>)[#text("3")]#text("). Let ")#mi("{\\mu, \\nu}")#text(" be two left-invariant Haar measures on ")#mi("{G}")#text(". We need to prove that ")#mi("{\\nu}")#text(" is a scalar multiple of ")#mi("{\\mu}")#text(". From the Riesz representation theorem, it suffices to show that ")#mi("{I_\\nu}")#text(" is a scalar multiple of ")#mi("{I_\\mu}")#text(". Equivalently, it suffices to show that")

#align(center)[#tao-fit-display[#mitex("I_\\nu(f) I_\\mu(g) = I_\\mu(f) I_\\nu(g)")]]

#text("for all ")#mi("{f, g \\in C_c(G)}")#text(".")

#text("To show this, the idea is to approximate both ")#mi("{f}")#text(" and ")#mi("{g}")#text(" by superpositions of translates of the same function ")#mi("{\\psi_\\epsilon}")#text(". More precisely, fix ")#mi("{f, g \\in C_c(G)}")#text(", and let ")#mi("{\\epsilon > 0}")#text(". As the functions ")#mi("{f}")#text(" and ")#mi("{g}")#text(" are continuous and compactly supported, they are uniformly continuous, in the sense that we can find an open neighbourhood ")#mi("{U_\\epsilon}")#text(" of the identity such that ")#tao-math("{\\left|f(xy)-f(x)\\right| \\leq \\epsilon}", block: false)#text(" and ")#tao-math("{\\left|g(xy)-g(x)\\right| \\leq \\epsilon}", block: false)#text(" for all ")#mi("{x \\in G}")#text(" and ")#mi("{y \\in U_\\epsilon}")#text("; we may also assume that the ")#mi("{U_\\epsilon}")#text(" are contained in a compact set that is uniform in ")#mi("{\\epsilon}")#text(". By Exercise ")#link(<tao-fa62ec8bdf57acae92fc>)[#text("4")]#text(" and Urysohn’s lemma, we can then find an “approximation to the identity” ")#mi("{\\psi_\\epsilon \\in C_c(U)}")#text(" supported in ")#mi("{U}")#text(" such that ")#mi("{\\int_G \\psi_\\epsilon(y)\\ d\\mu(y) = 1}")#text(". Since")

#align(center)[#tao-fit-display[#mitex("f(xy) = f(x) + O(\\epsilon)")]]

#text("for all ")#mi("{y}")#text(" in the support of ")#mi("{\\psi}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_G f(xy) \\psi_\\epsilon(y)\\ d\\mu(y) = f(x) + O(\\epsilon)")]]

#text("uniformly in ")#mi("{x \\in G}")#text("; also, the left-hand side has uniformly compact support in ")#mi("{\\epsilon}")#text(". If we integrate against ")#mi("{\\nu}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_G \\int_G f(xy) \\psi_\\epsilon(y)\\ d\\mu(y) d\\nu(x) = I_\\nu(f) + O(\\epsilon)")]]

#text("where the implied constant in the ")#mi("{O()}")#text(" notation can depend on ")#mi("{\\mu, \\nu, f, g}")#text(" but not on ")#mi("{\\epsilon}")#text(". But by the left-invariance of ")#mi("{\\mu}")#text(", the left-hand side is also")

#align(center)[#tao-fit-display[#mitex("\\int_G \\int_G f(y) \\psi_\\epsilon(x^{-1} y)\\ d\\mu(y) d\\nu(x)")]]

#text("which by the Fubini-Tonelli theorem is")

#align(center)[#tao-fit-display[#mitex("\\int_G f(y) (\\int_G \\psi_\\epsilon(x^{-1} y)\\ d\\nu(x))\\ d\\mu(y)")]]

#text("which by the left-invariance of ")#mi("{\\nu}")#text(" is")

#align(center)[#tao-fit-display[#mitex("\\int_G f(y) (\\int_G \\psi_\\epsilon(x^{-1})\\ d\\nu(x))\\ d\\mu(y)")]]

#text("which simplifies to ")#mi("{I_\\mu(f) \\int_G \\psi_\\epsilon(x^{-1})\\ d\\nu(x)}")#text(". We conclude that")

#align(center)[#tao-fit-display[#mitex("I_\\nu(f) = I_\\mu(f) \\int_G \\psi_\\epsilon(x^{-1})\\ d\\nu(x) + O(\\epsilon)")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("I_\\nu(g) = I_\\mu(g) \\int_G \\psi_\\epsilon(x^{-1})\\ d\\nu(x) + O(\\epsilon)")]]

#text("which implies that")

#align(center)[#tao-fit-display[#mitex("I_\\nu(f) I_\\mu(g) - I_\\mu(f) I_\\nu(g) = O(\\epsilon).")]]

#text("Sending ")#mi("{\\epsilon \\rightarrow 0}")#text(" we obtain the claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Obtain another proof of uniqueness of Haar measure by investigating the translation-invariance properties of the Radon-Nikodym derivative ")#mi("{\\frac{d \\mu}{d(\\mu+\\nu)}}")#text(" of ")#mi("{\\mu}")#text(" with respect to ")#mi("{\\mu+\\nu}")#text(".")
]

#text("Now we show existence of Haar measure. Again, we restrict attention to the left-invariant case (using Example ")#link(<tao-4e448897946ead9e39e8>)[#text("3")]#text(" if desired). By the Riesz representation theorem, it suffices to find a functional ")#mi("{I: C_c(G)^+ \\rightarrow {\\bf R}^+}")#text(" from the space ")#mi("{C_c(G)^+}")#text(" of non-negative continuous compactly supported functions to the non-negative reals obeying the following axioms:")

#list(
[#text("(Homogeneity) ")#mi("{I(\\lambda f) = \\lambda I(f)}")#text(" for all ")#mi("{\\lambda>0}")#text(" and ")#mi("{f \\in C_c(G)^+}")#text(".")],
[#text("(Additivity) ")#mi("{I(f+g) = I(f)+I(g)}")#text(" for all ")#mi("{f,g \\in C_c(G)^+}")#text(".")],
[#text("(Left-invariance) ")#mi("{I(\\tau(x) f) = I(f)}")#text(" for all ")#mi("{f \\in C_c(G)^+}")#text(" and ")#mi("{x \\in G}")#text(".")],
[#text("(Non-degeneracy) ")#mi("{I(f_0) > 0}")#text(" for at least one ")#mi("{f_0 \\in C_c(G)^+}")#text(".")]
)

#text("Here, ")#mi("{\\tau(x)}")#text(" is the translation operation ")#mi("{\\tau(x) f(y) := f(x^{-1} y)}")#text(" as discussed in the introduction.")

#text("We will construct this functional by an approximation argument. Specifically, we fix a non-zero ")#mi("{f_0 \\in C_c(G)^+}")#text(". We will show that given any finite number of functions ")#mi("{f_1,\\ldots,f_n \\in C_c(G)^+}")#text(" and any ")#mi("{\\epsilon>0}")#text(", one can find a functional ")#mi("{I = I_{f_1,\\ldots,f_n,\\epsilon}: C_c(G)^+ \\rightarrow {\\bf R}^+}")#text(" that obeys the following axioms:")

#list(
[#text("(Homogeneity) ")#mi("{I(\\lambda f) = \\lambda I(f)}")#text(" for all ")#mi("{\\lambda>0}")#text(" and ")#mi("{f \\in C_c(G)^+}")#text(".")],
[#text("(Approximate additivity) ")#tao-math("{\\left|I(f_i+f_j) - I(f_i)- I(f_j)\\right| \\leq \\epsilon}", block: false)#text(" for all ")#mi("{1 \\leq i,j \\leq n}")#text(".")],
[#text("(Left-invariance) ")#mi("{I(\\tau(x) f) = I(f)}")#text(" for all ")#mi("{f \\in C_c(G)^+}")#text(" and ")#mi("{x \\in G}")#text(".")],
[#text("(Uniform bound) For each ")#mi("{f \\in C_c(G)^+}")#text(", we have ")#mi("{I(f) \\leq K(f)}")#text(", where ")#mi("{K(f)}")#text(" does not depend on ")#mi("{f_1,\\ldots,f_n}")#text(" or ")#mi("{\\epsilon}")#text(".")],
[#text("(Normalisation) ")#mi("{I(f_0) = 1}")#text(".")]
)

#text("Once one has established the existence of these approximately additive functionals ")#mi("{I_{f_1,\\ldots,f_n,\\epsilon}}")#text(", one can then construct the genuinely additive functional ")#mi("{I}")#text(" (and thus a left-invariant Haar measure) by a number of standard compactness arguments. For instance:")

#list(
[#text("One can observe (from ")#link("http://en.wikipedia.org/wiki/Tychonoff%27s_theorem")[#text("Tychonoff’s theorem")]#text(") that the space of all functionals ")#mi("{I: C_c(G)^+ \\rightarrow {\\bf R}^+}")#text(" obeying the uniform bound ")#mi("{I(f) \\leq K(f)}")#text(" is a compact subset of the product space ")#mi("{({\\bf R}^+)^{C_c(G)^+}}")#text("; in particular, any collection of closed sets in this space obeying the ")#link("http://en.wikipedia.org/wiki/Finite_intersection_property")[#text("finite intersection property")]#text(" has non-empty intersection. Applying this fact to the closed sets ")#mi("{F_{f_1,\\ldots,f_n,\\epsilon}}")#text(" of functionals obeying the homogeneity, approximate additivity, left-invariance, uniform bound, and normalisation axioms for various ")#mi("{f_1,\\ldots,f_n,\\epsilon}")#text(", we conclude that there is a functional ")#mi("{I}")#text(" that lies in all such sets, giving the claim.")],
[#text("If one lets ")#mi("{{\\mathcal C}}")#text(" be the space of all tuples ")#mi("{(f_1,\\ldots,f_n,\\epsilon)}")#text(", one can use the ")#link("http://en.wikipedia.org/wiki/Hahn-Banach_theorem")[#text("Hahn-Banach theorem")]#text(" to construct a bounded real linear functional ")#mi("{\\lambda: \\ell^\\infty({\\mathcal C}) \\rightarrow {\\bf R}}")#text(" that maps the constant sequence ")#mi("{1}")#text(" to ")#mi("{1}")#text(". If one then applies this functional to the ")#mi("{I_{f_1,\\ldots,f_n,\\epsilon}}")#text(" one can obtain a functional ")#mi("{I}")#text(" with the required properties.")],
[#text("One can also adopt a ")#link("http://en.wikipedia.org/wiki/Nonstandard_analysis")[#text("nonstandard analysis")]#text(" approach, taking an ultralimit of all the ")#mi("{I_{f_1,\\ldots,f_n,\\epsilon}}")#text(" and then taking a standard part to recover ")#mi("{I}")#text(".")],
[#text("A closely related method is to obtain ")#mi("{I}")#text(" from the ")#mi("{I_{f_1,\\ldots,f_n,\\epsilon}}")#text(" by using the ")#link("http://en.wikipedia.org/wiki/Compactness_theorem")[#text("compactness theorem")]#text(" in logic.")],
[#text("In the case when ")#mi("{G}")#text(" is metrisable (and hence ")#link("http://en.wikipedia.org/wiki/Separable_space")[#text("separable")]#text(", by ")#mi("{\\sigma}")#text("-compactness), then ")#mi("{C_c(G)}")#text(" becomes separable, and one can also use the ")#link("http://en.wikipedia.org/wiki/Arzel%C3%A0%E2%80%93Ascoli_theorem")[#text("Arzelá-Ascoli theorem")]#text(" in this case. (One can also try in this case to directly ensure that the ")#mi("{I_{f_1,\\ldots,f_n,\\epsilon}}")#text(" converge pointwise, without needing to pass to a further subsequence, although this requires more effort than the compactness-based methods.)")]
)

#text("These approaches are more or less equivalent to each other, and the choice of which approach to use is largely a matter of personal taste.")

#text("It remains to obtain the approximate functionals ")#mi("{I_{f_1,\\ldots,f_n,\\epsilon}}")#text(" for a given ")#mi("{f_0,f_1,\\ldots,f_n}")#text(" and ")#mi("{\\epsilon}")#text(". As with the uniqueness claim, the basic idea is to approximate all the functions ")#mi("{f_0,f_1,\\ldots,f_n}")#text(" by translates ")#mi("{\\tau(y) \\psi}")#text(" of a given function ")#mi("{\\psi}")#text(". More precisely, let ")#mi("{\\delta > 0}")#text(" be a small quantity (depending on ")#mi("{f_0,f_1,\\ldots,f_n}")#text(" and ")#mi("{\\epsilon}")#text(") to be chosen later. By uniform continuity, we may find a neighbourhood ")#mi("{U}")#text(" of the identity such that ")#mi("{f_i(xy) = f_i(x) + O(\\delta)}")#text(" for all ")#mi("{x \\in G}")#text(" and ")#mi("{y \\in U}")#text(". Let ")#mi("{\\psi \\in C_c(G)^+}")#text(" be a function, not identically zero, which is supported in ")#mi("{U}")#text(".")

#text("To motivate the argument that follows, pretend temporarily that we have a left-invariant Haar measure ")#mi("{\\mu}")#text(" available, and let ")#mi("{\\kappa := \\int_G \\psi\\ d\\mu}")#text(" be the integral of ")#mi("{\\psi}")#text(" with respect to this measure. Then ")#mi("{0 < \\kappa < \\infty}")#text(", and by left-invariance one has")

#align(center)[#tao-fit-display[#mitex("\\int_G \\tau(y) \\psi(x)\\ d\\mu(x) = \\kappa,")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\int_G \\sum_{k=1}^K c_k \\tau(y_k) \\psi(x)\\ d\\mu = \\kappa \\sum_{k=1}^K c_k")]]

#text("for any scalars ")#mi("{c_1,\\ldots,c_K \\in {\\bf R}^+}")#text(" and ")#mi("{y_1,\\ldots,y_K \\in G}")#text(". In particular, if we introduce the ")#emph[#text("covering number")]

#align(center)[#tao-fit-display[#mitex("[f:\\psi] := \\inf \\{ \\sum_{k=1}^K c_k: c_1,\\ldots,c_K \\in {\\bf R}^+; f(x) \\leq \\sum_{k=1}^K c_k \\tau(y_k) \\psi(x) \\text{ for all } x \\in G \\}")]]

#text("of a given function ")#mi("{f \\in C_c(G)^+}")#text(" by ")#mi("{\\psi}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\int_G f\\ d\\mu \\leq \\kappa [f:\\psi].")]]

#text("This suggests using a scalar multiple of ")#mi("{f \\mapsto [f:\\psi]}")#text(" as the approximate linear functional (noting that ")#mi("{[f:\\psi]}")#text(" can be defined without reference to any existing Haar measure); in view of the normalisation ")#mi("{I(f_0)=1}")#text(", it is then natural to introduce the functional")

#align(center)[#tao-fit-display[#mitex("I(f) := \\frac{[f:\\psi]}{[f_0:\\psi]}.")]]

#text("(This functional is analogous in some ways to the concept of ")#link("http://en.wikipedia.org/wiki/Outer_measure")[#text("outer measure")]#text(" or the ")#link("http://en.wikipedia.org/wiki/Darboux_integral")[#text("upper Darboux integral")]#text(" in measure theory.) Note from compactness that ")#mi("{[f:\\psi]}")#text(" is finite for every ")#mi("{f \\in C_c(G)^+}")#text(", and from the non-triviality of ")#mi("{f_0}")#text(" we see that ")#mi("{[f_0:\\psi] > 0}")#text(", so ")#mi("{I}")#text(" is well-defined as a map from ")#mi("{C_c(G)^+}")#text(" to ")#mi("{{\\bf R}}")#text(". It is also easy to verify that ")#mi("{I}")#text(" obeys the homogeneity, left-invariance, and normalisation axioms. From the easy inequality ")#metadata(none) <tao-8252aa52eaa25942e776>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("[f:\\psi] \\leq [f:f_0] [f_0:\\psi]")]]



#text(" we also obtain the uniform bound axiom, and from the infimal nature of ")#mi("{[f:\\psi]}")#text(" we also easily obtain the subadditivity property")

#align(center)[#tao-fit-display[#mitex("I(f+g) \\leq I(f)+I(g).")]]

#text("To finish the construction, it thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("I(f_i+f_j) \\geq I(f_i) + I(f_j) - \\epsilon")]]

#text("for each ")#mi("{1 \\leq i, j \\leq n}")#text(", if ")#mi("{\\delta > 0}")#text(" is chosen sufficiently small depending on ")#mi("{\\epsilon, f_0,f_1,\\ldots,f_n}")#text(".")

#text("Fix ")#mi("{f_i, f_j}")#text(". By definition, we have the pointwise bound ")#metadata(none) <tao-251fecd592e56e6c4a95>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("f_i(x) + f_j(x) \\leq \\sum_{k=1}^K c_k \\tau(y_k) \\psi(x)")]]



#text(" for some ")#mi("{c_1,\\ldots,c_K}")#text(" with ")#metadata(none) <tao-b808760de23300313b4c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{k=1}^K c_k \\leq (I(f_i+f_j) + \\frac{\\epsilon}{2}) [f_0:\\psi].")]]



#text(" If we then write ")#mi("{c_k=c^{\\prime}_k+c^{\\prime\\prime}_k}")#text(" where")

#align(center)[#tao-fit-display[#mitex("c^{\\prime}_k := c_k \\frac{f_i(y_k) + \\delta}{f_i(y_k) + f_j(y_k) + 2\\delta}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("c^{\\prime\\prime}_k := c_k \\frac{f_j(y_k) + \\delta}{f_i(y_k) + f_j(y_k) + 2\\delta}")]]

#text("then we claim that ")#metadata(none) <tao-41e7eb6decc272c80ed7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("f_i(x) \\leq \\sum_{k=1}^K c^{\\prime}_k \\tau(y_k) \\psi(x) + 4 \\delta")]]



#text(" and ")#metadata(none) <tao-de499ab6b1780c31bd22>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("f_j(x) \\leq \\sum_{k=1}^K c^{\\prime\\prime}_k \\tau(y_k) \\psi(x) + 4 \\delta")]]



#text(" if ")#mi("{\\delta}")#text(" is small enough. Indeed, we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=1}^K c^{\\prime}_k \\tau(y_k) \\psi(x) = \\sum_{k=1}^K c_k \\psi(y_k^{-1} x) \\frac{f_i(y_k) + \\delta}{f_i(y_k) + f_j(y_k) + 2\\delta}.")]]

#text("If ")#mi("{\\psi(y_k^{-1} x)}")#text(" is non-zero, then by the construction of ")#mi("{\\psi}")#text(" and ")#mi("{U}")#text(", one has ")#tao-math("{\\left|f_i(y_k) - f_i(x)\\right| \\leq \\delta}", block: false)#text(" and ")#tao-math("{\\left|f_j(y_k) - f_j(x)\\right| \\leq \\delta}", block: false)#text(", which implies that")

#align(center)[#tao-fit-display[#mitex("\\frac{f_i(y_k) + \\delta}{f_i(y_k) + f_j(y_k) + 2\\delta} = \\frac{f_i(x)}{f_i(x)+f_j(x) + 4\\delta}.")]]

#text("Using ")#link(<tao-251fecd592e56e6c4a95>)[#text("(3)")]#text(" we thus have")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=1}^K c^{\\prime}_k \\tau(y_k) \\psi(x) + 4 \\delta \\geq \\frac{f_i(x)}{f_i(x)+f_j(x) + 4\\delta} (f_i(x)+f_j(x)) + 4 \\delta")]]

#text("which gives ")#link(<tao-41e7eb6decc272c80ed7>)[#text("(5)")]#text("; a similar argument gives ")#link(<tao-de499ab6b1780c31bd22>)[#text("(6)")]#text(". From the subadditivity (and monotonicity) of ")#mi("{I}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("I(f_i) \\leq \\frac{\\sum_{k=1}^K c^{\\prime}_k}{[f_0:\\psi]} + 4 \\delta I(g)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("I(f_j) \\leq \\frac{\\sum_{k=1}^K c^{\\prime\\prime}_k}{[f_0:\\psi]} + 4 \\delta I(g)")]]

#text("where ")#mi("{g \\in C_c(G)}")#text(" equals ")#mi("{1}")#text(" on the support of ")#mi("{f_i,f_j}")#text(". Summing and using ")#link(<tao-b808760de23300313b4c>)[#text("(4)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("I(f_i) + I(f_j) \\leq I(f_i+f_j) + \\frac{\\epsilon}{2} + 8 \\delta I(g)")]]

#text("and the claim follows by taking ")#mi("{\\delta}")#text(" small enough. This concludes the proof of Theorem ")#link(<tao-aff67f3419aedcabf966>)[#text("3")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" State and prove a generalisation of Theorem ")#link(<tao-aff67f3419aedcabf966>)[#text("3")]#text(" in which the hypothesis that ")#mi("{G}")#text(" is Hausdorff and ")#mi("{\\sigma}")#text("-compact are dropped. (This requires extending concepts such as “Borel ")#mi("{\\sigma}")#text("-algebra”, “Radon measure”, and “Haar measure” to the non-Hausdorff or non-")#mi("{\\sigma}")#text("-compact setting. Note that different texts sometimes have inequivalent definitions of these concepts in such settings; because of this (and also because of the potential breakdown of some basic measure-theoretic tools such as the Fubini-Tonelli theorem), it is usually best to avoid working with Haar measure in the non-Hausdorff or non-")#mi("{\\sigma}")#text("-compact case unless one is very careful.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" An important special case of the Haar measure construction arises for ")#emph[#text("compact")]#text(" groups ")#mi("{G}")#text(". Here, we can normalise the Haar measure by requiring that ")#mi("{\\mu(G)=1}")#text(" (i.e. ")#mi("{\\mu}")#text(" is a probability measure), and so there is now a unique (left-invariant) Haar probability measure on such a group. In Exercise ")#link(<tao-a8905bd4bf622bb7d683>)[#text("7")]#text(" we will see that this measure is in fact bi-invariant.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The above construction, based on the Riesz representation theorem, is not the only way to construct Haar measure. Another approach that is common in the literature is to first build a left-invariant outer measure and then use the ")#link("http://en.wikipedia.org/wiki/Carath%C3%A9odory%27s_extension_theorem")[#text("Carathéodory extension theorem")]#text(". Roughly speaking, the main difference between that approach and the one given here is that it is based on covering compact or open sets by other compact or open sets, rather than covering continuous, compactly supported functions by other continuous, compactly supported functions. In the compact case, one can also construct Haar probability measure by defining ")#mi("{\\int_G f\\ d\\mu}")#text(" to be the mean of ")#mi("{f}")#text(", or more precisely the unique constant function that is an average of translates of ")#mi("{f}")#text(". See Exercise 6 of ")#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")[#text("these notes")]#text(" for further discussion (the post there focuses on the abelian case, but the argument extends to the nonabelian setting).")
]

#text("The following exercise explores the distinction between left-invariance and right-invariance.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" ")#metadata(none) <tao-a8905bd4bf622bb7d683>#text(" Let ")#mi("{G}")#text(" be a ")#mi("{\\sigma}")#text("-compact locally compact Hausdorff group, and let ")#mi("{\\mu}")#text(" be a left-invariant Haar measure on ")#mi("{G}")#text(".")

#list(
[#text("(i) Show that for each ")#mi("{y \\in G}")#text(", there exists a unique positive real ")#mi("{c(y)}")#text(" (independent of the choice of ")#mi("{\\mu}")#text(") such that ")#mi("{\\mu(Ey) = c(y) \\mu(E)}")#text(" for all Borel measurable sets ")#mi("{E}")#text(" and ")#mi("{\\int_G f(xy^{-1})\\ d\\mu(x) = c(y) \\int_G f(x)\\ d\\mu(x)}")#text(" for all absolutely integrable ")#mi("{f}")#text(". In particular, a left-invariant Haar measure is right-invariant if and only if ")#mi("{c(y) = 1}")#text(" for all ")#mi("{y \\in G}")#text(".")],
[#text("(ii) Show that the map ")#mi("{y \\mapsto c(y)}")#text(" is a continuous homomorphism from ")#mi("{G}")#text(" to the multiplicative group ")#mi("{{\\bf R}^+ = ({\\bf R}^+, \\cdot)}")#text(". (This homomorphism is known as the ")#emph[#text("modular function")]#text(", and ")#mi("{G}")#text(" is said to be ")#emph[#text("unimodular")]#text(" if ")#mi("{c}")#text(" is identically equal to ")#mi("{1}")#text(".)")],
[#text("Show that for any ")#mi("{f \\in C_c(G)}")#text(", one has ")#mi("{\\int_G f(x^{-1})\\ d\\mu(x) = \\int_G c(x)^{-1} f(x)\\ d\\mu(x)}")#text(". (")#emph[#text("Hint:")]#text(" take another function ")#mi("{g \\in C_c(G)}")#text(" and evaluate ")#mi("{\\int_G \\int_G g(yx) c(x) f(x^{-1})\\ d\\mu(x) d\\mu(y)}")#text(" in two different ways, one of which involves replacing ")#mi("{x}")#text(" by ")#mi("{y^{-1} x}")#text(".) In particular, in a unimodular group one has ")#mi("{\\mu(E^{-1})=\\mu(E)}")#text(" and ")#mi("{\\int_G f(x^{-1})\\ dx = \\int_G f(x)\\ dx}")#text(" for any Borel set ")#mi("{E}")#text(" and any ")#mi("{f \\in C_c(G)}")#text(".")],
[#text("(iii) Show that ")#mi("{G}")#text(" is unimodular if it is compact.")],
[#text("(iv) If ")#mi("{G}")#text(" is a Lie group with Lie algebra ")#mi("{{\\mathfrak g}}")#text(", show that ")#tao-math("{c(g) = \\left|\\text{det} \\text{Ad}_g\\right|}", block: false)#text(", where ")#mi("{\\text{Ad}_g: {\\mathfrak g} \\rightarrow {\\mathfrak g}}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Adjoint_representation_of_a_Lie_group")[#text("adjoint representation")]#text(" of ")#mi("{g}")#text(", defined by requiring ")#mi("{\\exp( t \\text{Ad}_g X ) = g \\exp(tX) g^{-1}}")#text(" for all ")#mi("{X \\in {\\mathfrak g}}")#text(" (cf. Lemma 13 of ")#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")[#text("Notes 1")]#text(").")],
[#text("(v) If ")#mi("{G}")#text(" is a connected Lie group with Lie algebra ")#mi("{{\\mathfrak g}}")#text(", show that ")#mi("{G}")#text(" is unimodular if and only if ")#mi("{\\text{tr} \\text{ad}_X = 0}")#text(" for all ")#mi("{X \\in {\\mathfrak g}}")#text(", where ")#mi("{\\text{ad}_X: Y \\mapsto [X,Y]}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Adjoint_endomorphism")[#text("adjoint representation")]#text(" of ")#mi("{X}")#text(".")],
[#text("(vi) Show that ")#mi("{G}")#text(" is unimodular if it is a connected ")#link("http://en.wikipedia.org/wiki/Nilpotent")[#text("nilpotent")]#text(" Lie group.")],
[#text("(vii) Let ")#mi("{G}")#text(" be a connected Lie group whose Lie algebra ")#mi("{{\\mathfrak g}}")#text(" is such that ")#mi("{[{\\mathfrak g},{\\mathfrak g}] = {\\mathfrak g}}")#text(" (where ")#mi("{[{\\mathfrak g},{\\mathfrak g}]}")#text(" is the linear span of the commutators ")#mi("{[X,Y]}")#text(" with ")#mi("{X,Y \\in {\\mathfrak g}}")#text("). (This condition is in particular obeyed when the Lie algebra ")#mi("{{\\mathfrak g}}")#text(" is ")#link("http://en.wikipedia.org/wiki/Semisimple_Lie_algebra")[#text("semisimple")]#text(".) Show that ")#mi("{G}")#text(" is unimodular.")],
[#text("(viii) Let ")#mi("{G}")#text(" be the group of pairs ")#mi("{(a,b) \\in {\\bf R}^+ \\times {\\bf R}}")#text(" with the composition law ")#mi("{(a,b) (c,d) := (ac, ad+b)}")#text(". (One can interpret ")#mi("{G}")#text(" as the group of orientation-preserving affine transformations ")#mi("{x \\mapsto ax+b}")#text(" on the real line.) Show that ")#mi("{G}")#text(" is a connected Lie group that is not unimodular.")]
)
]

#text("In the case of a Lie group, one can also build Haar measures by starting with a non-invariant smooth measure, and then correcting it. Given a smooth manifold ")#mi("{M}")#text(", define a ")#emph[#text("smooth measure")]#text(" ")#mi("{\\mu}")#text(" on ")#mi("{M}")#text(" to be a Radon measure which is a smooth multiple of Lebesgue measure when viewed in coordinates, thus for any smooth coordinate chart ")#mi("{\\phi: U \\rightarrow V}")#text(", the pushforward measure ")#mi("{\\phi_* (\\mu\\downharpoonright_U)}")#text(" takes the form ")#mi("{f(x)\\ dx\\downharpoonright_V}")#text(" for some smooth function ")#mi("{f: V \\rightarrow {\\bf R}^+}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\mu(E) = \\int_{\\phi(E)} f(x)\\ dx")]]

#text("for all ")#mi("{E \\subset U}")#text(". We say that the smooth measure is ")#emph[#text("nonvanishing")]#text(" if ")#mi("{f}")#text(" is non-zero on ")#mi("{V}")#text(" for every coordinate chart ")#mi("{\\phi:U \\rightarrow V}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Let ")#mi("{G}")#text(" be a Lie group, and let ")#mi("{\\mu}")#text(" be a nonvanishing smooth measure on ")#mi("{G}")#text(".")

#list(
[#text("Show that for every ")#mi("{g \\in G}")#text(", there exists a unique smooth function ")#mi("{\\rho_g: G \\rightarrow {\\bf R}^+}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\int_G f(g^{-1} x)\\ d\\mu(x) = \\int_G f(x) \\rho_g(x)\\ d\\mu(x).")]]],
[#text("Verify the ")#emph[#text("cocycle equation")]#text(" ")#mi("{\\rho_{gh}(x) = \\rho_g(x) \\rho_h(gx)}")#text(" for all ")#mi("{g,h,x \\in G}")#text(".")],
[#text("Show that the measure ")#mi("{\\nu}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("\\nu(E) := \\int_E \\rho_x(\\text{id})^{-1}\\ d\\mu(x)")]]

#text("is a left-invariant Haar measure on ")#mi("{G}")#text(".")]
)
]

#text("There are a number of ways to generalise the Haar measure construction. For instance, one can define a local Haar measure on a local group ")#mi("{G}")#text(". If ")#mi("{U}")#text(" is a neighbourhood of the identity in a ")#mi("{\\sigma}")#text("-compact locally compact Hausdorff local group ")#mi("{G}")#text(", we define a ")#emph[#text("local left-invariant Haar measure")]#text(" on ")#mi("{U}")#text(" to be a non-zero Radon measure on ")#mi("{U}")#text(" with the property that ")#mi("{\\mu(gE)=\\mu(E)}")#text(" whenever ")#mi("{g \\in G}")#text(" and ")#mi("{E \\subset U}")#text(" is a Borel set such that ")#mi("{gE}")#text(" is well-defined and also in ")#mi("{U}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9 (Local Haar measure)")]#text(" Let ")#mi("{G}")#text(" be a ")#mi("{\\sigma}")#text("-compact locally compact Hausdorff local group, and let ")#mi("{U}")#text(" be an open neighbourhood of the identity in ")#mi("{G}")#text(" such that ")#mi("{U}")#text(" is symmetric (i.e. ")#mi("{U^{-1}}")#text(" is well-defined and equal to ")#mi("{U}")#text(") and ")#mi("{U^{10}}")#text(" is well-defined in ")#mi("{G}")#text(". By adapting the arguments above, show that there is a local left-invariant Haar measure on ")#mi("{U}")#text(", and that it is unique up to scalar multiplication. (")#emph[#text("Hint:")]#text(" a new technical difficulty is that there are now multiple covering numbers of interest, namely the covering numbers ")#mi("{[f,g]_{U^m}}")#text(" associated to various small powers ")#mi("{U^m}")#text(" of ")#mi("{m}")#text(". However, as long as one keeps track of which covering number to use at various junctures, this will not cause difficulty.)")
]

#text("One can also sometimes generalise the Haar measure construction from groups ")#mi("{G}")#text(" to spaces ")#mi("{X}")#text(" that ")#mi("{G}")#text(" acts transitively on.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 5 (Group actions)")]#text(" Given a topological group ")#mi("{G}")#text(" and a topological space ")#mi("{X}")#text(", define a (left) ")#link("http://en.wikipedia.org/wiki/Group_action")[#text("continuous action")]#text(" of ")#mi("{G}")#text(" on ")#mi("{X}")#text(" to be a continuous map ")#mi("{(g,x) \\mapsto gx}")#text(" from ")#mi("{G \\times X}")#text(" to ")#mi("{X}")#text(" such that ")#mi("{g(hx) = (gh)x}")#text(" and ")#mi("{\\text{id} x = x}")#text(" for all ")#mi("{g,h \\in G}")#text(" and ")#mi("{x \\in X}")#text(".")

#text("This action is said to be ")#link("http://en.wikipedia.org/wiki/Transitive_action#Transitive")[#text("transitive")]#text(" if for any ")#mi("{x,y\\in X}")#text(", there exists ")#mi("{g \\in G}")#text(" such that ")#mi("{gx = y}")#text(", and in this case ")#mi("{X}")#text(" is called a ")#link("http://en.wikipedia.org/wiki/Homogeneous_space")[#text("homogeneous space")]#text(" with structure group ")#mi("{G}")#text(", or ")#emph[#text("homogenous ")#mi("{G}")#text("-space")]#text(" for short.")

#text("For any ")#mi("{x_0 \\in X}")#text(", we call ")#mi("{\\text{Stab}(x_0) := \\{ g \\in G: gx_0 = x_0\\}}")#text(" the ")#link("http://en.wikipedia.org/wiki/Stabilizer_subgroup#Orbits_and_stabilizers")[#text("stabiliser")]#text(" of ")#mi("{x_0}")#text("; this is a closed subgroup of ")#mi("{G}")#text(".")

#text("If ")#mi("{G, X}")#text(" are smooth manifolds (so that ")#mi("{G}")#text(" is a Lie group) and the action ")#mi("{(g,x) \\mapsto gx}")#text(" is a smooth map, then we say that we have a ")#emph[#text("smooth action")]#text(" of ")#mi("{G}")#text(" on ")#mi("{X}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" If ")#mi("{G}")#text(" acts transitively on a space ")#mi("{X}")#text(", show that all the stabilisers ")#mi("{\\text{Stab}(x_0)}")#text(" are conjugate to each other, and ")#mi("{X}")#text(" is homeomorphic to the quotient spaces ")#mi("{G/\\text{Stab}(x_0)}")#text(" after weakening the topology of the quotient space (or strengthening the topology of the space ")#mi("{X}")#text(".")
]

#text("If ")#mi("{G}")#text(" and ")#mi("{X}")#text(" are ")#mi("{\\sigma}")#text("-compact, locally compact, and Hausdorff, a (left) ")#emph[#text("Haar measure")]#text(" is a non-zero Radon measure on ")#mi("{X}")#text(" such that ")#mi("{\\mu(gE) = \\mu(E)}")#text(" for all Borel ")#mi("{E \\subset X}")#text(" and ")#mi("{g \\in G}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Let ")#mi("{G}")#text(" be a ")#mi("{\\sigma}")#text("-compact, locally compact, and Hausdorff group (left) acting continuously and transitively on a ")#mi("{\\sigma}")#text("-compact, locally compact, and Hausdorff space ")#mi("{X}")#text(".")

#list(
[#text("(i) (Uniqueness up to scalars) Show that if ")#mi("{\\mu, \\nu}")#text(" are (left) Haar measures on ")#mi("{X}")#text(", then ")#mi("{\\mu = \\lambda \\nu}")#text(" for some ")#mi("{\\nu>0}")#text(".")],
[#text("(ii) (Compact case) Show that if ")#mi("{G}")#text(" is compact, then ")#mi("{X}")#text(" is compact too, and a Haar measure on ")#mi("{X}")#text(" exists.")],
[#text("(iii) (Smooth unipotent case) Suppose that the action is smooth (so that ")#mi("{G}")#text(" is a Lie group and ")#mi("{X}")#text(" is a smooth manifold). Let ")#mi("{x_0}")#text(" be a point of ")#mi("{X}")#text(". Suppose that for each ")#mi("{g \\in \\text{Stab}(x_0)}")#text(", the derivative map ")#mi("{Dg(x_0): T_{x_0} X \\rightarrow T_{x_0} X}")#text(" of the map ")#mi("{g:x \\mapsto gx}")#text(" at ")#mi("{x_0}")#text(" is unimodular (i.e. it has determinant ")#mi("{\\pm 1}")#text("). Show that a Haar measure on ")#mi("{X}")#text(" exists.")],
[#text("(iv) (Smooth case) Suppose that the action is smooth. Show that any Haar measure on ")#mi("{X}")#text(" is necessarily smooth. Conclude that a Haar measure exists if and only if the derivative maps ")#mi("{Dg}")#text(" are unimodular.")],
[#text("(v) (Counterexample) Let ")#mi("{G}")#text(" be the ")#mi("{ax+b}")#text(" group from Example ")#link(<tao-a8905bd4bf622bb7d683>)[#text("7")]#text("(viii), acting on ")#mi("{{\\bf R}}")#text(" by the action ")#mi("{(a,b) x := ax+b}")#text(". Show that there is no Haar measure on ")#mi("{{\\bf R}}")#text(". (This can be done either through (iv), or by an elementary direct argument.)")]
)
]

#heading(level: 1)[#strong[#text(" — 2. The Peter-Weyl theorem — ")]]

#text("We now restrict attention to compact groups ")#mi("{G}")#text(", which we will take to be Hausdorff for simplicity (although the results in this section will easily extend to the non-Hausdorff case using Exercise ")#link(<tao-c5375f9278b18d2308ed>)[#text("3")]#text("). By the previous discussion, there is a unique bi-invariant Haar probability measure ")#mi("{\\mu}")#text(" on ")#mi("{G}")#text(", which gives rise in particular to the Hilbert space ")#mi("{L^2(G) = L^2(G,d\\mu)}")#text(" of square-integrable functions ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" on ")#mi("{G}")#text(" (quotiented out by almost everywhere equivalence, as usual), with norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^2(G)} := (\\int_G \\left|f(x)\\right|^2\\ d\\mu(x))^{1/2}", block: true)]]

#text("and inner product")

#align(center)[#tao-fit-display[#mitex("\\langle f, g \\rangle_{L^2(G)} := \\int_G f(x) \\overline{g(x)}\\ dx.")]]

#text("For every group element ")#mi("{y \\in G}")#text(", the translation operator ")#mi("{\\tau(y): L^2(G) \\rightarrow L^2(G)}")#text(" is defined by")

#align(center)[#tao-fit-display[#mitex("\\tau(y) f(x) := f(y^{-1} x).")]]

#text("One easily verifies that ")#mi("{\\tau(y^{-1})}")#text(" is both the inverse and the adjoint of ")#mi("{\\tau(y)}")#text(", and so ")#mi("{\\tau(y)}")#text(" is a unitary operator. The map ")#mi("{\\tau: y \\mapsto \\tau(y)}")#text(" is then a continuous homomorphism from ")#mi("{G}")#text(" to the unitary group ")#mi("{U(L^2(G))}")#text(" of ")#mi("{L^2(G)}")#text(" (where we give the latter group the ")#link("http://en.wikipedia.org/wiki/Strong_operator_topology")[#text("strong operator topology")]#text("), and is known as the ")#link("http://en.wikipedia.org/wiki/Regular_representation")[#text("regular representation")]#text(" of ")#mi("{G}")#text(".")

#text("For our purposes, the regular representation is too “big” of a representation to work with because the underlying Hilbert space ")#mi("{L^2(G)}")#text(" is usually infinite-dimensional. However, we can find smaller representations by locating ")#emph[#text("left-invariant")]#text(" closed subspaces ")#mi("{V}")#text(" of ")#mi("{L^2(G)}")#text(", i.e. closed linear subspaces of ")#mi("{L^2(G)}")#text(" with the property that ")#mi("{\\tau(y) V \\subset V}")#text(" for all ")#mi("{y \\in G}")#text(". Then the restriction of ")#mi("{\\tau}")#text(" to ")#mi("{V}")#text(" becomes a representation ")#mi("{\\tau\\downharpoonright_V: G \\rightarrow U(V)}")#text(" to the unitary group of ")#mi("{V}")#text(". In particular, if ")#mi("{V}")#text(" has some finite dimension ")#mi("{n}")#text(", this gives a representation of ")#mi("{G}")#text(" by a unitary group ")#mi("{U_n({\\bf C})}")#text(" after expressing ")#mi("{V}")#text(" in coordinates.")

#text("We can build invariant subspaces from applying spectral theory to an invariant operator, and more specifically to a ")#emph[#text("convolution operator")]#text(". If ")#mi("{f, g \\in L^2(G)}")#text(", we define the convolution ")#mi("{f*g: G \\rightarrow {\\bf C}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("f*g(x) = \\int_G f(y) g(y^{-1} x)\\ d\\mu(y).")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" Show that if ")#mi("{f, g \\in L^2(G)}")#text(", then ")#mi("{f*g}")#text(" is well-defined and lies in ")#mi("{C(G)}")#text(", and in particular also lies in ")#mi("{L^2(G)}")#text(".")
]

#text("For ")#mi("{g \\in L^2(G)}")#text(", let ")#mi("{T_g: L^2(G) \\rightarrow L^2(G)}")#text(" denote the right-convolution operator ")#mi("{T_g f := f*g}")#text(". This is easily seen to be a bounded linear operator on ")#mi("{L^2(G)}")#text(". Using the properties of Haar measure, we also observe that ")#mi("{T_g}")#text(" will be self-adjoint if ")#mi("{g}")#text(" obeys the condition ")#metadata(none) <tao-dfcdaf51905dcb336a7b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("g(x^{-1}) = \\overline{g(x)}")]]



#text(" and it also commutes with left-translations:")

#align(center)[#tao-fit-display[#mitex("T_g \\rho(y) = \\rho(y) T_g.")]]

#text("In particular, for any ")#mi("{\\lambda \\in {\\bf C}}")#text(", the ")#emph[#text("eigenspace")]

#align(center)[#tao-fit-display[#mitex("V_\\lambda := \\{ f \\in L^2(G): T_g f = \\lambda f \\}")]]

#text("will be a closed invariant subspace of ")#mi("{L^2(G)}")#text(". Thus we see that we can generate a large number of representations of ")#mi("{G}")#text(" by using the eigenspace of a convolution operator.")

#text("Another important fact about these operators, is that the ")#mi("{T_g}")#text(" are ")#link("http://en.wikipedia.org/wiki/Compact_operator")[#text("compact")]#text(", i.e. they map bounded sets to precompact sets. This is a consequence of the following more general fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Compactness of integral operators)")]#text(" Let ")#mi("{(X,\\mu)}")#text(" and ")#mi("{(Y,\\nu)}")#text(" be ")#mi("{\\sigma}")#text("-finite measure spaces, and let ")#mi("{K \\in L^2(X\\times Y, \\mu \\times \\nu)}")#text(". Define an integral operator ")#mi("{T: L^2(X,\\mu) \\rightarrow L^2(Y,\\nu)}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("T f(y) := \\int_X K(x,y) f(x)\\ d\\mu(x).")]]

#list(
[#text("Show that ")#mi("{T}")#text(" is a bounded linear operator, with operator norm ")#tao-math("{\\left\\|T\\right\\|_{op}}", block: false)#text(" bounded by ")#tao-math("{\\left\\|K\\right\\|_{L^2(X \\times Y, \\mu \\times \\nu)}}", block: false)#text(". (")#emph[#text("Hint:")]#text(" use duality.)")],
[#text("Show that ")#mi("{T}")#text(" is a compact linear operator. (")#emph[#text("Hint:")]#text(" approximate ")#mi("{K}")#text(" by a linear combination of functions of the form ")#mi("{a(x) b(y)}")#text(" for ")#mi("{a \\in L^2(X,\\mu)}")#text(" and ")#mi("{b \\in L^2(Y,\\nu)}")#text(", plus an error which is small in ")#mi("{L^2(X \\times Y,\\mu \\times \\nu)}")#text(" norm, so that ")#mi("{T}")#text(" becomes approximated by the sum of a ")#link("http://en.wikipedia.org/wiki/Finite-rank_operator")[#text("finite rank operator")]#text(" and an operator of small operator norm.)")]
)
]

#text("Note that ")#mi("{T_g}")#text(" is an integral operator with kernel ")#mi("{K(x,y) := g(x^{-1} y)}")#text("; from the invariance properties of Haar measure we see that ")#mi("{K \\in L^2(G \\times G)}")#text(" if ")#mi("{g \\in L^2(G)}")#text(" (note here that we crucially use the fact that ")#mi("{G}")#text(" is compact, so that ")#mi("{\\mu(G)=1}")#text("). Thus we conclude that the convolution operator ")#mi("{T_g}")#text(" is compact when ")#mi("{G}")#text(" is compact.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Show that if ")#mi("{g \\in C_c({\\bf R})}")#text(" is non-zero, then ")#mi("{T_g}")#text(" is not compact on ")#mi("{L^2({\\bf R})}")#text(". This example demonstrates that compactness of ")#mi("{G}")#text(" is needed in order to ensure compactness of ")#mi("{T_g}")#text(".")
]

#text("We can describe self-adjoint compact operators in terms of their eigenspaces:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Spectral theorem)")]#text(" ")#metadata(none) <tao-d4f02eaafd1a9e9de7d1>#text(" Let ")#mi("{T: H \\rightarrow H}")#text(" be a compact self-adjoint operator on a complex Hilbert space ")#mi("{H}")#text(". Then there exists an at most countable sequence ")#mi("{\\lambda_1, \\lambda_2, \\ldots}")#text(" of non-zero reals that converge to zero and an orthogonal decomposition")

#align(center)[#tao-fit-display[#mitex("H = V_0 \\oplus \\bigoplus_n V_{\\lambda_n}")]]

#text("of ")#mi("{H}")#text(" into the ")#mi("{0}")#text(" eigenspace (or kernel) ")#mi("{V_0}")#text(" of ")#mi("{T}")#text(", and the ")#mi("{\\lambda_n}")#text("-eigenspaces ")#mi("{V_{\\lambda_n}}")#text(", which are all finite-dimensional.")
]

#emph[#text("Proof:")]#text(" From self-adjointness we see that all the eigenspaces ")#mi("{V_\\lambda}")#text(" are orthogonal to each other, and only non-trivial for ")#mi("{\\lambda}")#text(" real. If ")#mi("{r>0}")#text(", then ")#tao-math("{\\bigoplus_{\\lambda \\in {\\bf R}: \\left|\\lambda\\right| > r} V_\\lambda}", block: false)#text(" has an orthonormal basis of eigenfunctions ")#mi("{v}")#text(", each of which is enlarged by a factor of at least ")#mi("{r}")#text(" by ")#mi("{T}")#text(". In particular, this basis cannot be infinite, because otherwise the image of this basis by ")#mi("{T}")#text(" would have no convergent subsequence, contradicting compactness. Thus ")#tao-math("{\\bigoplus_{\\lambda \\in {\\bf R}: \\left|\\lambda\\right| > r} V_\\lambda}", block: false)#text(" is finite-dimensional for any ")#mi("{r}")#text(", which implies that ")#mi("{V_\\lambda}")#text(" is finite-dimensional for every non-zero ")#mi("{\\lambda}")#text(", and those non-zero ")#mi("{\\lambda}")#text(" with non-trivial ")#mi("{V_\\lambda}")#text(" can be enumerated to either be finite, or countable and go to zero.")

#text("Let ")#mi("{W}")#text(" be the orthogonal complement of ")#mi("{V_0 \\oplus \\bigoplus_n V_{\\lambda_n}}")#text(". If ")#mi("{W}")#text(" is trivial, then we are done, so suppose for sake of contradiction that ")#mi("{W}")#text(" is non-trivial. As all of the ")#mi("{V_\\lambda}")#text(" are invariant, and ")#mi("{T}")#text(" is self-adjoint, ")#mi("{W}")#text(" is also invariant, with ")#mi("{T}")#text(" being self-adjoint on ")#mi("{W}")#text(". As ")#mi("{W}")#text(" is orthogonal to the kernel ")#mi("{V_0}")#text(" of ")#mi("{T}")#text(", ")#mi("{T}")#text(" has trivial kernel in ")#mi("{W}")#text(". More generally, ")#mi("{T}")#text(" has no eigenvectors in ")#mi("{W}")#text(".")

#text("Let ")#mi("{B}")#text(" be the unit ball in ")#mi("{W}")#text(". As ")#mi("{T}")#text(" has trivial kernel and ")#mi("{W}")#text(" is non-trivial, ")#tao-math("{\\left\\|T\\right\\|_{op} > 0}", block: false)#text(". Using the identity ")#metadata(none) <tao-28720365c5e7476a011e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left\\|T\\right\\|_{op} = \\sup_{W: \\left\\|x\\right\\| \\leq 1} \\left|\\langle Tx, x \\rangle\\right|", block: true)]]



#text(" valid for all self-adjoint operators ")#mi("{T}")#text(" (see Exercise ")#link(<tao-5873102fa0951713a811>)[#text("15")]#text(" below). Thus, we may find a sequence ")#mi("{x_n}")#text(" of vectors of norm at most ")#mi("{1}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\langle Tx_n, x_n\\rangle \\rightarrow \\lambda")]]

#text("for some ")#tao-math("{\\lambda = \\pm \\left\\|T\\right\\|_{op}}", block: false)#text(". Since ")#tao-math("{\\left\\|Tx_n\\right\\|^2 \\leq \\left\\|T\\right\\|_{op}^2 \\left\\|x_n\\right\\|^2 \\leq \\lambda^2}", block: false)#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("0 \\leq \\left\\| Tx_n - \\lambda x_n\\right\\|^2 = \\left\\|Tx_n\\right\\|^2 + \\lambda^2 \\left\\|x_n\\right\\|^2 - 2 \\langle Tx_n, x_n\\rangle \\leq 2\\lambda^2 - 2 \\langle Tx_n, x_n\\rangle", block: true)]]

#text("and hence ")#metadata(none) <tao-12cea0154ec4197be108>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("Tx_n - \\lambda x_n \\rightarrow 0;")]]



#text(" applying ")#mi("{T}")#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("T(Tx_n) - \\lambda Tx_n \\rightarrow 0.")]]

#text("By compactness of ")#mi("{T}")#text(", we may pass to a subsequence so that ")#mi("{Tx_n}")#text(" converges to a limit ")#mi("{y}")#text(", and thus ")#mi("{Ty - \\lambda y = 0}")#text(". As ")#mi("{T}")#text(" has no eigenvectors, ")#mi("{y}")#text(" must be trivial; but then ")#mi("{\\langle Tx_n,x_n \\rangle}")#text(" converges to zero, a contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" ")#metadata(none) <tao-5873102fa0951713a811>#text(" Establish ")#link(<tao-12cea0154ec4197be108>)[#text("(9)")]#text(" whenever ")#mi("{T: W \\rightarrow W}")#text(" is a bounded self-adjoint operator on ")#mi("{W}")#text(". (")#emph[#text("Hint:")]#text(" Bound ")#tao-math("{\\left|\\langle Tx, y \\rangle\\right|}", block: false)#text(" by the right-hand side of ")#link(<tao-28720365c5e7476a011e>)[#text("(8)")]#text(" whenever ")#mi("{x, y}")#text(" are vectors of norm at most ")#mi("{1}")#text(", by playing with ")#mi("{\\langle T(ax+by), (ax+by)\\rangle}")#text(" for various choices of scalars ")#mi("{a,b}")#text(", in the spirit of the proof of the Cauchy-Schwarz inequality.)")
]

#text("This leads to the consequence that we can find non-trivial finite-dimensional representations on at least a single non-identity element:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Baby Peter-Weyl theorem)")]#text(" ")#metadata(none) <tao-dad0e46968bbce7315d5>#text(" Let ")#mi("{G}")#text(" be a compact Hausdorff group with Haar measure ")#mi("{\\mu}")#text(", and let ")#mi("{y \\in G}")#text(" be a non-identity element of ")#mi("{G}")#text(". Then there exists a finite-dimensional invariant subspace of ")#mi("{L^2(G)}")#text(" on which ")#mi("{\\tau(y)}")#text(" is not the identity.")
]

#emph[#text("Proof:")]#text(" Suppose for contradiction that ")#mi("{\\tau(y)}")#text(" is the identity on every finite-dimensional invariant subspace of ")#mi("{L^2(G)}")#text(", thus ")#mi("{\\tau(y)-1}")#text(" annihilates every such subspace. By Theorem ")#link(<tao-d4f02eaafd1a9e9de7d1>)[#text("6")]#text(", we conclude that ")#mi("{\\tau(y)-1}")#text(" has range in the kernel of every convolution operator ")#mi("{T_g}")#text(" with ")#mi("{g \\in L^2}")#text(", thus ")#mi("{T_g ( \\tau(y)-1) f = 0}")#text(" for any ")#mi("{f, g \\in L^2(G)}")#text(" with ")#mi("{g}")#text(" obeying ")#link(<tao-dfcdaf51905dcb336a7b>)[#text("(7)")]#text(", i.e.")

#align(center)[#tao-fit-display[#mitex("\\tau(y) (f*g) = (f*g)")]]

#text("for any such ")#mi("{f, g}")#text(". But one may easily construct ")#mi("{f, g}")#text(" such that ")#mi("{f*g}")#text(" is non-zero at the identity and vanishing at ")#mi("{y}")#text(" (e.g. one can set ")#mi("{f=g=1_U}")#text(" where ")#mi("{U}")#text(" is an open symmetric neighbourhood of the identity, small enough that ")#mi("{y}")#text(" lies outside ")#mi("{U^2}")#text("). This gives the desired contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" The full ")#link("http://en.wikipedia.org/wiki/Peter-Weyl_theorem")[#text("Peter-Weyl theorem")]#text(" describes rather precisely all the invariant subspaces of ")#mi("{L^2(G)}")#text(". Roughly speaking, the theorem asserts that for each irreducible finite-dimensional representation ")#mi("{\\rho_\\lambda: G \\rightarrow U(V_\\lambda)}")#text(" of ")#mi("{G}")#text(", ")#mi("{\\text{dim}(V_\\lambda)}")#text(" different copies of ")#mi("{V_\\lambda}")#text(" (viewed as an invariant ")#mi("{G}")#text("-space) appear in ")#mi("{L^2(G)}")#text(", and that they are all orthogonal and make up all of ")#mi("{L^2(G)}")#text("; thus, one has an orthogonal decomposition")

#align(center)[#tao-fit-display[#mitex("L^2(G) \\equiv \\bigoplus_{\\lambda} V_\\lambda^{\\text{dim}(V_\\lambda)}")]]

#text("of ")#mi("{G}")#text("-spaces. Actually, this is not the sharpest form of the theorem, as it only describes the left ")#mi("{G}")#text("-action and not the right ")#mi("{G}")#text("-action; see ")#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/")[#text("this previous blog post")]#text(" for a precise statement and proof of the Peter-Weyl theorem in its strongest form. This form is of importance in Fourier analysis and representation theory, but in this course we will only need the baby form of the theorem (Theorem ")#link(<tao-dad0e46968bbce7315d5>)[#text("7")]#text("), which is an easy consequence of the full Peter-Weyl theorem (since, if ")#mi("{g}")#text(" is not the identity, then ")#mi("{\\tau(g)}")#text(" is clearly non-trivial on ")#mi("{L^2(G)}")#text(" and hence on at least one of the ")#mi("{V_\\lambda}")#text(" factors).")
]

#text("The Peter-Weyl theorem leads to the following structural theorem for compact groups:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8 (Gleason-Yamabe theorem for compact groups)")]#text(" ")#metadata(none) <tao-9236ae3dbf9d1927cf02>#text(" Let ")#mi("{G}")#text(" be a compact Hausdorff group, and let ")#mi("{U}")#text(" be a neighbourhood of the identity. Then there exists a compact normal subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" contained in ")#mi("{U}")#text(" such that ")#mi("{G/H}")#text(" is isomorphic to a linear group (i.e. a closed subgroup of a general linear group ")#mi("{GL_n({\\bf C})}")#text(").")
]

#text("Note from Cartan’s theorem (Theorem 2 from ")#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/")[#text("Notes 2")]#text(") that every linear group is Lie; thus, compact Hausdorff groups are “almost Lie” in some sense.")

#emph[#text("Proof:")]#text(" Let ")#mi("{g}")#text(" be an element of ")#mi("{G \\backslash U}")#text(". By the baby Peter-Weyl theorem, we can find a finite-dimensional invariant subspace ")#mi("{V}")#text(" of ")#mi("{L^2(G)}")#text(" on which ")#mi("{\\tau(g)}")#text(" is non-trivial. Identifying such a subspace with ")#mi("{{\\bf C}^n}")#text(" for some finite ")#mi("{n}")#text(", we thus have a continuous homomorphism ")#mi("{\\rho: G \\rightarrow GL_n({\\bf C})}")#text(" such that ")#mi("{\\rho(g)}")#text(" is non-trivial. By continuity, ")#mi("{\\rho(g)}")#text(" will also be non-trivial for some open neighbourhood of ")#mi("{g}")#text(". Using the compactness of ")#mi("{G \\backslash U}")#text(", one can then find a finite number ")#mi("{\\rho_1,\\ldots,\\rho_k}")#text(" of such continuous homomorphisms ")#mi("{\\rho_i: G \\rightarrow GL_{n_i}({\\bf C})}")#text(" such that for each ")#mi("{g \\in G \\backslash U}")#text(", at least one of ")#mi("{\\rho_1(g),\\ldots,\\rho_k(g)}")#text(" is non-trivial. If we then form the direct sum")

#align(center)[#tao-fit-display[#mitex("\\rho :=\\bigoplus_{i=1}^k \\rho_i: G \\rightarrow \\bigoplus_{i=1}^k GL_{n_i}({\\bf C}) \\subset GL_{n_1+\\ldots+n_k}({\\bf C})")]]

#text("then ")#mi("{\\rho}")#text(" is still a continuous homomorphism, which is now non-trivial for any ")#mi("{g \\in G \\backslash U}")#text("; thus the kernel ")#mi("{H}")#text(" of ")#mi("{\\rho}")#text(" is a compact normal subgroup of ")#mi("{G}")#text(" contained in ")#mi("{U}")#text(". There is thus a continuous bijection from the compact space ")#mi("{G/H}")#text(" to the Hausdorff space ")#mi("{\\rho(G)}")#text(", and so the two spaces are homeomorphic. As ")#mi("{\\rho(G)}")#text(" is a compact (hence closed) subgroup of ")#mi("{GL_{n_1+\\ldots+n_k}({\\bf C})}")#text(", the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Show that the hypothesis that ")#mi("{G}")#text(" is Hausdorff can be omitted from Theorem ")#link(<tao-9236ae3dbf9d1927cf02>)[#text("8")]#text(". (")#emph[#text("Hint:")]#text(" use Exercise ")#link(<tao-c5375f9278b18d2308ed>)[#text("3")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" Show that any compact Lie group is isomorphic to a linear group. (")#emph[#text("Hint:")]#text(" first find a neighbourhood of the identity that is so small that it does not contain any non-trivial subgroups.) The property of having ")#link("http://en.wikipedia.org/wiki/No_small_subgroup")[#text("no small subgroups")]#text(" will be an important one in later notes.")
]

#text("One can rephrase the Gleason-Yamabe theorem for compact groups in terms of the machinery of ")#link("http://en.wikipedia.org/wiki/Inverse_limit")[#text("inverse limits")]#text(" (also known as ")#emph[#text("projective limits")]#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 9 (Inverse limits of groups)")]#text(" ")#metadata(none) <tao-89270a50341bb8e83734>#text(" Let ")#mi("{(G_\\alpha)_{\\alpha \\in A}}")#text(" be a family of groups ")#mi("{G_\\alpha}")#text(" indexed by a partially ordered set ")#mi("{A = (A,<)}")#text(". Suppose that for each ")#mi("{\\alpha < \\beta}")#text(" in ")#mi("{A}")#text(", there is a surjective homomorphism ")#mi("{\\pi_{\\alpha \\leftarrow \\beta}: G_\\beta \\rightarrow G_\\alpha}")#text(" which obeys the composition law ")#mi("{\\pi_{\\alpha \\leftarrow \\beta} \\circ \\pi_{\\beta \\leftarrow \\gamma} = \\pi_{\\alpha \\leftarrow \\gamma}}")#text(" for all ")#mi("{\\alpha < \\beta < \\gamma}")#text(". (If one wishes, one can take a ")#link("http://en.wikipedia.org/wiki/Category_theory")[#text("category-theoretic perspective")]#text(" and view these surjections as describing a ")#link("http://en.wikipedia.org/wiki/Functor")[#text("functor")]#text(" from the partially ordered set ")#mi("{A}")#text(" to the category of groups.) We then define the ")#emph[#text("inverse limit")]#text(" ")#mi("{G = \\lim_{\\leftarrow} G_\\alpha}")#text(" to be the set of all tuples ")#mi("{(g_\\alpha)_{\\alpha \\in A}}")#text(" in the product set ")#mi("{\\prod_{\\alpha \\in A} G_\\alpha}")#text(" such that ")#mi("{\\pi_{\\alpha \\leftarrow \\beta}(g_\\beta) = g_\\alpha}")#text(" for all ")#mi("{\\alpha < \\beta}")#text("; one easily verifies that this is also a group. We let ")#mi("{\\pi_\\alpha: G \\rightarrow G_\\alpha}")#text(" denote the coordinate projection maps ")#mi("{\\pi_\\alpha: (g_\\beta)_{\\beta \\in A} \\mapsto g_\\alpha}")#text(".")

#text("If the ")#mi("{G_\\alpha}")#text(" are topological groups and the ")#mi("{\\pi_{\\alpha \\leftarrow \\beta}}")#text(" are continuous, we can give ")#mi("{G}")#text(" the topology induced from ")#mi("{\\prod_{\\alpha \\in A} G_\\alpha}")#text("; one easily verifies that this makes ")#mi("{G}")#text(" a topological group, and that the ")#mi("{\\pi_\\alpha}")#text(" are continuous homomorphisms.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18 (Universal description of inverse limit)")]#text(" Let ")#mi("{(G_\\alpha)_{\\alpha \\in A}}")#text(" be a family of groups ")#mi("{G_\\alpha}")#text(" with the surjective homomorphisms ")#mi("{\\pi_{\\alpha \\leftarrow \\beta}}")#text(" as in Definition ")#link(<tao-89270a50341bb8e83734>)[#text("9")]#text(". Let ")#mi("{G = \\lim_{\\leftarrow} G_\\alpha}")#text(" be the inverse limit, and let ")#mi("{H}")#text(" be another group. Suppose that one has homomorphisms ")#mi("{\\phi_\\alpha: H \\rightarrow G_\\alpha}")#text(" for each ")#mi("{\\alpha \\in A}")#text(" such that ")#mi("{\\phi_{\\alpha \\leftarrow \\beta} \\circ \\phi_\\alpha = \\phi_\\beta}")#text(" for all ")#mi("{\\alpha < \\beta}")#text(". Show that there exists a unique homomorphism ")#mi("{\\phi: H \\rightarrow G}")#text(" such that ")#mi("{\\phi_\\alpha = \\pi_\\alpha \\circ \\phi}")#text(" for all ")#mi("{\\alpha \\in A}")#text(".")

#text("Establish the same claim with “group” and “homomorphism” replaced by “topological group” and “continuous homomorphism” throughout.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Let ")#mi("{p}")#text(" be a prime. Show that ")#mi("{{\\bf Z}_p}")#text(" is isomorphic to the inverse limit ")#mi("{\\lim_{\\leftarrow} {\\bf Z}/p^n{\\bf Z}}")#text(" of the cyclic groups ")#mi("{{\\bf Z}/p^n{\\bf Z}}")#text(" with ")#mi("{n \\in{\\bf N}}")#text(" (with the usual ordering), using the obvious projection homomorphisms from ")#mi("{{\\bf Z}/p^m{\\bf Z}}")#text(" to ")#mi("{{\\bf Z}/p^n{\\bf Z}}")#text(" for ")#mi("{m>n}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" ")#metadata(none) <tao-b11e23303e7d8bc69ecf>#text(" Show that every compact Hausdorff group is isomorphic (as a topological group) to an inverse limit of linear groups. (")#emph[#text("Hint:")]#text(" take the index set ")#mi("{A}")#text(" to be the set of all non-empty finite collections of open neighbourhoods ")#mi("{U}")#text(" of the identity, indexed by inclusion.) If the compact Hausdorff group is metrisable, show that one can take the inverse limit to be indexed instead by the natural numbers with the usual ordering.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Let ")#mi("{G}")#text(" be an abelian group with a homomorphism ")#mi("{\\rho: G \\mapsto U(V)}")#text(" into the unitary group of a finite-dimensional space ")#mi("{V}")#text(". Show that ")#mi("{V}")#text(" can be decomposed as the vector space sum of one-dimensional ")#mi("{G}")#text("-invariant spaces. (")#emph[#text("Hint:")]#text(" By the spectral theorem for unitary matrices, any unitary operator ")#mi("{T}")#text(" on ")#mi("{V}")#text(" decomposes ")#mi("{V}")#text(" into eigenspaces, and any operator commuting with ")#mi("{T}")#text(" must preserve each of these eigenspaces. Now induct on the dimension of ")#mi("{V}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22 (Fourier analysis on compact abelian groups)")]#text(" ")#metadata(none) <tao-aab210d24ab706a6b387>#text(" Let ")#mi("{G}")#text(" be a compact abelian Hausdorff group with Haar probability measure ")#mi("{\\mu}")#text(". Define a ")#emph[#text("character")]#text(" to be a continuous homomorphism ")#mi("{\\chi: G \\mapsto S^1}")#text(" to the unit circle ")#tao-math("{S^1 := \\{ z \\in {\\bf C}: \\left|z\\right|=1\\}}", block: false)#text(", and let ")#mi("{\\hat G}")#text(" be the collection of all such characters.")

#list(
[#text("(i) Show that for every ")#mi("{g \\in G}")#text(" not equal to the identity, there exists a character ")#mi("{\\chi}")#text(" such that ")#mi("{\\chi(g) \\neq 1}")#text(". (")#emph[#text("Hint:")]#text(" combine the baby Peter-Weyl theorem with the preceding exercise.)")],
[#text("(ii) Show that every function in ")#mi("{C(G)}")#text(" is the limit in the uniform topology of finite linear combinations of characters. (")#emph[#text("Hint:")]#text(" use the ")#link("http://en.wikipedia.org/wiki/Stone-weierstrass_theorem")[#text("Stone-Weierstrass theorem")]#text(".)")],
[#text("(iii) Show that the characters ")#mi("{\\chi}")#text(" for ")#mi("{\\chi \\in \\hat G}")#text(" form an orthonormal basis of ")#mi("{L^2(G,d\\mu)}")#text(".")]
)
]

#heading(level: 1)[#strong[#text(" — 3. The structure of locally compact abelian groups — ")]]

#text("We now use the above machinery to analyse locally compact abelian groups. We follow some combinatorial arguments of Pontryagin, as presented in the text of Montgomery and Zippin.")

#text("We first make a general observation that locally compact groups contain open subgroups that are “finitely generated modulo a compact set”. Call a subgroup ")#mi("{\\Gamma}")#text(" of a topological group ")#mi("{G}")#text(" ")#emph[#text("cocompact")]#text(" if the quotient space is compact.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10")]#text(" ")#metadata(none) <tao-abd8cfba151826bb7bf3>#text(" Let ")#mi("{G}")#text(" be a locally compact group. Then there exists an open subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" which has a cocompact finitely generated subgroup ")#mi("{\\Gamma}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{K}")#text(" be a compact neighbourhood of the identity. Then ")#mi("{K^2}")#text(" is also compact and can thus be covered by finitely many copies of ")#mi("{K}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("K^2 \\subset KS")]]

#text("for some finite set ")#mi("{S}")#text(", which we may assume without loss of generality to be contained in ")#mi("{K^{-1} K^2}")#text(". In particular, if ")#mi("{\\Gamma}")#text(" is the group generated by ")#mi("{S}")#text(", then")

#align(center)[#tao-fit-display[#mitex("K^2 \\Gamma \\subset K \\Gamma.")]]

#text("Multiplying this on the left by powers of ")#mi("{K}")#text(" and inducting, we conclude that")

#align(center)[#tao-fit-display[#mitex("K^n \\Gamma \\subset K \\Gamma")]]

#text("for all ")#mi("{n \\geq 1}")#text(". If we then let ")#mi("{G^{\\prime}}")#text(" be the group generated by ")#mi("{K}")#text(", then ")#mi("{\\Gamma}")#text(" lies in ")#mi("{G^{\\prime}}")#text(" and ")#mi("{G^{\\prime} \\subset K \\Gamma \\subset G^{\\prime}}")#text(". Thus ")#mi("{G^{\\prime}/\\Gamma}")#text(" is the image of the compact set ")#mi("{K}")#text(" under the quotient map, and the claim follows. ")#mi("\\Box")

#text("In the abelian case, we can improve this lemma by combining it with the following proposition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 11")]#text(" ")#metadata(none) <tao-b8d19b6206b72bf403a0>#text(" Let ")#mi("{G}")#text(" be a locally compact Hausdorff abelian group with a cocompact finitely generated subgroup. Then ")#mi("{G}")#text(" has a cocompact ")#emph[#text("discrete")]#text(" finitely generated subgroup.")
]

#text("To prove this proposition, we need the following lemma.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 12")]#text(" ")#metadata(none) <tao-31d123108dba5fd36075>#text(" Let ")#mi("{G}")#text(" be a locally compact Hausdorff group, and let ")#mi("{g \\in G}")#text(". Then the group ")#mi("{\\langle g \\rangle}")#text(" generated by ")#mi("{g}")#text(" is either precompact or discrete (or both).")
]

#emph[#text("Proof:")]#text(" By replacing ")#mi("{G}")#text(" with the closed subgroup ")#mi("{\\overline{\\langle g \\rangle}}")#text(" we may assume without loss of generality that ")#mi("{\\langle g \\rangle}")#text(" is dense in ")#mi("{G}")#text(".")

#text("We may assume of course that ")#mi("{\\langle g \\rangle}")#text(" is not discrete. This implies that the identity element is not an isolated point in ")#mi("{\\langle g \\rangle}")#text(", and thus for any neighbourhood of the identity ")#mi("{U}")#text(", there exist arbitrarily large ")#mi("{n}")#text(" such that ")#mi("{g^n \\in U}")#text("; since ")#mi("{g^{-n} = (g^n)^{-1}}")#text(" we may take these ")#mi("{n}")#text(" to be large and positive rather than large and negative.")

#text("Let ")#mi("{U}")#text(" be a precompact symmetric neighbourhood of the identity, then ")#mi("{U^3}")#text(" (say) is covered by a finite number ")#mi("{g_j U}")#text(" of left-translates of ")#mi("{U}")#text(". As ")#mi("{\\langle g \\rangle}")#text(" is dense, we conclude that ")#mi("{U^3}")#text(" is covered by a finite number of translates ")#mi("{g^{n_j} U^2}")#text(" of left-translates of ")#mi("{U}")#text(" by powers of ")#mi("{g}")#text(". Using the fact that there are arbitrarily large ")#mi("{n}")#text(" with ")#mi("{g^n \\in U}")#text(", we may thus cover ")#mi("{U^3}")#text(" by a finite number of translates ")#mi("{g^{m_j} U^3}")#text(" of ")#mi("{U^3}")#text(" with ")#mi("{m_j > 0}")#text(". In particular, if ")#mi("{g^n \\in U^3}")#text(", then there exists an ")#mi("{m_j}")#text(" such that ")#mi("{g^{n-m_j} \\in U^3}")#text(". Iterating this, we see that the set ")#mi("{\\{ n \\in {\\bf Z}: g^n \\in U^3 \\}}")#text(" is left-")#link("http://en.wikipedia.org/wiki/Syndetic_set")[#text("syndetic")]#text(", in that it has bounded gaps as one goes to ")#mi("{-\\infty}")#text(". Similarly one can argue that this set is right-syndentic and thus syndetic. This implies that the entire group ")#mi("{\\langle g \\rangle}")#text(" is covered by a bounded number of translates of ")#mi("{U^3}")#text(" and is thus precompact as required. ")#mi("\\Box")

#text("Now we can prove Proposition ")#link(<tao-b8d19b6206b72bf403a0>)[#text("11")]#text(".")

#emph[#text("Proof:")]#text(" Let us say that a locally compact Hausdorff abelian group has ")#emph[#text("rank at most ")#mi("{r}")]#text(" if it has a cocompact subgroup generated by at most ")#mi("{r}")#text(" generators. We will induct on the rank ")#mi("{r}")#text(". If ")#mi("{G}")#text(" has rank ")#mi("{0}")#text(", then the cocompact subgroup is trivial, and the claim is obvious; so suppose that ")#mi("{G}")#text(" has some rank ")#mi("{r \\geq 1}")#text(", and the claim has already been proven for all smaller ranks.")

#text("By hypothesis, ")#mi("{G}")#text(" has a cocompact subgroup ")#mi("{\\Gamma}")#text(" generated by ")#mi("{r}")#text(" generators ")#mi("{e_1,\\ldots,e_r}")#text(". By Lemma ")#link(<tao-31d123108dba5fd36075>)[#text("12")]#text(", the group ")#mi("{\\langle e_r \\rangle}")#text(" is either precompact or discrete. If it is discrete, then we can quotient out by that group to obtain a locally compact Hausdorff abelian group ")#mi("{G / \\langle e_r \\rangle}")#text(" of rank at most ")#mi("{r-1}")#text("; by induction hypothesis, ")#mi("{G/\\langle e_r \\rangle}")#text(" has a cocompact discrete subgroup, and so ")#mi("{G}")#text(" does also. Hence we may assume that ")#mi("{\\langle e_r \\rangle}")#text(" is precompact, and more generally that ")#mi("{\\langle e_i \\rangle}")#text(" is precompact for each ")#mi("{i}")#text(". But as we are in an abelian group, ")#mi("{\\Gamma}")#text(" is the product of all the ")#mi("{\\langle e_i \\rangle}")#text(", and is thus also precompact, so ")#mi("{\\overline{\\Gamma}}")#text(" is compact. But ")#mi("{G/\\overline{\\Gamma}}")#text(" is a quotient of ")#mi("{G/\\Gamma}")#text(" and is also compact, and so ")#mi("{G}")#text(" itself is compact, and the claim follows in this case. ")#mi("\\Box")

#text("We can then combine this with the Gleason-Yamabe theorem for compact groups to obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 13 (Gleason-Yamabe theorem for abelian groups)")]#text(" Let ")#mi("{G}")#text(" be a locally compact abelian Hausdorff group, and let ")#mi("{U}")#text(" be a neighbourhood of the identity. Then there exists a compact normal subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" contained in ")#mi("{U}")#text(" such that ")#mi("{G/H}")#text(" is isomorphic to a Lie group.")
]

#emph[#text("Proof:")]#text(" By Lemma ")#link(<tao-abd8cfba151826bb7bf3>)[#text("10")]#text(" and Proposition ")#link(<tao-b8d19b6206b72bf403a0>)[#text("11")]#text(", we can find an open subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" and discrete cocompact subgroup ")#mi("{\\Gamma}")#text(" of ")#mi("{G^{\\prime}}")#text(". By shrinking ")#mi("{U}")#text(" as necessary, we may assume that ")#mi("{U}")#text(" is symmetric and ")#mi("{U^2}")#text(" only intersects ")#mi("{\\Gamma}")#text(" at the identity. Let ")#mi("{\\pi: G^{\\prime} \\rightarrow G^{\\prime}/\\Gamma}")#text(" be the projection to the compact abelian group ")#mi("{G^{\\prime}/\\Gamma}")#text(", then ")#mi("{\\pi(U)}")#text(" is a neighbourhood of the identity in ")#mi("{G^{\\prime}/\\Gamma}")#text(". By Theorem ")#link(<tao-9236ae3dbf9d1927cf02>)[#text("8")]#text(", one can find a compact normal subgroup ")#mi("{H^{\\prime}}")#text(" of ")#mi("{G^{\\prime}/\\Gamma}")#text(" in ")#mi("{\\pi(U)}")#text(" such that ")#mi("{(G^{\\prime}/\\Gamma)/H^{\\prime}}")#text(" is isomorphic to a linear group, and thus to a Lie group. If we set ")#mi("{H := \\pi^{-1}(H^{\\prime}) \\cap U}")#text(", it is not difficult to verify that ")#mi("{H}")#text(" is also a compact normal subgroup of ")#mi("{G^{\\prime}}")#text(". If ")#mi("{\\phi: G^{\\prime} \\rightarrow G^{\\prime}/H}")#text(" is the quotient map, then ")#mi("{\\phi(\\Gamma)}")#text(" is a discrete subgroup of ")#mi("{G^{\\prime}/H}")#text(" and from abstract nonsense one sees that ")#mi("{(G^{\\prime}/H)/\\phi(\\Gamma)}")#text(" is isomorphic to the Lie group ")#mi("{(G/\\Gamma)/H^{\\prime}}")#text(". Thus ")#mi("{G^{\\prime}/H}")#text(" is locally Lie. Since ")#mi("{G^{\\prime}}")#text(" is an open subgroup of the abelian group ")#mi("{G}")#text(", ")#mi("{G/H}")#text(" is locally Lie also, and is thus ")#mi("{G/H}")#text(" is isomorphic to a Lie group by Exercise 15 of ")#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")[#text("Notes 1")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Show that the Hausdorff hypothesis can be dropped from the above theorem.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24 (Characters separate points)")]#text(" Let ")#mi("{G}")#text(" be a locally compact Hausdorff abelian group, and let ")#mi("{g \\in G}")#text(" be not equal to the identity. Show that there exists a character ")#mi("{\\chi: G \\rightarrow S^1}")#text(" (see Exercise ")#link(<tao-aab210d24ab706a6b387>)[#text("22")]#text(") such that ")#mi("{\\chi(g) \\neq 1}")#text(". This result can be used as the foundation of the theory of ")#link("http://en.wikipedia.org/wiki/Pontryagin_duality")[#text("Pontryagin duality")]#text(" in abstract ")#link("http://en.wikipedia.org/wiki/Harmonic_analysis")[#text("harmonic analysis")]#text(", but we will not pursue this here; see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=152834")[#text("this text of Rudin")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" Show that every locally compact abelian Hausdorff group is isomorphic to the inverse limit of abelian Lie groups.")
]

#text("Thus, in principle at least, the study of locally compact abelian group is reduced to that of abelian Lie groups, which are more or less easy to classify:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]

#list(
[#text("Show that every discrete subgroup of ")#mi("{{\\bf R}^d}")#text(" is isomorphic to ")#mi("{{\\bf Z}^{d^{\\prime}}}")#text(" for some ")#mi("{0 \\leq d^{\\prime} \\leq d}")#text(".")],
[#text("Show that every connected abelian Lie group ")#mi("{G}")#text(" is isomorphic to ")#mi("{{\\bf R}^d \\times ({\\bf R}/{\\bf Z})^{d^{\\prime}}}")#text(" for some natural numbers ")#mi("{d, d^{\\prime}}")#text(". (")#emph[#text("Hint:")]#text(" first show that the kernel of the exponential map is a discrete subgroup of the Lie algebra.) Conclude in particular the ")#emph[#text("divisibility property")]#text(" that if ")#mi("{g \\in G}")#text(" and ")#mi("{n \\geq 1}")#text(" then there exists ")#mi("{h \\in G}")#text(" with ")#mi("{h^n = g}")#text(".")],
[#text("Show that every compact abelian Lie group ")#mi("{G}")#text(" is isomorphic to ")#mi("{({\\bf R}/{\\bf Z})^d \\times H}")#text(" for some natural number ")#mi("{d}")#text(" and a ")#mi("{H}")#text(" which is a finite product of finite cyclic groups. (You may need the ")#link("http://en.wikipedia.org/wiki/Finitely-generated_abelian_group")[#text("classification of finitely generated abelian groups")]#text(", and will also need the divisibility property to lift a certain finite group from a certain quotient space back to ")#mi("{G}")#text(".)")],
[#text("Show that every abelian Lie group contains an open subgroup that is isomorphic to ")#mi("{{\\bf R}^d \\times ({\\bf R}/{\\bf Z})^{d^{\\prime}} \\times {\\bf Z}^{d^{\\prime\\prime}} \\times H}")#text(" for some natural numbers ")#mi("{d,d^{\\prime},d^{\\prime\\prime}}")#text(" and a finite product ")#mi("{H}")#text(" of finite cyclic groups.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" Despite the quite explicit description of (most) abelian Lie groups, some interesting behaviour can still occur in locally compact abelian groups after taking inverse limits; consider for instance the solenoid example (Exercise 6 from ")#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/")[#text("Notes 0")]#text(").")
]

#heading(level: 1)[#text("Comments (31)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-86004")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2011")])]

#text("In the uniqueness part of theorem 3, exactly which Fubini or Tonelli type theorem are you using? (related also to the interesting exercise 5 and comments inside).")

#text("Later, related to the comment which starts with: “In the case when {G} is metrisable…”, question: are there non metrisable examples where theorem 3 is true?")

#text("Typo: in exercise 10, “(Counterexample) Let {G} be the {ax+b} group from Example 6(vii)”, should be “exercise 6(viii)”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-86149")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2011")])]

#text("Thanks for the correction.")

#text("In the proof of uniqueness in the post, one is working with continuous functions of compact support, so (by local finiteness) one has absolute integrability and finite measure and so any version of the Fubini-Tonelli theorem will work here. The more serious use of sigma-compactness in the uniqueness argument given above lies in the use of the Riesz representation theorem. Without that theorem, one would have to work with more general measurable functions in the Fubini-Tonelli argument, at which point sigma-compactness (and hence sigma-finiteness) will become important.")

#text("Thanks to the Birkhoff-Kakutani theorem (that I will discuss in the next set of notes), a group is metrisable iff it is first countable (and hence also second-countable, in the sigma-compact case), which is more or less the minimum needed for the Arzela-Ascoli argument to work, so metrisability is basically the limit of that approach. Of course, one could modify Arzela-Ascoli by replacing sequences with nets and ultrafilters to avoid the dependence on countability, but then one is basically back to one of the other compactness methods outlined in the post.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Diego")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-86477")[#strong[#text("Diego")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2011")])]

#text("Thank you for this wonderful post Terry. Regarding further properties of the Haar measure, I know of an article in which the doubling property for the Haar measure on an *abelian* LCG is proved. Do you know whether this property (meaning, the existence of C > 0 s.t.")

#text("\\mu(B(x,2r)) \\leq C \\mu(B(x,r), for all x \\in G, r >0) holds true in general?")#linebreak()#text(" If not, how about the growth condition: there exists N > 0 such that")

#text("\\mu(B(x,r)) \\leq C r^N ?")

#text("Also, how about the “weak homogeneity property” (i.e. there exists N such that for all x \\in G and r > 0, N balls of radius r/2 are enough to cover B(x, r))? Does it always hold true for a general LCG? This property is proved for some special groups in Coifman and Weiss’ seminal work on spaces of homogeneous type.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-86610")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2011")])]

#text("I’m not sure what results you are referring to, because the metric on the locally compact group G is not specified. There are certainly metrics on LCA groups that are not doubling at small scales, for instance take the ")#mi("\\ell^1")#text(" sum of the circles ")#mi("{\\bf R}/2^{-n} {\\bf Z}")#text(" for ")#mi("n=1,2,\\ldots")#text(", which has increasingly large dimension at small scales and so is not doubling. At large scales the situation is better because one can show (after passing to an open subgroup, at least) that there is a cocompact discrete abelian subgroup of bounded rank (see Proposition 11 of the above post) which can be used to construct at least one metric on an LCA group that is doubling at large scales.")

#text("In the nonabelian case, though, one only expects doubling or polynomial growth at large scales if the group is essentially nilpotent at these scales; in the case of discrete finitely generated groups with the word metric, this is Gromov’s theorem, and (as we shall see in later notes) there are analogues for continuous groups also.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Diego")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-86796")[#strong[#text("Diego")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2011")])]

#text("Thanks Terry. In principle I meant any given translation-invariant distance on GxG, but after your answer I realize that’s too weak a condition.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4450e4147da948396f9d590eb40b1246afeb87db0fd0a8ec51bbcc51fe1eac21-ae1f804a76f2a60c4772084e2489da8325de083c3b3918ded8ea25acd323a3ae.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Neil Strickland")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-87007")[#strong[#text("Neil Strickland")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2011")])]

#text("In the compact case I like this characterisation: $I(f)$ is the unique constant function in the closure of the convex hull of the translates of $f$. I don’t know if there is any way to adapt that to the noncompact case, though.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-87127")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2011")])]

#text("Ah, yes, thanks for mentioning that method; I’ve added a remark referencing it to the notes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-87042")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2011")])]

#text("Thank you for the reply. Re: Neil Strickland, the technique resembles the one used in the calculus of variations to show that the quasiconvexification of an integral functional defined on ")#mi("W^{1,p}")#text(", with integrand depending only on the gradient, is an integral functional too, with integrand depending only on the gradient. Interestingly, by Morrey, quasiconvexity of the integrand is equivalent with the lower semicontinuity of the integral, and continuity of the integral (on functions with compact support, say) is equivalent with the integral being constant.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 4: Building metrics on groups, and the Gleason-Yamabe theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-89085")[#strong[#text("254A, Notes 4: Building metrics on groups, and the Gleason-Yamabe theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2011")])]

#text("[…] is the existence of a left-invariant Haar measure on any locally compact group; see Theorem 3 from Notes 3. Finally, we will also need the compact case of the Gleason-Yamabe theorem (Theorem 8 from Notes […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 5: The structure of locally compact groups, and Hilbert’s fifth problem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-90826")[#strong[#text("254A, Notes 5: The structure of locally compact groups, and Hilbert’s fifth problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2011")])]

#text("[…] the full group ; in particular, by arguing as in the treatment of the compact case (Exercise 19 of Notes 3), we conclude that any connected locally compact Hausdorff group is the inverse limit of Lie […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel zorin")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-91035")[#strong[#text("pavel zorin")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2011")])]

#text("Dear Prof. Tao,")

#text("the hint to Exercise 19 is misleading: one should rather index the linear groups by finite subsets of a neighborhood base of the identity, otherwise there are no obvious natural homomorphisms between them.")

#text("best regards,")#linebreak()#text(" pavel")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-97814")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2011")])]

#text("Hi,")

#text("In Exercise 6.vi, by a nilpotent Lie group do you mean a Lie group whose Lie algebra is nilpotent? These are not the same since e.g., the group in Exercise 6.viii is nilpotent as a group. Also, Exercise 6.viii has a random equation in the middle of a sentence.")

#emph[#text("[Corrected, thanks. For connected Lie groups, nilpotency of the group is equivalent to nilpotency of the Lie algebra; this is a consequence of the Baker-Campbell-Hausdorff formula.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-97815")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2011")])]

#text("Oops, never mind, that group is solvable, not nilpotent.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The microstructure of approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-101201")[#strong[#text("254A, Notes 8: The microstructure of approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2011")])]

#text("[…] measure (or Lebesgue measure) on is a bi-invariant Haar measure on . (Recall from Exercise 6 of Notes 3 that connected nilpotent Lie groups are […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b20e8604c5c0bd339b5c22ea32b9d9a9a2a9076cffd57371e0b72039b3bf01b-7025fcd9a838763784076db7610966d0f7c0d00ac8419f2b346f30fcba08a112.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alingalatan")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-101359")[#strong[#text("alingalatan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2011")])]

#text("In lemma 10, shouldn’t ")#mi("\\Gamma")#text(" be generated by S (and not K) ?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 2: Cayley graphs and Kazhdan’s property (T) « What’s new")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-113279")[#strong[#text("254B, Notes 2: Cayley graphs and Kazhdan’s property (T) « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2011")])]

#text("[…] a proof that any locally compact group has a Haar measure, unique up to scalar multiplication), see this previous blog post of mine. Example 5 (Quasiregular representation) If is a measure space that acts on in a transitive […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d8fca51d51d67bd4c7358d7c54247d28b01d50483b99c9482447316889ad6c0-0c29a534082f19a6a4a98b0f84ca03874df6f107bce899f1ae2d287f3bb301e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felix")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-141253")[#strong[#text("Felix")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2012")])]

#text("Dear Prof. Tao,")

#text("I am very much interested in the question if (at least in the (sigma) compact case) the Haar measure is still unique (up to a constant factor), if one drops the regularity assumptions and just assumes it to be (left) translation invariant and locally finite.")

#text("Up to now I was unable to find any statement regarding that question in the literature. When I saw your exercise 5 above, I hoped that this could prove the uniqueness (because one cannot invoke the Riesz representation theorem without regularity), but I can only show that for every x in G there is some null set N_x (possibly depending upon x!) such that f equals its translation by x on the complement of N_x. Without further regularity assumptions I seem unable to show that there is one null set N which does the trick for all x in G.")

#text("Can you give me a hint or do you know whether the uniqueness still holds in the non-regular case?")

#text("Best regards,")

#text("Felix V.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-141541")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2012")])]

#text("If the group is sigma-compact and first-countable (hence metrisable), then all locally finite Borel measures are automatically Radon; see Exercise 12 of ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("these notes of mine")]#text(". Offhand, I don’t know what happens without the sigma-compact and first-countability hypotheses but suspect that some pathological counterexamples can arise in those cases (though maybe the translation invariance of the measure could prohibit this).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on simple groups of Lie type | What's new")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-243960")[#strong[#text("Notes on simple groups of Lie type | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("[…] of for any ). Indeed, letting be the compact form of , the Peter-Weyl theorem (as discussed in this previous blog post) we see that can be identified with a unitary Lie group (i.e. a real Lie subgroup of for some ); […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dea4d164a18f5fd7b8573181090f208335a7eebe1f2e76aa579c45ec4dfb9cee-aab91af758fcad6c8b83072bdeb5dc0c077e0b67d96368a332ec4e213cdf6aa6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ignacio Villanueva")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-408828")[#strong[#text("Ignacio Villanueva")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2014")])]

#text("Dear Prof. Tao,")#linebreak()#text(" is there any “bounded additive” version of the Haar measure?. That is, we consider a ($\\sigma$-compact Hausdorff) locally compact group G. We know that there exists a unique left-invariant Radon measure \\mu. If we now consider also bounded additive measures, is there another measure such measure \\nu different from \\mu that is also left-invariant? I guess this is essentially equivalent to prove the existence of a purely not countably additive measure which is left-invariant. Do you know if such objects exist?")

#text("Thank you very much,")

#text("Ignacio")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-408867")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2014")])]

#text("If the group G is ")#link("http://en.wikipedia.org/wiki/Amenable_group")[#text("amenable")]#text(", then it has an invariant mean which will be a non-trivial finite left-invariant additive measure (I’m not sure what you mean by a bounded measure). If the group G is not amenable, then no such finite measure exists, but infinite measures would still exist. A trivial example would be to modify Haar measure by redefining the measure of any unbounded set to automatically be infinite.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dea4d164a18f5fd7b8573181090f208335a7eebe1f2e76aa579c45ec4dfb9cee-aab91af758fcad6c8b83072bdeb5dc0c077e0b67d96368a332ec4e213cdf6aa6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ignacio")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-409368")[#strong[#text("Ignacio")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2014")])]

#text("Thank you very much for the very quick answer. Probably it is indeed amenability the relevant condition I am searching for. Thanks again.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86c20a55a8d3f2edad3f633ed183739984acbfa4b57c93c14b2121b4a438fed7-572cd804beffcf18449723717132e1a3a06c857e1142dd71e223c35b4ae0ab50.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ilya Tsindlekht")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-420158")[#strong[#text("Ilya Tsindlekht")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2014")])]

#text("I think in the proof of uniqueness of Haar measure you need to show that ")#mi("\\int \\psi_\\epsilon(x^{-1})d\\nu(x)")#text(" behaves nicely as $epsilon$ goes to 0.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86c20a55a8d3f2edad3f633ed183739984acbfa4b57c93c14b2121b4a438fed7-572cd804beffcf18449723717132e1a3a06c857e1142dd71e223c35b4ae0ab50.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ilya Tsindlekht")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-420168")[#strong[#text("Ilya Tsindlekht")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2014")])]

#text("Sorry, I have been wrong.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8984268777854dc1f1c79a0f5d88d87baf33a6ede6baefccc0db3e21372576a4-fc9c7a4b874c592dbff988b2451d34182dababeff7e9b6f48d9a4812e40f79d9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-437186")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2014")])]

#text("Dear Prof. Tao,")#linebreak()#text(" do you know if a not connected locally compact group always can be inverse limit of second countable locally compact groups?")

#text("Thank you very much")

#text("Mauro")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ab2bffea97dcac67c1709c62af07670d6d784816955980f9179e07bda2cfb98-6605380d7bc9334bf914fb3e8275984edcebf84b85f7824307751cd018e5efa5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jcdiaz2015")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-453966")[#strong[#text("jcdiaz2015")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2015")])]

#text("Dear Professor Tao,")

#text("I was glad to discover this nice post. I would just like to point out that Stroppel’s book ”Locally Compact Groups” contains an elementary proof of the uniqueness part of the Haar measure. It uses Urysohn’s Lemma and uniform convergence.")

#text("Best regards,")#linebreak()#text(" Juan.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-457702")[#strong[#text("Lattices, the geometry of numbers, and adeles | the capacity to be alone")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2015")]

#text("[…] treatments of the (in my opinion, tedious) theory behind Haar measure readily available; I like this more algebraic treatment by Terry Tao more than some of the others, but you can look around if you’re interested in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of VMT")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-490981")[#strong[#text("VMT")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2017")])]

#text("Hi Terry,")#linebreak()#text(" – the first definition of convolution (little beyond (1)) seems inconsistent with the formula you use later on: they agree only when the group is unimodular")#linebreak()#text(" – in the proof of uniqueness of Haar measure, one may want to observe that ")#mi("\\int_G\\psi_\\epsilon(x^{-1})\\,d\\nu(x)")#text(" stays far from 0 as ")#mi("\\epsilon\\to 0")#text(", as one sees from the identity ")#mi("I_\\nu(f)=I_\\mu(f)\\int_G\\psi_\\epsilon(x^{-1})\\,d\\nu(x)+O(\\epsilon)")#text(" and Ex. 4 using a fixed nonnegative (nontrivial) f")#linebreak()#text(" – in the Hint for Ex. 7, I think you want the integrand ")#mi("g(yx)c(x)f(x)^{-1}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-490987")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2017")])]

#text("Thanks for the corrections! The lower bound on ")#mi("\\int_G \\psi_\\varepsilon(x^{-1})\\ d\\nu(x)")#text(" is true, but I don’t think it’s actually needed for the proof, as we don’t actually divide by this quantity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of VMT")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-491018")[#strong[#text("VMT")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2018")])]

#text("Ah yes, of course! (In my mind I was reaching the last estimate in a cumbersome way, rather than by direct substitution)")

#text("I would like to share a “variational” route for the last part of the proof of Theorem 6: ")#mi("T(B)")#text(" is compact, being precompact and closed (as ")#mi("B")#text(", and hence ")#mi("T(B)")#text(", are weakly compact and thus weakly closed). So there exists a vector ")#mi("x\\in B")#text(" maximising ")#tao-math("\\left\\|Tx\\right\\|^2", block: false)#text("; necessarily ")#tao-math("\\left\\|x\\right\\|=1", block: false)#text(" and ")#tao-math("\\left\\|Tx\\right\\|=\\left\\|T\\right\\|_{op}", block: false)#text(". For any ")#mi("y\\in W")#text(", the function")#linebreak()#text(" ")#tao-math("\\Big{\\left\\|\\frac{\\left\\|T(x+ty)\\right\\|}{\\left\\|x+ty\\right\\|}\\right\\|}^2", block: false)#text(", defined for ")#mi("t")#text(" near 0, has a maximum at ")#mi("t=0")#text(". Differentiation gives")#linebreak()#text(" ")#tao-math("\\langle Tx,Ty\\rangle-\\left\\|Tx\\right\\|^2\\langle x,y\\rangle=0", block: false)#text(" for every ")#mi("y\\in W")#text(", i.e. by self-adjointness ")#tao-math("(T-\\left\\|T\\right\\|_{op})(T-\\left\\|T\\right\\|_{op})x=T^2x-\\left\\|Tx\\right\\|^2x=0", block: false)#text(". Hence at least one among ")#tao-math("\\left\\|T\\right\\|_{op}", block: false)#text(" and ")#tao-math("-\\left\\|T\\right\\|_{op}", block: false)#text(" is an eigenvalue.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of VMT")]], [#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/#comment-491020")[#strong[#text("VMT")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2018")])]

#text("(I meant ")#tao-math("\\Big{\\left\\|T\\Big{\\left(\\frac{x+ty}{\\left\\|x+ty\\right\\|}\\right)}\\right\\|}^2", block: false)#text(", i.e. ")#tao-math("\\frac{\\left\\|Tx+tTy\\right\\|^2}{\\left\\|x+ty\\right\\|^2}", block: false)#text("…)")
]
]
]
]
