// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/
// Converted to Typst by tao2typ: "2026-10-14T15:17:50.561592+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245A, prologue: The problem of measure", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245A, prologue: The problem of measure")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 September 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/")[#text("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of the most fundamental concepts in Euclidean geometry is that of the ")#emph[#text("measure")]#text(" ")#mi("{m(E)}")#text(" of a solid body ")#mi("{E}")#text(" in one or more dimensions. In one, two, and three dimensions, we refer to this measure as the ")#emph[#text("length")]#text(", ")#emph[#text("area")]#text(", or ")#emph[#text("volume")]#text(" of ")#mi("{E}")#text(" respectively. In the classical approach to geometry, the measure of a body was often computed by partitioning that body into finitely many components, moving around each component by a rigid motion (e.g. a translation or rotation), and then reassembling those components to form a simpler body which presumably has the same area. One could also obtain lower and upper bounds on the measure of a body by computing the measure of some inscribed or circumscribed body; this ancient idea goes all the way back to the work of Archimedes at least. Such arguments can be justified by an appeal to geometric intuition, or simply by postulating the existence of a measure ")#mi("{m(E)}")#text(" that can be assigned to all solid bodies ")#mi("{E}")#text(", and which obeys a collection of geometrically reasonable axioms. One can also justify the concept of measure on “physical” or “reductionistic” grounds, viewing the measure of a macroscopic body as the sum of the measures of its microscopic components.")

#text("With the advent of ")#link("http://en.wikipedia.org/wiki/Analytic_geometry")[#text("analytic geometry")]#text(", however, Euclidean geometry became reinterpreted as the study of Cartesian products ")#mi("{{\\bf R}^d}")#text(" of the real line ")#mi("{{\\bf R}}")#text(". Using this analytic foundation rather than the classical geometrical one, it was no longer intuitively obvious how to define the measure ")#mi("{m(E)}")#text(" of a general subset ")#mi("{E}")#text(" of ")#mi("{{\\bf R}^d}")#text("; we will refer to this (somewhat vaguely defined) problem of writing down the “correct” definition of measure as the ")#emph[#text("problem of measure")]#text(". (One can also pose the problem of measure on other domains than Euclidean space, such as a Riemannian manifold, but we will focus on the Euclidean case here for simplicity.)")

#text("To see why this problem exists at all, let us try to formalise some of the intuition for measure discussed earlier. The physical intuition of defining the measure of a body ")#mi("{E}")#text(" to be the sum of the measure of its component “atoms” runs into an immediate problem: a typical solid body would consist of an infinite (and uncountable) number of points, each of which has a measure of zero; and the product ")#mi("{\\infty \\cdot 0}")#text(" is indeterminate. To make matters worse, two bodies that have exactly the same number of points, need not have the same measure. For instance, in one dimension, the intervals ")#mi("{A := [0,1]}")#text(" and ")#mi("{B := [0,2]}")#text(" are in one-to-one correspondence (using the bijection ")#mi("{x \\mapsto 2x}")#text(" from ")#mi("{A}")#text(" to ")#mi("{B}")#text("), but of course ")#mi("{B}")#text(" is twice as long as ")#mi("{A}")#text(". So one can disassemble ")#mi("{A}")#text(" into an uncountable number of points and reassemble them to form a set of twice the length.")

#text("Of course, one can point to the infinite (and uncountable) number of components in this disassembly as being the cause of this breakdown of intuition, and restrict attention to just finite partitions. But one still runs into trouble here for a number of reasons, the most striking of which is the ")#link("http://en.wikipedia.org/wiki/Banach%E2%80%93Tarski_paradox")[#text("Banach-Tarski paradox")]#text(", which shows that the unit ball ")#mi("{B := \\{ (x,y,z) \\in {\\bf R}^3: x^2+y^2+z^2 \\leq 1 \\}}")#text(" in three dimensions can be disassembled into a finite number of pieces (in fact, just five pieces suffice), which can then be reassembled (after translating and rotating each of the pieces) to form two disjoint copies of the ball ")#mi("{B}")#text(". (The paradox only works in three dimensions and higher, for reasons having to do with the property of ")#link("http://en.wikipedia.org/wiki/Amenable_group")[#text("amenability")]#text("; see ")#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/")[#text("this blog post")]#text(" for further discussion of this interesting topic, which is unfortunately too much of a digression from the current subject.)")

#text("Here, the problem is that the pieces used in this decomposition are highly pathological in nature; among other things, their construction requires use of the ")#link("http://en.wikipedia.org/wiki/Axiom_of_choice")[#text("axiom of choice")]#text(". (This is in fact necessary; there are models of set theory without the axiom of choice in which the Banach-Tarski paradox does not occur, thanks to a famous ")#link("http://en.wikipedia.org/wiki/Solovay_model")[#text("theorem of Solovay")]#text(".) Such pathological sets almost never come up in practical applications of mathematics. Because of this, the standard solution to the problem of measure has been to abandon the goal of measuring ")#emph[#text("every")]#text(" subset ")#mi("{E}")#text(" of ")#mi("{{\\bf R}^d}")#text(", and instead to settle for only measuring a certain subclass of “non-pathological” subsets of ")#mi("{{\\bf R}^d}")#text(", which are then referred to as the ")#emph[#text("measurable sets")]#text(". The problem of measure then divides into several subproblems:")

#enum(start: 1, 
[#text("What does it mean for a subset ")#mi("{E}")#text(" of ")#mi("{{\\bf R}^d}")#text(" to be measurable?")],
[#text("If a set ")#mi("{E}")#text(" is measurable, how does one define its measure?")],
[#text("What nice properties or axioms does measure (or the concept of measurability) obey?")],
[#text("Are “ordinary” sets such as cubes, balls, polyhedra, etc. measurable?")],
[#text("Does the measure of an “ordinary” set equal the “naive geometric measure” of such sets? (e.g. is the measure of an ")#mi("{a \\times b}")#text(" rectangle equal to ")#mi("{ab}")#text("?)")]
)

#text("These questions are somewhat open-ended in formulation, and there is no unique answer to them; in particular, one can expand the class of measurable sets at the expense of losing one or more nice properties of measure in the process (e.g. finite or countable additivity, translation invariance, or rotation invariance). However, there are two basic answers which, between them, suffice for most applications. The first is the concept of ")#link("http://en.wikipedia.org/wiki/Jordan_measure")[#text("Jordan measure")]#text(" of a Jordan measurable set, which is a concept closely related to that of the ")#link("http://en.wikipedia.org/wiki/Riemann_integral")[#text("Riemann integral")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Darboux_integral")[#text("Darboux integral")]#text("). This concept is elementary enough to be systematically studied in an undergraduate analysis course, and suffices for measuring most of the “ordinary” sets (e.g. the area under the graph of a continuous function) in many branches of mathematics. However, when one turns to the type of sets that arise in ")#emph[#text("analysis")]#text(", and in particular those sets that arise as ")#emph[#text("limits")]#text(" (in various senses) of other sets, it turns out that the Jordan concept of measurability is not quite adequate, and must be extended to the more general notion of ")#emph[#text("Lebesgue measurability")]#text(", with the corresponding notion of ")#link("http://en.wikipedia.org/wiki/Lebesgue_measure")[#text("Lebesgue measure")]#text(" that extends Jordan measure. With the Lebesgue theory (which can be viewed as a ")#emph[#text("completion")]#text(" of the Jordan-Darboux-Riemann theory), one keeps almost all of the desirable properties of Jordan measure, but with the crucial additional property that many features of the Lebesgue theory are preserved under limits (as exemplified in the fundamental ")#emph[#text("convergence theorems")]#text(" of the Lebesgue theory, such as the ")#link("http://en.wikipedia.org/wiki/Monotone_convergence_theorem")[#text("monotone convergence theorem")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Dominated_convergence_theorem")[#text("dominated convergence theorem")]#text(", which do not hold in the Jordan-Darboux-Riemann setting). As such, they are particularly well suited for applications in analysis, where limits of functions or sets arise all the time. (There are ")#link("http://en.wikipedia.org/wiki/Integral#Formal_definitions")[#text("other ways")]#text(" to extend Jordan measure and the Riemann integral, but the Lebesgue approach handles limits better than the other alternatives, and so has become the standard approach in analysis.)")

#text("In the rest of the course, we will formally define Lebesgue measure and the Lebesgue integral, as well as the more general concept of an abstract measure space and the associated integration operation. In the rest of this post, we will discuss the more elementary concepts of Jordan measure and the Riemann integral. This material will eventually be superceded by the more powerful theory to be treated in the main body of the course; but it will serve as motivation for that later material, as well as providing some continuity with the treatment of measure and integration in undergraduate analysis courses.")

#metadata(none) <tao-007fb84595d5128a060f>

#heading(level: 1)[#strong[#text(" — 1. Elementary measure — ")]]

#text("Before we discuss Jordan measure, we discuss the even simpler notion of ")#emph[#text("elementary measure")]#text(", which allows one to measure a very simple class of sets, namely the ")#emph[#text("elementary sets")]#text(" (finite unions of boxes).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Intervals, boxes, elementary sets)")]#text(" An ")#emph[#text("interval")]#text(" is a subset of ")#mi("{{\\bf R}}")#text(" of the form ")#mi("{[a,b] := \\{ x \\in {\\bf R}: a \\leq x \\leq b \\}}")#text(", ")#mi("{[a,b) := \\{ x \\in {\\bf R}: a \\leq x < b \\}}")#text(", ")#mi("{(a,b] := \\{ x \\in {\\bf R}: a < x \\leq b \\}}")#text(", or ")#mi("{(a,b) := \\{x \\in {\\bf R}: a < x < b \\}}")#text(", where ")#mi("{a \\leq b}")#text(" are real numbers. We define the ")#emph[#text("length")]#text(" ")#tao-math("{\\left|I\\right|}", block: false)#text(" of an interval ")#mi("{I = [a,b], [a,b), (a,b], (a,b)}")#text(" to be ")#tao-math("{\\left|I\\right| := b-a}", block: false)#text(". (Note we allow degenerate intervals of zero length.) A ")#emph[#text("box")]#text(" in ")#mi("{{\\bf R}^d}")#text(" is a Cartesian product ")#mi("{B := I_1 \\times \\ldots \\times I_d}")#text(" of ")#mi("{d}")#text(" intervals ")#mi("{I_1,\\ldots,I_d}")#text(" (not necessarily of the same length), thus for instance an interval is a one-dimensional box. The ")#emph[#text("volume")]#text(" ")#tao-math("{\\left|B\\right|}", block: false)#text(" of such a box ")#mi("{B}")#text(" is defined as ")#tao-math("{\\left|B\\right| := \\left|I_1\\right| \\times \\ldots \\times \\left|I_d\\right|}", block: false)#text(". An ")#emph[#text("elementary set")]#text(" is any subset of ")#mi("{{\\bf R}^d}")#text(" which is the union of a finite number of boxes.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1 (Boolean closure)")]#text(" ")#metadata(none) <tao-62e9f9c21a6601df04d4>#text(" Show that if ")#mi("{E, F \\subset {\\bf R}^d}")#text(" are elementary sets, then the union ")#mi("{E \\cup F}")#text(", the intersection ")#mi("{E \\cap F}")#text(", and the set theoretic difference ")#mi("{E \\backslash F}")#text(", and the symmetric difference ")#mi("{E \\Delta F := (E \\backslash F) \\cup (F \\backslash E)}")#text(" are also elementary. If ")#mi("{x \\in {\\bf R}^d}")#text(", show that the translate ")#mi("{E+x := \\{ y+x: y \\in E \\}}")#text(" is also an elementary set.")
]

#text("We now give each elementary set a measure.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Measure of an elementary set)")]#text(" Let ")#mi("{E \\subset {\\bf R}^d}")#text(" be an elementary set.")

#enum(start: 1, 
[#mi("{E}")#text(" can be expressed as the finite union of ")#emph[#text("disjoint")]#text(" boxes.")],
[#text("If ")#mi("{E}")#text(" is partitioned as the finite union ")#mi("{B_1 \\cup \\ldots \\cup B_k}")#text(" of disjoint boxes, then the quantity ")#tao-math("{m(E) := \\left|B_1\\right| + \\ldots + \\left|B_k\\right|}", block: false)#text(" is independent of the partition. In other words, given any other partition ")#mi("{B^{\\prime}_1 \\cup \\ldots \\cup B^{\\prime}_{k^{\\prime}}}")#text(" of ")#mi("{E}")#text(", one has ")#tao-math("{\\left|B_1\\right|+\\ldots+\\left|B_k\\right| = \\left|B^{\\prime}_1\\right|+\\ldots+\\left|B^{\\prime}_{k^{\\prime}}\\right|}", block: false)#text(".")

#text("We refer to ")#mi("{m(E)}")#text(" as the ")#emph[#text("elementary measure")]#text(" of ")#mi("{E}")#text(". (We occasionally write ")#mi("{m(E)}")#text(" as ")#mi("{m^d(E)}")#text(" to emphasise the ")#mi("{d}")#text("-dimensional nature of the measure.) Thus, for example, the elementary measure of ")#mi("{(1,2) \\cup [3,6]}")#text(" is ")#mi("{4}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" We first prove (1.) in the one-dimensional case ")#mi("{d=1}")#text(". Given any finite collection of intervals ")#mi("{I_1,\\ldots,I_k}")#text(", one can place the ")#mi("{2k}")#text(" endpoints of these intervals in increasing order (discarding repetitions). Looking at the open intervals between these endpoints, together with the endpoints themselves (viewed as intervals of length zero), we see that there exists a finite collection of disjoint intervals ")#mi("{J_1,\\ldots,J_{k^{\\prime}}}")#text(" such that each of the ")#mi("{I_1,\\ldots,I_k}")#text(" are a union of some subcollection of the ")#mi("{J_1,\\ldots,J_{k^{\\prime}}}")#text(". This already gives (1.) when ")#mi("{d=1}")#text(". To prove the higher dimensional case, we express ")#mi("{E}")#text(" as the union ")#mi("{B_1,\\ldots,B_k}")#text(" of boxes ")#mi("{B_i = I_{i,1} \\times \\ldots \\times I_{i,d}}")#text(". For each ")#mi("{j=1,\\ldots,d}")#text(", we use the one-dimensional argument to express ")#mi("{I_{1,j},\\ldots,I_{k,j}}")#text(" as the union of subcollections of a collection ")#mi("{J_{1,j},\\ldots,J_{k^{\\prime}_j,j}}")#text(" of disjoint intervals. Taking Cartesian products, we can express the ")#mi("{B_1,\\ldots,B_k}")#text(" as finite unions of boxes ")#mi("{J_{i_1,1} \\times \\ldots \\times J_{i_d,d}}")#text(", where ")#mi("{1 \\leq i_j \\leq k^{\\prime}_j}")#text(" for all ")#mi("{1 \\leq j \\leq d}")#text(". Such boxes are all disjoint, and the claim follows.")

#text("To prove (2.) we use a discretisation argument. Observe (exercise!) that for any interval ")#mi("{I}")#text(", the length of ")#mi("{I}")#text(" can be recovered by the limiting formula")

#align(center)[#tao-fit-display[#tao-math("\\left|I\\right| = \\lim_{N \\rightarrow \\infty} \\frac{1}{N} \\#( I \\cap \\frac{1}{N} {\\bf Z} )", block: true)]]

#text("where ")#mi("{\\frac{1}{N} {\\bf Z} := \\{ \\frac{n}{N}: n \\in {\\bf Z}\\}}")#text(" and ")#mi("{\\# A}")#text(" denotes the cardinality of a finite set ")#mi("{A}")#text(". Taking Cartesian products, we see that")

#align(center)[#tao-fit-display[#tao-math("\\left|B\\right| = \\lim_{N \\rightarrow \\infty} \\frac{1}{N^d} \\#( B \\cap \\frac{1}{N} {\\bf Z}^d )", block: true)]]

#text("for any box ")#mi("{B}")#text(", and in particular that")

#align(center)[#tao-fit-display[#tao-math("\\left|B_1\\right| + \\ldots + \\left|B_k\\right| = \\lim_{N \\rightarrow \\infty} \\frac{1}{N^d} \\#( E \\cap \\frac{1}{N} {\\bf Z}^d ).", block: true)]]

#text("Denoting the right-hand side as ")#mi("{m(E)}")#text(", we obtain the claim (2.). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Give an alternate proof of part (2.) of the above lemma by showing that any two partitions of ")#mi("{E}")#text(" into boxes admit a mutual refinement into boxes that arise from taking Cartesian products of elements from finite collections of disjoint intervals.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" One might be tempted to now define the measure ")#mi("{m(E)}")#text(" of an arbitrary set ")#mi("{E \\subset {\\bf R}^d}")#text(" by the formula ")#metadata(none) <tao-e90c560ecb63987067f5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("m(E) := \\lim_{N \\rightarrow \\infty} \\frac{1}{N^d} \\#( E \\cap \\frac{1}{N} {\\bf Z}^d ),")]]

#text("since this worked well for elementary sets. However, this definition is not particularly satisfactory for a number of reasons. Firstly, one can concoct examples in which the limit does not exist (Exercise!). Even when the limit does exist, this concept does not obey reasonable properties such as translation invariance. For instance, if ")#mi("{d=1}")#text(" and ")#mi("{E := {\\bf Q} \\cap [0,1] := \\{ x\\in {\\bf Q}: 0 \\leq x \\leq 1 \\}}")#text(", then this definition would give ")#mi("{E}")#text(" a measure of ")#mi("{1}")#text(", but would give the translate ")#mi("{E+\\sqrt{2} := \\{ x +\\sqrt{2}: x \\in {\\bf Q}; 0 \\leq x \\leq 1 \\}}")#text(" a measure of zero. Nevertheless, the formula ")#link(<tao-e90c560ecb63987067f5>)[#text("(1)")]#text(" will be valid for all Jordan measurable sets (see Exercise ")#link(<tao-809d2548c145cf911424>)[#text("13")]#text("). It also makes precise an important intuition, namely that the continuous concept of measure can be viewed as a limit of the discrete concept of (normalised) cardinality. (Another way to obtain continuous measure as the limit of discrete measure is via ")#link("http://en.wikipedia.org/wiki/Monte_Carlo_integration")[#text("Monte Carlo integration")]#text(", although in order to rigorously introduce the probability theory needed to set up Monte Carlo integration properly, one already needs to develop a large part of measure theory, so this perspective, while intuitive, is not suitable for foundational purposes.)")
]

#text("From the definitions, it is clear that ")#mi("{m(E)}")#text(" is a non-negative real number for every elementary set ")#mi("{E}")#text(", and that")

#align(center)[#tao-fit-display[#mitex("m(E \\cup F) = m(E) + m(F)")]]

#text("whenever ")#mi("{E}")#text(" and ")#mi("{F}")#text(" are disjoint elementary sets. We refer to the latter property as ")#emph[#text("finite additivity")]#text("; by induction it also implies that")

#align(center)[#tao-fit-display[#mitex("m(E_1 \\cup \\ldots \\cup E_k) = m(E_1) + \\ldots + m(E_k)")]]

#text("whenever ")#mi("{E_1,\\ldots,E_k}")#text(" are disjoint elementary sets. We also have the obvious degenerate case")

#align(center)[#tao-fit-display[#mitex("m(\\emptyset) = 0.")]]

#text("Finally, elementary measure clearly extends the notion of volume, in the sense that")

#align(center)[#tao-fit-display[#tao-math("m(B) = \\left|B\\right|", block: true)]]

#text("for all boxes ")#mi("{B}")#text(".")

#text("From non-negativity and finite additivity (and Exercise ")#link(<tao-62e9f9c21a6601df04d4>)[#text("1")]#text(") we conclude the ")#emph[#text("monotonicity property")]

#align(center)[#tao-fit-display[#mitex("m(E) \\leq m(F)")]]

#text("whenever ")#mi("{E \\subset F}")#text(" are nested elementary sets. From this and finite additivity (and Exercise ")#link(<tao-62e9f9c21a6601df04d4>)[#text("1")]#text(") we easily obtain the ")#emph[#text("finite subadditivity property")]

#align(center)[#tao-fit-display[#mitex("m(E \\cup F) \\leq m(E) + m(F)")]]

#text("whenever ")#mi("{E, F}")#text(" are elementary sets (not necessarily disjoint); by induction one then has")

#align(center)[#tao-fit-display[#mitex("m(E_1 \\cup \\ldots \\cup E_k) \\leq m(E_1) + \\ldots + m(E_k)")]]

#text("whenever ")#mi("{E_1,\\ldots,E_k}")#text(" are elementary sets (not necessarily disjoint).")

#text("It is also clear from the definition that we have the ")#emph[#text("translation invariance")]

#align(center)[#tao-fit-display[#mitex("m(E+x) = m(E)")]]

#text("for all elementary sets ")#mi("{E}")#text(" and ")#mi("{x \\in {\\bf R}^d}")#text(".")

#text("These properties in fact define elementary measure up to normalisation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3 (Uniqueness of elementary measure)")]#text(" ")#metadata(none) <tao-dc1388810d0db0ad8731>#text(" Let ")#mi("{d \\geq 1}")#text(". Let ")#mi("{m^{\\prime}: {\\mathcal E}({\\bf R}^d) \\rightarrow {\\bf R}^+}")#text(" be a map from the collection ")#mi("{{\\mathcal E}({\\bf R}^d)}")#text(" of elementary subsets of ")#mi("{{\\bf R}^d}")#text(" to the nonnegative reals that obeys the non-negativity, finite additivity, and translation invariance properties. Show that there exists a constant ")#mi("{c \\in {\\bf R}^+}")#text(" such that ")#mi("{m^{\\prime}(E) = cm(E)}")#text(" for all elementary sets ")#mi("{E}")#text(". In particular, if we impose the additional normalisation ")#mi("{m^{\\prime}( [0,1)^d ) = 1}")#text(", then ")#mi("{m^{\\prime} \\equiv m}")#text(". (")#emph[#text("Hint:")]#text(" Set ")#mi("{c := m^{\\prime}([0,1)^d)}")#text(", and then compute ")#mi("{m^{\\prime}([0,\\frac{1}{n})^d)}")#text(" for any positive integer ")#mi("{n}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Let ")#mi("{d_1,d_2 \\ge 1}")#text(", and let ")#mi("{E_1 \\subset {\\bf R}^{d_1}}")#text(", ")#mi("{E_2 \\subset {\\bf R}^{d_2}}")#text(" be elementary sets. Show that ")#mi("{E_1 \\times E_2 \\subset {\\bf R}^{d_1+d_2}}")#text(" is elementary, and ")#mi("{m^{d_1+d_2}(E_1 \\times E_2) = m^{d_1}(E_1) \\times m^{d_2}(E_2)}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 2. Jordan measure — ")]]

#text("We now have a satisfactory notion of measure for elementary sets. But of course, the elementary sets are a very restrictive class of sets, far too small for most applications. For instance, a solid triangle or disk in the plane will not be elementary, or even a rotated box. On the other hand, as essentially observed long ago by Archimedes, such sets ")#mi("{E}")#text(" can be ")#emph[#text("approximated")]#text(" from within and without by elementary sets ")#mi("{A \\subset E \\subset B}")#text(", and the inscribing elementary set ")#mi("{A}")#text(" and the circumscribing elementary set ")#mi("{B}")#text(" can be used to give lower and upper bounds on the putative measure of ")#mi("{E}")#text(". As one makes the approximating sets ")#mi("{A, B}")#text(" increasingly fine, one can hope that these two bounds eventually match. This gives rise to the following definitions.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3 (Jordan measure)")]#text(" Let ")#mi("{E \\subset {\\bf R}^d}")#text(" be a bounded set.")

#list(
[#text("The ")#emph[#text("inner Jordan measure")]#text(" ")#mi("{m_{*,(J)}(E)}")#text(" of ")#mi("{E}")#text(" is defined as")

#align(center)[#tao-fit-display[#mitex("m_{*,(J)}(E) := \\sup_{A \\subset E, A \\text{ elementary}} m(A).")]]],
[#text("The ")#emph[#text("outer Jordan measure")]#text(" ")#mi("{m^{*,(J)}(E)}")#text(" of ")#mi("{E}")#text(" is defined as")

#align(center)[#tao-fit-display[#mitex("m^{*,(J)}(E) := \\inf_{B \\supset E, B \\text{ elementary}} m(B).")]]],
[#text("If ")#mi("{m_{*,(J)}(E) = m^{*,(J)}(E)}")#text(", then we say that ")#mi("{E}")#text(" is ")#emph[#text("Jordan measurable")]#text(", and call ")#mi("{m(E) := m_{*,(J)}(E) = m^{*,(J)}(E)}")#text(" the ")#emph[#text("Jordan measure")]#text(" of ")#mi("{E}")#text(". As before, we write ")#mi("{m(E)}")#text(" as ")#mi("{m^d(E)}")#text(" when we wish to emphasise the dimension ")#mi("{d}")#text(".")]
)

#text("By convention, we do not consider unbounded sets to be Jordan measurable (they will be deemed to have infinite outer Jordan measure).")
]

#text("Jordan measurable sets are those sets which are “almost elementary” with respect to outer Jordan measure. More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5 (Characterisation of Jordan measurability)")]#text(" Let ")#mi("{E \\subset {\\bf R}^d}")#text(" be bounded. Show that the following are equivalent:")

#enum(start: 1, 
[#mi("{E}")#text(" is Jordan measurable.")],
[#text("For every ")#mi("{\\epsilon > 0}")#text(", there exist elementary sets ")#mi("{A \\subset E \\subset B}")#text(" such that ")#mi("{m(B \\backslash A) \\leq \\epsilon}")#text(".")],
[#text("For every ")#mi("{\\epsilon > 0}")#text(", there exists an elementary set ")#mi("{A}")#text(" such that ")#mi("{m^{*,(J)}(A \\Delta E) \\leq \\epsilon}")#text(".")]
)
]

#text("As one corollary of this exercise, we see that every elementary set ")#mi("{E}")#text(" is Jordan measurable, and that Jordan measure and elementary measure coincide for such sets; this justifies the use of ")#mi("{m(E)}")#text(" to denote both. In particular, we still have ")#mi("{m(\\emptyset)=0}")#text(".")

#text("Jordan measurability also inherits many of the properties of elementary measure:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Let ")#mi("{E, F \\subset {\\bf R}^d}")#text(" be Jordan measurable sets.")

#enum(start: 1, 
[#text("(Boolean closure) Show that ")#mi("{E \\cup F}")#text(", ")#mi("{E \\cap F}")#text(", ")#mi("{E \\backslash F}")#text(", and ")#mi("{E \\Delta F}")#text(" are Jordan measurable.")],
[#text("(Non-negativity) ")#mi("{m(E) \\geq 0}")#text(".")],
[#text("(Finite additivity) If ")#mi("{E, F}")#text(" are disjoint, then ")#mi("{m(E \\cup F) = m(E) + m(F)}")#text(".")],
[#text("(Monotonicity) If ")#mi("{E \\subset F}")#text(", then ")#mi("{m(E) \\leq m(F)}")#text(".")],
[#text("(Finite subadditivity) ")#mi("{m(E \\cup F) \\leq m(E) + m(F)}")#text(".")],
[#text("(Translation invariance) For any ")#mi("{x \\in {\\bf R}^d}")#text(", ")#mi("{E+x}")#text(" is Jordan measurable, and ")#mi("{m(E+x)=m(E)}")#text(".")]
)
]

#text("Now we give some examples of Jordan measurable sets:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7 (Regions under graphs are Jordan measurable)")]#text(" Let ")#mi("{B}")#text(" be a closed box in ")#mi("{{\\bf R}^d}")#text(", and let ")#mi("{f: B \\rightarrow {\\bf R}}")#text(" be a continuous function.")

#enum(start: 1, 
[#text("Show that the graph ")#mi("{\\{ (x,f(x)): x \\in B \\} \\subset {\\bf R}^{d+1}}")#text(" is Jordan measurable in ")#mi("{{\\bf R}^{d+1}}")#text(" with Jordan measure zero. (Hint: on a compact metric space, continuous functions are uniformly continuous.)")],
[#text("Show that the set ")#mi("{\\{ (x,t): x \\in B; 0 \\leq t \\leq f(x) \\} \\subset {\\bf R}^{d+1}}")#text(" is Jordan measurable.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Let ")#mi("{A,B,C}")#text(" be three points in ")#mi("{{\\bf R}^2}")#text(".")

#enum(start: 1, 
[#text("Show that the solid triangle with vertices ")#mi("{A,B,C}")#text(" is Jordan measurable.")],
[#text("Show that the Jordan measure of the solid triangle is equal to ")#tao-math("{\\frac{1}{2} \\left|(B-A) \\wedge (C-A)\\right|}", block: false)#text(", where ")#tao-math("{\\left|(a,b) \\wedge (c,d)\\right| := \\left|ad-bc\\right|}", block: false)#text(".")]
)

#text("(")#emph[#text("Hint:")]#text(" It may help to first do the case when one of the edges, say ")#mi("{AB}")#text(", is horizontal.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Show that every compact convex ")#link("http://en.wikipedia.org/wiki/Polytope")[#text("polytope")]#text(" in ")#mi("{{\\bf R}^d}")#text(" is Jordan measurable.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]

#enum(start: 1, 
[#text("Show that all open and closed Euclidean balls ")#tao-math("{B(x,r) := \\{ y \\in {\\bf R}^d: \\left|y-x\\right| < r \\}}", block: false)#text(", ")#tao-math("{\\overline{B(x,r)} := \\{ y \\in {\\bf R}^d: \\left|y-x\\right| \\leq r \\}}", block: false)#text(" in ")#mi("{{\\bf R}^d}")#text(" are Jordan measurable, with Jordan measure ")#mi("{c_d r^d}")#text(" for some constant ")#mi("{c_d > 0}")#text(" depending only on ")#mi("{d}")#text(".")],
[#text("Establish the crude bounds")

#align(center)[#tao-fit-display[#mitex("\\left(\\frac{2}{\\sqrt{d}}\\right)^d \\leq c_d \\leq 2^d.")]]]
)

#text("(An exact formula for ")#mi("{c_d}")#text(" is ")#mi("{c_d = \\frac{1}{d} \\omega_d}")#text(", where ")#mi("{\\omega_d := \\frac{2\\pi^{d/2}}{\\Gamma(d/2)}}")#text(" is the volume of the unit sphere ")#mi("{S^{d-1} \\subset {\\bf R}^d}")#text(" and ")#mi("{\\Gamma}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Gamma_function")[#text("Gamma function")]#text(", but we will not derive this formula here.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Let ")#mi("{L: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" be a linear transformation.")

#enum(start: 1, 
[#text("Show that there exists a non-negative real number ")#mi("{D}")#text(" such that ")#mi("{m(L(E)) = D m(E)}")#text(" for every elementary set ")#mi("{E}")#text(" (note from previous exercises that ")#mi("{L(E)}")#text(" is Jordan measurable). ")#emph[#text("Hint:")]#text(" apply Exercise ")#link(<tao-dc1388810d0db0ad8731>)[#text("3")]#text(" to the map ")#mi("{E \\mapsto m(L(E))}")#text(".")],
[#text("Show that if ")#mi("{E}")#text(" is Jordan measurable, then ")#mi("{L(E)}")#text(" is also, and ")#mi("{m(L(E)) = D m(E)}")#text(".")],
[#text("Show that ")#tao-math("{D = \\left|\\det L\\right|}", block: false)#text(". (")#emph[#text("Hint:")]#text(" Work first with the case when ")#mi("{L}")#text(" is an ")#link("http://en.wikipedia.org/wiki/Elementary_matrix_transformations")[#text("elementary transformation")]#text(", using ")#link("http://en.wikipedia.org/wiki/Gaussian_elimination")[#text("Gaussian elimination")]#text(". Alternatively, work with the cases when ")#mi("{L}")#text(" is a diagonal transformation or an orthogonal transformation, using the unit ball in the latter case, and use the ")#link("http://en.wikipedia.org/wiki/Polar_decomposition")[#text("polar decomposition")]#text(".)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" Define a ")#emph[#text("Jordan null set")]#text(" to be a Jordan measurable set of Jordan measure zero. Show that any subset of a Jordan null set is a Jordan null set.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" ")#metadata(none) <tao-809d2548c145cf911424>#text(" Show that ")#link(<tao-e90c560ecb63987067f5>)[#text("(1)")]#text(" holds for all Jordan measurable ")#mi("{E \\subset {\\bf R}^d}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14 (Metric entropy formulation of Jordan measurability)")]#text(" Define a ")#emph[#text("dyadic cube")]#text(" to be a half-open box of the form")

#align(center)[#tao-fit-display[#mitex("[\\frac{i_1}{2^n}, \\frac{i_1+1}{2^n}) \\times \\ldots \\times [\\frac{i_d}{2^n}, \\frac{i_d+1}{2^n})")]]

#text("for some integers ")#mi("{n, i_1,\\ldots,i_d}")#text(". Let ")#mi("{E \\subset {\\bf R}^d}")#text(" be a bounded set. For each integer ")#mi("{n}")#text(", let ")#mi("{{\\mathcal E}_*(E, 2^{-n})}")#text(" denote the number of dyadic cubes of sidelength ")#mi("{2^{-n}}")#text(" that are contained in ")#mi("{E}")#text(", and let ")#mi("{{\\mathcal E}^*(E, 2^{-n})}")#text(" be the number of dyadic cubes of sidelength ")#mi("{2^{-n}}")#text(" that intersect ")#mi("{E}")#text(". Show that ")#mi("{E}")#text(" is Jordan measurable if and only if")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} 2^{-dn} ({\\mathcal E}^*(E,2^{-n}) - {\\mathcal E}_*(E,2^{-n})) = 0,")]]

#text("in which case one has")

#align(center)[#tao-fit-display[#mitex("m(E) = \\lim_{n \\rightarrow \\infty} 2^{-dn} {\\mathcal E}_*(E,2^{-n}) = \\lim_{n \\rightarrow \\infty} 2^{-dn} {\\mathcal E}^*(E,2^{-n}).")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Uniqueness of Jordan measure)")]#text(" ")#metadata(none) <tao-5fceb8bc592ab31a3fbb>#text(" Let ")#mi("{d \\geq 1}")#text(". Let ")#mi("{m^{\\prime}: {\\mathcal J}({\\bf R}^d) \\rightarrow {\\bf R}^+}")#text(" be a map from the collection ")#mi("{{\\mathcal J}({\\bf R}^d)}")#text(" of Jordan-measurable subsets of ")#mi("{{\\bf R}^d}")#text(" to the nonnegative reals that obeys the non-negativity, finite additivity, and translation invariance properties. Show that there exists a constant ")#mi("{c \\in {\\bf R}^+}")#text(" such that ")#mi("{m^{\\prime}(E) = cm(E)}")#text(" for all Jordan measurable sets ")#mi("{E}")#text(". In particular, if we impose the additional normalisation ")#mi("{m^{\\prime}( [0,1)^d ) = 1}")#text(", then ")#mi("{m^{\\prime} \\equiv m}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Let ")#mi("{d_1,d_2 \\ge 1}")#text(", and let ")#mi("{E_1 \\subset {\\bf R}^{d_1}}")#text(", ")#mi("{E_2 \\subset {\\bf R}^{d_2}}")#text(" be Jordan measurable sets. Show that ")#mi("{E_1 \\times E_2 \\subset {\\bf R}^{d_1+d_2}}")#text(" is Jordan measurable, and ")#mi("{m^{d_1+d_2}(E_1 \\times E_2) = m^{d_1}(E_1) \\times m^{d_2}(E_2)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" Let ")#mi("{P, Q}")#text(" be two polytopes in ")#mi("{{\\bf R}^d}")#text(". Suppose that ")#mi("{P}")#text(" can be partitioned into finitely many sub-polytopes which, after being rotated and translated, form a cover of ")#mi("{Q}")#text(", with any two of the sub-polytopes in ")#mi("{Q}")#text(" intersecting only at their boundaries. Conclude that ")#mi("{P}")#text(" and ")#mi("{Q}")#text(" have the same Jordan measure. The converse statement is true in one and two dimensions ")#mi("{d=1,2}")#text(" (this is the ")#link("http://en.wikipedia.org/wiki/Bolyai-Gerwien_theorem")[#text("Bolyai-Gerwien theorem")]#text("), but false in higher dimensions (this was Dehn’s negative answer to ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_third_problem")[#text("Hilbert’s third problem")]#text(").")
]

#text("The above exercises give a fairly large class of Jordan measurable sets. However, not every subset of ")#mi("{{\\bf R}^d}")#text(" is Jordan measurable. First of all, the unbounded sets are not Jordan measurable, by construction. But there are also bounded sets that are not Jordan measurable:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" Let ")#mi("{E \\subset {\\bf R}^d}")#text(" be a bounded set.")

#enum(start: 1, 
[#text("Show that ")#mi("{E}")#text(" and the closure ")#mi("{\\overline{E}}")#text(" of ")#mi("{E}")#text(" have the same outer Jordan measure.")],
[#text("Show that ")#mi("{E}")#text(" and the interior ")#mi("{E^\\circ}")#text(" of ")#mi("{E}")#text(" have the same inner Jordan measure.")],
[#text("Show that ")#mi("{E}")#text(" is Jordan measurable if and only if the topological boundary ")#mi("{\\partial E}")#text(" of ")#mi("{E}")#text(" has outer Jordan measure zero.")],
[#text("Show that the ")#emph[#text("bullet-riddled square")]#text(" ")#mi("{ [0,1]^2 \\backslash {\\bf Q}^2}")#text(", and set of bullets ")#mi("{[0,1]^2 \\cap Q^2}")#text(", both have inner Jordan measure zero and outer Jordan measure one. In particular, both sets are not Jordan measurable.")]
)
]

#text("Informally, any set with a lot of “holes”, or a very “fractal” boundary, is unlikely to be Jordan measurable. In order to measure such sets we will need to develop ")#emph[#text("Lebesgue measure")]#text(", which is done in the next set of notes.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19 (Carathéodory type property)")]#text(" Let ")#mi("{E \\subset {\\bf R}^d}")#text(" be a bounded set, and ")#mi("{F \\subset {\\bf R}^d}")#text(" be an elementary set. Show that ")#mi("{m^{*,(J)}(E) = m^{*,(J)}(E \\cap F) + m^{*,(J)}(E \\backslash F)}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 3. Connection with the Riemann integral — ")]]

#text("To conclude these notes we briefly discuss the relationship between Jordan measure and the ")#link("http://en.wikipedia.org/wiki/Riemann_integral")[#text("Riemann integral")]#text(" (or the equivalent ")#link("http://en.wikipedia.org/wiki/Darboux_integral")[#text("Darboux integral")]#text("). For simplicity we will only discuss the classical one-dimensional Riemann integral on an interval ")#mi("{[a,b]}")#text(", though one can extend the Riemann theory without much difficulty to higher-dimensional integrals on Jordan measurable sets. (In later notes, this Riemann integral will be superceded by the ")#link("http://en.wikipedia.org/wiki/Lebesgue_integration")[#text("Lebesgue integral")]#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 4 (Riemann integrability)")]#text(" Let ")#mi("{[a,b]}")#text(" be an interval of positive length, and ")#mi("{f: [a,b] \\rightarrow {\\bf R}}")#text(" be a function. A ")#emph[#text("tagged partition")]#text(" ")#mi("{{\\mathcal P} = ((x_0,x_1,\\ldots,x_n), (x^*_1,\\ldots,x^*_n))}")#text(" of ")#mi("{[a,b]}")#text(" is a finite sequence of real numbers ")#mi("{a = x_0 < x_1 < \\ldots < x_n = b}")#text(", together with additional numbers ")#mi("{x_{i-1} \\leq x^*_i \\leq x_i}")#text(" for each ")#mi("{i=1,\\ldots,n}")#text(". We abbreviate ")#mi("{x_i-x_{i-1}}")#text(" as ")#mi("{\\delta x_i}")#text(". The quantity ")#mi("{\\Delta({\\mathcal P}) := \\sup_{1 \\leq i \\leq n} \\delta x_i}")#text(" will be called the ")#emph[#text("norm")]#text(" of the tagged partition. The ")#emph[#text("Riemann sum")]#text(" ")#mi("{{\\mathcal R}( f, {\\mathcal P} )}")#text(" of ")#mi("{f}")#text(" with respect to the tagged partition ")#mi("{{\\mathcal P}}")#text(" is defined as")

#align(center)[#tao-fit-display[#mitex("{\\mathcal R}( f, {\\mathcal P} ) := \\sum_{i=1}^n f(x^*_i) \\delta x_i.")]]

#text("We say that ")#mi("{f}")#text(" is ")#emph[#text("Riemann integrable")]#text(" on ")#mi("{[a,b]}")#text(" if there exists a real number, denoted ")#mi("{\\int_a^b f(x)\\ dx}")#text(" and referred to as the ")#emph[#text("Riemann integral")]#text(" of ")#mi("{f}")#text(" on ")#mi("{[a,b]}")#text(", for which we have")

#align(center)[#tao-fit-display[#mitex("\\int_a^b f(x)\\ dx = \\lim_{\\Delta({\\mathcal P}) \\rightarrow 0} {\\mathcal R}(f, {\\mathcal P})")]]

#text("by which we mean that for every ")#mi("{\\epsilon > 0}")#text(" there exists ")#mi("{\\delta > 0}")#text(" such that ")#tao-math("{\\left|{\\mathcal R}(f, {\\mathcal P}) - \\int_a^b f(x)\\ dx\\right| \\leq \\epsilon}", block: false)#text(" for every tagged partition ")#mi("{{\\mathcal P}}")#text(" with ")#mi("{\\Delta({\\mathcal P}) \\leq \\delta}")#text(".")

#text("If ")#mi("{[a,b]}")#text(" is an interval of zero length, we adopt the convention that every function ")#mi("{f: [a,b] \\rightarrow {\\bf R}}")#text(" is Riemann integrable, with a Riemann integral of zero.")
]

#text("Note that unbounded functions cannot be Riemann integrable (why?).")

#text("The above definition, while geometrically natural, can be awkward to use in practice. A more convenient formulation of the Riemann integral can be formulated using some additional machinery.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20 (Piecewise constant functions)")]#text(" Let ")#mi("{[a,b]}")#text(" be an interval. A ")#emph[#text("piecewise constant function")]#text(" ")#mi("{f: [a,b] \\rightarrow {\\bf R}}")#text(" is a function for which there exists a partition of ")#mi("{[a,b]}")#text(" into finitely many intervals ")#mi("{I_1,\\ldots,I_n}")#text(", such that ")#mi("{f}")#text(" is equal to a constant ")#mi("{c_i}")#text(" on each of the intervals ")#mi("{I_i}")#text(". If ")#mi("{f}")#text(" is piecewise constant, show that the expression")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i=1}^n c_i \\left|I_i\\right|", block: true)]]

#text("is independent of the choice of partition used to demonstrate the piecewise constant nature of ")#mi("{f}")#text(". We will denote this quantity by ")#mi("{\\text{p.c.} \\int_a^b f(x)\\ dx}")#text(", and refer to it as the ")#emph[#text("piecewise constant integral")]#text(" of ")#mi("{f}")#text(" on ")#mi("{[a,b]}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21 (Basic properties of the piecewise constant integral)")]#text(" Let ")#mi("{[a,b]}")#text(" be an interval, and let ")#mi("{f, g: [a,b] \\rightarrow {\\bf R}}")#text(" be piecewise constant functions. Establish the following statements:")

#enum(start: 1, 
[#text("(Linearity) For any real number ")#mi("{c}")#text(", ")#mi("{cf}")#text(" and ")#mi("{f+g}")#text(" are piecewise constant, with ")#mi("{\\text{p.c.} \\int_a^b cf(x)\\ dx = c \\text{p.c.} \\int_a^b f(x)\\ dx}")#text(" and ")#mi("{\\text{p.c.} \\int_a^b f(x)+g(x)\\ dx = \\text{p.c.} \\int_a^b f(x)\\ dx + \\text{p.c.} \\int_a^b g(x)\\ dx}")#text(".")],
[#text("(Monotonicity) If ")#mi("{f \\leq g}")#text(" pointwise (i.e. ")#mi("{f(x) \\leq g(x)}")#text(" for all ")#mi("{x \\in [a,b]}")#text(") then ")#mi("{\\text{p.c.} \\int_a^b f(x)\\ dx \\leq \\text{p.c.} \\int_a^b g(x)\\ dx}")#text(".")],
[#text("(Indicator) If ")#mi("{E}")#text(" is an elementary subset of ")#mi("{[a,b]}")#text(", then the indicator function ")#mi("{1_E: [a,b] \\rightarrow {\\bf R}}")#text(" (defined by setting ")#mi("{1_E(x) := 1}")#text(" when ")#mi("{x \\in E}")#text(" and ")#mi("{1_E(x):=0}")#text(" otherwise) is piecewise constant, and ")#mi("{\\text{p.c.} \\int_a^b 1_E(x)\\ dx = m(E)}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 5 (Darboux integral)")]#text(" Let ")#mi("{[a,b]}")#text(" be an interval, and ")#mi("{f: [a,b] \\rightarrow {\\bf R}}")#text(" be a bounded function. The ")#emph[#text("lower Darboux integral")]#text(" ")#mi("{\\underline{\\int_a^b} f(x)\\ dx}")#text(" of ")#mi("{f}")#text(" on ")#mi("{[a,b]}")#text(" is defined as")

#align(center)[#tao-fit-display[#mitex("\\underline{\\int_a^b} f(x)\\ dx := \\sup_{g \\leq f, \\text{ piecewise constant}} \\text{p.c.} \\int_a^b g(x)\\ dx,")]]

#text("where ")#mi("{g}")#text(" ranges over all piecewise constant functions that are pointwise bounded above by ")#mi("{f}")#text(". (The hypothesis that ")#mi("{f}")#text(" is bounded ensures that the supremum is over a non-empty set.) Similarly, we define the ")#emph[#text("upper Darboux integral")]#text(" ")#mi("{\\overline{\\int_a^b} f(x)\\ dx}")#text(" of ")#mi("{f}")#text(" on ")#mi("{[a,b]}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\overline{\\int_a^b} f(x)\\ dx := \\inf_{h \\geq f, \\text{ piecewise constant}} \\text{p.c.} \\int_a^b h(x)\\ dx.")]]

#text("Clearly ")#mi("{\\underline{\\int_a^b} f(x)\\ dx \\leq \\overline{\\int_a^b} f(x)\\ dx}")#text(". If these two quantities are equal, we say that ")#mi("{f}")#text(" is ")#emph[#text("Darboux integrable")]#text(", and refer to this quantity as the ")#emph[#text("Darboux integral")]#text(" of ")#mi("{f}")#text(" on ")#mi("{[a,b]}")#text(".")
]

#text("Note that the upper and lower Darboux integrals are related by the reflection identity")

#align(center)[#tao-fit-display[#mitex("\\overline{\\int_a^b} -f(x)\\ dx = - \\underline{\\int_a^b} f(x)\\ dx.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Let ")#mi("{[a,b]}")#text(" be an interval, and ")#mi("{f: [a,b] \\rightarrow {\\bf R}}")#text(" be a bounded function. Show that ")#mi("{f}")#text(" is Riemann integrable if and only if it is Darboux integrable, in which case the Riemann integral and Darboux integrals are equal.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Show that any continuous function ")#mi("{f: [a,b] \\rightarrow {\\bf R}}")#text(" is Riemann integrable. More generally, show that any bounded, ")#link("http://en.wikipedia.org/wiki/Piecewise")[#text("piecewise continuous")]#text(" function ")#mi("{f: [a,b] \\rightarrow {\\bf R}}")#text(" is Riemann integrable.")
]

#text("Now we connect the Riemann integral to Jordan measure in two ways. First, we connect the Riemann integral to one-dimensional Jordan measure:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24 (Basic properties of the Riemann integral)")]#text(" Let ")#mi("{[a,b]}")#text(" be an interval, and let ")#mi("{f, g: [a,b] \\rightarrow {\\bf R}}")#text(" be Riemann integrable. Establish the following statements:")

#enum(start: 1, 
[#text("(Linearity) For any real number ")#mi("{c}")#text(", ")#mi("{cf}")#text(" and ")#mi("{f+g}")#text(" are Riemann integrable, with ")#mi("{\\int_a^b cf(x)\\ dx = c \\cdot \\int_a^b f(x)\\ dx}")#text(" and ")#mi("{\\int_a^b f(x)+g(x)\\ dx = \\int_a^b f(x)\\ dx + \\int_a^b g(x)\\ dx}")#text(".")],
[#text("(Monotonicity) If ")#mi("{f \\leq g}")#text(" pointwise (i.e. ")#mi("{f(x) \\leq g(x)}")#text(" for all ")#mi("{x \\in [a,b]}")#text(") then ")#mi("{\\int_a^b f(x)\\ dx \\leq \\int_a^b g(x)\\ dx}")#text(".")],
[#text("(Indicator) If ")#mi("{E}")#text(" is a Jordan measurable subset of ")#mi("{[a,b]}")#text(", then the indicator function ")#mi("{1_E: [a,b] \\rightarrow {\\bf R}}")#text(" (defined by setting ")#mi("{1_E(x) := 1}")#text(" when ")#mi("{x \\in E}")#text(" and ")#mi("{1_E(x):=0}")#text(" otherwise) is Riemann integrable, and ")#mi("{\\int_a^b 1_E(x)\\ dx = m(E)}")#text(".")]
)

#text("Finally, show that these properties uniquely define the Riemann integral, in the sense that the functional ")#mi("{f \\mapsto \\int_a^b f(x)\\ dx}")#text(" is the only map from the space of Riemann integrable functions on ")#mi("{[a,b]}")#text(" to ")#mi("{{\\bf R}}")#text(" which obeys all three of the above properties.")
]

#text("Next, we connect the integral to two-dimensional Jordan measure:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25 (Area interpretation of the Riemann integral)")]#text(" Let ")#mi("{[a,b]}")#text(" be an interval, and let ")#mi("{f: [a,b] \\rightarrow {\\bf R}}")#text(" be a bounded function. Show that ")#mi("{f}")#text(" is Riemann integrable if and only if the sets ")#mi("{E_+ := \\{ (x,t): x \\in [a,b]; 0 \\leq t \\leq f(x)\\}}")#text(" and ")#mi("{E_- := \\{ (x,t): x \\in [a,b]; f(x) \\leq t \\leq 0\\}}")#text(" are both Jordan measurable in ")#mi("{{\\bf R}^2}")#text(", in which case one has")

#align(center)[#tao-fit-display[#mitex("\\int_a^b f(x)\\ dx = m^2( E_+ ) - m^2( E_- ),")]]

#text("where ")#mi("{m^2}")#text(" denotes two-dimensional Jordan measure. (")#emph[#text("Hint:")]#text(" First establish this in the case when ")#mi("{f}")#text(" is non-negative.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" Extend the definition of the Riemann and Darboux integrals to higher dimensions, in such a way that analogues of all the previous results hold.")
]

#heading(level: 1)[#text("Comments (99)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sin")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-640034")[#strong[#text("sin")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2022")])]

#text("Dear Professor Tao:")#linebreak()#text(" For (2) of exercise 8, can one simply match the definition of upper and lower Riemman integeral with those of jordan outer and inner measure respectively and conclude that the measure does coincide with the area ?")

#emph[#text("[Yes, this will work – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sin")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-640300")[#strong[#text("sin")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2022")])]

#text("Dear professor Tao:")#linebreak()#text(" For (3) of exercise 11, I’m struggling to show that if L is a shear, then the measure of the image of the unit box is 1. Since L does not map boxes to boxes as the other two types of elementary transformations do, how should one proceeds from here ?")

#emph[#text("[Upper and lower bound the sheared box by a union of finitely many boxes. You can draw some pictures in two dimensions first to get intuition. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sin")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-640805")[#strong[#text("sin")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2022")])]

#text("Dear professor Tao:")#linebreak()#text(" I greatly appreciate all the patient responses from you. In Definition 7.4,1 of your analysis 2, the splitting property is used to test Lebesgue measurability, I wonder if the Carathéodory type property can be used to test Jordan measurability in a similar fashion?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-645227")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2022")])]

#text("Dr. Tao:")#linebreak()#text(" Let ")#mi("B")#text(" be a closed box in ")#mi("R^d")#text(",")#linebreak()#text(" and ")#mi("f:B\\rightarrow R")#text(" be a continuous function,")#linebreak()#text(" consider the set")

#mi("E=\\{(x,t):x\\in B; 0\\leq t\\leq f(x)\\}\\subset R^{d+1}")#text(". What is ")#mi("\\partial E")#text("?")

#text("Someone mentioned that ")#mi("\\partial E=\\{(x,f(x)):x\\in B\\}")#text(". i.e. ")#mi("\\partial E")#text(" is just the graph of ")#mi("E")#text("? If that’s the case, then Exercise 7(2) follows easily from (1). But the boundary should also include the bottom box ")#mi("B")#text(", and the side surface set")#linebreak()#text(" ")#mi("\\{(\\partial B, t):0\\leq t\\leq f(x)\\}")#text(". The graph only covers the top of the set ")#mi("E")#text(". Is this correct?")

#emph[#text("[Yes, but it is easy to manage the contribution of these additional regions for the purposes of establishing Exercise 7(2). -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-684520")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2024")])]

#text("Dear professor Tao: Can you provide a bit hint on Exercise 9 (Jordan measurability of compact convex polytype)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-684578")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2024")])]

#text("Try the case of a triangle in a plane first (perhaps assuming some of the sides parallel to the axes as an easier case), and then use the various Boolean algebra properties of Jordan measurability to handle other polygons. Then think about how to extend this argument to higher dimensions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-688837")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2025")])]

#text("Dear Prof. Tao,")

#text("I previously saw a comment mentioning that the proofs of some theorems in real analysis essentially use techniques from combinatorics. My apologies, but I’ve searched for a long time and haven’t been able to find the original post.")

#text("I am currently studying measure theory, and I know that you are an expert in the fields of both analysis and combinatorics. I was wondering if you could provide some examples of this, from measure theory, undergraduate real analysis, or probability theory?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-688875")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2025")])]

#text("Dear Prof. Tao,")

#text("For exercise 14, you mentioned that ")#strong[#text("“epsilon entropy” is a slightly more accurate description here than “metric entropy”")]#text(". I wonder that —— what is entropy? Also, what is the difference between ”epsilon entropy” and “metric entropy” and can you provide us a bit hint of what strategy (section 2.1) can we use on this exercise?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-689123")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2025")])]

#text("Prof, Tao")

#text("Could you give us a hint on Exercise 17 —— What techniques in Section 2.1 can be used? I think this exercise seems a little different from the previous exercise, and I don’t know why. I think I must miss something essential.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-689124")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2025")])]

#text("2.1.9 is the most relevant here. For instance, one can work with the situation in which one only has to translate the subpolytopes, not translate or rotate. Or to work with cases where there is only one subpolytope involved (so the partition is trivial). Or work in one dimension. Or assume that even at the boundary there no intersections. 2.1.8 will also help.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-689167")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2025")])]

#text("Prof. Tao,")

#text("Before reading your proof of Lemma 1.1.2, I attempted to prove it on my own, but to no avail. I was astonished to discover that the core of the proof relies on a ")#strong[#text("discretisation argument")]#text(", as my impression was that objects in measure theory are inherently “continuous.” Given my limited experience, it came as a shock to see this proof treating continuous objects as limits of discrete ones.")

#text("I consulted Section 2.1, but I did not seem to find a corresponding description there. Consequently, I would like to ask you: In what scenarios is this discretization argument applicable? Under what circumstances should one consider employing this technique?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-689182")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2025")])]

#text("The list of strategies in Section 2.1 is not intended to be comprehensive (although one can view discrete approximation as a version of Strategy 2.1.3). More generally, one should not adopt the mindset that there are only a finite number of tricks that one needs to memorize in order to become proficient in a subject; one should use the full power of one’s intellectual capabilities when thinking about mathematics, and not rely solely on the rote memorization portion of those capabilities.")

#text("The truth is that almost any two subfields of mathematics are connected to each other in one fashion or another: in particular, continuous mathematics and discrete mathematics are intimately connected. This perspective is more visible in applied mathematics, in which one is often forced by necessity to seek discrete approximations to continuous problems in order to be able to solve them with computers; for instance, a continuous integral can be approximated by ")#link("https://en.wikipedia.org/wiki/Monte_Carlo_integration")[#text("Monte Carlo methods")]#text(". I would view one’s mathematical education as a continual process of discovering such connections, and using them to enrich and deepen your understanding of all the fields connected in this fashion; trying to “fence off” these connections to “simplify” the task of learning a subject is ultimately counterproductive, and leads to a more sterile educational experience.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fef06046c3e3f2eb0c11c98a8c4a11ed84b25ccbc023d13f15062e426e1fdf3a-366938429a206590b60f422cbbb17608d068f86905fb2652141d3f9024626ae7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elias Lam")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-689188")[#strong[#text("Elias Lam")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2025")])]

#text("Prof. Tao,")

#text("Thanks for your clear explanation, I benefit a lot from your reply! Although the initial intend was not trying to fence off the connections between two parts of mathematics —— I actually want to ask the technical details of the discretisation argument, in the spirits of tricki and Section 2.1, trying to give a “general principle” of this technique and find other examples in your book.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-689255")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2025")])]

#text("Dear Dr Tao,")

#text("In Exercise 10 you said that Gamma function is needed for the exact formula——Could you please explain how to derive it? I don’t know why the technique would show up here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-689261")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2025")])]

#link("https://en.wikipedia.org/wiki/Volume_of_an_n-ball")[#text("https://en.wikipedia.org/wiki/Volume_of_an_n-ball")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-689270")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2025")])]

#text("Thanks Dr Tao. I have seen the wiki but it says nothing about the reason why Gamma function show up here. Why would the Volume of an Ball related to the generalization of factorial function, which is the Gamma Function?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-689287")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2025")])]

#text("See ")#link("https://mathoverflow.net/questions/6160/explanation-for-gamma-function-in-formula-for-n-ball-volume")[#text("https://mathoverflow.net/questions/6160/explanation-for-gamma-function-in-formula-for-n-ball-volume")]

#text("Personally, I think the explanation is that balls and gamma functions are both connected to (high-dimensional) gaussians such as ")#tao-math("x \\mapsto e^{-\\pi \\left\\|x\\right\\|^2}", block: false)#text(". Balls are the level sets of gaussians, whereas gamma functions, being defined as an integral involving both exponentials and monomials, are naturally associated to gaussians when integrated against a high-dimensional volume element such as ")#mi("r^{d-1} dr d\\omega")#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-689447")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2025")])]

#text("Prof Tao,")

#text("Could we solve Exercise 11 using linear algebra methods? If so, could you provide some geometric intuition?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-693254")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2026")])]

#text("Dear Prof. Tao,")

#text("When I tried to prove the converse of Exercise 17 in the case where d ≥ 3, I found that none of the techniques used for the one-dimensional and two-dimensional cases worked. Later I realized that I had misread your remark—the answer is “negative.” But why is it that once we reach three dimensions, the question falls apart?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-693257")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2026")])]

#text("See ")#link("https://en.wikipedia.org/wiki/Dehn_invariant")[#text("https://en.wikipedia.org/wiki/Dehn_invariant")]#text(", or ")#link("https://claude.ai/share/8725e83f-430d-49e9-a656-e42fc6e3773b")[#text("this AI answer")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-693266")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2026")])]

#text("Thanks. I also wonder how can Dehn’s proof of Hilbert’s third problem, or the idea of the Dehn invariant, be reinterpreted from the perspective of modern geometry?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-2/#comment-693273")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2026")])]

#text("I am ")#link("https://claude.ai/share/69246d10-fc1b-4e4d-b3c6-2509c3dadf83")[#text("outsourcing this question to an AI")]#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2d4ab3bc48f38053d5bed6cb8509c92f142fb196f5df472c263109a8a6e77f7-6a5be68c477a5be6586b62f07fa83c3f9ed2c1a1f363e39f316e0d181b8044c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marek Bernát")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46784")[#strong[#text("Marek Bernát")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2010")])]

#text("Hello,")#linebreak()#text(" thank you for a nice post. There is a typo in the definition of ")#mi("\\omega_d")#text(" in Exercise 10. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aae63a793e21ba239ceef13e0fa1910aed10576bee1e247cad2d5d5dd2c00745-490845dda6d4ad1ace8df3a57513884fc979f98ad195de04f9284b622da59d55.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J Balachandran")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46787")[#strong[#text("J Balachandran")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2010")])]

#text("Prof.Tao I’m really happy to see your post. I’m right now learning Real Analysis. Is it possible for you to make a print option where I can print these notes. I personally find it difficult to read it online. It would be great if you can provide a print option")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46788")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2010")])]

#text("Your web browser should come with “Print” and/or “Print preview” options. The blog is configured to strip out the sidebar and other extraneous material from the printed version.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aae63a793e21ba239ceef13e0fa1910aed10576bee1e247cad2d5d5dd2c00745-490845dda6d4ad1ace8df3a57513884fc979f98ad195de04f9284b622da59d55.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J Balachandran")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46790")[#strong[#text("J Balachandran")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2010")])]

#text("Wooww . This is cool. Thank you very much Prof.Tao")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46792")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2010")])]

#text("In lemma 2, partitions do not have to have the same length. do they?")

#text("thanks")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7fb57456511ac2088bc3f1d7c3a64b421a4970eeadf49ca51e63343c4a9f4824-2dec3f7f27e92480ab10d2bd36cfa15d4d8e39376e823d3af7a6f4c3b0080cd4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JCK")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46795")[#strong[#text("JCK")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2010")])]

#text("“Outer Jordan Measure” in Definition 3 should be ” ")#mi("E \\subset B, B \\text{ elementary}")#text(" ”")

#text("Definition 5: “Clearly…” both D. integrals are upper.")

#text("Exercise 14: parenthesis trouble in the “if and only if” limit ( “E)_*”)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0fb1c0e344ad441293f29af1e466a09c9fe88006c6e59a3125f9852810b95f92-fc27c6ea68497f96056b607947dfaed05ed44ec859b6f5db145510d4df431c0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46798")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2010")])]

#text("Deer,Prof.Tao:")#linebreak()#text(" Exercise 23 (Basic properties of the Riemann integral) Let $latex$ be an interval, and let $latex$ be Riemann integrable. Establish the following statements:")

#text("(Linearity) For any real number $latex$, $latex$ and $latex$ are Riemann integrable, with $latex$")#linebreak()#text(" I wonder if the formala should be $latex$ ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8837af00930de74d9f00080b1632feb9d01c80311732f1102da9b3c590d26cac-dda99ae828de759f1685e0a4dfbf1ed47eb9d7b45733b2997ced900e1d90d03b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yu Cao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46803")[#strong[#text("Yu Cao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2010")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I think you are very generous to post the notes on your blog. And I benefit a lot here. But I was quite curious about your work. Do you type all these stuff in $LaTeX$ yourself in a very short time? Every post of your blog seams very long. How can you do that?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9600342ea6c4a9d9b3c467fc166a1c600cb8a5a49b7acc1a145414977e095f9a-e44c4910e771211e44bed0cc8479a2c89f24a6b6a9c6908e32ecf8da5d7ecfcb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ugroh")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46804")[#strong[#text("ugroh")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2010")])]

#text("Terence, this is great and I will recommend it for studying.")

#text("Q1: Can you please add the print-buttom offered by WordPress (see e.g.")#linebreak()#text(" ")#link("http://en.blog.wordpress.com/2010/08/24/more-ways-to-share/")[#text("http://en.blog.wordpress.com/2010/08/24/more-ways-to-share/")]#text(" ). Then it is easy to print the blog as asked above.")

#text("Q1: Will this appear in one of your “blog based books”?")

#text("Q2: Are you still using the latex->wordpress tool LaTeX2WP or do you have a newer one?")

#text("Ulrich")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46809")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2010")])]

#text("I’ve added the print button.")

#text("Yes, I plan to incorporate these notes into the 2010 blog-based book. I still mostly rely on Luca’s LaTeX2WP tool, and indeed for the purposes of bundling the posts into a book it is convenient to view my LaTeX source files as the “master” copy of the text, with the blog version available here being a secondary copy.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Real Analysis (=Measure Theory) by Terence Tao « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46806")[#strong[#text("Real Analysis (=Measure Theory) by Terence Tao « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2010")])]

#text("[…] Der Prolog ist eben erschienen (siehe den Link hier). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7bd79ccc17907103f59d86fb20316d47cd1b97b6e5da97c6784bb34597ecff0-0d4f3e22196665cd23c0b63eb88a1c5d6701288f8a5ee038d7b21ba2ca261e47.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46812")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2010")])]

#text("Pedagogical question, do you recommend students to write out full formal solutions for each of the exercises?")

#text("Or do you think it is enough to ponder each exercise long enough to see the key idea used to prove or solve it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46815")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2010")])]

#text("This depends to a large extent on the level of the student. If one is not yet confident in one’s own ability to expand out an informal argument into a fully fleshed out formal one, then I would indeed recommend writing out full solutions to such exercises. (In my experience, a significant proportion of first-year graduate students would be at this level.) But if one already has plenty of experience in writing out formal arguments (e.g. if one has already written publication-quality mathematical research papers or theses), and in particular can see what parts of a formal argument would be routine, and which ones address the heart of the matter, then it would be acceptable to give more informal solutions that only treat the latter portion of the argument in detail. (In contrast, informal solutions that leave out crucial details while focusing on more routine components of the arguments often indicate that the student has in fact missed the point of the question; in such cases I would definitely recommend that the student write out complete and detailed rigorous proofs instead.)")

#text("See also my discussion of the “rigorous” and “post-rigorous” stages of mathematics at")

#link("https://terrytao.wordpress.com/career-advice/there%E2%80%99s-more-to-mathematics-than-rigour-and-proofs/")[#text("https://terrytao.wordpress.com/career-advice/there%E2%80%99s-more-to-mathematics-than-rigour-and-proofs/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46816")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2010")])]

#text("When I pressed the ”print” button, it printed comments as well. is there way to print only your post, namely without comments?")

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46817")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2010")])]

#text("Dear Prof. Tao,")

#text("In exercise 3, does ")#mi("m^{\\prime}")#text(" go to positive reals or non-negative reals? because we have some measure zero boxes.")

#text("do we assume that ")#mi("m^{\\prime}")#text(" assigns zero to empty set?")

#text("Thanks")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/700ab9f86612d3fbb55778d307f50d45851d62f8a301710b8c6150123ae5c040-7ca199af677ea05871200f3b5779678b6d3938c79b5a64268da03358a6ad0ab1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grad Student")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46819")[#strong[#text("Grad Student")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2010")])]

#text("Dear Prof. Tao, thank you for this enlightening course!")

#text("My question regards Solovay’s model: Since it solves the problem of measure, by making every set of real numbers Lebesgue measurable, why isn’t this model used as the baseline model, instead of going through the difficulty of handling unmeasurable sets?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46820")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2010")])]

#text("Well, the price one pays for such Solovay-type models is that one has to sacrifice the axiom of choice and its many useful consequences (e.g. Zorn’s lemma, the Hahn-Banach theorem, the well-ordering theorem, Tychonoff’s theorem, the Banach-Alaoglu theorem, the ultrafilter lemma, the Stone-Cech compactification, existence of bases for arbitrary vector spaces, etc.; many of these topics will be touched upon in the 245B and 245C sequels to this course). This price is generally considered too expensive; the net benefit of these choice-dependent tools for analysis far outweighs the cost of having to entertain the concept of a non-measurable set, especially given how in practice, most of the sets one actually encounters will be Lebesgue measurable. (Indeed, one can view Solovay’s theorem as providing an explanation of this latter phenomenon.)")

#text("The reason given above is somewhat analogous to the reason why analysts work with the real number system ")#mi("{\\bf R}")#text(" rather than the rational number system ")#mi("{\\bf Q}")#text(". The latter has some ostensible advantages: the rationals are countable rather than uncountable, and all numbers have finite height. But by restricting to the rational model, one sacrifices almost completely the ability to take limits; and this cripples analysis far more than uncountability or infinite height does. This is not to say that the rational number system is useless for analysis – far from it – but the preferred “base” field for analysis is definitely ")#mi("{\\bf R}")#text(" (or ")#mi("{\\bf C}")#text(", in some cases).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01af8eef6cdd5bf8a6b1ef32bdbc781adf2b34f9c2ae404bb5977ccfb1356657-594ac91c0dba66001423e43601e58212b8c18cdae253753e7e7d3982fdce0e43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walt")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46831")[#strong[#text("Walt")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2010")])]

#text("You can add axioms to ZFC that make every set we care about measurable (projective determinacy is an example), so we could have our cake and eat it too. I’m not clear on the practical consequences of this. Are there lots of sets that we would like to be measurable, but we can’t prove that they are? Is lack of measurability a serious obstacle, or more of a technical nuisance? As far as I know, it’s just a technical nuisance, but some of the further reaches of probability theory get closer to the edge of what’s provable and what’s not, so maybe there it’s a real obstacle. For example, I have seen probability books that use the fact that the projection of a Borel set is Lebesgue measurable, which is sort-of the limit of what you can say in general in ZFC.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01af8eef6cdd5bf8a6b1ef32bdbc781adf2b34f9c2ae404bb5977ccfb1356657-594ac91c0dba66001423e43601e58212b8c18cdae253753e7e7d3982fdce0e43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walt")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46828")[#strong[#text("Walt")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2010")])]

#text("Grad Student: Switching to the Solovay model is a much bigger step than it might sound, beyond even the loss of the axiom of choice. It’s not true that the axiom of choice alone is what causes the troubles with unmeasurability. There are ordinary sets (sets that do not require the axiom of choice to construct) whose measurability is independent of the axioms of set theory. To make those sets Lebesgue measurable, we have to add, as a brand new axiom, that every subset of the reals has a closed set that’s slightly smaller and an open set that’s slightly bigger. We can’t say much of anything ")#emph[#text("about")]#text(" these open and closed sets. We just assert they exist so that we can say every set is measurable.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46839")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2010")])]

#text("Minor detail. In definition 3, “outer Jordan measure {m_{*,(J)}(E)}” should read: “outer Jordan measure {m^{*,(J)}(E)}”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1fbab2b5327242f8cf44211acaab4d4c2fe6d37b0043255e894e3b233fd66973-27e7185f0a476a907586ad2f0e4e340bfae4947eda42f40e70cfd858a8e226da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of some guy on the street")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46842")[#strong[#text("some guy on the street")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2010")])]

#text("Incidentally, the definition (for reasonable solids) of measure by circumscribing and exscribing simple solids (prisms) is found at least implicitly in Euclid’s books on solids, there called the “new” method of exhaustion, where it is used to argue that the volume of any pyramidal figure is the usual Ah/3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50c77abd6ff6c13af028d462682414793acfc9aa2c97fe5ab0c65e4a0f0904d9-ab74a537959dd3e0e686d7e0e2367fe9862d87b2387eaf7cff7a3fbee922e277.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ted")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46844")[#strong[#text("Ted")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2010")])]

#text("Prof. Tao – This is great, and I am grateful to you for all your contributions including teaching. There is no better way to groom next generation but to provide them with education & develop their interest. I have benefited from your blogs, and now i hope to benefit from your class notes. Sometime in future, do you think, will there be a time when you can post video lectures as well? You would have a class of thousands of students across the globe!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46858")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("re Definition 5 (Darboux integral).")

#text("Why not use the lower integral when defining the upper integral?")

#text("\\overline{\\int_a^b} f(x)\\ dx := – \\underline{\\int_a^b} -f(x)\\ dx")

#emph[#text("[I added a remark to this effect, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Gill")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46865")[#strong[#text("Nick Gill")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2010")])]

#text("Thanks for this Terry; I enjoyed reading it…")

#text("There’s a typo (A instead of B) in the definition of outer Jordan measure. ")#emph[#text("[Corrected, thanks! – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 1: Lebesgue measure « What’s new")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-46917")[#strong[#text("245A, Notes 1: Lebesgue measure « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2010")])]

#text("[…] instance, in one dimension, is infinite, and since has as its closure (see Exercise 18 of the prologue). On the other hand, all countable sets have Lebesgue outer measure zero. Indeed, one simply […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-47050")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2010")])]

#text("In the proof of Lemma 2, you say “A simple case check reveals that the intersection or set-theoretic difference of two intervals is again an interval.” Isn’t $[0,3] \\setminus (1,2) = [0,1] \\cup [2,3]$, which is not an interval? ")#emph[#text("[Fair enough; I’ve changed that portion of the argument to avoid using this claim. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ac1b2c0c904a32ebca147520068b9f3f7059437fd6275e1803c130bac86e024-dd343ef652ca906001ba89022e403911010f649895fc1327599851ac68b3b895.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wenying Gan")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-47246")[#strong[#text("Wenying Gan")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2010")])]

#text("Prof Tao, I think there is a typo in EX25. The integration of f(x) on interval [a,b] should be equal to $m(E_1)-m(E_2)$, but not $m^2 (E_1)-m^2 (E_2)$. ")#emph[#text("[")#mi("m^2")#text(" denotes the two-dimensional Lebesgue measure, not the square of that measure. I’ll add some text to clarify this. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems « What’s new")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-47249")[#strong[#text("245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2010")])]

#text("[…] length (see Exercise 14 of the prologue). These are Boolean algebras which are decreasing in : . Draw a diagram to indicate how these […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-47726")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2010")])]

#text("Prof. Tao,")#linebreak()#text(" For the question in “Remark 1”, if the set E is unbounded, the limit does not exist. Can we give the counterexample which is bounded?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-47727")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2010")])]

#text("Yes, it is possible, for instance by making the expression ")#mi("\\frac{1}{N^d} \\# (E \\cap \\frac{1}{N} {\\bf Z}^d)")#text(" behave differently for odd N and for even N, say in the one-dimensional case d=1; I’ll omit the precise construction as an exercise because it is quite instructive. (For a more difficult challenge, find an example where E is bounded, and the limit does not exist even when N is restricted to be a power of 2.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-48876")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2010")])]

#text("Prof. Tao,")#linebreak()#text(" I think your “challenge question” is the very hint for the original one. I may use the set ")#mi("E=\\cup_{n=1}^{\\infty}\\frac{{\\bf Z}}{2^n}\\cap [0,1]")#text(". when ")#mi("d=1")#text(". But for your “challenging”, ")#mi("E")#text(" seems to be useless here. Do I need another totally different idea for your question? I myself cannot find the hint even after I refer to your “Problem Solving Strategies”.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-47798")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2010")])]

#text("Prof. Tao,")#linebreak()#text(" For Exercise 5 (Characterisation of Jordan measurability), I think it is not very hard to give i)=>ii), ii)=>iii). When we need to prove something “exist”, we can try to construct it. But when it comes to take iii) as the premise to conclude i) or ii), one can have “trouble”. Since in iii), A can be not included in E or not including E. Then i) or ii) seems not that obvious. Do we need to prove by contradiction?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-47799")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2010")])]

#text("One does not need to prove by contradiction here, but as you say one does need to modify the set ")#mi("A")#text(" so that it becomes either completely contained inside ")#mi("E")#text(", or completely contains ")#mi("E")#text(". A hint: from the hypothesis (iii), what can you contain ")#mi("A \\Delta E")#text(" in?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 6: Outer measures, pre-measures, and product measures « What’s new")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-47926")[#strong[#text("245A, Notes 6: Outer measures, pre-measures, and product measures « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2010")])]

#text("[…] union of product sets of -measurable sets and -measurable sets (cf. Lemma 2 (and Exercise 2) from the prologue). We then define the quantity associated such a disjoint union by the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-48087")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2010")])]

#text("Prof. Tao,")#linebreak()#text(" For Exercise 7, the second statement, does one need to first prove that the boundary of the set is with Jordan measure zero? (It seems to become complicated). Considering the case ")#mi("d=1")#text(" , is possible that ")#mi("f(x)")#text(" has infinitely many zero points？ If so, the set ")#mi("\\{(x,t): x\\in B; 0\\leq t\\leq f(x)\\}")#text(" seems very strange and how can one come up with a elementary cover for approximation?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-48088")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2010")])]

#text("Use the fact that on a compact space, every continuous function is uniformly continuous. This will give a piecewise constant approximant to the continuous function.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-48101")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2010")])]

#text("Prof. Tao,")#linebreak()#text(" Does one need some “convenient” definition for the convex polytope to do Exercise 8? It is intuitively right. But how can one deal with such geometric concept?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-48102")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2010")])]

#text("Dear Prof. Tao,")#linebreak()#text(" In the Definition 5, why do you say “the hypothesis that f is bounded ensures that the supremum is over a non-empty set” instead of “ensures that the INFIMUM is over a non-empty set”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Y")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-48103")[#strong[#text("Y")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2010")])]

#text("Prof. Tao,")#linebreak()#text(" I tried to prove the uniqueness of elementary measure in the 1-D case, but I found that finally I had to deal with m'([0,a)), where 0<a<1, and a is a irrational number. Is it possible to avoid discussing the irrational number? One idea came to my mind is that using the non-negativity and finite additivity to construct monotonicity for m', and then applying the squeeze test for ")#mi("m^{\\prime}([0,a_1^{(n)}))\\leq m^{\\prime}([0,a))\\leq m([0,a_2^{(n)}))")#text(", where ")#mi("(a_1^({n)})")#text(" and ")#mi("(a_2^{(n)})")#text(" are rational number sequences which approximate ")#mi("a")#text(". But do such sequences exist? (Do I have to go over MATH 113A?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-48150")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2010")])]

#text("Prof. Tao,")#linebreak()#text(" I am confused in the definition 5. Since if ")#mi("f")#text(" is unbounded, then there at least exists a piecewise constant function, say, ")#mi("g=0")#text(", which satisfies ")#mi("g\\leq f")#text(", and ")#mi("g")#text(" is piecewise constant. Then the supremum on the right hand side of the definition of lower Darboux integral is always over a non-empty set. But if ")#mi("f")#text(" is unbounded, there is no piecewise constant function ")#mi("h")#text(" such that ")#mi("h\\geq f")#text(", and the infimum in the definition of upper darboux integral will be over a empty set. But as you said, “the hypothesis that ")#mi("f")#text(" is bounded ensures that the supremum is over a non-empty set.” Could you please point out my mistakes or explain it slightly?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-48153")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2010")])]

#text("f can be negative in Definition 5. To ensure the supremum is non-empty, we need a bound on f from below.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-48155")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2010")])]

#text("Thank you so much for your patience. This reminds me that one should always be very careful for the domain and the range of a function.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Y")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-48156")[#strong[#text("Y")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2010")])]

#text("Dear Prof. Tao,")

#text("I have some difficulties in Ex. 18 Problem 3. For the “if” part, one has to use the hypothesis “the topological boundary of E has outer Jordan measure zero”. I tried the definition. ")#mi("\\forall \\epsilon>0")#text(", ")#mi("\\exists B\\supset\\partial E")#text(", where ")#mi("B")#text(" is elementary set, such that ")#mi("m(B)<\\epsilon")#text(". The trouble for me is here. It seems that if I want to deduce E is Jordan measurable, I have to approximate E by the elementary sets from inside and outside. (say, ")#mi("A\\subset E\\subset C")#text(") And then use the argument like ")#mi("m(C\\backslash A)<m(B)")#text(". But how can I do this? Or should there be another \"right\" way to figure it out? (1 and 2 do not seem to be helpful here?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-48157")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2010")])]

#text("The definition of Jordan inner measure or Jordan outer measure will supply one of the elementary sets ")#mi("A, C")#text(". One can then use ")#mi("B")#text(" to construct the other set.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Y")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-48190")[#strong[#text("Y")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2010")])]

#text("Prof. Tao")

#text("I feel quite frustrated for the construction here. For the “if” part, if one can prove that for any ")#mi("B\\supset \\partial E")#text(", one always finds elementary sets ")#mi("A\\subset E\\subset C")#text(" with ")#mi("C\\backslash A \\subset B")#text(", which I think, is the essential goal, then things are done. But given ")#mi("B")#text(", even I get ")#mi("A")#text(" from the definition of Jordan inner measure, there seems to be no hope to construct ")#mi("C")#text(" without touching ")#mi("E")#text(", as I cannot find the way to make sure that ")#mi("A\\cup B\\subset E")#text(". But once I touch ")#mi("E")#text(", I have to deal with ")#mi("m_{*,(J)}(E)")#text(" and ")#mi("m^{*,(J)}(E)")#text(" at the same time which actually I need to “cancel” in the inequality.")

#text("I tried the definition again and again, but still did not see the light of dawn. I read the proof in Richard Courant’s “Introduction to Calculus and Analysis (vol.2)” for the same statement in which the “Jordan measure” is called “area”. He used the square cubes which is equivalent to the boxes here to define inner area and outer area, and finally used then cubes again to prove this statement. Does one have to use the boxes to cover ")#mi("E")#text(", like you did to rewrite the outer Jordan measure in the Notes 1, for the proof here? I think I must miss some points here which make the proof difficult for me. Could you please make the stuff clear here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-48191")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2010")])]

#text("Start with an elementary set C’ that contains E, and a small elementary set B that contains ")#mi("\\partial E")#text(". Then remove B from C’ to create another elementary set ")#mi("C^{\\prime} \\backslash B")#text(", which one can rewrite as the disjoint union of boxes. Each of these boxes is disjoint from ")#mi("\\partial E")#text(", and must therefore lie either completely outside of E, or completely inside of E (as the boxes are topologically connected). If one removes the boxes outside of E, one gets the desired sets A and C.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88466c191143df12bc10c0e5478b6f5e7900732bc4c13ea62d81e31c1544eb8b-efa8152dca20f58bdd00ce8e30050ede5a0439eb59699242ff9289e3438e0cb8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-48179")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2010")])]

#text("Dear Prof Tao,")#linebreak()#text(" first of all I would like to thank you for a wonderful blog. Now to my question:")

#text("1. When trying to prove the finite addivity of the Jordan measure in exercise 6, is it “enough” to prove it for the inner (outer) jordan measure? (Assuming that we already have proven the measurability of E U F, when both E and F are measurable.)")#linebreak()#text(" 2. This question is maybe a little bit out of line and unspecific, but anyhow… when thinking of measures (in general) is there according to you any mental picture which is particulary useful to have at hand?")

#text("Regards")#linebreak()#text(" H")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-48181")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2010")])]

#text("For Jordan measurable sets, the inner or outer Jordan measure is equal to the Jordan measure, so if one can show additivity for inner or outer Jordan measure for Jordan measurable sets, this certainly implies additivity of Jordan measure for the same sets. (Note though that inner and outer Jordan measure are not additive for general sets that are not assumed to be Jordan measurable.)")

#text("There are many ways to conceptualise measure. The viewpoint used here is geometric, using one’s intuition about length, area, or volume. But one can also use many other mental models. For instance, one can take a physical viewpoint and view the measure of a set E (now viewed as a physical body) as being something like the total mass of E; or an economic viewpoint and view the measure of E (now viewed as an economic asset, e.g. a tract of land) as the total cost or economic value of E; or a probabilistic viewpoint and view the measure of E (now interpreted as an event) as the probability that E occurs; or a political viewpoint and view the measure of E (now viewed as, say, a voting bloc) as the total political power of E; and so forth. Different people may prefer to use different conceptual models, but usually the best perspectives ultimately come from synthesising together multiple conceptual models to get a more stereoscopic viewpoint.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11128e4290fda88162336c609a63a91f90fa88316eff78b1757c67c996c650fa-fcde97ef5627bdc60423b8843e7c57dc4d57eb2cdfdad7ee7f6c20f9f347501a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthony")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-48192")[#strong[#text("anthony")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2010")])]

#text("Dear Prof Tao,")

#text("I think that")#linebreak()#text(" 1. one needs to turn “translation invariance” to italics for the sake of consistency with finite (sub-)additivity and monotony properties (after Remark 2)")#linebreak()#text(" 2. the sentences “Show that the bullet-riddled square , and with the bullets” and “The hypothesis that is bounded ensures that the supremum is over a non-empty set” are grammatically incomplete.")#linebreak()#text(" 3. one could mention Monte-Carlo Method in Remark 1.")

#text("best regards and thank you very much for this notes,")#linebreak()#text(" anthony")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/686d6d93bb25b4a7e5ca0018c2229694ff9188a7b558dc64ef394a0d6e2f3053-8b71c75bc5bd875771103e0532aef19458318916c0cd01e7494372a36b3931ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-176245")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2012")])]

#text("I think hint for exercise 11(1) means exercise 9, instead of 3?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-176286")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2012")])]

#text("Actually, I do intend Exercise 3 to be used as a hint for the proof. (It is true though that Exercise 9 is the “previous exercise” alluded to in the parenthetical comment.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-210499")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2012")])]

#text("The limit of the Riemann sum ")#mi("\\lim_{\\Delta({\\mathcal P})}{\\mathcal R}(f,{\\mathcal P})")#text(" is neither limit of real numbers nor limit of a real functions. More generally, it is also not the limit in a metric space. Is there a name of this kind of limit?")

#text("What’s the advantage of this type of limit? I’ve scanned the whole sets of 245a notes: it seems that this limit is never used again in the following notes (even in 245b?). Are there any other pieces of real analysis where this sort of limit is often useful?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-210574")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2012")])]

#text("This type of limit is an example of ")#link("http://en.wikipedia.org/wiki/Filter_(mathematics)")[#text("convergence along a filter")]#text(". In this case, the domain is the space of partitions ")#mi("{\\mathcal P}")#text(", the filter is the set of all collections of partitions with ")#mi("\\Delta({\\mathcal P})")#text(" less than a given threshold, and the function is the function ")#mi("{\\mathcal P} \\mapsto {\\mathcal R}(f, {\\mathcal P})")#text(".")

#text("One can recast topological notions of convergence in terms of filters (this is briefly alluded to in ")#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/")[#text("245B Notes 10")]#text("). The Bourbaki approach to topology emphasises this perspective, though I have generally chosen to downplay it in my own notes (instead using the more common approach of basing point set topology around the notion of an open set).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-210857")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2012")])]

#text("What properties are allowed to use for Exercise 8? Is reassembling allowed? In some special cases, one can use Ex.7. Using the lattice ")#mi("\\frac{1}{N}{\\Bbb Z}")#text(" and Ex.5(2) might work. But I think it’s not “rigorous” to say “consider those boxes containing the boundary of the solid triangle”. It would rely on a “picture” of the triangle. How can one turn this into a formal proof when the solid triangle is only regarded as a point set in ")#mi("{\\bf R}^2")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-210926")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2012")])]

#text("You can use the results from ")#strike[#text("Lemma")]#text(" Exercise 6, which provide some tools for reassembling complex Jordan measurable sets from simpler ones.")

#text("To turn the intuitive picture of the situation into a formal one is precisely the point of the exercise. One way to do it is by analytic geometry (writing each edge of the triangle as something like ")#mi("\\{ y=mx+b: x_1 \\leq x \\leq x_2\\}")#text(") and using an explicit covering the triangle by squares, and then upper bounding how many of these squares touch the boundary.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-210940")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2012")])]

#text("I can’t find Lemma 6. There are only 2 lemmas in this note. Do you mean Exercise 6?:-)")

#emph[#text("[Yes – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-214831")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2013")])]

#text("Regarding Exercise 3, I don’t know to show ")#mi("m^{\\prime}([0,a))=ca")#text(" when ")#mi("a\\in[0,1)\\setminus {\\bf Q}")#text(". Does one have to show that ")#mi("m^{\\prime}([0,\\lim_{n\\to\\infty}x_n))=\\lim_{n\\to\\infty}m^{\\prime}([0,x_n))")#text(" for ")#mi("\\{x_n\\}\\subset{\\bf Q}")#text("? Would you suggest alternative approach to get ")#mi("m^{\\prime}([0,a))=ca")#text("?")

#text("(I skipped some exercises until I reached exercise 1.3.16 in the book. I found that I have to do Exercise 1.2.21 first. When I went back to Exercise 1.2.21, I found that I need Exercise 1.1.11 which points to Exercise 1.1.3. Are the exercises set in this way deliberately?:) It seems that if one cannot do well in the exercises in one section, then it is very likely that one would have trouble in the later sections.So one has no way to skip exercises…)")

#emph[#text("[I recommend using some of the standard tricks discussed in ")#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")[#text("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")]#text(" ; in particular, Tricks 1, 2, 7, 8, and 18 are relevant here. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-215143")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2013")])]

#text("That’s very instructive. Now I see how Tricks 1,2,7, and 8 work. With a sequence of nested intervals (containing ")#mi("\\alpha\\in[0,1)\\setminus{\\bf Q}")#text(") ")#mi("\\{[a_n,b_n)\\}_{n=1}^\\infty")#text(" such that ")#mi("\\{a_n\\},\\{b_n\\}\\subset{\\bf Q}")#text(", ")#mi("a_n<\\alpha<b_n")#text(" for all ")#mi("n")#text(", and ")#mi("a_n\\to\\alpha")#text(", ")#mi("b_n\\to\\alpha")#text(", I think one can have")

#mi("cb_n-\\frac{1}{n}\\leq m^{\\prime}([0,\\alpha))\\leq ca_n+\\frac{1}{n}")#text(".")

#text("I don't see why Trick 18 is also relevant. How would ")#mi("\\limsup")#text(" help? Did I miss something here or is it implicitly used somewhere?")

#emph[#text("[One can flip a lim sup into a lim inf using Trick 4. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-215171")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2013")])]

#text("Ah, what I mean is that I don’t see why ")#mi("\\limsup")#text(" (i.e. Trick 18) is needed since I think one can take limit in the last formula above and then get")

#mi("c\\alpha-0\\leq m^{\\prime}([0,\\alpha))\\leq c\\alpha+0")

#text("since ")#mi("\\lim_{n\\to\\infty} a_n=\\alpha")#text(" and ")#mi("\\lim_{n\\to \\infty} \\lim b_n=\\alpha")#text("…")

#emph[#text("[Fair enough; as monotone bounded sequences are automatically convergent, one does not need to separate limits into lim inf and lim sup here. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-226237")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2013")])]

#text("Jack,this remind me of the process of constructing the irrationals from the rationals.")

#text("An irrational number is born to be approxiamated by rational numbers…")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-225819")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2013")])]

#text("Proposition 1:")

#text("If a set ")#mi("E\\in\\mathbf{R}^d")#text(" is covered by finite number of boxes ")#mi("B_1,\\cdots,B_n")#text(",and that ")#tao-math("\\left|B_1\\right|+\\cdots+\\left|B_n\\right|=p", block: false)#text(".Then it is easy to verify that $\\forall \\varepsilon>0$, ")#mi("E")#text(" can be covered by finite number of open boxes ")#mi("O_1,\\cdots,O_n")#text(",and that ")#tao-math("\\left|O_1\\right|+\\cdots+\\left|O_n\\right|=p+\\varepsilon", block: false)#text(".")

#text("Proposition 2:")

#text("If a set ")#mi("E\\in\\mathbf{R}^d")#text(" is covered by finite number of open boxes ")#mi("O_1,\\cdots,O_n")#text(",and that ")#tao-math("\\left|O_1\\right|+\\cdots+\\left|O_n\\right|=p", block: false)#text(".Then it is easy to verify that $\\forall \\varepsilon>0$, ")#mi("E")#text(" can be covered by finite number of boxes ")#mi("B_1,\\cdots,B_n")#text(",and that ")#tao-math("\\left|B_1\\right|+\\cdots+\\left|B_n\\right|=p-\\varepsilon", block: false)#text(".")

#text("From Exercise 5 (Characterisation of Jordan measurability) ,we have")

#text("Proposition 3:")

#text("If a set ")#mi("E\\in\\mathbf{R}^d")#text(" is jordan measurable,then $\\forall \\delta>0$,the border of ")#mi("E")#text(" can be covered by finite number of boxes ")#mi("B_1,\\cdots,B_n")#text(",and ")#tao-math("\\left|B_1\\right|+\\cdots+\\left|B_n\\right|=\\delta", block: false)#text(".")

#text("From Proposition 1 and Proposition 3,we can conclude Proposition 4.")

#text("Proposition 4:")

#text("If a set ")#mi("E\\in\\mathbf{R}^d")#text(" is jordan measurable,then $\\forall \\delta>0$,the border of ")#mi("E")#text(" can be covered by finite number of open boxes ")#mi("O_1,\\cdots,O_n")#text(",and ")#tao-math("\\left|O_1\\right|+\\cdots+\\left|O_n\\right|=\\delta", block: false)#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-225842")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2013")])]

#text("Unfortunately,proposition 2 is not true.It should be changed as follows")

#text("If a set ")#mi("E\\in\\mathbf{R}^d")#text(" is covered by finite number of open boxes ")#mi("O_1,\\cdots,O_n")#text(",and that ")#tao-math("\\left|O_1\\right|+\\cdots+\\left|O_n\\right|=p", block: false)#text(".Then it is easy to verify that ")#mi("\\exists \\varepsilon>0")#text(", E can be covered by finite number of boxes ")#mi("B_1,\\cdots,B_n")#text(",and that ")#tao-math("\\left|B_1\\right|+\\cdots+\\left|B_n\\right|=p-\\varepsilon", block: false)#text(".")

#text("But I think Proposition 1,3,4 is still true.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-225879")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2013")])]

#text("These material has a book version called “An introduction to measure theory”.Still,I like to read the blog version,because I like to read those comments made by other readers of your blog,also,the blog is more interactive.I decide to make some comments,take some notes and put up some personal thoughts of the material in the comment area while reading.")

#text("If my comments seems occupy too much room,just ignore it.I will be glad if my comments help someone(I hope so).And If I start my comment by “Dear Prof.Tao” ,that means I think I discover some errors in the post or I have some big confusions which can only be understood by the auther.(I decide I won’t post any general confusions casually,which should be solved by myself or asked at some other place).")

#text("Inherit the material of my above two comments,now I start to prove that If ")#mi("\\forall \\varepsilon>0")#text(",there exists finite number of boxes ")#mi("B_1,\\cdots,B_n")#text(" such that ")#tao-math("\\left|B_1\\right|+\\cdots+\\left|B_n\\right|=\\varepsilon", block: false)#text(",and that ")#mi("(B_i)_{i\\in \\{1,\\cdots,n\\}}")#text(" covers the border of ")#mi("E")#text(",then ")#mi("E")#text(" is jordan measurable.")

#text("This is the inverse of proposition 3.In fact,proposition 3 can be proved in a straightforward manner by using the definition of jordan measurable set.But in my eye,the inverse of Proposition 3 is not so obvious,so I think it is neccessary to write some words down to prove the inverse of proposition 3.")

#text("According to Proposition 1,it can be easily verified that ")#mi("\\forall \\varepsilon>0")#text(",there exists finite number of open boxes ")#mi("O_1,\\cdots,O_n")#text(" such that the border of ")#mi("E")#text(" can be covered by ")#mi("(O_i)_{i\\in\\{1,\\cdots,n\\}}")#text(",and that ")#tao-math("\\left|O_1\\right|+\\cdots+\\left|O_n\\right|=\\varepsilon", block: false)#text(".")

#text("And the interior of ")#mi("E")#text(" can be viewed as an at most countable union of disjoint open boxes ")#mi("L_1,\\cdots,L_n,\\cdots")#text("(according to the construction of open sets).So ")#mi("L_1,\\cdots,L_n,\\cdots")#text(" together with ")#mi("O_1,\\cdots,O_n")#text(" form an at most countable open covering of ")#mi("E")#text(".According to the Hein-Borel finite covering theorem,this at most countable open covering must have a finite subcovering ")#mi("H")#text(" which still covers ")#mi("E")#text(".It is also easy to verify that ")#mi("(H\\backslash \\{O_1,\\cdots,O_n\\})\\bigcup \\{O_1,\\cdots,O_n\\}=H")#text(" is still a finite covering of ")#mi("E")#text(".And in fact ")#mi("\\bigcup(H\\backslash \\{O_1,\\cdots,O_n\\})")#text(",which means the union of all the elements of ")#mi("H\\backslash \\{O_1,\\cdots,O_n\\}")#text(",is a subset of the interior of ")#mi("E")#text(".")

#text("So we have constructed a finite open covering of ")#mi("E")#text("——")#mi("H=(H\\backslash \\{O_1,\\cdots,O_n\\})\\bigcup \\{O_1,\\cdots,O_n\\}")#text(".And we have constructed a subset of ")#mi("E")#text(" which is a finite union of open boxes ——$\\bigcup (H\\backslash \\{O_1,\\cdots,O_n\\})$.It is easy to verify that ")#mi("m(H)-m((\\bigcup (H\\backslash \\{O_1,\\cdots,O_n\\}))\\leq \\varepsilon")#text(".")

#text("Combine this result with the corrected version of proposition 2,we can conclude that ")#mi("E")#text(" is indeed jordan measurable.")#mi("\\Box")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-226244")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2013")])]

#text("Dear Prof.Tao,")

#text("In exercise 3,I think ")#mi("{m^{\\prime}: {\\mathcal E}({\\bf R}^d) \\rightarrow {\\bf R}^+}")#text(" should be ")#mi("{m^{\\prime}: {\\mathcal E}({\\bf R}^d) \\rightarrow \\mathbf{R}^+\\bigcup\\{0\\}}")#text(",or ")#mi("{m^{\\prime}: {\\mathcal E}({\\bf R}^d) \\rightarrow \\mathbf{R}^*}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-226293")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2013")])]

#text("In this text, ")#mi("{\\bf R}^+")#text(" denotes the non-negative reals (as stated explicitly in Exercise 3).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-226312")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2013")])]

#text("…In fact ,it is not an interesting “errata”…It is related to notations,not mathematics.")

#text("In my convention,when I was in middle school or faced with an exam,etc,when seeing ")#mi("x\\in \\mathbf{R}^+")#text(",this always means that ")#mi("x")#text(" is positive,and can’t be zero…")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-226452")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2013")])]

#text("Regarding to Exercise 11,(3),I think I can write down some notes")#linebreak()#text(" here.These notes are about Gaussian elimination method and")#linebreak()#text(" determinant.Those who want to solve the problem yourself please ignore this notes.")

#text("A linear transformationm ")#mi("L")#text(" from ")#mi("\\mathbf{R}^d")#text(" to ")#mi("\\mathbf{R}^d")#text(" will")#linebreak()#text(" transform a ")#mi("n")#text(" dimensional square box ")#mi("[0,1]\\times\\cdots [0,1]")#text(" into")#linebreak()#text(" another stuff,namely, a ")#mi("n")#text(" dimensional parallelogram.This exercise")#linebreak()#text(" let me prove that the jordan measure of the parallelogram")#linebreak()#text(" corresponding to the square box is ")#tao-math("\\left|\\det L\\right|", block: false)#text(".")

#text("Luckily,by using Gaussion elimation method twice,we can prove it.What")#linebreak()#text(" does it mean to use Gaussion elimation method twice?Now I explain it.")

#text("The linear transformation ")#mi("L:\\mathbf{R}^d\\to\\mathbf{R}^d")#text(" can be")#linebreak()#text(" represented by a matrix ")#mi("\\displaystyle \\begin{pmatrix}   a_{11}&\\cdots&a_{1d}\\\\   \\cdots&\\cdots&\\vdots\\\\   a_{d1}&\\cdots&a_{dd}\\\\ \\end{pmatrix}")#text(",by using Gaussion elimation once,from the head to the")#linebreak()#text(" foot,we can change this matrix into an upper triangle form")#linebreak()#text(" ")#mi("\\displaystyle \\begin{pmatrix}   b_{11}&\\cdots&b_{1d}\\\\   0&\\cdots&\\vdots\\\\   0&0&b_{dd}\\\\ \\end{pmatrix}")#text(".Then by using Gaussion elimation from the foot to the")#linebreak()#text(" head,we can change this upper triangle form into the diagonal form")#linebreak()#text(" ")#mi("\\displaystyle \\begin{pmatrix}   b_{11}&\\cdots&0\\\\   0&\\cdots&0\\\\   0&0&b_{dd}. \\end{pmatrix}")#text(",where ")#mi("\\forall i\\neq j")#text(", ")#mi("b_{ij}=0")#text(".")

#text("I love diagonal form,because the diagonal form transform a square box")#linebreak()#text(" ")#mi("[0,1]\\times\\cdots\\times [0,1]")#text(" into a rectangle box")#linebreak()#text(" ")#mi("[0,b_{11}]\\times\\cdots\\times [0,b_{dd}]")#text(".It is very happy to see that")#linebreak()#text(" the volume of ")#mi("[0,b_{11}]\\times \\cdots\\times [0,b_{dd}]")#text(" is")#linebreak()#text(" ")#tao-math("\\left|b_{11}\\cdots b_{dd}\\right|", block: false)#text(",which is also exactly the absolute value of")#linebreak()#text(" the determinant of this diagonal matrix.")

#text("The process of Gaussion elimation do not affect the determinant of a")#linebreak()#text(" matrix.")

#text("And also,The process of Gaussion elimation do not affect the volume of")#linebreak()#text(" the ")#mi("n")#text(" dimensional parallelogram(This may seems not evident at")#linebreak()#text(" first,but it is in fact true after careful consideration.)")

#text("So the jordan measure of the parallelogram corresponding to the square box is ")#tao-math("\\left|\\det L\\right|", block: false)#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-226479")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2013")])]

#text("A remark to Exercise 14 (Metric entropy formulation of Jordan measurability) :")

#text("1.Why half-open box ?")

#text("I think the half-open box ")#mi("\\displaystyle [\\frac{i_1}{2^n}, \\frac{i_1+1}{2^n}) \\times \\ldots \\times [\\frac{i_d}{2^n}, \\frac{i_d+1}{2^n})")#text(" can also be replaced by closed box ")#mi("\\displaystyle [\\frac{i_1}{2^n}, \\frac{i_1+1}{2^n}] \\times \\ldots \\times [\\frac{i_d}{2^n}, \\frac{i_d+1}{2^n}]")#text(".")

#text("But it shouldn’t be replaced by open box,because there is finite number of holes in ")#mi("\\displaystyle (\\frac{i_1}{2^n}, \\frac{i_1+1}{2^n}) \\times \\ldots \\times (\\frac{i_d}{2^n}, \\frac{i_d+1}{2^n})")#text(",so it may not cover ")#mi("E")#text(".")

#text("2.What does this exercise mean?")

#text("I think this exercise means that a bounded set is Jordan measurable if and only if the boundary of this set can be covered by arbitrary small finite number of boxes.")

#text("3.Some thoughts about Jordan measure and Lebesgue measure.")

#text("In the past,I have an acquaintance with Lebesgue measurable sets.Now I think the main difference between the Jordan measurable sets and the Lebesgue measurable sets is that the former is essentially “arbitrarily finite cover”,but the latter is essentially “arbitrarily countable infinite cover”.")

#text("So why there is no “arbitrarily uncountable infinite cover”?If there is such,then I create a measure which is superior to the Lebesgue measure!But unfortunately I think this will not be realistic,because the arbitrarily uncountable infinite cover do not exists at all in ")#mi("\\mathbf{R}")#text("!(If so,there are only countable number of rational numbers,and there is an injective map from the rational number set to the arbitrarily uncountable cover,which is absurd!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-226505")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2013")])]

#text("I’d like to write down some notes to Exercise 18.")

#text("(1) and (2) are counterpart problems.Although they can be solved individually,I prefer to deduce one from the other.")

#text("Regarding (4),")

#text("We know that ")#mi("[0,1]\\bigcap \\mathbf{Q}")#text(" has outer Lebesgue outer measure 0,and Jordan outer measure 1.")

#text("So,in the changing from arbitrary finite cover to arbitrary countable cover,there is really something significant happen that result in such difference!Finite cover,though arbitrary,is still finite,we do not expect any thing amazing from finite stuff.But countable infinite is a really big step,there must be something in it that makes things work !But I have to go to sleep first!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-226629")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2013")])]

#text("A remark to Exercise 19 (Carathéodory type property):")

#text("I think the elementary set ")#mi("F")#text(" can be replaced by the Jordan measurable set ")#mi("F")#text(",just take a limit.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-226632")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2013")])]

#text("Dear Prof.Tao,")

#text("In exercise Exercise 24 (Basic properties of the Riemann integral) ,(3)(Indicator) ,”If ")#mi("E")#text(" is a Jordan measurable of ")#mi("[a,b]")#text("” should be “If ")#mi("E")#text(" is a Jordan measurable subset of ")#mi("[a,b]")#text("” .")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-353431")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2014")])]

#text("In Exercise 11.1, can you give a hint that why one can say that ")#mi("L(E)")#text(" is Jordan measurable when ")#mi("E")#text(" is an elementary set by the previous exercises?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-353480")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2014")])]

#text("Elementary sets are Boolean combinations of polytopes, and linear transformations of polytopes are polytopes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-469017")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2016")])]

#text("In Exercise 7(1), if we consider ")#mi("f")#text(" being measurable only, do we have an example that the Jordan measure of the graph of ")#mi("f")#text(" is positive?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-469018")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2016")])]

#text("Is the graph of ")#mi("f:[0,1]\\to {\\bf R}")#text(" with ")#mi("f=1_{Q\\cap[0,1]}")#text(" Jordan measurable?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-480197")[#strong[#text("1 số vấn đề hay về tích phân Riema")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2017")]

#text("[…] ")#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/")[#text("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/comment-page-1/#comment-560333")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2020")])]

#text("hello prof, I am 15 and have only recently started reading your book, and have a question which I am curious about:")#linebreak()#text(" prove that all distance preserving maps preserve Jordan measure..")#linebreak()#text(" will be highly obliged to know your answer")
]
