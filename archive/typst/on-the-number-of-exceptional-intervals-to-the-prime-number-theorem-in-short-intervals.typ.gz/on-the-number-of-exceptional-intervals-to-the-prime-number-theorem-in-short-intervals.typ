// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/06/02/on-the-number-of-exceptional-intervals-to-the-prime-number-theorem-in-short-intervals/
// Converted to Typst by tao2typ: "2026-10-14T16:39:18.349753+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On the number of exceptional intervals to the prime number theorem in short intervals", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On the number of exceptional intervals to the prime number theorem in short intervals")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 June 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/06/02/on-the-number-of-exceptional-intervals-to-the-prime-number-theorem-in-short-intervals/")[#text("https://terrytao.wordpress.com/2025/06/02/on-the-number-of-exceptional-intervals-to-the-prime-number-theorem-in-short-intervals/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("https://olemiss.edu/profiles/argafni")[#text("Ayla Gafni")]#text(" and I have just uploaded to the arXiv the paper “")#link("https://arxiv.org/abs/2505.24017")[#text("On the number of exceptional intervals to the prime number theorem in short intervals")]#text("“. This paper makes explicit some relationships between zero density theorems and prime number theorems in short intervals which were somewhat implicit in the literature at present.")

#text("Zero density theorems are estimates of the form")

#mi("\\displaystyle N(\\sigma,T) \\ll T^{A(\\sigma)(1-\\sigma)+o(1)}")

#text("for various ")#mi("{0 \\leq \\sigma < 1}")#text(", where ")#mi("{T}")#text(" is a parameter going to infinity, ")#mi("{N(\\sigma,T)}")#text(" counts the number of zeroes of the Riemann zeta function of real part at least ")#mi("{\\sigma}")#text(" and imaginary part between ")#mi("{-T}")#text(" and ")#mi("{T}")#text(", and ")#mi("{A(\\sigma)}")#text(" is an exponent which one would like to be as small as possible. The Riemann hypothesis would allow one to take ")#mi("{A(\\sigma)=-\\infty}")#text(" for any ")#mi("{\\sigma > 1/2}")#text(", but this is an unrealistic goal, and in practice one would be happy with some non-trivial upper bounds on ")#mi("{A(\\sigma)}")#text(". A key target here is the ")#emph[#text("density hypothesis")]#text(" that asserts that ")#mi("{A(\\sigma) \\leq 2}")#text(" for all ")#mi("{\\sigma}")#text(" (this is in some sense sharp because the Riemann-von Mangoldt formula implies that ")#mi("{A(1/2)=2}")#text("); this hypothesis is currently known for ")#mi("{\\sigma \\leq 1/2}")#text(" and ")#mi("{\\sigma \\geq 25/32}")#text(", but the known bounds are not strong enough to establish this hypothesis in the remaining region. However, there was a recent advance of Guth and Maynard, which among other things improved the upper bound ")#mi("{A_0}")#text(" on ")#mi("{\\sup_\\sigma A(\\sigma)}")#text(" from ")#mi("{12/5=2.4}")#text(" to ")#mi("{30/13=2.307\\dots}")#text(", marking the first improvement in this bound in over four decades. Here is a plot of the best known upper bounds on ")#mi("{A(\\sigma)}")#text(", either unconditionally, assuming the density hypothesis, or the stronger Lindelöf hypothesis:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2025/06/a_sigma.png")[#image("../assets/307a5141a16e75946d644bc64f7aa0f0c73bbbd4d0ec3c117f183287200798bd-4445553ed11ef09a2582c845118754aecb796d4b35b4d76715e37929f00498ba.png", width: 90%)]
]

#text("One of the reasons we care about zero density theorems is that they allow one to localize the prime number theorem to short intervals. In particular, if we have the uniform bound ")#mi("{A(\\sigma) \\leq A_0}")#text(" for all ")#mi("{\\sigma}")#text(", then this leads to the prime number theorem")

#mi("\\displaystyle  \\sum_{x \\leq n < x+x^\\theta} \\Lambda(n) \\sim x^\\theta")#text(" holding for all ")#mi("{x}")#text(" if ")#mi("{\\theta > 1-\\frac{1}{A_0}}")#text(", and for almost all ")#mi("{x}")#text(" (possibly excluding a set of density zero) if ")#mi("{\\theta > 1 - \\frac{2}{A_0}}")#text(". For instance, the Guth-Maynard results give a prime number theorem in almost all short intervals for ")#mi("{\\theta}")#text(" as small as ")#mi("{2/15+\\varepsilon}")#text(", and the density hypotheis would lower this just to ")#mi("{\\varepsilon}")#text(".")

#text("However, one can ask about more information on this exceptional set, in particular to bound its “dimension” ")#mi("{\\mu(\\theta)}")#text(", which roughly speaking amounts to getting an upper bound of ")#mi("{X^{\\mu(\\theta)+o(1)}}")#text(" on the size of the exceptional set in any large interval ")#mi("{[X,2X]}")#text(". Based on the above assertions, one expects ")#mi("{\\mu(\\theta)}")#text(" to only be bounded by ")#mi("{1}")#text(" for ")#mi("{\\theta < 1-2/A}")#text(", be bounded by ")#mi("{-\\infty}")#text(" for ")#mi("{\\theta > 1-1/A}")#text(", but have some intermediate bound for the remaining exponents.")

#text("This type of question had been studied in the past, most direclty ")#link("https://zbmath.org/0972.11087")[#text("by Bazzanella and Perelli")]#text(", although there is earlier work by many authors om some related quantities (such as the second moment ")#mi("{\\sum_{n \\leq x} (p_{n+1}-p_n)^2}")#text(" of prime gaps) by such authors as ")#link("https://zbmath.org/0028.34802")[#text("Selberg")]#text(" and ")#link("https://zbmath.org/0646.10032")[#text("Heath-Brown")]#text(". In most of these works, the best available zero density estimates at that time were used to obtain specific bounds on quantities such as ")#mi("{\\mu(\\theta)}")#text(", but the numerology was usually tuned to those specific estimates, with the consequence being that when newer zero density estimates were discovered, one could not readily update these bounds to match. In this paper we abstract out the arguments from previous work (largely based on the explicit formula for the primes and the second moment method) to obtain an explicit relationship between ")#mi("{\\mu(\\theta)}")#text(" and ")#mi("{A(\\sigma)}")#text(", namely that")

#mi("\\displaystyle  \\mu(\\theta) \\leq \\inf_{\\varepsilon>0} \\sup_{0 \\leq \\theta<1; A(\\sigma) \\geq \\frac{1}{1-\\theta}-\\varepsilon} \\mu_{2,\\sigma}(\\theta)")#text(" where")

#mi("\\displaystyle  \\mu_{2,\\theta}(\\theta) = (1-\\theta)(1-\\sigma)A(\\sigma)+2\\sigma-1.")#text(" Actually, by also utilizing fourth moment methods, we obtain a stronger bound")

#mi("\\displaystyle  \\mu(\\theta) \\leq \\inf_{\\varepsilon>0} \\sup_{0 \\leq \\theta<1; A(\\sigma) \\geq \\frac{1}{1-\\theta}-\\varepsilon} \\min( \\mu_{2,\\sigma}(\\theta), \\mu_{4,\\sigma}(\\theta) )")#text(" where")

#mi("\\displaystyle  \\mu_{4,\\theta}(\\theta) = (1-\\theta)(1-\\sigma)A^*(\\sigma)+4\\sigma-3")#text(" and ")#mi("{A^*(\\sigma)}")#text(" is the exponent in “additive energy zero density theorems”")

#mi("\\displaystyle N^*(\\sigma,T) \\ll T^{A^*(\\sigma)(1-\\sigma)+o(1)}")#text(" where ")#mi("{N^*(\\sigma,T)}")#text(" is similar to ")#mi("{N(\\sigma,T)}")#text(", but bounds the “additive energy” of zeroes rather than just their cardinality. Such bounds have appeared in the literature since the work of Heath-Brown, and are for instance a key ingredient in the recent work of Guth and Maynard. Here are the current best known bounds:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2025/06/astar_sigma.png")[#image("../assets/ade4e9fc51a5d01be9b1d389110dfa6714eac15f09c4ffd2b5885b46392e8b08-a087c85703796cd0bd4dec3d62eb3b62a921de8d65463cf4301af2b462c76003.png", width: 90%)]
]

#text("These explicit relationships between exponents are perfectly suited for the recently launched ")#link("https://github.com/teorth/expdb")[#text("Analytic Number Theory Exponent Database")]#text(" (ANTEDB) (discussed previously ")#link("https://terrytao.wordpress.com/2025/01/28/new-exponent-pairs-zero-density-estimates-and-zero-additive-energy-estimates-a-systematic-approach/")[#text("here")]#text("), and have been uploaded to that site.")

#text("This formula is moderately complicated (basically an elaborate variant of a Legendre transform), but easy to calculate numerically with a computer program. Here is the resulting bound on ")#mi("{\\mu(\\theta)}")#text(" unconditionally and under the density hypothesis (together with a previous bound of Bazzanella and Perelli for comparison, where the range had to be restricted due to a gap in the argument we discovered while trying to reproduce their results):")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2025/06/unconditional.png")[#image("../assets/098647ea94552d24df9e9abada824d9cde759a45cfd77514022e8fdf232c8287-f30671a5bf4017b7193d672c066fe81707a8977ffc2760e22dc6a34297f50810.png", width: 90%)]
]

#text("For comparison, here is the situation assuming strong conjectures such as the density hypothesis, Lindelof hypothesis, or Riemann hypothesis:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2025/06/conditional.png")[#image("../assets/e92010aff307c34302eb9033f608ee472e4670b9e2093235f3df1d89e63e2dc7-0bb997e7bf540a2c3583a8212bf1e7f5a119428fc02f29a439baee233068f7f1.png", width: 90%)]
]

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/06/02/on-the-number-of-exceptional-intervals-to-the-prime-number-theorem-in-short-intervals/#comment-688233")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2025")])]

#text("Missing paper tag")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d37a78db57722ca847c0890d993d604a290dfe9ae7f4f145cf0c52abcd98465-612c0aad0415c35ba32f9ec1ea65f8df3f28d31ff167a2e3f158241d22cdbb12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jess Mcallister")]], [#link("https://terrytao.wordpress.com/2025/06/02/on-the-number-of-exceptional-intervals-to-the-prime-number-theorem-in-short-intervals/#comment-688479")[#strong[#text("Jess Mcallister")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2025")])]

#text("Dr. Tao,")

#text("Have you ever thought of going the other way around and instead of looking for the patterns in primes, looking at the patterns in the integer pairs that make up the products?Like how in a divisor plot there are two patterns that reoccur throughout the number line, showing where the integer pairs will fall, and where they don’t fall are the primes?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d37a78db57722ca847c0890d993d604a290dfe9ae7f4f145cf0c52abcd98465-612c0aad0415c35ba32f9ec1ea65f8df3f28d31ff167a2e3f158241d22cdbb12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jess Mcallister")]], [#link("https://terrytao.wordpress.com/2025/06/02/on-the-number-of-exceptional-intervals-to-the-prime-number-theorem-in-short-intervals/#comment-688480")[#strong[#text("Jess Mcallister")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2025")])]

#text("My apologies, where the integer pairs only fall once are prime")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/06/02/on-the-number-of-exceptional-intervals-to-the-prime-number-theorem-in-short-intervals/#comment-688491")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2025")])]

#text("Dear Professor Tao and others,")

#text("First, I want to thank you for your work. I recently came across your blog via Lex Fridman’s podcast interview and, though I’m largely uneducated in mathematics, I was fascinated by the topics discussed.")

#text("I’m a software developer by trade, and I have a question regarding the Twin Prime Conjecture – or more generally, the apparent randomness of primes. I understand that primes become sparser as numbers grow larger, but what confuses me is that they are often described as “random”, which seems to conflict with how predictable their construction is from a computational standpoint.")

#text("Let me explain what I mean with a thought experiment.")

#text("Imagine a system – a kind of counting machine – that tracks every prime factor as you count upward. For each number ")#raw("N")#text(", you increment a counter for each smaller prime ")#raw("p")#text(". Once that counter reaches ")#raw("p")#text(", you know ")#raw("N")#text(" is divisible by ")#raw("p")#text(", and you reset the counter. (Modulo arithmetic makes this straightforward.) This system could, in theory, be used to determine whether a number is composite without factoring it explicitly.")

#text("If we extend this idea, we can track counters for ")#strong[#text("all")]#text(" primes – even those larger than ")#raw("√N")#text(" – just to observe the periodicity of their appearances. At any given ")#raw("N")#text(", you’d know the relative phase of every small prime clock. You could then, in principle, check whether both ")#raw("N")#text(" and ")#raw("N+2")#text(" avoid all small prime divisors – a necessary condition for being twin primes.")

#text("Now, I realize this doesn’t solve the Twin Prime Conjecture. But if such a system can be modeled abstractly, couldn’t we begin analyzing the dynamics of these periodic “prime clocks” to determine when twin primes are ")#strong[#text("forced")]#text(" to occur – i.e., when enough of the prime clocks are out of phase simultaneously? This could potentially also be extended to greater gaps or even prime triplets or more, not just twins.")

#text("To my mind, this feels like a constructive way to approach what is usually framed probabilistically or heuristically. It suggests primes are not random at all, just governed by a very complex interference of periodicities.")

#text("Am I missing something fundamental here? Is this line of thinking too naive, or is it similar in spirit to any modern approaches (e.g., sieve theory or analytic number theory)? I would deeply appreciate any insight or redirection.")

#text("With gratitude,")#linebreak()#strong[#text("Alex")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Products of consecutive integers with unusual anatomy | What's new")]], [#link("https://terrytao.wordpress.com/2025/06/02/on-the-number-of-exceptional-intervals-to-the-prime-number-theorem-in-short-intervals/#comment-692106")[#strong[#text("Products of consecutive integers with unusual anatomy | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2026")])]

#text("[…] and Maynard (as converted to a bound on exceptions to the prime number theorem in short intervals by Gafni and myself); previous zero density theorems were barely not strong enough to close the […]")
]
