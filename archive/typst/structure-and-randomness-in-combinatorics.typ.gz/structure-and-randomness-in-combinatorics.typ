// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/
// Converted to Typst by tao2typ: "2026-10-14T15:16:26.711197+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Structure and randomness in combinatorics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Structure and randomness in combinatorics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 31 July 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/")[#text("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’ve just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" my lecture notes “")#link("http://arxiv.org/abs/0707.4269")[#text("Structure and randomness in combinatorics")]#text("” for my tutorial at the upcoming ")#link("http://focs2007.org/")[#text("FOCS 2007 conference")]#text(" in October. This tutorial covers similar ground as my ")#link("http://front.math.ucdavis.edu/math.NT/0512114")[#text("ICM paper")]#text(" (or ")#link("http://www.math.ucla.edu/~tao/preprints/Slides/icmslides2.pdf")[#text("slides")]#text("), or my ")#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/")[#text("first two")]#text(" ")#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/")[#text("Simons lectures")]#text(", but focuses more on the “nuts-and-bolts” of how structure theorems actually work to separate objects into structured pieces and pseudorandom pieces, for various definitions of “structured” and “pseudorandom”. Given that the target audience consists of computer scientists, I have focused exclusively here on the combinatorial aspects of this dichotomy (applied for instance to functions on the Hamming cube) rather than, say, the ergodic theory aspects (which are covered in ")#link("http://www.math.northwestern.edu/~kra/")[#text("Bryna Kra")]#text("‘s ")#link("http://www.math.northwestern.edu/~kra/papers/montreal.pdf")[#text("lecture notes from Montreal")]#text(", or ")#link("http://front.math.ucdavis.edu/math.CO/0604456")[#text("my notes from Montreal")]#text(" for that matter). While most of the known applications of these decompositions are number-theoretic (e.g. my ")#link("http://en.wikipedia.org/wiki/Green-Tao_theorem")[#text("theorem with Ben Green")]#text("), the number theory aspects are not covered in detail in these notes. (For that, you can read Bernard Host’s ")#link("http://arxiv.org/abs/math.DS/0609795")[#text("Bourbaki article")]#text(", ")#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text("‘s ")#link("http://front.math.ucdavis.edu/math.NT/0508063")[#text("Gauss-Dirichlet article")]#text(" or ")#link("http://www.arxiv.org/abs/math.NT/0601211")[#text("ICM article")]#text(", or my ")#link("http://www.arxiv.org/abs/math.NT/0505402")[#text("Coates article")]#text(".)")

#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/#comment-5361")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2007")]

#text("[…] Structure and randomness in combinatorics I’ve just uploaded to the arXiv my lecture notes “Structure and randomness in combinatorics” for my […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/#comment-5430")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2007")])]

#text("HOWDY DR. T!")

#text("The linked article references “On the structure of certain infinite random hypergraphs” by one T. Austin.")

#text("If you know of a version of the cited preprint on the internet, could you be so kind as to link to it? I have had little luck with google and arxiv searches.")

#text("Sincerely,")

#text("Nate")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/#comment-5476")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2007")])]

#text("Prof Tao,")

#text("I am wondering if the following is known. does Green’s arithmetic regularity lemma over the Hamming cube extend to higher uniformity norms? More specifically, for every k>2 and eps, every function f, is there also a subspace V of constant codimension, such that f on most translates of V have small Gowers k-uniformity norm?")

#text("If this is known (or for specific k), can you provide a reference? Thanks.")

#text("Sincerely,")#linebreak()#text(" Victor")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/#comment-5570")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2007")])]

#text("Dear Nate,")

#text("Tim Austin’s article is in draft form right now and should be available in a few weeks (it is pending the finalisation of another joint article between Tim and myself which uses Tim’s structure theorem for a property testing application – stay tuned!).")

#text("Dear Victor,")

#text("There is a higher version of this lemma known, at least in the k=3 case; the one new twist is that rather than slicing up the Hamming cube into translates of a vector space (or in other words, level sets of a few linear functions), one needs to slice up the Hamming cube instead into ")#emph[#text("quadratic")]#text(" varieties – level sets of a few quadratic functions. One can see the need for this by looking at the standard maximum-rank quadratic form ")#mi("(-1)^{\\sum_{1 \\leq i < j \\leq n} x_i x_j}")#text("; no amount of slicing into linear subspaces will eradicate the quadratic nature of this form, and so you cannot get k=3 Gowers uniformity of the function (minus its average, of course) unless you use quadratic slices (or if you use a ")#emph[#text("lot")]#text(" of linear slices, at least n of them).")

#text("A reference for this is Proposition 3.9 of Ben Green’s Montreal lecture notes:")

#link("http://www.arxiv.org/abs/math.CA/0604089")[#text("http://www.arxiv.org/abs/math.CA/0604089")]

#text("If the Gowers inverse conjecture is true for higher k, then there will be analogues for higher k also (where now we slice using polynomials of degree k-1).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/#comment-5593")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2007")])]

#text("Hi Terry, thanks for the beautifully written article. A small correction: Reed-Solomon should be replaced by Reed-Muller.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/#comment-5604")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2007")])]

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6ac75207df45b68f726005648d15df30a65f31def10cf8bbda313159a6112db-7958a10f5849ab0f02c4e5036a86d56ccd4d708d226a2a31e25ba9095b682cab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/#comment-5747")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2007")])]

#text("What happens if one writes the combinatorial formulas for nCr, nPr in terms of the gamma function? Does this lead to randomness in combinatorics? Does it permit a combinatorics of objects arbitrary picked from two places along a continous interval among the reals? Would we need a different notion of “choosing” and “permutation”, or would it permit a combinatorics of fractional-valued objects with similar notions to one already? Supposing we can’t exactly count how many objects we have, but say we have approximately 6 objects and then we choose approximately 4 objects, would such a combinatorics allow us to compute how many “possibilities” would exist?")

#text("I can’t say that writing the combinatorial formulas in terms of the gamma function makes sense for me, at least not at this time. But, formally it seems permissible… at least if we take the combinations and permutations formulas as axioms, even if my little mind doesn’t get how to understand it (possibly yet). I’d guess someone could make some sense of this idea someday, but if you think really not, by all means have a laugh at this idea.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59c57b41bed6af30cc795fa69608f3e4c1b31b07b63386f857401605a1b9e6b4-2a3e527e061688ff79a4d2bbf36dfe20530f39117cdf85fddcdb6e8d9fcfdf23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zaiaku")]], [#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/#comment-5994")[#strong[#text("Zaiaku")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2007")])]

#text("Intersting write. Got me thinking tonight on this one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3dcaf18c2ac3f7bb0b4aa37db5adb45112bb7591f93e5023f92bd97cc63dd647-a95bbcc46c327adb352f6136cb179f579b934c971e99c35b490bca98501035a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of NATE")]], [#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/#comment-7383")[#strong[#text("NATE")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2007")])]

#text("Howdy.")

#text("Did you (or somebody else) ever write up a version of your variant on the hypergraph counting lemma to cover the case of non-partite hypergraphs?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/#comment-7385")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2007")])]

#text("Dear NATE,")

#text("Not as far as I know. You can “fake” it by interpreting a non-partite k-uniform hypergraph on n vertices as a k-partite k-uniform hypergraph on nk vertices in the obvious manner, and applying the regularity lemma to that, but it’s not fully satisfactory because the lower order hypergraphs that come out of that regularity lemma are not symmetric enough to have arisen from a non-partite hypergraph on the original vertex set, unless you do some technical trickery to force the symmetry. But probably the most direct way to proceed is to repeat the proof in the non-partite setting, working in spaces of functions which are symmetric with respect to the permutation group on k elements, and making sure that all the partitions etc. which arise are also symmetric (or at least equivariant) with respect to such permutations.")

#text("Of course, one probably needs to have some non-trivial application in mind for the regularity lemma in order to go to all this trouble; one already has the hypergraph regularity lemmas of Gowers and of Rodl-Nagle-Schacht-Skokan which are more or less of comparable strength.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3dcaf18c2ac3f7bb0b4aa37db5adb45112bb7591f93e5023f92bd97cc63dd647-a95bbcc46c327adb352f6136cb179f579b934c971e99c35b490bca98501035a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of NATE")]], [#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/#comment-7392")[#strong[#text("NATE")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2007")])]

#text("I have a definite application in mind, and I am shopping around for which version of hypergraph regularity will most easily lend itself to the generalization that I have in mind.")

#text("If you have any insights on which formulations are better in different contexts, I’d love to hear them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/#comment-7394")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2007")])]

#text("Well, for obvious reasons I am not the most objective judge of the relative worth of my version of the hypergraph regularity lemmas of Gowers and Rodl et al :-) . The latter has been used since in several places by Rodl and his school, so is presumably a good general-purpose tool. Gowers’ version seems to extend relatively well to sparse settings – Ben Green and I (very implicitly) took advantage of this in our papers on the primes. My version has an additional parameter F() which turns out to be useful in some property testing applications, but one can replicate this effect using other versions of the regularity lemma. But they are all fairly close to each other. There are also some newer variants; Ishigami has a version based on random sampling, and then there are the infinitary variants of Elek-Szegedy and also of myself (and a forthcoming paper of Austin). There are also ways to use graph and hypergraph limits to avoid the need to explicitly invoke the regularity lemma, as pursued by Lovasz-Szegedy and Borg-Chayes-Lovasz-Sos. For a more direct approach to understanding hypergraph densities there is also the abstract approach of Razborov, again avoiding an explicit use of the regularity lemma.")

#text("So we have sort of an embarrassment of riches here; hopefully there will be some unification and clarity in the near future when the relationships between all these approaches become better understood.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3dcaf18c2ac3f7bb0b4aa37db5adb45112bb7591f93e5023f92bd97cc63dd647-a95bbcc46c327adb352f6136cb179f579b934c971e99c35b490bca98501035a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of NATE")]], [#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/#comment-7397")[#strong[#text("NATE")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2007")])]

#text("how can the parameterization of the growth function help with property testing?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/#comment-7400")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2007")])]

#text("Dear Nate,")

#text("This can come in handy when dealing with a graph or hypergraph property which is equivalent to not having any copies of any forbidden subgraph or subhypergraph in an infinite family. For instance, the property of a graph being bipartite is equivalent to having all odd cycles forbidden. (Let’s stick here to graphs for simplicity.)")

#text("The problem here is that the graphs in the forbidden family can be arbitrarily large; for instance one needs to exclude odd cycles of arbitrarily high length in order to be sure one is bipartite. But if the graph is of a simple form, one can do better. For instance, if a graph has only n vertices, then one only needs to forbid odd cycles of length at most n before one can be confident that one is bipartite. A little more interestingly, if a graph can be partitioned into n cells, such that the graph is either complete or empty between any pair of cells, one again only needs to consider odd cycles of length at most n.")

#text("This fact comes in handy in property testing when combined with the regularity lemma; one first regularises the graph by dividing the vertices into, say, n classes. From the above discussion, we see that for certain graphs associated to these classes, we can test certain properties using only subgraphs of size at most F(n) for some function F that depends on the property. Now, we would like the regularity given by the regularity lemma to be as high a quality as 1/F(n) in order that we can still count subgraphs of this size. With the usual regularity lemma this is unrealistic; we cannot make the regularity of the graph depend on the number of cells (instead, the relationship goes the other way). But with enhanced versions of the regularity lemma (not just mine, but also an earlier regularity lemma of Alon, Fischer, Krivelevich, and Szegedy) one can largely get around this obstacle by choosing the growth function suitably.")

#text("As far as I am aware, this trick was first introduced by Alon and Shapira to show that every monotone graph property is testable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3dcaf18c2ac3f7bb0b4aa37db5adb45112bb7591f93e5023f92bd97cc63dd647-a95bbcc46c327adb352f6136cb179f579b934c971e99c35b490bca98501035a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of NATE")]], [#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/#comment-7634")[#strong[#text("NATE")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2007")])]

#text("Thanks for your replies, they were a big help. I am pretty sure that Ishigami’s version does most of what I want, so that saves me some time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FOCS slides: structure and randomness in combinatorics « What’s new")]], [#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/#comment-12686")[#strong[#text("FOCS slides: structure and randomness in combinatorics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2007")])]

#text("[…] these days in additive combinatorics and graph theory to distinguish structure and randomness. In a previous blog post, I had already mentioned that my lecture notes for this were available on the arXiv; now the slides […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/#comment-33642")[#strong[#text("Decomposition Results and Regularity Lemmas « in theory")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2008")]

#text("[…] Many examples of such results are given in the paper accompanying Terry Tao’s tutorial at FOCS’07. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd68f57ff3316311e88e965a33b5d48226a39141d0efa512fb1597d9a404db51-e5cad63ddce4b47963a0e7b2c038d629915f8e16ce4ed8d69093eff966979960.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fuchs")]], [#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/#comment-38375")[#strong[#text("Fuchs")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("Terence,")

#text("Is your work somewhat related to Ramsey theory?")

#text("Sincerely,")

#text("Fuchs")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An arithmetic regularity lemma, an associated counting lemma, and applications « What’s new")]], [#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/#comment-43604")[#strong[#text("An arithmetic regularity lemma, an associated counting lemma, and applications « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2010")])]

#text("[…] between structure and randomness”, as discussed for instance in my ICM article or FOCS article. In the degree case , this result is essentially due to Green. It is powered by the inverse […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 2: Roth’s theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/#comment-44137")[#strong[#text("254B, Notes 2: Roth’s theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2010")])]

#text("[…] viewed as the graph-theoretic analogue of this Fourier-analytic result; see this paper of mine (or my FOCS paper) for further discussion. The double iteration required to prove Theorem 10 means that the bounds […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 5: The inverse conjecture for the Gowers norm I. The finite field case « What’s new")]], [#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/#comment-45035")[#strong[#text("254B, Notes 5: The inverse conjecture for the Gowers norm I. The finite field case « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2010")])]

#text("[…] a proof, see this paper of mine. The argument is similar to that appearing in Theorem 10 of Notes 2, but the discrete nature of […]")
]
