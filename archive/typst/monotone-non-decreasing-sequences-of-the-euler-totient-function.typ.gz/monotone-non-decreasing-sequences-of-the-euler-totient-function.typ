// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/
// Converted to Typst by tao2typ: "2026-10-14T15:20:56.226334+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Monotone non-decreasing sequences of the Euler totient function", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Monotone non-decreasing sequences of the Euler totient function")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 September 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/")[#text("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I have just uploaded to the arXiv my paper “")#link("https://arxiv.org/abs/2309.02325")[#text("Monotone non-decreasing sequences of the Euler totient function")]#text("“. This paper concerns the quantity ")#mi("{M(x)}")#text(", defined as the length of the longest subsequence of the numbers from ")#mi("{1}")#text(" to ")#mi("{x}")#text(" for which the ")#link("https://en.wikipedia.org/wiki/Euler%27s_totient_function")[#text("Euler totient function")]#text(" ")#mi("{\\varphi}")#text(" is non-decreasing. The first few values of ")#mi("{M}")#text(" are")

#align(center)[#tao-fit-display[#mitex("1, 2, 3, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 11, 12, 12, \\dots")]]

#text("(")#link("https://oeis.org/A365339")[#text("OEIS A365339")]#text("). For instance, ")#mi("{M(6)=5}")#text(" because the totient function is non-decreasing on the set ")#mi("{\\{1,2,3,4,5\\}}")#text(" or ")#mi("{\\{1,2,3,4,6\\}}")#text(", but not on the set ")#mi("{\\{1,2,3,4,5,6\\}}")#text(".")

#text("Since ")#mi("{\\varphi(p)=p-1}")#text(" for any prime ")#mi("{p}")#text(", we have ")#mi("{M(x) \\geq \\pi(x)}")#text(", where ")#mi("{\\pi(x)}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Prime-counting_function")[#text("prime counting function")]#text(". Empirically, the primes come quite close to achieving the maximum length ")#mi("{M(x)}")#text("; indeed it was conjectured ")#link("https://zbmath.org/1348.11003")[#text("by Pollack, Pomerance, and Treviño")]#text(", based on numerical evidence, that one had ")#metadata(none) <tao-a68b412c4282555f1554>#mi("\\displaystyle  M(x) = \\pi(x)+64 \\ \\ \\ \\ \\ (1)")#text(" ")#text(" for all ")#mi("{x \\geq 31957}")#text("; this conjecture is verified up to ")#mi("{x=10^7}")#text(". The previous best known upper bound was basically of the form ")#metadata(none) <tao-0d6e4079e36703ebd37c>#mi("\\displaystyle  M(x) \\leq \\exp( (C+o(1)) (\\log\\log\\log x)^2 ) \\frac{x}{\\log x} \\ \\ \\ \\ \\ (2)")#text(" ")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(" for an explicit constant ")#mi("{C = 0.81781\\dots}")#text(", from combining results from the above paper with that ")#link("https://zbmath.org/0914.11053")[#text("of Ford")]#text(" or ")#link("https://zbmath.org/0638.10045")[#text("of Maier-Pomerance")]#text(". In this paper we obtain the asymptotic")

#align(center)[#tao-fit-display[#mitex("M(x) = \\left( 1 + O \\left(\\frac{(\\log\\log x)^5}{\\log x}\\right) \\right) \\frac{x}{\\log x}")]]

#text("so in particular ")#mi("{M(x) = (1+o(1))\\pi(x)}")#text(". This answers a ")#link("https://zbmath.org/0871.11002")[#text("question of Erdős")]#text(", as well as a closely related question ")#link("https://zbmath.org/1348.11003")[#text("of Pollack, Pomerance, and Treviño")]#text(".")

#text("The methods of proof turn out to be mostly elementary (the most advanced result from analytic number theory we need is the prime number theorem with classical error term). The basic idea is to isolate one key prime factor ")#mi("{p}")#text(" of a given number ")#mi("{1 \\leq n \\leq x}")#text(" which has a sizeable influence on the totient function ")#mi("{\\varphi(n)}")#text(". For instance, for “typical” numbers ")#mi("{n}")#text(", one has a factorization")

#align(center)[#tao-fit-display[#mitex("n = d p_2 p_1")]]

#text("where ")#mi("{p_2}")#text(" is a medium sized prime, ")#mi("{p_1}")#text(" is a significantly larger prime, and ")#mi("{d}")#text(" is a number with all prime factors less than ")#mi("{p_2}")#text(". This leads to an approximation")

#align(center)[#tao-fit-display[#mitex("\\varphi(n) \\approx \\frac{\\varphi(d)}{d} (1-\\frac{1}{p_2}) n.")]]

#text("As a consequence, if we temporarily hold ")#mi("{d}")#text(" fixed, and also localize ")#mi("{n}")#text(" to a relatively short interval, then ")#mi("{\\varphi}")#text(" can only be non-decreasing in ")#mi("{n}")#text(" if ")#mi("{p_2}")#text(" is also non-decreasing at the same time. This turns out to significantly cut down on the possible length of a non-decreasing sequence in this regime, particularly if ")#mi("{p_2}")#text(" is large; this can be formalized by partitioning the range of ")#mi("{p_2}")#text(" into various subintervals and inspecting how this (and the monotonicity hypothesis on ")#mi("{\\varphi}")#text(") constrains the values of ")#mi("{n}")#text(" associated to each subinterval. When ")#mi("{p_2}")#text(" is small, we instead use a factorization")

#metadata(none) <tao-0a2f133eb9f7ca028a20>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("n = d p")]]

#text("where ")#mi("{d}")#text(" is very smooth (i.e., has no large prime factors), and ")#mi("{p}")#text(" is a large prime. Now we have the approximation")

#metadata(none) <tao-3fc7c96a56b6e20ca727>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\varphi(n) \\approx \\frac{\\varphi(d)}{d} n")]]

#text("and we can conclude that ")#mi("{\\frac{\\varphi(d)}{d}}")#text(" will have to basically be piecewise constant in order for ")#mi("{\\varphi}")#text(" to be non-decreasing. Pursuing this analysis more carefully (in particular controlling the size of various exceptional sets in which the above analysis breaks down), we end up achieving the main theorem so long as we can prove the preliminary inequality")

#metadata(none) <tao-5154ed9edd766c720bf7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_{\\frac{\\varphi(d)}{d}=q} \\frac{1}{d} \\leq 1")]]

#text("for all positive rational numbers ")#mi("{q}")#text(". This is in fact also a necessary condition; any failure of this inequality can be easily converted to a counterexample to the bound ")#link(<tao-0d6e4079e36703ebd37c>)[#text("(2)")]#text(", by considering numbers of the form ")#link(<tao-0a2f133eb9f7ca028a20>)[#text("(3)")]#text(" with ")#mi("{\\frac{\\varphi(d)}{d}}")#text(" equal to a fixed constant ")#mi("{q}")#text(" (and omitting a few rare values of ")#mi("{n}")#text(" where the approximation ")#link(<tao-3fc7c96a56b6e20ca727>)[#text("(4)")]#text(" is bad enough that ")#mi("{\\varphi}")#text(" is temporarily decreasing). Fortunately, there is a minor miracle, relating to the fact that the largest prime factor of denominator of ")#mi("{\\frac{\\varphi(d)}{d}}")#text(" in lowest terms necessarily equals the largest prime factor of ")#mi("{d}")#text(", that allows one to evaluate the left-hand side of ")#link(<tao-5154ed9edd766c720bf7>)[#text("(5)")]#text(" almost exactly (this expression either vanishes, or is the product of ")#mi("{\\frac{1}{p-1}}")#text(" for some primes ")#mi("{p}")#text(" ranging up to the largest prime factor of ")#mi("{q}")#text(") that allows one to easily establish ")#link(<tao-5154ed9edd766c720bf7>)[#text("(5)")]#text(". If one were to try to prove an analogue of our main result for the ")#link("https://en.wikipedia.org/wiki/Divisor_function")[#text("sum-of-divisors function")]#text(" ")#mi("{\\sigma(n)}")#text(", one would need the analogue")

#metadata(none) <tao-8dd42f9fc74cd334c8dc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{\\frac{\\sigma(d)}{d}=q} \\frac{1}{d} \\leq 1")]]

#text("of ")#link(<tao-5154ed9edd766c720bf7>)[#text("(5)")]#text(", which looks within reach of current methods (and was even claimed without proof ")#link("https://zbmath.org/0291.10040")[#text("by Erdos")]#text("), but does not have a full proof in the literature at present.")

#text("In the final section of the paper we discuss some near counterexamples to the strong conjecture ")#link(<tao-a68b412c4282555f1554>)[#text("(1)")]#text(" that indicate that it is likely going to be difficult to get close to proving this conjecture without assuming some rather strong hypotheses. Firstly, we show that failure of ")#link("https://en.wikipedia.org/wiki/Legendre%27s_conjecture")[#text("Legendre’s conjecture")]#text(" on the existence of a prime between any two consecutive squares can lead to a counterexample to ")#link(<tao-a68b412c4282555f1554>)[#text("(1)")]#text(". Secondly, we show that failure of the ")#link("https://en.wikipedia.org/wiki/Prime_k-tuple")[#text("Dickson-Hardy-Littlewood conjecture")]#text(" can lead to a separate (and more dramatic) failure of ")#link(<tao-a68b412c4282555f1554>)[#text("(1)")]#text(", in which the primes are no longer the dominant sequence on which the totient function is non-decreasing, but rather the numbers which are a power of two times a prime become the dominant sequence. This suggests that any significant improvement to ")#link(<tao-0d6e4079e36703ebd37c>)[#text("(2)")]#text(" would require assuming something comparable to the prime tuples conjecture, and perhaps also some unproven hypotheses on prime gaps.")

#heading(level: 1)[#text("Comments (23)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681576")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2023")])]

#text("Surely, you need not worry about Legendre’s conjecture failing…")#linebreak()#text(" ")#link("https://qr.ae/pyQWkZ")[#text("https://qr.ae/pyQWkZ")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4c9b301cd1a9e8f3f50a2da225c95aeb109bbfe2e1525e967925fdffc4717b7-fb316f7fc5c88f5da7b88287e0c50ce2d26b006f9516b10b5ffca5df8dfa4f69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681577")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2023")])]

#text("tehory–>theory")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681579")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2023")])]

#text("Is there a similar conjecture non-increasing subsequences?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681590")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2023")])]

#text("While the upper bound methods in my paper apply also to non-increasing sequences, it turns out that there are other arguments that show that they are in fact significantly shorter than the non-decreasing ones. If ")#mi("M^\\downarrow(x)")#text(" denotes the longest length of a non-increasing sequence, and ")#mi("M^0(x)")#text(" denotes the longest length of a constant sequence, then we obviously have ")#mi("M^0(x) \\leq M^\\downarrow(x)")#text(". In the Pollack et al. paper it is speculated that “perhaps” the two quantities are comparable; they establish the lower bound ")#mi("M^0(x) + x^{0.18} \\leq M^\\downarrow(x)")#text(" for large ")#mi("x")#text(" was established, as well as the upper bound")

#mi("\\displaystyle M^\\downarrow(x) \\ll x \\exp(-(\\frac{1}{2}+o(1)) \\sqrt{\\log x \\log\\log x} )")

#text("which is significantly smaller than ")#mi("\\pi(x)")#text(". Also, the best bounds currently on ")#mi("M^0")#text(" are")

#mi("\\displaystyle x^{0.7038} \\ll M^0(x) \\ll x \\exp(-(1+o(1)) \\log x \\log\\log\\log x / \\log\\log x)")

#text("and it is conjectured that the upper bound is sharp.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681591")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2023")])]

#text("What does it mean /log1 (division by zero?) ? Can you maybe provide a reference?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681604")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2023")])]

#text("All bounds stated are for sufficiently large x only. The ")#link("https://zbmath.org/1348.11003")[#text("Pollack et al. paper")]#text(" contains these results and further references.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681592")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2023")])]

#text("Wonderful!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681613")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2023")])]

#text("Are there similar results (or conjectures) for the (more “noisy”) function ")#mi("\\omega(n)")#text(" ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681803")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2023")])]

#text("Thanks Professor Tao, for")#linebreak()#text(" Aug 19, 2023 Analytic prime number theory in the twenty-first century, 8/7/2023, Warsaw – Numbers in the Universe school and conference.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0937c030f22328ab0591a0a68d7e1839bb9f0dbc9ff3724e77d0c38dc1a9a212-117b4929f179599ca57251b28c13d88809f4520a0354839ff42e92f7eb551f94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of woutervandoorn")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681821")[#strong[#text("woutervandoorn")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2023")])]

#text("Small typo on page 17: ‘let k_0 be the unique natural number with log(x) < k \\le 2 log(x)'. The value 'k' should be 'k_0' there.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/485af1105e8999cdee4cecde02e00718b35f121d04ab93dab52d33f5ede4b112-cec3bf40bbf7fa5e8d7d98f5e97814a6a55c81f1bc7c8d7eece5e5d08fcebced.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SZ")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681893")[#strong[#text("SZ")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2023")])]

#text("Dear Prof. Tao:")

#text("Thank you for this wonderful post. I am wondering, what would M(A) be if A is the set of say x^{0.5}-smooth numbers below x? Clearly the {dp} construction no longer works, and I couldn’t come up with a better one easily.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681912")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2023")])]

#text("Hi Professor, I believe I have a proof to (6). Please kindly see ")#link("https://www.dropbox.com/scl/fi/d6jz59s6tiw2txz1nksjk/PlayGround-10.pdf?rlkey=vaaus9eoeqdcgj89p4w9v3mm9&dl=0")[#text("https://www.dropbox.com/scl/fi/d6jz59s6tiw2txz1nksjk/PlayGround-10.pdf?rlkey=vaaus9eoeqdcgj89p4w9v3mm9&dl=0")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681913")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2023")])]

#text("Very nice! If you agree, I can add it as an appendix to the paper (with attribution, of course), or if you wish to put the argument in another venue, I can make a reference to it in the next revision of that paper.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681918")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2023")])]

#text("Congratulations! BTW It’s “a better way” :)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681914")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2023")])]

#text("Thank you so much! You can include it as an appendix if you wish. By the way, my real name is Shengtong Zhang.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681925")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2023")])]

#text("I have added your proof to the last section of the paper, a draft of which is at ")#link("https://terrytao.files.wordpress.com/2023/10/phi-mult.pdf")[#text("https://terrytao.files.wordpress.com/2023/10/phi-mult.pdf")]#text(" . Let me know if you have any changes to suggest or other comments; once the draft is finalized I can update the arXiv copy and also contact the journal with a revision.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681930")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2023")])]

#text("Thanks for the great writeup! I have no comments, except that the \\phi in the first bullet point should be \\varphi.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681932")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2023")])]

#text("OK, I will go ahead and update the arXiv version of the paper and notify the editor handling the journal submission. Thanks for resolving this question!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681933")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2023")])]

#text("Didn’t you prove actually slightly better bound, i.e., instead of <=1, < 1 (or even something like < 0.9773 (=Zeta(2)*Zeta(3)) ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681934")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2023")])]

#text("When d = 1, the bound 1 is tight.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681939")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2023")])]

#text("Ok. I see. It is interesting though, that the bound is sharp only for d = 1, and for all other it is also sharp with (Zeta(2)*Zeta(3) – 1) (at least it seems to me so).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-681944")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2023")])]

#text("Yes, ")#mi("q=1")#text(" is the only case when equality holds, and furthermore a modification of the arguments show that the sum ")#mi("\\sum_{\\sigma(d)/d=q} \\frac{1}{d}")#text(" converges to zero in ")#mi("q")#text(" in the sense that for any ")#mi("\\varepsilon")#text(", one has ")#mi("\\sum_{\\sigma(d)/d=q} \\frac{1}{d} \\leq \\varepsilon")#text(" for all but finitely many ")#mi("q")#text(". (This can in fact be deduced from the dominated convergence theorem (!) once one has the representation ")#mi("\\sum_{\\sigma(d)/d=q} \\frac{1}{d} = \\sum_\\gamma \\frac{1}{\\gamma s_{\\gamma,q}}")#text(".)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63217035ac1e74608f68295bb0dce34e02f12e611295d3042442cb8f95e697a8-27b354a4aaf233a3afaa0e351280ca35809f1e2abef25e1cee80a9ec77d6c565.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mistake-averse lunatic")]], [#link("https://terrytao.wordpress.com/2023/09/06/monotone-non-decreasing-sequences-of-the-euler-totient-function/#comment-682306")[#strong[#text("Mistake-averse lunatic")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2023")])]

#text("I just started to read your paper, because I believe that mathematicians should evaluate each other’s work and not ignore it.")

#text("On p. 6, in the second to last line, I don’t quite see why we shouldn’t have ")#mi("\\gcd(a, p_1 - 1) > 1")#text("; this isn’t necessary to the proof though, because from the first displaystyle identity it follows that ")#mi("p_1")#text(" appears only once in the factorisation of b. In fact, this identity implies that b is a square-free number, and its prime divisors are a subset of those of d.")

#emph[#text("[I don’t believe I claim or use the assertion that ")#mi("\\gcd(a, p_1 = 1) = 1")#text(" in the proof. -T]")]

#text("I also assume that ")#mi("\\mathbb N_{<p_1}")#text(" are numbers whose prime factors are less than p1.")

#emph[#text("[Yes; see the fourth paragraph of page 5. -T]")]

#text("Hopefully, I'll be able to read more of the paper in the future, but due to my university cancelling all my previous credits (for some reason unknown to me), I'll be busy doing very many exercise sheets in the nearer future.")
]
