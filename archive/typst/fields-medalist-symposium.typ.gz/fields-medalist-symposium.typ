// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/04/27/fields-medalist-symposium/
// Converted to Typst by tao2typ: "2026-10-14T15:16:22.352468+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Fields Medalist Symposium", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Fields Medalist Symposium")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 April 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/04/27/fields-medalist-symposium/")[#text("https://terrytao.wordpress.com/2007/04/27/fields-medalist-symposium/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("On Thursday, UCLA hosted a “")#link("http://www.math.ucla.edu/Savethedate.pdf")[#text("Fields Medalist Symposium")]#text("“, in which four of the six University of California-affiliated Fields Medalists (")#link("http://en.wikipedia.org/wiki/Vaughan_Jones")[#text("Vaughan Jones")]#text(" (1990), ")#link("http://en.wikipedia.org/wiki/Efim_Isakovich_Zelmanov")[#text("Efim Zelmanov")]#text(" (1994), ")#link("http://en.wikipedia.org/wiki/Richard_Ewen_Borcherds")[#text("Richard Borcherds")]#text(" (1998), and myself (2006)) gave talks of varying levels of technical sophistication. (The other two are ")#link("http://en.wikipedia.org/wiki/Michael_Freedman")[#text("Michael Freedman")]#text(" (1986) and ")#link("http://en.wikipedia.org/wiki/Stephen_Smale")[#text("Steven Smale")]#text(" (1966), who could not attend.) The slides for my own talks are available ")#link("http://www.math.ucla.edu/~tao/preprints/Slides/fields2.pdf")[#text("here")]#text(".")

#text("The talks were in order of the year in which the medal was awarded: we began with Vaughan, who spoke on “Flatland: a great place to do algebra”, then Efim, who spoke on “Pro-finite groups”, Richard, who spoke on “What is a quantum field theory?”, and myself, on “Nilsequences and the primes.” The audience was quite mixed, ranging from mathematics faculty to undergraduates to alumni to curiosity seekers, and I severely doubt that every audience member understood every talk, but there was something for everyone, and for me personally it was fantastic to see some perspectives from first-class mathematicians on some wonderful areas of mathematics outside of my own fields of expertise.")

#text("Disclaimer: the summaries below are reconstructed from my notes and from some hasty web research; I don’t vouch for 100% accuracy of the mathematical content, and would welcome corrections.")

#metadata(none) <tao-96bd88fa07276d3b20a4>#text(" Vaughan Jones – “Flatland: a great place to do algebra”")

#text("Vaughan gave a very accessible and engaging public lecture, that managed the rare feat of being both non-technical, and yet packing in a surprising amount of meaty mathematics. He began by noting how the Cartesian co-ordinate system of Descartes had demystified the notion of dimension, reducing the two-dimensional plane to collections of pairs of numbers, the three-dimensional space to triplets of numbers, and so forth. Of course, even so, the notion of the “fourth dimension” and beyond still retains a certain almost magical appeal, and Vaughan illustrated this by discussing the classic book “")#link("http://en.wikipedia.org/wiki/Flatland")[#text("Flatland")]#text("” by Edwin Abbott, which mostly revolves around a society of two-dimensional intelligent beings, and the difficulty they have with even conceiving of the third dimension. (As an amusing side note, Vaughan quoted a reviewer of that book from that era approving of Abbott’s higher-dimensional speculations as likely to be more significant than those of his contemporary ")#link("http://en.wikipedia.org/wiki/William_Rowan_Hamilton")[#text("Hamilton")]#text(", who had just invented the ")#link("http://en.wikipedia.org/wiki/Quaternion")[#text("quaternionic number system")]#text(".)")

#text("Vaughan then talked about his own mathematical journey through dimensions, starting out in the infinite-dimensional theory of von Neumann algebras (in particular, in ")#link("http://www.ams.org/mathscinet-getitem?mr=696688")[#text("his celebrated paper")]#text(" developing an index theory for subfactors of von Neumann algebras), and then descending to three dimensions (through his achievements in knot theory) and more recently to two dimensions (through planar algebras). To describe the connections between all these topics, Vaughan first recalled how knots can be obtained from ")#link("http://en.wikipedia.org/wiki/Braid_theory")[#text("braids")]#text(" by tying the ends together; or equivalently, how braids can be viewed as “knots-with-boundary”. This brings group theory into the picture, because braids ")#link("http://en.wikipedia.org/wiki/Braid_group")[#text("form a group")]#text(". He then talked about Louis Kaufmann’s fundamental insight that braids (which can be viewed as a three-dimensional object) can be converted by a simple operation to a planar object (an element of the ")#link("http://en.wikipedia.org/wiki/Temperley-Lieb_algebra")[#text("Temperley-Lieb algebra")]#text(", which had also appeared in Vaughan’s paper on index theory). This led naturally to the more general notion of a ")#link("http://en.wikipedia.org/wiki/Planar_algebra")[#text("planar algebra")]#text(", which can very vaguely be viewed as a two-dimensional version of the more “linear” model of algebra (a sequence of one-input and one-output functions composed together), in which inputs and outputs are connected together by a planar tangle (a collection of non-crossing curves and loops). Other interesting examples of planar algebras included knots with boundary (as ")#link("http://www.ams.org/mathscinet-getitem?mr=258014")[#text("proposed by Conway")]#text(") and tensors (as ")#link("http://www.ams.org/mathscinet-getitem?mr=281657")[#text("proposed by Penrose")]#text("). He then noted how crucial the planarity was in order to obtain a rich algebraic structure; apparently, much of this interesting structure collapses if one allows the components in a tangle to cross each other. (As an analogy, he mentioned how much more rigid and easy a game of ")#link("http://en.wikipedia.org/wiki/Sudoku")[#text("sudoku")]#text(" would be if one worked in ")#mi("{\\Bbb F}_3^4")#text(" and required ")#emph[#text("all")]#text(" coordinate 2-planes (from all six families) to be labeled with some permutation of {1,…,9}, as opposed to just three of the families (the rows, the columns, and the squares, which are also all connected planar objects).)")

#text("To close, Vaughan mentioned how vertex algebra structures also arise naturally in the quantum theory of lattices, and in particular (as ")#link("http://www.ams.org/mathscinet-getitem?mr=1910832")[#text("proposed by Freedman and others")]#text(") could be useful in designing quantum computers. He then noted that the theory of the braid group (including of course the ")#link("http://en.wikipedia.org/wiki/Jones_polynomial")[#text("Jones polynomial")]#text(") could also be viewed as the theory of dynamics of non-colliding points in the plane (by viewing time as a third dimension); quantising this, one then expects braid groups to play a role in the ")#link("http://en.wikipedia.org/wiki/Quantum_Hall_effect")[#text("quantum Hall effect")]#text(" (and its ")#link("http://en.wikipedia.org/wiki/Fractional_Quantum_Hall_Effect")[#text("fractional generalisation")]#text(") that manifests itself at incredibly low temperatures, although despite many breakthroughs in the area, there has not yet been a physical model proposed that would truly be governed by a non-abelian braid group.")

#text("Efim Zelmanov – “Pro-finite groups”")

#text("Efim gave a much more technical, but also very beautiful, talk on some cutting edge research in group theory, revolving around the extent to which a group can be understood from a prescribed set of relations. One seeks to study infinite groups here, but Efim clearly distinguished between the “hopelessly infinite” groups, and the groups which are at least ")#link("http://en.wikipedia.org/wiki/Residually_finite")[#text("residually finite")]#text(" – groups which have enough finite models that one can distinguish points. For instance, the integers ")#mi("{\\Bbb Z}")#text(" are residually finite because given any two distinct integers x, y, one can find a homomorphism ")#mi("{\\Bbb Z} \\to {\\Bbb Z}/N{\\Bbb Z}")#text(" into a finite group which sends x and y to different values. One can then view a residually finite group as a subgroup of an infinite product of finite groups. If this subgroup is topologically complete, we say the group is ")#link("http://en.wikipedia.org/wiki/Pro-finite_group")[#text("pro-finite")]#text("; the ")#link("http://en.wikipedia.org/wiki/P-adic_number")[#text("p-adics")]#text(" are a good example, as are the ")#link("http://en.wikipedia.org/wiki/Galois_group")[#text("Galois groups")]#text(" ")#mi("\\text{Gal}(L/K)")#text(". One can localise these notions to a fixed (rational) prime p (replacing the notion of “finite group” with “finite ")#link("http://en.wikipedia.org/wiki/P-group")[#text("p-group")]#text("“), giving rise to the stricter notions of ")#emph[#text("residually p-finite")]#text(" and ")#emph[#text("pro-p-finite")]#text(" groups. The p-adics are again a good example of a pro-p-finite group. A little less obviously, the free (non-abelian) group ")#mi("F_m")#text(" on m generators is residually p-finite for every p, and has a pro-p-finite completion ")#mi("F := (F_m)_{\\hat p}")#text(". An important “linear” example of a pro-p-finite group comes from the congruence subgroup ")#mi("GL^1(n,\\Lambda)")#text(" of ")#mi("n \\times n")#text(" matrices over a commutative complete ")#link("http://en.wikipedia.org/wiki/Noetherian_ring")[#text("Noetherian ring")]#text(" ")#mi("\\Lambda")#text(" which are trivial when quotiented by a ")#link("http://en.wikipedia.org/wiki/Maximal_ideal")[#text("maximal ideal")]#text(" M whose quotient field is a characteristic p finite field; more generally, we say that a pro-p-finite group is ")#emph[#text("linear")]#text(" if it is isomorphic to a subgroup of such a congruence subgroup.")

#text("The pro-p-completed free group F on m generators is universal, in the sense that every pro-p-group G with m generators can be realised as a quotient of F by the (completed) ideal generated by a collection of relations R. In principle, the relations R describe the group G completely (up to isomorphism, of course), but in practice, even such basic questions as whether G is finite or infinite can be difficult to discern just from the relations R. A fundamental result in this area is the ")#link("http://en.wikipedia.org/wiki/Golod-Shafarevich_theorem")[#text("Golod-Shafarevich theorem")]#text(", which asserts that if there are sufficiently few relations (more precisely, ")#tao-math("\\left|R\\right| < m^2/4", block: false)#text(") and if one makes the technical hypothesis that the relations lie in the p-commutator ")#mi("F^p [F,F]")#text(", then the group is infinite. Groups which obey these hypotheses are known as ")#emph[#text("GS-groups")]#text(". For instance, many Galois groups turn out to be GS-groups and thus infinite, which is an important fact to know in algebraic number theory.")

#text("Another important class of GS groups arise as the fundamental groups ")#mi("\\Gamma = \\pi_1(X)")#text(" of compact hyperbolic 3-manifolds; Lubotzky showed that these are GS groups for all sufficiently large p. An important conjecture in this area is the ")#emph[#text("virtual positive Betti number conjecture")]#text(" (due to Thurston and Waldhausen), which asserts that such groups have a large abelian subquotient, or more precisely there exists a finite index subgroup H which has a surjective image onto ")#mi("{\\Bbb Z}")#text(". This conjecture is backed up by some impressive numerical evidence. Lubotzky and Sarnak observed that if this conjecture was true, it would imply the weaker conjecture that ")#mi("\\Gamma")#text(" does not have ")#link("https://terrytao.wordpress.com/wp-admin/www.ams.org/notices/200506/what-is.pdf")[#text("property ")#mi("\\tau")]#text("; this is now known as the ")#emph[#text("Lubotzky-Sarnak conjecture")]#text(". Recently, Lackenby showed a converse implication (deducing the Betti number conjecture from the Lubotzky-Sarnak conjecture) in the case of arithmetic groups. Efim and Lubotzky then conjectured that the LS conjecture in fact extends to all GS groups, but this was disproven by an explicit counterexample last year by Ershov. So it seems that there is more to these fundamental groups than just the GS property, at least if one believes these conjectures.")

#text("Efim then turned from low-dimensional topology to number theory, and in particular to questions relating to the ")#link("http://www.ams.org/mathscinet-getitem?mr=1363495")[#text("Fontaine-Mazur conjecture")]#text(", which asserts that Galois groups ")#mi("\\text{Gal}({\\Bbb Q}_S/{\\Bbb Q})")#text(" are so “nonlinear” that their image in any ")#mi("GL(n, {\\Bbb Q}_p)")#text(" can have only finite image. A weaker version of this conjecture asserts that such Galois groups are not linear in the sense mentioned earlier. These Galois groups are GS groups, and Efim showed that GS groups contain a copy of the pro-p-finite group F, and so to prove this weaker conjecture it would suffice to show that F is not linear, i.e. that F does not embed injectively into ")#mi("GL^1(n,\\Lambda)")#text(" for any n and ")#mi("\\Lambda")#text(". This was shown by Zubkov when n=2, and very recently Efim verified the conjecture when n is arbitrary and p is sufficiently large depending on n. The question reduces to one of locating universal identities for generic ")#mi("n \\times n")#text(" matrices over the p-adics (since the free group F, by definition, will not obey such identities). To prove this Efim had to generalise the problem to a representation theoretic version and “induct on representations”; I unfortunately didn’t understand this bit too well. As a consequence Efim showed that such universal identities exist, but his argument was non-constructive, so no explicit such identity is known.")

#text("Efim then closed by talking a little more about universal identities; he mentioned the Specht conjecture (proven ")#link("http://www.ams.org/mathscinet-getitem?mr=937115")[#text("by Kemer")]#text(") that over a field of characteristic 0, there are only finitely many universal identities which generate all the others in a syntactical sense (i.e. by the laws of algebra). He then made the interesting remark that there appears to be essentially one and only one technique known to establish finiteness theorems (such as this one) in algebra, namely to appeal to ")#link("http://en.wikipedia.org/wiki/Hilbert's_basis_theorem")[#text("Hilbert’s basis theorem")]#text(" (which asserts that every ideal in a finitely generated commutative ring is itself finitely generated).")

#text("Richard Borcherds – “What is a quantum field theory?”")

#text("Richard is best known for his work in lattices and group theory, most notably in explaining the ")#link("http://en.wikipedia.org/wiki/Monstrous_moonshine")[#text("monstrous moonshine")]#text(" phenomenon, but in recent years he has moved to a completely different area of mathematics, namely mathematical quantum field theory (QFT), which Richard did a very admirable job of explaining. He began by contrasting the very different perspectives of mathematicians and physicists to the subject; from the mathematical side of things, he mentioned the various axiomatic formulations proposed for QFT (")#link("http://en.wikipedia.org/wiki/Wightman_axioms")[#text("Wightman axioms")]#text(", ")#link("http://en.wikipedia.org/wiki/Haag-Kastler")[#text("Haag-Kastler axioms")]#text(", ")#link("http://en.wikipedia.org/wiki/Osterwalder-Schrader_theorem")[#text("Ostewalder-Schrader axioms")]#text(", etc.), but then mentioned the main difficulty with these formulations, namely that none of the major interacting four-dimensional spacetime QFTs (")#link("http://en.wikipedia.org/wiki/Quantum_electrodynamics")[#text("QED")]#text(", ")#link("http://en.wikipedia.org/wiki/Quantum_chromodynamics")[#text("QCD")]#text(", ")#link("http://en.wikipedia.org/wiki/Standard_model_%28basic_details%29")[#text("standard model")]#text(", etc.) are known to obey any of these axioms. (The free QFTs obey the axioms, as well as many two-dimensional and a few three-dimensional ones.) On the physical side, the emphasis is more on computing the ")#link("http://en.wikipedia.org/wiki/Correlation_function_%28quantum_field_theory%29")[#text("Green’s function")]#text(" for a QFT, which formally can be expressed as a ")#link("http://en.wikipedia.org/wiki/Path_integral_formulation")[#text("Feynman path integral")]#text(", which in turn is formally expandable as an infinite sum (essentially a ")#link("http://en.wikipedia.org/wiki/Dyson_series")[#text("Dyson series")]#text(") over ")#link("http://en.wikipedia.org/wiki/Feynman_diagram")[#text("Feynman diagrams")]#text(" of various finite-dimensional integrals; these sums are often horribly divergent, but nevertheless by means of various tricks of varying levels of mathematical rigour, physicists have been able to compute at least the first few terms of these sums and get some predictions which are in extraordinary agreement with experimental data. Most of Richard’s talk was on explaining how the mathematical and physical viewpoints could (hopefully) be reconciled.")

#text("Richard gave us a very interesting and useful “complexity hierarchy” to view the various spaces in both classical and quantum field theory, using things like the ")#link("http://en.wikipedia.org/wiki/Symmetric_algebra")[#text("symmetric algebra construction")]#text(" ")#mi("V \\mapsto S(V)")#text(" to go from one level to the next (thus one can view spaces in level n+1 as consisting of some sort of “polynomials” of objects in a level n space). According to Richard, one of the main reasons why QFT is conceptually difficult is that it routinely uses spaces which are very high up in the hierarchy. For example, in a classical field theory (CFT), ignoring all analytic questions of convergence, differentiability, integrability, etc.,")

#list(
[#text("“Level 0” spaces are finite-dimensional spaces such as the spacetime M, the gauge group G, the principal vector bundle B over M, and so forth. (For instance, in a scalar field theory, G is the real line, and B is just ")#mi("M \\times {\\Bbb R}")#text(".) Classical fields ")#mi("\\phi")#text(" are then just sections of these bundles; for instance, a scalar field is just a map ")#mi("\\phi: M \\to {\\Bbb R}")#text(". The ")#link("http://en.wikipedia.org/wiki/Jet_bundle")[#text("jet bundles")]#text(" of B also qualify as Level 0 spaces.")],
[#text("“Level 1” spaces include things like the space of differential operators on M (or on the bundle B), which can be viewed as polynomials over the “Level 0” vector fields ")#mi("\\partial_i")#text(". For instance, the d’Alembertian ")#mi("\\nabla^\\alpha \\partial_\\alpha")#text(" would belong to this Level 1 space. A little more generally, the ")#link("http://en.wikipedia.org/wiki/Poisson_algebra")[#text("Poisson algebra")]#text(" of a jet bundle is a Level 1 space.")],
[#text("“Level 2” spaces include the space of polynomial combinations of objects from Level 1 spaces applied to a classical field ")#mi("\\phi")#text(". In particular the space ")#mi("{\\mathcal L}")#text(" of ")#link("http://en.wikipedia.org/wiki/Lagrangian")[#text("Lagrangian densities")]#text(", of which ")#mi("L(\\phi) := \\partial^\\alpha \\phi \\partial_\\alpha \\phi + m^2 \\phi^2 + \\lambda^4 \\phi^4")#text(" is a typical example, is a Level 2 object. This is the level where standard explanations of classical field theory usually stop; the theory asserts that classical fields must be critical points for the associated action ")#mi("S(\\phi) := \\int_M L(\\phi)")#text(", and that is an adequate description of the theory. But one can continue onward:")],
[#text("“Level 3” spaces include the Poisson algebra generated by ")#mi("{\\mathcal L}")#text(", which contains such objects as the Poisson bracket ")#mi("\\{ S_1, S_2 \\}")#text(" between two actions. This algebra is implicit in things such as ")#link("http://en.wikipedia.org/wiki/Noether%27s_theorem")[#text("Noether’s theorem")]#text(", but is usually not discussed explicitly. Using the Poisson bracket structure, elements of this Level 3 space can be viewed as “vector fields” or “flows” on the space of all fields in the classical field theory; in particular, infinitesimal symmetries live in a Level 3 space.")],
[#text("“Level 4” spaces include the ")#link("http://en.wikipedia.org/wiki/Universal_enveloping_algebra")[#text("universal enveloping algebra")]#text(" of the previously mentioned Poisson algebra (which is of course a ")#link("http://en.wikipedia.org/wiki/Lie_algebra")[#text("Lie algebra")]#text("). This is where “differential operators” on the space of all fields will live. I think also that ")#link("http://en.wikipedia.org/wiki/Canonical_transformation")[#text("canonical transformations")]#text(" (such as those given by non-infinitesimal symmetries, e.g. spatial translation by a non-zero distance) are also supposed to (formally) lie in a Level 4 space, though I am a bit uncertain on this point.")]
)

#text("So while CFTs mostly top out at Level 2, QFTs seem to really require all levels up to Level 4:")

#list(
[#text("“Level 0” spaces of a QFT are much the same as those of the associated CFT: the spacetime, the bundle, etc. The quantum fields ")#mi("\\phi(x)")#text(" are no longer sections of the bundle, though, but should be interpreted for each x as (nastily singular and unbounded) operators on some abstract Hilbert space (it seems to be unprofitable to try to make this space concrete until much later in the theory). (Incidentally, these quantum fields are ")#emph[#text("not ")]#text("the wave function ")#mi("|\\psi\\rangle")#text(" that one is used to from the ")#link("http://en.wikipedia.org/wiki/Schr%C3%B6dinger_picture")[#text("Schrödinger formulation")]#text(" of non-relativistic quantum mechanics, but instead represent the (spacetime) position operators from the ")#link("http://en.wikipedia.org/wiki/Heisenberg_picture")[#text("Heisenberg formulation")]#text(".)")],
[#text("“Level 1” spaces again include the space of differential operators, but now acting on quantum fields rather than classical fields. (There is of course the usual problem that these operators might be unbounded and thus only be densely defined on the Hilbert space of interest, but there are standard ways to deal with these difficulties.)")],
[#text("“Level 2” spaces again include the space ")#mi("{\\mathcal L}")#text(" of all Lagrangians, are polynomials that convert a quantum field ")#mi("\\phi(x)")#text(" to another (formally) operator-valued function of space time.")],
[#text("“Level 3” spaces include the space of all Feynman path integrals, e.g. ")#mi("\\int \\phi^4(x) \\phi^3(y) e^{i \\int_M L(\\phi)} D\\phi")#text(". In particular they include Green’s functions.")],
[#text("“Level 4” spaces include the space of generalised Wightman distributions, which include things like ")#mi("\\langle \\emptyset | \\phi(f_1) \\ldots \\phi(f_n) | \\emptyset \\rangle")#text(" where ")#mi("|\\emptyset \\rangle")#text(" is the vacuum state and ")#mi("f_1,\\ldots,f_n")#text(" are various bump functions in spacetime, but also include more general objects in which the ")#mi("\\phi(f_1) \\ldots \\phi(f_n)")#text(" factors are replaced by any other time-ordered operators, such as those coming from the Level 3 space. (I admit I didn’t understand this point very well.) Apparently, the space of all renormalisations is also a Level 4 space.")]
)

#text("Richard then talked about the various attempts to build a QFT starting from the Lagrangian as the foundational object. He mentioned Dirac’s philosophy of building the Lie algebra structures first, and only worrying about exactly what the Hilbert space H was at a very late stage of the theory; indeed, trying to apply standard “prequantisation” methods such as proposing ")#mi("L^2(M)")#text(" as the Hilbert space seemed to run into fundamental difficulties (e.g. the action of the center was wrong). There was some fix to this involving the choice of a “polarisation”, but this seemed somewhat ")#emph[#text("ad hoc")]#text(" and didn’t seem to work in all cases (I didn’t follow this bit well). [Incidentally, Richard made a cute observation, which was that the theory becomes a little cleaner notationally when Hilbert spaces were not viewed as complex vector spaces, but rather as complex bimodules, with the complex numbers acting in the usual linear manner on the left but in an antilinear manner on the right, ")#mi("vz = \\overline{z} v")#text(". More generally, operators should act on vectors on the left in the usual manner but on the right by the adjoint operator. This ends up reconciling the “mathematical” and “physical” notation in the subject quite nicely.]")

#text("A more promising approach was to start by computing the Wightman distributions ")#mi("W_n(x_1,\\ldots,x_n) = \\langle \\emptyset | \\phi(x_1) \\ldots \\phi(x_n) | \\emptyset \\rangle")#text(" (which are slight variants of the Green’s function, the differences being technical and having to do with the time-ordering of the spacetime points ")#mi("x_1,\\ldots,x_n")#text("; the two can be related to each other via analytic continuation), and use that to construct the Hilbert space, or at least the portion of the Hilbert space generated from the vacuum state, via the ")#link("http://en.wikipedia.org/wiki/GNS_construction")[#text("GNS construction")]#text(". (There are problems due to ")#mi("\\phi(x)")#text(" being singular, but this can basically be dealt with by the ")#link("http://en.wikipedia.org/wiki/Distribution_%28mathematics%29")[#text("theory of distributions")]#text(".) This approach fits well with the Wightman axiom formulation of QFT mentioned earlier; unfortunately, it is not known how to make all the relevant series converge in order to verify these axioms for any of the physically relevant QFTs. However, one can often proceed ")#emph[#text("perturbatively")]#text(", which can be formalised by replacing the underlying field ")#mi("{\\Bbb C}")#text(" (a field in the mathematical sense, not the physical one!) with the field of formal power series ")#mi("{\\Bbb C}[[\\lambda]]")#text(", where ")#mi("\\lambda")#text(" denotes the (dimensionless) coupling constants of the theory (e.g. the ")#link("http://en.wikipedia.org/wiki/Fine-structure_constant")[#text("fine structure constant")]#text(", which basically represents the charge of the electron) and which show up in the interaction (i.e. non-quadratic) terms of the Lagrangian. There are some significant mathematical problems in working with this perturbative field (in particular, the notion of positivity, or of completeness, has to be carefully redefined) but these are reasonably tractable issues. But even when working perturbatively, the individual terms in the Dyson series used to compute path integrals are usually still divergent. To extract meaningful values for these expressions, physicists employ the twin devices of regularisation and renormalisation. Regularisation introduces a smoothing parameter s to help the integral converge, sending ")#mi("s \\to 0")#text(" at the end of the day; one can either use s to modify the ambient dimension of the spacetime (which is somewhat dubious mathematically, since spacetime is only supposed to have a nonnegative integer number of dimensions rather than complex!), or to strengthen the dissipative and dispersive nature of the Laplacian by raising it to another power (here one is on firmer ground mathematically, thanks to the well established theory of ")#link("http://en.wikipedia.org/wiki/Pseudo-differential_operator")[#text("pseudo-differential operators")]#text("). However, even when one regularises, the terms still blow up in the limit ")#mi("s \\to 0")#text(" if the parameters ")#mi("\\lambda")#text(" are kept fixed. However, one can renormalise away this issue by redefining ")#mi("\\lambda")#text(" to be a certain meromorphic function of s, in such a way that a finite limit can now be extracted. This means that ")#mi("\\lambda")#text(" goes to infinity as s goes to zero; for instance in QED, this is the assertion that the electron actually has an infinite “bare” charge but a finite “effective” charge. There can be multiple choices of renormalisation, but there are transformations which convert one to the other (I didn’t understand this point well). There is also some way to view renormalisations as some sort of coproduct-preserving homomorphism from the Level 3 space of all Green’s function-type objects to itself, but I was a little lost by this point.")

#text("Richard closed by giving an “executive summary” of QFT as being the unitary representation theory of a certain “Level 4” space (some sort of Lie algebra, I think) which incorporated the Lagrangian, the ")#link("http://http://en.wikipedia.org/wiki/Poincar%C3%A9_group")[#text("Poincaré group")]#text(", and the complex structure (but quotiented somehow by the constraint of locality); all of these ingredients are basically mandated by the Wightman axioms.")

#text("Terence Tao – “Nilsequences and the primes”")

#text("Here I gave a more detailed presentation of the material I had discussed in my ")#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/")[#text("first Simons lecture")]#text(", and focussing a bit more on the role of nilflows in characterising the “structure” or “conspiracies” which seem to control the additive behaviour of primes, as arising with my work with ")#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(", and also on the very recent connections between this work and ")#link("http://www.ams.org/mathscinet-getitem?mr=1403920")[#text("Ratner’s theorem")]#text(". My slides are available ")#link("http://www.math.ucla.edu/~tao/preprints/Slides/fields2.pdf")[#text("here")]#text(".")

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b12a9b8a7454dad1a36b38a28fdf6f94736f05a76d730f0cdb5209a8c8a35ed-f1207ae3196631b9435e0061df517e34c8040ccd2f087f4e1eb0c13502912e7e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2007/04/27/fields-medalist-symposium/#comment-717")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2007")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Richard is best known for his work in lattices and group theory, most notably in explaining the monstrous moonshine phenomenon, but in recent years he has moved to a completely different area of mathematics, namely mathematical quantum field theory (QFT)")
]

#text("Is monstrous moonshine really a completely different area? I was under the impression that vertex operators, infinite dimensional Grassmannians, and generalized Kac-Moody algebras arise naturally in conformal field theories, which are a baby version of QFT’s proper. Indeed, as far as I am aware Borcherd’s proof crucially relied on the no-ghost theorem from perturbative string theory.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/27/fields-medalist-symposium/#comment-718")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2007")])]

#text("Well, it’s outside my field, so I can’t really say, though Richard did tell me yesterday that he considers himself as having moved away from moonshine quite a bit, but perhaps this is only in regard to the focus of study, rather than the mathematical technology employed. He did list vertex algebras and Verma modules of affine Kac-Moody algebras as examples of “Level 2” objects, though, in his talk. (Verma modules of plain old Lie algebras are merely “Level 1” objects.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/04/27/fields-medalist-symposium/#comment-723")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2007")])]

#text("The symposium sounds very interesting, but it reminds of a quip that I made at a workshop that I attended not long ago. The workshop had an informal lunch buffet — I’m not sure that they even bothered with tablecloths — and a group of us had picked a particular table. I think that one Fields Medalist at the workshop (who shall remain nameless) was to eat with us. But he lost track of that and sat down with the other Fields Medalist at the workshop (who shall also remain nameless) at another table. So I said to the rest of the lunch party, “If it were only ")#strong[#text("one")]#text(" Fields Medalist, we could still ask him to come sit with us. But since it’s ")#strong[#text("two")]#text(" Fields Medalists, I think that we’re outvoted.” :-)")

#text("Anyway, to address the math question, yes, I believe that vertex operator algebras are intended as a axiomatization of a simplified part of conformal field theory. One of the simplifications is to restrict to CFT on a sphere with marked points, instead of surfaces with higher genus. Monstrous moonshine is an example CFT which is constructed with a certain amount of symmetry (that of the Leech lattice) but is revealed to have more symmetry (that of the monster group). It’s not my area either, but I think that this is a fair summary of what I have been told.")

#text("However, there is a great variety of quantum field theories in the world, so that you can easily move far away from any one set of examples and still do quantum field theory.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/27/fields-medalist-symposium/#comment-739")[#strong[#text("Not Even Wrong » Blog Archive » Various Events and Other News")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2007")]

#text("[…] the Fields Medalist blogging front, there’s a report from Terry Tao about a symposium at UCLA where he and three other Fields medalists gave talks. He gives a detailed […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yi-Zhi Huang")]], [#link("https://terrytao.wordpress.com/2007/04/27/fields-medalist-symposium/#comment-759")[#strong[#text("Yi-Zhi Huang")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2007")])]

#text("Vertex operator algebras are the algebras of meromorphic")#linebreak()#text(" quantum fields on the sphere. Rartional conformal field")#linebreak()#text(" theories on the sphere and on the torus have now been")#linebreak()#text(" constructed mathematically using the representation theory")#linebreak()#text(" of vertex operator algebras. The higher-genus case")#linebreak()#text(" might be a little tedious but no fundamental difficulties")#linebreak()#text(" are expected. Indeed, in this construction, the Hilbert space")#linebreak()#text(" structure is the last step. Actually one can introduce the")#linebreak()#text(" Hilbert space structure using a suitable inner product")#linebreak()#text(" from the beginning but it is not very useful.")#linebreak()#text(" What we need is a nice dense subspace of the Hilbert")#linebreak()#text(" space constructed from representations of the vertex operartor")#linebreak()#text(" algebra such that correlation functions on Riemann surfaces")#linebreak()#text(" associated to elements of this dense subspace")#linebreak()#text(" can be constructed. Then in the last step, one can use these")#linebreak()#text(" correlation functions to give a topological completion")#linebreak()#text(" (not the inner product completion) of")#linebreak()#text(" the dense subspace and show that this completion is the")#linebreak()#text(" same as the inner product completion.")

#text("Now it is clear why the direct use of the Hilbert space might be")#linebreak()#text(" difficult: We can look at the construction of the Hilbert")#linebreak()#text(" space using correlation functions. These correlation functions")#linebreak()#text(" involve higher genus Riemann surface structure, but from the")#linebreak()#text(" Hilbert space structure obtained from")#linebreak()#text(" the inner product completion, we do not see anything")#linebreak()#text(" about Riemann surfaces.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad1c023b28d8126e69bad719e6213ce96b3e5d70732d8589f0e86c0080440bfa-84ac88cffd9f3d903376bd16fac53ab8df57f1e98258e26fcdc539df32e99f38.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of stevenm")]], [#link("https://terrytao.wordpress.com/2007/04/27/fields-medalist-symposium/#comment-762")[#strong[#text("stevenm")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2007")])]

#text("Thanks for taking the time to provide summaries of these interesting talks. In Jones’ talk you mention he discusses the braid group and the Jones polynomial within the context of describing the dynamics of non-colliding points in the plane. I am wondering if he was referring to ‘vicious walkers’, which are Brownian motions or random walkers not allowed to intersect or which can annihilate when they meet. The probability densities for these types of random walks (for N particles) can be related to the partition function of a Chern-Simons theory on the 3-manifold ")#mi("S^{3}")#text(" with gauge group U(N). As regards the Jones polynomial and QFT, a beautiful and quite famous result that should perhaps be mentioned here is that of Witten who demonstrated that the Jones polynomial has a")#linebreak()#text(" representation in terms of a topological quantum field theory, namely an non-abelian SU(2) Chern-Simons theory on a 3-manifold. In a sense, this result would also seem to be bridge between the talks of Jones and that of Borcherds on QFT. The problem mathematicians have with this construction of the Jones is the usual lack of a rigorous definition of the Feynman path integral measure, although for once the path integral here can actually be performed exactly.")

#text("I always find it particularly fascinating when fields that at first seem unrelated turn out to have these tantalizing connections: the Jones connects with von Neumann algebras, statistical mechanics, braids etc. as you mentioned, but also with 3-dimensional topological quantum field theory. In molecular biology the Jones polynomial–and its generalisations like the HOMFLY polynomial, derivable from the SU(N) Chern-Simons–are also a potentially useful and powerful tool in classifying and identifying knotted states and topological properties of dna, polymers and enzymes; essentially ‘biological strings’. But an SU(N) Chern-Simons theory can also be related to topological string theory in the large N limit. A lot of fascinating things and connections going on here. Incidently, did Borcherd mention anything about the hard problems of actually defining QFTs on 4-manifolds, specifically the Yang-Mills gauge theory, which of course is a Clay problem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/27/fields-medalist-symposium/#comment-788")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2007")])]

#text("Dear Stevenm,")

#text("Thanks for the interesting comments. Vaughan didn’t mention any sort of random walks in his talk, but given that these things already show up in classical stochastic field theories I am not surprised that some version of them also shows up in QFTs. As for the 4-dim QFTs, the sense I got from Richard was that the algebraic issues (working in the perturbative regime of formal power series) are reasonably well understood and on a fairly solid foundation, but all the analytic issues remain extremely difficult. (As an analogy, one can easily construct “global” “solutions” to the Navier-Stokes equation from analytic initial data by a formal power series expansion (e.g. using Cauchy-Kowaleski), but without any convergence result on such formal power series, this formal power series sheds no light on the global regularity problem.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Carnahan")]], [#link("https://terrytao.wordpress.com/2007/04/27/fields-medalist-symposium/#comment-817")[#strong[#text("Scott Carnahan")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2007")])]

#text("I’m not an expert on renormalization, but my impression was that there is a space of Lagrangians, a space of renormalization prescriptions (basically perturbative Feynman path integral measures), and a way to combine a Lagrangian with a renormalization prescription to get a “quantum field theory”, which is a family of Green’s functions or generalized Wightman distributions. The group of renormalizations is some infinite dimensional nonabelian nilpotent group that acts on both spaces (changing coupling constants, counterterms, etc), in a way that the resulting quantum field theory is fixed. Finite dimensional orbits of this action on Lagrangians are called renormalizable.")

#text("I think Witten proposed the mass gap problem as a Clay prize problem in part because of its very nonperturbative nature. He has mentioned in some articles that there is both theoretical and computational evidence that the mass gap is exponentially damped as coupling constants are taken to zero. Since perturbative expanions are basically calculating in a formal neighborhood of zero, it sounds like they would be quite useless for this problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/27/fields-medalist-symposium/#comment-2011")[#strong[#text("Infinite Reflections » Blog Archive » Terry Tao’s Career Advice and Prime Number Colloqium …")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2007")]

#text("[…] A more technical talk is his Nilsequences and the primes – (The lack of) hidden patterns in the prime numbers [Fields Medalists Symposium- April 26, 2007 with Ben Green (Cambridge)] – [via his blog here […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/27/fields-medalist-symposium/#comment-2473")[#strong[#text("Machine Learning (Theory) » How is Compressed Sensing going to change Machine Learning ?")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2007")]

#text("[…] Tao, the recent Fields medalist, does a very nice job at explaining the framework here. He goes further in the theory description […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/04/27/fields-medalist-symposium/#comment-39773")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2009")])]

#text("Dear Prof. Tao,")

#text("I am wondering who decides to give Fields Medal to whom?")

#text("is there a fix committe, does it change each year?")

#text("if someone is working on statistics, do you think that it is possible to get Fields medals?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d16748755f72f2245cf7d76271ef24bf6211a05587775c0018440e64692942fe-cab85b756ce58d92eeb39033c3652949ff38e82fa28fde4dde4b74c0ef6d2d55.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert")]], [#link("https://terrytao.wordpress.com/2007/04/27/fields-medalist-symposium/#comment-47021")[#strong[#text("Robert")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text("Nice article as always (I myself am interested in the mathematics of quantum field theory).")

#text("Small typographical correction: it’s “d’Alembertian” not “d’Lambertian”. Indeed, d’ followed by a consonant makes no sense. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bec7d73c838f5b3fa23fc134f88b1366784e10b57788f084b1ab7961cb699278-11bb865a81476800179b77f9c0c0e018db1176676b514a7f839b4b5202520a08.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of galoisrepresentations")]], [#link("https://terrytao.wordpress.com/2007/04/27/fields-medalist-symposium/#comment-233893")[#strong[#text("galoisrepresentations")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("Dear Terry, In your discussion of the Zelmanov’s talk, it’s probably important to define ")#mi("\\mathbf{Q}_S")#text(": it is the maximal Galois extension of the rationals which is unramified away from a finite set of primes ")#mi("S")#text(". Moreover, one only expects that the image of this group in a p-adic linear group will have finite image when the set ")#mi("S")#text(" ")#emph[#text("does not")]#text(" contain the prime ")#mi("p")#text(". The “usual” Fontaine-Mazur conjecture allows ")#mi("p")#text(" to be in ")#mi("S")#text(", in which case there are many interesting infinite image linear representations (for example, coming from the Tate modules of Elliptic curves, or from the cyclotomic character on the ")#mi("p^{\\infty}")#text(" roots of unity).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/04/27/fields-medalist-symposium/#comment-519040")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("Wow! The works and awards of Prof. T. Tao are extraordinary!")

#text("Link: ")#link("https://en.wikipedia.org/wiki/Terence_Tao")[#text("https://en.wikipedia.org/wiki/Terence_Tao")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/04/27/fields-medalist-symposium/#comment-519093")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2019")])]

#text("The journey is over, and this is a final goodbye.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/04/27/fields-medalist-symposium/#comment-520106")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2019")])]

#text("Oops! The journey is not over… And my math work is not done. And I am still learning from Prof. T. Tao.")
]
]
]
