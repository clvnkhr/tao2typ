// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/
// Converted to Typst by tao2typ: "2026-10-14T15:18:18.464883+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254B, Notes 2: Cayley graphs and Kazhdan’s property (T)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254B, Notes 2: Cayley graphs and Kazhdan’s property (T)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 December 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/")[#text("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In ")#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/")[#text("the previous set of notes")]#text(" we introduced the notion of expansion in arbitrary ")#mi("{k}")#text("-regular graphs. For the rest of the course, we will now focus attention primarily to a special type of ")#mi("{k}")#text("-regular graph, namely a ")#link("http://en.wikipedia.org/wiki/Cayley_graph")[#text("Cayley graph")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Cayley graph)")]#text(" Let ")#mi("{G = (G,\\cdot)}")#text(" be a group, and let ")#mi("{S}")#text(" be a finite subset of ")#mi("{G}")#text(". We assume that ")#mi("{S}")#text(" is symmetric (thus ")#mi("{s^{-1} \\in S}")#text(" whenever ")#mi("{s \\in S}")#text(") and does not contain the identity ")#mi("{1}")#text(" (this is to avoid loops). Then the (right-invariant) ")#emph[#text("Cayley graph")]#text(" ")#mi("{Cay(G,S)}")#text(" is defined to be the graph with vertex set ")#mi("{G}")#text(" and edge set ")#mi("{\\{ \\{sx,x\\}: x \\in G, s \\in S \\}}")#text(", thus each vertex ")#mi("{x \\in G}")#text(" is connected to the ")#tao-math("{\\left|S\\right|}", block: false)#text(" elements ")#mi("{sx}")#text(" for ")#mi("{s \\in S}")#text(", and so ")#mi("{Cay(G,S)}")#text(" is a ")#tao-math("{\\left|S\\right|}", block: false)#text("-regular graph.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" The graph in Exercise 3 of ")#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/")[#text("Notes 1")]#text(" is the Cayley graph on ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" with generators ")#mi("{S = \\{-1,+1\\}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" We call the above Cayley graphs right-invariant because every right translation ")#mi("{x\\mapsto xg}")#text(" on ")#mi("{G}")#text(" is a graph automorphism of ")#mi("{Cay(G,S)}")#text(". This group of automorphisms acts transitively on the vertex set of the Cayley graph. One can thus view a Cayley graph as a ")#link("http://en.wikipedia.org/wiki/Homogenous_space")[#text("homogeneous space")]#text(" of ")#mi("{G}")#text(", as it “looks the same” from every vertex. One could of course also consider ")#emph[#text("left-invariant Cayley graphs")]#text(", in which ")#mi("{x}")#text(" is connected to ")#mi("{xs}")#text(" rather than ")#mi("{sx}")#text(". However, the two such graphs are isomorphic using the inverse map ")#mi("{x \\mapsto x^{-1}}")#text(", so we may without loss of generality restrict our attention throughout to left Cayley graphs.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" For minor technical reasons, it will be convenient later on to allow ")#mi("{S}")#text(" to contain the identity and to come with multiplicity (i.e. it will be a multiset rather than a set). If one does so, of course, the resulting Cayley graph will now contain some loops and multiple edges.")#linebreak()#text(" For the purposes of building expander families, we would of course want the underlying group ")#mi("{G}")#text(" to be finite. However, it will be convenient at various times to “lift” a finite Cayley graph up to an infinite one, and so we permit ")#mi("{G}")#text(" to be infinite in our definition of a Cayley graph.")
]

#text("We will also sometimes consider a generalisation of a Cayley graph, known as a ")#link("http://en.wikipedia.org/wiki/Schreier_coset_graph")[#text("Schreier graph")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 5 (Schreier graph)")]#text(" Let ")#mi("{G}")#text(" be a finite group that ")#link("http://en.wikipedia.org/wiki/Group_action")[#text("acts")]#text(" (on the left) on a space ")#mi("{X}")#text(", thus there is a map ")#mi("{(g,x) \\mapsto gx}")#text(" from ")#mi("{G \\times X}")#text(" to ")#mi("{X}")#text(" such that ")#mi("{1x = x}")#text(" and ")#mi("{(gh)x = g(hx)}")#text(" for all ")#mi("{g,h \\in G}")#text(" and ")#mi("{x \\in X}")#text(". Let ")#mi("{S}")#text(" be a symmetric subset of ")#mi("{G}")#text(" which acts freely on ")#mi("{X}")#text(" in the sense that ")#mi("{sx \\neq x}")#text(" for all ")#mi("{s \\in S}")#text(" and ")#mi("{x \\in X}")#text(", and ")#mi("{sx \\neq s^{\\prime}x}")#text(" for all distinct ")#mi("{s,s^{\\prime} \\in S}")#text(" and ")#mi("{x \\in X}")#text(". Then the ")#emph[#text("Schreier graph")]#text(" ")#mi("{Sch(X,S)}")#text(" is defined to be the graph with vertex set ")#mi("{X}")#text(" and edge set ")#mi("{\\{ \\{sx,x\\}: x \\in X, s \\in S \\}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 6")]#text(" Every Cayley graph ")#mi("{Cay(G,S)}")#text(" is also a Schreier graph ")#mi("{Sch(G,S)}")#text(", using the obvious left-action of ")#mi("{G}")#text(" on itself. The ")#mi("{k}")#text("-regular graphs formed from ")#mi("{l}")#text(" permutations ")#mi("{\\pi_1,\\ldots,\\pi_l \\in S_n}")#text(" that were studied in the ")#link("https://terrytao.wordpress.com/2011/12/02/245b-notes-1-basic-theory-of-expander-graphs/")[#text("previous set of notes")]#text(" is also a Schreier graph provided that ")#mi("{\\pi_i(v) \\neq v, \\pi_i^{-1}(v), \\pi_j(v)}")#text(" for all distinct ")#mi("{1 \\leq i,j \\leq l}")#text(", with the underlying group being the permutation group ")#mi("{S_n}")#text(" (which acts on the vertex set ")#mi("{X = \\{1,\\ldots,n\\}}")#text(" in the obvious manner), and ")#mi("{S := \\{\\pi_1,\\ldots,\\pi_l,\\pi_1^{-1},\\ldots,\\pi_l^{-1}\\}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" If ")#mi("{k}")#text(" is an even integer, show that every ")#mi("{k}")#text("-regular graph is a Schreier graph involving a set ")#mi("{S}")#text(" of generators of cardinality ")#mi("{k/2}")#text(". (")#emph[#text("Hint:")]#text(" you may assume without proof Petersen’s ")#link("https://en.wikipedia.org/wiki/2-factor_theorem")[#text("2-factor theorem")]#text(", which asserts that every ")#mi("{k}")#text("-regular graph with ")#mi("{k}")#text(" even can be decomposed into ")#mi("{k/2}")#text(" edge-disjoint ")#mi("{2}")#text("-regular graphs. Now use the previous example.)")
]

#text("We return now to Cayley graphs. It is easy to characterise qualitative expansion properties of Cayley graphs:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8 (Qualitative expansion)")]#text(" Let ")#mi("{Cay(G,S)}")#text(" be a finite Cayley graph.")

#list(
[#text("(i) Show that ")#mi("{Cay(G,S)}")#text(" is a one-sided ")#mi("{\\varepsilon}")#text("-expander for ")#mi("{G}")#text(" for some ")#mi("{\\varepsilon>0}")#text(" if and only if ")#mi("{S}")#text(" generates ")#mi("{G}")#text(".")],
[#text("(ii) Show that ")#mi("{Cay(G,S)}")#text(" is a two-sided ")#mi("{\\varepsilon}")#text("-expander for ")#mi("{G}")#text(" for some ")#mi("{\\varepsilon>0}")#text(" if and only if ")#mi("{S}")#text(" generates ")#mi("{G}")#text(", and furthermore ")#mi("{S}")#text(" intersects each index ")#mi("{2}")#text(" subgroup of ")#mi("{G}")#text(".")]
)
]

#text("We will however be interested in more quantitative expansion properties, in which the expansion constant ")#mi("{\\varepsilon}")#text(" is independent of the size of the Cayley graph, so that one can construct non-trivial expander families ")#mi("{Cay(G_n,S_n)}")#text(" of Cayley graphs.")#linebreak()#text(" One can analyse the expansion of Cayley graphs in a number of ways. For instance, by taking the edge expansion viewpoint, one can study Cayley graphs combinatorially, using the product set operation")

#align(center)[#tao-fit-display[#mitex("A \\cdot B := \\{ab: a \\in A, b \\in B \\}")]]

#text("of subsets of ")#mi("{G}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9 (Combinatorial description of expansion)")]#text(" Let ")#mi("{Cay(G_n,S_n)}")#text(" be a family of finite ")#mi("{k}")#text("-regular Cayley graphs. Show that ")#mi("{Cay(G_n,S_n)}")#text(" is a one-sided expander family if and only if there is a constant ")#mi("{c>0}")#text(" independent of ")#mi("{n}")#text(" such that ")#tao-math("{\\left|E_n \\cup E_n S_n\\right| \\geq (1+c) \\left|E_n\\right|}", block: false)#text(" for all sufficiently large ")#mi("{n}")#text(" and all subsets ")#mi("{E_n}")#text(" of ")#mi("{G_n}")#text(" with ")#tao-math("{\\left|E_n\\right| \\leq \\left|G_n\\right|/2}", block: false)#text(".")
]

#text("One can also give a combinatorial description of two-sided expansion, but it is more complicated and we will not use it here.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Abelian groups do not expand)")]#text(" Let ")#mi("{Cay(G_n,S_n)}")#text(" be a family of finite ")#mi("{k}")#text("-regular Cayley graphs, with the ")#mi("{G_n}")#text(" all abelian, and the ")#mi("{S_n}")#text(" generating ")#mi("{G_n}")#text(". Show that ")#mi("{Cay(G_n,S_n)}")#text(" are a one-sided expander family if and only if the Cayley graphs have bounded cardinality (i.e. ")#tao-math("{\\sup_n \\left|G_n\\right| < \\infty}", block: false)#text("). (")#emph[#text("Hint:")]#text(" assume for contradiction that ")#mi("{Cay(G_n,S_n)}")#text(" is a one-sided expander family with ")#tao-math("{\\left|G_n\\right| \\rightarrow \\infty}", block: false)#text(", and show by two different arguments that ")#tao-math("{\\sup_n \\left|S_n^m\\right|}", block: false)#text(" grows at least exponentially in ")#mi("{m}")#text(" and also at most polynomially in ")#mi("{m}")#text(", giving the desired contradiction.)")
]

#text("The left-invariant nature of Cayley graphs also suggests that such graphs can be profitably analysed using some sort of Fourier analysis; as the underlying symmetry group is not necessarily abelian, one should use the Fourier analysis of non-abelian groups, which is better known as (unitary) ")#link("http://en.wikipedia.org/wiki/Representation_theory")[#text("representation theory")]#text(". The Fourier-analytic nature of Cayley graphs can be highlighted by recalling the operation of ")#link("http://en.wikipedia.org/wiki/Convolution")[#text("convolution")]#text(" of two functions ")#mi("{f, g \\in \\ell^2(G)}")#text(", defined by the formula")

#align(center)[#tao-fit-display[#mitex("f * g(x) := \\sum_{y \\in G} f(y) g(y^{-1} x) = \\sum_{y \\in G} f(x y^{-1}) g(y).")]]

#text("This convolution operation is bilinear and associative (at least when one imposes a suitable decay condition on the functions, such as compact support), but is not commutative unless ")#mi("{G}")#text(" is abelian. (If one is more algebraically minded, one can also identify ")#mi("{\\ell^2(G)}")#text(" (when ")#mi("{G}")#text(" is finite, at least) with the ")#link("http://en.wikipedia.org/wiki/Group_algebra")[#text("group algebra")]#text(" ")#mi("{{\\bf C} G}")#text(", in which case convolution is simply the multiplication operation in this algebra.) The adjacency operator ")#mi("{A}")#text(" on a Cayley graph ")#mi("{Cay(G,S)}")#text(" can then be viewed as a convolution")

#align(center)[#tao-fit-display[#tao-math("Af = \\left|S\\right| \\mu * f,", block: true)]]

#text("where ")#mi("{\\mu}")#text(" is the probability density ")#metadata(none) <tao-57a9f4551db259cdadd4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\mu := \\frac{1}{\\left|S\\right|} \\sum_{s \\in S} \\delta_s", block: true)]]

#text("where ")#mi("{\\delta_s}")#text(" is the Kronecker delta function on ")#mi("{s}")#text(". Using the spectral definition of expansion, we thus see that ")#mi("{Cay(G,S)}")#text(" is a one-sided expander if and only if ")#metadata(none) <tao-4ae0b1a25d38b8d84255>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\langle f, \\mu*f \\rangle \\leq (1-\\varepsilon) \\left\\|f\\right\\|_{\\ell^2(G)}^2", block: true)]]

#text("whenever ")#mi("{f \\in \\ell^2(G)}")#text(" is orthogonal to the constant function ")#mi("{1}")#text(", and is a two-sided expander if ")#metadata(none) <tao-fc1f4829c0fcdf00d3b5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\| \\mu*f \\right\\|_{\\ell^2(G)} \\leq (1-\\varepsilon) \\left\\|f\\right\\|_{\\ell^2(G)}", block: true)]]

#text("whenever ")#mi("{f \\in \\ell^2(G)}")#text(" is orthogonal to the constant function ")#mi("{1}")#text(".")#linebreak()#text(" We remark that the above spectral definition of expansion can be easily extended to symmetric sets ")#mi("{S}")#text(" which contain the identity or have multiplicity (i.e. are multisets). (We retain symmetry, though, in order to keep the operation of convolution by ")#mi("{\\mu}")#text(" self-adjoint.) In particular, one can say (with some slight abuse of notation) that a set of elements ")#mi("{s_1,\\ldots,s_l}")#text(" of ")#mi("{G}")#text(" (possibly with repetition, and possibly with some elements equalling the identity) generates a one-sided or two-sided ")#mi("{\\varepsilon}")#text("-expander if the associated symmetric probability density")

#align(center)[#tao-fit-display[#mitex("\\mu := \\frac{1}{2l} \\sum_{i=1}^l \\delta_{s_i} + \\delta_{s_i^{-1}}")]]

#text("obeys either ")#link(<tao-4ae0b1a25d38b8d84255>)[#text("(2)")]#text(" or ")#link(<tao-fc1f4829c0fcdf00d3b5>)[#text("(3)")]#text(".")#linebreak()#text(" We saw in the last set of notes that expansion can be characterised in terms of random walks. One can of course specialise this characterisation to the Cayley graph case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11 (Random walk description of expansion)")]#text(" Let ")#mi("{Cay(G_n,S_n)}")#text(" be a family of finite ")#mi("{k}")#text("-regular Cayley graphs, and let ")#mi("{\\mu_n}")#text(" be the associated probability density functions. Let ")#mi("{A > 1/2}")#text(" be a constant.")

#list(
[#text("Show that the ")#mi("{Cay(G_n,S_n)}")#text(" are a two-sided expander family if and only if there exists a ")#mi("{C>0}")#text(" such that for all sufficiently large ")#mi("{n}")#text(", one has ")#tao-math("{\\left\\| \\mu_n^{*m} - \\frac{1}{\\left|G_n\\right|} \\right\\|_{\\ell^2(G_n)} \\leq \\frac{1}{\\left|G_n\\right|^A}}", block: false)#text(" for some ")#tao-math("{m \\leq C \\log \\left|G_n\\right|}", block: false)#text(", where ")#mi("{\\mu_n^{*m} := \\mu_n * \\ldots * \\mu_n}")#text(" denotes the convolution of ")#mi("{m}")#text(" copies of ")#mi("{\\mu_n}")#text(".")],
[#text("Show that the ")#mi("{Cay(G_n,S_n)}")#text(" are a one-sided expander family if and only if there exists a ")#mi("{C>0}")#text(" such that for all sufficiently large ")#mi("{n}")#text(", one has ")#tao-math("{\\left\\| (\\frac{1}{2} \\delta_1 + \\frac{1}{2} \\mu_n)^{*m} - \\frac{1}{\\left|G_n\\right|} \\right\\|_{\\ell^2(G_n)} \\leq \\frac{1}{\\left|G_n\\right|^A}}", block: false)#text(" for some ")#tao-math("{m \\leq C \\log \\left|G_n\\right|}", block: false)#text(".")]
)
]

#text("In this set of notes, we will connect expansion of Cayley graphs to an important property of certain infinite groups, known as ")#link("http://en.wikipedia.org/wiki/Kazhdan%27s_property_(T)")[#text("Kazhdan’s property (T)")]#text(" (or property (T) for short). In 1973, ")#link("http://www.ams.org/mathscinet-getitem?mr=484767")[#text("Margulis exploited this property")]#text(" to create the first known ")#emph[#text("explicit")]#text(" and deterministic examples of expanding Cayley graphs. As it turns out, property (T) is somewhat overpowered for this purpose; in particular, we now know that there are many families of Cayley graphs for which the associated infinite group does not obey property (T) (or weaker variants of this property, such as property ")#mi("{\\tau}")#text("). In later notes we will therefore turn to other methods of creating Cayley graphs that do not rely on property (T). Nevertheless, property (T) is of substantial intrinsic interest, and also has many connections to other parts of mathematics than the theory of expander graphs, so it is worth spending some time to discuss it here.")#linebreak()#text(" The material here is based in part on ")#link("http://www.ams.org/mathscinet-getitem?mr=2415834")[#text("this recent text on property (T) by Bekka, de la Harpe, and Valette")]#text(" (available online ")#link("http://perso.univ-rennes1.fr/bachir.bekka/KazhdanTotal.pdf")[#text("here")]#text(").")#linebreak()#text(" ")#metadata(none) <tao-c0291c21a36897fb7e3f>

#heading(level: 1)[#strong[#text(" — 1. Kazhdan’s property (T) — ")]]

#text("Kazhdan’s property (T) is a representation-theoretic property of groups. Although we will primarily be interested in finite groups (such as ")#mi("{SL_d({\\bf Z}/p{\\bf Z})}")#text("), or at least discrete, finitely generated groups (such as ")#mi("{SL_d({\\bf Z})}")#text("), it will be convenient to work in the more general category of ")#text("locally compact groups")#text(" which includes discrete finitely generated groups, but also Lie groups (such as ")#mi("{SL_d({\\bf R})}")#text(") as examples. (Locally compact groups were studied extensively in ")#link("https://terrytao.wordpress.com/category/teaching/254a-hilberts-fifth-problem/")[#text("last quarter’s course")]#text(", but we will not need the theory of those groups from that course here.) For minor technical reasons we will restrict attention to locally compact groups ")#mi("{G}")#text(" that are Hausdorff, second countable, and compactly generated (so that there is a compact set ")#mi("{S}")#text(" that generates ")#mi("{G}")#text(" as a group, as is for instance the case for discrete finitely generated groups). We shall therefore abuse notation and abbreviate “locally compact second countable Hausdorff compactly generated group” as “locally compact group”. One can extend the study of property (T) to more general classes of groups than these, but this class will be sufficient for our applications while avoiding some technical subtleties that are not relevant for our purposes.")#linebreak()#text(" We will focus on a particular type of representation of locally compact groups, namely a unitary representation.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 12 (Unitary representation)")]#text(" Let ")#mi("{G}")#text(" be a locally compact group. A ")#emph[#text("unitary representation")]#text(" (or ")#emph[#text("representation")]#text(", for short) of ")#mi("{G}")#text(" is a (complex) ")#link("http://en.wikipedia.org/wiki/Separable_space")[#text("separable")]#text(" Hilbert space ")#mi("{H}")#text(" (possibly infinite dimensional), together with a homomorphism ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" from ")#mi("{G}")#text(" to the group ")#mi("{U(H)}")#text(" of unitary transformations on ")#mi("{H}")#text(". Furthermore, we require ")#mi("{\\rho}")#text(" to be continuous, where we give ")#mi("{U(H)}")#text(" the ")#link("http://en.wikipedia.org/wiki/Strong_operator_topology")[#text("strong operator topology")]#text(". We often abuse notation and refer to ")#mi("{\\rho}")#text(" (rather than the pair ")#mi("{(\\rho,H)}")#text(") as the representation of ")#mi("{G}")#text(".")#linebreak()#text(" Two unitary representations ")#mi("{\\rho: G \\rightarrow U(H)}")#text(", ")#mi("{\\rho^{\\prime}: G \\rightarrow U(H^{\\prime})}")#text(" are ")#emph[#text("isomorphic")]#text(" if there is a Hilbert space isomorphism ")#mi("{\\phi: H \\rightarrow H^{\\prime}}")#text(" such that ")#mi("{\\rho^{\\prime}(g) \\circ \\phi = \\phi \\circ \\rho(g)}")#text(" for all ")#mi("{g \\in G}")#text(". When one has such an isomorphism, we write ")#mi("{\\rho \\equiv \\rho^{\\prime}}")#text(".")
]

#text("Note that if ")#mi("{G}")#text(" is a discrete group, then the continuity hypothesis is automatic and can be omitted. One could easily turn the space of unitary representations of a fixed group ")#mi("{G}")#text(" into a ")#link("http://en.wikipedia.org/wiki/Category_theory")[#text("category")]#text(" by defining the notion of a morphism between two unitary representations that generalises the notion of an isomorphism given above (basically by replacing “Hilbert space isomorphism” with “Hilbert space isometry”), but we will not need to do so here. One could also consider inseparable Hilbert space representations, but for minor technical reasons it will be convenient to restrict attention to the separable case. (Note that ")#mi("{G}")#text(", being second countable, is separable, and so any orbit ")#mi("{\\{ gv: g \\in G \\}}")#text(" of a vector ")#mi("{v}")#text(" in a Hilbert space is automatically contained in a separable subspace. As such, one can usually restrict without loss of generality to separable Hilbert spaces in applications.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 13 (Trivial representation)")]#text(" Any locally compact group ")#mi("{G}")#text(" acts trivially on any Hilbert space ")#mi("{H}")#text(" by defining ")#mi("{\\rho(g)}")#text(" to be the identity on ")#mi("{H}")#text(" for all ")#mi("{g \\in G}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 14 (Regular representation)")]#text(" If ")#mi("{G}")#text(" is a discrete group, then we have the (left) ")#link("http://en.wikipedia.org/wiki/Regular_representation")[#text("regular representation")]#text(" ")#mi("{\\tau: G \\rightarrow U(\\ell^2(G))}")#text(" of ")#mi("{G}")#text(", in which the Hilbert space is ")#mi("{\\ell^2(G)}")#text(", and the action is given by the formula")

#align(center)[#tao-fit-display[#mitex("\\tau(g) f(x) := f(g^{-1} x) = \\delta_g * f(x)")]]

#text("for ")#mi("{g \\in G}")#text(" and ")#mi("{x \\in G}")#text(". (Note that the ")#mi("{g^{-1}}")#text(" here is needed to make ")#mi("{\\tau}")#text(" a homomorphism.) This is easily verified to be a unitary representation. One can also consider the right-regular representation that takes ")#mi("{f(x)}")#text(" to ")#mi("{f(xg)}")#text(", but this is easily seen to be isomorphic to the left-regular representation and will not be needed here.")#linebreak()#text(" More generally, if ")#mi("{G}")#text(" is a locally compact group equipped with a left-invariant ")#link("http://en.wikipedia.org/wiki/Haar_measure")[#text("Haar measure")]#text(" ")#mi("{\\mu}")#text(", one can define the (left) regular representation ")#mi("{\\tau}")#text(" on ")#mi("{L^2(G,d\\mu)}")#text(" by setting ")#mi("{\\tau(g) f(x) := f(g^{-1} x)}")#text(" for all ")#mi("{f \\in L^2(G,d\\mu)}")#text(". (Note that ")#mi("{L^2(G,d\\mu)}")#text(" will be separable because we are assuming ")#mi("{G}")#text(" to be second countable.) For a review of the theory of Haar measure (and in particular, a proof that any locally compact group has a Haar measure, unique up to scalar multiplication), see ")#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/")[#text("this previous blog post of mine")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 15 (Quasiregular representation)")]#text(" If ")#mi("{(X,\\mu)}")#text(" is a measure space that ")#mi("{G}")#text(" acts on in a transitive measure-preserving fashion, then we have the (left) ")#link("http://en.wikipedia.org/wiki/Quasiregular_representation")[#text("quasiregular representation")]#text(" ")#mi("{\\tau_{X}: G \\rightarrow U(L^2(X,\\mu))}")#text(", in which the Hilbert spac is ")#mi("{L^2(X,\\mu)}")#text(", and the action is given by the formula")

#align(center)[#tao-fit-display[#mitex("\\tau_{X}(g) f(x) := f(g^{-1} x)")]]

#text("for ")#mi("{g \\in G}")#text(" and ")#mi("{x \\in X}")#text(". Of course, the regular representation can be viewed as a special case of a quasiregular representation, as can the one-dimensional trivial representation.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 16 (Direct sum)")]#text(" If ")#mi("{\\rho_1: G \\rightarrow U(H_1)}")#text(" and ")#mi("{\\rho_2: G \\rightarrow U(H_2)}")#text(" are unitary representations of a locally compact group ")#mi("{G}")#text(", then their ")#link("http://en.wikipedia.org/wiki/Direct_sum")[#text("direct sum")]#text(" ")#mi("{\\rho_1 \\oplus \\rho_2: G \\rightarrow U(H_1 \\oplus H_2)}")#text(" is also a unitary representation, where ")#mi("{H_1 \\oplus H_2}")#text(" is the Hilbert space of all formal sums ")#mi("{v_1 \\oplus v_2}")#text(" with ")#mi("{v_1 \\in H_1}")#text(" and ")#mi("{v_2 \\in H_2}")#text(" with the inner product")

#align(center)[#tao-fit-display[#mitex("\\langle v_1 \\oplus v_2, w_1 \\oplus w_2 \\rangle_{H_1 \\oplus H_2} := \\langle v_1,w_1 \\rangle_{H_1} + \\langle v_2,w_2\\rangle_{H_2}")]]

#text("and the representation ")#mi("{\\rho_1 \\oplus \\rho_2}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#mitex("(\\rho_1 \\oplus \\rho_2)(g) (v_1 \\oplus v_2) := (\\rho_1(g) v_1) \\oplus (\\rho_2(g) v_2).")]]

#text("One can also form the direct sum of finitely many or even countably many unitary representations in a similar manner; we leave the details to the reader. (There is also a construction to combine uncountably many such representations, known as the ")#link("http://en.wikipedia.org/wiki/Direct_integral")[#text("direct integral")]#text(", but we will not need it here.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 17 (Subrepresentation)")]#text(" If ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" is a unitary representation of a locally compact group ")#mi("{G}")#text(", and ")#mi("{H^{\\prime}}")#text(" is a closed subspace of ")#mi("{H}")#text(" which is ")#mi("{G}")#text("-invariant (thus ")#mi("{\\rho(g) H^{\\prime} \\subset H^{\\prime}}")#text(" for all ")#mi("{g \\in G}")#text("), then we can form the restriction ")#mi("{\\rho\\downharpoonright_{H^{\\prime}}: G \\rightarrow U(H^{\\prime})}")#text(" of ")#mi("{\\rho}")#text(" to ")#mi("{H^{\\prime}}")#text(", defined by setting ")#mi("{\\rho\\downharpoonright_{H^{\\prime}}(g) v := \\rho(g) v}")#text(" for all ")#mi("{g \\in G}")#text(" and ")#mi("{v \\in H^{\\prime}}")#text(". This is easily seen to also be a unitary representation, and is known as a ")#emph[#text("subrepresentation")]#text(" of ")#mi("{\\rho}")#text(". By unitarity, we see that the orthogonal complement ")#mi("{(H^{\\prime})^\\perp}")#text(" of ")#mi("{H^{\\prime}}")#text(" in ")#mi("{H}")#text(" is an invariant space, leading to the complementary subrepresentation ")#mi("{\\rho\\downharpoonright_{(H^{\\prime})^\\perp}}")#text(". One easily verifies the isomorphism")

#align(center)[#tao-fit-display[#mitex("\\rho \\equiv \\rho\\downharpoonright_{H^{\\prime}} \\oplus \\rho\\downharpoonright_{(H^{\\prime})^\\perp}.")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 18 (Invariant vectors)")]#text(" If ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" is a unitary representation of a locally compact group ")#mi("{G}")#text(", then the space ")#mi("{H^G := \\{ v \\in H: \\rho(g) v = v \\text{ for all } g \\in G \\}}")#text(" of ")#mi("{G}")#text("-invariant vectors in ")#mi("{H}")#text(" is a closed invariant subspace of ")#mi("{H}")#text(". By the preceding example, we thus have the decomposition")

#align(center)[#tao-fit-display[#mitex("\\rho \\equiv \\rho\\downharpoonright_{H^G} \\oplus \\rho\\downharpoonright_{(H^G)^\\perp}")]]

#text("into a trivial representation ")#mi("{\\rho\\downharpoonright_{H^G}}")#text(", and a representation ")#mi("{\\rho\\downharpoonright_{(H^G)^\\perp}}")#text(" with no non-trivial invariant vectors. (Indeed, this is the only such decomposition up to isomorphism; we leave this as an exercise to the reader.) For instance, if ")#mi("{G}")#text(" is a finite group and we consider the regular representation ")#mi("{\\tau}")#text(" (so ")#mi("{H = \\ell^2(G)}")#text("), then ")#mi("{H^G}")#text(" is the one-dimensional space of constants ")#mi("{{\\bf C}}")#text(", while ")#mi("{(H^G)^\\perp}")#text(" is the space ")#mi("{\\ell^2(G)_0}")#text(" of functions of mean zero, so we have the decomposition")

#align(center)[#tao-fit-display[#mitex("\\tau \\equiv {\\bf C} \\oplus \\tau\\downharpoonright_{\\ell^2(G)_0}.")]]

#text("Note that if ")#mi("{G}")#text(" is an ")#emph[#text("infinite")]#text(" discrete group, then there are already no non-trivial invariant vectors in ")#mi("{\\ell^2(G)}")#text(" (why?), so the decomposition in this case is trivial:")

#align(center)[#tao-fit-display[#mitex("\\tau \\equiv 0 \\oplus \\tau\\downharpoonright_{\\ell^2(G)}.")]]
]

#text("We now make a key definition of a ")#emph[#text("Kazhdan constant")]#text(", which is analogous to the expansion constant of a Cayley graph.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 19 (Kazhdan constant)")]#text(" Let ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" be a unitary representation of a locally compact group ")#mi("{G}")#text(", and let ")#mi("{S}")#text(" be a compact subset of ")#mi("{G}")#text(". The ")#emph[#text("Kazhdan constant")]#text(" ")#mi("{Kaz(G,S,\\rho)}")#text(" of ")#mi("{S}")#text(" and ")#mi("{\\rho}")#text(" is then the supremum of all the constants ")#mi("{\\varepsilon \\geq 0}")#text(" for which one has the bound")

#align(center)[#tao-fit-display[#tao-math("\\sup_{s \\in S} \\left\\| \\rho(s) v - v \\right\\|_H \\geq \\varepsilon \\left\\|v\\right\\|_H", block: true)]]

#text("for all ")#mi("{v \\in H}")#text(". Thus, for instance, ")#mi("{Kaz(G,S,\\rho)}")#text(" vanishes whenever the representation ")#mi("{\\rho}")#text(" contains non-trivial invariant vectors. The Kazhdan constant ")#mi("{Kaz(G,S)}")#text(" of ")#mi("{S}")#text(" is defined as")

#align(center)[#tao-fit-display[#mitex("Kaz(G,S) := \\inf_\\rho Kaz(G,S,\\rho),")]]

#text("where ")#mi("{\\rho}")#text(" ranges over all unitary representations of ")#mi("{G}")#text(" with no non-trivial invariant vectors. A group ")#mi("{G}")#text(" is said to have ")#emph[#text("Kazhdan property (T)")]#text(" if one has ")#mi("{Kaz(G,S) > 0}")#text(" for at least one compact set ")#mi("{S}")#text(".")
]

#text("Thus, if ")#mi("{G}")#text(" has Kazhdan property (T), then one can find at least one compact set ")#mi("{S}")#text(" and some ")#mi("{\\varepsilon>0}")#text(" with the property that for every representation unitary ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" with no non-trivial invariant vectors, and every ")#mi("{v \\in H}")#text(", one can find ")#mi("{s \\in S}")#text(" such that ")#tao-math("{\\left\\| \\rho(s) v - v \\right\\|_H \\geq \\varepsilon \\left\\|v\\right\\|_H}", block: false)#text(". Thus, we have a dichotomy: either a representation contains invariant vectors, or every vector in the representation is moved by a non-trivial amount by some “small” element of ")#mi("{G}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 20")]#text(" Later on in these notes, we will show that ")#mi("{SL_d({\\bf Z})}")#text(" and ")#mi("{SL_d({\\bf R})}")#text(" have property (T) if and only if ")#mi("{d \\geq 3}")#text(". We will also see that a free non-abelian group ")#mi("{F_k}")#text(" on ")#mi("{k}")#text(" generators will never have property (T), and also no finitely generated infinite abelian group will have property (T).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Show that every finite group ")#mi("{G}")#text(" has property (T). (")#emph[#text("Hint:")]#text(" first show that every vector ")#mi("{v}")#text(" in a unitary representation is contained in a subrepresentation of dimension at most ")#tao-math("{\\left|G\\right|}", block: false)#text(", and that all the unitary maps ")#mi("{\\rho(g)}")#text(" have order at most ")#tao-math("{\\left|G\\right|}", block: false)#text(".) Later on, we shall establish the stronger statement that every ")#emph[#text("compact")]#text(" group has property (T).")
]

#text("We record some basic properties of the Kazhdan constants:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" ")#metadata(none) <tao-55bd3a5913e5a3450179>#text(" Let ")#mi("{G}")#text(" be a locally compact group, let ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" be a representation, and let ")#mi("{S, S^{\\prime}}")#text(" be compact subsets of ")#mi("{G}")#text(".")

#list(
[#text("(i) If ")#mi("{S \\subset S^{\\prime}}")#text(", then ")#mi("{Kaz(G,S,\\rho) \\leq Kaz(G,S^{\\prime},\\rho)}")#text(" and ")#mi("{Kaz(G,S) \\leq Kaz(G,S^{\\prime})}")#text(".")],
[#text("(ii) One has ")#mi("{Kaz(G,S,\\rho) = Kaz(G,S^{-1},\\rho) = Kaz(G,S \\cup S^{-1},\\rho)}")#text(" and ")#mi("{Kaz(G,S) = Kaz(G,S^{-1}) = Kaz(G,S \\cup S^{-1})}")#text(".")],
[#text("(iii) One has ")#mi("{Kaz(G,S,\\rho) = Kaz(G,S \\cup \\{1\\},\\rho)}")#text(" and ")#mi("{Kaz(G,S) = Kaz(G,S \\cup \\{1\\})}")#text(".")],
[#text("(iv) One has ")#mi("{Kaz(G,S^m,\\rho) \\leq m Kaz(G,S,\\rho)}")#text(" and ")#mi("{Kaz(G,S^m) \\leq m Kaz(G,S)}")#text(" for all ")#mi("{m \\geq 1}")#text(".")],
[#text("(v) If ")#mi("{S}")#text(" generates ")#mi("{G}")#text(" as a group (thus every element of ")#mi("{G}")#text(" is a finite word in ")#mi("{S}")#text("), show that ")#mi("{G}")#text(" has Kazhdan property (T) if and only if ")#mi("{Kaz(G,S) > 0}")#text(".")]
)
]

#text("From the above exercise, we see that the precise choice of compact set ")#mi("{S}")#text(" needed to establish the Kazhdan property is not important, so long as that it generates the group (and by hypothesis, every locally compact group ")#mi("{G}")#text(" has at least one compact generating set ")#mi("{S}")#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 23")]#text(" ")#metadata(none) <tao-a083e941775650d739e6>#text(" In our conventions, we are only considering locally compact groups that are compactly generated. However, in some applications it is important to note that the compact generation hypothesis is in fact automatic if one has Kazhdan’s property (T). Indeed, if ")#mi("{Kaz(G,S) > 0}")#text(" for some compact ")#mi("{S}")#text(" (which we may assume without loss of generality to be a neighbourhood of the identity), and ")#mi("{G^{\\prime}}")#text(" is the (necessarily open) subgroup of ")#mi("{G}")#text(" generated by ")#mi("{S}")#text(", then the Dirac delta ")#mi("{\\delta_1}")#text(" in the Hilbert space ")#mi("{\\ell^2(G/G^{\\prime})}")#text(" is ")#mi("{G^{\\prime}}")#text("-invariant and thus (by the hypothesis ")#mi("{Kaz(G,S)>0}")#text(") ")#mi("{\\ell^2(G/G^{\\prime})}")#text(" has a ")#mi("{G}")#text("-invariant vector, which forces ")#mi("{G/G^{\\prime}}")#text(" to be finite, and so ")#mi("{G}")#text(" is compactly generated.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" ")#metadata(none) <tao-659ea97863b0ca57a42c>#text(" Let ")#mi("{G}")#text(" be a locally compact group, let ")#mi("{S}")#text(" be a compact subset of ")#mi("{G}")#text(". Show that the following assertions are equivalent:")

#list(
[#text("(i) ")#mi("{Kaz(G,S)=0}")#text(".")],
[#text("(ii) There exists a unitary representation ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" with no non-trivial invariant vectors such that ")#mi("{Kaz(G,S,\\rho)=0}")#text(".")]
)

#text("(")#emph[#text("Hint:")]#text(" If ")#mi("{Kaz(G,S)=0}")#text(", take a sequence of unitary representations of ")#mi("{G}")#text(" with no non-trivial invariant vectors but a sequence of increasingly ")#mi("{S}")#text("-approximately-invariant vectors, and form their (infinite) direct sum.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" ")#metadata(none) <tao-683a62ce15fbabb1ac86>#text(" Let ")#mi("{G}")#text(" be a locally compact group, let ")#mi("{S}")#text(" be a compact subset of ")#mi("{G}")#text(", and let ")#mi("{\\varepsilon>0}")#text(". Show that the following assertions are equivalent:")

#list(
[#text("(i) ")#mi("{Kaz(G,S) \\geq \\varepsilon}")#text(".")],
[#text("(ii) For any unitary representation ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" (possibly containing invariant vectors), and any ")#mi("{v \\in H}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\text{dist}(v, H^G) \\leq \\frac{1}{\\varepsilon} \\sup_{s \\in S} \\left\\| \\rho(s) v - v \\right\\|_H.", block: true)]]]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" Let ")#mi("{G}")#text(" be a locally compact group. Show that exactly one of the following is true:")

#list(
[#text("(i) ")#mi("{G}")#text(" has property (T).")],
[#text("(ii) There exists a sequence ")#mi("{\\rho_n: G \\rightarrow U(H_n)}")#text(" of representations and a sequence of unit vectors ")#mi("{v_n \\in H_n}")#text(" such that ")#tao-math("{\\left\\| sv_n -v_n \\right\\|_{H_n} \\rightarrow 0}", block: false)#text(" for all ")#mi("{s \\in G}")#text(", but such that each of the ")#mi("{H_n}")#text(" contains no non-trivial invariant vectors.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 27")]#text(" Informally, the statement in (ii) of the preceding exercise shows that one can reach the trivial representation as a “limit” of a sequence of representations with no non-trivial invariant vectors. As such, property (T) can be viewed as the assertion that the trivial representation ")#mi("{T}")#text(" is isolated from the other representations in some sense, which is the origin for the term “property (T)”. This intuition can be formalised by introducing ")#emph[#text("Fell’s topology")]#text(" on unitary representations; see ")#link("http://perso.univ-rennes1.fr/bachir.bekka/KazhdanTotal.pdf")[#text("the text of Bekka, de la Harpe, and Valette")]#text(" for details.")
]

#text("Now we show why Kazhdan constants are related to expansion in Cayley graphs.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" Let ")#mi("{Cay(G,S)}")#text(" be a finite ")#mi("{k}")#text("-regular Cayley graph, and let ")#mi("{\\varepsilon>0}")#text(". Let ")#mi("{\\rho = \\tau\\downharpoonright_{\\ell^2(G)_0}}")#text(" be the restriction of the regular representation of ")#mi("{G}")#text(" to the functions of mean zero.")

#list(
[#text("(i) If ")#mi("{Kaz(G,S,\\rho) \\geq \\varepsilon}")#text(", show that ")#mi("{Cay(G,S)}")#text(" is a one-sided ")#mi("{c}")#text("-expander for some ")#mi("{c = c(\\varepsilon,k) > 0}")#text(".")],
[#text("(ii) Conversely, if ")#mi("{Cay(G,S)}")#text(" is a one-sided ")#mi("{\\varepsilon}")#text("-expander, show that ")#mi("{Kaz(G,S,\\rho) \\geq c}")#text(" for some ")#mi("{c = c(\\varepsilon,k) > 0}")#text(".")]
)

#text("(")#emph[#text("Hint:")]#text(" Use the triangle inequality and the cosine rule: if ")#mi("{v, w}")#text(" are unit vectors with ")#tao-math("{\\left\\|v-w\\right\\|_H^2 = 2 - \\langle v, w \\rangle_H}", block: false)#text(".)")
]

#text("Thus, to show that a sequence ")#mi("{Cay(G_n,S_n)}")#text(" of ")#mi("{k}")#text("-regular Cayley graphs form a one-sided expander family, it suffices to obtain a lower bound on the Kazhdan constants ")#mi("{Kaz(G_n,S_n,\\rho_n)}")#text(". There is a similar criterion for two-sided expansion:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29")]#text(" Let ")#mi("{Cay(G,S)}")#text(" be a finite ")#mi("{k}")#text("-regular Cayley graph, and let ")#mi("{\\varepsilon>0}")#text(". Let ")#mi("{\\rho = \\tau\\downharpoonright_{\\ell^2(G)_0}}")#text(" be the restriction of the regular representation of ")#mi("{G}")#text(" to the functions of mean zero.")

#list(
[#text("(i) If ")#mi("{Kaz(G,S^2,\\rho) \\geq \\varepsilon}")#text(", show that ")#mi("{Cay(G,S)}")#text(" is a two-sided ")#mi("{c}")#text("-expander for some ")#mi("{c = c(\\varepsilon,k) > 0}")#text(".")],
[#text("(ii) Conversely, if ")#mi("{Cay(G,S)}")#text(" is a two-sided ")#mi("{\\varepsilon}")#text("-expander, show that ")#mi("{Kaz(G,S^2,\\rho) \\geq c}")#text(" for some ")#mi("{c = c(\\varepsilon,k) > 0}")#text(".")]
)
]

#text("One advantage of working with Kazhdan constants instead of expansion constants is that they behave well with respect to homomorphisms:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30")]#text(" ")#metadata(none) <tao-09cac9faa8125bc85d26>#text(" Let ")#mi("{G, G^{\\prime}}")#text(" be locally compact groups, and suppose that there is a continuous surjective homomorphism ")#mi("{\\pi: G \\rightarrow G^{\\prime}}")#text(" from ")#mi("{G}")#text(" to ")#mi("{G^{\\prime}}")#text(". Let ")#mi("{S}")#text(" be a compact subset of ")#mi("{G}")#text(". Show that for any unitary representation ")#mi("{\\rho^{\\prime}: G^{\\prime} \\rightarrow U(H)}")#text(" of ")#mi("{G^{\\prime}}")#text(", one has ")#mi("{Kaz(G^{\\prime},\\pi(S),\\rho^{\\prime}) = Kaz(G,S,\\rho^{\\prime} \\circ \\pi)}")#text(". Conclude that ")#mi("{Kaz(G^{\\prime},\\pi(S)) \\geq Kaz(G,S)}")#text(". In particular, if ")#mi("{G}")#text(" has property (T), then ")#mi("{G^{\\prime}}")#text(" does also.")
]

#text("As a corollary of the above results, we can use Kazhdan’s property (T) to generate expander families:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31")]#text(" ")#metadata(none) <tao-00fc5bdeb4eca3605a41>#text(" Let ")#mi("{G}")#text(" be a finitely generated discrete group, and let ")#mi("{S}")#text(" be a symmetric subset of ")#mi("{G}")#text(" that generates ")#mi("{G}")#text(". Let ")#mi("{N_n}")#text(" be a sequence of finite index normal subgroups of ")#mi("{G}")#text(", and let ")#mi("{\\pi_n: G \\rightarrow G/N_n}")#text(" be the quotient maps. Suppose that for all sufficiently large ")#mi("{n}")#text(", ")#mi("{\\pi_n}")#text(" is injective on ")#mi("{S \\cup \\{1\\}}")#text(". Show that if ")#mi("{G}")#text(" has property (T), then ")#mi("{Cay(G/N_n, \\pi_n(S))}")#text(" for sufficiently large ")#mi("{n}")#text(" is an expander family.")
]

#text("It is thus of interest to find ways to demonstrate property (T), or in other words to create invariant vectors from almost invariant vectors. The next few exercises will develop some tools for this purpose.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32")]#text(" ")#metadata(none) <tao-cac729832e48d8a3b24a>#text(" Let ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" be a unitary representation of a locally compact group ")#mi("{G}")#text(". Suppose that there is a closed convex set ")#mi("{K}")#text(" in ")#mi("{H}")#text(" that contains an orbit ")#mi("{\\{ gv_0: g \\in G \\}}")#text(" of some element ")#mi("{v_0}")#text(" in ")#mi("{K}")#text(". Show that ")#mi("{K}")#text(" contains an invariant vector. (")#emph[#text("Hint:")]#text(" Show that the set ")#mi("{K^{\\prime} := \\{ v \\in H: gv \\in K \\text{ for all } g \\in G \\}}")#text(" is closed, convex, and ")#mi("{G}")#text("-invariant; now study an element of ")#mi("{K^{\\prime}}")#text(" of minimal norm.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" Show that every compact group has property (T). (")#emph[#text("Hint:")]#text(" use Exercise ")#link(<tao-cac729832e48d8a3b24a>)[#text("32")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34 (Direct products and property (T))")]#text(" Let ")#mi("{G, G^{\\prime}}")#text(" be locally compact groups. Show that the product group ")#mi("{G \\times G^{\\prime}}")#text(" (with the product topology, of course) has property (T) if and only if ")#mi("{G}")#text(" and ")#mi("{G^{\\prime}}")#text(" both separately have property (T). (")#emph[#text("Hint:")]#text(" one direction follows from Exercise ")#link(<tao-09cac9faa8125bc85d26>)[#text("30")]#text(". To obtain the other direction, start with an approximately invariant vector ")#mi("{v}")#text(" for ")#mi("{G \\times G^{\\prime}}")#text(" and use Exercise ")#link(<tao-683a62ce15fbabb1ac86>)[#text("25")]#text(" (and Exercise ")#link(<tao-55bd3a5913e5a3450179>)[#text("22")]#text("(v)) to show that the ")#mi("{G \\times G^{\\prime}}")#text("-orbit of ")#mi("{v}")#text(" stays close to ")#mi("{v}")#text(", then use Exercise ")#link(<tao-cac729832e48d8a3b24a>)[#text("32")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35 (Short exact sequences and property (T))")]#text(" Let ")#mi("{G}")#text(" be a locally compact group, and let ")#mi("{N}")#text(" be a closed normal subgroup of ")#mi("{G}")#text("; then ")#mi("{N}")#text(" and ")#mi("{G/N}")#text(" are also locally compact. Show that if ")#mi("{N}")#text(" and ")#mi("{G/N}")#text(" have property (T), then ")#mi("{G}")#text(" also has property (T).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36")]#text(" Let ")#mi("{G}")#text(" be an infinite discrete finitely generated group, generated by a finite set ")#mi("{S}")#text(". Show that the following assertions are equivalent:")

#list(
[#text("(i) There exists a sequence ")#mi("{F_n}")#text(" of finite non-empty subsets in ")#mi("{G}")#text(" with the property that ")#tao-math("{\\left|sF_n \\Delta F_n\\right|/\\left|F_n\\right| \\rightarrow 0}", block: false)#text(" as ")#mi("{n \\rightarrow \\infty}")#text(" for each ")#mi("{s \\in S}")#text(". (Such a sequence of sets is known as a ")#link("http://en.wikipedia.org/wiki/F%C3%B8lner_sequence")[#text("Folner sequence")]#text(" for ")#mi("{G}")#text(".)")],
[#text("(ii) One has ")#mi("{Kaz(G,S,\\tau) = 0}")#text(", where ")#mi("{\\tau}")#text(" is the regular representation of ")#mi("{G}")#text(".")]
)

#text("(")#emph[#text("Hint:")]#text(" you may wish to mimic the proof of the weak discrete Cheeger inequality.)")
]

#text("Infinite, finitely generated groups ")#mi("{G}")#text(" with property (i) or (ii) of the above exercise are known as ")#link("http://en.wikipedia.org/wiki/Amenable_group")[#text("amenable groups")]#text("; amenability is an important property in ergodic theory, operator algebras, and many other areas of mathematics, but will not be discussed extensively in this course. The notion of amenability can also be extended to other locally compact groups, but we again will not discuss these matters here. From the above exercise, we see that an infinite amenable finitely generated group cannot have property (T). The next example shows, though, that it is also possible for non-amenable groups (such as the ")#link("http://en.wikipedia.org/wiki/Free_group")[#text("free group")]#text(" on two or more generators) to not have property (T).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37")]#text(" ")#metadata(none) <tao-7653097b0a56851e687b>

#list(
[#text("(i) Show that the integers ")#mi("{{\\bf Z}}")#text(" do not have property (T).")],
[#text("(ii) Show that any infinite discrete abelian finitely generated group does not have property (T).")],
[#text("(iii) Show that any finitely generated group ")#mi("{G}")#text(" with infinite abelianisation ")#mi("{G/[G,G]}")#text(" does not have property (T).")],
[#text("(iv) Show that for any ")#mi("{k \\geq 1}")#text(", the free group on ")#mi("{k}")#text(" generators does not have property (T).")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38 (Property (T) and group cohomology)")]#text(" The purpose of this exercise is to link property (T) to some objects of interest in ")#link("http://en.wikipedia.org/wiki/Group_cohomology")[#text("group cohomology")]#text(", and in particular to demonstrate some “rigidity” properties of groups with property (T). (This exercise will not be needed in the rest of the course.) The results here originate from the work of Delorme and Guichardet; see ")#link("http://perso.univ-rennes1.fr/bachir.bekka/KazhdanTotal.pdf")[#text("Bekka, de la Harpe, and Valette")]#text(" or ")#link("http://www.ams.org/mathscinet-getitem?mr=1767270")[#text("this paper of Shalom")]#text(" for a further discussion of the rigidity (and superrigidity) properties of groups with property (T).")#linebreak()#text(" Let ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" be a unitary representation of a locally compact group ")#mi("{G}")#text(". Define a ")#emph[#mi("{\\rho}")#text("-cocycle")]#text(" to be a continuous function ")#mi("{c: G \\rightarrow H}")#text(" obeying the ")#emph[#text("cocycle equation")]

#align(center)[#tao-fit-display[#mitex("c(gh) = c(g) + \\rho(g) c(h)")]]

#text("for all ")#mi("{g,h \\in G}")#text(". (Equivalently, a ")#mi("{\\rho}")#text("-cocycle determines an affine isometric action ")#mi("{v \\mapsto \\rho(g) v + c(g)}")#text(" of ")#mi("{G}")#text(" on ")#mi("{H}")#text(" with ")#mi("{\\rho}")#text(" as the unitary component of the action.) Define a ")#emph[#mi("{\\rho}")#text("-coboundary")]#text(" to be a function ")#mi("{c: G \\rightarrow H}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("c(g) = v_0 - \\rho(g) v_0")]]

#text("for some fixed vector ")#mi("{v_0 \\in H}")#text(" (or equivalently, an affine isometric action of ")#mi("{G}")#text(" on ")#mi("{H}")#text(" with a common fixed point ")#mi("{v_0}")#text("); observe that every ")#mi("{\\rho}")#text("-coboundary is automatically a ")#mi("{\\rho}")#text("-cocycle.")

#list(
[#text("(i) Show that a ")#mi("{\\rho}")#text("-cocycle ")#mi("{c: G \\rightarrow H}")#text(" is a ")#mi("{\\rho}")#text("-coboundary if and only if it is bounded. (")#emph[#text("Hint:")]#text(" if ")#mi("{c}")#text(" is a bounded ")#mi("{\\rho}")#text("-cocycle, then for any vector ")#mi("{v}")#text(" the orbit ")#mi("{\\{ \\rho(g) v + c(g): g \\in G \\}}")#text(" of ")#mi("{v}")#text(" lies in a ball. Exploit convexity to construct a shrinking sequence of such balls and use the completeness of ")#mi("{H}")#text(" pass to the limit.)")],
[#text("(ii) Show that if ")#mi("{G}")#text(" has property (T), then every ")#mi("{\\rho}")#text("-cocycle is a ")#mi("{\\rho}")#text("-coboundary. (")#emph[#text("Hint:")]#text(" the main difficulty is to lift the affine isometric action to a unitary action. One way to do this is to work in the Hilbert space ")#mi("{\\tilde H}")#text(" that is the completion of the finitely supported measures on ")#mi("{H}")#text(", using an inner product such as ")#tao-math("{\\langle \\delta_v, \\delta_w \\rangle_{\\tilde H} := e^{-\\varepsilon \\left\\|v-w\\right\\|^2}}", block: false)#text(" for some sufficiently small ")#mi("{\\varepsilon>0}")#text(" (one needs to verify that this does indeed determine a positive definite inner product, which can be seen for instance by working in finite dimensions and using either Fourier transforms or gaussian identities). Note that the separability of ")#mi("{H}")#text(" will imply the separability of ")#mi("{\\tilde H}")#text(".)")],
[#text("(iii) Conversely, show that if for every unitary representation ")#mi("{\\rho}")#text(", every ")#mi("{\\rho}")#text("-cocycle is a ")#mi("{\\rho}")#text("-coboundary, then ")#mi("{G}")#text(" has property (T). (")#emph[#text("Hint:")]#text(" First show that (by taking a direct sum of counterexamples, as in Exercise ")#link(<tao-659ea97863b0ca57a42c>)[#text("24")]#text(") that if ")#mi("{S}")#text(" is a compact neighbourhood of the identity that generates ")#mi("{G}")#text(", ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" is any unitary representation, and ")#mi("{c}")#text(" is a ")#mi("{\\rho}")#text("-cocycle, then ")#tao-math("{\\sup_{g \\in G} \\left\\|c(g)\\right\\|_H \\leq C \\sup_{s \\in S} \\left\\|c(s)\\right\\|_H}", block: false)#text(", where ")#mi("{C}")#text(" depends on ")#mi("{S}")#text(" but is independent of ")#mi("{\\rho}")#text(" or ")#mi("{c}")#text(". Apply this fact to a coboundary generated by an approximate vector.)")]
)
]

#heading(level: 1)[#strong[#text(" — 2. Induced representations and property (T) — ")]]

#text("Let ")#mi("{\\tilde G}")#text(" be a locally compact group, and let ")#mi("{G}")#text(" be a subgroup of ")#mi("{\\tilde G}")#text(" which is closed (and thus also locally compact). Clearly, every unitary representation ")#mi("{\\tilde \\rho: \\tilde G \\rightarrow U(H)}")#text(" of ")#mi("{\\tilde G}")#text(" can be restricted to form a unitary representation ")#mi("{Res^G_{\\tilde G} \\rho\\: G \\rightarrow U(H)}")#text(" of ")#mi("{G}")#text(". It is then natural to ask whether the converse is also true, that is to say whether any unitary representation ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" of ")#mi("{H}")#text(" can be extended to a representation ")#mi("{\\tilde \\rho: \\tilde G \\rightarrow U(H)}")#text(" of ")#mi("{\\tilde G}")#text(" on the same Hilbert space ")#mi("{H}")#text(".")#linebreak()#text(" In general, the answer is no. For instance, if ")#mi("{\\tilde G}")#text(" is the Heisenberg group ")#mi("{\\tilde G = \\begin{pmatrix} 1 & {\\bf Z} & {\\bf Z} \\\\ 0 & 1 & {\\bf Z} \\\\ 0 & 0 & 1 \\end{pmatrix}}")#text(", and ")#mi("{G = [\\tilde G,\\tilde G]}")#text(" is the commutator group ")#mi("{G = \\begin{pmatrix} 1 & 0 & {\\bf Z} \\\\ 0 & 1 & 0 \\\\ 0 & 0 & 1 \\end{pmatrix}}")#text(", then any one-dimensional representation ")#mi("{\\tilde \\rho: \\tilde G \\rightarrow U_1({\\bf C})}")#text(" must annihilate the commutator ")#mi("{G}")#text(", but there are clearly non-trivial one-dimensional representations ")#mi("{\\rho: G \\rightarrow U_1({\\bf C})}")#text(" of ")#mi("{G}")#text(" which thus cannot be extended to a representation of ")#mi("{G}")#text(".")#linebreak()#text(" However, there is a fundamental construction that (under some mild hypotheses) takes a representation ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" of ")#mi("{G}")#text(" and converts it to an ")#link("http://en.wikipedia.org/wiki/Induced_representation")[#text("induced representation")]#text(" ")#mi("{\\tilde \\rho := Ind^{\\tilde G}_G \\rho: \\tilde G \\rightarrow U(\\tilde H)}")#text(" of ")#mi("{\\tilde G}")#text(", that acts on a somewhat larger Hilbert space ")#mi("{\\tilde H}")#text(" than ")#mi("{H}")#text(" (in particular, the induced representation construction is ")#emph[#text("not")]#text(" an inverse of the restricted representation construction). This construction will provide an important link between the representation theories of ")#mi("{G}")#text(" and ")#mi("{\\tilde G}")#text(", and in particular will connect property (T) for ")#mi("{G}")#text(" to property (T) for ")#mi("{\\tilde G}")#text(".")#linebreak()#text(" To motivate the induced representation construction, we work for simplicity in the case when ")#mi("{G}")#text(" and ")#mi("{\\tilde G}")#text(" are discrete, consider the regular representations ")#mi("{\\tau: G \\rightarrow U(H)}")#text(" and ")#mi("{\\tilde \\tau: \\tilde G \\rightarrow U(\\tilde H)}")#text(" of ")#mi("{G}")#text(" and ")#mi("{\\tilde G}")#text(" respectively, where ")#mi("{H := \\ell^2(G)}")#text(" and ")#mi("{\\tilde H := \\ell^2(\\tilde G)}")#text(". We wish to view the ")#mi("{\\tilde G}")#text("-representation ")#mi("{\\tilde \\tau}")#text(" as somehow being induced from the ")#mi("{G}")#text("-representation ")#mi("{\\tau}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\tilde \\tau = Ind_G^{\\tilde G} \\tau.")]]

#text("To do this, we must somehow connect ")#mi("{H}")#text(" with ")#mi("{\\tilde H}")#text(", and ")#mi("{\\tau}")#text(" with ")#mi("{\\tilde \\tau}")#text(".")#linebreak()#text(" One natural way to proceed is to express ")#mi("{\\tilde G}")#text(" as the union of cosets ")#mi("{kG}")#text(" of ")#mi("{G}")#text(" for ")#mi("{k}")#text(" in some set ")#mi("{K}")#text(" of coset representatives. We can then split ")#mi("{\\ell^2(\\tilde G)}")#text(" as a direct sum ")#mi("{\\ell^2(\\tilde G) = \\oplus_{k \\in K} \\ell^2(kG)}")#text(" (at least in the model case when ")#mi("{K}")#text(" is finite), and each factor space ")#mi("{\\ell^2(kG)}")#text(" can be viewed as a shift ")#mi("{\\ell^2(kG) = \\tilde \\rho(k) \\ell^2(G)}")#text(" of ")#mi("{\\ell^2(G)}")#text(". This does indeed give enough of a relationship between ")#mi("{\\tau}")#text(" and ")#mi("{\\tilde \\tau}")#text(" to generalise to other representations, but it is a somewhat inelegant “coordinate-dependent” formalism because it initially depends on making a somewhat arbitrary choice of coset representatives ")#mi("{K}")#text(" (though one can show, at the end of the construction, that the choice of ")#mi("{K}")#text(" was ultimately irrelevant). Also, this method develops some technical complications when the quotient space ")#mi("{\\tilde G/G}")#text(" is not discrete.")#linebreak()#text(" Because of this, we shall work instead with a more “coordinate-free” construction that does not require an explicit construction of coset representatives. Instead, we rely on the orthogonal projection ")#mi("{\\pi: \\tilde H \\rightarrow H}")#text(" of the larger Hilbert space ")#mi("{\\tilde H = \\ell^2(\\tilde G)}")#text(" to the smaller Hilbert space ")#mi("{\\ell^2(G)}")#text(", which in the case of the regular representation is just the restriction map, ")#mi("{\\pi(f) := f\\downharpoonright_G}")#text(".")#linebreak()#text(" Observe that given any vector ")#mi("{f \\in \\tilde H}")#text(" and group element ")#mi("{g \\in \\tilde G}")#text(", one can form the projection ")#mi("{F(g) := \\pi(\\tilde \\rho(g^{-1}) f)}")#text(" in ")#mi("{H}")#text(", which can be written explicitly as")

#align(center)[#tao-fit-display[#mitex("F(g)(x) = f(gx)")]]

#text("for ")#mi("{g \\in \\tilde G}")#text(" and ")#mi("{x \\in \\tilde G}")#text(". Thus ")#mi("{F}")#text(" is a function from ")#mi("{\\tilde G}")#text(" to ")#mi("{H}")#text(" which obeys the symmetry ")#metadata(none) <tao-36e0fd847d927d68475f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("F(gh) = \\rho(h^{-1}) F(g)")]]

#text("for all ")#mi("{g \\in \\tilde G}")#text(" and ")#mi("{h \\in G}")#text(". Conversely, any function ")#mi("{F: \\tilde G \\rightarrow H}")#text(" obeying the symmetry ")#link(<tao-36e0fd847d927d68475f>)[#text("(4)")]#text(" arises from an element ")#mi("{f}")#text(" of ")#mi("{H^{\\prime}}")#text(" in this manner. Thus, we may identify ")#mi("{\\tilde H}")#text(" (as a vector space, at least), with the space of functions ")#mi("{F: \\tilde G \\rightarrow H}")#text(" obeying ")#link(<tao-36e0fd847d927d68475f>)[#text("(4)")]#text(". Furthermore, the Hilbert space norm ")#tao-math("{\\left\\|f\\right\\|_{\\tilde H} = \\left\\|f\\right\\|_{\\ell^2(\\tilde G)}}", block: false)#text(" of ")#mi("{\\tilde G}")#text(" can be expressed in terms of ")#mi("{F}")#text(" via the identity")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{\\tilde H} = (\\sum_{g \\in \\tilde G/G} \\left\\|F(g)\\right\\|_H^2)^{1/2},", block: true)]]

#text("where we use the fact (from ")#link(<tao-36e0fd847d927d68475f>)[#text("(4)")]#text(") that ")#tao-math("{\\left\\|F(gh)\\right\\|_H = \\left\\|F(g)\\right\\|_H}", block: false)#text(" for all ")#mi("{h \\in H}")#text(" to view (by abuse of notation) ")#tao-math("{\\left\\|F(\\cdot)\\right\\|_H}", block: false)#text(" as a function of ")#mi("{\\tilde G/G}")#text(" rather than of ")#mi("{\\tilde G}")#text(". Similarly, given two vectors ")#mi("{f, f^{\\prime} \\in \\tilde H}")#text(" with associated functions ")#mi("{F, F^{\\prime}: \\tilde G \\rightarrow H}")#text(", the inner product ")#mi("{\\langle f, f^{\\prime} \\rangle_{\\tilde H}}")#text(" can be recovered from ")#mi("{F, F^{\\prime}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\langle f, f^{\\prime} \\rangle_{\\tilde H} = \\sum_{g \\in \\tilde G/G} \\langle F(g), F^{\\prime}(g) \\rangle_H,")]]

#text("where we adopt the same abuse of notation as before.")#linebreak()#text(" Motivated by this example, we now have the following construction (essentially due to Frobenius).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 39 (Induced representation)")]#text(" Let ")#mi("{\\tilde G}")#text(" be a locally compact group, and let ")#mi("{G}")#text(" be a subgroup of ")#mi("{\\tilde G}")#text(" which is closed (and thus also locally compact). Suppose that there is a non-zero Radon measure ")#mi("{\\mu_{\\tilde G/G}}")#text(" on the quotient space ")#mi("{\\tilde G/G}")#text(" which is invariant under the left-action of ")#mi("{\\tilde G}")#text(" (i.e. it is a ")#link("http://en.wikipedia.org/wiki/Haar_measure")[#text("Haar measure")]#text(" of ")#mi("{\\tilde G/G}")#text("). Let ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" be a unitary representation of ")#mi("{G}")#text(". Then we define the ")#emph[#text("induced representation")]#text(" ")#mi("{\\tilde \\rho = Ind_G^{\\tilde G} \\rho: \\tilde G \\rightarrow U(\\tilde H)}")#text(" as follows. We define ")#mi("{\\tilde H}")#text(" to be the (pre-)Hilbert space of all functions ")#mi("{F: \\tilde G \\rightarrow H}")#text(" obeying ")#link(<tao-36e0fd847d927d68475f>)[#text("(4)")]#text(" for all ")#mi("{g \\in \\tilde G}")#text(" and ")#mi("{h \\in G}")#text(", that are weakly measurable in the sense that ")#mi("{\\lambda(F)}")#text(" is Borel measurable for all bounded linear functionals ")#mi("{\\lambda: H \\rightarrow {\\bf C}}")#text(", and such that the norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|F\\right\\|_{\\tilde H} := (\\int_{g \\in \\tilde G/G} \\left\\|F(g)\\right\\|_H^2\\ d\\mu_{\\tilde G/G}(g))^{1/2}", block: true)]]

#text("is finite, where we abuse notation as before and view ")#tao-math("{\\left\\|F(\\cdot)\\right\\|_H}", block: false)#text(" as a function of ")#mi("{\\tilde G/G}")#text(". (Note from the separability of ")#mi("{H}")#text(" that the function ")#tao-math("{\\left\\|F(\\cdot)\\right\\|_H}", block: false)#text(" is measurable.) We also define the inner product on ")#mi("{\\tilde H}")#text(" by")

#align(center)[#tao-fit-display[#mitex("\\langle F, F^{\\prime} \\rangle_{\\tilde H} := \\int_{g \\in \\tilde G/G} \\langle F(g), F^{\\prime}(g) \\rangle_H\\ d\\mu_{\\tilde G/G}(g),")]]

#text("and identify together elements of ")#mi("{\\tilde H}")#text(" whose difference has norm zero, to obtain a genuine Hilbert space rather than a pre-Hilbert space. (We leave it to the reader to verify that this space is in fact complete; this is a “")#mi("{G}")#text("-space” version of the standard argument establishing that ")#mi("{L^2(X,\\mu)}")#text(" is complete for any measure space ")#mi("{(X,\\mu)}")#text(".) We then define the representation ")#mi("{\\tilde \\rho}")#text(" on ")#mi("{\\tilde H}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\tilde \\rho(g) F(x) := F(g^{-1} x)")]]

#text("for all ")#mi("{g, x \\in \\tilde G}")#text("; one can verify that this is a well-defined unitary representation.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 40")]#text(" Given a Haar measure ")#mi("{\\mu_{\\tilde G/G}}")#text(" on ")#mi("{\\tilde G/G}")#text(" and a Haar measure ")#mi("{\\mu_G}")#text(" on ")#mi("{G}")#text(", one can build a Haar measure ")#mi("{\\mu_{\\tilde G}}")#text(" on ")#mi("{\\tilde G}")#text(" via the ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem")[#text("Riesz representation theorem")]#text(" and the integration formula")

#align(center)[#tao-fit-display[#mitex("\\int_{\\tilde G} f(x)\\ d\\mu_{\\tilde G}(x) := \\int_{\\tilde G/G} (\\int_{G} f(yz)\\ d\\mu_G(z)) d\\mu_{\\tilde G/G}(y)")]]

#text("for ")#mi("{f \\in C_c(\\tilde G)}")#text(", where we abuse notation by noting that the integrand is a ")#mi("{G}")#text("-right-invariant function of ")#mi("{y \\in \\tilde G}")#text(", and can thus be viewed as a function on the quotient space ")#mi("{\\tilde G/G}")#text(". As Haar measures on groups are determined up to constants (as shown for instance in ")#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/")[#text("this previous blog post")]#text("), we conclude that Haar measures on quotient spaces ")#mi("{\\tilde G/G}")#text(", if they exist, are also determined up to constants. As such, the induced representation construction given above does not depend (up to isomorphism) on the choice of Haar measure on ")#mi("{\\tilde G/G}")#text(". However, it is possible to have quotient spaces for which no Haar measure is available; for instance the group of affine transformations ")#mi("{x \\mapsto ax+b}")#text(" acts on ")#mi("{{\\bf R}}")#text(" (which is then a quotient of the affine group by the stabiliser of a point), but without any invariant measure. It is possible to extend the induced representation construction to this setting also, but this is more technical; see ")#link("http://www.ams.org/mathscinet-getitem?mr=1397028")[#text("this text of Folland")]#text(" for details.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 41")]#text(" If ")#mi("{G}")#text(" is an open subgroup of ")#mi("{\\tilde G}")#text(", and ")#mi("{\\mu_{\\tilde G/G}}")#text(" is counting measure, then the induced representation of the trivial one-dimensional representation of ")#mi("{G}")#text(" is the quasiregular representation of ")#mi("{\\tilde G}")#text(" on ")#mi("{\\tilde G/G}")#text(", and the induced representation of the regular representation of ")#mi("{G}")#text(" is the regular representation of ")#mi("{\\tilde G}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42 (Transitivity of induction)")]#text(" Let ")#mi("{G_3 \\leq G_2 \\leq G_1}")#text(" be locally compact groups, such that ")#mi("{G_3}")#text(" has finite index in ")#mi("{G_2}")#text(", and ")#mi("{G_2}")#text(" has finite index in ")#mi("{G_1}")#text(". Show that for any unitary representation ")#mi("{\\rho: G_3 \\rightarrow U(H)}")#text(" of ")#mi("{G_3}")#text(", one has ")#mi("{Ind_{G_2}^{G_3} Ind_{G_2}^{G_1} \\rho \\equiv Ind^{G_1}_{G_3} \\rho}")#text(". (A similar statement is also true in the infinite index case, but is more technical to establish.)")
]

#text("As a first application of the induced representation construction (and the much simpler restricted representation construction), we show that one can pass from a group to a finite subgroup as far as property (T) is concerned.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 43")]#text(" ")#metadata(none) <tao-b4bdc848109722a383d0>#text(" Let ")#mi("{\\tilde G}")#text(" be a locally compact group, and let ")#mi("{G}")#text(" be a finite index closed subgroup of ")#mi("{\\tilde G}")#text(". Then ")#mi("{\\tilde G}")#text(" has property (T) if and only if ")#mi("{G}")#text(" has property (T).")
]

#emph[#text("Proof:")]#text(" Suppose first that ")#mi("{G}")#text(" has property (T). Let ")#mi("{S}")#text(" be a compact generating subset of ")#mi("{G}")#text(". As ")#mi("{G}")#text(" has finite index in ")#mi("{\\tilde G}")#text(", we may find a finite set ")#mi("{K}")#text(" in ")#mi("{\\tilde G}")#text(" such that ")#mi("{K G = \\tilde G}")#text(". Let ")#mi("{\\rho: \\tilde G \\rightarrow U(H)}")#text(" be a unitary representation, and suppose that ")#mi("{H}")#text(" has a unit vector ")#mi("{v}")#text(" such that ")#tao-math("{\\left\\|sv-v\\right\\|_H \\leq \\varepsilon}", block: false)#text(" for all ")#mi("{s \\in S \\cup K}")#text(", where ")#mi("{\\varepsilon>0}")#text(" is a small quantity (independent of ")#mi("{\\rho}")#text(") to be determined later. We will show that ")#mi("{v}")#text(" lies within distance ")#mi("{O(\\varepsilon)}")#text(" from a ")#mi("{\\tilde G}")#text("-invariant vector (where the implied constant can depend on ")#mi("{S,G,\\tilde G}")#text(" but not on ")#mi("{\\varepsilon}")#text("), which will give the claim for ")#mi("{\\varepsilon}")#text(" small enough.")#linebreak()#text(" By Exercise ")#link(<tao-55bd3a5913e5a3450179>)[#text("22")]#text("(v) applied to ")#mi("{G}")#text(", ")#mi("{Kaz(G,S) > 0}")#text(". By Exercise ")#link(<tao-683a62ce15fbabb1ac86>)[#text("25")]#text(", we thus see that ")#mi("{v}")#text(" lies within ")#mi("{O(\\varepsilon)}")#text(" from a ")#mi("{G}")#text("-invariant vector, so by the triangle inequality we may assume without loss of generality (and adjusting ")#mi("{\\varepsilon}")#text(" slightly) that ")#mi("{v}")#text(" is ")#mi("{G}")#text("-invariant. If ")#mi("{g \\in G}")#text(" is arbitrary, we may write ")#mi("{g = k \\gamma}")#text(" for some ")#mi("{k \\in K}")#text(". Then ")#tao-math("{\\left\\|gv-v\\right\\|_H = \\left\\|kv-v\\right\\|_H = O(\\varepsilon)}", block: false)#text(". Thus the ")#mi("{\\tilde G}")#text("-orbit of ")#mi("{v}")#text(" lies in a ball of radius ")#mi("{O(\\varepsilon)}")#text(" centred at ")#mi("{v}")#text(", and so by Exercise ")#link(<tao-cac729832e48d8a3b24a>)[#text("32")]#text(" this ball contains an invariant vector as required.")#linebreak()#text(" Conversely, suppose that ")#mi("{\\tilde G}")#text(" has property (T). Let ")#mi("{S}")#text(" be a compact generating subset of ")#mi("{G}")#text(", which we may assume without loss of generality to be a neighbourhood of the identity. Let ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" be a unitary representation, and let ")#mi("{v_0}")#text(" be a unit vector such that ")#metadata(none) <tao-42a3c32a25ec821b96eb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\|sv_0-v_0\\right\\|_H \\leq \\varepsilon", block: true)]]

#text("for all ")#mi("{s \\in S}")#text(", where ")#mi("{\\varepsilon>0}")#text(" is a small quantity independent of ")#mi("{\\rho}")#text(" to be chosen later. Our task is to show that ")#mi("{v_0}")#text(" lies within ")#mi("{O(\\varepsilon)}")#text(" of a ")#mi("{G}")#text("-invariant vector. Now we form the induced representation ")#mi("{\\tilde \\rho := Ind_{G}^{\\tilde G} \\rho: \\tilde G \\rightarrow U(\\tilde H)}")#text(" (using counting measure for ")#mi("{\\mu_{\\tilde G/G}}")#text("). By construction, ")#mi("{\\tilde H}")#text(" is the space of all functions ")#mi("{\\tilde v: \\tilde G \\rightarrow H}")#text(" such that ")#mi("{\\tilde v(x\\gamma) := \\rho(\\gamma)^{-1} \\tilde v(x)}")#text(" for all ")#mi("{\\gamma \\in G}")#text(" and ")#mi("{x \\in \\tilde G}")#text(". If we let ")#mi("{K}")#text(" be a finite set consisting of one representative of each left-coset of ")#mi("{G}")#text(", it is easy to see that each element ")#mi("{\\tilde v: \\tilde G \\rightarrow H}")#text(" of ")#mi("{\\tilde H}")#text(" is determined by its restriction to ")#mi("{K}")#text(", and conversely every function from ")#mi("{\\tilde v:K \\rightarrow H}")#text(" can be extended uniquely to an element of ")#mi("{\\tilde H}")#text("; thus ")#mi("{\\tilde H}")#text(" can be identified with the direct sum ")#mi("{\\oplus_{k \\in K} H}")#text(" of ")#tao-math("{\\left|K\\right|}", block: false)#text(" copies of ")#mi("{H}")#text(". Also, ")#mi("{\\tilde H}")#text(" contains ")#mi("{H}")#text(" as a ")#mi("{G}")#text("-invariant subspace, by identifying each vector ")#mi("{v \\in H}")#text(" with the function ")#mi("{\\tilde v}")#text(" defined by setting ")#mi("{\\tilde v(\\gamma) = \\rho(\\gamma)^{-1} v}")#text(" for ")#mi("{\\gamma \\in G}")#text(" and ")#mi("{\\tilde v(x)=0}")#text(" for ")#mi("{x \\not \\in G}")#text(". The actions of ")#mi("{\\tilde \\rho}")#text(" and ")#mi("{\\rho}")#text(" are then compatible in the sense that ")#mi("{\\tilde \\rho(\\gamma) v = \\rho(\\gamma) v}")#text(" for all ")#mi("{\\gamma \\in G}")#text(" and ")#mi("{v \\in H}")#text(".")#linebreak()#text(" Now consider the vector")

#align(center)[#tao-fit-display[#mitex("\\tilde v := \\sum_{k \\in K} \\tilde \\rho(k) v_0.")]]

#text("We now study its invariance properties of this vector with respect to ")#mi("{\\tilde S := S \\cup K}")#text(" (which generates ")#mi("{\\tilde G}")#text("). For any ")#mi("{s \\in \\tilde S}")#text(" and ")#mi("{k \\in K}")#text(", ")#mi("{sk}")#text(" lies in a compact subset of ")#mi("{\\tilde G}")#text(", and thus ")#mi("{sk = k^{\\prime} s^{\\prime}}")#text(" for some ")#mi("{k^{\\prime} = k^{\\prime}(k,s)}")#text(" in ")#mi("{K}")#text(" and ")#mi("{s^{\\prime} = s^{\\prime}(k,s)}")#text(" for some ")#mi("{s^{\\prime}}")#text(" in a compact subset of ")#mi("{G}")#text(". Also, for fixed ")#mi("{k}")#text(", the map ")#mi("{k \\mapsto k^{\\prime}(k,s)}")#text(" is a permutation of ")#mi("{K}")#text(". Since ")#mi("{S}")#text(" is a compact neighbourhood of the identity generating ")#mi("{G}")#text(", we see from compactness that there is a finite ")#mi("{m}")#text(" such that ")#mi("{s^{\\prime}(k,s) \\in S^m}")#text(" for all ")#mi("{k,s}")#text(". In particular, from ")#link(<tao-42a3c32a25ec821b96eb>)[#text("(5)")]#text(" and the triangle inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\rho(s^{\\prime}) v_0 - v_0 \\right\\|_H \\leq m \\varepsilon.", block: true)]]

#text("Since")

#align(center)[#tao-fit-display[#mitex("\\tilde \\rho(s) \\tilde v - \\tilde v = \\sum_{k \\in K} \\tilde \\rho(k^{\\prime}(k,s)) ( \\rho(s^{\\prime}(k,s)) v_0 - v_0 )")]]

#text("we conclude from the triangle inequality that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|\\tilde \\rho(s) \\tilde v - \\tilde v\\right\\|_H = O(\\varepsilon)", block: true)]]

#text("where the implied constant can depend on ")#mi("{m,S,K,G,\\tilde G}")#text(" but not on ")#mi("{\\rho}")#text(" or ")#mi("{\\varepsilon}")#text(". As ")#mi("{\\tilde G}")#text(" has property (T), we conclude (for ")#mi("{\\varepsilon}")#text(" small enough) using Exercise ")#link(<tao-683a62ce15fbabb1ac86>)[#text("25")]#text(" that ")#mi("{\\tilde v}")#text(" lies within ")#mi("{O(\\varepsilon)}")#text(" of an ")#mi("{\\tilde G}")#text("-invariant vector ")#mi("{w}")#text(". In particular, as ")#mi("{\\tilde G}")#text("-invariant vectors are also ")#mi("{G}")#text("-invariant, ")#mi("{w(1)}")#text(" is a ")#mi("{G}")#text("-invariant vector in ")#mi("{H}")#text(" which is within ")#mi("{O(\\varepsilon)}")#text(" of ")#mi("{\\tilde v(1)=v_0}")#text(", as desired. ")#mi("\\Box")#linebreak()#text(" Actually, with a bit more effort, one can generalise the above proposition from the finite index case to the finite covolume case, as was first observed by Kazhdan. There is however a technical issue; once ")#mi("{\\tilde G/G}")#text(" is not discrete, the original Hilbert space ")#mi("{H}")#text(" does not embed naturally into the induced Hilbert space ")#mi("{\\tilde H}")#text(" (basically because ")#mi("{G}")#text(" now has measure zero in ")#mi("{\\tilde G}")#text(", so there is no obvious way to embed ")#mi("{L^2(G)}")#text(" into ")#mi("{L^2(\\tilde G)}")#text("). This issue however can be dealt with by “convolving” with a suitable approximation to the identity ")#mi("{f \\in C_c(\\tilde G)}")#text(", where ")#mi("{C_c(\\tilde G)}")#text(" is the space of continuous functions ")#mi("{f: \\tilde G \\rightarrow {\\bf C}}")#text(" with compact support. More precisely, we have the following definition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 44")]#text(" ")#metadata(none) <tao-647efd2d4eb2381d296d>#text(" Let ")#mi("{\\tilde G}")#text(" be a locally compact group, and let ")#mi("{G}")#text(" be a subgroup of ")#mi("{\\tilde G}")#text(" that is also a locally compact group. Let ")#mi("{\\mu_{\\tilde G/G}}")#text(" be a Haar measure on ")#mi("{\\tilde G/G}")#text(", and let ")#mi("{\\mu_G}")#text(" be a Haar measure on ")#mi("{G}")#text(". Let ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" be a unitary representation, and let ")#mi("{\\tilde \\rho: \\tilde G \\rightarrow U(\\tilde H)}")#text(" be the induced representation ")#mi("{\\tilde \\rho = Ind_G^{\\tilde G} \\rho}")#text(". Let ")#mi("{v \\in H}")#text(", and let ")#mi("{f \\in C_c(\\tilde G)}")#text(". Then we define the convolution ")#mi("{C_f(v) \\in \\tilde H}")#text(" of ")#mi("{v}")#text(" by ")#mi("{f}")#text(" to be the function ")#mi("{C_f(v): \\tilde G \\rightarrow H}")#text(" given by the formula")

#align(center)[#tao-fit-display[#mitex("C_f(v)(g) := \\int_G f(gh) \\rho(h) v d\\mu_G(h).")]]

#text("One easily verifies that ")#mi("{C_f(v)}")#text(" is well-defined and lies in ")#mi("{\\tilde H}")#text(".")
]

#text("Related to the convolution operation will be the projection ")#mi("{\\Pi_{\\tilde G/G}(f) \\in C_c(\\tilde G/G)}")#text(" of a function ")#mi("{f \\in C_c(\\tilde G)}")#text(", defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\Pi_{\\tilde G/G}(f)(g) = \\int_G f(gh)\\ d\\mu_G(h),")]]

#text("where the right-hand side is right ")#mi("{G}")#text("-invariant in ")#mi("{g}")#text(", and can thus be viewed as a function of ")#mi("{\\tilde G/G}")#text(" rather than ")#mi("{\\tilde G}")#text(". We have the following key technical fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 45 (Surjectivity)")]#text(" ")#metadata(none) <tao-062f2416cd1d27d15110>#text(" The projection operator ")#mi("{\\Pi_{\\tilde G/G}: C_c(\\tilde G) \\rightarrow C_c(\\tilde G/G)}")#text(" is surjective. Furthermore, given a non-negative function ")#mi("{F}")#text(" in ")#mi("{C_c(\\tilde G/G)}")#text(", we may find a non-negative function ")#mi("{f^{\\prime}}")#text(" in ")#mi("{C_c(\\tilde G)}")#text(" with ")#mi("{\\Pi_{\\tilde G/G}(f^{\\prime})= F}")#text(".")
]

#emph[#text("Proof:")]#text(" It suffices to prove the second claim. Let ")#mi("{F: \\tilde G/G \\rightarrow {\\bf R}^+}")#text(" be a non-negative continuous function supported on some compact subset ")#mi("{K}")#text(" of ")#mi("{\\tilde G/G}")#text(". By compactness, one can find a compact subset ")#mi("{\\tilde K}")#text(" of ")#mi("{\\tilde G}")#text(" which covers ")#mi("{K}")#text(" in the sense that for every coset ")#mi("{gG}")#text(" in the preimage of ")#mi("{K}")#text(", the set ")#mi("{\\tilde K \\cap gG}")#text(" is non-empty and open in ")#mi("{gG}")#text(" (or equivalently, ")#mi("{g^{-1} \\tilde K \\cap G}")#text(" is open in ")#mi("{G}")#text("). By Urysohn’s lemma, we may find a non-negative function ")#mi("{f \\in C_c(\\tilde G)}")#text(" which equals ")#mi("{1}")#text(" on ")#mi("{\\tilde K}")#text(", and then ")#mi("{\\Pi_{\\tilde G/G}(f)}")#text(" is nonzero on ")#mi("{K}")#text(". Thus we may write ")#mi("{F = \\Pi_{\\tilde G/G}(f) F^{\\prime}}")#text(" for some ")#mi("{F^{\\prime} \\in C_c(\\tilde G/G)}")#text(". If we let ")#mi("{\\pi: \\tilde G \\rightarrow \\tilde G/G}")#text(" be the projection map, then we easily verify that the function ")#mi("{f^{\\prime} := f (F^{\\prime} \\circ \\pi)}")#text(" lies in ")#mi("{C_c(\\tilde G)}")#text(" and is non-negative with ")#mi("{F = \\Pi_{\\tilde G/G}(f^{\\prime})}")#text(", and the claim follows. ")#mi("\\Box")#linebreak()#text(" Now we generalise Proposition ")#link(<tao-b4bdc848109722a383d0>)[#text("43")]#text(" to the finite covolume case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 46")]#text(" ")#metadata(none) <tao-7310ce7a29303a551ff4>#text(" Let ")#mi("{\\tilde G}")#text(" be a locally compact group, and let ")#mi("{G}")#text(" be a locally compact subgroup of ")#mi("{\\tilde G}")#text(". Suppose that ")#mi("{G}")#text(" has ")#emph[#text("finite covolume")]#text(" in ")#mi("{\\tilde G}")#text(", which means that there exists a ")#emph[#text("finite")]#text(" Haar measure ")#mi("{\\mu_{\\tilde G/G}}")#text(" on ")#mi("{\\tilde G/G}")#text(". Then ")#mi("{\\tilde G}")#text(" has property (T) if and only if ")#mi("{G}")#text(" has property (T).")
]

#emph[#text("Proof:")]#text(" We may normalise the Radon measure ")#mi("{\\mu}")#text(" to be a probability measure. Suppose first that ")#mi("{G}")#text(" has property (T). Let ")#mi("{S}")#text(" be a compact generating subset of ")#mi("{G}")#text(", and let ")#mi("{\\varepsilon}")#text(" be chosen later. As ")#mi("{\\mu(\\tilde G/G) = 1}")#text(" and ")#mi("{\\tilde G}")#text(" is compactly generated, we may use inner regularity and find a compact subset ")#mi("{K}")#text(" of ")#mi("{\\tilde G}")#text(" such that ")#mi("{\\mu(\\pi(K)) \\geq 1-\\varepsilon}")#text(", where ")#mi("{\\pi: \\tilde G \\rightarrow \\tilde G/G}")#text(" is the projection map.")#linebreak()#text(" Now let ")#mi("{\\rho: \\tilde G \\rightarrow U(H)}")#text(" be a unitary representation, and suppose that ")#mi("{H}")#text(" has a unit vector ")#mi("{v}")#text(" such that ")#tao-math("{\\left\\|sv-v\\right\\|_H \\leq \\varepsilon}", block: false)#text(" for all ")#mi("{s \\in S \\cup K}")#text(". As before, the goal is to show that ")#mi("{v}")#text(" lies within distance ")#mi("{O(\\varepsilon)}")#text(" from a ")#mi("{\\tilde G}")#text("-invariant vector, which will give the claim for ")#mi("{\\varepsilon}")#text(" small enough.")#linebreak()#text(" By Exercise ")#link(<tao-55bd3a5913e5a3450179>)[#text("22")]#text("(v) and Exercise ")#link(<tao-683a62ce15fbabb1ac86>)[#text("25")]#text(" as in the previous argument, we may assume that ")#mi("{v}")#text(" is ")#mi("{G}")#text("-invariant. The function ")#mi("{g \\mapsto \\rho(g) v}")#text(" then descends from a bounded ")#mi("{H}")#text("-valued function on ")#mi("{\\tilde G}")#text(" to a function on ")#mi("{F: \\tilde G/G \\rightarrow H}")#text(". We may thus form the average")

#align(center)[#tao-fit-display[#mitex("\\bar{v} := \\int_{\\tilde G/G} F(x)\\ d\\mu_{\\tilde G/G}(x),")]]

#text("where we can define the ")#mi("{H}")#text("-valued integral in the weak sense, using bounded linear functionals ")#mi("{\\lambda: H \\rightarrow {\\bf C}}")#text(" on ")#mi("{H}")#text(" and the Riesz representation theorem for Hilbert spaces, noting that ")#mi("{F}")#text(" is weakly integrable in the sense that ")#mi("{\\lambda(F)}")#text(" is absolutely integrable for all bounded linear functionals ")#mi("{\\lambda}")#text(". By the left-invariance of ")#mi("{\\mu_{\\tilde G/G}}")#text(" we see that ")#mi("{\\bar{v}}")#text(" is ")#mi("{\\tilde G}")#text("-invariant. Also, by construction, we have ")#tao-math("{\\left\\|F(x)\\right\\|_H = O(1)}", block: false)#text(" for all ")#mi("{x \\in \\tilde G/G}")#text(", and ")#tao-math("{\\left\\|F(x)-x\\right\\|_H = O(\\varepsilon)}", block: false)#text(" for all ")#mi("{x \\in \\pi(K)}")#text(", which has measure ")#mi("{1-\\varepsilon}")#text(". As such we see that ")#tao-math("{\\left\\|\\bar{v}-v\\right\\|_H = O(\\varepsilon)}", block: false)#text(", and the claim follows.")#linebreak()#text(" Now suppose instead that ")#mi("{\\tilde G}")#text(" has property (T). Let ")#mi("{S}")#text(" be a compact generating subset of ")#mi("{G}")#text(", which we may assume without loss of generality to be a neighbourhood of the identity. Let ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" be a unitary representation, and let ")#mi("{v_0}")#text(" be a unit vector obeying ")#link(<tao-42a3c32a25ec821b96eb>)[#text("(5)")]#text(" for all ")#mi("{s \\in S}")#text(", and some small ")#mi("{\\varepsilon>0}")#text(" (depending only on ")#mi("{S,G, \\tilde G}")#text(" and to be chosen later). We will suppose for contradiction that ")#mi("{H}")#text(" contains no non-trivial ")#mi("{G}")#text("-invariant vectors.")#linebreak()#text(" As before, the first step is to build the induced representation ")#mi("{\\tilde \\rho := Ind_G^{\\tilde G} \\rho: \\tilde G \\rightarrow U(\\tilde H)}")#text(" of ")#mi("{\\rho}")#text(", using the given Haar measure ")#mi("{\\mu_{\\tilde G/G}}")#text(". Let ")#mi("{\\delta > 0}")#text(" be a sufficiently small quantity (depending on ")#mi("{S,G,\\tilde G}")#text(", but not depending on ")#mi("{\\varepsilon}")#text(") to be chosen later. By inner regularity, we can find a compact subset ")#mi("{K}")#text(" of ")#mi("{\\tilde G/G}")#text(" of measure ")#mi("{\\mu_{\\tilde G/G}(K) \\geq 1-\\delta}")#text(". By Urysohn’s lemma followed by Lemma ")#link(<tao-062f2416cd1d27d15110>)[#text("45")]#text(", we may find a function ")#mi("{f \\in C_c(G)}")#text(" such that ")#mi("{\\Pi_{\\tilde G/G}(f)}")#text(" is bounded by ")#mi("{1}")#text(" and equals ")#mi("{1}")#text(" on ")#mi("{K}")#text("; in particular, it differs by ")#mi("{1}")#text(" only on a set of measure ")#mi("{O(\\delta)}")#text(". Now we consider the vector ")#mi("{v \\in \\tilde H}")#text(" defined by the formula")

#align(center)[#tao-fit-display[#mitex("v := C_f(v_0),")]]

#text("thus")

#align(center)[#tao-fit-display[#mitex("v(g) = \\int_G f(gh) \\rho(h) v d\\mu_G(h).")]]

#text("By the triangle inequality one has ")#metadata(none) <tao-ef73fb8e44f0424f578f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left\\|v(g)\\right\\|_H \\leq \\int_G f(gh) d\\mu_G(h) = \\Pi_{\\tilde G/G}(f) \\leq 1", block: true)]]

#text("for all ")#mi("{g \\in \\tilde G}")#text(".")#linebreak()#text(" Let ")#mi("{K^{\\prime}}")#text(" be a compact subset of ")#mi("{\\tilde G}")#text(" with ")#mi("{\\pi(K^{\\prime})}")#text(" containing ")#mi("{K}")#text(". For ")#mi("{g \\in K^{\\prime}}")#text(" and ")#mi("{h \\in G}")#text(" with ")#mi("{gh}")#text(" in the support of ")#mi("{f}")#text(", we see from the approximate invariance of ")#mi("{v_0}")#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\rho(h) v - v \\right\\|_H \\ll_\\delta \\varepsilon", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\| v(g) - \\Pi_{\\tilde G/G} f(g) v \\right\\|_H \\ll_\\delta \\varepsilon.", block: true)]]

#text("In particular, we see that ")#tao-math("{\\left\\|v(g)\\right\\|_H}", block: false)#text(" is equal to ")#mi("{1 - O_\\delta(\\varepsilon)}")#text(" for all ")#mi("{g \\in K}")#text(" (again abusing notation and descending from ")#mi("{\\tilde G}")#text(" to ")#mi("{\\tilde G/G}")#text("). From this and ")#link(<tao-ef73fb8e44f0424f578f>)[#text("(6)")]#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("1 \\ll \\left\\|v\\right\\|_H \\leq 1", block: true)]]

#text("if ")#mi("{\\delta}")#text(" is small enough (and ")#mi("{\\varepsilon}")#text(" sufficiently small depending on ")#mi("{\\delta}")#text(").")#linebreak()#text(" Now we investigate the approximate invariance properties of ")#mi("{v}")#text(". Let ")#mi("{\\tilde S}")#text(" be a compact generating subset of ")#mi("{\\tilde G}")#text(" (not depending on ")#mi("{\\delta}")#text(" or ")#mi("{\\varepsilon}")#text("). For ")#mi("{g \\in K^{\\prime}}")#text(" and ")#mi("{s \\in \\tilde S}")#text(", the preceding argument gives")

#align(center)[#tao-fit-display[#tao-math("\\left\\| v(g) - \\Pi_{\\tilde G/G} f(g) v \\right\\|_H \\ll_\\delta \\varepsilon", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| v(s^{-1} g) - \\Pi_{\\tilde G/G} f(s^{-1} g) v \\right\\|_H \\ll_\\delta \\varepsilon", block: true)]]

#text("and thus (by choice of ")#mi("{\\Pi_{\\tilde G/G} f}")#text(")")

#align(center)[#tao-fit-display[#tao-math("\\left\\| v(g) - v(s^{-1} g) \\right\\|_H \\ll_\\delta \\varepsilon", block: true)]]

#text("whenever ")#mi("{g \\in K \\cap s K}")#text(" (again abusing notation). This is a measure ")#mi("{1-O(\\delta)}")#text(" subset of ")#mi("{\\tilde G/G}")#text(". From this and ")#link(<tao-ef73fb8e44f0424f578f>)[#text("(6)")]#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| v - \\tilde \\rho(s) v \\right\\|_{\\tilde H} \\leq O_\\delta(\\varepsilon) + O(\\delta^{1/2}).", block: true)]]

#text("Since ")#mi("{\\tilde G}")#text(" has property (T), we conclude (if ")#mi("{\\delta}")#text(" is small enough, and ")#mi("{\\varepsilon}")#text(" sufficiently small depending on ")#mi("{\\delta}")#text(") that there exists a non-zero ")#mi("{\\tilde G}")#text("-invariant vector ")#mi("{w \\in \\tilde H}")#text(". Thus, for all ")#mi("{g \\in \\tilde G}")#text(", one has ")#mi("{w(g x) = w(x)}")#text(" for almost all ")#mi("{x \\in \\tilde G}")#text(" (using Haar measure on ")#mi("{\\tilde G}")#text(", of course). By the Fubini-Tonelli theorem, this implies that for almost all ")#mi("{x}")#text(", one has ")#mi("{w(g x) = w(x)}")#text(" for almost all ")#mi("{g \\in \\tilde G}")#text(". Fixing such a ")#mi("{x}")#text(", we conclude in particular that ")#mi("{w}")#text(" is almost everywhere equal to a constant ")#mi("{w_0 \\in H}")#text(". By another application of Fubini-Tonelli, this implies the existence of a coset ")#mi("{xG}")#text(" on which ")#mi("{w}")#text(" is almost everywhere equal to ")#mi("{w_0}")#text(" (this time using the Haar measure coming from ")#mi("{G}")#text("). By ")#link(<tao-36e0fd847d927d68475f>)[#text("(4)")]#text(", this makes ")#mi("{w_0}")#text(" ")#mi("{G}")#text("-invariant, and thus zero by choice of ")#mi("{H}")#text(". But this makes ")#mi("{w}")#text(" zero almost everywhere, contradicting the non-zero nature of ")#mi("{w}")#text(". ")#mi("\\Box")#linebreak()#text(" A discrete subgroup ")#mi("{\\Gamma}")#text(" of a locally compact group ")#mi("{G}")#text(" with finite covolume is known as a ")#emph[#text("lattice")]#text(". Thus, for instance, ")#mi("{{\\bf Z}^d}")#text(" is a lattice in ")#mi("{{\\bf R}^d}")#text(". Here is another important example of a lattice, involving the ")#link("http://en.wikipedia.org/wiki/Special_linear_group")[#text("special linear groups")]#text(" ")#mi("{SL_d}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 47")]#text(" For any ")#mi("{d \\geq 1}")#text(", ")#mi("{SL_d({\\bf Z})}")#text(" is a lattice in ")#mi("{SL_d({\\bf R})}")#text(".")
]

#emph[#text("Proof:")]#text(" Clearly ")#mi("{SL_d({\\bf Z})}")#text(" is discrete, so it suffices to show that there is a finite Haar measure on ")#mi("{SL_d({\\bf R})/SL_d({\\bf Z})}")#text(". It will suffice to show that there is a subset ")#mi("{E}")#text(" of ")#mi("{SL_d({\\bf R})}")#text(" of finite measure (with respect to a Haar measure on ")#mi("{SL_d({\\bf R})}")#text(", of course) whose projection onto ")#mi("{SL_d({\\bf R})/SL_d({\\bf Z})}")#text(" is surjective. Indeed, if this is the case, then one can construct a fundamental domain ")#mi("{K}")#text(" in ")#mi("{E}")#text(" by selecting, for each left coset ")#mi("{g SL_d({\\bf Z})}")#text(" of ")#mi("{SL_d({\\bf Z})}")#text(", a single element of ")#mi("{g SL_d({\\bf Z}) \\cap E}")#text(" in some measurable fashion (noting that this set is discrete and so has finite intersection with every compact set, allowing one to locate minimal elements with respect to some measurable ordering on ")#mi("{SL_d({\\bf R})}")#text("). As the translates of ")#mi("{K}")#text(" by the countable group ")#mi("{SL_d({\\bf Z})}")#text(" cover ")#mi("{SL_d({\\bf R})}")#text(", ")#mi("{K}")#text(" must have positive measure; and one can then construct a Haar measure on ")#mi("{SL_d({\\bf R})/SL_d({\\bf Z})}")#text(" by ")#link("http://en.wikipedia.org/wiki/Pushforward_measure")[#text("pushing forward")]#text(" the Haar measure on ")#mi("{K}")#text(".")#linebreak()#text(" One can interpret ")#mi("{SL_d({\\bf R})}")#text(" as the space of all lattices in ")#mi("{{\\bf R}^d}")#text(" generated by ")#mi("{d}")#text(" marked generators ")#mi("{v_1,\\ldots,v_d \\in {\\bf R}^d}")#text(" which are ")#emph[#text("unimodular")]#text(" in the sense that ")#mi("{\\det(v_1,\\ldots,v_d)=1}")#text(". The quotient space ")#mi("{SL_d({\\bf R})/SL_d(Z)}")#text(" can then be viewed as the space of all unimodular lattices ")#emph[#text("without")]#text(" marked generators (since the action of ")#mi("{SL_d({\\bf Z})}")#text(" simply serves to move one set of generators to another). Our task is thus to find a finite measure set of unimodular lattices with marked generators, which cover all unimodular lattices.")#linebreak()#text(" It will be slightly more convenient to work with ")#mi("{GL_d({\\bf R})}")#text(" instead of ")#mi("{SL_d({\\bf R})}")#text(" – i.e. the space of all lattices (not necessarily unimodular) with marked generators ")#mi("{v_1, \\ldots,v_d}")#text(". The reason for this is that there is a very simple Haar measure on ")#mi("{GL_d({\\bf R})}")#text(", namely the Lebesgue measure ")#tao-math("{dv_1 \\ldots dv_d / \\left|v_1 \\wedge \\dots \\wedge v_d\\right|}", block: false)#text(" on the generators (or equivalently, the measure induced from the open embedding ")#mi("{GL_d({\\bf R}) \\subset {\\bf R}^{d^2}}")#text("), divided by the determinant magnitude ")#tao-math("{\\left|v_1 \\wedge \\dots \\wedge v_d\\right|}", block: false)#text("; this is easily verified to be a Haar measure. One can then use dilation to convert a Haar measure on ")#mi("{GL_d({\\bf R})}")#text(" to one on ")#mi("{SL_d({\\bf R})}")#text(", for instance by declaring the ")#mi("{SL_d({\\bf R})}")#text(" Haar measure of a set ")#mi("{E \\subset SL_d({\\bf R})}")#text(" to be the ")#mi("{GL_d({\\bf R})}")#text(" Haar measure of the set ")#mi("{\\{ t A: t \\in [1,2]; A \\in E \\}}")#text(". Our task is now to find a finite measure set of lattices with marked generators, which cover all lattices of covolume in the interval ")#mi("{[1,2^d]}")#text(". Clearly one can replace ")#mi("{[1,2^d]}")#text(" here by any other compact interval in the positive real line.")#linebreak()#text(" This claim is trivial for ")#mi("{d=1}")#text(", so suppose inductively that ")#mi("{d>1}")#text(", and that the claim has already been proven for ")#mi("{d-1}")#text(". From ")#link("http://en.wikipedia.org/wiki/Minkowski%27s_theorem")[#text("Minkowski’s theorem")]#text(", every lattice ")#mi("{\\Gamma}")#text(" of covolume in ")#mi("{[1,2^d]}")#text(" contains a non-zero vector ")#mi("{v_d}")#text(" of norm ")#mi("{O(1)}")#text(", where we allow implied constants to depend on ")#mi("{d}")#text(". We may assume this vector to be irreducible, so that ")#mi("{\\Gamma}")#text(" is generated by ")#mi("{v_d}")#text(" and ")#mi("{d-1}")#text(" other generators ")#mi("{v_1,\\ldots,v_{d-1}}")#text(" that are independent of ")#mi("{v_d}")#text(". By subtracting or adding an integer multiple of ")#mi("{v_d}")#text(" to these other generators, we may assume that they take the form ")#mi("{v_i = w_i + t_i n_d}")#text(" for some ")#mi("{w_i}")#text(" orthogonal to ")#mi("{v_i}")#text(" and some ")#tao-math("{t_i \\in [0,\\left|v_d\\right|]}", block: false)#text(" for each ")#mi("{i=1,\\ldots,d-1}")#text(", where ")#tao-math("{n_d := v_d/\\left|v_d\\right|}", block: false)#text(" is the direction vector of ")#mi("{v_d}")#text(". Furthermore, ")#mi("{w_1,\\ldots,w_{d-1}}")#text(" span a lattice in the ")#mi("{d-1}")#text("-dimensional space ")#mi("{n_d^\\perp}")#text(" of covolume comparable to ")#tao-math("{1/\\left|v_d\\right|}", block: false)#text(".")#linebreak()#text(" For each fixed ")#mi("{v_d}")#text(", the parameters ")#mi("{t_1,\\ldots,t_{d-1}}")#text(" range over a cube of ")#mi("{d-1}")#text("-dimensional Lebesgue measure ")#tao-math("{\\left|v_d\\right|^{d-1}}", block: false)#text(". By induction hypothesis and a rescaling argument, the ")#mi("{w_1,\\ldots,w_{d-1}}")#text(" can be made (after identifying ")#mi("{n_d^\\perp}")#text(" arbitrarily with ")#mi("{{\\bf R}^{d-1}}")#text(") to range over a set of ")#mi("{GL_{d-1}({\\bf R})}")#text(" of Haar measure ")#mi("{O( 1 )}")#text(". By the Fubini-Tonelli theorem (and the rotation-invariance of Lebesgue measure), we may thus cover all the lattices of covolume in ")#mi("{[1,2^d]}")#text(" in ")#mi("{{\\bf R}^d}")#text(" by a subset of ")#mi("{GL_d({\\bf R})}")#text(" of measure at most")

#align(center)[#tao-fit-display[#tao-math("\\int_{v_d \\in {\\bf R}^d: \\left|v_d\\right| = O(1)} \\left|v_d\\right|^{d-1} O( 1 )\\ \\frac{dv_d}{\\left|v_d\\right|}", block: true)]]

#text("which evaluates to ")#mi("{O(1)}")#text(", and the claim follows. ")#mi("\\Box")#linebreak()#text(" Combining this fact with Proposition ")#link(<tao-7310ce7a29303a551ff4>)[#text("46")]#text(", we obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 48")]#text(" ")#metadata(none) <tao-ed7588280ddea2b1a1c8>#text(" For any ")#mi("{d \\geq 1}")#text(", ")#mi("{SL_d({\\bf R})}")#text(" has property (T) if and only if ")#mi("{SL_d({\\bf Z})}")#text(" has property (T).")
]

#text("The usefulness of this corollary lies in the fact that there is a certain asymptotic conjugation argument of Mautner and Moore which is available for connected Lie groups such as ")#mi("{SL_d({\\bf R})}")#text(", but not for discrete groups such as ")#mi("{SL_d({\\bf Z})}")#text(", and allows one to boost the invariance properties of a vector; see Proposition ")#link(<tao-087d1c6fc70c8057fc25>)[#text("60")]#text(" below.")#linebreak()#text(" We will now study the property (T) nature of the special linear group.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 49")]#text(" Another consequence of Proposition ")#link(<tao-7310ce7a29303a551ff4>)[#text("46")]#text(" (and Remark ")#link(<tao-a083e941775650d739e6>)[#text("23")]#text(") is that if a locally compact group ")#mi("{\\tilde G}")#text(" has property (T), then all lattices ")#mi("{G}")#text(" in ")#mi("{\\tilde G}")#text(" are finitely generated; this was one of Kazhdan’s original applications of property (T). (Strictly speaking, one has to modify the proof of Proposition ")#link(<tao-7310ce7a29303a551ff4>)[#text("46")]#text(" to obtain this application, because one is not allowed to assume that ")#mi("{G}")#text(" is compactly generated any more; however, if one inspects the proof, one sees that the set ")#mi("{S}")#text(" in that proof does not need to generate all of ")#mi("{G}")#text(", but merely needs to generate those ")#mi("{h}")#text(" for which ")#mi("{gh}")#text(" lies in the support of ")#mi("{f}")#text(" for some ")#mi("{g \\in K^{\\prime}}")#text(". As this is already a compact set, we can remove the hypothesis that ")#mi("{G}")#text(" is compactly generated.) It is surprisingly difficult to replicate this result for, say, ")#mi("{SL_3({\\bf R})}")#text(", without using property (T) (or something very close to it).")
]

#heading(level: 1)[#strong[#text(" — 3. The special linear group and property (T) — ")]]

#text("The purpose of this section is to prove the following theorem of Kazhdan:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 50")]#text(" ")#metadata(none) <tao-8910e1575d27549aca08>#text(" ")#mi("{SL_d({\\bf R})}")#text(" has property (T) if and only if ")#mi("{d \\neq 2}")#text(".")
]

#text("Combining this theorem with Corollary ")#link(<tao-ed7588280ddea2b1a1c8>)[#text("48")]#text(" and Exercise ")#link(<tao-00fc5bdeb4eca3605a41>)[#text("31")]#text(", we obtain some explicit families of expanders:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 51 (Margulis’ expander construction)")]#text(" ")#metadata(none) <tao-da703cfdff517ed3a5ba>#text(" If ")#mi("{d \\geq 3}")#text(" and ")#mi("{S}")#text(" is a symmetric set of generators of ")#mi("{SL_d({\\bf Z})}")#text(" that does not contain the identity, then the Cayley graphs ")#mi("{Cay( SL_d({\\bf Z}/n{\\bf Z}), \\pi_n(S) )}")#text(" form an expander family, where ")#mi("{\\pi_n: SL_d({\\bf Z}) \\rightarrow SL_d({\\bf Z}/n{\\bf Z})}")#text(" is the obvious projection homomorphism.")
]

#text("We now prove this theorem. We first deal with the ")#mi("{d=1,2}")#text(" cases. The group ")#mi("{SL_1({\\bf R})}")#text(" is trivial and thus has property (T). As for ")#mi("{SL_2({\\bf R})}")#text(", we may rule out property (T) by using the following basic fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 52")]#text(" ")#metadata(none) <tao-1d56363ecacbaf24e8da>#text(" ")#mi("{SL_2({\\bf R})}")#text(" contains a lattice isomorphic to the free group ")#mi("{F_2}")#text(" on two generators.")
]

#text("Indeed, from this lemma, Proposition ")#link(<tao-7310ce7a29303a551ff4>)[#text("46")]#text(", and Exercise ")#link(<tao-7653097b0a56851e687b>)[#text("37")]#text(", we conclude that ")#mi("{SL_2({\\bf R})}")#text(" does not have property (T).")#linebreak()#text(" A proof of the above lemma is given in the exercise below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 53")]#text(" ")#metadata(none) <tao-758d61f26a44448384e5>#text(" Let ")#mi("{\\Gamma}")#text(" be the subgroup of ")#mi("{SL_2({\\bf Z})}")#text(" (and hence of ")#mi("{SL_2({\\bf R})}")#text(") generated by the elements ")#mi("{a := \\begin{pmatrix} 1 & 2 \\\\ 0 & 1\\end{pmatrix}}")#text(" and ")#mi("{b := \\begin{pmatrix} 1 & 0 \\\\ 2 & 1 \\end{pmatrix}}")#text(".")

#list(
[#text("(i) If ")#tao-math("{A := \\{ (x,y) \\in {\\bf R}^2: \\left|x\\right| < \\left|y\\right| \\}}", block: false)#text(" and ")#tao-math("{B := \\{ (x,y) \\in {\\bf R}^2: \\left|x\\right| > \\left|y\\right| \\}}", block: false)#text(", show that ")#mi("{a^n A \\subset B}")#text(" and ")#mi("{b^n B \\subset A}")#text(" for any non-zero integer ")#mi("{n}")#text(", where ")#mi("{SL_2({\\bf R})}")#text(" acts on ")#mi("{{\\bf R}^2}")#text(" in the obvious manner.")],
[#text("(ii) Show that ")#mi("{\\Gamma}")#text(" is a free group on two generators. (")#emph[#text("Hint:")]#text(" use (i) to show that any ")#link("http://en.wikipedia.org/wiki/Reduced_word#Reduced_words")[#text("reduced word")]#text(" of ")#mi("{a,b}")#text(" that both begins and ends with ")#mi("{a^{\\pm 1}}")#text(", or begins and ends with ")#mi("{b^{\\pm 1}}")#text(", is not equal to the identity. This argument is a variant of the ")#link("http://en.wikipedia.org/wiki/Ping-pong_lemma")[#text("ping-pong lemma")]#text(" argument.)")],
[#text("(iii) Show that ")#mi("{\\Gamma}")#text(" has finite index in ")#mi("{SL_2({\\bf Z})}")#text(". (")#emph[#text("Hint:")]#text(" Show that given an element of ")#mi("{SL_2({\\bf Z})}")#text(" with columns ")#mi("{v, w \\in {\\bf Z}^2}")#text(", one can multiply this element on the left by some word in ")#mi("{a,b}")#text(" to minimise the magnitude ")#tao-math("{\\left|v \\cdot w\\right|}", block: false)#text(" of the dot product, until one reaches a point where ")#tao-math("{\\left|v \\cdot w\\right| \\leq \\left\\|v\\right\\|^2, \\left\\|w\\right\\|^2}", block: false)#text(". Now use the Lagrange identity ")#tao-math("{\\left|v \\cdot w\\right|^2 + 1 = \\left\\|v\\right\\|^2 \\left\\|w\\right\\|^2}", block: false)#text(" to conclude that ")#mi("{v, w}")#text(" have bounded size.)")],
[#text("(iv) Establish Lemma ")#link(<tao-1d56363ecacbaf24e8da>)[#text("52")]#text(".")]
)
]

#text("Now we turn to the higher-dimensional cases ")#mi("{d \\geq 3}")#text(". The idea is to first use Fourier analysis to understand the action of various simpler subgroups of ")#mi("{SL_d({\\bf R})}")#text(" acting on a space ")#mi("{H}")#text(" with approximately invariant vectors, and obtain non-trivial vectors that are invariant with respect to those simpler subgroups. Then, we will use an asymptotic conjugation trick of Mautner to boost this invariance up to increasingly larger groups, until we obtain a non-trivial vector invariant under the whole group ")#mi("{SL_d({\\bf R})}")#text(". (As such, this section will presuppose some familiarity with Fourier analysis, as reviewed for instance in ")#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")[#text("this blog post")]#text(".)")#linebreak()#text(" We begin with a preliminary result, reminiscent of property (T) but in the category of probability measures.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 54")]#text(" ")#metadata(none) <tao-15aa4ce43c3fc979bad9>#text(" Let ")#mi("{S}")#text(" be a compact neighbourhood of the identity in ")#mi("{SL_2({\\bf R})}")#text(", and let ")#mi("{\\varepsilon > 0}")#text(". Suppose that ")#mi("{\\mu}")#text(" is a probability measure on ")#mi("{{\\bf R}^2}")#text(" with the property that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| s_* \\mu - \\mu \\right\\|_{TV} \\leq \\varepsilon", block: true)]]

#text("for all ")#mi("{s \\in S}")#text(", where ")#mi("{s}")#text(" acts on ")#mi("{{\\bf R}^2}")#text(" in the obvious manner, ")#mi("{s_* \\mu}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Pushforward_measure")[#text("pushforward")]#text(" of ")#mi("{\\mu}")#text(" by ")#mi("{s}")#text(", and ")#mi("{\\| \\|_{TV}}")#text(" denotes the ")#link("http://en.wikipedia.org/wiki/Total_variation#Total_variation_of_a_measure")[#text("total variation norm")]#text(". Then ")#mi("{\\mu(\\{0\\}) = 1 - O(\\varepsilon)}")#text(", where the implied constant can depend on ")#mi("{S}")#text(".")
]

#emph[#text("Proof:")]#text(" We modify the argument used to establish Exercise ")#link(<tao-758d61f26a44448384e5>)[#text("53")]#text(". (There are many other proofs available, but this one has the advantage of extending without difficulty to the integer setting of ")#mi("{SL_2({\\bf Z})}")#text(".) Let ")#mi("{A, B, a, b}")#text(" be as in that exercise. Then")

#align(center)[#tao-fit-display[#tao-math("\\left\\| a_* \\mu - \\mu \\right\\|_{TV} = O(\\varepsilon)", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\mu(B) \\geq \\mu( a A ) = \\mu( A ) + O(\\varepsilon)")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("\\mu(A) \\geq \\mu( b B ) = \\mu( B ) + O(\\varepsilon).")]]

#text("Putting these estimates together, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\mu(B) = \\mu(a A ) + O(\\varepsilon).")]]

#text("Similarly one has")

#align(center)[#tao-fit-display[#mitex("\\mu(B) = \\mu(a^2 A) + O(\\varepsilon).")]]

#text("Since")

#align(center)[#tao-fit-display[#tao-math("B \\backslash a^2 A \\supset \\{ (x,y) \\in {\\bf R}^2: \\left|y\\right| < \\left|x\\right| \\leq 3\\left|y\\right| \\},", block: true)]]

#text("we conclude that the set ")#tao-math("{\\{ (x,y) \\in {\\bf R}^2: \\left|y\\right| < \\left|x\\right| \\leq 3\\left|y\\right| \\}}", block: false)#text(" has measure ")#mi("{O(\\varepsilon)}")#text(". Translating this set around by a finite number of explicit elements of ")#mi("{SL_2({\\bf R})}")#text(", we conclude that ")#mi("{\\mu( {\\bf R}^2 \\backslash \\{0\\} ) = O(\\varepsilon)}")#text(", and the claim follows. ")#mi("\\Box")#linebreak()#text(" Now we use Fourier analysis to pass from probability measures back to Hilbert spaces. We will need a fundamental result from abstract harmonic analysis, namely ")#link("http://en.wikipedia.org/wiki/Bochner%27s_theorem")[#text("Bochner’s theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 55 (Bochner’s theorem for ")#mi("{{\\bf R}^d}")#text(")")]#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be a bounded continuous function which is positive semi-definite, in the sense that ")#mi("{f(x)=\\overline{f(-x)}}")#text(" for all ")#mi("{x \\in {\\bf R}^d}")#text(", and ")#metadata(none) <tao-7cf6b0597fe4e3cb3559>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\int_{{\\bf R}^d} \\int_{{\\bf R}^d} f(x-y)\\ d\\nu(x) d\\overline{\\nu}(y) \\geq 0")]]

#text("for all finite complex measures ")#mi("{\\nu}")#text(". Then there exists a non-negative finite measure ")#mi("{\\mu}")#text(" on ")#mi("{{\\bf R}^d}")#text(" such that ")#mi("{f}")#text(" is the inverse Fourier transform of ")#mi("{\\mu}")#text(", in the sense that")

#align(center)[#tao-fit-display[#mitex("f(x) = \\int_{{\\bf R}^d} e^{2\\pi i x \\cdot \\xi}\\ d\\mu(\\xi)")]]

#text("for all ")#mi("{x \\in {\\bf R}^d}")#text(".")
]

#emph[#text("Proof:")]#text(" Suppose first that ")#mi("{f}")#text(" was square-integrable. Then by Plancherel’s theorem, there is a square-integrable Fourier transform ")#mi("{\\hat f}")#text(" for which one has")

#align(center)[#tao-fit-display[#mitex("f(x) = \\int_{{\\bf R}^d} e^{2\\pi i x \\cdot \\xi} \\hat f(\\xi)\\ d\\xi")]]

#text("in the sense of tempered distributions (or in an ")#mi("{L^2}")#text(" approximation sense). From ")#link(<tao-7cf6b0597fe4e3cb3559>)[#text("(7)")]#text(" (applied to a smooth measure ")#mi("{d\\nu(x) = g(x)\\ dx}")#text(") and standard Fourier identities, one then has")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^d} \\hat f(\\xi) \\left|\\hat g(\\xi)\\right|^2\\ d\\xi \\geq 0", block: true)]]

#text("for any Schwartz function ")#mi("{\\hat g}")#text(". From this and the Lebesgue differentiation theorem we see that ")#mi("{\\hat f}")#text(" is non-negative almost everywhere. By testing ")#mi("{f}")#text(" against an approximation ")#mi("{R^d \\phi(Rx)}")#text(" to the identity, we also see from the continuity of ")#mi("{f}")#text(" that")

#align(center)[#tao-fit-display[#mitex("f(0) = \\lim_{R \\rightarrow \\infty} \\int_{{\\bf R}^d} \\hat f(\\xi) \\hat \\phi(\\xi/R)\\ d\\xi")]]

#text("which (after choosing ")#mi("{\\phi}")#text(" to have non-negative Fourier transform) we see that ")#mi("{\\hat f}")#text(" is absolutely integrable. Setting ")#mi("{d\\mu(\\xi) := \\hat f(\\xi)\\ d\\xi}")#text(", one obtains the claim.")#linebreak()#text(" Now we consider the general case. We consider a truncation ")#mi("{f_R(x) := f(x) \\psi(x/R)}")#text(" of ")#mi("{f}")#text(" for some large ")#mi("{R>0}")#text(", where ")#mi("{\\psi = \\eta * \\eta}")#text(" and ")#mi("{\\eta}")#text(" is a real even Schwartz function with unit ")#mi("{L^2}")#text(" norm. From the identity")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^d} \\int_{{\\bf R}^d} f_R(x-y)\\ d\\nu(x) d\\overline{\\nu}(y) = \\int_{{\\bf R}^d} \\left|\\hat \\eta(\\xi)\\right|^2 \\int_{{\\bf R}^d} f_R(x-y)\\ e^{2\\pi i \\xi \\cdot x}d \\nu(x) e^{-2\\pi i \\xi \\cdot y} d\\overline{\\nu}(y)", block: true)]]

#text("we see that ")#mi("{f_R}")#text(" is also positive semi-definite, and is thus the Fourier transform of a finite non-negative measure ")#mi("{\\mu_R}")#text(", with ")#mi("{\\mu_R({\\bf R}^d) = f_R(0) = f(0)}")#text(". Since the ")#mi("{f_R}")#text(" converge in the sense of tempered distributions to ")#mi("{f}")#text(", ")#mi("{\\mu_R}")#text(" must converge in distribution to the distributional Fourier transform of ")#mi("{f}")#text(". In particular, by the Riesz representation theorem, ")#mi("{\\hat f}")#text(" must be another finite non-negative measure, and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 56")]#text(" Bochner’s theorem can be extended to arbitrary locally compact abelian groups, and this fact can be used to build the foundation of Fourier analysis on such groups; see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=1038803")[#text("this text of Rudin")]#text(" for details. (Note though that in order to do this without circularity, one needs a different proof than the one above, which presupposes Plancherel’s theorem, which in the case of general locally compact abelian groups is usually proven using Bochner’s theorem.) There are several substitutes for Fourier analysis that can serve this purpose, such as spectral theory or the Gelfand theory of ")#mi("{C^*}")#text(" algebras, but we will not discuss these topics here.")
]

#text("We can use Bochner’s theorem to analyse unitary representations ")#mi("{\\rho: {\\bf R}^d \\rightarrow U(H)}")#text(" of Euclidean groups. (Actually, much the same analysis will apply to unitary representations of arbitrary locally compact abelian groups, but we will only need to work with ")#mi("{{\\bf R}^d}")#text(" (and more specifically, ")#mi("{{\\bf R}^2}")#text(") here.) Given a vector ")#mi("{v}")#text(" in the Hilbert space ")#mi("{H}")#text(", we consider the associated autocorrelation function ")#mi("{f_{v,v}: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" defined by the formula")

#align(center)[#tao-fit-display[#mitex("f_{v,v}(x) := \\langle \\rho(x) v, v \\rangle_H")]]

#text("This is a continuous bounded function of ")#mi("{{\\bf R}^d}")#text(", and from the identity")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^d} \\int_{{\\bf R}^d} f_{v,v}(x-y)\\ d\\nu(x) d\\overline{\\nu}(y) = \\left\\| \\int_{\\bf R} \\rho(x) v\\ d\\nu(x) \\right\\|_H^2", block: true)]]

#text("we see that it is positive semi-definite. Thus, by Bochner’s theorem, there exists a non-negative finite measure ")#mi("{\\mu_{v,v}}")#text(" whose inverse Fourier transform is ")#mi("{f_{v,v}}")#text(", thus ")#metadata(none) <tao-3c98f2b565373ba9d8ec>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\langle \\rho(x) v, v \\rangle_H = \\int_{{\\bf R}^d} e^{2\\pi i x \\cdot \\xi}\\ d\\mu_{v,v}(\\xi).")]]

#text("In particular, ")#mi("{\\mu_{v,v}}")#text(" has total mass ")#tao-math("{\\left\\|v\\right\\|_H^2}", block: false)#text(". From a quantum mechanical viewpoint, one can view ")#mi("{\\mu_{v,v}}")#text(" as the probability distribution of the momentum of ")#mi("{v}")#text(" (now viewed as a quantum state, and normalising ")#mi("{v}")#text(" to be a unit vector).")#linebreak()#text(" By depolarisation, we can then assign a complex finite measure ")#mi("{\\mu_{v,w}}")#text(" to any pair of vectors ")#mi("{v,w \\in H}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\langle \\rho(x) v, w \\rangle_H = \\int_{{\\bf R}^d} e^{2\\pi i x \\cdot \\xi}\\ d\\mu_{v,w}(\\xi).")]]

#text("Indeed, one can explicitly define ")#mi("{\\mu_{v,w}}")#text(" using the ")#link("http://en.wikipedia.org/wiki/Polarization_identity")[#text("polarisation identity")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\mu_{v,w} := \\frac{1}{4}( \\mu_{v+w,v+w} - \\mu_{v-w,v-w} + i \\mu_{v+iw,v+iw} - i \\mu_{v-iw,v-iw} ).")]]

#text("By the uniqueness of Fourier inversion, we see that ")#mi("{\\mu_{v,w}}")#text(" is uniquely determined by ")#mi("{v,w}")#text(", and is sesquilinear with respect to these inputs. By depolarising with the right normalisations, we see that this measure has total mass ")#tao-math("{O(\\left\\|v\\right\\|_H \\left\\|w\\right\\|_H)}", block: false)#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 57 (Functional calculus)")]#text(" Show that for any bounded Borel-measurable function ")#mi("{m: {\\bf R}^d \\rightarrow {\\bf C}}")#text(", there is a bounded operator ")#mi("{m(\\rho): H \\rightarrow H}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\langle m(\\rho) v, w \\rangle = \\int_{{\\bf R}^d} m(\\xi) d\\mu_{v,w}(\\xi)")]]

#text("for all unit vectors ")#mi("{v, w}")#text(", with the operator norm of ")#mi("{m(\\rho)}")#text(" bounded by the supremum norm of ")#mi("{m}")#text(". Furthermore, show the map ")#mi("{m \\mapsto m(\\rho)}")#text(" is a *-homomorphism of ")#link("http://en.wikipedia.org/wiki/*-algebra")[#text("*-algebras")]#text(". In particular, for any Borel set ")#mi("{E}")#text(", the operator ")#mi("{\\mu(E) := 1_E(\\rho)}")#text(" is an orthogonal projection on ")#mi("{H}")#text(". Show that ")#mi("{\\mu}")#text(" is a countably additive measure taking values as orthogonal projections on ")#mi("{H}")#text(", with ")#mi("{\\mu({\\bf R}^d)}")#text(" equal to the identity operator on ")#mi("{H}")#text(". Define a notion of integration with respect to such measures in such a way that one has the identities")

#align(center)[#tao-fit-display[#mitex("\\rho(x) = \\int_{{\\bf R}^d} e^{2\\pi i x \\cdot \\xi}\\ d\\mu(\\xi)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("m(\\rho) = \\int_{{\\bf R}^d} m(\\xi)\\ d\\mu(\\xi)")]]

#text("for all ")#mi("{x \\in {\\bf R}^d}")#text(" and bounded Borel-measurable ")#mi("{m}")#text(". (This exercise is not explicitly used in the sequel, though the functional calculus perspective is definitely lurking beneath the surface in the arguments below. One can use the results of this exercise to establish ")#link("http://en.wikipedia.org/wiki/Stone's_theorem_on_one-parameter_unitary_groups")[#text("Stone’s theorem on one-parameter groups")]#text(", but we will not do so here.)")
]

#text("Now we can obtain a relative version of property (T), relating the Euclidean group ")#mi("{{\\bf R}^2}")#text(" with the semi-direct product ")#mi("{SL_2({\\bf R}) \\ltimes {\\bf R}^2}")#text(", defined in the obvious manner.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 58")]#text(" ")#metadata(none) <tao-01a74a26c138ee4c998f>#text(" Let ")#mi("{S}")#text(" be a compact neighbourhood of the identity in ")#mi("{SL_2({\\bf R}) \\ltimes {\\bf R}^2}")#text(", and let ")#mi("{\\rho: SL_2({\\bf R}) \\ltimes {\\bf R}^2 \\rightarrow U(H)}")#text(" be a unitary representation. If ")#mi("{Kaz( SL_2({\\bf R}) \\ltimes {\\bf R}^2, S, H )}")#text(" is sufficiently small depending on ")#mi("{S}")#text(", then ")#mi("{H}")#text(" contains a non-trivial ")#mi("{{\\bf R}^2}")#text("-invariant vector.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 59")]#text(" Another way of stating the conclusion of this proposition is that the pair ")#mi("{(SL_2({\\bf R}) \\ltimes {\\bf R}^2, {\\bf R}^2)}")#text(" of locally compact groups has relative property (T). See the ")#link("http://perso.univ-rennes1.fr/bachir.bekka/KazhdanTotal.pdf")[#text("text of Bekka, de la Harpe, and Valette")]#text(" for a more thorough discussion of this property.")
]

#emph[#text("Proof:")]#text(" Suppose that ")#mi("{Kaz( SL_2({\\bf R}) \\ltimes {\\bf R}^2, S, H ) < \\varepsilon}")#text(" for some sufficiently small ")#mi("{\\varepsilon>0}")#text(", then there is a unit vector ")#mi("{v}")#text(" in ")#mi("{H}")#text(" such that ")#tao-math("{\\left\\|\\rho(s)v-v\\right\\|_H \\leq \\varepsilon}", block: false)#text(" for all ")#mi("{s \\in S}")#text(". Now let ")#mi("{g}")#text(" be an element of ")#mi("{SL_2({\\bf R})}")#text(" (which we can view as a subgroup of ")#mi("{SL_2({\\bf R}) \\ltimes {\\bf R}^2}")#text(", and similarly for ")#mi("{{\\bf R}^2}")#text("). Observe that")

#align(center)[#tao-fit-display[#mitex("\\langle \\rho(x) \\rho(g) v, \\rho(g) v \\rangle_H = \\langle \\rho(g(x)) v , v \\rangle_H")]]

#text("for all ")#mi("{x \\in {\\bf R}^2}")#text(". Comparing this with the Fourier inversion formula ")#link(<tao-3c98f2b565373ba9d8ec>)[#text("(8)")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("\\mu_{\\rho(g)v,\\rho(g)v} = (g^*)_* \\mu_{v,v},")]]

#text("where ")#mi("{(g^*)_*}")#text(" is the pushforward by the adjoint ")#mi("{g^*}")#text(" of ")#mi("{g}")#text(". By the sesquilinearity and boundedness of ")#mi("{\\mu_{v,w}}")#text(", we thus see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (g^*)_* \\mu_{v,v} - \\mu_{v,v} \\right\\|_{TV} \\ll \\left\\| \\rho(g) v - v \\right\\|_H.", block: true)]]

#text("By Lemma ")#link(<tao-15aa4ce43c3fc979bad9>)[#text("54")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\mu_{v,v}(\\{0\\}) \\geq 1 - O(\\varepsilon)")]]

#text("which, by ")#link(<tao-3c98f2b565373ba9d8ec>)[#text("(8)")]#text(", implies that")

#align(center)[#tao-fit-display[#mitex("\\langle \\rho(x) v, v \\rangle_H = 1 - O(\\varepsilon)")]]

#text("for all ")#mi("{x \\in {\\bf R}^2}")#text(". Using Exercise ")#link(<tao-cac729832e48d8a3b24a>)[#text("32")]#text(", we conclude that ")#mi("{H}")#text(" has a non-trivial ")#mi("{{\\bf R}^2}")#text("-invariant vector, as claimed. ")#mi("\\Box")#linebreak()#text(" The above proposition gives a vector which is invariant with respect to the action of an abelian group, namely ")#mi("{{\\bf R}^2}")#text(". The next lemma, using an argument of Moore exploiting an asymptotic conjugation idea of Mautner, shows how to boost invariance from a small abelian group to a larger non-abelian group. We will only need this argument in the context of ")#mi("{SL_2({\\bf R})}")#text(", and using the three subgroups")

#tao-aligned(keep: true)[


#tao-math("U^+  & := \\{ u_+(t) : t \\in {\\bf R} \\}", block: true)



#tao-math("D  & := \\{ d(t): t \\in {\\bf R} \\}", block: true)



#tao-math("U^-  & := \\{ u_-(t): t \\in {\\bf R} \\}", block: true)
]

#text("of ")#mi("{SL_2({\\bf R})}")#text(", where")

#tao-aligned(keep: true)[


#tao-math("u_+(t)  & := \\begin{pmatrix} 1 & t \\\\ 0 & 1 \\end{pmatrix}", block: true)



#tao-math("d(t)  & := \\begin{pmatrix} e^t & 0 \\\\ 0 & e^{-t} \\end{pmatrix}", block: true)



#tao-math("u_-(t)  & := \\begin{pmatrix} 1 & 0 \\\\ t & 1 \\end{pmatrix}.", block: true)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 60 (Mautner phenomenon)")]#text(" ")#metadata(none) <tao-087d1c6fc70c8057fc25>#text(" Let ")#mi("{\\rho: SL_2({\\bf R}) \\rightarrow U(H)}")#text(" be a unitary representation. Then any vector ")#mi("{v}")#text(" which is ")#mi("{U^+}")#text("-invariant, is also ")#mi("{SL_2({\\bf R})}")#text(" invariant.")
]

#emph[#text("Proof:")]#text(" The main idea (")#link("http://www.ams.org/mathscinet-getitem?mr=193188")[#text("due to Moore")]#text(") is to show that ")#mi("{D}")#text(" can be approximated by double cosets ")#mi("{U^+ u_-(\\varepsilon) U^+}")#text(" for ")#mi("{\\varepsilon}")#text(" arbitrarily small. More precisely, we will use the identity")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} e^t & 0 \\\\ \\varepsilon & e^{-t} \\end{pmatrix} = u_+(\\frac{e^t-1}{\\varepsilon}) u_-(\\varepsilon) u_+( \\frac{e^{-t}-1}{\\varepsilon} ) \\in U^+ u_-(\\varepsilon) U^+")]]

#text("for any ")#mi("{t \\in {\\bf R}}")#text(" and ")#mi("{\\varepsilon > 0}")#text(". In particular, from the ")#mi("{U^+}")#text("-invariance of ")#mi("{v}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\langle \\rho(\\begin{pmatrix} e^t & 0 \\\\ \\varepsilon & e^{-t} \\end{pmatrix}) v, v \\rangle_H = \\langle u_-(\\varepsilon) v, v \\rangle_H.")]]

#text("Sending ")#mi("{\\varepsilon \\rightarrow 0}")#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("\\langle d(t) v, v \\rangle_H = \\langle v, v \\rangle_H;")]]

#text("since ")#mi("{d(t) v}")#text(" has the same length as ")#mi("{v}")#text(", we conclude that ")#mi("{d(t) v = v}")#text(", thus ")#mi("{v}")#text(" is ")#mi("{D}")#text("-invariant. Now we use a similar ")#link("http://www.ams.org/mathscinet-getitem?mr=84823")[#text("argument of Mautner")]#text(" to finish up. Starting with the identity")

#align(center)[#tao-fit-display[#mitex("d(t) u_-(s) d(-t) = u_-(e^{-t} s)")]]

#text("for ")#mi("{s,t \\in {\\bf R}}")#text(", we see from the ")#mi("{D}")#text("-invariance of ")#mi("{v}")#text(" that")

#align(center)[#tao-fit-display[#mitex("\\langle u_-(s) v, v \\rangle = \\langle u_-(e^{-t} s) v, v \\rangle.")]]

#text("Sending ")#mi("{t \\rightarrow \\infty}")#text(" and arguing as before we conclude that ")#mi("{v}")#text(" is also ")#mi("{U^-}")#text("-invariant. Since ")#mi("{U^+, D, U^-}")#text(" generate ")#mi("{SL_2({\\bf R})}")#text(", the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 61")]#text(" As a corollary of the above proposition, we see that if a probability space ")#mi("{(X,\\mu)}")#text(" with a measure-preserving action of ")#mi("{SL_2({\\bf R})}")#text(" is ergodic with respect to the ")#mi("{SL_2({\\bf R})}")#text(" action (in the sense that all ")#mi("{SL_2({\\bf R})}")#text("-invariant sets have either full measure or zero measure, or equivalently that ")#mi("{L^2(X,\\mu)_0}")#text(" has no non-trivial ")#mi("{SL_2({\\bf R})}")#text("-invariant vectors), then it is necessarily ergodic with respect to the ")#mi("{U^+}")#text(" action as well. Thus, for instance, the action of ")#mi("{U^+}")#text(" on ")#mi("{SL_2({\\bf R})/SL_2({\\bf Z})}")#text(" (which is known as the horocycle flow) is ergodic. This is a special case of an ")#link("http://www.ams.org/mathscinet-getitem?mr=193188")[#text("ergodic theorem of Moore")]#text(".")
]

#text("We can now establish that ")#mi("{SL_3({\\bf R})}")#text(" has property (T) by navigating between various subgroups of that group. Indeed, let ")#mi("{S}")#text(" be a compact neighbourhood of the identity in ")#mi("{SL_3({\\bf R})}")#text(", and suppose that ")#mi("{\\rho: SL_3({\\bf R}) \\rightarrow U(H)}")#text(" is a unitary representation with ")#mi("{Kaz(SL_3({\\bf R}),S,\\rho)}")#text(" sufficiently small. We need to show that ")#mi("{H}")#text(" contains an ")#mi("{SL_3({\\bf R})}")#text("-invariant vector. To do this, we first note that ")#mi("{SL_3({\\bf R})}")#text(" contains a copy of the semi-direct product ")#mi("{SL_2({\\bf R}) \\ltimes {\\bf R}^2}")#text(", namely the space of all matrices in ")#mi("{SL_3({\\bf R})}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} * & * & * \\\\ * & * & * \\\\ 0 & 0 & 1 \\end{pmatrix}")]]

#text("where the entries marked ")#mi("{*}")#text(" are unconstrained (beyond the ")#mi("{SL_3}")#text(" requirement that the entire matrix have determinant ")#mi("{1}")#text("). Applying Proposition ")#link(<tao-01a74a26c138ee4c998f>)[#text("58")]#text(", we conclude that ")#mi("{H}")#text(" contains a non-trivial vector ")#mi("{v}")#text(" which is invariant with respect to the matrices of the form ")#metadata(none) <tao-ee96e48ac867ab59efb6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\begin{pmatrix} 1 & 0 & * \\\\ 0 & 1 & * \\\\ 0 & 0 & 1 \\end{pmatrix}.")]]

#text("Now we work with a copy of ")#mi("{SL_2({\\bf R})}")#text(" in ")#mi("{SL_3({\\bf R})}")#text(", namely the matrices in ")#mi("{SL_3({\\bf R})}")#text(" of the form ")#metadata(none) <tao-fdb65620079bc01a7e21>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\begin{pmatrix} * & 0 & * \\\\ 0 & 1 & 0 \\\\ * & 0 & * \\end{pmatrix}.")]]

#text("The associated copy of ")#mi("{U^+}")#text(" here is a subgroup of the matrices of the form ")#link(<tao-ee96e48ac867ab59efb6>)[#text("(9)")]#text(". Applying Proposition ")#link(<tao-087d1c6fc70c8057fc25>)[#text("60")]#text(", we see that ")#mi("{v}")#text(" is invariant under the matrices in ")#mi("{SL_3({\\bf R})}")#text(" of the form ")#link(<tao-ee96e48ac867ab59efb6>)[#text("(9)")]#text(". A similar argument shows that ")#mi("{v}")#text(" is also invariant with respect to matrices in ")#mi("{SL_3({\\bf R})}")#text(" of the form ")#metadata(none) <tao-4655cbf91ceb975c7e5d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\begin{pmatrix} 1 & 0 & 0 \\\\ 0 & * & * \\\\ 0 & * & * \\end{pmatrix}.")]]

#text("But it is easy to see (e.g. by working with the Lie algebras) that ")#link(<tao-fdb65620079bc01a7e21>)[#text("(10)")]#text(", ")#link(<tao-4655cbf91ceb975c7e5d>)[#text("(11)")]#text(" generate all of ")#mi("{SL_3({\\bf R})}")#text(", and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 62")]#text(" Adapt the above argument to larger values of ")#mi("{d}")#text(" to finish the proof of Theorem ")#link(<tao-8910e1575d27549aca08>)[#text("50")]#text(". (")#emph[#text("Hint:")]#text(" one either has to extend Lemma ")#link(<tao-15aa4ce43c3fc979bad9>)[#text("54")]#text(" to higher dimensions, or else use a version of the Mautner argument to boost invariance with respect to, say, a copy of ")#mi("{SL_3({\\bf R})}")#text(", to invariance with respect to larger subgroups of ")#mi("{SL_d({\\bf R})}")#text(".)")
]

#heading(level: 1)[#strong[#text(" — 4. A more elementary approach (optional) — ")]]

#text("In Corollary ")#link(<tao-da703cfdff517ed3a5ba>)[#text("51")]#text(" we constructed an explicit family of expander graphs, but the verification of the expander graph property was quite complicated, involving for instance the theory of induced representations, Bochner’s theorem, the Riesz representation theorem, and many other tools besides. It turns out that this is overkill; if all one wants to do is construct expanders (as opposed to establishing property (T) for various groups), one can skip much of the above theory and establish expansion by more elementary methods (one still needs some Fourier analysis, but now just for finite abelian groups). In this section we outline this approach, following ")#link("http://www.ams.org/mathscinet-getitem?mr=633542")[#text("the work of Gabber-Galil")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=931192")[#text("Jimbo-Maruocka")]#text(", as presented in ")#link("http://www.ams.org/mathscinet-getitem?mr=2247919")[#text("the survey of Hoory, Linial, and Wigderson")]#text(".")#linebreak()#text(" To avoid the need to exploit Mautner’s phenomenon, the example is based on the semi-direct product ")#mi("{SL_2({\\bf R}) \\ltimes {\\bf R}^2}")#text(" (or more accurately, the lattice ")#mi("{SL_2({\\bf Z}) \\ltimes {\\bf Z}^2}")#text(") rather than ")#mi("{SL_d({\\bf R})}")#text(" or ")#mi("{SL_d({\\bf Z})}")#text(". More precisely, we show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 63")]#text(" Let ")#mi("{S}")#text(" be a symmetric finite set generating ")#mi("{SL_2({\\bf Z}) \\ltimes {\\bf Z}^2}")#text(". Then the Schreier graphs ")#mi("{Sch( ({\\bf Z}/n{\\bf Z})^2, \\pi_n(S) )}")#text(" form an one-sided expander family, where ")#mi("{\\pi_n: SL_2({\\bf Z}) \\ltimes {\\bf Z}^2 \\rightarrow SL_2({\\bf Z}/n{\\bf Z}) \\ltimes ({\\bf Z}/n{\\bf Z})^2}")#text(" is the obvious projection homomorphism. (Here, we allow the Schreier graphs to contain loops or repeated edges; one has to check that the theory of expander graphs used here extends to this setting, but this is routine and will be glossed over here.)")
]

#text("One can deduce this theorem from Proposition ")#link(<tao-01a74a26c138ee4c998f>)[#text("58")]#text(" and (a relative version of) Proposition ")#link(<tao-7310ce7a29303a551ff4>)[#text("46")]#text(". We will not do so here, but instead establish the theorem directly. We first need a discrete variant of Lemma ")#link(<tao-15aa4ce43c3fc979bad9>)[#text("54")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 64")]#text(" ")#metadata(none) <tao-e2bf957ddcf6019616ab>#text(" Let ")#mi("{S}")#text(" be a finite generating subset of ")#mi("{SL_2({\\bf Z})}")#text(", and let ")#mi("{\\varepsilon > 0}")#text(". Suppose that ")#mi("{\\mu}")#text(" is a probability measure on ")#mi("{{\\bf Z}^2}")#text(" with the property that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| s_* \\mu - \\mu \\right\\|_{TV} \\leq \\varepsilon", block: true)]]

#text("for all ")#mi("{s \\in S}")#text(", where ")#mi("{s}")#text(" acts on ")#mi("{{\\bf Z}^2}")#text(" in the obvious manner. Show that ")#mi("{\\mu(\\{0\\}) = 1 - O(\\varepsilon)}")#text(", where the implied constant can depend on ")#mi("{S}")#text(".")
]

#text("Now we prove the theorem. Suppose for contradiction that the Schreier graphs do not form a one-sided expander family. Then we obtain a family of nearly invariant vectors:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 65")]#text(" With the above assumption, show that after passing to a subsequence of ")#mi("{n}")#text("‘s, one can find a sequence ")#mi("{f_n \\in \\ell^2( ({\\bf Z}/n{\\bf Z})^2 )}")#text(" of mean zero functions of ")#mi("{\\ell^2}")#text(" norm ")#mi("{1}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\sup_{s \\in S} \\left\\| \\rho_n(s) f_n - f_n \\right\\|_{\\ell^2(({\\bf Z}/n{\\bf Z})^2)} = o(1),", block: true)]]

#text("where ")#mi("{\\rho_n}")#text(" is the quasiregular representation of ")#mi("{SL_2({\\bf Z}) \\ltimes {\\bf Z}^2}")#text(" on ")#mi("{({\\bf Z}/n{\\bf Z})^2}")#text(", and ")#mi("{o(1)}")#text(" denotes a quantity that goes to zero as ")#mi("{n \\rightarrow \\infty}")#text(".")
]

#text("Let ")#mi("{f_n}")#text(" be as in the above exercise. If we let ")#mi("{e_1, e_2}")#text(" be the generators of the translation group ")#mi("{{\\bf Z}^2}")#text(", we see in particular that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\rho_n(e_j) f_n - f_n \\right\\|_{\\ell^2(({\\bf Z}/n{\\bf Z})^2)} = o(1)", block: true)]]

#text("for ")#mi("{j=1,2}")#text(". If we then introduce the finite Fourier transform")

#align(center)[#tao-fit-display[#mitex("\\hat f_n(\\xi_1,\\xi_2) := \\frac{1}{n} \\sum_{x_1,x_2 \\in {\\bf Z}/n{\\bf Z}} f_n(x_1,x_2) e^{-2\\pi i (x_1 \\xi_1 + x_2 \\xi_2)/n},")]]

#text("normalised to be an isometry on ")#mi("{\\ell^2(({\\bf Z}/n{\\bf Z})^2)}")#text(", we conclude from Plancherel’s theorem that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (e^{-2\\pi i \\xi_j /n}-1) \\hat f_n(\\xi_1,\\xi_2) \\right\\|_{\\ell^2_{\\xi_1,\\xi_2}(({\\bf Z}/n{\\bf Z})^2)} = o(1).", block: true)]]

#text("In particular, we can find a ball ")#mi("{B_n}")#text(" of radius ")#mi("{o(n)}")#text(" centred at the origin in ")#mi("{({\\bf Z}/n{\\bf Z})^2}")#text(" on which ")#mi("{f_n}")#text(" concentrates almost all of its ")#mi("{\\ell^2}")#text(" mass:")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\hat f_n \\right\\|_{\\ell^2( ({\\bf Z}/n{\\bf Z})^2 \\backslash B_n )} = o(1).", block: true)]]

#text("Let ")#mi("{g_n \\in \\ell^2({\\bf Z}^2)}")#text(" be the restriction of ")#mi("{\\hat f_n}")#text(" to ")#mi("{B_n}")#text(", which one then identifies with a subset of ")#mi("{{\\bf Z}^2}")#text(". Then we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g_n\\right\\|_{\\ell^2({\\bf Z}^2)} = 1-o(1).", block: true)]]

#text("If ")#mi("{s}")#text(" is any fixed element of ")#mi("{SL_2({\\bf Z})}")#text(", then we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\rho_n(s) f_n - f_n \\right\\|_{\\ell^2(({\\bf Z}/n{\\bf Z})^2)} = o(1)", block: true)]]

#text("and thus by Fourier duality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\hat f_n \\circ s^* - \\hat f_n \\right\\|_{\\ell^2(({\\bf Z}/n{\\bf Z})^2)} = o(1).", block: true)]]

#text("Restricting to ")#mi("{B_n}")#text(" and then embedding into ")#mi("{{\\bf Z}^2}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| g_n \\circ s^* - g_n \\right\\|_{\\ell^2({\\bf Z}^2)} = o(1).", block: true)]]

#text("Applying Exercise ")#link(<tao-e2bf957ddcf6019616ab>)[#text("64")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("g_n(0) = 1 - o(1).")]]

#text("But as the ")#mi("{f_n}")#text(" have mean zero, we have ")#mi("{g_n(0)=0}")#text(", giving the desired contradiction.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 66")]#text(" One advantage of this more elementary approach is that it is easier to obtain explicit bounds on the expansion constant of these graphs; see ")#link("http://www.ams.org/mathscinet-getitem?mr=931192")[#text("the paper of Jimbo-Marouka")]#text(" for details.")
]

#heading(level: 1)[#text("Comments (30)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/adaf83934ef9e83041fdd0b5ad16e455b02b1c2e6eb01568a16f9884d8d5f8fd-4cb33d494f6365ff4f85492980c809be6fde69086d5ddfee0bef924d0a084420.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-113308")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2011")])]

#text("Not sure if it’s just me, but at the top of section 2 the Heisenberg group and commutator subgroup matrices are missing the field entries. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a78adda74a503d08a066be0168d70769742e6c3ca5e1cfff877ca98a0fcd7ef7-27a2abd070cf49146795a5a0638ac7174fc2dbd13bdbe91bf3ecfcf28ff20833.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cristina")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-113551")[#strong[#text("Cristina")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2011")])]

#text("In Definition 2 (Schreier graph), last line, in the set of edges, x should be from X, not G. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4259f5b59b4e7a54ecd7595690a54c8e5d51f8952c5473e634b40275c841ddb-208c5aa391ce87553ec1b820b6b558ff273d6b839a07a6e548aee99a6fefb808.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan O'Donnell")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-113687")[#strong[#text("Ryan O'Donnell")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2011")])]

#text("Marouka -> Maruoka ")#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed443d8a11784c5982f0b00db9d6e57690f7cc863fb7396ea292b24f4fd574cd-b10cb900580c30ca3df78ffbb919dd4350ef5dfed17e13b62581b02831e2799a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-113891")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2011")])]

#text("Dear Terry,")

#text("I must confess I am slightly confused by Exercise 21.")

#text("* In part (ii), shouldn’t the norm be e^{-epsilon |v-w|^2}, without the “1-” in front (and perhaps require v and w to be unit vectors)? Presumably you want the delta functions associated to v and w to have *large* inner product if v and w are close to each other.")#linebreak()#text(" * Also in part (ii): is it easy to see that the closure of the orbit (and not just the orbit itself) must live in something separable?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-113901")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2011")])]

#text("Oops, that was a mistake on my part (I was thinking of ")#tao-math("\\left\\|\\delta_v-\\delta_w\\right\\|_{\\tilde H}^2", block: false)#text(" rather than ")#mi("\\langle \\delta_v, \\delta_w \\rangle_{\\tilde H}")#text(".)")

#text("The closure of a separable space is again separable, so I don’t see any difficulty to pass from the orbit to its closure (or more precisely, to the closure of its linear span). Actually, now that I look over the argument again, I see that as H was already separable, ")#mi("\\tilde H")#text(" will be also, so this point is actually moot…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed443d8a11784c5982f0b00db9d6e57690f7cc863fb7396ea292b24f4fd574cd-b10cb900580c30ca3df78ffbb919dd4350ef5dfed17e13b62581b02831e2799a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-114019")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2011")])]

#text("Yes, I was being silly on the second point. (Reason: I could not get out of my head the picture of a vector being pushed around a circle until the average of the delta functions of the images of the vector converged weakly to the circle’s measure. Presumably this doesn’t happen because of the funny norm.)")

#text("In Exercise 15, v\\in G should be v\\in H.")

#text("In the proof of Lemma 15, do you really need the ping-pong elements? Don’t you just need to bound mu on an angle at the origin – and can you cover that just by using a map a that shrinks one eigenvector and stretches the other one?")

#emph[#text("[Corrected, thanks. It is true that one can also use a single semisimple element instead of a pair of unipotent elements to demonstrate Lemma 15, but the argument given has the advantage of also working without any change over the integers. (Of course, there are also non-trivial semisimple elements in SL_2(Z), but the numerology becomes a bit uglier.) Also, I wanted to highlight the role of ping pong arguments, which tend to be a particularly flexible method (as one in principle has the entire free group to work with).) – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed443d8a11784c5982f0b00db9d6e57690f7cc863fb7396ea292b24f4fd574cd-b10cb900580c30ca3df78ffbb919dd4350ef5dfed17e13b62581b02831e2799a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald Helfgott")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-114304")[#strong[#text("Harald Helfgott")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2011")])]

#text("Where is exercise 24 being used? In the line before it – can you write down the depolarization in full? It’s not obvious to me how to distinguish the contribution of from that of .")

#emph[#text("[I’m guessing that the HTML parser ate your < and > signs; you have to use &lt; and &gt; instead. Anyways, I edited the text to include the explicit depolarisation identity. I wrote the notes in such a way that the functional calculus is not actually used to the arguments, although traditionally it is used for this purpose (i.e. one analyses the invariance properties of the projection-valued spectral measure ")#mi("\\mu")#text(", rather than its various components ")#mi("\\mu_{v,v}")#text(" or ")#mi("\\mu_{v,w}")#text("). That way the arguments become a little bit more elementary, though the simplification is admittedly minor. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4db7f931b7831845d5ad9a27b1a6319cf65192de9454a28bb64b50d9e9f9875b-09b27acb458a076240e9968737c42ca77e5653b215ae746d53770326465c5608.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-115518")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2011")])]

#text("I think your combinatorial description in Exercise 3 may be slightly off, for instance, if I take my family to consist of ")#mi("{\\bf Z}_{2n}")#text(" by itself, ")#mi("S = \\{+1,-1\\}")#text(", and ")#mi("E")#text(" to be the even elements.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-115521")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2011")])]

#text("I’m not sure I understand the counterexample. Here, there is no uniform positive constant c for which ")#tao-math("\\left|E_n S_n\\right| \\geq (1+c) \\left|E_n\\right|", block: false)#text(", and so this is not an expander family of graphs.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4db7f931b7831845d5ad9a27b1a6319cf65192de9454a28bb64b50d9e9f9875b-09b27acb458a076240e9968737c42ca77e5653b215ae746d53770326465c5608.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-115534")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2011")])]

#text("I mean I’m taking my family to consist of a single group, say ")#mi("{\\bf Z}_{2n}")#text(" for any ")#mi("n")#text(". For concreteness say ")#mi("{\\bf Z}_{2}")#text(". (If you insist on an infinite collection, take an infinite number of copies of this group.) Then the equation ")#tao-math("\\left|E_n S_n\\right| \\geq (1+c)\\left|E_n\\right|", block: false)#text(" forces $c=0$.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-115538")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2011")])]

#text("Ah, I see the issue now. I’ve repaired the description.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 3: Quasirandom groups, expansion, and Selberg’s 3/16 theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-116196")[#strong[#text("254B, Notes 3: Quasirandom groups, expansion, and Selberg’s 3/16 theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2011")])]

#text("[…] the previous set of notes we saw how a representation-theoretic property of groups, namely Kazhdan’s property (T), […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-116207")[#strong[#text("254B, Notes 3: Quasirandom groups, expansion, and Selberg’s 3/16 theorem | t1u")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2011")]

#text("[…] the previous set of notes we saw how a representation-theoretic property of groups, namely Kazhdan’s property (T), could be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-116770")[#strong[#text("254B, Notes 1: Basic theory of expander graphs « Another Word For It")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2011")]

#text("[…] 254B, Notes 2: Cayley graphs and Kazhdan’s property (T) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The spectral theorem and its converses for unbounded symmetric operators « What’s new")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-117271")[#strong[#text("The spectral theorem and its converses for unbounded symmetric operators « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2011")])]

#text("[…] for all . (Hint: use Bochner’s theorem, a proof of which (at least on , which is the case of interest here) can be found for instance in these notes.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c6953ab4425d109767a7eef3ecc7c8cf8d944a87ec5e2a502981e671d9cc1a-1d73f6869dd4b3f2691c3f1f37c65f3584e7eca39cd73c5b09d3068e6ab0d958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-117305")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2011")])]

#text("After Cor. 13 you say “The group ")#mi("\\mathrm{SL}_1(\\mathbb{R})")#text(" is trivial and thus does not have property (T)” — but the trivial group trivially has property (T).")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c6953ab4425d109767a7eef3ecc7c8cf8d944a87ec5e2a502981e671d9cc1a-1d73f6869dd4b3f2691c3f1f37c65f3584e7eca39cd73c5b09d3068e6ab0d958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-117306")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2011")])]

#text("Also, The second displayed equation in the proof of Prop 16 is missing half the equation (I think you mean to say that the given integral is non-negative?)")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 4: The Bourgain-Gamburd expansion machine « What’s new")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-122231")[#strong[#text("254B, Notes 4: The Bourgain-Gamburd expansion machine « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2012")])]

#text("[…] have now seen two ways to construct expander Cayley graphs . The first, discussed in Notes 2, is to use Cayley graphs that are projections of an infinite Cayley graph on a group with […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 6: Non-concentration in subgroups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-128468")[#strong[#text("254B, Notes 6: Non-concentration in subgroups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2012")])]

#text("[…] (i) Show that generates a free subgroup of . (Hint: use a ping-pong argument, as in Exercise 23 of Notes 2.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4db7f931b7831845d5ad9a27b1a6319cf65192de9454a28bb64b50d9e9f9875b-09b27acb458a076240e9968737c42ca77e5653b215ae746d53770326465c5608.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-133086")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2012")])]

#text("Dear Terry,")

#text("In Remark 6 you claim that Kazhdan’s theorem about finite generation of lattices is a consequence of Remark 3 and Proposition 9. This seems to me illegitimate, given that throughout this section we seem to be taking for granted compact generation. In particular, we prove Proposition 9 by starting with a compact generating set. Is there an easy way to fix this? – Best, Sean")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-133092")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2012")])]

#text("Yes, this was a bit awkward; for my applications I only needed the compactly generated case and so assumed it throughout for simplicity, but for other applications (such as Kazhdan’s original application) it is important to not assume compact generation ")#emph[#text("a priori")]#text(". But for the specific task of proving Proposition 9, the compact generation of G is not actually needed; if one inspects the argument, one sees that the set S does not need to generate all of G, but merely to generate a certain compact subset of G, namely those h such that gh lies in the support of f for some g in K’. Indeed, one could basically just set S to be that set. I’ll adjust Remark 6 to reflect this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4db7f931b7831845d5ad9a27b1a6319cf65192de9454a28bb64b50d9e9f9875b-09b27acb458a076240e9968737c42ca77e5653b215ae746d53770326465c5608.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-133886")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2012")])]

#text("You’re right, that fixes it.")

#text("Still working my way through Proposition 9: Unless I’m not looking at it right, the end of the proof seems a little oversimplified. Namely, you claim that the ")#mi("G")#text("-invariance of ")#mi("w")#text(" implies the ")#mi("G")#text("-invariance of ")#mi("w(g)")#text(" (for almost all ")#mi("g\\in\\widetilde{G}")#text("). That this is not the case can be seen from the case of ")#mi("\\widetilde{G}/G")#text(" finite: ")#mi("G")#text("-invariance of ")#mi("w")#text(" only implies ")#mi("G")#text("-invariance of ")#mi("w(e)")#text(" (unless ")#mi("G")#text(" is a normal subgroup).")

#text("Actually ")#mi("\\widetilde{G}")#text("-invariance of ")#mi("w")#text(" means that for all ")#mi("g")#text(" the equation ")#mi("w(g^{-1} x) = w(x)")#text(" holds for almost all ")#mi("x")#text(". Now we must apply Fubini in order to change the order of quantification over ")#mi("g")#text(" and ")#mi("x")#text(", to deduce that for almost all ")#mi("x")#text(" the equation ")#mi("w(g^{-1} x) = w(x)")#text(" holds for almost all ")#mi("g")#text(", which then implies that ")#mi("w")#text(" is almost everywhere constant. At least, this seems to be the approach in the Bekka, de la Harpe, and Valette book, Theorem E.3.1.")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e129a68dcf0bb46ecba772753b8f9af1ec273d49cbd7ace8069058648b03b58-7eb33440dcbae163fc1d170d08c9c52deb82d4eb4253cf0fbe7e8b13997f3aa7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig H")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-141299")[#strong[#text("Craig H")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2012")])]

#text("I have a question about Exercise 13. Why is it an inequality? When we look at the finite case, I’m pretty sure it’s an equality — I think it’s even an equality when the representation is finite-dimensional. I’m trying to figure out a context when it wouldn’t be just an equality, and I’m coming up blank. If you could help out, I’d appreciate it.")

#text("Also, in Exercise 21(i), can’t we just take the Haar integral of \\rho(g)v + c(g)? By convexity, the result must lie in the ball (and hence be finite), and by the left-invariance of the Haar measure, it has the behavior that we’re looking for.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-141519")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2012")])]

#text("Yes, the first inequality in Exercise 13 is in fact an equality (and I have now adjusted the exercise accordingly), though the second inequality is not.")

#text("For Exercise 21(i), the averaging trick only works when G is compact, or at least amenable. Otherwise, the Haar measure is infinite and there is no obvious way to perform the averaging. (But this is certainly “morally” the right way to think about the problem.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e992c9d6bd69dd80732ca5390a35dcd2f41def765f7553ed62128e4fb9b21ecb-4768d42197c2c4f660569b64d7705d69c7ec4ef2e7e1cbee040f09e195407ee1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 2: Cayley graphs and Kazhdan’s property (T) | What’s new | Peter's ruminations")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-232022")[#strong[#text("254B, Notes 2: Cayley graphs and Kazhdan’s property (T) | What’s new | Peter's ruminations")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2013")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#more-55&#8230")[#text("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#more-55&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d1b1c9362a5cf961e9742140b187c7402b0cbd678d23a45a43ef32ade818ff50-5963856e16a34216dd7d408822a181523846d70e6af1c691b7e6e35a32010f88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of schreier graphs and the space of groups « citedcorpse")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-249032")[#strong[#text("schreier graphs and the space of groups « citedcorpse")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2013")])]

#text("[…] a pair of exercises on Terry Tao’s blog that give another way to do this with finite graphs and the symmetric […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e992c9d6bd69dd80732ca5390a35dcd2f41def765f7553ed62128e4fb9b21ecb-4768d42197c2c4f660569b64d7705d69c7ec4ef2e7e1cbee040f09e195407ee1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tt | Peter's ruminations")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-251613")[#strong[#text("tt | Peter's ruminations")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2013")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/")[#text("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0061ff8eb1125e18a7f0cddd8ae8fbcd97f198e1e58caa74a44bc01f1dd360a2-04d22380a29164c0159374889d75b98dc0af4f5ebd8e2b2b3e089e8ea19309d9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pietro gheri")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-481217")[#strong[#text("pietro gheri")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2017")])]

#text("I have a question about the proof of proposition 17. In the bound for the total variation norm of ")#mi("(g^*)_* \\mu_{v,v} - \\mu_{v,v}")#text(" should I use the bound on the total mass of this kind of measures? Is there a link between their total mass and their total variation norm?")#linebreak()#text(" Sorry to bother with such questions, I’m new to these topics.")#linebreak()#text(" Thanks in advance for your help!")

#emph[#text("[The phrase “total mass” before Exercise 24 has been corrected to “total variation”. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/816f32efffbd9c7b0ad4b2ceb25f3c62db9599b32c7dd46ad8110cdcc3080b8a-805fe07e2eec4d9d274bf5690104e9fb5b9d3f730baf868b7165cf741e09ba9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Justin C")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-513825")[#strong[#text("Justin C")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2019")])]

#text("I am confused by the claim made in the proof of Proposition 10 that the Lebesgue measure on ")#mi("GL_d(\\mathbb{R})")#text(" is a Haar measure for this group.")#linebreak()#text(" It seems to me that the Lebesgue measure is invariant under addition, but not under the multiplication in the group. Don’t you need to divide the Lebesgue measure by the $d$-th power of the absolute value of the determinant to make it a Haar measure?")

#emph[#text("[Fair enough; I have corrected the text accordingly -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bff28cfff7635e3a1afc7992f316e3a5c17f485c81ad4dfb3c6ca627cfad5061-fd429a2e312ba21d280a175a9f77a2eed75310191404327fec6c87f7991c51a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mriganka Basu Roy Chowdhury")]], [#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/#comment-532936")[#strong[#text("Mriganka Basu Roy Chowdhury")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2019")])]

#text("Equation ")#mi("(2)")#text(" should have ")#tao-math("\\left|\\left| f \\right|\\right|^2_{\\mathcal{l}^2(G)}", block: false)#text(" instead of ")#tao-math("\\left|\\left| f \\right|\\right|_{\\mathcal{l}^2(G)}", block: false)#text(" right?")

#emph[#text("[Corrected, thanks – T.]")]
]
