// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/02/05/some-notes-on-bakry-emery-theory/
// Converted to Typst by tao2typ: "2026-10-14T16:36:58.513817+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Some notes on Bakry-Emery theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Some notes on Bakry-Emery theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 February 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/02/05/some-notes-on-bakry-emery-theory/")[#text("https://terrytao.wordpress.com/2013/02/05/some-notes-on-bakry-emery-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#emph[#text("[These are notes intended mostly for myself, as these topics are useful in random matrix theory, but may be of interest to some readers also. -T.]")]

#text("One of the most fundamental partial differential equations in mathematics is the ")#link("http://en.wikipedia.org/wiki/Heat_equation")[#text("heat equation")]#text(" ")#metadata(none) <tao-f9394510528c7122ccd0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\partial_t f = L f")]]

#text("where ")#mi("{f: [0,+\\infty) \\times {\\bf R}^n \\rightarrow {\\bf R}}")#text(" is a scalar function ")#mi("{(t,x) \\mapsto f(t,x)}")#text(" of both time and space, and ")#mi("{L}")#text(" is the Laplacian ")#mi("{L := \\frac{1}{2} \\Delta = \\sum_{i=1}^n \\frac{\\partial^2}{\\partial x_i^2}}")#text(". For the purposes of this post, we will ignore all technical issues of regularity and decay, and always assume that the solutions to equations such as ")#link(<tao-f9394510528c7122ccd0>)[#text("(1)")]#text(" have all the regularity and decay in order to justify all formal operations such as the chain rule, integration by parts, or differentiation under the integral sign. The factor of ")#mi("{\\frac{1}{2}}")#text(" in the definition of the heat propagator ")#mi("{L}")#text(" is of course an arbitrary normalisation, chosen for some minor technical reasons; one can certainly continue the discussion below with other choices of normalisations if desired.")

#text("In probability theory, this equation takes on particular significance when ")#mi("{f}")#text(" is restricted to be non-negative, and furthermore to be a probability measure at each time, in the sense that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} f(t,x)\\ dx = 1")]]

#text("for all ")#mi("{t}")#text(". (Actually, it suffices to verify this constraint at time ")#mi("{t=0}")#text(", as the heat equation ")#link(<tao-f9394510528c7122ccd0>)[#text("(1)")]#text(" will then preserve this constraint.) Indeed, in this case, one can interpret ")#mi("{f(t,x)\\ dx}")#text(" as the probability distribution of a Brownian motion ")#metadata(none) <tao-5eb67f9f8409b9c3f739>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("dx = dB(t)")]]

#text("where ")#mi("{x = x(t) \\in {\\bf R}^n}")#text(" is a stochastic process with initial probability distribution ")#mi("{f(0,x)\\ dx}")#text("; see for instance ")#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/")[#text("this previous blog post")]#text(" for more discussion.")

#text("A model example of a solution to the heat equation to keep in mind is that of the fundamental solution ")#metadata(none) <tao-38157b72ac6667893f38>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("G(t,x) = \\frac{1}{(2\\pi t)^{n/2}} e^{-\\left|x\\right|^2/2t}", block: true)]]

#text("defined for any ")#mi("{t>0}")#text(", which represents the distribution of Brownian motion of a particle starting at the origin ")#mi("{x=0}")#text(" at time ")#mi("{t=0}")#text(". At time ")#mi("{t}")#text(", ")#mi("{G(t,x)}")#text(" represents an ")#mi("{{\\bf R}^n}")#text("-valued random variable, each coefficient of which is an independent random variable of mean zero and variance ")#mi("{t}")#text(". (As ")#mi("{t \\rightarrow 0^+}")#text(", ")#mi("{G(t)}")#text(" converges in the sense of distributions to a Dirac mass at the origin.)")

#text("The heat equation can also be viewed as the gradient flow for the ")#link("http://en.wikipedia.org/wiki/Dirichlet_form")[#text("Dirichlet form")]#text(" ")#metadata(none) <tao-16ba121a04d5ad3b885f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("D(f,g) := \\frac{1}{2} \\int_{{\\bf R}^n} \\nabla f \\cdot \\nabla g\\ dx")]]

#text("since one has the integration by parts identity ")#metadata(none) <tao-dc0ba88f20a66cdc468c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\int_{{\\bf R}^n} Lf(x) g(x)\\ dx = \\int_{{\\bf R}^n} f(x) Lg(x)\\ dx = - D(f,g)")]]

#text("for all smooth, rapidly decreasing ")#mi("{f,g}")#text(", which formally implies that ")#mi("{L f}")#text(" is (half of) the negative gradient of the ")#emph[#text("Dirichlet energy")]#text(" ")#tao-math("{D(f,f) = \\frac{1}{2} \\int_{{\\bf R}^n} \\left|\\nabla f\\right|^2\\ dx}", block: false)#text(" with respect to the ")#mi("{L^2({\\bf R}^n,dx)}")#text(" inner product. Among other things, this implies that the Dirichlet energy decreases in time: ")#metadata(none) <tao-1a802487a5c43284fc02>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\partial_t D(f,f) = - 2 \\int_{{\\bf R}^n} \\left|Lf\\right|^2\\ dx.", block: true)]]

#text("For instance, for the fundamental solution ")#link(<tao-38157b72ac6667893f38>)[#text("(3)")]#text(", one can verify for any time ")#mi("{t>0}")#text(" that ")#metadata(none) <tao-837ed09a9133ade51d06>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("D(G,G) = \\frac{n}{2^{n+2} \\pi^{n/2}} \\frac{1}{t^{(n+2)/2}}")]]

#text("(assuming I have not made a mistake in the calculation). In a similar spirit we have ")#metadata(none) <tao-a33ff8eef24006b1c225>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\partial_t \\int_{{\\bf R}^n} \\left|f\\right|^2\\ dx = - 2 D(f,f).", block: true)]]

#text("Since ")#mi("{D(f,f)}")#text(" is non-negative, the formula ")#link(<tao-1a802487a5c43284fc02>)[#text("(6)")]#text(" implies that ")#tao-math("{\\int_{{\\bf R}^n} \\left|Lf\\right|^2\\ dx}", block: false)#text(" is integrable in time, and in particular we see that ")#mi("{Lf}")#text(" converges to zero as ")#mi("{t \\rightarrow \\infty}")#text(", in some averaged ")#mi("{L^2}")#text(" sense at least; similarly, ")#link(<tao-a33ff8eef24006b1c225>)[#text("(8)")]#text(" suggests that ")#mi("{D(f,f)}")#text(" also converges to zero. This suggests that ")#mi("{f}")#text(" converges to a constant function; but as ")#mi("{f}")#text(" is also supposed to decay to zero at spatial infinity, we thus expect solutions to the heat equation in ")#mi("{{\\bf R}^n}")#text(" to decay to zero in some sense as ")#mi("{t \\rightarrow \\infty}")#text(". However, the decay is only expected to be polynomial in nature rather than exponential; for instance, the solution ")#link(<tao-38157b72ac6667893f38>)[#text("(3)")]#text(" decays in the ")#mi("{L^\\infty}")#text(" norm like ")#mi("{O(t^{-n/2})}")#text(".")

#text("Since ")#mi("{L1=0}")#text(", we also observe the basic cancellation property ")#metadata(none) <tao-febbf1bdbe6964d2dfa4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\int_{{\\bf R}^n} Lf(x) \\ dx = 0")]]

#text("for any function ")#mi("{f}")#text(".")

#text("There are other quantities relating to ")#mi("{f}")#text(" that also decrease in time under heat flow, particularly in the important case when ")#mi("{f}")#text(" is a probability measure. In this case, it is natural to introduce the ")#emph[#text("entropy")]

#align(center)[#tao-fit-display[#mitex("S(f) := \\int_{{\\bf R}^n} f(x) \\log f(x)\\ dx.")]]

#text("Thus, for instance, if ")#mi("{f(x)\\ dx}")#text(" is the uniform distribution on some measurable subset ")#mi("{E}")#text(" of ")#mi("{{\\bf R}^n}")#text(" of finite measure ")#tao-math("{\\left|E\\right|}", block: false)#text(", the entropy would be ")#tao-math("{-\\log \\left|E\\right|}", block: false)#text(". Intuitively, as the entropy decreases, the probability distribution gets wider and flatter. For instance, in the case of the fundamental solution ")#link(<tao-38157b72ac6667893f38>)[#text("(3)")]#text(", one has ")#mi("{S(G) = -\\frac{n}{2} \\log( 2 \\pi e t )}")#text(" for any ")#mi("{t>0}")#text(", reflecting the fact that ")#mi("{G(t)}")#text(" is approximately uniformly distributed on a ball of radius ")#mi("{O(\\sqrt{t})}")#text(" (and thus of measure ")#mi("{O(t^{n/2})}")#text(").")

#text("A short formal computation shows (if one assumes for simplicity that ")#mi("{f}")#text(" is strictly positive, which is not an unreasonable hypothesis, particularly in view of the ")#link("http://en.wikipedia.org/wiki/Maximum_principle")[#text("strong maximum principle")]#text(") using ")#link(<tao-febbf1bdbe6964d2dfa4>)[#text("(9)")]#text(", ")#link(<tao-dc0ba88f20a66cdc468c>)[#text("(5)")]#text(" that")

#tao-aligned(keep: true)[


#tao-math("\\partial_t S(f)  & = \\int_{{\\bf R}^n} (Lf) \\log f + f \\frac{Lf}{f}\\ dx", block: true)



#tao-math(" & = \\int_{{\\bf R}^n} (Lf) \\log f\\ dx", block: true)



#tao-math(" & = - D( f, \\log f )", block: true)



#tao-math(" & = - \\frac{1}{2} \\int_{{\\bf R}^n} \\frac{\\left|\\nabla f\\right|^2}{f}\\ dx", block: true)



#tao-math(" & = - 4D( g, g )", block: true)
]

#text("where ")#mi("{g := \\sqrt{f}}")#text(" is the square root of ")#mi("{f}")#text(". For instance, if ")#mi("{f}")#text(" is the fundamental solution ")#link(<tao-38157b72ac6667893f38>)[#text("(3)")]#text(", one can check that ")#mi("{D(g,g) = \\frac{n}{8t}}")#text(" (note that this is a significantly cleaner formula than ")#link(<tao-837ed09a9133ade51d06>)[#text("(7)")]#text("!).")

#text("In particular, the entropy is decreasing, which corresponds well to one’s intuition that the heat equation (or Brownian motion) should serve to spread out a probability distribution over time.")

#text("Actually, one can say more: the rate of decrease ")#mi("{4D(g,g)}")#text(" of the entropy is itself decreasing, or in other words the entropy is convex. I do not have a satisfactorily intuitive reason for this phenomenon, but it can be proved by straightforward application of basic several variable calculus tools (such as the chain rule, product rule, quotient rule, and integration by parts), and completing the square. Namely, by using the chain rule we have ")#metadata(none) <tao-9414886b1ebf025db067>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("L \\phi(f) = \\phi^{\\prime}(f) Lf + \\frac{1}{2} \\phi^{\\prime\\prime}(f) \\left|\\nabla f\\right|^2,", block: true)]]

#text("valid for for any smooth function ")#mi("{\\phi: {\\bf R} \\rightarrow {\\bf R}}")#text(", we see from ")#link(<tao-f9394510528c7122ccd0>)[#text("(1)")]#text(" that")

#align(center)[#tao-fit-display[#tao-math("2 g \\partial_t g = 2 g L g + \\left|\\nabla g\\right|^2", block: true)]]

#text("and thus (again assuming that ")#mi("{f}")#text(", and hence ")#mi("{g}")#text(", is strictly positive to avoid technicalities)")

#align(center)[#tao-fit-display[#tao-math("\\partial_t g = Lg + \\frac{\\left|\\nabla g\\right|^2}{2g}.", block: true)]]

#text("We thus have")

#align(center)[#tao-fit-display[#tao-math("\\partial_t D(g,g) = 2 D(g,Lg) + D(g, \\frac{\\left|\\nabla g\\right|^2}{g} ).", block: true)]]

#text("It is now convenient to compute using the ")#link("http://en.wikipedia.org/wiki/Einstein_notation")[#text("Einstein summation convention")]#text(" to hide the summation over indices ")#mi("{i,j = 1,\\ldots,n}")#text(". We have")

#align(center)[#tao-fit-display[#mitex("2 D(g,Lg) = \\frac{1}{2} \\int_{{\\bf R}^n} (\\partial_i g) (\\partial_i \\partial_j \\partial_j g)\\ dx")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("D(g, \\frac{\\left|\\nabla g\\right|^2}{g} ) = \\frac{1}{2} \\int_{{\\bf R}^n} (\\partial_i g) \\partial_i \\frac{\\partial_j g \\partial_j g}{g}\\ dx.", block: true)]]

#text("By integration by parts and interchanging partial derivatives, we may write the first integral as")

#align(center)[#tao-fit-display[#mitex("2 D(g,Lg) = - \\frac{1}{2} \\int_{{\\bf R}^n} (\\partial_i \\partial_j g) (\\partial_i \\partial_j g)\\ dx,")]]

#text("and from the quotient and product rules, we may write the second integral as")

#align(center)[#tao-fit-display[#tao-math("D(g, \\frac{\\left|\\nabla g\\right|^2}{g} ) = \\int_{{\\bf R}^n} \\frac{(\\partial_i g) (\\partial_j g) (\\partial_i \\partial_j g)}{g} - \\frac{(\\partial_i g) (\\partial_j g) (\\partial_i g) (\\partial_j g)}{2g^2}\\ dx.", block: true)]]

#text("Gathering terms, completing the square, and making the summations explicit again, we see that")

#align(center)[#tao-fit-display[#tao-math("\\partial_t D(g,g) =- \\frac{1}{2} \\int_{{\\bf R}^n} \\frac{\\sum_{i=1}^n \\sum_{j=1}^n \\left|g \\partial_i \\partial_j g - (\\partial_i g) (\\partial_j g)\\right|^2}{g^2}\\ dx", block: true)]]

#text("and so in particular ")#mi("{D(g,g)}")#text(" is always decreasing.")

#text("The above identity can also be written as")

#align(center)[#tao-fit-display[#tao-math("\\partial_t D(g,g) = - \\frac{1}{2} \\int_{{\\bf R}^n} \\left|\\nabla^2 \\log g\\right|^2 g^2\\ dx.", block: true)]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Give an alternate proof of the above identity by writing ")#mi("{f = e^{2u}}")#text(", ")#mi("{g = e^u}")#text(" and deriving the equation ")#tao-math("{\\partial_t u = Lu + \\left|\\nabla u\\right|^2}", block: false)#text(" for ")#mi("{u}")#text(".")
]

#text("It was observed in ")#link("http://www.ams.org/mathscinet-getitem?mr=889476")[#text("a well known paper of Bakry and Emery")]#text(" that the above monotonicity properties hold for a much larger class of heat flow-type equations, and lead to a number of important relations between energy and entropy, such as the log-Sobolev inequality ")#link("http://www.ams.org/mathscinet-getitem?mr=420249")[#text("of Gross")]#text(" and ")#link("http://www.zentralblatt-math.org/zmath/en/search/?q=an:0165.58301&format=complete")[#text("of Federbush")]#text(", and the hypercontractivity inequality ")#link("http://www.ams.org/mathscinet-getitem?mr=210416")[#text("of Nelson")]#text("; we will discuss one such family of generalisations (or more precisely, variants) below the fold.")

#metadata(none) <tao-a8163bc3ff07d1a8ae74>

#text("We modify the above examples by replacing the Lebesgue measure ")#mi("{dx}")#text(" on ")#mi("{{\\bf R}^n}")#text(" by a probability measure ")#mi("{\\mu}")#text(", which (inspired by the formalism of statistical mechanics) is customarily written in the form")

#align(center)[#tao-fit-display[#mitex("d\\mu = \\frac{1}{Z} e^{-\\beta H(x)}\\ dx,")]]

#text("where the ")#emph[#text("Hamiltonian")]#text(" ")#mi("{H: {\\bf R}^n \\rightarrow {\\bf R}}")#text(" is some (smooth) function that grows at a suitable rate at infinity (to make ")#mi("{e^{-\\beta H}}")#text(" have finite mass), ")#mi("{\\beta > 0}")#text(" is a scaling parameter (sometimes referred to as the ")#link("http://en.wikipedia.org/wiki/Thermodynamic_beta")[#text("inverse temperature")]#text("), and ")#mi("{Z = \\int_{{\\bf R}^n} e^{-\\beta H}\\ dx}")#text(" is a normalisation constant (known as the ")#link("http://en.wikipedia.org/wiki/Partition_function_(statistical_mechanics)")[#text("partition function")]#text("). A model example here is that of the Gaussian distribution ")#metadata(none) <tao-a19ee2577879b76a5b98>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("d\\mu = \\frac{1}{(2\\pi)^{n/2}} e^{-\\left|x\\right|^2/2}\\ dx", block: true)]]

#text("which would correspond to the harmonic oscillator Hamiltonian ")#tao-math("{H(x) = \\left|x\\right|^2/2}", block: false)#text(" with ")#mi("{\\beta=1}")#text(", or of a random Gaussian vector in which each coefficient independently has a normal distribution of mean zero and variance one. (For the purposes of this blog post, one could combine the ")#mi("{\\beta}")#text(" and ")#mi("{H}")#text(" quantities into a single object if one wished, effectively normalising ")#mi("{\\beta}")#text(" to equal ")#mi("{1}")#text(", but there can be some minor advantages to using a different normalisation to ")#mi("{\\beta}")#text(" for some applications, for instance if one is interested in large dimensional limits ")#mi("{n \\rightarrow \\infty}")#text(".)")

#text("While we are altering the base measure ")#mi("{\\mu}")#text(" here, we will retain the Euclidean gradient structure; one can of course consider even more general variants of heat flow (such as heat flow on Riemannian manifolds) in which we also change the gradient structure; these are also of interest for many applications, but we will not consider them here.")

#text("We can form the Dirichlet form ")#mi("{D_\\mu}")#text(" relative to ")#mi("{\\mu}")#text(" (but retaining the Euclidean gradient structure, as mentioned above) by the formula")

#align(center)[#tao-fit-display[#mitex("D_\\mu(f,g) := \\frac{1}{2} \\int_{{\\bf R}^n} \\nabla f \\cdot \\nabla g\\ d\\mu")]]

#text("in analogy with ")#link(<tao-16ba121a04d5ad3b885f>)[#text("(4)")]#text(". In analogy with ")#link(<tao-dc0ba88f20a66cdc468c>)[#text("(5)")]#text(", we then have ")#metadata(none) <tao-7bf67d3cc7eb91fb8fc1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\int_{{\\bf R}^n} (Lf) g\\ d\\mu = \\int_{{\\bf R}^n} f (Lg)\\ d\\mu = -D_\\mu(f,g)")]]

#text("where ")#mi("{L}")#text(" is the differential operator")

#align(center)[#tao-fit-display[#mitex("L f = L_\\mu f = \\frac{1}{2} \\Delta f - \\frac{1}{2} \\beta \\nabla H \\cdot \\nabla f.")]]

#text("For instance, in the Gaussian case ")#link(<tao-a19ee2577879b76a5b98>)[#text("(11)")]#text(", ")#mi("{L}")#text(" becomes the ")#link("http://en.wikipedia.org/wiki/Ornstein%E2%80%93Uhlenbeck_operator")[#text("Ornstein-Uhlenbeck operator")]

#align(center)[#tao-fit-display[#mitex("Lf = \\frac{1}{2} (\\Delta f - x \\cdot \\nabla f)")]]

#text("(note that the normalisation factor of ")#mi("{\\frac{1}{2}}")#text(" is not always present in the literature concerning this operator). Observe that ")#mi("{L1=0}")#text(" (or equivalently, that ")#mi("{D(f,1)=0}")#text(" for all reasonable ")#mi("{f}")#text(") and so from ")#link(<tao-7bf67d3cc7eb91fb8fc1>)[#text("(12)")]#text(" we have the analogue of ")#link(<tao-febbf1bdbe6964d2dfa4>)[#text("(9)")]#text(", namely that ")#metadata(none) <tao-2834e64f3da4f1eb4167>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\int_{{\\bf R}^n} Lf\\ d\\mu = 0")]]

#text("for all (smooth, not too rapidly increasing) ")#mi("{f}")#text(".")

#text("The corresponding gradient flow (now using the inner product structure of ")#mi("{L^2({\\bf R}^n,d\\mu)}")#text(", rather than ")#mi("{L^2({\\bf R}^n, dx)}")#text(") is then ")#metadata(none) <tao-5a2a0ed9aa3ab7d82b53>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\partial_t f = Lf.")]]

#text("This equation becomes probabilistically meaningful if ")#mi("{f\\ d\\mu}")#text(" is a probability measure, thus ")#mi("{f}")#text(" is non-negative and")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} f\\ d\\mu = 1")]]

#text("for all times ")#mi("{t}")#text(" (but again, it is easy to see using ")#link(<tao-2834e64f3da4f1eb4167>)[#text("(13)")]#text(" that if this constraint holds for one time, it holds for all subsequent times also). In probabilistic terms, the probability measure ")#mi("{f(t,x)\\ d\\mu(x)}")#text(" then represents the probability distribution at time ")#mi("{t}")#text(" of a particle ")#mi("{x: t \\mapsto x(t) \\in {\\bf R}^n}")#text(" with initial distribution ")#mi("{f(0,x)\\ d\\mu(x)}")#text(" at time zero, and obeying the stochastic differential equation")

#align(center)[#tao-fit-display[#mitex("dx = dB_t - \\frac{1}{2} \\beta \\nabla H(x) dt,")]]

#text("which can be viewed as a combination of Brownian motion ")#mi("{dx = dB_t}")#text(" and gradient flow ")#mi("{dx = -\\nabla H(x) dt}")#text(". For instance, in the Gaussian case ")#link(<tao-a19ee2577879b76a5b98>)[#text("(11)")]#text(", this equation becomes the ")#link("http://en.wikipedia.org/wiki/Ornstein%E2%80%93Uhlenbeck_process")[#text("Ornstein-Uhlenbeck process")]#text(" ")#metadata(none) <tao-6bd1b55c3c729cce8bc1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("dx = dB_t - \\frac{1}{2} x\\ dt,")]]

#text("with the relative density ")#mi("{f}")#text(" then obeying the ")#emph[#text("Ornstein-Uhlenbeck equation")]#text(" ")#metadata(none) <tao-57a5c2812fa064eb89aa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\partial_t f = \\frac{1}{2} (\\Delta f - x \\cdot \\nabla f).")]]

#text("As before, we have a number of monotonicity formulae for the heat flow ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(14)")]#text(", such as")

#align(center)[#tao-fit-display[#tao-math("\\partial_t \\int_{{\\bf R}^n} \\left|f\\right|^2\\ d\\mu = - 2 D_\\mu(f,f)", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\partial_t D_\\mu(f,f) = - 2\\int_{{\\bf R}^n} \\left|Lf\\right|^2\\ d\\mu,", block: true)]]

#text("which strongly suggests (as before) that ")#mi("{f}")#text(" should be converging as ")#mi("{t \\rightarrow \\infty}")#text(" to a function with ")#mi("{D_\\mu(f,f)=0}")#text(", i.e. to a constant function. In particular, as ")#mi("{\\mu}")#text(" is normalised to be a probability measure, and ")#mi("{f\\ d\\mu}")#text(" is also a probability measure, then we expect ")#mi("{f}")#text(" to converge to ")#mi("{1}")#text(".")

#text("One way to quantify this convergence is to introduce the entropy")

#align(center)[#tao-fit-display[#mitex("S_\\mu(f) := \\int_{{\\bf R}^n} f \\log f\\ d\\mu.")]]

#text("If ")#mi("{\\mu}")#text(" and ")#mi("{f\\ d\\mu}")#text(" are both probability measures, then a simple application of Jensen’s inequality gives us that ")#mi("{S_\\mu(f)}")#text(" is non-negative. Indeed, we can say more:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Entropy controls total variation)")]#text(" ")#metadata(none) <tao-8b1101c7d738ce75a708>#text(" We have ")#mi("{(\\int_{{\\bf R}^n} |f-1|\\ d\\mu)^2 \\leq 2 S_\\mu(f)}")#text(".")
]

#text("This inequality is also known as ")#link("http://en.wikipedia.org/wiki/Pinsker's_inequality")[#text("Pinsker’s inequality")]#text(".")

#emph[#text("Proof:")]#text(" We first give a crude argument that loses a factor of ")#mi("{4}")#text(". As ")#mi("{x \\log x}")#text(" has a second derivative of ")#mi("{\\frac{1}{x}}")#text(", we see from Taylor expansion at ")#mi("{1}")#text(" that")

#align(center)[#tao-fit-display[#mitex("x \\log x \\geq (x-1) + \\frac{1}{2} (1-x)_+^2")]]

#text("for any ")#mi("{x \\geq 0}")#text(", and hence on replacing ")#mi("{x}")#text(" by ")#mi("{f(x)}")#text(" and integrating against ")#mi("{\\mu}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("S_\\mu(f) \\geq \\frac{1}{2} \\int_{{\\bf R}^n} (1-f)_+^2\\ d\\mu")]]

#text("and hence by Cauchy-Schwarz")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} (1-f)_+\\ d\\mu \\leq \\sqrt{2} S_\\mu(f)^{1/2}")]]

#text("and hence since ")#mi("{f}")#text(" has mean ")#mi("{1}")#text(" with respect to ")#mi("{\\mu}")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} |f-1|\\ d\\mu \\leq 2 \\sqrt{2} S_\\mu(f)^{1/2}")]]

#text("which on squaring gives the bound with a loss of ")#mi("{4}")#text(". To eliminate the loss, we use ")#link("http://www.ams.org/mathscinet-getitem?mr=252112")[#text("an argument of Kemperman")]#text(" (which also appears in a ")#link("http://www.ams.org/mathscinet-getitem?mr=1410112")[#text("subsequent paper of Diaconis and Saloff-Coste")]#text("), and use the more precise inequality")

#align(center)[#tao-fit-display[#mitex("x \\log x \\geq (x-1) + \\frac{(x-1)^2}{2+2(x-1)/3}")]]

#text("which can be verified by elementary calculus (indeed, this function vanishes to fourth order at ")#mi("{x=1}")#text(" and has the non-negative second derivative of ")#mi("{\\frac{(x-1)^2(x+8)}{x(x+2)^3}}")#text("). We then conclude that")

#align(center)[#tao-fit-display[#tao-math("S_\\mu(f) \\geq \\int_{{\\bf R}^n} \\frac{\\left|f-1\\right|^2}{2 + 2(f-1)/3}\\ d\\mu;", block: true)]]

#text("since ")#mi("{\\int_{{\\bf R}^n} 2+2(f-1)/3\\ d\\mu = 2}")#text(", the claim then follows from the Cauchy-Schwarz inequality. ")#mi("\\Box")

#text("The computations used to compute the time derivative of ")#mi("{S(f)}")#text(" also work for ")#mi("{S_\\mu(f)}")#text(", leading to the identity ")#metadata(none) <tao-e1cd2701488eac23f325>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\partial_t S_\\mu(f) = - 4D_\\mu(g,g)")]]

#text("where ")#mi("{f=g^2}")#text(". The formula for the time derivative for ")#mi("{D_\\mu(g,g)}")#text(" is a bit more interesting. The chain rule ")#link(<tao-9414886b1ebf025db067>)[#text("(10)")]#text(" still holds for ")#mi("{L}")#text(" (why?), and so we still have")

#align(center)[#tao-fit-display[#tao-math("\\partial_t g = Lg + \\frac{\\left|\\nabla g\\right|^2}{2g}", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\partial_t D_\\mu(g,g) = 2 D_\\mu(g,Lg) + D_\\mu(g, \\frac{\\left|\\nabla g\\right|^2}{g} ).", block: true)]]

#text("As in the Euclidean case, we have ")#metadata(none) <tao-40b3783c5925dae7bfbd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("D_\\mu(g, \\frac{\\left|\\nabla g\\right|^2}{g} ) = \\int_{{\\bf R}^n} \\frac{(\\partial_i g) (\\partial_j g) (\\partial_i \\partial_j g)}{g} - \\frac{(\\partial_i g) (\\partial_j g) (\\partial_i g) (\\partial_j g)}{2g^2}\\ d\\mu(x).", block: true)]]

#text("The situation with ")#mi("{D_\\mu(g,Lg)}")#text(" is however a bit more complicated:")

#align(center)[#tao-fit-display[#mitex("2 D_\\mu(g,Lg) = \\frac{1}{2} \\int_{{\\bf R}^n} (\\partial_i g) (\\partial_i \\partial_j \\partial_j g)\\ d\\mu - \\frac{\\beta}{2} \\int_{{\\bf R}^n} (\\partial_i g) \\partial_i( (\\partial_j H) (\\partial_j g) )\\ d\\mu.")]]

#text("If we perform integration by parts on the first integral, it becomes")

#align(center)[#tao-fit-display[#mitex("- \\frac{1}{2} \\int_{{\\bf R}^n} (\\partial_i \\partial_j g) (\\partial_i \\partial_j g)\\ d\\mu(x) + \\frac{\\beta}{2} \\int_{{\\bf R}^n} (\\partial_i g) (\\partial_i \\partial_j g) (\\partial_j H)\\ d\\mu;")]]

#text("this partially cancels the second integral, leading to the formula")

#align(center)[#tao-fit-display[#mitex("2 D_\\mu(g,Lg) = \\frac{1}{2} \\int_{{\\bf R}^n} (\\partial_i \\partial_j g) (\\partial_i \\partial_j g)\\ d\\mu - \\frac{\\beta}{2} \\int_{{\\bf R}^n} (\\partial_i \\partial_j H) (\\partial_i g) (\\partial_j g)\\ d\\mu.")]]

#text("Combining this with ")#link(<tao-40b3783c5925dae7bfbd>)[#text("(18)")]#text(" and completing the square as in the Euclidean case, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\partial_t D_\\mu(g,g) = - \\frac{1}{2} \\int_{{\\bf R}^n} \\left|\\nabla^2 \\log g\\right|^2 g^2\\ d\\mu - \\frac{\\beta}{2} \\int_{{\\bf R}^n} \\nabla^2 H( \\nabla g, \\nabla g)\\ d\\mu", block: true)]]

#text("where ")#mi("{\\nabla^2 H}")#text(" is the Hessian of ")#mi("{H}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\nabla^2 H( u, v ) := (\\partial_i \\partial_j H) (\\partial_i u) (\\partial_j v).")]]

#text("In particular, we have the ")#emph[#text("Bakry-Emery inequality")]#text(" ")#metadata(none) <tao-3f8c49ce280206ab28f9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\partial_t D_\\mu(g,g) \\leq - \\frac{\\beta}{2} \\int_{{\\bf R}^n} \\nabla^2 H( \\nabla g, \\nabla g)\\ d\\mu.")]]

#text("If ")#mi("{H}")#text(" is convex, then this implies that ")#mi("{D_\\mu(g,g)}")#text(" is non-increasing, much as in the Euclidean case. However, the situation improves significantly if ")#mi("{H}")#text(" is (uniformly) ")#emph[#text("strictly")]#text(" convex in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\nabla^2 H( u, u ) \\geq \\rho \\left|u\\right|^2", block: true)]]

#text("for some fixed ")#mi("{\\rho>0}")#text(". In this case, we have")

#align(center)[#tao-fit-display[#mitex("\\partial_t D_\\mu(g,g) \\leq -\\beta\\rho D_\\mu(g,g)")]]

#text("and thus by Gronwall’s inequality we have the exponential decay ")#metadata(none) <tao-dd1b3c312cf7d8161303>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("D_\\mu(g,g) \\leq \\exp( - \\beta \\rho t ) D_\\mu(g(0),g(0))")]]

#text("for all ")#mi("{t \\geq 0}")#text(". This suggests that ")#mi("{g}")#text(" (and hence ")#mi("{f}")#text(") relaxes exponentially fast to the equilibrium state ")#mi("{1}")#text(", with the time of relaxation being of the order of ")#mi("{O(1/(\\rho \\beta))}")#text(". In particular, we expect ")#mi("{S_\\mu(f)}")#text(" to converge to ")#mi("{S_\\mu(1)=0}")#text(" as ")#mi("{t \\rightarrow \\infty}")#text(". From ")#link(<tao-e1cd2701488eac23f325>)[#text("(17)")]#text(" and the fundamental theorem of calculus we therefore have (formally at least) that")

#align(center)[#tao-fit-display[#mitex("S_\\mu(f(0)) = 4\\int_0^\\infty D_\\mu(g(t),g(t))\\ dt")]]

#text("and hence from ")#link(<tao-dd1b3c312cf7d8161303>)[#text("(20)")]#text(" we have the ")#emph[#text("log-Sobolev inequality")]

#align(center)[#tao-fit-display[#mitex("S_\\mu(f(0)) \\leq \\frac{4}{\\beta \\rho} D_\\mu(g(0),g(0))")]]

#text("or to put in a more familiar way, we have ")#metadata(none) <tao-9b9a3717eacd16206b4b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\int_{{\\bf R}^n} g^2 \\log g^2\\ d\\mu \\leq \\frac{2}{\\beta \\rho} \\int_{{\\bf R}^n} \\left|\\nabla g\\right|^2\\ d\\mu", block: true)]]

#text("whenever ")#mi("{\\int_{{\\bf R}^n} g^2\\ d\\mu = 1}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Formally establish the exponential decay of entropy")

#align(center)[#tao-fit-display[#mitex("S_\\mu(f(t)) \\leq \\exp( - \\beta \\rho t ) S_\\mu(f(0))")]]

#text("whenever ")#mi("{f\\ d\\mu}")#text(" is a probability measure obeying the heat equation ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(14)")]#text(".")
]

#text("In the gaussian case ")#link(<tao-a19ee2577879b76a5b98>)[#text("(11)")]#text(", we have ")#mi("{\\beta=\\rho=1}")#text(", and ")#link(<tao-9b9a3717eacd16206b4b>)[#text("(21)")]#text(" is the classical log-Sobolev inequality of Gross and of Federbush. But we see from the above argument that log-Sobolev inequalities in fact hold for all convex Hamiltonians ")#mi("{H}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Using ")#link(<tao-9b9a3717eacd16206b4b>)[#text("(21)")]#text(", formally establish the ")#emph[#text("hypercontractivity inequality")]#text(" ")#metadata(none) <tao-0e71757b927c6507af4b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#tao-math("\\left\\| f(t) \\right\\|_{L^{\\beta \\rho t}({\\bf R}^n, d\\mu)} \\leq \\left\\|f(0) \\right\\|_{L^1({\\bf R}^n,d\\mu)}", block: true)]]

#text("whenever ")#mi("{f}")#text(" is a non-negative solution to the heat flow ")#link(<tao-5a2a0ed9aa3ab7d82b53>)[#text("(14)")]#text(". (")#emph[#text("Hint:")]#text(" compute the derivative of ")#tao-math("{\\left\\| f(t) \\right\\|_{L^{\\beta \\rho t}({\\bf R}^n, d\\mu)}^{\\beta \\rho t}}", block: false)#text(" at some time ")#mi("{t=t_0}")#text(", after performing the normalisation ")#tao-math("{\\left\\| f(t_0) \\right\\|_{L^{\\beta \\rho t_0}({\\bf R}^n, d\\mu)} = 1}", block: false)#text(".) Conversely, show that the hypercontractivity inequality ")#link(<tao-0e71757b927c6507af4b>)[#text("(22)")]#text(" implies the log-Sobolev inequality ")#link(<tao-9b9a3717eacd16206b4b>)[#text("(21)")]#text(". In the Gaussian case ")#link(<tao-a19ee2577879b76a5b98>)[#text("(11)")]#text(", the hypercontractivity inequality is due ")#link("http://www.ams.org/mathscinet-getitem?mr=210416")[#text("to Nelson")]#text("; the equivalence between the two inequalities was first observed ")#link("http://www.zentralblatt-math.org/zmath/en/search/?q=an:0165.58301&format=complete")[#text("by Federbush")]#text(".")
]

#text("Log-Sobolev inequalities can also be used to establish concentration of measure inequalities; see for instance ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("this previous blog post")]#text(" for an instance of this.")

#text("The exponential convergence to equilibrium in the convex case should be contrasted with the polynomial convergence to zero in the Euclidean case. As always, the model gaussian case ")#link(<tao-a19ee2577879b76a5b98>)[#text("(11)")]#text(" is instructive. Let us use the Brownian motion formalism. In the Euclidean case, using the Brownian motion ")#link(<tao-5eb67f9f8409b9c3f739>)[#text("(2)")]#text(", and assuming mean zero ")#mi("{\\mathop{\\bf E} x(t) = 0}")#text(" for simplicity, we have constant variance production thanks to Ito’s formula ")#tao-math("{\\mathop{\\bf E} \\left|dB_t\\right|^2 = dt}", block: false)#text(":")

#align(center)[#tao-fit-display[#tao-math("\\frac{d}{dt} \\mathop{\\bf E}\\left|x(t)\\right|^2 = 1.", block: true)]]

#text("On the other hand, with the Ornstein-Uhlenbeck process ")#link(<tao-6bd1b55c3c729cce8bc1>)[#text("(15)")]#text(" with mean zero, a short computation shows that the variance instead obeys the formula")

#align(center)[#tao-fit-display[#tao-math("\\frac{d}{dt} \\mathop{\\bf E} \\left|x(t)\\right|^2 = 1 - \\mathop{\\bf E} \\left|x(t)\\right|^2", block: true)]]

#text("and thus ")#tao-math("{\\mathop{\\bf E} \\left|x(t)\\right|^2 - 1}", block: false)#text(" relaxes exponentially fast to the identity. One can also see this from the explicit solution")

#align(center)[#tao-fit-display[#tao-math("f(t,x)\\ d\\mu(x) = \\frac{1}{(2\\pi (1+e^{-t}))^{n/2}} e^{-\\left|x\\right|^2/2(1+e^{-t})}\\ dx", block: true)]]

#text("to the Ornstein-Uhlenbeck equation ")#link(<tao-57a5c2812fa064eb89aa>)[#text("(16)")]#text(".")

#text("The exponential convergence to equilibrium can also be understood as a probabilistic mixing inequality. Let us take the model case of a quadratic Hamiltonian attaining a minimum at ")#mi("{x_0}")#text(": ")#metadata(none) <tao-e6ffaf87ee6dd87be190>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#tao-math("H(x) = \\frac{1}{2} \\rho \\left|x-x_0\\right|^2 + H(x_0).", block: true)]]

#text("In this case, the stochastic equation is a more general Ornstein-Uhlenbeck process")

#align(center)[#tao-fit-display[#mitex("dx = dB_t - \\beta \\rho (x-x_0) dt.")]]

#text("The natural length scale for the measure ")#mi("{\\mu}")#text(" is ")#mi("{O((\\beta \\rho)^{-1/2})}")#text(", since the weight ")#mi("{e^{-\\beta H}}")#text(" starts decreasing faster than exponentially once one wanders more than this length scale away from the Hamiltonian minimiser ")#mi("{x_0}")#text(". The natural scale for the drift velocity ")#mi("{-\\beta \\rho(x-x_0)}")#text(" is thus ")#mi("{O( (\\beta \\rho)^{1/2} )}")#text(". Over a time scale ")#mi("{t=O(T)}")#text(", the net drift should then be ")#mi("{O( (\\beta \\rho)^{1/2} T)}")#text(", while the net diffusion from the Brownian motion component ")#mi("{dB_t}")#text(" of the process should be ")#mi("{O(T^{1/2})}")#text(". The two contributions meet at ")#mi("{T \\sim (\\beta \\rho)^{-1}}")#text(", which helps explain why this is the mixing time for relaxation to equilibrium; it is basically the time needed for the random portion of the dynamics to fill out the space drawn by the equilibrium.")

#text("The above Bakry-Emery theory works well when the Hamiltonian is “isotropic” in the sense that it has about the same amount of convexity in any direction (or to put it another way, the Hessian ")#mi("{\\nabla^2 H}")#text(" is well-conditioned), as was the case in the quadratic examples ")#link(<tao-e6ffaf87ee6dd87be190>)[#text("(23)")]#text(". But it does not give completely satisfactory results for “non-isotropic” choices of Hamiltonian. A simple example is provided by the two-dimensional anisotropic quadratic Hamiltonian ")#metadata(none) <tao-2790770b1de05bcc790d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("H(x_1,x_2) = \\frac{1}{2} \\rho_1 x_1^2 + \\frac{1}{2} \\rho_2 x_2^2")]]

#text("for some ")#mi("{0 < \\rho_1 < \\rho_2}")#text(" with ")#mi("{\\beta=1}")#text("; this corresponds to two decoupled Ornstein-Uhlenbeck process, a “slow” process")

#align(center)[#tao-fit-display[#mitex("dx_1 = dB^1_t - \\rho_1 x dt")]]

#text("which takes time ")#mi("{O(1/\\rho_1)}")#text(" to converge to equilibrium, and an independent “fast” process")

#align(center)[#tao-fit-display[#mitex("dx_2 = dB^2_t - \\rho_2 x dt")]]

#text("which takes the shorter time of ")#mi("{O(1/\\rho_2)}")#text(" to converge to equilibrium. One should view ")#mi("{x_1}")#text(" as a “macroscopic” or “global” coordinate of a system, while ")#mi("{x_2}")#text(" is a “microscopic” or “local” coordinate. We have the strict convexity bound ")#metadata(none) <tao-2724e2268970074519bf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#tao-math("\\nabla^2 H(u,u) = \\rho_1 u_1^2 + \\rho_2 u_2^2 \\geq \\rho_1 \\left|u\\right|^2", block: true)]]

#text("which by the above theory gives convergence to equilibrium of the combined process ")#mi("{(x_1,x_2)}")#text(" in time ")#mi("{O(1/\\rho_1)}")#text(". This is the right order of magnitude if one is interested in convergence to global equilibrium, but it does not capture the fact that convergence to local equilibrium (as measured by convergence of the ")#mi("{x_2}")#text(" component) can occur at times much sooner than ")#mi("{O(1/\\rho_1)}")#text(". However, in ")#link("http://arxiv.org/abs/0907.5605")[#text("a series")]#text(" ")#link("http://arxiv.org/abs/0911.3687")[#text("of papers")]#text(" by Erdos, Schlein, Yau, and Yin (see also these ")#link("http://arxiv.org/abs/1004.0861")[#text("later")]#text(" ")#link("http://arxiv.org/abs/1106.4986")[#text("surveys")]#text("), the ")#emph[#text("local relaxation flow method")]#text(" were developed to improve upon the basic Bakry-Emery theory, with applications to the universality theory of random matrices. We can illustrate some of the basic ideas of this method with the simple example of the decoupled Hamiltonian ")#link(<tao-2790770b1de05bcc790d>)[#text("(24)")]#text(" (though the whole point of the method, for the purpose of applications, is that it can also be applied to more complicated Hamiltonians in which the slow and fast modes are coupled together).")

#text("The first trick is to refrain from applying the inequality ")#link(<tao-2724e2268970074519bf>)[#text("(25)")]#text(" to the Bakry-Emery inequality ")#link(<tao-3f8c49ce280206ab28f9>)[#text("(19)")]#text(" as it is too lossy in the fast variables. Instead, since")

#align(center)[#tao-fit-display[#mitex("\\nabla^2 H(u,u) \\geq \\rho_2 u_2^2")]]

#text("we see that ")#link(<tao-3f8c49ce280206ab28f9>)[#text("(19)")]#text(" implies that")

#align(center)[#tao-fit-display[#mitex("\\partial_t D_\\mu(g,g) \\leq - \\frac{\\rho_2}{2} \\int_{{\\bf R}^2} (\\partial_2 g)^2\\ d\\mu.")]]

#text("Integrating this, we obtain an additional bound on ")#mi("{\\partial_2 g}")#text(" which becomes useful in the regime when ")#mi("{\\rho_2}")#text(" is much larger than ")#mi("{\\rho_1}")#text(": ")#metadata(none) <tao-956fc30bfe11b61e7962>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\int_0^\\infty \\int_{{\\bf R}^2} (\\partial_2 g)^2\\ d\\mu dt \\leq \\frac{2}{\\rho_2} D_\\mu(g(0),g(0)).")]]

#text("This gives some additional smoothing in the ")#mi("{x_2}")#text(" direction. For instance, given a test function ")#mi("{F(x_1,x_2) = F(x_2)}")#text(" of the ")#mi("{x_2}")#text(" variable only, we have")

#tao-aligned(keep: true)[


#tao-math("\\partial_t \\int_{{\\bf R}^2} F f\\ d\\mu  & = \\int_{{\\bf R}^2} F Lf\\ d\\mu", block: true)



#tao-math(" & = - D_\\mu(F,f)", block: true)



#tao-math(" & = - \\frac{1}{2} \\int_{{\\bf R}^2} F^{\\prime}(x_2) \\partial_2 f\\ d\\mu", block: true)



#tao-math(" & = - \\int_{{\\bf R}^2} F^{\\prime}(x_2) g \\partial_2 g\\ d\\mu;", block: true)
]

#text("since ")#mi("{\\int_{{\\bf R}^2} g^2\\ d\\mu = 1}")#text(", we thus have from Cauchy-Schwarz that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\partial_t \\int_{{\\bf R}^2} F f\\ d\\mu\\right| \\ll \\left\\|F^{\\prime}\\right\\|_{L^\\infty} (\\int_{{\\bf R}^2} (\\partial_2 g)^2\\ d\\mu)^{1/2};", block: true)]]

#text("integrating this from ")#mi("{t=0}")#text(" to some time ")#mi("{t=T}")#text(" and using Cauchy-Schwarz again followed by, we see that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{{\\bf R}^2} F f(0)\\ d\\mu - \\int_{{\\bf R}^2} F f(T)\\ d\\mu\\right| \\ll \\frac{T^{1/2}}{\\rho_2^{1/2}} \\left\\|F^{\\prime}\\right\\|_{L^\\infty} D_\\mu(g(0),g(0))^{1/2}.", block: true)]]

#text("Given that the time to relaxation to equilibrium is ")#mi("{O(1/\\rho_1)}")#text(", we morally have ")#mi("{f(T) \\approx 1}")#text(" for ")#mi("{T \\gg 1/\\rho_1}")#text(", so heuristically at least we have the bound ")#metadata(none) <tao-4e448897946ead9e39e8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#tao-math("\\left|\\int_{{\\bf R}^2} F f(0)\\ d\\mu - \\int_{{\\bf R}^2} F\\ d\\mu\\right| \\ll \\frac{1}{\\rho_1^{1/2} \\rho_2^{1/2}} \\left\\|F^{\\prime}\\right\\|_{L^\\infty} D_\\mu(g(0),g(0))^{1/2}.", block: true)]]

#text("For sake of comparison, the log-Sobolev inequality ")#link(<tao-9b9a3717eacd16206b4b>)[#text("(21)")]#text(" followed by Lemma ")#link(<tao-8b1101c7d738ce75a708>)[#text("1")]#text(" gives a bound of the shape")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{{\\bf R}^2} F f(0)\\ d\\mu - \\int_{{\\bf R}^2} F\\ d\\mu\\right| \\ll \\frac{1}{\\rho_1^{1/2}} \\left\\|F\\right\\|_{L^\\infty} D_\\mu(g(0),g(0))^{1/2}", block: true)]]

#text("for all ")#mi("{F}")#text(" (which can now depend on ")#mi("{x_1}")#text(" as well as ")#mi("{x_2}")#text("). The bound ")#link(<tao-4e448897946ead9e39e8>)[#text("(27)")]#text(" is better than the log-Sobolev bound when the test function ")#mi("{F}")#text(" is spread out over scales larger than the natural length scale ")#mi("{\\rho_2^{1/2}}")#text(" of the fast variable. This suggests that such statistics are universal among all distributions ")#mi("{f\\ d\\mu}")#text(" for which one can control the Dirichlet functional ")#mi("{D_\\mu(\\sqrt{f},\\sqrt{f})}")#text(". (In the context of the theory of universality theory for Wigner random matrices, this corresponds to local spectral statistics that have been averaged in the energy parameter in order to reduce the dependence of these statistics on fast variables.)")

#text("The above trick improves the estimates somewhat, but it still involves the slow relaxation time ")#mi("{T = O(1/\\rho_1)}")#text(", which is undesirable for some applications. The second trick in the method of local relaxation flow is to modify the Hamiltonian, working with a more convexified (but slightly artificial) Hamiltonian ")#mi("{\\tilde H}")#text(", such as ")#metadata(none) <tao-cdc2def9aec4576c7f9f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#tao-math("\\tilde H(x) := H(x) + \\frac{1}{2} \\rho_* \\left|x\\right|^2", block: true)]]

#text("for some parameter ")#mi("{\\rho_*}")#text(", which one can think of as being intermediate between ")#mi("{\\rho_1}")#text(" and ")#mi("{\\rho_2}")#text(" for our toy example. Since ")#tao-math("{\\nabla^2 \\tilde H(u,u) \\geq \\rho_* \\left|u\\right|^2}", block: false)#text(", Bakry-Emery theory tells us that the associated heat equation ")#mi("{\\partial_t \\tilde f = \\tilde L \\tilde f}")#text(" associated to this modified Hamiltonian (which Erdos, Schlein, Yau, and Yin refer to as the ")#emph[#text("local relaxation flow")]#text(") will relax to a local equilibrium measure ")#mi("{\\tilde \\mu}")#text(" in time ")#mi("{O(1/\\rho_*)}")#text(", which can be considerably faster than the relaxation time ")#mi("{O(1/\\rho_1)}")#text(" to global equilibrium if the parameter ")#mi("{\\rho_*}")#text(" is chosen appropriately. In particular, this can lead to improvements in the constants for bounds such as ")#link(<tao-4e448897946ead9e39e8>)[#text("(27)")]#text(" (namely, by replacing ")#mi("{\\rho_1}")#text(" there with ")#mi("{\\rho_*}")#text("), at the cost of replacing the original Dirichlet energy ")#mi("{D_\\mu(g(0),g(0))}")#text(" with a modified Dirichlet energy ")#mi("{D_{\\tilde \\mu}(g(0),g(0))}")#text(".")

#text("Of course, in practice one is not directly interested in the local relaxation flow, but in solutions to the original heat equation ")#mi("{\\partial_t f = L f}")#text(". As such, the Bakry-Emery inequality ")#link(<tao-3f8c49ce280206ab28f9>)[#text("(19)")]#text(" for such flows does not directly say much about the modified Dirichlet energy ")#mi("{D_{\\tilde \\mu}(g,g)}")#text(", as it only directly controls the original Dirichlet energy ")#mi("{D_\\mu(g,g)}")#text(" (and in practice, the ratio between ")#mi("{\\tilde \\mu}")#text(" and ")#mi("{\\mu}")#text(" will be quite large). Nevertheless, one can adapt the Bakry-Emery methods to say something useful in this setting. Starting with a solution to the original heat equation ")#mi("{\\partial_t f = Lf}")#text(", we define a modified function ")#mi("{\\tilde f}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("f\\ d\\mu = \\tilde f\\ d\\tilde \\mu.")]]

#text("In other words, we have ")#mi("{f = \\tilde f \\psi}")#text(", where ")#mi("{\\psi}")#text(" is the weight ")#mi("{\\psi := \\frac{d\\tilde \\mu}{d\\mu}}")#text(". Instead of working with the entropy ")#mi("{S_\\mu(f) = \\int_{{\\bf R}^n} f \\log f\\ d\\mu}")#text(" of ")#mi("{f}")#text(" relative to ")#mi("{\\mu}")#text(", we instead work with the entropy")

#align(center)[#tao-fit-display[#mitex("S_{\\tilde \\mu}(\\tilde f) = \\int_{{\\bf R}^n} \\tilde f \\log \\tilde f\\ d\\tilde \\mu")]]

#text("of ")#mi("{\\tilde f}")#text(" with respect to ")#mi("{\\mu}")#text("; we may write this as")

#align(center)[#tao-fit-display[#mitex("S_{\\tilde \\mu}(\\tilde f) = S_\\mu(f) - \\int_{{\\bf R}^n} f \\log \\psi\\ d\\mu.")]]

#text("Differentiating this using ")#link(<tao-e1cd2701488eac23f325>)[#text("(17)")]#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\partial_t S_{\\tilde \\mu}(\\tilde f) = - 4 D_\\mu(g,g) - \\int_{{\\bf R}^n} Lf \\log \\psi\\ d\\mu")]]

#text("where ")#mi("{g = f^{1/2}}")#text(". We easily verify using ")#link(<tao-7bf67d3cc7eb91fb8fc1>)[#text("(12)")]#text(", ")#link(<tao-9414886b1ebf025db067>)[#text("(10)")]#text(" that")

#tao-aligned(keep: true)[


#tao-math("\\int_{{\\bf R}^n} Lf \\log \\psi\\ d\\mu  & = \\int_{{\\bf R}^n} f L \\log \\psi\\ d\\mu", block: true)



#tao-math(" & = \\int_{{\\bf R}^n} f (\\frac{L \\psi}{\\psi} - \\frac{\\left|\\nabla \\psi\\right|^2}{2\\psi^2})\\ d\\mu", block: true)



#tao-math(" & = \\int_{{\\bf R}^n} \\tilde f (\\frac{L \\psi}{\\psi} - \\frac{\\left|\\nabla \\psi\\right|^2}{2\\psi^2})\\ d\\tilde \\mu.", block: true)
]

#text("Meanwhile, ")#mi("{\\tilde g = \\tilde f^{1/2} = g / \\psi^{1/2}}")#text(", we have ")#mi("{\\nabla g = \\nabla \\tilde g \\sqrt{\\psi} + \\tilde g \\frac{\\nabla \\psi}{2\\sqrt{\\psi}}}")#text(", and so")

#tao-aligned(keep: true)[


#tao-math("4D_\\mu(g,g)  & = 2 \\int_{{\\bf R}^n} \\left|\\nabla \\tilde g \\sqrt{\\psi} + \\tilde g \\frac{\\nabla \\psi}{2\\sqrt{\\psi}}\\right|^2\\ d\\mu", block: true)



#tao-math(" & =\\int_{{\\bf R}^n} ( 2\\left|\\nabla \\tilde g\\right|^2 \\psi + \\nabla(\\tilde g)^2 \\nabla \\psi + \\left|\\tilde g\\right|^2 \\frac{\\left|\\nabla \\psi\\right|^2}{2\\psi})\\ d\\mu", block: true)



#tao-math(" & = \\int_{{\\bf R}^n} ( 2\\left|\\nabla \\tilde g\\right|^2 \\psi - 2 (\\tilde g)^2 L \\psi + \\left|\\tilde g\\right|^2 \\frac{\\left|\\nabla \\psi\\right|^2}{2\\psi})\\ d\\mu", block: true)



#tao-math(" & = 4 D_{\\tilde \\mu}(\\tilde g,\\tilde g) - 2 \\int_{{\\bf R}^n} \\tilde f L\\psi\\ d\\mu +\\int_{{\\bf R}^n} \\tilde f \\frac{\\left|\\nabla \\psi\\right|^2}{2\\psi^2}\\ d\\tilde \\mu", block: true)
]

#text("and thus on combining these identities and simplifying, we see that")

#align(center)[#tao-fit-display[#mitex("\\partial_t S_{\\tilde \\mu}(\\tilde f) = - 4 D_{\\tilde \\mu}(\\tilde g,\\tilde g) + \\int_{{\\bf R}^n} \\tilde f L\\psi\\ d\\mu.")]]

#text("We can write the second term as")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} L\\tilde f \\psi\\ d\\mu,")]]

#text("but from ")#link(<tao-2834e64f3da4f1eb4167>)[#text("(13)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} \\tilde L\\tilde f \\psi\\ d\\mu = \\int_{{\\bf R}^n} \\tilde L \\tilde f\\ d\\tilde \\mu = 0")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\partial_t S_{\\tilde \\mu}(\\tilde f) = - 4 D_{\\tilde \\mu}(\\tilde g,\\tilde g) + \\int_{{\\bf R}^n} (L-\\tilde L) \\tilde f\\ d\\tilde \\mu.")]]

#text("If ")#mi("{\\tilde H}")#text(" is related to ")#mi("{H}")#text(" by ")#link(<tao-cdc2def9aec4576c7f9f>)[#text("(28)")]#text(" with ")#mi("{\\beta=1}")#text(", then")

#align(center)[#tao-fit-display[#mitex("L - \\tilde L = \\rho_* x \\cdot \\nabla")]]

#text("and so")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{{\\bf R}^n} (L-\\tilde L) \\tilde f\\ d\\tilde \\mu\\right| \\leq 2 \\rho_* \\int_{{\\bf R}^n} \\tilde g \\left|x\\right| \\left|\\nabla \\tilde g\\right|\\ d\\tilde \\mu.", block: true)]]

#text("To remove the derivative here, we can apply the arithmetic mean-geometric mean inequality to obtain")

#align(center)[#tao-fit-display[#tao-math("2 \\rho_* \\int_{{\\bf R}^n} \\tilde g \\left|x\\right| \\left|\\nabla \\tilde g\\right|\\ d\\tilde \\mu \\leq D_{\\tilde \\mu}(\\tilde g,\\tilde g) + O( \\int_{{\\bf R}^n} \\left|x\\right|^2 \\tilde f\\ d\\tilde \\mu)", block: true)]]

#text("and so")

#align(center)[#tao-fit-display[#tao-math("\\partial_t S_{\\tilde \\mu}(\\tilde f) \\leq - D_{\\tilde \\mu}(\\tilde g, \\tilde g) + O( \\int_{{\\bf R}^n} \\left|x\\right|^2 \\tilde f\\ d\\tilde \\mu).", block: true)]]

#text("In many applications, one can get good control on the variance ")#tao-math("{\\int_{{\\bf R}^n} \\left|x\\right|^2 \\tilde f\\ d\\tilde \\mu}", block: false)#text("; in the context of universality for Wigner matrices, such bounds can be obtained from ")#emph[#text("local semi-circular laws")]#text(", and particularly from a strong version of such a law, known as ")#emph[#text("eigenvalue rigidity")]#text(". Because of this, one can get good bounds on the entropy ")#mi("{S_{\\tilde \\mu}(\\tilde f)}")#text(" and Dirichlet form ")#mi("{D_{\\tilde \\mu}(\\tilde g,\\tilde g)}")#text(" with respect to the local equilibrium measure in these cases in timescales as short as ")#mi("{O(1/\\rho_*)}")#text("; see for instance ")#link("http://arxiv.org/abs/1106.4986")[#text("this survey of Erdos and Yau")]#text(" for details.")

#text("One of the main applications of the local relaxation flow method is to obtain universality for various local statistics of random matrices after averaging in the energy parameter. In some cases (notably in that of complex Wigner matrices that match the GUE ensemble to second order) it is possible to remove the energy averaging by using methods based on explicit formulae for the correlation functions, rather than by the local relaxation flow method; this was first achieved for certain classes of ensembles ")#link("http://arxiv.org/abs/math-ph/0006020")[#text("by Johansson")]#text(", and later extended to increasingly wider sets of ensembles by many authors. However, it appears difficult to obtain such fixed-energy results from heat flow methods alone, as there is an insufficient amount of concentration of measure for the fixed-energy measurements. However, by combining these methods with (a variant of) the Holder continuity theory of parabolic equations ")#link("http://www.ams.org/mathscinet-getitem?mr=2784330")[#text("of Caffarelli, Chan, and Vasseur")]#text(", ")#link("http://arxiv.org/abs/1211.3786")[#text("Erdos and Yau were recently able")]#text(" to obtain universality for a slightly different statistic, namely a fixed gap ")#mi("{\\lambda_{i+1}-\\lambda_i}")#text(" between eigenvalues, without any averaging in the ")#mi("{i}")#text(" parameter. This avoids the need for energy averaging, but on the other hand the statistic studied is invariant with respect to the slow mode in which all the eigenvalues are translated by the same amount. It remains a technical challenge to discover a technique for understanding statistics that are not invariant (or nearly invariant) with respect to the slow mode, which does not invoke either explicit formulae or energy averaging.")

#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af54948163e2f8d721a73c87c70099a6d5e1abead80238d510ae083fe21a42f8-f7818a6e733d8dd8f833a0a2e4959d78deac6c97ea80694f3978efc8e872a0dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hanbangxian")]], [#link("https://terrytao.wordpress.com/2013/02/05/some-notes-on-bakry-emery-theory/#comment-215988")[#strong[#text("hanbangxian")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2013")])]

#text("I am not sure if the problem you mentioned for random graph has relationship with the Ricci curvature of a graph.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb6268cbed30cccbc31d3bcb25353720767ea5fac57341b64560a2164ab98d52-b305ea421a2226f1dd4ca3d1f69533f801af6248fa89845a152498615814b636.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of d")]], [#link("https://terrytao.wordpress.com/2013/02/05/some-notes-on-bakry-emery-theory/#comment-216080")[#strong[#text("d")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2013")])]

#text("I think your definition of entropy has the opposite sign to the standard one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/02/05/some-notes-on-bakry-emery-theory/#comment-216084")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2013")])]

#text("Actually, ")#link("http://en.wikipedia.org/wiki/Kullback%E2%80%93Leibler_divergence")[#text("relative entropy")]#text(" is usually defined using the positive sign (which, among other things, makes this quantity non-negative), in contrast to ")#link("http://en.wikipedia.org/wiki/Shannon_entropy")[#text("Shannon entropy")]#text(" or ")#link("http://en.wikipedia.org/wiki/Entropy_in_thermodynamics_and_information_theory")[#text("thermodynamic entropy")]#text(" which usually has the negative sign.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Djalil")]], [#link("https://terrytao.wordpress.com/2013/02/05/some-notes-on-bakry-emery-theory/#comment-216428")[#strong[#text("Djalil")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2013")])]

#text("Dear Terry,")

#text("regarding the sharp inequality for the proof of the optimal entropy-total-variation comparison, I though that it goes back at least to Kemperman (1969) ")#link("http://www.ams.org/mathscinet-getitem?mr=252112")[#text("http://www.ams.org/mathscinet-getitem?mr=252112")]#text(" pages 2174-2175. It seems to me also that the inequality is often referred to as the Pinsker or Csiszár-Kullback inequality.")

#text("Best.")

#emph[#text("[Reference added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Djalil")]], [#link("https://terrytao.wordpress.com/2013/02/05/some-notes-on-bakry-emery-theory/#comment-216446")[#strong[#text("Djalil")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2013")])]

#text("Precision: the first know proof is due to Pinsker (1963 or 64). However, the argument using the lower bound with a rational fraction is due to Kemperman (1969)… Best.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64a10c163e634cc43e2995fdce39a0040ded2ce9debaa48ee9a1396cabded53d-e2729b491f49bf837a7c4b5153d140d602bd4dd7a2258a0b475deeb0c306e225.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of salazar")]], [#link("https://terrytao.wordpress.com/2013/02/05/some-notes-on-bakry-emery-theory/#comment-239561")[#strong[#text("salazar")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2013")])]

#text("In the display above (19), the quadratic form should be defined by ")#mi("\\nabla^2 H(u,v) = (\\partial_i \\partial_j H)(u_i)(v_j)")#text(" in Einstein convention, where ")#mi("u")#text(" and ")#mi("v")#text(" are vectors?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/596a41084757ba27393d72b0c9510708609cd9e177ac7606bae6719df1d5ea64-c107d6dc6c0a14a36d28a6e7a3a55edbfcb121ddbc539615ddd1fd359d1be7ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FC7")]], [#link("https://terrytao.wordpress.com/2013/02/05/some-notes-on-bakry-emery-theory/#comment-422802")[#strong[#text("FC7")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2014")])]

#text("For your question “I do not have a satisfactorily intuitive reason for this phenomenon, but it can be proved by”. I think we have a partial answer for it. In a paper, we prove that the the third order derivative of S(f) is >=0 and the fourth order <=0. The paper can be found in arXiv: ")#link("http://arxiv.org/abs/1409.5543")[#text("http://arxiv.org/abs/1409.5543")]#linebreak()#text(" I have also sent an email to you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Entropy and rare events | What's new")]], [#link("https://terrytao.wordpress.com/2013/02/05/some-notes-on-bakry-emery-theory/#comment-459508")[#strong[#text("Entropy and rare events | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2015")])]

#text("[…] this previous blog post for a proof of this inequality.) A standard application of Jensen’s inequality reveals that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/02/05/some-notes-on-bakry-emery-theory/#comment-614026")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2020")])]

#text("I check the result of equation (7)，I think it should be 2^（ n/2） in the denominator")

#emph[#text("[I believe the exponent is correct as stated – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/15e81fd6f2da3403a7e3023302b894ad66e4d3e975af24ebedc152b98cc702b7-4fa55f0d62c917290a6fd04f77e56b82bbbbe8a3179f67ca255c6b4cdf2f5fb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TK")]], [#link("https://terrytao.wordpress.com/2013/02/05/some-notes-on-bakry-emery-theory/#comment-641419")[#strong[#text("TK")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2022")])]

#text("After eqn 10, you consider 2g d_t g for which one expression is 2g Lg by eqn 1. But another expression that you use is d_t g^2 = L g^2 and then appeal to eqn 10 to get 2gLg + |\\nabla g|^2. But this would imply |\\nabla g|^2 = 0 which seems wrong. Not sure what mistake I made….")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/15e81fd6f2da3403a7e3023302b894ad66e4d3e975af24ebedc152b98cc702b7-4fa55f0d62c917290a6fd04f77e56b82bbbbe8a3179f67ca255c6b4cdf2f5fb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TK")]], [#link("https://terrytao.wordpress.com/2013/02/05/some-notes-on-bakry-emery-theory/#comment-641426")[#strong[#text("TK")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2022")])]

#text("Oh I got the issue. Nevermind.")
]
]
