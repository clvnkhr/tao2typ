// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/05/13/dworks-proof-of-rationality-of-the-zeta-function-over-finite-fields/
// Converted to Typst by tao2typ: "2026-10-14T09:37:25.366053+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Dwork’s proof of rationality of the zeta function over finite fields", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Dwork’s proof of rationality of the zeta function over finite fields")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 May 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/05/13/dworks-proof-of-rationality-of-the-zeta-function-over-finite-fields/")[#text("https://terrytao.wordpress.com/2014/05/13/dworks-proof-of-rationality-of-the-zeta-function-over-finite-fields/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{V}")#text(" be a ")#link("http://en.wikipedia.org/wiki/Quasi-projective_variety")[#text("quasiprojective variety")]#text(" defined over a finite field ")#mi("{{\\bf F}_q}")#text(", thus for instance ")#mi("{V}")#text(" could be an affine variety ")#metadata(none) <tao-d18b0d4411bb927a0d70>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("V = \\{ x \\in {\\bf A}^d: P_1(x) = \\dots = P_m(x) = 0\\}")]]

#text("where ")#mi("{{\\bf A}^d}")#text(" is ")#mi("{d}")#text("-dimensional affine space and ")#mi("{P_1,\\dots,P_m: {\\bf A}^d \\rightarrow {\\bf A}}")#text(" are a finite collection of polynomials with coefficients in ")#mi("{{\\bf F}_q}")#text(". Then one can define the set ")#mi("{V[{\\bf F}_q]}")#text(" of ")#mi("{{\\bf F}_q}")#text("-rational points, and more generally the set ")#mi("{V[{\\bf F}_{q^n}]}")#text(" of ")#mi("{{\\bf F}_{q^n}}")#text("-rational points for any ")#mi("{n \\geq 1}")#text(", since ")#mi("{{\\bf F}_{q^n}}")#text(" can be viewed as a field extension of ")#mi("{{\\bf F}_q}")#text(". Thus for instance in the affine case ")#link(<tao-d18b0d4411bb927a0d70>)[#text("(1)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("V[{\\bf F}_{q^n}] := \\{ x \\in {\\bf F}_{q^n}^d: P_1(x) = \\dots = P_m(x) = 0\\}.")]]

#text("The ")#link("http://en.wikipedia.org/wiki/Weil_conjectures")[#text("Weil conjectures")]#text(" are concerned with understanding the number ")#metadata(none) <tao-e36cbca8242a0cb2ae8b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("S_n := \\left|V[{\\bf F}_{q^n}]\\right|", block: true)]]

#text("of ")#mi("{{\\bf F}_{q^n}}")#text("-rational points over a variety ")#mi("{V}")#text(". The first of these conjectures was proven ")#link("http://www.ams.org/mathscinet-getitem?mr=140494")[#text("by Dwork")]#text(", and can be phrased as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Rationality of the zeta function)")]#text(" ")#metadata(none) <tao-a758ef9a983916caae3d>#text(" Let ")#mi("{V}")#text(" be a quasiprojective variety defined over a finite field ")#mi("{{\\bf F}_q}")#text(", and let ")#mi("{S_n}")#text(" be given by ")#link(<tao-e36cbca8242a0cb2ae8b>)[#text("(2)")]#text(". Then there exist a finite number of algebraic integers ")#mi("{\\alpha_1,\\dots,\\alpha_k, \\beta_1,\\dots,\\beta_{k^{\\prime}} \\in O_{\\overline{{\\bf Q}}}}")#text(" (known as ")#emph[#text("characteristic values")]#text(" of ")#mi("{V}")#text("), such that")

#align(center)[#tao-fit-display[#mitex("S_n = \\alpha_1^n + \\dots + \\alpha_k^n - \\beta_1^n - \\dots - \\beta_{k^{\\prime}}^n")]]

#text("for all ")#mi("{n \\geq 1}")#text(".")
]

#text("After cancelling, we may of course assume that ")#mi("{\\alpha_i \\neq \\beta_j}")#text(" for any ")#mi("{i=1,\\dots,k}")#text(" and ")#mi("{j=1,\\dots,k^{\\prime}}")#text(", and then it is easy to see (as we will see below) that the ")#mi("{\\alpha_1,\\dots,\\alpha_k,\\beta_1,\\dots,\\beta_{k^{\\prime}}}")#text(" become uniquely determined up to permutations of the ")#mi("{\\alpha_1,\\dots,\\alpha_k}")#text(" and ")#mi("{\\beta_1,\\dots,\\beta_{k^{\\prime}}}")#text(". These values are known as the ")#emph[#text("characteristic values")]#text(" of ")#mi("{V}")#text(". Since ")#mi("{S_n}")#text(" is a rational integer (i.e. an element of ")#mi("{{\\bf Z}}")#text(") rather than merely an algebraic integer (i.e. an element of the ring of integers ")#mi("{O_{\\overline{{\\bf Q}}}}")#text(" of the algebraic closure ")#mi("{\\overline{{\\bf Q}}}")#text(" of ")#mi("{{\\bf Q}}")#text("), we conclude from the above-mentioned uniqueness that the set of characteristic values are invariant with respect to the Galois group ")#mi("{Gal(\\overline{{\\bf Q}} / {\\bf Q} )}")#text(". To emphasise this Galois invariance, we will not fix a specific embedding ")#mi("{\\iota_\\infty: \\overline{{\\bf Q}} \\rightarrow {\\bf C}}")#text(" of the algebraic numbers into the complex field ")#mi("{{\\bf C} = {\\bf C}_\\infty}")#text(", but work with all such embeddings simultaneously. (Thus, for instance, ")#mi("{\\overline{{\\bf Q}}}")#text(" contains three cube roots of ")#mi("{2}")#text(", but which of these is assigned to the complex numbers ")#mi("{2^{1/3}}")#text(", ")#mi("{e^{2\\pi i/3} 2^{1/3}}")#text(", ")#mi("{e^{4\\pi i/3} 2^{1/3}}")#text(" will depend on the choice of embedding ")#mi("{\\iota_\\infty}")#text(".)")

#text("An equivalent way of phrasing Dwork’s theorem is that the (")#mi("{T}")#text("-form of the) ")#link("http://en.wikipedia.org/wiki/Hasse%E2%80%93Weil_zeta_function")[#text("zeta function")]

#align(center)[#tao-fit-display[#mitex("\\zeta_V(T) := \\exp( \\sum_{n=1}^\\infty \\frac{S_n}{n} T^n )")]]

#text("associated to ")#mi("{V}")#text(" (which is well defined as a formal power series in ")#mi("{T}")#text(", at least) is equal to a rational function of ")#mi("{T}")#text(" (with the ")#mi("{\\alpha_1,\\dots,\\alpha_k}")#text(" and ")#mi("{\\beta_1,\\dots,\\beta_{k^{\\prime}}}")#text(" being the poles and zeroes of ")#mi("{\\zeta_V}")#text(" respectively). Here, we use the formal exponential")

#align(center)[#tao-fit-display[#mitex("\\exp(X) := 1 + X + \\frac{X^2}{2!} + \\frac{X^3}{3!} + \\dots.")]]

#text("Equivalently, the (")#mi("{s}")#text("-form of the) zeta-function ")#mi("{s \\mapsto \\zeta_V(q^{-s})}")#text(" is a meromorphic function on the complex numbers ")#mi("{{\\bf C}}")#text(" which is also periodic with period ")#mi("{2\\pi i/\\log q}")#text(", and which has only finitely many poles and zeroes up to this periodicity.")

#text("Dwork’s argument relies primarily on ")#link("http://en.wikipedia.org/wiki/P-adic_analysis")[#mi("{p}")#text("-adic analysis")]#text(" – an analogue of complex analysis, but over an algebraically complete (and metrically complete) extension ")#mi("{{\\bf C}_p}")#text(" of the ")#mi("{p}")#text("-adic field ")#mi("{{\\bf Q}_p}")#text(", rather than over the Archimedean complex numbers ")#mi("{{\\bf C}}")#text(". The argument is quite effective, and in particular gives explicit upper bounds for the number ")#mi("{k+k^{\\prime}}")#text(" of characteristic values in terms of the complexity of the variety ")#mi("{V}")#text("; for instance, in the affine case ")#link(<tao-d18b0d4411bb927a0d70>)[#text("(1)")]#text(" with ")#mi("{V}")#text(" of degree ")#mi("{D}")#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=506272")[#text("Bombieri used")]#text(" Dwork’s methods (in combination with Deligne’s theorem below) to obtain the bound ")#mi("{k+k^{\\prime} \\leq (4D+9)^{2d+1}}")#text(", and a subsequent ")#link("http://www.ams.org/mathscinet-getitem?mr=697259")[#text("paper of Hooley")]#text(" established the slightly weaker bound ")#mi("{k+k^{\\prime} \\leq (11D+11)^{d+m+2}}")#text(" purely from Dwork’s methods (a similar bound had also been pointed out in unpublished work of Dwork). In particular, one has bounds that are uniform in the field ")#mi("{{\\bf F}_q}")#text(", which is an important fact for many analytic number theory applications.")

#text("These ")#mi("{p}")#text("-adic arguments stand in contrast with ")#link("http://www.ams.org/mathscinet-getitem?mr=0340258")[#text("Deligne’s")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=601520")[#text("resolution")]#text(" of the last (and deepest) of the Weil conjectures:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Riemann hypothesis)")]#text(" Let ")#mi("{V}")#text(" be a quasiprojective variety defined over a finite field ")#mi("{{\\bf F}_q}")#text(", and let ")#mi("{\\lambda \\in \\overline{{\\bf Q}}}")#text(" be a characteristic value of ")#mi("{V}")#text(". Then there exists a natural number ")#mi("{w}")#text(" such that ")#tao-math("{\\left|\\iota_\\infty(\\lambda)\\right|_\\infty = q^{w/2}}", block: false)#text(" for every embedding ")#mi("{\\iota_\\infty: \\overline{{\\bf Q}} \\rightarrow {\\bf C}}")#text(", where ")#mi("{| |_\\infty}")#text(" denotes the usual absolute value on the complex numbers ")#mi("{{\\bf C} = {\\bf C}_\\infty}")#text(". (Informally: ")#mi("{\\lambda}")#text(" and all of its Galois conjugates have complex magnitude ")#mi("{q^{w/2}}")#text(".)")
]

#text("To put it another way that closely resembles the classical ")#link("http://en.wikipedia.org/wiki/Riemann_hypothesis")[#text("Riemann hypothesis")]#text(", all the zeroes and poles of the ")#mi("{s}")#text("-form ")#mi("{s \\mapsto \\zeta_V(q^{-s})}")#text(" lie on the critical lines ")#mi("{\\{ s \\in {\\bf C}: \\text{Re}(s) = \\frac{w}{2} \\}}")#text(" for ")#mi("{w=0,1,2,\\dots}")#text(". (See ")#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/")[#text("this previous blog post")]#text(" for further comparison of various instantiations of the Riemann hypothesis.) Whereas Dwork uses ")#mi("{p}")#text("-adic analysis, Deligne uses the essentially orthogonal technique of ")#link("http://en.wikipedia.org/wiki/%C3%89tale_cohomology")[#text("ell-adic cohomology")]#text(" to establish his theorem. However, ell-adic methods can be used (via the ")#link("http://en.wikipedia.org/wiki/Lefschetz_trace_formula#Frobenius")[#text("Grothendieck-Lefschetz trace formula")]#text(") to establish rationality, and conversely, in ")#link("http://www.ams.org/mathscinet-getitem?mr=2278753")[#text("this paper of Kedlaya")]#text(" p-adic methods are used to establish the Riemann hypothesis. As pointed out by Kedlaya, the ell-adic methods are tied to the intrinsic geometry of ")#mi("{V}")#text(" (such as the structure of sheaves and covers over ")#mi("{V}")#text("), while the ")#mi("{p}")#text("-adic methods are more tied to the ")#emph[#text("extrinsic")]#text(" geometry of ")#mi("{V}")#text(" (how ")#mi("{V}")#text(" sits inside its ambient affine or projective space).")

#text("In this post, I would like to record my notes on Dwork’s proof of Theorem ")#link(<tao-a758ef9a983916caae3d>)[#text("1")]#text(", drawing heavily on the expositions of ")#link("http://www.ams.org/mathscinet-getitem?mr=1603483")[#text("Serre")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=697259")[#text("Hooley")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=754003")[#text("Koblitz")]#text(", and others.")

#text("The basic strategy is to control the rational integers ")#mi("{S_n}")#text(" both in an “Archimedean” sense (embedding the rational integers inside the complex numbers ")#mi("{{\\bf C}_\\infty}")#text(" with the usual norm ")#mi("{||_\\infty}")#text(") as well as in the “")#mi("{p}")#text("-adic” sense, with ")#mi("{p}")#text(" the characteristic of ")#mi("{{\\bf F}_q}")#text(" (embedding the integers now in the “complexification” ")#mi("{{\\bf C}_p}")#text(" of the ")#mi("{p}")#text("-adic numbers ")#mi("{{\\bf Q}_p}")#text(", which is equipped with a norm ")#mi("{||_p}")#text(" that we will recall later). (This is in contrast to the methods of ell-adic cohomology, in which one primarily works over an ")#mi("{\\ell}")#text("-adic field ")#mi("{{\\bf Q}_\\ell}")#text(" with ")#mi("{\\ell \\neq p,\\infty}")#text(".) The Archimedean control is trivial:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Archimedean control of ")#mi("{S_n}")#text(")")]#text(" ")#metadata(none) <tao-890cabe271136403326f>#text(" With ")#mi("{S_n}")#text(" as above, and any embedding ")#mi("{\\iota_\\infty: \\overline{{\\bf Q}} \\rightarrow {\\bf C}}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\iota_\\infty(S_n)\\right|_\\infty \\leq C q^{A n}", block: true)]]

#text("for all ")#mi("{n}")#text(" and some ")#mi("{C, A >0}")#text(" independent of ")#mi("{n}")#text(".")
]

#emph[#text("Proof:")]#text(" Since ")#mi("{S_n}")#text(" is a rational integer, ")#tao-math("{\\left|\\iota_\\infty(S_n)\\right|_\\infty}", block: false)#text(" is just ")#tao-math("{\\left|S_n\\right|_\\infty}", block: false)#text(". By decomposing ")#mi("{V}")#text(" into affine pieces, we may assume that ")#mi("{V}")#text(" is of the affine form ")#link(<tao-d18b0d4411bb927a0d70>)[#text("(1)")]#text(", then we trivially have ")#tao-math("{\\left|S_n\\right|_\\infty \\leq q^{nd}}", block: false)#text(", and the claim follows. ")#mi("\\Box")

#text("Another way of thinking about this Archimedean control is that it guarantees that the zeta function ")#mi("{T \\mapsto \\zeta_V(T)}")#text(" can be defined holomorphically on the open disk in ")#mi("{{\\bf C}_\\infty}")#text(" of radius ")#mi("{q^{-A}}")#text(" centred at the origin.")

#text("The ")#mi("{p}")#text("-adic control is significantly more difficult, and is the main component of Dwork’s argument:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (")#mi("{p}")#text("-adic control of ")#mi("{S_n}")#text(")")]#text(" ")#metadata(none) <tao-8988692c5771cc4398b2>#text(" With ")#mi("{S_n}")#text(" as above, and using an embedding ")#mi("{\\iota_p: \\overline{{\\bf Q}} \\rightarrow {\\bf C}_p}")#text(" (defined later) with ")#mi("{p}")#text(" the characteristic of ")#mi("{{\\bf F}_q}")#text(", we can find for any real ")#mi("{A > 0}")#text(" a finite number of elements ")#mi("{\\alpha_1,\\dots,\\alpha_k,\\beta_1,\\dots,\\beta_{k^{\\prime}} \\in {\\bf C}_p}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\iota_p(S_n) - (\\alpha_1^n + \\dots + \\alpha_k^n - \\beta_1^n - \\dots - \\beta_{k^{\\prime}}^n)\\right|_p \\leq q^{-An}", block: true)]]

#text("for all ")#mi("{n}")#text(".")
]

#text("Another way of thinking about this ")#mi("{p}")#text("-adic control is that it guarantees that the zeta function ")#mi("{T \\mapsto \\zeta_V(T)}")#text(" can be defined ")#emph[#text("meromorphically")]#text(" on the entire ")#mi("{p}")#text("-adic complex field ")#mi("{{\\bf C}_p}")#text(".")

#text("Proposition ")#link(<tao-8988692c5771cc4398b2>)[#text("4")]#text(" is ostensibly much weaker than Theorem ")#link(<tao-a758ef9a983916caae3d>)[#text("1")]#text(" because of (a) the error term of ")#mi("{p}")#text("-adic magnitude at most ")#mi("{Cq^{-An}}")#text("; (b) the fact that the number ")#mi("{k+k^{\\prime}}")#text(" of potential characteristic values here may go to infinity as ")#mi("{A \\rightarrow \\infty}")#text("; and (c) the potential characteristic values ")#mi("{\\alpha_1,\\dots,\\alpha_k,\\beta_1,\\dots,\\beta_{k^{\\prime}}}")#text(" only exist inside the complexified ")#mi("{p}")#text("-adics ")#mi("{{\\bf C}_p}")#text(", rather than in the algebraic integers ")#mi("{O_{\\overline{{\\bf Q}}}}")#text(". However, it turns out that by combining ")#mi("{p}")#text("-adic control on ")#mi("{S_n}")#text(" in Proposition ")#link(<tao-8988692c5771cc4398b2>)[#text("4")]#text(" with the trivial control on ")#mi("{S_n}")#text(" in Proposition ")#link(<tao-890cabe271136403326f>)[#text("3")]#text(", one can obtain Theorem ")#link(<tao-a758ef9a983916caae3d>)[#text("1")]#text(" by an elementary argument that does not use any further properties of ")#mi("{S_n}")#text(" (other than the obvious fact that the ")#mi("{S_n}")#text(" are rational integers), with the ")#mi("{A}")#text(" in Proposition ")#link(<tao-8988692c5771cc4398b2>)[#text("4")]#text(" chosen to exceed the ")#mi("{A}")#text(" in Proposition ")#link(<tao-890cabe271136403326f>)[#text("3")]#text(". We give this argument (essentially due to Borel) below the fold.")

#text("The proof of Proposition ")#link(<tao-8988692c5771cc4398b2>)[#text("4")]#text(" can be split into two pieces. The first piece, which can be viewed as the number-theoretic component of the proof, uses external descriptions of ")#mi("{V}")#text(" such as ")#link(<tao-d18b0d4411bb927a0d70>)[#text("(1)")]#text(" to obtain the following decomposition of ")#mi("{S_n}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5 (Decomposition of ")#mi("{S_n}")#text(")")]#text(" ")#metadata(none) <tao-77e7172226db5b3566f7>#text(" With ")#mi("{\\iota_p}")#text(" and ")#mi("{S_n}")#text(" as above, we can decompose ")#mi("{\\iota_p(S_n)}")#text(" as a finite linear combination (over the integers) of sequences ")#mi("{S^{\\prime}_n \\in {\\bf C}_p}")#text(", such that for each such sequence ")#mi("{n \\mapsto S^{\\prime}_n}")#text(", the zeta functions")

#align(center)[#tao-fit-display[#mitex("\\zeta^{\\prime}(T) := \\exp( \\sum_{n=1}^\\infty \\frac{S^{\\prime}_n}{n} T^n ) = \\sum_{n=0}^\\infty c_n T^n")]]

#text("are entire in ")#mi("{{\\bf C}_p}")#text(", by which we mean that")

#align(center)[#tao-fit-display[#tao-math("\\left|c_n\\right|_p^{1/n} \\rightarrow 0", block: true)]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(".")
]

#text("This proposition will ultimately be a consequence of the properties of the ")#link("http://en.wikipedia.org/wiki/Teichm%C3%BCller_character")[#text("Teichmuller lifting")]#text(" ")#mi("{\\tau: \\overline{{\\bf F}_p}^\\times \\rightarrow {\\bf C}_p^\\times}")#text(".")

#text("The second piece, which can be viewed as the “")#mi("{p}")#text("-adic complex analytic” component of the proof, relates the ")#mi("{p}")#text("-adic entire nature of a zeta function with control on the associated sequence ")#mi("{S^{\\prime}_n}")#text(", and can be interpreted (after some manipulation) as a ")#mi("{p}")#text("-adic version of the ")#link("http://en.wikipedia.org/wiki/Weierstrass_preparation_theorem")[#text("Weierstrass preparation theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6 (")#mi("{p}")#text("-adic Weierstrass preparation theorem)")]#text(" ")#metadata(none) <tao-6fa9052a8f60aeb5a134>#text(" Let ")#mi("{S^{\\prime}_n}")#text(" be a sequence in ")#mi("{{\\bf C}_p}")#text(", such that the zeta function")

#align(center)[#tao-fit-display[#mitex("\\zeta^{\\prime}(T) := \\exp( \\sum_{n=1}^\\infty \\frac{S^{\\prime}_n}{n} T^n )")]]

#text("is entire in ")#mi("{{\\bf C}_p}")#text(". Then for any real ")#mi("{A > 0}")#text(", there exist a finite number of elements ")#mi("{\\beta_1,\\dots,\\beta_{k^{\\prime}} \\in {\\bf C}_p}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\iota_p(S^{\\prime}_n) + \\beta_1^n + \\dots + \\beta_{k^{\\prime}}^n\\right|_p \\leq q^{-An}", block: true)]]

#text("for all ")#mi("{n}")#text(" and some ")#mi("{C>0}")#text(".")
]

#text("Clearly, the combination of Proposition ")#link(<tao-77e7172226db5b3566f7>)[#text("5")]#text(" and Proposition ")#link(<tao-6fa9052a8f60aeb5a134>)[#text("6")]#text(" (and the non-Archimedean nature of the ")#mi("{||_p}")#text(" norm) imply Proposition ")#link(<tao-8988692c5771cc4398b2>)[#text("4")]#text(".")

#metadata(none) <tao-7d214e56a5c3ffb1c049>

#heading(level: 1)[#strong[#text(" — 1. Constructing the complex ")#mi("{p}")#text("-adics — ")]]

#text("Given a field ")#mi("{k}")#text(", a ")#emph[#text("norm")]#text(" on that field is defined to be a map ")#mi("{||: k \\rightarrow {\\bf R}^+}")#text(" obeying the following axioms for ")#mi("{x,y \\in k}")#text(":")

#list(
[#text("(Non-degeneracy) ")#tao-math("{\\left|x\\right|=0}", block: false)#text(" if and only if ")#mi("{x=0}")#text(".")],
[#text("(Multiplicativity) ")#tao-math("{\\left|xy\\right| = \\left|x\\right| \\left|y\\right|}", block: false)#text(".")],
[#text("(Triangle inequality) ")#tao-math("{\\left|x+y\\right| \\leq \\left|x\\right| + \\left|y\\right|}", block: false)#text(".")]
)

#text("If the triangle inequality can be improved to the ")#link("http://en.wikipedia.org/wiki/Ultrametric")[#text("ultra-triangle inequality")]#text(" ")#metadata(none) <tao-425ed264c86619b9975b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|x+y\\right| \\leq \\max(\\left|x\\right|, \\left|y\\right|)", block: true)]]

#text("then we say that the norm is ")#emph[#text("non-Archimedean")]#text(". The pair ")#mi("{(k, ||)}")#text(" will be referred to as a ")#emph[#text("normed field")]#text(".")

#text("The most familiar example of a norm is the usual (Archimedean) absolute value ")#tao-math("{z \\mapsto \\left|z\\right| = \\left|z\\right|_\\infty}", block: false)#text(" on the complex numbers ")#mi("{{\\bf C} = {\\bf C}_\\infty}")#text(", and thus also on its subfields ")#mi("{{\\bf R}}")#text(" and ")#mi("{{\\bf Q}}")#text(". For a given prime ")#mi("{p}")#text(", we also have the ")#mi("{p}")#text("-adic norm ")#tao-math("{x \\mapsto \\left|x\\right|_p}", block: false)#text(" defined initially on the rationals ")#mi("{{\\bf Q}}")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{a}{b}\\right|_p := p^{\\text{ord}_p(b) - \\text{ord}_p(a)}", block: true)]]

#text("for any rational ")#mi("{\\frac{a}{b}}")#text(", where ")#mi("{\\text{ord}_p(a)}")#text(" is the number of times ")#mi("{p}")#text(" divides an integer ")#mi("{a}")#text(" (with the conventions ")#mi("{\\text{ord}_p(0)=+\\infty}")#text(" and ")#mi("{p^{-\\infty} = 0}")#text("). Thus for instance ")#tao-math("{\\left|p^j\\right|_p = p^{-j}}", block: false)#text(" for any integer ")#mi("{j}")#text(", which is of course inverse to the Archimedean norm ")#tao-math("{\\left|p^j\\right|_\\infty = p^j}", block: false)#text(". (More generally, the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_arithmetic")[#text("fundamental theorem of arithmetic")]#text(" can be elegantly rephrased as the identity ")#tao-math("{\\prod_\\nu \\left|x\\right|_\\nu = 1}", block: false)#text(" for all non-zero rationals ")#mi("{x}")#text(", where ")#mi("{\\nu}")#text(" ranges over all places (i.e. over all the rational primes ")#mi("{p}")#text(", together with ")#mi("{\\infty}")#text(".) It is easy to see that ")#mi("{||_p}")#text(" is indeed a non-Archimedean norm. A ")#link("http://en.wikipedia.org/wiki/Ostrowski's_theorem")[#text("classical theorem of Ostrowski")]#text(" asserts that all norms on ")#mi("{{\\bf Q}}")#text(" are equivalent to either the Archimedean norm ")#mi("{||_\\infty}")#text(" or one of the ")#mi("{p}")#text("-adic norms ")#mi("{||_p}")#text(", although we will not need this result here.")

#text("A norm ")#mi("{||}")#text(" on a field ")#mi("{k}")#text(" defines a metric ")#tao-math("{d(x,y) := \\left|x-y\\right|}", block: false)#text(", and then one can define the ")#link("http://en.wikipedia.org/wiki/Completion_(metric_space)#Completion")[#text("metric completion")]#text(" ")#mi("{\\text{Clos}_{||}(k)}")#text(" of this field in the usual manner (as equivalence classes of Cauchy sequences in ")#mi("{k}")#text(" with respect to this metric). It is easy to see that the resulting completion is again a field, and that the norm ")#mi("{||}")#text(" on ")#mi("{k}")#text(" extends continuously to a norm on the metric completion ")#mi("{\\text{Clos}_{||}(k)}")#text(".")

#text("The metric closure of a non-Archimedean normed field is again a non-Archimedean normed field. Once one has metric completeness, one can form infinite series ")#mi("{\\sum_{n=1}^\\infty x_n}")#text(" of elements of the field in the usual manner; but the non-Archimedean setting is somewhat better behaved than the Archimedean setting. In particular, it is easy to see that if ")#mi("{k = (k,||)}")#text(" is a non-Archimedean metrically complete normed vector field, then an infinite series ")#mi("{\\sum_{n=1}^\\infty x_n}")#text(" is convergent if and only if it obeys the ")#link("http://en.wikipedia.org/wiki/Term_test")[#text("zero test")]#text(" ")#tao-math("{\\lim_{n \\rightarrow \\infty} \\left|x_n\\right| = 0}", block: false)#text(", and furthermore that convergent series are automatically ")#link("http://en.wikipedia.org/wiki/Unconditional_convergence")[#text("unconditionally convergent")]#text(". (The notion of absolute convergence is not particularly relevant in non-Archimedean fields.) Thus we can talk about a countable series ")#mi("{\\sum_{n \\in I} x_n}")#text(" in a non-Archimedean metrically complete normed vector field being convergent without having to be concerned about the ordering of the series.")

#text("As key examples of metric completion, we recall that using the Archimedean norm ")#mi("{||_\\infty}")#text(", the metric completion ")#mi("{\\text{Clos}_{||_\\infty}({\\bf Q})}")#text(" of the rationals is the reals ")#mi("{{\\bf R} = {\\bf Q}_\\infty}")#text(", whereas using a ")#mi("{p}")#text("-adic norm ")#mi("{||_\\infty}")#text(", the metric completion ")#mi("{\\text{Clos}_{||_p}({\\bf Q})}")#text(" of the rationals is instead the ")#link("http://en.wikipedia.org/wiki/P-adic_numbers")[#mi("{p}")#text("-adic field")]#text(" ")#mi("{{\\bf Q}_p}")#text(".")

#text("Note that the metric notion of completeness (convergence of every Cauchy sequence) is distinct from the algebraic notion of completeness (solvability of every non-constant polynomial equation, also known as being algebraically closed). For instance, the fields ")#mi("{{\\bf R}={\\bf Q}_\\infty}")#text(" and ")#mi("{{\\bf Q}_p}")#text(" are metrically complete, but not algebraically complete. However, the two notions of completeness are related to each other in a number of ways. Firstly, the metric completion of an algebraically complete field remains algebraically complete:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7")]#text(" ")#metadata(none) <tao-355b1bbfc96725cdce8f>#text(" Let ")#mi("{(k, ||)}")#text(" be a normed field which is algebraically closed. Then the metric completion ")#mi("{\\text{Clos}_{||}(k)}")#text(" is also algebraically closed.")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{P(x) = x^d + a_{d-1} x^{d-1} + \\dots + a_0}")#text(" be a monic polynomial of some degree ")#mi("{d \\geq 1}")#text(" with coefficients ")#mi("{a_0,\\dots,a_{d-1}}")#text(" in ")#mi("{\\text{Clos}_{||}(k)}")#text(". We need to show that ")#mi("{P}")#text(" has at least one root in ")#mi("{\\text{Clos}_{||}(k)}")#text(". By construction of ")#mi("{\\text{Clos}_{||}(k)}")#text(", we can view ")#mi("{P}")#text(" as the limit of polynomials ")#mi("{P_n(x) = x^d + a_{d-1,n} x^{d-1} + \\dots + a_{0,n}}")#text(" with coefficients ")#mi("{a_{0,n},\\dots,a_{d-1,n} \\in k}")#text(", where the convergence is in the sense that each coefficient ")#mi("{a_{i,n}}")#text(" converges to ")#mi("{a_i}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(" for ")#mi("{i=0,\\dots,d-1}")#text(". As ")#mi("{k}")#text(" is already algebraically closed, each ")#mi("{P_n}")#text(" has ")#mi("{d}")#text(" roots ")#mi("{z_{1,n},\\dots,z_{d,n} \\in k}")#text(" (possibly with repetition). Because the ")#mi("{a_{i,n}}")#text(" are bounded, it is easy to see from the equation ")#mi("{P_n(z_{i,n})=0}")#text(" that the roots ")#mi("{z_{i,n}}")#text(" are uniformly bounded in ")#mi("{n}")#text(". Among other things, this implies that ")#mi("{P_n(z_{i,m})}")#text(" converges to zero as ")#mi("{n,m \\rightarrow \\infty}")#text(", since ")#mi("{P_m(z_{i,m})=0}")#text(" and the coefficients of ")#mi("{P_m-P_n}")#text(" converge to zero. Writing ")#mi("{P_n(z_{i,m}) = \\prod_{j=1}^n (z_{i,m}-z_{j,n})}")#text(", we conclude that the distance between ")#mi("{z_{i,m}}")#text(" and the zero set ")#mi("{\\{z_{1,n},\\dots,z_{d,n}\\}}")#text(" goes to zero as ")#mi("{n,m \\rightarrow \\infty}")#text(". From this one can easily extract a Cauchy sequence ")#mi("{z_{i_j, n_j}}")#text(" with ")#mi("{n_j \\rightarrow \\infty}")#text(", which then converges to a limit ")#mi("{z \\in \\text{Clos}_{||}(k)}")#text(" which can be seen to be a zero of ")#mi("{P}")#text(", giving the claim. ")#mi("\\Box")

#text("In the other direction, in the case of the ")#mi("{p}")#text("-adics at least, it is possible to extend a norm on a field to the algebraic closure of that field:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8")]#text(" For any ")#mi("{z}")#text(" in the algebraic closure ")#mi("{\\overline{{\\bf Q}_p}}")#text(" of ")#mi("{{\\bf Q}_p}")#text(", define the norm ")#tao-math("{\\left|z\\right|_p}", block: false)#text(" of ")#mi("{z}")#text(" by the formula ")#metadata(none) <tao-9889a3fb03c5db96d1c6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|z\\right| := \\left|z_1 \\dots z_d\\right|^{1/d}", block: true)]]

#text("where ")#mi("{z_1,\\dots,z_d}")#text(" are the Galois conjugates of ")#mi("{z}")#text(" in ")#mi("{\\overline{{\\bf Q}_p}}")#text(" (so in particular ")#mi("{z_1 \\dots z_d \\in {\\bf Q}_p}")#text("). Then ")#mi("{\\overline{{\\bf Q}_p}}")#text(" becomes a non-Archimedean normed field with this norm.")
]

#text("The situation is much more complicated in the Archimedean case, as there is no canonical way to extend the norm in this case. For instance, if one wishes to extend the Archimedean norm ")#mi("{||_\\infty}")#text(" from ")#mi("{{\\bf Q}}")#text(" to ")#mi("{\\overline{{\\bf Q}}}")#text(", one can do so by choosing an embedding ")#mi("{\\iota_\\infty: \\overline{{\\bf Q}} \\rightarrow {\\bf C}}")#text(" and using the Archimedean norm on ")#mi("{{\\bf C}}")#text(", but this is not a Galois-invariant definition. For instance, one of the two roots of the equation ")#mi("{x^2 - x - 1 = 0}")#text(" will have a larger norm than the other (one norm being the golden ratio, and the other being its reciprocal), but the choice of root that has the larger norm depends on the choice of embedding ")#mi("{\\iota_\\infty}")#text(". Note that the definition ")#link(<tao-9889a3fb03c5db96d1c6>)[#text("(4)")]#text(" fails to be a norm in the Archimedean case; for instance, in ")#mi("{\\overline{{\\bf Q}}}")#text(", ")#link(<tao-9889a3fb03c5db96d1c6>)[#text("(4)")]#text(" would require ")#mi("{3+2\\sqrt{2}}")#text(" and ")#mi("{3-2\\sqrt{2}}")#text(" to have norm ")#mi("{1}")#text(", while their sum would have norm ")#mi("{6}")#text(", violating the triangle inequality.")

#emph[#text("Proof:")]#text(" The only difficult task to show is the ultra-triangle inequality ")#link(<tao-425ed264c86619b9975b>)[#text("(3)")]#text(". It suffices to show that for every Galois extension ")#mi("{E}")#text(" of ")#mi("{{\\bf Q}_p}")#text(" and every ")#mi("{z,w \\in E}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left|z+w\\right| \\leq \\max(\\left|z\\right|, \\left|w\\right|).", block: true)]]

#text("We view ")#mi("{E}")#text(" as a finite-dimensional vector space over ")#mi("{{\\bf Q}_p}")#text(" of some dimension ")#mi("{d}")#text(", and identify each ")#mi("{z \\in E}")#text(" with the multiplication operator ")#mi("{M_z: E \\rightarrow E}")#text(" defined by ")#mi("{M_z x := zx}")#text(". These ")#mi("{M_z}")#text(" can be viewed as an element of ")#mi("{\\text{Hom}_{{\\bf Q}_p}(E \\rightarrow E)}")#text(", the space of ")#mi("{{\\bf Q}_p}")#text("-linear maps from ")#mi("{E}")#text(" to itself, and the determinant of ")#mi("{M_z}")#text(" has norm ")#tao-math("{\\left|z\\right|^d}", block: false)#text(" by construction. We pick some arbitrary ")#mi("{{\\bf Q}_p}")#text("-basis ")#mi("{e_1,\\dots,e_d}")#text(" of ")#mi("{E}")#text(" and use this to define a non-Archimedean “norm” ")#mi("{\\| \\|}")#text(" on ")#mi("{E}")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\| x_1 e_1 + \\dots + x_d e_d \\right\\| := \\sup_{i=1,\\dots,d} \\left|x_i\\right|", block: true)]]

#text("for ")#mi("{x_1,\\dots,x_d \\in {\\bf Q}_p}")#text(", and then define a “norm” ")#mi("{\\|\\|_{op}}")#text(" on ")#mi("{\\text{Hom}_{{\\bf Q}_p}(E \\rightarrow E)}")#text(" by")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T \\right\\|_{op} := \\sup \\{ \\left\\|Tx\\right\\|: x \\in E, \\left\\|x\\right\\| \\leq 1 \\}.", block: true)]]

#text("It is easy to see that the space ")#mi("{\\{ M_z: z \\in E \\}}")#text(" is then a closed linear subspace of ")#mi("{\\text{Hom}_{{\\bf Q}_p}(E \\rightarrow E)}")#text(". In particular, since ")#mi("{{\\bf Q}_p}")#text(" is locally compact, we see that for any compact interval ")#mi("{I \\subset (0,+\\infty)}")#text(", the set ")#tao-math("{\\{ M_z: \\left\\|M_z\\right\\|_{op} \\in I \\}}", block: false)#text(" is compact. On the other hand, as all the ")#mi("{M_z}")#text(" are invertible, ")#mi("{\\text{det}(M_z)}")#text(" is non-zero on this compact set. Thus, for any ")#mi("{I}")#text(", there exists a constant ")#mi("{C = C_I > 0}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("C^{-1} \\leq \\left|\\text{det}(M_z)\\right| \\leq C", block: true)]]

#text("for all ")#tao-math("{z \\in \\{ M_z: \\left\\|M_z\\right\\|_{op} \\in I \\}}", block: false)#text(". Since ")#tao-math("{\\text{det}(M_z) = \\left|z\\right|^d}", block: false)#text(", we then see from a rescaling argument that there is a constant ")#mi("{C^{\\prime}>0}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("(C^{\\prime})^{-1} \\left\\|z\\right\\|_{op} \\leq \\left|z\\right| \\leq C \\left\\|z\\right\\|_{op}", block: true)]]

#text("for all ")#mi("{z \\in E}")#text(". Since ")#tao-math("{\\left|z\\right| = \\left|z^n\\right|^{1/n}}", block: false)#text(", we conclude the spectral radius formula ")#metadata(none) <tao-ed3cb1d12f510dd46004>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left|z\\right| = \\lim_{n \\rightarrow \\infty} \\left\\|z^n\\right\\|_{op}^{1/n}.", block: true)]]

#text("Now we can prove the ultra-triangle inequality via the ")#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/")[#text("tensor power trick")]#text(". If ")#tao-math("{\\left|z\\right|, \\left|w\\right| \\leq A}", block: false)#text(", then from ")#link(<tao-ed3cb1d12f510dd46004>)[#text("(5)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|z^n\\right\\|_{op}, \\left\\|w^n\\right\\|_{op} \\leq (A+o(1))^n", block: true)]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text("; from this and the easy bounds ")#tao-math("{\\left\\|zw\\right\\|_{op} \\leq \\left\\|z\\right\\|_{op} \\left\\|w\\right\\|_{op}, \\left\\|z+w\\right\\|_{op} \\leq \\max( \\left\\|z\\right\\|_{op}, \\left\\|w\\right\\|_{op} )}", block: false)#text(" and binomial expansion we also conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|(z+w)^n\\right\\|_{op} \\leq (A+o(1))^n", block: true)]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(". A second application of ")#link(<tao-ed3cb1d12f510dd46004>)[#text("(5)")]#text(" then gives ")#tao-math("{\\left|z+w\\right| \\leq A}", block: false)#text(", and the ultra-triangle inequality follows. ")#mi("\\Box")

#text("Combining the two lemmas, we see that if we define")

#align(center)[#tao-fit-display[#mitex("{\\bf C}_p = \\text{Clos}_{||_p}( \\overline{{\\bf Q}_p} )")]]

#text("to be the metric completion of the algebraic completion ")#mi("{\\overline{{\\bf Q}_p}}")#text(" of the ")#mi("{p}")#text("-adic field ")#mi("{{\\bf Q}_p}")#text(", then this is a non-Archimedean normed field which is both metrically complete and algebraically complete, and serves as the analogue of the complex field ")#mi("{{\\bf C} = {\\bf C}_\\infty}")#text(". Note that ")#mi("{{\\bf C}_p}")#text(" comes with an embedding ")#mi("{\\iota_p: \\overline{{\\bf Q}} \\rightarrow {\\bf C}_p}")#text(", since ")#mi("{\\overline{{\\bf Q}}}")#text(" may clearly be embedded into ")#mi("{\\overline{{\\bf Q}_p}}")#text(". Also, the norm on ")#mi("{\\overline{{\\bf Q}}}")#text(" induced from this embedding is clearly Galois-invariant and thus independent of the choice of embedding. Finally, we remark from construction that every non-zero element of ")#mi("{\\overline{{\\bf Q}_p}}")#text(" has a norm which is a rational power ")#mi("{p^{a/b}}")#text(" of ")#mi("{p}")#text(", so on taking limits (and using the ultra-triangle inequality) we see that the same is true for non-zero elements of ")#mi("{{\\bf C}_p}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" In the Archimedean case, the analogue of ")#mi("{{\\bf Q}_p}")#text(" is the reals ")#mi("{{\\bf R} = {\\bf Q}_\\infty}")#text(", and in this case the algebraic completion ")#mi("{\\overline{{\\bf R}}}")#text(" is a finite extension of ")#mi("{{\\bf R}}")#text(" (in fact it is just a quadratic extension) and is thus already metrically complete. However, in the ")#mi("{p}")#text("-adic case, it turns out that ")#mi("{\\overline{{\\bf Q}_p}}")#text(" is an infinite extension of ")#mi("{{\\bf Q}_p}")#text(" (for instance, it contains ")#mi("{n^{th}}")#text(" roots of ")#mi("{p}")#text(" for every ")#mi("{n \\geq 1}")#text("), and is no longer metrically complete, requiring the additional application of Lemma ")#link(<tao-355b1bbfc96725cdce8f>)[#text("7")]#text(" to recover metric completeness.")
]

#heading(level: 1)[#strong[#text(" — 2. From meromorphicity to rationality — ")]]

#text("We now show how Proposition ")#link(<tao-890cabe271136403326f>)[#text("3")]#text(" and Proposition ")#link(<tao-8988692c5771cc4398b2>)[#text("4")]#text(" imply Theorem ")#link(<tao-a758ef9a983916caae3d>)[#text("1")]#text(". The basic idea is to exploit the fact that a non-zero rational integer ")#mi("{N}")#text(" cannot be simultaneously small in the Archimedean sense and in the ")#mi("{p}")#text("-adic sense, and in particular that we have an “uncertainty principle” ")#metadata(none) <tao-d626bd3aa02ef1ab0d04>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left|N\\right|_\\infty \\times \\left|N\\right|_p \\geq 1", block: true)]]

#text("which is immediate from the fundamental theorem of arithmetic. We would like to use this uncertainty principle to eliminate the error term in Proposition ")#link(<tao-8988692c5771cc4398b2>)[#text("4")]#text(", but run into the issue that many of the quantities involved here are not rational integers, but instead merely lie in ")#mi("{{\\bf C}_p}")#text(". To get around this, we have to work with expressions that are guaranteed to be rational integers, such as polynomial combinations of the ")#mi("{S_n}")#text(" with integer coefficients. To this end, we introduce the following classical lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10 (Rationality criterion)")]#text(" ")#metadata(none) <tao-9950cec246ece55e46c9>#text(" Let ")#mi("{S_n}")#text(" be a sequence in a field ")#mi("{k}")#text(", with the property that there exists a natural number ")#mi("{m \\geq 0}")#text(" such that the ")#mi("{m+1 \\times m+1}")#text(" determinants ")#metadata(none) <tao-3c2d493a01a75bfecc82>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\det ( S_{n+i+j} )_{0 \\leq i,j \\leq m}")]]

#text("vanish for all sufficiently large ")#mi("{n}")#text(". Then there exist ")#mi("{a_0,\\dots,a_m \\in k}")#text(", not all zero, such that we have the linear recurrence ")#metadata(none) <tao-a76eec4bc3720f7d0237>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("a_0 S_n + a_1 S_{n+1} + \\dots + a_m S_{n+m} = 0")]]

#text("for all sufficiently large ")#mi("{n}")#text(". (Equivalently, the formal power series ")#mi("{\\sum_n S_n T^n}")#text(" is a rational function of ")#mi("{T}")#text(".)")
]

#text("Note that in the converse direction, row operations show that if one has the recurrence ")#link(<tao-a76eec4bc3720f7d0237>)[#text("(8)")]#text(", then ")#link(<tao-3c2d493a01a75bfecc82>)[#text("(7)")]#text(" vanishes.")

#emph[#text("Proof:")]#text(" We may assume that the ")#mi("{m \\times m}")#text(" determinants ")#metadata(none) <tao-af61203ce19d7295fde8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\det ( S_{n+i+j} )_{0 \\leq i,j \\leq m-1}")]]

#text("are non-vanishing for infinitely many ")#mi("{n}")#text(" (this is a vacuous condition if ")#mi("{m=0}")#text("), since otherwise we can replace ")#mi("{m}")#text(" by ")#mi("{m-1}")#text(" in the hypotheses and conclusion.")

#text("Let ")#mi("{n}")#text(" be large enough that ")#link(<tao-3c2d493a01a75bfecc82>)[#text("(7)")]#text(" vanishes, and suppose that the determinant ")#link(<tao-af61203ce19d7295fde8>)[#text("(9)")]#text(" vanishes for this value of ")#mi("{n}")#text(". We claim that the determinant ")#metadata(none) <tao-bd88db8bccf32d1b4025>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\det ( S_{n+1+i+j} )_{0 \\leq i,j \\leq m-1}")]]

#text("also vanishes; induction then shows that ")#link(<tao-af61203ce19d7295fde8>)[#text("(9)")]#text(" vanishes for all sufficiently large ")#mi("{n}")#text(", a contradiction.")

#text("To see why ")#link(<tao-bd88db8bccf32d1b4025>)[#text("(10)")]#text(" vanishes, we argue as follows. As ")#link(<tao-af61203ce19d7295fde8>)[#text("(9)")]#text(" vanishes, there is a non-trivial linear dependence among the ")#mi("{m}")#text(" rows of the matrix in ")#link(<tao-af61203ce19d7295fde8>)[#text("(9)")]#text(". If this dependence does not involve the first row, then it also creates a non-trivial dependence among the first ")#mi("{m-1}")#text(" rows of the matrix ")#link(<tao-bd88db8bccf32d1b4025>)[#text("(10)")]#text(", and we are done. Thus we may assume that the first row in ")#link(<tao-af61203ce19d7295fde8>)[#text("(9)")]#text(" is a linear combination of the next ")#mi("{m-1}")#text(" rows. As a consequence, the first row in ")#link(<tao-3c2d493a01a75bfecc82>)[#text("(7)")]#text(" is a linear combination of the next ")#mi("{m-1}")#text(" rows, plus a vector of the form ")#mi("{(0,\\dots,0,\\beta)}")#text(" for some ")#mi("{\\beta \\in k}")#text(". If ")#mi("{\\beta}")#text(" is non-zero, then the row operations and cofactor expansion show that the determinant ")#link(<tao-3c2d493a01a75bfecc82>)[#text("(7)")]#text(" is plus or minus ")#mi("{\\beta}")#text(" times the determinant ")#link(<tao-bd88db8bccf32d1b4025>)[#text("(10)")]#text(", giving the claim. If ")#mi("{\\beta}")#text(" is instead zero, then the first ")#mi("{m}")#text(" rows of the matrix in ")#link(<tao-3c2d493a01a75bfecc82>)[#text("(7)")]#text(" have a non-trivial linear dependence, which on deleting the first column shows that the ")#mi("{m}")#text(" rows of the matrix in ")#link(<tao-bd88db8bccf32d1b4025>)[#text("(10)")]#text(" also have a non-trivial linear dependence, giving the claim.")

#text("We thus conclude that ")#link(<tao-af61203ce19d7295fde8>)[#text("(9)")]#text(" does not vanish for all sufficiently large ")#mi("{n}")#text(". In particular, the matrix in ")#link(<tao-3c2d493a01a75bfecc82>)[#text("(7)")]#text(" always has rank ")#mi("{m}")#text(". An easy induction then shows that the row span of the matrix in ")#link(<tao-3c2d493a01a75bfecc82>)[#text("(7)")]#text(" is a hyperplane in ")#mi("{k^{m+1}}")#text(" (spanned by either the first ")#mi("{m}")#text(" rows or the last ")#mi("{m}")#text(" rows), which is independent of ")#mi("{n}")#text(". Writing this hyperplane as ")#mi("{\\{ (x_0,\\dots,x_m): a_0 x_0 + \\dots + a_m x_m = 0 \\}}")#text(", we obtain the claim. ")#mi("\\Box")

#text("Now let ")#mi("{S_n}")#text(" be as in Proposition ")#link(<tao-890cabe271136403326f>)[#text("3")]#text(" and Proposition ")#link(<tao-8988692c5771cc4398b2>)[#text("4")]#text(", let ")#mi("{m}")#text(" be a large natural number to be chosen later, and consider the determinant ")#link(<tao-3c2d493a01a75bfecc82>)[#text("(7)")]#text(". This is clearly a rational integer. On the one hand, from Proposition ")#link(<tao-890cabe271136403326f>)[#text("3")]#text(" we have the upper bound ")#metadata(none) <tao-b84d3ec0078f070c0a59>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left|\\det ( S_{n+i+j} )_{0 \\leq i,j \\leq m}\\right|_\\infty \\leq C_m q^{A n (m+1)}", block: true)]]

#text("for all ")#mi("{n}")#text(" and some ")#mi("{C_m, A>0}")#text(", with ")#mi("{A}")#text(" independent of ")#mi("{m}")#text(". On the other hand, from Proposition ")#link(<tao-8988692c5771cc4398b2>)[#text("4")]#text(" we can write each row in the ")#mi("{m+1\\times m+1}")#text(" matrix in ")#link(<tao-3c2d493a01a75bfecc82>)[#text("(7)")]#text(" (after applying the embedding ")#mi("{\\iota_p}")#text(") as the linear combination of at most ")#mi("{k}")#text(" vectors of the form ")#mi("{(1, \\lambda, \\dots, \\lambda^m)}")#text(" for various ")#mi("{\\lambda \\in {\\bf C}_p}")#text(", plus an error vector whose coefficients all have norm at most ")#mi("{q^{-(A+1)n}}")#text(" (say), where ")#mi("{k}")#text(" is independent of ")#mi("{m}")#text(". Taking determinants, we conclude that ")#metadata(none) <tao-2b2c15820075359bd814>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\left|\\det ( S_{n+i+j} )_{0 \\leq i,j \\leq m}\\right|_p \\leq C^{\\prime}_m q^{-(A+1) n (m-k)}", block: true)]]

#text("for sufficiently large ")#mi("{n,m}")#text(" and some ")#mi("{C^{\\prime}_m > 0}")#text(". Inserting the two bounds ")#link(<tao-b84d3ec0078f070c0a59>)[#text("(11)")]#text(", ")#link(<tao-2b2c15820075359bd814>)[#text("(12)")]#text(" into the uncertainty principle ")#link(<tao-d626bd3aa02ef1ab0d04>)[#text("(6)")]#text(", we conclude the vanishing")

#align(center)[#tao-fit-display[#mitex("\\det ( S_{n+i+j} )_{0 \\leq i,j \\leq m} = 0")]]

#text("for all sufficiently large ")#mi("{n,m}")#text(". Applying Lemma ")#link(<tao-9950cec246ece55e46c9>)[#text("10")]#text(", we conclude that there exists a natural number ")#mi("{m \\geq 0}")#text(" and rational coefficients ")#mi("{a_0,\\dots,a_m \\in {\\bf Q}}")#text(", not all zero, such that ")#metadata(none) <tao-a072a89c0a0611ee009c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("a_0 S_n + a_1 S_{n+1} + \\dots + a_m S_{n+m} = 0")]]

#text("for all sufficiently large ")#mi("{n}")#text(". By clearing denominators, we may assume that the ")#mi("{a_i}")#text(" are all rational integers. By deleting zero terms, we may assume that ")#mi("{a_0}")#text(" and ")#mi("{a_m}")#text(" are non-zero.")

#text("We can use this recurrence to improve the conclusions of Proposition ")#link(<tao-8988692c5771cc4398b2>)[#text("4")]#text(". Observe from that proposition, after collecting like terms and absorbing any characteristic value ")#mi("{\\lambda}")#text(" with ")#tao-math("{\\left|\\lambda\\right|_p \\leq q^{-A}}", block: false)#text(" into the error term, that for any ")#mi("{A > 0}")#text(" we can find a finite number of distinct characteristic values ")#mi("{\\lambda_1,\\dots,\\lambda_k \\in {\\bf C}_p}")#text(" with ")#tao-math("{\\left|\\lambda_i\\right|_p > q^{-A}}", block: false)#text(" for ")#mi("{i=1,\\dots,k}")#text(", as well as non-zero integers ")#mi("{c_1,\\dots,c_k \\in {\\bf Z}}")#text(", such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\iota_p(S_n) - \\sum_{i=1}^k c_i \\lambda_i^n\\right|_p \\leq q^{-An}", block: true)]]

#text("for all ")#mi("{n}")#text(". Applying ")#link(<tao-a072a89c0a0611ee009c>)[#text("(13)")]#text(" to eliminate the ")#mi("{S_n}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{i=1}^k c_k P(\\lambda_i) \\lambda_i^n\\right|_p \\leq q^{-An}", block: true)]]

#text("for all sufficiently large ")#mi("{n}")#text(", where ")#mi("{P}")#text(" is the characteristic polynomial")

#align(center)[#tao-fit-display[#mitex("P(z) := a_0 + a_1 z + \\dots + a_m z^m.")]]

#text("If one of the ")#mi("{\\lambda_i}")#text(" is not a root of ")#mi("{P}")#text(", then by applying difference operators")

#align(center)[#tao-fit-display[#mitex("\\partial_\\lambda S_n := S_{n+1} - \\lambda S_n")]]

#text("to eliminate all the other characteristic values, we eventually conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\lambda_i^n\\right|_p \\leq C_i q^{-An}", block: true)]]

#text("for all sufficiently large ")#mi("{n}")#text(" and some ")#mi("{C_i}")#text(" independent of ")#mi("{n}")#text(", contradicting the hypothesis ")#tao-math("{\\left|\\lambda_i\\right|_p > q^{-A}}", block: false)#text(". Thus all the ")#mi("{\\lambda_i}")#text(" are zeroes of ")#mi("{P}")#text(" and in particular lie in ")#mi("{\\overline{{\\bf Q}}}")#text(". If we then let ")#mi("{\\zeta_1,\\dots,\\zeta_l \\in \\overline{{\\bf Q}}}")#text(" be an enumeration of the distinct zeroes of ")#mi("{P}")#text(" (which are all non-zero by the non-vanishing of ")#mi("{a_0}")#text("), and choose ")#mi("{A}")#text(" such that ")#tao-math("{\\left|\\zeta_i\\right| > q^{-A}}", block: false)#text(" for all ")#mi("{i=1,\\dots,l}")#text(", we conclude that for each ")#mi("{A}")#text(", there exist integers ")#mi("{c_i = c_{i,A}}")#text(" for ")#mi("{i=1,\\dots,l}")#text(" such that ")#metadata(none) <tao-18fd1bbc0207603d84f9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\left|S_n - \\sum_{i=1}^l c_i \\zeta_i^n\\right|_p \\leq q^{-An}", block: true)]]

#text("for all ")#mi("{n}")#text(". The coefficients ")#mi("{c_i}")#text(" ostensibly depend on ")#mi("{A}")#text(", but a repetition of the above arguments show that they are in fact independent of ")#mi("{A}")#text(", since given two ")#mi("{A,A^{\\prime}}")#text(" with ")#tao-math("{\\left|\\zeta_i\\right| > q^{-A} \\geq q^{-A^{\\prime}}}", block: false)#text(", we see from the triangle inequality that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{i=1}^l (c_{i,A} - c_{i,A^{\\prime}}) \\zeta_i^n\\right|_p \\leq q^{-An}", block: true)]]

#text("for all ")#mi("{n}")#text(", and then by applying difference operators to isolate a single ")#mi("{\\zeta_i}")#text(", we see that ")#mi("{c_{i,A} = c_{i,A^{\\prime}}}")#text(" for all ")#mi("{i}")#text(". (Note that this argument also gives the uniqueness of the characteristic values that was asserted in the introduction.) As the ")#mi("{c_i}")#text(" are independent of ")#mi("{A}")#text(", we may send ")#mi("{A \\rightarrow \\infty}")#text(" in ")#link(<tao-18fd1bbc0207603d84f9>)[#text("(14)")]#text(", and conclude that ")#metadata(none) <tao-fa7db7cf8697a2407957>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("S_n = \\sum_{i=1}^l c_i \\zeta_i^n")]]

#text("for all ")#mi("{n}")#text(".")

#text("We are now nearly done, except that the ")#mi("{\\zeta_i \\in \\overline{{\\bf Q}}}")#text(" are algebraic ")#emph[#text("numbers")]#text(" rather than algebraic integers. However, as the ")#mi("{S_n}")#text(" are rational integers, we have ")#tao-math("{\\left|S_n\\right|_\\ell \\leq 1}", block: false)#text(" for all ")#mi("{n}")#text(" and ")#mi("{\\ell}")#text(", and applying difference operators to ")#link(<tao-fa7db7cf8697a2407957>)[#text("(15)")]#text(" to isolate ")#mi("{\\zeta_i}")#text(" we conclude that ")#tao-math("{\\left|\\zeta_i\\right|_\\ell \\leq 1}", block: false)#text(" for all ")#mi("{i}")#text(" and all ")#mi("{\\ell}")#text(". As the characteristic values are closed under the absolute Galois group of ")#mi("{{\\bf Q}}")#text(", we conclude that all Galois conjugates of ")#mi("{\\zeta_i}")#text(" also have ")#mi("{\\ell}")#text("-adic norm at most one, so the minimal polynomial of ")#mi("{\\zeta_i}")#text(" in ")#mi("{{\\bf Q}}")#text(" has coefficients that are rational and have ")#mi("{\\ell}")#text("-adic norm at most one for every ")#mi("{\\ell}")#text(", and are thus rational integers, so that ")#mi("{\\zeta_i}")#text(" is an algebraic integer as required. Theorem ")#link(<tao-a758ef9a983916caae3d>)[#text("1")]#text(" follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 11")]#text(" The argument above is has been slightly rearranged from the standard argument in the literature, in which one establishes rationality of the zeta function ")#mi("{\\exp(\\sum_{n=1}^\\infty \\frac{S_n}{n} T^n)}")#text(" directly, rather than first establishing rationality of the generating function ")#mi("{\\sum_{n=1}^\\infty S_n T^n}")#text(" (which is essentially the logarithmic derivative of the zeta function). The reason I did so was to highlight the fact that transcendental operations such as exponentiation do not play a role in this portion of the argument, in contrast to Propositions ")#link(<tao-77e7172226db5b3566f7>)[#text("5")]#text(" and ")#link(<tao-6fa9052a8f60aeb5a134>)[#text("6")]#text(", which crucially exploit the properties of the exponential function.")
]

#heading(level: 1)[#strong[#text(" — 3. The ")#mi("{p}")#text("-adic Weierstrass preparation theorem — ")]]

#text("Now we prove Proposition ")#link(<tao-6fa9052a8f60aeb5a134>)[#text("6")]#text(". We begin with a theorem somewhat analogous to ")#link("http://en.wikipedia.org/wiki/Rouch%C3%A9%27s_theorem")[#text("Rouche’s theorem")]#text(" in complex analysis, which approximately locates a zero of an entire function that is dominated by a monomial ")#mi("{a_m T^m}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 12 (Rouche-type theorem)")]#text(" ")#metadata(none) <tao-150a7f114f74fba22e40>#text(" Let")

#align(center)[#tao-fit-display[#mitex("f(T) = 1 + a_1 T + a_2 T^2 + \\dots")]]

#text("be an entire function on ")#mi("{{\\bf C}_p}")#text(", thus ")#mi("{a_1,a_2,\\dots \\in {\\bf C}_p}")#text(" and ")#tao-math("{\\left|a_n\\right|_p^{1/n} \\rightarrow 0}", block: false)#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". Suppose that ")#tao-math("{\\left|a_m\\right|_p^{1/m} \\geq 1/R}", block: false)#text(" for some ")#mi("{m \\geq 1}")#text(" and ")#mi("{R>0}")#text(". Then there exists a root ")#mi("{z \\in {\\bf C}_p}")#text(" of ")#mi("{f}")#text(" (thus ")#mi("{f(z)=0}")#text(") with ")#tao-math("{\\left|z\\right|_p \\leq R}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" We first consider the polynomials")

#align(center)[#tao-fit-display[#mitex("f_n(T) = 1 + a_1 T + \\dots + a_n T^n")]]

#text("for some ")#mi("{n \\geq m}")#text(". As ")#mi("{{\\bf C}_p}")#text(" is algebraically closed, there must be a factorisation")

#align(center)[#tao-fit-display[#mitex("f_n(T) = (1-\\beta_{n,1} T) \\dots (1-\\beta_{n,n} T)")]]

#text("for some ")#mi("{\\beta_{n,1},\\dots,\\beta_{n,n} \\in {\\bf C}_p}")#text(", thus ")#mi("{a_m}")#text(" is plus or minus the ")#mi("{m^{th}}")#text(" symmetric polynomials of the ")#mi("{\\beta_{n,i}}")#text(". Since ")#tao-math("{\\left|a_m\\right|_p \\geq 1/R^m}", block: false)#text(", we conclude from the non-archimedean nature of the norm that ")#tao-math("{\\left|\\beta_{i,n}\\right|_p \\geq 1/R}", block: false)#text(" for at least one ")#mi("{i}")#text(". Similarly, given any ")#mi("{R^{\\prime}>0}")#text(", if there are exactly ")#mi("{k}")#text(" ")#mi("{i}")#text(" for which ")#tao-math("{\\left|\\beta_{i,n}\\right| \\geq 1/R^{\\prime}}", block: false)#text(", then by computing the ")#mi("{k^{th}}")#text(" symmetric polynomial we conclude that ")#tao-math("{\\left|a_k\\right|_p \\geq (1/R^{\\prime})^k}", block: false)#text(". Since ")#tao-math("{\\left|a_n\\right|_p^{1/n}}", block: false)#text(" goes to zero, we conclude that for any ")#mi("{R^{\\prime}}")#text(", the number of ")#mi("{i}")#text(" for which ")#tao-math("{\\left|\\beta_{i,n}\\right|_p \\geq 1/R^{\\prime}}", block: false)#text(" is bounded uniformly in ")#mi("{n}")#text("; the same argument shows that the ")#tao-math("{\\left|\\beta_{i,n}\\right|_p}", block: false)#text(" are uniformly bounded away from zero.")

#text("Now we run an argument somewhat similar to the proof of Lemma ")#link(<tao-355b1bbfc96725cdce8f>)[#text("7")]#text(". Let ")#mi("{n, n^{\\prime}}")#text(" be large natural numbers, and let ")#mi("{i=i_n}")#text(" be such that ")#tao-math("{\\left|\\beta_{i,n}\\right|_p \\geq 1/R}", block: false)#text(". We have")

#align(center)[#tao-fit-display[#mitex("P_n( \\frac{1}{\\beta_{i,n}} ) = 0")]]

#text("and hence (since ")#tao-math("{\\left|a_n\\right|_p^{1/n} \\rightarrow 0}", block: false)#text(")")

#align(center)[#tao-fit-display[#mitex("P_{n^{\\prime}}( \\frac{1}{\\beta_{i,n}} ) \\rightarrow 0")]]

#text("as ")#mi("{n,n^{\\prime} \\rightarrow \\infty}")#text("; thus")

#align(center)[#tao-fit-display[#tao-math("\\prod_{j=1}^{n^{\\prime}} \\left| 1 - \\frac{\\beta_{j,n^{\\prime}}}{\\beta_{i,n}}\\right|_p \\rightarrow 0.", block: true)]]

#text("On the other hand, since ")#tao-math("{\\left|\\beta_{i,n}\\right|_p \\geq 1/R}", block: false)#text(", and since ")#tao-math("{\\left|\\beta_{j,n^{\\prime}}\\right| < R}", block: false)#text(" for all but a bounded number of ")#mi("{j}")#text(", we see from the non-archimedean nature of the norm that ")#tao-math("{\\left| 1 - \\frac{\\beta_{j,n^{\\prime}}}{\\beta_{i,n}}\\right|_p = 1}", block: false)#text(" for all but a bounded number of ")#mi("{j}")#text(". Since the ")#mi("{\\beta_{j,n^{\\prime}}}")#text(" are also uniformly bounded away from zero, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\inf_{1 \\leq j \\leq n^{\\prime}} \\left|\\beta_{i,n} - \\beta_{j,n^{\\prime}}\\right|_p \\rightarrow 0", block: true)]]

#text("as ")#mi("{n,n^{\\prime} \\rightarrow \\infty}")#text(". From this, we can form a Cauchy sequence ")#mi("{\\beta_{i_k,n_k}}")#text(" such that ")#mi("{n_k \\rightarrow \\infty}")#text(" and ")#tao-math("{\\left|\\beta_{i_k,n_k}\\right|_p \\geq 1/R}", block: false)#text("; taking limits, we obtain ")#mi("{\\beta \\in {\\bf C}_p}")#text(" with ")#tao-math("{\\left|\\beta\\right|_p \\geq 1/R}", block: false)#text(" such that ")#mi("{f( \\frac{1}{\\beta} ) = 0}")#text(", giving the claim. ")#mi("\\Box")

#text("One can refine the methods in this proof to read off the ")#mi("{p}")#text("-adic magnitudes of all the zeroes of ")#mi("{f}")#text(" in terms of the ")#link("http://en.wikipedia.org/wiki/Convex_lattice_polytope")[#text("Newton polytope")]#text(" of ")#mi("{f}")#text(" (yielding a ")#mi("{p}")#text("-adic analogue of ")#link("http://en.wikipedia.org/wiki/Jensen%27s_formula")[#text("Jensen’s formula")]#text(" from complex analysis), but we will not need to do so here.")

#text("By iteratively removing the zeroes generated by the above lemma, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 13 (")#mi("{p}")#text("-adic Weierstrass preparation theorem, alternate form)")]#text(" ")#metadata(none) <tao-ffbb50b67bb60d541acb>#text(" Let")

#align(center)[#tao-fit-display[#mitex("f(T) = 1 + a_1 T + a_2 T^2 + \\dots")]]

#text("be an entire function on ")#mi("{{\\bf C}_p}")#text(", and let ")#mi("{R>0}")#text(". Then there exists a factorisation")

#align(center)[#tao-fit-display[#mitex("f(T) = (\\prod_{i=1}^m (1-\\beta_i T)) g(T)")]]

#text("where ")#mi("{\\beta_1,\\dots,\\beta_m \\in {\\bf C}_p}")#text(" and")

#align(center)[#tao-fit-display[#mitex("g(T) = 1 + b_1 T + b_2 T^2 + \\dots")]]

#text("is an entire function such that ")#tao-math("{\\left|b_n\\right|_p \\leq R^{-n}}", block: false)#text(" for all ")#mi("{n}")#text(".")
]

#emph[#text("Proof:")]#text(" We can make ")#mi("{R}")#text(" a rational power of ")#mi("{p}")#text(", and then by rescaling we may normalise ")#mi("{R=1}")#text(".")

#text("Since ")#tao-math("{\\left|a_n\\right|_p^{1/n} \\rightarrow 0}", block: false)#text(", the function ")#tao-math("{R^n \\left|a_n\\right|_p}", block: false)#text(" goes to zero as ")#mi("{n \\rightarrow \\infty}")#text(", and so there exists a natural number ")#mi("{m \\geq 0}")#text(" such that ")#metadata(none) <tao-4cdd36430d5b67e250ba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left|a_n\\right|_p \\leq \\left|a_m\\right|_p", block: true)]]

#text("for all ")#mi("{n \\geq 0}")#text(", with the convention that ")#mi("{a_0=1}")#text(", and with strict inequality if ")#mi("{n<m}")#text(". We now induct on ")#mi("{m}")#text(". If ")#mi("{m=0}")#text(" then we are already done (setting ")#mi("{g=f}")#text("). Now suppose that ")#mi("{m \\geq 1}")#text(", and that the claim has already been proven for ")#mi("{m-1}")#text(". From the strict form of ")#link(<tao-4cdd36430d5b67e250ba>)[#text("(16)")]#text(" with ")#mi("{n=0}")#text(" we have ")#tao-math("{\\left|a_m\\right|_p > 1}", block: false)#text(", so by Lemma ")#link(<tao-150a7f114f74fba22e40>)[#text("12")]#text(" we can find ")#mi("{\\beta \\in {\\bf C}_p}")#text(" with ")#tao-math("{\\left|\\beta\\right| > 1}", block: false)#text(" such that ")#mi("{f(1/\\beta)=0}")#text(". We can then factor")

#align(center)[#tao-fit-display[#mitex("f(T) = (1-\\beta T) f^{\\prime}(T)")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("f^{\\prime}(T) = 1 + a^{\\prime}_1 T + a^{\\prime}_2 T^2 + \\dots")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("a^{\\prime}_n = \\beta^n + a_1 \\beta^{n-1} + \\dots + a_n.")]]

#text("Since ")#mi("{f(1/\\beta)=0}")#text(", we also have")

#align(center)[#tao-fit-display[#mitex("a^{\\prime}_n = - \\beta^{-1} a_{n+1} - \\beta^{-2} a_{n+2} - \\dots.")]]

#text("Using ")#link(<tao-4cdd36430d5b67e250ba>)[#text("(16)")]#text(" and the non-archimedean property, one easily verifies that")

#align(center)[#tao-fit-display[#tao-math("\\left|a^{\\prime}_n\\right|_p \\leq \\frac{\\left|a_m\\right|_p}{\\left|\\beta\\right|_p} = \\left|a^{\\prime}_{m-1}\\right|_p", block: true)]]

#text("for all ")#mi("{n \\geq 0}")#text(", with strict inequality if ")#mi("{n<m-1}")#text(". Applying the induction hypothesis to ")#mi("{f^{\\prime}}")#text(", we obtain the claim. ")#mi("\\Box")

#text("Now we prove Proposition ")#link(<tao-6fa9052a8f60aeb5a134>)[#text("6")]#text(". Let ")#mi("{S^{\\prime}_n}")#text(" be as in that proposition, and let ")#mi("{A>0}")#text(" be arbitrary. By Proposition ")#link(<tao-ffbb50b67bb60d541acb>)[#text("13")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\exp( \\sum_{n=1}^\\infty \\frac{S^{\\prime}_n}{n} T^n ) = (\\prod_{i=1}^{k} (1-\\beta_i T)) g(T)")]]

#text("for some ")#mi("{\\beta_1,\\dots,\\beta_k \\in {\\bf C}_p}")#text(" and some entire function")

#align(center)[#tao-fit-display[#mitex("g(T) = 1 + b_1 T + b_2 T^2 + \\dots")]]

#text("with ")#tao-math("{\\left|b_n\\right|_p \\leq q^{-An}}", block: false)#text(" for all ")#mi("{n}")#text(". Now we apply formal logarithms")

#align(center)[#tao-fit-display[#mitex("\\log(1-X) := - X - \\frac{X^2}{2} - \\frac{X^3}{3} - \\dots")]]

#text("to both sides. Clearly ")#mi("{\\log(\\exp(f(T))) = f(T)}")#text(" for any formal power series ")#mi("{f(T)}")#text(" that actually converges in ")#mi("{{\\bf C}}")#text("; comparing coefficients, we conclude that the formal identity ")#mi("{\\log(\\exp(f(T))=f(T)}")#text(" holds in any characteristic zero field. For similar reasons we have ")#mi("{\\log(f(T) g(T)) = \\log(f(T))+\\log(g(T))}")#text(" for any formal power series ")#mi("{f(T), g(T)}")#text(" with ")#mi("{f(0)=g(0)=1}")#text(" with coefficients in a characteristic zero field. We conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{S^{\\prime}_n}{n} T^n = - \\sum_{n=1}^\\infty \\sum_{i=1}^k \\frac{\\beta_i^n}{n} T^n + \\log g(T).")]]

#text("But by working out the power series, we see that")

#align(center)[#tao-fit-display[#mitex("\\log g(T) = c_1 T + c_2 T^2 + \\dots")]]

#text("where the coefficients ")#mi("{c_n}")#text(" obey the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|c_n\\right|_p \\leq C^n q^{-An}", block: true)]]

#text("for some constant ")#mi("{C}")#text(" independent of ")#mi("{A}")#text(". The claim then follows after increasing ")#mi("{A}")#text(" as necessary.")

#heading(level: 1)[#strong[#text(" — 4. Factorising the zeta function — ")]]

#text("Now we establish Proposition ")#link(<tao-77e7172226db5b3566f7>)[#text("5")]#text(", which is the most “number-theoretical” component of Dwork’s argument.")

#text("First observe that by covering the quasiprojective variety ")#mi("{V}")#text(" into affine pieces, and using an induction on the dimension of ")#mi("{V}")#text(" to take care of any double-counted terms, we may reduce to the case when ")#mi("{V}")#text(" is an affine variety ")#link(<tao-d18b0d4411bb927a0d70>)[#text("(1)")]#text(", thus")

#align(center)[#tao-fit-display[#tao-math("S_n = \\left| \\{ x \\in {\\bf F}_{q^n}^d: P_1(x) = \\dots = P_m(x) = 0 \\}\\right|.", block: true)]]

#text("We can view ")#mi("{S_n}")#text(" as a sum ")#mi("{S_n= \\sum_{x \\in V[{\\bf F}_{q^n}]} 1}")#text(" over the affine variety ")#mi("{V}")#text(". The next step is Fourier expansion in order to “complete” the sum ")#mi("{S_n}")#text(" into exponential sums over an ambient affine space. Write ")#mi("{q=p^r}")#text(". For any ")#mi("{n \\geq 0}")#text(" define the trace map ")#mi("{\\text{Tr}_n: {\\bf F}_{p^n} \\rightarrow {\\bf F}_p}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\text{Tr}_n( x ) := x + x^p + x^{p^2} + \\dots + x^{p^{n-1}}.")]]

#text("This is a linear map over ")#mi("{{\\bf F}_p}")#text(".")

#text("Let ")#mi("{\\varepsilon}")#text(" be a primitive ")#mi("{p^{th}}")#text(" root of unity in ")#mi("{{\\bf C}_p}")#text(". Then from Fourier analysis we see that for any ")#mi("{x \\in {\\bf F}_{q^n}^d = {\\bf F}_{p^{nr}}^d}")#text(", the sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{y_1,\\dots,y_k \\in {\\bf F}_{q^n}} \\varepsilon^{\\text{Tr}_{nr}( y_1 P_1(x) + \\dots + y_m P_k(x) )}")]]

#text("is equal to ")#mi("{q^{mn}}")#text(" if ")#mi("{P_1(x)=\\dots=P_m(x)=0}")#text(" and equal to zero otherwise. Hence")

#align(center)[#tao-fit-display[#mitex("q^{mn} S_n = q^{mn} \\iota_p(S_n) = \\sum_{(x,y_1,\\dots,y_m) \\in {\\bf F}_{q^n}^{d+m}} \\varepsilon^{\\text{Tr}_{nr}( y_1 P_1(x) + \\dots + y_m P_m(x) )}.")]]

#text("In view of this (replacing ")#mi("{d+m}")#text(" by ")#mi("{d}")#text(", and rescaling the zeta function), it suffices to show that for any polynomial ")#mi("{P: {\\bf A}^d \\rightarrow {\\bf A}}")#text(" defined over ")#mi("{{\\bf F}_q}")#text(", one can decompose the sequence")

#align(center)[#tao-fit-display[#mitex("n \\mapsto \\sum_{x \\in {\\bf F}_{q}^d} \\varepsilon^{\\text{Tr}_{nr}( P(x) )}")]]

#text("as a finite linear combination over ")#mi("{{\\bf Z}}")#text(" of sequences ")#mi("{S^{\\prime}_n \\in {\\bf C}_p}")#text(" with ")#mi("{\\exp( \\sum_{n=1}^\\infty \\frac{S^{\\prime}_n}{n} T^n )}")#text(" entire.")

#text("It is convenient to remove the coordinate hyperplanes. Note that ")#mi("{{\\bf F}_{q^n}^d}")#text(" splits as the space ")#mi("{({\\bf F}_{q^n}^\\times)^d}")#text(" plus some lower-dimensional spaces, where ")#mi("{{\\bf F}_{q^n}^\\times := {\\bf F}_{q^n} \\backslash \\{0\\}}")#text(". By an induction on dimension, it thus suffices to show that the sequence")

#align(center)[#tao-fit-display[#mitex("n \\mapsto \\sum_{x \\in ({\\bf F}_{q^n}^\\times)^d} \\varepsilon^{\\text{Tr}_n( P(x) )}")]]

#text("decomposes as a finite linear combination over ")#mi("{{\\bf Z}}")#text(" of sequences ")#mi("{S^{\\prime}_n \\in {\\bf C}_p}")#text(" with ")#mi("{\\exp( \\sum_{n=1}^\\infty \\frac{S^{\\prime}_n}{n} T^n )}")#text(" entire.")

#text("To prove this, we will establish the following trace formula:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 14 (Trace formula)")]#text(" There exists a formal power series")

#align(center)[#tao-fit-display[#mitex("G(X_1,\\dots,X_d) = \\sum_{w_1,\\dots,w_d \\geq 0} c_{w_1,\\dots,w_d} X_1^{w_1} \\dots X_d^{w_d}")]]

#text("in ")#mi("{d}")#text(" variables with coefficients ")#mi("{c_{w_1,\\dots,w_d}}")#text(" in ")#mi("{{\\bf C}_p}")#text(", or more compactly")

#align(center)[#tao-fit-display[#mitex("G(X) = \\sum_{w \\in {\\bf N}^d} c_w X^w,")]]

#text("such that ")#metadata(none) <tao-8263ed4f9e6b5fbb961c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\left|c_w\\right|_p \\leq p^{-M\\left|w\\right|}", block: true)]]

#text("for all ")#mi("{w \\in {\\bf N}^d}")#text(" and some ")#mi("{M>0}")#text(" (where ")#tao-math("{\\left|w\\right| := w_1+\\dots+w_d}", block: false)#text("), such that one has the trace formula ")#metadata(none) <tao-2f8c0b475a71847a5766>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\sum_{(x \\in {\\bf F}_{q^n}^\\times)^d} \\varepsilon^{\\text{Tr}_{nr}( P(x) )} = (q^n-1)^d \\text{tr}_R( \\Psi^n )")]]

#text("for all ")#mi("{n \\geq 1}")#text(", where ")#mi("{\\Psi = \\Psi_{q,G}: R \\rightarrow R}")#text(" is the ")#mi("{{\\bf C}_p}")#text("-linear map on the (infinite-dimensional) vector space ")#mi("{R}")#text(" of all formal power series ")#mi("{F(X) = \\sum_{u \\in {\\bf N}^d} a_u X^u}")#text(" in ")#mi("{d}")#text(" variables defined by ")#metadata(none) <tao-3f4146a1d0b5dac26562>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\Psi(F(X)) = T_q( G(X) F(X) )")]]

#text("where ")#mi("{T_q: R \\rightarrow R}")#text(" is the linear map")

#align(center)[#tao-fit-display[#mitex("T_q( \\sum_{u \\in {\\bf N}^d} a_u X^u ) := \\sum_{u \\in {\\bf N}^d} a_{qu} X^u")]]

#text("and the trace ")#mi("{\\text{tr}_R}")#text(" on ")#mi("{R}")#text(" is computed using the monomial basis ")#mi("{X^u}")#text(" of ")#mi("{R}")#text(", thus if")

#align(center)[#tao-fit-display[#mitex("\\Psi^m( X^u ) = \\sum_{v \\in {\\bf N}^d} c^{(m)}_{uv} X^v")]]

#text("then")

#align(center)[#tao-fit-display[#mitex("\\text{tr}_R(\\Psi^n) := \\sum_{u \\in {\\bf N}^d} c^{(m)}_{uu};")]]

#text("one can easily verify that this sum is convergent. (We will not address the subtle issue as to whether trace is a basis-independent concept in infinite dimensions.)")
]

#text("Let us assume this trace formula for the moment and conclude the proof of Theorem ")#link(<tao-77e7172226db5b3566f7>)[#text("5")]#text(". Expanding out the ")#mi("{(q^n-1)^d}")#text(" factor in ")#link(<tao-2f8c0b475a71847a5766>)[#text("(18)")]#text(" and arguing as before, it will suffice to show that the zeta function ")#metadata(none) <tao-72d7027887e4341e0d65>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\exp( - \\sum_{n=1}^\\infty \\frac{\\text{tr}_R( \\Psi^n ) T^n}{n} )")]]

#text("is entire; thus if ")#mi("{b_m}")#text(" is the ")#mi("{T^m}")#text(" coefficient of this zeta function, our task is to show that ")#metadata(none) <tao-003e8f6c42a2a3fc52f2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\left|b_m\\right|^{1/m} \\rightarrow 0", block: true)]]

#text("as ")#mi("{m \\rightarrow \\infty}")#text(".")

#text("Note from the formal identity")

#align(center)[#tao-fit-display[#mitex("1 - X = \\exp( - \\sum_{n=1}^\\infty \\frac{X^n}{n} )")]]

#text("(which is true for small complex ")#mi("{X}")#text(", and is thus also true for formal power series in characteristic zero) and the Jordan normal form that")

#align(center)[#tao-fit-display[#mitex("\\det( 1 - AT ) = \\exp( - \\sum_{n=1}^\\infty \\frac{\\text{tr}(A^n) T^n}{n} )")]]

#text("on the level of formal power series in ")#mi("{T}")#text(" for any finite-dimensional matrix ")#mi("{A = (a_{ij})_{1 \\leq i,j \\leq k}}")#text(" in characteristic zero. In particular, for any natural number ")#mi("{m}")#text(", the ")#mi("{T^m}")#text(" coefficient of ")#mi("{\\exp( - \\sum_{n=1}^\\infty \\frac{\\text{tr}(A^n) T^n}{n} )}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#mitex("(-1)^m \\sum_* \\text{sgn}(\\sigma) a_{i_1,\\sigma(i_1)} \\dots a_{i_m,\\sigma(i_m)}")]]

#text("where the sum ")#mi("{\\sum_*}")#text(" ranges over distinct elements ")#mi("{i_1,\\dots,i_m}")#text(" of ")#mi("{\\{1,\\dots,k\\}}")#text(", and over permutations ")#mi("{\\sigma}")#text(" of ")#mi("{\\{i_1,\\dots,i_m\\}}")#text(". This is a universal polynomial identity in characteristic zero, and so we conclude that the ")#mi("{T^m}")#text(" coefficient ")#mi("{b_m}")#text(" of the zeta function ")#link(<tao-72d7027887e4341e0d65>)[#text("(20)")]#text(" is given by the formula")

#align(center)[#tao-fit-display[#mitex("b_m = (-1)^m \\sum_* \\text{sgn}(\\sigma) c^{(1)}_{i_1,\\sigma(i_1)} \\dots c^{(1)}_{i_m,\\sigma(i_m)}")]]

#text("where ")#mi("{i_1,\\dots,i_m}")#text(" now range over distinct natural numbers, and ")#mi("{\\sigma}")#text(" ranges over permutations of ")#mi("{\\{i_1,\\dots,i_m\\}}")#text("; again, one can check that this sum is convergent. By the non-archimedean nature of the metric, it thus suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sup_* (\\left|c^{(1)}_{i_1,\\sigma(i_1)}\\right|_p \\dots \\left|c^{(1)}_{i_m,\\sigma(i_m)}\\right|_p)^{1/m} \\rightarrow 0", block: true)]]

#text("as ")#mi("{m \\rightarrow \\infty}")#text(".")

#text("Now from ")#link(<tao-8263ed4f9e6b5fbb961c>)[#text("(17)")]#text(" and construction of ")#mi("{\\Psi}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|c^{(1)}_{ij}\\right|_p \\leq p^{-M (q\\left|i\\right| - \\left|j\\right|)}", block: true)]]

#text("for any ")#mi("{i,j}")#text(", and so (as ")#mi("{\\sigma}")#text(" is a permutation)")

#align(center)[#tao-fit-display[#tao-math("(\\left|c^{(1)}_{i_1,\\sigma(i_1)}\\right|_p \\dots \\left|c^{(1)}_{i_m,\\sigma(i_m)}\\right|_p)^{1/m} \\leq p^{-M (q-1) \\frac{1}{m} (\\left|i_1\\right| + \\dots + \\left|i_m\\right|)}.", block: true)]]

#text("But because there are only a finite number of elements ")#mi("{i}")#text(" of ")#mi("{{\\bf N}^d}")#text(" of a given length ")#tao-math("{\\left|i\\right|}", block: false)#text(", we see that ")#tao-math("{\\left|i_1\\right| + \\dots + \\left|i_m\\right|}", block: false)#text(" grows superlinearly in ")#mi("{m}")#text(" (in fact it must grow by ")#mi("{\\gg m^{1+\\frac{1}{d}}}")#text("), and the claim follows.")

#text("It remains to establish the trace formula ")#link(<tao-2f8c0b475a71847a5766>)[#text("(18)")]#text(". We first write the trace ")#mi("{\\text{tr}_R( \\Psi^n )}")#text(" in a more tractable form. For any natural number ")#mi("{k}")#text(", let ")#mi("{\\mu_k := \\{ z \\in {\\bf C}_p: z^k = 1 \\}}")#text(" denote the group of ")#mi("{k^{th}}")#text(" roots of unity.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 15")]#text(" If")

#align(center)[#tao-fit-display[#mitex("G(X) = \\sum_{w \\in {\\bf N}^d} c_w X^w")]]

#text("is a power series with ")#tao-math("{\\left|c_w\\right|_p \\leq p^{-M\\left|w\\right|}}", block: false)#text(" for some ")#mi("{M>0}")#text(" and all ")#mi("{w}")#text(", then for any ")#mi("{n \\geq 1}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("(q^n-1)^d \\text{tr}_R( \\Psi^n ) = \\sum_{x \\in \\mu_{q^n-1}^d} G(x) G(x^q) \\dots G(x^{q^{n-1}})")]]

#text("where we use the notation")

#align(center)[#tao-fit-display[#mitex("(x_1,\\dots,x_d)^q := (x_1^q,\\dots,x_d^q).")]]

#text("Note that the power series for ")#mi("{G}")#text(" converges at all roots of unity.")
]

#emph[#text("Proof:")]#text(" Observe that")

#align(center)[#tao-fit-display[#mitex("H(X) T_q( F(X) ) = T_q( H(X^q) F(X) )")]]

#text("for any ")#mi("{F,H \\in R}")#text(". Iterating this using ")#link(<tao-3f4146a1d0b5dac26562>)[#text("(19)")]#text(", we conclude the identity")

#tao-aligned(keep: true)[


#tao-math("\\Psi_{q,G}^n( F(x) )  & = T_{q^n}( G(X^{q^{n-1}}) \\dots G(X^q) G(X) F(X) )", block: true)



#tao-math(" & = \\Psi_{q^n, G(X) \\dots G(X^{q^{n-1}})}( F(x) )", block: true)
]

#text("and so to prove the lemma it suffices to do so in the ")#mi("{n=1}")#text(" case, that is to say")

#align(center)[#tao-fit-display[#mitex("(q-1)^d \\text{tr}_R( \\Psi ) = \\sum_{x \\in \\mu_{q-1}^d} G(x).")]]

#text("The right-hand side expands as")

#align(center)[#tao-fit-display[#mitex("\\sum_{w \\in {\\bf N}^d} c_w \\sum_{x \\in \\mu_{q-1}^d} x^w.")]]

#text("From Fourier analysis we see that ")#mi("{\\sum_{x \\in \\mu_{q-1}^d} x^w}")#text(" equals ")#mi("{(q-1)^d}")#text(" when ")#mi("{w}")#text(" is a multiple of ")#mi("{q-1}")#text(" and zero otherwise, so the sum simplifies to")

#align(center)[#tao-fit-display[#mitex("(q-1)^d \\sum_{w \\in {\\bf N}^d} c_{qw-w}.")]]

#text("The claim follows. ")#mi("\\Box")

#text("In view of this lemma, it will suffices to obtain an identity of the form ")#metadata(none) <tao-956fc30bfe11b61e7962>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\sum_{x \\in ({\\bf F}_{q^n}^\\times)^d} \\varepsilon^{\\text{Tr}_{nr}( P(x) )} = \\sum_{x \\in \\mu_{q^n-1}^d} G(x) G(x^q) \\dots G(x^{q^{r-1}})")]]

#text("for some power series")

#align(center)[#tao-fit-display[#mitex("G(X) = \\sum_{w \\in {\\bf N}^d} c_w X^w")]]

#text("with ")#tao-math("{\\left|c_w\\right|_p \\leq p^{-M\\left|w\\right|}}", block: false)#text(" for some ")#mi("{M>0}")#text(" and all ")#mi("{w}")#text(".")

#text("This will be deduced from the following basic fact in ")#mi("{p}")#text("-adic analysis, namely the existence of a canonical multiplicative embedding of the algebraic closure ")#mi("{\\overline{{\\bf F}_p}}")#text(" of ")#mi("{{\\bf F}_p}")#text(" inside ")#mi("{{\\bf C}_p}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 16 (Teichmuller lifting)")]#text(" ")#metadata(none) <tao-5364b92e50b1944f33d1>#text(" Let ")#mi("{\\overline{{\\bf F}_p} = \\bigcup_{n=1}^\\infty {\\bf F}_{p^n}}")#text(" be the algebraic closure of ")#mi("{{\\bf F}_p}")#text(". Then there exists a map ")#mi("{\\tau: \\overline{{\\bf F}_p} \\rightarrow {\\bf C}_p^\\times}")#text(", known as the ")#link("http://en.wikipedia.org/wiki/Teichm%C3%BCller_character")[#text("Teichmuller lift")]#text(", with the following properties:")

#list(
[#text("(Homomorphism) One has")

#metadata(none) <tao-75239d03c9a8bd9381c1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\tau(xy) = \\tau(x) \\tau(y)")]]

#text("for all ")#mi("{x,y \\in \\overline{{\\bf F}_p}}")#text(".")],
[#text("(Bijection) For each ")#mi("{n \\geq 1}")#text(", ")#mi("{\\tau}")#text(" is a bijection (and hence group isomorphism, by ")#link(<tao-75239d03c9a8bd9381c1>)[#text("(23)")]#text(") between ")#mi("{{\\bf F}_{p^n}^\\times}")#text(" and ")#mi("{\\mu_{p^n-1}}")#text(". In particular, ")#tao-math("{\\left|\\tau(x)\\right|_p=1}", block: false)#text(" for all ")#mi("{x \\in \\overline{{\\bf F}_p}^\\times}")#text(".")],
[#text("(Description of trace) There exists a power series")

#align(center)[#tao-fit-display[#mitex("\\Theta(T) = \\sum_{n=0}^\\infty a_n T^n")]]

#text("with ")#tao-math("{\\left|a_n\\right| \\leq p^{-n/(p-1)}}", block: false)#text(" for all ")#mi("{n}")#text(", such that ")#metadata(none) <tao-34a389d790fc2bdd8458>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\varepsilon^{\\text{Tr}_n(x)} = \\Theta(\\tau(x)) \\Theta(\\tau(x)^p) \\dots \\Theta(\\tau(x)^{p^{n-1}})")]]

#text("for all ")#mi("{n \\geq 1}")#text(" and ")#mi("{x \\in {\\bf F}_{p^n}}")#text(".")]
)
]

#text("Let us see how the lemma implies an identity of the form ")#link(<tao-956fc30bfe11b61e7962>)[#text("(22)")]#text(". Writing")

#align(center)[#tao-fit-display[#mitex("P(x) = \\sum_w a_w x^w")]]

#text("for some finite set of multi-indices ")#mi("{w}")#text(" and coefficients ")#mi("{a_w \\in {\\bf F}_q}")#text(", we have from the linearity of trace that")

#align(center)[#tao-fit-display[#mitex("\\varepsilon^{\\text{Tr}_{nr}(P(x))} = \\prod_w \\varepsilon^{\\text{Tr}_{nr}(a_w x^w)}")]]

#text("and hence by ")#link(<tao-34a389d790fc2bdd8458>)[#text("(24)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\varepsilon^{\\text{Tr}_{nr}(P(x))} = G(\\tau(x)) G(\\tau(x)^q) \\dots G(\\tau(x)^{q^{r-1}})")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("G(z) := \\prod_{s=0}^{r-1} \\prod_w \\Theta(\\tau(a_w)^{p^s} z^{p^s w})")]]

#text("and ")#mi("{\\tau(x_1,\\dots,x_d) := (\\tau(x_1),\\dots,\\tau(x_d))}")#text(". Note that the required decay of the coefficients of ")#mi("{G}")#text(" follows from that of ")#mi("{\\Theta}")#text(", since the ")#mi("{\\tau(a_w)}")#text(" have unit ")#mi("{p}")#text("-norm. The claim now follows from the bijective nature of the Teichmuller lift.")

#text("The only remaining task is to establish Lemma ")#link(<tao-5364b92e50b1944f33d1>)[#text("16")]#text("; here I will follow the exposition ")#link("http://www.ams.org/mathscinet-getitem?mr=754003")[#text("of Koblitz")]#text(". We begin by constructing the Teichmuller lift ")#mi("{\\tau: {\\bf F}_{p^n}^\\times \\rightarrow \\mu_{p^n-1}}")#text(" for a given ")#mi("{n \\geq 1}")#text(". Let ")#mi("{\\alpha}")#text(" be a primitive element of ")#mi("{{\\bf F}_{p^n}^\\times}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("{\\bf F}_{p^n}^\\times = \\{ 1, \\alpha, \\alpha^2, \\dots, \\alpha^{p^n-1} \\}.")]]

#text("(The existence of such a primitive element can be seen by counting how many elements of ")#mi("{{\\bf F}_{p^n}^\\times}")#text(" have order strictly less than ")#mi("{p^n-1}")#text(".) The minimal polynomial of ")#mi("{\\alpha}")#text(" over ")#mi("{{\\bf F}_p}")#text(" thus has degree ")#mi("{n}")#text(", that is to say it is of the form")

#align(center)[#tao-fit-display[#mitex("P(x) = x^n + a_{n-1} x_{n-1} + \\dots + a_0")]]

#text("for some ")#mi("{a_0,\\dots,a_{n-1} \\in {\\bf F}_p}")#text(". We arbitrarily lift this to the ")#mi("{p}")#text("-adic integers ")#mi("{{\\bf Z}_p}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\tilde P(x) = x^n + \\tilde a_{n-1} x_{n-1} + \\dots + \\tilde a_0")]]

#text("where ")#mi("{\\tilde a_0,\\dots,\\tilde a_{n-1} \\in {\\bf Z}_p}")#text(" reduce to ")#mi("{a_0,\\dots,a_{n-1}}")#text(" modulo ")#mi("{p}")#text(". Since the minimal polynomial ")#mi("{P}")#text(" is irreducible in ")#mi("{{\\bf F}_p}")#text(", the lift ")#mi("{\\tilde P}")#text(" is irreducible in ")#mi("{{\\bf Z}_p}")#text(" and hence also in ")#mi("{{\\bf Q}_p}")#text(" (here we use Lemma ")#link(<tao-150a7f114f74fba22e40>)[#text("12")]#text(" to reach a contradiction if a monic factor of ")#mi("{\\tilde P}")#text(" has a coefficient of ")#mi("{p}")#text("-norm greater than ")#mi("{1}")#text("). Thus, if we let ")#mi("{\\alpha \\in \\overline{{\\bf Q}_p}}")#text(" be a root of ")#mi("{\\tilde P}")#text(", then ")#tao-math("{\\left|\\alpha\\right|_p \\leq 1}", block: false)#text(" and ")#mi("{{\\bf Q}_p(\\alpha)}")#text(" is a degree ")#mi("{n}")#text(" extension of ")#mi("{{\\bf Q}_p}")#text(". In this field, we define the ")#emph[#text("valuation ring")]#text(" ")#tao-math("{A := \\{ x \\in {\\bf Q}_p(\\alpha): \\left|x\\right|_p \\leq 1\\}}", block: false)#text(" and its ")#emph[#text("maximal ideal")]#text(" ")#tao-math("{M := \\{ x \\in {\\bf Q}_p(\\alpha): \\left|x\\right|_p < 1 \\}}", block: false)#text(". Then ")#mi("{A/M}")#text(" is a field generated over ")#mi("{{\\bf F}_p}")#text(" by ")#mi("{\\alpha \\text{ mod } M}")#text(", which is a root of ")#mi("{P}")#text(", thus ")#mi("{A/M}")#text(" is a degree ")#mi("{n}")#text(" extension of ")#mi("{{\\bf F}_p}")#text(" and may be identified with ")#mi("{{\\bf F}_{p^n}}")#text(".")

#text("We claim that the field extension ")#mi("{{\\bf Q}_p(\\alpha)}")#text(" is ")#emph[#text("unramified")]#text(" in the sense that all of the non-zero elements of ")#mi("{{\\bf Q}_p(\\alpha)}")#text(" have norms that are integer powers of ")#mi("{p}")#text(", and in particular that ")#mi("{M = pA}")#text(". Suppose this were not the case, then there exists an element ")#mi("{\\pi}")#text(" of ")#mi("{{\\bf Q}_p(\\alpha)}")#text(" with ")#tao-math("{1/p < \\left|\\pi\\right| < 1}", block: false)#text(". If one lets ")#mi("{e_1,\\dots,e_n}")#text(" be a linear basis of ")#mi("{{\\bf F}_{p^n}}")#text(" over ")#mi("{{\\bf F}_p}")#text(", and let ")#mi("{\\tilde e_1,\\dots,\\tilde e_n}")#text(" be representatives of this basis in ")#mi("{A}")#text(", one can then show that ")#mi("{\\tilde e_1,\\dots,\\tilde e_n, \\pi \\tilde e_1,\\dots,\\pi \\tilde e_n}")#text(" are linearly independent over ")#mi("{{\\bf Q}_p}")#text(", contradicting the fact that ")#mi("{{\\bf Q}_p(\\alpha)}")#text(" is a degree ")#mi("{n}")#text(" extension.")

#text("Let ")#mi("{\\alpha}")#text(" be an element of ")#mi("{{\\bf F}_{p^n}^\\times}")#text(", then ")#mi("{\\alpha^{p^n-1}=1}")#text(". As discussed earlier, we can view ")#mi("{\\alpha}")#text(" as an element of ")#mi("{A/M = A/pA}")#text(". By applying (a slight variant of) ")#link("http://en.wikipedia.org/wiki/Hensel%27s_lemma")[#text("Hensel’s lemma")]#text(", we can find a lift ")#mi("{\\tau(\\alpha) \\in A}")#text(" of ")#mi("{\\alpha}")#text(" such that ")#mi("{\\tau(\\alpha)^{p^n-1} = 1}")#text(". This gives an injective map from ")#mi("{{\\bf F}_{p^n}^\\times}")#text(" to ")#mi("{\\mu_{p^n-1}}")#text(", which on comparing cardinalities must be a bijection. Since the quotient map from ")#mi("{A}")#text(" to ")#mi("{A/pA}")#text(" is a homomorphism, we see that ")#mi("{\\tau}")#text(" is a homomorphism. One can check that the maps ")#mi("{\\tau: {\\bf F}_{p^n}^\\times \\rightarrow {\\bf C}_p^\\times}")#text(" for different ")#mi("{n}")#text(" are compatible, and glue together to form a single map ")#mi("{\\tau: \\overline{{\\bf F}_p}^\\times \\rightarrow {\\bf C}_p^\\times}")#text(" obeying the homomorphism and bijection properties.")

#text("Now we have to construct ")#mi("{\\Theta}")#text(". We first give a heuristic discussion. From the construction of ")#mi("{\\tau}")#text(", we morally have ")#mi("{\\tau(x) = x \\text{ mod } p}")#text(" for all ")#mi("{x \\in \\overline{{\\bf F}_p}^\\times}")#text(", where we are deliberately vague as to what “")#mi("{\\text{ mod } p}")#text("” means. Since the map ")#mi("{x \\mapsto \\varepsilon^x}")#text(" should morally be periodic modulo ")#mi("{p}")#text(", we thus expect")

#tao-aligned(keep: true)[


#tao-math("\\varepsilon^{\\text{Tr}_n(x)}  & = \\varepsilon^{x + x^p + \\dots + x^{p^{n-1}}}", block: true)



#tao-math(" & = \\varepsilon^{\\tau(x) + \\tau(x^p) + \\dots + \\tau(x^{p^{n-1}})}", block: true)



#tao-math(" & = \\varepsilon^{\\tau(x)} \\varepsilon^{\\tau(x^p)} \\dots \\varepsilon^{\\tau(x^{p^{n-1}})}", block: true)
]

#text("and so one is led to the initial guess")

#align(center)[#tao-fit-display[#mitex("\\Theta(T) ?= \\varepsilon^T")]]

#text("for ")#mi("{\\Theta}")#text(". To make this heuristic discussion rigorous, we have to formally define what ")#mi("{\\varepsilon^T}")#text(" means as a power series in ")#mi("{T}")#text(". We write ")#mi("{\\varepsilon = 1+\\lambda}")#text(", thus ")#mi("{\\lambda \\neq 0}")#text(" and")

#align(center)[#tao-fit-display[#mitex("(1+\\lambda)^p = 1;")]]

#text("so that")

#align(center)[#tao-fit-display[#mitex("p + \\binom{p}{2} \\lambda + \\dots + \\binom{p}{p-1} \\lambda^{p-2} + \\lambda^{p-1} = 0;")]]

#text("thus the ")#mi("{p-1}")#text(" Galois conjugates of ")#mi("{\\lambda}")#text(" multiply to ")#mi("{\\pm p}")#text(", and so ")#tao-math("{\\left|\\lambda\\right|_p = p^{-\\frac{1}{p-1}}}", block: false)#text(". We can then define ")#mi("{\\varepsilon^T = (1+\\lambda)^T}")#text(" by formal binomial expansion as")

#align(center)[#tao-fit-display[#mitex("(1+\\lambda)^T := \\sum_{i=0}^\\infty \\frac{T (T-1) \\dots (T-i+1)}{i!} \\lambda^i.")]]

#text("This is well-defined (over ")#mi("{{\\bf C}_p}")#text(") as a formal power series in ")#mi("{T}")#text(". However, the convergence properties are bad, because of the denominator ")#mi("{i!}")#text(". Indeed, a standard computation shows that")

#align(center)[#tao-fit-display[#tao-math("\\left| \\frac{1}{i!} \\right| = p^{\\frac{i-S_i}{p-1}}", block: true)]]

#text("where ")#mi("{S_i}")#text(" is the sum of the digits of the base ")#mi("{p}")#text(" expansion of ")#mi("{i}")#text(", and so")

#align(center)[#tao-fit-display[#tao-math("\\left| \\frac{\\lambda^i}{i!} \\right| = p^{\\frac{-S_i}{p-1}}.", block: true)]]

#text("The sequence ")#mi("{S_i}")#text(" does not go to infinity as ")#mi("{i \\rightarrow \\infty}")#text(", and so the power series ")#mi("{(1+\\lambda)^T}")#text(" does not converge for ")#tao-math("{\\left|T\\right|_p \\geq 1}", block: false)#text(". This is a problem, since we want to apply ")#mi("{\\Theta}")#text(" to norm one quantities such as ")#mi("{\\tau(x^{p^j})}")#text(", and furthermore we are claiming a slightly larger radius of convergence in Lemma ")#link(<tao-5364b92e50b1944f33d1>)[#text("16")]#text(", namely (almost) ")#mi("{p^{1/(p-1)}}")#text(".")

#text("It turns out that there is a way to tweak the series ")#mi("{T \\mapsto (1+\\lambda)^T}")#text(" to significantly improve the ")#mi("{p}")#text("-adic convergence behaviour. Namely, we (formally) define the corrected function")

#align(center)[#tao-fit-display[#mitex("\\Theta(T) := F(T,\\lambda)")]]

#text("where ")#mi("{F(T,Y)}")#text(" is the formal power series in two variables ")#mi("{T,Y}")#text(" defined by ")#metadata(none) <tao-c23f67974c41324afd8d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("F(T,Y) := (1+Y)^T \\prod_{j=1}^\\infty (1+Y^{p^j})^{(T^{p^j} - T^{p^{j-1}})/p^j};")]]

#text("one can verify that this is well-defined as a formal power series, and for fixed ")#mi("{t \\in {\\bf C}_p}")#text(", ")#mi("{F(t,Y)}")#text(" is a formal power series in ")#mi("{Y}")#text(". By telescoping series, we have")

#align(center)[#tao-fit-display[#mitex("F(t,Y) F(t^p,Y) \\dots F(t^{p^{n-1}},Y) = (1+Y)^{t+t^p+\\dots+t^{p^{n-1}}}")]]

#text("as a formal power series, whenever ")#mi("{t \\in \\mu_{p^n-1}}")#text(". In particular,")

#align(center)[#tao-fit-display[#mitex("F(\\tau(x),Y) F(\\tau(x^p),Y) \\dots F(\\tau(x^{p^{n-1}}),Y) = (1+Y)^{\\tau(x)+\\tau(x)^p+\\dots+\\tau(x)^{p^{n-1}}}")]]

#text("for ")#mi("{x \\in {\\bf F}_{p^n}^\\times}")#text(". If we can show that ")#mi("{F(T,\\lambda)}")#text(" makes sense as a formal power series ")#mi("{\\sum_n a_n T^n}")#text(" with ")#tao-math("{\\left|a_n\\right|_p \\leq p^{-n/(p-1)}}", block: false)#text(" for all ")#mi("{n}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("\\Theta(\\tau(x)) \\Theta(\\tau(x^p)) \\dots \\Theta(\\tau(x^{p^{n-1}})) = (1+\\lambda)^{\\tau(x)+\\tau(x)^p+\\dots+\\tau(x)^{p^{n-1}}};")]]

#text("since ")#mi("{x, x^p, \\dots, x^{p^{n-1}}}")#text(" are the Galois conjugates of ")#mi("{x \\in {\\bf F}_{p^n}}")#text(" over ")#mi("{{\\bf F}_p}")#text(", one can verify that ")#mi("{\\tau(x), \\tau(x)^p,\\dots,\\tau(x)^{p^{n-1}}}")#text(" are the Galois conjugates of ")#mi("{\\tau(x) \\in \\overline{{\\bf Q}_p}}")#text(" over ")#mi("{{\\bf Q}_p}")#text(", and so ")#mi("{\\tau(x)+\\tau(x)^p+\\dots+\\tau(x)^{p^{n-1}}}")#text(" lies in ")#mi("{{\\bf Q}_p}")#text("; since ")#mi("{\\tau(x)}")#text(" has norm ")#mi("{1}")#text(", this quantity in fact lies in ")#mi("{{\\bf Z}_p}")#text(". Quotienting out by the maximal ideal ")#tao-math("{\\{ z \\in {\\bf Q}_p(\\tau(x)): \\left|z\\right|_p < 1 \\}}", block: false)#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\tau(x)+\\tau(x)^p+\\dots+\\tau(x)^{p^{n-1}} = x + x^p + \\dots + x^{p^{n-1}} = \\text{Tr}_n(x) \\text{ mod } p")]]

#text("and ")#link(<tao-34a389d790fc2bdd8458>)[#text("(24)")]#text(" follows.")

#text("So we are at last reduced to showing that ")#mi("{F(T,\\lambda) = \\sum_n a_n T^n}")#text(" with ")#tao-math("{\\left|a_n\\right|_p \\leq p^{-n/(p-1)}}", block: false)#text(" for all ")#mi("{n}")#text(". From ")#link(<tao-c23f67974c41324afd8d>)[#text("(25)")]#text(" we have the identity")

#align(center)[#tao-fit-display[#mitex("F(T^p, Y^p) = F(T,Y)^p \\frac{(1+Y^p)^T}{(1+Y)^{pT}}.")]]

#text("On the other hand, we have ")#mi("{1+Y^p = (1 + Y)^p \\text{ mod } pY{\\bf Z}_p[Y]}")#text(", and hence")

#align(center)[#tao-fit-display[#mitex("\\frac{1+Y^p}{1+Y} = 1 + p Y G(Y)")]]

#text("for some formal power series ")#mi("{G(Y)}")#text(" with coefficients in ")#mi("{{\\bf Z}_p}")#text(", and hence")

#align(center)[#tao-fit-display[#mitex("F(T^p, Y^p) = F(T,Y)^p (1 + p Y G(Y))^T.")]]

#text("We can expand ")#mi("{(1 + pY G(Y))^T}")#text(" as ")#mi("{1 + pH(Y,T)}")#text(", where ")#mi("{H(Y,T)}")#text(" is a formal power series with coefficients in ")#mi("{{\\bf Z}_p}")#text(" and no constant term, hence")

#align(center)[#tao-fit-display[#mitex("F(T^p, Y^p) = F(T,Y)^p (1 + p H(Y,T)).")]]

#text("As ")#mi("{F(0,0)=1}")#text(", the ")#mi("{T^a Y^b}")#text(" coefficient of this identity lets us express the ")#mi("{T^a Y^b}")#text(" coefficient of ")#mi("{F(T,Y)}")#text(" as a polynomial combination (over ")#mi("{{\\bf Z}_p}")#text(") of lower degree coefficients of ")#mi("{F}")#text(" (as well as coefficients of ")#mi("{H}")#text("), which by induction shows that all coefficients of ")#mi("{F}")#text(" lie in ")#mi("{{\\bf Z}_p}")#text(". Replacing ")#mi("{Y}")#text(" by ")#mi("{\\lambda}")#text(", the desired claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 17")]#text(" The function ")#mi("{\\Theta}")#text(" can also be defined as")

#align(center)[#tao-fit-display[#mitex("\\Theta(T) = E_p( \\pi T )")]]

#text("where ")#mi("{E_p}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Artin-Hasse_exponential")[#text("Artin-Hasse exponential")]

#align(center)[#tao-fit-display[#mitex("E_p(x) := \\exp( \\sum_{i=0}^\\infty \\frac{x^{p^i}}{p^i} )")]]

#text("and ")#mi("{\\pi \\in {\\bf C}_p}")#text(" is a root of the power series ")#mi("{\\sum_{i=0}^\\infty \\frac{x^{p^i}}{p^i}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 18")]#text(" A small modification of Dwork’s argument also establishes rationality (the zeta function associated to) exponential sums such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\in V[{\\bf F}_q^n]} \\chi(\\text{Tr}_{nr}(P(x)))")]]

#text("for some polynomial ")#mi("{P: V \\rightarrow {\\bf A}}")#text(" defined over ")#mi("{{\\bf F}_q}")#text(", and some multiplicative character ")#mi("{\\chi: {\\bf F}_p \\rightarrow {\\bf C}}")#text(".")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27e7070af2c8cecbe65c0bd2047912d0dde6eaa77e7595e4d0dd4e7741b1f7ee-011cc43a6a7233cc01cb9ca581e8df3b57df1eee94f84c3b434ec595dee77387.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/05/13/dworks-proof-of-rationality-of-the-zeta-function-over-finite-fields/#comment-338645")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2014")])]

#text("There is an extraneous “sup” at the start of the post.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0388efa73d74660f3599ac29578426a66ecb4ee43951ac21cdd0829b194e336a-0b4e9669c4d2ed25883ee72fdfc7e5f5b65ffaddd2f8e9b8acd9d34e351f3f5b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KCd")]], [#link("https://terrytao.wordpress.com/2014/05/13/dworks-proof-of-rationality-of-the-zeta-function-over-finite-fields/#comment-339027")[#strong[#text("KCd")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2014")])]

#text("In the paragraph after Theorem 2, ")#mi("s \\mapsto \\zeta_V(q^s)")#text(" should be ")#mi("s \\mapsto \\zeta_V(q^{-s})")#text(". For example, if ")#mi("V = {\\mathbf A}^1")#text(" then ")#mi("S_n = q^n")#text(" and ")#mi("\\zeta_V(T) = \\exp(\\sum_{n \\geq 1} q^nT^n/n)")#text(" with ")#mi("T = q^{-s}")#text(" converges for ")#mi("{\\rm Re}(s) > 1")#text(", as you’d want.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/05/13/dworks-proof-of-rationality-of-the-zeta-function-over-finite-fields/#comment-339462")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2014")])]

#text("“as we wil seesup below” What does that mean?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2014/05/13/dworks-proof-of-rationality-of-the-zeta-function-over-finite-fields/#comment-339625")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2014")])]

#text("Very interesting post!")

#text("I have trouble following the argument below (14). Let us consider the polynomial ")#mi("\\ell x^2+x+\\ell")#text(". It is irreducible over ")#mi("{\\bf Q}")#text(" but reducible over ")#mi("{\\bf Q}_\\ell")#text(". In fact, in ")#mi("{\\bf Q}_\\ell")#text(", the two roots have valuations ")#mi("\\pm 1")#text(". This means that we cannot just say that ")#tao-math("\\left|\\zeta_i\\right|_\\ell>1", block: false)#text(", because ")#tao-math("\\left|\\zeta_i\\right|_\\ell", block: false)#text(" will depend on the embedding ")#mi("\\overline{\\bf Q}\\rightarrow\\overline{{\\bf Q}_\\ell}")#text(" we use. Perhaps ")#tao-math("\\left|\\zeta_i\\right|_\\ell>1", block: false)#text(" is meant under a suitable embedding? This should follow from the fact that if ")#mi("\\zeta_i")#text(" is not an algebraic integer, then ")#tao-math("\\left|\\zeta_i\\right|_v>1", block: false)#text(" for some finite place ")#mi("v\\mid\\ell")#text(" of ")#mi("{\\bf Q}(\\zeta_i)")#text(". Am I missing something?")

#text("Further small remarks and suggestions:")

#text("1. In the display below (1), “")#mi("=0")#text("” is missing from the chain of equations.")

#text("2. “seesup” should be “see”.")

#text("3. ")#mi("\\beta_1,\\dots,\\beta_k")#text(" should be ")#mi("\\beta_1,\\dots,\\beta_{k^{\\prime}}")#text(".")

#text("4. In the proof of Proposition 3, ")#mi("\\iota(S_n)")#text(" should be ")#mi("\\iota_\\infty(S_n)")#text(".")

#text("5. In Proposition 6, the words “there exist” are missing.")

#text("6. The example “cube root of 2” after Lemma 8 is not the best one, as this algebraic number has the same norm in every embedding into ")#mi("\\bf{C}")#text(".")

#text("7. In Section 2, “Proposition 4” and “Proposition 5” should really be “Proposition 3” and “Proposition 4” at several occurrences (e.g. in the beginning, or before and after (10), or after (12)).")

#text("8. Before (13), the zeros of ")#mi("P")#text(" should be labeled as ")#mi("\\zeta_1,\\dots,\\zeta_m")#text(", because the degree of ")#mi("P")#text(" equals ")#mi("m")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2014/05/13/dworks-proof-of-rationality-of-the-zeta-function-over-finite-fields/#comment-339799")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2014")])]

#text("I thought I’d advertise an old blog post of mine ")#link("http://sbseminar.wordpress.com/2011/12/12/rationality-of-the-zeta-function-mod-p/")[#text("http://sbseminar.wordpress.com/2011/12/12/rationality-of-the-zeta-function-mod-p/")]#text(" where I show ")#mi("\\# \\{ x \\in \\mathbb{F}_{p^k}^n : P(x)=0 \\} \\bmod p")#text(" is given by the trace of the ")#mi("n")#text("-th power of a matrix, acting on monomials in a manner similar to the infinite operator ")#mi("\\Psi")#text(" in this proof. My vague intuition for Dwork’s argument is that he figured out how to make this construction work to count solutions modulo any power of ")#mi("p")#text(", not just the first power.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/05/13/dworks-proof-of-rationality-of-the-zeta-function-over-finite-fields/#comment-339951")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2014")])]

#text("This is an interesting variant of Dwork’s argument! It’s slightly different though. In your argument, your starting point is the factorisation")

#mi("1_{P(x) \\neq 0} = g(x) g(x^p) \\dots g(x^{p^{k-1}}) \\text{ mod } p")#text(" (1)")

#text("for all ")#mi("x \\in {\\bf F}_{p^k}^n")#text(", where ")#mi("g(x) := P(x)^{p-1}")#text(" is a polynomial that does not depend on k. In Dwork’s argument, the analogous factorisation is")

#mi("\\varepsilon^{\\text{Tr}_k P(x)} = G( \\tau(x) ) G( \\tau(x)^p ) \\dots G( \\tau(x)^{p^{k-1}})")#text(" (2)")

#text("in ")#mi("{\\bf C}_p")#text(" for all ")#mi("x \\in ({\\bf F}_{p^k}^\\times)^n")#text(", where ")#mi("\\varepsilon")#text(" is a ")#mi("p^{th}")#text(" root of unity, ")#mi("\\tau(x) \\in (\\mu_{p^k-1})^n")#text(" is the Teichmuller lift of x, and ")#mi("G")#text(" is a certain formal power series independent of k with coefficients in ")#mi("{\\bf C}_p")#text(" that converges at the Teichmuller lifts. In your case, ")#mi("g")#text(" is a polynomial, which makes your matrices finite dimensional, but in Dwork’s case ")#mi("G")#text(" is transcendental, which creates the infinite-dimensional matrices.")

#text("My understanding of the Teichmuller lift and associated objects (e.g. the Artin-Hasse exponential) is not firm enough to see if there is any substantial connection between the easy factorisation (1) and the harder factorisation (2). Part of the problem is that the ")#mi("p^{th}")#text(" root of unity ")#mi("\\varepsilon")#text(" does not live in the p-adic field ")#mi("{\\bf Q}_p")#text(", instead being of the form ")#mi("\\varepsilon = 1 + \\lambda")#text(" for some ")#mi("\\lambda \\in {\\bf C}_p")#text(" of norm ")#mi("p^{-1/(p-1)}")#text(". The coefficients of G also live in some finite extension of ")#mi("{\\bf Q}_p")#text(" that I don’t understand very well. In principle one can try to reduce (2) mod p to get something more closely resembling (1), but I don’t see any precise connection. (The left-hand sides of (1), (2) are of course related through the Fourier identity ")#mi("\\sum_{y \\in {\\bf F}_{p^k}} \\varepsilon^{\\text{Tr}_k( P(x) y )} = p^k 1_{P(x)=0}")#text(".)")

#text("p.s. as far as I can tell, your argument does not use the smoothness or irreducibility of ")#mi("\\{P=0\\}")#text(", which bothers me a little bit because I’m pretty sure one can have nontrivial even and odd cohomology in the non-smooth or reducible case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59e7cc015abe36655329b57fc473d54b0124e40428d9299fab3212350430dace-d68dc7a9cd8bb487b1e36264fcdb4a497a80be48ec13c7aec300b89cdfa2d222.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2014/05/13/dworks-proof-of-rationality-of-the-zeta-function-over-finite-fields/#comment-340528")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2014")])]

#text("Your PS is bothering me too. The easiest way I can see that the story can be consistent is if those terms vanish modulo ")#mi("p")#text(". That’s what happens in the simplest case: Take ")#mi("P(x,y,z) = xyz")#text(". Then the complex curve defined by ")#mi("P")#text(" is three spheres glued into a circle, so with Betti numbers ")#mi("(1,1,3)")#text(". The corresponding action of Frobenius is by ")#mi("(1)")#text(", ")#mi("(p)")#text(" and ")#mi("p^2 \\mathrm{Id}_3")#text("; the argument I give is computing that the second of these is ")#mi("0 \\bmod p")#text(", and the reason that the third isn’t causing a problem is that it also vanishes modulo ")#mi("p")#text(". A more interesting example is ")#mi("(x^2+y^2) z")#text(". On complex points, this is the same as the previous one (note that ")#mi("(x^2+y^2) = (x+iy)(x-iy)")#text(") but the Frobenius action now depends on ")#mi("p \\bmod 4")#text(". However, it still seems to be true that the action on ")#mi("H^2")#text(" vanishes modulo ")#mi("p")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dab262b249e6b008de2defe2a9d55f776181f2faf2f8a2ae168348cdfb2adaf-097fe507317aee85ccf32427e06a89aeacc09d75464afe95cd265a14b70a7a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2014/05/13/dworks-proof-of-rationality-of-the-zeta-function-over-finite-fields/#comment-341184")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2014")])]

#text("The Lefschetz hyperplane theorem still works for the low cohomology degrees, so the issue is large degree eigenvalues. These tend to vanish modulo p – I can see an l-adic proof that they always do for smooth compact varieties using Poincare duality + the Weil conjectures, but I don’t see a similar argument for smooth hypersurface complements.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf439e996e29d20cb552d68ffe9f964d8919f4f9773b9c41c886fb326a5a9695-66573747b7b50dc2532a1c1acd7e23c9482f9aeb4a00f437399c08ade2278ee3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aquazorcarson")]], [#link("https://terrytao.wordpress.com/2014/05/13/dworks-proof-of-rationality-of-the-zeta-function-over-finite-fields/#comment-347566")[#strong[#text("aquazorcarson")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2014")])]

#text("Are there bounds for S_n that use the number of defining polynomial k? Also this k seems to collide with the k for the number of characteristic values. The results of Bombieri and Hooley also remind me of work by J. Milnor that bounds the number of intersection points of two complex varieties of complementary dimension, using Morse theory.")

#emph[#text("[Notation changed, and dependence on number of defining polynomials clarified – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf439e996e29d20cb552d68ffe9f964d8919f4f9773b9c41c886fb326a5a9695-66573747b7b50dc2532a1c1acd7e23c9482f9aeb4a00f437399c08ade2278ee3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aquazorcarson")]], [#link("https://terrytao.wordpress.com/2014/05/13/dworks-proof-of-rationality-of-the-zeta-function-over-finite-fields/#comment-348010")[#strong[#text("aquazorcarson")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2014")])]

#text("Thanks for the quick update. With the dependency on m, is Hooley’s bound strictly weaker than Bombieri’s?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/05/13/dworks-proof-of-rationality-of-the-zeta-function-over-finite-fields/#comment-348115")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2014")])]

#text("In practice yes. Technically, the bound stated in Hooley’s paper may occasionally be stronger than that stated in Bombieri’s, if the variety is not a complete intersection, but I think that if one pushes the methods in Bombieri’s paper to the limit (beyond what is stated as the main result in his paper), it will give slightly stronger results than the corresponding limit of Hooley’s methods.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd07dcea576c58f5ba8e26f5f8e1708a83f3310d14f777048c780246eaf4e033-60a38ffe34f6cd85111cf5c8281639cee7688a72a1427b77a339480f4513d484.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Angel Fernandez")]], [#link("https://terrytao.wordpress.com/2014/05/13/dworks-proof-of-rationality-of-the-zeta-function-over-finite-fields/#comment-387060")[#strong[#text("Angel Fernandez")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2014")])]

#text("Theorem 2 (hypothesis Riemann).")

#text("In its indication, the similarity with the classical Riemann hypothesis.")

#text("I have te inform you that it is shown by (Albana Diez) than no-trivial zeros of the zeta function are on the straight line for ( a = 1/2).")

#text("See in: Universañl Journal of Applied Mathematics Vol 1 (3);2013")

#text("title: Convergents series for Riemann hypothesis.")

#text("Regards.")

#text("Angel")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/878699eaa6d217727c4edaeb1db20ddc8952c420bf3b33aa2734601cc4ab72dc-ec6a6fbd29669667ec8085df41dde1c52195a733bff13e4604ba2f5e2801d195.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A p-adic proof that pi is transcendental | Matt Baker's Math Blog")]], [#link("https://terrytao.wordpress.com/2014/05/13/dworks-proof-of-rationality-of-the-zeta-function-over-finite-fields/#comment-453266")[#strong[#text("A p-adic proof that pi is transcendental | Matt Baker's Math Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2015")])]

#text("[…] following well-known characterization of rational functions, whose proof we omit (see Lemma 9 in this blog post by Terry […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/53fcc48298fbf0b39ae5c96682a2c080fee212fbb77abc5806357799299d07d1-19bcd8fa5c69e7de1455040cb216c9de991aa3f88b2c107a7cf22f1075b0c652.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cécile G.")]], [#link("https://terrytao.wordpress.com/2014/05/13/dworks-proof-of-rationality-of-the-zeta-function-over-finite-fields/#comment-484452")[#strong[#text("Cécile G.")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2017")])]

#text("Thank you for this post ! I had some trouble with two small mistakes or typos which seem to have crept into the definitions of G (for the trace formula) and F(T,Y) (for the Teichmüller lifting) :")

#text("— writing ")#mi("P(x)=\\sum_w{a_wx^w}")#text(" and ")#mi("G(z)=\\prod_w \\Theta(\\tau(a_w)z^w)")#text(", as you do, one gets")#linebreak()#text(" ")#mi("\\epsilon^{\\text{Tr}_{nr}{P(x)}}=\\prod_w \\epsilon^{\\text{Tr}_{nr}(a_wx^w)}=\\prod_w{\\prod_{i=0}^{nr-1}{\\Theta(\\tau(a_wx^w)^{p^i})}}")#text(" and since ")#mi("a_w")#text(" merely is in ")#mi("\\mathbb{F}_q")#text(", not in ")#mi("\\mathbb{F}_p")#text(", you can’t get rid of the powers ")#mi("p")#text(" in order to come back to ")#mi("G(\\tau(x))\\cdots G(\\tau(x)^{p^{nr-1}})")#text("…")

#text("If you set ")#mi("G(z)=\\prod_w\\prod_{s=0}^{r-1}\\Theta(\\tau(a_w)^{p^s}z^{p^s w})")#text(" instead, it arises : ")#mi("\\epsilon^{\\text{Tr}_{nr}{P(x)}}=\\prod_w\\prod_{i=0}^{n-1}G(\\tau(x)^{q^i})")#text(", which seems to work then.")

#text("— a ")#mi("j")#text(" may have disappeared in formula (25) : ")#mi("F(T,Y)=(1+Y)^T\\prod_{j=1}^{\\infty}(1+Y^{p^j})^{(T^{p^j}-T^{p^{j-1}})/p^j}")#text(" works better for the next identities to hold.")

#emph[#text("[Corrected, thanks – T.]")]
]
