// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/
// Converted to Typst by tao2typ: "2026-10-14T09:02:50.204659+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An inverse theorem for the Gowers U^{s+1}[N] norm", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An inverse theorem for the Gowers U^{s+1}[N] norm")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 September 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/")[#text("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(", ")#link("http://www.technion.ac.il/~tamarzr/")[#text("Tamar Ziegler")]#text(", and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/1009.3998")[#text("An inverse theorem for the Gowers U^{s+1}[N] norm")]#text("“, which was ")#link("https://terrytao.wordpress.com/2010/06/02/an-inverse-theorem-for-the-gowers-norm-us1n-announcement/")[#text("previously announced on this blog")]#text(". We are still planning one final round of reviewing the preprint before submitting the paper, but it has gotten to the stage where we are comfortable with having the paper available on the arXiv.")

#text("The main result of the paper is to establish the inverse conjecture for the Gowers norm over the integers, which has a number of applications, in particular to counting solutions to various linear equations in primes. In spirit, the proof of the paper follows the 21-page announcement that was ")#link("http://arxiv.org/abs/1006.0205")[#text("uploaded previously")]#text(". However, for various rather annoying technical reasons, the 117-page paper has to devote a large amount of space to setting up various bits of auxiliary machinery (as well as a dozen or so pages worth of examples and discussion). For instance, the announcement motivates many of the steps of the argument by heuristically identifying nilsequences ")#mi("n \\mapsto F(g(n) \\Gamma)")#text(" with bracket polynomial phases such as ")#mi("n \\mapsto e( \\{ \\alpha n \\} \\beta n )")#text(". However, a rather significant amount of theory (which was already worked out to a large extent ")#link("http://www.math.ohio-state.edu/~leibman/preprints/bas.pdf")[#text("by Leibman")]#text(") is needed to formalise the “bracket algebra” needed to manipulate such bracket polynomials and to connect them with nilsequences. Furthermore, the “piecewise smooth” nature of bracket polynomials causes some technical issues with the equidistribution theory for these sequences. Our original version of the paper (which was even longer than the current version) set out this theory. But we eventually decided that it was best to eschew almost all use of bracket polynomials (except as motivation and examples), and run the argument almost entirely within the language of nilsequences, to keep the argument a bit more notationally focused (and to make the equidistribution theory easier to establish). But this was not without a tradeoff; some statements that are almost trivially true for bracket polynomials, required some “nilpotent algebra” to convert to the language of nilsequences. Here are some examples of this:")

#enum(start: 1, 
[#text("It is intuitively clear that a bracket polynomial phase e(P(n)) of degree k in one variable n can be “multilinearised” to a polynomial ")#mi("e(Q(n_1,\\ldots,n_k))")#text(" of multi-degree ")#mi("(1,\\ldots,1)")#text(" in k variables ")#mi("n_1,\\ldots,n_k")#text(", such that ")#mi("e(P(n))")#text(" and ")#mi("e(Q(n,\\ldots,n))")#text(" agree modulo lower order terms. For instance, if ")#mi("e(P(n)) = e(\\alpha n \\{ \\beta n \\{ \\gamma n \\} \\})")#text(" (so k=3), then one could take ")#mi("e(Q(n_1,n_2,n_3)) = e( \\alpha n_1 \\{ \\beta n_2 \\{ \\gamma n_3 \\} \\})")#text(". The analogue of this statement for nilsequences is true, but required a moderately complicated nilpotent algebra construction using the Baker-Campbell-Hausdorff formula.")],
[#text("Suppose one has a bracket polynomial phase e(P_h(n)) of degree k in one variable n that depends on an additional parameter h, in such a way that exactly one of the coefficients in each monomial depends on h. Furthermore, suppose this dependence is bracket linear in h. Then it is intuitively clear that this phase can be rewritten (modulo lower order terms) as e( Q(h,n) ) where Q is a bracket polynomial of multidegree (1,k) in (h,n). For instance, if ")#mi("e(P_h(n)) = e( \\{ \\alpha_h n \\} \\beta n )")#text(" and ")#mi("\\alpha_h = \\{\\gamma h \\} \\delta")#text(", then we can take ")#mi("e(Q(h,n)) = e(\\{ \\{\\gamma h\\} \\delta n\\} \\beta n )")#text(". The nilpotent algebra analogue of this claim is true, but requires another moderately complicated nilpotent algebra construction based on semi-direct products.")],
[#text("A bracket polynomial has a fairly visible concept of a “degree” (analogous to the corresponding notion for true polynomials), as well as a “rank” (which, roughly speaking measures the number of parentheses in the bracket monomials, plus one). Thus, for instance, the bracket monomial ")#mi("\\{\\{ \\alpha n^4 \\} \\beta n \\} \\gamma n^2")#text(" has degree 7 and rank 3. Defining degree and rank for nilsequences requires one to generalise the notion of a (filtered) nilmanifold to one in which the lower central series is replaced by a filtration indexed by both the degree and the rank.")]
)

#text("There are various other tradeoffs of this type in this paper. For instance, nonstandard analysis tools were introduced to eliminate what would otherwise be quite a large number of epsilons and regularity lemmas to manage, at the cost of some notational overhead; and the piecewise discontinuities mentioned earlier were eliminated by the use of vector-valued nilsequences, though this again caused some further notational overhead. These difficulties may be a sign that we do not yet have the “right” proof of this conjecture, but one will probably have to wait a few years before we get a proper amount of perspective and understanding on this circle of ideas and results.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b3f5bbda2d74e24b9764772a51725a8e084a779bc6ba5afbccff2b92a68407d-b48d55d47087586935596d9898a4f961e682af4eb3345878687874ba7fba7d57.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xianliang wu")]], [#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/#comment-47199")[#strong[#text("xianliang wu")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2010")])]

#text("Dear Prof Tao")#linebreak()#text(" It seems that there is some extra words near the hyperlinks in this Arxiv version which need to remove by changing some latex setting. May be, I think. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b3f5bbda2d74e24b9764772a51725a8e084a779bc6ba5afbccff2b92a68407d-b48d55d47087586935596d9898a4f961e682af4eb3345878687874ba7fba7d57.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xianliang wu")]], [#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/#comment-47200")[#strong[#text("xianliang wu")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2010")])]

#text("by the way, would you like suggest some books on nonstandard analysis which is a little bit nonstandard in ordinary mathematical education?")

#text("Thank you very much! Happy mid-autumn festival!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/#comment-47201")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2010")])]

#text("You might find this MathOverflow thread relevant:")

#link("http://mathoverflow.net/questions/18840/nonstandard-analysis-book-recommendation")[#text("http://mathoverflow.net/questions/18840/nonstandard-analysis-book-recommendation")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c6262112424c0265c5b7a0ca9c807c75fb92880451485851e67159a5beb93e4-528cd358603681216d9589c7c3b784fdc08c97b557ab4671353a6494cd80acb3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nikita Sidorov")]], [#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/#comment-47206")[#strong[#text("Nikita Sidorov")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2010")])]

#text("Terry, could you please check the pdf generated by the arXiv again? It seems to contain lots of LateX leftovers which shouldn’t be there… ")#emph[#text("[We’ve uploaded a new version, which should propagate into the system within 24 hours or so. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/#comment-47265")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2010")])]

#text("Heartfelt congratulations on finishing this remarkable work!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The inverse conjecture for the Gowers norm over finite fields in low characteristic « What’s new")]], [#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/#comment-49533")[#strong[#text("The inverse conjecture for the Gowers norm over finite fields in low characteristic « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2011")])]

#text("[…] to the low characteristic case. (The case of a cyclic group or interval was established by Ben Green and ourselves in another recent paper. For an arbitrary abelian (or nilpotent) group, a general but less explicit […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 7: Sieving and expanders « What’s new")]], [#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/#comment-131024")[#strong[#text("254B, Notes 7: Sieving and expanders « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2012")])]

#text("[…] theorem handles infinite arithmetic progressions , and a somewhat complicated result of Green, Tao, and Ziegler handles “non-degenerate” affine lattices in of rank two or more (such as the lattice […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An inverse theorem for the continuous Gowers uniformity norm | What's new")]], [#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/#comment-457578")[#strong[#text("An inverse theorem for the continuous Gowers uniformity norm | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2015")])]

#text("[…] few years ago, Ben Green, Tamar Ziegler, and myself proved the following (rather technical-looking) inverse theorem for the Gowers […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Deducing a weak ergodic inverse theorem from a combinatorial inverse theorem. | What's new")]], [#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/#comment-457637")[#strong[#text("Deducing a weak ergodic inverse theorem from a combinatorial inverse theorem. | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2015")])]

#text("[…] mentioned in the previous post, Ben Green, Tamar Ziegler, and myself proved the following inverse theorem for the Gowers […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Deducing the inverse theorem for the multidimensional Gowers norms from the one-dimensional version | What's new")]], [#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/#comment-457655")[#strong[#text("Deducing the inverse theorem for the multidimensional Gowers norms from the one-dimensional version | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2015")])]

#text("[…] mentioned in the previous two posts, Ben Green, Tamar Ziegler, and myself proved the following inverse theorem for the Gowers […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Concatenation theorems for anti-Gowers-uniform functions and Host-Kra characteristic factors; polynomial patterns in primes | What's new")]], [#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/#comment-467302")[#strong[#text("Concatenation theorems for anti-Gowers-uniform functions and Host-Kra characteristic factors; polynomial patterns in primes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2016")])]

#text("[…] we are able to control global Gowers uniformity norms of such functions (thanks to results such as the proof of the inverse conjecture for the Gowers norms, the orthogonality of the Möbius function with nilsequences, and asymptotics for linear […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on nilcharacters and their symbols | What's new")]], [#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/#comment-480133")[#strong[#text("Notes on nilcharacters and their symbols | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2017")])]

#text("[…] a number of papers; in particular, the theory of nilcharacters is mostly developed in Appendix E of this 116-page paper of Ben Green, Tamar Ziegler, and myself, and is furthermore written using nonstandard analysis and treating the more general setting of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Odd order cases of of the logarithmically averaged Chowla conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/#comment-487027")[#strong[#text("Odd order cases of of the logarithmically averaged Chowla conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2017")])]

#text("[…] the Gowers uniformity of the (W-tricked) von Mangoldt function, established in several papers of Ben Green, Tamar Ziegler, and myself). The proof follows the lines sketched in the previous blog […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Higher uniformity of bounded multiplicative functions in short intervals on average | What's new")]], [#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/#comment-578371")[#strong[#text("Higher uniformity of bounded multiplicative functions in short intervals on average | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2020")])]

#text("[…] (The equivalence of (4) and (1) follows from the inverse conjecture for the Gowers norms, proven in this paper.) We quickly sketch first the proof of (3), using very informal language to avoid many […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on inverse theorem entropy | What's new")]], [#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/#comment-644063")[#strong[#text("Notes on inverse theorem entropy | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2022")])]

#text("[…] the norm on cyclic groups for , the inverse theorem proved by Green, Ziegler, and myself gives an -inverse theorem for some and consisting of nilsequences for some filtered nilmanifold […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erratum for “An inverse theorem for the Gowers U^{s+1}[N]-norm” | What's new")]], [#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/#comment-684814")[#strong[#text("Erratum for “An inverse theorem for the Gowers U^{s+1}[N]-norm” | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2024")])]

#text("[…] for the Gowers -norm” of Ben Green, myself, and Tamar Ziegler (previously discussed in this blog post). The main results of this paper have been superseded with stronger quantitative results, first in […]")
]
