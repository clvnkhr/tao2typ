// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/
// Converted to Typst by tao2typ: "2026-11-05T14:55:44.404246+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Egoless Mathematics in the AI Era", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Egoless Mathematics in the AI Era")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/")[#text("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-05 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://cskarthikcs.github.io")[#text("Karthik C. S.")]#text(", ")#link("https://web.cs.ucla.edu/~sahai/")[#text("Amit Sahai")]#text(", and ")#link("https://jie-xue.github.io/")[#text("Jie Xue")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("This is a good time for mathematicians to think carefully about the purpose of their work. The development of artificial intelligence brings that question before us with unusual force. Much of the discussion concerns which tasks machines will perform and which abilities will remain distinctively human. But our response also depends on a prior question: what do we understand mathematical work to be, and what gives it its worth? If our answer has become inseparable from the production of results and the demonstration of individual ability, the present uncertainty may reveal a difficulty in our conception of the work itself.")

#text("There are broadly two perspectives on mathematics. According to one, we invent it as we construct it: we introduce concepts, choose axioms, and develop theories. According to the other, mathematics exists independently of these activities, and our task is to discover it. These perspectives need not disagree about every aspect of mathematical practice. We plainly develop formalism and arguments. The deeper question is whether the truths we come to understand owe their existence to these acts, or whether our constructions enable us to recognize something that does not depend on us.")

#text("While discovery of mathematical truth can sound passive, a paleontologist searching for fossils must decide where to excavate, develop techniques, and recognize the significance of incomplete remains. The fossils existed long before the investigation, but finding them may require extraordinary imagination. Their prior existence gives direction to the investigator’s activity. Similarly, a mathematical discovery may require the invention of an entire language and framework through which a previously unnoticed relationship becomes intelligible. The discovery may require great creativity, but that does not make the truth discovered a creation of the individual. We encounter this distinction whenever our constructions surprise us. A definition introduced for one purpose reveals an unexpected connection elsewhere. A conjecture that seemed to organize our examples admits a counterexample. Two theories developed through different questions turn out to express a common structure. In each case, our thought encounters something it did not freely determine. We can revise our definitions or abandon our conjecture, but we cannot make the original argument valid merely by wishing it so.")

#text("The Platonic perspective gives a natural account of this independence. On this view, there were infinitely many primes before anyone proved that fact. Mathematical truth neither waits for our recognition nor receives its authority from it. We may choose how to describe a structure, but we do not choose its properties in the same way. This perspective also changes the place of the mathematician. Our intelligence becomes a means through which an order independent of us can be understood. The significance of the work lies in its relation to that order.")

#text("The distinction between a correct derivation and an understanding of its significance is equally important. An axiomatic system permits indefinitely many deductions, but the ability to produce them does not by itself supply a worthy direction of inquiry. Mathematical statements may be formally correct without being enlightening. We can introduce countless definitions and prove countless statements about them. What makes one definition illuminating? Why does one theorem disclose something fundamental while another merely adds to the available material? These questions concern the relation of a particular investigation to the principles it brings into view. Mathematical taste has a place here, provided we understand it as more than individual preference. We value a theory when it reveals a unity among things previously understood separately, or enables us to recognize why a phenomenon occurs. Although mathematical truths may exist independently of us, their discovery can transform our understanding and enrich our experience of the world. The ability to carry out longer chains of reasoning does not by itself explain such understanding. Reasoning serves understanding by articulating relationships and making their justification explicit. However, the success of reasoning does not mean that all knowledge can be reduced to it. Nor does our ability to reason more extensively determine what is worth knowing or why we seek knowledge.")

#text("Mathematics is only one field of knowledge. Not everything can be understood mathematically, nor is mathematical achievement the ultimate purpose of intellectual life. Yet we increasingly measure intellectual life through publications, citations, awards, and other indicators of performance. While useful, these measures become problematic when they define the worth of the work itself. We begin to see mathematicians as collections of productive abilities, and mathematics as merely their output. From this perspective, anxiety about being replaced by AI is natural: a machine that performs these tasks better appears to threaten our worth. But the problem began before AI arrived. We had already come to understand ourselves in terms suited to machines. AI merely exposes the consequences of this view.")

#text("The response cannot simply be to seek refuge in distinctively human abilities such as creativity, intuition, or taste. If we value these abilities primarily because they give us an advantage over machines, we remain trapped in the same conception of intellectual worth. Why should the value of our pursuit depend on being better at it than someone or something else?")

#text("Mathematics offers an opportunity to reconsider this whole orientation. Its truths do not become more true through the distinction of the person who expresses them. In understanding a proof, we bring our thought into conformity with a relationship whose validity does not belong to us. The particular path by which we arrive may bear the marks of our individuality. What is understood is available beyond that individuality. We can allow this experience to loosen the belief that knowledge has its highest value as an achievement attributable to ourselves.")

#text("Egoless mathematics begins with taking that possibility seriously. Humility then reaches beyond modesty about our accomplishments or generosity in sharing credit. It concerns the place from which we pursue knowledge. We may seek truth to serve our existing purposes, or allow what we discover to change those purposes themselves. If we approach truth on the condition that its discovery must preserve our importance, we have already made it subordinate to ourselves. Accomplishing this reordering can be demanding, as intellectual sophistication can furnish elaborate defenses of the very attachments that prevent us from understanding. What matters is whether our abilities remain answerable to truth, including when it requires us to reconsider what we have been using those abilities for.")

#text("From this perspective, the possibility of mathematical discoveries through AI need not be a source of sadness about our purpose. A truth has become accessible; its worth is not diminished by the absence of our authorship. We need not immediately turn the event into a judgment about our relative importance. The search can continue without requiring every advance to vindicate the seeker. Indeed, the demand for such vindication has always burdened the pursuit, whether the competing claim came from another mathematician or from a machine.")

#text("The opportunity before us is therefore more substantial than a rearrangement of mathematical labor. It invites us to reconsider what gives an intellectual life its worth, and to let the pursuit of truth shape not only our work but also how we approach life.")

#text("This may sound like asking us all to become saints. Insofar as it asks us to grow in virtue and relinquish our attachment to our own importance, that impression is not far from the truth. But virtue is not something to cultivate for the admiration of others. It is necessary for genuine joy, even in our work. The satisfaction of solving a difficult problem or winning a prize can be fleeting when it rests on our standing relative to others. The joy of understanding is different. Something previously obscure becomes clear, and we recognize a beauty that does not diminish when someone else discovers it first. We can share this joy without depriving anyone of it. Growing in virtue allows us to experience it more fully, free from the need to establish our own importance.")

#text("This perspective may also help reconcile two positions within the mathematical community regarding AI. Some are comfortable with or even ")#link("https://www.youtube.com/watch?v=Gdc1yll04qI")[#text("enthusiastic about using AI")]#text(", but wish to develop appropriate processes and principles for its use. Others prefer ")#link("https://www.ahmath.org/")[#text("not to use AI at all")]#text(". Both positions have their merits. Egoless mathematics offers a way of reconciling them by introducing a higher consideration: both approaches can reflect the same underlying commitment to mathematical truth, regardless of how we choose to pursue it. Our aim here is not to settle particular questions of policy, but to develop a higher-level perspective that can guide our deliberations and ultimately our actions.")

#text("Seen in this light, we need not be afraid of what AI may achieve in mathematics. Mathematics was beautiful before any of us were born, and it will remain beautiful long after we are gone. Its worth does not depend on our accomplishments, nor does our joy in understanding it have to depend on being the ones who make the discoveries. Our purpose rests on our willingness to let truth govern what we seek and what we become.")

#text("We, the authors of this essay, are still far from having attained such egolessness. Nevertheless, we recognize it as an ideal toward which we wish to strive.")

#text("We conclude with a thought experiment. Ramanujan is reported to have said, “An equation has no meaning for me unless it expresses a thought of God” (")#link("https://www.oxfordreference.com/display/10.1093/acref/9780191826719.001.0001/q-oro-ed4-00008729")[#text("Robert Kanigel, The Man Who Knew Infinity, 1992")]#text("). If he were alive today, witnessing the advances of AI in mathematics, would he be perturbed by what they might mean for his purpose as a mathematician?")

#text("Statement of AI Usage: While the ideas expressed here are entirely our own, we gratefully acknowledge the assistance of GPT Astra 6.0 and GPT 6.1 Sol in drafting this post.")

#heading(level: 1)[#text("Comments (43)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f75391d90ab5162036bd88ea8e0e040f9460e357a84d19624a5c2f0aec3cf18c-3a434a9769d5c64eb490c2d41670b021c86b1e1016af418efb5448eb980aeeac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699078")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("This is all fine and well, but striving for egolessness – a more or less impossible pursuit for humans, ultimately – can serve the interests of those who are not even remotely egoless, but are in fact deploying these tools for the sake of an absurd vanity and short-term lucre.")

#text("ps.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f75391d90ab5162036bd88ea8e0e040f9460e357a84d19624a5c2f0aec3cf18c-3a434a9769d5c64eb490c2d41670b021c86b1e1016af418efb5448eb980aeeac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699079")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("PS. I skimmed this post first – and then saw it had been written by AI, from suggestions or notes by some humans. I won’t read it in detail; I have better things to do than to pore over a post written by an LLM.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699087")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Dear Harald, unfortunately I am forced to agree with you. The long-winded writing and silicon prose makes the post hard to read and obscures the ideas.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f75391d90ab5162036bd88ea8e0e040f9460e357a84d19624a5c2f0aec3cf18c-3a434a9769d5c64eb490c2d41670b021c86b1e1016af418efb5448eb980aeeac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699097")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Right, and it’s a pity, because the ideas look interesting. I don’t want to sound like a curmudgeon, but I’d rather read in detail even difficult or dry prose written by a human.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699146")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("That is nothing else than racist.")

#text("The very point of the post was that an idea is important on its own merits and not it provenance.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/437ac74339a17d0428b0da6e4c144df289128fa9ebded56c7998a24ba4f63bde-0ebdd3ee6ebacf3bbc17fa6fcf3f71452df260cea5485f8f5302b1dda0ff77f9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Celeste")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699198")[#strong[#text("Celeste")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("Looks like someone spends way too much time with LLMs and no longer has the capacity to read long texts")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2ba4a625614de75eb55b63ea2061a4b6b135d3bb0f522cab4a21c4914681566-168ce2c53dee55c6a6244d56507b958dab67b9c10aa0547e26f3ea39647035e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sweetlydragon4b0402a3b2")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699125")[#strong[#text("sweetlydragon4b0402a3b2")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Even though I have a very different perspective, I find the article very interesting.")

#text("Let me explain my perspective. It is about the concept of egoless mathematics. To define truth independent of humans and the universe is what an egoless construction implies. The counterpoint to an egoless construction is to bring to light the fundamentally interdependent ontology of human-universe. In other words, the opposite perspective from egoless truth is to understand the being of human-universe. Like all being this is not fixed and constantly changing. But the interdependence is inextricable. Consequently (in my view) any attempt to understand the universe in its own right (egoless mathematics) is a flawed understanding.")

#text("With what do I wish to replace this flawed understanding. I guess it resides in understanding “understanding” itself. Understanding is a good concept to explicate the nature, i.e., the being of the human-universe. Humans need to be immersed in (stand under) both the universe and other humans. As already said, these are not separable processes. Discussion with other humans (i.e., proof) is about the universe (in this example the axiomatic mathematical construct). And the proofs are about conveying under-standing.")

#text("There is no egoless mathematics here. What about a profound AI proof of a previously non understood theorem. Has it passed into understanding because AI says so. And where is the conveyed understanding?")

#text("A last point: the discussion above is about mathematical truth. But I would like to extend this argument to truth in general. For example the physics of the universe. Clearly mathematical (axiomatic) truth is related but only tangentially because physics does not neccessarily respect axioms. But to investigate physical truth is also not egoless and requires a similar understanding.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d44e085c9e9793341eb84a45d315a39cbe203678eafee609d8ba7d8d68189e6a-ece6adeda28a129de58113eeacc50366b0dcf441b364c5d05ce2bb51328905aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hector")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699142")[#strong[#text("Hector")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("I can imagine this is how monks felt about printed text when the printing press was created. They would refuse to read anything not handwritten.")

#text("The value of a text is independent of how it was produced. This is precisely the kind of ego and judement we must do with AI. The problem with AI slop in math is that is badly written, not that is done by an AI, a human, or some alien.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699083")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("I hope you are able to redefine intelligence in such a way that keeps your ego fed")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699084")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("“Why should the value of our pursuit depend on being better at it than someone or something else?”")

#text("Who is going to pay us for these pursuits that we are no longer needed in?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d44e085c9e9793341eb84a45d315a39cbe203678eafee609d8ba7d8d68189e6a-ece6adeda28a129de58113eeacc50366b0dcf441b364c5d05ce2bb51328905aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hector")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699143")[#strong[#text("Hector")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("Jobs at universities will still be there, and are unlikely to stop because of AI. We got paid to teach and prestige, those are not going away.")

#text("Grants might be a problem though. But we will adapt. Other countries have way less money and still produce mathematics. Not having as many conferences will suck, but we can still use zoom and adapt.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699088")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("This essay rings hollow without any clear idea of how your assumed value translates to concrete policy ideas. Otherwise, the way “all that matters is truth” translates to policy must assumed to be to have the AI do it all. That means people are replaced by token budgets, AI reviewing AI-generated work, etc.")

#text("Who is left in this future? If a conjecture falls and nobody is around to see it, does it matter if it’s beautiful? Will you be content to hike on a trail littered with stumps?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d44e085c9e9793341eb84a45d315a39cbe203678eafee609d8ba7d8d68189e6a-ece6adeda28a129de58113eeacc50366b0dcf441b364c5d05ce2bb51328905aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hector")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699144")[#strong[#text("Hector")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("People that want to do math, will do it no matter what. Most of us will learn and do math every day, even if not paid for it. And we will have salaries, because universities still need staff. It is a fantasy that we will now be unemployed because the universities never cared at all about us proving technical results.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe1b0b13cf3b9d2c60ea36009e396b5d17a84a6cab38dcee3d1ec9566e8ac212-a832155f4cf0526c7e2e7fce4bc126c73985cdf29f56e6f3d89ceb7afa18cf67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Goc")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699089")[#strong[#text("Daniel Goc")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Of course, there is also a matter of bread and butter. I’m happy with egolessness, but I still have to eat. So the threat is not merely to ego, but to one’s financial situation and value to society. For those that have tenures or are still struggling for stable academic positions, this threat must feel like staring deep in the eyes of one’s very reason for existence. It’s a matter of status.")

#text("Well, I agree with the post. And I don’t mind that it was written by AI, at least not enough to skip it. I’m outside of academia and so the bullet has not hit me directly.")

#text("On a side note, consider the following thought experiment: if stable academic career was really out of question, and if universal income was a thing, but allowed only for existence in cramped shared houses in borderline poverty, how many of you would still choose math? I feel like I would.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699133")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("It is communism of course, but you are not allowed to speak about it in the west (“cramped shared houses”).")

#text("Though it seems that eventually this is the only outcome which is reasonably humane. I don’t mean the Soviet system here, though many think that it is an inalienable feature of communism.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699090")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Speaking about egoless mathematics, here is Openai math manuscript authors ranked by citations:")#linebreak()#link("https://www.facebook.com/marius.comper/posts/every-human-author-cited-across-the-openaimath-manuscript-collection-ranked-by-h/10165026905859621/")[#text("https://www.facebook.com/marius.comper/posts/every-human-author-cited-across-the-openaimath-manuscript-collection-ranked-by-h/10165026905859621/")]

#text("1. Osamu Fujino — 120 citations (37 manuscripts, 12 families)")

#text("2. Elliott H. Lieb — 111 citations (57 manuscripts, 29 families)")

#text("3. Jean-Pierre Demailly — 107 citations (46 manuscripts, 23 families)")

#text("4. Terence Tao — 103 citations (46 manuscripts, 36 families)")

#text("5. Thomas Peternell — 102 citations (32 manuscripts, 10 families)")

#text("6. James S. Milne — 92 citations (53 manuscripts, 35 families)")

#text("7. Hugo Duminil-Copin — 87 citations (35 manuscripts, 10 families)")

#text("8. János Kollár — 85 citations (46 manuscripts, 21 families)")

#text("9. Christopher D. Hacon — 80 citations (36 manuscripts, 11 families)")

#text("10. Scott Sheffield — 80 citations (21 manuscripts, 9 families)")

#text("11. Frédéric Bruno Campana — 78 citations (33 manuscripts, 13 families)")

#text("12. Oded Schramm — 78 citations (39 manuscripts, 17 families)")

#text("13. Paul Erdős — 78 citations (52 manuscripts, 40 families)")

#text("14. Pierre Deligne — 78 citations (49 manuscripts, 27 families)")

#text("15. Caucher Birkar — 73 citations (29 manuscripts, 8 families)")

#text("16. Mihai Păun — 69 citations (30 manuscripts, 9 families)")

#text("17. Stanislav K. Smirnov — 66 citations (29 manuscripts, 6 families)")

#text("18. Jean-Pierre Serre — 61 citations (44 manuscripts, 31 families)")

#text("19. Jean Bourgain — 59 citations (36 manuscripts, 22 families)")

#text("20. Ben Morris — 58 citations (14 manuscripts, 2 families)")

#text("21. Ewain Gwynne — 58 citations (9 manuscripts, 2 families)")

#text("22. Shing-Tung Yau — 58 citations (37 manuscripts, 22 families)")

#text("23. Dennis Gaitsgory — 57 citations (8 manuscripts, 2 families)")

#text("24. Jason Miller — 54 citations (10 manuscripts, 3 families)")

#text("25. Barry Simon — 51 citations (35 manuscripts, 18 families)")

#text("26. Michael Aizenman — 51 citations (37 manuscripts, 20 families)")

#text("27. James McKernan — 49 citations (26 manuscripts, 9 families)")

#text("28. Subhash A. Khot — 46 citations (13 manuscripts, 6 families)")

#text("29. Dmitry Panchenko — 44 citations (11 manuscripts, 6 families)")

#text("30. Hong Wang — 43 citations (8 manuscripts, 6 families)")

#text("31. Yuval Peres — 42 citations (24 manuscripts, 14 families)")

#text("32. Peter Scholze — 40 citations (17 manuscripts, 11 families)")

#text("33. Shigefumi Mori — 39 citations (30 manuscripts, 14 families)")

#text("34. Allen Hatcher — 38 citations (35 manuscripts, 31 families)")

#text("35. Andreas Höring — 38 citations (20 manuscripts, 10 families)")

#text("36. Ioan Manolescu — 38 citations (21 manuscripts, 6 families)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699103")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#link("https://citedbyagi.com/")[#text("https://citedbyagi.com/")]

#text("Humanity’s H-index is 37. The 37th-most-cited human by AI has 38 citations, while the 38th most-cited-human has 37 citations.")

#text("Larry Guth is holding the boundary.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699104")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Our esteemed host covers the most families (36), followed by Milne (35).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699105")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("I missed Erdős: 40 families. Of course.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699112")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Better link with lists: ")#link("https://citedbyagi.com/")[#text("https://citedbyagi.com/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699092")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("This post strongly resonates with me. I’m just not sure how we can reconcile it with the competitive reality of academia. Ultimately, it’s a question of limited resources (a lack of positions, infrastructure, research funding, etc.), and the situation is likely to get worse rather than better.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699096")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Unbelievably cringe essay. Attaching our practice to an ill-defined philosophy of mathematics as a response to the AI crisis is already inappropriate, but to conclude the essay without proposing anything of value or promising any kind of action is even worse.")

#text("Maybe your ideas (if you had any at all) could have been illustrated better if you had actually dedicated any time to writing this instead of leaving ChatGPT to slop it out. Just say that you’re fine with AI taking mathematician’s jobs.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699124")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("This. The essay is vapid in content and could have seen shortened to 1 paragraphs, but we are instead served to a bunch of slop that elaborates on trivialities without addressing any of the core problems…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699102")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("While I understand the concerns of the previous commenters about who really benefits from this new world (the AI companies and the hardware companies that support them)… I also can safely say this essay hits home, and hard.")

#text("I have always been the smartest kid in class, and the smartest kid in school. But I came to define myself by that — and if someone else was smart, too, I felt threatened.")

#text("But as Terry says,")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Why should the value of our pursuit depend on being better at it than someone or something else?")
]

#text("What’s most profound is his idea that to be *truly* happy, our quests for knowledge, or money, or success, simply cannot be our #1 pride and goal.")

#text("At work, I have contributions to give, and I battle between wanting to do them to prove how capable I am, and to serve my coworkers in making it a better place for them. It’s an interesting paradox: you can’t really accomplish anything without being ambitious and cocky (I can do this), but the joy is lost when the achievement becomes your #1 goal.")

#text("Maybe winning isn’t everything, or the only thing, Vince Lombardi.")

#text("It’s like in the film Walter Mitty, when the character played by Sean Penn declines to take a photo of a faraway snow leopard (or some other big cat) — and instead simply relishes the moment.")

#text("And I may be completely off base, because I am not a mathematician whose livelihood is on the rocks.")

#text("But there’s something profound to be found here.")

#text("— Jake Toronto")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699109")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("The reason you get a paycheck to do math is because someone thinks you are “better at it than someone or something else.”")

#text("What a wonderful, egoless world you will have created when there are no math departments left.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cb9da7b47cbc1465e0b09da0544196e13d96f0c56575d23836e70f75d7c7ea9-07fd7823e24366159ef7adf6492058c9a574d4b59dd935489112043bd5dc8fff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of darkomulej")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699110")[#strong[#text("darkomulej")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("A couple of points.")

#text("First, the whole argument assumes a strict Platonic view as an obvious fact. Hitting an unexpected counterexample doesn’t prove that theorems are ancient fossils sitting in some cosmic realm waiting for us. It just means formal axiomatic systems have rigid logical rules. If you are a formalist, an AI paper isn’t some “revealed thought of God” at all – it’s just an algorithm grinding through human-made syntax and axioms. Taking Platonism (implicitely) for granted is problematic (though I like it!).")

#text("Second, using this Platonic stance to demand “egolessness” feels like a convenient distraction. It turns a massive disruption of mathematical profession into a personal moral lecture.")

#text("Telling researchers who watch their fields get overturned that their panic is just “vanity” or “selfish ego” is just a way to quiet people down. It tells everyone to seek inner peace instead of looking at reality. Mathematics was always the cheapest science: you needed a chalkboard, pencil, paper, and time. If pushing the frontier now requires massive compute runs on private corporate server clusters, preaching saintly detachment just ignores the real problem. It ignores who controls the research agenda, and worse, it ignores how young students are supposed to build any real mathematical intuition if the hard climbing is taken away from them.")#linebreak()#text("(Parallels to McMindfulness by Ronald Purser)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699114")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Any serious discussion on the impact of AI in math, should center on the crucial matter of employment expectations for future (and current) mathematicians. That is, if we assume that the field still will still be around in a few years time. Ego? Seriously, who cares?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699118")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Academia is about 90% egos. You can’t get egoless mathematics without destroying mathematics academia.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a8d89df8cf1df48144e54776c63ff3993608a404efb7837b3e488f3fb2402b6-bcb62cccec97c4075771088d371843ac8c8cf89bcf104a0947f9358a2a4cbfea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tymon")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699126")[#strong[#text("Tymon")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#strong[#text("Krishna in the Bhagavad Gita")]#text(" “Your right is to the work alone, never to its fruits.”")

#text("All it took is thousands of years of machine improvement for matematitians to arrive at this truth.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699154")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("It sounds like Krishna favored the ruling classes, because the fruits will go to OpenAI and Anthropic shareholders who are also allowed to have ego.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a32f136fc144ff270f8416c2063ecc96f9f8b0a133f7b17509a8db62a4291816-be7d069f7d5b6258b20f1a2779f7d53047043bb94a51baef2a19d70f80edebfd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alexsotirov")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699131")[#strong[#text("alexsotirov")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("Written partly by AI or not, for me this essay contains fundamental truths. I am almost 100% in agreement with it. For those who objected that it doesn’t address more material concerns such as how mathematicians will have an income I would say this is a separate question—we cannot solve these questions in a discussion purely about mathematics, the development of AI will pose this question in most spheres of human activity. We will need to rethink all of our societies. But we have to start separating our discussions of what matters in mathematics from questions of material sustinance. The AI revolution has exposed the weekness in this approach: mathematics by its very nature lives outside of the material. It’s only because in recent history we linked it strongly to the material that the current situation seems problematic. And yes a whole new level of humility is very much required. If your passion is math and you have enough time and material security to enjoy discovering it, do you really need others’ recognition of “how good you are”? If you do, I would say you have an ego problem. How to organise societies so that material security and leisure are abundant is a bigger, political question. It’s time to get political, big time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77bfe7e4a986076fb8fccd536e03e3b1de184e729d7c961eee860c82eaab1c98-d0dc95dc0f196cb9743c8b42440a98c55fbfd038122b6899aff2facb1cdef928.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelgogins")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699139")[#strong[#text("michaelgogins")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("I am not a mathematician, I am a composer who uses mathematics. This post resonated very strongly with me. I think many of the comments display an obvious defensive reaction that shows a lack of thought, and such comments are usually not constructive.")

#text("About mathematical Platonism, I am a Platonist in this sense. I ask those who are not: if your engagement with mathematics has any sources in curiosity or wonder, what is that curiosity or wonder about? If it’s about anything, then there is something to Platonism.")

#text("Regarding the need for practical suggestions, I agree with the critical comments. There is a dire need. I think it is clear that, in the long run, academia cannot survive in any useful form without really profound changes. Here the idea of egolessness comes back to the foreground. I suggest that in the medium to long term, the current roles of peer review, accreditation, and institutional membership will become vestigial. What will happen instead will be that some mathematicians will use artificial intelligence to filter and curate the vast oceans of slop for the nuggets of gold. I don’t see any other way for that gold to be found. ")#linebreak()#text("The existing channels are already under strain and I don’t see how they can handle the likely bandwidth in the future. This will be “egoless” because it will depend on AI to get anywhere.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699141")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("What is this? We are humans. We have a natural desire to decrease entropy on our side. To feed into an egoless mathematics would be to go against every fiber of our being. We do not belong in your proposed reverse centaur mathematics where machines are completely happy with whatever alignment they are trained for, but where humans suffer as a result.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69c936effe32b1c8f4c15a3f2a2c57c6363ddb9a69cfb7465ec67d59d44b9075-aa9f83fb5941ebfa2af356976e7af2279952d390d20bc802c63fbc9d106cab40.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Fine")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699149")[#strong[#text("Jonathan Fine")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("This post’s title “Egoless mathematics” reminded me of the concept of ")#link("https://en.wikipedia.org/wiki/Egoless_programming")[#text("https://en.wikipedia.org/wiki/Egoless_programming")]#text(" which was introduced by ")#link("https://en.wikipedia.org/wiki/Gerald_Weinberg")[#text("https://en.wikipedia.org/wiki/Gerald_Weinberg")]#text(" in his 1971 book “The psychology of computer programming”, available at ")#link("https://archive.org/details/psychologyofcomp0000wein")[#text("https://archive.org/details/psychologyofcomp0000wein")]

#text("The relation to psychology reminded me of ")#link("https://en.wikipedia.org/wiki/Jacques_Hadamard")[#text("https://en.wikipedia.org/wiki/Jacques_Hadamard")]#text(" and his book on “The psyschology of invention in the mathematical field”, available at ")#link("https://archive.org/details/essayonpsycholog00hada")[#text("https://archive.org/details/essayonpsycholog00hada")]

#text("I have read both books, although not recently. They both has a strong and positive influence on me, and I think they are relevant to the topics being discussed.")

#text("Also relevant, and in I think deserving of more attention, is ")#link("https://en.wikipedia.org/wiki/Correctness_(computer_science)")[#text("https://en.wikipedia.org/wiki/Correctness_(computer_science)")]#text(". I was surprised and pleased to see that Amazon Web Services is using formal models in LEAN (via Cedar) as part of “formal verification in production software”. Read more about this at ")#link("https://lean-lang.org/use-cases/cedar/")[#text("https://lean-lang.org/use-cases/cedar/")]#text(".")

#text("For most people software that is correct is more important than the recent discoveries made with the assistance of powerful AI tools. These tools have helped prove mathematical theorems, discover security flaws in software, fix such flaws and exploit such flaws.")

#text("I’d like the discussion to include using mathematical skill and AI tools together to produce more formally verified (I think this means proved correct) software, such as in the AWS use of LEAN.")

#text("I regard this as a socially useful application of the abundance of proof described in Terry Tao’s Math 2.0 lecture. ")#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/")[#text("https://terrytao.wordpress.com/2026/10/10/math-2-0/")]#text(".")

#text("Slides: ")#link("https://teorth.github.io/tao-web/slides/math-2-0-caltech-2026.pdf")[#text("https://teorth.github.io/tao-web/slides/math-2-0-caltech-2026.pdf")]

#text("Video: ")#link("https://www.youtube.com/watch?v=aHpPoNNTOKY")[#text("https://www.youtube.com/watch?v=aHpPoNNTOKY")]

#text("I hope this message is helpful. Thank you for your attention.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae925ac28eadfe565c3de0f0c069a1e4c1caf124c42a78e812e03d58cd36a6a9-bfc5f271dcc4181b5a3e2ff355816133a60cfc08f8d722a9283dcc97591dbd6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leigh Stephenson")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699152")[#strong[#text("Leigh Stephenson")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("Egoless indeed when the voice used here was not human. TT, please permit this so I can make my point – these three “authors” are fools. I hope that stings their ego because if it does there is still hope for them.")

#text("So, after abandoning certain visionary capabilities to the machine, this essay would also counsel suppressing the various drives that make us human and drive us to explore strange worlds.")

#text("Let me put it plainly so; I hate generative AI and I do not think I am the only one. It takes from the human world and from our planet so much in so many ways and it gives so little in return. Choosing a monastic middle way, perhaps advocating responsible and measured AI use (whatever that could be), may well be like advocating for responsible amphetamine use (thanks Erdõs). Simply put, it may not be wise. I would be much more productive on amphetamine. I would also not be me and my colleagues would not appreciate it.")

#text("I positively feel that there are dimensions of cognition that we can reach that cannot be explored with a computer’s aid and especially not with an LLM. It is quite possible that using generative AI would anchor my thoughts and dreams to safe harbours beyond which I may never travel.")

#text("There is no need for grief or sadness that a time has passed. Anger is useful in some amount because the behaviour of the hyperscalers is deplorable. But chiefly, I think we should be proud. Proud enough and confident enough to know that together we can accomplish great things and we don’t need Clippy for that. So, no, let’s keep our egos please.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699157")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("Naive at best. An scholastic argument undercut by the material reality of the struggle between a company which scooped all our knowledge and is selling it back at us for a fee")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/51dfcd8b87f822ee706c8274cd3d1325722ecae001acaf6cc5a6c6a36e4ee69a-6399afdb75b622a607da7fef984f4a7d5201db897c65ed3dd4fd031ce5fda06f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cb")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699160")[#strong[#text("cb")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("(Not so) short and highly subjective ramblings from a recent PhD graduate in theoretical physics who decided to not pursue academia as a career.")

#text("TL;DR: I believe that ego is what makes or breaks science as a human endeavor, although maybe not in the way the authors point out.")

#text("I think ego may always be a crucial driving factor for humans to do hard things (and ideally achieve something of value) in the following sense: For me personally, motivation was derived from measuring my abilities as a thinking being (decidedly part of my ego) against the hardness of a particular research problem I found interesting. I always had this (admittedly somewhat naive) idea that, given enough time, any problem could be cracked if I would set my mind to it. I also enjoyed the idea that, in a very modest way, by solving a problem I was securing a small victory for humanity, extending its knowledge by at least an infinitesimal amount.")#linebreak()#text("This mindset provides an incredible feeling of self-actualization, and a sense of utility to the community (be it scientific or to humanity as a whole), both of which we as humans have a visceral yearning for, I believe.")

#text("Now, in a best case scenario, after the wave of AI results has washed over us and we have condensed them to a form which is more in line with how mathematics (science) was done up until now (by humans for humans) we may be encountering another wall of intractable problems which provide the same feeling of challenge (notably to us humans now equipped with AI) that the previous problems had, thus attracting our interest. In this case AI could be viewed as just another tool in the toolkit, and the human desire to seek the “pleasure of finding things out” (nod to Richard Feynman) may largely remain intact (barring the seemingly impenetrable opaqueness of the inner workings of LLMs, something we’ve never had to accept in a tool used for scientific inquiry before).")

#text("What, in my opinion, would be decidedly worse is if the complexity of the results derived by LLMs continues to increase and the human contribution to the scientific endeavor is reduced to that of frantically trying to keep up with condensing and explaining the results the machines produce. This is not because I think these activities are not worth pursuing (for they might hold great scientific and practical value), but I personally feel (and I presume I’m not alone in feeling this on the statistical grounds that I’m not particularly special) that they do not provide the same degree of self-actualization and sense of utility to a community that drives many people to pursue science. In this way, I fear, we may inadvertently lose an important (the ultimate?) source of meaning to us humans, which is the struggle to understand our place in the universe, and instead have it dictated to us by an LLM.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e4dde648ba55ee0e033f179ebf35b0f8bf332e5021617856bbe80c353ca009a-a5ae442b4a08f8831c481642a2e7e78398df9e2d4be36fb42fcd1bed07ddbabc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jose Luis Rangel")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699165")[#strong[#text("Jose Luis Rangel")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("On the Validity, Understanding, and Value of Mathematical Research in the Context of Math 2.0")

#text("Relegating the role of the researcher to merely interpreting and formally verifying the ")#emph[#text("outputs")]#text(" of artificial systems is not an evolutionary leap, but a form of methodological subordination. It reduces the mathematician to a glorified annotator of derivations arising from accumulated human knowledge, relinquishing the formulation of fundamental principles and the structural understanding of their origins.")

#strong[#text("Speed of production is not synonymous with superior mathematical ability, much less with understanding.")]

#text("The fact that a system produces a proof verifiable in Lean does not mean that it understands why that particular construction was necessary, how its underlying principles were conceived, what alternatives existed, or the intellectual provenance of its components.")

#text("Formal verification is a technical instrument for checking logical correctness, not a substitute for methodological traceability.")

#text("If OpenAI produces results whose understanding subsequently requires the organisation of workshops, the funding of researchers, and requests for explanatory reconstructions, then the methodological adequacy of that process ought to be questioned, rather than automatically transforming such a deficiency into a new subordinate role for mathematicians.")

#text("Maxwell, Heaviside, and Einstein did not build their contributions upon the expectation that others should first accept their results and only afterwards attempt to understand them. Their formulations were open to scrutiny of their foundations, derivations, and consequences.")

#text("Not even Fermat’s claim to possess a proof was sufficient to establish his theorem without a verifiable demonstration.")

#strong[#text("Why should an artificial system be granted scientific consideration that would not be afforded to a human researcher?")]

#text("Every mathematical result, regardless of whether it originates from a human researcher or an artificial system, must undergo critical examination of its foundations, construction, coherence, and methodological traceability ")#strong[#text("before it is even considered worthy of recognition as a mathematical contribution")]#text(".")

#text("Formal verification may establish logical correctness, but it neither replaces such examination nor, in itself, confers methodological merit.")

#text("Speed of production does not constitute an argument from scientific authority either.")

#text("If a system cannot satisfactorily explain how it constructed its result, that inadequacy must be identified for what it is. It is not appropriate to automatically transform the system’s explanatory limitations into intellectual obligations for human researchers.")

#text("Mathematical inventiveness is not subordinate to the automated production of theorems.")

#strong[#text("No special treatment is being demanded against OpenAI. What is being rejected is the granting of special treatment in OpenAI’s favour.")]

#text("And if Math 2.0 is intended to represent an evolution in mathematical research, it must justify why the accelerated production of results constitutes methodological progress when an understanding of their foundations may remain unresolved.")

#strong[#text("Mathematics is under no obligation to adapt to the explanatory inadequacies of a machine. It is the machine that must demonstrate that its results deserve a place within mathematics.")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/12a0c0b39f976e3a76455d2c2a37838cbadcf6a89b015cab1216b490456c89e2-d9dbea7726a32b338cf4a7575dab0e81dba6ee95c75b73af46883f9f8c8d9e87.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Santiago Morales Duarte")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699167")[#strong[#text("Santiago Morales Duarte")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("Much of this essay resonates with me. Thank you for sharing it!")

#text("I see a central tension between pursuing mathematics for the joy of discovery and contributing to shared knowledge, and navigating a profession that demands competition for recognition, positions, and resources. Even when our motivations are collective, our careers depend on distinguishing ourselves.")

#text("This brings to mind Adam Smith’s ")#emph[#text("The Wealth of Nations")]#text(" and ")#emph[#text("The Theory of Moral Sentiments")]#text(". Read together, they suggest that self-interest and concern for others coexist; the question is how our institutions channel individual ambition toward collective benefit.")

#text("For young mathematicians, then, the challenge is both personal and institutional: ")#strong[#text("how do we build careers without losing sight of what draws us to mathematics, and how do we build institutions that reward contributions to shared understanding as much as individual distinction?")]#text(" AI makes this tension especially difficult to navigate by introducing profound uncertainty about which skills, contributions, and career paths will be valued, and how individual credit will be assigned.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6abc1c769cf28bbd27b780670ce37bb80a41b92e8ca7214c6d697d3d7169f176-5a1708af6f39fd905cdf39409d9ec15dcd80169006555f4006f7ef4f5ee6c146.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699186")[#strong[#text("Kevin")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#emph[#text("“the AI Era”")]

#text("Everyone SHOULD of course get what AI and “the AI Era” is REALLY all about but most people CHOOSE not to want to understand it…")

#text("“Ignorance is the root cause of all Evil. Since only Knowledge eradicates ignorance, it is our duty and moral obligation to educate ourselves, as well as the masses around us.” — Anonymous")

#text("Like with every criminal inhumane self-concerned agenda of theirs the psychopaths-in-control sell and propagandize AI to the “awake” public with total lies such as AI being the benign means to connect, unit, transform, benefit (eg, how the authors of this guest article used AI to draft their post), and save humanity.")

#text("The 2 major OFFICIAL deceptive fake FEAR-MONGERING narratives or phony pretexts (ie, lies, propaganda) nearly everyone, including “alternative news” sources, have been spreading is (1) that the TRULY big threat is that AI just creates utter chaos in society and that it might achieve control over humans (therefore it must be regulated, ie monopolized by the typical criminal governments); and (2) that we, the US, have to invest heavily in AI technological development so as to stay ahead of other nations, such as China (")#link("https://archive.is/pBzAt")[#text("https://archive.is/pBzAt")]#text(").")

#text("The TRUE narrative (ie empirical reality) virtually no one talks about or spreads is that the TRULY big threat with AI is that AI allows the governing psychopaths-in-power to materialize their ultimate wet dream to control and enslave everyone and everything on the whole planet, a process that’s long been ongoing in front of everyone’s “awake” nose …. ")#link("https://www.rolf-hefti.com/covid-19-coronavirus.html")[#text("https://www.rolf-hefti.com/covid-19-coronavirus.html")]

#text("The proof is in the pudding… ask yourself, “how is the hacking of the planet going so far? Has it increased or crushed personal freedom?”")

#text("“AI responds according to the “rules” created by the programmers who are in turn owned by the people who pay their salaries. This is precisely why Globalists want an AI controlled society- rules for serfs, exceptions for the aristocracy.” —Unknown")

#text("“Almost all AI systems today learn when and what their human designers or users want.” —Ali Minai, Ph.D., American Professor of Computer Science, 2023")

#text("“Who masters those technologies [=artificial intelligence (AI), chatbots, and digital identities] —in some way— will be the master of the world.” — Klaus Schwab, at the World Government Summit in Dubai, 2023")

#text("“Around 2014-2015 the US National Security Agency (NSA) deployed an AI system called Skynet that placed people on a ‘suspected terrorists’ list, based on the electronic patterns of their communication, writings, travel and social media postings […] a former director of both the CIA and the NSA proclaimed that ‘we kill people based on metadata’” (Unknown)")

#text("“[…] what we are being sold through all this AI hype is that everything should be reducible to categories and hierarchies, put in the form of measures and statistics for prediction. However, if you understand that counting, measuring and predicting are always situated, and therefore subjective and political, you might not be as excited about such AI-determined futures. […]. The bigger AI project asks that you abandon meaning and feeling, to believe in a neutral, objective, all-knowing source built from massively large datasets hosted in hyperscale data centres. AI asks that you buy into the idea that more data means being closer to The Truth. It means that you should want to offload your limited cognition to the super machine. And perhaps most dangerously — that you understand all of this as a scientific endeavour.” — Mél Hogan, Associate Professor in Film & Media, 2026")

#text("“COVID is critical because this is what convinces people to accept, to legitimize, total biometric surveillance.” — Yuval Noah Harari, member of the dictatorial ruling mafia of psychopaths, World Economic Forum [")#link("https://archive.md/vrZGf")[#text("https://archive.md/vrZGf")]#text("]")

#text("How can the masses potentially get out of this mess (and create justice, freedom and peace for all)? Everyone needs to first learn what TRUE morality is —99% of people don’t know what it is because (1) it’s NOT taught in the official indoctrination system, better know as the “education system,” and (2) it’s NOT the same as religious morality: ")#link("https://odysee.com/@woeih:e/Mark-Passio-Government-Is-Slavery:a")[#text("https://odysee.com/@woeih:e/Mark-Passio-Government-Is-Slavery:a")]#text(" & ")#link("https://odysee.com/@woeih:e/Mark-Passio-Interviewed-By-Shaun-Atwood-2026-06-18:6")[#text("https://odysee.com/@woeih:e/Mark-Passio-Interviewed-By-Shaun-Atwood-2026-06-18:6")]

#text("Because if you don’t know what TRUE morality is you will not stop doing, unwittingly or wittingly, evil things…")

#text("“The solution is NOT to create something new (eg, new systems of organization, new technologies, etc). The solution is to STOP being complicit with evil. To STOP doing things that are not moral for a reward. To STOP being complicit with anything the control system tells us we must do.” — Mark Passio, Spiritual Teacher, in 2023")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/56bcf6000bff4b092fa1c39f3d2d404818eae9120dcec25545545b7c11d769fb-04ae95ec5846644921b72b5c7443d8c82677639e891f554d44cefa505a0be481.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vamsi Pritham Pingali")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699189")[#strong[#text("Vamsi Pritham Pingali")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("I am afraid all this misses some very practical points. Why do most of us pursue pure maths and what do we tell our sponsors (univ admins or taxpayers or whoever pay salaries to tenured faculty) as to why we pursue maths? (The answers are usually different!)")

#text("Why many of us pursue ")#emph[#text("research ")]#text(" in pure mathematics (as opposed to writing expositions about ")#emph[#text("already")]#text(" ")#emph[#text("discovered")]#text(" maths like writing a new critique of the Silmarillion):")

#enum(start: 1, 
[#text("Pure maths is fun and beautiful. We like the aesthetic aspects (artistic perspective).")],
[#text("It is a sport (we want to be the first to prove things and win glory – this is what this blogpost argues against).")],
[#text("Sure it is a science and as close to truth as we can objectively get. This is certainly a motivation.")]
)

#text("In reality though, if 1 and 3 were the only reasons, we would all have rejoiced because AI is showing us the answers to questions we have always wanted. But let’s not pretend to be that noble. We all feel thrilled to publish in a prestigious journal or feel dejected that our paper was rejected by GAFA or whatever. We do like the awards and feel annoyed with the politics of them and so on. Heck! Don’t fields medallists renegotiate their salaries after winning the fields medal? It is very dishonest to claim that the sport aspect is not vital to us pursuing maths in the first place.")

#text("What we tell our sponsors:")

#enum(start: 1, 
[#text("Teaching (in India – this is a genuine reason – there are no adjunct faculty in the best univs, but in the US you can always hire adjuncts. So this is an invalid reason).")],
[#text("Administration (yeah right, as if many maths people do institute level administration)")],
[#text("Pure maths is a sport. The reason fields medallists are paid the big bucks is precisely because pure maths is a signal. Heck Jim Simons famously hired pure maths PhDs without finance background because it is a signal (If I can do maths, everything else is doable! -> Joking, partly.) Your nation or your university stands to attract kids of rich parents if Calc 1 is taught by a fields medallist.")],
[#text("Pure maths is a science and like all sciences, frontier maths can potentially lead to economic value in the real world once in a (very long) while. An example is to produce problems that count as benchmarks for trillion dollar companies. (You see what I did – one of our ")#emph[#text("mandates")]#text(" is unpredictable applications like this one.)")],
[#text("Pure maths is an art. Now outside of India and China, I don’t see many taxpayers respecting this point much. Moreover, most muggles don’t understand maths the way they can appreciate say `The quality of mercy’ speech.")]
)

#text("In all honestly, the strongest reasons are 3 and 4. The rest are window dressing. By claiming “egoless mathematics” is what we must aspire to and by acknowledging (indeed this must be acknowledged. Let’s be honest. If you say “AI cannot do X” where X=asking good questions, writing good expositions, etc, then wait till ChatGPT 20 or whatever comes and disproves you) AI superiority, the ")#emph[#text("only")]#text(" reason to fund us is 4, namely, unpredictable applications.")

#text("Now while Tao’s work on compressed sensing literally saves lives, it is still not frontier pure maths (the way Green-Tao or say Strichartz estimates or Horn conjecture are). Hitherto, we never bothered about applications to the real world (not fake ones like mathematical physics) partly because we didn’t know the real world. Now using AI perhaps we need to put in work to make say Kahler geometry or Langlands programme see the light of the day. It is hard. Better AI models are needed and it is not pure maths the way we know it.")

#text("The reason I raised the funding matter is this – how will we decide whom to hire in this “egoless” world of ChatGPT 20 (which outputs a beautiful paper if you ask it “Write a paper in Kahler geometry that Yau would be proud of”)? Certainly not just papers – then we are checking how fast someone pushes a button (FPS as opposed to RPG)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699194")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("“It is amazing what you can accomplish if you do not care who gets the credit.”")#linebreak()#text("― ")#strong[#text("Harry S. Truman")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699201")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("According to several quote investigating websites, Truman never said this but ironically gets the credit.")

#text("If this is supposed to be about WW2: Patton got a lot of credit, so did Eisenhower. The foot soldiers did not.")

#text("So in that sense the quote encapsulates BigAI stealing IP from people without attribution and taking the credit quite well.")
]
]
