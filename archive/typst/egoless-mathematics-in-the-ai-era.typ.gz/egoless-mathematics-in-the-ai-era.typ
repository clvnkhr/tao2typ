// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/
// Converted to Typst by tao2typ: "2026-11-03T14:31:46.972215+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Egoless Mathematics in the AI Era", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Egoless Mathematics in the AI Era")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/")[#text("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-03 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://cskarthikcs.github.io")[#text("Karthik C. S.")]#text(", ")#link("https://web.cs.ucla.edu/~sahai/")[#text("Amit Sahai")]#text(", and ")#link("https://jie-xue.github.io/")[#text("Jie Xue")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("This is a good time for mathematicians to think carefully about the purpose of their work. The development of artificial intelligence brings that question before us with unusual force. Much of the discussion concerns which tasks machines will perform and which abilities will remain distinctively human. But our response also depends on a prior question: what do we understand mathematical work to be, and what gives it its worth? If our answer has become inseparable from the production of results and the demonstration of individual ability, the present uncertainty may reveal a difficulty in our conception of the work itself.")

#text("There are broadly two perspectives on mathematics. According to one, we invent it as we construct it: we introduce concepts, choose axioms, and develop theories. According to the other, mathematics exists independently of these activities, and our task is to discover it. These perspectives need not disagree about every aspect of mathematical practice. We plainly develop formalism and arguments. The deeper question is whether the truths we come to understand owe their existence to these acts, or whether our constructions enable us to recognize something that does not depend on us.")

#text("While discovery of mathematical truth can sound passive, a paleontologist searching for fossils must decide where to excavate, develop techniques, and recognize the significance of incomplete remains. The fossils existed long before the investigation, but finding them may require extraordinary imagination. Their prior existence gives direction to the investigator’s activity. Similarly, a mathematical discovery may require the invention of an entire language and framework through which a previously unnoticed relationship becomes intelligible. The discovery may require great creativity, but that does not make the truth discovered a creation of the individual. We encounter this distinction whenever our constructions surprise us. A definition introduced for one purpose reveals an unexpected connection elsewhere. A conjecture that seemed to organize our examples admits a counterexample. Two theories developed through different questions turn out to express a common structure. In each case, our thought encounters something it did not freely determine. We can revise our definitions or abandon our conjecture, but we cannot make the original argument valid merely by wishing it so.")

#text("The Platonic perspective gives a natural account of this independence. On this view, there were infinitely many primes before anyone proved that fact. Mathematical truth neither waits for our recognition nor receives its authority from it. We may choose how to describe a structure, but we do not choose its properties in the same way. This perspective also changes the place of the mathematician. Our intelligence becomes a means through which an order independent of us can be understood. The significance of the work lies in its relation to that order.")

#text("The distinction between a correct derivation and an understanding of its significance is equally important. An axiomatic system permits indefinitely many deductions, but the ability to produce them does not by itself supply a worthy direction of inquiry. Mathematical statements may be formally correct without being enlightening. We can introduce countless definitions and prove countless statements about them. What makes one definition illuminating? Why does one theorem disclose something fundamental while another merely adds to the available material? These questions concern the relation of a particular investigation to the principles it brings into view. Mathematical taste has a place here, provided we understand it as more than individual preference. We value a theory when it reveals a unity among things previously understood separately, or enables us to recognize why a phenomenon occurs. Although mathematical truths may exist independently of us, their discovery can transform our understanding and enrich our experience of the world. The ability to carry out longer chains of reasoning does not by itself explain such understanding. Reasoning serves understanding by articulating relationships and making their justification explicit. However, the success of reasoning does not mean that all knowledge can be reduced to it. Nor does our ability to reason more extensively determine what is worth knowing or why we seek knowledge.")

#text("Mathematics is only one field of knowledge. Not everything can be understood mathematically, nor is mathematical achievement the ultimate purpose of intellectual life. Yet we increasingly measure intellectual life through publications, citations, awards, and other indicators of performance. While useful, these measures become problematic when they define the worth of the work itself. We begin to see mathematicians as collections of productive abilities, and mathematics as merely their output. From this perspective, anxiety about being replaced by AI is natural: a machine that performs these tasks better appears to threaten our worth. But the problem began before AI arrived. We had already come to understand ourselves in terms suited to machines. AI merely exposes the consequences of this view.")

#text("The response cannot simply be to seek refuge in distinctively human abilities such as creativity, intuition, or taste. If we value these abilities primarily because they give us an advantage over machines, we remain trapped in the same conception of intellectual worth. Why should the value of our pursuit depend on being better at it than someone or something else?")

#text("Mathematics offers an opportunity to reconsider this whole orientation. Its truths do not become more true through the distinction of the person who expresses them. In understanding a proof, we bring our thought into conformity with a relationship whose validity does not belong to us. The particular path by which we arrive may bear the marks of our individuality. What is understood is available beyond that individuality. We can allow this experience to loosen the belief that knowledge has its highest value as an achievement attributable to ourselves.")

#text("Egoless mathematics begins with taking that possibility seriously. Humility then reaches beyond modesty about our accomplishments or generosity in sharing credit. It concerns the place from which we pursue knowledge. We may seek truth to serve our existing purposes, or allow what we discover to change those purposes themselves. If we approach truth on the condition that its discovery must preserve our importance, we have already made it subordinate to ourselves. Accomplishing this reordering can be demanding, as intellectual sophistication can furnish elaborate defenses of the very attachments that prevent us from understanding. What matters is whether our abilities remain answerable to truth, including when it requires us to reconsider what we have been using those abilities for.")

#text("From this perspective, the possibility of mathematical discoveries through AI need not be a source of sadness about our purpose. A truth has become accessible; its worth is not diminished by the absence of our authorship. We need not immediately turn the event into a judgment about our relative importance. The search can continue without requiring every advance to vindicate the seeker. Indeed, the demand for such vindication has always burdened the pursuit, whether the competing claim came from another mathematician or from a machine.")

#text("The opportunity before us is therefore more substantial than a rearrangement of mathematical labor. It invites us to reconsider what gives an intellectual life its worth, and to let the pursuit of truth shape not only our work but also how we approach life.")

#text("This may sound like asking us all to become saints. Insofar as it asks us to grow in virtue and relinquish our attachment to our own importance, that impression is not far from the truth. But virtue is not something to cultivate for the admiration of others. It is necessary for genuine joy, even in our work. The satisfaction of solving a difficult problem or winning a prize can be fleeting when it rests on our standing relative to others. The joy of understanding is different. Something previously obscure becomes clear, and we recognize a beauty that does not diminish when someone else discovers it first. We can share this joy without depriving anyone of it. Growing in virtue allows us to experience it more fully, free from the need to establish our own importance.")

#text("This perspective may also help reconcile two positions within the mathematical community regarding AI. Some are comfortable with or even ")#link("https://www.youtube.com/watch?v=Gdc1yll04qI")[#text("enthusiastic about using AI")]#text(", but wish to develop appropriate processes and principles for its use. Others prefer ")#link("https://www.ahmath.org/")[#text("not to use AI at all")]#text(". Both positions have their merits. Egoless mathematics offers a way of reconciling them by introducing a higher consideration: both approaches can reflect the same underlying commitment to mathematical truth, regardless of how we choose to pursue it. Our aim here is not to settle particular questions of policy, but to develop a higher-level perspective that can guide our deliberations and ultimately our actions.")

#text("Seen in this light, we need not be afraid of what AI may achieve in mathematics. Mathematics was beautiful before any of us were born, and it will remain beautiful long after we are gone. Its worth does not depend on our accomplishments, nor does our joy in understanding it have to depend on being the ones who make the discoveries. Our purpose rests on our willingness to let truth govern what we seek and what we become.")

#text("We, the authors of this essay, are still far from having attained such egolessness. Nevertheless, we recognize it as an ideal toward which we wish to strive.")

#text("We conclude with a thought experiment. Ramanujan is reported to have said, “An equation has no meaning for me unless it expresses a thought of God” (")#link("https://www.oxfordreference.com/display/10.1093/acref/9780191826719.001.0001/q-oro-ed4-00008729")[#text("Robert Kanigel, The Man Who Knew Infinity, 1992")]#text("). If he were alive today, witnessing the advances of AI in mathematics, would he be perturbed by what they might mean for his purpose as a mathematician?")

#text("Statement of AI Usage: While the ideas expressed here are entirely our own, we gratefully acknowledge the assistance of GPT Astra 6.0 and GPT 6.1 Sol in drafting this post.")

#heading(level: 1)[#text("Comments (22)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f75391d90ab5162036bd88ea8e0e040f9460e357a84d19624a5c2f0aec3cf18c-3a434a9769d5c64eb490c2d41670b021c86b1e1016af418efb5448eb980aeeac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699078")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("This is all fine and well, but striving for egolessness – a more or less impossible pursuit for humans, ultimately – can serve the interests of those who are not even remotely egoless, but are in fact deploying these tools for the sake of an absurd vanity and short-term lucre.")

#text("ps.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f75391d90ab5162036bd88ea8e0e040f9460e357a84d19624a5c2f0aec3cf18c-3a434a9769d5c64eb490c2d41670b021c86b1e1016af418efb5448eb980aeeac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699079")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("PS. I skimmed this post first – and then saw it had been written by AI, from suggestions or notes by some humans. I won’t read it in detail; I have better things to do than to pore over a post written by an LLM.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699087")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Dear Harald, unfortunately I am forced to agree with you. The long-winded writing and silicon prose makes the post hard to read and obscures the ideas.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f75391d90ab5162036bd88ea8e0e040f9460e357a84d19624a5c2f0aec3cf18c-3a434a9769d5c64eb490c2d41670b021c86b1e1016af418efb5448eb980aeeac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699097")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Right, and it’s a pity, because the ideas look interesting. I don’t want to sound like a curmudgeon, but I’d rather read in detail even difficult or dry prose written by a human.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2ba4a625614de75eb55b63ea2061a4b6b135d3bb0f522cab4a21c4914681566-168ce2c53dee55c6a6244d56507b958dab67b9c10aa0547e26f3ea39647035e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sweetlydragon4b0402a3b2")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699125")[#strong[#text("sweetlydragon4b0402a3b2")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Even though I have a very different perspective, I find the article very interesting.")

#text("Let me explain my perspective. It is about the concept of egoless mathematics. To define truth independent of humans and the universe is what an egoless construction implies. The counterpoint to an egoless construction is to bring to light the fundamentally interdependent ontology of human-universe. In other words, the opposite perspective from egoless truth is to understand the being of human-universe. Like all being this is not fixed and constantly changing. But the interdependence is inextricable. Consequently (in my view) any attempt to understand the universe in its own right (egoless mathematics) is a flawed understanding.")

#text("With what do I wish to replace this flawed understanding. I guess it resides in understanding “understanding” itself. Understanding is a good concept to explicate the nature, i.e., the being of the human-universe. Humans need to be immersed in (stand under) both the universe and other humans. As already said, these are not separable processes. Discussion with other humans (i.e., proof) is about the universe (in this example the axiomatic mathematical construct). And the proofs are about conveying under-standing.")

#text("There is no egoless mathematics here. What about a profound AI proof of a previously non understood theorem. Has it passed into understanding because AI says so. And where is the conveyed understanding?")

#text("A last point: the discussion above is about mathematical truth. But I would like to extend this argument to truth in general. For example the physics of the universe. Clearly mathematical (axiomatic) truth is related but only tangentially because physics does not neccessarily respect axioms. But to investigate physical truth is also not egoless and requires a similar understanding.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699083")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("I hope you are able to redefine intelligence in such a way that keeps your ego fed")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699084")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("“Why should the value of our pursuit depend on being better at it than someone or something else?”")

#text("Who is going to pay us for these pursuits that we are no longer needed in?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699088")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("This essay rings hollow without any clear idea of how your assumed value translates to concrete policy ideas. Otherwise, the way “all that matters is truth” translates to policy must assumed to be to have the AI do it all. That means people are replaced by token budgets, AI reviewing AI-generated work, etc.")

#text("Who is left in this future? If a conjecture falls and nobody is around to see it, does it matter if it’s beautiful? Will you be content to hike on a trail littered with stumps?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe1b0b13cf3b9d2c60ea36009e396b5d17a84a6cab38dcee3d1ec9566e8ac212-a832155f4cf0526c7e2e7fce4bc126c73985cdf29f56e6f3d89ceb7afa18cf67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Goc")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699089")[#strong[#text("Daniel Goc")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Of course, there is also a matter of bread and butter. I’m happy with egolessness, but I still have to eat. So the threat is not merely to ego, but to one’s financial situation and value to society. For those that have tenures or are still struggling for stable academic positions, this threat must feel like staring deep in the eyes of one’s very reason for existence. It’s a matter of status.")

#text("Well, I agree with the post. And I don’t mind that it was written by AI, at least not enough to skip it. I’m outside of academia and so the bullet has not hit me directly.")

#text("On a side note, consider the following thought experiment: if stable academic career was really out of question, and if universal income was a thing, but allowed only for existence in cramped shared houses in borderline poverty, how many of you would still choose math? I feel like I would.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699090")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Speaking about egoless mathematics, here is Openai math manuscript authors ranked by citations:")#linebreak()#link("https://www.facebook.com/marius.comper/posts/every-human-author-cited-across-the-openaimath-manuscript-collection-ranked-by-h/10165026905859621/")[#text("https://www.facebook.com/marius.comper/posts/every-human-author-cited-across-the-openaimath-manuscript-collection-ranked-by-h/10165026905859621/")]

#text("1. Osamu Fujino — 120 citations (37 manuscripts, 12 families)")

#text("2. Elliott H. Lieb — 111 citations (57 manuscripts, 29 families)")

#text("3. Jean-Pierre Demailly — 107 citations (46 manuscripts, 23 families)")

#text("4. Terence Tao — 103 citations (46 manuscripts, 36 families)")

#text("5. Thomas Peternell — 102 citations (32 manuscripts, 10 families)")

#text("6. James S. Milne — 92 citations (53 manuscripts, 35 families)")

#text("7. Hugo Duminil-Copin — 87 citations (35 manuscripts, 10 families)")

#text("8. János Kollár — 85 citations (46 manuscripts, 21 families)")

#text("9. Christopher D. Hacon — 80 citations (36 manuscripts, 11 families)")

#text("10. Scott Sheffield — 80 citations (21 manuscripts, 9 families)")

#text("11. Frédéric Bruno Campana — 78 citations (33 manuscripts, 13 families)")

#text("12. Oded Schramm — 78 citations (39 manuscripts, 17 families)")

#text("13. Paul Erdős — 78 citations (52 manuscripts, 40 families)")

#text("14. Pierre Deligne — 78 citations (49 manuscripts, 27 families)")

#text("15. Caucher Birkar — 73 citations (29 manuscripts, 8 families)")

#text("16. Mihai Păun — 69 citations (30 manuscripts, 9 families)")

#text("17. Stanislav K. Smirnov — 66 citations (29 manuscripts, 6 families)")

#text("18. Jean-Pierre Serre — 61 citations (44 manuscripts, 31 families)")

#text("19. Jean Bourgain — 59 citations (36 manuscripts, 22 families)")

#text("20. Ben Morris — 58 citations (14 manuscripts, 2 families)")

#text("21. Ewain Gwynne — 58 citations (9 manuscripts, 2 families)")

#text("22. Shing-Tung Yau — 58 citations (37 manuscripts, 22 families)")

#text("23. Dennis Gaitsgory — 57 citations (8 manuscripts, 2 families)")

#text("24. Jason Miller — 54 citations (10 manuscripts, 3 families)")

#text("25. Barry Simon — 51 citations (35 manuscripts, 18 families)")

#text("26. Michael Aizenman — 51 citations (37 manuscripts, 20 families)")

#text("27. James McKernan — 49 citations (26 manuscripts, 9 families)")

#text("28. Subhash A. Khot — 46 citations (13 manuscripts, 6 families)")

#text("29. Dmitry Panchenko — 44 citations (11 manuscripts, 6 families)")

#text("30. Hong Wang — 43 citations (8 manuscripts, 6 families)")

#text("31. Yuval Peres — 42 citations (24 manuscripts, 14 families)")

#text("32. Peter Scholze — 40 citations (17 manuscripts, 11 families)")

#text("33. Shigefumi Mori — 39 citations (30 manuscripts, 14 families)")

#text("34. Allen Hatcher — 38 citations (35 manuscripts, 31 families)")

#text("35. Andreas Höring — 38 citations (20 manuscripts, 10 families)")

#text("36. Ioan Manolescu — 38 citations (21 manuscripts, 6 families)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699103")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#link("https://citedbyagi.com/")[#text("https://citedbyagi.com/")]

#text("Humanity’s H-index is 37. The 37th-most-cited human by AI has 38 citations, while the 38th most-cited-human has 37 citations.")

#text("Larry Guth is holding the boundary.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699104")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Our esteemed host covers the most families (36), followed by Milne (35).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699105")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("I missed Erdős: 40 families. Of course.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699112")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Better link with lists: ")#link("https://citedbyagi.com/")[#text("https://citedbyagi.com/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699092")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("This post strongly resonates with me. I’m just not sure how we can reconcile it with the competitive reality of academia. Ultimately, it’s a question of limited resources (a lack of positions, infrastructure, research funding, etc.), and the situation is likely to get worse rather than better.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699096")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Unbelievably cringe essay. Attaching our practice to an ill-defined philosophy of mathematics as a response to the AI crisis is already inappropriate, but to conclude the essay without proposing anything of value or promising any kind of action is even worse.")

#text("Maybe your ideas (if you had any at all) could have been illustrated better if you had actually dedicated any time to writing this instead of leaving ChatGPT to slop it out. Just say that you’re fine with AI taking mathematician’s jobs.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699124")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("This. The essay is vapid in content and could have seen shortened to 1 paragraphs, but we are instead served to a bunch of slop that elaborates on trivialities without addressing any of the core problems…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699102")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("While I understand the concerns of the previous commenters about who really benefits from this new world (the AI companies and the hardware companies that support them)… I also can safely say this essay hits home, and hard.")

#text("I have always been the smartest kid in class, and the smartest kid in school. But I came to define myself by that — and if someone else was smart, too, I felt threatened.")

#text("But as Terry says,")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Why should the value of our pursuit depend on being better at it than someone or something else?")
]

#text("What’s most profound is his idea that to be *truly* happy, our quests for knowledge, or money, or success, simply cannot be our #1 pride and goal.")

#text("At work, I have contributions to give, and I battle between wanting to do them to prove how capable I am, and to serve my coworkers in making it a better place for them. It’s an interesting paradox: you can’t really accomplish anything without being ambitious and cocky (I can do this), but the joy is lost when the achievement becomes your #1 goal.")

#text("Maybe winning isn’t everything, or the only thing, Vince Lombardi.")

#text("It’s like in the film Walter Mitty, when the character played by Sean Penn declines to take a photo of a faraway snow leopard (or some other big cat) — and instead simply relishes the moment.")

#text("And I may be completely off base, because I am not a mathematician whose livelihood is on the rocks.")

#text("But there’s something profound to be found here.")

#text("— Jake Toronto")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699109")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("The reason you get a paycheck to do math is because someone thinks you are “better at it than someone or something else.”")

#text("What a wonderful, egoless world you will have created when there are no math departments left.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cb9da7b47cbc1465e0b09da0544196e13d96f0c56575d23836e70f75d7c7ea9-07fd7823e24366159ef7adf6492058c9a574d4b59dd935489112043bd5dc8fff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of darkomulej")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699110")[#strong[#text("darkomulej")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("A couple of points.")

#text("First, the whole argument assumes a strict Platonic view as an obvious fact. Hitting an unexpected counterexample doesn’t prove that theorems are ancient fossils sitting in some cosmic realm waiting for us. It just means formal axiomatic systems have rigid logical rules. If you are a formalist, an AI paper isn’t some “revealed thought of God” at all – it’s just an algorithm grinding through human-made syntax and axioms. Taking Platonism (implicitely) for granted is problematic (though I like it!).")

#text("Second, using this Platonic stance to demand “egolessness” feels like a convenient distraction. It turns a massive disruption of mathematical profession into a personal moral lecture.")

#text("Telling researchers who watch their fields get overturned that their panic is just “vanity” or “selfish ego” is just a way to quiet people down. It tells everyone to seek inner peace instead of looking at reality. Mathematics was always the cheapest science: you needed a chalkboard, pencil, paper, and time. If pushing the frontier now requires massive compute runs on private corporate server clusters, preaching saintly detachment just ignores the real problem. It ignores who controls the research agenda, and worse, it ignores how young students are supposed to build any real mathematical intuition if the hard climbing is taken away from them.")#linebreak()#text("(Parallels to McMindfulness by Ronald Purser)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699114")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Any serious discussion on the impact of AI in math, should center on the crucial matter of employment expectations for future (and current) mathematicians. That is, if we assume that the field still will still be around in a few years time. Ego? Seriously, who cares?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a8d89df8cf1df48144e54776c63ff3993608a404efb7837b3e488f3fb2402b6-bcb62cccec97c4075771088d371843ac8c8cf89bcf104a0947f9358a2a4cbfea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tymon")]], [#link("https://terrytao.wordpress.com/2026/11/02/egoless-mathematics-in-the-ai-era/comment-page-1/#comment-699126")[#strong[#text("Tymon")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#strong[#text("Krishna in the Bhagavad Gita")]#text(" “Your right is to the work alone, never to its fruits.”")

#text("All it took is thousands of years of machine improvement for matematitians to arrive at this truth.")
]
