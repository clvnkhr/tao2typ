// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/30/__trashed/
// Converted to Typst by tao2typ: "2026-10-31T12:52:52.476854+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Report of the Summit on Math Research in the Age of AI", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Report of the Summit on Math Research in the Age of AI")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/30/__trashed/")[#text("https://terrytao.wordpress.com/2026/10/30/__trashed/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-31 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by the organizers of the ")#link("https://cmsa.fas.harvard.edu/aimathresearch_summit/")[#text("Summit on Math Research in the Age of AI")]#text(": Dan Freed (Harvard), Larry Guth (MIT), Bryna Kra (Northwestern), Emily Riehl (Johns Hopkins), and Mohammed Abouzaid (Stanford). This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("Last week we organized an intensive two-day summit ")#emph[#text("Math Research in the Age of AI")]#text(". It was held at the Harvard Center for Mathematical Sciences and Applications (")#link("https://cmsa.fas.harvard.edu")[#text("CMSA")]#text("). Thirty-two mathematicians from academia, government, and industry came together to help navigate this period of rapid change in mathematics and, most importantly, to offer ideas for building the future. There were five working groups organized around the following themes:")

#list(
[#text("Evaluation, production, and dissemination of research")],
[#text("Coordinated actions for the AI era")],
[#text("Open-source tools")],
[#text("Formalization in mathematics")],
[#text("Collaboration between academia and AI labs")]
)

#text("Our ")#link("https://cmsa.fas.harvard.edu/media/2026/10/Summit-on-Math-Research-in-the-Age-of-AI.pdf")[#text("report")]#text(" can be found on the ")#link("https://cmsa.fas.harvard.edu/aimathresearch_summit/")[#text("summit website")]#text(". There you’ll also find a ")#link("https://docs.google.com/forms/d/e/1FAIpQLSc6_RDRhjfDmBs1rjzzH5mFNjkGslkzXenaY7pjbQBU6NrPiw/viewform")[#text("link")]#text(" to provide feedback, and we also encourage open discussion in the comments section of this blog.")
