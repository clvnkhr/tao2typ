// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/07/11/on-the-universality-of-potential-well-dynamics/
// Converted to Typst by tao2typ: "2026-10-14T10:41:38.594405+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On the universality of potential well dynamics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On the universality of potential well dynamics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 July 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/07/11/on-the-universality-of-potential-well-dynamics/")[#text("https://terrytao.wordpress.com/2017/07/11/on-the-universality-of-potential-well-dynamics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("I’ve just uploaded to the arXiv my paper “")#link("https://arxiv.org/abs/1707.02389")[#text("On the universality of potential well dynamics")]#text("“, submitted to ")#link("http://intlpress.com/site/pub/pages/journals/items/dpde")[#text("Dynamics of PDE")]#text(". This is a spinoff from ")#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/")[#text("my previous paper on blowup of nonlinear wave equations")]#text(", inspired by some conversations with ")#link("http://www.kias.re.kr/sub02/sub02_01_01_01_01.jsp?empid=NTAzMzc=")[#text("Sungjin Oh")]#text(". Here we focus mainly on the zero-dimensional case of such equations, namely the potential well equation ")#metadata(none) <tao-cdee64b7f3cee407e52c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\partial_{tt} u = - (\\nabla F)(u)")]]

#text("for a particle ")#mi("{u: {\\bf R} \\rightarrow {\\bf R}^m}")#text(" trapped in a potential well with potential ")#mi("{F: {\\bf R}^m \\rightarrow {\\bf R}}")#text(", with ")#mi("{F(z) \\rightarrow +\\infty}")#text(" as ")#mi("{z \\rightarrow \\infty}")#text(". This ODE always admits global solutions from arbitrary initial positions ")#mi("{u(0)}")#text(" and initial velocities ")#mi("{\\partial_t u(0)}")#text(", thanks to conservation of the Hamiltonian ")#tao-math("{\\frac{1}{2} \\left|\\partial_t u\\right|^2 + F(u)}", block: false)#text(". As this Hamiltonian is coercive (in that its level sets are compact), solutions to this equation are always ")#link("https://en.wikipedia.org/wiki/Almost_periodic_function")[#text("almost periodic")]#text(". On the other hand, as can already be seen using the harmonic oscillator ")#mi("{\\partial_{tt} u = - k^2 u}")#text(" (and direct sums of this system), this equation can generate periodic solutions, as well as ")#link("https://en.wikipedia.org/wiki/Quasiperiodic_motion")[#text("quasiperiodic solutions")]#text(".")

#text("All quasiperiodic motions are almost periodic. However, there are many examples of dynamical systems that admit solutions that are almost periodic but not quasiperiodic. So one can pose the question: are the dynamics of potential wells ")#emph[#text("universal")]#text(" in the sense that they can capture all almost periodic solutions?")

#text("A precise question can be phrased as follows. Let ")#mi("{M}")#text(" be a compact manifold, and let ")#mi("{X}")#text(" be a smooth vector field on ")#mi("{M}")#text("; to avoid degeneracies, let us take ")#mi("{X}")#text(" to be ")#emph[#text("non-singular")]#text(" in the sense that it is everywhere non-vanishing. Then the trajectories of the first-order ODE ")#metadata(none) <tao-07302499974f21b9e32d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\partial_t u = X(u)")]]

#text("for ")#mi("{u: {\\bf R} \\rightarrow M}")#text(" are always global and almost periodic. Can we then find a (coercive) potential ")#mi("{F: {\\bf R}^m \\rightarrow {\\bf R}}")#text(" for some ")#mi("{m}")#text(", as well as a smooth embedding ")#mi("{\\phi: M \\rightarrow {\\bf R}^m}")#text(", such that every solution ")#mi("{u}")#text(" to ")#link(<tao-07302499974f21b9e32d>)[#text("(2)")]#text(" pushes forward under ")#mi("{\\phi}")#text(" to a solution to ")#link(<tao-cdee64b7f3cee407e52c>)[#text("(1)")]#text("? (Actually, for technical reasons it is preferable to map into the phase space ")#mi("{{\\bf R}^m \\times {\\bf R}^m}")#text(", rather than position space ")#mi("{{\\bf R}^m}")#text(", but let us ignore this detail for this discussion.)")

#text("It turns out that the answer is no; there is a very specific obstruction. Given a pair ")#mi("{(M,X)}")#text(" as above, define a ")#emph[#text("strongly adapted ")#mi("{1}")#text("-form")]#text(" to be a ")#mi("{1}")#text("-form ")#mi("{\\phi}")#text(" on ")#mi("{M}")#text(" such that ")#mi("{\\phi(X)}")#text(" is pointwise positive, and the ")#link("https://en.wikipedia.org/wiki/Lie_derivative")[#text("Lie derivative")]#text(" ")#mi("{{\\mathcal L}_X \\phi}")#text(" is an exact ")#mi("{1}")#text("-form. We then have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" A smooth compact non-singular dynamics ")#mi("{(M,X)}")#text(" can be embedded smoothly in a potential well system if and only if it admits a strongly adapted ")#mi("{1}")#text("-form.")
]

#text("For the “only if” direction, the key point is that potential wells (viewed as a Hamiltonian flow on the phase space ")#mi("{{\\bf R}^m \\times {\\bf R}^m}")#text(") admit a strongly adapted ")#mi("{1}")#text("-form, namely the ")#link("https://en.wikipedia.org/wiki/Tautological_one-form")[#text("canonical ")#mi("{1}")#text("-form")]#text(" ")#mi("{p dq}")#text(", whose Lie derivative is the derivative ")#mi("{dL}")#text(" of the ")#link("https://en.wikipedia.org/wiki/Lagrangian_(field_theory)")[#text("Lagrangian")]#text(" ")#tao-math("{L := \\frac{1}{2} \\left|\\partial_t u\\right|^2 - F(u)}", block: false)#text(" and is thus exact. The converse “if” direction is mainly a consequence of the ")#link("https://en.wikipedia.org/wiki/Nash_embedding_theorem")[#text("Nash embedding theorem")]#text(", and follows the ")#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/")[#text("arguments used in my previous paper")]#text(".")

#text("Interestingly, the same obstruction also works for potential wells in a more general Riemannian manifold than ")#mi("{{\\bf R}^m}")#text(", or for nonlinear wave equations with a potential; combining the two, the obstruction is also present for wave maps with a potential.")

#text("It is then natural to ask whether this obstruction is non-trivial, in the sense that there are at least some examples of dynamics ")#mi("{(M,X)}")#text(" that do not support strongly adapted ")#mi("{1}")#text("-forms (and hence cannot be modeled smoothly by the dynamics of a potential well, nonlinear wave equation, or wave maps). I posed ")#link("https://mathoverflow.net/questions/273635/finding-a-1-form-adapted-to-a-smooth-flow")[#text("this question on MathOverflow")]#text(", and Robert Bryant provided a very nice construction, showing that the vector field ")#mi("{(\\sin(2\\pi x), \\cos(2\\pi x))}")#text(" on the ")#mi("{2}")#text("-torus ")#mi("{({\\bf R}/{\\bf Z})^2}")#text(" had no strongly adapted ")#mi("{1}")#text("-forms, and hence the dynamics of this vector field cannot be smoothly reproduced by a potential well, nonlinear wave equation, or wave map:")

#image("../assets/0f4317c09df438d7a2c313325b8bf4acd68188d530984edcd3e036a43ffdc235-b8d888563bc0460813c66b343c0a8599ac4dd08387af9a663100736a87b15e1d.png", width: 90%)

#text("On the other hand, the ")#link("https://en.wikipedia.org/wiki/Suspension_(dynamical_systems)")[#text("suspension")]#text(" of any diffeomorphism does support a strongly adapted ")#mi("{1}")#text("-form (the derivative ")#mi("{dt}")#text(" of the time coordinate), and using this and the previous theorem I was able to embed a ")#link("https://en.wikipedia.org/wiki/Universal_Turing_machine")[#text("universal Turing machine")]#text(" into a potential well. In particular, there are flows for an explicitly describable potential well whose trajectories have behavior that is undecidable using the usual ZFC axioms of set theory! So potential well dynamics are “effectively” universal, despite the presence of the aforementioned obstruction.")

#text("In ")#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/")[#text("my previous work on blowup for Navier-Stokes like equations")]#text(", I speculated that if one could somehow replicate a universal Turing machine within the Euler equations, one could use this machine to create a “von Neumann machine” that replicated smaller versions of itself, which on iteration would lead to a finite time blowup. Now that such a mechanism is present in nonlinear wave equations, it is tempting to try to make this scheme work in that setting. Of course, in ")#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/")[#text("my previous paper")]#text(" I had already demonstrated finite time blowup, at least in a three-dimensional setting, but that was a relatively simple discretely self-similar blowup in which no computation occurred. This more complicated blowup scheme would be significantly more effort to set up, but would be proof-of-concept that the same scheme would in principle be possible for the Navier-Stokes equations, assuming somehow that one can embed a universal Turing machine into the Euler equations. (But I’m still hopelessly stuck on how to accomplish this latter task…)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98d192abd70f5311db8ec60dec56a48604f76cb7ff6a4cf4f5df43803680c3ff-cb5dcadf7bcf8b56cb8857c450f2fddd18645e59e478b53d2f6ab76b378a6646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mango")]], [#link("https://terrytao.wordpress.com/2017/07/11/on-the-universality-of-potential-well-dynamics/#comment-483671")[#strong[#text("John Mango")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2017")])]

#text("I don’t know a terrible lot about ODE except for very sloppy statements about the existence of solutions. This is not the first time you’ve connected Turing Machines and ODE. I guess it just says flows on surfaces (could be) fairly complex. I’m always intrigued.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6525d7cd9db10f0f8b9a18fa0e62f21ac78916ee3eed4debea5956daeaf030-72219f07d23f0f1bc893af77a76e1cfd99cff0d2c3626a52796f2e15ac6c7e88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andreas")]], [#link("https://terrytao.wordpress.com/2017/07/11/on-the-universality-of-potential-well-dynamics/#comment-483682")[#strong[#text("Andreas")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2017")])]

#text("Thank you for this exciting update! I was wondering for some time what the consequences are when you could prove the opposite: That one cannot encode a Turing Machine into the NS equation. Can one make some restrictive Statements on the finite-time Blowup? In the best case, could one argue that finite-time blowup doesnt exist? Are there some examples of the negative turing machine result and blowup in other PDEs? Thank you for exampling your research in these blog posts to people from outside the field!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0c790d5c7e3eb467c51194becdcb9ff5cd8de57e20dee1f86c6c863d7fdb95b-c935d84b5b9a7dfd1546f5f67eb569e3b918b676754b2ec317ec4fc9fc5bb4f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SERGIO MACHADO TORRES")]], [#link("https://terrytao.wordpress.com/2017/07/11/on-the-universality-of-potential-well-dynamics/#comment-483699")[#strong[#text("SERGIO MACHADO TORRES")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2017")])]

#text("Dear Mr Tao,")

#text("I’m a Brazilian journalist and I am writing for the IMO Journal (International Mathematical Olympiad), to be issued for the competition, which will take place next week in Rio de Janero, Brazil. I work for Impa (Institute of Aplied and Pure Math).")

#text("Since you are an icon for many of these young men and women, I would like to ask you a few questions for an interview to be printed on the IMO journal (one issue only).")#linebreak()#text(" We and the IMO contestants would really appreciate if you could answer the questions.")#linebreak()#text(" Best regards, Sergio Torres")

#text("1. What advice would you give to young mathematicians?")#linebreak()#text(" 2. What is IMO’s importance in revealing new talents in Math?")

#text("3. In your opinion what would Brazil need to do to become a powerhouse in mathematics?")

#text("4. You are known for being an early winner of the IMO gold medal and also for excelling in various areas of Math. Is Math only for people like you?")

#text("5. You are also famous for your enormous capability of working, for writing many articles and still managing a blog, in which you actually answer people who write you. How do you manage to do all that and to teach in UCLA at the same time?")#linebreak()#text(" 6. Like you, 13 other mathematicians who have earned the Fields Medal also started off winning IMO gold medals. So there is likely potential for another Fields Medalist among these 650 contestants. What is your message for them?")#linebreak()#text(" 7. You had a remarkable initiative concerning the Twin Prime Conjecture, stimulating what has been called Poli Math, in which thousands are involved to try to solve a problem. In a world of nets, where everyone is connected, is that collaborative effort the future of Math?")

#text("Thank you very much.")

#text("Best regards")

#text("Sergio Torres")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59e7cc015abe36655329b57fc473d54b0124e40428d9299fab3212350430dace-d68dc7a9cd8bb487b1e36264fcdb4a497a80be48ec13c7aec300b89cdfa2d222.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2017/07/11/on-the-universality-of-potential-well-dynamics/#comment-484228")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2017")])]

#text("Just out of curiosity: What happens if you take one of your universal potentials and study Schroedinger’s equation ")#mi("i \\hbar \\tfrac{\\partial \\Phi}{\\partial t} = V \\Phi")#text("? Does the computation “diffuse away”, or is it still universal in some sense?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/07/11/on-the-universality-of-potential-well-dynamics/#comment-484237")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2017")])]

#text("Actually, I had just asked one of my graduate students to look into this question. The RHS will have to be a bit different – something of the form $\\nabla_{{\\bf C}^m} V(\\Phi)$ where ")#mi("\\Phi")#text(" takes values in ")#mi("{\\bf C}^m")#text(", and ")#mi("V: {\\bf C}^m \\to {\\bf R}")#text(" is a rotation-invariant potential – but in analogy with my finite time blowup results for NLW and NLS, I would expect that there should be a choice of potential which can perform universal computation in this setting also.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/07/11/on-the-universality-of-potential-well-dynamics/#comment-484292")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2017")])]

#text("Ah, I realise I misinterpreted your question (thought you were asking about a variant of the problem regarding NLS). If you quantise the potential well equation as you say then, as per the usual correspondence principle, one would obtain dynamics that would approximate the classical dynamics for bounded times ")#mi("t = O(1)")#text(" for initial data that is suitably localised in position and momentum, but would eventually disperse away from that dynamics due to the uncertainty principle, quantum tunneling, etc.. Indeed, the only finite-dimensional dynamics that the linear Schrodinger equation can model are quasiperiodic flows (as can be seen by using the spectral theorem to the Hamiltonian operator); the RAGE theorem tells us that everything except for bound states will radiate away, and each bound state oscillates periodically.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On the universality of the incompressible Euler equation on compact manifolds | What's new")]], [#link("https://terrytao.wordpress.com/2017/07/11/on-the-universality-of-potential-well-dynamics/#comment-484241")[#strong[#text("On the universality of the incompressible Euler equation on compact manifolds | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2017")])]

#text("[…] manifolds“, submitted to Discrete and Continuous Dynamical Systems. This is a variant of my recent paper on the universality of potential well dynamics, but instead of trying to embed dynamical systems into a potential well , here we try to embed […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e80c2bfa298d4886a507d9a4a825c9b92eda39a3f6beb10f7bb921d5adde1ae-b1f05f42ac1417ca9a591ad51a17dd49c39b80a1e267d76997fd2a9e69319ce2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Viktor Ivanov")]], [#link("https://terrytao.wordpress.com/2017/07/11/on-the-universality-of-potential-well-dynamics/#comment-484960")[#strong[#text("Viktor Ivanov")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2017")])]

#text("Dear Professor Terence Tao,")

#text("Why you insist that NS problem has blowup time? Ir can delay a proof of the opposite result, if it is really true.")

#text("In my opinion, there is no blowup time, since the respective Volterra-type equations has integrals vanishing over vicinity of possible singularities.")

#text("Sincerely,")

#text("Dr. Viktor Ivanov")
]
