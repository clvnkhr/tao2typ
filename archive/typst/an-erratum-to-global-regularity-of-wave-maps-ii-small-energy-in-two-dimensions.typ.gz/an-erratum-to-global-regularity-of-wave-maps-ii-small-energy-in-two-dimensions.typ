// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/08/26/an-erratum-to-global-regularity-of-wave-maps-ii-small-energy-in-two-dimensions/
// Converted to Typst by tao2typ: "2026-10-14T10:35:56.173401+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An erratum to “Global regularity of wave maps. II. Small energy in two dimensions”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An erratum to “Global regularity of wave maps. II. Small energy in two dimensions”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 August 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/08/26/an-erratum-to-global-regularity-of-wave-maps-ii-small-energy-in-two-dimensions/")[#text("https://terrytao.wordpress.com/2016/08/26/an-erratum-to-global-regularity-of-wave-maps-ii-small-energy-in-two-dimensions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Fifteen years ago, I wrote a paper entitled ")#link("http://www.ams.org/mathscinet-getitem?mr=1869874")[#text("Global regularity of wave maps. II. Small energy in two dimensions")]#text(", in which I established global regularity of wave maps from two spatial dimensions to the unit sphere, assuming that the initial data had small energy. Recently, ")#link("http://math.uchicago.edu/~jiahao/")[#text("Hao Jia")]#text(" (personal communication) discovered a small gap in the argument that requires a slightly non-trivial fix. The issue does not really affect the subsequent literature, because the main result has since been reproven and extended by methods that avoid the gap (see in particular ")#link("http://www.ams.org/mathscinet-getitem?mr=2130618")[#text("this subsequent paper of Tataru")]#text("), but I have decided to describe the gap and its fix on this blog.")

#text("I will assume familiarity with the notation of my paper. In Section 10, some complicated spaces ")#mi("{S[k] = S[k]({\\bf R}^{1+n})}")#text(" are constructed for each frequency scale ")#mi("{k}")#text(", and then a further space ")#mi("{S(c) = S(c)({\\bf R}^{1+n})}")#text(" is constructed for a given frequency envelope ")#mi("{c}")#text(" by the formula ")#metadata(none) <tao-32066f6309bdf990b753>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| \\phi \\right\\|_{S(c)({\\bf R}^{1+n})} := \\left\\|\\phi \\right\\|_{L^\\infty_t L^\\infty_x({\\bf R}^{1+n})} + \\sup_k c_k^{-1} \\left\\| \\phi_k \\right\\|_{S[k]({\\bf R}^{1+n})}", block: true)]]

#text("where ")#mi("{\\phi_k := P_k \\phi}")#text(" is the Littlewood-Paley projection of ")#mi("{\\phi}")#text(" to frequency magnitudes ")#mi("{\\sim 2^k}")#text(". Then, given a spacetime slab ")#mi("{[-T,T] \\times {\\bf R}^n}")#text(", we define the restrictions")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\phi \\right\\|_{S(c)([-T,T] \\times {\\bf R}^n)} := \\inf \\{ \\left\\| \\tilde \\phi \\right\\|_{S(c)({\\bf R}^{1+n})}: \\tilde \\phi \\downharpoonright_{[-T,T] \\times {\\bf R}^n} = \\phi \\}", block: true)]]

#text("where the infimum is taken over all extensions ")#mi("{\\tilde \\phi}")#text(" of ")#mi("{\\phi}")#text(" to the Minkowski spacetime ")#mi("{{\\bf R}^{1+n}}")#text("; similarly one defines")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\phi_k \\right\\|_{S_k([-T,T] \\times {\\bf R}^n)} := \\inf \\{ \\left\\| \\tilde \\phi_k \\right\\|_{S_k({\\bf R}^{1+n})}: \\tilde \\phi_k \\downharpoonright_{[-T,T] \\times {\\bf R}^n} = \\phi_k \\}.", block: true)]]

#text("The gap in the paper is as follows: it was implicitly assumed that one could restrict ")#link(<tao-32066f6309bdf990b753>)[#text("(1)")]#text(" to the slab ")#mi("{[-T,T] \\times {\\bf R}^n}")#text(" to obtain the equality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\phi \\right\\|_{S(c)([-T,T] \\times {\\bf R}^n)} = \\left\\|\\phi \\right\\|_{L^\\infty_t L^\\infty_x([-T,T] \\times {\\bf R}^n)} + \\sup_k c_k^{-1} \\left\\| \\phi_k \\right\\|_{S[k]([-T,T] \\times {\\bf R}^n)}.", block: true)]]

#text("(This equality is implicitly used to establish the bound (36) in the paper.) Unfortunately, ")#link(<tao-32066f6309bdf990b753>)[#text("(1)")]#text(" only gives the lower bound, not the upper bound, and it is the upper bound which is needed here. The problem is that the extensions ")#mi("{\\tilde \\phi_k}")#text(" of ")#mi("{\\phi_k}")#text(" that are optimal for computing ")#tao-math("{\\left\\| \\phi_k \\right\\|_{S[k]([-T,T] \\times {\\bf R}^n)}}", block: false)#text(" are not necessarily the Littlewood-Paley projections of the extensions ")#mi("{\\tilde \\phi}")#text(" of ")#mi("{\\phi}")#text(" that are optimal for computing ")#tao-math("{\\left\\| \\phi \\right\\|_{S(c)([-T,T] \\times {\\bf R}^n)}}", block: false)#text(".")

#text("To remedy the problem, one has to prove an upper bound of the form")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\phi \\right\\|_{S(c)([-T,T] \\times {\\bf R}^n)} \\lesssim \\left\\|\\phi \\right\\|_{L^\\infty_t L^\\infty_x([-T,T] \\times {\\bf R}^n)} + \\sup_k c_k^{-1} \\left\\| \\phi_k \\right\\|_{S[k]([-T,T] \\times {\\bf R}^n)}", block: true)]]

#text("for all Schwartz ")#mi("{\\phi}")#text(" (actually we need affinely Schwartz ")#mi("{\\phi}")#text(", but one can easily normalise to the Schwartz case). Without loss of generality we may normalise the RHS to be ")#mi("{1}")#text(". Thus ")#metadata(none) <tao-d0baaad1dce96b65f772>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\|\\phi \\right\\|_{L^\\infty_t L^\\infty_x([-T,T] \\times {\\bf R}^n)} \\leq 1", block: true)]]

#text("and ")#metadata(none) <tao-4cc4175c1e7008e52445>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\|P_k \\phi \\right\\|_{S[k]([-T,T] \\times {\\bf R}^n)} \\leq c_k", block: true)]]

#text("for each ")#mi("{k}")#text(", and one has to find a single extension ")#mi("{\\tilde \\phi}")#text(" of ")#mi("{\\phi}")#text(" such that ")#metadata(none) <tao-37dc639ec61ff675e9ec>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\|\\tilde \\phi \\right\\|_{L^\\infty_t L^\\infty_x({\\bf R}^{1+n})} \\lesssim 1", block: true)]]

#text("and ")#metadata(none) <tao-2dd2466f87217b6033f8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\|P_k \\tilde \\phi \\right\\|_{S[k]({\\bf R}^{1+n})} \\lesssim c_k", block: true)]]

#text("for each ")#mi("{k}")#text(". Achieving a ")#mi("{\\tilde \\phi}")#text(" that obeys ")#link(<tao-37dc639ec61ff675e9ec>)[#text("(4)")]#text(" is trivial (just extend ")#mi("{\\phi}")#text(" by zero), but such extensions do not necessarily obey ")#link(<tao-2dd2466f87217b6033f8>)[#text("(5)")]#text(". On the other hand, from ")#link(<tao-4cc4175c1e7008e52445>)[#text("(3)")]#text(" we can find extensions ")#mi("{\\tilde \\phi_k}")#text(" of ")#mi("{P_k \\phi}")#text(" such that ")#metadata(none) <tao-cdc3271ebc14b28aceec>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left\\|\\tilde \\phi_k \\right\\|_{S[k]({\\bf R}^{1+n})} \\lesssim c_k;", block: true)]]

#text("the extension ")#mi("{\\tilde \\phi := \\sum_k \\tilde \\phi_k}")#text(" will then obey ")#link(<tao-2dd2466f87217b6033f8>)[#text("(5)")]#text(" (here we use Lemma 9 from my paper), but unfortunately is not guaranteed to obey ")#link(<tao-37dc639ec61ff675e9ec>)[#text("(4)")]#text(" (the ")#mi("{S[k]}")#text(" norm does control the ")#mi("{L^\\infty_t L^\\infty_x}")#text(" norm, but a key point about frequency envelopes for the small energy regularity problem is that the coefficients ")#mi("{c_k}")#text(", while bounded, are not necessarily summable).")

#text("This can be fixed as follows. For each ")#mi("{k}")#text(" we introduce a time cutoff ")#mi("{\\eta_k}")#text(" supported on ")#mi("{[-T-2^{-k}, T+2^{-k}]}")#text(" that equals ")#mi("{1}")#text(" on ")#mi("{[-T-2^{-k-1},T+2^{-k+1}]}")#text(" and obeys the usual derivative estimates in between (the ")#mi("{j^{th}}")#text(" time derivative of size ")#mi("{O_j(2^{jk})}")#text(" for each ")#mi("{j}")#text("). Later we will prove the truncation estimate ")#metadata(none) <tao-e41e7dcbc37fd2f16ee9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left\\| \\eta_k \\tilde \\phi_k \\right\\|_{S[k]({\\bf R}^{1+n})} \\lesssim \\left\\| \\tilde \\phi_k \\right\\|_{S[k]({\\bf R}^{1+n})}.", block: true)]]

#text("Assuming this estimate, then if we set ")#mi("{\\tilde \\phi := \\sum_k \\eta_k \\tilde \\phi_k}")#text(", then using Lemma 9 in my paper and ")#link(<tao-cdc3271ebc14b28aceec>)[#text("(6)")]#text(", ")#link(<tao-e41e7dcbc37fd2f16ee9>)[#text("(7)")]#text(" (and the local stability of frequency envelopes) we have the required property ")#link(<tao-2dd2466f87217b6033f8>)[#text("(5)")]#text(". (There is a technical issue arising from the fact that ")#mi("{\\tilde \\phi}")#text(" is not necessarily Schwartz due to slow decay at temporal infinity, but by considering partial sums in the ")#mi("{k}")#text(" summation and taking limits we can check that ")#mi("{\\tilde \\phi}")#text(" is the strong limit of Schwartz functions, which suffices here; we omit the details for sake of exposition.) So the only issue is to establish ")#link(<tao-37dc639ec61ff675e9ec>)[#text("(4)")]#text(", that is to say that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_k \\eta_k(t) \\tilde \\phi_k(t) \\right\\|_{L^\\infty_x({\\bf R}^n)} \\lesssim 1", block: true)]]

#text("for all ")#mi("{t \\in {\\bf R}}")#text(".")

#text("For ")#mi("{t \\in [-T,T]}")#text(" this is immediate from ")#link(<tao-d0baaad1dce96b65f772>)[#text("(2)")]#text(". Now suppose that ")#mi("{t \\in [T+2^{k_0-1}, T+2^{k_0}]}")#text(" for some integer ")#mi("{k_0}")#text(" (the case when ")#mi("{t \\in [-T-2^{k_0}, -T-2^{k_0-1}]}")#text(" is treated similarly). Then we can split")

#align(center)[#tao-fit-display[#mitex("\\sum_k \\eta_k(t) \\tilde \\phi_k(t) = \\Phi_1 + \\Phi_2 + \\Phi_3")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("\\Phi_1  & := \\sum_{k < k_0} \\tilde \\phi_k(T)", block: true)



#tao-math("\\Phi_2  & := \\sum_{k < k_0} \\tilde \\phi_k(t) - \\tilde \\phi_k(T)", block: true)



#tao-math("\\Phi_3  & := \\eta_{k_0}(t) \\tilde \\phi_{k_0}(t).", block: true)
]

#text("The contribution of the ")#mi("{\\Phi_3}")#text(" term is acceptable by ")#link(<tao-cdc3271ebc14b28aceec>)[#text("(6)")]#text(" and estimate (82) from my paper. The term ")#mi("{\\Phi_1}")#text(" sums to ")#mi("{P_{<k_0} \\phi(T)}")#text(" which is acceptable by ")#link(<tao-d0baaad1dce96b65f772>)[#text("(2)")]#text(". So it remains to control the ")#mi("{L^\\infty_x}")#text(" norm of ")#mi("{\\Phi_2}")#text(". By the triangle inequality and the fundamental theorem of calculus, we can bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\Phi_2 \\right\\|_{L^\\infty_x} \\leq (t-T) \\sum_{k < k_0} \\left\\| \\partial_t \\tilde \\phi_k \\right\\|_{L^\\infty_t L^\\infty_x({\\bf R}^{1+n})}.", block: true)]]

#text("By hypothesis, ")#mi("{t-T \\leq 2^{-k_0}}")#text(". Using the first term in (79) of my paper and Bernstein’s inequality followed by ")#link(<tao-cdc3271ebc14b28aceec>)[#text("(6)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\partial_t \\tilde \\phi_k \\right\\|_{L^\\infty_t L^\\infty_x({\\bf R}^{1+n})} \\lesssim 2^k \\left\\| \\tilde \\phi_k \\right\\|_{S[k]({\\bf R}^{1+n})} \\lesssim 2^k;", block: true)]]

#text("and then we are done by summing the geometric series in ")#mi("{k}")#text(".")

#text("It remains to prove the truncation estimate ")#link(<tao-e41e7dcbc37fd2f16ee9>)[#text("(7)")]#text(". This estimate is similar in spirit to the algebra estimates already in my paper, but unfortunately does not seem to follow immediately from these estimates as written, and so one has to repeat the somewhat lengthy decompositions and case checkings used to prove these estimates. We do this below the fold.")

#metadata(none) <tao-0d107be339a84ccb8801>

#heading(level: 1)[#strong[#text(" — 1. Proof of truncation estimate — ")]]

#text("Firstly, by rescaling (and changing ")#mi("{T}")#text(" as necessary) we may assume that ")#mi("{k=0}")#text(". By the triangle inequality and time translation invariance, it suffices to show an estimate of the form")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\eta \\phi \\right\\|_{S[0]} \\lesssim \\left\\| \\phi \\right\\|_{S[0]}", block: true)]]

#text("where ")#mi("{\\eta}")#text(" is a smooth time cutoff that equals ")#mi("{1}")#text(" on ")#mi("{(-\\infty,0]}")#text(" and is supported in ")#mi("{(-\\infty,1]}")#text(", and all norms are understood to be on ")#mi("{{\\bf R}^{1+n}}")#text(". We may normalise the right-hand side to be ")#mi("{1}")#text(", thus ")#mi("{\\phi}")#text(" is supported in frequencies ")#tao-math("{\\left|\\xi\\right| \\sim 1}", block: false)#text(", and by equation (79) of my paper one has the estimates ")#metadata(none) <tao-f64551fcd6f07823cb87>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left\\| \\nabla_{x,t} \\phi \\right\\|_{L^\\infty_t \\dot H^{n/2-1}_x} \\lesssim 1", block: true)]]

#metadata(none) <tao-3946ca64ff78d93ca610>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left\\| \\nabla_{x,t} \\phi \\right\\|_{\\dot X_0^{n/2-1,1/2,\\infty}} \\lesssim 1", block: true)]]

#metadata(none) <tao-43bb00d0ce7790a53b91>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\sum_{\\kappa \\in K_l} \\left\\| P_{0,\\pm \\kappa} Q^\\pm_{<-2l} \\phi \\right\\|_{S[0,\\kappa]}^2 \\lesssim 1", block: true)]]

#text("for all ")#mi("{l > 10}")#text(", and our objective is to show that ")#metadata(none) <tao-8b5cc4df7eec7d32a781>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left\\| \\nabla_{x,t}( \\eta \\phi) \\right\\|_{L^\\infty_t \\dot H^{n/2-1}_x} \\lesssim 1", block: true)]]

#metadata(none) <tao-ac0f09c0f8bf5e7a4b06>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\left\\| \\nabla_{x,t} (\\eta \\phi) \\right\\|_{\\dot X_0^{n/2-1,1/2,\\infty}} \\lesssim 1", block: true)]]

#metadata(none) <tao-cef7fc13a38180936ffa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\sum_{\\kappa \\in K_l} \\left\\| P_{0,\\pm \\kappa} Q^\\pm_{<-2l} (\\eta \\phi) \\right\\|_{S[0,\\kappa]}^2 \\lesssim 1", block: true)]]

#text("for all ")#mi("{l>10}")#text(".")

#text("The bound ")#link(<tao-8b5cc4df7eec7d32a781>)[#text("(11)")]#text(" easily follows from ")#link(<tao-f64551fcd6f07823cb87>)[#text("(8)")]#text(", the Leibniz rule, and using the frequency localisation of ")#mi("{\\phi}")#text(" to ignore spatial derivatives. Now we turn to ")#link(<tao-ac0f09c0f8bf5e7a4b06>)[#text("(12)")]#text(". From the definition of the ")#mi("{\\dot X_0^{n/2-1,1/2,\\infty}}")#text(" norms, we have ")#metadata(none) <tao-ab71fc4c8a1c4d62b920>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\left\\| Q_j \\nabla_{x,t} \\phi \\right\\|_{L^2_t L^2_x} \\lesssim 2^{-j/2}", block: true)]]

#text("for all integers ")#mi("{j}")#text(", and we need to show that ")#metadata(none) <tao-449777124b1466a8ed66>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left\\| Q_j \\nabla_{x,t} (\\eta \\phi) \\right\\|_{L^2_t L^2_x} \\lesssim 2^{-j/2}", block: true)]]

#text("for all integers ")#mi("{j}")#text(".")

#text("Fix ")#mi("{j}")#text(". We can use Littlewood-Paley operators to split ")#mi("{\\eta = \\eta_{<j-10} + \\eta_{\\geq j-10}}")#text(", where ")#mi("{\\eta_{<j-10}}")#text(" is supported on time frequencies ")#tao-math("{\\left|\\tau\\right| \\leq 2^{j-10}}", block: false)#text(" and ")#mi("{\\eta_{\\geq j-10}}")#text(" is supported on time frequencies ")#tao-math("{\\left|\\tau\\right| \\geq 2^{-j-11}}", block: false)#text(". For the contribution of ")#mi("{\\eta_{<j-10}}")#text(" one can replace ")#mi("{\\phi}")#text(" in ")#link(<tao-449777124b1466a8ed66>)[#text("(15)")]#text(" by ")#mi("{Q_{j-5 < \\cdot < j+5}}")#text(" (say) and the claim then follows from ")#link(<tao-ab71fc4c8a1c4d62b920>)[#text("(14)")]#text(", the Leibniz rule, and Hölder’s inequality (again ignoring spatial derivatives). For the contribution of ")#mi("{\\eta_{\\geq j-10}}")#text(", we discard ")#mi("{Q_j}")#text(" and observe that ")#mi("{\\eta_{\\geq j-10}}")#text(" has an ")#mi("{L^2_t L^\\infty_x}")#text(" norm of ")#mi("{2^{-j/2}}")#text(" (and its time derivative has a ")#mi("{L^2_t L^\\infty_x}")#text(" norm of ")#mi("{2^{j/2}}")#text("), so this contribution is then acceptable from ")#link(<tao-f64551fcd6f07823cb87>)[#text("(8)")]#text(" and Hölder’s inequality.")

#text("Finally we need to show ")#link(<tao-cef7fc13a38180936ffa>)[#text("(13)")]#text(". Similarly to before, we split ")#mi("{\\eta = \\eta_{<-2l-10} + \\eta_{\\geq -2l-10}}")#text(". We also split ")#mi("{\\phi = Q^\\pm_{<-2l} \\phi + Q^\\mp_{<-2l} \\phi + Q_{\\geq -2l} \\phi}")#text(", leaving us with the task of proving the four estimates ")#metadata(none) <tao-98cf27e460d9d07cbfe9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\sum_{\\kappa \\in K_l} \\left\\| P_{0,\\pm \\kappa} Q^\\pm_{<-2l} (\\eta_{<-2l-10} Q^\\pm_{<-2l} \\phi) \\right\\|_{S[0,\\kappa]}^2 \\lesssim 1", block: true)]]

#metadata(none) <tao-78fee7b8df3ba23d837f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\sum_{\\kappa \\in K_l} \\left\\| P_{0,\\pm \\kappa} Q^\\pm_{<-2l} (\\eta Q_{\\geq -2l} \\phi) \\right\\|_{S[0,\\kappa]}^2 \\lesssim 1", block: true)]]

#metadata(none) <tao-7e608be808cdb5a96237>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\sum_{\\kappa \\in K_l} \\left\\| P_{0,\\pm \\kappa} Q^\\pm_{<-2l} (\\eta_{\\geq -2l-10} Q^\\pm_{<-2l} \\phi) \\right\\|_{S[0,\\kappa]}^2 \\lesssim 1.", block: true)]]

#metadata(none) <tao-981309a55b1a205ad3b7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("\\sum_{\\kappa \\in K_l} \\left\\| P_{0,\\pm \\kappa} Q^\\pm_{<-2l} (\\eta Q^\\mp_{< -2l} \\phi) \\right\\|_{S[0,\\kappa]}^2 \\lesssim 1", block: true)]]

#text("We begin with ")#link(<tao-98cf27e460d9d07cbfe9>)[#text("(16)")]#text(". The multiplier ")#mi("{P_{0,\\pm \\kappa} Q^\\pm_{<-2l}}")#text(" is disposable in the sense of the paper, and similarly if one replaces ")#mi("{P_{0,\\pm \\kappa}}")#text(" by a slightly larger multiplier; this lets us bound the left-hand side of ")#link(<tao-98cf27e460d9d07cbfe9>)[#text("(16)")]#text(" by")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\kappa \\in K_l} \\left\\| P_{0,\\pm \\kappa} (\\eta_{<-2l-10} Q^\\pm_{<-2l} \\phi) \\right\\|_{S[0,\\kappa]}^2 \\lesssim 1.", block: true)]]

#text("The time cutoff ")#mi("{\\eta_{<-2l-10}}")#text(" commutes with the spatial Fourier projection ")#mi("{P_{0,\\pm \\kappa}}")#text(" and can then be discarded by equation (66) of my paper. This term is thus acceptable thanks to ")#link(<tao-43bb00d0ce7790a53b91>)[#text("(10)")]#text(".")

#text("Now we turn to ")#link(<tao-78fee7b8df3ba23d837f>)[#text("(17)")]#text(". We can freely insert a factor of ")#mi("{Q^\\pm_{<-2l+5}}")#text(" in front of ")#mi("{P_{0,\\pm \\kappa} Q^\\pm_{<-2l}}")#text(". Applying estimate (75) from my paper, it then suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Q^\\pm_{<-2l+5} (\\eta Q_{\\geq -2l} \\phi) \\right\\|_{\\dot X_0^{n/2,1/2,1}} \\lesssim 1.", block: true)]]

#text("From the Fourier support of the expression inside the norm, the left-hand side is bounded by")

#align(center)[#tao-fit-display[#tao-math("\\lesssim 2^{-l} \\left\\| \\eta Q_{\\geq -2l} \\phi \\right\\|_{L^2_t L^2_x};", block: true)]]

#text("discarding the cutoff ")#mi("{\\eta_{<-2l-10}}")#text(" and using ")#link(<tao-3946ca64ff78d93ca610>)[#text("(9)")]#text(" we see that this contribution is acceptable.")

#text("Next, we show ")#link(<tao-7e608be808cdb5a96237>)[#text("(18)")]#text(". Here we use the energy estimate from equation (27) (and (25)) of the paper. By repeating the proof of ")#link(<tao-8b5cc4df7eec7d32a781>)[#text("(11)")]#text(" (and using Lemma 4 from my paper) we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\eta_{\\geq -2l-10} Q^\\pm_{<-2l} \\phi[0] \\right\\|_{\\dot H^{n/2} \\times \\dot H^{n/2-1}} \\lesssim 1", block: true)]]

#text("so it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\Box( \\eta_{\\geq -2l-10} Q^\\pm_{<-2l} \\phi ) \\right\\|_{L^1_t L^2_x} \\lesssim 1.", block: true)]]

#text("Expanding out the d’Lambertian using the Leibniz rule, we are reduced to showing the estimates ")#metadata(none) <tao-aa58b21b01d6b8a99c1a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("\\left\\| \\eta_{\\geq -2l-10} \\Box Q^\\pm_{<-2l} \\phi \\right\\|_{L^1_t L^2_x} \\lesssim 1.", block: true)]]

#metadata(none) <tao-cf04b1041e6366d1c48b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\left\\| \\eta^{\\prime}_{\\geq -2l-10} \\partial_t Q^\\pm_{<-2l} \\phi ) \\right\\|_{L^1_t L^2_x} \\lesssim 1.", block: true)]]

#metadata(none) <tao-cdd6f7efe38a28031f9b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#tao-math("\\left\\| \\eta^{\\prime\\prime}_{\\geq -2l-10} Q^\\pm_{<-2l} \\phi ) \\right\\|_{L^1_t L^2_x} \\lesssim 1.", block: true)]]

#text("For ")#link(<tao-aa58b21b01d6b8a99c1a>)[#text("(20)")]#text(" we note that ")#mi("{\\eta_{\\geq -2l-10}}")#text(" has an ")#mi("{L^2_t L^\\infty_x}")#text(" norm of ")#mi("{O( 2^l )}")#text(", while from ")#link(<tao-3946ca64ff78d93ca610>)[#text("(9)")]#text(" ")#mi("{\\Box Q^\\pm_{<-2l} \\phi}")#text(" has an ")#mi("{L^2_t L^\\infty_x}")#text(" norm of ")#mi("{O(2^{-l})}")#text(", so the claim follows from Hölder’s inequality. For ")#link(<tao-cf04b1041e6366d1c48b>)[#text("(21)")]#text(" we can similarly observe that ")#mi("{\\eta^{\\prime}_{\\geq -2l-10}}")#text(" has an ")#mi("{L^1_t L^\\infty_x}")#text(" norm of ")#mi("{O(1)}")#text(" while from ")#link(<tao-f64551fcd6f07823cb87>)[#text("(8)")]#text(" we see that ")#mi("{\\partial_t Q^\\pm_{<-2l} \\phi}")#text(" has an ")#mi("{L^\\infty_t L^2_x}")#text(" norm of ")#mi("{O(1)}")#text(", so the claim again follows from Hölder’s inequality. A similar argument gives ")#link(<tao-cdd6f7efe38a28031f9b>)[#text("(22)")]#text(" (with an additional gain of ")#mi("{2^{-2l}}")#text(" coming from the second derivative on ")#mi("{\\eta_{\\geq -2l-10}}")#text(").")

#text("Finally, for ")#link(<tao-981309a55b1a205ad3b7>)[#text("(19)")]#text(", we observe from the Fourier separation between ")#mi("{Q^\\pm_{<-2l}}")#text(" and ")#mi("{Q^\\mp_{<-2l}}")#text(" that we may replace ")#mi("{\\eta}")#text(" by ")#mi("{\\eta_{\\geq -2l-10}}")#text(" (in fact one could do a much more drastic replacement if desired). The claim now follows from repeating the proof of ")#link(<tao-7e608be808cdb5a96237>)[#text("(18)")]#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1d8a33c0fca1a64cb6b190db505f3d238724965e2b209991078e636a4f3f9fc-76b86bbcfd0f6bd7a8dafa028511c2232308098ab8826e0db37aa518ac63f0b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cristhian Camachoo")]], [#link("https://terrytao.wordpress.com/2016/08/26/an-erratum-to-global-regularity-of-wave-maps-ii-small-energy-in-two-dimensions/#comment-472494")[#strong[#text("Cristhian Camachoo")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2016")])]

#text("Off topic: My initial thought, is there an area in mathematics related to Algebra of Summations to see cases like ")#link("https://m.facebook.com/photo.php?fbid=2452483354379&id=1320876756&set=a.1240274569917.2036482.1320876756&source=48&ref=bookmarks")[#text("https://m.facebook.com/photo.php?fbid=2452483354379&id=1320876756&set=a.1240274569917.2036482.1320876756&source=48&ref=bookmarks")]
]
