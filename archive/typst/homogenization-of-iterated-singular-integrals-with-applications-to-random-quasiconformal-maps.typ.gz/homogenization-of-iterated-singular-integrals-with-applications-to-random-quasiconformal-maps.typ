// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/06/22/homogenization-of-iterated-singular-integrals-with-applications-to-random-quasiconformal-maps/
// Converted to Typst by tao2typ: "2026-10-14T16:38:48.672736+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Homogenization of iterated singular integrals with applications to random quasiconformal maps", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Homogenization of iterated singular integrals with applications to random quasiconformal maps")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 June 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/06/22/homogenization-of-iterated-singular-integrals-with-applications-to-random-quasiconformal-maps/")[#text("https://terrytao.wordpress.com/2020/06/22/homogenization-of-iterated-singular-integrals-with-applications-to-random-quasiconformal-maps/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://en.wikipedia.org/wiki/Kari_Astala")[#text("Kari Astala")]#text(", ")#link("https://sites.math.washington.edu/~rohde/")[#text("Steffen Rohde")]#text(", ")#link("https://researchportal.helsinki.fi/en/persons/eero-saksman")[#text("Eero Saksman")]#text(" and I have (finally!) uploaded to the arXiv our preprint “")#link("https://arxiv.org/abs/2006.11602")[#text("Homogenization of iterated singular integrals with applications to random quasiconformal maps")]#text("“. This project started (and was largely completed) over a decade ago, but for various reasons it was not finalised until very recently. The motivation for this project was to study the behaviour of “random” quasiconformal maps. Recall that a (smooth) ")#link("https://en.wikipedia.org/wiki/Quasiconformal_mapping")[#text("quasiconformal map")]#text(" is a homeomorphism ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" that obeys the ")#link("https://en.wikipedia.org/wiki/Beltrami_equation")[#text("Beltrami equation")]

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial f}{\\partial \\overline{z}} = \\mu \\frac{\\partial f}{\\partial z}")]]

#text("for some ")#emph[#text("Beltrami coefficient")]#text(" ")#mi("{\\mu: {\\bf C} \\rightarrow D(0,1)}")#text("; this can be viewed as a deformation of the Cauchy-Riemann equation ")#mi("{\\frac{\\partial f}{\\partial \\overline{z}} = 0}")#text(". Assuming that ")#mi("{f(z)}")#text(" is asymptotic to ")#mi("{z}")#text(" at infinity, one can (formally, at least) solve for ")#mi("{f}")#text(" in terms of ")#mi("{\\mu}")#text(" using the ")#emph[#text("Beurling transform")]

#align(center)[#tao-fit-display[#mitex("Tf(z) := \\frac{\\partial}{\\partial z}(\\frac{\\partial f}{\\partial \\overline{z}})^{-1}(z) = -\\frac{1}{\\pi} p.v. \\int_{\\bf C} \\frac{f(w)}{(w-z)^2}\\ dw")]]

#text("by the Neumann series")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial f}{\\partial \\overline{z}} = \\mu + \\mu T \\mu + \\mu T \\mu T \\mu + \\dots.")]]

#text("We looked at the question of the asymptotic behaviour of ")#mi("{f}")#text(" if ")#mi("{\\mu = \\mu_\\delta}")#text(" is a random field that oscillates at some fine spatial scale ")#mi("{\\delta>0}")#text(". A simple model to keep in mind is")

#metadata(none) <tao-af07ff91ab7ce2a7d1f9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\mu_\\delta(z) = \\varphi(z) \\sum_{n \\in {\\bf Z}^2} \\epsilon_n 1_{n\\delta + [0,\\delta]^2}(z)")]]

#text("where ")#mi("{\\epsilon_n = \\pm 1}")#text(" are independent random signs and ")#mi("{\\varphi: {\\bf C} \\rightarrow D(0,1)}")#text(" is a bump function. For models such as these, we show that a homogenisation occurs in the limit ")#mi("{\\delta \\rightarrow 0}")#text("; each multilinear expression")

#metadata(none) <tao-1752e10a31f9c697bb9c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\mu_\\delta T \\mu_\\delta \\dots T \\mu_\\delta")]]

#text("converges weakly in probability (and almost surely, if we restrict ")#mi("{\\delta}")#text(" to a lacunary sequence) to a deterministic limit, and the associated quasiconformal map ")#mi("{f = f_\\delta}")#text(" similarly converges weakly in probability (or almost surely). (Results of this latter type were also recently obtained ")#link("https://arxiv.org/abs/1905.07932")[#text("by Ivrii and Markovic")]#text(" by a more geometric method which is simpler, but is applied to a narrower class of Beltrami coefficients.) In the specific case ")#link(<tao-af07ff91ab7ce2a7d1f9>)[#text("(1)")]#text(", the limiting quasiconformal map is just the identity map ")#mi("{f(z)=z}")#text(", but if for instance replaces the ")#mi("{\\epsilon_n}")#text(" by non-symmetric random variables then one can have significantly more complicated limits. The convergence theorem for multilinear expressions such as is not specific to the Beurling transform ")#mi("{T}")#text("; any other translation and dilation invariant singular integral can be used here.")

#text("The random expression ")#link(<tao-1752e10a31f9c697bb9c>)[#text("(2)")]#text(" is somewhat reminiscent of a moment of a random matrix, and one can start computing it analogously. For instance, if one has a decomposition ")#mi("{\\mu_\\delta = \\sum_{n \\in {\\bf Z}^2} \\mu_{\\delta,n}}")#text(" such as ")#link(<tao-af07ff91ab7ce2a7d1f9>)[#text("(1)")]#text(", then ")#link(<tao-1752e10a31f9c697bb9c>)[#text("(2)")]#text(" expands out as a sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{n_1,\\dots,n_k \\in {\\bf Z}^2} \\mu_{\\delta,n_1} T \\mu_{\\delta,n_2} \\dots T \\mu_{\\delta,n_k}")]]

#text("The random fluctuations of this sum can be treated by a routine second moment estimate, and the main task is to show that the expected value")

#metadata(none) <tao-77f2f036726eaa17f75c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{n_1,\\dots,n_k \\in {\\bf Z}^2} \\mathop{\\bf E}(\\mu_{\\delta,n_1} T \\mu_{\\delta,n_2} \\dots T \\mu_{\\delta,n_k})")]]

#text("becomes asymptotically independent of ")#mi("{\\delta}")#text(".")

#text("If all the ")#mi("{n_1,\\dots,n_k}")#text(" were distinct then one could use independence to factor the expectation to get")

#align(center)[#tao-fit-display[#mitex("\\sum_{n_1,\\dots,n_k \\in {\\bf Z}^2} \\mathop{\\bf E}(\\mu_{\\delta,n_1}) T \\mathop{\\bf E}(\\mu_{\\delta,n_2}) \\dots T \\mathop{\\bf E}(\\mu_{\\delta,n_k})")]]

#text("which is a relatively straightforward expression to calculate (particularly in the model ")#link(<tao-af07ff91ab7ce2a7d1f9>)[#text("(1)")]#text(", where all the expectations here in fact vanish). The main difficulty is that there are a number of configurations in ")#link(<tao-77f2f036726eaa17f75c>)[#text("(3)")]#text(" in which various of the ")#mi("{n_j}")#text(" collide with each other, preventing one from easily factoring the expression. A typical problematic contribution for instance would be a sum of the form")

#metadata(none) <tao-d397d1c3ec3b58cfaa30>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{n_1,n_2 \\in {\\bf Z}^2: n_1 \\neq n_2} \\mathop{\\bf E}(\\mu_{\\delta,n_1} T \\mu_{\\delta,n_2} T \\mu_{\\delta,n_1} T \\mu_{\\delta,n_2}).")]]

#text("This is an example of what we call a ")#emph[#text("non-split")]#text(" sum. This can be compared with the ")#emph[#text("split sum")]

#metadata(none) <tao-4d4f0f7a97c8f4035952>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_{n_1,n_2 \\in {\\bf Z}^2: n_1 \\neq n_2} \\mathop{\\bf E}(\\mu_{\\delta,n_1} T \\mu_{\\delta,n_1} T \\mu_{\\delta,n_2} T \\mu_{\\delta,n_2}).")]]

#text("If we ignore the constraint ")#mi("{n_1 \\neq n_2}")#text(" in the latter sum, then it splits into")

#align(center)[#tao-fit-display[#mitex("f_\\delta T g_\\delta")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("f_\\delta := \\sum_{n_1 \\in {\\bf Z}^2} \\mathop{\\bf E}(\\mu_{\\delta,n_1} T \\mu_{\\delta,n_1})")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("g_\\delta := \\sum_{n_2 \\in {\\bf Z}^2} \\mathop{\\bf E}(\\mu_{\\delta,n_2} T \\mu_{\\delta,n_2})")]]

#text("and one can hope to treat this sum by an induction hypothesis. (To actually deal with constraints such as ")#mi("{n_1 \\neq n_2}")#text(" requires an inclusion-exclusion argument that creates some notational headaches but is ultimately manageable.) As the name suggests, the non-split configurations such as ")#link(<tao-d397d1c3ec3b58cfaa30>)[#text("(4)")]#text(" cannot be factored in this fashion, and are the most difficult to handle. A direct computation using the triangle inequality (and a certain amount of combinatorics and induction) reveals that these sums are somewhat localised, in that dyadic portions such as")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n_1,n_2 \\in {\\bf Z}^2: \\left|n_1 - n_2\\right| \\sim R} \\mathop{\\bf E}(\\mu_{\\delta,n_1} T \\mu_{\\delta,n_2} T \\mu_{\\delta,n_1} T \\mu_{\\delta,n_2})", block: true)]]

#text("exhibit power decay in ")#mi("{R}")#text(" (when measured in suitable function space norms), basically because of the large number of times one has to transition back and forth between ")#mi("{n_1}")#text(" and ")#mi("{n_2}")#text(". Thus, morally at least, the dominant contribution to a non-split sum such as ")#link(<tao-d397d1c3ec3b58cfaa30>)[#text("(4)")]#text(" comes from the local portion when ")#mi("{n_2=n_1+O(1)}")#text(". From the translation and dilation invariance of ")#mi("{T}")#text(" this type of expression then simplifies to something like")

#align(center)[#tao-fit-display[#mitex("\\varphi(z)^4 \\sum_{n \\in {\\bf Z}^2} \\eta( \\frac{n-z}{\\delta} )")]]

#text("(plus negligible errors) for some reasonably decaying function ")#mi("{\\eta}")#text(", and this can be shown to converge to a weak limit as ")#mi("{\\delta \\rightarrow 0}")#text(".")

#text("In principle all of these limits are computable, but the combinatorics is remarkably complicated, and while there is certainly some algebraic structure to the calculations, it does not seem to be easily describable in terms of an existing framework (e.g., that of free probability).")

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/06/22/homogenization-of-iterated-singular-integrals-with-applications-to-random-quasiconformal-maps/#comment-568971")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2020")])]

#link("https://www.fpa.es/es/premios-princesa-de-asturias/premiados/2020-yves-meyer-ingrid-daubechies-terence-tao-y-emmanuel-candes.html?texto=trayectoria&especifica=0")[#text("https://www.fpa.es/es/premios-princesa-de-asturias/premiados/2020-yves-meyer-ingrid-daubechies-terence-tao-y-emmanuel-candes.html?texto=trayectoria&especifica=0")]#linebreak()#text(" Enhorabuena profesor")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of BabaDaga")]], [#link("https://terrytao.wordpress.com/2020/06/22/homogenization-of-iterated-singular-integrals-with-applications-to-random-quasiconformal-maps/#comment-569204")[#strong[#text("BabaDaga")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2020")])]

#text("does it have applications to string theory?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18a7866c654cf3fe1ab1279db62496f1558286f44647c5b36d79ac83fd1c4771-6f3e77fee47e6083ed03276fb5c145cccb35c5dd51132e7b400ddf4c6d140ff4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hollis Williams")]], [#link("https://terrytao.wordpress.com/2020/06/22/homogenization-of-iterated-singular-integrals-with-applications-to-random-quasiconformal-maps/#comment-573213")[#strong[#text("Hollis Williams")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2020")])]

#text("@BabaDaga: does everything need to have applications to string theory? This post clearly has nothing to do with mathematical physics, which is another subject entirely.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebd1827b5334803455c77d70c00467861c2b5e7bed9c2506001c6891d88f1dcb-f47a4aff78709e7081b043e44db03c3864abe0af81581a8fc82862f099d1a6cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CONNOR MICHAEL CASSEDY")]], [#link("https://terrytao.wordpress.com/2020/06/22/homogenization-of-iterated-singular-integrals-with-applications-to-random-quasiconformal-maps/#comment-569367")[#strong[#text("CONNOR MICHAEL CASSEDY")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2020")])]

#text("Hi Professor Tao, I believe this paper may be at risk of being legally declared being “open source” and you may lose significant credit for your credit for your work. Specifically, there is a problem because there is no formal citation of David White who I believe is a pseudonym for a general editor to this paper. I thought this would be informative for you to know before you decide to submit this collaborative project to a journal, since I believe this paper would fit right into a theoretical physics journal or a string theory journal. I am wondering if you are planning on submitting this paper with your name alone as it exists in the .org domain the paper lies or if you are planning on submitting with collaborators. I was working on a similar problem to this so that is why I am writing the comment. Please email me if you have questions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0db243aa4de5834cfa5ac8ed01670440a54baf720b078f3e56e1f246ec384040-f0a13d3905a426c790ce9b2d63c38705b8f6669b977b5bcd376568fe8503b7dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Submathematics")]], [#link("https://terrytao.wordpress.com/2020/06/22/homogenization-of-iterated-singular-integrals-with-applications-to-random-quasiconformal-maps/#comment-569719")[#strong[#text("Submathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2020")])]

#text("Reblogged this on ")#link("https://subham838040565.wordpress.com/2020/06/27/homogenization-of-iterated-singular-integrals-with-applications-to-random-quasiconformal-maps/")[#text("Path of Maths")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/097a4d5133f182db0e69d4c8b545f1e04ffe71834194bb0c5514993838312913-be24c73e8383858c44fd3f54eca00b77b675548c40c6fb0e21384600734295e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YahyaAA1")]], [#link("https://terrytao.wordpress.com/2020/06/22/homogenization-of-iterated-singular-integrals-with-applications-to-random-quasiconformal-maps/#comment-570214")[#strong[#text("YahyaAA1")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2020")])]

#text("“some notational headaches” … Maybe _a better notation_ would either alleviate the headaches, or suggest a new viewpoint? One thinks, e.g., of Feynman diagrams, the use of which allowed physicists to step outside the old boxes. Of course, radically new notations take considerable invention, and not all are productive or useful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/06/22/homogenization-of-iterated-singular-integrals-with-applications-to-random-quasiconformal-maps/#comment-570355")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2020")])]

#text("Is there a connection between the Beltrami equation and the Beltrami fields appearing as stationary solutions of the Euler equation ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/06/22/homogenization-of-iterated-singular-integrals-with-applications-to-random-quasiconformal-maps/#comment-575029")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2020")])]

#text("Dear Pro.Tao,")#linebreak()#text(" Happy birthday to you !")#linebreak()#text(" Happy next your big steps on the way !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e4720175b18ed4755ee01995f8484f54a29f9e57639be6122088745055d0c5f-806779e24544d9d8527fd4cbfdc4d284cd6f82fcccdd495e461fd8159aa955ab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/06/22/homogenization-of-iterated-singular-integrals-with-applications-to-random-quasiconformal-maps/#comment-578234")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2020")])]

#text("Potentially silly question here; why does that formula for the Neumann expansion make sense? I (think I) see why the Beurling transform can be defined that way (the Cauchy-Green-Pompeiu formula with appropriate limits), but can’t see how, even formally, the expression for $\\bar{\\partial}f$ arises.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/06/22/homogenization-of-iterated-singular-integrals-with-applications-to-random-quasiconformal-maps/#comment-578374")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2020")])]

#text("Because ")#mi("f")#text(" is required to behave like ")#mi("z")#text(" at infinity rather than like ")#mi("0")#text(", the function ")#mi("\\frac{\\partial f}{\\partial z}")#text(" is actually equal to ")#mi("1 + T \\frac{\\partial f}{\\partial \\overline{z}}")#text(" rather than just ")#mi("T \\frac{\\partial f}{\\partial \\overline{z}}")#text(". The Beltrami equation now becomes ")#mi("\\frac{\\partial f}{\\partial \\overline{z}} = \\mu + \\mu T \\frac{\\partial f}{\\partial \\overline{z}}")#text(" which can then be solved by Neumann series or iteration to give (at least formally) the claimed infinite series.")
]
]
