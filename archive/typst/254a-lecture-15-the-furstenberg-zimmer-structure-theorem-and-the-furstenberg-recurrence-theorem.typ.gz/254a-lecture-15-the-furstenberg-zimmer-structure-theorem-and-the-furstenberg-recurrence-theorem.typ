// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/
// Converted to Typst by tao2typ: "2026-10-14T15:16:42.007343+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Lecture 15: The Furstenberg-Zimmer structure theorem and the Furstenberg recurrence theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Lecture 15: The Furstenberg-Zimmer structure theorem and the Furstenberg recurrence theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 March 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/")[#text("https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("In this lecture – the final one on general measure-preserving dynamics – we put together the results from the past few lectures to establish the Furstenberg-Zimmer structure theorem for measure-preserving systems, and then use this to finish the proof of the Furstenberg recurrence theorem.")

#heading(level: 1)[#metadata(none) <tao-d5f4ee4a8c24109faed7>#text("— The Furstenberg-Zimmer structure theorem —")]

#text("Let ")#mi("X = (X,{\\mathcal X},\\mu,T)")#text(" be a measure-preserving system, and let ")#mi("Y = (Y, {\\mathcal Y},\\nu,S)")#text(" be a factor. In Theorem 2 of the ")#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/")[#text("previous lecture")]#text(", we showed that if X was not a weakly mixing extension of Y, then we could find a non-trivial compact extension Z of Y (thus ")#mi("L^2(Z)")#text(" is a non-trivial superspace of ")#mi("L^2(Y)")#text("). Combining this with ")#link("http://en.wikipedia.org/wiki/Zorn%27s_lemma")[#text("Zorn’s lemma")]#text(" (and starting with the trivial factor Y = pt), one obtains")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1. ")]#text(" (Furstenberg-Zimmer structure theorem) Let ")#mi("(X,{\\mathcal X},\\mu,T)")#text(" be a measure-preserving system. Then there exists an ")#link("http://en.wikipedia.org/wiki/Ordinal_number")[#text("ordinal")]#text(" ")#mi("\\alpha")#text(" and a factor ")#mi("Y_\\beta = (Y_\\beta, {\\mathcal Y}_\\beta, \\nu_\\beta, S_\\beta)")#text(" for every ")#mi("\\beta \\leq \\alpha")#text(" with the following properties:")

#enum(start: 1, 
[#mi("Y_\\emptyset")#text(" is a point.")],
[#text("For every ")#link("http://en.wikipedia.org/wiki/Successor_ordinal")[#text("successor ordinal")]#text(" ")#mi("\\beta+1 \\leq \\alpha")#text(", ")#mi("Y_{\\beta+1}")#text(" is a compact extension of ")#mi("Y_\\beta")#text(".")],
[#text("For every ")#link("http://en.wikipedia.org/wiki/Limit_ordinal")[#text("limit ordinal")]#text(" ")#mi("\\beta \\leq \\alpha")#text(", ")#mi("Y_\\beta")#text(" is the inverse limit of the ")#mi("Y_\\gamma")#text(" for the ")#mi("\\gamma < \\beta")#text(", in the sense that ")#mi("L^2(Y_\\beta)")#text(" is the closure of ")#mi("\\bigcup_{\\gamma < \\beta} L^2(Y_\\gamma)")#text(".")],
[#text("X is a weakly mixing extension of ")#mi("Y_\\alpha")#text(".")]
)
]

#text("This theorem should be compared with Furstenberg’s structure theorem for distal systems in topological dynamics (Theorem 2 from ")#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/")[#text("Lecture 7")]#text("). Indeed, in analogy to that theorem, the factors ")#mi("Y_\\beta")#text(" are known as ")#emph[#text("distal measure-preserving systems")]#text(". The result was proven independently ")#link("http://www.ams.org/mathscinet-getitem?mr=498471")[#text("by Furstenberg")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=414832")[#text("by Zimmer")]#text(".")

#strong[#text("Exercise 1.")]#text(" Deduce Theorem 1 from Theorem 2 of the ")#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/")[#text("previous lecture")]#text(". ")#mi("\\diamond")

#strong[#text("Remark 1.")]#text(" Since the Hilbert spaces ")#mi("L^2(Y_\\beta)")#text(" are increasing inside the separable Hilbert space ")#mi("L^2(X)")#text(", it is not hard to see that the ordinal ")#mi("\\alpha")#text(" must be at most countable. Conversely, a ")#link("http://www.ams.org/mathscinet-getitem?mr=1417768")[#text("result of Beleznay and Foreman")]#text(" shows that every countable ordinal can appear as the minimal length of a Furstenberg tower of a given system. Thus, in some sense, the complexity of a system can be as great as any countable ordinal. This is because the structure theorem roots out every last trace of structure from the system, so much so that every remaining function orthogonal to the final factor ")#mi("L^2(Y_\\alpha)")#text(" is weakly mixing. But in many applications one does not need so much weak mixing; for instance to establish k-fold recurrence for a function f, it would be enough to obtain weak mixing control on just a few combinations of f (such as ")#mi("T^h f \\overline{f}")#text("), as we already saw in the proof of Roth’s theorem in Lecture 12. In fact, it is not hard to show that to prove Furstenberg’s recurrence theorem for a fixed k, one only needs to analyse the first k-2 steps of the Furstenberg tower. As one consequence of this, it is possible to avoid the use of Zorn’s lemma (and the axiom of choice) in the proof of the recurrence theorem. ")#mi("\\diamond")

#strong[#text("Remark 2. ")]#text(" Analogues of the structure theorem exist for other actions, such as the action of ")#mi("{\\Bbb Z}^d")#text(" on a measure space (which can equivalently be viewed as the action of d commuting shifts ")#mi("T_1,\\ldots,T_d: X \\to X")#text("). There is a new feature in this case, though: instead of having a tower of purely compact extensions, followed by one weakly mixing extension at the end, one instead has a tower of hybrid extensions (known as primitive extensions), each one of which is compact along one subgroup of ")#mi("{\\Bbb Z}^d")#text(" and weakly mixing along a complementary subgroup. See for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=603625")[#text("Furstenberg’s book")]#text(" for details. ")#mi("\\diamond")

#heading(level: 1)[#text("— The Furstenberg recurrence theorem —")]

#text("The Furstenberg recurrence theorem asserts that every measure-preserving system ")#mi("(X,{\\mathcal X},\\mu,T)")#text(" has the uniform multiple recurrence (UMR) property, thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\liminf_{N \\to \\infty} \\frac{1}{N} \\sum_{n=0}^{N-1} \\int_X f T^n f \\ldots T^{(k-1)n} f\\ d\\mu > 0")]]

#text("whenever ")#mi("k \\geq 1")#text(" and ")#mi("f \\in L^\\infty(X)")#text(" is non-negative with positive mean. The UMR property is trivially true for a point, and we have already shown that UMR is preserved by compact extensions (Theorem 1 of ")#link("https://terrytao.wordpress.com/2008/02/27/254a-lecture-13-compact-extensions/")[#text("Lecture 13")]#text(") and by weakly mixing extensions (Theorem 1 of ")#link("https://terrytao.wordpress.com/2008/03/02/254a-lecture-14-weakly-mixing-extensions/")[#text("Lecture 14")]#text("). The former result lets us climb the successor ordinal steps of the tower in Theorem 1, while the latter lets us jump from the final distal system ")#mi("Y_\\alpha")#text(" to X. But to clinch the proof of the recurrence theorem, we also need to deal with the limit ordinals. More precisely, we need to prove")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2. ")]#text("(Limits of chains) Let ")#mi("(Y_\\beta)_{\\beta \\in B}")#text(" be a totally ordered family of factors of a measure-preserving system X (thus ")#mi("L^2(Y_\\beta)")#text(" is increasing with ")#mi("\\beta")#text(", and let Y be the inverse limit of the ")#mi("Y_\\beta")#text(". If each of the ")#mi("Y_\\beta")#text(" obeys the UMR, then Y does also.")
]

#text("With this theorem, the Furstenberg recurrence theorem (Theorem 1 from ")#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/")[#text("Lecture 11")]#text(") follows from the previous theorems and ")#link("http://en.wikipedia.org/wiki/Transfinite_induction")[#text("transfinite induction")]#text(".")

#text("The main difficulty in establishing Theorem 2 is that while each ")#mi("Y_\\beta")#text(" obeys the UMR separately, we do not know that this property holds uniformly in ")#mi("\\beta")#text(". The main new observation needed to establish the theorem is that there is another way to leverage the UMR from a factor to an extension… if the support of the function f is sufficiently “dense”. We motivate this by first considering the unconditional case.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1. ")]#text("(UMR for densely supported functions) Let ")#mi("(X,{\\mathcal X},\\mu,T)")#text(" be a measure-preserving system, let ")#mi("k \\geq 1")#text(" be an integer, and let ")#mi("f \\in L^\\infty(X)")#text(" be a non-negative function whose support ")#mi("\\{ x: f(x) > 0\\}")#text(" has measure greater than ")#mi("1-1/k")#text(". Then (1) holds.")
]

#strong[#text("Proof.")]#text(" By monotone convergence, we can find ")#mi("\\varepsilon > 0")#text(" such that ")#mi("f(x) > \\varepsilon")#text(" for all x outside of a set E of measure at most ")#mi("1/k - \\varepsilon")#text(". For any n, this implies that ")#mi("f(x) T^n f(x) \\ldots T^{(k-1) n} f(x) > \\varepsilon^k")#text(" for all x outside of the set ")#mi("E \\cup T^n E \\cup \\ldots \\cup T^{(k-1)n} E")#text(", which has measure at most ")#mi("1-k\\varepsilon")#text(". In particular we see that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\int_X f T^n f \\ldots T^{(k-1) n} f\\ d\\mu > k \\varepsilon^{k+1}")]]

#text("for all n, and the claim follows. ")#mi("\\Box")

#text("As with the other components of the proof of the recurrence theorem, we will need to upgrade the above proposition to a “relative” version:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2. ")]#text("(UMR for relatively densely supported functions) Let ")#mi("(X,{\\mathcal X},\\mu,T)")#text(" be an extension of a factor ")#mi("(Y,{\\mathcal Y},\\nu, S)")#text(" with the UMR, let ")#mi("k \\geq 1")#text(" be an integer, and let ")#mi("f \\in L^\\infty(X)")#text(" be a non-negative function whose support ")#mi("\\Omega := \\{ x: f(x) > 0\\}")#text(" is such that the set ")#mi("\\{ y \\in Y: {\\Bbb E}(1_\\Omega|Y) > 1-1/k \\}")#text(" has positive measure in Y. Then (1) holds.")
]

#strong[#text("Proof.")]#text(" By monotone convergence again, we can find ")#mi("\\varepsilon > 0")#text(" such that the set ")#mi("E := \\{ x: f(x) > \\varepsilon \\}")#text(" is such that the set ")#mi("F := \\{ y \\in Y: {\\Bbb E}(1_E|Y) > 1-1/k+\\varepsilon \\}")#text(" has positive measure. Since Y has the UMR, this implies that (1) holds for ")#mi("1_F")#text(". In other words, there exists ")#mi("c > 0")#text(" such that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\nu( F \\cap T^n F \\cap \\ldots \\cap T^{(k-1)n} F ) > c")]]

#text("for all n in a set of positive lower density.")

#text("Now we turn to f. We have the pointwise lower bound ")#mi("f(x) \\geq \\varepsilon 1_E(x)")#text(", and so")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("f T^n f \\ldots T^{(k-1)n} f(x) \\geq \\varepsilon^k 1_{E \\cap T^n E \\cap \\ldots \\cap T^{(k-1)n} E}(x).")]]

#text("We have the crude lower bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("1_{E \\cap T^n E \\cap \\ldots \\cap T^{(k-1)n} E}(x) \\geq 1 - \\sum_{j=0}^{k-1} 1_{T^{jn} E^c}(x);")]]

#text("inserting this into (4) and taking conditional expectations, we conclude")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("{\\Bbb E}( f T^n f \\ldots T^{(k-1)n} f | Y) (y) \\geq \\varepsilon^k ( 1 - \\sum_{j=0}^{k-1} {\\Bbb E}( 1_{T^{jn} E^c} | Y)(y))")]]

#text("a.e. On the other hand, we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("{\\Bbb E}( 1_{T^{jn} E^c} | Y) = 1 - {\\Bbb E}( 1_{T^{jn} E} | Y) = 1 - T^{jn} {\\Bbb E}(1_E|Y).")]]

#text("By definition of F, we thus see that if y lies in ")#mi("F \\cap T^n F \\cap \\ldots \\cap T^{(k-1)n} F")#text(", then")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("{\\Bbb E}( f T^n f \\ldots T^{(k-1)n} f | Y) (y) \\geq \\varepsilon^k \\times k \\varepsilon.")]]

#text("Integrating this and using (3), we obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\int_X  f T^n f \\ldots T^{(k-1)n} f\\ d\\mu \\geq c \\varepsilon^k \\times k \\varepsilon")]]

#text("for all n in a set of positive lower density, and (1) follows. ")#mi("\\Box")

#strong[#text("Proof of Theorem 2.")]#text(" Let ")#mi("f \\in L^\\infty(Y)")#text(" be non-negative with positive mean ")#mi("\\int_X f\\ d\\mu = c > 0")#text("; we may normalise f to be bounded by 1. Since Y is the inverse limit of the ")#mi("Y_\\beta")#text(", we see that the orthogonal projections ")#mi("{\\Bbb E}(f|Y_\\beta)")#text(" converge in ")#mi("L^2(X)")#text(" norm to ")#mi("{\\Bbb E}(f|Y) = f")#text(". Thus, for any ")#mi("\\varepsilon")#text(", we can find ")#mi("\\beta")#text(" such that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left\\| f - {\\Bbb E}(f|Y_\\beta) \\right\\|_{L^2(X)} \\leq \\varepsilon.", block: true)]]

#text("Now ")#mi("{\\Bbb E}(f|Y_\\beta)")#text(" has the same mean c as f, and is also bounded by 1. Thus the set ")#mi("E := \\{ y: {\\Bbb E}(f|Y_\\beta)(y) \\geq c/2 \\}")#text(" must have measure at least c/2 in ")#mi("Y_\\beta")#text(". Now if ")#mi("\\Omega := \\{ x: f(x) > 0 \\}")#text(", then we have the pointwise bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left|f - {\\Bbb E}(f|Y_\\beta)\\right| \\geq \\frac{c}{2} 1_{\\Omega^c} 1_E;", block: true)]]

#text("squaring this and taking conditional expectations we obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("{\\Bbb E}(\\left|f - {\\Bbb E}(f|Y_\\beta)\\right|^2|Y_\\beta)(y) \\geq \\frac{c^2}{4} (1 - {\\Bbb E}(1_{\\Omega}|Y_\\beta)(y)) 1_E(y),", block: true)]]

#text("and so by (10) and Markov’s inequality we see that ")#mi("1 - {\\Bbb E}(1_{\\Omega}|Y_\\beta)(y) 1_E(y)  1-1/k")#text(" on a set of positive measure. The claim now follows from Proposition 2. ")#mi("\\Box")

#text("The proof of the Furstenberg recurrence theorem (and thus Szemerédi’s theorem) is finally complete.")

#strong[#text("Remark 3.")]#text(" The same type of argument yields many further recurrence theorems, and thus (by the correspondence principle) many combinatorial results also. For instance, in the original paper ")#link("http://www.ams.org/mathscinet-getitem?mr=498471")[#text("of Furstenberg")]#text(" it was noted that the above arguments allow one to strengthen (1) to")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\liminf_{N \\to \\infty} \\inf_M \\frac{1}{N} \\sum_{n=M}^{M+N-1} \\int_X f T^n f \\ldots T^{(k-1)n} f\\ d\\mu > 0,")]]

#text("which allows one to conclude that in a set A of positive upper density, the set of n for which ")#mi("A \\cap (A+n) \\cap \\ldots \\cap (A+(k-1)n)")#text(" has positive upper density is syndetic for every k. One can also extend the argument to higher dimensions, and to polynomial recurrence without too many changes in the structure of the proof. But some more serious modifications to the argument are needed for other recurrence results involving IP systems or Hales-Jewett type results; see ")#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/")[#text("Lecture 10")]#text(" for more discussion. ")#mi("\\diamond")

#text("[")#emph[#text("Update")]#text(", Mar 6: Statement of Proposition 1 corrected.]")

#text("o")

#heading(level: 1)[#text("Comments (17)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c6953ab4425d109767a7eef3ecc7c8cf8d944a87ec5e2a502981e671d9cc1a-1d73f6869dd4b3f2691c3f1f37c65f3584e7eca39cd73c5b09d3068e6ab0d958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior")]], [#link("https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/#comment-26983")[#strong[#text("Lior")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2008")])]

#text("In the statement of Prop 1, ")#mi("1/k")#text(" should be ")#mi("1-1/k")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/#comment-26986")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2008")])]

#text("Dear Lior: thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 陶哲轩遍历论：第十五讲 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/#comment-34766")[#strong[#text("陶哲轩遍历论：第十五讲 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2009")])]

#text("[…] (注：遍历论为陶哲轩教授于今年年初的一门课程，我尝试将所有习题做出来，这是第十五讲的唯一一个习题，就是Zorn引理的使用。这里是本讲的链接。) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73196101058b01a7b5178a5c0b1eb30a5a176e3bc57a7a26d1c49d8e30671304-bab8ee688d0d5fd8fe52d477c3e3eff98ad07799efeccc22e05aee131831a8eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nate Chandler")]], [#link("https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/#comment-34768")[#strong[#text("Nate Chandler")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2009")])]

#text("Just a small correction: In the second paragraph, you wrote “In Theorem 2 of the previous lecture, we showed that X was not a weakly mixing extension of Y, then we could find a non-trivial compact extension Z of Y”. I think you meant “In Theorem 2 of the previous lecture, we showed that if X was not a weakly mixing extension of Y, then we could find a non-trivial compact extension Z of Y”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/#comment-34777")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2009")])]

#text("Dear Professor:")

#text("In the left hand side of (12), if the expectation is taken with respect to ")#mi("Y_\\beta")#text(", then ")#tao-math("{\\Bbb E}(\\left|f - {\\Bbb E}(f|Y_\\beta)\\right|^2|Y_{\\beta})(y)", block: false)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/#comment-34782")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2009")])]

#text("Thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/#comment-43743")[#strong[#text("ERT8: Weak Mixing Systems « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2010")]

#text("[…] denote this by and is called a factor of . Theorem 1 (Furstenberg structural theorem) Given a mps , there exists an ordinal and a family of factors of , for every , such […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/#comment-52148")[#strong[#text("ERT16: Compact extensions « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2011")]

#text("[…] when looked through the spectral lenses. It is a matter of fact that this dichotomy turns Furstenberg-Zimmer structural theorem direct, as we’ll prove in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Furstenberg multiple recurrence theorem and finite extensions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/#comment-53438")[#strong[#text("The Furstenberg multiple recurrence theorem and finite extensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2011")])]

#text("[…] as a consequence of the Furstenberg-Zimmer structure theorem for measure-preserving systems. See these lecture notes for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An abstract ergodic theorem, and the Mackey-Zimmer theorem | What's new")]], [#link("https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/#comment-376244")[#strong[#text("An abstract ergodic theorem, and the Mackey-Zimmer theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2014")])]

#text("[…] measure-preserving systems (as well as subsequent refinements of this theory by Host and Kra); see this previous blog post for some relevant discussion. One can obtain similar descriptions of non-ergodic extensions via the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ed500379cf83ffe977b8582db8962b7fcda59cce8bd59e91ffb1ac5fc6d3a5-4269aa430367dac1db38a63e09e1b4959efdf42fca781fb13cfc99d9ec98ded4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yaoxiao")]], [#link("https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/#comment-479751")[#strong[#text("yaoxiao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2017")])]

#text("Dear professor Tao,")#linebreak()#text(" by (10) and markov inequality, ")#mi("1-E(1_{\\Omega}|Y)(y)1_{E}(y)<\\frac{1}{k}")#text(" on a set of ")#mi("O_{c}(\\epsilon)")#text(", did you here mean that out a set of … Thanks!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/#comment-513845")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2019")])]

#text("Dear Prof. Tao,")

#text("I’d really appreciate an answer to this question, and I hope that the question is sufficiently non-stupid. I’m not yet done with the proof of the Furstenberg recurrence theorem, but I noticed that in some way it was a bit similar to the proof of von Neumann’s theorem, that is to say, the first proof that was given in your book. Namely, we decompose a space into two types of elements which behave contrary to each other.")

#text("Hence, I have been asking myself whether it might be possible to generalise the Furstenberg recurrence to a Hilbert space setting, where the Integral might be replaced by some sort of scalar products against Dirac measures. (A more plausible, yet less far-reaching generalisation might be given by replacing the shift map of a dynamical system by an operator on a suitable ")#mi("L^2")#text(" space, perhaps a space given by Bochner integrable functions.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/#comment-513965")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2019")])]

#text("The Furstenberg recurrence theorem requires the ability to take higher order correlations ")#mi("\\int_X f_1 \\dots f_k\\ d\\mu")#text(" of ")#mi("k")#text(" different functions with ")#mi("k")#text(" potentially larger than 2; a Hilbert space structure only gives ")#mi("k=2")#text(" correlations and so it does not seem possible to even phrase the Furstenberg recurrence theorem in purely Hilbert space-theoretic terms, let alone prove it. (On the other hand, higher order Hilbert spaces can be used to at least describe the closely related concept of a Gowers-Host-Kra seminorm; see ")#link("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/")[#text("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/")]#text(" ).")

#text("One natural abstract framework to describe these recurrence theorems is that of commutative tracial von Neumann algebras. One can then try to extend these theorems to the noncommutative case, but unfortunately the theorems largely break down in that case: ")#link("https://terrytao.wordpress.com/2009/12/29/nonconventional-ergodic-averages-and-multiple-recurrence-for-von-neumann-dynamical-systems/")[#text("https://terrytao.wordpress.com/2009/12/29/nonconventional-ergodic-averages-and-multiple-recurrence-for-von-neumann-dynamical-systems/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/#comment-513968")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2019")])]

#text("Thanks a lot for your reply. I had questioned myself about whether there is a space that admits “pair”ings of any order, and whether such a concept would (at least given a higher cardinality) be a generalisation of some additional spaces (which would have to be found). Perhaps an appropriate generalisation would require the given forms to satisfy some consistency conditions. These are just random ideas; when I have time, I’ll give it more thought.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/#comment-513969")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2019")])]

#text("In particular, the negative examples Prof. Tao gave jointly with Austin and Eisner prove that one would have to choose one’s category in a way that excludes the non-commutative systems Prof. Tao referred to.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5b9e294b7817298da0041801ad7580b05be211d36bbe9ff4737b92334e9ed70-e3c8a64fc288043c161f682465f9344ce7458fb0b0bc6a14ad4724f240e360ab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YV")]], [#link("https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/#comment-669760")[#strong[#text("YV")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2022")])]

#text("Hi, thank you for this proof!")#linebreak()#text(" I have one question.")#linebreak()#text(" Can you elaborate on why the ordinal \\alpha you mentioned in the structure theorem must be at most countable?")

#text("Thanks in advanced")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/#comment-669802")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2022")])]

#text("If there is an increasing set ")#mi("H_\\beta, \\beta < \\alpha")#text(" of strictly increasing Hilbert subspaces")#linebreak()#text(" of ")#mi("H")#text(" indexed by an uncountable ordinal ")#mi("\\alpha")#text(" then the Hilbert space ")#mi("H")#text(" has an uncountable orthonormal basis (formed by choosing an orthonormal basis for each ")#mi("H_\\beta \\ominus \\bigcup_{\\gamma < \\beta} H_\\gamma")#text(", which is non-trivial for successor ordinals ")#mi("\\beta")#text("). So if ")#mi("H")#text(" is separable it can only admit a countable tower of such spaces.")

#text("inside a separable Hilbert space ")#mi("H")#text(" then")
]
]
