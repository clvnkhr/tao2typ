// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/09/18/undecidability-of-translational-monotilings/
// Converted to Typst by tao2typ: "2026-10-14T11:10:50.147092+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Undecidability of translational monotilings", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Undecidability of translational monotilings")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 September 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/09/18/undecidability-of-translational-monotilings/")[#text("https://terrytao.wordpress.com/2023/09/18/undecidability-of-translational-monotilings/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("https://www.math.ias.edu/~rgreenfeld/")[#text("Rachel Greenfeld")]#text(" and I have just uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/2309.09504")[#text("Undecidability of translational monotilings")]#text("“. This is a sequel to ")#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/")[#text("our previous paper")]#text(" in which we constructed a translational monotiling ")#mi("{A \\oplus F = {\\bf Z}^d}")#text(" of a high-dimensional lattice ")#mi("{{\\bf Z}^d}")#text(" (thus the monotile ")#mi("{F}")#text(" is a finite set and the translates ")#mi("{a+F}")#text(", ")#mi("{a \\in A}")#text(" of ")#mi("{F}")#text(" partition ")#mi("{{\\bf Z}^d}")#text(") which was aperiodic (there is no way to “repair” this tiling into a periodic tiling ")#mi("{A^{\\prime} \\oplus F = {\\bf Z}^d}")#text(", in which ")#mi("{A^{\\prime}}")#text(" is now periodic with respect to a finite index subgroup of ")#mi("{{\\bf Z}^d}")#text("). This disproved the periodic tiling conjecture of ")#link("https://zbmath.org/0284.20048")[#text("Stein")]#text(", ")#link("https://zbmath.org/0746.52001")[#text("Grunbaum-Shephard")]#text(" and ")#link("https://zbmath.org/0847.05037")[#text("Lagarias-Wang")]#text(", which asserted that such aperiodic translational monotilings do not exist. (Compare with the “")#link("https://arxiv.org/abs/2303.10798")[#text("hat monotile")]#text("“, which is a recently discovered aperiodic isometric monotile for of ")#mi("{{\\bf R}^2}")#text(", where one is now allowed to use rotations and reflections as well as translations, or the even more recent “")#link("https://arxiv.org/abs/2305.17743")[#text("spectre monotile")]#text("“, which is similar except that no reflections are needed.)")

#text("One of the motivations of this conjecture was the observation of ")#link("https://zbmath.org/0137.01001")[#text("Hao Wang")]#text(" that if the periodic tiling conjecture were true, then the translational monotiling problem is (algorithmically) decidable: there is a Turing machine which, when given a dimension ")#mi("{d}")#text(" and a finite subset ")#mi("{F}")#text(" of ")#mi("{{\\bf Z}^d}")#text(", can determine in finite time whether ")#mi("{F}")#text(" can tile ")#mi("{{\\bf Z}^d}")#text(". This is because if a periodic tiling exists, it can be found by computer search; and if no tiling exists at all, then (by the compactness theorem) there exists some finite subset of ")#mi("{{\\bf Z}^d}")#text(" that cannot be covered by disjoint translates of ")#mi("{F}")#text(", and this can also be discovered by computer search. The periodic tiling conjecture asserts that these are the only two possible scenarios, thus giving the decidability.")

#text("On the other hand, Wang’s argument is not known to be reversible: the failure of the periodic tiling conjecture does not automatically imply the undecidability of the translational monotiling problem, as it does not rule out the existence of some other algorithm to determine tiling that does not rely on the existence of a periodic tiling. (For instance, even with the newly discovered hat and spectre tiles, it remains an open question whether the isometric monotiling problem for (say) polygons with rational coefficients in ")#mi("{{\\bf R}^2}")#text(" is decidable, with or without reflections.)")

#text("The main result of this paper settles this question (with one caveat):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" There does not exist any algorithm which, given a dimension ")#mi("{d}")#text(", a periodic subset ")#mi("{E}")#text(" of ")#mi("{{\\bf Z}^d}")#text(", and a finite subset ")#mi("{F}")#text(" of ")#mi("{{\\bf Z}^d}")#text(", determines in finite time whether there is a translational tiling ")#mi("{A \\oplus F = E}")#text(" of ")#mi("{E}")#text(" by ")#mi("{F}")#text(".")
]

#text("The caveat is that we have to work with periodic subsets ")#mi("{E}")#text(" of ")#mi("{{\\bf Z}^d}")#text(", rather than all of ")#mi("{{\\bf Z}^d}")#text("; we believe this is largely a technical restriction of our method, and it is likely that can be removed with additional effort and creativity. We also remark that when ")#mi("{d=2}")#text(", the periodic tiling conjecture was established ")#link("https://zbmath.org/1454.11125")[#text("by Bhattacharya")]#text(", and so the problem is decidable in the ")#mi("{d=2}")#text(" case. It remains open whether the tiling problem is decidable for any ")#emph[#text("fixed")]#text(" value of ")#mi("{d>2}")#text(" (note in the above result that the dimension ")#mi("{d}")#text(" is not fixed, but is part of the input).")

#text("Because of a well known link between algorithmic undecidability and logical undecidability (also known as ")#link("https://en.wikipedia.org/wiki/Independence_(mathematical_logic)")[#text("logical independence")]#text("), the main theorem also implies the existence of an (in principle explicitly describable) dimension ")#mi("{d}")#text(", periodic subset ")#mi("{E}")#text(" of ")#mi("{{\\bf Z}^d}")#text(", and a finite subset ")#mi("{F}")#text(" of ")#mi("{{\\bf Z}^d}")#text(", such that the assertion that ")#mi("{F}")#text(" tiles ")#mi("{E}")#text(" by translation cannot be proven or disproven in ZFC set theory (assuming of course that this theory is consistent).")

#text("As a consequence of our method, we can also replace ")#mi("{{\\bf Z}^d}")#text(" here by “virtually two-dimensional” groups ")#mi("{{\\bf Z}^2 \\times G_0}")#text(", with ")#mi("{G_0}")#text(" a finite abelian group (which now becomes part of the input, in place of the dimension ")#mi("{d}")#text(").")

#text("We now describe some of the main ideas of the proof. It is a common technique to show that a given problem is undecidable by demonstrating that some other problem that was already known to be undecidable can be “encoded” within the original problem, so that any algorithm for deciding the original problem would also decide the embedded problem. Accordingly, we will encode the ")#link("https://en.wikipedia.org/wiki/Wang_tile")[#text("Wang tiling problem")]#text(" as a monotiling problem in ")#mi("{{\\bf Z}^d}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 2 (Wang tiling problem)")]#text(" Given a finite collection ")#mi("{{\\mathcal W}}")#text(" of Wang tiles (unit squares with each side assigned some color from a finite palette), is it possible to tile the plane with translates of these tiles along the standard lattice ")#mi("{{\\bf Z}^2}")#text(", such that adjacent tiles have matching colors along their common edge?")
]

#text("It is a famous ")#link("https://zbmath.org/0199.30802")[#text("result of Berger")]#text(" that this problem is undecidable. The embedding of this problem into the higher-dimensional translational monotiling problem proceeds through some intermediate problems. Firstly, it is an easy matter to embed the Wang tiling problem into a similar problem which we call the ")#emph[#text("domino problem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 3 (Domino problem)")]#text(" Given a finite collection ")#mi("{{\\mathcal R}_1}")#text(" (resp. ")#mi("{{\\mathcal R}_2}")#text(") of horizontal (resp. vertical) dominoes – pairs of adjacent unit squares, each of which is decorated with an element of a finite set ")#mi("{{\\mathcal W}}")#text(" of “pips”, is it possible to assign a pip to each unit square in the standard lattice tiling of ")#mi("{{\\bf Z}^2}")#text(", such that every horizontal (resp. vertical) pair of squares in this tiling is decorated using a domino from ")#mi("{{\\mathcal R}_1}")#text(" (resp. ")#mi("{{\\mathcal R}_2}")#text(")?")
]

#text("Indeed, one just has to interpet each Wang tile as a separate “pip”, and define the domino sets ")#mi("{{\\mathcal R}_1}")#text(", ")#mi("{{\\mathcal R}_2}")#text(" to be the pairs of horizontally or vertically adjacent Wang tiles with matching colors along their edge.")

#text("Next, we embed the domino problem into a ")#emph[#text("Sudoku problem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 4 (Sudoku problem)")]#text(" Given a column width ")#mi("{N}")#text(", a digit set ")#mi("{\\Sigma}")#text(", a collection ")#mi("{{\\mathcal S}}")#text(" of functions ")#mi("{g: \\{0,\\dots,N-1\\} \\rightarrow \\Sigma}")#text(", and an “initial condition” ")#mi("{{\\mathcal C}}")#text(" (which we will not detail here, as it is a little technical), is it possible to assign a digit ")#mi("{F(n,m)}")#text(" to each cell ")#mi("{(n,m)}")#text(" in the “Sudoku board” ")#mi("{\\{0,1,\\dots,N-1\\} \\times {\\bf Z}}")#text(" such that for any slope ")#mi("{j \\in {\\bf Z}}")#text(" and intercept ")#mi("{i \\in {\\bf Z}}")#text(", the digits ")#mi("{n \\mapsto F(n,jn+i)}")#text(" along the line ")#mi("{\\{(n,jn+i): 0 \\leq n \\leq N-1\\}}")#text(" lie in ")#mi("{{\\mathcal S}}")#text(" (and also that ")#mi("{F}")#text(" obeys the initial condition ")#mi("{{\\mathcal C}}")#text(")?")
]

#text("The most novel part of the paper is the demonstration that the domino problem can indeed be embedded into the Sudoku problem. The embedding of the Sudoku problem into the monotiling problem follows from a modification of the methods in ")#link("https://terrytao.wordpress.com/2021/08/19/undecidable-translational-tilings-with-only-two-tiles-or-one-nonabelian-tile/")[#text("our previous")]#text(" ")#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/")[#text("papers")]#text(", which had also introduced versions of the Sudoku problem, and created a “tiling language” which could be used to “program” various problems, including the Sudoku problem, as monotiling problems.")

#text("To encode the domino problem into the Sudoku problem, we need to take a domino function ")#mi("{{\\mathcal T}: {\\bf Z}^2 \\rightarrow {\\mathcal W}}")#text(" (obeying the domino constraints associated to some domino sets ")#mi("{{\\mathcal R}_1, {\\mathcal R}_2}")#text(") and use it to build a Sudoku function ")#mi("{F: \\{0,\\dots,N-1\\} \\times {\\bf Z} \\rightarrow \\Sigma}")#text(" (obeying some Sudoku constraints relating to the domino sets); conversely, every Sudoku function obeying the rules of our Sudoku puzzle has to arise somehow from a domino function. The route to doing so was not immediately obvious, but after a helpful tip from ")#link("https://members.loria.fr/EJeandel/")[#text("Emmanuel Jeandel")]#text(", we were able to adapt some ideas ")#link("https://zbmath.org/0301.02042")[#text("of Aanderaa and Lewis")]#text(", in which certain hierarchical structures were used to encode one problem in another. Here, we interpret hierarchical structure ")#mi("{p}")#text("-adically (using two different primes due to the two-dimensionality of the domino problem). The Sudoku function ")#mi("{F}")#text(" that will exemplify our embedding is then built from ")#mi("{{\\mathcal T}}")#text(" by the formula ")#metadata(none) <tao-8451636a4d9089990fc3>

#mi("\\displaystyle  F(n,m) := ( f_{p_1}(m), f_{p_2}(m), {\\mathcal T}(\\nu_{p_1}(m), \\nu_{p_2}(m)) ) \\ \\ \\ \\ \\ (1)")#text(" ")#text(" where ")#mi("{p_1,p_2}")#text(" are two large distinct primes (for instance one can take ")#mi("{p_1=53}")#text(", ")#mi("{p_2=59}")#text(" for concreteness), ")#mi("{\\nu_p(m)}")#text(" denotes the number of times ")#mi("{p}")#text(" divides ")#mi("{m}")#text(", and ")#mi("{f_p(m) \\in {\\bf Z}/p{\\bf Z} \\backslash \\{0\\}}")#text(" is the last non-zero digit in the base ")#mi("{p}")#text(" expansion of ")#mi("{m}")#text(":")

#mi("\\displaystyle  f_p(m) := \\frac{m}{p^{\\nu_p(m)}} \\text{ mod } p")#text(" (with the conventions ")#mi("{\\nu_p(0)=+\\infty}")#text(" and ")#mi("{f_p(0)=1}")#text("). In the case ")#mi("{p_1=3, p_2=5}")#text(", the first component of ")#link(<tao-8451636a4d9089990fc3>)[#text("(1)")]#text(" looks like this:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/09/p3.png")[#image("../assets/9e9308a53a6d84e0860d3a0545dc144746dc1ed4cebba3b9ead47adf7e640f8a-98ecb4e8791a0d1d994807de2a800a5a38c6047a0b4d0404984dc2f485abad81.png", width: 90%)]
]

#text("and a typical instance of the final component ")#mi("{{\\mathcal T}(\\nu_{p_1}(m), \\nu_{p_2}(m))}")#text(" looks like this:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/09/domino.png")[#image("../assets/9f0f89dfb1908a9547772c62917e9d16887faed920e64d5199795870894dc3a5-21d508df60b7a9f70fb3f0a4531025c84e53f376524341931a15525327317c8b.png", width: 90%)]
]

#text("Amusingly, the decoration here is essentially following the rules of the children’s game “")#link("https://en.wikipedia.org/wiki/Fizz_buzz")[#text("Fizz buzz")]#text("“.")

#text("To demonstrate the embedding, we thus need to produce a specific Sudoku rule ")#mi("{{\\mathcal S}}")#text(" (as well as a more technical initial condition ")#mi("{{\\mathcal C}}")#text(", which is basically required to exclude degenerate Sudoku solutions such as a constant solution) that can “capture” the target function ")#link(<tao-8451636a4d9089990fc3>)[#text("(1)")]#text(", in the sense that the only solutions to this specific Sudoku puzzle are given by variants of ")#mi("{F}")#text(" (e.g., ")#mi("{F}")#text(" composed with various linear transformations). In ")#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/")[#text("our previous paper")]#text(" we were able to build a Sudoku puzzle that could similarly capture either of the first two components ")#mi("{f_{p_1}(m)}")#text(", ")#mi("{f_{p_2}(m)}")#text(" of our target function ")#link(<tao-8451636a4d9089990fc3>)[#text("(1)")]#text(" (up to linear transformations), by a procedure very akin to solving an actual Sudoku puzzle (combined with iterative use of a “Tetris” move in which we eliminate rows of the puzzle that we have fully solved, to focus on the remaining unsolved rows). Our previous paper treated the case when ")#mi("{p}")#text(" was replaced with a power of ")#mi("{2}")#text(", as this was the only case that we know how to embed in a monotiling problem of the entirety of ")#mi("{{\\bf Z}^d}")#text(" (as opposed to a periodic subset ")#mi("{E}")#text(" of ")#mi("{{\\bf Z}^d}")#text("), but the analysis is in fact easier when ")#mi("{p}")#text(" is a large odd prime, instead of a power of ")#mi("{2}")#text(". Once the first two components ")#mi("{f_{p_1}(m), f_{p_2}(m)}")#text(" have been solved for, it is a relatively routine matter to design an additional constraint in the Sudoku rule that then constrains the third component to be of the desired form ")#mi("{{\\mathcal T}(\\nu_{p_1}(m), \\nu_{p_2}(m))}")#text(", with ")#mi("{{\\mathcal T}}")#text(" obeying the domino constraints.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/18/undecidability-of-translational-monotilings/#comment-681829")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2023")])]

#text("Wow, very very interesting!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/18/undecidability-of-translational-monotilings/#comment-681830")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2023")])]

#text("Terry, I’m sure you did this as a joke referencing the famous Grothendieck story, but (page 27) 57 is not prime.")

#emph[#text("[That’s hilarious! It will be fixed in the next revision of the ms. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/18/undecidability-of-translational-monotilings/#comment-685557")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2024")])]

#text("After Weyl and Grothendieck, Terry wants to claim 57 to be his prime!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/18/undecidability-of-translational-monotilings/#comment-681831")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2023")])]

#text("Very intesting work!")

#text("Concerning the paragraph about logical independence, might there be some possibility to work out special cases by fixing the side lengths of E and the cardinality of F ti zstimatz the corresponding d?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/18/undecidability-of-translational-monotilings/#comment-681853")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2023")])]

#text("Professor Tao, could you address the importance of tiling problems to other areas of mathematics?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/09/18/undecidability-of-translational-monotilings/#comment-684514")[#strong[#text("陶哲轩再逼近60年几何学难题！周期性密铺问题又获新突破")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2024")]

#text("[…] Undecidability of translational monotilings […]")
]
