// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/
// Converted to Typst by tao2typ: "2026-10-14T16:36:14.226759+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The uncertainty principle", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The uncertainty principle")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 June 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/")[#text("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A recurring theme in mathematics is that of ")#emph[#text("duality")]#text(": a mathematical object ")#mi("{X}")#text(" can either be described ")#emph[#text("internally")]#text(" (or in ")#emph[#text("physical space")]#text(", or ")#emph[#text("locally")]#text("), by describing what ")#mi("{X}")#text(" physically consists of (or what kind of maps exist ")#emph[#text("into")]#text(" ")#mi("{X}")#text("), or ")#emph[#text("externally")]#text(" (or in ")#emph[#text("frequency space")]#text(", or ")#emph[#text("globally")]#text("), by describing what ")#mi("{X}")#text(" globally interacts or resonates with (or what kind of maps exist ")#emph[#text("out of")]#text(" ")#mi("{X}")#text("). These two fundamentally opposed perspectives on the object ")#mi("{X}")#text(" are often ")#emph[#text("dual")]#text(" to each other in various ways: performing an operation on ")#mi("{X}")#text(" may transform it one way in physical space, but in a dual way in frequency space, with the frequency space description often being a “inversion” of the physical space description. In several important cases, one is fortunate enough to have some sort of ")#emph[#text("fundamental theorem")]#text(" connecting the internal and external perspectives. Here are some (closely inter-related) examples of this perspective:")

#enum(start: 1, 
[#strong[#text("Vector space duality")]#text(" A vector space ")#mi("{V}")#text(" over a field ")#mi("{F}")#text(" can be described either by the set of vectors inside ")#mi("{V}")#text(", or dually by the set of linear functionals ")#mi("{\\lambda: V \\rightarrow F}")#text(" from ")#mi("{V}")#text(" to the field ")#mi("{F}")#text(" (or equivalently, the set of vectors inside the dual space ")#mi("{V^*}")#text("). (If one is working in the category of topological vector spaces, one would work instead with continuous linear functionals; and so forth.) A fundamental connection between the two is given by the ")#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/")[#text("Hahn-Banach theorem")]#text(" (and its relatives).")],
[#strong[#text("Vector subspace duality")]#text(" In a similar spirit, a subspace ")#mi("{W}")#text(" of ")#mi("{V}")#text(" can be described either by listing a basis or a spanning set, or dually by a list of linear functionals that cut out that subspace (i.e. a spanning set for the orthogonal complement ")#mi("{W^\\perp := \\{ \\lambda \\in V^*: \\lambda(w)=0 \\text{ for all } w \\in W \\})}")#text(". Again, the Hahn-Banach theorem provides a fundamental connection between the two perspectives.")],
[#strong[#text("Convex duality")]#text(" More generally, a (closed, bounded) convex body ")#mi("{K}")#text(" in a vector space ")#mi("{V}")#text(" can be described either by listing a set of (extreme) points whose convex hull is ")#mi("{K}")#text(", or else by listing a set of (irreducible) linear inequalities that cut out ")#mi("{K}")#text(". The fundamental connection between the two is given by the ")#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/")[#text("Farkas lemma")]#text(".")],
[#strong[#text("Ideal-variety duality")]#text(" In a slightly different direction, an algebraic variety ")#mi("{V}")#text(" in an affine space ")#mi("{A^n}")#text(" can be viewed either “in physical space” or “internally” as a collection of points in ")#mi("{V}")#text(", or else “in frequency space” or “externally” as a collection of polynomials on ")#mi("{A^n}")#text(" whose simultaneous zero locus cuts out ")#mi("{V}")#text(". The fundamental connection between the two perspectives is given by the ")#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/")[#text("nullstellensatz")]#text(", which then leads to many of the basic fundamental theorems in classical algebraic geometry.")],
[#strong[#text("Hilbert space duality")]#text(" An element ")#mi("{v}")#text(" in a Hilbert space ")#mi("{H}")#text(" can either be thought of in physical space as a ")#emph[#text("vector")]#text(" in that space, or in momentum space as a ")#emph[#text("covector")]#text(" ")#mi("{w \\mapsto \\langle v, w \\rangle}")#text(" on that space. The fundamental connection between the two is given by the ")#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/")[#text("Riesz representation theorem for Hilbert spaces")]#text(".")],
[#strong[#text("Semantic-syntactic duality")]#text(" Much more generally still, a mathematical theory can either be described ")#emph[#text("internally")]#text(" or ")#emph[#text("syntactically")]#text(" via its axioms and theorems, or ")#emph[#text("externally")]#text(" or ")#emph[#text("semantically")]#text(" via its models. The fundamental connection between the two perspectives is given by the ")#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/")[#text("Gödel completeness theorem")]#text(".")],
[#strong[#text("Intrinsic-extrinsic duality")]#text(" A (Riemannian) manifold ")#mi("{M}")#text(" can either be viewed intrinsically (using only concepts that do not require an ambient space, such as the ")#link("http://en.wikipedia.org/wiki/Levi-Civita_connection")[#text("Levi-Civita connection")]#text("), or extrinsically, for instance as the level set of some defining function in an ambient space. Some important connections between the two perspectives includes the ")#link("http://en.wikipedia.org/wiki/Nash_embedding_theorem")[#text("Nash embedding theorem")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Theorema_Egregium")[#text("theorema egregium")]#text(".")],
[#strong[#text("Group duality")]#text(" A group ")#mi("{G}")#text(" can be described either via ")#emph[#text("presentations")]#text(" (lists of generators, together with relations between them) or ")#emph[#text("representations")]#text(" (realisations of that group in some more concrete group of transformations). A fundamental connection between the two is ")#link("http://en.wikipedia.org/wiki/Cayley's_theorem")[#text("Cayley’s theorem")]#text(". Unfortunately, in general it is difficult to build upon this connection (except in special cases, such as the abelian case), and one cannot always pass effortlessly from one perspective to the other.")],
[#strong[#text("Pontryagin group duality")]#text(" A (locally compact Hausdorff) ")#emph[#text("abelian")]#text(" group ")#mi("{G}")#text(" can be described either by listing its elements ")#mi("{g \\in G}")#text(", or by listing the ")#emph[#text("characters")]#text(" ")#mi("{\\chi: G \\rightarrow {\\bf R}/{\\bf Z}}")#text(" (i.e. continuous homomorphisms from ")#mi("{G}")#text(" to the unit circle, or equivalently elements of ")#mi("{\\hat G}")#text("). The connection between the two is the focus of ")#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")[#text("abstract harmonic analysis")]#text(".")],
[#strong[#text("Pontryagin subgroup duality")]#text(" A subgroup ")#mi("{H}")#text(" of a locally compact abelian group ")#mi("{G}")#text(" can be described either by generators in ")#mi("{H}")#text(", or generators in the orthogonal complement ")#mi("{H^\\perp := \\{ \\xi \\in \\hat G: \\xi \\cdot h = 0 \\text{ for all } h \\in H \\}}")#text(". One of the fundamental connections between the two is the ")#link("http://en.wikipedia.org/wiki/Poisson_summation_formula")[#text("Poisson summation formula")]#text(".")],
[#strong[#text("Fourier duality")]#text(" A (sufficiently nice) function ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" on a locally compact abelian group ")#mi("{G}")#text(" (equipped with a Haar measure ")#mi("{\\mu}")#text(") can either be described in physical space (by its values ")#mi("{f(x)}")#text(" at each element ")#mi("{x}")#text(" of ")#mi("{G}")#text(") or in frequency space (by the values ")#mi("{\\hat f(\\xi) = \\int_G f(x) e( - \\xi \\cdot x )\\ d\\mu(x)}")#text(" at elements ")#mi("{\\xi}")#text(" of the Pontryagin dual ")#mi("{\\hat G}")#text("). The fundamental connection between the two is the ")#link("http://en.wikipedia.org/wiki/Fourier_inversion_theorem")[#text("Fourier inversion formula")]#text(".")],
[#strong[#text("The uncertainty principle")]#text(" The behaviour of a function ")#mi("{f}")#text(" at physical scales above (resp. below) a certain scale ")#mi("{R}")#text(" is almost completely controlled by the behaviour of its Fourier transform ")#mi("{\\hat f}")#text(" at frequency scales below (resp. above) the dual scale ")#mi("{1/R}")#text(" and vice versa, thanks to various mathematical manifestations of the ")#link("http://en.wikipedia.org/wiki/Uncertainty_principle")[#text("uncertainty principle")]#text(". (The Poisson summation formula can also be viewed as a variant of this principle, using subgroups instead of scales.)")],
[#strong[#text("Stone/Gelfand duality")]#text(" A (locally compact Hausdorff) topological space ")#mi("{X}")#text(" can be viewed in physical space (as a collection of points), or dually, via the ")#mi("{C^*}")#text(" algebra ")#mi("{C(X)}")#text(" of continuous complex-valued functions on that space, or (in the case when ")#mi("{X}")#text(" is compact and totally disconnected) via the boolean algebra of clopen sets (or equivalently, the idempotents of ")#mi("{C(X)}")#text("). The fundamental connection between the two is given by the ")#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/")[#text("Stone representation theorem")]#text(" or the (commutative) ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("Gelfand-Naimark theorem")]#text(".")]
)

#text("I have discussed a fair number of these examples in previous blog posts (indeed, most of the links above are to my own blog). In this post, I would like to discuss the ")#emph[#text("uncertainty principle")]#text(", that describes the dual relationship between physical space and frequency space. There are various concrete formalisations of this principle, most famously the ")#link("http://en.wikipedia.org/wiki/Heisenberg_uncertainty_principle")[#text("Heisenberg uncertainty principle")]#text(" and the ")#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/")[#text("Hardy uncertainty principle")]#text(" – but in many situations, it is the ")#emph[#text("heuristic")]#text(" formulation of the principle that is more useful and insightful than any particular rigorous theorem that attempts to capture that principle. Unfortunately, it is a bit tricky to formulate this heuristic in a succinct way that covers all the various applications of that principle; the Heisenberg inequality ")#mi("{\\Delta x \\cdot \\Delta \\xi \\gtrsim 1}")#text(" is a good start, but it only captures a portion of what the principle tells us. Consider for instance the following (deliberately vague) statements, each of which can be viewed (heuristically, at least) as a manifestation of the uncertainty principle:")

#enum(start: 1, 
[#text("A function which is band-limited (restricted to low frequencies) is featureless and smooth at fine scales, but can be oscillatory (i.e. containing plenty of cancellation) at coarse scales. Conversely, a function which is smooth at fine scales will be almost entirely restricted to low frequencies.")],
[#text("A function which is restricted to high frequencies is oscillatory at fine scales, but is negligible at coarse scales. Conversely, a function which is oscillatory at fine scales will be almost entirely restricted to high frequencies.")],
[#text("Projecting a function to low frequencies corresponds to averaging out (or spreading out) that function at fine scales, leaving only the coarse scale behaviour.")],
[#text("Projecting a frequency to high frequencies corresponds to removing the averaged coarse scale behaviour, leaving only the fine scale oscillation.")],
[#text("The number of degrees of freedom of a function is bounded by the product of its spatial uncertainty and its frequency uncertainty (or more generally, by the volume of the phase space uncertainty). In particular, there are not enough degrees of freedom for a non-trivial function to be simulatenously localised to both very fine scales and very low frequencies.")],
[#text("To control the coarse scale (or global) averaged behaviour of a function, one essentially only needs to know the low frequency components of the function (and vice versa).")],
[#text("To control the fine scale (or local) oscillation of a function, one only needs to know the high frequency components of the function (and vice versa).")],
[#text("Localising a function to a region of physical space will cause its Fourier transform (or inverse Fourier transform) to resemble a plane wave on every dual region of frequency space.")],
[#text("Averaging a function along certain spatial directions or at certain scales will cause the Fourier transform to become localised to the dual directions and scales. The smoother the averaging, the sharper the localisation.")],
[#text("The smoother a function is, the more rapidly decreasing its Fourier transform (or inverse Fourier transform) is (and vice versa).")],
[#text("If a function is smooth or almost constant in certain directions or at certain scales, then its Fourier transform (or inverse Fourier transform) will decay away from the dual directions or beyond the dual scales.")],
[#text("If a function has a singularity spanning certain directions or certain scales, then its Fourier transform (or inverse Fourier transform) will decay slowly along the dual directions or within the dual scales.")],
[#text("Localisation operations in position approximately commute with localisation operations in frequency so long as the product of the spatial uncertainty and the frequency uncertainty is significantly larger than one.")],
[#text("In the high frequency (or large scale) limit, position and frequency asymptotically behave like a pair of classical observables, and partial differential equations asymptotically behave like classical ordinary differential equations. At lower frequencies (or finer scales), the former becomes a “quantum mechanical perturbation” of the latter, with the strength of the quantum effects increasing as one moves to increasingly lower frequencies and finer spatial scales.")],
[#text("Etc., etc.")],
[#text("Almost all of the above statements generalise to other locally compact abelian groups than ")#mi("{{\\bf R}}")#text(" or ")#mi("{{\\bf R}^n}")#text(", in which the concept of a direction or scale is replaced by that of a subgroup or an approximate subgroup. (In particular, as we will see below, the Poisson summation formula can be viewed as another manifestation of the uncertainty principle.)")]
)

#text("I think of all of the above (closely related) assertions as being instances of “the uncertainty principle”, but it seems difficult to combine them all into a single unified assertion, even at the heuristic level; they seem to be better arranged as a ")#emph[#text("cloud")]#text(" of tightly interconnected assertions, each of which is reinforced by several of the others. The famous inequality ")#mi("{\\Delta x \\cdot \\Delta \\xi \\gtrsim 1}")#text(" is at the centre of this cloud, but is by no means the only aspect of it.")

#text("The uncertainty principle (as interpreted in the above broad sense) is one of the most fundamental principles in harmonic analysis (and more specifically, to the subfield of ")#emph[#text("time-frequency analysis")]#text("), second only to the Fourier inversion formula (and more generally, ")#link("http://en.wikipedia.org/wiki/Plancherel_theorem")[#text("Plancherel’s theorem")]#text(") in importance; understanding this principle is a key piece of intuition in the subject that one has to internalise before one can really get to grips with this subject (and also with closely related subjects, such as semi-classical analysis and microlocal analysis). Like many fundamental results in mathematics, the principle is not actually that difficult to understand, once one sees how it works; and when one needs to use it rigorously, it is usually not too difficult to improvise a suitable formalisation of the principle for the occasion. But, given how vague this principle is, it is difficult to present this principle in a traditional “theorem-proof-remark” manner. Even in the more informal format of a blog post, I was surprised by how challenging it was to describe my own understanding of this piece of mathematics in a linear fashion, despite (or perhaps because of) it being one of the most central and basic conceptual tools in my own personal mathematical toolbox. In the end, I chose to give below a cloud of interrelated discussions about this principle rather than a linear development of the theory, as this seemed to more closely align with the nature of this principle.")

#metadata(none) <tao-d91d1b4ccc85d1a40d74>

#heading(level: 1)[#strong[#text(" — 1. An informal foundation for the uncertainty principle — ")]]

#text("Many of the manifestations of the uncertainty principle can be heuristically derived from the following informal heuristic:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Heuristic 1 (Phase heuristic)")]#text(" If the phase ")#mi("{\\phi(x)}")#text(" of a complex exponential ")#mi("{e^{2\\pi i \\phi(x)}}")#text(" fluctuates by less than ")#mi("{1}")#text(" for ")#mi("{x}")#text(" in some nice domain ")#mi("{\\Omega}")#text(" (e.g. a convex set, or more generally an approximate subgroup), then the phase ")#mi("{e^{2\\pi i \\phi(x)}}")#text(" behaves as if it were constant on ")#mi("{\\Omega}")#text(". If instead the phase fluctuates by much more than ")#mi("{1}")#text(", then ")#mi("{e^{2\\pi i \\phi(x)}}")#text(" should oscillate and exhibit significant cancellation. The more the phase fluctuates, the more oscillation and cancellation becomes present.")
]

#text("For instance, according to this heuristic, on an interval ")#mi("{[-R,R]}")#text(" in the real line, the linear phase ")#mi("{x \\mapsto e^{2\\pi i \\xi x}}")#text(" at a given frequency ")#mi("{\\xi \\in {\\bf R}}")#text(" behaves like a constant when ")#tao-math("{\\left|\\xi\\right| \\ll 1/R}", block: false)#text(", but oscillates significantly when ")#tao-math("{\\left|\\xi\\right| \\gg 1/R}", block: false)#text(". This is visually plausible if one graphs the real and imaginary parts ")#mi("{\\cos(2\\pi i \\xi x)}")#text(", ")#mi("{\\sin(2 \\pi i \\xi x)}")#text(". For now, we will take this principle as axiomatic, without further justification, and without further elaboration as to what vague terms such as “behaves as if” or ")#mi("{\\ll}")#text(" mean.")

#text("We remark in passing that, the above heuristic can also be viewed as the informal foundation for the ")#link("http://en.wikipedia.org/wiki/Stationary_phase_approximation")[#text("principle of stationary phase")]#text(". This is not coincidental, but will not be the focus of the discussion here.")

#text("Let’s give a few examples to illustrate how this heuristic informally implies some versions of the uncertainty principle. Suppose for instance that a function ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" is supported in an interval ")#mi("{[-R,R]}")#text(". Now consider the Fourier transform")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) := \\int_{\\bf R} e^{-2\\pi i x\\xi} f(x)\\ dx = \\int_{-R}^R e^{-2\\pi i x \\xi} f(x)\\ dx.")]]

#text("(Other normalisations of the Fourier transform are possible, but this does not significantly affect the discussion here.) We assume that the function is nice enough (e.g. absolutely integrable will certainly suffice) that one can define the Fourier transform without difficulty.")

#text("If ")#tao-math("{\\left|\\xi\\right| \\ll 1/R}", block: false)#text(", then the phase ")#mi("{x\\xi}")#text(" fluctuates by less than ")#mi("{1}")#text(" on the domain ")#mi("{x \\in [-R,R]}")#text(", and so the phase here is essentially constant by the above heuristic; in particular, we expect the Fourier transform ")#mi("{\\hat f(\\xi)}")#text(" to not vary much in this interval. More generally, if we consider frequencies ")#mi("{\\xi}")#text(" in an interval ")#tao-math("{\\left|\\xi-\\xi_0\\right| \\ll 1/R}", block: false)#text(" for a fixed ")#mi("{\\xi_0}")#text(", then on separating ")#mi("{e^{-2\\pi i x \\xi}}")#text(" as ")#mi("{e^{-2\\pi i x \\xi_0} \\times e^{-2\\pi i x (\\xi-\\xi_0)}}")#text(", the latter phase ")#mi("{x (\\xi-\\xi_0)}")#text(" is essentially constant by the above heuristic, and so we expect ")#mi("{\\hat f(\\xi)}")#text(" to not vary much in this interval either. Thus ")#mi("{\\hat f(\\xi)}")#text(" is close to constant at scales much finer than ")#mi("{1/R}")#text(", just as the uncertainty principle predicts.")

#text("A similar heuristic calculation using the Fourier inversion formula")

#align(center)[#tao-fit-display[#mitex("f(x) = \\int_{\\bf R} e^{2\\pi i x\\xi} \\hat f(\\xi)\\ d\\xi")]]

#text("shows that if the Fourier transform ")#mi("{\\hat f(\\xi)}")#text(" is restricted to an interval ")#mi("{[-N, N]}")#text(", then the function ")#mi("{f}")#text(" should behave roughly like a constant at scales ")#mi("{\\ll 1/N}")#text(". A bit more generally, if the Fourier transform is restricted to an interval ")#mi("{[\\xi_0-N, \\xi_0+N]}")#text(", then by separating ")#mi("{e^{2\\pi i x \\xi}}")#text(" as ")#mi("{e^{2\\pi i x_0 \\xi_0} e^{2\\pi i (x-x_0) \\xi} e^{2\\pi i x_0 (\\xi-\\xi_0)} e^{2\\pi i (x-x_0)(\\xi-\\xi_0)}}")#text(" and discarding the last phase when ")#tao-math("{\\left|x-x_0\\right| \\ll 1/N}", block: false)#text(", we see that the function ")#mi("{f}")#text(" behaves like a constant multiple of the plane wave ")#mi("{x \\mapsto e^{2\\pi i x \\xi_0}}")#text(" on each interval ")#tao-math("{\\{ x: \\left|x-x_0\\right| \\ll 1/N \\}}", block: false)#text(" (but it could be a different constant multiple on each such interval).")

#text("The same type of heuristic computation can be carried through in higher dimensions. For instance, if a function ")#mi("{f: {\\bf R}^n \\rightarrow {\\bf C}}")#text(" has Fourier transform supported in some symmetric convex body ")#mi("{\\Omega}")#text(", then one expects ")#mi("{f}")#text(" itself to behave like a constant on any translate ")#mi("{x_0+c\\Omega^*}")#text(" of a small multiple ")#mi("{0 < c \\ll 1}")#text(" of the ")#emph[#text("polar body")]

#align(center)[#tao-fit-display[#tao-math("\\Omega^* := \\{ x \\in {\\bf R}^n: \\left|x \\cdot \\xi\\right| \\leq 1 \\text{ for all } \\xi \\in \\Omega \\}", block: true)]]

#text("of ")#mi("{\\Omega}")#text(".")

#text("An important special case where the above heuristics are in fact exactly rigorous is when one does not work with ")#emph[#text("approximate subgroups")]#text(" such as intervals ")#mi("{[-R,R]}")#text(" or convex bodies ")#mi("{\\Omega}")#text(", but rather with ")#emph[#text("subgroups")]#text(" ")#mi("{H}")#text(" of the ambient (locally compact abelian) group ")#mi("{G}")#text(" that is serving as physical space. Here, of course, we need the general Fourier transform")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) := \\int_G e^{-2\\pi i \\xi \\cdot x} f(x)\\ d\\mu_G(x),")]]

#text("where ")#mi("{\\mu_G}")#text(" is a Haar measure on the locally compact abelian group ")#mi("{G}")#text(", where ")#mi("{\\xi: x \\mapsto \\xi \\cdot x}")#text(" is a continuous homomorphism from ")#mi("{G}")#text(" to ")#mi("{{\\bf R}/{\\bf Z}}")#text(" (and is thus an element of the Pontryagin dual group ")#mi("{\\hat G}")#text("), with Fourier transform given by the inversion formula")

#align(center)[#tao-fit-display[#mitex("f(x) = \\int_{\\hat G} e^{2\\pi i \\xi \\cdot x} \\hat f(\\xi) d\\mu_{\\hat G}(\\xi)")]]

#text("wheere ")#mi("{\\mu_{\\hat G}}")#text(" is the dual Haar measure on ")#mi("{\\hat G}")#text(" (see e.g. ")#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")[#text("my lecture notes")]#text(" for further discussion of this general theory). If ")#mi("{f}")#text(" is supported on a subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" (this may require ")#mi("{f}")#text(" to be a measure rather than a function, if ")#mi("{H}")#text(" is a measure zero subgroup of ")#mi("{G}")#text("), we conclude (rigorously!) that ")#mi("{\\hat f}")#text(" is constant along cosets of the orthogonal complement")

#align(center)[#tao-fit-display[#mitex("\\hat H := \\{ \\xi \\in \\hat G: \\xi \\cdot x = 0 \\text{ for all } x \\in H\\}.")]]

#text("For instance, a measure ")#mi("{f}")#text(" on ")#mi("{{\\bf R}}")#text(" that is supported on ")#mi("{{\\bf Z}}")#text(" will have a Fourier transform ")#mi("{\\hat f}")#text(" that is constant along the ")#mi("{{\\bf Z}}")#text(" direction, as ")#mi("{{\\bf Z}}")#text(" is its own orthogonal complement. This is a basic component of the ")#link("http://en.wikipedia.org/wiki/Poisson_summation_formula")[#text("Poisson summation formula")]#text(". (The situation becomes more complicated if ")#mi("{f}")#text(" is merely a distribution rather than a measure, but we will not discuss this technical issue here.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Of course, in Euclidean domains such as ")#mi("{{\\bf R}}")#text(" or ")#mi("{{\\bf R}^n}")#text(", basic sets such as the intervals ")#mi("{[-R,R]}")#text(" are not actual subgroups, but are only ")#emph[#text("approximate subgroups")]#text(" (roughly speaking, this means that they are closed under addition a “reasonable fraction of the time”; for a precise definition, see ")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("my book with Van Vu")]#text("). However, there are ")#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/")[#text("dyadic models")]#text(" of Euclidean domains, such as the field ")#mi("{F((\\frac{1}{t}))}")#text(" of formal Laurent series in a variable ")#mi("{\\frac{1}{t}}")#text(" over a finite field ")#mi("{F}")#text(", in which the analogues of such intervals ")#emph[#text("are")]#text(" in fact actual subgroups, which allows for a very precise and rigorous formalisation of many of the heuristics given here in that setting. See for instance ")#link("http://www.math.ucla.edu/~tao/254a.1.01w/notes5.ps")[#text("these lecture notes of mine")]#text(" for more discussion.")
]

#text("One can view an interval such as ")#mi("{[-1/R,1/R]}")#text(" as being an approximate orthogonal complement to the interval ")#mi("{[-R,R]}")#text(", and more generally the polar body ")#mi("{\\Omega^*}")#text(" as an approximate orthogonal complement to ")#mi("{\\Omega}")#text(". Conversely, the uncertainty principle ")#mi("{\\Delta x \\cdot \\Delta \\xi \\gg 1}")#text(" when specialised to subgroups ")#mi("{H}")#text(" of a finite abelian group ")#mi("{G}")#text(" becomes the equality")

#align(center)[#tao-fit-display[#tao-math("\\left|H\\right| \\cdot \\left|H^\\perp\\right| = \\left|G\\right|", block: true)]]

#text("and when specialised to subspaces ")#mi("{V}")#text(" of a Euclidean space ")#mi("{{\\bf R}^n}")#text(" becomes")

#align(center)[#tao-fit-display[#mitex("\\text{dim}(V) + \\text{dim}(V^\\perp) = \\text{dim}({\\bf R}^n).")]]

#text("We saw above that a function ")#mi("{f}")#text(" that was restricted to a region ")#mi("{\\Omega}")#text(" would necessarily have a Fourier transform ")#mi("{\\hat f}")#text(" that was essentially constant on translates of (small multiples of) the dual region ")#mi("{\\Omega^*}")#text(". This implication can be partially reversed. For instance, suppose that ")#mi("{\\hat f}")#text(" behaved like a constant at all scales ")#mi("{\\ll N}")#text(". Then if one inspects the Fourier inversion formula")

#align(center)[#tao-fit-display[#mitex("f(x) = \\int_{\\bf R} \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi")]]

#text("we note that if ")#tao-math("{\\left|x\\right| \\gg 1/N}", block: false)#text(", then ")#mi("{e^{2\\pi i x \\xi}}")#text(" oscillates at scales ")#mi("{\\ll N}")#text(" by the above heuristic, and so ")#mi("{f(x)}")#text(" should be negligible when ")#tao-math("{\\left|x\\right| \\gg 1/N}", block: false)#text(".")

#text("The above heuristic computations can be made rigorous in a number of ways. One basic method is to exploit the fundamental fact that the Fourier transform intertwines multiplication and convolution, thus")

#align(center)[#tao-fit-display[#mitex("\\widehat{f*g} = \\hat f \\hat g")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\widehat{fg} = \\hat f * \\hat g")]]

#text("and similarly for the inverse Fourier transform. (Here, the convolution ")#mi("{*}")#text(" is with respect to either the Haar measure ")#mi("{\\mu_G}")#text(" on the physical space ")#mi("{G}")#text(", or the Haar measure ")#mi("{\\mu_{\\hat G}}")#text(" on the frequency space ")#mi("{\\hat G}")#text(", as indicated by context.) For instance, if a function ")#mi("{f}")#text(" has Fourier transform supported on ")#mi("{[-N,N]}")#text(", then we have")

#align(center)[#tao-fit-display[#mitex("\\hat f = \\hat f \\psi_N")]]

#text("where ")#mi("{\\psi_N(x) := \\psi(x/N)}")#text(" and ")#mi("{\\psi}")#text(" is a smooth and compactly supported (or rapidly decreasing) cutoff function that equals ")#mi("{1}")#text(" on the interval ")#mi("{[-1,1]}")#text(". (There is a lot of freedom here in what cutoff function to pick, but in practice, “all bump functions are usually equivalent”; unless one is optimising constants, needs a very specific and delicate cancellation, or if one really, really needs a explicit formula, one usually does not have to think too hard regarding what specific cutoff to use, though smooth and well localised cutoffs ")#link("http://www.tricki.org/article/Smoothing_sums")[#text("often tend to be superior")]#text(" to rough or slowly decaying cutoffs.)")

#text("Inverting the Fourier transform, we obtain the reproducing formula")

#align(center)[#tao-fit-display[#mitex("f = f * \\check \\psi_N")]]

#text("where ")#mi("{\\check \\psi_N}")#text(" is the inverse Fourier transform of ")#mi("{\\psi_N}")#text(". One can compute that")

#align(center)[#tao-fit-display[#mitex("\\check \\psi_N(x) = N \\check \\psi(Nx)")]]

#text("and thus ")#metadata(none) <tao-a44faa96da9d54640074>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("f(x) = \\int_{\\bf R} f(x+\\frac{y}{N}) \\check \\psi(y)\\ dy.")]]

#text("If one chose ")#mi("{\\psi}")#text(" to be smooth and compactly supported (or at the very least, a Schwartz function), ")#mi("{\\check \\psi}")#text(" will be in the Schwartz class. As such, ")#link(<tao-a44faa96da9d54640074>)[#text("(1)")]#text(" can be viewed as an assertion that the value of the band-limited function ")#mi("{f}")#text(" at any given point ")#mi("{x}")#text(" is essentially an average of its values at nearby points ")#mi("{x+\\frac{y}{N}}")#text(" for ")#mi("{y=O(1)}")#text(". This formula can already be used to give many rigorous instantiations of the uncertainty principle; see for instance ")#link("http://www.math.ucla.edu/~tao/254a.1.01w/notes1.ps")[#text("these lecture notes of mine")]#text(" for further discussion.")

#text("Another basic method to formalise the above heuristics, particularly with regard to “oscillation causes cancellation”, is to use integration by parts; this is discussed at ")#link("http://www.tricki.org/article/Use_integration_by_parts_to_exploit_cancellation")[#text("this Tricki article")]#text(".")

#heading(level: 1)[#strong[#text(" — 2. Projections — ")]]

#text("The restriction ")#mi("{1_{[-N,N]}(X) f := f 1_{[-N,N]}}")#text(" of a function ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" to an interval ")#mi("{[-N,N]}")#text(" is just the orthogonal projection (in the Hilbert space ")#mi("{L^2({\\bf R})}")#text(") of ")#mi("{f}")#text(" to the space of functions that are spatially supported in ")#mi("{[-N,N]}")#text(". Taking Fourier transforms (which, by Plancherel’s theorem, preserves the Hilbert space ")#mi("{L^2({\\bf R})}")#text("), we see that the Fourier restriction ")#mi("{1_{[-N,N]}(D) f}")#text(" of ")#mi("{f}")#text(", defined as")

#align(center)[#tao-fit-display[#mitex("\\widehat{1_{[-N,N]}(D) f} := \\hat f 1_{[-N,N]}")]]

#text("is the orthogonal projection of ")#mi("{f}")#text(" to those functions with ")#emph[#text("Fourier")]#text(" support in ")#mi("{[-N,N]}")#text(". As discussed above, such functions are (heuristically) those functions which are essentially constant at scales ")#mi("{\\ll 1/N}")#text(". As such, these projection operators should behave like averaging operators at this scale. This turns out not to be that accurate of a heuristic if one uses the sharp cutoffs ")#mi("{1_{[-N,N]}}")#text(" (though this does work perfectly in the dyadic model setting), but if one replaces the sharp cutoffs by smoother ones, then this heuristic can be justified by using convolutions as in the previous section; this leads to ")#emph[#text("Littlewood-Paley theory")]#text(", a cornerstone of the harmonic analysis of function spaces such as Sobolev spaces, and which are particularly important in partial differential equations; see for instance the first appendix of my PDE book for further discussion.")

#text("One can view the restriction operator ")#mi("{1_{[-N,N]}(X)}")#text(" as the spectral projection of the position operator ")#mi("{X f(x) := x f(x)}")#text(" to the interval ")#mi("{[-N,N]}")#text("; in a similar vein, one can view ")#mi("{1_{[-N,N]}(D)}")#text(" as a spectral projection of the differentiation operator ")#mi("{D f(x) := \\frac{1}{2\\pi i} \\frac{d}{dx} f(x)}")#text(".")

#text("As before, one can work with other sets than intervals here. For instance, restricting a function ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" to a subgroup ")#mi("{H}")#text(" causes the Fourier transform ")#mi("{\\hat f}")#text(" to be averaged along the dual group ")#mi("{\\hat H}")#text(". In particular, restricting a function ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" to the integers (and renormalising it to become the measure ")#mi("{\\sum_{n \\in {\\bf Z}} f(n) \\delta_n}")#text(") causes the Fourier transform ")#mi("{\\hat f: {\\bf R} \\rightarrow {\\bf C}}")#text(" to become summed over the dual group ")#mi("{{\\bf Z}^\\perp = {\\bf Z}}")#text(" to become the function ")#mi("{\\sum_{m \\in {\\bf Z}} \\hat f(\\cdot+m)}")#text(". In particular, the zero Fourier coefficient of ")#mi("{\\sum_{n \\in {\\bf Z}} f(n) \\delta_n}")#text(" is ")#mi("{\\sum_{m \\in {\\bf Z}} \\hat f(m)}")#text(", leading to the Poisson summation formula")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}} f(n) = \\sum_{m \\in {\\bf Z}} \\hat f(m).")]]

#text("More generally, one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in R {\\bf Z}} f(n) = \\frac{1}{R} \\sum_{m \\in \\frac{1}{R} {\\bf Z}} \\hat f(m)")]]

#text("for any ")#mi("{R > 0}")#text(", which can be viewed as a one-parameter family of identities interpolating between the inversion formula")

#align(center)[#tao-fit-display[#mitex("f(0) = \\int_{\\bf R} \\hat f(\\xi) \\ d\\xi")]]

#text("on one hand, and the forward Fourier transform formula")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} f(x)\\ dx = \\hat f(0)")]]

#text("on the other.")

#text("The duality ")#mi("{\\Delta x \\cdot \\Delta \\xi \\gg 1}")#text(" between the position variable ")#mi("{x}")#text(" and the frequency variable ")#mi("{\\xi}")#text(" (or equivalently, between the position operator ")#mi("{X}")#text(" and the differentiation operator ")#mi("{D}")#text(") can be generalised to contexts in which the two dual variables haved a different “physical” interpretation than position and frequency. One basic example of this is the duality ")#mi("{\\Delta t \\cdot \\Delta E \\gg 1}")#text(" between a time variable ")#mi("{t}")#text(" and an energy variable ")#mi("{E}")#text(" in quantum mechanics. Consider a time-dependent Schrödinger equation ")#metadata(none) <tao-336074805fc853987abe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("i \\partial_t \\psi = H \\psi; \\quad \\psi(0) = \\psi_0")]]

#text("for some Hermitian (and time-independent) spatial operator ")#mi("{H}")#text(" on some arbitrary domain (which does not need to be a Euclidean space ")#mi("{{\\bf R}^n}")#text(", or even a group), where we have normalised away for now the role of Planck’s constant ")#mi("{\\hbar}")#text(". If the underlying spatial space ")#mi("{L^2({\\bf R})}")#text(" has an orthonormal basis of eigenvector solutions to the time-independent Schrödinger equation")

#align(center)[#tao-fit-display[#mitex("H u_k = E_k u_k")]]

#text("then the solution to ")#link(<tao-336074805fc853987abe>)[#text("(2)")]#text(" is formally given by the formula")

#align(center)[#tao-fit-display[#mitex("\\psi = e^{-itH} \\psi_0 = \\sum_k e^{-i E_k t} \\langle \\psi_0, u_k \\rangle u_k.")]]

#text("We thus see that the coefficients ")#mi("{\\psi_0, u_k \\rangle}")#text(" (or more precisely, the eigenvectors ")#mi("{\\langle \\psi_0, u_k \\rangle u_k}")#text(") can be viewed as the Fourier coefficients of ")#mi("{\\psi}")#text(" in time, with the energies ")#mi("{E_k}")#text(" playing the role of the frequency vector. Taking traces, one (formally) sees a similar Fourier relationship between the trace function ")#mi("{\\text{tr}(e^{-itH})}")#text(" and the spectrum ")#mi("{E_1 < E_2 < E_3 < \\ldots}")#text(": ")#metadata(none) <tao-d19cdf21559824bb330d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\text{tr}(e^{-itH}) = \\sum_k e^{-i E_k t}.")]]

#text("As a consequence, the heuristics of the uncertainty principle carry through here. Just as the behaviour of a function ")#mi("{f}")#text(" at scales ")#mi("{\\ll T}")#text(" largely controls the spectral behaviour of ")#mi("{\\hat f}")#text(" at scales ")#mi("{\\gg 1/T}")#text(", one can use the evolution operator ")#mi("{e^{-itH}}")#text(" of the Schrödinger equation up to times ")#tao-math("{\\left|t\\right| \\leq T}", block: false)#text(" to understand the spectrum ")#mi("{E_1 < E_2 < E_3 < \\ldots}")#text(" of ")#mi("{H}")#text(" at scales ")#mi("{\\gg 1/T}")#text(". For instance, from ")#link(<tao-d19cdf21559824bb330d>)[#text("(3)")]#text(" we (formally) see that")

#align(center)[#tao-fit-display[#mitex("\\text{tr}( \\int_{\\bf R} \\eta(t/T) e^{it E_0} e^{-itH}\\ dt ) = T \\sum_k \\hat \\eta( \\frac{E_k - E_0}{2\\pi/T} )")]]

#text("for any test function ")#mi("{\\eta}")#text(" and any energy level ")#mi("{E_0}")#text(". Roughly speaking, this formula tells us that the number of eigenvalues in an interval of size ")#mi("{O(1/T)}")#text(" can be more or less controlled by the Schrödinger operators up to time ")#mi("{T}")#text(".")

#text("A similar analysis also holds for the solution operator")

#align(center)[#tao-fit-display[#mitex("u(t) = \\cos(t \\sqrt{-\\Delta}) u_0 + \\frac{\\sin(t\\sqrt{-\\Delta})}{\\sqrt{-\\Delta}} u_1")]]

#text("for the wave equation")

#align(center)[#tao-fit-display[#mitex("\\partial_t^2 u - \\Delta u = 0")]]

#text("on an arbitrary spatial Riemannian manifold ")#mi("{M}")#text(" (which we will take to be compact in order to have discrete spectrum). If we write ")#mi("{\\lambda_k}")#text(" for the eigenvalues of ")#mi("{\\sqrt{-\\Delta}}")#text(" (so the Laplace-Beltrami operator ")#mi("{\\Delta}")#text(" has eigenvalues ")#mi("{-\\lambda_k^2}")#text("), then a similar analysis to the above shows that knowledge of the solution to the wave equation up to time ")#mi("{T}")#text(" gives (at least in principle) knowledge of the spectrum averaged to at the scale ")#mi("{1/T}")#text(" or above.")

#text("From the finite speed of propagation property of the wave equation (which has been normalised so that the speed of light ")#mi("{c}")#text(" is equal to ")#mi("{1}")#text("), one only needs to know the geometry of the manifold ")#mi("{M}")#text(" up to distance scales ")#mi("{T}")#text(" in order to understand the wave operator up to times ")#mi("{T}")#text(". In particular, if ")#mi("{T}")#text(" is less than the injectivity radius of ")#mi("{M}")#text(", then the topology and global geometry of ")#mi("{M}")#text(" is largely irrelevant, and the manifold more or less behaves like (a suitably normalised version of) Euclidean space. As a consequence, one can borrow Euclidean space techniques (such as the spatial Fourier transform) to control the spectrum at coarse scales ")#mi("{\\gg 1}")#text(", leading in particular to the ")#emph[#text("Weyl law")]#text(" for the distribution of eigenvalues on this manifold; see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=1205579")[#text("this book of Sogge")]#text(" for a rigorous discussion. It is a significant challenge to go significantly below this scale and understand the finer structure of the spectrum; by the uncertainty principle, this task is largely equivalent to that of understanding the wave equation on long time scales ")#mi("{T \\gg 1}")#text(", and the global geometry of the manifold ")#mi("{M}")#text(" (and in particular, the dynamical properties of the geodesic flow) must then inevitably play a more dominant role.")

#text("Another important uncertainty principle duality relationship is that between the (imaginary parts of the) zeroes ")#mi("{\\rho}")#text(" of the Riemann zeta function ")#mi("{\\zeta(s)}")#text(" and the logarithms ")#mi("{\\log p}")#text(" of the primes. Starting from the fundamental Euler product formula")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) = \\prod_p (1-p^{-s})^{-1}")]]

#text("and using rigorous versions of the heuristic factorisation")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) \\approx \\prod_\\rho (s-\\rho)")]]

#text("one can soon derive explicit formulae connecting zeroes and primes, such as")

#align(center)[#tao-fit-display[#mitex("\\sum_\\rho \\frac{1}{s-\\rho} \\approx - \\sum_p \\log p e^{-s \\log p}")]]

#text("(see e.g. ")#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/")[#text("this blog post of mine")]#text(" for more discussion). Using such formulae, one can relate the zeroes of the zeta function in the strip ")#mi("{\\{ \\text{Im}(\\rho) \\leq T \\}}")#text(" with the distribution of the log-primes at scales ")#mi("{\\gg 1/T}")#text(". For instance, knowing that there are no zeroes on the line segment ")#tao-math("{\\{ 1+it: \\left|t\\right| \\leq T \\}}", block: false)#text(" is basically equivalent to a partial prime number theorem ")#mi("{\\pi(x) = (1+O(\\frac{1}{T})) \\frac{x}{\\log x}}")#text("; letting ")#mi("{T \\rightarrow \\infty}")#text(", we see that the full prime number theorem is equivalent to the absence of zeroes on the entire line ")#mi("{\\{1+it: t \\in {\\bf R} \\}}")#text(". More generally, there is a fairly well-understood dictionary between the distribution of zeroes and the distribution of primes, which is explored in just about any advanced text in analytic number theory.")

#heading(level: 1)[#strong[#text(" — 3. Phase space and the semi-classical limit — ")]]

#text("The above heuristic description of Fourier projections such as ")#mi("{1_{[-N,N]}(x)}")#text(" suggest that a Fourier projection ")#mi("{1_J(D)}")#text(" will approximately commute with a spatial projection ")#mi("{1_I(X)}")#text(" whenever ")#mi("{I}")#text(", ")#mi("{J}")#text(" are intervals that obey the Heisenberg inequality ")#tao-math("{\\left|I\\right| \\left|J\\right| \\gg 1}", block: false)#text(". Again, this heuristic is not quite accurate if one uses sharp cutoffs (except in the dyadic model), but becomes quite valid if one uses smooth cutoffs. As such, one can morally talk about phase space projections ")#mi("{1_{I \\times J}(X,D) \\approx 1_I(X) 1_J(D) \\approx 1_J(D) 1_I(X)}")#text(" to rectangles ")#mi("{I \\times J}")#text(" in phase space, so long as these rectangles are large enough not to be in violation of the uncertainty principle.")

#text("Heuristically, ")#mi("{1_{I \\times J}(X,D)}")#text(" is an orthogonal projection to the space of functions that are localised to ")#mi("{I}")#text(" in physical space and to ")#mi("{J}")#text(" in frequency space. (This is morally a vector space, but unfortunately this is not rigorous due to the inability to perfectly localise in both physical space and frequency space simultaneously, thanks to the Hardy uncertainty principle.) One can approximately compute the dimension of this not-quite-vector-space by computing the trace of the projection. Recalling that the trace of an integral operator ")#mi("{Tf(x) := \\int_{\\bf R} K(x,y) f(y)\\ dy}")#text(" is given by ")#mi("{\\text{tr} T = \\int_{\\bf R} K(x,x)}")#text(", a short computation reveals that the trace of ")#mi("{1_I(X) 1_J(D)}")#text(" is")

#align(center)[#tao-fit-display[#tao-math("\\int_I \\check 1_J(0)\\ dx = \\left|I\\right| |J|.", block: true)]]

#text("Thus we conclude that the phase space region ")#mi("{I \\times J}")#text(" contains approximately ")#tao-math("{\\left|I\\right| \\left|J\\right|}", block: false)#text(" degrees of freedom in it, which can be viewed as a “macroscopic” version of the uncertainty principle.")

#text("More generally, the number of degrees of freedom contained in a large region ")#mi("{\\Omega \\subset {\\bf R} \\times {\\bf R}}")#text(" of phase space is proportional to its area. Among other things, this can be used to justify the Weyl law for the distribution of eigenvalues of various operators. For instance, if ")#mi("{H}")#text(" is the Schrödinger operator")

#align(center)[#tao-fit-display[#mitex("H = - \\hbar^2 \\frac{d^2}{dx^2} + V(x) = \\hbar^2 D^2 + V(X),")]]

#text("where ")#mi("{\\hbar > 0}")#text(" is a small constant (which physically can be interpreted as Planck’s constant), and ")#mi("{V}")#text(" is a confining potential (to ensure discreteness of the spectrum), then the spectral projection ")#mi("{1_{[-\\infty,E]}(H)}")#text(", when spectrally projected to energy levels below a given threshold ")#mi("{E}")#text(", is morally like a phase space projection to the region ")#mi("{\\Omega := \\{ (\\xi,x): \\hbar^2 \\xi^2 + V(x) \\leq E \\}}")#text(". As such, the number of eigenvalues of ")#mi("{H}")#text(" less than ")#mi("{E}")#text(" should roughly equal the area of ")#mi("{\\Omega}")#text(", particularly when ")#mi("{\\hbar}")#text(" is small (so that ")#mi("{\\Omega}")#text(" becomes large, and the uncertainty principle no longer dominates); note that if ")#mi("{V}")#text(" is a confining potential (such as the harmonic potential ")#tao-math("{V(x) = \\left|x\\right|^2}", block: false)#text(") then ")#mi("{\\Omega}")#text(" will have finite area. Such heuristics can be justified by the machinery of ")#emph[#text("semi-classical analysis")]#text(" and the ")#emph[#text("pseudo-differential calculus")]#text(", which we will not detail here.")

#text("The ")#link("http://en.wikipedia.org/wiki/Correspondence_principle")[#text("correspondence principle")]#text(" in quantum mechanics asserts that in the limit ")#mi("{\\hbar \\rightarrow 0}")#text(", quantum mechanics asymptotically converges (in some suitable sense) to classical mechanics. There are several ways to make this precise. One can work in a dual formulation, using algebras of observables rather than dealing with physical states directly, in which case the point is that the non-commutative operator algebras of quantum observables converge in various operator topologies to the commutative operator algebras of classical observables in the limit ")#mi("{\\hbar \\rightarrow 0}")#text(". This is the most common way that the correspondence principle is formulated; but one can also work directly using states. We illustrate this with the time-dependent Schrödinger equation ")#metadata(none) <tao-1a1173498cbef446d881>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("i \\hbar \\partial_t \\psi = - \\frac{\\hbar^2}{2m} \\partial_{xx} \\psi + V(x) \\psi")]]

#text("with a potential ")#mi("{V}")#text(", where ")#mi("{m > 0}")#text(" is a fixed constant (representing mass) and ")#mi("{\\hbar > 0}")#text(" is a small constant, or equivalently")

#align(center)[#tao-fit-display[#mitex("i \\hbar \\partial_t \\psi = (\\frac{P^2}{2m} + V(X)) \\psi")]]

#text("where ")#mi("{X}")#text(" is the position operator ")#mi("{X f(x) := x f(x)}")#text(" and ")#mi("{P}")#text(" is the momentum operator ")#mi("{P f(x) := -i \\hbar \\frac{d}{dx} f(x)}")#text(" (thus ")#mi("{P = i \\hbar D}")#text("). The classical counterpart to this equation is ")#link("http://en.wikipedia.org/wiki/Newton%27s_laws_of_motion")[#text("Newton’s second law")]

#align(center)[#tao-fit-display[#mitex("F = ma;")]]

#text("where ")#mi("{a = \\frac{d^2 x}{dt^2}}")#text(" and ")#mi("{F = - \\partial_x V(x)}")#text("; introducing the momentum ")#mi("{p := mv = m \\frac{dx}{dt}}")#text(", one can rewrite Newton’s second law as ")#link("http://en.wikipedia.org/wiki/Hamiltonian_mechanics")[#text("Hamilton’s equations of motion")]#text(" ")#metadata(none) <tao-1f3f937dff6a258bcf1e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\partial_t p = -\\partial_x V(x); \\quad \\partial_t x = \\frac{1}{m} p.")]]

#text("We now indicate (heuristically, at least) how ")#link(<tao-1a1173498cbef446d881>)[#text("(4)")]#text(" converges to ")#link(<tao-1f3f937dff6a258bcf1e>)[#text("(5)")]#text(" as ")#mi("{\\hbar \\rightarrow 0}")#text(". According to ")#link("http://en.wikipedia.org/wiki/Matter_wave")[#text("de Broglie’s law")]#text(" ")#mi("{p = 2\\pi \\hbar \\xi}")#text(", the momentum ")#mi("{p}")#text(" should be proportional to the frequency ")#mi("{\\xi}")#text(". Accordingly, consider a wave function ")#mi("{\\psi}")#text(" that at time ")#mi("{t}")#text(" is concentrated near position ")#mi("{x_0(t)}")#text(" and momentum ")#mi("{p_0(t)}")#text(", and thus near frequency ")#mi("{p_0(t)/(2\\pi\\hbar)}")#text("; heuristically one can view ")#mi("{\\psi}")#text(" as having the shape")

#align(center)[#tao-fit-display[#mitex("\\psi(t,x) = A(t,\\frac{x-x_0(t)}{r}) e^{i p_0(t) x / \\hbar} e^{i \\theta(t) / \\hbar}")]]

#text("where ")#mi("{\\theta(t)}")#text(" is some phase, ")#mi("{r}")#text(" is some spatial scale (between ")#mi("{1}")#text(" and ")#mi("{\\hbar}")#text(") and ")#mi("{A}")#text(" is some amplitude function. Informally, we have ")#mi("{X \\approx x_0(t)}")#text(" and ")#mi("{P \\approx p_0(t)}")#text(" for ")#mi("{\\psi}")#text(".")

#text("Before we analyse the equation ")#link(<tao-1a1173498cbef446d881>)[#text("(4)")]#text(", we first look at some simpler equations. First, we look at")

#align(center)[#tao-fit-display[#mitex("i \\hbar \\partial_t \\psi = E \\psi")]]

#text("where ")#mi("{E}")#text(" is a real scalar constant. Then the evolution of this equation is given by a simple phase rotation:")

#align(center)[#tao-fit-display[#mitex("\\psi(t,x) = e^{-i Et/\\hbar} \\psi(0,x).")]]

#text("This phase rotation does not change the location ")#mi("{x_0(t)}")#text(" or momentum ")#mi("{p_0(t)}")#text(" of the wave:")

#align(center)[#tao-fit-display[#mitex("\\partial_t x_0(t) = 0; \\quad \\partial_t p_0(t) = 0.")]]

#text("Next, we look at the transport equation")

#align(center)[#tao-fit-display[#mitex("i \\hbar \\partial_t \\psi = - i \\hbar v \\partial_x \\psi")]]

#text("where ")#mi("{v \\in {\\bf R}}")#text(" is another constant This evolution is given by translation:")

#align(center)[#tao-fit-display[#mitex("\\psi(t,x) = \\psi(0,x-vt);")]]

#text("the position ")#mi("{x_0(t)}")#text(" of this evolution moves at the constant speed of ")#mi("{v}")#text(", but the momentum is unchanged:")

#align(center)[#tao-fit-display[#mitex("\\partial_t x_0(t) = v; \\quad \\partial_t p_0(t) = 0.")]]

#text("Combining the two, we see that an equation of the form")

#align(center)[#tao-fit-display[#mitex("i \\hbar \\partial_t \\psi = E \\psi - i \\hbar v (\\partial_x - i p_0(t) / \\hbar) \\psi")]]

#text("would also transport the position ")#mi("{x_0}")#text(" at a constant speed of ")#mi("{v}")#text(", without changing the momentum. Next, we consider the modulation equation")

#align(center)[#tao-fit-display[#mitex("i \\hbar \\partial_t \\psi = F x \\psi")]]

#text("where ")#mi("{F \\in {\\bf R}}")#text(" is yet another constant. This equation is solved by the formula")

#align(center)[#tao-fit-display[#mitex("\\psi(t,x) = e^{i t F x / \\hbar} \\psi(0,x);")]]

#text("this phase modulation does not change the position ")#mi("{x_0(t)}")#text(", but steadily increases the momentum ")#mi("{p_0(t)}")#text(" at a rate of ")#mi("{F}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\partial_t x_0(t) = 0; \\quad \\partial_t p_0(t) = F.")]]

#text("Finally, we combine all these equations together, looking at the combined equation")

#align(center)[#tao-fit-display[#mitex("i \\hbar \\partial_t \\psi = E \\psi - i \\hbar v (\\partial_x - i p_0(t) / \\hbar) \\psi + F (x-x_0(t)) \\psi.")]]

#text("Heuristically at least, the position ")#mi("{x_0(t)}")#text(" and momentum ")#mi("{p_0(t)}")#text(" of solutions to this equation should evolve according to the law ")#metadata(none) <tao-83100857305e5a4f34be>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\partial_t x_0(t) = v; \\quad \\partial_t p_0(t) = F.")]]

#text("We remark that one can make the above quite rigorous by using the ")#link("http://en.wikipedia.org/wiki/Metaplectic_group")[#text("metaplectic representation")]#text(".")

#text("This analysis was for ")#mi("{v, F}")#text(" constant, but as all statements here are instantaneous and first-order in time, it also applies for time-dependent ")#mi("{v, F}")#text(".")

#text("Now we return to the Schrödinger equation ")#link(<tao-1a1173498cbef446d881>)[#text("(4)")]#text(". If ")#mi("{\\psi}")#text(" is localised in space close to ")#mi("{x_0(t)}")#text(", then by Taylor expansion we may linearise the ")#mi("{V(x)}")#text(" component as")

#align(center)[#tao-fit-display[#mitex("V(x) = V(x_0(t)) + (x-x_0(t)) \\partial_x V(x).")]]

#text("Similarly, if ")#mi("{\\psi}")#text(" is localised in momentum close to ")#mi("{p_0(t)}")#text(", then in frequency it is localised close to ")#mi("{p_0(t)/(2\\pi \\hbar)}")#text(", so that ")#mi("{\\partial_x \\approx i p_0(t)/\\hbar}")#text(", and so we have a Taylor expansion")

#align(center)[#tao-fit-display[#mitex("\\partial_{xx} \\approx (i p_0(t)/\\hbar)^2 + 2 (i p_0(t)/\\hbar) (\\partial_x - (i p_0(t)/\\hbar)).")]]

#text("These Taylor expansions become increasingly accurate in the limit ")#mi("{\\hbar \\rightarrow 0}")#text(", assuming suitable localisation in both space and momentum. Inserting these approximations and simplifying, one arrives at")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\psi = \\frac{E(t)}{i\\hbar} \\psi - \\frac{p_0(t)}{m} (\\partial_x - (i p_0(t)/\\hbar)) \\psi - \\frac{i}{\\hbar} (x-x_0(t)) \\partial_x V(x_0(t)) \\psi")]]

#text("where ")#mi("{E(t) := \\frac{p_0(t)^2}{2m} + V(x_0(t))}")#text(" is the classical energy of the state. Using the heuristics ")#link(<tao-83100857305e5a4f34be>)[#text("(6)")]#text(" we are led to ")#link(<tao-1f3f937dff6a258bcf1e>)[#text("(5)")]#text(" as desired.")

#text("More generally, a Schrödinger equation")

#align(center)[#tao-fit-display[#mitex("i \\hbar \\partial_t \\psi = H( X, P ) \\psi")]]

#text("where ")#mi("{P := -i \\hbar \\frac{d}{dx}}")#text(" is the momentum operator, and being vague about exactly what a function ")#mi("{H(X,P)}")#text(" of two non-commuting operators ")#mi("{X, P}")#text(" means, can be (heuristically) approximately Taylor expanded as")

#align(center)[#tao-fit-display[#mitex("i \\hbar \\partial_t \\psi = H(x_0(t),p_0(t)) + \\frac{\\partial H}{\\partial p} H( x_0(t), p_0(t) ) ( P - p_0(t) ) \\psi + \\frac{\\partial H}{\\partial x} H( x_0(t), p_0(t) ) ( X - x_0(t) ) \\psi")]]

#text("and ")#link(<tao-83100857305e5a4f34be>)[#text("(6)")]#text(" leads us to the Hamilton equations of motion")

#align(center)[#tao-fit-display[#mitex("\\partial_t x(t) = \\frac{\\partial H}{\\partial p}; \\quad \\partial_t p(t) = - \\frac{\\partial H}{\\partial x}.")]]

#text("It turns out that these heuristic computations can be made completely rigorous in the semi-classical limit ")#mi("{\\hbar \\rightarrow 0}")#text(", by using the machinery of ")#emph[#text("pseudodifferential calculus")]#text(", but we will not detail this here.")

#heading(level: 1)[#text("Comments (33)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90c02f41607c68dc2bed941e13427d5caa05ebbef2fbcce8749d6ba70055a4a2-ba58d5187ecfe093fa29070570e91eae9d0d8a98aca2cf6ce452f53fa4647938.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-45710")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2010")])]

#text("At the end of the discussion of zeta, ")#mi("1/(s-p)")#text(" should be ")#mi("1/(s-\\rho)")#text(".")

#emph[#text("[Corrected, thanks. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90c02f41607c68dc2bed941e13427d5caa05ebbef2fbcce8749d6ba70055a4a2-ba58d5187ecfe093fa29070570e91eae9d0d8a98aca2cf6ce452f53fa4647938.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-45711")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2010")])]

#text("Also, the ")#mi("i")#text(" in the exponential is surpuflous. Sorry for the double comment!")

#emph[#text("[Corrected, thanks. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a718fe0ae1ce222ea33275174bc93b6011081a9ba6d690bd7cf9c39f0317e62a-6170224188d25c8da1133b3e3d9c851d6c93c48eb9e4532aaaf759d38dceb8b4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mfrasca")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-45740")[#strong[#text("mfrasca")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2010")])]

#text("Hi Terry,")

#text("As you know, a duality principle holds true also in perturbation theory:")

#link("http://pra.aps.org/abstract/PRA/v58/i5/p3439_1")[#text("http://pra.aps.org/abstract/PRA/v58/i5/p3439_1")]

#text("For a given problem with a small perturbation you can generally get a solution to the same one having the perturbation going to infinity.")

#text("Regards,")

#text("Marco")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-45744")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2010")])]

#text("There is a t missing in exponent of e^(-iE/h) in the equation just under “Then the evolution of this equation is given by a simple phase rotation: ”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11cac8bde0677bc43849cc66b6c6c521d3d5a7cf91c7fdeac73e56aae0504d7d-8314babeb03af470dda611f556254e78f7322714dcc217a2d0f56def9d134eaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Researcher")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-45752")[#strong[#text("Researcher")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2010")])]

#text("Great post! May I humbly suggest using a new tag “heuristics” for the posts like that? And anyway I’d be thrilled to see more posts on various heuristics in mathematics on your blog, with or without this tag :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dmitin")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-45815")[#strong[#text("dmitin")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2010")])]

#link("http://en.wikipedia.org/wiki/Duality_(projective_geometry)")[#text("http://en.wikipedia.org/wiki/Duality_(projective_geometry)")]

#link("http://en.wikipedia.org/wiki/Duality_(projective_geometry)#Combinatorial_duality")[#text("http://en.wikipedia.org/wiki/Duality_(projective_geometry)#Combinatorial_duality")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80fc30ae57babf1761c3ee9694d74c74f910d6e6bc43df06294feb5a98f4ec85-182ac54eb8a39839fb3c88582bd9ea6a6b670cc4441367427cb7c52b768702c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-46464")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2010")])]

#text("Professor Tao:")#linebreak()#text(" If we consider 1, 10 , 100, 1000… as basis we have a representation of integers in terms of these basis. I was wondering if there is a notion of harmonic analysis on integers apart from the fourier transform so that multiplication (which is just convolution with carry) could have a dual basis interpretation. Something like multiplication of polynomials using fft. It seems that the ordinary notion of Parseval’s theorem will not hold (or else product of sum of squares of digits of two numbers to be multiplied would be the sum of squares of the digits of the resulting integers which is untrue).")#linebreak()#text(" Thank you")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d9989e2183ab57681fe691a29fc00e6d47a44a48cf9e1e9fd25b3f767d80f4f-d2f05afecac42953da561091174aa0faed51b9bfe656a26abfcaf4e5abb00099.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Shearer")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-46538")[#strong[#text("Paul Shearer")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2010")])]

#text("Hi Terry,")

#text("Another beautiful example of duality comes from optimization theory, in the form of the Fenchel dual to a function. The Fenchel dual has the following physical interpretation, which nicely illustrates your theme of “dual intrinsic/extrinsic” descriptions of an object:")

#text("“A particle in a convex potential well ")#mi("F(z)")#text(" can be pushed to any desired equilibrium point x by applying an appropriate force p. There is a bijective map relating x and p: the forward map is ")#mi("\\nabla F")#text(", while the inverse is ")#mi("\\nabla F^*")#text(", where ")#mi("F^*")#text(" is the Fenchel dual to ")#mi("F")#text(".”")

#text("To be more formal, given a nice convex function ")#mi("F : \\mathbb{R} \\rightarrow \\mathbb{R}")#text(", we can interpret it as a potential function that a particle rolls around in.")

#text("Let ")#mi("(a,b)")#text(" denote the inner product. Then the Fenchel dual to F is defined as")

#mi("F^*(p) = \\max_z (p,z) - F(z).")

#text("Let x be the point where the max is achieved. The point x can be interpreted as the equilibrium position of a particle in potential F when this particle is subjected to a constant “applied force” p. The function")

#mi("F_p(z) = F(z) - (p,z)")

#text("can be interpreted as an effective potential induced by the applied force, and the Fenchel dual is implicitly finding x, the equilibrium point where this potential is minimized. With a little calc and algebra we find")

#mi("\\nabla F(x) = p")#linebreak()#text(" ")#mi("F^*(p) = -F_p(x).")

#text("(The negative is taken simply because the duality is cleaner if ")#mi("F^*")#text(" is convex rather than concave.) A little calculus shows that")

#text("(*) ")#mi("\\nabla F^*(p) = x")

#text("completing the justification of the physical interpretation at the top of this post.")

#text("The derivation of this fact is intriguing in itself; by applying the multivariate chain rule to differentiate")

#mi("F^*(p) = g(x,p) = (x,p) - F(x)")

#text("with respect to p, we find")

#mi("\\nabla F^*(p) = (p - \\nabla F(x)) + x = 0 + x = x.")

#text("The fact ")#mi("p - \\nabla F(x) = 0")#text(" is known from above, and arises from the fact that the particle is at equilibrium; thus the only change in the effective potential arises from the change in the “applied potential” with respect to p alone, holding x constant.")

#text("Another interesting fact: a nonrigorous but intuitively appealing derivation of the Fenchel dual, in particular the involutive property, is possible by the following geometric procedure:")

#text("1. draw a contour plot of some nice F.")#linebreak()#text(" 2. draw a vector from 0 to a given equilibrium point x.")#linebreak()#text(" 3. draw the applied force p as a vector pointing from point x to x + p.")

#text("Note that the two vectors drawn are now two sides of a parallelogram; the Fenchel dual is a function for which one can follow the exact same steps (1)-(3) again, but one uses the other two sides of the parallelogram and reverses the roles of p and x. After drawing this diagram, the involutive property of Fenchel duality becomes immediately obvious: taking the dual just means “flipping” the parallelogram over! :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d9989e2183ab57681fe691a29fc00e6d47a44a48cf9e1e9fd25b3f767d80f4f-d2f05afecac42953da561091174aa0faed51b9bfe656a26abfcaf4e5abb00099.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Shearer")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-46545")[#strong[#text("Paul Shearer")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2010")])]

#text("whoops! it’s supposed to be ")#mi("F : \\mathbb{R}^n \\rightarrow \\mathbb{R}")#text(". sorry. Although I guess it’s still an interesting and nontrivial statement for n = 1. Just not as geometrically cool…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ff4481429a1a2cf5d39b8b4eacea58d372f35d2630729c9f42c80dd2f3afae74-d249a59e6d2d1e14c96379befbd0fd182decd5a905f7bc7359e6f106f2d1dc9e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chen-bo Zhu")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-49970")[#strong[#text("Chen-bo Zhu")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2011")])]

#text("Hi Prof. Tao,")

#text("Before Remark 1, there is a typo: if H is a measure zero subgroup of H (which should be G). Also I think the statement that f^ is constant along cosets of the orthogonal complement may need a small revision since f can be a transversal derivative of a measure on H. ")#emph[#text("[Corrected, thanks – T.]")]

#text("Not sure if the following paragraph is appropriate as a follow-up to your blog, and so please feel free to remove this paragraph if it is not so.")

#text("There is a certain rigidity phenomenon of distributions with strong support properties, which may be considered as an another instance of the uncertainty principle:")

#link("http://www.math.nus.edu.sg/~matzhucb/rigidity-distribution.pdf")[#text("Click to access rigidity-distribution.pdf")]

#text("Regards, Chen-bo")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Higher order Fourier analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-51103")[#strong[#text("Higher order Fourier analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2011")])]

#text("[…] was based primarily on my graduate course in the topic, though it also contains material from some additional posts related to linear and higher order Fourier analysis on the blog. It is available […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Localisation and compactness properties of the Navier-Stokes global regularity problem « What’s new")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-63757")[#strong[#text("Localisation and compactness properties of the Navier-Stokes global regularity problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2011")])]

#text("[…] the uncertainty principle (discussed in this post) suggests that . Finally, the linear term and nonlinear term have heuristic magnitudes about and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Montgomery’s uncertainty principle « What’s new")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-119925")[#strong[#text("Montgomery’s uncertainty principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2012")])]

#text("[…] One of the most fundamental principles in Fourier analysis is the uncertainty principle. It does not have a single canonical formulation, but one typical informal description of the principle is that if a function is restricted to a narrow region of physical space, then its Fourier transform must be necessarily “smeared out” over a broad region of frequency space. Some versions of the uncertainty principle are discussed in this previous blog post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-144151")[#strong[#text("Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2012")]

#strong[#text("What is an intuitive way of explaining how the “Fourier transform” works?…")]

#text("Fourier transform is way of writing functions on a space as a superposition of symmetric functions. Depending on the space we are interested, there can be several symmetries associated to the function. For instance, the fourier transform on real line i…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-457410")[#strong[#text("Lemme tell y’all about icosian calculus. | between bourbaki and me")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2015")]

#text("[…] Sitting in a coffee shop, I wandered over to the wiki for the presentation of a group. A presentation is a natural idea in group theory, a compact way of describing a group by referring to a set of generators and relations between those generators. Fun fact, the presentation of a group is an example of an internal object description. This is part of a larger phenomenon in mathematics where we describe an object based on functions from similar objects into your object. For instance, the presentation is equivalent to a description of a map from a free group on a set of generators S into your group G. You essentially describe how to fold the free group up into your group! The internal description is in contrast with external, where you send maps out of your objects. In group theory, this is called representation theory. Tons more mind-blowing examples of internal-external definitions at Terry Tao’s blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Decoupling and the Bourgain-Demeter-Guth proof of the Vinogradov main conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-463394")[#strong[#text("Decoupling and the Bourgain-Demeter-Guth proof of the Vinogradov main conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2015")])]

#text("[…] of Theorem 5.6 of Bourgain-Demeter-Guth, or my general discussion on the uncertainty principle in this previous blog post). This implies that , when restricted to , is essentially constant on “plates”, defined […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-479110")[#strong[#text("On “external” definitions for computation | Windows On Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2017")]

#text("[…] to me to be an instance of moving to an external, as opposed to internal definition, in the sense described by Tao. (Please correct me if I’m wrong!) As Arkani-Hamed describes, a hugely important paper […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-534891")[#strong[#text("To lift and breathe – Tea and Skulls")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2020")]

#text("[…] Internal descriptions stand in contrast with external descriptions. Can you guess what an external description might be like? If internal descriptions were maps into the group, then it would make sense if external descriptions were maps out of the group. Fortunately, things do make sense, and I’m not lying to you, so that’s exactly what external descriptions are. In group theory, the description of a group is called a representation. The study of representation is called representation. (If this internal-external business sounds cool to you, check out this dope post by Terry Tao: blog). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32065b81c16f187944d8c30e760cd8d517709c8ac8b7fd61fc96b9e15e310ac3-26bbdb9819ad9c35bc05f817557b45172536330a2f6cd94c8a4ec0de03846620.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On generating functions in additive number theory, II: Lower-order terms and applications to PDEs | George Shakan")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-536701")[#strong[#text("On generating functions in additive number theory, II: Lower-order terms and applications to PDEs | George Shakan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2020")])]

#text("[…] By uncertainty principle heuristics, we expect , as defined in (1), to be constant on scales […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bdc752fcaed670cc8f0a250f4220cd2b2a0caaf7c5bfafdc84739396dc5dc94c-d04b7dfe9e88c196d002b2ba6d6441ee6108eeb306613829d75b8a3dacf96440.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel D")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-543482")[#strong[#text("Daniel D")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2020")])]

#text("In (3) we have ")#mi("\\sum e^{itE}")#text(" and then another expression that appears is ")#mi("\\sum \\ln(p)e^{is\\ln(p)}")#text(", as I understand just a position and momentum satisfy heisenberg uncertainty, time and energy also do ")#mi("\\Delta t\\Delta E\\ge \\frac{h}{2\\pi}")#text(" could ")#mi("\\Delta s\\Delta ln(p)\\ge c")#text(" make sense?, thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-543595")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2020")])]

#text("Well, it’s ")#mi("e^{s \\log p}")#text(" rather than ")#mi("e^{is \\log p}")#text(". So if one splits ")#mi("s = \\sigma+it")#text(" then the more accurate form of the uncertainty principle heuristic regarding the primes should be ")#mi("\\Delta t \\Delta \\log p \\gg 1")#text(". Thus, for instance, if one wants to count the number of primes in an interval of the form ")#mi("[x, x+x/T]")#text(" (so that ")#mi("\\log p")#text(" is confined to an interval of length ")#mi("O(1/T)")#text("), one should expect to need to control the Riemann zeta function ")#mi("\\zeta(\\sigma+it)")#text(" for heights ")#mi("t=O(T)")#text(". And this is indeed the case if one looks at what the truncated Perron formula actually gives (see e.g., Proposition 12 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")]#text(" ).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0de09d266d26079eaf69ee19087cf48aae60739ed03ce0c1a5da96c9ec174917-fc537f80f473858ff67191bfb513b3171102d88f73b2ebbf54fac5c71d0c766b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of trucupey")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-571178")[#strong[#text("trucupey")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2020")])]

#text("Hi, professor Tao, maybe I am not understanding well but in the example 14 of what you called heuristically statements, shouldn’t it say “In the low frequency (or large scale) limit, position and frequency asymptotically behave like a pair of classical observables … ” instead of “In the high frequency (or large scale) limit, position and frequency asymptotically behave like a pair of classical observables …” ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-572503")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2020")])]

#text("To achieve the semiclassical limit one has to make the product ")#mi("\\Delta x \\Delta \\xi")#text(" much larger than Planck’s constant ")#mi("\\hbar")#text(". There are two ways to do this: either go to high frequencies (so that ")#mi("\\Delta \\xi")#text(" becomes large) or large scales (so that ")#mi("\\Delta x")#text(" becomes large).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-636557")[#strong[#text("[scala] 프로그래밍에서 \"대수\"는 무엇을 의미합니까? - 리뷰나라")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2021")]

#text("[…] 이중 공간 을 보는 이유 는 일반적으로 그 공간에서 생각하기가 더 쉽기 때문입니다. 예를 들어, 법선 벡터에 대해 법선 평면보다 생각하기가 더 쉬운 경우가 있지만 벡터로 평면 (하이 평면 포함)을 제어 할 수 있습니다 (이제 광선 추적기와 같이 익숙한 기하학적 벡터에 대해 말하고 있습니다). . […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-657725")[#strong[#text("Adversarial examples and quant quakes – Research Notebook")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2022")]

#text("[…] in the data by diffusely spreading out across a large number of predictors. There’s a generalized uncertainty principle at work a la Donoho and Stark […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-675626")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2023")])]

#text("Dr Tao: You mentioned that the Poisson summation formula can be interpreted as a variant of the uncertainty principle using “adelic” topology. I don’t know anything about adelic topology. Could you explain a bit more about the interpretation? Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-684849")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2024")])]

#text("Should ")#mi("<e^{2\\pi ix\\xi}>")#text(" be decomposed into “")#mi("<e^{2\\pi i(x-x_{0})(\\xi-\\xi_{0})}e^{2\\pi ix_{0}(\\xi-\\xi_{0})}e^{2\\pi ix\\xi_{0}}>")#text("” when fourier transform restricted in ")#mi("<[\\xi_{0}-N,\\xi_{0}+N]>")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-693154")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2026")])]

#text("Dr Tao: Since the Riesz representation theorem for Hilbert spaces mentioned in point 5 reflects Hilbert duality, if we regard Banach spaces as a generalization of Hilbert spaces, can we also view the Riesz representation theorem on C₀(X) spaces in measure theory as the duality theorem too, which is Banach space duality (X is LCH)?")

#emph[#text("[Yes – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-693162")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2026")])]

#text("I believe entropic uncertainty principle gives both Heisenberg and Hardy UP. Is there p-adic version applicable in Physics, Engineering and Computer Science?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-693188")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2026")])]

#text("Can we make such a big list in non-commutative setting?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-693788")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2026")])]

#text("I believe the entropy uncertainty principle is another example. Are there also some fundamental theorems in random matrices and stochastic processes that can serve as examples connecting dual concepts?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-694166")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2026")])]

#text("Dear Dr Tao,")

#text("Could you explain in detail why the Hahn-Banach theorem is regarded as the duality theorem for the ")#emph[#text("Vector space duality")]#text(" and the ")#emph[#text("Vector subspace duality")]#text(" mentioned here? Also, why is this (duality) theorem suited to being proved by the Zorn’s lemma argument?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d17b4c62568d991aebc662167172e37e77c515886f33d213fda8323cabc5609f-11b98e38202929c4bc8ebf82bf80046911054078b0112d8f8021b3d1fe7a824f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of agustin.pinovalero")]], [#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/#comment-694183")[#strong[#text("agustin.pinovalero")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2026")])]

#text("Here comes a feeling: It seems that the meaning of a concept is unambiguous if and only if the set of elements to which the concept refers is the empty set.")
]
