// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/
// Converted to Typst by tao2typ: "2026-10-14T15:16:40.168104+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Good on ya, mate", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Good on ya, mate")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 February 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/")[#text("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The newly elected Australian Prime Minister, ")#link("http://en.wikipedia.org/wiki/Kevin_Rudd")[#text("Kevin Rudd")]#text(", ")#link("http://en.wikipedia.org/wiki/Stolen_Generation#Rudd_government_apology")[#text("apologises")]#text(" to the “")#link("http://en.wikipedia.org/wiki/Stolen_Generation")[#text("Stolen Generation")]#text("” of indigenous Australians for past government policies.")

#heading(level: 1)[#text("Comments (49)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9527221cf63bd4a5ac1f0e76087c731571e5acbde5ea461aa6d3471ce0f082bf-b9942300c0dfbea1968210e9c7f2791a4549089efbe07d6ae798d63b07ee5fc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vishal")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26112")[#strong[#text("Vishal")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2008")])]

#text("Interestingly, the US followed a ")#link("http://en.wikipedia.org/wiki/Americanization_%28of_Native_Americans%29")[#text("similar policy")]#text(" in the past ")#emph[#text("vis-a-vis")]#text(" the Native Americans and so did ")#link("http://en.wikipedia.org/wiki/Canadian_residential_school_system")[#text("Canada")]#text(". It seems colonization of lands in the past invariably led to such practices/policies, perhaps due to zealous religious men.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2a2f54c7ee7d23af06172a15bff339a516de7d21d600994fd7add0e4e61b3e93-a370e33da26faabe936757d66ddbf6d13462ee145e0ee19afba47fe73f322da4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Reid")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26128")[#strong[#text("Mark Reid")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2008")])]

#text("I went to the gathering between Old and New Parliament Houses in Canberra along with many hundred others to watch the speech live. Rudd’s speech was fantastic: humble, gracious, respectful and sincere. It was the first time in a long time I’ve been genuinely proud of what an Australian PM has had to say.")

#text("It was definitely worthy of a “Good On Ya, Mate” and one might go so far as to say, “Strewth, that was a bloody corker!”")

#text("For those who missed it, a ")#link("http://www.abc.net.au/news/video/2008/02/13/2161249.htm")[#text("video of the speech")]#text(" can be found at the ABC website.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26130")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2008")])]

#text("If you’re comparing it to the US, then here is the depressing part: After a century of guilt over the way that the US treated the Indians. the settlers are so vilified and the Indians are so ennobled that few Americans draw a useful connection between the past and the present. They legalize Indian casinos, partly out of guilt and partly out of greed. But there is little feeling that Americans could make the same mistakes now as then. The reality is that the Minnesota Massacre, for example, was the 9/11 of that period. The Governor of Minnesota wanted Lincoln to round up and hang hundreds of Indians. And instead of just reacting to the Minnesota Sioux or even all of the Sioux, public opinion turned against all American Indians. Fear trumped the wisdom that different tribes had little in common. The lesson for today is clear, but the Minnesota Massacre is downplayed out of guilt. But at the time it was a big deal; it is mentioned repeatedly in the “Little House” books, for example.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/183ac431bd6657accfef7a58db791109a5499f4c1a57a781098ddec7b1d1ad55-05624a636c0727db971e35da43cf45e63872582ab72b816f8b8042354ea778c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Julie")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26131")[#strong[#text("Julie")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2008")])]

#text("We were there too. It was wonderful. At last!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of km")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26157")[#strong[#text("km")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2008")])]

#text("Hey,")

#text("So, what can the White do to compensate for what they did? Withdraw from the continent and move to another one? Giving a hundred more apologies? The White is now dominating Australia. A little apology is nothing compared to how they hurt the natives on the land.")

#text("km")#linebreak()#text(" ps: I am not a native in Australia")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josuah Chamberlain")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26161")[#strong[#text("Josuah Chamberlain")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2008")])]

#text("The following comment of mine should not be taken as a justification for what happened to Ameridians and Aborgines.")

#text("If we are to condemn Whites for past atrociticies-which is absurd because Whites alive today had 0 to with what happened in the past-should we condemn other groups for the same reason? It is well documented that there were genocides in North American Ameridian-Native American-history.It’s not like the Ameridaian were Saints. European settelers weren’t doing anything that wasn’t being done within Ameridian America.")

#text("I don’t accept the racial guilt that is required when these apologies are made. Moral standards should be applied uniformly(moral symmetry principle.)")

#text("There was extreme violence and exterminations within Ameridaian American. America Ameridians were not great environmentalist either. In other words, Ameridians were just like every other racial group on the planet.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josuah Chamberlain")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26162")[#strong[#text("Josuah Chamberlain")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2008")])]

#text("And yes, Whites do demographically dominate Australia and America,. The Chinese demographically dominate China, The Hindus demographically dominate India. The muslims demographically dominate the middle east. Some people seemd to be really bothered by the fact that Whites/Europeans demographically dominate Australia, America and England. Changing this state of affairs as quickly as possible seems to be a very high priority for liberals,leftists and corporatists(worshipers of the corporation).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9527221cf63bd4a5ac1f0e76087c731571e5acbde5ea461aa6d3471ce0f082bf-b9942300c0dfbea1968210e9c7f2791a4549089efbe07d6ae798d63b07ee5fc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vishal")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26163")[#strong[#text("Vishal")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2008")])]

#text("@Josuah")

#text("Though there is a lot to be argued against ")#emph[#text("some")]#text(" of the points you mentioned above, I won’t debate them right now since this isn’t really a proper forum for such a debate. However, you have to be careful about making sloppy arguments like the one below.")

#emph[#text("The Hindus demographically dominate India. The muslims demographically dominate the middle east.")]

#text("Hindus and Muslims are not races! There are, in India, people belonging to ")#emph[#text("different races")]#text(" that practice Hinduism. Ditto for Muslims in the middle-east or anywhere else.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26166")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2008")])]

#text("If white people today are sincere, then it is good. As the Buddha and Confucius said, a confession (confession, not apology) can wash away any sin. But if I should be frank, I sometime fail to see that sincerity given my experience in the US and observation on the western world in general. Josuah’s comment above demonstrates such insincerity with his sloppy arguements as pointed out by Vishal.")

#text("However, there is improvement indeed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26167")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2008")])]

#text("Dear Josuah,")

#text("I do not have enough knowledge of native American history to comment accurately on affairs there. However, with regard to “moral symmetry”, I can say that the issue of the stolen generation and historical atrocities by, say, native Americans are not exactly on ")#link("http://en.wikipedia.org/wiki/Ceteris_paribus")[#emph[#text("ceteris paribus")]]#text(" (")#emph[#text("lit.")]#text(" all other things being equal) terms, for several reasons. Firstly, the matter of scale: the Australian policies of forcibly removing children from their families affected 100,000 children alone, and of course their families also. I would imagine that the numbers are at least an order of magnitude or more lower for any of the examples you mention. (Furthermore, unlike the situation with wars in which there is literally the possibility of a level playing field, the overwhelming number of “casualties” in this case were on one side of the conflict, due to the massive imbalance in power.) Secondly, the matter of time: these events are not ancient history, but continued until 1969 – well within living memory. In particular large numbers of children affected are still alive today. (The time gap would have been even narrower, had the previous government not delayed the apology for twelve years.) Thirdly, the matter of principles: like other modern democracies, Australia claims to aspire to various post-Enlightenment ideals involving equality, fundamental human rights, etc., and thus should be judged by these standards also.")

#text("It is commonplace for politicians, and ordinary citizens too, to boast of the past achievements of their country. “Moral symmetry” would require that they acknowledge past failures also.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josuah Chamberlain")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26171")[#strong[#text("Josuah Chamberlain")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2008")])]

#text("Dear Professor Tao")

#text("I think I agree with everything you wrote. I’m not making a case for treating Aborginals ar Ameridians badly. My point is that if population removal and extermination are morally wrong in one context/situation, it should be wrong in another. No one should get a free pass. The fact that it occurs/occured within “racial” family for centuries should not make a difference when passing moral judgements.")

#text("Vishal")

#text("Look, India is dominated by peoples in the South-Asian category. I specifically didn’t use the word race.")

#text("Jian")

#text("Your comments are an example of why I made this post. You are pushing the collective guilt framework which I don’t accept. Although I would accept a collective guilty verdict for the species.")

#text("I don’t accept the view that all Europeans are born with bloddy hands. Ditto for the Chinese and muslims.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9527221cf63bd4a5ac1f0e76087c731571e5acbde5ea461aa6d3471ce0f082bf-b9942300c0dfbea1968210e9c7f2791a4549089efbe07d6ae798d63b07ee5fc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vishal")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26172")[#strong[#text("Vishal")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2008")])]

#text("@Josuah")

#text("In public discourse, we refer to whites, blacks or aborigines as belonging to different races. So, even if you ")#emph[#text("don’t")]#text(" use the word ")#emph[#text("race")]#text(", the use of the word ")#emph[#text("white")]#text(" by yourself, earlier, implied you were talking about some specific race. Unless, of course, race means something completely different to you.")

#emph[#text("Look, India is dominated by peoples in the South-Asian category. I specifically didn’t use the word race.")]

#text("Earlier, you used the word ")#emph[#text("Hindus")]#text(" vis-a-vis India without knowing what you were talking about. Now, you change it to “peoples in the South-Asian category”. Those two have different meanings, if you must know.")

#emph[#text("My point is that if population removal and extermination are morally wrong in one context/situation, it should be wrong in another.")]

#text("No one denies that. However, we are not discussing things in their generality. We are talking here about a specific example: the “Stolen Generation” of indigenous Australians. I don’t think they were in a position to put up a fight against the government(s) of their time. They were pretty much helpless against the laws passed by the Parliament seeking to separate mothers and children at that time. Moreover, if Australians do aspire to the post-Enlightenment ideals – something that I didn’t know – as mentioned by Prof Tao and if the practice continued till 1969, then there is a lot to be answered.")

#emph[#text("I don’t accept the view that all Europeans are born with bloddy hands.")]

#text("Neither does anyone. But, what Jian ")#emph[#text("probably")]#text(" is referring to is the underlying feeling amongst a significant number of Asians (if not most) that colonization of distant lands in the past several hundred years by European colonial masters brought about a lot of destruction in those regions. And the imposition of foreign culture/religion on the indigenous people wrecked havoc on their ways of lives. So, the context has to be understood. No one is saying that Europeans are born bloody or anything.")

#text("And, seriously, there is no reason for you to be guilty about anything. You were not responsible directly or indirectly for the events in the past.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josuah Chamberlain")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26174")[#strong[#text("Josuah Chamberlain")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2008")])]

#text("Vishal")

#text("Some of the posts were moving into a more general direction. I don’t know what you mean by a “lot has to be answered”. The low economic and social status of Australian Aboriginals needs to be addressed. However, programs that address this problem should transcend “race”‘/tribal memebership. So what are we really talking about? Basically free health care, Education up through the college level, middle class job opportunities. In America and Australia, there are a lot of Whites who would fit a dispossessed underclass description. Why wouldn’t they qaulify for these programs.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26176")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2008")])]

#text("Josuah,")

#text("You are adding extra meanings to my comment. The “collective word” that I used was probably “white people”, but this is due to the limitation of language. If I said “some white people” it is still white people conceptually. you used the word too. However, I am not willing to go any further in this discussion. A Chinese proverb says “The universal truth is naturally in people’s heart”. It is in mine, and must be in yours too. Let it be.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9527221cf63bd4a5ac1f0e76087c731571e5acbde5ea461aa6d3471ce0f082bf-b9942300c0dfbea1968210e9c7f2791a4549089efbe07d6ae798d63b07ee5fc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vishal")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26178")[#strong[#text("Vishal")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2008")])]

#text("Josuah")

#emph[#text("The low economic and social status of Australian Aboriginals needs to be addressed. However, programs that address this problem should transcend “race”‘/tribal memebership.")]

#text("You are making contradictory statements. On one hand, apropos the present condition of the tribal people – I hope I am using the correct phrase here – in Australia, you agree that “corrective” measures must be undertaken by the government to help ")#emph[#text("precisely")]#text(" those people, and on the other, you say that such measures should transcend race/tribe. If the corrective measures are to be applied uniformly in Australian society, then how are we really helping those tribal people? Obviously, some “extra” programs must be implemented or something more has to be done for such people, otherwise, the very purpose of helping such people is defeated.")

#emph[#text("In America and Australia, there are a lot of Whites who would fit a dispossessed underclass description. Why wouldn’t they qaulify for these programs.")]

#text("I agree with you that there may be a lot of Whites who need help from the government just as much as the tribes for various reasons. But that is a separate problem. It has got ")#emph[#text("nothing")]#text(" to do with the problem of indigenous people and/or the stolen generation. In fact, you should press on the government to introduce measures to help the needy Whites as well. However, the two problems need not, or rather, should not be related to each other.")

#text("As to what kind of fair “compensation” – I use this for lack of a better word – the government is ready to provide to the indigenous people is a different albeit important matter. And this is where economists, policy makers, planners, and so on come into the picture.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9527221cf63bd4a5ac1f0e76087c731571e5acbde5ea461aa6d3471ce0f082bf-b9942300c0dfbea1968210e9c7f2791a4549089efbe07d6ae798d63b07ee5fc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vishal")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26179")[#strong[#text("Vishal")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2008")])]

#text("Prof Tao")

#text("I believe some kind of “compensation” should be provided to the members of the Stolen Generation and/or some extra measures should be undertaken to help them lead better lives. And, therefore, the government needs to decide the best/optimal way of allocating resources to such people and also to members from other non-tribal communities in the “fairest” way possible. And, this does bring to my mind the equivalent of the ")#link("http://en.wikipedia.org/wiki/Fair_division")[#text("cake-cutting problem")]#text(" but of course in a much more general sense. Would you like to hazard some guesses on how mathematics could be used to solve such a problem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26185")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2008")])]

#text("Terence,")

#text("Native American children were also subjected to removal from their families. They were placed in special boarding schools where they were forced to wear European style clothing, punished for speaking their own language, and force fed Christian religion. This was violent cultural aggression.")

#text("Very large numbers of Native Americans were wiped out by diseases that the Europeans carried and the Native Americans had never encountered before. Much of this biological warfare was probably unintentional, but there were definitely instances where it was intentional, such as offering blankets to tribes ostensibly as a friendly gesture while neglecting to mention that the blankets carried Small Pox.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2a2f54c7ee7d23af06172a15bff339a516de7d21d600994fd7add0e4e61b3e93-a370e33da26faabe936757d66ddbf6d13462ee145e0ee19afba47fe73f322da4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Reid")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26186")[#strong[#text("Mark Reid")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2008")])]

#text("Just to clarify the situation somewhat, if you read the actual ")#link("http://www.abc.net.au/news/events/apology/text.htm")[#text("content of the apology")]#text(" Rudd made it was exclusively on behalf of the Parliament of Australia – not on behalf of all Australians.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/acc1283f71ec7b231d5d76df9d5f236bd4d0a9a83cdc80f688199a7bb28128bc-8312915a95136cc57e5a9f73e03b153f539f00c1977afd181e142ef643864a37.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Luthy")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26192")[#strong[#text("Peter Luthy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("The debate which followed Terry’s post is typical, I think. It is one I have given a great amount of thought to. In what follows I will make analogy to the Holocaust not because I am making a direct comparison to the wrongs committed against the Stolen Generation, but because it’s something I know much more about.")

#text("I believe that assigning blame or finding people guilty of crimes of this magnitude (or really of any intensity) does not make things better. I don’t think that Jews feel any better about the Holocaust, despite having executed a great number of high ranking Nazi thugs — e.g. the Nuremburg trials. Adolf Eichmann, the man who proposed the Final Solution to the “Jewish problem” in Germany, was put to death in Israel in 1962, but I’m pretty sure that is little comfort to survivors or their descendants, the Abrahamic religions, or anyone at all — it is merely an ")#mi("\\epsilon")#text(".")

#text("This was a tragedy beyond recompense. One cannot undo what was done or magically clean the slate and start over. The same goes for the depopulation of the Americas and, from what I’ve garnered from the wikipedia article Terry posted, the atrocities endured by the Stolen Generation. In a very strong way, it doesn’t matter who was responsible. At the end of the day, the suffering don’t care (in their heart of hearts, anyway) who makes them suffer — they just wish it would stop happening.")

#text("The fact that white people were in charge at the time is immaterial. One should not feel ashamed of being white or any other race. I don’t think acts like these would never happen if the power structure was completely flipped or even if we lived in a world beyond race. Religion, social status, what have you: they are all equally successful ways that people in power have dehumanized people who aren’t.")

#text("The important lesson to glean from these events is not that one group in isolation committed horrifying acts against other humans for no good reason. It’s that deep down we have tendencies to that same bigotry, to that same terrifying propensity to hate or be idle in the face of it. The question is not who was bad or how much monetary recompense will make things ok again. This merely puts a bandaid on one wound. It should be, rather, how do we elevate society to a level where we no longer casually write-off the existence and happiness of many? How should we go about eliminating insurmountable suffering from this planet?")

#text("I think governments accepting that such suffering exists, that it is deplorable, and that it has happened in no small part due to a representative-government sanctioned activity is a good place to start. Cheers to the Australian government.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of km")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26194")[#strong[#text("km")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("It is like the following:")#linebreak()#text(" A selfish, cold-blooded man wants to occupy the house and backyard of his neighbour. To fulfill his greed, he used a machine gun to kill the whole family of his neighbour. Then, he moved to the dead neighbour’s house with his family, lived there and took it as their own home. 10 or so years later, he felt a little guilt and then made the following annoucement to make himself feel better: I am sorry to have killed my neighbour but I’ll continue to live there!")

#text("What is the point of making such an announcement or so called apology! Do you think it is basically bull shit? I certainly do!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of km")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26195")[#strong[#text("km")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("The white people should be shameful of what they have done to the natives on the southern continent!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26209")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("I guess I still have a few words to say.")

#text("The problem probably isn’t white people, but white people’s culture. There existed and still exists powerful or delicate civilizasions that did not, do not choose to conqire. I feel that Peter’s feeling though good intended but only based on limitted facts and is unhealthy.")

#text("The world is changing. I know many white people who feel very bad about their culture and history and look to the east.")

#text("Both Confucius and Buddha think people are originally good in nature. When people do bad things, it is because they are confused. Also, Karma is quite a genuine effect, one doesn’t need to look at it in a way of mysterism. For instance, I have observed that black people in the US are more alive than white people, and enjoy more dimensions of humanity (one has to live long in this country to see this, since at the begining it seems the opposite). When I think it through, I realized that white people are suffering from what they have done, and precisely because they are still human. Perhaps here I could respond to Josuah in different perspective: it may not be collective guilt framework, but collective Karma (a Buhhdist term). So white people will have to fix it anyway if they want to be happy themselves.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2fb853a1800c20ef09e109fbf166f518299f2ebd3167abc254d70e57aa0eea31-2094396f6eb2d93ebc4e0ab0ca225f48dadba608793f890ac165084c3f6cd1c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Not Happy")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26211")[#strong[#text("Not Happy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("This apology was more about Australian politics than anything else. As Mark Reid’s comment shows, there is a large segment of the Australian left that has a deep and visceral hatred for our previous Prime Minister (John Howard). This despite the fact that we was reelected three times, making him one of the most successful Prime Ministers in Australia’s history. Most of the online commentary on the apology has included some kind of snarky remark directed at John Howard.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26217")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("Dear Vishal:")

#text("Mathematical modeling is always limited by the accuracy of the model, the accuracy of the data, and on the amount of consensus as to what the objective to be optimised should be, so expecting (say) a computation of the optimal amount of compensation per capita which is accurate to four decimal places is unrealistic, to say the least. But one place where good modeling knowledge can help is to guard against overly simplified analysis and to indicate, at a qualitative level at least, what the possible unintended consequences of a given policy would be, and to give a rough indication of the magnitudes of such consequences. But this is more within the purview of economics and public policy than mathematics, really.")

#text("Dear km:")

#text("I think you may be conflating the issue of the “")#link("http://en.wikipedia.org/wiki/Stolen_Generation")[#text("Stolen generation")]#text("” with the separate issue of “")#link("http://en.wikipedia.org/wiki/Native_title")[#text("Native title")]#text("“, which is another important topic in indigenous Australian affairs, but not one which is directly related to the current subject of discussion. If you are interested in these things, I would encourage you to read further on the history and background of these matters, for instance by following the links mentioned by myself and others here.")

#text("I don’t think that anyone, least of all the Prime Minister, pretends that an apology alone resolves the entire issue; this is abundantly clear from the speech itself, if you read the text or listen to the video. But it is definitely a (rather necessary) step in the right direction. (Here we see another instance of the idiom “the perfect is the enemy of the good”; a move from 0% progress to 1% progress is criticised for not going far enough, thus inadvertently creating more incentive to keep progress stuck at 0%.)")

#text("Dear Jian:")

#text("Unfortunately, these sorts of events are not confined to one race or culture; it seems that any sufficiently large, powerful, or old country (or movement, organisation, corporation, etc.) will commit at least one shameful act during its history and within its sphere of influence, just from the law of averages and the non-zero imperfection of humanity alone if nothing else. One can, sadly, cite any number of examples from any number of cultures, from Darfur to Tiananmen square to almost any war or conflict of one’s choice, to back this statement up. Of course, this shouldn’t stop us from trying to lower one’s own “error rate” as much as possible, and the acknowledgment that a non-negligible error rate exists at all is a basic but fundamental first step in this direction. I for one would wish that more world leaders were able to honestly admit the past failings of the governments and countries they represent.")

#text("Dear Not Happy:")

#text("It is hard to avoid political overtones with these things, but as far as I am concerned, I would have commended John Howard just as equally if he had made a comparable apology during his tenure as Prime Minister. For what it is worth, I felt that Brendan Nelson (the current opposition leader) gave an acceptable apology – certainly better than no apology at all – though it was perhaps rationalised and qualified a little more than was appropriate.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Not Happy")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26219")[#strong[#text("Not Happy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("But do you condemn John Howard for not apologizing on behalf of the nation? What many on the left gloss over is that Howard expressed personal sorrow for the Stolen Generation, but for his own reasons (most of which I personally agree with), he chose not to apologize on behalf of the nation. And I dare say, such is the visceral and unreasoning hatred of Howard by the Australian left, had he given an identical speech to Rudd’s they would have found some way to pillory him.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26220")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("Dear Not Happy:")

#text("I don’t speak for this monolithic entity you call “the Australian left”, but if John Howard had given a speech with identical content (and more importantly, identical spirit and sincerity) to Kevin Rudd’s, then I for one would find any criticism of the speech based on Howard’s past policies or personal antipathy to be inappropriate. (In many ways, such a speech would in fact have been even more commendable, in a “Only Nixon could go to China” sort of way.)")

#text("Personally, I don’t condemn the former PM (I talked briefly to him once, and he seems like a reasonable enough person), but I do feel he missed out on an important opportunity to improve matters in these areas during his tenure. It seems that Rudd’s (and Nelson’s) apology has initiated a bit of momentum towards further reconciliation and improvement of the current abysmal state of indigenous Australians, in a way that a mere expression of personal sorrow would not have.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Not Happy")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26222")[#strong[#text("Not Happy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("Actually, the previous government did far more than any government before them to tackle head-on the problems of indigenous Australians. No doubt they could have done more, but they were the ones who rooted out the endemic corruption in ATSIC and took seriously the problems of child abuse amongst remote indigenous communities.")

#text("Those problems were impossible for previous Labor governments to address because to do so required sacrificing many of their long-held ideologies (the “Noble Savage” view of Aboriginals and the unwillingness to accept that long-term welfare dependency is socially destructive).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9527221cf63bd4a5ac1f0e76087c731571e5acbde5ea461aa6d3471ce0f082bf-b9942300c0dfbea1968210e9c7f2791a4549089efbe07d6ae798d63b07ee5fc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vishal")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26223")[#strong[#text("Vishal")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("Dear Prof Tao")

#text("That’s what I thought too. Indeed, my question had more to do with matters related to public policy and economics (and perhaps politics!). My apology for asking that naive question anyway. :-)")

#text("But just out of curiosity, do you read philosophical literature? I am guessing you have read stuff on the Enlightenment Philosophy. What writers/philosophers have influenced you the most? And what have you learned from them?")

#text("Jian")

#text("As Prof Tao hinted, we shouldn’t really blame whites or white culture – I am not sure what the latter exactly means – for the horrible acts committed by their elected governments or representatives. In fact, one of the lessons of World War II is that with PR (read propaganda), states/governments can (and they do) influence/convince the masses into believing that every act of the former is performed with the purpose of bringing peace and stability when, on the contrary, the aims are far from noble. We have had terrible pogroms/genocides committed by governments in China and the erstwhile Soviet Union against their own people in the past, but that doesn’t mean something is inherently wrong with the Chinese or Russians.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Chamberlain")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26238")[#strong[#text("Joshua Chamberlain")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("It looks like Australian Aboriginals have just launched a legal lawsuit to obtain compensation")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Chamberlain")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26239")[#strong[#text("Joshua Chamberlain")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("After WW1,The German people received a massive dose of collective punishment. John Maynard Keynes predicted that the terms of the peace would lead to something even worse than WW1. We all know what happened. WW2 was a direct consequence of a policy-terms of the peace -that had its basis in a collective “racial” guilt mindset. If you ever have the time, read Keynes book.")

#text("I should be possible to compensate the Australian Aboriginals in fair way without demonizing another “racial” group.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2a2f54c7ee7d23af06172a15bff339a516de7d21d600994fd7add0e4e61b3e93-a370e33da26faabe936757d66ddbf6d13462ee145e0ee19afba47fe73f322da4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Reid")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26240")[#strong[#text("Mark Reid")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("Not Happy:")

#text("I fail to see how my comments suggested a “deep and visceral hatred” of Howard. All I said in my earlier comment was that I didn’t find any of his speeches as PM as inspiring as Rudd’s apology.")

#text("Of course the apology is about politics, it has been since the idea of it was put forward by the Bringing Them Home report in 1997 and ignored by Howard. Many people disagreed with Howard’s response but, as you point out, the Coalition was voted in for three straight terms and so it could be argued his actions had a representative legitimacy.")

#text("Rudd made it very clear during his election campaign that he would apologise to the Stolen Generations as a matter of priority if elected. He was elected and so kept his promise. Many of the same people that thought Howard was right not to apologise would have disliked Rudd’s apology but it can be similarly argued that their opinion is no longer a representative one.")

#text("Howard, consistent with his earlier views about the issue, continued to make his political opinions known by being the only living ex-PM (Labor or Liberal) not to turn up to Parliament for the apology. In addition, several Liberal MPs chose not to be in the chamber for the apology. That’s entirely within their rights and they will be judged for their actions differently by different people. Provided disagreements can be discussed (although not necessarily resolved) without recourse to sweeping generalisations and emotionally charged attacks I think this makes for healthy politics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26245")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("Terence and Vishal,")

#text("Culture does have its role in this sort of act. I don’t see how that can be denied. Blaming the goverment for all is already dishonest and iresponsible. Remember, Ganhdi recieved inspiration from the Gita while Hitler from Nietzsche. You are intelligent people, I guess I don’t need to explain further.")

#text("Vishal,")

#text("I said, people are good in nature, and that is why they feel bad about their wrong doings after. Karma is an even term. A confessing individual would not consider it a punishemnt. It becomes a punishment only when there is apology but without confession.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of km")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26246")[#strong[#text("km")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("Dear Terrence,")

#text("I admit that I didn’t go deep about the issue being discussed. I saw the Prime Minster of Australia apologize and a big “Sorry” in the Australian sky on TV one day. The news was only briefly reported here in Hong Kong. After reading your cited article, I know that the white people not only occupied the land of the Australian Aboriginals with force but also broke down their families by removing the children from their parents.")

#text("This is a solid proof that the white people were without conscience! How could they do that to the Aboriginals? They should be condemned thousands of thousands of times!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26251")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("Dear km,")

#text("I think there is no reason to blame white people just because most of the people who occupied and forced aboriginals happened to be white. I think you are pushing too much. It is like “they had two legs, you have two legs too so you have to pay now”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Not Happy")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26295")[#strong[#text("Not Happy")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2008")])]

#text("km, read more about the history. Half-caste children (usually white father, black mother) were removed because they were at risk of being killed or seriously abused by the tribe.")

#text("You can debate the wisdom of such a policy but it was (in most cases) done with good intentions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Not Happy")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26296")[#strong[#text("Not Happy")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2008")])]

#text("Mark Reid, the fact that you admit to being ashamed of every speech ever made by John Howard indicates that you are quite likely afflicted with the same unreasoning hatred of Howard as the rest of the Australian left. I mean surely, somewhere in 12 years of speeches you could find one, just one, that met your high standards?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e093c233e3b4fd9212414ffdc0d05387015073c746c4571d57b8c51214acf03c-5d88fa03311d8419597a0e9087ae18cdffbacff798cecbf2f817831c878cbfa6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26298")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2008")])]

#text("“Not Happy”,")

#text("Judging from contents and tone, “km” is a youth in a distant land. In such case, the heart of him or her is more important than wisdom and knowledge. Unless all or most of the stolen generation are half-caste, otherwise your argument can be misleading. Even if most or all are half-caste, it shouldn’t be put as simply as “done with good intention”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26307")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2008")])]

#text("Dear “Not Happy”,")

#text("I think you might be reading a ")#link("http://en.wikipedia.org/wiki/False_dichotomy")[#text("false dichotomy")]#text(" into many of the comments here. Praise for an action of party X does not automatically imply criticism of the corresponding actions of party Y; “not being genuinely proud” of a speech is definitely not the same as being “ashamed” of that speech; and so forth.")

#text("In any event, these discussions are now becoming rather off-topic to the original topic, which was the recent (bipartisan) apology for previous policies towards the stolen Generation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Not Happy")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26354")[#strong[#text("Not Happy")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("Terrence, “damning with faint praise” is a common rhetorical device.")

#text("Jian, nearly all the stolen generation were mixed race. I don’t condone the policy, but nowhere in this debate have I seen any serious analysis of the motivations behind the policy or the effect of the policy: did it save children’s lives or not? Did it improve their living conditions or not? Was it motivated more by eugenics than a desire to protect?")

#text("Kevin Rudd in his speech devoted about 30s to this issue, unconvincingly attempting to claim the motivation was almost entirely eugenic. And he never discussed outcomes for stolen children versus those mixed-race who remained with their families. Of course, that suits the politics of the issue, but it is misleading and unfair at best.")

#text("In a sense, none of this matters, because the issue has become such a cause célèbre that the mere absence of an apology, regardless of the merits of past policies, has come to stand for racism and bigotry towards Aboriginals.")

#text("The apology suits both sides: the white left, almost none of whom would invite a disfunctional Aboriginal family into their own home, and hence need the apology to salve their own conscience; and the Aboriginals who can use this as a further buttress to their victim culture.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Not Happy")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26360")[#strong[#text("Not Happy")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("For an alternative viewpoint, this from Lara Wieland who spent eight years working as a doctor in Aboriginal communities in Cape York:")

#text("“I could not fathom the possibility that so many people in a community would “not care” about their children. The dysfunction has become so deep that many people do not even realise the damage that is being done to their young people.")

#text("They hardly bat an eyelid at events that would make your stomach churn. A young mother in a drunken state beats her young child with a stick and screams that she is going to kill him. The next day, that same mother, sober, hugs her child and does not even think about the lasting emotional scars. Why would she when her mother did the same to her, and her neighbours do the same, and no one has ever told her that it is wrong?")

#text("Children who have had sexually transmitted diseases and have been raped and molested are now parents. No one ever helped them or told them that what happened to them was wrong or not normal. Today’s teenage parents grew up in homes with hardly any furniture or toilet paper or soap or toothpaste.")

#text("They don’t know what it means to make your child wash with soap in the shower or brush their teeth at night. They eat meals that materialise – if they’re lucky – occasionally around pay day…")

#text("Boys raping younger boys becomes just boys “playing gay” – to be “told off”. Yes, young boys do often engage in explorative sexual play but that is completely different to non-consensual acts where pre-pubescent boys sodomise little kids with objects while they scream out “no”, or where older teenagers or adults watch as they make younger teenagers rape little kids, who then have nightmares….")

#text("Dysfunction is so entrenched that large swaths of the population’s children could meet the definition for removal because of abuse and/or neglect. It is impossible to remove all the children who would meet the criteria for removal. Certainly, children who are at immediate risk or who are in an unsafe situation must be removed immediately, and away from the community…”")

#text("Again, to all those in favour of National Sorry Day, for what exactly are we apologizing?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26363")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("Dear “Not Happy”,")

#text("1. Sometimes, a cigar is just a cigar. Not all expressions of “faint praise” are automatically expressions of “deep and visceral hatred”.")

#text("2. “Good intentions”, by themselves, are not sufficient to absolve responsibility for the consequences of one’s actions. We all know the type of roads one paves with such “good intentions”. For instance, forcible removal of children in the name of protection against sexual abuse does not imply that any subsequent sexual abuse perpetrated against such children in foster care needs no apology.")

#text("3. If you want “serious analysis”, I can recommend the “Bringing them home” report:")

#link("http://www.humanrights.gov.au/social_justice/bth_report/report/index.html")[#text("http://www.humanrights.gov.au/social_justice/bth_report/report/index.html")]

#text("which addresses many of your questions.")

#text("4. With regard to eugenics, it does seem that such sentiment was present in the early history of the policy, though it was later replaced by the slightly different philosophy of forcible assimilation. Here is a typical quote, from 1937:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Mr Neville [the Chief Protector of WA] holds the view that within one hundred years the pure black will be extinct. But the half-caste problem was increasing every year. Therefore their idea was to keep the pure blacks segregated and absorb the half-castes into the white population. Sixty years ago, he said, there were over 60,000 full-blooded natives in Western Australia. Today there are only 20,000. In time there would be none. Perhaps it would take one hundred years, perhaps longer, but the race was dying. The pure blooded Aboriginal was not a quick breeder. On the other hand the half-caste was. In Western Australia there were half-caste families of twenty and upwards. That showed the magnitude of the problem…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Not Happy")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26365")[#strong[#text("Not Happy")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("I could not see anywhere in the “Bringing them Home” report a comparative analysis of the outcomes for the removed children versus those left behind.")

#text("No doubt the removal of children was a tragedy, but the real tragedy is the history of Aboriginal people in Australia since white settlement. That is what led to the appalling conditions in which the children were (and still are) living today. Are you suggesting that Lara Wieland is wrong? That we should be leaving these children in harms way?")

#text("And I think your representation of the policy as one of eugenics or forcible assimilation is thoroughly unfair. Most of the evidence points towards it being a humanitarian policy, eg:")

#text("““Letters Blog | February 01, 2008")

#text("I was a Northern Territory police officer in the 1950s. No full-blood")#linebreak()#text(" Aboriginal child was ever removed from a tribal situation.")

#text("Only part-Aborigines were removed when their lives were in danger. This")#linebreak()#text(" danger arose at puberty, when a male would normally be initiated and a")#linebreak()#text(" female could marry. Both events required that the “skin’’ of the Aboriginal")#linebreak()#text(" parents be known, to determine the skin of the pubescent child. A")#linebreak()#text(" part-Aborigine could not have a skin. The part-Aboriginal female could be")#linebreak()#text(" used by any initiated male. The “skinless’’ male would just quietly")#linebreak()#text(" disappear.")

#text("I had a tracker who began living with a part-Aboriginal girl. She already")#linebreak()#text(" had a son who had red hair and freckles. They all lived in the Aboriginal")#linebreak()#text(" camp. The boy was not removed because he still had a few years before he")#linebreak()#text(" would reach puberty, when the danger would arise. I was subsequently")#linebreak()#text(" transferred to Alice Springs. My tracker followed me but left his consort")#linebreak()#text(" behind. Her son was probably eventually “stolen’’. If so, he is probably")#linebreak()#text(" still alive somewhere.")#linebreak()#text(" Tony Kelly")#linebreak()#text(" Eden Hills, SA”")

#text("But the left in Australia does not really want to get to the bottom of this. It suits those who prefer empty victim politics over real solutions to paint the whole thing as the result of malevolent and racist white policies.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of km")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26397")[#strong[#text("km")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2008")])]

#text("Not Happy,")

#text("You said the removal policy was launched for the sake of the children. If it was regarded by all that it was such a good policy, then why did it end? (It ended, right?)")

#text("Many bad, damaging or evil things were done with seemingly good excuses. But why were they stopped at last? If they are so good, they should be continued but not stopped by other people.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of km")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26398")[#strong[#text("km")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2008")])]

#text("Dear t8m8r,")

#text("Ok, I should be more precise.")

#text("It is without questions that those people who did that to the Australian Aboriginals should be condemned.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Not Happy")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26399")[#strong[#text("Not Happy")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2008")])]

#text("km, the policy ended because times changed. Tribes were no longer dominated by pure bloods. Government could exert more control over Aboriginal communities via other means. An expanded welfare state lessened the need for removal of children (in the same way that adopting out children of young mothers of all color all but stopped in the 70s).")

#text("Unfortunately, this debate is not about whether the policy helped the children or not, since no-one championing the apology seems interested in determining that. The Australian PM in his speech simply declared as fact (with essentially no supporting evidence) that the motivation was eugenic and assimilation, not protection. That is simply false, and a gross affront.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26405")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2008")])]

#text("“Not Happy”")

#text("I am sorry, I did not know the stolen generation was all mixed race. I was intending to protect the innocence of a youth since your argument reminded me those deceptive and misleading ones I heard here in the US (“population of American natives is higher now than it was before conolialism, therefore…” etc.). My earlier comments were refering to my experience in the US and observation on the western world in general. Since I am not suitable to comment specificly on Australian events, I can only point out in general, one must be very careful with “good intention” arguments, be it an initial “good intention” (such as Americans going to Iraq) or “good intention” as intreprated afterward (“Life standars are higher for blacks in the US now than those of Africa”. Which does not justify slavery trade.). As well, one should not isolate an event from the network that gives it its meaning. For instance, one can ask how the mixed race was created in the first place, etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9527221cf63bd4a5ac1f0e76087c731571e5acbde5ea461aa6d3471ce0f082bf-b9942300c0dfbea1968210e9c7f2791a4549089efbe07d6ae798d63b07ee5fc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vishal")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26409")[#strong[#text("Vishal")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2008")])]

#text("“Not Happy”, I think, has a lot of problems with the Australian left, or so it seems. And, since some of his arguments are ideological ones, I would be reluctant to get into the fray now. :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea51297cab21237d4cadda3a3356b9e71fd3d471e84e100be92dfa9cf413ca30-3abb0a3bebac451361ce44e0999e10d2fcde5930f79592f71864f2f6e06d68c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cardster")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26430")[#strong[#text("cardster")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2008")])]

#text("Terry thanks for your support for a long overdue gesture. I have always thought that many Australian “white folk” (to which group I belong) have had terrible attitudes towards non “white folks” Autsralians.")

#text("My own experience was growing up as a Catholic (I am now an athiest) in the 1950s. There was discrimination against Catholicsin that era. , but it was decreasing.")

#text("My parents showed me the true way; in the 1950s they welcomed everybody who crossed their hearth; Germans, Japanes, Italians and so on. They taught me that it’s personality that matters, not ethnic orgin, gender or social position. They also taught me not to judge others by ones own supposed standards.")

#text("Therefore, I hope that the apology is a first step to engaging all Australians into accepting that imposing European standards on our orginal countrymenis wrong. who may be still follow the concept that the group tather than the indivdual is paramount, ( see Hunter-Gather Survival 101).")

#text("As in education, the concept that one size fits all does not work. We need to engage aboriginal communities and provide them with hope.")

#text("It would be superb if you could find time to talk to some communites about opportunies from education (a big ask from someome with your time constrains but someone of your stature contacting Mr Rudd could make a difference).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/963cf853c016954f52375e5e48e7f861d3b867e9a1a0563be69f6e5030613c0e-57c0e38df17d1fb140a3dd725efbdc6bf7c514959f11f31a5e5ef3fd17f9c4b6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SteveGW")]], [#link("https://terrytao.wordpress.com/2008/02/13/good-on-ya-mate/#comment-26613")[#strong[#text("SteveGW")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2008")])]

#text("Well, I’m a bit late to this discussion, but on the off chance that anyone is here I’d like to make a few brief comments of clarification.")

#text("km wondered above why, if the policy of forced removal was such a good one, was it ever ended. The answer is that the policy never ended because there never was such a policy – at least not in the form that the Stolen Generations activists present it. The theory behind the term ‘Stolen Generations’ is that the mixed-bloods were removed from aboriginal parents primarily because of their racial type with the intention of eventually eliminating the aboriginal race. This theory has been tested in the Australian courts in the case, for example, of Lorna Cubill and Peter Gunner vs Commonwealth of Australia, and the judgement is that there is no evidence of there being any such policy. All those cases have failed. In cases like Trevorrow, where a fault has been admitted, the fault is found to be one of faulty application of laws, not the successful application of laws and policies that are morally repugnant.")

#text("Kevin Rudd and Julia Gillard assured Australia following the Apology that there would be no compensation. The most likely reason for their confidence on this point is that they have lawyer’s advice (that they refuse to make public) that no case will succeed in the future for the same reason that no case has succeeded in the past. There is just no case to answer.")

#text("Of course, knowing that, and attributing guilt (to others) and apologizing for them despite that knowledge makes the whole exercise somewhat less than admirable.")
]
