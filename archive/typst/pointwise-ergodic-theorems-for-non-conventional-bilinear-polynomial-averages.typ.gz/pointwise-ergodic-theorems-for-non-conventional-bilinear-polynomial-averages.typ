// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/
// Converted to Typst by tao2typ: "2026-10-14T16:38:49.466994+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Pointwise ergodic theorems for non-conventional bilinear polynomial averages", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Pointwise ergodic theorems for non-conventional bilinear polynomial averages")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 August 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/")[#text("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://www.math.princeton.edu/people/benjamin-krause")[#text("Ben Krause")]#text(", ")#link("https://sites.math.rutgers.edu/~mm2809/")[#text("Mariusz Mirek")]#text(", and I have uploaded to the arXiv our paper ")#link("https://arxiv.org/abs/2008.00857")[#text("Pointwise ergodic theorems for non-conventional bilinear polynomial averages")]#text(". This paper is a contribution to the decades-long program of extending the classical ergodic theorems to “non-conventional” ergodic averages. Here, the focus is on pointwise convergence theorems, and in particular looking for extensions of the pointwise ergodic theorem of Birkhoff:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Birkhoff ergodic theorem)")]#text(" Let ")#mi("{(X,\\mu,T)}")#text(" be a measure-preserving system (by which we mean ")#mi("{(X,\\mu)}")#text(" is a ")#mi("{\\sigma}")#text("-finite measure space, and ")#mi("{T: X \\rightarrow X}")#text(" is invertible and measure-preserving), and let ")#mi("{f \\in L^p(X)}")#text(" for any ")#mi("{1 \\leq p < \\infty}")#text(". Then the averages ")#mi("{\\frac{1}{N} \\sum_{n=1}^N f(T^n x)}")#text(" converge pointwise for ")#mi("{\\mu}")#text("-almost every ")#mi("{x \\in X}")#text(".")
]

#text("Pointwise ergodic theorems have an inherently harmonic analysis content to them, as they are closely tied to maximal inequalities. For instance, the Birkhoff ergodic theorem is closely tied to the Hardy-Littlewood maximal inequality.")

#text("The above theorem was generalized ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=937581")[#text("by Bourgain")]#text(" (conceding the endpoint ")#mi("{p=1}")#text(", where pointwise almost everywhere convergence is ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2680392")[#text("now known")]#text(" ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2788358")[#text("to fail")]#text(") to polynomial averages:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Pointwise ergodic theorem for polynomial averages)")]#text(" ")#metadata(none) <tao-1fd12105879ebe7e5251>#text(" Let ")#mi("{(X,\\mu,T)}")#text(" be a measure-preserving system, and let ")#mi("{f \\in L^p(X)}")#text(" for any ")#mi("{1 < p < \\infty}")#text(". Let ")#mi("{P \\in {\\bf Z}[{\\mathrm n}]}")#text(" be a polynomial with integer coefficients. Then the averages ")#mi("{\\frac{1}{N} \\sum_{n=1}^N f(T^{P(n)} x)}")#text(" converge pointwise for ")#mi("{\\mu}")#text("-almost every ")#mi("{x \\in X}")#text(".")
]

#text("For bilinear averages, we have a separate 1990 ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1037434")[#text("result of Bourgain")]#text(" (for ")#mi("{L^\\infty}")#text(" functions), extended to other ")#mi("{L^p}")#text(" spaces ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1745019")[#text("by Lacey")]#text(", and with an alternate proof given, ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2417419")[#text("by Demeter")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Pointwise ergodic theorem for two linear polynomials)")]#text(" ")#metadata(none) <tao-0fb3869113fc0be90046>#text(" Let ")#mi("{(X,\\mu,T)}")#text(" be a measure-preserving system with finite measure, and let ")#mi("{f \\in L^{p_1}(X)}")#text(", ")#mi("{g \\in L^{p_2}}")#text(" for some ")#mi("{1 < p_1,p_2 \\leq \\infty}")#text(" with ")#mi("{\\frac{1}{p_1}+\\frac{1}{p_2} < \\frac{3}{2}}")#text(". Then for any integers ")#mi("{a,b}")#text(", the averages ")#mi("{\\frac{1}{N} \\sum_{n=1}^N f(T^{an} x) g(T^{bn} x)}")#text(" converge pointwise almost everywhere.")
]

#text("It has been an open question for some time (see e.g., Problem 11 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3613710")[#text("this survey of Frantzikinakis")]#text(") to extend this result to other bilinear ergodic averages. In our paper we are able to achieve this in the partially linear case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Pointwise ergodic theorem for one linear and one nonlinear polynomial)")]#text(" ")#metadata(none) <tao-c9dd241a61068ecfdfbe>#text(" Let ")#mi("{(X,\\mu,T)}")#text(" be a measure-preserving system, and let ")#mi("{f \\in L^{p_1}(X)}")#text(", ")#mi("{g \\in L^{p_2}}")#text(" for some ")#mi("{1 < p_1,p_2 < \\infty}")#text(" with ")#mi("{\\frac{1}{p_1}+\\frac{1}{p_2} \\leq 1}")#text(". Then for any polynomial ")#mi("{P \\in {\\bf Z}[{\\mathrm n}]}")#text(" of degree ")#mi("{d \\geq 2}")#text(", the averages ")#mi("{\\frac{1}{N} \\sum_{n=1}^N f(T^{n} x) g(T^{P(n)} x)}")#text(" converge pointwise almost everywhere.")
]

#text("We actually prove a bit more than this, namely a maximal function estimate and a variational estimate, together with some additional estimates that “break duality” by applying in certain ranges with ")#mi("{\\frac{1}{p_1}+\\frac{1}{p_2}>1}")#text(", but we will not discuss these extensions here. A good model case to keep in mind is when ")#mi("{p_1=p_2=2}")#text(" and ")#mi("{P(n) = n^2}")#text(" (which is the case we started with). We note that norm convergence for these averages was established much earlier ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1412607")[#text("by Furstenberg and Weiss")]#text(" (in the ")#mi("{d=2}")#text(" case at least), and in fact norm convergence for arbitrary polynomial averages is now known thanks to the work of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2191208")[#text("Host-Kra")]#text(", ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2151605")[#text("Leibman")]#text(", and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2912715")[#text("Walsh")]#text(".")

#text("Our proof of Theorem ")#link(<tao-c9dd241a61068ecfdfbe>)[#text("4")]#text(" is much closer in spirit to Theorem ")#link(<tao-1fd12105879ebe7e5251>)[#text("2")]#text(" than to Theorem ")#link(<tao-0fb3869113fc0be90046>)[#text("3")]#text(". The property of the averages shared in common by Theorems ")#link(<tao-1fd12105879ebe7e5251>)[#text("2")]#text(", ")#link(<tao-c9dd241a61068ecfdfbe>)[#text("4")]#text(" is that they have “true complexity zero”, in the sense that they can only be only be large if the functions ")#mi("{f,g}")#text(" involved are “major arc” or “profinite”, in that they behave periodically over very long intervals (or like a linear combination of such periodic functions). In contrast, the average in Theorem ")#link(<tao-0fb3869113fc0be90046>)[#text("3")]#text(" has “true complexity one”, in the sense that they can also be large if ")#mi("{f,g}")#text(" are “almost periodic” (a linear combination of eigenfunctions, or plane waves), and as such all proofs of the latter theorem have relied (either explicitly or implicitly) on some form of time-frequency analysis. In principle, the true complexity zero property reduces one to study the behaviour of averages on major arcs. However, until recently the available estimates to quantify this true complexity zero property were not strong enough to achieve a good reduction of this form, and even once one was in the major arc setting the bilinear averages in Theorem ")#link(<tao-c9dd241a61068ecfdfbe>)[#text("4")]#text(" were still quite complicated, exhibiting a mixture of both continuous and arithmetic aspects, both of which being genuinely bilinear in nature.")

#text("After applying standard reductions such as the Calderón transference principle, the key task is to establish a suitably “scale-invariant” maximal (or variational) inequality on the integer shift system (in which ")#mi("{X = {\\bf Z}}")#text(" with counting measure, and ")#mi("{T(n) = n-1}")#text("). A model problem is to establish the maximal inequality ")#metadata(none) <tao-3edfc4202cd6ce823d00>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| \\sup_N \\left|A_N(f,g)\\right| \\right\\|_{\\ell^1({\\bf Z})} \\lesssim \\left\\|f\\right\\|_{\\ell^2({\\bf Z})}\\left\\|g\\right\\|_{\\ell^2({\\bf Z})}", block: true)]]

#text(" ")#text(" where ")#mi("{N}")#text(" ranges over powers of two and ")#mi("{A_N}")#text(" is the bilinear operator")

#align(center)[#tao-fit-display[#mitex("A_N(f,g)(x) := \\frac{1}{N} \\sum_{n=1}^N f(x-n) g(x-n^2).")]]

#text("The single scale estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| A_N(f,g) \\right\\|_{\\ell^1({\\bf Z})} \\lesssim \\left\\|f\\right\\|_{\\ell^2({\\bf Z})}\\left\\|g\\right\\|_{\\ell^2({\\bf Z})}", block: true)]]

#text("or equivalently (by duality)")

#metadata(none) <tao-36e0fd847d927d68475f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\frac{1}{N} \\sum_{n=1}^N \\sum_{x \\in {\\bf Z}} h(x) f(x-n) g(x-n^2) \\lesssim \\left\\|f\\right\\|_{\\ell^2({\\bf Z})}\\left\\|g\\right\\|_{\\ell^2({\\bf Z})} \\left\\|h\\right\\|_{\\ell^\\infty({\\bf Z})}", block: true)]]

#text("is immediate from Hölder’s inequality; the difficulty is how to take the supremum over scales ")#mi("{N}")#text(".")

#text("The first step is to understand when the single-scale estimate ")#link(<tao-36e0fd847d927d68475f>)[#text("(2)")]#text(" can come close to equality. A key example to keep in mind is when ")#mi("{f(x) = e(ax/q) F(x)}")#text(", ")#mi("{g(x) = e(bx/q) G(x)}")#text(", ")#mi("{h(x) = e(cx/q) H(x)}")#text(" where ")#mi("{q=O(1)}")#text(" is a small modulus, ")#mi("{a,b,c}")#text(" are such that ")#mi("{a+b+c=0 \\text{ mod } q}")#text(", ")#mi("{G}")#text(" is a smooth cutoff to an interval ")#mi("{I}")#text(" of length ")#mi("{O(N^2)}")#text(", and ")#mi("{F=H}")#text(" is also supported on ")#mi("{I}")#text(" and behaves like a constant on intervals of length ")#mi("{O(N)}")#text(". Then one can check that (barring some unusual cancellation) ")#link(<tao-36e0fd847d927d68475f>)[#text("(2)")]#text(" is basically sharp for this example. A remarkable result ")#link("https://arxiv.org/abs/1903.02592")[#text("of Peluse and Prendiville")]#text(" (generalised to arbitrary nonlinear polynomials ")#mi("{P}")#text(" ")#link("https://arxiv.org/abs/1909.00309")[#text("by Peluse")]#text(") asserts, roughly speaking, that this example basically the only way in which ")#link(<tao-36e0fd847d927d68475f>)[#text("(2)")]#text(" can be saturated, at least when ")#mi("{f,g,h}")#text(" are supported on a common interval ")#mi("{I}")#text(" of length ")#mi("{O(N^2)}")#text(" and are normalised in ")#mi("{\\ell^\\infty}")#text(" rather than ")#mi("{\\ell^2}")#text(". (Strictly speaking, the above paper of Peluse and Prendiville only says something like this regarding the ")#mi("{f,h}")#text(" factors; the corresponding statement for ")#mi("{g}")#text(" was established in a ")#link("https://arxiv.org/abs/2003.04122")[#text("subsequent paper of Peluse and Prendiville")]#text(".) The argument requires tools from additive combinatorics such as the Gowers uniformity norms, and hinges in particular on the “degree lowering argument” of Peluse and Prendiville, which I discussed in ")#link("https://terrytao.wordpress.com/2020/03/08/cut-norms-and-degree-lowering/")[#text("this previous blog post")]#text(". Crucially for our application, the estimates are very quantitative, with all bounds being polynomial in the ratio between the left and right hand sides of ")#link(<tao-36e0fd847d927d68475f>)[#text("(2)")]#text(" (or more precisely, the ")#mi("{\\ell^\\infty}")#text("-normalized version of ")#link(<tao-36e0fd847d927d68475f>)[#text("(2)")]#text(").")

#text("For our applications we had to extend the ")#mi("{\\ell^\\infty}")#text(" inverse theory of Peluse and Prendiville to an ")#mi("{\\ell^2}")#text(" theory. This turned out to require a certain amount of “sleight of hand”. Firstly, one can dualise the theorem of Peluse and Prendiville to show that the “dual function”")

#align(center)[#tao-fit-display[#mitex("A^*_N(h,g)(x) = \\frac{1}{N} \\sum_{n=1}^N h(x+n) g(x+n-n^2)")]]

#text("can be well approximated in ")#mi("{\\ell^1}")#text(" by a function that has Fourier support on “major arcs” if ")#mi("{g,h}")#text(" enjoy ")#mi("{\\ell^\\infty}")#text(" control. To get the required extension to ")#mi("{\\ell^2}")#text(" in the ")#mi("{f}")#text(" aspect one has to improve the control on the error from ")#mi("{\\ell^1}")#text(" to ")#mi("{\\ell^2}")#text("; this can be done by some interpolation theory combined with the useful Fourier multiplier theory ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2188130")[#text("of Ionescu and Wainger")]#text(" on major arcs. Then, by further interpolation using recent ")#mi("{\\ell^p({\\bf Z})}")#text(" improving estimates of ")#link("https://arxiv.org/abs/1910.14630")[#text("Han, Kovac, Lacey, Madrid, and Yang")]#text(" for linear averages such as ")#mi("{x \\mapsto \\frac{1}{N} \\sum_{n=1}^N g(x+n-n^2)}")#text(", one can relax the ")#mi("{\\ell^\\infty}")#text(" hypothesis on ")#mi("{g}")#text(" to an ")#mi("{\\ell^2}")#text(" hypothesis, and then by undoing the duality one obtains a good inverse theorem for ")#link(<tao-36e0fd847d927d68475f>)[#text("(2)")]#text(" for the function ")#mi("{f}")#text("; a modification of the arguments also gives something similar for ")#mi("{g}")#text(".")

#text("Using these inverse theorems (and the Ionescu-Wainger multiplier theory) one still has to understand the “major arc” portion of ")#link(<tao-3edfc4202cd6ce823d00>)[#text("(1)")]#text("; a model case arises when ")#mi("{f,g}")#text(" are supported near rational numbers ")#mi("{a/q}")#text(" with ")#mi("{q \\sim 2^l}")#text(" for some moderately large ")#mi("{l}")#text(". The inverse theory gives good control (with an exponential decay in ")#mi("{l}")#text(") on individual scales ")#mi("{N}")#text(", and one can leverage this with a Rademacher-Menshov type argument (see e.g., ")#link("https://terrytao.wordpress.com/2020/05/14/247b-notes-4-almost-everywhere-convergence-of-fourier-series/")[#text("this blog post")]#text(") and some closer analysis of the bilinear Fourier symbol of ")#mi("{A_N}")#text(" to eventually handle all “small” scales, with ")#mi("{N}")#text(" ranging up to say ")#mi("{2^{2^u}}")#text(" where ")#mi("{u = C 2^{\\rho l}}")#text(" for some small constant ")#mi("{\\rho}")#text(" and large constant ")#mi("{C}")#text(". For the “large” scales, it becomes feasible to place all the major arcs simultaneously under a single common denominator ")#mi("{Q}")#text(", and then a quantitative version of the Shannon sampling theorem allows one to transfer the problem from the integers ")#mi("{{\\bf Z}}")#text(" to the locally compact abelian group ")#mi("{{\\bf R} \\times {\\bf Z}/Q{\\bf Z}}")#text(". Actually it was conceptually clearer for us to work instead with the ")#link("https://en.wikipedia.org/wiki/Adele_ring#Alternative_definition_for_number_fields")[#text("adelic integers")]#text(" ")#mi("{{\\mathbf A}_{\\bf Z} ={\\bf R} \\times \\hat {\\bf Z}}")#text(", which is the inverse limit of the ")#mi("{{\\bf R} \\times {\\bf Z}/Q{\\bf Z}}")#text(". Once one transfers to the adelic integers, the bilinear operators involved split up as tensor products of the “continuous” bilinear operator")

#align(center)[#tao-fit-display[#mitex("A_{N,{\\bf R}}(f,g)(x) := \\frac{1}{N} \\int_0^N f(x-t) g(x-t^2)\\ dt")]]

#text("on ")#mi("{{\\bf R}}")#text(", and the “arithmetic” bilinear operator")

#align(center)[#tao-fit-display[#mitex("A_{\\hat Z}(f,g)(x) := \\int_{\\hat {\\bf Z}} f(x-y) g(x-y^2) d\\mu_{\\hat {\\bf Z}}(y)")]]

#text("on the ")#link("https://en.wikipedia.org/wiki/Profinite_integers")[#text("profinite integers")]#text(" ")#mi("{\\hat {\\bf Z}}")#text(", equipped with probability Haar measure ")#mi("{\\mu_{\\hat {\\bf Z}}}")#text(". After a number of standard manipulations (interpolation, Fubini’s theorem, Hölder’s inequality, variational inequalities, etc.) the task of estimating this tensor product boils down to establishing an ")#mi("{L^q}")#text(" improving estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| A_{\\hat {\\bf Z}}(f,g) \\right\\|_{L^q(\\hat {\\bf Z})} \\lesssim \\left\\|f\\right\\|_{L^2(\\hat {\\bf Z})} \\left\\|g\\right\\|_{L^2(\\hat {\\bf Z})}", block: true)]]

#text("for some ")#mi("{q>2}")#text(". Splitting the profinite integers ")#mi("{\\hat {\\bf Z}}")#text(" into the product of the ")#mi("{p}")#text("-adic integers ")#mi("{{\\bf Z}_p}")#text(", it suffices to establish this claim for each ")#mi("{{\\bf Z}_p}")#text(" separately (so long as we keep the implied constant equal to ")#mi("{1}")#text(" for sufficiently large ")#mi("{p}")#text("). This turns out to be possible using an arithmetic version of the Peluse-Prendiville inverse theorem as well as an arithmetic ")#mi("{L^q}")#text(" improving estimate for linear averaging operators which ultimately arises from some estimates on the distribution of polynomials on the ")#mi("{p}")#text("-adic field ")#mi("{{\\bf Q}_p}")#text(", which are a variant of some estimates ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3000832")[#text("of Kowalski and Wright")]#text(".")

#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03641b63e9d7878d4a6a6febb01899a0e4fb1dea91164bf5f79c34bf5e07bb5f-e719ddee485abcd417ea8aee7a610f08f06272926aba11e8730944f5e257b618.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwerty")]], [#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/#comment-579465")[#strong[#text("qwerty")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2020")])]

#text("Theorem 2: did you mean p>1?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83fae7dcf7ac806ac46aba7e81102b2e05a8e5d49f6a1af44bbcf18ba1d41c08-92d5afbe2b64e7d2bb1c98ec989c7b0935da33b4b9a29697ac69ea8b27086b8c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of IQ news")]], [#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/#comment-586785")[#strong[#text("IQ news")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2020")])]

#text("I believe the author of this blog is a person with a high IQ. I read an article about him with the highest IQ in America.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/#comment-579530")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2020")])]

#text("Is the upper bound 3/2 in theorem 3 the best possible ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/#comment-580299")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2020")])]

#text("This question (or its counterpart for the closely related bilinear Hilbert transform) is actually one of the key open problems in time frequency analysis; the standard time-frequency techniques break down past this threshold, but this has not yet led to an actual counterexample to boundedness or convergence beyond this point. See for instance ")#link("https://arxiv.org/abs/1409.3875")[#text("https://arxiv.org/abs/1409.3875")]#text(" for some attempts to create such counterexamples.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/#comment-579952")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2020")])]

#text("Should $G(x) = H(x)$ rather than $G(x) = F(x)$ to respect the $N^2$ spatial scale?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Satan")]], [#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/#comment-580348")[#strong[#text("Satan")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2020")])]

#text("terence tao Let me attempt to make the path integral rigorous.")#linebreak()#text(" you can define the path integral as follows.")

#text("you discretize the 3d space and you define a path from point (x,y,z) to point (x’,y’,z’) by adjacent cubes.")#linebreak()#text(" for every such discrete path you give it a weight which is as follows:")#linebreak()#text(" the number of algorithms which produce this path divided by the total number of algorithms – and taking this limit to infinity, in other words the probability of a random algorithm generator to produce an algorithm which produce this path.")#linebreak()#text(" then you sum over all path each multiplied by its weigh, and because you discretized the space you take this infinite sum to the limit of infinity such that in each step the cubes that divide the space are smaller and smaller")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b24f64a216946f595854696297e5d05c40d08af89fe00bed34c5637cf590a02-818fe79e329ac73205d37288b757662d20e11838e944d54954356be6a2c94785.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Asaf")]], [#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/#comment-580402")[#strong[#text("Asaf")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2020")])]

#text("Are there characteristic factors (in the sense of Furstenberg-Weiss) for those types of averages?")

#text("Another question – is the convergence result becomes easier when we assume some mixing condition on one system (or both)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/#comment-581275")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2020")])]

#text("For these averages the characteristic factor is the profinite (or rational Kronecker) factor, i.e., the factor generated by the periodic functions (or the rational spectrum of the shift). This is basically already in the original paper of Furstenberg and Weiss (at least for the quadratic polynomial ")#mi("P(n)=n^2")#text(").")

#text("Mixing conditions certainly make norm convergence easier, but to my knowledge there is no way to use mixing hypotheses to simplify the proof of pointwise ae convergence for these averages. But there is prior work establishing pointwise convergence for multilinear polynomial averages for exact endomorphisms and K-automorphisms by Derrien and Lesigne (reference [20] in the paper).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike Jones")]], [#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/#comment-580403")[#strong[#text("Mike Jones")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2020")])]

#text("Where did you submit this paper?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Ionescu-Wainger multiplier theorem and the adeles | What's new")]], [#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/#comment-582028")[#strong[#text("The Ionescu-Wainger multiplier theorem and the adeles | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2020")])]

#text("[…] I’ve just uploaded to the arXiv my paper The Ionescu-Wainger multiplier theorem and the adeles“. This paper revisits a useful multiplier theorem of Ionescu and Wainger on “major arc” Fourier multiplier operators on the integers (or lattices ), and strengthens the bounds while also interpreting it from the viewpoint of the adelic integers (which were also used in my recent paper with Krause and Mirek). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/#comment-582739")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2020")])]

#text("Within the references of the paper uploaded on ArXiv, a minor correction related to the ref #20: Un théorème … Annales de l’Institut Henri Poincaré (IHP)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc5fbd9259de635483b56a771a37f23596fa7b320f0ce80fd4c181e9caa9956d-0b064a96a993a5f5f354bdd6467301559d7a8a18519db0412943970a8e5bd844.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/#comment-582749")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2020")])]

#text("Congratulations for your paper.")#linebreak()#text(" In order to improve it, within the references of its first version uploaded on the ArXiv plateform, here are very minor corrections and precisions related to :")#linebreak()#text(" – the ref #15: … des groupes p-adiques. Bulletin de la Société Mathématique de France (SMF), 89:43-75, Paris, France, 1961.")#linebreak()#text(" – the ref #20: Un théorème … Annales de l’Institut Henri Poincaré (IHP) en probabilités et statistiques, 32(6):765-778, Paris, France, 1996.")#linebreak()#text(" – the ref #23: for paraproducts. (the final dot is missing)")#linebreak()#text(" Kind regards")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chen")]], [#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/#comment-585379")[#strong[#text("Chen")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2020")])]

#text("Just found a typo, in Theorem 2, the second “polynpmial”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Huang")]], [#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/#comment-586818")[#strong[#text("Huang")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2020")])]

#text("Another typo founded: “Fubini’s theorem, Holder’s inequality” => “Fubini’s theorem, Ho¨lder’s inequality”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/#comment-684816")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2024")])]

#text("Hello, professor Tao: I’d like to know more on open question (7) in the paper. Based on the spirit the similarity on the proof of boundedness of bilinear Hilbert transform and bilinear maximal function. Could we expect to use the methods in the paper to establish the bounededness of bilinear Radon transform (or its truncation version): ")#mi("\\sum_{k \\neq0}\\frac{1}{k}f(T^kx)g(T^{k^2}x)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/#comment-684820")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2024")])]

#text("It’s possible, but not guaranteed. The ")#mi("1/k")#text(" weight potentially generates additional logarithmic divergences in many of the estimates used in our arguments; the question is whether the various gains that we also manage to obtain are sufficiently strong to counteract this divergence. My initial guess is that a naive replication of our arguments will fail to contain these divergences (for instance, the L^p improving inequalities probably fail once such weights are introduced), but it is possible that the argument could somehow be refactored in a way that the logarithmic divergences are only experienced when considering those components of the proof that have really strong additional cancellations. One reason to pursue questions like this is that it may force the person researching these questions to develop a more efficient or simpler proof of our original theorem in order to be able to extend it to the singular setting; I certainly don’t claim that our arguments are the *only* way to proceed for these sorts of questions!")

#text("As discussed in the paper, there may be model versions of these questions on other domains than the integers, such as the reals, the p-adics, or the adeles, which may be worth studying first as toy problems that already capture some, but not all, of the main difficulties.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/#comment-684822")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2024")])]

#text("Thanks for detailed explications!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pointwise convergence of bilinear polynomial averages over the primes | What's new")]], [#link("https://terrytao.wordpress.com/2020/08/03/pointwise-ergodic-theorems-for-non-conventional-bilinear-polynomial-averages/#comment-685784")[#strong[#text("Pointwise convergence of bilinear polynomial averages over the primes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2024")])]

#text("[…] of bilinear polynomial averages over the primes“. This paper builds upon a previous result of Krause, Mirek, and myself, in which we demonstrated the pointwise almost everywhere convergence of the ergodic […]")
]
