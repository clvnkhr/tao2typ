// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/04/16/tricki-now-live/
// Converted to Typst by tao2typ: "2026-10-14T07:20:11.772426+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Tricki now live", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Tricki now live")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 April 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/04/16/tricki-now-live/")[#text("https://terrytao.wordpress.com/2009/04/16/tricki-now-live/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("From ")#link("http://gowers.wordpress.com/")[#text("Tim Gowers’ blog")]#text(" comes the ")#link("http://gowers.wordpress.com/2009/04/16/tricki-now-fully-live/")[#text("announcement")]#text(" that the Tricki – a wiki for various tricks and strategies for proving mathematical results – ")#link("http://www.tricki.org/")[#text("is now live")]#text(". (My own articles for the Tricki are ")#link("https://terrytao.wordpress.com/category/expository/tricks/")[#text("also on this blog")]#text("; also Ben Green has written up an ")#link("http://www.tricki.org/article/Use_finite_fields")[#text("article on using finite fields")]#text(" to prove results about infinite fields which is loosely based on ")#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/")[#text("my own post on the topic,")]#text(" which is in turn based on an ")#link("http://arxiv.org/abs/0903.0517")[#text("article of Serre")]#text(".) It seems to already be growing at a reasonable rate, with many contributors.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2009/04/16/tricki-now-live/#comment-38207")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2009")])]

#text("Nice, but I hope there are more algebraic articles to come.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2009/04/16/tricki-now-live/#comment-38214")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2009")])]

#text("I hope there will be more algebraic articles too. In fact part of my thinking in writing a couple of (loosely) algebraic articles was that more expert readers would be so affronted by my ignorance that they could not help but make corrections and supply further discussion. I hope to see that happening!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/04/16/tricki-now-live/#comment-38215")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2009")])]

#text("I too very much hope that there will be more algebraic articles, and my motivation for writing a couple of articles on group theory was much the same as the motivation that Ben expresses above. I’m glad to see that Henry Wilton has already contributed a group theory article.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/16/tricki-now-live/#comment-38220")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2009")])]

#text("In that spirit, I just contributed another group theory article to the Tricki:")

#link("http://www.tricki.org/article/First_pretend_that_a_normal_subgroup_is_trivial")[#text("http://www.tricki.org/article/First_pretend_that_a_normal_subgroup_is_trivial")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2009/04/16/tricki-now-live/#comment-38235")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2009")])]

#text("Dear Professor Tao,")

#text("you (or someone else) could write a short article on “making divergent expressions into precise proofs” explaining what you meant in your blog entry on Tate’s thesis about using distributions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/16/tricki-now-live/#comment-38262")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2009")])]

#text("Dear Anon,")

#text("There is some discussion on this at the tricki article")

#link("http://www.tricki.org/article/Create_an_epsilon_of_room")[#text("http://www.tricki.org/article/Create_an_epsilon_of_room")]

#text("particularly in Example 5. (For the manipulations involving adeles, one would probably want to perform some regularisations based on gaussians; such computations are not yet on that tricki article, but presumably one could request a computation there.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/16/tricki-now-live/#comment-38286")[#strong[#text("Tricki opens its doors // La Tricki abre sus puertas « chimathera")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2009")]

#text("[…] More information available at: Tricki now fully live – Gowers Tricki now live – Tao […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3529ef3432f19f545244ebd5f1dcf2e0c12c9d7a202f84575075a8a6a8f28b46-4e0415730b98015d10729ff930abd4ed7e2d3b9eb85d1d109c12918dde1913bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JoseBrox")]], [#link("https://terrytao.wordpress.com/2009/04/16/tricki-now-live/#comment-38287")[#strong[#text("JoseBrox")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2009")])]

#text("Hi Terry!")

#text("I trackbacked you at my new wordpress blog (chimathera) and mentioned you in my first post as an example of a mathematician who uses (and uses well!) the “Tricki techniques”. I hope you don’t mind!")

#text("Regards, Jose Brox")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/16/tricki-now-live/#comment-38493")[#strong[#text("How to Write a Really Good Research Paper « Successful Researcher")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2009")]

#text("[…] Mathematicians can also make use of the classical text How to write mathematics by Paul R. Halmos. Another potentially very promising tool for mathematicians is Tricki (the wiki of math tricks and techniques) whose aims and scope are discussed at the blogs of the Fields medalists Tim Gowers and Terence Tao, see e.g. here and here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/16/tricki-now-live/#comment-40764")[#strong[#text("Trucos y consejos para demostraciones Matemáticas")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2009")]

#text("[…] niveles superiores, es más, el lanzamiento de Tricki.org lo conocí hace unos meses gracias a un post del Dr. Terry Tao (Medalla Fields en el 2006, algo así como el Novel en Matemáticas), desde entonces la cantidad de […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/16/tricki-now-live/#comment-143797")[#strong[#text("Tricki Math Methods Website | New Math Done Right")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2012")]

#text("[…] Terry Tao announcement on Tricki now live. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/16/tricki-now-live/#comment-499708")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2018")])]

#text("It seems that Tricki is not active anymore.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/04/16/tricki-now-live/#comment-499928")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2018")])]

#text("That’s basically correct, and it’s a phenomenon I hope to learn from. I think the fundamental problem with it was that it was quite hard to make a really good contribution to it: for a website to take off, there needs to be a lower bar to participation.")
]
]
