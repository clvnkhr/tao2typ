// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/04/21/write-in-your-own-voice/
// Converted to Typst by tao2typ: "2026-10-14T15:17:44.256748+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Write in your own voice", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Write in your own voice")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 April 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/04/21/write-in-your-own-voice/")[#text("https://terrytao.wordpress.com/2010/04/21/write-in-your-own-voice/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("It’s been a while since I’ve added to my ")#link("https://terrytao.wordpress.com/career-advice/")[#text("career advice")]#text(" and ")#link("https://terrytao.wordpress.com/advice-on-writing-papers/")[#text("writing pages")]#text(" on this blog, but I recently took the time to write up another such page on a topic I had not previously covered, entitled “")#link("https://terrytao.wordpress.com/advice-on-writing-papers/write-in-your-own-voice/")[#text("Write in your own voice")]#text("“. The main point here is that while every piece of mathematical research inevitably builds upon the previous literature, one should not mimic the style and text of that literature slavishly, but instead develop one’s own individual style, while also updating and adapting the results and insights of previous authors.")

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/33c234ea8634575b8fb3de26ca009aba6c65655c2f96d779c52620a6f1856d04-5428f352c19b9e341f44807e5bc234f6848fca221bb357f5752f211fd4551d7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yiwei")]], [#link("https://terrytao.wordpress.com/2010/04/21/write-in-your-own-voice/#comment-44335")[#strong[#text("Yiwei")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2010")])]

#text("Hi Terry,")

#text("Well, I can not agree this more.")

#text("I also wish authors to write their work ‘in situ’. Anyway, the history is unique. I believe that looking things in an abstract way is harmful, especially abstracting without pointing out the origin.")

#text("Here is a polt in my mind.")

#text("The other day, one got an idea independently under certain situation and worked it out. There are two cases, among other things: 1) later, he found that someone else had published the ‘same’ work. So, he normally attempted to abandon (i.e. do not publish) his work. 2) later, he found that no one had published the same work; but, when he published it, he found that when other ones tried to understand his work with their own knowledge, his work was apt to be distorted more or less, say relating his work to the existing ones, and getting his work ‘derived’ from the existing ones, although it was not the case for him, and atributed the contribution to authors other than him. I call this ‘reverse plagiarism’ or ‘backward plagiarism’. I believe that it is a common experience for many authors.")

#text("So, if the authors are allowed to write their work ‘in situ’, such ‘reverse plagiarism’ may be avoided.")

#text("Yiwei")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/21/write-in-your-own-voice/#comment-44346")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2010")])]

#text("Those who write in polished and understated British style English, a style no one owns, will tend to sound alike, but vast and obvious differences in substance will remain. Moreover, people can tell the difference between Elvis and an Elvis impersonator. So don’t worry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2010/04/21/write-in-your-own-voice/#comment-44359")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2010")])]

#text("This is somewhat tangential but falls under the general category of individual style in mathematical writing:")

#link("http://mathoverflow.net/questions/22299/what-are-some-examples-of-colorful-language-in-serious-mathematics-papers")[#text("http://mathoverflow.net/questions/22299/what-are-some-examples-of-colorful-language-in-serious-mathematics-papers")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aea8901d860592d4454d2d9f5895133b9588ce69aa393dc7de3bc8b38b7a7119-b4b7acf4d3378d70d90ca8d8757b8a0c3d821d01625fbb4409544bc1968001f9.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of APA citation style – some examples | Universiti Kuala Lumpur Library Blog")]], [#link("https://terrytao.wordpress.com/2010/04/21/write-in-your-own-voice/#comment-491507")[#strong[#text("APA citation style – some examples | Universiti Kuala Lumpur Library Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2018")])]

#text("[…] [Terence]. (2010, April 21). Write in your own voice [Blog post]. Retrieved January 23, 2014 from ")#link("https://terrytao.wordpress.com/2010/04/21/write-in-your-own-voice/")[#text("https://terrytao.wordpress.com/2010/04/21/write-in-your-own-voice/")]#text(" In-text citation: (Tao, […]")
]
