// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/03/11/sumfree-sets-in-groups/
// Converted to Typst by tao2typ: "2026-10-14T15:19:40.460233+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Sumfree sets in groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Sumfree sets in groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 March 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/03/11/sumfree-sets-in-groups/")[#text("https://terrytao.wordpress.com/2016/03/11/sumfree-sets-in-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.ams.org/mathscinet/search.html")[#text("Van Vu")]#text(" and I just posted to the arXiv our paper “")#link("http://arxiv.org/abs/1603.03068")[#text("sum-free sets in groups")]#text("” (submitted to ")#link("http://discreteanalysisjournal.com/")[#text("Discrete Analysis")]#text("), as well as ")#link("http://arxiv.org/abs/1603.03071")[#text("a companion survey article")]#text(" (submitted to ")#link("http://intlpress.com/site/pub/pages/journals/items/joc/_home/_main/")[#text("J. Comb")]#text(".). Given a subset ")#mi("{A}")#text(" of an additive group ")#mi("{G = (G,+)}")#text(", define the quantity ")#mi("{\\phi(A)}")#text(" to be the cardinality of the largest subset ")#mi("{B}")#text(" of ")#mi("{A}")#text(" which is ")#emph[#text("sum-free in ")#mi("{A}")]#text(" in the sense that all the sums ")#mi("{b_1+b_2}")#text(" with ")#mi("{b_1,b_2}")#text(" distinct elements of ")#mi("{B}")#text(" lie outside of ")#mi("{A}")#text(". For instance, if ")#mi("{A}")#text(" is itself a group, then ")#mi("{\\phi(A)=1}")#text(", since no two elements of ")#mi("{A}")#text(" can sum to something outside of ")#mi("{A}")#text(". More generally, if ")#mi("{A}")#text(" is the union of ")#mi("{k}")#text(" groups, then ")#mi("{\\phi(A)}")#text(" is at most ")#mi("{k}")#text(", thanks to the pigeonhole principle.")

#text("If ")#mi("{G}")#text(" is the integers, then there are no non-trivial subgroups, and one can thus expect ")#mi("{\\phi(A)}")#text(" to start growing with ")#mi("{A}")#text(". For instance, one has the following easy result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" ")#metadata(none) <tao-55d6b753cd3085a7283a>#text(" Let ")#mi("{A}")#text(" be a set of ")#mi("{2^k}")#text(" natural numbers. Then ")#mi("{\\phi(A) > k}")#text(".")
]

#emph[#text("Proof:")]#text(" We use an argument ")#link("http://www.ams.org/mathscinet-getitem?mr=2166379")[#text("of Ruzsa")]#text(", which is based in turn on an older argument ")#link("http://www.ams.org/mathscinet-getitem?mr=292785")[#text("of Choi")]#text(". Let ")#mi("{x_1}")#text(" be the largest element of ")#mi("{A}")#text(", and then recursively, once ")#mi("{x_1,\\dots,x_i}")#text(" has been selected, let ")#mi("{x_{i+1}}")#text(" be the largest element of ")#mi("{A}")#text(" not equal to any of the ")#mi("{x_1,\\dots,x_i}")#text(", such that ")#mi("{x_{i+1}+x_j \\not \\in A}")#text(" for all ")#mi("{j=1,\\dots,i}")#text(", terminating this construction when no such ")#mi("{x_{i+1}}")#text(" can be located. This gives a sequence ")#mi("{x_1 > x_2 > \\dots > x_m}")#text(" of elements in ")#mi("{A}")#text(" which are sum-free in ")#mi("{A}")#text(", and with the property that for any ")#mi("{y \\in A}")#text(", either ")#mi("{y}")#text(" is equal to one of the ")#mi("{x_i}")#text(", or else ")#mi("{y + x_i \\in A}")#text(" for some ")#mi("{i}")#text(" with ")#mi("{x_i > y}")#text(". Iterating this, we see that any ")#mi("{y \\in A}")#text(" is of the form ")#mi("{x_{i_1} - x_{i_2} - \\dots - x_{i_j}}")#text(" for some ")#mi("{j \\geq 1}")#text(" and ")#mi("{1 \\leq i_1 < i_2 < \\dots \\leq i_j \\leq m}")#text(". The number of such expressions ")#mi("{x_{i_1} - x_{i_2} - \\dots - x_{i_j}}")#text(" is at most ")#mi("{2^{m}-1}")#text(", thus ")#mi("{2^k \\leq 2^m-1}")#text(" which implies ")#mi("{m \\geq k+1}")#text(". Since ")#mi("{\\phi(A) \\geq m}")#text(", the claim follows. ")#mi("\\Box")

#text("In particular, we have ")#tao-math("{\\phi(A) \\gg \\log \\left|A\\right|}", block: false)#text(" for subsets ")#mi("{A}")#text(" of the integers. It has been possible to improve upon this easy bound, but only with remarkable effort. The best lower bound currently is")

#align(center)[#tao-fit-display[#tao-math("\\phi(A) \\geq \\log \\left|A\\right| (\\log\\log\\left|A\\right|)^{1/2 - o(1)},", block: true)]]

#text("a result ")#link("http://www.ams.org/mathscinet-getitem?mr=3344672")[#text("of Shao")]#text(" (building upon earlier ")#link("http://www.ams.org/mathscinet-getitem?mr=2155059")[#text("work of Sudakov, Szemeredi, and Vu")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=292785")[#text("of Dousse")]#text("). In the opposite direction, a ")#link("http://www.ams.org/mathscinet-getitem?mr=2166379")[#text("construction of Ruzsa")]#text(" gives examples of large sets ")#mi("{A}")#text(" with ")#tao-math("{\\phi(A) \\leq \\exp( O( \\sqrt{\\log \\left|A\\right|} ) )}", block: false)#text(".")

#text("Using the standard tool of Freiman homomorphisms, the above results for the integers extend to other torsion-free abelian groups ")#mi("{G}")#text(". In our paper we study the opposite case where ")#mi("{G}")#text(" is finite (but still abelian). In ")#link("http://www.ams.org/mathscinet-getitem?mr=174539")[#text("this paper of Erdös")]#text(" (in which the quantity ")#mi("{\\phi(A)}")#text(" was first introduced), the following question was posed: if ")#mi("{A}")#text(" is sufficiently large depending on ")#mi("{\\phi(A)}")#text(", does this imply the existence of two elements ")#mi("{x,y \\in A}")#text(" with ")#mi("{x+y=0}")#text("? As it turns out, we were able to find some simple counterexamples to this statement. For instance, if ")#mi("{H}")#text(" is any finite additive group, then the set ")#mi("{A := \\{ 1 \\text{ mod } 7, 2 \\text{ mod } 7, 4 \\text{ mod } 7\\} \\times H \\subset {\\bf Z}/7{\\bf Z} \\times H}")#text(" has ")#mi("{\\phi(A)=3}")#text(" but with no ")#mi("{x,y \\in A}")#text(" summing to zero; this type of example in fact works with ")#mi("{7}")#text(" replaced by any larger Mersenne prime, and we also have a counterexample in ")#mi("{{\\bf Z}/2^n{\\bf Z}}")#text(" for ")#mi("{n}")#text(" arbitrarily large. However, in the positive direction, we can show that the answer to Erdös’s question is positive if ")#tao-math("{\\left|G\\right|}", block: false)#text(" is assumed to have no small prime factors. That is to say,")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" For every ")#mi("{k \\geq 1}")#text(" there exists ")#mi("{C \\geq 1}")#text(" such that if ")#mi("{G}")#text(" is a finite abelian group whose order is not divisible by any prime less than or equal to ")#mi("{C}")#text(", and ")#mi("{A}")#text(" is a subset of ")#mi("{G}")#text(" with order at least ")#mi("{C}")#text(" and ")#mi("{\\phi(A) \\leq k}")#text(", then there exist ")#mi("{x,y \\in A}")#text(" with ")#mi("{x+y=0}")#text(".")
]

#text("There are two main tools used to prove this result. One is an “arithmetic removal lemma” ")#link("http://www.ams.org/mathscinet-getitem?mr=2994398")[#text("proven by Král, Serra, and Vena")]#text(". Note that the condition ")#mi("{\\phi(A) \\leq k}")#text(" means that for any ")#emph[#text("distinct")]#text(" ")#mi("{x_1,\\dots,x_{k+1} \\in A}")#text(", at least one of the ")#mi("{x_i+x_j}")#text(", ")#mi("{1 \\leq i < j \\leq k+1}")#text(", must also lie in ")#mi("{A}")#text(". Roughly speaking, the arithmetic removal lemma allows one to “almost” remove the requirement that ")#mi("{x_1,\\dots,x_{k+1}}")#text(" be distinct, which basically now means that ")#mi("{x \\in A \\implies 2x \\in A}")#text(" for almost all ")#mi("{x \\in A}")#text(". This near-dilation symmetry, when combined with the hypothesis that ")#tao-math("{\\left|G\\right|}", block: false)#text(" has no small prime factors, gives a lot of “dispersion” in the Fourier coefficients of ")#mi("{1_A}")#text(" which can now be exploited to prove the theorem.")

#text("The second tool is the following structure theorem, which is the main result of our paper, and goes a fair ways towards classifying sets ")#mi("{A}")#text(" for which ")#mi("{\\phi(A)}")#text(" is small:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(" Let ")#mi("{A}")#text(" be a finite subset of an arbitrary additive group ")#mi("{G}")#text(", with ")#mi("{\\phi(A) \\leq k}")#text(". Then one can find finite subgroups ")#mi("{H_1,\\dots,H_m}")#text(" with ")#mi("{m \\leq k}")#text(" such that ")#tao-math("{\\left|A \\cap H_i\\right| \\gg_k \\left|H_i\\right|}", block: false)#text(" and ")#tao-math("{\\left|A \\backslash (H_1 \\cup \\dots \\cup H_m)\\right| \\ll_k 1}", block: false)#text(". Furthermore, if ")#mi("{m=k}")#text(", then the exceptional set ")#mi("{A \\backslash (H_1 \\cup \\dots \\cup H_m)}")#text(" is empty.")
]

#text("Roughly speaking, this theorem shows that the example of the union of ")#mi("{k}")#text(" subgroups mentioned earlier is more or less the “only” example of sets ")#mi("{A}")#text(" with ")#mi("{\\phi(A) \\leq k}")#text(", modulo the addition of some small exceptional sets and some refinement of the subgroups to dense subsets.")

#text("This theorem has the flavour of other inverse theorems in additive combinatorics, such as ")#link("https://en.wikipedia.org/wiki/Freiman%27s_theorem")[#text("Freiman’s theorem")]#text(", and indeed one can use Freiman’s theorem (and related tools, such as the Balog-Szemeredi theorem) to easily get a weaker version of this theorem. Indeed, if there are no sum-free subsets of ")#mi("{A}")#text(" of order ")#mi("{k+1}")#text(", then a fraction ")#mi("{\\gg_k 1}")#text(" of all pairs ")#mi("{a,b}")#text(" in ")#mi("{A}")#text(" must have their sum also in ")#mi("{A}")#text(" (otherwise one could take ")#mi("{k+1}")#text(" random elements of ")#mi("{A}")#text(" and they would be sum-free in ")#mi("{A}")#text(" with positive probability). From this and the Balog-Szemeredi theorem and Freiman’s theorem (in arbitrary abelian groups, as established ")#link("http://www.ams.org/mathscinet-getitem?mr=2302736")[#text("by Green and Ruzsa")]#text("), we see that ")#mi("{A}")#text(" must be “commensurate” with a “coset progression” ")#mi("{H+P}")#text(" of bounded rank. One can then eliminate the torsion-free component ")#mi("{P}")#text(" of this coset progression by a number of methods (e.g. by using variants of the argument in Proposition ")#link(<tao-55d6b753cd3085a7283a>)[#text("1")]#text("), with the upshot being that one can locate a finite group ")#mi("{H_1}")#text(" that has large intersection with ")#mi("{A}")#text(".")

#text("At this point it is tempting to simply remove ")#mi("{H_1}")#text(" from ")#mi("{A}")#text(" and iterate. But one runs into a technical difficulty that removing a set such as ")#mi("{H_1}")#text(" from ")#mi("{A}")#text(" can alter the quantity ")#mi("{\\phi(A)}")#text(" in unpredictable ways, so one has to still keep ")#mi("{H_1}")#text(" around when analysing the residual set ")#mi("{A \\backslash H_1}")#text(". A second difficulty is that the latter set ")#mi("{A \\backslash H_1}")#text(" could be considerably smaller than ")#mi("{A}")#text(" or ")#mi("{H_1}")#text(", but still large in absolute terms, so in particular any error term whose size is only bounded by ")#tao-math("{\\varepsilon \\left|A\\right|}", block: false)#text(" for a small ")#mi("{\\varepsilon}")#text(" could be massive compared with the residual set ")#mi("{A\\backslash H_1}")#text(", and so such error terms would be unacceptable. One can get around these difficulties if one first performs some preliminary “normalisation” of the group ")#mi("{H_1}")#text(", so that the residual set ")#mi("{A \\backslash H_1}")#text(" does not intersect any coset of ")#mi("{H_1}")#text(" too strongly. The arguments become even more complicated when one starts removing more than one group ")#mi("{H_1,\\dots,H_i}")#text(" from ")#mi("{A}")#text(" and analyses the residual set ")#mi("{A \\backslash (H_1 \\cup \\dots \\cup H_i)}")#text("; indeed the “epsilon management” involved became so fearsomely intricate that we were forced to use a nonstandard analysis formulation of the problem in order to keep the complexity of the argument at a reasonable level (cf. my ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("previous blog post")]#text(" on this topic). One drawback of doing so is that we have no effective bounds for the implied constants in our main theorem; it would be of interest to obtain a more direct proof of our main theorem that would lead to effective bounds.")

#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/11/sumfree-sets-in-groups/#comment-466847")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2016")])]

#text("Is it possible to get information on the structure of ")#mi("G")#text(" from the knowledge of ")#mi("\\phi (A)")#text(" for sufficiently many subsets ")#mi("A")#text(" of ")#mi("G")#text(" ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2016/03/11/sumfree-sets-in-groups/#comment-466867")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2016")])]

#text("“this paper of Erdos” – link missing?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/377c70a7cc38a51f9cc25fb2f095206b5fd83a51686bd3d6456013f597f2567b-acfaf89cc8e0a69460406dae1a55c8f060e7cefcaa3a5044e2c47743d6a5b3ae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymouse")]], [#link("https://terrytao.wordpress.com/2016/03/11/sumfree-sets-in-groups/#comment-466901")[#strong[#text("anonymouse")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2016")])]

#text("The link of Van Vu in the first sentence seems wrong.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37531d9674938adc67767adf8c404b8f7ad94e5ed0ddfc5d6cbe8fee940d50a3-6bcd915693ec7827ecaa612d58d15fd4bfbd8447d8cf41dab6bfd6cceb258d69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of HUMBERTO")]], [#link("https://terrytao.wordpress.com/2016/03/11/sumfree-sets-in-groups/#comment-466913")[#strong[#text("HUMBERTO")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2016")])]

#text("$order o(1) ???$")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/443de6758bc6ae1d5cefe4ab1b1a6059e6877d1cb31d5822f42f73f5ce8861af-d42366feb31b16427096a0ae00a4f846d356bae586851801f436d483be925adf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rik Bos")]], [#link("https://terrytao.wordpress.com/2016/03/11/sumfree-sets-in-groups/#comment-508264")[#strong[#text("Rik Bos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2018")])]

#text("Does proposition 1 hold when A contains 0? For instance, if A={0,1,3,4} then k=2 and a sum-free subset of cardinality 3 does not exist.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95f817915d852118c2db29947edd1f0232e34af1da29fce284382b8d2c7693dd-c5b61708c0ddc7fbbb44307dda379ff58b8a251c9a58d151d7df61c10d12963d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bik Ros")]], [#link("https://terrytao.wordpress.com/2016/03/11/sumfree-sets-in-groups/#comment-508266")[#strong[#text("Bik Ros")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2018")])]

#text("0 is not a natural number")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/443de6758bc6ae1d5cefe4ab1b1a6059e6877d1cb31d5822f42f73f5ce8861af-d42366feb31b16427096a0ae00a4f846d356bae586851801f436d483be925adf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rik Bos")]], [#link("https://terrytao.wordpress.com/2016/03/11/sumfree-sets-in-groups/#comment-508282")[#strong[#text("Rik Bos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2018")])]

#text("Well, that seems to be an ongoing debate. Since Bourbaki, many people tend to include 0 to the natural numbers. Also, this paper is about additive groups, where 0 plays an important role. Finally, a comment from ")#link("https://terrytao.wordpress.com/books/analysis-i/")[#text("https://terrytao.wordpress.com/books/analysis-i/")]#text(" states:")#linebreak()#text(" “Natural numbers have no zero divisors” should read “Positive natural numbers have no zero divisors”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95f817915d852118c2db29947edd1f0232e34af1da29fce284382b8d2c7693dd-c5b61708c0ddc7fbbb44307dda379ff58b8a251c9a58d151d7df61c10d12963d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bik Ros")]], [#link("https://terrytao.wordpress.com/2016/03/11/sumfree-sets-in-groups/#comment-508311")[#strong[#text("Bik Ros")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2018")])]

#text("There should not be any debate. See the middle of page 7 of the paper he links to (“sum-free sets in groups”, now named “sum-avoiding sets in groups”), which says “the natural numbers N = {1,2,…}”.")

#text("With this in mind, the responses to your points are the following:")#linebreak()#text(" 1). Terry does not consider 0 a natural number.")#linebreak()#text(" 2). I don’t see why 0 playing an important role should mean it is a natural number.")#linebreak()#text(" 3). The example you provided seems more like an exception.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/443de6758bc6ae1d5cefe4ab1b1a6059e6877d1cb31d5822f42f73f5ce8861af-d42366feb31b16427096a0ae00a4f846d356bae586851801f436d483be925adf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rik Bos")]], [#link("https://terrytao.wordpress.com/2016/03/11/sumfree-sets-in-groups/#comment-508391")[#strong[#text("Rik Bos")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2018")])]

#text("Well, especially the reference to p. 7 settles my question, even though the comment related to his book seems to indicate otherwise. Indeed, p. 18 of his book states:")#linebreak()#text(" *Axiom 2.1.* 0 is a natural number")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/11/sumfree-sets-in-groups/#comment-508473")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2018")])]

#text("Regarding the question of when to include zero amongst the natural numbers, I can refer readers to my previous comments on this question at ")#link("https://terrytao.wordpress.com/books/analysis-i/#comment-439818")[#text("https://terrytao.wordpress.com/books/analysis-i/#comment-439818")]#text(" and ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/#comment-442582")[#text("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/#comment-442582")]#text(" (and also Remark 2.1.2 of my “Analysis I” book). The short answer is that in some contexts it is slightly preferable to consider zero a natural number, and in other contexts it is preferable not to. (But it is ultimately worth bearing in mind that, the ")#link("https://en.wikiquote.org/wiki/Leopold_Kronecker")[#text("quote attributed to Kronecker")]#text(" notwithstanding, the choice of what we do or do not consider to be a natural number is ultimately a human convention.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/443de6758bc6ae1d5cefe4ab1b1a6059e6877d1cb31d5822f42f73f5ce8861af-d42366feb31b16427096a0ae00a4f846d356bae586851801f436d483be925adf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rik Bos")]], [#link("https://terrytao.wordpress.com/2016/03/11/sumfree-sets-in-groups/#comment-508476")[#strong[#text("Rik Bos")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2018")])]

#text("Thanks for your answer. So basically, you state that the inclusion or exclusion of 0 as a natural number is context-dependent. I guess my context is that 0 is a natural number unless stated otherwise (since as you write, it is ultimately a matter of convention).")
]
