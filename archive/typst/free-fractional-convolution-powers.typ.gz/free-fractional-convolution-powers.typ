// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/
// Converted to Typst by tao2typ: "2026-10-14T11:00:19.870055+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Fractional free convolution powers", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Fractional free convolution powers")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 September 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/")[#text("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://www.math.ucla.edu/~shlyakht/")[#text("Dimitri Shlyakhtenko ")]#text(" and I have uploaded to the arXiv our paper ")#link("https://arxiv.org/abs/2009.01882")[#text("Fractional free convolution powers")]#text(". For me, this project (which we started during the 2018 ")#link("https://terrytao.wordpress.com/2017/11/07/ipam-program-in-quantitative-linear-algebra-mar-19-jun-15-2018/")[#text("IPAM program on quantitative linear algebra")]#text(") was motivated by a desire to understand the behavior of the ")#emph[#text("minor process")]#text(" applied to a large random Hermitian ")#mi("{N \\times N}")#text(" matrix ")#mi("{A_N}")#text(", in which one takes the successive upper left ")#mi("{n \\times n}")#text(" minors ")#mi("{A_n}")#text(" of ")#mi("{A_N}")#text(" and computes their eigenvalues ")#mi("{\\lambda_1(A_n) \\leq \\dots \\leq \\lambda_n(A_n)}")#text(" in non-decreasing order. These eigenvalues are related to each other by the ")#link("https://en.wikipedia.org/wiki/Min-max_theorem#Cauchy_interlacing_theorem")[#text("Cauchy interlacing inequalities")]

#align(center)[#tao-fit-display[#mitex("\\lambda_i(A_{n+1}) \\leq \\lambda_i(A_n) \\leq \\lambda_{i+1}(A_{n+1})")]]

#text("for ")#mi("{1 \\leq i \\leq n < N}")#text(", and are often arranged in a triangular array known as a ")#emph[#text("Gelfand-Tsetlin pattern")]#text(", as discussed in ")#link("https://terrytao.wordpress.com/tag/gelfand-tsetlin-patterns/")[#text("these previous blog posts")]#text(".")

#text("When ")#mi("{N}")#text(" is large and the matrix ")#mi("{A_N}")#text(" is a random matrix with empirical spectral distribution converging to some compactly supported probability measure ")#mi("{\\mu}")#text(" on the real line, then under suitable hypotheses (e.g., unitary conjugation invariance of the random matrix ensemble ")#mi("{A_N}")#text("), a “concentration of measure” effect occurs, with the spectral distribution of the minors ")#mi("{A_n}")#text(" for ")#mi("{n = \\lfloor N/k\\rfloor}")#text(" for any fixed ")#mi("{k \\geq 1}")#text(" converging to a specific measure ")#mi("{k^{-1}_* \\mu^{\\boxplus k}}")#text(" that depends only on ")#mi("{\\mu}")#text(" and ")#mi("{k}")#text(". The reason for this notation is that there is a surprising description of this measure ")#mi("{k^{-1}_* \\mu^{\\boxplus k}}")#text(" when ")#mi("{k}")#text(" is a natural number, namely it is the ")#link("https://en.wikipedia.org/wiki/Free_convolution")[#text("free convolution")]#text(" ")#mi("{\\mu^{\\boxplus k}}")#text(" of ")#mi("{k}")#text(" copies of ")#mi("{\\mu}")#text(", pushed forward by the dilation map ")#mi("{x \\mapsto k^{-1} x}")#text(". For instance, if ")#mi("{\\mu}")#text(" is the Wigner semicircular measure ")#mi("{d\\mu_{sc} = \\frac{1}{\\pi} (4-x^2)^{1/2}_+\\ dx}")#text(", then ")#mi("{k^{-1}_* \\mu_{sc}^{\\boxplus k} = k^{-1/2}_* \\mu_{sc}}")#text(". At the random matrix level, this reflects the fact that the minor of a GUE matrix is again a GUE matrix (up to a renormalizing constant).")

#text("As first observed ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1355057")[#text("by Bercovici and Voiculescu")]#text(" and developed further ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1400060")[#text("by Nica and Speicher")]#text(", among other authors, the notion of a free convolution power ")#mi("{\\mu^{\\boxplus k}}")#text(" of ")#mi("{\\mu}")#text(" can be extended to non-integer ")#mi("{k \\geq 1}")#text(", thus giving the notion of a “fractional free convolution power”. This notion can be defined in several different ways. One of them proceeds via the Cauchy transform")

#align(center)[#tao-fit-display[#mitex("G_\\mu(z) := \\int_{\\bf R} \\frac{d\\mu(x)}{z-x}")]]

#text("of the measure ")#mi("{\\mu}")#text(", and ")#mi("{\\mu^{\\boxplus k}}")#text(" can be defined by solving the Burgers-type equation")

#metadata(none) <tao-8f329750b4b75fc98c88>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("(k \\partial_k + z \\partial_z) G_{\\mu^{\\boxplus k}}(z) = \\frac{\\partial_z G_{\\mu^{\\boxplus k}}(z)}{G_{\\mu^{\\boxplus k}}(z)}")]]

#text("with initial condition ")#mi("{G_{\\mu^{\\boxplus 1}} = G_\\mu}")#text(" (see ")#link("https://terrytao.wordpress.com/2017/09/16/inverting-the-schur-complement-and-large-dimensional-gelfand-tsetlin-patterns/")[#text("this previous blog post")]#text(" for a derivation). This equation can be solved explicitly using the ")#emph[#mi("{R}")#text("-transform")]#text(" ")#mi("{R_\\mu}")#text(" of ")#mi("{\\mu}")#text(", defined by solving the equation")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{G_\\mu(z)} + R_\\mu(G_\\mu(z)) = z")]]

#text("for sufficiently large ")#mi("{z}")#text(", in which case one can show that")

#align(center)[#tao-fit-display[#mitex("R_{\\mu^{\\boxplus k}}(z) = k R_\\mu(z).")]]

#text("(In the case of the semicircular measure ")#mi("{\\mu_{sc}}")#text(", the ")#mi("{R}")#text("-transform is simply the identity: ")#mi("{R_{\\mu_{sc}}(z)=z}")#text(".)")

#text("Nica and Speicher also gave a free probability interpretation of the fractional free convolution power: if ")#mi("{A}")#text(" is a noncommutative random variable in a noncommutative probability space ")#mi("{({\\mathcal A},\\tau)}")#text(" with distribution ")#mi("{\\mu}")#text(", and ")#mi("{p}")#text(" is a real projection operator free of ")#mi("{A}")#text(" with trace ")#mi("{1/k}")#text(", then the “minor” ")#mi("{[pAp]}")#text(" of ")#mi("{A}")#text(" (viewed as an element of a new noncommutative probability space ")#mi("{({\\mathcal A}_p, \\tau_p)}")#text(" whose elements are minors ")#mi("{[pXp]}")#text(", ")#mi("{X \\in {\\mathcal A}}")#text(" with trace ")#mi("{\\tau_p([pXp]) := k \\tau(pXp)}")#text(") has the law of ")#mi("{k^{-1}_* \\mu^{\\boxplus k}}")#text(" (we give a self-contained proof of this in an appendix to our paper). This suggests that the minor process (or fractional free convolution) can be studied within the framework of free probability theory.")

#text("One of the known facts about integer free convolution powers ")#mi("{\\mu^{\\boxplus k}}")#text(" is monotonicity of the ")#emph[#text("free entropy")]

#align(center)[#tao-fit-display[#tao-math("\\chi(\\mu) = \\int_{\\bf R} \\int_{\\bf R} \\log\\left|s-t\\right|\\ d\\mu(s) d\\mu(t) + \\frac{3}{4} + \\frac{1}{2} \\log 2\\pi", block: true)]]

#text("and ")#emph[#text("free Fisher information")]

#align(center)[#tao-fit-display[#mitex("\\Phi(\\mu) = \\frac{2\\pi^2}{3} \\int_{\\bf R} \\left(\\frac{d\\mu}{dx}\\right)^3\\ dx")]]

#text("which were introduced ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1228526")[#text("by Voiculescu")]#text(" as free probability analogues of the classical probability concepts of ")#link("https://en.wikipedia.org/wiki/Differential_entropy")[#text("differential entropy")]#text(" and ")#link("https://en.wikipedia.org/wiki/Fisher_information")[#text("classical Fisher information")]#text(". (Here we correct a small typo in the normalization constant of Fisher entropy as presented in Voiculescu’s paper.) Namely, it was shown ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2304337")[#text("by Shylakhtenko")]#text(" that the quantity ")#mi("{\\chi(k^{-1/2}_* \\mu^{\\boxplus k})}")#text(" is monotone non-decreasing for integer ")#mi("{k}")#text(", and the Fisher information ")#mi("{\\Phi(k^{-1/2}_* \\mu^{\\boxplus k})}")#text(" is monotone non-increasing for integer ")#mi("{k}")#text(". This is the free probability analogue of the corresponding monotonicities for differential entropy and classical Fisher information that was established ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2083473")[#text("by Artstein, Ball, Barthe, and Naor")]#text(", answering a ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=32134")[#text("question of Shannon")]#text(".")

#text("Our first main result is to extend the monotonicity results of Shylakhtenko to fractional ")#mi("{k \\geq 1}")#text(". We give two proofs of this fact, one using free probability machinery, and a more self contained (but less motivated) proof using integration by parts and contour integration. The free probability proof relies on the concept of the ")#emph[#text("free score")]#text(" ")#mi("{J(X)}")#text(" of a noncommutative random variable, which is the analogue of the classical ")#link("https://en.wikipedia.org/wiki/Score_(statistics)")[#text("score")]#text(". The free score, also introduced ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1618636")[#text("by Voiculescu")]#text(", can be defined by duality as measuring the perturbation with respect to semicircular noise, or more precisely")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{d\\varepsilon} \\tau( Z P( X + \\varepsilon Z) )|_{\\varepsilon=0} = \\tau( J(X) P(X) )")]]

#text("whenever ")#mi("{P}")#text(" is a polynomial and ")#mi("{Z}")#text(" is a semicircular element free of ")#mi("{X}")#text(". If ")#mi("{X}")#text(" has an absolutely continuous law ")#mi("{\\mu = f\\ dx}")#text(" for a sufficiently regular ")#mi("{f}")#text(", one can calculate ")#mi("{J(X)}")#text(" explicitly as ")#mi("{J(X) = 2\\pi Hf(X)}")#text(", where ")#mi("{Hf}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Hilbert_transform")[#text("Hilbert transform")]#text(" of ")#mi("{f}")#text(", and the Fisher information is given by the formula")

#align(center)[#tao-fit-display[#mitex("\\Phi(X) = \\tau( J(X)^2 ).")]]

#text("One can also define a notion of relative free score ")#mi("{J(X:B)}")#text(" relative to some subalgebra ")#mi("{B}")#text(" of noncommutative random variables.")

#text("The free score interacts very well with the free minor process ")#mi("{X \\mapsto [pXp]}")#text(", in particular by standard calculations one can establish the identity")

#align(center)[#tao-fit-display[#mitex("J( [pXp] : [pBp] ) = k {\\bf E}( [p J(X:B) p] | [pXp], [pBp] )")]]

#text("whenever ")#mi("{X}")#text(" is a noncommutative random variable, ")#mi("{B}")#text(" is an algebra of noncommutative random variables, and ")#mi("{p}")#text(" is a real projection of trace ")#mi("{1/k}")#text(" that is free of both ")#mi("{X}")#text(" and ")#mi("{B}")#text(". The monotonicity of free Fisher information then follows from an application of Pythagoras’s theorem (which implies in particular that conditional expectation operators are contractions on ")#mi("{L^2}")#text("). The monotonicity of free entropy then follows from an integral representation of free entropy as an integral of free Fisher information along the free Ornstein-Uhlenbeck process (or equivalently, free Fisher information is essentially the rate of change of free entropy with respect to perturbation by semicircular noise). The argument also shows when equality holds in the monotonicity inequalities; this occurs precisely when ")#mi("{\\mu}")#text(" is a semicircular measure up to affine rescaling.")

#text("After an extensive amount of calculation of all the quantities that were implicit in the above free probability argument (in particular computing the various terms involved in the application of Pythagoras’ theorem), we were able to extract a self-contained proof of monotonicity that relied on differentiating the quantities in ")#mi("{k}")#text(" and using the differential equation ")#link(<tao-8f329750b4b75fc98c88>)[#text("(1)")]#text(". It turns out that if ")#mi("{d\\mu = f\\ dx}")#text(" for sufficiently regular ")#mi("{f}")#text(", then there is an identity ")#metadata(none) <tao-e77c4b3f81059b97c4d2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\partial_k \\Phi( k^{-1/2}_* \\mu^{\\boxplus k} ) = -\\frac{1}{2\\pi^2} \\lim_{\\varepsilon \\rightarrow 0} \\sum_{\\alpha,\\beta = \\pm} f(x) f(y) K(x+i\\alpha \\varepsilon, y+i\\beta \\varepsilon)\\ dx dy")]]

#text(" ")#text(" where ")#mi("{K}")#text(" is the kernel")

#align(center)[#tao-fit-display[#mitex("K(z,w) := \\frac{1}{G(z) G(w)} (\\frac{G(z)-G(w)}{z-w} + G(z) G(w))^2")]]

#text("and ")#mi("{G(z) := G_\\mu(z)}")#text(". It is not difficult to show that ")#mi("{K(z,\\overline{w})}")#text(" is a positive semi-definite kernel, which gives the required monotonicity. It would be interesting to obtain some more insightful interpretation of the kernel ")#mi("{K}")#text(" and the identity ")#link(<tao-e77c4b3f81059b97c4d2>)[#text("(2)")]#text(".")

#text("These monotonicity properties hint at the minor process ")#mi("{A \\mapsto [pAp]}")#text(" being associated to some sort of “gradient flow” in the ")#mi("{k}")#text(" parameter. We were not able to formalize this intuition; indeed, it is not clear what a gradient flow on a varying noncommutative probability space ")#mi("{({\\mathcal A}_p, \\tau_p)}")#text(" even means. However, after substantial further calculation we were able to formally describe the minor process as the Euler-Lagrange equation for an intriguing Lagrangian functional that we conjecture to have a random matrix interpretation. We first work in “Lagrangian coordinates”, defining the quantity ")#mi("{\\lambda(s,y)}")#text(" on the “Gelfand-Tsetlin pyramid”")

#align(center)[#tao-fit-display[#mitex("\\Delta = \\{ (s,y): 0 < s < 1; 0 < y < s \\}")]]

#text("by the formula")

#align(center)[#tao-fit-display[#mitex("\\mu^{\\boxplus 1/s}((-\\infty,\\lambda(s,y)/s])=y/s,")]]

#text("which is well defined if the density of ")#mi("{\\mu}")#text(" is sufficiently well behaved. The random matrix interpretation of ")#mi("{\\lambda(s,y)}")#text(" is that it is the asymptotic location of the ")#mi("{\\lfloor yN\\rfloor^{th}}")#text(" eigenvalue of the ")#mi("{\\lfloor sN \\rfloor \\times \\lfloor sN \\rfloor}")#text(" upper left minor of a random ")#mi("{N \\times N}")#text(" matrix ")#mi("{A_N}")#text(" with asymptotic empirical spectral distribution ")#mi("{\\mu}")#text(" and with unitarily invariant distribution, thus ")#mi("{\\lambda}")#text(" is in some sense a continuum limit of Gelfand-Tsetlin patterns. Thus for instance the Cauchy interlacing laws in this asymptotic limit regime become")

#align(center)[#tao-fit-display[#mitex("0 \\leq \\partial_s \\lambda \\leq \\partial_y \\lambda.")]]

#text("After a lengthy calculation (involving extensive use of the chain rule and product rule), the equation ")#link(<tao-8f329750b4b75fc98c88>)[#text("(1)")]#text(" is equivalent to the Euler-Lagrange equation")

#align(center)[#tao-fit-display[#mitex("\\partial_s L_{\\lambda_s}(\\partial_s \\lambda, \\partial_y \\lambda) + \\partial_y L_{\\lambda_y}(\\partial_s \\lambda, \\partial_y \\lambda) = 0")]]

#text("where ")#mi("{L}")#text(" is the Lagrangian density")

#align(center)[#tao-fit-display[#mitex("L(\\lambda_s, \\lambda_y) := \\log \\lambda_y + \\log \\sin( \\pi \\frac{\\lambda_s}{\\lambda_y} ).")]]

#text("Thus the minor process is formally a critical point of the integral ")#mi("{\\int_\\Delta L(\\partial_s \\lambda, \\partial_y \\lambda)\\ ds dy}")#text(". The quantity ")#mi("{\\partial_y \\lambda}")#text(" measures the mean eigenvalue spacing at some location of the Gelfand-Tsetlin pyramid, and the ratio ")#mi("{\\frac{\\partial_s \\lambda}{\\partial_y \\lambda}}")#text(" measures mean eigenvalue drift in the minor process. This suggests that this Lagrangian density is some sort of measure of entropy of the asymptotic microscale point process emerging from the minor process at this spacing and drift. There is ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3010400")[#text("work of Metcalfe")]#text(" demonstrating that this point process is given by ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2489161")[#text("the Boutillier bead model")]#text(", so we conjecture that this Lagrangian density ")#mi("{L}")#text(" somehow measures the entropy density of this process.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/744af6de8cc8d5fa42cf0dbd096e88eef82f4b51081b78514bff85bf909eab07-d4d0b110ce3d5330716c189c6d455c2cd768a34ab962b2a8c3755b79505fb788.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of grpaseman")]], [#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/#comment-587476")[#strong[#text("grpaseman")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2020")])]

#text("Do fractional and free commute? (in reference to your blog post title.)")

#emph[#text("[Oops, corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/744af6de8cc8d5fa42cf0dbd096e88eef82f4b51081b78514bff85bf909eab07-d4d0b110ce3d5330716c189c6d455c2cd768a34ab962b2a8c3755b79505fb788.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of grpaseman")]], [#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/#comment-587477")[#strong[#text("grpaseman")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2020")])]

#text("Also, after display equation (1), I see “This equation can be solved explicitly using the \\emph “. Can you explain \\emph ? (I’m afraid I don’t know enough to translate this bit of TeX.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/050ea1537511e920a7134bcb40062a30a87a370ae0242cbdf34c24b428ff8be6-8ed3b0957857d65f9abe39a3fe0a311128de4c517645a1bbf694d2c4d2928157.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/#comment-587478")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2020")])]

#text("Does free entropy have information theoretic meaning that can be transferred to settings similar to ")#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/")[#text("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/")]#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/#comment-587480")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2020")])]

#text("Is there a “natural” extension of these results to complex measures?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/#comment-587487")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2020")])]

#text("Hmm. In free probability, measures on the complex plane would correspond to normal operators rather than Hermitian, but the problem is that the sum of freely *-independent normal operators is unlikely to again be normal, so it is not clear if there is a natural free convolution operation here. The R-transform might not be sufficient to define the operation as it only gives moments rather than *-moments. There may still be some sort of free convolution operation for non-real elements of a noncommutative probability space, but it might not be easily described in terms of classical measures.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/#comment-587491")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2020")])]

#text("I’ve just been informed by Istvan Prause that the local entropy (aka surface tension) of the bead process was recently worked out ")#link("https://arxiv.org/abs/1804.03414")[#text("by Sun")]#text(" (with an alternate approach also given ")#link("https://arxiv.org/abs/1909.03219v2")[#text("by Johnston and O’Connell")]#text(") and the formula there does indeed appear to resemble the Lagrangian density given here (and the connection with the complex Burgers equation also noted recently ")#link("https://arxiv.org/pdf/2006.01219.pdf")[#text("by Kenyon and Prause")]#text("). The normalizations are quite different but this is nevertheless quite strong support for our conjecture.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/#comment-587605")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2020")])]

#text("What ensures the existence of the integral in the definition of the free Fisher information?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/#comment-587643")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2020")])]

#text("If the integral does not exist then the free Fisher information is infinite.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/148dad55d7ac8263ede756fe617941686bc74e7d7039aa288652c04e1d035616-1c3e607ad18709f1d97c112b92b9d74a8efefc39395829bb114906feb3c2eb07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of biotropic")]], [#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/#comment-587612")[#strong[#text("biotropic")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2020")])]

#text("A IMO gold medalist needs donations for his cancer treatment. Please consider donating: ")#link("https://www.gofundme.com/f/help-denis-smirnov/")[#text("https://www.gofundme.com/f/help-denis-smirnov/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Huong")]], [#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/#comment-587845")[#strong[#text("Huong")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2020")])]

#text("Dear Professor")#linebreak()#text(" In the paper uploaded to ArXiv p. 12 you use the term “Equating the two”. Do you mean “Identifying the two” i.e. “By identification” ?")#linebreak()#text(" Moreover I have pointed out a very minor typo in the last reference of your paper p. 24: “Lèvy processes” instead of “Lvy processes”.")#linebreak()#text(" Yours sincerely")

#emph[#text("[This will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chen")]], [#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/#comment-589064")[#strong[#text("Chen")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2020")])]

#text("Dear Professor Tao,")#linebreak()#text(" A very minor typo founded in the paper uploaded to ArXiv p. 13 : “As is well known,” -> “As it is well-known,”")#linebreak()#text(" Best regards")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/33b26edc4ef5e000529026ac77dd839231886a7bffaa8c1dd07531e238933100-5f9603ca0a37873cafc810cfe8dd5f2e70a532324b85eb4e9b217e39c16faaaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Prateek P Kulkarni")]], [#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/#comment-589285")[#strong[#text("Prateek P Kulkarni")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2020")])]

#text("Prof Tao, Can these have an extension to complex probability measures?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/#comment-590737")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2020")])]

#text("An update: David Jekel has adapted our proof of monotonicity of non-microstate free entropy of free convolution powers of several noncommutative variables to also cover the microstate free entropy, by converting the problem into an approximate monotonicity of (suitably normalized) classical entropy of several large noncommuting random matrices, and developing classical analogues of the arguments in the paper. This is now included as an appendix to the revised version of the paper (which should appear shortly on the arXiv in the same location as the previous paper.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zong")]], [#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/#comment-590980")[#strong[#text("Zong")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2020")])]

#text("Dear Professor")#linebreak()#text(" Two typos just founded in the second version of your ArXiv uploaded article:")#linebreak()#text(" – p. 26 Lemma B.5 (v) “we have the the identity” —> “we have the identity” ;")#linebreak()#text(" – p. 36 in the last reference #37 of J. Williams “Lévy processes” —> “Lèvy processes”.")#linebreak()#text(" Yours sincerely")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chang")]], [#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/#comment-590984")[#strong[#text("Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2020")])]

#text("Another minor typo pointed out in the ref [36] of your paper: ‘random matrices’ instead of ‘randommatrices’")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chen")]], [#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/#comment-591097")[#strong[#text("Chen")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2020")])]

#text("Yet another typo in the second version of your paper uploaded to ArXiv : p. 7 foot note #4 “by Vadim Gorin (private communciation)” ==> “by Vadim Gorin (private communication)”")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Milos")]], [#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/#comment-591099")[#strong[#text("Milos")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2020")])]

#text("Two new typos in the bibliography :")#linebreak()#text(" [1] … ‘Random Matrices’ instead of ‘Ran-dom Matrices’")#linebreak()#text(" [9] … ‘Cramer theorem’ instead of ‘Cramér theorem’")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zinzong")]], [#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/#comment-591542")[#strong[#text("Zinzong")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2020")])]

#text("An update to the reference of Johnston & O’Connell: Samuel G.G. Johnston and Neil O’Connell. Scaling limits for non-intersecting polymers and Whittaker measures. Journal of Statistical Physics, 179(2):354-407, 2020.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zaoming")]], [#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/#comment-591649")[#strong[#text("Zaoming")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2020")])]

#text("Dear Professor Tao")#linebreak()#text(" For your complete and perfect information, the two very recent following preprints uploaded to ArXiv could interest you or/and be included into your bibliography:")#linebreak()#text(" A. Gordenko. Limit shapes of large skew Young tableaux and a modification of the TASEP process. 43 pages (v1). Uploaded on September 23, 2020.")#linebreak()#text(" A.H. Morales and D.G. Zhu. On the Okounkov-Olshanski formula for standard tableaux of skew shapes. 36 pages (v2). Uploaded on September 11, 2020.")#linebreak()#text(" Sincerely yours")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klint")]], [#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/#comment-594243")[#strong[#text("Klint")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("As pointed out in a previous post, the reference of Johnston and O Connell should be yet updated.")

#emph[#text("[This will be updated in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ZenZao")]], [#link("https://terrytao.wordpress.com/2020/09/07/free-fractional-convolution-powers/#comment-594802")[#strong[#text("ZenZao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2020")])]

#text("In the third footnote page 4, maybe you should cut off the symbol [] after “The brackets” or use the symbols [ ] in order to avoid any confusion for certain readers.")
]
