// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/
// Converted to Typst by tao2typ: "2026-10-14T16:34:57.105507+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The cosmic distance ladder", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The cosmic distance ladder")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 31 May 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/")[#text("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I gave a non-technical talk today to the local chapter of the ")#link("http://www.pme-math.org/")[#text("Pi Mu Epsilon")]#text(" society here at UCLA. I chose to talk on the ")#link("http://en.wikipedia.org/wiki/Cosmic_distance_ladder")[#text("cosmic distance ladder")]#text(" – the hierarchy of rather clever (yet surprisingly elementary) mathematical methods that astronomers use to indirectly measure very large distances, such as the distance to planets, nearby stars, or distant stars. This ladder was really started by the ancient Greeks, who used it to measure the size and relative locations of the Earth, Sun and Moon to reasonable accuracy, and then continued by Copernicus, Brahe and Kepler who then measured distances to the planets, and in the modern era to stars, galaxies, and (very recently) to the scale of the universe itself. It’s a great testament to the power of indirect measurement, and to the use of mathematics to cleverly augment observation.")

#text("For this (rather graphics-intensive) talk, I used Powerpoint for the first time; the slides (which are rather large – 3 megabytes) – ")#link("https://terrytao.wordpress.com/wp-content/uploads/2007/05/cosmic-distance-ladder.ppt")[#text("can be downloaded here")]#text(". [I ")#link("http://qtss.amsi.org.au/Teachers_afternoon.html")[#text("gave an earlier version of this talk in Australia")]#text(" last year in a plainer PDF format, and had to get someone to convert it for me.]")

#text("[")#emph[#text("Update")]#text(", May 31: In case the powerpoint file is too large or unreadable, I also have my older ")#link("http://www.math.ucla.edu/~tao/preprints/Slides/distance_ladder.pdf")[#text("PDF version of the talk")]#text(", which omits all the graphics.]")

#text("[Update, July 1 2008: ")#link("http://wwwmaths.anu.edu.au/~john/")[#text("John Hutchinson")]#text(" has made some computations to accompany these slides, which can be found at ")#link("http://www.maths.anu.edu.au/DoM/secondary/ProfDev.html")[#text("this page")]#text(".]")

#heading(level: 1)[#text("Comments (25)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6beba7ada0150d5d3f5a9ecff397be36867e53e143e7e65ac2cdad283946329-d70fa4912474dfd1bfe0b8498a9e5f6856057a641ed49efa3348e515d8ee4694.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Carroll")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-1477")[#strong[#text("Sean Carroll")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2007")])]

#text("Nice talk! Just FYI, there are by now several methods for determining distances that reach directly to cosmological scales, without using any nearby calibrators; examples include the Sunyaev-Zeldovich effect, gravitational-lens time delays, and the expanding photosphere method for Type II (not Type Ia) supernovae. I don’t know of a great reference, but ")#link("http://www.astro.ucla.edu/~wright/distance.htm")[#text("Ned Wright")]#text(" has a list that covers the basics. Interestingly, though, the actual precision of those methods doesn’t quite match that of the conventional distance-ladder based approach, or at least not yet.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-1495")[#strong[#text("Measuring the Universe « Home Schooled")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2007")]

#text("[…] the Universe Have a look at the slides for Terry Tao’s nontechnical talk on the cosmic distance ladder. It is a great story of ideas about measuring the cosmos from the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-1505")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2007")]

#text("[…] The cosmic distance ladder I gave a non-technical talk today to the local chapter of the Pi Mu Epsilon society here at UCLA. I chose to talk on […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-1548")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2007")])]

#emph[#text("Beyond that scale, only ad hoc methods of measuring distances are known (e.g. relying on supernovae measurements, which are of the few events that can still be detected at such distances)")]

#text("I don’t really understand this remark. In a way, all astronomy is ad hoc. The ad hoc nature of distance measurement is a main theme of your talk. Assembling different methods into a composite distance ladder is surely as ad hoc as could be.")

#text("Maybe you mean that distance measurements far above 13 million light years are more implicit than at smaller distances. Although even if these distances are more provisional, the argument for them (the Hubble red shift) seems to me about as good as Aristotle’s argument that the Earth is round. As I understand it, Aristotle argued that the earth is curved north to south and inferred a sphere.")

#text("On that note, you might be interested to know about an interesting new measuring stick at the high end of the Cepheid scale or even beyond it. Some galaxies have a water vapor maser that can be used to triangulate distances with phase measurements; see e.g. arXiv:astro-ph/9908140.")

#text("Also, if it is on your mind that you are using Powerpoint, I noticed that we have had a lot of talks at Davis lately using Beamer, which is a Powerpoint-like LaTeX package. As for document size, 3MB isn’t really so bad, but you can probably make it much smaller by compressing the images to JPEG. (The JPEG standard has a free parameter, distinct from image resolution, that lets you trade file size with lossiness.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-1559")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2007")])]

#text("Dear Sean and Greg, thanks for the pointers to the more recent measurement methods, which I was not aware of. Regarding “ad hoc”, I meant that (except perhaps for the Hubble law method and some other recent methods), there did not seem to be a systematic and calibrated way of reasonable accuracy to measure a large number of distances beyond the Cepheid scale; there were individual methods which could work in some cases, but they depended in part on some parameters which might have to be inferred by ad hoc means, or whose accuracy was still somewhat unsatisfactory. (This is contrast to, say, main sequence fitting, in which the ad hoc calibration has already been done, and new distances that one measures by this method can therefore be computed without having to make any further arbitrary choices.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-1562")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2007")])]

#emph[#text("There did not seem to be a systematic and calibrated way of reasonable accuracy to measure a large number of distances beyond the Cepheid scale; there were individual methods which could work in some cases, but they depended in part on some parameters which might have to be inferred by ad hoc means, or whose accuracy was still somewhat unsatisfactory.")]

#text("Well, I think that this is still true, with the exception of the Hubble law. The Hubble law seems about as decent as any other distance method, except when the Hubble law itself is the object of study! As you suggest, all other intergalactic distance methods, including the new ones based on masers and supernovas, require rare circumstances are are more used to calibrate the Hubble law, or as a consistency check for Cepheid variables.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-1563")[#strong[#text("Terence Tao - the cosmic distance ladder « Sachi’s hyperbolic space")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2007")]

#text("[…] Tao – the cosmic distance ladder Terence Tao has put up a nice post about calculating astronomical distances – the cosmic distance ladder. Download his presentation and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A visit to the Royal Society « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-4440")[#strong[#text("A visit to the Royal Society « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2007")])]

#text("[…] and video of which are available here). It’s the second time I’ve used Powerpoint (this is the first); I myself am most comfortable with good old fashioned chalk and blackboard, but now that I see how […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fc2c99afee0668b8e90a338a766aafe608b5259ff35e6f161328c1c2f0bac33-05d3eeeee07780c177666558c4352e090bba3be15c673d0dfbe98eb669c1f24c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ford Denison")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-11270")[#strong[#text("Ford Denison")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2007")])]

#text("Excellent! But why do leave out the story of estimating the earth-sun distance using a transit of Venus? It’s such a great example of the power of fairly simple math.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-11443")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2007")])]

#text("Hmm, good suggestion; I have a passing method to “parallax methods” for determining interplanetary distances, but no details. (As it stands, the talk fits almost exactly into a 50 minute lecture; it’s hard to squash much more in.) I’ve added a sentence to the slides, though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-15839")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2007")])]

#text("Dear Terry,")#linebreak()#text(" Do astronomers have any methods for explaining the bizarre")#linebreak()#text(" hexagonal cloud on Saturn’s north pole (Wikipedia)?")#linebreak()#text(" Physicists have done some simple experiments and obtained")#linebreak()#text(" polygons in a rotating bucket of fluid.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-20421")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2007")])]

#text("Dear All,")#linebreak()#text(" New NASA observations show that the solar system is asymmetrical:")#linebreak()#text(" ")#link("http://www.cnn.com/2007/TECH/space/12/11/solarsystem.edge.ap/index.html")[#text("http://www.cnn.com/2007/TECH/space/12/11/solarsystem.edge.ap/index.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sierra")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-20443")[#strong[#text("Sierra")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2007")])]

#text("Dear Adam,")#linebreak()#text(" You missed the coma of Comet 17P/Holmes a month ago.")#linebreak()#text(" Scientists speculated it exploded because there were sinkholes")#linebreak()#text(" in its nucleus, giving it a honeycomb-like structure.")#linebreak()#text(" This once-in-a-lifetime event to witness was along the lines of")#linebreak()#text(" when Comet Shoemaker – levy 9 smashed into Jupiter back in 1994.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c714bebdd47707d3f52355cc737849d6348d0a983ed53e808670dbeb402471bc-d36bd4eac54f1c0444549aba9e935932042b7c140c8c8efa956a9d731bb668b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roger Brewis")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-32673")[#strong[#text("Roger Brewis")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2008")])]

#text("You conclude that the diameter of the observable universe is 78 billion light years (78 bly). I wonder if this is intended to provoke. The radial distance to furthest observed galaxies would appear to be either 13.5 bly, on the big bang hypothesis, invoking a form of relativistic adjustment, or in excess of 100 bly by unadulterated application of the Hubble constant.")

#text("I am not convinced of the big bang conclusion. Out of the original three possibilities identified as explanation of the cosmological redshift, the Doppler interpretation appeared initially more likely than the tired light theory or the suggestion that the laws of physics change with time.")

#text("However, the BB idea has degenerated into one of the messiest and least causal theories in physics – and it has some ‘impressive’ competition! It is now one of the worst theories in the history of science. Surely it is overdue a serious critical review, and a proper re-examination of possible alternatives.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-32686")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2008")])]

#text("Dear Roger,")

#text("The diameter bound for the universe comes not from observable galaxy data, which as you say only allows us to cover a portion of the universe, but from the ")#link("http://en.wikipedia.org/wiki/Wilkinson_Microwave_Anisotropy_Probe")[#text("WMAP")]#text(" data on cosmic microwave background radiation, which incidentally has also provided the most precise measurements and confirmations of various Big Bang parameters to date. The paper that analyses this data to obtain the diameter bound can be found at ")#link("http://arxiv.org/abs/astro-ph/0310233")[#text("http://arxiv.org/abs/astro-ph/0310233")]#text(" .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c714bebdd47707d3f52355cc737849d6348d0a983ed53e808670dbeb402471bc-d36bd4eac54f1c0444549aba9e935932042b7c140c8c8efa956a9d731bb668b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roger Brewis")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-34335")[#strong[#text("Roger Brewis")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2008")])]

#text("Your response is misleading, and I trust that this is not deliberate. The paper you refer to does not appear to offer other than a lower bound on the size of the universe. Also, this is clearly not the ‘observable’ universe, as you initially state in your lecture notes.")#linebreak()#text(" You decline to acknowledge my point about the abandonment of causal reasoning in cosmology, despite the fact that the only – disputed – justifications in physics for this absurd abandonment relate specifically to quantum effects.")#linebreak()#text(" There are other major problems in the BB ‘model’: a number relate to the age of the universe and there are others around the existence or otherwise of a boundary. For all these reasons, the BB story has never made coherent scientific sense.")#linebreak()#text(" If you (or indeed any other cosmologist) were to address these issues honestly you would be doing real science. Even were you to follow up your own assertion about the ‘observable’ diameter being 78 billion light years, you would find yourself addressing these very difficulties.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-34358")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2008")])]

#text("Dear Roger,")

#text("The slides give the 78 billion ly figure as a lower bound only on the diameter of the universe, but perhaps the wording was unclear about this; I have clarified the sentence in the ")#link("https://terrytao.files.wordpress.com/2007/05/cosmic-distance-ladder.ppt")[#text("latest version")]#text(" of the slides. (The original slides can be viewed ")#link("http://www.math.ucla.edu/%7Etao/preprints/Slides/Cosmic%20Distance%20Ladder.ppt")[#text("here")]#text(".) Given that this figure is extracted directly from the WMAP data, which is of course observable data, this also places a lower bound on the diameter of the observable universe (assuming, of course, that the universe is approximately flat at this scale). But given that the word “observable” is causing confusion, I have now removed it that sentence.")

#text("Incidentally, current estimates on the maximum radius of the observable universe (as defined using comoving coordinates) are about 46 billion light years (see e.g. ")#link("http://arxiv.org/abs/astro-ph/0310808")[#text("this paper")]#text("), thus the maximum diameter of the observable universe should be about 92 or 93 billion light years. (As you note, galaxies have only been observed out to about 19 billion ly, but observable galaxies are only a subset of the observable universe.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-34360")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2008")])]

#text("The word “observable” raises so many red herrings (red-shifted herrings?).")

#text("Naive readers may assume that “observe” means via light in telescopes or on our retinas, whereas astronomers may be interpreting it to mean all of the visual spectrum plus gravitational waves and various indirect inferences.")

#text("There is an implicit distinction between “nonluminous matter” and “luminous matter” which originates from localized hot bursts already present in the plasma state prior to the decoupling transition when a plasma of protons and electrons condensed into a gas of Hydrogen. COBE indicates that only very small ripples of order 10^-5 existed at decoupling. Gravity then caused hydrogen to cluster and possibly reheat parts of the universe to form the luminous matter that we observe today. Nonluminous combines the non-photons prior to the decoupling transition, and dark matter.")

#text("We visually (optically) observe luminous matter. Dr. Andisheh Mahdavi, University of Victoria nicely describes: “Clusters of galaxies are dominated by dark matter. We can see the gravitational effect of this dark material on the orbits of cluster members, the thermodynamics of the hot gas, and the lensed shapes of galaxies behind the cluster. I will show that combining multi-wavelength data for a single relaxed cluster can yield powerful constraints on its dark matter distribution and on the equation of state of the intra-cluster plasma. At the same time, as the bullet cluster teaches us, multi-wavelength observations of merging clusters can yield significant and perhaps even more interesting constraints on dark matter properties. Both relaxed and merging clusters are well-represented in the Canadian Cluster Comparison Project, an X-ray, optical, and radio survey of fifty nearby clusters.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of research news")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-34386")[#strong[#text("research news")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2008")])]

#text("The Higgs belongs to dark matter.")#linebreak()#text(" Proof: Variational thermodynamics. Hint: Dark free energy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Feynman’s lectures online « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-40059")[#strong[#text("Feynman’s lectures online « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2009")])]

#text("[…] I covered some of the material in Feynman’s first lecture in my own talk on the cosmic distance ladder, though I was approaching the topic from a rather different angle, and with a less elegant […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The cosmic distance ladder « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-41255")[#strong[#text("The cosmic distance ladder « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2009")])]

#text("[…] namely my public talk on the cosmic distance ladder (8MB, PDF). These slides are based on my previous talks of the same name, but I have updated and reorganised the graphics significantly as I was not fully satisfied with […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a6dbd98c03c1bf8088d2b786d124e71c1cd3e4f3d75c53f496a40d9a1503bca1-f229400d9a3491ae5650d12824dba968c47baf0e8ce4b2312cdc0b4bcdff7e27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Patrick")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-45968")[#strong[#text("Patrick")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2010")])]

#text("Uploaded your presentation to SlideShare for easier access: ")#link("http://www.slideshare.net/embeds/cosmic-distance-ladder")[#text("http://www.slideshare.net/embeds/cosmic-distance-ladder")]#text(". Hope you don’t mind.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/374e43a48903df50ab37e8912e33c6ae3afe746a9edd4b3678d79c8236923dbc-d166669a941b254aeaf36e6fd87be886b49b46d29cab5c412c34c2ffd005e88d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Refreshing Childhood Math « Joseph Chan")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-49200")[#strong[#text("Refreshing Childhood Math « Joseph Chan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2010")])]

#text("[…] a public lecture, detailed calculations are omitted. If you need to see them there is a link from his earlier lecture in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c714bebdd47707d3f52355cc737849d6348d0a983ed53e808670dbeb402471bc-d36bd4eac54f1c0444549aba9e935932042b7c140c8c8efa956a9d731bb668b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roger Brewis")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-50090")[#strong[#text("Roger Brewis")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2011")])]

#text("Terrence,")#linebreak()#text(" Hi. Sorry I haven’t been back to this discussion for a while. I do accept your clarifications and that you did not mean to mislead. It seems that we have some points in agreement that I would like to take further.")#linebreak()#text(" All the figures you cite for distances appear to refer to light (microwaves etc) emitted much longer ago than the 13.6 billion years or so that is still the best estimate for a big bang. Would you care to elaborate?")#linebreak()#text(" For a host of reasons too long to go into in detail here I have no truck with the hypothesis of a big bang. It is too reliant on ad hoc add-ons such as expanding space, inflation and dark energy; there are too many contradictions about the age (as appears to be the case with your figures); it is too a-causal, etc.")#linebreak()#text(" I don’t have a fully convincing alternative, but am certain that we should be looking for one.")#linebreak()#text(" Your responses to my criticisms have been very reasonable. If you wish to discuss this further away from this board, please contact me.")#linebreak()#text(" All best wishes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62fcdcd7773931b3e864bf18074ca0fc674aaa8c9b840bd67debd0c4bdebdb17-e59cc59918a6c95e42b658f8e692db13637122f709e07f7a16b73c79d2d7aea9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 1298129812")]], [#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/#comment-593936")[#strong[#text("1298129812")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2020")])]

#text("Cosmic distance to Hutchinson’s computations is $\\infty$.")
]
