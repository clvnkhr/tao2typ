// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/11/25/course-announcement-254b-expansion-in-groups-of-lie-type/
// Converted to Typst by tao2typ: "2026-10-14T15:18:17.602255+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Course announcement: 254B, expansion in groups of Lie type", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Course announcement: 254B, expansion in groups of Lie type")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 November 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/11/25/course-announcement-254b-expansion-in-groups-of-lie-type/")[#text("https://terrytao.wordpress.com/2011/11/25/course-announcement-254b-expansion-in-groups-of-lie-type/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In the Winter quarter (starting on January 9), I will be teaching a ")#link("http://www.math.ucla.edu/~tao/254b.1.12w/")[#text("graduate course on expansion in groups of Lie type")]#text(". This course will focus on constructions of expanding Cayley graphs on finite groups of Lie type (such as the special linear groups ")#mi("SL_d({\\bf F}_q)")#text(", or their simple quotients ")#mi("PSL_d({\\bf F}_q)")#text(", but also including more exotic “twisted” groups of Lie type, such as the Steinberg or Suzuki-Ree groups), including the “classical” constructions of Margulis and of Selberg, but also the more recent constructions of Bourgain-Gamburd and later authors (including some very recent work of Ben Green, Emmanuel Breuillard, Rob Guralnick, and myself which is nearing completion and which I plan to post about shortly). As usual, I plan to start posting lecture notes on this blog before the course begins.")

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e67a2b3df965651da7c8840f8efe7bac5d74a2b5184a8ed900651ceaaf7c4e8f-9bf5ebcb90a9a5948d45c0158db01a12de4388f334928150ef18214e6b5d12a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AADIL AMAN")]], [#link("https://terrytao.wordpress.com/2011/11/25/course-announcement-254b-expansion-in-groups-of-lie-type/#comment-110025")[#strong[#text("AADIL AMAN")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2011")])]

#text("Great, Keep posting the updates of the course…. I love graph theory!!! and I want to explore about cayley graphs and its recent uses… Your blog is seriously awesome!!")#linebreak()#text(" thanks a lot")#linebreak()#text(" -Aadil")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bogdan")]], [#link("https://terrytao.wordpress.com/2011/11/25/course-announcement-254b-expansion-in-groups-of-lie-type/#comment-110823")[#strong[#text("Bogdan")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2011")])]

#text("Dear Tao,")#linebreak()#text(" My question is completely out of topic, but I do not see where to ask “general” questions. I was recently asked the following question: What is the probability that a random n to n symmetric matrix (say, ones on diagonal, upper diagonals entries are i.i.d, and entries below the diagonal are given by symmerty) is positive definite? Clearly, this probability goes to 0 with n, but how fast? I could not answer this, but I have impression that the question is more than classical and should be known… Could you please comment?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/11/25/course-announcement-254b-expansion-in-groups-of-lie-type/#comment-110825")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2011")])]

#text("I would recommend ")#link("http://mathoverflow.net/")[#text("http://mathoverflow.net/")]#text(" for general research-level maths questions if they are off-topic for the posts on this blog.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bogdan")]], [#link("https://terrytao.wordpress.com/2011/11/25/course-announcement-254b-expansion-in-groups-of-lie-type/#comment-111018")[#strong[#text("Bogdan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2011")])]

#text("Ok, I know this site, I just wanted to ask namely you… Thanks anyway.")
]
]
]
