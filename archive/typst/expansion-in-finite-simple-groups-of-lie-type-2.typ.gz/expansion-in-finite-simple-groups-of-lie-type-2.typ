// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/10/31/expansion-in-finite-simple-groups-of-lie-type-2/
// Converted to Typst by tao2typ: "2026-10-14T15:18:49.733088+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Expansion in finite simple groups of Lie type", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Expansion in finite simple groups of Lie type")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 31 October 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/10/31/expansion-in-finite-simple-groups-of-lie-type-2/")[#text("https://terrytao.wordpress.com/2013/10/31/expansion-in-finite-simple-groups-of-lie-type-2/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’ve just finished the first draft of my book “")#link("https://terrytao.wordpress.com/wp-content/uploads/2013/11/expander-book.pdf")[#text("Expansion in finite simple groups of Lie type")]#text("“, which is based in the ")#link("https://terrytao.wordpress.com/category/teaching/254b-expansion-in-groups/")[#text("lecture notes for my graduate course on this topic")]#text(" that were previously posted on this blog. It also contains some newer material, such as the notes on Lie algebras and Lie groups that I posted most recently here.")

#text("As always, corrections or comments are greatly appreciated (and errata will be collected at ")#link("https://terrytao.wordpress.com/books/expansion-in-finite-simple-groups-of-lie-type/")[#text("this page")]#text(").")

#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f4b77766c835c33f7d2b638347f2a2588160405aff0fa8ac7810e3d9c202fa7-031252fa54b2400ae360f0e69a646ccde2f6818237ded05c485e250e4bc4c447.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of oogenhand")]], [#link("https://terrytao.wordpress.com/2013/10/31/expansion-in-finite-simple-groups-of-lie-type-2/#comment-249849")[#strong[#text("oogenhand")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2013")])]

#text("Reblogged this on ")#link("http://oogenhand.wordpress.com/2013/11/03/expansion-in-finite-simple-groups-of-lie-type/")[#text("oogenhand")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/31/expansion-in-finite-simple-groups-of-lie-type-2/#comment-250173")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2013")])]

#text("Congratulations on such milestone!")
]
