// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/10/31/expansion-in-finite-simple-groups-of-lie-type-2/
// Converted to Typst by tao2typ: "2026-10-31T12:52:42.509598+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Expansion in finite simple groups of Lie type", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Expansion in finite simple groups of Lie type")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 31 October 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/10/31/expansion-in-finite-simple-groups-of-lie-type-2/")[#text("https://terrytao.wordpress.com/2013/10/31/expansion-in-finite-simple-groups-of-lie-type-2/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-31 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’ve just finished the first draft of my book “")#link("https://terrytao.wordpress.com/wp-content/uploads/2013/11/expander-book.pdf")[#text("Expansion in finite simple groups of Lie type")]#text("“, which is based in the ")#link("https://terrytao.wordpress.com/category/teaching/254b-expansion-in-groups/")[#text("lecture notes for my graduate course on this topic")]#text(" that were previously posted on this blog. It also contains some newer material, such as the notes on Lie algebras and Lie groups that I posted most recently here.")

#text("As always, corrections or comments are greatly appreciated (and errata will be collected at ")#link("https://terrytao.wordpress.com/books/expansion-in-finite-simple-groups-of-lie-type/")[#text("this page")]#text(").")

#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83c3bc139f27e6d3c34dff01d22b4a194e8fc2fc973c210c0ce6bb67dc307580-7bffa41730688f99130a4bcc709217a2ea66f6ec23dd055c46d7eecc4f2c5d36.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of oogenhand")]], [#link("https://terrytao.wordpress.com/2013/10/31/expansion-in-finite-simple-groups-of-lie-type-2/comment-page-1/#comment-249849")[#strong[#text("oogenhand")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2013")])]

#text("Reblogged this on ")#link("http://oogenhand.wordpress.com/2013/11/03/expansion-in-finite-simple-groups-of-lie-type/")[#text("oogenhand")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2013/10/31/expansion-in-finite-simple-groups-of-lie-type-2/comment-page-1/#comment-250173")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2013")])]

#text("Congratulations on such milestone!")
]
