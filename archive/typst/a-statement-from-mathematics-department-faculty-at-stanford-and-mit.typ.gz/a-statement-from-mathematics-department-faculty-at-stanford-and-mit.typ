// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/
// Converted to Typst by tao2typ: "2026-10-14T15:20:36.817193+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A statement from mathematics department faculty at Stanford and MIT", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A statement from mathematics department faculty at Stanford and MIT")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 February 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/")[#text("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[The following statement is signed by several mathematicians at Stanford and MIT in support of one of their recently admitted graduate students, and I am happy to post it here on my blog. -T]")]

#text("We were saddened and horrified to learn that Ilya Dumanski, a brilliant young mathematician who has been admitted to our graduate programs at Stanford and MIT, has been imprisoned in Russia, along with several other mathematicians, for participation in a peaceful demonstration. Our thoughts are with them. We urge their rapid release, and failing that, that they be kept in humane conditions. A petition in their support has been started at")

#link("https://www.ipetitions.com/petition/a-call-for-immediate-release-of-arrested-students/")[#text("https://www.ipetitions.com/petition/a-call-for-immediate-release-of-arrested-students/")]

#text("Signed,")

#link("http://math.mit.edu/~bezrukav/")[#text("Roman Bezrukavnikov")]#text(" (MIT)")#linebreak()#link("https://math.mit.edu/directory/profile.php?pid=1222")[#text("Alexei Borodin")]#text(" (MIT)")#linebreak()#link("https://math.stanford.edu/~bump/")[#text("Daniel Bump")]#text(" (Stanford)")#linebreak()#link("https://statweb.stanford.edu/~souravc/")[#text("Sourav Chatterjee")]#text(" (Stanford)")#linebreak()#link("http://web.stanford.edu/~ochodosh/")[#text("Otis Chodosh")]#text(" (Stanford)")#linebreak()#link("http://math.stanford.edu/~ralph/")[#text("Ralph Cohen")]#text(" (Stanford)")#linebreak()#link("http://math.mit.edu/~cohn/")[#text("Henry Cohn")]#text(" (MIT)")#linebreak()#link("http://math.stanford.edu/~conrad/")[#text("Brian Conrad")]#text(" (Stanford)")#linebreak()#link("https://math.mit.edu/~dunkel/")[#text("Joern Dunkel")]#text(" (MIT)")#linebreak()#link("http://math.mit.edu/~etingof/")[#text("Pavel Etingof")]#text(" (MIT)")#linebreak()#link("https://stanford.edu/~jacobfox/")[#text("Jacob Fox")]#text(" (Stanford)")#linebreak()#link("http://www-math.mit.edu/~goemans/")[#text("Michel Goemans")]#text(" (MIT)")#linebreak()#link("https://virtualmath1.stanford.edu/~ionel/")[#text("Eleny Ionel")]#text(" (Stanford)")#linebreak()#link("https://mathematics.stanford.edu/people/steven-kerckhoff")[#text("Steven Kerckhoff")]#text(" (Stanford)")#linebreak()#link("https://web.stanford.edu/~jluk/")[#text("Jonathan Luk")]#text(" (Stanford)")#linebreak()#link("https://mathematics.stanford.edu/people/eugenia-malinnikova")[#text("Eugenia Malinnikova")]#text(" (Stanford)")#linebreak()#link("https://math.mit.edu/directory/profile.php?pid=177")[#text("Davesh Maulik")]#text(" (MIT)")#linebreak()#link("https://web.stanford.edu/~rmazzeo/cgi-bin/")[#text("Rafe Mazzeo")]#text(" (Stanford)")#linebreak()#link("http://www-math.mit.edu/~hrm/")[#text("Haynes Miller")]#text(" (MIT)")#linebreak()#link("https://people.csail.mit.edu/moitra/")[#text("Ankur Moitra")]#text(" (MIT)")#linebreak()#link("http://math.mit.edu/~elmos/")[#text("Elchanan Mossel")]#text(" (MIT)")#linebreak()#link("http://math.mit.edu/~mrowka/")[#text("Tomasz Mrowka")]#text(" (MIT)")#linebreak()#link("http://www-math.mit.edu/~poonen/")[#text("Bjorn Poonen")]#text(" (MIT)")#linebreak()#link("http://www-math.mit.edu/~apost/")[#text("Alex Postnikov")]#text(" (MIT)")#linebreak()#link("http://math.stanford.edu/~ryzhik/")[#text("Lenya Ryzhik")]#text(" (Stanford)")#linebreak()#link("http://www-math.mit.edu/~seidel/")[#text("Paul Seidel")]#text(" (MIT)")#linebreak()#link("http://math.mit.edu/~sipser/")[#text("Mike Sipser")]#text(" (MIT)")#linebreak()#link("http://math.stanford.edu/~ksound/")[#text("Kannan Soundararajan")]#text(" (Stanford)")#linebreak()#link("http://math.mit.edu/~gigliola/")[#text("Gigliola Staffilani")]#text(" (MIT)")#linebreak()#link("https://math.mit.edu/~nsun/")[#text("Nike Sun")]#text(" (MIT)")#linebreak()#link("http://virtualmath1.stanford.edu/~rltaylor/")[#text("Richard Taylor")]#text(" (Stanford)")#linebreak()#link("http://virtualmath1.stanford.edu/~vakil/")[#text("Ravi Vakil")]#text(" (Stanford)")#linebreak()#link("http://math.stanford.edu/~andras/")[#text("Andras Vasy")]#text(" (Stanford)")#linebreak()#link("https://theory.stanford.edu/~jvondrak/")[#text("Jan Vondrak")]#text(" (Stanford)")#linebreak()#link("https://mathematics.stanford.edu/people/brian-white")[#text("Brian White")]#text(" (Stanford)")#linebreak()#link("http://math.mit.edu/~zyun/")[#text("Zhiwei Yun")]#text(" (MIT)")

#align(center)[
#image("../assets/efa8b28e7eaf5afbcf1614a16db359fa0e5fe5c0413ca37158a1de96c6c3c9be-b1442e85b03bdcaf66dc58c7abb98745dd2687d86350be9a298a1d9382ac849b.gif", width: 90%)
]

#heading(level: 1)[#text("Comments (35)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622115")[#strong[#text("Curious")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2021")])]

#text("What was the peaceful demonstration?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d425f3db8e49b01d7b613ff608fbd8756ef292760fdf00269face23964abb35a-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ilya Kapovich")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622129")[#strong[#text("Ilya Kapovich")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2021")])]

#text("As explained at the ipetitions link in the statement, the peaceful demonstration in question was the January 31 protest across Russia against the new prison sentence for Alexei Navalny. Hundreds of students and many faculty members have been arrested in Moscow, Saint Petersburg and other cities across Russia and many received jail sentences from a few days to several weeks. These arrests are currently ongoing and people are being prosecuted for retweeting or posting on social media information about the Navalny protests.")#linebreak()#text(" Ilya Dumanski himself received a jail sentence of 10 days in an express trial on Feb 1, and he is still serving it at the moment.")#linebreak()#text(" There is a video message from him in prison, for those who speak Russian:")#linebreak()#text(" ")#link("https://t.me/doxajournal/5912")[#text("https://t.me/doxajournal/5912")]#linebreak()#text(" For those who are interested, a lot more info (in Russian, you’ll need to use GoogleTranslate) is available at")#linebreak()#text(" ")#link("https://news.doxajournal.ru/novosti/")[#text("https://news.doxajournal.ru/novosti/")]#linebreak()#text(" ")#link("https://t.me/s/doxajournal/")[#text("https://t.me/s/doxajournal/")]#linebreak()#text(" ")#link("https://t.me/s/nedimonspbinf")[#text("https://t.me/s/nedimonspbinf")]#linebreak()#text(" ")#link("https://t.me/s/apologia")[#text("https://t.me/s/apologia")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6a158f100564286398bc05b397f1c74f82d5a21dccc7c67b9e781d0e5fe1c640-b05e3406aa0c928f716533477b0d3a7ff8470a5a0d8581478a1a44ff370332cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Universities are Evil")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622207")[#strong[#text("Universities are Evil")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2021")])]

#text("Quick trials with sentences of a few days to several weeks is middle-of-the-road in international terms. It is arrogant beyond words for Stanford and MIT (indeed, specific *departments* at those schools) to assert that merely having accepted a student, who has not even agreed to attend either school, entitles them to make demands as to how Russia run its internal affairs.")

#text("The US government that pays direct and indirect subsidies on the order of a billion dollars a year to Stanford and MIT, is doing that and more — TEN YEAR prison terms for some charges — to the January 6 protestors, including arrests, legal threats and investigations of people who did not enter the Capitol or were not in Washington DC. They were “pro-democracy activists” by the standard the US State Department uses for other countries. MIT and Stanford are not interested in political clampdowns as long as the dough keeps rolling in.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c5df9492d2138555cec2ebcd4fdb5a3e6a9c62453d52d5f5a18a80502819fc5-90d53e8533ff8bd454c14b165ded5bf9e6cf347067e100d41255509f429edb5b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Better to take a moral stand everywhere.")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622218")[#strong[#text("Better to take a moral stand everywhere.")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2021")])]

#text("Subsidy is the wrong word. Every employee amazon squeezes at software produces 10 times as much revenue to the company that the pay incurs which subsidizes the organization and pays the tax payer in return. To grow a single talent in US is an enormous fortune. US imports subsidies of other governments is the proper terminology (Professor Tao highlights the student and perhaps the student is of immense value but still he is a single life and the posting is about the morality of the situation and not who benefits in the situation).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e3d1461b018ec6050a846c27fc45c22a4517241632555dfb4041a2733071a35-8c33cfe37c0317494b427249933b403ed2e80bb0e629aa58a7c98ff5a118a96e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Universities are Evil")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622242")[#strong[#text("Universities are Evil")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("Subsidy is the correct term. Direct cash transfers, tax exemption, and the direction of government policy to enrich universities (e.g., financial aid, special legal treatment of student loans) have created a parasite sector whose costs, revenues and endowments have grown at MANY times the rate of the economy and the rate of inflation, most of that driven by administrative expenses rather than new productivity.")

#text("Your story of the imported Amazon employee, “created” by universities as it were, or imported (as though that were a net economic benefit) is a fable spun by the Chamber of Commerce. Every new US resident uses a couple of million dollars or more in infrastructure built here, lowers the wages and availability of housing and education to natives (by raising prices and competing for limited places), brings all the problems that come with social and political diversity in the unassimilated generations, and on average represents a net cost (cf. econometric work of George Borjas at Harvard).")

#text("Those immigrants we brought to STEM graduate programs are not a compensating subsidy by the home countries, they represent low-cost paper and pencil instruction in their homelands. If they had enough of the expensive stuff like laboratories and particle accelerators domestically they wouldn’t need to come to the US. Math is cheap, textbook-and-exam instruction (non US style) is cheap, and relying on brain drain is an expensive strategy compared to upgrading the cheap domestic education in the USA. Which of course we are not allowed to do because of government capture by the universities. Evil!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c5df9492d2138555cec2ebcd4fdb5a3e6a9c62453d52d5f5a18a80502819fc5-90d53e8533ff8bd454c14b165ded5bf9e6cf347067e100d41255509f429edb5b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Better to take a moral stand everywhere.")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622341")[#strong[#text("Better to take a moral stand everywhere.")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2021")])]

#text("Universities are inefficient. Industry is efficient because all the inefficiencies are moved to academia. What you build in the real world were modeled by 1000s of researchers and perfected in academia by a clusmy oaflike process and sent to oafins in the outside world who can later claim to transport humans to other planets by private effort and entrepreneurship and still say in a simulated world it all indeed originated from their heads (all the trillions of dollars effective investment over a long period to produce a few cocky billionaires).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622246")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("According to the natural selection rules, every persistent organization (“good” or “evil”) is attempting to protect itself from potential “enemies”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cea26646f23f520e349e2946ab29458ebf5f88b0ad494ace48b27e0dcb2d6760-fedf8ed336cec89d50063184fa602d504c56ab660c679df59f2796766134d6ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PAOK")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-631530")[#strong[#text("PAOK")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2021")])]

#text("Bolches yarboclos")

#text("Uncle Vlad the Impaler thinks otherwise.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46756071817445e9a765ee7114a22049b0702ebc937268e5ad95cf229791776c-df1ea12ed1ab846f3b7a45c1b8bd3638e30595ad0e0738ace0e282f056d7e1eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orsis Rutherford")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622161")[#strong[#text("Orsis Rutherford")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2021")])]

#text("Not a good idea to mix math with politics.")#linebreak()#text(" Navalny is a CIA asset. Shame on you woke mathematitians.!!!!")#linebreak()#text(" Stick to math and leave politics to Satanist pedophiles like Nancy Pelosi and Joseph Biden.")#linebreak()#text(" And poor Ilya deserves his 10 days in jail for being an idiot. At least he did not get shot in the face like Ashley Babbitt.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/38cb1f43761fc9821677b6422c7bbef4f130cf2e95d7f6c3cb2310315ffc22e1-1fcda325bbdbaffd08b2a95ca49f797583bfaffc1a1de5f3d2b595f73b5984ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rogets")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622550")[#strong[#text("Rogets")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2021")])]

#text("Your stupidity is palpable.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/34385ae8db3827f0953d4677ea2f9f2fe5728110bbcdea4e96a2bfd63e7ee0e9-da28b75fcb1483de38f40576adbd70faef34695dba1b058f731c27e5377fad12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622164")[#strong[#text("Andrew")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2021")])]

#text("First hope you all voted for Trump not that it’s going to do you any good now but promise you biden. The man doesn’t look like a trump supporter so too bad guess you reap what you sow. Secondly I’ve looked and I can’t find anything about his arrest or what he was arrested for. If I’m going to put my name on a petition for a man I’d like to know what he did in the other country not just by your words saying it’s a peaceful protest. Since I’ve witnessed peaceful protests here burned down some cities even in the last year. Was it a”mostly peaceful protests” or maybe a peaceful protest in which police were shot or someone was beaten savagely and needed hospitalization? I am glad that all of the MIT and Stanford professors were there to witness the protest to tell us it was peaceful, oh wait they might just be full of crap like so much I’ve heard this year.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88f50615ae8fe3c17bf7974134c5cb7249c9eac7ac071ef81e10f49158672c14-d02c0ea9db279dc79c6cb910834b95d6cf73c601b65c884cc5228e1402ab96af.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pgsince69")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622166")[#strong[#text("pgsince69")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2021")])]

#text("Prayers to all")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/360e3726bab5312aee1e5b888f7cf394f86df90679ae783693c7c00b00f72d88-a8ebfbcb52c7f48e805ac6fd9d2785a83606674f29344da0dea99a6e7c419ad9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Better to take a moral stand everywhere.")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622172")[#strong[#text("Better to take a moral stand everywhere.")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2021")])]

#text("I think there are terrible wrongs done in USA. For instance the plight of immigrants (legal ones). You are trying to take a moral stand. But in reality the stand is not any better than neutral. You can for instance post a blog stating to help graduate students immigration separately from the crony ‘particular ethnic community’ caucus’ illegal immigration demands which lays hostage to legal immigration situation. Clearly 100 illegals from one country cannot hold hostage to 1 bright graduate student (the ratio is 100 to 1 or worse) perhaps from your own school or elsewhere. If the support is about education then the obligation should be universal not just for the sake of taking a stand for public image.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622175")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2021")])]

#text("For those who are saying that this is an unfriendly act of mixing mathematics with politics, here are a few incidents where lack of such an activity caused serious bad outcomes.")

#text("Abel getting declined a job: had the mathematics community at that time showed mass support in favour of Abel, he would have not died of starvation at that young age.")

#text("Grothendieck : we all know.")

#text("Be it a talented mathematician or not, we do not have the right to let anyone suffer from injustice; the mathematics community is doing the right thing and we must support that.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622176")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2021")])]

#text("Furthermore, this also shows what could have happened to genius mathematicians like Paul Erdos if he didn’t leave Hungary for USA at the right time.")#linebreak()#text(" No matter whether the person suffering injustice is a genius or not, we must not let any innocent suffer. Furthermore losing a genius, or punishing a talented mind without any reason just demotivates him or her and that puts the whole society at danger of not receiving the benefits of his or her talents.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c5df9492d2138555cec2ebcd4fdb5a3e6a9c62453d52d5f5a18a80502819fc5-90d53e8533ff8bd454c14b165ded5bf9e6cf347067e100d41255509f429edb5b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Better to take a moral stand everywhere.")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622184")[#strong[#text("Better to take a moral stand everywhere.")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2021")])]

#text("If Erdos or Grothendieck came here from any other place other than Europe or South America or Australia he/she is most likely (keyword likely (odds involves numbers)) to have a miserable time. No one said this was a bad post. On the other hand this post is one of those most biased picks to elevate public image shamelessly (perhaps if European Union had been treated as one country for immigration purposes mathematicians would scramble to save their ‘legacy’ (I don’t understand what goal this post is going to accomplish other than self-image)).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c5df9492d2138555cec2ebcd4fdb5a3e6a9c62453d52d5f5a18a80502819fc5-90d53e8533ff8bd454c14b165ded5bf9e6cf347067e100d41255509f429edb5b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Better to take a moral stand everywhere.")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622185")[#strong[#text("Better to take a moral stand everywhere.")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2021")])]

#text("It is ridiculous to post just for 1 guy (no one probably knew him until this post) a post shows up while ignoring the vast majority of insaneness that is going on (graduate students in past, present and future).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622178")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2021")])]

#text("Reblogged this on ")#link("https://scoutmathematics.wordpress.com/2021/02/10/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/")[#text("Aditya Guha Roy's weblog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622181")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2021")])]

#text("Hope the Bidden administration gets them home soon and safely.")#linebreak()#text(" I will pray they get home safely.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/654860f7ab3bccdacdd1edf4ed9ca7a452824bc33757d21bd183dd0012aafae1-bef87085757bcf462a3a59c721d677df37b119c3fd1e9113e67b868e9183be0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edgawliet")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622204")[#strong[#text("Edgawliet")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2021")])]

#text("You have my support Professor Tao.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Reznikov")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622224")[#strong[#text("Alexander Reznikov")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2021")])]

#text("Dear Terry,")

#text("I realize you might not want to go political in the comments, but I have to ask: if the Russian government ignores your demands (and even if it does not, there are so many people being tortured there), will you consider not attending the ICM (that will be funded by the same government)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5afe613a7cf75cf5e33b13f713e7e501c53e8d5c0cd607fc42dedbb008e20fcb-30886b1afd42979294c16c057e5c962c9c82c85d287918ed09f97397adb5f3c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622274")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("Considering new EU sanctions after Navalny’s poisoning, I am surprised that IMU is still apparently holding ICM in Russia.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9830b7cafb06a963c886ab284a51750713da27553dc1f1cd046adbe5d6be529-d4205b68602f1ad69bb5fabd5295dc096c1c0df668a8fc5638ef1d0adbda7ad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of the good old days")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622316")[#strong[#text("the good old days")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2021")])]

#text("That’s like publicly saying to a public figure in front of a crowd, 50 years ago in the old country, “I have to ask, will you be joining the Party?”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622227")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2021")])]

#text("What’s the reason? The US government arrested a lot of Chinese scientists in the US and in China (via some fake conference invitations) for some fake reasons. Please release them. Most mathematicians are jut idiots on politics. Stay away from politics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18771d3b1cc7bb3b34e29695f42c25853ca248fe9ad09459381b9db4616210bf-0e72cd8657efb011df8b7186cfb3e707126f8e7832842673fd2ca06382d6c385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John McAllison")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622229")[#strong[#text("John McAllison")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2021")])]

#text("I feel very uneasy about the politics involved here:")

#text("Alexey Navalny is to Russian politics what Trump is to American politics: politically incompetent with zero political experience and a racist in the view of some. And were the demonstrations legal and non-violent as claimed?")#linebreak()#text(" Putin, for all his faults, is a professional politician that knows how to integrate different ethnic groups into Russia whereas Alexey Navalny has compared immigrants to “cockroaches”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/def6e51f14d2a0711ccd492d61c36f3205aad3f259a2d390f2d9f101a1436f88-4b27221765b508c3ae5e7bb7ca4207a49d54958f6445fefb36f7afd0a578a991.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622230")[#strong[#text("Lars")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2021")])]

#text("Peaceful peaceful or BLM peaceful?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e456fd8bc7eba884f0e6a7dafafabe4f5b8a985f98b248c40150f6a0555e743-34584d23e2465a3aacd9958373076a0662df1ba19e1cbaee6e28601e22107935.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Racism Sucks")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622551")[#strong[#text("Racism Sucks")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2021")])]

#text("BLM protests were overwhelmingly peaceful, even in the face of armed racist cowards.")

#text("And other impotent racists. Like you.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/229942d2ec6c4e33fa46fe819fe1288fdfdff572eadcfc4c5036fed957e008bb-57ccb42d2e04b4e625f587772bf7630a5f832657cf0657ddbd11ab60c6889059.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Don Quijote")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622264")[#strong[#text("Don Quijote")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("What a patronizing and pretentious bunch (mathematicians")#linebreak()#text(" who signed this).")

#text("To put his in perspective, how would US mathematicians react")#linebreak()#text(" if there is a petition from overseas that demand recognition and")#linebreak()#text(" fair treatment for women and minority, underprivileged mathematicians")#linebreak()#text(" in the US?")

#text("Ironically, having a petition like this may have the opposite intended effect.")

#text("Unlike other commenters, I believe mathematicians (and their colleagues in other fields) should come out of their “bubbles” and rally behind certain social issues. But they would be wise to pick their battles closer to home. The internet just makes it easier to slap one’s “signature” down and make him/her feel good about doing something.")

#text("Now downvote this comment as much you want so it draws attention to how")#linebreak()#text(" ludicrous, fruitless these actions are.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622285")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("Dear Terry,")

#text("Please consider signing the ICM 2022 boycott petition.")

#link("http://www.icm2022boycott.org/")[#text("http://www.icm2022boycott.org/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e86d0d986a8fe0c8588b78cbc485839a44089585c2c6aa07e5b3b9d7023dd9c-b2b8e2da3d836928db48a20722f2cc36f5aec1a87e861f09eb001dcc50d2491b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of STEM Caveman")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622290")[#strong[#text("STEM Caveman")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("You will notice the total lack of Russians living in Russia who signed the petition, even anonymously, and no indication that Russians in Russia want the ICM there cancelled or think that would be helpful. Rather, we see a list of virtue signaling Western academics with no skin in the game, happy to volunteer their Russian colleagues as guinea pigs.")

#text("The concern about Russia’s politics, much like concern about Tibet, Taiwan and Hong Kong, is far from universal around the world, but ICM is an international organization. It has quite a lot of members in Russia, China, Iran, and Arab and African countries where the US State Department party line differs from official or popular opinion. This type of petition is Foggy Bottom projecting soft power through academic proxies, not a stand for democracy.")

#text("Speaking of State and its color revolutions, how’d the US election go? There’s a de facto communist revolution in progress, a political and economic clampdown on anyone to the right of Chuck Schumer, and the White House is at the moment floating a boycott not of Russia but of *Florida*. Given the centrality and power of US academia and the totalitarian tendencies now engulfing it (e.g., deplatforming, summary firings, critical race theory, mandatory Diversity Statements), if the ICM is interested in intellectual and political freedom the developments in USA pose more of a problem than anything in Russia, but splitting Russia away from the rest of ICM would exacerbate the dominance of the USA and its dysfunctional academic politics within the organization. The AMS, for example, just rolled out a race-specific “fellowship for a black mathematician”. Anyone at ICM willing to take a stand on that?")

#text("For every ICM speaker who declines to go to Russia, there are several mathematicians who would be happy to take their place. So the “free market of ideas” and people “voting with their feet” works against this boycott, and the only way to make it successful is to apply pressure to the ICM as a whole and impose it from the top. Which of course has a lot less political legitimacy; the angriest faction may win by tantrum, not by being right or popular. The top-down workaround is a very familiar move for fringe movements in a hurry for political power, it usually does not end well, and it is obviously at odds with a supposed concern for democracy and human rights.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/429d96200205d715512da71360d948c643ba116e89b5fea41e180e0bfa63ff66-8b0d1ed0ef840a77bd10f02d87eac31d4b39cd20b7f4ea20dfe51ae76425164d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antifa Math")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622549")[#strong[#text("Antifa Math")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2021")])]

#text("There is no “communist revolution” pending, you racist moron.")

#text("We get it: you’re all filled up on stupid, and wanna export it.")

#text("Try somewhere else.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/041e0d8efb404a6a2cf18b2270a848edf2c64e454a9f79bc7b5042d769355180-62fe160b29fccbce5500ff3d0ac989c0d3a0e9678d38be9c88331b114d02c1d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622918")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2021")])]

#text("Both US and Russia are repressive regimes. The fact that US is repressive in some ways doesn’t excuse the fact that Russia is repressive in other ways. I agree with boycotting both. More generally, Western countries have manifested in recent times they profound contempt for human rights and democracy (with the lockdowns, etc.) and indeed it is hypocritical for them at the moment to pretend that whatever happens in Russia is _so much worse_ than what happens domestically. Still we should oppose both developments, both in Russia and in Western countries.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/041e0d8efb404a6a2cf18b2270a848edf2c64e454a9f79bc7b5042d769355180-62fe160b29fccbce5500ff3d0ac989c0d3a0e9678d38be9c88331b114d02c1d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622919")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2021")])]

#text("You will also notice that the petition was initiated by four Polish mathematicians working in Poland, and as you know “virtue signaling about liberal causes” is not part of Polish culture, while it is obviously by now a huge part of American culture. So your theory that virtue signaling by academics is the only reason for the petition opposing ICM2022 in Russia cannot be entirely accurate.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622291")[#strong[#text("Particular petitions and the leveraging of professional reputation | Life, Liberty, and Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")]

#text("[…] Russians of all walks of life has taken to the streets, including many academics, so naturally some of those arrested are academics. Concerned colleagues in the West (sadly the old terms are still relevant) are naturally sympathetic, and petitions of support for specific Russian individuals are circulating. A colleague in my department circulated the petition in support of Alexander Kuznetsov, and another circulated this petition in support of three arrested students, a petition also promoted by Terry Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5afe613a7cf75cf5e33b13f713e7e501c53e8d5c0cd607fc42dedbb008e20fcb-30886b1afd42979294c16c057e5c962c9c82c85d287918ed09f97397adb5f3c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2021/02/08/a-statement-from-mathematics-department-faculty-at-stanford-and-mit/#comment-622917")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2021")])]

#text("Maybe IMU should watch this video and read this article and seriously consider moving ICM elsewhere:")

#link("https://www.france24.com/en/live-news/20210301-navalny-s-penal-colony-a-kremlin-weapon-to-break-him")[#text("https://www.france24.com/en/live-news/20210301-navalny-s-penal-colony-a-kremlin-weapon-to-break-him")]

#text("Morally, holding ICM in Russia is like holding it in the rotten garbage pile.")
]
