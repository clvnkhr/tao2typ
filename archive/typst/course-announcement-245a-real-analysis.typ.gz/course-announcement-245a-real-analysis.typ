// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/08/31/course-announcement-245a-real-analysis/
// Converted to Typst by tao2typ: "2026-10-14T15:17:50.394464+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Course announcement: 245A, Real analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Course announcement: 245A, Real analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 31 August 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/08/31/course-announcement-245a-real-analysis/")[#text("https://terrytao.wordpress.com/2010/08/31/course-announcement-245a-real-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In a few weeks (and more precisely, starting Friday, September 24), I will begin teaching ")#link("http://www.math.ucla.edu/~tao/245a.1.10f/")[#text("Math 245A")]#text(", which is an introductory first year graduate course in real analysis. (A few years ago, I taught the followup courses to this course, ")#link("https://terrytao.wordpress.com/category/teaching/245b-real-analysis/")[#text("245B")]#text(" and ")#link("https://terrytao.wordpress.com/category/teaching/245c-real-analysis/")[#text("245C")]#text(".) The material will focus primarily on the foundations of measure theory and integration theory, which are used throughout analysis. In particular, we will cover")

#enum(start: 1, 
[#text("Abstract theory of ")#link("http://en.wikipedia.org/wiki/Sigma-algebra")[#mi("\\sigma")#text("-algebras")]#text(", ")#link("http://en.wikipedia.org/wiki/Sigma-algebra")[#text("measure spaces")]#text(", measures, and integrals;")],
[#text("Construction of ")#link("http://en.wikipedia.org/wiki/Lebesgue_measure")[#text("Lebesgue measure")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Lebesgue_integration")[#text("Lebesgue integral")]#text(", and connections with the classical ")#link("http://en.wikipedia.org/wiki/Riemann_integral")[#text("Riemann integral")]#text(";")],
[#text("The fundamental convergence theorems of the Lebesgue integral (which are a large part of the reason why we bother moving from the Riemann integral to the Lebesgue integral in the first place): ")#link("http://en.wikipedia.org/wiki/Fatou%27s_lemma")[#text("Fatou’s lemma")]#text(", ")#link("http://en.wikipedia.org/wiki/Monotone_convergence_theorem")[#text("monotone convergence theorem")]#text(", and the ")#link("http://en.wikipedia.org/wiki/Dominated_convergence_theorem")[#text("dominated convergence theorem")]#text(";")],
[#link("http://en.wikipedia.org/wiki/Product_measure")[#text("Product measures")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Fubini%27s_theorem")[#text("Fubini-Tonelli theorem")]#text(";")],
[#text("The ")#link("http://en.wikipedia.org/wiki/Lebesgue_differentiation_theorem")[#text("Lebesgue differentiation theorem")]#text(", ")#link("http://en.wikipedia.org/wiki/Absolute_continuity")[#text("absolute continuity")]#text(", and the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_calculus")[#text("fundamental theorem of calculus")]#text(" for the Lebesgue integral. (The closely related topic of the ")#link("http://en.wikipedia.org/wiki/Lebesgue%27s_decomposition_theorem")[#text("Lebesgue")]#text("–")#link("http://en.wikipedia.org/wiki/Radon%E2%80%93Nikodym_theorem")[#text("Radon-Nikodym")]#text(" theorem is likely to be deferred to the next quarter.)")]
)

#text("See also ")#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/")[#text("this preliminary 245B post")]#text(" for a summary of the material to be covered in 245A.")

#text("Some of this material will overlap with that seen in an advanced undergraduate real analysis class, and indeed we will be revisiting some of this undergraduate material in this class. However, the emphasis in this graduate-level class will not only be on the rigorous proofs and on the mathematical intuition, but also on the bigger picture. For instance, measure theory is not only a suitable foundation for rigorously quantifying concepts such as the area of a two-dimensional body, or the volume of a three-dimensional one, but also for defining the probability of an event, or the portion of a manifold (or even a fractal) that is occupied by a subset, the amount of mass contained inside a domain, and so forth. Also, there will be more emphasis on the subtleties involved when dealing with such objects as unbounded sets or functions, discontinuities, or sequences of functions that converge in one sense but not another. Being able to handle these sorts of subtleties correctly is important in many applications of analysis, for instance to partial differential equations in which the functions one is working with are not always ")#emph[#text("a priori")]#text(" guaranteed to be “nice”.")

#heading(level: 1)[#text("Comments (17)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2010/08/31/course-announcement-245a-real-analysis/#comment-46728")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2010")])]

#text("“Nice” and “Not nice.” Hmmmm.")

#text("This is my favorite Dirac story. When P.A.M. Dirac was in his late 20s Dirac and Heisenberg took a cruise together to Japan. Heisenberg, who was a social animal, would dance every evening with the ladies, while the orchestra played.")

#text("Dirac, probably suffering from Aspergers, and from a dysfunctional family, finally asked him, “Why do you dance?”")

#text("Heisenberg replied — not unreasonably — “When there are nice girls, it is a pleasure to dance with them.”")

#text("Dirac thought about this for 5 minutes. Then he said: “Heisenberg, how do you know a priori that the girls are nice?”")

#text("I remember the sandwich that my mentor and coauthor Feynman had the")#linebreak()#text(" owner of the topless bar in Pasadena add to the booze menu, after the")#linebreak()#text(" City shut it down. That was a ham and cheese sandwich.")

#text("Feynman, who liked going there (”after a hard day dealing with")#linebreak()#text(" oscillating bodies, it’s nice to see some oscillating bodies”), succeeded in keeping the place open a few more months. When the city tried enforcing the anti-topless-bar ordinance, the owner could now say: “we’re not a topless bar. We’re a topless restaurant.”")

#text("The other Feynman sandwich anecdote: Leonard Susskind and Feynman are getting a “Feynman sandwich” at the local deli, and Feynman remarks")#linebreak()#text(" that a “Susskind sandwich” would be similar, but with “more ham.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7bd79ccc17907103f59d86fb20316d47cd1b97b6e5da97c6784bb34597ecff0-0d4f3e22196665cd23c0b63eb88a1c5d6701288f8a5ee038d7b21ba2ca261e47.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2010/08/31/course-announcement-245a-real-analysis/#comment-46735")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2010")])]

#text("Do you recommend a textbook for those of us trying to follow along as a supplement to your posts?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87f609b600c0011801e3fecf434b7175b6160f6413a0a344294a78069e0ee4b6-ea67f17c33a5367d97698d0335387c231d9aaae45cc6b588cf0cf51f250cbd8d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A fan")]], [#link("https://terrytao.wordpress.com/2010/08/31/course-announcement-245a-real-analysis/#comment-46736")[#strong[#text("A fan")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2010")])]

#text("So， has the “inverse conjecture” paper been completely finished? Or is there any gap?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben G")]], [#link("https://terrytao.wordpress.com/2010/08/31/course-announcement-245a-real-analysis/#comment-46744")[#strong[#text("Ben G")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2010")])]

#text("There is a complete draft. There’s no gap, but at 100 pages long we want to try and streamline the exposition as much as possible.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87f609b600c0011801e3fecf434b7175b6160f6413a0a344294a78069e0ee4b6-ea67f17c33a5367d97698d0335387c231d9aaae45cc6b588cf0cf51f250cbd8d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A fan")]], [#link("https://terrytao.wordpress.com/2010/08/31/course-announcement-245a-real-analysis/#comment-46751")[#strong[#text("A fan")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2010")])]

#text("Thanks！ And Congratulations to you three and k-tuple project of such far-sight.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/79a190795d80e8c530d4a698e6be06bac867e32eed945b944b9cc603f8f83754-717d77f039a97e939bab0746ac8ac93e3d6f29dd80ba56d28d6bf76de4a9939f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of none")]], [#link("https://terrytao.wordpress.com/2010/08/31/course-announcement-245a-real-analysis/#comment-46742")[#strong[#text("none")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2010")])]

#text("Jeff, the course announcement says that the textbook is “Real Analysis: measure theory, integration, and Hilbert spaces”, by Stein and Shakarchi.")

#text("This sounds great. The book is not even that expensive. I might send away for a copy just to follow along on the blog.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c72e531f0c7c8d6c68121ae704aa263f37e0187adf6f7c5c9c841a6454342897-801dfc6e304bbbbf184393f087ca695e9d1d6ca4cd9ed72a915d8e45e7d3395b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S.C. Kavassalis")]], [#link("https://terrytao.wordpress.com/2010/08/31/course-announcement-245a-real-analysis/#comment-46753")[#strong[#text("S.C. Kavassalis")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2010")])]

#text("I love how you make your course information available to the interested public like this. You are a wonderful inspiration for teachers and aspiring teachers everywhere.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abf42c4c521b5e56a68896ab7306583a40de8f377292a694df60835dd8c96b5c-3fc98460602cbc1b34b409b2296c9757669db40a02b0db4aba705a73b4565609.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of basil")]], [#link("https://terrytao.wordpress.com/2010/08/31/course-announcement-245a-real-analysis/#comment-46754")[#strong[#text("basil")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2010")])]

#text("can’t wait for the notes!!!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbd24672668e8794237c2f9014650055d05ef31fe0238fd649f6e48c9c85a096-38b58c210e2b506346d3aa407f3dc0ac3bc1930624bf77d0ed756b01df06de8c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An ECE Grad Student !")]], [#link("https://terrytao.wordpress.com/2010/08/31/course-announcement-245a-real-analysis/#comment-46756")[#strong[#text("An ECE Grad Student !")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2010")])]

#text("Dear Prof. Tao,")

#text("It would be amazing if there were Videos of the Lectures ! :)")

#text("Do you think this would be possible now or for the near future ?")

#text("Thanks very much")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e5296b75242012daa1e4d627b7cd5b01010b81d8468fd8fd06c48e351fbb369-b7abc69797d36ef2864be9866590a1d776a5f3c1a4d9dc44a1956eba8d7d4369.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Aldrich")]], [#link("https://terrytao.wordpress.com/2010/08/31/course-announcement-245a-real-analysis/#comment-47055")[#strong[#text("Chris Aldrich")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2010")])]

#text("Possibly even better than video versions of lectures would be audio versions of lectures posted with concurrent written notes? I’ve recently been playing with Livescribe.com’s Pulse and Echo pen technologies which do a phenomenal job, particularly for memorializing mathematics lectures. I live locally to Los Angeles/UCLA if anyone would like a demonstration of it.")

#text("If Dr. Tao is interested, I’d volunteer to capture his upcoming class using it and allow him to share it as he sees fit. I think it would be particularly intriguing as although there is a wealth of undergraduate level mathematics material on the web, there is a dearth of upper level lecture material online.")

#text("I’m also curious if anyone here has any experience/thought with the ")#link("http://openstudy.com")[#text("http://openstudy.com")]#text(" platform for studying along with others? I came across it this afternoon and it seems to be an interesting platform.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/08/31/course-announcement-245a-real-analysis/#comment-46758")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2010")])]

#text("Video Lectures are a good idea !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0fc807063d2ae74ade863c339bc88dc57335e179cc2342e264655fc6559af77b-ef4e6ea7e6a33bd542369eeded2342aa40cfecdc1f77f979b0381a460328acbb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ross")]], [#link("https://terrytao.wordpress.com/2010/08/31/course-announcement-245a-real-analysis/#comment-46767")[#strong[#text("Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2010")])]

#text("John shut up please.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3a2b97a1eba9d06f3c5c9d0490557d5d49e85d73a723d580d6b5f638d5336fa8-96541a5a296f1ef2e2dd7caf3f9018316626bedfc57ce94ee8e42627f26599eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of saharra")]], [#link("https://terrytao.wordpress.com/2010/08/31/course-announcement-245a-real-analysis/#comment-46769")[#strong[#text("saharra")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2010")])]

#text("this is great post")#linebreak()#text(" thank you so much Prof Tao")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0d474a860188a57b59db3a9d3934801c05cd54ee0718ab24e167e04138e09ff-d2a256353dd9c69bce34c47873266bfb364cdb0e72a6f0ffa643055fb2533369.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of futbolusa")]], [#link("https://terrytao.wordpress.com/2010/08/31/course-announcement-245a-real-analysis/#comment-46775")[#strong[#text("futbolusa")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2010")])]

#text("This is great! I am taking graduate Real Analysis 1 this Fall and we are using the same book! Awesome!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39be2b741f5db6b9353e856dec84ec21b8b8926658595af6eb2ba1fe4034e3db-57f8a23a2d0df915fb6c6f2a6bf5621c610b963fa3459c3f36a8d34fe528f89e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew L.")]], [#link("https://terrytao.wordpress.com/2010/08/31/course-announcement-245a-real-analysis/#comment-46791")[#strong[#text("Andrew L.")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2010")])]

#text("Dear Dr.Tao,")#linebreak()#text(" I just wanted to thank you for posting your lectures here at your blog. I’m always on the hunt for good free mathematical source material online and your lectures are some of the best there are. In an age when most mathematicans as prominent as you are leave teaching as a belittling drudgery for lesser mortals,you clearly take great pride in your teaching. And I think it’s one of the things that makes you such a great researcher-you don’t just DO mathematics,you THINK about it. A lot. You ask the deep questions a lot of mathematicans are afraid to ask for fear of getting bogged down in metaphysics and delaying thier publication date. And it’s clear you take that same approach with your teaching. Your students are very fortunate,indeed-and the rest of us are that you are generous enough to share the experience with all of us.")#linebreak()#text(" Thank you again.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Real Analysis (=Measure Theory) by Terence Tao « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2010/08/31/course-announcement-245a-real-analysis/#comment-46805")[#strong[#text("Real Analysis (=Measure Theory) by Terence Tao « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2010")])]

#text("[…] Gutes tun will (also Wellness für das Gehirn), dem empfehle ich die Vorlesung von Terence Tao, 245A-Real Analysis, die er begonnen hat zu […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/08/31/course-announcement-245a-real-analysis/#comment-47373")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2010")])]

#text("Dear Prof. Tao,")

#text("which course are you planning to teach after this course?")#linebreak()#text(" I hope you teach a grad level complex analysis course.")

#text("Thank you for these great posts.")
]
