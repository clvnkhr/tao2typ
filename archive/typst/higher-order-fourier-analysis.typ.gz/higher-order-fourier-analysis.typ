// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/
// Converted to Typst by tao2typ: "2026-10-14T15:18:02.390763+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Higher order Fourier analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Higher order Fourier analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 March 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/")[#text("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’ve just finished writing the first draft of my third book coming out of the 2010 blog posts, namely “")#link("https://terrytao.wordpress.com/books/higher-order-fourier-analysis/")[#text("Higher order Fourier analysis")]#text("“, which was based primarily on ")#link("https://terrytao.wordpress.com/category/teaching/254b-higher-order-fourier-analysis/")[#text("my graduate course in the topic")]#text(", though it also contains material from ")#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/")[#text("some")]#text(" ")#link("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/")[#text("additional")]#text(" ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("posts")]#text(" related to linear and higher order Fourier analysis on the blog. ")#link("https://terrytao.wordpress.com/wp-content/uploads/2011/03/higher-book.pdf")[#text("It is available online here")]#text(". As usual, comments and corrections are welcome. There is also a ")#link("https://terrytao.wordpress.com/books/higher-order-fourier-analysis/")[#text("stub page")]#text(" for the book, which at present does not contain much more than the above link.")

#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e8177bfe05cf97387f8d1a717d1e3ae62bab73ceee57365307f791ad8e5129b0-9238e44405e9128296eed0d41e19830cb9cb2c0f042b6969eee3f2ba0f0894b0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Loc")]], [#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/#comment-51110")[#strong[#text("Loc")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2011")])]

#text("I think you have a typo: The name of this book is not “Topics in random matrix theory,” right? ")#emph[#text("[Oops! One of the dangers of cut-and-paste. Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0370d1a896797a6c35d6dcfd44d6754e09ccd8bbc0700b42d12133888202801f-a1c7c2ca13b5ac992b05a7c9dda2638098396ea50fd31bf4c95069b66ad37a4a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Sauvaget")]], [#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/#comment-51115")[#strong[#text("Thomas Sauvaget")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2011")])]

#text("This looks like a very interesting book!")

#text("Speaking of typos, I’ve spotted two:")#linebreak()#text(" – page numbered 183 (i.e. 191 of the file): the big tensor formula at line 5 has a \\huge or the like missing at the end.")#linebreak()#text(" – page numbered 207 (i.e. 215 of the file): at line 12 “We thus…” there’s an \\langle missing.")

#text("This was only after a very fast glance though, not a serious look yet. May I ask: until when should one report any remaining typo, if any?")

#emph[#text("[Corrected for the next revision, thanks! I’d be happy to take corrections at any time, though of course catching them before the final publication of the book would be preferable :-) – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/#comment-51123")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2011")])]

#text("The “Acknowledgements” sections of the preface has a link to the Random Matrix book.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/#comment-51170")[#strong[#text("Prof Terence Tao UCLA on his blog What’s… « What's up Gaurav?")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2011")]

#text("[…] on Higher Order Fourier Analysis based upon his blog posts in 2010. The announcement could be find here or the book in pdf (format) can be directly downloaded from here: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9dda1d414fedfcf6559908f6c68fc50dcbc4259df22bb58331a8d287b807296-79acbc624ae058cda2568300e2466260e9ceef8d5fb5da62f0c6e99a42f05a56.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emanuel")]], [#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/#comment-51174")[#strong[#text("Emanuel")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2011")])]

#text("Good evening mr. , my name is Emanuel and i’m a math student in Romania .")

#text("I have a problem , and if it doesn’t bother you too much i would very much appreciate your opinion on the matter.")

#text("Open problem 1 :")

#text("f is a continuous functions for which the limit at plus infinity does not exist but whose liminf and limsup exist and are finite. Then there exist two sequences that converge to infinity x_n and y_n such that x_n1 and f(x_n) , f(a_n x_n) tends to different limits .")

#text("If these propositions are false do you know some restrictions to f that makes them true ? is periodicity the single one ?")

#text("Thank you, best regards from Romania")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/743ec659e95a03c26d192883fa7bbe7647704868ea113c827a627daa82ded8e0-dbc98e08ce176ef4ec67b629e09f1f3d2786817a4f2ebdb07194ca7cd341d047.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/#comment-51196")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2011")])]

#text("One thing that puzzle me regarding “higher Fourier analysis”, (be it over {1,2,…,n} or {-1,1}^n or other domainas) is what is the “right” analog (if any) of Parseval’s formula.")

#text("It seems that the spectacular applications of higher Fourier theory is in “quasirandomness”. When I tried to find combinatorial applications to areas where ordinary fourier analysis is very useful (influences, monotone functions etc. and even spectral graph theory) the first obstacle seems to be (but I may be wrong) that I dont know of how to replace Parseval formula and its sometime easy consequences to the “higher” case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/#comment-51197")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2011")])]

#text("Yes, this (the lack of an explicit Parseval-type formula) is one of the major deficiencies of higher order Fourier analysis as compared against linear Fourier analysis. The basic issue is as follows. In linear Fourier analysis, if a function f is a linear character, then its Fourier transform is a delta function. But in (say) quadratic Fourier analysis, if f is a quadratic character (say, on F_2^n), then the naive quadratic Fourier transform (i.e. the correlations of f with other quadratic characters) are much more spread out than a delta function, with high correlations with quadratic characters that differ from the original character by a low rank quadratic, and a huge number of low correlations with generic quadratics. In the latter case, the correlation may be exponentially small (e.g. ")#mi("2^{-n/2}")#text(" is typical) but the number of quadratics is huge (something like ")#mi("2^{n^2}")#text(") and so if one takes any sort of L^p type norm, the generic quadratics are certainly going to dominate any putative Parseval-type formula, rather than the quadratics that actually have substantial correlation with the original function f. This suggests to me (in the finite field case, at least), that L^p type norms of correlations will not convey much useful information for the purposes of higher order Fourier analysis.")

#text("One may have to define a “smarter” quadratic Fourier transform that somehow “zeroes in” on the most relevant quadratic characters, rather than blindly correlating the function with _all_ quadratic characters, but I do not know how to construct such an object (and if it were constructed, it seems unlikely that it would obey algebraic identities anywhere near as pleasant as the Parseval identity.) Note though that crude versions of such “smart” higher order decompositions are what underlie the various structure-quasirandomness dichotomies in the subject, used for instance to establish arithmetic progressions in sets such as the primes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d28195df14800315168ea974f4adf888eace7d3a34fc83513af492698793a2c-e2ad3cdfa379c5dcf139408dc5d555ac7c236dfa87abd3799a789b51ef5d74f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kodlu")]], [#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/#comment-51215")[#strong[#text("kodlu")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2011")])]

#text("A simple typo, “the observaation that”, bottom of p. 57")

#emph[#text("[Thanks, this will be corrected for the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d28195df14800315168ea974f4adf888eace7d3a34fc83513af492698793a2c-e2ad3cdfa379c5dcf139408dc5d555ac7c236dfa87abd3799a789b51ef5d74f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kodlu")]], [#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/#comment-51216")[#strong[#text("kodlu")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2011")])]

#text("missing citation number, bottom of p. 60:")

#text("“by the Brascamp-Lieb inequality, see for instance [?] for further discussion.”")

#emph[#text("[Thanks, this will be corrected for the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d768ec80f51b0282d4ae61b5b4c013d98c73e7c37885ebd22d117350cdc90268-22c0ca4bc63cd013d702c2689f5f5c11505c9a780d6892e97dddd73c345b1d4d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JC Yang")]], [#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/#comment-51331")[#strong[#text("JC Yang")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2011")])]

#text("Hi, professor Tao. Would you mind I post a not strictly math related problem here? People would probably appreciate if you lend them your brain power on this one.")#linebreak()#text(" It’s a cryptanalysis problem which force FBI into asking for help.")#linebreak()#text(" Here is the link:")#linebreak()#text(" ")#link("http://www.fbi.gov/news/stories/2011/march/cryptanalysis_032911")[#text("http://www.fbi.gov/news/stories/2011/march/cryptanalysis_032911")]#linebreak()#text(" Yet I have another request, if you lend them brain power and help them successfully decrypt this message, can you please elaborate the steps you tackle this problem in a blog post?")#linebreak()#text(" Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Diego")]], [#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/#comment-51346")[#strong[#text("Diego")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2011")])]

#text("Wonderful book, Terry. Inspiring math and insightful window to your mind. Thank you.")#linebreak()#text(" Below are some simple corrections to be made.")

#text("p. 106 “thaat”.")#linebreak()#text(" P. 123″nilmaniofold”")#linebreak()#text(" p. 141. “Sectino 1.3”")#linebreak()#text(" p. 149. “to favorr”")#linebreak()#text(" p. 153. “See for instance [?] for more discussion. ” Of course, a Ctrl-F")#linebreak()#text(" search for “?” will take care of all these missing references.")#linebreak()#text(" p.219. Reference [Sh2009], article’s title is not in italics.")

#emph[#text("[Corrected for the next revision, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47d5c69d29b66fd3a1a778d648747c9bb6e8c4f0725b0ce1d22f858fe2ef1229-23e4762dee579d79ee766c8f389cceee8fe6155c335cc87100d79b6dfe9bb027.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dr. Sextistics")]], [#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/#comment-51350")[#strong[#text("Dr. Sextistics")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2011")])]

#text("Looking forward to the 3rd Edition. The 2nd was pretty decent. Keep up the good work!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/#comment-51389")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("this looks boring")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a8c1203d7f31aafc34322b009621eb45b736076bb0a611be7053943dfafc686-51bcccf5ddb2ff5658e8ce8dc6b1c1fd8cc866c0e0306612367dcd242fb15df0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gábor Pete")]], [#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/#comment-51390")[#strong[#text("Gábor Pete")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Dear Terry,")

#text("I’m surprised not to see any mention of Balázs Szegedy’s work in the book. I’m not following the area very closely, but I have heard lectures by Balázs, and it seems to me important and relevant. Am I wrong? Or is there some other reason for the omission?")

#text("Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/#comment-51392")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Dear Gabor,")

#text("Ah, thanks for pointing this out. The book was based on a course I gave last spring (Mar-Jun 2010), back when only three of the six papers in Balazs’s series had appeared on the arXiv, and the connection to the combinatorial side of the subject (and in particular, to the inverse conjecture for the Gowers norms) was less clear. Of course I will update the references in view of the progress made in Balazs’s program (although the methods are closer to the ergodic theory side of the subject than the combinatorial one, which is the main focus of this particular text).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a42cba640f2f48d3f054903d909fb2ce11e1a826b0a5390f8e42d4684bea591b-5dce9a925b3fb33ba098ac4f22ed772ccac177173e57b03a627300d00316757a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Answering my own question on the Fourier Series | cartesian product")]], [#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/#comment-51828")[#strong[#text("Answering my own question on the Fourier Series | cartesian product")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2011")])]

#text("[…] Higher order Fourier analysis (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siming Tu")]], [#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/#comment-54109")[#strong[#text("Siming Tu")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2011")])]

#text("Dear Prof. Tao:")#linebreak()#text(" p.219. In the reference,I think that [Roth1964] should be [Roth1953]")

#emph[#text("[This will be corrected in the revised version, thanks. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ali")]], [#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/#comment-54114")[#strong[#text("Ali")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2011")])]

#text("Hi,")#linebreak()#text(" First line of preface: “…has been focused the analysis of…”")

#emph[#text("[This will be corrected in the revised version, thanks. – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/#comment-58480")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2011")])]

#text("Dear Tao,")#linebreak()#text(" Do you know some investigation about high order discrete fourier transform?")#linebreak()#text(" Thanks!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd212631064cd49436302c141d93e06ded016d49f56ca99d344210241ff8474a-4f74795743c5f1e8ed4b888c00b3c059a1e1899629ef0ca1b9abfb7d42611158.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zhiqiang xu")]], [#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/#comment-59441")[#strong[#text("zhiqiang xu")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2011")])]

#text("Dear Tao,")#linebreak()#text(" Do you know some investigation about high order discrete fourier transform?")#linebreak()#text(" For example, is it possible to extend FFT to high order ?")#linebreak()#text(" Thanks!")

#text("Zhiqiang")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/03/30/higher-order-fourier-analysis/#comment-636398")[#strong[#text("CALCULATORS ON-LINE CENTER SUBJECT: F-P - Martindale Center")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2021")]

#text("[…] more information see Higher Order Fourier Analysis; 254B; Terence Tao’s Home Page; Analysis Group or the Department of […]")
]
