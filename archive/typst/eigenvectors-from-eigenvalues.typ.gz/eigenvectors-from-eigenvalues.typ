// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/
// Converted to Typst by tao2typ: "2026-10-14T15:20:20.180824+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Eigenvectors from eigenvalues", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Eigenvectors from eigenvalues")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 August 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/")[#text("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://peterdenton.github.io/")[#text("Peter Denton")]#text(", ")#link("https://home.fnal.gov/~parke/")[#text("Stephen Parke")]#text(", ")#link("https://physics.uchicago.edu/people/profile/xining-zhang/")[#text("Xining Zhang")]#text(", and I have just uploaded to the arXiv the short unpublished note “")#link("https://arxiv.org/abs/1908.03795")[#text("Eigenvectors from eigenvalues")]#text("“. This note gives two proofs of a general eigenvector identity observed recently ")#link("https://arxiv.org/abs/1907.02534")[#text("by Denton, Parke and Zhang")]#text(" in the course of some quantum mechanical calculations. The identity is as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" ")#metadata(none) <tao-69f5e8a085c0a76dac81>#text(" Let ")#mi("{A}")#text(" be an ")#mi("{n \\times n}")#text(" Hermitian matrix, with eigenvalues ")#mi("{\\lambda_1(A),\\dots,\\lambda_n(A)}")#text(". Let ")#mi("{v_i}")#text(" be a unit eigenvector corresponding to the eigenvalue ")#mi("{\\lambda_i(A)}")#text(", and let ")#mi("{v_{i,j}}")#text(" be the ")#mi("{j^{th}}")#text(" component of ")#mi("{v_i}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\left|v_{i,j}\\right|^2 \\prod_{k=1; k \\neq i}^n (\\lambda_i(A) - \\lambda_k(A)) = \\prod_{k=1}^{n-1} (\\lambda_i(A) - \\lambda_k(M_j))", block: true)]]

#text("where ")#mi("{M_j}")#text(" is the ")#mi("{n-1 \\times n-1}")#text(" Hermitian matrix formed by deleting the ")#mi("{j^{th}}")#text(" row and column from ")#mi("{A}")#text(".")
]

#text("For instance, if we have")

#align(center)[#tao-fit-display[#mitex("A = \\begin{pmatrix} a & X^* \\\\ X & M \\end{pmatrix}")]]

#text("for some real number ")#mi("{a}")#text(", ")#mi("{n-1}")#text("-dimensional vector ")#mi("{X}")#text(", and ")#mi("{n-1 \\times n-1}")#text(" Hermitian matrix ")#mi("{M}")#text(", then we have ")#metadata(none) <tao-3f9ce8121531e852b8a3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|v_{i,1}\\right|^2 = \\frac{\\prod_{k=1}^{n-1} (\\lambda_i(A) - \\lambda_k(M))}{\\prod_{k=1; k \\neq i}^n (\\lambda_i(A) - \\lambda_k(A))}", block: true)]]

#text("assuming that the denominator is non-zero.")

#text("Once one is aware of the identity, it is not so difficult to prove it; we give two proofs, each about half a page long, one of which is based on a variant of ")#link("https://en.wikipedia.org/wiki/Cauchy%E2%80%93Binet_formula")[#text("the Cauchy-Binet formula")]#text(", and the other based on properties of the ")#link("https://en.wikipedia.org/wiki/Adjugate_matrix")[#text("adjugate matrix")]#text(". But perhaps it is surprising that such a formula exists at all; one does not normally expect to learn much information about eigenvectors purely from knowledge of eigenvalues. In the random matrix theory literature, for instance in ")#link("https://arxiv.org/abs/0711.1730")[#text("this paper of Erdos, Schlein, and Yau")]#text(", or ")#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/")[#text("this later paper of Van Vu and myself")]#text(", a related identity has been used, namely ")#metadata(none) <tao-e2813bdf6e981a34b32d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|v_{i,1}\\right|^2 = \\frac{1}{1 + \\left\\| (M-\\lambda_i(A))^{-1} X \\right\\|^2},", block: true)]]

#text("but it is not immediately obvious that one can derive the former identity from the latter. (I do so below the fold; we ended up not putting this proof in the note as it was longer than the two other proofs we found. I also give two other proofs below the fold, one from a more geometric perspective and one proceeding via Cramer’s rule.) It was certainly something of a surprise to me that there is no explicit appearance of the ")#mi("{a,X}")#text(" components of ")#mi("{A}")#text(" in the formula ")#link(<tao-3f9ce8121531e852b8a3>)[#text("(1)")]#text(" (though they do indirectly appear through their effect on the eigenvalues ")#mi("{\\lambda_k(A)}")#text("; for instance from taking traces one sees that ")#mi("{a = \\sum_{k=1}^n \\lambda_k(A) - \\sum_{k=1}^{n-1} \\lambda_k(M)}")#text(").")

#text("One can get some feeling of the identity ")#link(<tao-3f9ce8121531e852b8a3>)[#text("(1)")]#text(" by considering some special cases. Suppose for instance that ")#mi("{A}")#text(" is a diagonal matrix with all distinct entries. The upper left entry ")#mi("{a}")#text(" of ")#mi("{A}")#text(" is one of the eigenvalues of ")#mi("{A}")#text(". If it is equal to ")#mi("{\\lambda_i(A)}")#text(", then the eigenvalues of ")#mi("{M}")#text(" are the other ")#mi("{n-1}")#text(" eigenvalues of ")#mi("{A}")#text(", and now the left and right-hand sides of ")#link(<tao-3f9ce8121531e852b8a3>)[#text("(1)")]#text(" are equal to ")#mi("{1}")#text(". At the other extreme, if ")#mi("{a}")#text(" is equal to a different eigenvalue of ")#mi("{A}")#text(", then ")#mi("{\\lambda_i(A)}")#text(" now appears as an eigenvalue of ")#mi("{M}")#text(", and both sides of ")#link(<tao-3f9ce8121531e852b8a3>)[#text("(1)")]#text(" now vanish. More generally, if we order the eigenvalues ")#mi("{\\lambda_1(A) \\leq \\dots \\leq \\lambda_n(A)}")#text(" and ")#mi("{\\lambda_1(M) \\leq \\dots \\leq \\lambda_{n-1}(M)}")#text(", then the ")#link("https://en.wikipedia.org/wiki/Min-max_theorem#Cauchy_interlacing_theorem")[#text("Cauchy interlacing inequalities")]#text(" tell us that")

#align(center)[#tao-fit-display[#mitex("0 \\leq \\lambda_i(A) - \\lambda_k(M) \\leq \\lambda_i(A) - \\lambda_k(A)")]]

#text("for ")#mi("{1 \\leq k < i}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\lambda_i(A) - \\lambda_{k+1}(A) \\leq \\lambda_i(A) - \\lambda_k(M) < 0")]]

#text("for ")#mi("{i \\leq k \\leq n-1}")#text(", so that the right-hand side of ")#link(<tao-3f9ce8121531e852b8a3>)[#text("(1)")]#text(" lies between ")#mi("{0}")#text(" and ")#mi("{1}")#text(", which is of course consistent with ")#link(<tao-3f9ce8121531e852b8a3>)[#text("(1)")]#text(" as ")#mi("{v_i}")#text(" is a unit vector. Thus the identity relates the coefficient sizes of an eigenvector with the extent to which the Cauchy interlacing inequalities are sharp.")

#metadata(none) <tao-f047b3363b937a9b315d>

#heading(level: 1)[#strong[#text(" — 1. Relating the two identities — ")]]

#text("We now show how ")#link(<tao-3f9ce8121531e852b8a3>)[#text("(1)")]#text(" can be deduced from ")#link(<tao-e2813bdf6e981a34b32d>)[#text("(2)")]#text(". By a limiting argument, it suffices to prove ")#link(<tao-3f9ce8121531e852b8a3>)[#text("(1)")]#text(" in the case when ")#mi("{\\lambda_i(A)}")#text(" is not an eigenvalue of ")#mi("{M}")#text(". Without loss of generality we may take ")#mi("{i=n}")#text(". By subtracting the matrix ")#mi("{\\lambda_n(A) I_n}")#text(" from ")#mi("{A}")#text(" (and ")#mi("{\\lambda_n(A) I_{n-1}}")#text(" from ")#mi("{M_j}")#text(", thus shifting all the eigenvalues down by ")#mi("{\\lambda_i(A)}")#text(", we may also assume without loss of generality that ")#mi("{\\lambda_i(A)=0}")#text(". So now we wish to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|v_{n,1}\\right|^2 \\prod_{k=1}^{n-1} \\lambda_k(A) = \\prod_{k=1}^{n-1} \\lambda_k(M).", block: true)]]

#text("The right-hand side is just ")#mi("{\\mathrm{det}(M)}")#text(". If one differentiates the characteristic polynomial")

#align(center)[#tao-fit-display[#mitex("\\mathrm{det}(A - \\lambda I_n) = \\prod_{k=1}^n (\\lambda_k(A) - \\lambda) = - \\lambda \\prod_{k=1}^{n-1} (\\lambda_k(A) - \\lambda)")]]

#text("at ")#mi("{\\lambda=0}")#text(", one sees that")

#align(center)[#tao-fit-display[#mitex("\\prod_{k=1}^{n-1} \\lambda_k(A) = -\\frac{d}{d\\lambda}\\mathrm{det}(A - \\lambda I_n)|_{\\lambda=0}.")]]

#text("Finally, ")#link(<tao-e2813bdf6e981a34b32d>)[#text("(2)")]#text(" can be rewritten as")

#align(center)[#tao-fit-display[#tao-math("\\left|v_{n,1}\\right|^2 = \\frac{1}{1 + X^* M^{-2} X}", block: true)]]

#text("so our task is now to show that ")#metadata(none) <tao-f7010c177a28f06dc2c9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\frac{d}{d\\lambda}\\mathrm{det}(A - \\lambda I_n)|_{\\lambda=0} = - \\mathrm{det}(M) ( 1 + X^* M^{-2} X ).")]]

#text("By ")#link("https://en.wikipedia.org/wiki/Schur_complement")[#text("Schur complement")]#text(", we have ")#metadata(none) <tao-d7291123c459dd15c912>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\mathrm{det}(A - \\lambda I_n) = \\mathrm{det}(M - \\lambda I_{n-1}) ( a - \\lambda - X^* (M_1 - \\lambda I_{n-1})^{-1} X ).")]]

#text("Since ")#mi("{\\lambda=0}")#text(" is an eigenvalue of ")#mi("{A}")#text(", but not of ")#mi("{M_1}")#text(" (by hypothesis), the factor ")#mi("{a - \\lambda - X^* (M_1 - \\lambda I_{n-1})^{-1} X}")#text(" vanishes when ")#mi("{\\lambda=0}")#text(". If we then differentiate ")#link(<tao-d7291123c459dd15c912>)[#text("(4)")]#text(" in ")#mi("{\\lambda}")#text(" and set ")#mi("{\\lambda=0}")#text(" we obtain ")#link(<tao-f7010c177a28f06dc2c9>)[#text("(3)")]#text(" as desired.")

#heading(level: 1)[#strong[#text(" — 2. A geometric proof — ")]]

#text("Here is a more geometric way to think about the identity. One can view ")#mi("{\\lambda_i(A) - A}")#text(" as a linear operator on ")#mi("{{\\bf C}^n}")#text(" (mapping ")#mi("{w}")#text(" to ")#mi("{(\\lambda_i(A) w - Aw)}")#text(" for any vector ")#mi("{w}")#text("); it then also acts on all the ")#link("https://en.wikipedia.org/wiki/Exterior_algebra")[#text("exterior powers")]#text(" ")#mi("{\\bigwedge^k {\\bf C}^n}")#text(" by mapping ")#mi("{w_1 \\wedge \\dots \\wedge w_k}")#text(" to ")#mi("{(\\lambda_i(A) w_1 - Aw_1) \\wedge \\dots \\wedge (\\lambda_i(A) w_k - Aw_k)}")#text(" for all vectors ")#mi("{w_1,\\dots,w_k}")#text(". In particular, if one evaluates ")#mi("{A}")#text(" on the basis ")#mi("{v_1 \\wedge \\dots \\wedge v_{j-1} \\wedge v_{j+1} \\wedge \\dots \\wedge n_n}")#text(" of ")#mi("{\\bigwedge^{n-1} {\\bf C}^n}")#text(" induced by the orthogonal eigenbasis ")#mi("{v_1,\\dots,v_n}")#text(", we see that the action of ")#mi("{\\lambda_i(A) - A}")#text(" on ")#mi("{\\bigwedge^{n-1} {\\bf C}^n}")#text(" is rank one, with")

#align(center)[#tao-fit-display[#tao-math("\\langle (\\lambda_i(A) - A) \\omega, \\omega \\rangle = \\prod_{k=1; k \\neq i}^n (\\lambda_i(A) - \\lambda_k(A)) \\left|\\omega \\wedge v_i\\right|^2", block: true)]]

#text("for any ")#mi("{\\omega \\in \\bigwedge^{n-1} {\\bf C}^n}")#text(", where ")#mi("{\\langle,\\rangle}")#text(" is the inner product on ")#mi("{\\bigwedge^{n-1} {\\bf C}^n}")#text(" induced by the standard inner product on ")#mi("{{\\bf C}^n}")#text(". If we now apply this to the ")#mi("{n-1}")#text("-form ")#mi("{\\omega = e_1 \\wedge \\dots \\wedge e_{j-1} \\wedge e_{j+1} \\wedge \\dots \\wedge e_n}")#text(", we have ")#tao-math("{\\left|\\omega \\wedge v_i\\right| = \\left|v_{i,j}\\right|}", block: false)#text(", while ")#mi("{(\\lambda_i(A)-A) \\omega}")#text(" is equal to ")#mi("{\\mathrm{det}(\\lambda_i(A) I_{n-1} - M) \\omega}")#text(" plus some terms orthogonal to ")#mi("{\\omega}")#text(". Since ")#mi("{\\mathrm{det}(\\lambda_i(A) I_{n-1} - M ) = \\prod_{k=1}^{n-1} (\\lambda_i(A) - \\lambda_k(M))}")#text(", Theorem ")#link(<tao-69f5e8a085c0a76dac81>)[#text("1")]#text(" follows.")

#heading(level: 1)[#strong[#text(" — 3. A proof using Cramer’s rule — ")]]

#text("By a limiting argument we can assume that all the eigenvalues of ")#mi("{A}")#text(" are simple. From the spectral theorem we can compute the resolvent ")#mi("{(\\lambda I_n - A)^{-1}}")#text(" for ")#mi("{\\lambda \\neq \\lambda_1(A),\\dots,\\lambda_n(A)}")#text(" as")

#align(center)[#tao-fit-display[#mitex("(\\lambda I_n - A)^{-1} = \\sum_{k=1}^n \\frac{1}{\\lambda - \\lambda_k(A)} v_k v_k^*.")]]

#text("Extracting the ")#mi("{(j,j)}")#text(" component of both sides and using ")#link("https://en.wikipedia.org/wiki/Cramer%27s_rule")[#text("Cramer’s rule")]#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\mathrm{det}(\\lambda I_{n-1} - M_j)}{\\mathrm{det}(\\lambda I_n - A)} = \\sum_{k=1}^n \\frac{1}{\\lambda - \\lambda_k(A)} \\left|v_{k,j}\\right|^2", block: true)]]

#text("or in terms of eigenvalues")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\prod_{k=1}^{n-1} (\\lambda - \\lambda_k(M_j)) }{\\prod_{k=1}^{n} (\\lambda - \\lambda_k(A)) } = \\sum_{k=1}^n \\frac{1}{\\lambda - \\lambda_k(A)} \\left|v_{k,j}\\right|^2.", block: true)]]

#text("Both sides are rational functions with a simple pole at the eigenvalues ")#mi("{\\lambda_i(A)}")#text(". Extracting the residue at ")#mi("{\\lambda = \\lambda_i(A)}")#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\prod_{k=1}^{n-1} (\\lambda_i(A) - \\lambda_k(M_j)) }{\\prod_{k=1; k \\neq i}^{n} (\\lambda_i(A) - \\lambda_k(A)) } = \\left|v_{i,j}\\right|^2", block: true)]]

#text("and Theorem ")#link(<tao-69f5e8a085c0a76dac81>)[#text("1")]#text(" follows. (Note that this approach also gives a formula for ")#mi("{v_{i,j} \\overline{v_{i,j^{\\prime}}}}")#text(" for ")#mi("{j,j^{\\prime}=1,\\dots,n}")#text(", although the formula becomes messier when ")#mi("{j \\neq j^{\\prime}}")#text(" because the relevant minor of ")#mi("{\\lambda I_n}")#text(" is no longer a scalar multiple of the identity ")#mi("{I_{n-1}}")#text(".)")

#heading(level: 1)[#text("Comments (139)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e6ccdf461e936a5926f2676336d23a712680c75f27ea86ee5c8c6916b6e19e4-fd1376eb9f6e4d6c10c8dfa86cc15927989495054a3b57526f7a4f84bc34f6e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arturo Portnoy")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-529406")[#strong[#text("Arturo Portnoy")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2019")])]

#text("Looks like this identity could be useful for inverse spectral problems, where information about the eigenvalues and eigenfunctions is used to determine some parameter/coefficients of the operator/matrix.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-529408")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2019")])]

#text("Yes, in fact we have recently learned that the identity is indeed used for inverse eigenvalue problems for Jacobi matrices, see Section 4.5 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2008966")[#text("this 2002 paper of Chu and Golub")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2443a64cec5302b9d17b3043b05c6d8c0353095d9909cd2861cf4f63c671aa6-9dc86472e82a17112626b808197f15144aa16b3cc09ace474a7c5863812b6909.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Godsil")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-529411")[#strong[#text("Chris Godsil")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2019")])]

#text("I’ve listed more appearances at ")#link("https://mathoverflow.net/questions/346264/consequences-of-eigenvector-eigenvalue-formula-found-by-studying-neutrinos/346421#346421")[#text("https://mathoverflow.net/questions/346264/consequences-of-eigenvector-eigenvalue-formula-found-by-studying-neutrinos/346421#346421")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b353bf41e4733e19b33b74a715ac5f28542ad3a97b5430e5d5458df835176eda-efb99eca128cfa46593ee29adf1943352387d70685fa6a76fd7420373c823a3e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill Province")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-529413")[#strong[#text("Bill Province")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2019")])]

#text("How close does this come to resolving the Graph Reconstruction Conjecture (")#link("https://en.wikipedia.org/wiki/Reconstruction_conjecture")[#text("https://en.wikipedia.org/wiki/Reconstruction_conjecture")]#text(")? I notice that we get the square of the eigenvector element values rather than the values themselves, so I don’t think that in and of itself, this resolves the reconstruction conjecture, but it gives some pretty convincing additional evidence!")

#text("In order for the reconstruction conjecture to be false in the face of this, there would need to be two graphs G1, G2 such that they are non-isomorphic, but share the same spectrum, and where the eigenvectors differ only in the choice of sign for the elements (and of course, where it’s not simply that we have one vector that is the negative of the other).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-529419")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2019")])]

#text("Due to the existence of cospectral mates, I am not sure that it really would resolve the conjecture.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b353bf41e4733e19b33b74a715ac5f28542ad3a97b5430e5d5458df835176eda-efb99eca128cfa46593ee29adf1943352387d70685fa6a76fd7420373c823a3e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill Province")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-529497")[#strong[#text("Bill Province")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2019")])]

#text("Yet the results here are much stronger than merely being co-spectral. Being able to (nearly) completely recover the eigenvectors is something I had not seen before. Indeed, if the eigenvectors are recoverable — and we can properly associate the correct eigenvalue with each eigenvector — then we have recovered the entire matrix. I agree that we have not reached that point yet, and the existence of co-spectral non-isomorphic graphs must at least make us doubt, but this seems to be a really big step in that direction.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9375ba1193cd75e59ecabcb3d6b993490dc3f6ff062d06014303f5d9b0ba2381-bac681b88146b9932ac7ee82f2d5d5b531b951698ea7ee604e0bdcfe9c51bbe5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J. M.")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-529415")[#strong[#text("J. M.")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2019")])]

#text("A look at ")#link("https://doi.org/10.1098/rsta.1950.0007")[#text(" L. F. Richardson’s paper")]#text(" (which I found through J. H. Wilkinson’s classical treatise) apparently uses a variant of the formula to iteratively improve an eigenpair.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-529501")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2019")])]

#text("Hmm, this seems to be a little bit different. What seems to be happening here is that the author is iteratively applying linear operations of the form ")#mi("\\frac{1}{\\lambda_i(A) -\\lambda_j(A)} (A - \\lambda_j(A) I)")#text(" for ")#mi("j \\neq i")#text(" to isolate the ")#mi("v_i")#text(" component of a given vector and damp out the other components. This iteration will lead to spectral multipliers that have a form resembling that used in this identity (namely a ratio of two products of characteristic function type objects) but I’m not sure there is a deeper connection beyond this (for instance, there is no role in that paper played by minors).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/254b8805a17f57a3956b116edf4afd07bac667a7ecc64cf01ac7ebc92bce0a45-d856aad2b97eae692c02785e2208e4f8be4b185a3409cdffee2a21bb3c526520.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emanuele Rodolà")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-529505")[#strong[#text("Emanuele Rodolà")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2019")])]

#text("From a computational perspective, it might be actually useful in all cases where one only needs specific eigenvector components; in these cases you don’t need to compute the eigenvalues of all sub-matrices M_j, but only for a selection of sub-matrices. I can think of a few practical settings where it could come useful, e.g. in discrete geometry processing or graph analysis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45af9b789a76457d887560f808430189f8fea6d7e681bf2166dc451a9fa08f9f-4e2146df8e57cd647b60e6b0becc370c91e4f8dac20ddc447f109d6f008c9eca.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Comments on an arXiv preprint authored by Terence Tao – Feng Qi's Academic Homepage & Blogs")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-529698")[#strong[#text("Comments on an arXiv preprint authored by Terence Tao – Feng Qi's Academic Homepage & Blogs")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2019")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/#comment-528704")[#text("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/#comment-528704")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-529699")[#strong[#text("Eigenvectors and Eigenvalues | Delightful & Distinctive COLRS")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2019")]

#text("[…] Resource: Terry Tao blog, Nov […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a24729fe93d9bb501744ba30f36a633b0bc0a3059bdadd8306728745d035e617-e78c897b5216e55a49065a9caf586479c0911391d9b9933e3a6728593f941ec7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Margaret Stawiska-Friedland")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-529809")[#strong[#text("Margaret Stawiska-Friedland")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2019")])]

#text("Theorem 1 can be generalized to not necessarily Hermitian matrices as follows:")#linebreak()#text(" Let ")#mi("n \\geq 1")#text(" and let ")#mi("A \\in M_{n \\times n}(\\mathbb{C})")#text(". Let ")#mi("\\lambda \\in \\mathbb{C}")#text(" be an eigenvalue of ")#mi("A")#text(" of algebraic multiplicity ")#mi("1")#text(". It follows that the eigenspace corresponding to ")#mi("\\lambda")#text(" is ")#mi("1")#text("-dimensional.")#linebreak()#text(" By nullity-rank theorem, ")#mi("\\text{rank}(A-\\lambda I)=n-1")#text(", and so ")#mi("\\text{rank } \\text{adj}(A-\\lambda I)=1")#text(". This implies that ")#mi("\\text{adj}(A-\\lambda I)=\\mathbf{v} \\mathbf{u}^T")#text(" with ")#mi("\\mathbf{v}, \\mathbf{u} \\in \\mathbb{C}^n \\setminus \\{0\\}")#text(". Further, since ")#mi("(A-\\lambda I)(\\text{adj}(A-\\lambda I))=\\det(A-\\lambda I)I")#text(" and ")#mi("\\lambda")#text(" is an eigenvalue of ")#mi("A")#text(", we have ")#mi("0=(A-\\lambda I)(\\text{adj}(A-\\lambda I))=((A-\\lambda I)\\mathbf{v})\\mathbf{u}^T")#text(". Hence ")#mi("(A-\\lambda I)\\mathbf{v}=0")#text(". Similarly we show that ")#mi("A^T\\mathbf{u}=\\lambda \\mathbf{u}")#text(".")#linebreak()#text(" There exists a unique ")#mi("\\mathbf{w} \\in \\mathbb{C}^n\\setminus \\{0\\}")#text(" such that ")#mi("A^T\\mathbf{w}=\\lambda \\mathbf{w}")#text(", ")#mi("\\mathbf{w}^T\\mathbf{v}=1")#text(". We have ")#mi("c\\mathbf{w}^T=\\mathbf{u}^T")#linebreak()#text(" with ")#mi("0 \\ne c = c\\mathbf{w}^T\\mathbf{v}=\\mathbf{u}^T\\mathbf{v}= \\text{tr }\\text{adj}(A-\\lambda I)")#text(". Hence ")#mi("\\text{adj}(A-\\lambda I)=\\mathbf{v}\\mathbf{u}^T=\\text{tr }\\text{adj}(A-\\lambda I)\\mathbf{v}\\mathbf{w}^T")#text(". By Jacobi’s formula for derivative of the determinant, ")#mi("\\text{tr }\\text{adj}(A-\\lambda I)=(-1)^nP^{\\prime}(\\lambda)")#text(", where ")#mi("P(t)=\\det (A-tI)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d03349f6af6a8df5c00cfa1d7aa9b7aafcaacede8bd33fffc1353e9ac9cdcbad-a2c4ccb228d8697dea13a413898683b4cfb7fcc8d7d8fbbce669aa5052d4b6df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiu Wu")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-529817")[#strong[#text("Xiu Wu")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2019")])]

#text("Hello Mr.Tao, I want to ask that how to determine the +/- sign of the calculated elements of the eigenvectors.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-529850")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2019")])]

#text("Read the comments above.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d03349f6af6a8df5c00cfa1d7aa9b7aafcaacede8bd33fffc1353e9ac9cdcbad-a2c4ccb228d8697dea13a413898683b4cfb7fcc8d7d8fbbce669aa5052d4b6df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiu Wu")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-530523")[#strong[#text("Xiu Wu")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2019")])]

#text("Thanks, I found it in one of the comments, Mr.Tao gives a method of determining the signs.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9dc8e5d8dcbe693c19b4f16435654ebc0acfa5078c0bc47d59924abfaf53029e-95ed21b1a149fb35dea949f51a39868cf9dc8f1040043b0a3c8c07a27b98026d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ed")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-529937")[#strong[#text("Ed")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2019")])]

#text("Hi, I am no math major, but I found this paper very interesting to read! I am reading the consistency check section of the paper, and I am not sure how to show “RHS of eq 8 is the n-1 symmetric function of the eigenvalues,S_{n-1}”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-530621")[#strong[#text("Eigenvectors from eigenvalues - Nevin Manimala's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2019")]

#text("[…] by /u/BeverlyHillsBastet [link] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ac586ff23990a20899039b7413642dee776c1d994544e3f194c792145e7aa0d-818053568e16ea9c09920ac68410ef590af7e5fb1efb970dd87b8ea6ab9e9ba8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-530762")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2019")])]

#text("Some of the popular science articles claim that it’s easier to use a matrix’s eigenvalues than its eigenvectors, at least in context of the neutrino-related research in which this identity was discovered. However, at first glance, computing all eigenvectors using this identity seems to have greater computational complexity than existing methods (which, roughly, are O(n^3)).")

#text("Of course, this work will be relevant in particular contexts where the minor matrices’ eigenvalues are already known, or where other constraints are imposed that can simplify computation. But do you think that with some additional research, the formula can be used to improve on existing eigenvector estimation methods more generally?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-530821")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2019")])]

#text("I agree that this identity is unlikely to be a superior method for computing eigenvectors for general matrices, but for special matrices where the characteristic polynomial of the matrix and its minors are relatively easy to compute, the identity appears to be useful. For instance, we have found a number of references in the literature where this identity was applied to tridiagonal matrices to help control the convergence rate of various numerical linear algebra algorithms such as the Rayleigh-Ritz method for computing eigenvectors. So here the identity is not directly used to compute eigenvectors, but it can be used to analyze a different algorithm for (approximately) computing these eigenvectors.")

#text("Another thing the identity highlights is that the (square of the) magnitude of an eigenvector component is proportional to the distance between the eigenvalue and the spectrum of a minor. So information about how the spectrum of minors interlace with the spectrum of the full matrix will tell us something about the localization or delocalization properties of eigenvectors, and conversely. This ought to be a useful tool, or at least a useful heuristic, in random matrix theory in which one is often interested in at least one of these two pieces of information, though I do not yet have a concrete use case for this (mostly because our current tools usually do not let us easily understand the coupling between the spectrum of a matrix and the spectrum of a minor).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/731f61019f56f8297f6a93d543c2989bc1b4b578c4d29bb417655f3ccae7843e-585c477ad3bd9abc3ed5879477af4df00234d54256dfc9fdf9f25cc0cf03f697.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim Campion")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-530998")[#strong[#text("Tim Campion")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2019")])]

#text("I’m confused by the statement of the identity — are we assuming that the eigenvalues $\\lambda_i(A)$ are distinct?")

#text("If not, then the identity is hard for me to believe: for instance if $\\lambda_1(A) = \\lambda_2(A)$, then the identity seems to entail that $|v_{1,j}| = |v_{2,j}|$ for any choice of orthogonal unit vectors $v_1,v_2$ in the eigenspace corresponding to the eigenvalue $\\lambda_1(A) = \\lambda_2(A)$. But if, say, this eigenspace is spanned by the first two coordinate vectors $e_1,e_2$, then we could take $v_1 = e_1, v_2 = e_2$ and obtain a contradiction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/731f61019f56f8297f6a93d543c2989bc1b4b578c4d29bb417655f3ccae7843e-585c477ad3bd9abc3ed5879477af4df00234d54256dfc9fdf9f25cc0cf03f697.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim Campion")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-531000")[#strong[#text("Tim Campion")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2019")])]

#text("Oh I see — if the eigenvalues are not distinct, then the product on the left hand side is zero, so my reasoning is incorrect.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eigenvectors from Eigenvalues: a survey of a basic identity in linear algebra | What's new")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-531066")[#strong[#text("Eigenvectors from Eigenvalues: a survey of a basic identity in linear algebra | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2019")])]

#text("[…] Parke, Xining Zhang, and I have just uploaded to the arXiv a completely rewritten version of our previous paper, now titled “Eigenvectors from Eigenvalues: a survey of a basic identity in linear […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b7c9c8c8343b63cb0f01f5dad5aa53c951d80f77f2d405288e5a58f6f3dd238d-82ef6ff9b1ef8c2686961140a216e89fc3315a0284cb9c4f6be17c565e1f75e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gautam")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-531254")[#strong[#text("Gautam")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2019")])]

#text("In Remark 7 of the updated paper, it appears that Aram Harrow’s name is spelled wrong.")

#emph[#text("[This will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b2e6ff760706a26ef5078995af43f0ac52a14c399cd32038f7a3cad63402bf-8ee127cedb51b551937ab4f5eaafbb32a9ea484ee56b4fe3906e87a2af47a96b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam Denchfield")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-531553")[#strong[#text("Adam Denchfield")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2019")])]

#text("I think I found another instance of proof/usage of a special case. In this paper (linked below) by Gaveau and Schulman, “Limited quantum decay”, Equations 2.1-2.6. If this is indeed an example of a special case, then I think this identity is used fairly commonly in physics, because this usage seems familiar.")

#link("https://iopscience.iop.org/article/10.1088/0305-4470/28/24/029/pdf")[#text("https://iopscience.iop.org/article/10.1088/0305-4470/28/24/029/pdf")]

#emph[#text("[Yes, this appears to be an independent discovery of Lemma 14 in the survey. We’ll add the reference to the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48140e93d7f327dc29f1c457364f661a89651480562cdba1259f1b8d754c6f66-1a7b48ae55155f3274e1eabbc191eafc22dd8d3f7a77d3f8ff3bf4da1364b60b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pawan")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-532394")[#strong[#text("Pawan")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2019")])]

#mi("\\displaystyle  (\\lambda I_n - A)^{-1} = \\sum_{k=1}^n \\frac{1}{\\lambda - \\lambda_k(A)} v_k v_k^*")

#text("How one gets this equation ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-532396")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2019")])]

#link("https://en.wikipedia.org/wiki/Eigendecomposition_of_a_matrix#Functional_calculus")[#text("https://en.wikipedia.org/wiki/Eigendecomposition_of_a_matrix#Functional_calculus")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48140e93d7f327dc29f1c457364f661a89651480562cdba1259f1b8d754c6f66-1a7b48ae55155f3274e1eabbc191eafc22dd8d3f7a77d3f8ff3bf4da1364b60b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pawan")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-553241")[#strong[#text("Pawan")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2020")])]

#text("Thank you.")

#tao-math("\\displaystyle  \\frac{\\mathrm{det}(\\lambda I_{n-1} - M_j)}{\\mathrm{det}(\\lambda I_n - A)} = \\sum_{k=1}^n \\frac{1}{\\lambda - \\lambda_k(A)} \\left|v_{k,j}\\right|^2", block: false)

#text("This is not clear. In particular the use of Cramer’s rule. To use this rule there should be AX=B. What is A, X and B here ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-553286")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2020")])]

#text("Here we are using Cramer’s rule in the form ")#mi("A^{-1} = \\frac{1}{\\mathrm{det} A} \\mathrm{adj} A")#text(" (see ")#link("https://en.wikipedia.org/wiki/Cramer%27s_rule#Finding_inverse_matrix")[#text("https://en.wikipedia.org/wiki/Cramer%27s_rule#Finding_inverse_matrix")]#text(" ). Applying this with ")#mi("A")#text(" replaced by ")#mi("\\lambda I_n - A")#text(" and extracting the ")#mi("jj")#text(" coefficient we see that ")#mi("\\frac{\\mathrm{det}(\\lambda I_{n-1} - M_j)}{\\mathrm{det}(\\lambda I_n - A)} = [(\\lambda I_n - A)^{-1}]_{jj}")#text(". On the other hand, from the eigendecomposition of the matrix ")#mi("A")#text(" one has ")#tao-math("[(\\lambda I_n - A)^{-1}]_{jj} = \\sum_{k=1}^n \\frac{1}{\\lambda - \\lambda_k(A)} \\left|v_{k,j}\\right|^2", block: false)#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/328a00eff937302d1c0ef1ea315bae605cb871ccae2afb912b438ae3a62991c7-9873cba4df7c65ac1dd97d808553dc407351e9091b84c6a0784fabd4712da237.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henning")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-535421")[#strong[#text("Henning")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2020")])]

#text("I wonder about the application of the EEI to not necessarily Hermitian diagonalizable matrices when there are two or more matrices with the same eigenvalues but different eigenvectors. Example: The matrices A_1 = CM and A_2 = C^1/2 M C^1/2 have the same eigenvalues if C is diagonal positive definite and M real symmetric. Application of the EEI to this spectrum results in the eigenvectors of the Hermitian case A_2. But how can one obtain the correct eigenvectors, using only the EEI and some minimal other assumptions, for A_1? (This problem is somewhat similar to a standard problem in vibrational analysis described in the book G.M.L. Gladwell: “Inverse Problems In Vibration”, where the EEI for Jacobi matrices appears in Eqs. 4.3.17 and 4.5.6.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ralph Burger")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-535426")[#strong[#text("Ralph Burger")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2020")])]

#text("Doesn’t all as well depend on the minors and their eigenvalues?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/328a00eff937302d1c0ef1ea315bae605cb871ccae2afb912b438ae3a62991c7-9873cba4df7c65ac1dd97d808553dc407351e9091b84c6a0784fabd4712da237.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-535445")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2020")])]

#text("Yes, I forgot to mention that all the minors have identical spectra between the two cases, too.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bffff894c017d7fbeb153e0798677d7fd709e364f2e1629b6f50d09614ed706c-562f804040b2623fe3e9d83485596e6c02411f271883f36d455767e6df684ecc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sasha Sodin")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-547842")[#strong[#text("Sasha Sodin")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2020")])]

#text("Dear Terry,")

#text("I would like to mention another couple of references:")#linebreak()#text(" – Kerov’s paper “interlacing measures” and his book “Asymptotic Representation Theory of the Symmetric Group and its Applications in Analysis”, which describe a result equivalent to this identity (and its relation to the Markov moment problem)")#linebreak()#text(" – Krein’s work on the spectral shift function (and earlier work by I.M.Lifshitz)")#linebreak()#text(" – the famous paper of Aronszajn and Donoghue")#linebreak()#text(" The first one describes several seemingly unrelated facts which can be stated in a similar way (e.g. the hook formula in the representation theory of S_N). The other two discuss operator-theoretic versions.")

#text("With best regards,")#linebreak()#text(" Sasha")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c685fe53a0017bfbb1a2dcd54aa856fbefdd677d38a82c923c50a97281ad9903-01ef04b5ef1b58a71fbe0cc8f3b459639a6650f6e3bd441f92d2281551b7dd30.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Knyazev")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-551084")[#strong[#text("Andrew Knyazev")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("Dear Terry,")

#text("The main result here has a simple and intuitively evident geometric interpretation:")

#text("Crossing a 3D ellipsoid centered at the origin and aligned with the coordinate axes by a 2D plane crossing the origin results in a 2D ellipse. The position of the 2D plane relative to the 3D ellipsoid is then uniquely (up to symmetries) determined by 5 numbers: the 2 lengths of the semi-axes of the 2D ellipse and the 3 lengths of the semi-axes of the 3D ellipsoid. Perhaps you may want to add a plot like this to the paper, ")#link("https://commons.wikimedia.org/wiki/File:Indexellipsoid.png")[#text("https://commons.wikimedia.org/wiki/File:Indexellipsoid.png")]

#text("Having the semi-axes of the 3D ellipsoid aligned with the coordinate axes, one can derive a formula for the (absolute values of) coordinates of the unit vector normal to the 2D plane, which is the main result of your paper, implying everything else, as far as I can see.")

#text("These formulas can evidently be found in old textbooks on geometry. I have seen one in a 100 y.o. book scanned by Google books, but did not save the reference.")

#text("My papers go one step further and derive (from the coordinates of the normal vector) formulas for the (absolute values of) coordinates of the semi-axes of the 2D ellipse relative to the coordinates of the semi-axes of the 3D ellipsoid. The semi-axes of the 2D ellipse are actually Ritz vectors in the Rayleigh-Ritz method where the trial subspace is a hyper-plane (i.e. co-dimension 1)")

#text("Best, Andrew")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-551088")[#strong[#text("Eigenvectors from Eigenvalues – Rumbo Loxodromico")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")]

#text("[…] Terry Tao gives a nice “geometric” proof on his blog that might be interesting to readers here (see “2 a geometric proof”): ")#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/")[#text("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d389c4220bcfc45564d71ae3c61d3b43732681abe52a972e7ae47e5c7596c69a-b525c5e89bf5de14c648d8ff2bf61b174d0af1fdba4f668b84e4fd44974e62cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hippolite Kaarineo Dery")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-564747")[#strong[#text("Hippolite Kaarineo Dery")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2020")])]

#text("So confusing")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b835ec109e047b0cb0b7533e12ac45625c2431f0447571e834295d24cffed84-277b7d1f45017a096800c740d1e62964cb68a5c042f48485224c2e725cce96c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Symbols")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-573915")[#strong[#text("Symbols")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2020")])]

#text("Thank you Prof. Tao for this wonderful blog post. Was looking for this on an assignment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7cde7eae538a9dfb0392fa36b85f0c2b76c86df8fa57fa490ea79cef4987f6ac-9bd18a0a879a84120e0d0bb91e2b521e3f98a661cb6a58dc5d3c887688b78028.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zeno")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-574207")[#strong[#text("Zeno")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2020")])]

#text("Also our paper published recently (after a long gestation):")#linebreak()#text(" “Eigenlogic in the spirit of George Boole”, ")#link("https://doi.org/10.1007/s11787-020-00252-3")[#text("https://doi.org/10.1007/s11787-020-00252-3")]#linebreak()#text(" also available on the arXiv:1512.06632")

#text("We show that the multilinear method introcduced by Boole for the invention of mathematical logic was actually linear algebra… truth values become eigenvalues…")

#text("For all these matters one should give a deeper look at the English school of the XiXth century, they invented linear algebra and logic (their link is quite close)")#linebreak()#text(" see Boole, Hamilton, Cayley, Sylvester, Jacobi, Clifford….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-579627")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2020")])]

#text("the last proof is really cool. Just a question here. Do you ever feel the need to think it is important to think of things from scratch. I feel using existing identities is a bit impure way of deriving something. Is it important to build up using new observations in mathematics or to connect different patterns that we’ve already seen ( like these identities )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad33c684879995bea816d6a620e2674712674c94a35cc3413ac90fc7339bf11a-c7a7561b6e59cd728e764d2d99563987cb6c3226e7a5363d2e4fb46d9b59bbe5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lynmar M. Didal")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-614053")[#strong[#text("Lynmar M. Didal")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2020")])]

#text("This is in the same situation as the “new way to solve quadratic equations.” (re: semantic search engine)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d7379243a9cd422b5e04e241fb436215ef53f519714e5ad88bc45c4e7068f169-0d8f60db14747ddf468ff8432efcd0d4c069c78a3046c9a402fd95533392fa7f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andre j- Grebenc")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-639542")[#strong[#text("Andre j- Grebenc")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2022")])]

#text("I am an engineer and I kindly ask for some examples( cases)")

#emph[#text("[See Example 2 in the paper. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/881ee18ee0a6071e50e4382e7c87c18852ad0d5988863df023f2278c54d9f492-6d934a79db1d772fbeefe624cb8731b0e29c46d16ef116a6ff4ac27ed0bd2386.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hariprasad Manjunath")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-687158")[#strong[#text("Hariprasad Manjunath")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2025")])]

#text("Dear Prof. Tao,")

#text("I have a conjecture that repeatedly taking eigenvector matrix of eigenvector matrices will eventually become unitary matrix. for dimension less than 7. Is it possible to prove that using the non Hermitian analog of this identity (as in the last proof) in 2 by 2 case.")

#text("Regards,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/881ee18ee0a6071e50e4382e7c87c18852ad0d5988863df023f2278c54d9f492-6d934a79db1d772fbeefe624cb8731b0e29c46d16ef116a6ff4ac27ed0bd2386.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hariprasad Manjunath")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-2/#comment-687159")[#strong[#text("Hariprasad Manjunath")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2025")])]

#text("Here is the link for the conjecture ")#link("https://arxiv.org/abs/1907.12039")[#text("https://arxiv.org/abs/1907.12039")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/686de7c56e01b9812b7dab89e546012de642bacbe076abbb729dc42f7ff8089a-e85a696188abca866bc724d3304752748cfcf62e5c8c2de35fe8a6be3c205525.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of omarleoblog")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519573")[#strong[#text("omarleoblog")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2019")])]

#text("What kind of mathematics is this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d16d823c341775c0e1c05efd72529aa86e4f60e232d0d7debc4ccc6d1a6b215c-410902a25935f38e12fc41c5e4ae368624ecdd9ef96aa6a53dcbacbc2230ac96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519575")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2019")])]

#text("Linear Algebra")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed9945458be687811f4558b42acdd57084d85d5e5bc833803c3f31216f130574-1b396572c4c94bb5444694ebe5430ecdbcfc43bb7081940b8f2e9ec101d7f17b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of That Kitty")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-520930")[#strong[#text("That Kitty")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2019")])]

#text("At the research level, these results are sometimes called things like “matrix analysis,” especially when dealing with finite-dimensional normed spaces. Maybe because mathematicians often consider linear algebra “solved” or because so much (especially applied) work can be called “linear algebra” that finer descriptors are needed?")

#text("[Insert any variation on the old joke about how all of maths is an attempt to reduce problems to (some generalization) of linear algebra]")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/674f7d0fc766175251e5825957e500d33582c43ba3557ed637c4750c9cfd4f76-6e0351f6b7043a89db122d83b59b5c2266f36212b0c3ed52c320fe513235c7c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cimmerianhydra")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519611")[#strong[#text("cimmerianhydra")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2019")])]

#text("I never visited your blog before, mr. Tao, and the first article I read is about such an interesting equality!")

#text("The last proof is especially elegant. About the second one: would you say that geometric intuition is always a valuable perspective from which to understand one’s results? Are there situations where geometry “gets in the way” of seeing things clearly?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/674f7d0fc766175251e5825957e500d33582c43ba3557ed637c4750c9cfd4f76-6e0351f6b7043a89db122d83b59b5c2266f36212b0c3ed52c320fe513235c7c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cimmerianhydra")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519612")[#strong[#text("cimmerianhydra")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2019")])]

#text("For some reason this was posted as a reply to a comment. I’m sorry, I have no idea how this happened.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db070355fdb640ad2c7e83f2901c04633b4e24c7b6e1d2ee2589133350895006-f9da2e26c1544e14f1a4e3e3f414c5d1d407558530a6ed84bd66e870340def56.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Krause")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519576")[#strong[#text("Andrew Krause")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2019")])]

#text("Are there any analogues to the identities for any interesting infinite-dimensional cases? I’m wondering specifically if one can relate the eigenfunctions of a differential operator to spectral properties of that operator. Of course Kac’s famous paper on the “shape of the drum” and the solutions in that case suggest that there is no simple relationship, but perhaps there is an analogue of the spectrum of these sub-matrices which helps clarify this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519586")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2019")])]

#text("The first part of the Cramer rule proof, based on the spectral theorem, will hold in some infinite-dimensional settings: for instance, if ")#mi("\\Delta")#text(" is the (positive semi-definite) Laplacian on a smooth compact Riemannian manifold ")#mi("M")#text(" and ")#mi("v_i(x)")#text(" is an ")#mi("L^2(M)")#text("-normalised eigenfunction corresponding to the eigenvalue ")#mi("\\lambda(M)")#text(", then it is still true that ")#tao-math("\\left|v_i(x)\\right|^2", block: false)#text(" is the residue at ")#mi("\\lambda = \\lambda_i(\\Delta)")#text(" of the integral kernel of the resolvent ")#mi("(\\lambda - \\Delta)^{-1}")#text(" evaluated at ")#mi("(x,x)")#text(". However it is not obvious how to evaluate this resolvent further; possibly there is still some remnant of Cramer’s rule involving Fredholm determinants, but I’m not sure how useful it would be. Certainly computing residues or other asymptotic expansions of resolvents is quite a common pastime in the spectral theory or microlocal analysis literature though.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f49c1d159321ecec940e4f2ea732c94a18d3a10ba885ed450008e00040f49cba-bf842d107863661e4060ef50814558631b9e334c5d54134d53c900578ff77e80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ken Krechmer")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528818")[#strong[#text("Ken Krechmer")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2019")])]

#text("The solution (eigenvectors to eigenvalues) appears to also be a general solution of the Born Rule in quantum mechanics. A narrower solution to the Born Rule was presented in ")#link("https://www.sciencedirect.com/science/article/pii/S0263224117306887")[#text("https://www.sciencedirect.com/science/article/pii/S0263224117306887")]#text(" in 2018")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519585")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2019")])]

#text("It seems that the LHS product is the discriminant of the characteristic polynomial of the matrix ")#mi("A")#text(" (i.e. the resultant of the characteristic polynomial and its derivative), while the RHS product is the resultant of the chracteristic polynomials of the matrices ")#mi("A, M_j")#text(".")#linebreak()#text(" Since these resultants representing the two products can be computed via determinants of their corresponding Sylvester matrices, it seems closely related to the proof using Cramer’s rule.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e24bd5fddb6da4761d307787cce09f5f8116a25b1b17ef89bf9be37be08994b3-155c9ba54d1dbeedc9b92270942a7b718ec7611d83c0974d39cdcd3e9072d870.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Watts")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519595")[#strong[#text("Watts")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2019")])]

#text("If ")#mi("A")#text(" is Toeplitz, say the Laplacian ")#mi("T_n(2-2\\cos(\\theta))")#text(", then the right hand side is constant for any ")#mi("j")#text(". Then the formula can only recover the first eigenvector. Right?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e24bd5fddb6da4761d307787cce09f5f8116a25b1b17ef89bf9be37be08994b3-155c9ba54d1dbeedc9b92270942a7b718ec7611d83c0974d39cdcd3e9072d870.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Watts")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519597")[#strong[#text("Watts")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2019")])]

#text("This is incorrect, it is not constant for any ")#mi("j")#text(". Ignore this comment.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519596")[#strong[#text("Part III: A Physicist Completes a Linear Algebra Result - Nevin Manimala's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2019")]

#text("[…] a bit. We put the paper online last weekend and it finally appeared on the arXiv, along with a new Terry blog post! I’m so excited you guys don’t even […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519601")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2019")])]

#text("Cool thing!")

#text("There is a chemical example which is immediately intuitive. A closed ring of n atoms has an adjacency matrix that is a constant on a 1-band-diagonal (at the n,n+1 and n+1,n elements) and at element (n,1) and (1,n). The eigenvalues of this matrix (Hückel matrix) correspond to the energy levels of the molecule (at some crude approximation). The adjacency matrix of the open chain you get when you remove one atom from the ring is the above described “1-band-diagonal” with dimension (n-1),(n-1). Now the energies (eigenvalues) of the open chain system with n-1 atoms are exactly matching the eigenvalues of the n+1 ring (they both are the real part of the roots of unity in the ring case of order n and in the open chain with n atoms case of order n+1). So removing one atom from the ring to get a chain is one example for making M out of A. In this example the eigenvalues of M without the first, and those of A are identical. From chemical intuition it is immediately clear that both v_1 eigenvectors are (1,…,1). An interesting question would be how or if to get information on the phases of the coefficients. In case of symmetric systems they would correspond to the characters of irreducible representations.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519602")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2019")])]

#text("Oh sorry there is a mistake it is even a bit more interesting: The “ground state” eigenvectors ")#mi("v_1")#text(" of both systems (A and M) are different, the ring has obviously ")#mi("v_1(M) = (1,1,1,..,1,..,1,1,1)^T")#text(" while the open chain one is ")#mi("v_1(A) = (1,2,2,..,..,2,2,1)^T")#text(" (up to normalization).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-529409")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2019")])]

#text("In fact we have recently learned that this identity was indeed introduced to study chemical graphs ")#link("https://link.springer.com/article/10.1007/BF02880817")[#text("by Mukherjee and Datta in 1989")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-529412")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2019")])]

#text("Thank you very much! Its amazing to see how this work grows also due to the contribution and knowledge of others. I find it very positive that much of the old literature in this way can be reviewed. Very good results still can gain in weight and meaning if they are set properly in the context of what has already been done and what is known. I imagine there is a lot of stuff out there in the ever growing body of scientific literature that has bee discovered several times or equally that has been forgotten or is invisible for those who search for solutions.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a147090f9af3c1b2c7dfde9c119986d572ab0aca1c0597bd9e392500cbf50056-9bf5ee52900edef5f06b595ac20ad5b51cceeba44940ca30fdbafffac5929f0a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519609")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2019")])]

#text("In the last formula, this should be ")#tao-math("\\left|v_{i, j}\\right|^2", block: false)#text(" on the RHS.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519617")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2019")])]

#text("what are these used for?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519619")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2019")])]

#text("These are used for developing a new way to write neutrino oscillation probabilities in matter, both exactly and with simpler approximate expressions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519634")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2019")])]

#text("There seems to be something strange about the left hand side of equation (1) in the arXiv paper. The product ")#mi("B v_n")#text(" is not well defined if ")#mi("B")#text(" is an ")#mi("n\\times(n-1)")#text(" matrix and ")#mi("v_n\\in R^n")#text(". It’s certainly not a squared matrix, so how is that determinant calculated?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519658")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2019")])]

#text("It’s not multiplication, it’s concatenation: stick the column vector after the last column of B to “complete the square”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/560d99305b140f8b63e7bfab8304a7403c5bcf43b1ced333ec325cb5523fa777-379795694bc933d262758bd3954d891099658635730935ff9067f28250394ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karl Svozil")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519798")[#strong[#text("Karl Svozil")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2019")])]

#text("In which way is this result different from the one mentioned, for instance, in Par. 79, p. 157 of Halmos’ “Finite-dimensional vector spaces”: Let ")#mi("A")#text(" be a self-adjoint operator in finite dimensional Hilbert space, and a polynomial")

#mi("\\displaystyle p_i(t) = \\prod_{\\begin{array}{c} 1\\le j\\le k\\\\ j\\neq i \\end{array}} \\frac{t-\\lambda_j}{\\lambda_i -\\lambda_j}.")

#text("Then the respective orthogonal projectors are ")#mi("p_i(\\textsf{\\textbf{A}})=\\textsf{\\textbf{E}}_i")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519848")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2019")])]

#text("This identity is related to the ones discussed here, but not quite the same; it involves polynomials of the matrix ")#mi("A")#text(", rather than eigenvalues of the minor ")#mi("M_j")#text(". In the notation of this post, Halmos’s identity (assuming simple eigenvalues) would read")

#mi("\\displaystyle v_i v_i^* = \\prod_{k=1; k \\neq i}^n \\frac{A - \\lambda_k(A) I_n}{\\lambda_i(A) - \\lambda_k(A)}.")

#text("It can be proven easily from the spectral theorem. Extracting the ")#mi("(j,j)")#text(" component of this identity, we see that to derive Theorem 1 from this identity (or vice versa) one would have to establish the identity")

#mi("\\displaystyle \\left( \\prod_{k=1; k \\neq i}^n (A - \\lambda_k(A) I_n) \\right)_{j,j} = \\prod_{k=1}^{n-1} (\\lambda_i(A) - \\lambda_k(M_j)) \\quad (*)")

#text("where ")#mi("(B)_{(j,j)}")#text(" denotes the ")#mi("(j,j)")#text(" component of a matrix ")#mi("B")#text(". This identity has to be true (by combining Halmos’s identity with Theorem 1, and using a limiting argument to remove the hypothesis that the eigenvalues are simple), but actually I don’t see any direct way to prove (*) that doesn’t basically proceed via this route. (The right-hand side is ")#mi("\\mathrm{det}( \\lambda_i(A) I_{n-1} - M_j )")#text(", which suggests some sort of invocation of Cramer’s rule, but if one pursues this idea, one is basically repeating the Cramer’s rule proof given in the blog post, followed by the spectral theory proof of Halmos’s identity. The left-hand side is definitely reminiscent of the Cayley-Hamilton theorem, but I have thus far been unable to use that theorem to give a more tractable expression for the left-hand side of (*), other than by the route of combining Halmos’s identity with Theorem 1.)")

#text("It is interesting that there seem to be a number of rather different looking expressions for the same quantity, with the equality between any of the two being a slightly non-trivial theorem. If one writes (assuming simple eigenvalues and ")#mi("j=1")#text(" for sake of discussion)")

#tao-math("\\displaystyle Q_1 := \\left|v_{i,1}\\right|^2", block: false)

#mi("\\displaystyle Q_2 := \\frac{\\prod_{k=1}^{n-1} (\\lambda_i(A) - \\lambda_k(M))}{ \\prod_{k=1; k \\neq i}^{n} (\\lambda_i(A) - \\lambda_k(A))}")

#tao-math("\\displaystyle Q_3 := \\frac{1}{1 + \\left\\| (M - \\lambda_i(A))^{-1} X\\right\\|^2}", block: false)

#mi("\\displaystyle Q_4 := \\left( \\prod_{k=1; k \\neq i}^n \\frac{A - \\lambda_k(A) I_n}{\\lambda_i(A) - \\lambda_k(A)} \\right)_{(1,1)}")

#mi("\\displaystyle Q_5 := \\mathrm{Res}_{\\lambda = \\lambda_i(A)} \\left( (\\lambda I_n - A)^{-1}\\right)_{(1,1)}")

#text("then Theorem 1 asserts that ")#mi("Q_1=Q_2")#text(", the identity from Erdos-Schlein-Yau (and my paper with Van Vu) asserts that ")#mi("Q_1=Q_3")#text(", and Halmos’s identity asserts that ")#mi("Q_1=Q_4")#text(". The Cramer rule proof of Theorem 1 basically proceeds by showing that ")#mi("Q_1=Q_5")#text(" and ")#mi("Q_5 = Q_2")#text(". In the first proof in the blog post an independent proof is given that ")#mi("Q_2=Q_3")#text(". However I don’t know of a direct way to establish that ")#mi("Q_2=Q_4")#text(" or ")#mi("Q_3=Q_4")#text(" without going through ")#mi("Q_1")#text(" or ")#mi("Q_5")#text(".")

#emph[#text("[UPDATE: I can now adapt the adjugate proof of Theorem 1 in the arXiv article to show (*) (or equivalently, ")#mi("Q_2=Q_4")#text(") directly. One can check that")]

#mi("\\displaystyle \\mathrm{adj}( \\lambda_i(A) I_n - A ) = \\prod_{k=1; k \\neq i}^n (A-\\lambda_k(A) I_n)")

#text("by testing against each of the eigenvectors ")#mi("v_1,\\dots,v_n")#text(" separately (or, if one wishes, first checking the identity when ")#mi("A")#text(" is a diagonal matrix, and using the spectral theorem to extend to general Hermitian ")#mi("A")#text("). [Amusingly, if one multiplies both sides of the above identity by ")#mi("\\lambda_i(A) I_n - A")#text(", one also recovers the Cayley-Hamilton theorem.] Extracting the ")#mi("(j,j)")#text(" coefficient, one obtains (*). In other words, one can show ")#mi("Q_2=Q_4")#text(" by equating both quantities with")

#mi("\\displaystyle Q_6 := \\frac{\\left( \\mathrm{adj}( \\lambda_i(A) I_n - A)\\right)_{(1,1)}}{ \\prod_{k=1; k \\neq i}^{n} (\\lambda_i(A) - \\lambda_k(A))}.")

#text("It is also rather easy to show that ")#mi("Q_6 = Q_5")#text(", so this proof is arguably “going through” ")#mi("Q_5")#text(" in some sense.")#linebreak()#text(" ]")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64cdcf6c5ad2c4a5b929477f6c6f6bc307654f648757e49291f4a15228879b96-65ec6802d77367cb10a2bfcf950b269cfbdf743be840fe341c5f6b3d13792b27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vassilis Papanicolaou")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519905")[#strong[#text("Vassilis Papanicolaou")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2019")])]

#text("The RHS of (1) makes sense for arbitrary matrices, not only for Hernmitian. One, then, suspects that the formula extends to any square matrix. The guess is that, in the general case, the LHS is the product of the j-th component of the i-th eigenvector with the conjugate of the j-th component of the eigenvector of the Hermitian adjoint of the matrix coresponding to the conjugate eigenvalue.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519925")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2019")])]

#text("Yes, this seems to indeed be the case; for instance, the Cramer rule based proof looks like it will extend to the non-Hermitian case in the manner indicated.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04cb5cc46cbd11becbc6c85e76aaa98f21284f09ba67500a2c0d011f7fe723ec-4a18deec6b52fbdb9ab4aa4fa75365b66167d685d711c95260b9e89599a9b451.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo B")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519914")[#strong[#text("Bo B")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2019")])]

#text("Maybe it is worthwhile to write the identity in coordinate free notation: We may assume ")#mi("\\lambda_i(A)=0")#text("; otherwise replace ")#mi("A")#text(" by ")#mi("A-\\lambda_i(A)I")#text(". For any vector ")#mi("f")#text(", let ")#mi("\\Delta_f")#text(" be the determinant of the quadratic form ")#mi("(Ax,x)")#text(" restricted to the orthogonal complement of ")#mi("f")#text(". Let ")#mi("v")#text(" be the (a) vector with ")#mi("Av=0")#text(". Then the identity says that")#linebreak()#text(" ")#tao-math("\\displaystyle \\left|(v,f)\\right|^2\\Delta_v=\\Delta_f,", block: false)#linebreak()#text(" if ")#mi("v")#text(" and ")#mi("f")#text(" have norm 1.")

#text("One advantage with this is that we may assume that ")#mi("v")#text(", instead of ")#mi("f")#text(", is an element of an ON basis, which helps (a little) in the proof.")#linebreak()#text(" It also suggests that the formula might hold in the case of infinite dimension, for a suitable notion of determinants. For instance, when ")#mi("A=I+T")#text(" and ")#mi("T")#text(" is of trace class, it should hold for Fredholm determinants, since they are limits of finite dimensional determinants. It might also hold for determinants defined by zeta-functions (?).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-519926")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2019")])]

#text("Nice! This fits well with the geometric proof. The quantity ")#mi("\\Delta_f")#text(" clearly equals ")#mi("\\Delta_v")#text(" when ")#mi("f=v")#text(", and also clearly vanishes when ")#mi("(v,f)=0")#text(" (because the null vector ")#mi("v")#text(" to the quadratic form now lies in the orthogonal complement of ")#mi("f")#text("), while on rewriting ")#mi("\\Delta_f = \\langle A^{\\wedge n-1} *f, *f \\rangle")#text(" (where ")#mi("A^{\\wedge n-1}")#text(" represents the action of ")#mi("A")#text(" on the exterior power ")#mi("\\bigwedge^{n-1} {\\bf C}^n")#text(", and ")#mi("*f \\in \\bigwedge^{n-1} {\\bf C}^n")#text(" is the Hodge dual of ")#mi("f")#text(") we see that ")#mi("\\Delta_f")#text(" is a quadratic form in ")#mi("f")#text(", at which point the identity ")#tao-math("\\left|(v,f)\\right|^2 \\Delta_v = \\Delta_f", block: false)#text(" is forced upon us.")

#text("In less coordinate-free notation, the identity can also be written as ")#tao-math("\\left|v^* f\\right|^2 v^* \\mathrm{adj}(A) v = f^* \\mathrm{adj}(A) f", block: false)#text(", with basically the same proof; this is then more or less the adjugate matrix proof in the arXiv posting.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-523064")[#strong[#text("Theorists discover the “Rosetta Stone” for neutrino physics | News")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2019")]

#text("[…] Experts fully expected the identity to exist somewhere in the literature for centuries but couldn’t find any evidence for it online or in textbooks. The three of us were eventually directed to a similar result by UCLA mathematics professor Terence Tao, who has a Fields Medal and Breakthrough Prize to his name. When we presented Tao with our result, he cheerfully declared that it was, in fact, the discovery of a new identity, and he provided several mathematical proofs, which have now been published online. Tao also discussed the new identity in his math blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0fc118b4404b2a278069777fae9c43262bb90b06891fb788ee5da61c85f6eaaf-bbee2c46a14dac245a8377cb9c97c345c5b616110da29bf799d2bf0474841997.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-523202")[#strong[#text("Jonathan")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2019")])]

#text("I have observed that, due to this version of Cramer’s Rule (I find no separate name for it) : ")#mi("A\\,\\text{adj}(A)=\\text{adj}(A)A=\\det(A)I")#linebreak()#text(" Applied to ")#mi("A\\rightarrow A-\\lambda I")#text(" where ")#mi("\\lambda")#text(" is an eigenvalue of ")#mi("A")#text(", then taken column-by-column, each column of ")#mi("\\text{adj}(A-\\lambda I)")#text(" is a candidate eigenvector for eigenvalue ")#mi("\\lambda")#text(".")

#text("In the case that the eigenspace of eigenvalue ")#mi("\\lambda")#text(" is 1-dimensional, then all the columns of ")#mi("\\text{adj}(A-\\lambda I)")#text(" will be multiples of each other; the matrix itself is an outer product, just as is the case in eq. (7) of the note on arxiv. Would this be useful to generalize your result to the non-hermitian case?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c66ead9d57be1b9fb7c592d26498fb6199c971c567dc67ba8ee06bc82148674-581fe2315e6309a341cd26d11f68809d4c26c86e03c878e710d821f1ed6602fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-523268")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2019")])]

#text("Somehow this identity looks like it is a manifestation of a more abstract algebraic principle not restricted to setting of linear spaces over complex numbers. For example, what has the triangle inequality to do with it, or the fact that complex numbers form an algebraically closed field? (Of course there is a bilinear form involved.) Relaxing the precise formulation and letting this thing run loose, what would turn out to be its “natural habitat”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e64e4304c1b5f17b24e936135027882e0d1d1d596e29266fee083ab6659d782-e8c314aad605c8bed42dfc122e7b447d7d4f18ca44bfc5553e9eee9d29d10525.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ricardo Marino")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-523282")[#strong[#text("Ricardo Marino")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2019")])]

#text("What are the implications of this identity for the spectrum of d-regular graphs, Dr. Tao? Let ")#mi("A")#text(" be the adjacency matrix of a ")#mi("G_{N,d}")#text(" d-regular graph with ")#mi("N")#text(" vertices. Taking the trivial eigenvalue and eigenvector, as ")#mi("v")#text(" and ")#mi("\\lambda_i")#text(" in the identity, does this mean that the product of all the non-zero L-eigenvalues of ")#mi("A")#text(" is equivalent to the ")#mi("\\prod (1 - \\lambda_k)")#text(", where ")#mi("\\lambda_k")#text(" are the eigenvalues of any 1-minor. This creates a series of identities between the eigenvalues of all minors of the adjacency matrix, or am I mistaken? Was this well-known before and I am out of the loop?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-523298")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2019")])]

#text("My thoughts were along similar lines. I thought about Hückel bonding matrices and the eigenfunctions/eigenvalues emerging from that. That is pretty close to spectral graph theory. I see a major problem in that the information on the signs ist lost. That namely makes out a large bit of the unknowns. The absolut values of the components I think are not all too thrilling after all. But as I said also, group representation theory could help here out possibly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-523289")[#strong[#text("Researchers Uncover 'Rosetta Stone' For Neutrino Oscillations in Matter - PJ Digital Marketing")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2019")]

#text("[…] The basic nature of the invention made researchers suppose that the id will need to have already been confirmed however couldn’t discover any proof indicating in any other case, Stephen Parke co-author of analysis recalled. The researchers introduced their findings to Fields Medal Awardee, Terence Tao who confirmed that the id is certainly, a brand new elementary id. The researchers together with Tao revealed that findings on arXiv.org merely titled Eigenvectors from Eigenvalues. Tao additionally defined the invention on his math weblog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-523353")[#strong[#text("Theorists discover the ‘Rosetta Stone’ for neutrino physics – News")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2019")]

#text("[…] Experts fully expected the identity to exist somewhere in the literature for centuries but couldn't find any evidence for it online or in textbooks. The three of us were eventually directed to a similar result by UCLA mathematics professor Terence Tao, who has a Fields Medal and Breakthrough Prize to his name. When we presented Tao with our result, he cheerfully declared that it was, in fact, the discovery of a new identity, and he provided several mathematical proofs, which have now been published online. Tao also discussed the new identity in his math blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d04856a71d86e64035f7493d8c69a52938de60156f7617bfd1ca6f276a632e3a-1e3a3e55fc01a81324b9d056eed8ac351268b7bcc2da606d65958d87a97de49e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lucas Morin")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-523695")[#strong[#text("Lucas Morin")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2019")])]

#text("I have been toying with the formula in the context of statistics, but without much results. I was wondering :")#linebreak()#text(" 1) If it has any practical implication on correlation matrices, which can be put in the form ")#mi("X^{T}X")#text(" after centering and reducing the statistical variables.")#linebreak()#text(" 2) If it could give hindsight into linear regression coefficients that are traditionally given by : ")#mi("\\hat \\beta = (X^{T}X)^{-1}X^Ty")#text(", notably in the context of step wise regression, where you recursively add or remove a variable. Removing the k th variable would mean replacing ")#mi("X^{T}X")#text(" by it’s minor ")#mi("M_k")#text(" in the formula above.")#linebreak()#text(" 3) If it can add to the general linear regression anatomy formula where the regression coefficient for the kth variable is given by : ")#mi("\\beta_k = \\frac{Cov(y_i,\\hat x_{k,i})}{V(\\hat x_{k,i})}")#text(" where ")#mi("\\hat x_{k,i}")#text(" is the residual from a regression of ")#mi("x_{k,i}")#text(" on all the other covariate. I thought about this formula as the regression of ")#mi("x_{k,i}")#text(" would involve ")#mi("X^{T}X")#text(" with kth line and column removed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-527382")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2019")])]

#text("In case in equation (1), the denominator is zero (.i.e the i-th eigenvalue has a multiplicity bigger than 1), It seems in such case the formula does not allow to derive eigenvectors.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528567")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2019")])]

#text("Yes, but this would be expected in any case, since when an eigenvalue occurs with multiplicity then the eigenvectors are not determined uniquely, even after allowing for rotation by a phase and normalising the eigenvector to be of unit length.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528680")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2019")])]

#text("I wonder if there’s a modification of the result giving an expression for the projector onto the eigenspace in this case?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528683")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2019")])]

#text("Incidentally, on Twitter Manjari Narayan just pointed out to me that Lemma 2 seems to appear in a 2014 paper of Van Mieghem: ")#link("https://twitter.com/NeuroStats/status/1194741145177223169")[#text("https://twitter.com/NeuroStats/status/1194741145177223169")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528704")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2019")])]

#text("Thanks for this link! Yes, this does seem to be the same identity (and the author here specifically states that it has been discovered a couple times in the past but never successfully publicised to a wider audience). As far as I can tell this particular preprint was never published either – it seems for some reason that this particular identity just has a tough time trying to become known in the literature. (It’s at times like this that I wish we had a good semantic search engine for mathematics – I am not sure how I would have discovered this preprint other than by publishing our own preprint and waiting for someone to notice the connection.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528710")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2019")])]

#text("Actually, it is possible you would not have discovered this preprint by publishing your own preprint without the Quanta article. :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528714")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2019")])]

#text("I’m glad it’s getting this publicity. I’ve always had the vague sense there should be some geometric sense to the components of eigenvectors, but didn’t know what it was. Now I do!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528806")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2019")])]

#text("Eigenvectors and eigenvalues. May be useful ?")#link("https://www.youtube.com/watch?v=PFDu9oVAE-g")[#text("https://www.youtube.com/watch?v=PFDu9oVAE-g")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528702")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2019")])]

#text("One can write down a formula, but it is messy; it involves the determinants of off-diagonal minors of ")#mi("A - \\lambda I")#text(", which cannot be computed purely from the eigenvalues of the minors of ")#mi("A")#text(" as off-diagonal minors of ")#mi("I")#text(" are no longer multiples of the identity matrix.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5c90f768e5a960ae16c92033f389a30b9ce9f81fb72db10d157e4ebea34a2a0-d00e5498182daab1ea295e9ca8765fc2f4bd789be981f64ae403314b98432970.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manjari Narayan")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528716")[#strong[#text("Manjari Narayan")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2019")])]

#text("I stumbled into Mieghem’s results and other similar ones while trying to create a custom measure of network centrality using entries of the eigenvector. There is a similar interest in properties of eigenvector entries in the systems and control theory literature and the statistics literature on leverage scores and variable importance measures.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/669a67f3636ac2e6acf70b20f0e12fd51298d73eb05118f3c798b2be02b76152-75cf6e16ab3ddbef3c4668c36c1d1a86ec6d79b9e95b8ce7ab8e5f5f1c837e45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guoqiang Wan")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-531088")[#strong[#text("Guoqiang Wan")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2019")])]

#text("My name is Guoqiang Wan.I am from China. I’ve heard a lot about your good reputation. You have good character and advanced knowledge. I’ve also heard that you are especially good at cooperating with people. Because my English level is limited, My paper can’t be published. But I think my method is correct. You’re a master of mathematics, I think you will understand my proof. My email is ")#link("mailto:408073346@qq.com")[#text("408073346@qq.com")]#text(".I hope to receive your reply as soon as possible in order to deliver my paper.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528678")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2019")])]

#text("Why do you say that eigenvectors are determined by eigenvalues? For example, for symmetric matrices you still do not know n-squared plus or minus signs of the coordinates. Isn’t finding the signs almost as hard to finding eigenvectors themselves?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528703")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2019")])]

#text("The title is indeed an oversimplification (it seemed to convey the essence of the result more succinctly than “norm square of coefficients of eigenvectors from eigenvalues”). The second sentence of the abstract is intended to clarify the sense in which we relate eigenvectors and eigenvalues.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64d57dd13985119742b23f6be9e6ee370450bbf56abdeef100fe6090605eccd5-4fe8cce13a6ad41456d3520be518a550757a7997a3254706f4393769715147f0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of s1291")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528849")[#strong[#text("s1291")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")])]

#text("For a semantic search engine, try to use: ")#link("https://zbmath.org/formulae/")[#text("https://zbmath.org/formulae/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528883")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")])]

#text("The problem is that a single identity will appear in very different equivalent forms in the literature, due to a combination of variation in notation and different ways to algebraically rearrange the identity, and so no single regular expression (or other similar device in modern search engines) can currently capture an equivalence class of a given identity, or even to guess when two identities are close to each other. For instance, the forms of the current identity that I am aware of in the literature are described in radically different ways:")

#text("* [Denton-Parke-T.-Zhang 2019] ")#tao-math("\\left|v_{i,j}\\right|^2 \\prod_{k=1; k \\neq i}^n (\\lambda_i(A) - \\lambda_k(A)) = \\prod_{k=1}^{n-1} (\\lambda_i(A) - \\lambda_k(M_j))", block: false)

#text("* [Forrester-Zhang 2019] ")#mi("w_j = \\frac{\\prod_{l=1}^{n-1} (a_j - \\lambda_l)}{\\prod_{l=1,l \\neq j}^n (a_j - a_l)}")

#text("* [van Mieghem 2014] ")#mi("(x_k)_j^2 = -\\frac{1}{c^{\\prime}_A(\\lambda_k)} \\mathrm{det}(A_{\\backslash\\{j\\}} - \\lambda_k I)")

#text("* [Cvetkovic-Rowlinson-Simic 2007] ")#tao-math("x_j^2 = \\left|P_{G-j}(\\lambda)\\right|", block: false)

#text("* [Hagos 2002] ")#mi("x_j^2 = \\frac{P_{G_j}(\\lambda)}{P^{\\prime}_G(\\lambda)}")

#text("* [Baryshnikov 2001] ")#mi("w_i = (-1)^i \\frac{\\prod_{1 \\leq j \\leq M-1}(\\lambda_i-\\mu_j)}{\\prod_{1 \\leq j \\leq M; j \\neq i} (\\lambda_i-\\lambda_j)}")

#text("* [Mukherjee-Datta 1989] ")#mi("C_{rj}^2 = \\frac{P(G-v_r; x_j)}{P^{\\prime}(G; x_j)}")

#text("* [Thompson-McEnteggert 1968] ")#tao-math("\\left|u_{ij}\\right|^2 = \\left\\{ \\frac{\\lambda_j - \\xi_{i1}}{\\lambda_j - \\lambda_1} \\right\\} \\dots \\left\\{ \\frac{\\lambda_j - \\xi_{i,j-1}}{\\lambda_j - \\lambda_{j-1}} \\right\\} \\left\\{ \\frac{\\xi_{ij}-\\lambda_j}{\\lambda_{j+1} - \\lambda_j} \\right\\} \\dots \\left\\{ \\frac{\\xi_{i,n-1}-\\lambda_j}{\\lambda_{n} - \\lambda_j} \\right\\}", block: false)

#text("It is not too difficult to mathematically derive any of these identities from the others, after one unpacks all the notation and performs some standard linear algebraic manipulations, but I don’t see how this could be done automatically by a search engine.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09f5e42236f84baa161d4fb1e1e9244d4cb35e302851782309faff583966b430-11002f0e725618ae2423a91c1c45314a122ea65c45e8746a0fb5a1a392084072.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lostinio (@lostinio)")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528867")[#strong[#text("lostinio (@lostinio)")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")])]

#text("Hello! I implemented your formula in numpy and found the results are exact up to 6-th position. That’s great. Is there any algorithmically simple way to recover the sign, after we found the norm of each component. Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528879")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")])]

#text("This may not be the most optimal way to do things, but if one conjugates the original matrix ")#mi("A")#text(" by some orthogonal matrix ")#mi("U")#text(", then the eigenvectors of the conjugation ")#mi("UAU^{-1}")#text(" are then the vectors ")#mi("U v_i")#text(" formed by applying the orthogonal matrix to the original eigenvectors ")#mi("v_i")#text(". So if one uses the identity twice, once for ")#mi("A")#text(" and once for ")#mi("UAU^{-1}")#text(", then one gets the magnitudes of the components of both ")#mi("v_i")#text(" and ")#mi("Uv_i")#text(", and for various choices of ")#mi("U")#text(" one could use this to determine the signs of the components of ")#mi("v_i")#text(". For instance if ")#mi("n")#text(" is even one could make ")#mi("U")#text(" a block-diagonal matrix with ")#mi("n/2")#text(" copies of the rotation matrix ")#mi("\\begin{pmatrix} 1/\\sqrt{2} & 1/\\sqrt{2} \\\\ -1/\\sqrt{2} & 1/\\sqrt{2} \\end{pmatrix}")#text(". This would give the magnitudes of ")#mi("v_{i,j} \\pm v_{i,j+1}")#text(" for even ")#mi("j")#text(", which when combined with the magnitudes of ")#mi("v_{i,j}, v_{i,j+1}")#text(" would be enough information to determine the signs. Hopefully this only increases the numerical cost of this approach by a factor of 2 or so.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11f80ae81525cf0030792c160df200dd08b031c5c05e5b4646d70bbb6614fc0a-b6b1727efca82ed47e7037c73a14a078496245f138ad652ce36f26e61e8c043c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jim")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-603224")[#strong[#text("Jim")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2020")])]

#text("Hello,")

#text("That is a very cool identity. It might be helpful in an application I am working with, possibly minimize the number of parameters needed to be estimated from a deep learning system.")#linebreak()#text(" I would like to kindly ask a bit of more explanation on the signs deriving method that is explained above. Assuming that we have a 3×3 symmetrical matrix, following the procedure, how do we eventually derive the signs of the initial vi’s?")

#text("Thank you!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528785")[#strong[#text("La física de los neutrinos inspira cómo calcular los autovectores de matrices hermíticas - La Ciencia de la Mula Francis")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2019")]

#text("[…] las tres demostraciones en el blog de Terence Tao, “Eigenvectors from eigenvalues,” What’s new, 13 Aug 2019; cuando lo leí entonces no le presté mayor atención pues no tienen interés desde el punto de […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528822")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2019")])]

#text("On Twitter, Aram Harrow shares a nice proof related to your Cramer’s rule proof:")

#text("Let ")#mi("\\epsilon > 0")#text(" and consider the special case of a zero eigenvalue. Then ")#mi("(A+\\epsilon)^{-1} = v v^T/\\epsilon + O(1)")#text(". Cramer’s rule says the jj’th entry of the LHS is ")#mi("\\mathrm{det}(M_j+\\epsilon)/\\mathrm{det}(\\epsilon+A)")#text(". The result follows by taking the limit ")#mi("\\epsilon -> 0")#text(".")

#text("The result for a general eigenvalue may be done similarly, or can be recovered by considering ")#mi("A-\\lambda I")#text(".")

#text("I really like this way of thinking, since it’s all pretty much automatic once one thinks about ")#mi("(A+\\epsilon)^{-1}")#text(".")

#text("Ref: ")#link("https://twitter.com/quantum_aram/status/1195185551667847170")[#text("https://twitter.com/quantum_aram/status/1195185551667847170")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82dd38e0c03da1661d1ff82b2f028c882a67b135c08b21487a6a4cacdcc42d7f-6b1da39af3a990227e5f24dbb4f906d3d135bc03de160e754162070731bd3de6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jon")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528835")[#strong[#text("Jon")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")])]

#text("We were deriving eigenvectors from eigenvalues in universsity math class back in the 90’s. How come this is now something new and revolutional?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f037892a5c3545c0d5f4a2f0537af8a65c17f31d69150f1937f9d3eec0995b1-6bef6c3775a865d0b1418fe833de7931c13940a581fbd11a3431ca1151b3ccc3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shay")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528837")[#strong[#text("Shay")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")])]

#text("It will take me a while to fully understand the math here, but I was wondering from an applied algorithmic complexity perspective if this approach can yield faster eigenvalue/eigenvector algorithms?")#linebreak()#text(" Additionally, does this result make the Inverse Iteration algorithm redundant?")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/Inverse_iteration")[#text("https://en.wikipedia.org/wiki/Inverse_iteration")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5b439b5d291842be14a059d3637574b876085b473bd14fe761ccc453604c88e-b88bb8a881c3be345caf1a7bcc0ecf8413636c7e412a1bbb94abe97f9959c11e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cheng Wang")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528839")[#strong[#text("Cheng Wang")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")])]

#text("I found this corollary interesting and nonintuitive: If lambda is a repeated eigenvalue, then each minor matrix M_j of A would have lambda as an eigenvalue. There must be some elegant geometry explanation to this")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f95446cb5fda31366d973231f0c19276639b04b63c416b03c2c9d0274df2f47-80d830fcd771a03b7d155c86ae78d3816e924ee63598e3d25526ca80f2d719c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cheng Wang")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528842")[#strong[#text("Cheng Wang")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")])]

#text("This might be a potential way to reduce the multiplicity of eigenvalue by using the minor matrix in some cases.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528866")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")])]

#text("If ")#mi("\\lambda")#text(" is a repeated eigenvalue of ")#mi("A")#text(", then the ")#mi("\\lambda")#text("-eigenspace of ")#mi("A")#text(" is at least two dimensional, and in particular contains an eigenvector whose ")#mi("j^{th}")#text(" component vanishes (since the hyperplane of vectors with vanishing ")#mi("j^{th}")#text(" component has codimension one). Removing this zero component, we obtain an eigenvector of ")#mi("M_j")#text(" with the same eigenvalue. The corollary is also a special case of the ")#link("https://en.wikipedia.org/wiki/Min-max_theorem#Cauchy_interlacing_theorem")[#text("Cauchy interlacing inequalities")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-529342")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2019")])]

#text("How can one get a similar “eigenvectors from eigenvalues” formula in the paper when there are repeated eigenvalues?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-529352")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2019")])]

#text("There is a variant identity in this case that we found in a ")#link("http://www.sciencedirect.com/science/article/pii/S0024379502003245")[#text("2002 paper of Hagos")]#text(". If there is eigenvalue multiplicity ")#mi("\\lambda_{i_-}(A) = \\dots = \\lambda_{i_+}(A) =\\lambda_*")#text(" with some multiplicity ")#mi("m = i_+ - i_- + 1")#text(", then")

#tao-math("\\displaystyle \\sum_{i=i_-}^{i_+} \\left|v_{i,j}\\right|^2 = \\lim_{\\lambda \\to \\lambda_*} \\frac{p_{M_j}(\\lambda) (\\lambda - \\lambda_*)}{p_{A}(\\lambda)}", block: false)

#text("where ")#mi("p_A(\\lambda) = \\prod_{i=1}^n (\\lambda - \\lambda_i(A))")#text(" is the characteristic polynomial of ")#mi("A")#text(", and ")#mi("p_{M_j}(\\lambda) = \\prod_{i=1}^{n-1} (\\lambda - \\lambda_i(M_j))")#text(" is the characteristic polynomial of ")#mi("M_j")#text(". In the multiplicity one case ")#mi("m=1")#text(" one can recover the previous identity from this one by using L’Hopital’s rule. This generalized identity can also be easily obtained from a modification of the Cramer’s rule proof in this blog post.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b97550d28e045c7f85cb252616176e3431d1423f8faee9c114de059d335a9d1-f9445ae081b48040602d5090a3a62e5a0a0c3abd8f95bf7087f639ed2d19c9c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528847")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")])]

#text("could you write 3 examples for 3 lemma?")#linebreak()#text(" it’s hard for me to understand it.")#linebreak()#text(" Thanks~!")

#emph[#text("[Some examples are discussed in the final paragraph before Section 1 of the blog post. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528848")[#strong[#text("Eigenvectors from eigenvalues – GeekWay")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")]

#text("[…] Peter Denton, Stephen Parke, Xining Zhang, and I have just uploaded to the arXiv the short unpublished note “Eigenvectors from eigenvalues”. This note gives two proofs of a general eige…Read More […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b97550d28e045c7f85cb252616176e3431d1423f8faee9c114de059d335a9d1-f9445ae081b48040602d5090a3a62e5a0a0c3abd8f95bf7087f639ed2d19c9c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528850")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")])]

#text("vi,j can be positive or negative,")#linebreak()#text(" How can I make sure whether it is positive or negtive?")#linebreak()#text(" Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528865")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")])]

#text("A (real) unit eigenvector ")#mi("v_i")#text(" is only determined up to sign: if ")#mi("v_i")#text(" is an eigenvector, then so is ")#mi("-v_i")#text(". So the sign ")#mi("v_{i,j}")#text(" is ambiguous to begin with. The relative sign ")#mi("v_{i,j} \\overline{v_{i,j^{\\prime}}}")#text(" between two different components ")#mi("v_{i,j}, v_{i,j^{\\prime}}")#text(" of ")#mi("v_i")#text(" is not ambiguous in this fashion; there is a formula linking this to various determinants involving (off-diagonal) minors, but now the formula does not seem to be neatly expressible in terms of eigenvalues. (See the end of Section 3 of the blog post.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77ec342f161b8f012ae9aa6e9882fb4d14227fbdb8e39c6edb66dbf65f8df764-3d0b465582d6882113b6d08e17fccd8dd6f83603a55b4c77e2907bc2d5cf7a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yiteng Hu")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528851")[#strong[#text("Yiteng Hu")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")])]

#text("This result is very interesting. It reminds me of another observation in inverse spectral theory for Sturm-Liouville operators. We can find it in Levitan’s book")#linebreak()#text(" Inverse Sturm—Liouville Problems in 1987 at pages 64-67. Consider the Sturm-Liouville problems on finite interval [0,1] with two different separated boundary conditions, denote them by L_1 and L_2, then, the norming constants of one operator can read from the spectrum of L_1 and L_2, the formula is highly similar. I don’t know whether there is a similar result for inverse problems of Jacobi operators.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77ec342f161b8f012ae9aa6e9882fb4d14227fbdb8e39c6edb66dbf65f8df764-3d0b465582d6882113b6d08e17fccd8dd6f83603a55b4c77e2907bc2d5cf7a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yiteng Hu")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528856")[#strong[#text("Yiteng Hu")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")])]

#text("I think the result from the inverse spectral theory are just the generalization of this n x n matrix to infinite dimension. For two sequences tends to infinity to be the spectrum of Sturm-Liouville problems, they must satisfy two conditions: interlacing property, asymptotics. For the n x n matrix, the eigenvalues of A and M_j also satisfy interlacing property.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77ec342f161b8f012ae9aa6e9882fb4d14227fbdb8e39c6edb66dbf65f8df764-3d0b465582d6882113b6d08e17fccd8dd6f83603a55b4c77e2907bc2d5cf7a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yiteng Hu")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528857")[#strong[#text("Yiteng Hu")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")])]

#text("After writing this, I begin to wonder whether there is an inverse spectral theory for this n x n matrix situation: by the spectrum of A and one of M_j, to reconstruct this matrix. Since for the inverse Sturm—Liouville problems, by two spectrum or one spectrum and the corresponding norming constants, there is so called Gelfand-Levitan equation to recover the potential. Perhaps, there are already some results about this argument, I’m not sure.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71184a9818707abfa0191069585db134a42bef2eb7fbe9b7ebc3bf29473495c7-8544377a5c38b1bd8bec000cc6f177877d51d45e6031b4f95971c0fb461dbf37.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zhiyue Lu")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528855")[#strong[#text("Zhiyue Lu")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")])]

#text("I wonder what can we say about the non-hermitian matrix such as the transition probability rate matrix? Can we get nice ways to get its eigenvectors there as well?")

#emph[#text("[Yes: see the previous remark of Vassilis Papanicolaou in this comment thread -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528903")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")])]

#text("It looks like they have just reinvented the wheel.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f32d5e3834f5bf900148cf513f79fe36a91cfb3054f0ab77979207ecca9d9369-935fe748a0736c9a185b16566f7e880bcdc7050c7ee04f7a6a55b13985523e26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yc")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528905")[#strong[#text("yc")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")])]

#text("This can be related to evaluating the transition probability between two states in quantum mechanics. If we define")

#mi("f_{ij}(t) =\\langle i |e^{-i H t} |j\\rangle")

#text("then ")#mi("f_{ij}(t)")#text(" will oscillate at angular frequencies given by eigenvalues of ")#mi("H")#text(". Here ")#mi("i,j,\\ldots")#text(" are used to label basis vectors in which ")#mi("H")#text(" is not necessarily diagonal. Let us use ")#mi("|\\alpha\\rangle,\\;\\lambda_\\alpha")#text(" to label eigenvectors and eigenvalues of ")#mi("H")#text(".")

#text("If we carry out Laplace transform, we obtain")

#mi("F_{ij}(s) = \\langle i |(s+iH)^{-1}| j\\rangle")

#text("If we take the residue of ")#mi("F_{ij}(s)")#text(" at any eigenvalue ")#mi("\\lambda_\\alpha")#text(", this will extract the projection of ")#mi("i")#text(" and ")#mi("j")#text(" onto the ")#mi("\\alpha")#text(" eigenvector. More specifically,")

#mi("\\mathrm{Res}_{- i \\lambda_\\alpha} F_{ij} = \\langle i | \\alpha\\rangle\\langle \\alpha |j\\rangle  = \\langle i |(-i\\lambda_\\alpha +i H)^{-1} |j \\rangle")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528906")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")])]

#text("I think the equation (1) in linked paper is missing a symbol after B?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57e685c192fac0b0962f84adfdfefd573af81927553439e1a1a97bd1d4ae8591-6e31fb4297de93b44570229cd79b2320feb7a68df6b54887ca1e61cfd299ed25.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528908")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")])]

#link("https://www.sciencedirect.com/science/article/pii/0024379568900050")[#text("https://www.sciencedirect.com/science/article/pii/0024379568900050")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c18d2baf734b408dd4bed1a6271ad44327894eecc934cce90d471d8f3799447e-f78fcf0eb05a5b1128dda8e80fc6302b76289f47a540e2ac5818a9c5556fd4de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean O'Connor")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528932")[#strong[#text("Sean O'Connor")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2019")])]

#text("There are problems with neural network research too.")#linebreak()#text(" The dot product as a linear associative memory in the context of the central limit theorem.")#linebreak()#text(" ReLU as a literal switch, meaning networks are switched systems of linear projections. Each switch decision is determined by looking at a simple equivalent dot product of the input vector.")#linebreak()#text(" The failure to incorporate efficient dot product algorithms such as the FFT or WHT where that can usefully be done.")#linebreak()#text(" ")#link("https://github.com/S6Regen/Fixed-Filter-Bank-Neural-Networks")[#text("https://github.com/S6Regen/Fixed-Filter-Bank-Neural-Networks")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon313")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528940")[#strong[#text("Anon313")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2019")])]

#text("Maybe this is too simplistic, but I think one way to understand why this is possible is to say that the diagonal eigenvalue matrix is one instance of a matrix with those eigenvalues, and its eigenvectors are simply the unit matrix. Then the question is how the complete set (equivalence class?) of matrices that have the same eigenvalues looks like. Then one has vector permutation and basis rotation as transposition operations that do not change the eigenvalues (maybe thats all?). Then these identyties are expressing projection relations between M and A in these rotated and permuted matrices .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9375ba1193cd75e59ecabcb3d6b993490dc3f6ff062d06014303f5d9b0ba2381-bac681b88146b9932ac7ee82f2d5d5b531b951698ea7ee604e0bdcfe9c51bbe5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J. M.")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528957")[#strong[#text("J. M.")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2019")])]

#text("Let me add a little note, which may or may not be ultimately useful in relation to these results. In Beresford Parlett’s now classical book ")#emph[#link("https://books.google.com/books?hl=en&id=BM9rtF9cu7gC&pg=PA139")[#text("The Symmetric Eigenvalue Problem")]]#text(", there is a result he ascribes to Paige relating the square of the magnitude of an eigenvector component with the characteristic polynomials of submatrices for a symmetric tridiagonal matrix, evaluated at the corresponding eigenvalue. The possible relevance of this is that it is well-known that any Hermitian matrix is (unitarily) similar to a symmetric tridiagonal matrix. I presume there is a way to relate these results to the results in the arXiv preprint.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dfd265efe00ca498b6d65292a21b9d7e87c299db94b40ca8715c7897bfeaa848-ef767ec174a5b2938c27d32b29eb31a45fb9eae42bb007ba806562aaaf3db395.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Coxson")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528972")[#strong[#text("Greg Coxson")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2019")])]

#text("I would like to see a short paper extending the result to the non-Hermitian case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/89bb2b9f252fc26e8f9617b449f1881aa53dc2e8f173c2b2d0402a62cf802bdd-3f633f7e1c1f088273c6e51c62dd4843ee43e90d5839d3167236995bc42336dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yanda Jiang")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-528989")[#strong[#text("Yanda Jiang")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2019")])]

#text("So, this method could calculate eigenvectors given eigenvalues are known. And the value of it is we don’t need all information of original matrix and still be able to get what we want. However, how could we get eigenvalues without original matrix? Plz correct me where I am wrong.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/328a00eff937302d1c0ef1ea315bae605cb871ccae2afb912b438ae3a62991c7-9873cba4df7c65ac1dd97d808553dc407351e9091b84c6a0784fabd4712da237.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henning")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-535984")[#strong[#text("Henning")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2020")])]

#text("In some physics applications it is often relatively easy to measure the spectrum (eigenvalues) of a system. This relationship then provides a representation of the underlying system (matrix). I have recently tried this out, in the arXiv paper “Recovery of eigenvectors from eigenvalues in systems of coupled harmonic oscillators,” and it worked amazingly well.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1cc02d3ec6da9aa61612e6bb181892bdfa63fbc383fff4be42efb70391cd0538-f7486586d73b203a1c5fd11eced7daba00825852a7c34d76d7b2a2741bf95214.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of H Zhao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-529001")[#strong[#text("H Zhao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2019")])]

#text("Dear Terence, have you a practical way to apply the new equation for eigenvectors to eigenvalues of infinite square matrix? Dr. H Zhao (univ of St. Andrews)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78dbbccb7b4abc15fc552dec87e20f5ca8bcd7c082e4baf035fefd27eccb3764-fa86ce6d5707e702e66c99defdd4f7c86186439551e1004880ebc48f3761cbce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FranklyWrong")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-529028")[#strong[#text("FranklyWrong")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2019")])]

#text("Reblogged this on ")#link("http://fwphys.com/2019/11/17/eigenvectors-from-eigenvalues/")[#text("Yourong Frank WANG")]#text(" and commented:")#linebreak()#text(" … Something whose importance only reblogging can be commensurate")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/12950414e0094fa54a70378ec10de94a2d3fbd2628faae879289b92f00341f9b-0aaabc1f995b0df5ebc60e11864a77b83c6db116c0d26dfb53e81f2f6e75cea9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Edelman")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-529031")[#strong[#text("Alan Edelman")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2019")])]

#text("The result can essentially be found in our beta ensembles paper [https://arxiv.org/abs/math-ph/0206043] from 2002.Like J.M. (see the note earlier today), I also found the key formula in Beresford Parlett’s book (Theorem 7.2.1) that may be traced to Chris Paige’s thesis [https://pdfs.semanticscholar.org/48ed/e1ea2ad4a079c3d7386e97b6635c58544170.pdf] (8.12) on page 107. Our formulation of Paige’s result may be found in Equation (15) of the beta ensembles paper. The other observation that we made is that tridiagonalizing doesn’t change the relevant eigenvector component. This is mentioned, for example, in the proof of Corollary 2.2 of the beta ensembles paper.What is interesting is that Paige himself on page 105 refers back to the 1968 paper of Thompson and McEnteggert.")

#text("In other words, I had taken the result from Parlett’s book, who had taken it from Paige, who had taken it from Thompson and McEnteggert, which means that there was a linked chain right back to the 1968 source. Thus while search engines might or might not have worked, the academic version of “follow the money trail”, i.e. follow the publication trail, would have worked just fine.")

#text("In the classroom in a Random Matrix Theory class and also in a numerical computing class, I have demonstrated this formula with Julia [https://julialang.org/] many many times.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/12950414e0094fa54a70378ec10de94a2d3fbd2628faae879289b92f00341f9b-0aaabc1f995b0df5ebc60e11864a77b83c6db116c0d26dfb53e81f2f6e75cea9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Edelman")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-529038")[#strong[#text("Alan Edelman")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2019")])]

#text("Regarding my Julia classroom code, the following yields true")

#text("using LinearAlgebra")

#text("N = 10")#linebreak()#text(" A = rand(N,N)")#linebreak()#text(" A = A+A’")

#text("λ,V = eigen(A)")#linebreak()#text(" VV = zeros(N,N)")#linebreak()#text(" for i=1:N, j=1:N")#linebreak()#text(" 𝓘 = setdiff(1:N,j)")#linebreak()#text(" VV[i,j] = prod(λ[i].-eigvals(A[𝓘,𝓘]))")#linebreak()#text(" end")#linebreak()#text(" VV ./= [prod(λ[i]-λ[k] for k∈1:N if k≠i) for i=1:N]")#linebreak()#text(" VV ≈ V’.^2")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9375ba1193cd75e59ecabcb3d6b993490dc3f6ff062d06014303f5d9b0ba2381-bac681b88146b9932ac7ee82f2d5d5b531b951698ea7ee604e0bdcfe9c51bbe5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J. M.")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-529061")[#strong[#text("J. M.")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2019")])]

#text("I would not be overly surprised if J. H. Wilkinson had noted a formula like this one somewhere.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-529034")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2019")])]

#text("Regarding semantic search for math, Mohan Ganesalingam did some work on understanding natural mathematical language that might be relevant. He wrote a PhD thesis a few years ago that got some attention including from Tim Gowers, but then seems to have dropped into obscurity.")

#text("The thesis was on the author’s website for a while and it looked interesting, but it was taken off the site and put behind a paywall, making it effectively invisible to many of us.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e38e0db2b52ce4fa7d0e4d786570f65ea33601a575766ac38a863fc5f50ce90a-f96b1aa3113fa63c9ce10882b4563d47de5e403fff272cd0639cca65e41bf7cc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rui")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-529043")[#strong[#text("Rui")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2019")])]

#text("This identity is interesting in theory. I’d like to know more about its practical use. If we apply this result to infer a egienvector v of a n*n Hermitian matrix A, a three steps process is required. Firstly, all egivalues of A should be determined and it costs O(n^3)，then we have to further determine all egienvalues of n (n-1)*(n-1) sub-matrices M_j, which costs O(n^4), and the third one is determining the signs of v_i. In contrast, the complexity of the traditional way is O(n^3). According to this, the computational idea is not optimal.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9375ba1193cd75e59ecabcb3d6b993490dc3f6ff062d06014303f5d9b0ba2381-bac681b88146b9932ac7ee82f2d5d5b531b951698ea7ee604e0bdcfe9c51bbe5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J. M.")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-529129")[#strong[#text("J. M.")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2019")])]

#text("Yes, your observation on the required computational effort is sound. In addition, numerical problems will arise if the Hermitian matrix (or a particular submatrix of it) has coincident (or nearly-coincident) eigenvalues. For people who want to do experiments about this, try the procedure out on the symmetric tridiagonal ")#link("https://en.wikipedia.org/wiki/Wilkinson_matrix")[#text("Wilkinson matrix")]#text(", especially the larger cases.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/811c59da98bce7a9978a33df5008f84d8526630c6f494b76290141a8959e398a-9d77bfd350fda1238d0538af84bbfa1229f2c1a7db56c933f1abbbe0419d2983.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yp")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-529147")[#strong[#text("yp")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2019")])]

#text("[3,2,4")#linebreak()#text(" 2,0,2")#linebreak()#text(" 4,2,3]")#linebreak()#text(" How about this matrix with repeated eigenvalues？A Counter-Example.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b97550d28e045c7f85cb252616176e3431d1423f8faee9c114de059d335a9d1-f9445ae081b48040602d5090a3a62e5a0a0c3abd8f95bf7087f639ed2d19c9c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-529245")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2019")])]

#text("In this textbook in year 1995:")#linebreak()#text(" ")#link("https://book.douban.com/subject/1031551/")[#text("https://book.douban.com/subject/1031551/")]#linebreak()#text(" page 323th have already printed out this content.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-529246")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2019")])]

#link("https://max.book118.com/html/2015/0228/12780311.shtm")[#text("https://max.book118.com/html/2015/0228/12780311.shtm")]#linebreak()#text(" page323 ,the lemma 3.1 has the almost the same formula.")#linebreak()#text(" But….in the last century,computer is not widespreaded…let alone semantic search engine.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2f7b18410accc6463ec5fd9b4c34feb24498fc2ab582c69326bd547be93017a-2c622e376bcb7b78cdd8d5591dfdcb580d86730e1dbbe1d0223c6fb96233325a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 良 王")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-529283")[#strong[#text("良 王")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2019")])]

#text("earlier first, i am very exciting about this news stated that it is basic break in math from weChat, then go through the contents and the comments lead me to here, though it is not same as my first imagine, great thanks for authors who broadcasting this news to China, since this i learning much new knowledge about eigenvalues & eigenvectors and a new perspective for this two totally, thanks….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/663bb4296e73939831a3b72c39e70d0de5a5e54b240ddbc1aa1c22294557eadd-c28cf50ecb33f46bf6298e7bfa0250777566ad03fa88144c287ed33eff8fe18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carlo Beenakker")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-529298")[#strong[#text("Carlo Beenakker")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2019")])]

#text("I may have found a 1993 appearance of this formula, ")#link("https://mathoverflow.net/a/346313/11260")[#text("https://mathoverflow.net/a/346313/11260")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-529341")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2019")])]

#text("Thanks for this!")

#text("We are in the process of completely rewriting the paper; at this point it seems more appropriate to present a historical survey of the various places in the literature the identity has appeared (the earliest relevant reference we have currently is a ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1545446")[#text("1934 paper of Loewner")]#text(", and there are at least 18 other appearances in the literature to our knowledge), and describe the various proofs, generalisations, and applications that we are now aware of. There is also an interesting sociology-of-science aspect to this story which is also worth recording, in particular how it seems that it was not feasible to integrate all the disparate references to this identity in the literature until a popular science article reporting on the identity created enough “")#link("https://en.wikipedia.org/wiki/Common_knowledge_(logic)")[#text("common knowledge")]#text("” to kick off what was effectively a crowdsourced effort to locate all these prior references.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63c5e3d164b60dbf2c30b341adc5ad73b787518ecb74470ab6a00431ab9dc71a-de3e719e9960b0a44f0116a1201823a8b5ddfd465aacf6c51ba7363425eb9495.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuyao")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-529350")[#strong[#text("liuyao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2019")])]

#text("That’s most wonderful.")

#text("Though it’s perhaps not appropriate for you to say in the paper, I think how this has turned out has a great deal to do with the fact that your name is associated with it—not only for the initial inclusion in a popular science (online) magazine, but how it got everyone read it: this is one paper of Terry Tao that I could understand the statement of :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-529353")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2019")])]

#text("The Quanta article got me to read it, even though I follow this blog and saw it (but ignored it) on this blog on it this summer. Popular science magazines play an important role in science.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad4c3787242d6ad347603b086c9199bde1ce5d44e9675c4e5b19425957052ce2-db07be4e620a168e46cf17ccc7dae887491bf310a23bf33f361f64f756be6ccd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Timothy Chow")]], [#link("https://terrytao.wordpress.com/2019/08/13/eigenvectors-from-eigenvalues/comment-page-1/#comment-529486")[#strong[#text("Timothy Chow")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2019")])]

#text("Regarding integrating disparate references, I’m reminded of a paper by Miklós Ruszinkó, “On the upper bound of the size of the r-cover-free families,” J. Combin. Theory Ser. A 66 (1994), no. 2, 302–310. What he calls “r-cover-free families” was studied independently by several different communities (coding theory, group testing, combinatorics) under different names. I don’t know how Ruszinkó managed to track down all those different references. I myself independently rediscovered the concept and was going to call them “k-Sperner sets.” I got as far as having my paper accepted for publication before I somehow discovered Ruszinkó’s paper, which superseded everything I had proved. I was just in time to withdraw my paper from publication.")
]
]
]
