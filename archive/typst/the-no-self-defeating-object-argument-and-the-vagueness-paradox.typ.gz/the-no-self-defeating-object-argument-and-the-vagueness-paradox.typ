// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/
// Converted to Typst by tao2typ: "2026-10-14T09:05:12.692138+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The “no self-defeating object” argument, and the vagueness paradox", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The “no self-defeating object” argument, and the vagueness paradox")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 November 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/")[#text("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("This is the third in a ")#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/")[#text("series")]#text(" ")#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/")[#text("of posts")]#text(" on the “no self-defeating object” argument in mathematics – a powerful and useful argument based on formalising the observation that any object or structure that is so powerful that it can “defeat” even itself, cannot actually exist. This argument is used to establish many basic impossibility results in mathematics, such as ")#link("http://en.wikipedia.org/wiki/G%C3%B6del's_incompleteness_theorems")[#text("Gödel’s theorem")]#text(" that it is impossible for any sufficiently sophisticated formal axiom system to prove its own consistency, ")#link("http://en.wikipedia.org/wiki/Halting_problem")[#text("Turing’s theorem")]#text(" that it is impossible for any sufficiently sophisticated programming language to solve its own halting problem, or ")#link("http://en.wikipedia.org/wiki/Cantor's_theorem")[#text("Cantor’s theorem")]#text(" that it is impossible for any set to enumerate its own power set (and as a corollary, the natural numbers cannot enumerate the real numbers).")

#text("As remarked in the previous posts, many people who encounter these theorems can feel uneasy about their conclusions, and their method of proof; this seems to be particularly the case with regard to Cantor’s result that the reals are uncountable. In ")#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/")[#text("the previous post in this series")]#text(", I focused on one particular aspect of the standard proofs which one might be uncomfortable with, namely their ")#link("http://en.wikipedia.org/wiki/Counterfactual_thinking")[#text("counterfactual")]#text(" nature, and observed that many of these proofs can be largely (though not completely) converted to non-counterfactual form. However, this does not fully dispel the sense that the ")#emph[#text("conclusions")]#text(" of these theorems – that the reals are not countable, that the class of all sets is not itself a set, that truth cannot be captured by a predicate, that consistency is not provable, etc. – are highly unintuitive, and even objectionable to “common sense” in some cases.")

#text("How can intuition lead one to doubt the conclusions of these mathematical results? I believe that one reason is because these results are sensitive to the amount of ")#emph[#text("vagueness")]#text(" in one’s mental model of mathematics. In the formal mathematical world, where every statement is either absolutely true or absolutely false with no middle ground, and all concepts require a precise definition (or at least a precise axiomatisation) before they can be used, then one can rigorously state and prove Cantor’s theorem, Gödel’s theorem, and all the other results mentioned in the previous posts without difficulty. However, in the vague and fuzzy world of mathematical intuition, in which one’s impression of the truth or falsity of a statement may be influenced by recent mental reference points, definitions are malleable and blurry with no sharp dividing lines between what is and what is not covered by such definitions, and key mathematical objects may be incompletely specified and thus “moving targets” subject to interpretation, then one can argue with some degree of justification that the conclusions of the above results are incorrect; in the vague world, it seems quite plausible that one can always enumerate all the real numbers “that one needs to”, one can always justify the consistency of one’s reasoning system, one can reason using truth as if it were a predicate, and so forth. The impossibility results only kick in once one tries to clear away the fog of vagueness and nail down all the definitions and mathematical statements precisely. (To put it another way, the no-self-defeating object argument relies very much on the disconnected, definite, and absolute nature of the boolean truth space ")#mi("\\{\\text{true},\\text{ false}\\}")#text(" in the rigorous mathematical world.)")

#metadata(none) <tao-2a1b309960babf350041>

#text("One can already see this with one of the most basic conclusions of the “no self-defeating object” argument, namely that the set of natural numbers is infinite. Let me rephrase this result in the following manner:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1.")]#text(" Let ")#mi("A")#text(" be a set of natural numbers with the following properties:")

#enum(start: 1, 
[#mi("0")#text(" lies in ")#mi("A")#text(".")],
[#text("Whenever a natural number ")#mi("n")#text(" lies in ")#mi("A")#text(", then its successor ")#mi("n+1")#text(" also lies in ")#mi("A")#text(".")]
)

#text("Then ")#mi("A")#text(" is infinite.")
]

#text("Indeed, from the ")#link("http://en.wikipedia.org/wiki/Mathematical_induction")[#text("principle of mathematical induction")]#text(", the hypotheses of Proposition 1 force ")#mi("A")#text(" to be the entire set of natural numbers, and so Proposition 1 is logically equivalent to the assertion that the set of natural numbers is infinite. (Here, infinite has its usual set theoretic meaning, i.e. the conclusion is that ")#mi("A")#text(" cannot be placed in bijection with a set of the form ")#mi("\\{1,\\ldots,n\\}")#text(" for any natural number ")#mi("n")#text(".)")

#text("In the rigorous world of formal mathematics, Proposition 1 is of course uncontroversial, and is easily proven by a simple “no self-defeating object” argument:")

#strong[#text("Proof.")]#text(" Suppose for contradiction that ")#mi("A")#text(" was finite. As ")#mi("A")#text(" is non-empty (it contains ")#mi("0")#text("), it must therefore have a largest element ")#mi("n")#text(" (as can be seen by a routine induction on the cardinality of ")#mi("A")#text("). But then by hypothesis, ")#mi("n+1")#text(" would also have to lie in ")#mi("A")#text(", and ")#mi("n")#text(" would thus need to be at least as large as ")#mi("n+1")#text(", a contradiction. ")#mi("\\Box")

#text("But if one allows for vagueness in how one specifies the set ")#mi("A")#text(", then Proposition 1 can seem to be false, as observed by the ancient Greeks with the ")#link("http://en.wikipedia.org/wiki/Sorites_paradox")[#text("sorites paradox")]#text(". To use their original example, consider the question of how many grains of sand are required to make a heap of sand. One or zero grains of sand are certainly not sufficient, but clearly if one places enough grains of sand together, one would make a heap. If one then “defines” ")#mi("A")#text(" to be the set of all natural numbers ")#mi("n")#text(" such that ")#mi("n")#text(" grains of sand are not sufficient to make a heap, then it is intuitively plausible that ")#mi("A")#text(" obeys both Hypothesis 1 and Hypothesis 2 of the above proposition, since it is intuitively clear that adding a single grain of sand to a non-heap cannot convert it to a heap. On the other hand, it is just as clear that the set ")#mi("A")#text(" is finite, thus providing a counterexample to Proposition 1.")

#text("The problem here is the vagueness inherent in the notion of a “heap”. Given a pile of sand ")#mi("P")#text(", the question “Is ")#mi("P")#text(" a heap?” does not have an absolute truth value; what may seem like a heap to one observer may not be so to another. Furthermore, what may seem like a heap to one observer when presented in one context, may not look like a heap to the same observer when presented in another context; for instance, a large pile of sand that was slowly accumulated over time may not seem as large as a pile of sand that suddenly appeared in front of the observer, even if both piles of sand were of identical size in absolute terms. (The well-known (though technically inaccurate) ")#link("http://en.wikipedia.org/wiki/Boiling_frog")[#text("boiling frog metaphor")]#text(" is a particularly graphic way of depicting this phenomenon, which ultimately arises from the fact that people usually do not judge quantities in absolute terms, but instead by using relative measurements that compare that quantity to nearby reference quantities.)")

#text("There are many modern variants of the sorites paradox that exploit vagueness of definition to obtain conclusions that apparently contradict rigorous statements such as Proposition 1. One of them is the ")#link("http://en.wikipedia.org/wiki/Interesting_number_paradox")[#text("interesting number paradox")]#text(". Let ")#mi("A")#text(" be the set of all natural numbers that are “interesting”, in the sense that they have some unusual defining feature (for instance, 561 is the first composite ")#link("http://en.wikipedia.org/wiki/Carmichael_number")[#text("Carmichael number")]#text(" and is thus presumably an interesting number). Then ")#mi("A")#text(" is presumably finite, but the first natural number that does not lie in ")#mi("A")#text(" is presumably also an interesting number, thus contradicting the definition of ")#mi("A")#text(". (Here, the variant of Proposition 1 that is apparently being contradicted here is the ")#link("http://en.wikipedia.org/wiki/Well-ordering_principle")[#text("well-ordering principle")]#text(".)")

#text("Of course, just as the sorites paradox can be diagnosed as arising from the vagueness of the term “heap”, the interesting number paradox can be diagnosed as arising from the vagueness of the term “interesting”. But one can create a functionally similar paradox that, at first glance, eliminates this vagueness, namely the ")#link("http://en.wikipedia.org/wiki/Well-ordering_principle")[#text("Berry paradox")]#text(". Let ")#mi("A")#text(" denote the set of all natural numbers that can be defined in fewer than sixteen words in the English language; thus, again 561 can be defined as “The first composite Carmichael number” and thus belongs in ")#mi("A")#text(". As there are only finitely many sentences that one can form with fewer than sixteen words of the English language, ")#mi("A")#text(" is clearly finite. But the first natural number that does not lie in ")#mi("A")#text(" can be described as “The first natural number not definable in fewer than sixteen words in the English language”, which is a definition in fewer than sixteen words in the English language, and thus lies in ")#mi("A")#text(", again providing another seeming contradiction to the well-ordering principle.")

#text("Here, the vagueness is a bit harder to spot, and it comes from the use of “the English language”, which is a vague and mutable concept that allows for self-reference and is in fact technically inconsistent if one tries to interpret it naively (as can be seen from any number of linguistic paradoxes, starting with the classic ")#link("http://en.wikipedia.org/wiki/Liar_paradox")[#text("liar paradox")]#text("). To make things more precise, one can try to replace the English language here by a ")#link("http://en.wikipedia.org/wiki/Formal_language")[#text("formal mathematical language")]#text(", e.g. the language of ")#link("http://en.wikipedia.org/wiki/True_arithmetic")[#text("true arithmetic")]#text(". Let us take one such formal language and call it ")#mi("L")#text(". Then one can certainly define the set ")#mi("A_L")#text(" of all natural numbers that can be definable in fewer than sixteen words in the language ")#mi("L")#text(", and one can form the natural number ")#mi("n_L")#text(", defined as “The first natural number not definable in fewer than sixteen words in the language L”. This is a natural number that is definable in fewer than sixteen words – but not in the language ")#mi("L")#text(", but rather in a meta-language ")#mi("L^{\\prime}")#text(" that, among other things, is able to interpret what it means for a sentence in ")#mi("L")#text(" to define a natural number. This requires a truth predicate for ")#mi("L")#text(", and ")#link("http://en.wikipedia.org/wiki/Tarski's_indefinability_theorem")[#text("Tarski’s indefinability theorem")]#text(" asserts that such a predicate cannot exist inside ")#mi("L")#text(" itself. Indeed, one can interpret Berry’s paradox as providing a proof of Tarski’s theorem. Thus we see that a non-trivial mathematical theorem (in this case, Tarski’s theorem) emerges when one finally clears away all the vagueness from a sorites-type paradox. (If instead one replaced the word “definable” by “provably definable”, and used a ")#link("http://en.wikipedia.org/wiki/Formal_system")[#text("formal axiom system")]#text(" ")#mi("L")#text(" as one’s language, one could similarly deduce ")#link("http://en.wikipedia.org/wiki/G%C3%B6del's_incompleteness_theorems")[#text("Gödel’s incompleteness theorem")]#text(" from this argument.)")

#text("Similar paradoxes come up when trying to enumerate the real numbers, or subsets of real numbers. Here, the analogue of Proposition 1 is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2.")]#text(" Let ")#mi("A")#text(" be a set of real numbers with the following properties:")

#enum(start: 1, 
[#mi("A")#text(" is infinite.")],
[#text("Given any sequence ")#mi("x_1, x_2, x_3, \\ldots")#text(" of elements of ")#mi("A")#text(", one can find another element ")#mi("y")#text(" of ")#mi("A")#text(" that is not equal to any of the elements of the sequence (i.e. ")#mi("y \\neq x_n")#text(" for every positive integer ")#mi("n")#text(").")]
)

#text("Then ")#mi("A")#text(" is uncountable.")
]

#text("(Of course, uncountability has the usual set-theoretic definition, namely that the infinite set ")#mi("A")#text(" is not in one-to-one correspondence with the natural numbers.)")

#text("Again, in the rigorous world in which all terms are clearly defined, this proposition is easily proven:")

#strong[#text("Proof.")]#text(" Suppose for sake of contradiction that ")#mi("A")#text(" was countable. Then, being infinite, it could be enumerated by a sequence ")#mi("x_1, x_2, x_3, \\ldots")#text(" of real numbers in ")#mi("A")#text("; but then by hypothesis #2, there would then be another real number ")#mi("y")#text(" that was also in ")#mi("A")#text(", but distinct from all of the elements of the sequence, contradicting the fact that this was an enumeration. ")#mi("\\Box")

#text("Since Cantor’s diagonal argument demonstrates that the set of reals ")#mi("{\\bf R}")#text(" itself obeys hypothesis #2 (and also clearly obeys hypothesis #1), we conclude as a corollary that the reals are uncountable.")

#text("However, one can find apparent counterexamples to Proposition 2 if one deploys enough vagueness. For instance, in the spirit of the Berry paradox, one could try setting ")#mi("A")#text(" to be the set of all “definable” real numbers – those numbers that can be defined using a finite sentence in the English language. As there are only countably many such sentences, ")#mi("A")#text(" would be countable; it is also clearly infinite. But, on the other hand, one could take any sequence of real numbers ")#mi("x_1, x_2, x_3, \\ldots")#text(" in ")#mi("A")#text(" and apply the diagonal argument to define another real number that does not lie in that sequence.")

#text("Again, this apparent contradiction becomes clarified if one removes the vagueness, by replacing “the English language” with a formal language ")#mi("L")#text(". For instance, one could take ")#mi("L")#text(" to be true arithmetic, and ")#mi("A_L")#text(" to be the set of all real numbers that are definable by a sentence in ")#mi("L")#text(". Then ")#mi("A_L")#text(" is indeed countable, but any enumeration of ")#mi("A_L")#text(" requires the truth predicate for ")#mi("L")#text(" and thus such an enumeration (as well as the Cantor diagonalisation thereof) cannot be defined in ")#mi("L")#text(", but only in a meta-language ")#mi("L^{\\prime}")#text(" – thus obtaining yet another proof of Tarski’s indefinability theorem. Or, one could take ")#mi("L")#text(" to be a programming language, such as the language of Turing machines; then again the set ")#mi("A_L")#text(" of real numbers whose decimal expansion can be given as the output of an algorithm in ")#mi("L")#text(" is countable, but to enumerate it one would have to solve the halting problem for ")#mi("L")#text(", which requires a meta-language ")#mi("L^{\\prime}")#text(" that is distinct from ")#mi("L")#text(" itself; thus in this case the diagonalisation argument gives a proof of ")#link("http://en.wikipedia.org/wiki/Halting_problem")[#text("Turing’s halting theorem")]#text(".")

#text("It is also instructive to contrast the formal distinction between countable and uncountable sets with the sorites paradox distinction between a non-heap and a heap of sand. Intuitively, the act of adding one grain of sand to a non-heap cannot directly turn that non-heap into a heap, and yet Proposition 1 forces this to eventually be the case. Similarly, it is intuitively clear that act of producing a single real number not on one’s countable enumeration of a set ")#mi("A")#text(" does not directly convert a countable set to become uncountable, and yet Proposition 2 forces this to eventually be the case. (More formally, Proposition 1 is powered by the principle of mathematical induction, which allows one to iterate the ")#mi("n \\to n+1")#text(" operation indefinitely (or more precisely, up to the first infinite ")#link("http://en.wikipedia.org/wiki/Ordinal_number")[#text("ordinal")]#text(" ")#mi("\\omega")#text(") to explicitly achieve infinite cardinality; in a similar spirit, one can interpret Proposition 2 as being powered by ")#link("http://en.wikipedia.org/wiki/Transfinite_induction")[#text("transfinite induction")]#text(", in the sense that one can iterate the diagonalisation operation indefinitely (or more precisely, up to the ")#link("http://en.wikipedia.org/wiki/First_uncountable_ordinal")[#text("first uncountable ordinal")]#text(" ")#mi("\\omega_1")#text(") to explicitly achieve uncountable cardinality. The transition from countability to uncountability does not occur during the ")#link("http://en.wikipedia.org/wiki/Successor_ordinal")[#text("successor ordinal")]#text(" steps of this transfinite induction, but during the (final) ")#link("http://en.wikipedia.org/wiki/Limit_ordinal")[#text("limit ordinal")]#text(" step.)")

#text("One can perform a similar analysis for the other results discussed previously in this series. For instance, ")#link("http://en.wikipedia.org/wiki/Russell's_paradox")[#text("Russell’s paradox")]#text(" tells us, among other things, that (assuming the standard ")#link("http://en.wikipedia.org/wiki/Zermelo-Fraenkel_set_theory")[#text("Zermelo-Frankel axioms of set theory")]#text(") the ")#link("http://en.wikipedia.org/wiki/Class_(set_theory)")[#text("class")]#text(" of all sets cannot itself be a set. Actually we have the following slightly more general statement, analogous to Proposition 1 or Proposition 2:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3.")]#text(" Let ")#mi("{\\mathcal C}")#text(" be a class of sets with the following properties:")

#enum(start: 1, 
[#text("The empty set ")#mi("\\emptyset")#text(" belongs to ")#mi("{\\mathcal C}")#text(".")],
[#text("If a set ")#mi("A")#text(" belongs to ")#mi("{\\mathcal C}")#text(", then the singleton set ")#mi("\\{A\\}")#text(" also belongs to ")#mi("{\\mathcal C}")#text(".")],
[#text("If any collection ")#mi("\\{ A_\\beta: \\beta \\in B\\}")#text(" of sets ")#mi("A_\\beta")#text(", indexed by another set ")#mi("B")#text(", is such that each ")#mi("A_\\beta")#text(" lies in ")#mi("{\\mathcal C}")#text(", then their union ")#mi("\\bigcup_{\\beta \\in B} A_\\beta")#text(" also lies in ")#mi("{\\mathcal C}")#text(".")]
)

#text("Then ")#mi("{\\mathcal C}")#text(" is not a set.")
]

#text("(Hypothesis #1 is actually redundant, being implied by the trivial case of Hypothesis #3 when ")#mi("B")#text(" is empty, but we keep it in order to emphasise the similarity with Propositions 1 and 2.) The ")#link("http://en.wikipedia.org/wiki/Zermelo-Fraenkel_set_theory")[#text("Zermelo-Frankel axioms ")]#text("(as well as one’s intuition from ")#link("http://en.wikipedia.org/wiki/Naive_set_theory")[#text("naive set theory")]#text(") tell us that the class of all sets obeys Hypotheses #1, #2, #3, and so cannot be a set. (In fact, the above proposition is essentially equivalent to the slightly stronger assertion that the class of all ")#link("http://en.wikipedia.org/wiki/Well-founded_set")[#text("well-founded sets")]#text(", also known as the ")#link("http://en.wikipedia.org/wiki/Von_neumann_universe")[#text("von Neumann universe")]#text(" ")#mi("V")#text(", is not a set.) A key subtlety is that the set ")#mi("\\{ A_\\beta: \\beta \\in B\\}")#text(" itself is not required to lie in ")#mi("{\\mathcal C}")#text(". If one imposes such a restriction, then ")#mi("{\\mathcal C}")#text(" can become a set (and by adding a few additional axioms, such sets become the same concept as ")#link("http://en.wikipedia.org/wiki/Grothendieck_universe")[#text("Grothendieck universes")]#text(").")

#strong[#text("Proof.")]#text(" Suppose for contradiction that ")#mi("{\\mathcal C}")#text(" is a set. Using the ")#link("http://en.wikipedia.org/wiki/Axiom_of_specification")[#text("axiom (schema) of specification")]#text(", the set ")#mi("B := \\{ A \\in {\\mathcal C}: A \\not \\in A \\}")#text(" is then a set. It is the union of all the singleton sets ")#mi("\\{A\\}")#text(" with ")#mi("A \\in B")#text(", so by Hypotheses #2 and #3, ")#mi("B \\in {\\mathcal C}")#text(". But then we see that ")#mi("B \\in B")#text(" if and only if ")#mi("B \\not \\in B")#text(", which is absurd. ")#mi("\\Box")

#text("Again, the hypotheses in this proposition seem innocuous, much like adding a single grain of sand to a non-heap of sand; but if one iterates them indefinitely then one eventually ends up with a class so large that it is no longer a set. (Here, the transfinite induction is not up to the first infinite ordinal or the first uncountable ordinal, but rather across the class of ")#emph[#text("all")]#text(" ordinals; the point then being that the class of all ordinals is itself not a set.) Naive set theory intuition seems to be in contradiction to Proposition 3, but this is only due to the vagueness inherent in that concept of set theory. One can also try analysing Berry-type paradoxes in this setting, for instance working only with “constructible” sets (i.e. elements of ")#link("http://en.wikipedia.org/wiki/Constructible_universe")[#text("Gödel’s universe")]#text(" ")#mi("L")#text("); the consequence one gets from this is that the class of constructible sets is not itself constructible (in fact, it is not even a set, as it contains all the ordinals).")

#text("Proposition 3 may seem only of interest to set theorists and logicians, but if one makes a tiny modification of it, by replacing a class of sets with a partially ordered class, then one gets a very important result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4.")]#text(" (")#link("http://en.wikipedia.org/wiki/Zorn's_lemma")[#text("Zorn’s lemma")]#text(") Let ")#mi("{\\mathcal C}")#text(" be a partially ordered class which obeys the following properties:")

#enum(start: 1, 
[#text("At least one element belongs to ")#mi("{\\mathcal C}")#text(".")],
[#text("If ")#mi("x")#text(" is an element of ")#mi("{\\mathcal C}")#text(", then there is another element ")#mi("y")#text(" of ")#mi("{\\mathcal C}")#text(" such that ")#mi("y > x")#text(".")],
[#text("If ")#mi("(x_\\beta)_{\\beta \\in B}")#text(" is a totally ordered set in ")#mi("{\\mathcal C}")#text(", indexed by another set ")#mi("B")#text(", then there exists an element ")#mi("y \\in {\\mathcal C}")#text(" such that ")#mi("y \\geq x_\\beta")#text(" for all ")#mi("\\beta \\in B")#text(".")]
)

#text("Then ")#mi("{\\mathcal C}")#text(" is not a set.")
]

#text("This lemma (which, of course, requires the ")#link("http://en.wikipedia.org/wiki/Axiom_of_choice")[#text("axiom of choice")]#text(" to prove, and is in fact equivalent to this axiom) is usually phrased in the contrapositive form: any non-empty set ")#mi("{\\mathcal C}")#text(" for which every totally ordered set has an upper bound, has a maximal element. However when phrased in the above form, we see the close similarity between Zorn’s lemma and Propositions 1, 2, and 3. In this form, it can be used to demonstrate that many standard classes (e.g. the class of vector spaces, the class of groups, the class of ordinals, etc.) are not sets, despite the fact that each of the hypotheses in the lemma do not directly seem to take one from being a set to not being a set. This is only an apparent contradiction if one’s notion of sets is vague enough to accommodate sorites-type paradoxes.")

#text("More generally, many of the objects demonstrated to be impossible in the previous posts in this series can appear possible as long as there is enough vagueness. For instance, one can certainly imagine an omnipotent being provided that there is enough vagueness in the concept of what “omnipotence” means; but if one tries to nail this concept down precisely, one gets hit by the ")#link("http://en.wikipedia.org/wiki/Omnipotence_paradox")[#text("omnipotence paradox")]#text(". Similarly, one can imagine a foolproof strategy for beating the stock market (or some other zero sum game), as long as the strategy is vague enough that one cannot analyse what happens when that strategy ends up being used against itself. Or, one can imagine the possibility of time travel as long as it is left vague what would happen if one tried to trigger the ")#link("http://en.wikipedia.org/wiki/Grandfather_paradox")[#text("grandfather paradox")]#text(". And so forth. The “self-defeating” aspect of these impossibility results relies heavily on precision and definiteness, which is why they can seem so strange from the perspective of vague intuition.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (32)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-47958")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2010")])]

#text("I’m not sure I understand the point you are making just after you state Proposition 1, since in the proof you use the fact that a finite set of positive integers has a maximum, which, it seems to me, needs induction for its proof. Of course, it’s inevitable that you will use something of the same strength as induction to prove something of (pretty much) the same strength as induction. Are you treating the well-ordering principle as somehow more basic than induction in its usual form?")

#text("I’m writing this without having got to the end of the post. This is just a minor quibble — I’m enjoying the main point about vagueness.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-47963")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2010")])]

#text("I guess I am splitting Proposition 1 into two pieces:")

#text("Proposition 1a: If the set ")#mi("A")#text(" of natural numbers obeys Hypotheses 1 and 2, then it is the entire set of natural numbers.")

#text("Proposition 1b: The natural numbers are infinite.")

#text("Proposition 1a is precisely the principle of mathematical induction. Proposition 1b, as you note, is a fairly short consequence of mathematical induction (which one needs to prove Sublemma 1′: every finite set has a maximal element), but I consider it slightly ‘harder’ than mathematical induction (for instance, it requires the total ordering of the natural numbers, which actually takes a non-trivial amount of effort to prove if one is starting from the Peano axioms, and also the proof has to go via contradiction or negation). So, from a relative perspective, Proposition 1 and Proposition 1b are equivalent modulo induction (but both are fairly easy to show with induction, so this is not a very strong assertion). I’ve reworded the text slightly to emphasise this point.")

#text("Proposition 1 is of course very close in spirit to the well-ordering principle too, but technically I would consider it a different result; the well-ordering principle does not directly say anything about the cardinality of the natural numbers without a fair amount of additional argument.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97513d8b8425e0330dc195bfb6fc841727696ec12a8e24f61e025eeadc53f545-84fa8cc80609d489c3b98baf81048e1cca0a9d99af3b0c30e182a5f89a1fc7f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-47959")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2010")])]

#text("“In the rigorous world of formal mathematics, Proposition 1 is of course uncontroversial, and is easily proven…”")#linebreak()#text(" But isn’t Prop. 1 the definition of the natural numbers (once you add closure: only what is derivable from 1 by finite application of 2…)? If you accept recursive definition of the natural numbers, then the proposition is trivial, but if someone is uncertain of how to formalize the usual `definition’ N={0,1,2,..}, they will be uncertain of the proof.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-47964")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2010")])]

#emph[#text("But isn’t Prop. 1 the definition of the natural numbers?")]

#text("No, this is what I call Proposition 1a in my reply to Tim Gowers. Proposition 1 actually does not need the notion of the set ")#mi("{\\bf N}")#text(" of natural numbers, and can be stated and proved merely knowing that the natural numbers form a class rather than a set (i.e. one still has the predicate “")#mi("n")#text(" is a natural number”, but one does not have a notion of the set of natural numbers).")

#text("One can phrase Proposition 1 in the contrapositive, so that it becomes a result in finite set theory (set theory without the axiom of infinity): if ")#mi("A")#text(" is a finite set of natural numbers, then either ")#mi("A")#text(" does not contain 0, or else there is a natural number ")#mi("n")#text(" in ")#mi("A")#text(" such that ")#mi("n+1")#text(" does not lie in ")#mi("A")#text(". This statement, and its proof, does not require any infinite sets at all, though of course it still does use the principle of mathematical induction (it is hard to do much at all with the natural numbers without this principle).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-47961")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2010")])]

#text("When proving theorems about (for example) prime numbers, I am not troubled by feelings of vagueness, because given an integer asserted to be prime, I can concretely verify that it ")#emph[#text("is")]#text(" prime.")

#text("But when proving theorems about (for example) the complexity class ")#emph[#text("P")]#text(", doubts assail me, because given an algorithm asserted to be in ")#emph[#text("P")]#text(", there is no general means to verify that it ")#emph[#text("is")]#text(" in ")#emph[#text("P")]#text(" … membership is decided instead by a (never-instantiated) oracle.")

#text("This “oracular” vagueness is (AFAICT) a peculiar and distinctive feature of complexity theory, that even the completeness theorems do not share.")

#text("How commonly does it occur, that students are troubled by the oracular vagueness that is associated to complexity theory?")

#text("Is there a (gentle) textbook that discusses oracular vagueness in general, and in particular the oracular vagueness of deciding membership in ")#emph[#text("P")]#text(" (and thus, membership in ")#emph[#text("NP")]#text(" too)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-47967")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2010")])]

#text("This is part of the more general point (made in this post) that in order to completely describe any formal mathematical language L, one needs to use a meta-language L’ that is more expressive than L itself, as the ability of a language L to properly reference itself would be self-defeating. So if one is doing any analysis of systems, one needs a hierarchy of at least two languages, an “internal” language that describes things that are “observable”, “computable”, or “provable” inside the system, and an “external” language that completely describes the external interpretation of that system. This external language could in turn be completely formalised and analysed from an even more external viewpoint, but only by working in a yet more expressive language… and so, given that our human reasoning capacity is finite, one must eventually stop at an outermost layer of language that is either (a) informal or otherwise vague, (b) unable to be externally analysed, (c) unable to prove its own consistency, (d) inconsistent, or (e) too weak to do any serious mathematics. But we can at least insulate all of our mathematical reasoning from this outermost layer by working in a formal internal system inside the informal or indescribable external one (and one which can be nested arbitrarily deeply in this hierarchy). In particular, one can push the vagueness in one’s reasoning to a different layer from the layer in which one is doing mathematics.")

#text("In the more specific case of polynomial time algorithms, one can certainly encode the concept of P (and more generally, to externally analyse polynomial time algorithms) inside a more expressive theory, such as set theory with the axiom of infinity, or by using infinite time algorithms. (I touch upon this latter point in ")#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/")[#text("this post of mine")]#text(".) Now, of course, to be able to externally analyse those latter concepts completely, one would need an even more expressive theory, but in practice one does not need to go arbitrarily high up this hierarchy in order to actually get some mathematics done.")

#text("In any event, just about any subject of study in mathematics (or theoretical computer science) can be described externally using set theory (and usually ZFC is more than sufficient), so one can argue that the problem of vagueness can be delegated to the set theorists (and, moving up the externality hierarchy, to the logicians and then to the philosophers) to resolve.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-48056")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2010")])]

#text("Prof. Tao, thank you for this terrific answer, which went far toward clarifying my understanding of the role of oracles in defining complexity classes in general, and the classes ")#emph[#text("P")]#text(" and ")#emph[#text("NP")]#text(" in particular.")

#text("For me—and I think for many people—the contemplation of concrete examples does much to mitigate feelings of vagueness. Thus, it has greatly helped my understanding of proof theory that Gödel exhibited concrete examples of undecidable formulas. Similarly, it would help my understanding of complexity theory if concrete examples were exibited of algorithms in ")#emph[#text("P")]#text(" for which membership in ")#emph[#text("P")]#text(" similarly was undecidable.")

#text("On Scott Aaronson’s blog ")#emph[#text("Shtetl Optimized")]#text(", Kaveh Khodjasteh took the trouble to ")#link("http://scottaaronson.com/blog/?p=470#comment-53817")[#text("discuss these decidability-in-complexity issues in some depth")]#text(" (including good references).")

#text("Thanks to posts like yours and Kevah’s, it is feasible for a student and/or non-expert to begin with an understanding at the level of (say) Nagel and Newman’s ")#emph[#text("Gödel’s Proof")]#text(", then work her way through your post, Kevah’s post, and then the in-depth discussion of Krajicek and/or Cook and Nguyen (as referenced by Kaveh) … with at least some hope of emerging with a working understanding of the central roles that decidability and oracles play in defining complexity classes.")

#text("It is definitely *not* the case that I have myself gained this understanding … in aggregate, these references are lengthy and plenty tough. But I *have* learned the value of vigorous weblogs in making these mathematical ideas accessible to non-experts. For which, this post is an expression of appreciation and thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-48069")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2010")])]

#text("PS: as I wade deeper into MathOverflow and TCS StackExchange, I find there are at least two persons who post as “Kaveh” on these forums, namely Kaveh Ghasemloo (mainly on MathOverflow) and Kaveh Khodjasteh (mainly on TCS StackExchange) … and perhaps there are even more “Kavehs” than this.")

#text("So in respect to the question “How big is ")#emph[#text("P?”")]#text(", my thanks and appreciation should have been extended more broadly, to encompass everyone who has posted under the name “Kaveh”.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/41c8ffbfd6f91e92580c88f502d3f638d00981e07f05482a450b4473931bfced-c84ece5f3fe3ef888230c87b79d04265b691807639d6bd234bf56af1e8d9f597.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Milovich")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-47971")[#strong[#text("David Milovich")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2010")])]

#text("Godel’s L can’t be a set, at least not in ZF, because L contains as a definable subclass the von Neumann ordinals ordinals On, i.e., the class of all transitive sets strictly well ordered by the membership relation. But by the Burali-Forti paradox, ZF proves that On is not a set, so, by the Axiom of Specification, neither is L a set.")

#text("Actually, not all of ZF is required for the above argument: the axioms of Infinity, Replacement, and Foundation are certainly not used in the proof of Burali-Forti from Chapter 1 of Kunen’s book, nor is anything remotely close to the full strength of the Power Set Axiom used. (I strongly suspect coding could eliminate the use of the Power Set Axiom entirely, though at the expense of assuming the Axiom of Infinity.)")

#emph[#text("[Ah, corrected, thanks. I got confused because one can cut off L at a suitably large cardinal to make internal models of set theory, but L itself does not qualify for this purpose. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cd7e89969ee36f56b9052851f8ce8f7ac2f4339f64db57655ce0e692427ed83-ece70002b800a5489a378c29fb90ce2938c70c1ec41fa976b759c767a46e0da8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ted Gast")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-47978")[#strong[#text("Ted Gast")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2010")])]

#text("Another paradox related to uncountable sets is Skolem’s Paradox. By the Lowenheim-Skolem theorem any countable first order theory with an infinite model must have a countable model. ZFC has a countable first order formulation, thus assuming ZFC has a model (which must be infinite because it satisfies the axiom of infinity), ZFC has a countable model, call it M. But this is an apparent paradox, because M must presumably contain the powerset of the natural numbers, an uncountable set. The way around this paradox is to realize that M may not contain the actual powerset of the natural numbers, just a countable set P, that M thinks is the powerset. Further Cantor’s diagonal argument shows that the bijection of P with the natural numbers, is not in M. This paradox can be disconcerting as it suggests that a set being uncountable is a relative, rather than absolute notion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0fd56049a8189a380fda42273fee0bc2b9ce50a7a224700afce1fe96194008-d71b4d207f9bb85a02159d9eb02ffc3ded2bfbce61de425e7d3d85b4f53db867.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uwe Stroinski")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-47979")[#strong[#text("Uwe Stroinski")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2010")])]

#text("Consider terms like ‘square root of 2’, ‘square root of -1’ or ‘non-Euclidean geometry’. All of them were once known to not exist and later being constructed (albeit in larger sets). They are now part of our syllabus.")

#text("What do you think, is it farfetched to believe that ‘the self-defeating object’ has a similar fate? It ‘contradicts’ the law of excluded middle and thus the two-valuedness of our logic. Due to its circularity it also doesn’t fit well into our ‘bottom-up’ framework of constructing objects. Is it impossible that someday someone will start with ‘the set of all sets’ and construct mathematics ‘top-down’ in terms of some many-valued logic not obeying the law of excluded middle? The result would be mind-boggling (as were the imaginary numbers at their time) and in a way a justification for people feeling ‘uneasy’ about the above proof method.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d00beb1d378886b318ef298ea4a4713ff93ca629e5a6ca444be729dd71f21905-0668a7a169cc566936d553360698be1a830e8caf2687fc492b6d714b9a0c5992.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roger Witte")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-47984")[#strong[#text("Roger Witte")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2010")])]

#text("There are set theories that admit the set of all sets with classical logic and the excluded middle. There is Quine’s NF/NFU family of theories (see Randall Holmes wb pages) and there are Positive set theories (which originate in topology).")

#text("Actually in the main candidate for alternative logics for mathematics, intuitionist logic and constructive mathematics, the self-defeating object causes less uneasiness because there are many thing that neither are or are not.")

#text("Similarly, some category theorists postulate that the problems arise because standard set theory allows questions that should be ill-formed to be meaningful. For example is the empty set a member of the complex number e? They use theories like Lawvere’s Elementary Theory of The Category of Sets in which sets and their members are of different types.")

#text("I have also heard of attempts at ‘inconsistent mathematics’ and ‘paraconsistent logic’, which attempt to allow P and not P without collapse into triviality but I don’t know much about them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b14a08793ead6f06f9db4557eee0271f99e432d06fe3dec339aeb9b565fb3758-819bc8cdf39d530f585f2d28fe35f3e451ac73663bae50a87fd031fe0c6b7fd6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-48034")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2010")])]

#text("To summarize classical logic asserts the 3 classical principles or laws of thought: identity, no-contradiction and excluded middle. Deviant logics (Susan Haack), such as minimal logics, intuitionism or paraconsistent logics (which is more a family of logics than a single logic) are variants which does not accept some of these principles. Quantum logic can also be seen as a deviant logic which differs from classical regarding the distributiveness.")

#text("And in fact, an apparently paradoxical fact, with any of these deviant logics (i do not know if this is the case also for quantum logic) you can do less than with classical (the set of valid inferences is weaker), the reason beeing explained bellow by Prof Tao (Wikipedia articles are a also a good reference to start with). I suggest also the paper from Béziau “S5 is a paraconsistent logic and so is first order classical logic”.")

#text("Universal logic is a brand new trend in logic which tries to integrate all these “deviant” and other new logics (multivalued…), in a common frame.")#linebreak()#text(" Under this frame i suppose they are not seeing as deviant anymore, just possible logics as non-euclidean geometries are possible geometries.")#linebreak()#text(" Regarding multivaluedness Suszko thesis is a good start: ")#link("http://plato.stanford.edu/entries/truth-values/supplement1.html")[#text("http://plato.stanford.edu/entries/truth-values/supplement1.html")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-47987")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2010")])]

#text("Well, as your examples show, one can certainly add an overpowered object to one’s system as long as one depowers something else. For instance, one can add the square root of -1 to one’s number system as long as one depowers the order operation <; one can consider non-Euclidean geometries if one depowers the parallel postulate; and so forth. With regard to, say, \"the set of all sets\", there is for instance New Foundations (mentioned in another comment), which admits this set, but only by depowering the concept of a function (so, in particular, the singleton-forming map ")#mi("x \\mapsto \\{x\\}")#text(" is not considered to be a function from any set ")#mi("X")#text(" to the set of its singletons). And if one depowers the notion of a definite, two-valued truth value to every mathematical statement, then certainly many previously impossible things become possible (or at least not impossible).")

#text("But the real test is whether these extended systems of mathematics actually make it easier for one to say anything new about the \"core\" systems of mathematics (e.g. the natural numbers). The complex numbers, for instance, have been spectacularly successful in this regard, whereas the quaternion numbers, which are superficially a similar type of extension to the real numbers (and arguably \"better\", as it allows for more objects than the complex numbers) have not. The problem here is that the quaternion numbers depowered far too much (in particular, depowering the commutativity of multiplication, which made the polynomial ring much nastier) for the addition of the new objects to be particularly worthwhile.")

#text("From a foundational perspective, the impossibility arguments given in this series of posts can be viewed as a road map that gives a list of items that one must select from to depower in order to enable a self-defeating object to exist. (For instance, definiteness of truth is certainly one of the options to depower here, which is why self-defeating objects are much more plausible in vague models of mathematics than in definite ones.) But the cost of this depowering to one's ability to do mathematics is so great that there must be some significant other advantage, beyond the ability to introduce the self-defeating objects, to make the transition. (The complex numbers form a good example again; if all they allowed one to do is take the square root of -1, they would be next to useless. It is only because they happen to offer so much more – an algebraically complete field structure, an elliptic conformal geometry, etc. – that they are so indispensable in modern mathematics.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/494df6d6a0c1f66a7c37c90f07c0170a976e18d7685e3f3655823a77ad367d19-15b9e865ba19e63a177222a16fbe652f863c942035df375cc63b0d9ca7fa4aaf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gelada")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-48033")[#strong[#text("gelada")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2010")])]

#text("In terms of depowering “definiteness of truth”, I think it is worth analysing how deep the losses are. For example in his discussion of what we could do it the axioms of arithmetic are inconsistent: ")#link("http://video.ias.edu/voevodsky-80th")[#text("http://video.ias.edu/voevodsky-80th")]#text(" Vladimir Voevodsky considers systems where every statement contains its proof steps from the axioms. In this case contradiction is depowered as it no longer causes the whole system to fail.")

#text("In this case the advantage: being able to continue doing mathematics, is obvious. It would be interesting to know the exact costs. For example within these systems can one avoid the esoteric details of non-standard analysis?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d00beb1d378886b318ef298ea4a4713ff93ca629e5a6ca444be729dd71f21905-0668a7a169cc566936d553360698be1a830e8caf2687fc492b6d714b9a0c5992.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roger Witte")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-47983")[#strong[#text("Roger Witte")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2010")])]

#text("“Let A be the set of all natural numbers that are “interesting”, in the sense that they have some unusual defining feature (for instance, 561 is the first composite Carmichael number and is thus presumably an interesting number). Then A is presumably finite”")

#text("On reading this fragment my first thought was “prime numbers are interesting” and “There is no largest Prime” therefore “A is infinite”.")

#text("(Actually this makes it a good example of vagueness, since you and I immediately jumped to opposite conclusions from the same description).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-47988")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2010")])]

#text("One has to be careful here to avoid a ")#link("http://en.wikipedia.org/wiki/Fallacy_of_distribution")[#text("fallacy of distribution")]#text(". The set of prime numbers is certainly interesting; but this does not imply that each individual prime number is itself interesting.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-47985")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2010")])]

#text("I thought I’d try to use your ideas in the last post on this subject, to give my students an introduction to uncountable sets, without entering a counter-factual world. I think it went over pretty well.")

#text("There was one further point of confusion expressed by a few students. It related to timing, which ultimately boils down to the fact that quantifiers do not commute. They were initially confused by the fact that we are *given* a countable list r_1, r_2,… and using this list we can construct something not in the list. They asked why we couldn’t use the element we constructed to modify our list at the time. So, if you are trying to delve into what confuses students, I would just add “non-commutativity of quantifiers”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8442ab05981b5f2944ef3387ce95faae79fbbcab0252627380eb6bfff76e97bd-386a3fdbcc0a12b60077e9dd23e718db90aed0b2988d3cbcebaf044b057408f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Coulter")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-48031")[#strong[#text("Robert Coulter")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2010")])]

#text("There are practical scenarios here that I believe mathematicians should do more research. For example, engineering models often give some statement indicating the “accuracy” of the models. These accuracy statements are often of the form:")

#text("“Model error is greater than 5 % if p > pmax” (e.g.).")

#text("So why bother with the accuracy statement? If the model “knows” there is an error approaching pmax, why doesn’t it incorporate an error correction term to account for it? Then move the accuracy statement out to a further bound, say at a new pmax1. But then there would have to be some point where the model knows nothing and no accuracy statement can be given. Are we better off in that case? It seems as though, from an engineering standpoint, that a model with a “flaw” and an accuracy statement is superior to a model with “flaw correction” and no accuracy statement.. In other words, a model, no matter how accurate, is consider inferior if it cannot say anything about its own accuracy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-48107")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2010")])]

#text("Our intuition may fail in these cases b/c math is a discipline where every statement has to be ascribed a truth value “true” or “false”. Outside of mathematics this binary classification may be a bit simplistic. In other fields (even quantitative) it may not be possible to resolve every statement into one of these two categories. (Upon closer reading, you’ve already mentioned this.)")

#text("Also, maybe a collection of grains of sand becomes a heap when we’re no longer able to count. It takes a certain amount of energy and resources to count every single grain of sand. After a certain point, one might just give up and eat a sandwich.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8442ab05981b5f2944ef3387ce95faae79fbbcab0252627380eb6bfff76e97bd-386a3fdbcc0a12b60077e9dd23e718db90aed0b2988d3cbcebaf044b057408f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Coulter")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-48121")[#strong[#text("Robert Coulter")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2010")])]

#text("A heap of sand is just a heap of sand until it is noted that it consists of individual grains, and then logic can be deployed to destroy the definition. Yet somehow the usefulness of the definition still exists.")

#text("I also find it interesting that the generally accepted to view of deep reality is that is obeys a form of logic (or illogic) that basically states that there is no deep reality:")

#link("http://en.wikipedia.org/wiki/Bell's_theorem")[#text("http://en.wikipedia.org/wiki/Bell's_theorem")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abffa09c500faecb8705951eb7f2b185311b080188e03cd5a0b3b1a934ca6e1d-1d7ff34fbdca5b1d6bd974f014ace44847c3ae402435ce26786f6aa134ba1f0f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mathematics and realism « Xi'an's Og")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-48287")[#strong[#text("Mathematics and realism « Xi'an's Og")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2010")])]

#text("[…] necessarily stem from the human mind and from human perceptions. (He paradoxically quotes Gödel to back his point, while Gödel actually was in agreement with Platonicism.) He then diverges […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e8d808fb560361128dad1dc62bbf62d7d7685ec778b33f4cbde0a424d6e4e9c-25e687b5d96db732bb896de00f9ef512807d8afde27fa2e2375f512c0d52b6f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aru Ronelect")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-48317")[#strong[#text("Aru Ronelect")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2010")])]

#text("Dear Terens Tao,")

#text("Thanks for a surprisingly fresh post on global “mathematical” ideas. Looks like common sense is not yet dead in math :))))")

#text("You talk about vagueness, as a solution for many paradoxes. I think these things belong to the domain of metalanguage as you call it. I would rather say metaprogramming language, or even better metaphysics – so hated word these days :))). Since thinking and your previous post is some sort of programm-calculation.")

#text("What you call mathematics is a very small set (though very important for many reasons) of this metaphysicall programm language, lets call is human mind later on for simplicity.")

#text("If we look at what you said from this perspective we see that paradoxes (in their naive form) are impossible. Since paradox is just a type of calculation, type of statement (usually about infinity, in a form of recursion), or if you want just a message.")

#text("From here we see that vagueness as you call it, is not something from outside, its actually one of the core elements of this metaprogramming language (mind, thinking, feeling), acutally quite vice versa mathematics is some sort of paradox in this realm since it sometimes gives a feeling of absolute predictablilty, which is obviously not there.")

#text("So here with vagueness you go back to the roots, to the original conceptual language used in our heads. Moreover in your first theorem about natural numbers its obvious that you assume we understand what a number is. But we dont. And nobody does. Because number is exactly one of the main blocks of this metalanguage.")

#text("And even idea of recursion and infinity is not something you (we humans) come up with, its also a corestone block of this language.")

#text("So to sum up. From your post its obvious that you as a person is in the possession of the very complex highly conceptual (means rich) language. Well, actually language is already a set of conceptions including the conception of set :)))")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e8d808fb560361128dad1dc62bbf62d7d7685ec778b33f4cbde0a424d6e4e9c-25e687b5d96db732bb896de00f9ef512807d8afde27fa2e2375f512c0d52b6f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aru Ronelect")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-48319")[#strong[#text("Aru Ronelect")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2010")])]

#text("I got into thinking about this. Have to add something :)")

#text("Paradoxes and dualism are everywhere. Better to say calculation errors (expectationsVSresult). So if we look at human mind and universe as a program (for first simplicity) we see that paradox-error is most fundamental element of program work. No errors – no development. Well, there is development without error but this is just traveling.")

#text("It also seems obvious that its impossible to get rid from binary logic of true-false at fundamental level since its just reformulates obvious fact about if something exist or not exist there is nothing in between.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-49006")[#strong[#text("Dangerous Knowledge « /Users/dan/proj")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2010")]

#text("[…] I just wanted to add a link to an awesome post by Terrence Tao about the kind of paradoxes I’ve summarized here. Visit and subscribe to his blog, for it is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-50364")[#strong[#text("Finite Sets | Poincare's Paradise")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2011")]

#text("[…] links are link1,link2,link3. By going through these links we can understand how this method has been used in mathematics, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-58986")[#strong[#text("Alexander Kruel · GiveWell, the SIAI and risks from AI")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2011")]

#text("[…] most of this superficial simplicity is a result of the vagueness of natural language descriptions. Reducing the vagueness of those concepts by being more specific, or by coming up with technical definitions of each of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heuristic limitations of the circle method « What’s new")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-143793")[#strong[#text("Heuristic limitations of the circle method « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2012")])]

#text("[…] (in the spirit of “self-defeating object” arguments, discussed previously several times on this blog). This is actually a fairly common technique in analytic number theory (though not usually […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-188991")[#strong[#text("Alexander Kruel · What I would like the Singularity Institute to publish")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2012")]

#text("[…] [41] The “no self-defeating object” argument, and the vagueness paradox […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A: Problem solving strategies | What's new")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-511370")[#strong[#text("245A: Problem solving strategies | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2019")])]

#text("[…] objects one is applying Zorn’s lemma to is actually a set rather than a proper class; see this previous blog post for more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2944e1f8c4aad16dfdf54d1b263eaf9e971d00edcfca84e3675396cf0444523e-91acb45b2fff7d265bda239bac837bd00d610f49e8073d84ec499da6d1daad2c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-532764")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2019")])]

#text("Is there a self defeating when you deal with things that are ‘finite’?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a04f5bb1b1552d9bb9d4694fe5610c369d9a48a5ef1d3a6de39ee743bb6339fd-a02faddefa904af5b8c5b707a84857ecbf7d3a22b32999df83a44b810d52f57f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Stone")]], [#link("https://terrytao.wordpress.com/2010/11/02/the-no-self-defeating-object-argument-and-the-vagueness-paradox/#comment-559910")[#strong[#text("Michael Stone")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("Dear Mr. Tao,")#linebreak()#text(" This post brought me some comfort on a sleepless night thinking about the axiom of choice and the well ordering principal. Thank you.")
]
