// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/11/26/a-correction-to-an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/
// Converted to Typst by tao2typ: "2026-10-14T15:20:34.035940+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A correction to “An arithmetic regularity lemma, an associated counting lemma, and applications”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A correction to “An arithmetic regularity lemma, an associated counting lemma, and applications”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 November 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/11/26/a-correction-to-an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/")[#text("https://terrytao.wordpress.com/2020/11/26/a-correction-to-an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://people.maths.ox.ac.uk/greenbj/")[#text("Ben Green")]#text(" and I have ")#link("http://arxiv.org/abs/1002.2028")[#text("updated")]#text(" our paper “")#link("https://terrytao.wordpress.com/2010/02/12/an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/")[#text("An arithmetic regularity lemma, an associated counting lemma, and applications")]#text("” to account for a somewhat serious issue with the paper that was pointed out to us recently ")#link("https://www.maths.ox.ac.uk/people/daniel.altman")[#text("by Daniel Altman")]#text(". This paper contains two core theorems:")

#list(
[#text("An “arithmetic regularity lemma” that, roughly speaking, decomposes an arbitrary bounded sequence ")#mi("{f(n)}")#text(" on an interval ")#mi("{\\{1,\\dots,N\\}}")#text(" as an “irrational nilsequence” ")#mi("{F(g(n) \\Gamma)}")#text(" of controlled complexity, plus some “negligible” errors (where one uses the Gowers uniformity norm as the main norm to control the neglibility of the error); and")],
[#text("An “arithmetic counting lemma” that gives an asymptotic formula for counting various averages ")#mi("{{\\mathbb E}_{{\\bf n} \\in {\\bf Z}^d \\cap P} f(\\psi_1({\\bf n})) \\dots f(\\psi_t({\\bf n}))}")#text(" for various affine-linear forms ")#mi("{\\psi_1,\\dots,\\psi_t}")#text(" when the functions ")#mi("{f}")#text(" are given by irrational nilsequences.")]
)

#text("The combination of the two theorems is then used to address various questions in additive combinatorics.")

#text("There are no direct issues with the arithmetic regularity lemma. However, it turns out that the arithmetic counting lemma is only true if one imposes an additional property (which we call the “flag property”) on the affine-linear forms ")#mi("{\\psi_1,\\dots,\\psi_t}")#text(". Without this property, there does not appear to be a clean asymptotic formula for these averages if the only hypothesis one places on the underlying nilsequences is irrationality. Thus when trying to understand the asymptotics of averages involving linear forms that do not obey the flag property, the paradigm of understanding these averages via a combination of the regularity lemma and a counting lemma seems to require some significant revision (in particular, one would probably have to replace the existing regularity lemma with some variant, despite the fact that the lemma is still technically true in this setting). Fortunately, for most applications studied to date (including the important subclass of translation-invariant affine forms), the flag property holds; however our claim in the paper to have resolved a conjecture of Gowers and Wolf on the true complexity of systems of affine forms must now be narrowed, as our methods only verify this conjecture under the assumption of the flag property.")

#text("In a bit more detail: the asymptotic formula for our counting lemma involved some finite-dimensional vector spaces ")#mi("{\\Psi^{[i]}}")#text(" for various natural numbers ")#mi("{i}")#text(", defined as the linear span of the vectors ")#mi("{(\\psi^i_1({\\bf n}), \\dots, \\psi^i_t({\\bf n}))}")#text(" as ")#mi("{{\\bf n}}")#text(" ranges over the parameter space ")#mi("{{\\bf Z}^d}")#text(". Roughly speaking, these spaces encode some constraints one would expect to see amongst the forms ")#mi("{\\psi^i_1({\\bf n}), \\dots, \\psi^i_t({\\bf n})}")#text(". For instance, in the case of length four arithmetic progressions when ")#mi("{d=2}")#text(", ")#mi("{{\\bf n} = (n,r)}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\psi_i({\\bf n}) = n + (i-1)r")]]

#text("for ")#mi("{i=1,2,3,4}")#text(", then ")#mi("{\\Psi^{[1]}}")#text(" is spanned by the vectors ")#mi("{(1,1,1,1)}")#text(" and ")#mi("{(1,2,3,4)}")#text(" and can thus be described as the two-dimensional linear space")

#metadata(none) <tao-1d559f288e68f1defe5f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\Psi^{[1]} = \\{ (a,b,c,d): a-2b+c = b-2c+d = 0\\}")]]

#text("while ")#mi("{\\Psi^{[2]}}")#text(" is spanned by the vectors ")#mi("{(1,1,1,1)}")#text(", ")#mi("{(1,2,3,4)}")#text(", ")#mi("{(1^2,2^2,3^2,4^2)}")#text(" and can be described as the hyperplane")

#metadata(none) <tao-e3ce46a4f7bd4622f496>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\Psi^{[2]} = \\{ (a,b,c,d): a-3b+3c-d = 0 \\}.")]]

#text("As a special case of the counting lemma, we can check that if ")#mi("{f}")#text(" takes the form ")#mi("{f(n) = F( \\alpha n, \\beta n^2 + \\gamma n)}")#text(" for some irrational ")#mi("{\\alpha,\\beta \\in {\\bf R}/{\\bf Z}}")#text(", some arbitrary ")#mi("{\\gamma \\in {\\bf R}/{\\bf Z}}")#text(", and some smooth ")#mi("{F: {\\bf R}/{\\bf Z} \\times {\\bf R}/{\\bf Z} \\rightarrow {\\bf C}}")#text(", then the limiting value of the average")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{n, r \\in [N]} f(n) f(n+r) f(n+2r) f(n+3r)")]]

#text("as ")#mi("{N \\rightarrow \\infty}")#text(" is equal to")

#align(center)[#tao-fit-display[#mitex("\\int_{a_1,b_1,c_1,d_1 \\in {\\bf R}/{\\bf Z}: a_1-2b_1+c_1=b_1-2c_1+d_1=0} \\int_{a_2,b_2,c_2,d_2 \\in {\\bf R}/{\\bf Z}: a_2-3b_2+3c_2-d_2=0}")]]

#align(center)[#tao-fit-display[#mitex("F(a_1,a_2) F(b_1,b_2) F(c_1,c_2) F(d_1,d_2)")]]

#text("which reflects the constraints")

#align(center)[#tao-fit-display[#mitex("\\alpha n - 2 \\alpha(n+r) + \\alpha(n+2r) = \\alpha(n+r) - 2\\alpha(n+2r)+\\alpha(n+3r)=0")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(\\beta n^2 + \\gamma n) - 3 (\\beta(n+r)^2+\\gamma(n+r))")]]

#align(center)[#tao-fit-display[#mitex("+ 3 (\\beta(n+2r)^2 +\\gamma(n+2r)) - (\\beta(n+3r)^2+\\gamma(n+3r))=0.")]]

#text("These constraints follow from the descriptions ")#link(<tao-1d559f288e68f1defe5f>)[#text("(1)")]#text(", ")#link(<tao-e3ce46a4f7bd4622f496>)[#text("(2)")]#text(", using the containment ")#mi("{\\Psi^{[1]} \\subset \\Psi^{[2]}}")#text(" to dispense with the lower order term ")#mi("{\\gamma n}")#text(" (which then plays no further role in the analysis).")

#text("The arguments in our paper turn out to be perfectly correct under the assumption of the “flag property” that ")#mi("{\\Psi^{[i]} \\subset \\Psi^{[i+1]}}")#text(" for all ")#mi("{i}")#text(". The problem is that the flag property turns out to not always hold. A counterexample, provided by Daniel Altman, involves the four linear forms")

#align(center)[#tao-fit-display[#mitex("\\psi_1(n,r) = r; \\psi_2(n,r) = 2n+2r; \\psi_3(n,r) = n+3r; \\psi_4(n,r) = n.")]]

#text("Here it turns out that")

#align(center)[#tao-fit-display[#mitex("\\Psi^{[1]} = \\{ (a,b,c,d): d-c=3a; b-2a=2d\\}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\Psi^{[2]} = \\{ (a,b,c,d): 24a+3b-4c-8d=0 \\}")]]

#text("and ")#mi("{\\Psi^{[1]}}")#text(" is no longer contained in ")#mi("{\\Psi^{[2]}}")#text(". The analogue of the asymptotic formula given previously for ")#mi("{f(n) = F( \\alpha n, \\beta n^2 + \\gamma n)}")#text(" is then valid when ")#mi("{\\gamma}")#text(" vanishes, but not when ")#mi("{\\gamma}")#text(" is non-zero, because the identity")

#align(center)[#tao-fit-display[#mitex("24 (\\beta \\psi_1(n,r)^2 + \\gamma \\psi_1(n,r)) + 3 (\\beta \\psi_2(n,r)^2 + \\gamma \\psi_2(n,r))")]]

#align(center)[#tao-fit-display[#mitex("- 4 (\\beta \\psi_3(n,r)^2 + \\gamma \\psi_3(n,r)) - 8 (\\beta \\psi_4(n,r)^2 + \\gamma \\psi_4(n,r)) = 0")]]

#text("holds in the former case but not the latter. Thus the output of any purported arithmetic regularity lemma in this case is now sensitive to the lower order terms of the nilsequence and cannot be described in a uniform fashion for all “irrational” sequences. There should still be some sort of formula for the asymptotics from the general equidistribution theory of nilsequences, but it could be considerably more complicated than what is presented in this paper.")

#text("Fortunately, the flag property does hold in several key cases, most notably the translation invariant case when ")#mi("{\\Psi^{[1]}}")#text(" contains ")#mi("{(1,\\dots,1)}")#text(", as well as “complexity one” cases. Nevertheless non-flag property systems of affine forms do exist, thus limiting the range of applicability of the techniques in this paper. In particular, the conjecture of Gowers and Wolf (Theorem 1.13 in the paper) is now open again in the non-flag property case.")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11512c45589e33eccb4bb84c5842ebd5a974fb80c99cfcbde3135adb8e15244c-f46198dd1021398a13fd00f21a6f09b13b406363f33f2d6ad9122bac3e528f1d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Q")]], [#link("https://terrytao.wordpress.com/2020/11/26/a-correction-to-an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/#comment-606384")[#strong[#text("Q")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2020")])]

#text("No relation to main theme of posting. Eq 1 and 2 seems related to (x-y)^2 and (x-y)^3. What is the terminology for this combinatorics and does it change in a nice formulaic manner if the second and third vectors do not start at 1?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/11/26/a-correction-to-an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/#comment-606396")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2020")])]

#text("Is it possible to partition the lower order terms into several classes (with several flag properties) where each class obeys its particular flag-property?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/11/26/a-correction-to-an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/#comment-606513")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2020")])]

#text("I think the first ")#mi("n")#text(" in the first display should probably be ")#mi("\\bf n")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/11/26/a-correction-to-an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/#comment-622673")[#strong[#text("55 Best Computer Science Blogs (+ Example Articles)")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2021")]

#text("[…] Interesting to read: A Correction to “An Arithmetic Regularity Lemma, an Associated Counting Lemma, and Application… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Gowers uniformity norm of order 1+ | What's new")]], [#link("https://terrytao.wordpress.com/2020/11/26/a-correction-to-an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/#comment-631852")[#strong[#text("The Gowers uniformity norm of order 1+ | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2021")])]

#text("[…] ; Ben Green and I thought we had resolved this conjecture back in 2010, though it turned out there was a subtle gap in our arguments and we were only able to resolve the conjecture in a partial range of cases. However, the full […]")
]
