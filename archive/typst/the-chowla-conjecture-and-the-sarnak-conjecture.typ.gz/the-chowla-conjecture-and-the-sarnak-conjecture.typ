// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T09:28:17.340719+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Chowla conjecture and the Sarnak conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Chowla conjecture and the Sarnak conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 October 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/")[#text("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of the basic general problems in analytic number theory is to understand as much as possible the fluctuations of the ")#link("http://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(" ")#mi("{\\mu(n)}")#text(", defined as ")#mi("{(-1)^k}")#text(" when ")#mi("{n}")#text(" is the product of ")#mi("{k}")#text(" distinct primes, and zero otherwise. For instance, as ")#mi("{\\mu}")#text(" takes values in ")#mi("{\\{-1,0,1\\}}")#text(", we have the trivial bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\leq x} \\mu(n)\\right| \\leq x", block: true)]]

#text("and the seemingly slight improvement ")#metadata(none) <tao-a160524700113ddd3205>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{n \\leq x} \\mu(n) = o(x)")]]

#text("is already equivalent to the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(", as observed by Landau (see e.g. ")#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/")[#text("this previous blog post")]#text(" for a proof), while the much stronger (and still open) improvement")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) = O(x^{1/2+o(1)})")]]

#text("is equivalent to the notorious ")#link("http://en.wikipedia.org/wiki/Riemann_hypothesis")[#text("Riemann hypothesis")]#text(".")#linebreak()#text(" There is a general ")#emph[#text("Möbius pseudorandomness heuristic")]#text(" that suggests that the sign pattern ")#mi("{\\mu}")#text(" behaves so randomly (or pseudorandomly) that one should expect a substantial amount of cancellation in sums that involve the sign fluctuation of the Möbius function in a nontrivial fashion, with the amount of cancellation present comparable to the amount that an analogous random sum would provide; cf. the probabilistic heuristic discussed in ")#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/")[#text("this recent blog post")]#text(". There are a number of ways to make this heuristic precise. As already mentioned, the Riemann hypothesis can be considered one such manifestation of the heuristic. Another manifestation is the following old ")#link("http://www.ams.org/mathscinet-getitem?mr=177943")[#text("conjecture of Chowla")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Chowla’s conjecture)")]#text(" For any fixed integer ")#mi("{m}")#text(" and exponents ")#mi("{a_1,a_2,\\ldots,a_m \\geq 0}")#text(", with at least one of the ")#mi("{a_i}")#text(" odd (so as not to completely destroy the sign cancellation), we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n+1)^{a_1} \\ldots \\mu(n+m)^{a_m} = o_{x \\rightarrow \\infty;m}(x).")]]
]

#text("Note that as ")#mi("{\\mu^a = \\mu^{a+2}}")#text(" for any ")#mi("{a \\geq 1}")#text(", we can reduce to the case when the ")#mi("{a_i}")#text(" take values in ")#mi("{0,1,2}")#text(" here. When only one of the ")#mi("{a_i}")#text(" are odd, this is essentially the prime number theorem in arithmetic progressions (after some elementary sieving), but with two or more of the ")#mi("{a_i}")#text(" are odd, the problem becomes completely open. For instance, the estimate")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) \\mu(n+2) = o(x)")]]

#text("is morally very close to the conjectured asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) \\Lambda(n+2) = 2\\Pi_2 x + o(x)")]]

#text("for the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(" ")#mi("{\\Lambda}")#text(", where ")#mi("{\\Pi_2 := \\prod_{p > 2} (1 - \\frac{1}{(p-1)^2}) = 0.66016\\ldots}")#text(" is the ")#link("http://mathworld.wolfram.com/TwinPrimesConstant.html")[#text("twin prime constant")]#text("; this asymptotic in turn implies the twin prime conjecture. (To formally deduce estimates for von Mangoldt from estimates for Möbius, though, typically requires some better control on the error terms than ")#mi("{o()}")#text(", in particular gains of some power of ")#mi("{\\log x}")#text(" are usually needed. See ")#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/")[#text("this previous blog post")]#text(" for more discussion.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The Chowla conjecture resembles an assertion that, for ")#mi("{n}")#text(" chosen randomly and uniformly from ")#mi("{1}")#text(" to ")#mi("{x}")#text(", the random variables ")#mi("{\\mu(n+1),\\ldots,\\mu(n+k)}")#text(" become asymptotically independent of each other (in the probabilistic sense) as ")#mi("{x \\rightarrow \\infty}")#text(". However, this is not quite accurate, because some moments (namely those with all exponents ")#mi("{a_i}")#text(" even) have the “wrong” asymptotic value, leading to some unwanted correlation between the two variables. For instance, the events ")#mi("{\\mu(n)=0}")#text(" and ")#mi("{\\mu(n+4)=0}")#text(" have a strong correlation with each other, basically because they are both strongly correlated with the event of ")#mi("{n}")#text(" being divisible by ")#mi("{4}")#text(". A more accurate interpretation of the Chowla conjecture is that the random variables ")#mi("{\\mu(n+1),\\ldots,\\mu(n+k)}")#text(" are asymptotically ")#emph[#text("conditionally")]#text(" independent of each other, after conditioning on the zero pattern ")#mi("{\\mu(n+1)^2,\\ldots,\\mu(n+k)^2}")#text("; thus, it is the ")#emph[#text("sign")]#text(" of the Möbius function that fluctuates like random noise, rather than the zero pattern. (The situation is a bit cleaner if one works instead with the ")#link("http://en.wikipedia.org/wiki/Liouville_function")[#text("Liouville function")]#text(" ")#mi("{\\lambda}")#text(" instead of the Möbius function ")#mi("{\\mu}")#text(", as this function never vanishes, but we will stick to the traditional Möbius function formalism here.)")
]

#text("A more recent formulation of the Möbius randomness heuristic is the following conjecture of Sarnak. Given a bounded sequence ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(", define the ")#emph[#text("topological entropy")]#text(" of the sequence to be the least exponent ")#mi("{\\sigma}")#text(" with the property that for any fixed ")#mi("{\\varepsilon > 0}")#text(", and for ")#mi("{m}")#text(" going to infinity the set ")#mi("{\\{ (f(n+1),\\ldots,f(n+m)): n \\in {\\bf N} \\} \\subset {\\bf C}^m}")#text(" of ")#mi("{f}")#text(" can be covered by ")#mi("{O( \\exp( \\sigma m + o(m) ) )}")#text(" balls of radius ")#mi("{\\varepsilon}")#text(" (in the ")#mi("{\\ell^\\infty}")#text(" metric). (If ")#mi("{f}")#text(" arises from a minimal topological dynamical system ")#mi("{(X,T)}")#text(" by ")#mi("{f(n) := F(T^n x)}")#text(" and ")#mi("{X}")#text(" is generated by ")#mi("{F}")#text(" and its shifts, the above notion is equivalent to the ")#link("http://en.wikipedia.org/wiki/Topological_entropy")[#text("usual notion of the topological entropy")]#text(" of a dynamical system.) For instance, if the sequence is a bit sequence (i.e. it takes values in ")#mi("{\\{0,1\\}}")#text("), then there are only ")#mi("{\\exp(\\sigma m + o(m))}")#text(" ")#mi("{m}")#text("-bit patterns that can appear as blocks of ")#mi("{m}")#text(" consecutive bits in this sequence. As a special case, a Turing machine with bounded memory that had access to a random number generator at the rate of one random bit produced every ")#mi("{T}")#text(" units of time, but otherwise evolved deterministically, would have an output sequence that had a topological entropy of at most ")#mi("{\\frac{1}{T} \\log 2}")#text(". A bounded sequence is said to be ")#emph[#text("deterministic")]#text(" if its topological entropy is zero. A typical example is a polynomial sequence such as ")#mi("{f(n) := e^{2\\pi i \\alpha n^2}}")#text(" for some fixed ")#mi("{\\sigma}")#text("; the ")#mi("{m}")#text("-blocks of such polynomials sequence have covering numbers that only grow polynomially in ")#mi("{m}")#text(", rather than exponentially, thus yielding the zero entropy. Unipotent flows, such as the horocycle flow on a compact hyperbolic surface, are another good source of deterministic sequences.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 3 (Sarnak’s conjecture)")]#text(" Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be a deterministic bounded sequence. Then")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) f(n) = o_{x \\rightarrow \\infty;f}(x).")]]
]

#text("This conjecture in general is still quite far from being solved. However, special cases are known:")

#list(
[#text("For constant sequences, this is essentially the prime number theorem ")#link(<tao-a160524700113ddd3205>)[#text("(1)")]#text(".")],
[#text("For periodic sequences, this is essentially the prime number theorem in arithmetic progressions.")],
[#text("For quasiperiodic sequences such as ")#mi("{f(n) = F(\\alpha n \\text{ mod } 1)}")#text(" for some continuous ")#mi("{F}")#text(", this follows from the work of Davenport.")],
[#text("For nilsequences, this is a ")#link("https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/")[#text("result of Ben Green and myself")]#text(".")],
[#text("For horocycle flows, this is a ")#link("http://arxiv.org/abs/1110.0992")[#text("result of Bourgain, Sarnak, and Ziegler")]#text(".")],
[#text("For the ")#link("http://en.wikipedia.org/wiki/Thue%E2%80%93Morse_sequence")[#text("Thue-Morse sequence")]#text(", this is a ")#link("http://www.ams.org/mathscinet-getitem?mr=2207389")[#text("result of Dartyge-Tenenbaum")]#text(" (with a stronger error term obtained by ")#link("http://www.ams.org/mathscinet-getitem?mr=2680394")[#text("Maduit-Rivat")]#text("). A subsequent ")#link("http://arxiv.org/abs/1112.1032")[#text("result of Bourgain")]#text(" handles all bounded rank one sequences (though the Thue-Morse sequence is actually of rank two), and a related ")#link("http://arxiv.org/abs/1103.4991")[#text("result of Green")]#text(" establishes asymptotic orthogonality of the Möbius function to bounded depth circuits, although such functions are not necessarily deterministic in nature.")],
[#text("For ")#link("http://en.wikipedia.org/wiki/Rudin%E2%80%93Shapiro_sequence")[#text("the Rudin-Shapiro sequence")]#text(", I sketched out an argument at ")#link("http://mathoverflow.net/questions/97261/mobius-randomness-of-the-rudin-shapiro-sequence")[#text("this MathOverflow post")]#text(".")],
[#text("The Möbius function is known to itself be non-deterministic, because its square ")#mi("{\\mu^2(n)}")#text(" (i.e. the indicator of the square-free functions) is known to be non-deterministic (indeed, its topological entropy is ")#mi("{\\frac{6}{\\pi^2}\\log 2}")#text("). (The corresponding question for the ")#link("http://en.wikipedia.org/wiki/Liouville_function")[#text("Liouville function")]#text(" ")#mi("{\\lambda(n)}")#text(", however, remains open, as the square ")#mi("{\\lambda^2(n)=1}")#text(" has zero entropy.)")],
[#text("In the converse direction, it is easy to construct sequences of arbitrarily small positive entropy that correlate with the Möbius function (a rather silly example is ")#mi("{\\mu(n) 1_{k|n}}")#text(" for some fixed large (squarefree) ")#mi("{k}")#text(", which has topological entropy at most ")#mi("{\\log 2/k}")#text(" but clearly correlates with ")#mi("{\\mu}")#text(").")]
)

#text("See ")#link("http://publications.ias.edu/sites/default/files/MobiusFunctionsLectures(2)_0.pdf")[#text("this survey of Sarnak")]#text(" for further discussion of this and related topics.")#linebreak()#text(" In this post I wanted to give a very nice argument of Sarnak that links the above two conjectures:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4")]#text(" The Chowla conjecture implies the Sarnak conjecture.")
]

#text("The argument does not use any number-theoretic properties of the Möbius function; one could replace ")#mi("{\\mu}")#text(" in both conjectures by any other function from the natural numbers to ")#mi("{\\{-1,0,+1\\}}")#text(" and obtain the same implication. The argument consists of the following ingredients:")

#enum(start: 1, 
[#text("To show that ")#mi("{\\sum_{n<x} \\mu(n) f(n) = o(x)}")#text(", it suffices to show that the expectation of the random variable ")#mi("{\\frac{1}{m} (\\mu(n+1)f(n+1)+\\ldots+\\mu(n+m)f(n+m))}")#text(", where ")#mi("{n}")#text(" is drawn uniformly at random from ")#mi("{1}")#text(" to ")#mi("{x}")#text(", can be made arbitrary small by making ")#mi("{m}")#text(" large (and ")#mi("{n}")#text(" even larger).")],
[#text("By the union bound and the zero topological entropy of ")#mi("{f}")#text(", it suffices to show that for any bounded ")#emph[#text("deterministic")]#text(" coefficients ")#mi("{c_1,\\ldots,c_m}")#text(", the random variable ")#mi("{\\frac{1}{m}(c_1 \\mu(n+1) + \\ldots + c_m \\mu(n+m))}")#text(" concentrates with exponentially high probability.")],
[#text("Finally, this exponentially high concentration can be achieved by the moment method, using a slight variant of the moment method proof of the large deviation estimates such as the ")#link("http://en.wikipedia.org/wiki/Chernoff_bound")[#text("Chernoff inequality")]#text(" or ")#link("http://en.wikipedia.org/wiki/Hoeffding%27s_inequality")[#text("Hoeffding inequality")]#text(" (as discussed in ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("this blog post")]#text(").")]
)

#text("As is often the case, though, while the “top-down” order of steps presented above is perhaps the clearest way to think ")#emph[#text("conceptually")]#text(" about the argument, in order to ")#emph[#text("present")]#text(" the argument formally it is more convenient to present the arguments in the reverse (or “bottom-up”) order. This is the approach taken below the fold.")#linebreak()#text(" ")#metadata(none) <tao-927af31708ed5ea0b0ec>

#heading(level: 1)[#strong[#text(" — 1. Proof of proposition — ")]]

#text("We first establish step 3 of the above outline.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5")]#text(" Assume the Chowla conjecture. Then for any ")#mi("{m \\geq 1}")#text(", any ")#mi("{\\varepsilon}")#text(", and any coefficients ")#mi("{c_1,\\ldots,c_m}")#text(" bounded in magnitude by ")#mi("{1}")#text(", we have ")#metadata(none) <tao-560c48d6c73e72bde5e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\mathop{\\bf P}( \\left|\\frac{1}{m} \\sum_{i=1}^m c_i \\mu(n+i)\\right| \\geq \\varepsilon ) \\leq C \\exp( - \\varepsilon^2 m / C ) + o_{x \\rightarrow \\infty; m,\\varepsilon}(1)", block: true)]]

#text("where ")#mi("{C}")#text(" is an absolute constant and ")#mi("{o_{x \\rightarrow \\infty; m,\\varepsilon}(1)}")#text(" goes to zero as ")#mi("{x \\rightarrow \\infty}")#text(" for fixed ")#mi("{m,\\varepsilon}")#text(" (uniformly in the choice of coefficients ")#mi("{c_1,\\ldots,c_m}")#text("), and ")#mi("{n}")#text(" is drawn uniformly at random from ")#mi("{1}")#text(" to ")#mi("{x}")#text(".")
]

#emph[#text("Proof:")]#text(" We use the moment method. Let ")#mi("{k}")#text(" be a large even integer to be optimised in later. By Chebyshev’s inequality, we can bound the left-hand side of ")#link(<tao-560c48d6c73e72bde5e5>)[#text("(2)")]#text(" by")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{(\\varepsilon m)^k} \\mathop{\\bf E} \\left|\\sum_{i=1}^m c_i \\mu(n+i)\\right|^k;", block: true)]]

#text("expanding out the ")#mi("{k^{th}}")#text(" power and using the triangle inequality, we can bound this by ")#metadata(none) <tao-b6b1ecf2b1b3b58ba2e7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\frac{1}{(\\varepsilon m)^k} \\sum_{1 \\leq i_1,\\ldots,i_k \\leq m} |\\mathop{\\bf E} \\mu(n+i_1) \\ldots \\mu(n+i_k)|.")]]

#text("The summand here is always bounded by ")#mi("{1}")#text(". By Chowla’s conjecture, the summand can in fact be bounded by ")#mi("{o_{n \\rightarrow \\infty; m}(1)}")#text(" unless none of the indices ")#mi("{i_1,\\ldots,i_k}")#text(" occur an odd number of times, so that the ")#mi("{k}")#text(" indices are in fact grouped into at most ")#mi("{k/2}")#text(" classes. So we are now facing the enumerative combinatorics problem of counting how many tuples ")#mi("{(i_1,\\ldots,i_k)}")#text(" are of this form. We can estimate this count as follows. Reading the ")#mi("{i_1,\\ldots,i_k}")#text(" from left to right, there are two cases: each ")#mi("{j}")#text(" is either “fresh” (in that ")#mi("{i_j}")#text(" is not equal to any of the ")#mi("{i_1,\\ldots,i_{j-1}}")#text("), or a “repeat”. In the former case, there are at most ")#mi("{m}")#text(" choices for ")#mi("{i_j}")#text("; in the latter case, there are at most ")#mi("{k}")#text(". Also, at most ")#mi("{k/2}")#text(" of the cases are fresh, so once it is decided which indices ")#mi("{j}")#text(" are fresh or repeats, there are at most ")#mi("{m^{k/2} k^{k/2}}")#text(" remaining choices to be made (assuming that ")#mi("{m \\geq k}")#text("). Thus the total count is bounded by ")#mi("{2^k m^{k/2} k^{k/2}}")#text(". Using this bound, we can thus upper bound ")#link(<tao-b6b1ecf2b1b3b58ba2e7>)[#text("(3)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("(\\frac{4k}{\\varepsilon^2 m})^{k/2} + o_{n \\rightarrow \\infty; \\varepsilon,m,k}(1).")]]

#text("If we then optimise in ")#mi("{k}")#text(" by choosing ")#mi("{k}")#text(" to be the largest even integer less than ")#mi("{\\varepsilon^2 m/10}")#text(" (say), we obtain the claim. ")#mi("\\Box")#linebreak()#text(" Now let ")#mi("{f}")#text(" be a deterministic sequence, which we can normalise to be bounded to be real-valued and in magnitude by ")#mi("{1}")#text(". Let ")#mi("{\\varepsilon>0}")#text(" and ")#mi("{m \\geq 1}")#text(", and let ")#mi("{f_\\varepsilon}")#text(" be ")#mi("{f}")#text(" rounded to the nearest multiple of ")#mi("{\\varepsilon}")#text(" that is also bounded in magnitude by ")#mi("{1}")#text("., then from the zero-entropy hypothesis, there are at most ")#mi("{\\exp( o_{m \\rightarrow \\infty;\\varepsilon,f}(m))}")#text(" different values for the tuple ")#mi("{(f_\\varepsilon(n+1),\\ldots,f_\\varepsilon(n+m))}")#text(", as ")#mi("{n}")#text(" ranges over the natural numbers. Let ")#mi("{S_m}")#text(" be the set of all such tuples. From the previous proposition and the union bound, we have")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf P}( \\sup_{(c_1,\\ldots,c_m) \\in S_m} \\left|\\frac{1}{m} \\sum_{i=1}^m c_i \\mu(n+i)\\right| \\geq \\varepsilon )", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\leq (C \\exp( - \\varepsilon^2 m / C ) + o_{x \\rightarrow \\infty; m,\\varepsilon}(1)) \\exp( o_{m \\rightarrow \\infty;\\varepsilon,f}(m))")]]

#text("and hence")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf P}( \\left|\\frac{1}{m} \\sum_{i=1}^m f_\\varepsilon(n+i) \\mu(n+i)\\right| \\geq \\varepsilon )", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\leq C \\exp( - \\varepsilon^2 m / C ) + o_{x \\rightarrow \\infty; m,\\varepsilon}(1)) \\exp( o_{m \\rightarrow \\infty;\\varepsilon,f}(m)).")]]

#text("The right-hand side can be simplified to")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf P}( \\left|\\frac{1}{m} \\sum_{i=1}^m f_\\varepsilon(n+i) \\mu(n+i)\\right| \\geq \\varepsilon ) \\leq \\varepsilon + o_{x \\rightarrow \\infty; m,\\varepsilon}(1)", block: true)]]

#text("if ")#mi("{m}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon,C}")#text(". This in turn leads to the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E} \\frac{1}{m} \\sum_{i=1}^m f_\\varepsilon(n+i) \\mu(n+i) \\right| \\leq o_{x \\rightarrow \\infty; m,\\varepsilon}(1) + 2\\varepsilon", block: true)]]

#text("since the expression inside the integrand is bounded in magnitude by ")#mi("{1}")#text(" (this is Step 2 of the sketch). But by approximate translation invariance we have")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} f_\\varepsilon(n+i) \\mu(n+i) = \\frac{1}{x} \\sum_{n<x} f_\\varepsilon(n) \\mu(n) + o_{x \\rightarrow \\infty;m}(1)")]]

#text("for each ")#mi("{1 \\leq i \\leq m}")#text(", hence")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\frac{1}{m} \\sum_{i=1}^m f_\\varepsilon(n+i) \\mu(n+i) = \\frac{1}{x} \\sum_{n<x} f_\\varepsilon(n) \\mu(n) + o_{x \\rightarrow \\infty;m}(1).")]]

#text("This gives (for a suitable choice of ")#mi("{m}")#text(")")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n<x} f_\\varepsilon(n) \\mu(n)\\right| \\leq (o_{x \\rightarrow \\infty;\\varepsilon,f}(1) + 2\\varepsilon) x", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n<x} f(n) \\mu(n)\\right| \\leq (o_{x \\rightarrow \\infty;\\varepsilon,f}(1) + 2\\varepsilon) x", block: true)]]

#text("letting ")#mi("{\\varepsilon}")#text(" go to zero sufficiently slowly in ")#mi("{x}")#text(", we obtain the Sarnak conjecture.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" The final part of this argument (Step 1 of the sketch) is very lossy: control of short-range correlations (such as ")#mi("{\\frac{1}{m} \\sum_{i=1}^m f_\\varepsilon(n+i) \\mu(n+i)}")#text(") can be easily averaged out to yield control of long-range correlations (such as those ")#mi("{\\frac{1}{x} \\sum_{n<x} f_\\varepsilon(n) \\mu(n)}")#text("), but it is very difficult to reverse the process and deduce short-range control from long-range control. Indeed, conjectures such as the Chowla conjecture, which control ")#mi("{k}")#text("-point correlations of an arithmetic function such as ")#mi("{\\mu}")#text(" are generally considered to be significantly more difficult than conjectures such as the Sarnak conjecture, which involve only simple correlations of that function. (In particular, one can plan to tackle the Sarnak conjecture by using Cauchy-Schwarz type methods to eliminate the role of arithmetic functions ")#mi("{\\mu}")#text(", as was discussed for instance in ")#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/")[#text("this blog post")]#text(", but there is no obvious way to usefully eliminate arithmetic from the Chowla conjeture.)")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (20)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/#comment-182261")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2012")])]

#text("The link of “this Mathoverflow post” does not seem to work, I suppose it is supposed to be this one ?")

#link("http://mathoverflow.net/questions/97261/mobius-randomness-of-the-rudin-shapiro-sequence")[#text("http://mathoverflow.net/questions/97261/mobius-randomness-of-the-rudin-shapiro-sequence")]

#emph[#text("[Yes; the link is now added, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/#comment-182385")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2012")])]

#text("Almost there, but you wrote \\hre instead of \\href")

#emph[#text("[Oops! Fixed, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/815387abb27267e38e0a2f5283f676e11bbc6a335bc3cb3b21f217ced2c2319b-7a270c155a389afd795b534ca64eec559bec2a09b840c4cc7cb2b56940ad16d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Duvall")]], [#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/#comment-183374")[#strong[#text("Duvall")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2012")])]

#text("Dear Terry,")

#text("can you explain the relation between the Sarnak conjecture for zero entropy transformations and uniform distribution of points at prime times for these transformations ( under suitable extra assumptions of course, as say, unique ergodicity of all powers).")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/#comment-183503")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2012")])]

#text("As mentioned in the post, the qualitative formulation of the Sarnak conjecture (with only a ")#mi("o(1)")#text(" gain over the trivial bound) appears to be insufficient to establish any nontrivial bounds involving sums over primes, but if one has a stronger version of the conjecture in which one gains a few powers of ")#mi("\\log x")#text(" (and has some uniformity with respect to dilations) then one can start getting results of this form. Ben and I did this in the case of nilsequences in Section 7 of ")#link("http://arxiv.org/abs/0807.1736")[#text("http://arxiv.org/abs/0807.1736")]#text(" . One can probably write down an abstract version of this implication that applies to more general sequences, though this is not in the literature. (We gave two arguments in that paper, but both took advantage of the special features of nilsequences.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/#comment-183686")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2012")])]

#text("A few questions: 1)What is an example of bounded depth function which is not deterministic? (Actually one can wonder also if there is a connection between “detrminism” in the topological entropy sense and notion of psedorandomness from CS) 2).Regarding the question of Duvall: Do the Mobius randomness of the +- 1 sequences f(n) considered above (or their proofs) imply that there are infinitely many primes for which f(p)=1. 3) What is the lowest density of 1’s that Mobius randomness is known for a non-artificial 01 sequence? 4) if you consider a not too complicated sequence of the kind listed above which depends also on random bits. Is it still mobius-random in some sense?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/#comment-183898")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2012")])]

#text("Dear Gil,")

#text("With regards to (1), one has to be a little careful with how one defines entropy for bounded depth functions, as entropy is an asymptotic notion and bounded depth circuits are generally only defined on {0,…,2^{n-1}} for some fixed large n. But note that if k is a natural number and n is much larger than k (more specifically, ")#mi("n \\geq k + 2^k")#text("), one can build a bounded depth circuit ")#mi("f: \\{0,\\ldots,2^{n-1}\\} \\to \\{0,1\\}")#text(" with ")#mi("f(i)")#text(" zero unless ")#mi("i = a \\text{ mod } 2^k")#text(" for some fixed residue class a. ANDing such a circuit with the ")#mi("(k+a)^{th}")#text(" bit of i, and then ORing ")#mi("2^k")#text(" of these circuits together, we can get a bounded depth circuit which can attain any pattern whatsoever in a consecutive block of ")#mi("2^k")#text(" inputs, and so the topological entropy at scale ")#mi("2^k")#text(" is maximal. This suggests that there is no direct relation between circuit complexity and topological entropy.")

#text("For (2), one generally needs to improve the o(1) bounds by several factors of logarithms, and also to get some quantitative control of f on medium arithmetic progressions (the so-called “Type I sums”). See e.g. Proposition 3 of ")#link("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/")[#text("https://terrytao.wordpress.com/2011/11/21/the-bourgain-sarnak-ziegler-orthogonality-criterion/")]#text(" .")

#text("For (3), I’m not sure I understand the question; any sequence of 0s and 1s for which the 1s only appear with density zero, will automatically have o(1) correlation with Mobius just from the triangle inequality.")

#text("For (4), once there is a nontrivial amount of randomness, it should become rather easy to establish low correlation with high probability. For instance, an easy application of Cauchy-Schwarz (or what harmonic analysts would call the TT^* method, or number theorists would call the large sieve) shows that if f is a random +-1 sequence, f’ is an independent copy of f, and one has ")#tao-math("{\\bf E} \\left|{\\bf E}_{n \\in [N]} f(n) f^{\\prime}(n)\\right| = o(1)", block: false)#text(", then ")#tao-math("{\\bf E} \\left|{\\bf E}_{n \\in [N]} \\mu(n) f(n)\\right| = o(1)", block: false)#text(" (and one could replace ")#mi("\\mu")#text(" here by any deterministic bounded sequence).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/#comment-183979")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2012")])]

#text("Dear Terry, regarding (3) I would regard a sequence ")#emph[#text("f(n)")]#text(" of with 01-values to be “Möbius random” if ")#mi("\\sum_{k=1}^n f(k)\\mu (k)")#text(" is ")#mi("o(\\sum_{k=1}^nf(n))")#text(". Regarding (1) you are right, but I would expect that there is a way around it, e.g. perhaps every bounded depth function is approximately deterministic where the approximation does not affect Mobius randomness.")

#text("A class of functions that are interesting are based on low degree polynomials over ")#emph[#text("Z/2Z")]#text(". So")#emph[#text(" f(n) ")]#text("is described in terms of the m digits of n ")#mi("x_1,x_2\\dots,x_m")#text(" as ")#mi("(-1)^Y")#text(" where ")#mi("Y=\\sum_S x_S")#text(" and the monomials ")#mi("x_S")#text(" are of low degree, namely ")#emph[#text("|S|")]#text(" is “small”. (Here ")#mi("x_S")#text(" corresponds to the AND function on the variables in S, so ")#mi("x_S=1")#text(" iff ")#mi("x_i=1")#text(" for every ")#mi("i \\in S")#text(".) The Walsh functions correspond to all ")#emph[#text("S")]#text("‘s being of size 1 and the Rudin-Shapiro sequence correspond to a special degree 2 polynomial. Some strong form of Mobius randomness will have nice or even spectacular coputational complexity applications.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/#comment-183982")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2012")])]

#text("My guess is that the Friedlander-Iwaniec type results should give some discorrelation of Mobius in such sets as ")#mi("\\{ n^2+m^4: n,m \\in {\\bf N} \\}")#text(" or ")#mi("\\{ n^3 + 2m^3: n,m \\in {\\bf N}\\}")#text(". Some version of the Piatetski-Shapiro prime number theorem should also give discorrelation of Mobius in sparse sets such as ")#mi("\\{ \\lfloor n^c \\rfloor: n \\in {\\bf N} \\}")#text(" for some ")#mi("c")#text(" slightly larger than 1, but these probably won’t be quite as sparse as the Friedlander-Iwaniec examples unless one starts assuming some strong number theoretic conjectures (e.g. Density conjecture, Lindehof hypothesis, RH, etc.). Then of course one could take a random sparse set, but that’s cheating…")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed443d8a11784c5982f0b00db9d6e57690f7cc863fb7396ea292b24f4fd574cd-b10cb900580c30ca3df78ffbb919dd4350ef5dfed17e13b62581b02831e2799a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/#comment-184901")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2012")])]

#text("Hi Terry,")

#text(">My guess is that the Friedlander-Iwaniec type results should give >some discorrelation of Mobius in such sets as \\{ n^2+m^4: n,m \\in {\\bf >N} \\} or \\{ n^3 + 2m^3: n,m \\in {\\bf N}\\}.")

#text("This was shown in a part of my PhD thesis that I never got around to publishing. (Perhaps I should when I have some free time.) I seem to remember that adapting the first result (for n^2+m^4) was easy, whereas adapting Heath-Brown (n^3+2 m^3) and Heath-Brown-Moroz (cubic forms in general) was harder. Perhaps you can give an opinion of how much general interest there is in these results.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/#comment-184366")[#strong[#text("The Quantum Debate is Over! (and other Updates) | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2012")]

#text("[…] some avenues and eventually Tao solved the problem (and earned the 300 reputation points). Here is a very recent post on Möbius randomness on Terry Tao’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d28195df14800315168ea974f4adf888eace7d3a34fc83513af492698793a2c-e2ad3cdfa379c5dcf139408dc5d555ac7c236dfa87abd3799a789b51ef5d74f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kodlu")]], [#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/#comment-184702")[#strong[#text("kodlu")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2012")])]

#text("@Gil: I think you must mean ")#mi("o(\\sum_{k=1}^n f(k))")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An informal version of the Furstenberg correspondence principle | What's new")]], [#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/#comment-221346")[#strong[#text("An informal version of the Furstenberg correspondence principle | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2013")])]

#text("[…] convention that ). The Möbius function is conjectured to behave quite random in many ways (see this blog post for a discussion of some of these), and so one might think that there is no interesting dynamical […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/#comment-379046")[#strong[#text("Derandomizing restricted isometries via the Legendre symbol | Short, Fat Matrices")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2014")]

#text("[…] a strong version of the Chowla conjecture, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/#comment-451469")[#strong[#text("Dynamique de la suite de Moebius et conjecture de Chowla (El Abdalaoui, Lemanczyk, de la Rue) | Jérôme Buzzi's")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2015")]

#text("[…] d’accumulation de l’orbite (et donc au sous-décalage ) et des mesures empiriques . La conjecture de Chowla (1965) est équivalente à la convergence des mesures empiriques vers une mesure pour laquelle les […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An averaged form of Chowla’s conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/#comment-453188")[#strong[#text("An averaged form of Chowla’s conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2015")])]

#text("[…] This paper concerns a weaker variant of the famous conjecture of Chowla (discussed for instance in this previous post) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/#comment-454112")[#strong[#text("On the speed of ergodicity of horocycle maps | Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2015")]

#text("[…] following particular case of Sarnak’s conjecture on the randomness of Möbius function: for all non-periodic and , one […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]], [#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/#comment-459434")[#strong[#text("The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2015")])]

#text("[…] for all , which would have a number of consequences (such as a logarithmically averaged version of Sarnak’s conjecture, as per this blog […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Equivalence of the logarithmically averaged Chowla and Sarnak conjectures | What's new")]], [#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/#comment-468689")[#strong[#text("Equivalence of the logarithmically averaged Chowla and Sarnak conjectures | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2016")])]

#text("[…] in turn follows from the logarithmically averaged form of Sarnak’s conjecture (discussed in this previous post), namely […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Furstenberg limits of the Liouville function | What's new")]], [#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/#comment-478888")[#strong[#text("Furstenberg limits of the Liouville function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2017")])]

#text("[…] any zero-entropy sequence (see this previous blog post for more discussion). Morally speaking, this conjecture should be equivalent to the assertion that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Higher uniformity of bounded multiplicative functions in short intervals on average | What's new")]], [#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/#comment-578372")[#strong[#text("Higher uniformity of bounded multiplicative functions in short intervals on average | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2020")])]

#text("[…] of Chowla’s conjecture from Sarnak’s conjecture, as discussed for instance in this post) gives enough of Chowla’s conjecture to produce plenty of length sign patterns. If there are […]")
]
