// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/
// Converted to Typst by tao2typ: "2026-10-14T15:21:04.265641+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The three-dimensional Kakeya conjecture, after Wang and Zahl", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The three-dimensional Kakeya conjecture, after Wang and Zahl")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 February 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/")[#text("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("There has been some spectacular progress in geometric measure theory: ")#link("https://sites.google.com/view/hongwang/home")[#text("Hong Wang")]#text(" and ")#link("https://personal.math.ubc.ca/~jzahl/")[#text("Joshua Zahl")]#text(" have ")#link("https://arxiv.org/abs/2502.17655")[#text("just released a preprint")]#text(" that resolves the three-dimensional case of the infamous ")#link("https://en.wikipedia.org/wiki/Kakeya_set#Kakeya_conjecture")[#text("Kakeya set conjecture")]#text("! This conjecture asserts that a Kakeya set – a subset of ")#mi("{{\\bf R}^3}")#text(" that contains a unit line segment in every direction, must have Minkowski and Hausdorff dimension equal to three. (There is also a stronger “maximal function” version of this conjecture that remains open at present, although the methods of this paper will give some non-trivial bounds on this maximal function.) It is common to discretize this conjecture in terms of small scale ")#mi("{0 < \\delta < 1}")#text(". Roughly speaking, the conjecture then asserts that if one has a family ")#mi("{\\mathbb{T}}")#text(" of ")#mi("{\\delta \\times \\delta \\times 1}")#text(" tubes of cardinality ")#mi("{\\approx \\delta^{-2}}")#text(", and pointing in a ")#mi("{\\delta}")#text("-separated set of directions, then the union ")#mi("{\\bigcup_{T \\in \\mathbb{T}} T}")#text(" of these tubes should have volume ")#mi("{\\approx 1}")#text(". Here we shall be a little vague as to what ")#mi("{\\approx}")#text(" means here, but roughly one should think of this as “up to factors of the form ")#mi("{O_\\varepsilon(\\delta^{-\\varepsilon})}")#text(" for any ")#mi("{\\varepsilon>0}")#text("“; in particular this notation can absorb any logarithmic losses that might arise for instance from a dyadic pigeonholing argument. For technical reasons (including the need to invoke the aforementioned dyadic pigeonholing), one actually works with slightly smaller sets ")#mi("{\\bigcup_{T \\in \\mathbb{T}} Y(T)}")#text(", where ")#mi("{Y}")#text(" is a “shading” of the tubes in ")#mi("{\\mathbb{T}}")#text(" that assigns a large subset ")#mi("{Y(T)}")#text(" of ")#mi("{T}")#text(" to each tube ")#mi("{T}")#text(" in the collection; but for this discussion we shall ignore this subtlety and pretend that we can always work with the full tubes.")

#text("Previous results in this area tended to center around lower bounds of the form ")#metadata(none) <tao-f41a2056162829ad896d>#tao-math("\\displaystyle  \\left|\\bigcup_{T \\in \\mathbb{T}} T\\right| \\gtrapprox \\delta^{3-d} \\ \\ \\ \\ \\ (1)", block: false)#text(" ")#text(" for various intermediate dimensions ")#mi("{0 < d < 3}")#text(", that one would like to make as large as possible. For instance, just from considering a single tube in this collection, one can easily establish ")#link(<tao-f41a2056162829ad896d>)[#text("(1)")]#text(" with ")#mi("{d=1}")#text(". By just using the fact that two lines in ")#mi("{{\\bf R}^3}")#text(" intersect in a point (or more precisely, a more quantitative estimate on the volume between the intersection of two ")#mi("{\\delta \\times \\delta \\times 1}")#text(" tubes, based on the angle of intersection), combined with a now classical ")#mi("{L^2}")#text("-based argument of Córdoba, one can obtain ")#link(<tao-f41a2056162829ad896d>)[#text("(1)")]#text(" with ")#mi("{d=2}")#text(" (and this type of argument also resolves the Kakeya conjecture in two dimensions). In 1995, building on earlier work by Bourgain, ")#link("https://zbmath.org/0848.42015")[#text("Wolff famously obtained")]#text(" ")#link(<tao-f41a2056162829ad896d>)[#text("(1)")]#text(" with ")#mi("{d=2.5}")#text(" using what is now known as the “Wolff hairbrush argument”, based on considering the size of a “hairbrush” – the union of all the tubes that pass through a single tube (the hairbrush “stem”) in the collection.")

#text("In their new paper, Wang and Zahl established ")#link(<tao-f41a2056162829ad896d>)[#text("(1)")]#text(" for ")#mi("{d=3}")#text(". The proof is lengthy (127 pages!), and relies crucially on ")#link("https://arxiv.org/abs/2210.09581")[#text("their previous paper")]#text(" establishing a key “sticky” case of the conjecture. Here, I thought I would try to summarize the high level strategy of proof, omitting many details and also oversimplifying the argument at various places for sake of exposition. The argument does use many ideas from previous literature, including some from my own papers with co-authors; but the case analysis and iterative schemes required are remarkably sophisticated and delicate, with multiple new ideas needed to close the full argument.")

#text("A natural strategy to prove ")#link(<tao-f41a2056162829ad896d>)[#text("(1)")]#text(" would be to try to induct on ")#mi("{d}")#text(": if we let ")#mi("{K(d)}")#text(" represent the assertion that ")#link(<tao-f41a2056162829ad896d>)[#text("(1)")]#text(" holds for all configurations of ")#mi("{\\approx \\delta^{-2}}")#text(" tubes of dimensions ")#mi("{\\delta \\times \\delta \\times 1}")#text(", with ")#mi("{\\delta}")#text("-separated directions, we could try to prove some implication of the form ")#mi("{K(d) \\implies K(d + \\alpha)}")#text(" for all ")#mi("{0 < d < 3}")#text(", where ")#mi("{\\alpha>0}")#text(" is some small positive quantity depending on ")#mi("{d}")#text(". Iterating this, one could hope to get ")#mi("{d}")#text(" arbitrarily close to ")#mi("{3}")#text(".")

#text("A general principle with these sorts of continuous induction arguments is to first obtain the trivial implication ")#mi("{K(d) \\implies K(d)}")#text(" in a non-trivial fashion, with the hope that this non-trivial argument can somehow be perturbed or optimized to get the crucial improvement ")#mi("{K(d) \\implies K(d+\\alpha)}")#text(". The standard strategy for doing this, since the work of Bourgain and then Wolff in the 1990s (with precursors in older work of Córdoba), is to perform some sort of “induction on scales”. Here is the basic idea. Let us call the ")#mi("{\\delta \\times \\delta \\times 1}")#text(" tubes ")#mi("{T}")#text(" in ")#mi("{\\mathbb{T}}")#text(" “thin tubes”. We can try to group these thin tubes into “fat tubes” of dimension ")#mi("{\\rho \\times \\rho \\times 1}")#text(" for some intermediate scale ")#mi("{\\delta \\ll \\rho \\ll 1}")#text("; it is not terribly important for this sketch precisely what intermediate value is chosen here, but one could for instance set ")#mi("{\\rho = \\sqrt{\\delta}}")#text(" if desired. Because of the ")#mi("{\\delta}")#text("-separated nature of the directions in ")#mi("{\\mathbb{T}}")#text(", there can only be at most ")#mi("{\\lessapprox (\\rho/\\delta)^{2}}")#text(" thin tubes in a given fat tube, and so we need at least ")#mi("{\\gtrapprox \\rho^{-2}}")#text(" fat tubes to cover the ")#mi("{\\approx \\delta^{-2}}")#text(" thin tubes. Let us suppose for now that we are in the “sticky” case where the thin tubes stick together inside fat tubes as much as possible, so that there are in fact a collection ")#mi("{\\mathbb{T}_\\rho}")#text(" of ")#mi("{\\approx \\rho^{-2}}")#text(" fat tubes ")#mi("{T_\\rho}")#text(", with each fat tube containing about ")#mi("{\\approx (\\rho/\\delta)^{2}}")#text(" of the thin tubes. Let us also assume that the fat tubes ")#mi("{T_\\rho}")#text(" are ")#mi("{\\rho}")#text("-separated in direction, which is an assumption which is highly consistent with the other assumptions made here.")

#text("If we already have the hypothesis ")#mi("{K(d)}")#text(", then by applying it at scale ")#mi("{\\rho}")#text(" instead of ")#mi("{\\delta}")#text(" we conclude a lower bound on the volume occupied by fat tubes:")

#align(center)[#tao-fit-display[#tao-math("\\left|\\bigcup_{T_\\rho \\in \\mathbb{T}_\\rho} T_\\rho\\right| \\gtrapprox \\rho^{3-d}.", block: true)]]

#text("Since ")#tao-math("{\\sum_{T_\\rho \\in \\mathbb{T}_\\rho} \\left|T_\\rho\\right| \\approx \\rho^{-2} \\rho^2 = 1}", block: false)#text(", this morally tells us that the typical multiplicity ")#mi("{\\mu_{fat}}")#text(" of the fat tubes is ")#mi("{\\lessapprox \\rho^{d-3}}")#text("; a typical point in ")#mi("{\\bigcup_{T_\\rho \\in \\mathbb{T}_\\rho} T_\\rho}")#text(" should belong to about ")#mi("{\\mu_{fat} \\lessapprox \\rho^{d-3}}")#text(" fat tubes.")

#text("Now, inside each fat tube ")#mi("{T_\\rho}")#text(", we are assuming that we have about ")#mi("{\\approx (\\rho/\\delta)^{2}}")#text(" thin tubes that are ")#mi("{\\delta}")#text("-separated in direction. If we perform a linear rescaling around the axis of the fat tube by a factor of ")#mi("{1/\\rho}")#text(" to turn it into a ")#mi("{1 \\times 1 \\times 1}")#text(" tube, this would inflate the thin tubes to be rescaled tubes of dimensions ")#mi("{\\delta/\\rho \\times \\delta/\\rho \\times 1}")#text(", which would now be ")#mi("{\\approx \\delta/\\rho}")#text("-separated in direction. This rescaling does not affect the multiplicity of the tubes. Applying ")#mi("{K(d)}")#text(" again, we see morally that the multiplicity ")#mi("{\\mu_{fine}}")#text(" of the rescaled tubes, and hence the thin tubes inside ")#mi("{T_\\rho}")#text(", should be ")#mi("{\\lessapprox (\\delta/\\rho)^{d-3}}")#text(".")

#text("We now observe that the multiplicity ")#mi("{\\mu}")#text(" of the full collection ")#mi("{\\mathbb{T}}")#text(" of thin tubes should morally obey the inequality ")#metadata(none) <tao-5441d0099848706dbdc0>#mi("\\displaystyle  \\mu \\lessapprox \\mu_{fat} \\mu_{fine}, \\ \\ \\ \\ \\ (2)")#text(" ")#text(" since if a given point lies in at most ")#mi("{\\mu_{fat}}")#text(" fat tubes, and within each fat tube a given point lies in at most ")#mi("{\\mu_{fine}}")#text(" thin tubes in that fat tube, then it should only be able to lie in at most ")#mi("{\\mu_{fat} \\mu_{fine}}")#text(" tubes overall. This heuristically gives ")#mi("{\\mu \\lessapprox \\rho^{d-3} (\\delta/\\rho)^{d-3} = \\delta^{d-3}}")#text(", which then recovers ")#link(<tao-f41a2056162829ad896d>)[#text("(1)")]#text(" in the sticky case.")

#text("In ")#link("https://arxiv.org/abs/2210.09581")[#text("their previous paper")]#text(", Wang and Zahl were roughly able to squeeze a little bit more out of this argument to get something resembling ")#mi("{K(d) \\implies K(d+\\alpha)}")#text(" in the sticky case, loosely following a strategy of Nets Katz and myself that I discussed in ")#link("https://terrytao.wordpress.com/2014/05/07/stickiness-graininess-planiness-and-a-sum-product-approach-to-the-kakeya-problem/")[#text("this previous blog post")]#text(" from over a decade ago. I will not discuss this portion of the argument further here, referring the reader to the introduction to that paper; instead, I will focus on the arguments in the current paper, which handle the non-sticky case.")

#text("Let’s try to repeat the above analysis in a non-sticky situation. We assume ")#mi("{K(d)}")#text(" (or some suitable variant thereof), and consider some thickened Kakeya set")

#align(center)[#tao-fit-display[#mitex("E = \\bigcup_{T \\in {\\mathbb T}} T")]]

#text("where ")#mi("{{\\mathbb T}}")#text(" is something resembling what we might call a “Kakeya configuration” at scale ")#mi("{\\delta}")#text(": a collection of ")#mi("{\\delta^{-2}}")#text(" thin tubes of dimension ")#mi("{\\delta \\times \\delta \\times 1}")#text(" that are ")#mi("{\\delta}")#text("-separated in direction. (Actually, to make the induction work, one has to consider a more general family of tubes than these, satisfying some standard “Wolff axioms” instead of the direction separation hypothesis; but we will gloss over this issue for now.) Our goal is to prove something like ")#mi("{K(d+\\alpha)}")#text(" for some ")#mi("{\\alpha>0}")#text(", which amounts to obtaining some improved volume bound")

#align(center)[#tao-fit-display[#tao-math("\\left|E\\right| \\gtrapprox \\delta^{3-d-\\alpha}", block: true)]]

#text("that improves upon the bound ")#tao-math("{\\left|E\\right| \\gtrapprox \\delta^{3-d}}", block: false)#text(" coming from ")#mi("{K(d)}")#text(". From the previous paper we know we can do this in the “sticky” case, so we will assume that ")#mi("{E}")#text(" is “non-sticky” (whatever that means).")

#text("A typical non-sticky setup is when there are now ")#mi("{m \\rho^{-2}}")#text(" fat tubes for some multiplicity ")#mi("{m \\ggg 1}")#text(" (e.g., ")#mi("{m = \\delta^{-\\eta}}")#text(" for some small constant ")#mi("{\\eta>0}")#text("), with each fat tube containing only ")#mi("{m^{-1} (\\delta/\\rho)^{-2}}")#text(" thin tubes. Now we have an unfortunate imbalance: the fat tubes form a “super-Kakeya configuration”, with too many tubes at the coarse scale ")#mi("{\\rho}")#text(" for them to be all ")#mi("{\\rho}")#text("-separated in direction, while the thin tubes inside a fat tube form a “sub-Kakeya configuration” in which there are not enough tubes to cover all relevant directions. So one cannot apply the hypothesis ")#mi("{K(d)}")#text(" efficiently at either scale.")

#text("This looks like a serious obstacle, so let’s change tack for a bit and think of a different way to try to close the argument. Let’s look at how ")#mi("{E}")#text(" intersects a given ")#mi("{\\rho}")#text("-ball ")#mi("{B(x,\\rho)}")#text(". The hypothesis ")#mi("{K(d)}")#text(" suggests that ")#mi("{E}")#text(" might behave like a ")#mi("{d}")#text("-dimensional fractal (thickened at scale ")#mi("{\\delta}")#text("), in which case one might be led to a predicted size of ")#mi("{E \\cap B(x,\\rho)}")#text(" of the form ")#mi("{(\\rho/\\delta)^d \\delta^3}")#text(". Suppose for sake of argument that the set ")#mi("{E}")#text(" was denser than this at this scale, for instance we have ")#metadata(none) <tao-ad0634ada6af58d6c71b>#tao-math("\\displaystyle  \\left|E \\cap B(x,\\rho)\\right| \\gtrapprox (\\rho/\\delta)^d \\delta^{3-\\alpha} \\ \\ \\ \\ \\ (3)", block: false)#text(" ")#text(" for all ")#mi("{x \\in E}")#text(" and some ")#mi("{\\alpha>0}")#text(". Observe that the ")#mi("{\\rho}")#text("-neighborhood ")#mi("{E}")#text(" is basically ")#mi("{\\bigcup_{T_\\rho \\in {\\mathbb T}_\\rho} T_\\rho}")#text(", and thus has volume ")#mi("{\\gtrapprox \\rho^{3-d}}")#text(" by the hypothesis ")#mi("{K(d)}")#text(" (indeed we would even expect some gain in ")#mi("{m}")#text(", but we do not attempt to capture such a gain for now). Since ")#mi("{\\rho}")#text("-balls have volume ")#mi("{\\approx \\rho^3}")#text(", this should imply that ")#mi("{E}")#text(" needs about ")#mi("{\\gtrapprox \\rho^{-d}}")#text(" balls to cover it. Applying ")#link(<tao-ad0634ada6af58d6c71b>)[#text("(3)")]#text(", we then heuristically have")

#align(center)[#tao-fit-display[#tao-math("\\left|E\\right| \\gtrapprox \\rho^{-d} \\times (\\rho/\\delta)^d \\delta^{3-\\alpha} = \\delta^{3-d-\\alpha}", block: true)]]

#text("which would give the desired gain ")#mi("{K(d+\\alpha)}")#text(". So we win if we can exhibit the condition ")#link(<tao-ad0634ada6af58d6c71b>)[#text("(3)")]#text(" for some intermediate scale ")#mi("{\\rho}")#text(". I think of this as a “Frostman measure violation”, in that the ")#link("https://en.wikipedia.org/wiki/Frostman_lemma")[#text("Frostman type bound")]

#align(center)[#tao-fit-display[#tao-math("\\left|E \\cap B(x,\\rho)\\right| \\lessapprox (\\rho/\\delta)^d \\delta^3", block: true)]]

#text("is being violated.")

#text("The set ")#mi("{E}")#text(", being the union of tubes of thickness ")#mi("{\\delta}")#text(", is essentially the union of ")#mi("{\\delta \\times \\delta \\times \\delta}")#text(" cubes. But it has been observed in several previous works (starting ")#link("https://zbmath.org/1005.42009")[#text("with a paper of Nets Katz, Izabella Laba, and myself")]#text(") that these Kakeya type sets tend to organize themselves into larger “grains” than these cubes – in particular, they can organize into ")#mi("{\\delta \\times c \\times c}")#text(" disjoint prisms (or “grains”) in various orientations for some intermediate scales ")#mi("{\\delta \\lll c \\ll 1}")#text(". The original “graininess” argument of Nets, Izabella and myself required a stickiness hypothesis which we are explicitly not assuming (and also an “x-ray estimate”, though Wang and Zahl were able to find a suitable substitute for this), so is not directly available for this argument; however, there is an alternate approach to graininess ")#link("https://zbmath.org/1358.52011")[#text("developed by Guth")]#text(", based on the polynomial method, that can be adapted to this setting. (I am told that Guth has a way to obtain this graininess reduction for this paper without invoking the polynomial method, but I have not studied the details.) With rescaling, we can ensure that the thin tubes inside a single fat tube ")#mi("{T_\\rho}")#text(" will organize into grains of a rescaled dimension ")#mi("{\\delta \\times \\rho c \\times c}")#text(". The grains associated to a single fat tube will be essentially disjoint; but there can be overlap between grains from different fat tubes.")

#text("The exact dimensions ")#mi("{\\rho c, c}")#text(" of the grains are not specified in advance; the argument of Guth will show that ")#mi("{\\rho c}")#text(" is significantly larger than ")#mi("{\\delta}")#text(", but other than that there are no bounds. But in principle we should be able to assume without loss of generality that the grains are as “large” as possible. This means that there are no longer grains of dimensions ")#mi("{\\delta \\times \\rho^{\\prime} c^{\\prime} \\times c^{\\prime}}")#text(" with ")#mi("{c^{\\prime}}")#text(" much larger than ")#mi("{c}")#text("; and for fixed ")#mi("{c}")#text(", there are no wider grains of dimensions ")#mi("{\\delta \\times \\rho^{\\prime} c \\times c}")#text(" with ")#mi("{\\rho^{\\prime}}")#text(" much larger than ")#mi("{\\rho}")#text(".")

#text("One somewhat degenerate possibility is that there are enormous grains of dimensions approximately ")#mi("{\\delta \\times 1 \\times 1}")#text(" (i.e., ")#mi("{\\rho \\approx c \\approx 1}")#text("), so that the Kakeya set ")#mi("{E}")#text(" becomes more like a union of planar slabs. Here, it turns out that the classical ")#mi("{L^2}")#text(" arguments of Córdoba give good estimates, so this turns out to be a relatively easy case. So we can assume that least one of ")#mi("{\\rho}")#text(" or ")#mi("{c}")#text(" is small (or both).")

#text("We now revisit the multiplicity inequality ")#link(<tao-5441d0099848706dbdc0>)[#text("(2)")]#text(". There is something slightly wasteful about this inequality, because the fat tubes used to define ")#mi("{\\mu_{fat}}")#text(" occupy a lot of space that is not in ")#mi("{E}")#text(". An improved inequality here is ")#metadata(none) <tao-57ab877770c87c2bfbd5>#mi("\\displaystyle  \\mu \\lessapprox \\mu_{coarse} \\mu_{fine}, \\ \\ \\ \\ \\ (4)")#text(" ")#text(" where ")#mi("{\\mu_{coarse}}")#text(" is the multiplicity, not of the fat tubes ")#mi("{T_\\rho}")#text(", but rather of the smaller set ")#mi("{\\bigcup_{T \\subset T_\\rho} T}")#text(". The point here is that by the graininess hypotheses, each ")#mi("{\\bigcup_{T \\subset T_\\rho} T}")#text(" is the union of essentially disjoint grains of some intermediate dimensions ")#mi("{\\delta \\times \\rho c \\times c}")#text(". So the quantity ")#mi("{\\mu_{coarse}}")#text(" is basically measuring the multiplicity of the grains.")

#text("It turns out that after a suitable rescaling, the arrangement of grains looks locally like an arrangement of ")#mi("{\\rho \\times \\rho \\times 1}")#text(" tubes. If one is lucky, these tubes will look like a Kakeya (or sub-Kakeya) configuration, for instance with not too many tubes in a given direction. (More precisely, one should assume here some form of the Wolff axioms, which the authors refer to as the “Katz-Tao Convex Wolff axioms”). A suitable version if the hypothesis ")#mi("{K(d)}")#text(" will then give the bound")

#align(center)[#tao-fit-display[#mitex("\\mu_{coarse} \\lessapprox \\rho^{-d}.")]]

#text("Meanwhile, the thin tubes inside a fat tube are going to be a sub-Kakeya configuration, having about ")#mi("{m}")#text(" times fewer tubes than a Kakeya configuration. It turns out to be possible to use ")#mi("{K(d)}")#text(" to then get a gain in ")#mi("{m}")#text(" here,")

#align(center)[#tao-fit-display[#mitex("\\mu_{fine} \\lessapprox m^{-\\sigma} (\\delta/\\rho)^{-d},")]]

#text("for some small constant ")#mi("{\\sigma>0}")#text(". Inserting these bounds into ")#link(<tao-57ab877770c87c2bfbd5>)[#text("(4)")]#text(", one obtains a good bound ")#mi("{\\mu \\lessapprox m^{-\\sigma} \\delta^{-d}}")#text(" which leads to the desired gain ")#mi("{K(d+\\alpha)}")#text(".")

#text("So the remaining case is when the grains do not behave like a rescaled Kakeya or sub-Kakeya configuration. Wang and Zahl introduce a “structure theorem” to analyze this case, concluding that the grains will organize into some larger convex prisms ")#mi("{W}")#text(", with the grains in each prism ")#mi("{W}")#text(" behaving like a “super-Kakeya configuration” (with significantly more grains than one would have for a Kakeya configuration). However, the precise dimensions of these prisms ")#mi("{W}")#text(" is not specified in advance, and one has to split into further cases.")

#text("One case is when the prisms ")#mi("{W}")#text(" are “thick”, in that all dimensions are significantly greater than ")#mi("{\\delta}")#text(". Informally, this means that at small scales, ")#mi("{E}")#text(" looks like a super-Kakeya configuration after rescaling. With a somewhat lengthy induction on scales argument, Wang and Zahl are able to show that (a suitable version of) ")#mi("{K(d)}")#text(" implies an “x-ray” version of itself, in which the lower bound of super-Kakeya configurations is noticeably better than the lower bound for Kakeya configurations. The upshot of this is that one is able to obtain a Frostman violation bound of the form ")#link(<tao-ad0634ada6af58d6c71b>)[#text("(3)")]#text(" in this case, which as discussed previously is already enough to win in this case.")

#text("It remains to handle the case when the prisms ")#mi("{W}")#text(" are “thin”, in that they have thickness ")#mi("{\\approx \\delta}")#text(". In this case, it turns out that the ")#mi("{L^2}")#text(" arguments of Córdoba, combined with the super-Kakeya nature of the grains inside each of these thin prisms, implies that each prism is almost completely occupied by the set ")#mi("{E}")#text(". In effect, this means that these prisms ")#mi("{W}")#text(" themselves can be taken to be grains of the Kakeya set. But this turns out to contradict the maximality of the dimensions of the grains (if everything is set up properly). This treats the last remaining case needed to close the induction on scales, and obtain the Kakeya conjecture!")

#heading(level: 1)[#text("Comments (44)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687399")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2025")])]

#text("Thanks for this!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687400")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2025")])]

#text("” crucial improvement")

#link("https://s0.wp.com/latex.php?latex=%7BK%28d%29+%5Cimplies+K%28d%29%7D&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%7BK%28d%29+%5Cimplies+K%28d%29%7D&bg=ffffff&fg=000000&s=0&c=20201002")]

#text(".”")

#text("I think this is a typo.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687401")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2025")])]

#text("For the upper bounds on mu_{fat} and mu_{fine} above and below (2), should the exponent 3-d instead be d-3?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687403")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2025")])]

#text("yay for Kakeya")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687404")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2025")])]

#text("Which other conjectures are also closed by this conjecture?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687421")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("In the paper, Wang and Zahl show that their methods also establish the tube doubling conjecture of Keleti: if an arbitrary collection of ")#mi("\\delta \\times \\delta \\times 1")#text(" tubes is doubled in all spatial dimensions, then the volume of the union only increases by a factor of ")#mi("\\approx 1")#text(".")

#text("In principle, this breakthrough could lead to progress on the other conjectures in the Kakeya cluster, such as the Bochner-Riesz and restriction conjectures, but this would probably require improving the Kakeya set results here to a Kakeya maximal function estimate, as well as more technical “Furstenberg set” variants of the conjecture (roughly speaking, in which one has a fractal subset of a line segment in every direction, rather than a full line segment or some fixed measure subset of that line segment).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687405")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("Thank you for the accessible explanation. I learned a lot.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687406")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("How similar is the d = 3 case to higher d, and do arguments in this case improve bounds in the higher case?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687417")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("Some of the basic framework (e.g., induction on scales) would carry over, but much of the case analysis would become more complicated. In the three-dimensional situation, whenever one of the dimensions degenerated in some fashion, the problem was then similar to a two-dimensional one, and one could turn to the L^2 methods of Cordoba to good effect. If one was say in four dimensions, then to treat such degenerate cases one would need three-dimensional analysis – that is to say, one would need to adapt the methods of the current paper. In principle if one had exactly the right induction hypothesis in the ambient dimension, one could then get Kakeya estimates in all dimensions, but finding precisely the right hypothesis for which the induction will close might take some time to work out. But I think this will get done eventually; the obstructions I see to extending to higher dimensions are primarily technical in nature, rather than fundamental obstacles (though there could be some nasty unfavorable surprises in the exponent numerology when one tries to execute the strategy carefully).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687410")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("How difficult would it be to formalize the proof in Lean compared to your earlier project, where you formalized the proof of PFR in Lean4?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687416")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("I would imagine this to be several times larger in magnitude than the ")#link("https://github.com/fpvandoorn/carleson")[#text("Carleson formalization project")]#text(", which is currently ongoing and expected to take months (with dozens of people involved). When combined with previous papers, we are looking at something like 200 to 300 pages of literature, which needs to be expanded further into a detailed blueprint. I think it is theoretically possible to do at the current state of formalization technology if we divert significant mathematical resources to this goal, but it may be better to wait on this one until the technology improves and/or the proof simplifies.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687411")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("Really excited to see this cracked! It is the culmination of dozens of papers and years of research that at least. I suppose now trying to extend this to Restriction will be attempted? Not getting the maximal function estimate shows the difficulty of the problem.")

#text("It is impressive, to me at least, how non-intuitive the argument is. A remarkable amount of effort and perseverance must have gone into the proof. Typing 127 pages of Tex is a feat in and of itself")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37432c98750e4022b84c1e02476ca47a145927ff594ef0eb39e820fe7e06b425-ce55d07280b037e17918e2e1908cc9c00ecabf3d55d9d47936fe5043346ccd52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687412")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("The equation immediately after the phrase “the crucial improvement” does not actually include the crucial improvement and instead is identical to the previous equation.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fe491592c06969ffd720fbc139cdcec7f12d5e09ee34700ed21ed254daafdef-d994cecf772ce8765fa0545e561e41806b2971f5b04296e2e002478b70e4beee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of basementcolorful451c5cd9f3")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687420")[#strong[#text("basementcolorful451c5cd9f3")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("Hong Wang should be awarded by the Fields Medal in next year for what she achieved in past several years. She is a truly amazing mathematician!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687423")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("There are several instances of (rho/delta)^(-2) that should say (rho/delta)^2 when talking about the number of thin tubes in a fat tube.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687430")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("I vaguely recall there is some connection between the Kakeya conjecture and large value estimates for Dirichlet polynomials. How much of the Kakeya conjecture needs to be proved in order to get new large values estimates? Does one need the Kakeya conjecture in every dimension? Does one need “hard” versions of the conjecture as opposed to “soft” versions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687431")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("See for instance this ")#link("https://mathoverflow.net/questions/137635/a-reference-for-this-possibly-well-known-fact-concerning-the-kakeya-conjecture")[#text("MathOverflow question and answer")]#text(". The Montgomery conjecture implies the Kakeya conjecture for arithmetic progressions, which implies the Kakeya conjecture in all dimensions, which of course implies the Kakeya conjecture in three dimensions. So the new breakthrough will not immediately make any progress on the Montgomery conjecture, but it does raise one’s hopes that some advance will be made on these stronger conjectures also in coming years.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687441")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2025")])]

#text("Following up on the 2014 paper “Degree reduction and graininess for Kakeya-type sets in ")#mi("\\mathbb{R}^3")#text(" ” and specifically Theorem 0.1, which seems to play a crucial role in degree reduction for the 3D Kakeya conjecture, I’ve been searching on Google Scholar for subsequent citations or extensions, but haven’t found explicit high-dimensional generalizations directly related to this 2014 work. I’m unsure if this type of structural theorem has been extended to higher dimensions.")

#text("I was wondering if the absence of such a generalization is considered a major obstacle in tackling the Kakeya conjecture in higher dimensions?")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687442")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2025")])]

#text("My guess is that the lack of an optimal 3D Kakeya theory was an obstacle to extending graininess type results to higher dimensions, but now that we have at least one 3D Kakeya result with an optimal exponent, it should now be possible *in principle* to start getting higher dimensional results. Of course, this 3D theory is vastly more complicated than the optimal 2D theory of Cordoba that is largely based on L^2 estimates (second moment method), so it will take some time to work out even the 4D case I think. But I don’t see any fundamental obstacles, only (significant) technical challenges.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/550881157acd11d04eb741d9fb16999a423187117cf93144b8dcb4c3136318e6-c4d1eab40b306ad6059e70a2fec08bf13a6e417436ac2b2b4151a5d9abfc8f55.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josh")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687443")[#strong[#text("Josh")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2025")])]

#text("Proposition 3.2 from [1] is a higher dimensional grains decomposition similar in spirit to Guth’s previous work in R^3. In higher dimensions, the grains need not be pieces of (hyper)planes. Proposition 3.2 only asserts that the grains are thin neighbourhoods of low-degree algebraic hypersurfaces. In R^4 a bit more is known, compared to R^n — heuristically, the grains must be either hyperplanes, quadratic hypersurfaces, or algebraic hypersurfaces that are ruled by 2-planes.")

#text("[1] ")#link("https://arxiv.org/abs/1701.07045")[#text("https://arxiv.org/abs/1701.07045")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687446")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2025")])]

#text("Congratulations to Josh and Hong Wang for this spectacular work. Seeing their gradual progress on the problem over the last five years I expected they could do this. But still seeing the completion of it was a beautiful surprise.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687464")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2025")])]

#text("Hi Professor Tao. It seems there is a similar-flavor question called Nikodym (set) problem whose dim 2 case is also solved for a long time. ")#linebreak()#text("Is there any higher dimensional results for this problem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687466")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2025")])]

#text("The Kakeya set conjecture implies the Nikodym set conjecture as a corollary (this is a simple argument coming from applying a projective transformation to convert a Nikodym set into a Kakeya set). The converse isn’t quite a known implication (though the “maximal function” version of the two conjectures are known to be equivalent), but nevertheless the two conjectures are believed to be of essentially the same level of difficulty. I discussed this issue in Section 4 of ")#link("https://projecteuclid.org/journals/duke-mathematical-journal/volume-96/issue-2/The-Bochner-Riesz-conjecture-implies-the-restriction-conjecture/10.1215/S0012-7094-99-09610-2.short")[#text("this old paper of mine")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687488")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2025")])]

#text("Wrong paper link?")

#emph[#text("[I don’t believe so -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687493")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2025")])]

#text("Thank you for answering the question!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687465")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2025")])]

#text("When was the Kakeya set conjecture posed? 1930s?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687467")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2025")])]

#text("The Kakeya needle problem was proposed in 1917, and Kakeya sets (initially referred to as Besicovitch sets, as Besicovitch was the first to construct them) were introduced as a concept in 1919, but the question of the dimension of such sets was not explicitly addressed until the work of Davies in 1971, who referred to it as the “Kakeya problem”. The precise terminology of the “Kakeya set conjecture” was likely introduced by Bourgain in the early 1990s.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687470")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2025")])]

#text("A noob passing by with a stupid question….")

#text("I’ve only been introduced to the ‘squeegee’ approach by Mathologer (")#link("https://www.youtube.com/watch?v=IM-n9c-ARHU&t=804s")[#text("https://www.youtube.com/watch?v=IM-n9c-ARHU&t=804s")]#text("). Can yall help me understand, how using ‘tubes’ can even go lower? Did Wang and Zahl just prove that it is infinitesimal?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687472")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2025")])]

#text("The Kakeya set problem is related to the Kakeya needle problem, but technically the two problems are distinct. The needle problem concerns the problem of trying to rotate a needle of zero thickness in as small a set as possible to cover all orientations. The Kakeya set problem (in its Minkowski dimension formulation) can be phrased as a problem of understanding how to pack tubes of small but non-zero thickness ")#mi("\\delta")#text(" in different orientations in as small a set as possible. Besicovitch showed for the set problem that the minimum area (in two dimensions) or volume (in three dimensions) required for the latter problem goes to zero in the limit ")#mi("\\delta \\to 0")#text(", which by some additional arguments shows that the area required for the Kakeya needle problem also can be made as small as possible. The question then remained of how fast this convergence to zero was as a function of ")#mi("\\delta")#text(" – in particular, whether it was basically a power law in ")#mi("\\delta")#text(", or whether the convergence was more logarithmic in nature. It was shown by Davies in 1971 that the latter scenario was the truth in two dimensions; and now we basically know it to be true in three dimensions also (although the convergence rate is not known to be precisely logarithmic; currently we just know that it is slower than a power law convergence rate).")

#text("This does not directly impact the original Kakeya needle problem, which was set in two dimensions, but from a modern perspective the needle problem was more of a historical motivation for the Kakeya family of conjectures than the primary focus of current research.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687481")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2025")])]

#text("Can you expand on the historical motivation part?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687486")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2025")])]

#text("I have some old surveys on this topic, e.g., ")#link("https://www.ams.org/notices/200103/fea-tao.pdf")[#text("https://www.ams.org/notices/200103/fea-tao.pdf")]#text(" ")#link("http://www.math.ucla.edu/~tao/preprints/Expository/edinburgh.dvi")[#text("http://www.math.ucla.edu/~tao/preprints/Expository/edinburgh.dvi")]#text(" ")#link("https://arxiv.org/abs/math/0010069")[#text("https://arxiv.org/abs/math/0010069")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687515")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2025")])]

#text("Is there a conjectural analogue of a more generalized “Furstenberg-type arithmetic Kakeya” and would such a result imply the Montgomery conjecture? It would be mildly amusing if this recent progress in Kakeya eventually leads to the resolution of RH, but one can only dream…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687516")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2025")])]

#text("At this stage I do not think there is any such proposal, though it is tempting to contemplate such a conjecture as a possible route to resolving the Montgomery conjecture. The recent advances on restriction and Kakeya have relied quite heavily on the geometry of Euclidean space, and specifically three dimensional space. It is possible that the geometric structure is actually a red herring, and that one may be able to run the induction on scales etc. in a much more arithmetic setting (replacing convex bodies by approximate groups, etc.). Perhaps after the recent progress is extended to arbitrary dimension, it will become clearer what is going on. (As a point against this approach, though, there are signs that in higher dimensions that higher degree geometric objects, such as quadric hypersurfaces, will inevitably show up, and at present additive combinatorics is not well equipped to even talk about these sorts of objects in a purely arithmetic fashion. As a wild speculation, one *might* be able to somehow reconstruct that sort of algebraic geometry structure from the incidence structure in the spirit of the group configuration theorem from model theory, but this is a rather large ask, especially given how other such proposals – e.g., an inverse Szemeredi-Trotter theorem that has some sort of algebraic structure in its conclusion – have no viable path to completion at present.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687517")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2025")])]

#text("This is a truly spectacular result by Hong and Josh!")

#text("I’m curious if you (or any of your readers) are aware of anything non-trivial known about Besicovitch constructions in higher dimensions? I’m unaware of any literature on this topic, or any construction that beats taking products of the Schoenberg-Keich two dimensional example which has logarithmic compression. There seems to be a bit of a paradox in that lower bounds get considerably harder to prove as the dimension increases yet (as far as I know) that extra freedom doesn’t seem to actually be very helpful in finding compression (for affine objects).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687536")[#strong[#text("\"Once In A Century\" Math Proof Threads The Needle On A Decades-Old Conjecture - 3ACES")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2025")]

#text("[…] preprint server, a wave of excitement rippled through the international mathematical community. Tao wrote about it on his blog; Katz lauded it as a “once-in-a-century kind of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687573")[#strong[#text("Hoe een naald kan draaien en kantelen in een onzichtbaar gebied")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2025")]

#text("[…] dan zou die onmogelijke eigenschappen moeten bezitten. Direct nadat het bewijs online kwam, reageerde Terence Tao op zijn blog enthousiast: „Hong Wang en Joshua Zahl hebben een preprint gepubliceerd die het driedimensionale […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687636")[#strong[#text("Aperiodical News Roundup – March 2025 | The Aperiodical")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2025")]

#text("[…] three-dimensional Kakeya set conjecture has been proved. The result is described by Terry Tao as “spectacular progress in geometric measure […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-687652")[#strong[#text("Hong Wang and Joshua Zahl’s Solution for Kakeya’s Problem in Three Dimensions – Reflections and Links | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2025")]

#text("[…] and Zahl’s spectacular work was described in Terry Tao’s blog, in an article by Joseph Howlett in Quanta Magazine, and in many other places. Congratulations to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-688534")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2025")])]

#text("Just read a Quanta article on Hannah Cairo’s resolution of the Mizohata-Takeuchi conjecture. Does Cairo’s result tell us anything about the Kakeya problem? I haven’t looked at her paper, maybe she answers that question. (I’m a curious bystander, not a mathematician.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-688574")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2025")])]

#text("Cairo’s work deals with another aspect of the Kakeya/restriction cluster of conjectures, roughly speaking it has to do with measuring how strong the effect of constructive interference between oscillations of different frequencies can be, and where these effects can be localized. Kakeya compression can give examples of such interference, but they are not the only source of such; and Cairo’s construction does not go through this route and so does not directly impact the Kakeya conjecture (which is already well understood in two dimensions anyways).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-688929")[#strong[#text("How to Make the Kakeya Conjecture Quantitative: A Guided Walk Through the Wang–Zahl Proof | Continuous Learning & Development")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2025")]

#text("[…] The three-dimensional Kakeya conjecture, after Wang and Zahl […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-693649")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2026")])]

#text("Thank you for the detailed explanation Professor TT")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/767607abb5da6fab39b4023f5479afc31bc368375956172d788e0090659635a4-72d4bdcf764f973f830cab7f43686b9e1619d5ed9da15acbaf734befd18c58f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jennifer suzuki")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-693750")[#strong[#text("jennifer suzuki")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2026")])]

#text("I’m so glad that a female mathematician has won the Fields Medal!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/767607abb5da6fab39b4023f5479afc31bc368375956172d788e0090659635a4-72d4bdcf764f973f830cab7f43686b9e1619d5ed9da15acbaf734befd18c58f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jennifer suzuki")]], [#link("https://terrytao.wordpress.com/2025/02/25/the-three-dimensional-kakeya-conjecture-after-wang-and-zahl/#comment-693858")[#strong[#text("jennifer suzuki")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2026")])]

#text("Being someone who does not work in the geometric measure theory, I of course had absolutely no ability to understand the original proof published by Wang-Zahl. I had attempted to read the streamlined proof published by Wang’s advisor Guth, and the only thing I was able to understand were the first few pages regarding notations and definitions. I got stuck once they mentioned Dyadic pigeonholing, which was something I have never heard before.")

#text("So after googling around, I came to understand that dyadic pigeonholing was invented by Terrence Tao, owner of the this blog, and that is why I am here.")

#text("I had attempted to read this blog several times, but, once again, I’m completely lost after just a few paragraphs.")

#text("The only paper I was able to fully comprehend was Hickman’s “The Kakeya Conjecture: where does it come from and why is it important?”")

#text("I initially thought that the paper by Hickman was written with a lay person in mind, and I eagerly read that and was fascinated by the paper. So I decided to share the paper with two friends, one is a theoretical physicist, and another one was a quant who graduated from MIT and worked in finance.")

#text("Neither of them was able to understand even the paper published by Hickman.")

#text("Apparently, to be able to follow the expository paper on Kakeya Conjecture by Hickman, you would still need a few years of graduate level math, have at least some familiarity with measure theory, harmonic analysis, etc.")

#text("It’s kind depressing, actually, that so much of the frontier of mathematical research is completely beyond the reach of “ordinary intellectuals.”")
]
