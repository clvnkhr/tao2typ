// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/03/23/some-ingredients-in-szemeredis-proof-of-szemeredis-theorem/
// Converted to Typst by tao2typ: "2026-10-14T09:24:31.714594+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Some ingredients in Szemerédi’s proof of Szemerédi’s theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Some ingredients in Szemerédi’s proof of Szemerédi’s theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 March 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/03/23/some-ingredients-in-szemeredis-proof-of-szemeredis-theorem/")[#text("https://terrytao.wordpress.com/2012/03/23/some-ingredients-in-szemeredis-proof-of-szemeredis-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A few days ago, ")#link("http://en.wikipedia.org/wiki/Endre_Szemer%C3%A9di")[#text("Endre Szemerédi")]#text(" ")#link("http://www.abelprize.no/c54147/seksjon/vis.html?tid=54148&strukt_tid=54147")[#text("was awarded the 2012 Abel prize")]#text(" “for his fundamental contributions to discrete mathematics and theoretical computer science, and in recognition of the profound and lasting impact of these contributions on additive number theory and ergodic theory.” The full citation for the prize may be ")#link("http://www.abelprize.no/c54147/binfil/download.php?tid=54063")[#text("found here")]#text(", and the written notes for a talk given by Tim Gowers on Endre’s work at the announcement ")#link("http://www.abelprize.no/c54147/binfil/download.php?tid=54060")[#text("may be found here")]#text(" (and video of the talk ")#link("http://www.abelprize.no/c53751/seksjon/vis.html?tid=53753")[#text("can be found here")]#text(").")

#text("As I was on the Abel prize committee this year, I won’t comment further on the prize, but will instead focus on what is arguably Endre’s most well known result, namely ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di%27s_theorem")[#text("Szemerédi’s theorem on arithmetic progressions")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Szemerédi’s theorem)")]#text(" Let ")#mi("{A}")#text(" be a set of integers of positive upper density, thus ")#tao-math("{\\lim \\sup_{N \\rightarrow\\infty} \\frac{\\left|A \\cap [-N,N]\\right|}{\\left|[-N,N]\\right|} > 0}", block: false)#text(", where ")#mi("{[-N,N] := \\{-N, -N+1,\\ldots,N\\}}")#text(". Then ")#mi("{A}")#text(" contains an arithmetic progression of length ")#mi("{k}")#text(" for any ")#mi("{k>1}")#text(".")
]

#text("Szemerédi’s original proof of this theorem is a remarkably intricate piece of combinatorial reasoning. Most proofs of theorems in mathematics – even long and difficult ones – generally come with a reasonably compact “high-level” overview, in which the proof is (conceptually, at least) broken down into simpler pieces. There may well be technical difficulties in formulating and then proving each of the component pieces, and then in fitting the pieces together, but usually the “big picture” is reasonably clear. To give just one example, the overall strategy of ")#link("http://en.wikipedia.org/wiki/Poincar%C3%A9_conjecture#Hamilton.27s_program_and_Perelman.27s_solution")[#text("Perelman’s proof of the Poincaré conjecture")]#text(" can be briefly summarised as follows: to show that a simply connected three-dimensional manifold is homeomorphic to a sphere, place a Riemannian metric on it and perform Ricci flow, excising any singularities that arise by surgery, until the entire manifold becomes extinct. By reversing the flow and analysing the surgeries performed, obtain enough control on the topology of the original manifold to establish that it is a topological sphere.")

#text("In contrast, the pieces of Szemerédi’s proof are highly interlocking, particularly with regard to all the epsilon-type parameters involved; it takes quite a bit of notational setup and foundational lemmas before the key steps of the proof can even be stated, let alone proved. ")#link("http://www.ams.org/mathscinet-getitem?mr=369312")[#text("Szemerédi’s original paper")]#text(" contains a logical diagram of the proof (reproduced in ")#link("http://www.abelprize.no/c54147/binfil/download.php?tid=54060")[#text("Gowers’ recent talk")]#text(") which already gives a fair indication of this interlocking structure. (Many years ago I ")#link("http://www.math.ucla.edu/~tao/preprints/Expository/szemeredi_theorem.dvi")[#text("tried to present the proof")]#text(", but I was unable to find much of a simplification, and my exposition is probably not that much clearer than the original text.) Even the use of ")#link("http://en.wikipedia.org/wiki/Non-standard_analysis")[#text("nonstandard analysis")]#text(", which is often helpful in cleaning up armies of epsilons, turns out to be a bit tricky to apply here. (In typical applications of nonstandard analysis, one can get by with a single nonstandard universe, constructed as an ultrapower of the standard universe; but to correctly model all the epsilons occuring in Szemerédi’s argument, one needs to repeatedly perform the ultrapower construction to obtain a (finite) sequence of increasingly nonstandard (and increasingly ")#link("http://en.wikipedia.org/wiki/Saturated_model")[#text("saturated")]#text(") universes, each one containing unbounded quantities that are far larger than any quantity that appears in the preceding universe, as discussed at the end of ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("this previous blog post")]#text(". This sequence of universes does end up concealing all the epsilons, but it is not so clear that this is a net gain in clarity for the proof; I may return to the nonstandard presentation of Szemeredi’s argument at some future juncture.)")

#text("Instead of trying to describe the entire argument here, I thought I would instead show some key components of it, with only the slightest hint as to how to assemble the components together to form the whole proof. In particular, I would like to show how two particular ingredients in the proof – namely ")#link("http://en.wikipedia.org/wiki/Van_der_Waerden's_theorem")[#text("van der Waerden’s theorem")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(" – become useful. For reasons that will hopefully become clearer later, it is convenient not only to work with ordinary progressions ")#mi("{P_1 = \\{ a, a+r_1, a+2r_1, \\ldots, a+(k_1-1)r_1\\}}")#text(", but also progressions of progressions ")#mi("{P_2 := \\{ P_1, P_1 + r_2, P_1+2r_2, \\ldots, P_1+(k_2-1)r_2\\}}")#text(", progressions of progressions of progressions, and so forth. (In additive combinatorics, these objects are known as ")#emph[#text("generalised arithmetic progressions")]#text(" of rank one, two, three, etc., and play a central role in the subject, although the way they are used in Szemerédi’s proof is somewhat different from the way that they are normally used in additive combinatorics.) Very roughly speaking, Szemerédi’s proof begins by building an enormous generalised arithmetic progression of high rank containing many elements of the set ")#mi("{A}")#text(" (arranged in a “near-maximal-density” configuration), and then steadily prunes this progression to improve the combinatorial properties of the configuration, until one ends up with a single rank one progression of length ")#mi("{k}")#text(" that consists entirely of elements of ")#mi("{A}")#text(".")

#text("To illustrate some of the basic ideas, let us first consider a situation in which we have located a progression ")#mi("{P, P + r, \\ldots, P+(k-1)r}")#text(" of progressions of length ")#mi("{k}")#text(", with each progression ")#mi("{P+ir}")#text(", ")#mi("{i=0,\\ldots,k-1}")#text(" being quite long, and containing a near-maximal amount of elements of ")#mi("{A}")#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\left|A \\cap (P+ir)\\right| \\approx \\delta \\left|P\\right|", block: true)]]

#text("where ")#tao-math("{\\delta := \\lim \\sup_{\\left|P\\right| \\rightarrow \\infty} \\frac{\\left|A \\cap P\\right|}{\\left|P\\right|}}", block: false)#text(" is the “maximal density” of ")#mi("{A}")#text(" along arithmetic progressions. (There are a lot of subtleties in the argument about exactly how good the error terms are in various approximations, but we will ignore these issues for the sake of this discussion and just use the imprecise symbols such as ")#mi("{\\approx}")#text(" instead.) By hypothesis, ")#mi("{\\delta}")#text(" is positive. The objective is then to locate a progression ")#mi("{a, a+r^{\\prime}, \\ldots,a+(k-1)r^{\\prime}}")#text(" in ")#mi("{A}")#text(", with each ")#mi("{a+ir}")#text(" in ")#mi("{P+ir}")#text(" for ")#mi("{i=0,\\ldots,k-1}")#text(". It may help to view the progression of progressions ")#mi("{P, P + r, \\ldots, P+(k-1)r}")#text(" as a tall thin rectangle ")#mi("{P \\times \\{0,\\ldots,k-1\\}}")#text(".")

#text("If we write ")#mi("{A_i := \\{ a \\in P: a+ir \\in A \\}}")#text(" for ")#mi("{i=0,\\ldots,k-1}")#text(", then the problem is equivalent to finding a (possibly degenerate) arithmetic progression ")#mi("{a_0,a_1,\\ldots,a_{k-1}}")#text(", with each ")#mi("{a_i}")#text(" in ")#mi("{A_i}")#text(".")

#text("By hypothesis, we know already that each set ")#mi("{A_i}")#text(" has density about ")#mi("{\\delta}")#text(" in ")#mi("{P}")#text(": ")#metadata(none) <tao-6b905c825ebff86a4a06>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|A_i \\cap P\\right| \\approx \\delta |P|.", block: true)]]

#text("Let us now make a “weakly mixing” assumption on the ")#mi("{A_i}")#text(", which roughly speaking asserts that ")#metadata(none) <tao-f95b812d3aca261fab7e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|A_i \\cap E\\right| \\approx \\delta \\sigma \\left|P\\right|", block: true)]]

#text("for “most” subsets ")#mi("{E}")#text(" of ")#mi("{P}")#text(" of density ")#mi("{\\approx \\sigma}")#text(" of a certain form to be specified shortly. This is a plausible type of assumption if one believes ")#mi("{A_i}")#text(" to behave like a random set, and if the sets ")#mi("{E}")#text(" are constructed “independently” of the ")#mi("{A_i}")#text(" in some sense. Of course, we do not expect such an assumption to be valid all of the time, but we will postpone consideration of this point until later. Let us now see how this sort of weakly mixing hypothesis could help one count progressions ")#mi("{a_0,\\ldots,a_{k-1}}")#text(" of the desired form.")

#text("We will inductively consider the following (nonrigorously defined) sequence of claims ")#mi("{C(i,j)}")#text(" for each ")#mi("{0 \\leq i \\leq j < k}")#text(":")

#list(
[#mi("{C(i,j)}")#text(": For most choices of ")#mi("{a_j \\in P}")#text(", there are ")#tao-math("{\\sim \\delta^i \\left|P\\right|}", block: false)#text(" arithmetic progressions ")#mi("{a_0,\\ldots,a_{k-1}}")#text(" in ")#mi("{P}")#text(" with the specified choice of ")#mi("{a_j}")#text(", such that ")#mi("{a_l \\in A_l}")#text(" for all ")#mi("{l=0,\\ldots,i-1}")#text(".")]
)

#text("(Actually, to avoid boundary issues one should restrict ")#mi("{a_j}")#text(" to lie in the middle third of ")#mi("{P}")#text(", rather than near the edges, but let us ignore this minor technical detail.) The quantity ")#tao-math("{\\delta^i \\left|P\\right|}", block: false)#text(" is natural here, given that there are ")#tao-math("{\\sim \\left|P\\right|}", block: false)#text(" arithmetic progressions ")#mi("{a_0,\\ldots,a_{k-1}}")#text(" in ")#mi("{P}")#text(" that pass through ")#mi("{a_i}")#text(" in the ")#mi("{i^{th}}")#text(" position, and that each one ought to have a probability of ")#mi("{\\delta^i}")#text(" or so that the events ")#mi("{a_0 \\in A_0, \\ldots, a_{i-1} \\in A_{i-1}}")#text(" simultaneously hold.) If one has the claim ")#mi("{C(k-1,k-1)}")#text(", then by selecting a typical ")#mi("{a_{k-1}}")#text(" in ")#mi("{A_{k-1}}")#text(", we obtain a progression ")#mi("{a_0,\\ldots,a_{k-1}}")#text(" with ")#mi("{a_i \\in A_i}")#text(" for all ")#mi("{i=0,\\ldots,k-1}")#text(", as required. (In fact, we obtain about ")#tao-math("{\\delta^k \\left|P\\right|^2}", block: false)#text(" such progressions by this method.)")

#text("We can heuristically justify the claims ")#mi("{C(i,j)}")#text(" by induction on ")#mi("{i}")#text(". For ")#mi("{i=0}")#text(", the claims ")#mi("{C(0,j)}")#text(" are clear just from direct counting of progressions (as long as we keep ")#mi("{a_j}")#text(" away from the edges of ")#mi("{P}")#text("). Now suppose that ")#mi("{i>0}")#text(", and the claims ")#mi("{C(i-1,j)}")#text(" have already been proven. For any ")#mi("{i \\leq j < k}")#text(" and for most ")#mi("{a_j \\in P}")#text(", we have from hypothesis that there are ")#tao-math("{\\sim \\delta^{i-1} \\left|P\\right|}", block: false)#text(" progressions ")#mi("{a_0,\\ldots,a_{k-1}}")#text(" in ")#mi("{P}")#text(" through ")#mi("{a_j}")#text(" with ")#mi("{a_0 \\in A_0,\\ldots,a_{i-2}\\in A_{i-2}}")#text(". Let ")#mi("{E = E(a_j)}")#text(" be the set of all the values of ")#mi("{a_{i-1}}")#text(" attained by these progressions, then ")#tao-math("{\\left|E\\right| \\sim \\delta^{i-1} \\left|P\\right|}", block: false)#text(". Invoking the weak mixing hypothesis, we (heuristically, at least) conclude that for most choices of ")#mi("{a_j}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|A_{i-1} \\cap E\\right| \\sim \\delta^i \\left|P\\right|", block: true)]]

#text("which then gives the desired claim ")#mi("{C(i,j)}")#text(".")

#text("The observant reader will note that we only needed the claim ")#mi("{C(i,j)}")#text(" in the case ")#mi("{j=k-1}")#text(" for the above argument, but for technical reasons, the full proof requires one to work with more general values of ")#mi("{j}")#text(" (also the claim ")#mi("{C(i,j)}")#text(" needs to be replaced by a more complicated version of itself, but let’s ignore this for sake of discussion).")

#text("We now return to the question of how to justify the weak mixing hypothesis ")#link(<tao-f95b812d3aca261fab7e>)[#text("(2)")]#text(". For a single block ")#mi("{A_i}")#text(" of ")#mi("{A}")#text(", one can easily concoct a scenario in which this hypothesis fails, by choosing ")#mi("{E}")#text(" to overlap with ")#mi("{A_i}")#text(" too strongly, or to be too disjoint from ")#mi("{A_i}")#text(". However, one can do better if one can select ")#mi("{A_i}")#text(" from a long progression of blocks. The starting point is the following simple ")#link("http://en.wikipedia.org/wiki/Double_counting_(proof_technique)")[#text("double counting observation")]#text(" that gives the right upper bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Single upper bound)")]#text(" ")#metadata(none) <tao-ae849dec36ce103cf4a4>#text(" Let ")#mi("{P, P+r, \\ldots, P+(M-1)r}")#text(" be a progression of progressions ")#mi("{P}")#text(" for some large ")#mi("{M}")#text(". Suppose that for each ")#mi("{i=0,\\ldots,M-1}")#text(", the set ")#mi("{A_i := \\{ a \\in P: a+ir \\in A \\}}")#text(" has density ")#mi("{\\approx \\delta}")#text(" in ")#mi("{P}")#text(" (i.e. ")#link(<tao-6b905c825ebff86a4a06>)[#text("(1)")]#text(" holds). Let ")#mi("{E}")#text(" be a subset of ")#mi("{P}")#text(" of density ")#mi("{\\approx \\sigma}")#text(". Then (if ")#mi("{M}")#text(" is large enough) one can find an ")#mi("{i = 0,\\ldots,M-1}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|A_i \\cap E\\right| \\lessapprox \\delta \\sigma |P|.", block: true)]]
]

#emph[#text("Proof:")]#text(" The key is the double counting identity")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i=0}^{M-1} \\left|A_i \\cap E\\right| = \\sum_{a \\in E} |A \\cap \\{ a, a+r, \\ldots, a+(M-1) r\\}|.", block: true)]]

#text("Because ")#mi("{A}")#text(" has maximal density ")#mi("{\\delta}")#text(" and ")#mi("{M}")#text(" is large, we have")

#align(center)[#tao-fit-display[#tao-math("\\left|A \\cap \\{ a, a+r, \\ldots, a+(M-1) r\\}\\right| \\lessapprox \\delta M", block: true)]]

#text("for each ")#mi("{a}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=0}^{M-1} |A_i \\cap E| \\lessapprox \\delta M |E|.")]]

#text("The claim then follows from the pigeonhole principle. ")#mi("\\Box")

#text("Now suppose we want to obtain weak mixing not just for a single set ")#mi("{E}")#text(", but for a small number ")#mi("{E_1,\\ldots,E_m}")#text(" of such sets, i.e. we wish to find an ")#mi("{i}")#text(" for which ")#metadata(none) <tao-e7e1c6f82ed227013fd0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|A_i \\cap E_j\\right| \\lessapprox \\delta \\sigma_j |P|.", block: true)]]

#text("for all ")#mi("{j=1,\\ldots,m}")#text(", where ")#mi("{\\sigma_j}")#text(" is the density of ")#mi("{E_j}")#text(" in ")#mi("{P}")#text(". The above proposition gives, for each ")#mi("{j}")#text(", a choice of ")#mi("{i}")#text(" for which ")#link(<tao-e7e1c6f82ed227013fd0>)[#text("(3)")]#text(" holds, but it could be a different ")#mi("{i}")#text(" for each ")#mi("{j}")#text(", and so it is not immediately obvious how to use Proposition ")#link(<tao-ae849dec36ce103cf4a4>)[#text("2")]#text(" to find an ")#mi("{i}")#text(" for which ")#link(<tao-e7e1c6f82ed227013fd0>)[#text("(3)")]#text(" holds ")#emph[#text("simultaneously")]#text(" for all ")#mi("{j}")#text(". However, it turns out that the van der Waerden theorem is the perfect tool for this amplification:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Multiple upper bound)")]#text(" ")#metadata(none) <tao-484c6fc18fa013621b8c>#text(" Let ")#mi("{P, P+r, \\ldots, P+(M-1)r}")#text(" be a progression of progressions ")#mi("{P+ir}")#text(" for some large ")#mi("{M}")#text(". Suppose that for each ")#mi("{i=0,\\ldots,M-1}")#text(", the set ")#mi("{A_i := \\{ a \\in P: a+ir \\in A \\}}")#text(" has density ")#mi("{\\approx \\delta}")#text(" in ")#mi("{P}")#text(" (i.e. ")#link(<tao-6b905c825ebff86a4a06>)[#text("(1)")]#text(" holds). For each ")#mi("{1 \\leq j \\leq m}")#text(", let ")#mi("{E_j}")#text(" be a subset of ")#mi("{P}")#text(" of density ")#mi("{\\approx \\sigma_j}")#text(". Then (if ")#mi("{M}")#text(" is large enough depending on ")#mi("{j}")#text(") one can find an ")#mi("{i = 0,\\ldots,M-1}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|A_i \\cap E_j\\right| \\lessapprox \\delta \\sigma_j \\left|P\\right|", block: true)]]

#text("simultaneously for all ")#mi("{1 \\leq j \\leq m}")#text(".")
]

#emph[#text("Proof:")]#text(" Suppose that the claim failed (for some suitably large ")#mi("{M}")#text("). Then, for each ")#mi("{i = 0,\\ldots,M-1}")#text(", there exists ")#mi("{j \\in \\{1,\\ldots,m\\}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|A_i \\cap E_j\\right| \\gg \\delta \\sigma_j |P|.", block: true)]]

#text("This can be viewed as a colouring of the interval ")#mi("{\\{1,\\ldots,M\\}}")#text(" by ")#mi("{m}")#text(" colours. If we take ")#mi("{M}")#text(" large compared to ")#mi("{m}")#text(", ")#link("http://en.wikipedia.org/wiki/Van_der_Waerden's_theorem")[#text("van der Waerden’s theorem")]#text(" allows us to then find a long subprogression of ")#mi("{\\{1,\\ldots,M\\}}")#text(" which is monochromatic, so that ")#mi("{j}")#text(" is constant on this progression. But then this will furnish a counterexample to Proposition ")#link(<tao-ae849dec36ce103cf4a4>)[#text("2")]#text(". ")#mi("\\Box")

#text("One nice thing about this proposition is that the upper bounds can be automatically upgraded to an asymptotic:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (Multiple mixing)")]#text(" ")#metadata(none) <tao-f863ff87543f3ed8d1f3>#text(" Let ")#mi("{P, P+r, \\ldots, P+(M-1)r}")#text(" be a progression of progressions ")#mi("{P+ir}")#text(" for some large ")#mi("{M}")#text(". Suppose that for each ")#mi("{i=0,\\ldots,M-1}")#text(", the set ")#mi("{A_i := \\{ a \\in P: a+ir \\in A \\}}")#text(" has density ")#mi("{\\approx \\delta}")#text(" in ")#mi("{P}")#text(" (i.e. ")#link(<tao-6b905c825ebff86a4a06>)[#text("(1)")]#text(" holds). For each ")#mi("{1 \\leq j \\leq m}")#text(", let ")#mi("{E_j}")#text(" be a subset of ")#mi("{P}")#text(" of density ")#mi("{\\approx \\sigma_j}")#text(". Then (if ")#mi("{M}")#text(" is large enough depending on ")#mi("{m}")#text(") one can find an ")#mi("{i = 0,\\ldots,M-1}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|A_i \\cap E_j\\right| \\approx \\delta \\sigma_j \\left|P\\right|", block: true)]]

#text("simultaneously for all ")#mi("{1 \\leq j \\leq m}")#text(".")
]

#emph[#text("Proof:")]#text(" By applying the previous proposition to the collection of sets ")#mi("{E_1,\\ldots,E_m}")#text(" and their complements ")#mi("{P\\backslash E_1,\\ldots,P \\backslash E_m}")#text(" (thus replacing ")#mi("{m}")#text(" with ")#mi("{2m}")#text(", one can find an ")#mi("{i}")#text(" for which")

#align(center)[#tao-fit-display[#tao-math("\\left|A_i \\cap E_j\\right| \\lessapprox \\delta \\sigma_j \\left|P\\right|", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|A_i \\cap (P \\backslash E_j)\\right| \\lessapprox \\delta (1-\\sigma_j) \\left|P\\right|", block: true)]]

#text("which gives the claim. ")#mi("\\Box")

#text("However, this improvement of Proposition ")#link(<tao-ae849dec36ce103cf4a4>)[#text("2")]#text(" turns out to not be strong enough for applications. The reason is that the number ")#mi("{m}")#text(" of sets ")#mi("{E_1,\\ldots,E_m}")#text(" for which mixing is established is too small compared with the length ")#mi("{M}")#text(" of the progression one has to use in order to obtain that mixing. However, thanks to the magic of the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(", one can amplify the above proposition even further, to allow for a huge number of ")#mi("{E_i}")#text(" to be mixed (at the cost of excluding a small fraction of exceptions):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5 (Really multiple mixing)")]#text(" ")#metadata(none) <tao-4ce6dea6d5b8bf1767db>#text(" Let ")#mi("{P, P+r, \\ldots, P+(M-1)r}")#text(" be a progression of progressions ")#mi("{P+ir}")#text(" for some large ")#mi("{M}")#text(". Suppose that for each ")#mi("{i=0,\\ldots,M-1}")#text(", the set ")#mi("{A_i := \\{ a \\in P: a+ir \\in A \\}}")#text(" has density ")#mi("{\\approx \\delta}")#text(" in ")#mi("{P}")#text(" (i.e. ")#link(<tao-6b905c825ebff86a4a06>)[#text("(1)")]#text(" holds). For each ")#mi("{v}")#text(" in some (large) finite set ")#mi("{V}")#text(", let ")#mi("{E_v}")#text(" be a subset of ")#mi("{P}")#text(" of density ")#mi("{\\approx \\sigma_v}")#text(". Then (if ")#mi("{M}")#text(" is large enough, but ")#emph[#text("not")]#text(" dependent on the size of ")#mi("{V}")#text(") one can find an ")#mi("{i = 0,\\ldots,M-1}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|A_i \\cap E_v\\right| \\approx \\delta \\sigma_v \\left|P\\right|", block: true)]]

#text("simultaneously for almost all ")#mi("{v \\in V}")#text(".")
]

#emph[#text("Proof:")]#text(" We build a bipartite graph ")#mi("{G = (P, V, E)}")#text(" connecting the progression ")#mi("{P}")#text(" to the finite set ")#mi("{V}")#text(" by placing an edge ")#mi("{(a,v)}")#text(" between an element ")#mi("{a \\in P}")#text(" and an element ")#mi("{v \\in V}")#text(" whenever ")#mi("{a \\in E_v}")#text(". The number ")#tao-math("{\\left|E_v\\right| \\approx \\sigma_v \\left|P\\right|}", block: false)#text(" can then be interpreted as the degree of ")#mi("{v}")#text(" in this graph, while the number ")#tao-math("{\\left|A_i \\cap E_v\\right|}", block: false)#text(" is the number of neighbours of ")#mi("{v}")#text(" that land in ")#mi("{A_i}")#text(".")

#text("We now apply the regularity lemma to this graph ")#mi("{G}")#text(". Roughly speaking, what this lemma does is to partition ")#mi("{P}")#text(" and ")#mi("{V}")#text(" into almost equally sized cells ")#mi("{P = P_1 \\cup \\ldots P_m}")#text(" and ")#mi("{V = V_1 \\cup \\ldots V_m}")#text(" such that for most pairs ")#mi("{P_j, V_k}")#text(" of cells, the graph ")#mi("{G}")#text(" resembles a random bipartite graph of some density ")#mi("{d_{jk}}")#text(" between these two cells. The key point is that the number ")#mi("{m}")#text(" of cells here is bounded uniformly in the size of ")#mi("{P}")#text(" and ")#mi("{V}")#text(". As a consequence of this lemma, one can show that for most vertices ")#mi("{v}")#text(" in a typical cell ")#mi("{V_k}")#text(", the number ")#tao-math("{\\left|E_v\\right|}", block: false)#text(" is approximately equal to")

#align(center)[#tao-fit-display[#tao-math("\\left|E_v\\right| \\approx \\sum_{j=1}^m d_{ij} \\left|P_j\\right|", block: true)]]

#text("and the number ")#tao-math("{\\left|A_i \\cap E_v\\right|}", block: false)#text(" is approximately equal to")

#align(center)[#tao-fit-display[#tao-math("\\left|A_i \\cap E_v\\right| \\approx \\sum_{j=1}^m d_{ij} |A_i \\cap P_j|.", block: true)]]

#text("The point here is that the ")#tao-math("{\\left|V\\right|}", block: false)#text(" different statistics ")#tao-math("{\\left|A_i \\cap E_v\\right|}", block: false)#text(" are now controlled by a mere ")#mi("{m}")#text(" statistics ")#tao-math("{\\left|A_i \\cap P_j\\right|}", block: false)#text(" (this is not unlike the use of ")#link("http://en.wikipedia.org/wiki/Principal_component_analysis")[#text("principal component analysis")]#text(" in statistics, incidentally, but that is another story). Now, we invoke Proposition ")#link(<tao-f863ff87543f3ed8d1f3>)[#text("4")]#text(" to find an ")#mi("{i}")#text(" for which")

#align(center)[#tao-fit-display[#tao-math("\\left|A_i \\cap P_j\\right| \\approx \\delta \\left|P_j\\right|", block: true)]]

#text("simultaneously for all ")#mi("{j=1,\\ldots,m}")#text(", and the claim follows. ")#mi("\\Box")

#text("This proposition now suggests a way forward to establish the type of mixing properties ")#link(<tao-f95b812d3aca261fab7e>)[#text("(2)")]#text(" needed for the preceding attempt at proving Szemerédi’s theorem to actually work. Whereas in that attempt, we were working with a single progression of progressions ")#mi("{P, P+r, \\ldots, P+(k-1)r}")#text(" of progressions containing a near-maximal density of elements of ")#mi("{A}")#text(", we will now have to work with a ")#emph[#text("family")]#text(" ")#mi("{(P_\\lambda, P_\\lambda+r_\\lambda,\\ldots,P_\\lambda+(k-1)r_\\lambda)_{\\lambda \\in \\Lambda}}")#text(" of such progression of progressions, where ")#mi("{\\Lambda}")#text(" ranges over some suitably large parameter set. Furthermore, in order to invoke Proposition ")#link(<tao-4ce6dea6d5b8bf1767db>)[#text("5")]#text(", this family must be “well-arranged” in some arithmetic sense; in particular, for a given ")#mi("{i}")#text(", it should be possible to find many reasonably large subfamilies of this family for which the ")#mi("{i^{th}}")#text(" terms ")#mi("{P_\\lambda + i r_\\lambda}")#text(" of the progression of progressions in this subfamily are themselves in arithmetic progression. (Also, for technical reasons having to do with the fact that the sets ")#mi("{E_v}")#text(" in Proposition ")#link(<tao-4ce6dea6d5b8bf1767db>)[#text("5")]#text(" are not allowed to depend on ")#mi("{i}")#text(", one also needs the progressions ")#mi("{P_\\lambda + i^{\\prime} r_\\lambda}")#text(" for any given ")#mi("{0 \\leq i^{\\prime} < i}")#text(" to be “similar” in the sense that they intersect ")#mi("{A}")#text(" in the same fashion (thus the sets ")#mi("{A \\cap (P_\\lambda + i^{\\prime} r_\\lambda)}")#text(" as ")#mi("{\\lambda}")#text(" varies need to be translates of each other).) If one has this sort of family, then Proposition ")#link(<tao-4ce6dea6d5b8bf1767db>)[#text("5")]#text(" allows us to “spend” some of the degrees of freedom of the parameter set ")#mi("{\\Lambda}")#text(" in order to gain good mixing properties for at least one of the sets ")#mi("{P_\\lambda +i r_\\lambda}")#text(" in the progression of progressions.")

#text("Of course, we still have to figure out how to get such large families of well-arranged progressions of progressions. Szemerédi’s solution was to begin by working with generalised progressions of a much larger rank ")#mi("{d}")#text(" than the rank ")#mi("{2}")#text(" progressions considered here; roughly speaking, to prove Szemerédi’s theorem for length ")#mi("{k}")#text(" progressions, one has to consider generalised progressions of rank as high as ")#mi("{2^k+1}")#text(". It is possible by a reasonably straightforward (though somewhat delicate) “density increment argument” to locate a huge generalised progression of this rank which is “saturated” by ")#mi("{A}")#text(" in a certain rather technical sense (related to the concept of “near maximal density” used previously). Then, by another reasonably elementary argument, it is possible to locate inside a suitable large generalised progression of some rank ")#mi("{d}")#text(", a family of large generalised progressions of rank ")#mi("{d-1}")#text(" which inherit many of the good properties of the original generalised progression, and which have the arithmetic structure needed for Proposition ")#link(<tao-4ce6dea6d5b8bf1767db>)[#text("5")]#text(" to be applicable, at least for one value of ")#mi("{i}")#text(". (But getting this sort of property for ")#emph[#text("all")]#text(" values of ")#mi("{i}")#text(" simultaneously is tricky, and requires many careful iterations of the above scheme; there is also the problem that by obtaining good behaviour for one index ")#mi("{i}")#text(", one may lose good behaviour at previous indices, leading to a sort of “")#link("http://en.wikipedia.org/wiki/Tower_of_Hanoi")[#text("Tower of Hanoi")]#text("” situation which may help explain the exponential factor in the rank ")#mi("{2^k+1}")#text(" that is ultimately needed. It is an extremely delicate argument; all the parameters and definitions have to be set very precisely in order for the argument to work at all, and it is really quite remarkable that Endre was able to see it through to the end.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2012/03/23/some-ingredients-in-szemeredis-proof-of-szemeredis-theorem/#comment-134690")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2012")])]

#text("I’m always amused that the original proof is so involved that Szemeredi himself didn’t want to write it up. What ended up in print was (heroically) written by Ron Graham. Maybe one of the principals will post here the true story of how that came to happen.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f485e092feba54fdaa267e6d09e8803d6fd165f648841ad4887d7b7b67002019-aea4141198ffddc4a6c03c1bdf094392754309230b9db8c218177c5d3706a7eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Komjath")]], [#link("https://terrytao.wordpress.com/2012/03/23/some-ingredients-in-szemeredis-proof-of-szemeredis-theorem/#comment-135107")[#strong[#text("Peter Komjath")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2012")])]

#text("The heroic writing up was done by Andras Hajnal. See here the detailed story by Szemeredi himself: ")#link("http://www.matud.iif.hu/08jun/12.html")[#text("http://www.matud.iif.hu/08jun/12.html")]#text(" (in Hungarian).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Endre Szemeredi")]], [#link("https://terrytao.wordpress.com/2012/03/23/some-ingredients-in-szemeredis-proof-of-szemeredis-theorem/#comment-135685")[#strong[#text("Endre Szemeredi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2012")])]

#text("“The true story”")

#text("The exact acknowledgment is the following:")

#text("” My indebtedness to my friends R.L.Graham and A.Hajnal is extremely great.")#linebreak()#text(" In Fact, they wrote the whole paper after listening to my rough oral exposition.”")

#text("In the volume, An Irregular Mind Andras Hajnal wrote a short essay, My Early Encounters with Szemeredi (page 757-758 he writes the following.")

#text("“In 1973 Endre announced that he generalized his old theorem for arbitrary arithmetic progressions. Paul as very excited, first because this was a problem he and Turan had raised about thirty years ago, and also because he promised one thousand dollars for it.")

#text("He was in the US an could not come to Budapest. He quarelled with “joe” because he did not let some Israeli mathematicians attend the conference held in Hungary for his sixtieth birthday. Endre was telling me the proof and I was writing it down as we went along. It took unusually long because we checked every detail. We were about halfway when Paul called from the US asking if there was a proof. I told him that I don’t know, since I did not see the and of it, but would buy it for $500. This convinced him that the matter is serious. Endre submitted the manuscript and it appeared quite fast in the Acta Arithmetica in 1975. It helped that Ron Graham kindly read it, but it appeared basically as it was submitted.”")

#text("Actually the Mathematical Institute of the Hungarian Academy of Sciences produced a preprint what I gave to my friend Ron.")

#text("A few words about r4 (n). The r4(n) paper was written down by Peter Elliott and Eduard Wirsing while I was giving the lecture. Because of my practically non existing English they had to suffer a lot. I am very greatful to them also.")

#text("Endre Szemeredi")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/03/23/some-ingredients-in-szemeredis-proof-of-szemeredis-theorem/#comment-135936")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2012")])]

#text("Wait, who is B. L. Graham? Is that someone different from Ron Graham?")

#emph[#text("[Corrected – T.]")]

#text("And congratulations of course ;-).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2440d6a669b266b1e0ded0cf262bd8572dc362e7aa000fb14c6782e94a6cbf7-545719ca34e8c1d255335ce8638b341f6cc5ba0edfe9ede6f49618c2d9c7de51.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Endre Szemerédi laureado com Prémio Abel 2012 « problemas | teoremas")]], [#link("https://terrytao.wordpress.com/2012/03/23/some-ingredients-in-szemeredis-proof-of-szemeredis-theorem/#comment-134711")[#strong[#text("Endre Szemerédi laureado com Prémio Abel 2012 « problemas | teoremas")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2012")])]

#text("[…] Post de Terence Tao acerca da demonstração do Teorema de Szemerédi. Partilhar isto:TwitterGostar […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c152c793afa64ce1aa2160bc0f57cace7d3fe3ecb2ef816a9244694e3e3bfd8a-77d7b60900ddb8febe905fb801a81d187a1c445bddd65558037c80514d070fe4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of csgergo")]], [#link("https://terrytao.wordpress.com/2012/03/23/some-ingredients-in-szemeredis-proof-of-szemeredis-theorem/#comment-134720")[#strong[#text("csgergo")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2012")])]

#text("Dear Prof Tao,")#linebreak()#text(" Aren’t absolute signs in theorem 1 missing?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/03/23/some-ingredients-in-szemeredis-proof-of-szemeredis-theorem/#comment-134957")[#strong[#text("Teorema de la semana: el de Szemerédi | Series divergentes")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2012")]

#text("[…] razonamiento lógico de los enunciados está demasiado enredado. Terry Tao publicó ayer en su blog los “ingredientes” de la demostración, y hace notar que el mismo Szemerédi incluyó un diagrama con las implicaciones lógicas de las […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2012/03/23/some-ingredients-in-szemeredis-proof-of-szemeredis-theorem/#comment-134975")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2012")])]

#text("Kevin, I feel I should add that, at least according to the acknowledgement in the paper, Ron Graham wrote it with András Hajnal. But I agree that it would be good to hear the full story.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b88794d035dd7a374538e2cc638136a031febaa0b7dfe354aa8df427d1108fd-501668d8a98f7c9ddd89f138e1fe737bf816970872547c94b8a27ed46660a3cc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of none")]], [#link("https://terrytao.wordpress.com/2012/03/23/some-ingredients-in-szemeredis-proof-of-szemeredis-theorem/#comment-135001")[#strong[#text("none")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2012")])]

#text("Aha, the part about Ron Graham explains something I found amusing: that Tim’s write-up had a snippet of the original paper, and the snippet referred to the theorem as “Szemerédi’s theorem”. Usually when a paper presents a new result, the result is called something like “Theorem 3” and it only becomes known as “So-and-so’s theorem” after other papers have been citing it for a while ;-).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ee4e3cad72cedc4a51e2797a583d68d74d8f93866d29af3deea543eaf198809-fb868687aeccbd883399a2b0ebb48db7dbd5e73d6552f1398dd657d432962420.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arif")]], [#link("https://terrytao.wordpress.com/2012/03/23/some-ingredients-in-szemeredis-proof-of-szemeredis-theorem/#comment-136527")[#strong[#text("arif")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2012")])]

#text("ah… that’s was insane")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c25700f6fc77514649506df835a3bb1efb38a949c6c799c232e7729091162ac-dc5a7b89368ab820ee0bb2ddd5ff5d51552694dc212a7368f08b68fec0a740d5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abel Ödülü 2012 « mathematist")]], [#link("https://terrytao.wordpress.com/2012/03/23/some-ingredients-in-szemeredis-proof-of-szemeredis-theorem/#comment-140971")[#strong[#text("Abel Ödülü 2012 « mathematist")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2012")])]

#text("[…] İlgilenenler Terence Tao’nun Szemerédi Teoremi’nin ispatıyla alakalı yazısını okuyabilir. Ayrıca Szemerédi’nin çakışma geometrisi (incidence geometry) ve çizge […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/03/23/some-ingredients-in-szemeredis-proof-of-szemeredis-theorem/#comment-150382")[#strong[#text("Fifteenth Linkfest")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2012")]

#text("[…] Some ingredients in Szemerédi’s proof of Szemerédi’s theorem (includes an interesting comparison with Perelmen’s proof of the Poincaré conjecture) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Szemeredi’s proof of Szemeredi’s theorem | What's new")]], [#link("https://terrytao.wordpress.com/2012/03/23/some-ingredients-in-szemeredis-proof-of-szemeredis-theorem/#comment-486159")[#strong[#text("Szemeredi’s proof of Szemeredi’s theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2017")])]

#text("[…] with the intention to try to write up a more readable version of the proof, but ended up just presenting some ingredients of the argument in a blog post, rather than try to rewrite the whole thing. In that post, I suspected that the cleanest way to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2012/03/23/some-ingredients-in-szemeredis-proof-of-szemeredis-theorem/#comment-641728")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2022")])]

#text("What happened to the math formulas in this old post?")
]
