// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/
// Converted to Typst by tao2typ: "2026-11-02T16:21:37.202231+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "275A, Notes 4: The central limit theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("275A, Notes 4: The central limit theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 November 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/")[#text("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-02 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{X_1,X_2,\\dots}")#text(" be iid copies of an absolutely integrable real scalar random variable ")#mi("{X}")#text(", and form the partial sums ")#mi("{S_n := X_1 + \\dots + X_n}")#text(". As we saw in ")#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/")[#text("the last set of notes")]#text(", the law of large numbers ensures that the empirical averages ")#mi("{S_n/n}")#text(" converge (both in probability and almost surely) to a deterministic limit, namely the mean ")#mi("{\\mu= {\\bf E} X}")#text(" of the reference variable ")#mi("{X}")#text(". Furthermore, under some additional moment hypotheses on the underlying variable ")#mi("{X}")#text(", we can obtain ")#emph[#text("square root cancellation")]#text(" for the fluctuation ")#mi("{\\frac{S_n}{n} - \\mu}")#text(" of the empirical average from the mean. To simplify the calculations, let us first restrict to the case ")#mi("{\\mu=0, \\sigma^2=1}")#text(" of mean zero and variance one, thus")

#mi("\\displaystyle {\\bf E} X = 0")

#text("and")

#mi("\\displaystyle {\\bf Var}(X) = {\\bf E} X^2 = 1.")

#text("Then, as computed in previous notes, the normalised fluctuation ")#mi("{S_n/\\sqrt{n}}")#text(" also has mean zero and variance one:")

#mi("\\displaystyle {\\bf E} \\frac{S_n}{\\sqrt{n}} = 0")

#mi("\\displaystyle {\\bf Var}(\\frac{S_n}{\\sqrt{n}}) = {\\bf E} (\\frac{S_n}{\\sqrt{n}})^2 = 1.")

#text("This and Chebyshev’s inequality already indicates that the “typical” size of ")#mi("{S_n}")#text(" is ")#mi("{O(\\sqrt{n})}")#text(", thus for instance ")#mi("{\\frac{S_n}{\\sqrt{n} \\omega(n)}}")#text(" goes to zero in probability for any ")#mi("{\\omega(n)}")#text(" that goes to infinity as ")#mi("{n \\rightarrow \\infty}")#text(". If we also have a finite fourth moment ")#tao-math("{{\\bf E} \\left|X\\right|^4 < \\infty}", block: false)#text(", then the calculations of the previous notes also give a fourth moment estimate")

#tao-math("\\displaystyle {\\bf E} (\\frac{S_n}{\\sqrt{n}})^4 = 3 + O( \\frac{{\\bf E} \\left|X\\right|^4}{n} ).", block: false)

#text("From this and the Paley-Zygmund inequality (Exercise 44 of ")#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/")[#text("Notes 1")]#text(") we also get some lower bound for ")#mi("{\\frac{S_n}{\\sqrt{n}}}")#text(" of the form")

#tao-math("\\displaystyle {\\bf P}( \\left|\\frac{S_n}{\\sqrt{n}}\\right| \\geq \\varepsilon ) \\geq \\varepsilon", block: false)

#text("for some absolute constant ")#mi("{\\varepsilon>0}")#text(" and for ")#mi("{n}")#text(" sufficiently large; this indicates in particular that ")#mi("{\\frac{S_n \\omega(n)}{\\sqrt{n}}}")#text(" does not converge in any reasonable sense to something finite for any ")#mi("{\\omega(n)}")#text(" that goes to infinity.")#linebreak()#text(" The question remains as to what happens to the ratio ")#mi("{S_n/\\sqrt{n}}")#text(" itself, without multiplying or dividing by any factor ")#mi("{\\omega(n)}")#text(". A first guess would be that these ratios converge in probability or almost surely, but this is unfortunately not the case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be iid copies of an absolutely integrable real scalar random variable ")#mi("{X}")#text(" with mean zero, variance one, and finite fourth moment, and write ")#mi("{S_n := X_1 + \\dots + X_n}")#text(". Then the random variables ")#mi("{S_n/\\sqrt{n}}")#text(" do not converge in probability or almost surely to any limit, and neither does any subsequence of these random variables.")
]

#emph[#text("Proof:")]#text(" Suppose for contradiction that some sequence ")#mi("{S_{n_j}/\\sqrt{n_j}}")#text(" converged in probability or almost surely to a limit ")#mi("{Y}")#text(". By passing to a further subsequence we may assume that the convergence is in the almost sure sense. Since all of the ")#mi("{S_{n_j}/\\sqrt{n_j}}")#text(" have mean zero, variance one, and bounded fourth moment, Theorem 25 of ")#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/")[#text("Notes 1")]#text(" implies that the limit ")#mi("{Y}")#text(" also has mean zero and variance one. On the other hand, ")#mi("{Y}")#text(" is a tail random variable and is thus almost surely constant by the Kolmogorov zero-one law from ")#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/")[#text("Notes 3")]#text(". Since constants have variance zero, we obtain the required contradiction. ")#mi("\\Box")

#text("Nevertheless there is an important limit for the ratio ")#mi("{S_n/\\sqrt{n}}")#text(", which requires one to replace the notions of convergence in probability or almost sure convergence by the weaker concept of ")#link("https://en.wikipedia.org/wiki/Convergence_of_random_variables#Convergence_in_distribution")[#text("convergence in distribution")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2 (Vague convergence and convergence in distribution)")]#text(" Let ")#mi("{R}")#text(" be a locally compact Hausdorff topological space with the Borel ")#mi("{\\sigma}")#text("-algebra. A sequence of finite measures ")#mi("{\\mu_n}")#text(" on ")#mi("{R}")#text(" is said to converge ")#link("https://en.wikipedia.org/wiki/Vague_topology")[#text("vaguely")]#text(" to another finite measure ")#mi("{\\mu}")#text(" if one has")

#mi("\\displaystyle \\int_R G(x)\\ d\\mu_n(x) \\rightarrow \\int_R G(x)\\ d\\mu(x)")

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" for all continuous compactly supported functions ")#mi("{G: R \\rightarrow {\\bf R}}")#text(". (Vague convergence is also known as ")#emph[#text("weak convergence")]#text(", although strictly speaking the terminology ")#link("https://en.wikipedia.org/wiki/Weak_topology")[#text("weak-* convergence")]#text(" would be more accurate.) A sequence of random variables ")#mi("{X_n}")#text(" taking values in ")#mi("{R}")#text(" is said to ")#emph[#text("converge in distribution")]#text(" (or ")#emph[#text("converge weakly")]#text(" or ")#emph[#text("converge in law")]#text(") to another random variable ")#mi("{X}")#text(" if the distributions ")#mi("{\\mu_{X_n}}")#text(" converge vaguely to the distribution ")#mi("{\\mu_X}")#text(", or equivalently if")

#mi("\\displaystyle {\\bf E}G(X_n) \\rightarrow {\\bf E} G(X)")

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" for all continuous compactly supported functions ")#mi("{G: R \\rightarrow {\\bf R}}")#text(".")
]

#text("One could in principle try to extend this definition beyond the locally compact Hausdorff setting, but certain pathologies can occur when doing so (e.g. failure of the ")#link("https://en.wikipedia.org/wiki/Riesz%E2%80%93Markov%E2%80%93Kakutani_representation_theorem")[#text("Riesz representation theorem")]#text("), and we will never need to consider vague convergence in spaces that are not locally compact Hausdorff, so we restrict to this setting for simplicity.")

#text("Note that the notion of convergence in distribution depends only on the distribution of the random variables involved. One consequence of this is that convergence in distribution does not produce unique limits: if ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(", and ")#mi("{Y}")#text(" has the same distribution as ")#mi("{X}")#text(", then ")#mi("{X_n}")#text(" also converges in distribution to ")#mi("{Y}")#text(". However, limits are unique up to equivalence in distribution (this is a consequence of the Riesz representation theorem, discussed for instance in ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("this blog post")]#text("). As a consequence of the insensitivity of convergence in distribution to equivalence in distribution, we may also legitimately talk about convergence of distribution of a sequence of random variables ")#mi("{X_n}")#text(" to another random variable ")#mi("{X}")#text(" even when all the random variables ")#mi("{X_1,X_2,\\dots}")#text(" and ")#mi("{X}")#text(" involved are being modeled by different probability spaces (e.g. each ")#mi("{X_n}")#text(" is modeled by ")#mi("{\\Omega_n}")#text(", and ")#mi("{X}")#text(" is modeled by ")#mi("{\\Omega}")#text(", with no coupling presumed between these spaces). This is in contrast to the stronger notions of convergence in probability or almost sure convergence, which require all the random variables to be modeled by a common probability space. Also, by an abuse of notation, we can say that a sequence ")#mi("{X_n}")#text(" of random variables converges in distribution to a probability measure ")#mi("{\\mu}")#text(", when ")#mi("{\\mu_{X_n}}")#text(" converges vaguely to ")#mi("{\\mu}")#text(". Thus we can talk about a sequence of random variables converging in distribution to a uniform distribution, a gaussian distribution, etc..")

#text("From the dominated convergence theorem (available for both convergence in probability and almost sure convergence) we see that convergence in probability or almost sure convergence implies convergence in distribution. The converse is not true, due to the insensitivity of convergence in distribution to equivalence in distribution; for instance, if ")#mi("{X_1,X_2,\\dots}")#text(" are iid copies of a non-deterministic scalar random variable ")#mi("{X}")#text(", then the ")#mi("{X_n}")#text(" trivially converge in distribution to ")#mi("{X}")#text(", but will not converge in probability or almost surely (as one can see from the zero-one law). However, there are some partial converses that relate convergence in distribution to convergence in probability; see Exercise ")#link(<tao-b0846c4700fc211e6822>)[#text("10")]#text(" below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" The notion of convergence in distribution is somewhat similar to the notion of convergence in the sense of distributions that arises in distribution theory (discussed for instance in ")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("this previous blog post")]#text("), however strictly speaking the two notions of convergence are distinct and should not be confused with each other, despite the very similar names.")
]

#text("The notion of convergence in distribution simplifies in the case of real scalar random variables:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4")]#text(" ")#metadata(none) <tao-473c3cba6f0b66454d76>#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be a sequence of scalar random variables, and let ")#mi("{X}")#text(" be another scalar random variable. Then the following are equivalent:")

#list(
[#text("(i) ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(".")],
[#text("(ii) ")#mi("{F_{X_n}(t)}")#text(" converges to ")#mi("{F_X(t)}")#text(" for each continuity point ")#mi("{t}")#text(" of ")#mi("{F_X}")#text(" (i.e. for all real numbers ")#mi("{t \\in {\\bf R}}")#text(" at which ")#mi("{F_X}")#text(" is continuous). Here ")#mi("{F_X(t) := {\\bf P}(X \\leq t)}")#text(" is the cumulative distribution function of ")#mi("{X}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" First suppose that ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(", and ")#mi("{F_X}")#text(" is continuous at ")#mi("{t}")#text(". For any ")#mi("{\\varepsilon > 0}")#text(", one can find a ")#mi("{\\delta}")#text(" such that")

#mi("\\displaystyle F_X(t) - \\varepsilon \\leq F_X(t^{\\prime}) \\leq F_X(t) + \\varepsilon")

#text("for every ")#mi("{t^{\\prime} \\in [t-\\delta,t+\\delta]}")#text(". One can also find an ")#mi("{N}")#text(" larger than ")#tao-math("{\\left|t\\right|+\\delta}", block: false)#text(" such that ")#mi("{F_X(-N) \\leq \\varepsilon}")#text(" and ")#mi("{F_X(N) \\geq 1-\\varepsilon}")#text(". Thus")

#tao-math("\\displaystyle {\\bf P} (\\left|X\\right| \\geq N ) = O(\\varepsilon)", block: false)

#text("and")

#tao-math("\\displaystyle {\\bf P} (\\left|X - t\\right| \\leq \\delta ) = O(\\varepsilon).", block: false)

#text("Let ")#mi("{G: {\\bf R} \\rightarrow [0,1]}")#text(" be a continuous function supported on ")#mi("{[-2N, t]}")#text(" that equals ")#mi("{1}")#text(" on ")#mi("{[-N, t-\\delta]}")#text(". Then by the above discussion we have")

#mi("\\displaystyle {\\bf E} G(X) = F_X(t) + O(\\varepsilon)")

#text("and hence")

#mi("\\displaystyle {\\bf E} G(X_n) = F_X(t) + O(\\varepsilon)")

#text("for large enough ")#mi("{n}")#text(". In particular")

#mi("\\displaystyle {\\bf P}( X_n \\leq t ) \\geq F_X(t) - O(\\varepsilon).")

#text("A similar argument, replacing ")#mi("{G}")#text(" with a continuous function supported on ")#mi("{[t,2N]}")#text(" that equals ")#mi("{1}")#text(" on ")#mi("{[t+\\delta,N]}")#text(" gives")

#mi("\\displaystyle {\\bf P}( X_n > t ) \\geq 1 - F_X(t) - O(\\varepsilon)")

#text("for ")#mi("{n}")#text(" large enough. Putting the two estimates together gives")

#mi("\\displaystyle F_{X_n}(t) = F_X(t) + O(\\varepsilon)")

#text("for ")#mi("{n}")#text(" large enough; sending ")#mi("{\\varepsilon \\rightarrow 0}")#text(", we obtain the claim.")#linebreak()#text(" Conversely, suppose that ")#mi("{F_{X_n}(t)}")#text(" converges to ")#mi("{F_X(t)}")#text(" at every continuity point ")#mi("{t}")#text(" of ")#mi("{F_X}")#text(". Let ")#mi("{G: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a continuous compactly supported function, then it is uniformly continuous. As ")#mi("{F_X}")#text(" is monotone increasing, it can only have countably many points of discontinuity. From these two facts one can find, for any ")#mi("{\\varepsilon>0}")#text(", a simple function ")#mi("{G_\\varepsilon(t) = \\sum_{i=1}^n c_i 1_{(t_i,t_{i+1}]}}(t)")#text(" for some ")#mi("{t_1 < \\dots < t_n}")#text(" that are points of continuity of ")#mi("{F_X}")#text(", and real numbers ")#mi("{c_i}")#text(", such that ")#tao-math("{\\left|G(t) - G_\\varepsilon(t)\\right| \\leq \\varepsilon}", block: false)#text(" for all ")#mi("{t}")#text(". Thus")

#mi("\\displaystyle {\\bf E} G(X_n) = {\\bf E} G_\\varepsilon(X_n) + O(\\varepsilon)")

#mi("\\displaystyle = \\sum_{i=1}^n c_i(F_{X_n}(t_{i+1}) - F_{X_n}(t_i)) + O(\\varepsilon).")

#text("Similarly for ")#mi("{X_n}")#text(" replaced by ")#mi("{X}")#text(". Subtracting and taking limit superior, we conclude that")

#tao-math("\\displaystyle \\limsup_{n \\rightarrow \\infty} \\left|{\\bf E} G(X_n) - {\\bf E} G(X)\\right| = O(\\varepsilon),", block: false)

#text("and on sending ")#mi("{\\varepsilon \\rightarrow 0}")#text(", we obtain that ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(" as claimed. ")#mi("\\Box")#linebreak()#text(" The restriction to continuity points of ")#mi("{t}")#text(" is necessary. Consider for instance the deterministic random variables ")#mi("{X_n = 1/n}")#text(", then ")#mi("{X_n}")#text(" converges almost surely (and hence in distribution) to ")#mi("{0}")#text(", but ")#mi("{F_{X_n}(0) = 0}")#text(" does not converge to ")#mi("{F_X(0)=1}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 5")]#text(" For any natural number ")#mi("{n}")#text(", let ")#mi("{X_n}")#text(" be a discrete random variable drawn uniformly from the finite set ")#mi("{\\{0/n, 1/n, \\dots, (n-1)/n\\}}")#text(", and let ")#mi("{X}")#text(" be the continuous random variable drawn uniformly from ")#mi("{[0,1]}")#text(". Then ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(". Thus we see that a continuous random variable can emerge as the limit of discrete random variables.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 6")]#text(" For any natural number ")#mi("{n}")#text(", let ")#mi("{X_n}")#text(" be a continuous random variable drawn uniformly from ")#mi("{[0,1/n]}")#text(", then ")#mi("{X_n}")#text(" converges in distribution to the deterministic real number ")#mi("{0}")#text(". Thus we see that discrete (or even deterministic) random variables can emerge as the limit of continuous random variables.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7 (Portmanteau theorem)")]#text(" Show that the properties (i) and (ii) in Proposition ")#link(<tao-473c3cba6f0b66454d76>)[#text("4")]#text(" are also equivalent to the following three statements:")

#list(
[#text("(iii) One has ")#mi("{\\limsup_{n \\rightarrow \\infty} {\\bf P}( X_n \\in K ) \\leq {\\bf P}(X \\in K)}")#text(" for all closed sets ")#mi("{K \\subset {\\bf R}}")#text(".")],
[#text("(iv) One has ")#mi("{\\liminf_{n \\rightarrow \\infty} {\\bf P}( X_n \\in U ) \\geq {\\bf P}(X \\in U)}")#text(" for all open sets ")#mi("{U \\subset {\\bf R}}")#text(".")],
[#text("(v) For any Borel set ")#mi("{E \\subset {\\bf R}}")#text(" whose topological boundary ")#mi("{\\partial E}")#text(" is such that ")#mi("{{\\bf P}(X \\in \\partial E) = 0}")#text(", one has ")#mi("{\\lim_{n \\rightarrow \\infty} {\\bf P}(X_n \\in E) = {\\bf P}(X \\in E)}")#text(".")]
)

#text("(Note: to prove this theorem, you may wish to invoke ")#link("https://en.wikipedia.org/wiki/Urysohn%27s_lemma")[#text("Urysohn’s lemma")]#text(". To deduce (iii) from (i), you may wish to start with the case of compact ")#mi("{K}")#text(".)")
]

#text("We can now state the famous central limit theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8 (Central limit theorem)")]#text(" ")#metadata(none) <tao-667ae99a22d281e83efd>#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be iid copies of a scalar random variable ")#mi("{X}")#text(" of finite mean ")#mi("{\\mu := {\\bf E} X}")#text(" and finite non-zero variance ")#mi("{\\sigma^2 := {\\bf Var}(X)}")#text(". Let ")#mi("{S_n := X_1 + \\dots + X_n}")#text(". Then the random variables ")#mi("{\\frac{\\sqrt{n}}{\\sigma} (\\frac{S_n}{n} - \\mu)}")#text(" converges in distribution to a random variable with the standard normal distribution ")#mi("{N(0,1)}")#text(" (that is to say, a random variable with probability density function ")#mi("{x \\mapsto \\frac{1}{\\sqrt{2\\pi}} e^{-x^2/2}}")#text("). Thus, by abuse of notation")

#mi("\\displaystyle \\frac{\\sqrt{n}}{\\sigma} (\\frac{S_n}{n} - \\mu) \\rightarrow N(0,1).")

#text("In the normalised case ")#mi("{\\mu=0, \\sigma^2=1}")#text(" when ")#mi("{X}")#text(" has mean zero and unit variance, this simplifies to")

#mi("\\displaystyle \\frac{S_n}{\\sqrt{n}} \\rightarrow N(0,1).")
]

#text("Using Proposition ")#link(<tao-473c3cba6f0b66454d76>)[#text("4")]#text(" (and the fact that the cumulative distribution function associated to ")#mi("{N(0,1)}")#text(" is continuous, the central limit theorem is equivalent to asserting that")

#mi("\\displaystyle {\\bf P}( \\frac{\\sqrt{n}}{\\sigma} (\\frac{S_n}{n} - \\mu) \\leq t ) \\rightarrow \\frac{1}{\\sqrt{2\\pi}} \\int_{-\\infty}^t e^{-x^2/2}\\ dx")

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" for any ")#mi("{t \\in {\\bf R}}")#text(", or equivalently that")

#mi("\\displaystyle {\\bf P}( a \\leq \\frac{\\sqrt{n}}{\\sigma} (\\frac{S_n}{n} - \\mu) \\leq b ) \\rightarrow \\frac{1}{\\sqrt{2\\pi}} \\int_{a}^b e^{-x^2/2}\\ dx.")

#text("Informally, one can think of the central limit theorem as asserting that ")#mi("{S_n}")#text(" approximately behaves like it has distribution ")#mi("{N( n \\mu, n \\sigma^2 )}")#text(" for large ")#mi("{n}")#text(", where ")#mi("{N(\\mu,\\sigma^2)}")#text(" is the normal distribution with mean ")#mi("{\\mu}")#text(" and variance ")#mi("{\\sigma^2}")#text(", that is to say the distribution with probability density function ")#mi("{x \\mapsto \\frac{1}{\\sqrt{2\\pi} \\sigma} e^{-(x-\\mu)^2/2\\sigma^2}}")#text(". The integrals ")#mi("{\\frac{1}{\\sqrt{2\\pi}} \\int_{-\\infty}^t e^{-x^2/2}\\ dx}")#text(" can be written in terms of the ")#link("https://en.wikipedia.org/wiki/Error_function")[#text("error function")]#text(" ")#mi("{\\text{erf}}")#text(" as ")#mi("{\\frac{1}{2} + \\frac{1}{2} \\text{erf}(t/\\sqrt{2})}")#text(".")#linebreak()#text(" The central limit theorem is a basic example of the ")#emph[#text("universality phenomenon")]#text(" in probability – many statistics involving a large system of many independent (or weakly dependent) variables (such as the normalised sums ")#mi("{\\frac{\\sqrt{n}}{\\sigma}(\\frac{S_n}{n}-\\mu)}")#text(") end up having a universal asymptotic limit (in this case, the normal distribution), regardless of the precise makeup of the underlying random variable ")#mi("{X}")#text(" that comprised that system. Indeed, the universality of the normal distribution is such that it arises in many other contexts than the fluctuation of iid random variables; the central limit theorem is merely the first place in probability theory where it makes a prominent appearance.")

#text("We will give several proofs of the central limit theorem in these notes; each of these proofs has their advantages and disadvantages, and can each extend to prove many further results beyond the central limit theorem. We first give Lindeberg’s proof of the central limit theorem, based on exchanging (or swapping) each component ")#mi("{X_1,\\dots,X_n}")#text(" of the sum ")#mi("{S_n}")#text(" in turn. This proof gives an accessible explanation as to why there should be a universal limit for the central limit theorem; one then computes directly with gaussians to verify that it is the normal distribution which is the universal limit. Our second proof is the most popular one taught in probability texts, namely the Fourier-analytic proof based around the concept of the ")#link("https://en.wikipedia.org/wiki/Characteristic_function_(probability_theory)")[#text("characteristic function")]#text(" ")#mi("{t \\mapsto {\\bf E} e^{itX}}")#text(" of a real random variable ")#mi("{X}")#text(". Thanks to the powerful identities and other results of Fourier analysis, this gives a quite short and direct proof of the central limit theorem, although the arguments may seem rather magical to readers who are not already familiar with Fourier methods. Finally, we give a proof based on the moment method, in the spirit of the arguments in the ")#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/")[#text("previous notes")]#text("; this argument is more combinatorial, but is straightforward and is particularly robust, in particular being well equipped to handle some dependencies between components; we will illustrate this by proving the ")#link("https://en.wikipedia.org/wiki/Erd%C5%91s%E2%80%93Kac_theorem")[#text("Erdos-Kac law")]#text(" in number theory by this method. Some further discussion of the central limit theorem (including some further proofs, such as one based on ")#link("https://en.wikipedia.org/wiki/Stein%27s_method")[#text("Stein’s method")]#text(") can be found in ")#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/")[#text("this blog post")]#text(". Some further variants of the central limit theorem, such as local limit theorems, stable laws, and large deviation inequalities, will be discussed in the next (and final) set of notes.")

#text("The following exercise illustrates the power of the central limit theorem, by establishing combinatorial estimates which would otherwise require the use of Stirling’s formula to establish.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9 (De Moivre-Laplace theorem)")]#text(" ")#metadata(none) <tao-bf89c2eb19a71b812e51>#text(" Let ")#mi("{X}")#text(" be a Bernoulli random variable, taking values in ")#mi("{\\{0,1\\}}")#text(" with ")#mi("{{\\bf P}(X=0)={\\bf P}(X=1)=1/2}")#text(", thus ")#mi("{X}")#text(" has mean ")#mi("{1/2}")#text(" and variance ")#mi("{1/4}")#text(". Let ")#mi("{X_1,X_2,\\dots}")#text(" be iid copies of ")#mi("{X}")#text(", and write ")#mi("{S_n := X_1+\\dots+X_n}")#text(".")

#list(
[#text("(i) Show that ")#mi("{S_n}")#text(" takes values in ")#mi("{\\{0,\\dots,n\\}}")#text(" with ")#mi("{{\\bf P}(S_n=i) = \\frac{1}{2^n} \\binom{n}{i}}")#text(". (This is an example of a ")#link("https://en.wikipedia.org/wiki/Binomial_distribution")[#text("binomial distribution")]#text(".)")],
[#text("(ii) Assume ")#link("https://en.wikipedia.org/wiki/Stirling%27s_approximation")[#text("Stirling’s formula")]#linebreak()

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("n! = (1+o(1)) \\sqrt{2\\pi n} n^n e^{-n}")]]

#linebreak()

#text("where ")#mi("{o(1)}")#text(" is a function of ")#mi("{n}")#text(" that goes to zero as ")#mi("{n \\rightarrow \\infty}")#text(". (A proof of this formula may be found in ")#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/")[#text("this previous blog post")]#text(".) Using this formula, and without using the central limit theorem, show that")

#linebreak()

#align(center)[#tao-fit-display[#mitex("{\\bf P}( a \\leq 2\\sqrt{n} (\\frac{S_n}{n} - \\frac{1}{2}) \\leq b ) \\rightarrow \\frac{1}{\\sqrt{2\\pi}} \\int_{a}^b e^{-x^2/2}\\ dx")]]

#linebreak()

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" for any fixed real numbers ")#mi("{a<b}")#text(".")]
)

#text("The above special case of the central limit theorem was first established ")#link("https://en.wikipedia.org/wiki/De_Moivre%E2%80%93Laplace_theorem")[#text("by de Moivre and Laplace")]#text(".")
]

#text("We close this section with some basic facts about convergence of distribution that will be useful in the sequel.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" ")#metadata(none) <tao-b0846c4700fc211e6822>#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(", ")#mi("{Y_1,Y_2,\\dots}")#text(" be sequences of real random variables, and let ")#mi("{X,Y}")#text(" be further real random variables.")

#list(
[#text("(i) If ")#mi("{X}")#text(" is deterministic, show that ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(" if and only if ")#mi("{X_n}")#text(" converges in probability to ")#mi("{X}")#text(".")],
[#text("(ii) Suppose that ")#mi("{X_n}")#text(" is independent of ")#mi("{Y_n}")#text(" for each ")#mi("{n}")#text(", and ")#mi("{X}")#text(" independent of ")#mi("{Y}")#text(". Show that ")#mi("{X_n+iY_n}")#text(" converges in distribution to ")#mi("{X+iY}")#text(" if and only if ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(" and ")#mi("{Y_n}")#text(" converges in distribution to ")#mi("{Y}")#text(". (The shortest way to prove this is by invoking the ")#link("https://en.wikipedia.org/wiki/Stone%E2%80%93Weierstrass_theorem")[#text("Stone-Weierstrass theorem")]#text(", but one can also proceed by proving some version of Proposition ")#link(<tao-473c3cba6f0b66454d76>)[#text("4")]#text(".) What happens if the independence hypothesis is dropped?")],
[#text("(iii) If ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(", show that for every ")#mi("{\\varepsilon>0}")#text(" there exists ")#mi("{K>0}")#text(" such that ")#tao-math("{{\\bf P}( \\left|X_n\\right| \\geq K ) < \\varepsilon}", block: false)#text(" for all sufficiently large ")#mi("{n}")#text(". (That is to say, ")#mi("{X_n}")#text(" is a ")#link("https://en.wikipedia.org/wiki/Tightness_of_measures")[#text("tight sequence")]#text(" of random variables.)")],
[#text("(iv) Show that ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(" if and only if, after extending the probability space model if necessary, one can find copies ")#mi("{Z_1,Z_2,\\dots}")#text(" and ")#mi("{Z}")#text(" of ")#mi("{X_1,X_2,\\dots}")#text(" and ")#mi("{X}")#text(" respectively such that ")#mi("{Z_n}")#text(" converges almost surely to ")#mi("{Z}")#text(". (")#emph[#text("Hint:")]#text(" use the Skorohod representation, Exercise 29 of ")#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/")[#text("Notes 0")]#text(".)")],
[#text("(v) If ")#mi("{X_1,X_2,\\dots}")#text(" converges in distribution to ")#mi("{X}")#text(", and ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" is continuous, show that ")#mi("{F(X_1),F(X_2),\\dots}")#text(" converges in distribution to ")#mi("{F(X)}")#text(". Generalise this claim to the case when ")#mi("{X}")#text(" takes values in an arbitrary locally compact Hausdorff space.")],
[#text("(vi) (")#link("https://en.wikipedia.org/wiki/Slutsky%27s_theorem")[#text("Slutsky’s theorem")]#text(") If ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(", and ")#mi("{Y_n}")#text(" converges in probability to a ")#emph[#text("deterministic")]#text(" limit ")#mi("{Y}")#text(", show that ")#mi("{X_n+Y_n}")#text(" converges in distribution to ")#mi("{X+Y}")#text(", and ")#mi("{X_n Y_n}")#text(" converges in distribution to ")#mi("{XY}")#text(". (Hint: either use (iv), or else use (iii) to control some error terms.) This statement combines particularly well with (i). What happens if ")#mi("{Y}")#text(" is not assumed to be deterministic?")],
[#text("(vii) (Fatou lemma) If ")#mi("{G: {\\bf R} \\rightarrow [0,+\\infty)}")#text(" is continuous, and ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(", show that ")#mi("{\\liminf_{n \\rightarrow \\infty} {\\bf E} G(X_n) \\geq {\\bf E} G(X)}")#text(".")],
[#text("(viii) (Bounded convergence) If ")#mi("{G: {\\bf R} \\rightarrow {\\bf R}}")#text(" is continuous and bounded, and ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(", show that ")#mi("{\\lim_{n \\rightarrow \\infty} {\\bf E} G(X_n) = {\\bf E} G(X)}")#text(".")],
[#text("(ix) (Dominated convergence) If ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(", and there is an absolutely integrable ")#mi("{Y}")#text(" such that ")#tao-math("{\\left|X_n\\right| \\leq Y}", block: false)#text(" almost surely for all ")#mi("{n}")#text(", show that ")#mi("{\\lim_{n \\rightarrow \\infty} {\\bf E} X_n = {\\bf E} X}")#text(".")]
)
]

#text("For future reference we also mention (but will not prove) ")#link("https://en.wikipedia.org/wiki/Prokhorov%27s_theorem")[#text("Prokhorov’s theorem")]#text(" that gives a partial converse to part (iii) of the above exercise:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 11 (Prokhorov’s theorem)")]#text(" ")#metadata(none) <tao-7a9d53f34ec8a3bc03b8>#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be a sequence of real random variables which is tight (that is, for every ")#mi("{\\varepsilon>0}")#text(" there exists ")#mi("{K>0}")#text(" such that ")#tao-math("{{\\bf P}(\\left|X_n\\right| \\geq K) < \\varepsilon}", block: false)#text(" for all sufficiently large ")#mi("{n}")#text("). Then there exists a subsequence ")#mi("{X_{n_j}}")#text(" which converges in distribution to some random variable ")#mi("{X}")#text(" (which may possibly be modeled by a different probability space model than the ")#mi("{X_1,X_2,\\dots}")#text(".)")
]

#text("The proof of this theorem relies on the Riesz representation theorem, and is beyond the scope of this course; but see for instance Exercise 29 of ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("this previous blog post")]#text(". (See also the closely related ")#link("http://en.wikipedia.org/wiki/Helly%27s_selection_theorem")[#text("Helly selection theorem")]#text(", covered in Exercise 30 of the same post.)")

#strong[#text(" — 1. The Lindeberg approach to the central limit theorem — ")]

#text("We now give the Lindeberg argument establishing the central limit theorem. The proof splits into two unrelated components. The first component is to establish the central limit theorem for a ")#emph[#text("single")]#text(" choice of underlying random variable ")#mi("{X}")#text(". The second component is to show that the limiting distribution of ")#mi("{\\frac{\\sqrt{n}}{\\sigma} (\\frac{S_n}{n} - \\mu)}")#text(" is ")#emph[#text("universal")]#text(" in the sense that it does not depend on the choice of underlying random variable. Putting the two components together gives Theorem ")#link(<tao-667ae99a22d281e83efd>)[#text("8")]#text(".")

#text("We begin with the first component of the argument. One could use the Bernoulli distribution from Exercise ")#link(<tao-bf89c2eb19a71b812e51>)[#text("9")]#text(" as the choice of underlying random variable, but a simpler choice of distribution (in the sense that no appeal to Stirling’s formula is required) is the normal distribution ")#mi("{N(\\mu,\\sigma^2)}")#text(" itself. The key computation is:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 12 (Sum of independent Gaussians)")]#text(" ")#metadata(none) <tao-a543997d84f12798350c>#text(" Let ")#mi("{X_1, X_2}")#text(" be independent real random variables with normal distributions ")#mi("{N(\\mu_1,\\sigma_1^2)}")#text(", ")#mi("{N(\\mu_2,\\sigma_2^2)}")#text(" respectively for some ")#mi("{\\mu_1,\\mu_2 \\in {\\bf R}}")#text(" and ")#mi("{\\sigma_1,\\sigma_2 > 0}")#text(". Then ")#mi("{X_1+X_2}")#text(" has the normal distribution ")#mi("{N(\\mu_1+\\mu_2, \\sigma_1^2+\\sigma_2^2)}")#text(".")
]

#text("This is of course consistent with the additivity of mean and variance for independent random variables, given that random variables with the distribution ")#mi("{N(\\mu,\\sigma^2)}")#text(" have mean ")#mi("{\\mu}")#text(" and variance ")#mi("{\\sigma^2}")#text(".")

#emph[#text("Proof:")]#text(" By subtracting ")#mi("{\\mu_1}")#text(" and ")#mi("{\\mu_2}")#text(" from ")#mi("{X_1,X_2}")#text(" respectively, we may normalise ")#mi("{\\mu_1=\\mu_2=0}")#text(", by dividing through by ")#mi("{\\sqrt{\\sigma_1^2+\\sigma_2^2}}")#text(" we may also normalise ")#mi("{\\sigma_1^2+\\sigma_2^2=1}")#text(". Thus")

#mi("\\displaystyle {\\bf P}( X_1 \\in E_1 ) = \\frac{1}{\\sqrt{2\\pi} \\sigma_1} \\int_{E_1} e^{-x_1^2 / 2\\sigma_1^2}\\ dx_1")

#text("and")

#mi("\\displaystyle {\\bf P}( X_2 \\in E_2 ) = \\frac{1}{\\sqrt{2\\pi} \\sigma_2} \\int_{E_2} e^{-x_2^2 / 2\\sigma_2^2}\\ dx_2")

#text("for any Borel sets ")#mi("{E_1,E_2 \\subset {\\bf R}}")#text(". As ")#mi("{X_1,X_2}")#text(" are independent, this implies that")

#mi("\\displaystyle {\\bf P}( (X_1,X_2) \\in E ) = \\frac{1}{2\\pi \\sigma_1 \\sigma_2} \\int_E e^{-x_1^2/2\\sigma_1^2 - x_2^2/2\\sigma_2^2}\\ dx_1 dx_2")

#text("for any Borel set ")#mi("{E \\subset {\\bf R}^2}")#text(" (this follows from the uniqueness of product measure, or equivalently one can use the monotone class lemma starting from the case when ")#mi("{E}")#text(" is a finite boolean combination of product sets ")#mi("{E_1 \\times E_2}")#text("). In particular, we have")

#mi("\\displaystyle {\\bf P}( X_1 + X_2 \\leq t ) = \\frac{1}{2\\pi \\sigma_1 \\sigma_2} \\int_{{\\bf R}^2} 1_{x_1+x_2 \\leq t} e^{-x_1^2/2\\sigma_1^2 - x_2^2/2\\sigma_2^2}\\ dx_1 dx_2")

#text("for any ")#mi("{t \\in {\\bf R}}")#text(". Making the change of variables ")#mi("{x = x_1 + x_2}")#text(" (and using the Fubini-Tonelli theorem as necessary) we can write the right-hand side as ")#metadata(none) <tao-6b51d431df5d7f141cbe>

#mi("\\displaystyle \\frac{1}{2\\pi \\sigma_1 \\sigma_2} \\int_{-\\infty}^t \\int_{\\bf R} e^{-x_1^2/2\\sigma_1^2 - (x-x_1)^2/2\\sigma_2^2}\\ dx_1 dx. \\ \\ \\ \\ \\ (2)")

#text("We can complete the square using ")#mi("{\\sigma_1^2+\\sigma_2^2=1}")#text(" to write (after some routine algebra)")

#mi("\\displaystyle e^{-x_1^2/2\\sigma_1^2 - (x-x_1)/2\\sigma_2^2} = e^{-x^2 / 2} e^{-(x_1 - x \\sigma_1^2)^2 / 2 \\sigma_1^2 \\sigma_2^2}")

#text("so on using the identity ")#mi("{\\frac{1}{\\sqrt{2\\pi} \\sigma} \\int_{\\bf R} e^{-(x_1-\\mu)^2/2\\sigma^2}\\ dx_1 = 1}")#text(" for any ")#mi("{\\mu \\in {\\bf R}}")#text(" and ")#mi("{\\sigma>0}")#text(", we can write ")#link(<tao-6b51d431df5d7f141cbe>)[#text("(2)")]#text(" as")

#mi("\\displaystyle \\frac{1}{\\sqrt{2\\pi}} \\int_{-\\infty}^t e^{-x^2 / 2}\\ dx")

#text("and so ")#mi("{X_1+X_2}")#text(" has the cumulative distribution function of ")#mi("{N(0, 1)}")#text(", giving the claim. ")#mi("\\Box")#linebreak()#text(" In the next section we give an alternate proof of the above lemma using the machinery of characteristic functions. A more geometric argument can be given as follows. With the same normalisations as in the above proof, we can write ")#mi("{\\sigma_1 = \\cos \\theta}")#text(" and ")#mi("{\\sigma_2 = \\sin \\theta}")#text(" for some ")#mi("{0 < \\theta < \\pi/2}")#text(". Then we can write ")#mi("{X_1 = \\cos \\theta Y_1}")#text(" and ")#mi("{X_2 = \\sin \\theta Y_2}")#text(" where ")#mi("{Y_1,Y_2}")#text(" are iid copies of ")#mi("{N(0,1)}")#text(". But the joint probability density function ")#mi("{(x_1,x_2) \\mapsto \\frac{1}{2\\pi} e^{-(x_1^2+x_2^2)/2}}")#text(" of ")#mi("{(Y_1,Y_2)}")#text(" is rotation invariant, so ")#mi("{X_1+X_2 = \\cos \\theta Y_1 + \\sin \\theta Y_2}")#text(" has the same distribution as ")#mi("{Y_1}")#text(", and the claim follows.")

#text("From the above lemma we see that if ")#mi("{X_1,X_2,\\dots}")#text(" are iid copies of a normal distribution ")#mi("{N(\\mu,\\sigma^2)}")#text(" of mean ")#mi("{\\mu}")#text(" and variance ")#mi("{\\sigma^2}")#text(", then ")#mi("{S_n = X_1 + \\dots X_n}")#text(" has distribution ")#mi("{N(n \\mu, n \\sigma^2)}")#text(", and hence ")#mi("{\\frac{\\sqrt{n}}{\\sigma} (\\frac{S_n}{n} - \\mu)}")#text(" has distribution exactly equal to ")#mi("{N(0,1)}")#text(". Thus the central limit theorem is clearly true in this case.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Probabilistic interpretation of convolution)")]#text(" Let ")#mi("{f, g: {\\bf R} \\rightarrow [0,+\\infty]}")#text(" be measurable functions with ")#mi("{\\int_{\\bf R} f(x)\\ dx = \\int_{\\bf R} g(x)\\ dx = 1}")#text(". Define the ")#link("https://en.wikipedia.org/wiki/Convolution")[#text("convolution")]#text(" ")#mi("{f*g}")#text(" of ")#mi("{f}")#text(" and ")#mi("{g}")#text(" to be")

#mi("\\displaystyle f*g(x) := \\int_{\\bf R} f(y) g(x-y)\\ dy.")

#text("Show that if ")#mi("{X, Y}")#text(" are independent real random variables with probability density functions ")#mi("{f, g}")#text(" respectively, then ")#mi("{X+Y}")#text(" has probability density function ")#mi("{f*g}")#text(".")
]

#text("Now we turn to the general case of the central limit theorem. By subtracting ")#mi("{\\mu}")#text(" from ")#mi("{X}")#text(" (and from each of the ")#mi("{X_i}")#text(") we may normalise ")#mi("{\\mu = 0}")#text("; by dividing ")#mi("{X}")#text(" (and each of the ")#mi("{X_i}")#text(") by ")#mi("{\\sigma}")#text(" we may also normalise ")#mi("{\\sigma=1}")#text(". Thus ")#mi("{{\\bf E} X = 0, {\\bf E} X^2 = 1}")#text(", and our task is to show that ")#metadata(none) <tao-fac0f4f77309e3e02254>

#mi("\\displaystyle {\\bf E} G( \\frac{X_1+\\dots+X_n}{\\sqrt{n}} ) \\rightarrow {\\bf E} G(N) \\ \\ \\ \\ \\ (3)")

#linebreak()#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", for any continuous compactly supported functions ")#mi("{G: {\\bf R} \\rightarrow {\\bf R}}")#text(", where ")#mi("{N}")#text(" is a random variable distributed according to ")#mi("{N(0,1)}")#text(" (possibly modeled by a different probability space than the original ")#mi("{X_1,X_2,\\dots}")#text("). Since any continuous compactly supported function can be approximated uniformly by smooth compactly supported functions (as can be seen from the Weierstrass or Stone-Weierstrass theorems), it suffices to show this for smooth compactly supported ")#mi("{G}")#text(".")#linebreak()#text(" Let ")#mi("{Y_1,Y_2,\\dots}")#text(" be iid copies of ")#mi("{N}")#text("; by extending the probability space used to model ")#mi("{X_1,X_2,\\dots}")#text(" (using Proposition 26 from ")#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/")[#text("Notes 2")]#text("), we can model the ")#mi("{Y_1,Y_2,\\dots}")#text(" and ")#mi("{X_1,X_2,\\dots}")#text(" by a common model, in such a way that the combined collection ")#mi("{(X_n,Y_n)_{n=1}^\\infty}")#text(" of random variables are jointly independent. As we have already proved the central limit theorem in the normally distributed case, we already have ")#metadata(none) <tao-1906bc7c801f03c41551>

#mi("\\displaystyle {\\bf E} G( \\frac{Y_1+\\dots+Y_n}{\\sqrt{n}} ) \\rightarrow {\\bf E} G(N) \\ \\ \\ \\ \\ (4)")

#linebreak()#text(" as ")#mi("{n \\rightarrow \\infty}")#text(" (indeed we even have equality here). So it suffices to show that ")#metadata(none) <tao-6fcba5d96a4fadfdd630>

#mi("\\displaystyle {\\bf E} G( \\frac{X_1+\\dots+X_n}{\\sqrt{n}} ) - {\\bf E} G( \\frac{Y_1+\\dots+Y_n}{\\sqrt{n}} ) \\rightarrow 0 \\ \\ \\ \\ \\ (5)")

#text("as ")#mi("{n \\rightarrow \\infty}")#text(".")#linebreak()#text(" We first establish this claim under the additional simplifying assumption of a finite third moment: ")#tao-math("{{\\bf E} \\left|X\\right|^3 < \\infty}", block: false)#text(". Rather than swap all of the ")#mi("{X_1,\\dots,X_n}")#text(" with all of the ")#mi("{Y_1,\\dots,Y_n}")#text(", let us just swap the final ")#mi("{X_n}")#text(" to a ")#mi("{Y_n}")#text(", that is to say let us consider the expression")

#mi("\\displaystyle {\\bf E} G( \\frac{X_1+\\dots+X_n}{\\sqrt{n}} ) - {\\bf E} G( \\frac{X_1+\\dots+X_{n-1}+Y_n}{\\sqrt{n}} ).")

#text("Writing ")#mi("{Z := \\frac{X_1 + \\dots + X_{n-1}}{\\sqrt{n}}}")#text(", we can write this as")

#mi("\\displaystyle {\\bf E} G( Z + \\frac{1}{\\sqrt{n}} X_n ) - {\\bf E} G( Z + \\frac{1}{\\sqrt{n}} Y_n ).")

#text("To compute this expression we use Taylor expansion. As ")#mi("{G}")#text(" is smooth and compactly supported, the first three derivatives of ")#mi("{G}")#text(" are bounded, leading to the Taylor approximation")

#tao-math("\\displaystyle G( Z + \\frac{1}{\\sqrt{n}} X_n ) = G(Z) + \\frac{1}{\\sqrt{n}} G^{\\prime}(Z) X_n + \\frac{1}{2n} G^{\\prime\\prime}(Z) X_n^2 + O( \\frac{1}{n^{3/2}} \\left|X_n\\right|^3 )", block: false)

#text("where the implied constant depends on ")#mi("{G}")#text(". Taking expectations, we conclude that")

#mi("\\displaystyle {\\bf E} G( Z + \\frac{1}{\\sqrt{n}} X_n ) = {\\bf E} G(Z) + \\frac{1}{\\sqrt{n}} {\\bf E} G^{\\prime}(Z) X_n + \\frac{1}{2n} {\\bf E} G^{\\prime\\prime}(Z) X_n^2")

#tao-math("\\displaystyle + O( \\frac{1}{n^{3/2}} {\\bf E} \\left|X\\right|^3 ).", block: false)

#text("Now for a key point: as the random variable ")#mi("{Z}")#text(" only depends on ")#mi("{X_1,\\dots,X_{n-1}}")#text(", it is independent of ")#mi("{X_n}")#text(", and so we can decouple the expectations to obtain")

#mi("\\displaystyle {\\bf E} G( Z + \\frac{1}{\\sqrt{n}} X_n ) = {\\bf E} G(Z) + \\frac{1}{\\sqrt{n}} {\\bf E} G^{\\prime}(Z) {\\bf E} X_n + \\frac{1}{2n} {\\bf E} G^{\\prime\\prime}(Z) {\\bf E} X_n^2")

#tao-math("\\displaystyle + O( \\frac{1}{n^{3/2}} {\\bf E} \\left|X\\right|^3 ).", block: false)

#text("The same considerations apply after swapping ")#mi("{X_n}")#text(" with ")#mi("{Y_n}")#text(" (which also has a bounded third moment):")

#mi("\\displaystyle {\\bf E} G( Z + \\frac{1}{\\sqrt{n}} Y_n ) = {\\bf E} G(Z) + \\frac{1}{\\sqrt{n}} {\\bf E} G^{\\prime}(Z) {\\bf E} Y_n + \\frac{1}{2n} {\\bf E} G^{\\prime\\prime}(Z) {\\bf E} Y_n^2")

#mi("\\displaystyle + O( \\frac{1}{n^{3/2}} ).")

#text("But by hypothesis, ")#mi("{X_n}")#text(" and ")#mi("{Y_n}")#text(" have matching moments to second order: ")#mi("{{\\bf E} X_n = {\\bf E} Y_n = 0}")#text(" and ")#mi("{{\\bf E} X_n^2 = {\\bf E} Y_n^2 = 1}")#text(". Thus on subtraction we have")

#mi("\\displaystyle {\\bf E} G( \\frac{X_1+\\dots+X_n}{\\sqrt{n}} ) - {\\bf E} G( \\frac{X_1+\\dots+X_{n-1}+Y_n}{\\sqrt{n}} )")

#tao-math("\\displaystyle = O( \\frac{1}{n^{3/2}} (1 + {\\bf E} \\left|X\\right|^3) ).", block: false)

#text("A similar argument (permuting the indices, and replacing some of the ")#mi("{X_i}")#text(" with ")#mi("{Y_i}")#text(") gives")

#mi("\\displaystyle {\\bf E} G( \\frac{X_1+\\dots+X_i+Y_{i+1}+\\dots+Y_n}{\\sqrt{n}} )")

#mi("\\displaystyle - {\\bf E} G( \\frac{X_1+\\dots+X_{i-1}+Y_i+\\dots+Y_n}{\\sqrt{n}} )")

#tao-math("\\displaystyle = O( \\frac{1}{n^{3/2}} (1 + {\\bf E} \\left|X\\right|^3) )", block: false)

#text("for all ")#mi("{1 \\leq i \\leq n}")#text(". Summing the telescoping series, we conclude that")

#tao-math("\\displaystyle {\\bf E} G( \\frac{X_1+\\dots+X_n}{\\sqrt{n}} ) - {\\bf E} G( \\frac{Y_1+\\dots+Y_n}{\\sqrt{n}} ) = O( \\frac{1}{n^{1/2}} (1 + {\\bf E} \\left|X\\right|^3))", block: false)

#text("which gives ")#link(<tao-6fcba5d96a4fadfdd630>)[#text("(5)")]#text(". Note how it was important to Taylor expand to at least third order to obtain a total error bound that went to zero, which explains why it is the first two moments ")#mi("{{\\bf E} X, {\\bf E} X^2}")#text(" of ")#mi("{X}")#text(" (or equivalently, the mean and variance) that play such a decisive role in the central limit theorem.")#linebreak()#text(" Now we remove the hypothesis of finite third moment. As in the ")#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/")[#text("previous set of notes")]#text(", we use the truncation method, taking advantage of the “room” inherent in the ")#mi("{\\frac{1}{n^{1/2}}}")#text(" factor in the error term of the above analysis. For technical reasons we have to modify the usual truncation slightly to preserve the mean zero condition. Let ")#mi("{\\varepsilon > 0}")#text(". We split ")#mi("{X_i = X_{i,\\leq} + X_{i,>}}")#text(", where ")#tao-math("{X_{i,\\leq} := X_i 1_{\\left|X_i\\right| \\leq \\varepsilon \\sqrt{n}} - \\mu_n}", block: false)#text(" and ")#tao-math("{X_{i,>} := X_i 1_{\\left|X_i\\right| > \\varepsilon \\sqrt{n}} + \\mu_n}", block: false)#text(" with ")#tao-math("{\\mu_n := {\\bf E} X 1_{\\left|X\\right| \\leq \\varepsilon \\sqrt{n}}}", block: false)#text("; we split ")#mi("{X = X_{\\leq} + X_{>}}")#text(" respectively (we are suppressing the dependence of ")#mi("{X_{i,\\leq}, X_{i,>}, X_{\\leq}, X_{>}}")#text(" on ")#mi("{\\varepsilon}")#text(" and ")#mi("{n}")#text(" to simplify the notation). The random variables ")#mi("{X_\\leq}")#text(" (and ")#mi("{X_{i,\\leq}}")#text(") are chosen to have mean zero, but their variance is not quite one. However, from dominated convergence, the quantity ")#tao-math("{\\mu_n := {\\bf E} X 1_{\\left|X\\right| \\leq \\varepsilon \\sqrt{n}}}", block: false)#text(" converges to ")#mi("{0}")#text(", and the variance ")#tao-math("{\\sigma_n^2 := {\\bf Var}(X_{\\leq}) = {\\bf E} \\left|X\\right|^2 1_{\\left|X\\right| \\leq \\varepsilon \\sqrt{n}} - \\mu_n^2}", block: false)#text(" converges to ")#mi("{1}")#text(", as ")#mi("{n \\rightarrow \\infty}")#text(".")

#text("Let ")#mi("{Y^{\\prime}_1,\\dots,Y^{\\prime}_n}")#text(" be iid copies of ")#mi("{N(0,\\sigma_n^2)}")#text(". The previous arguments then give")

#tao-math("\\displaystyle {\\bf E} G( \\frac{X_{1,\\leq}+\\dots+X_{n,\\leq}}{\\sqrt{n}} ) - {\\bf E} G( \\frac{Y^{\\prime}_1+\\dots+Y^{\\prime}_n}{\\sqrt{n}} ) = O( \\frac{1}{n^{1/2}} (1 + {\\bf E} \\left|X_\\leq\\right|^3))", block: false)

#text("for ")#mi("{n}")#text(" large enough. We can bound")

#tao-math("\\displaystyle {\\bf E} \\left|X_\\leq\\right|^3 \\leq {\\bf E} \\varepsilon n^{1/2} \\left|X\\right|^2 = \\varepsilon n^{1/2}", block: false)

#text("and thus")

#mi("\\displaystyle {\\bf E} G( \\frac{X_{1,\\leq}+\\dots+X_{n,\\leq}}{\\sqrt{n}} ) - {\\bf E} G( \\frac{Y^{\\prime}_1+\\dots+Y^{\\prime}_n}{\\sqrt{n}} ) = O( \\varepsilon )")

#text("for large enough ")#mi("{n}")#text(". By Lemma ")#link(<tao-a543997d84f12798350c>)[#text("12")]#text(", ")#mi("{\\frac{Y^{\\prime}_1+\\dots+Y^{\\prime}_n}{\\sqrt{n}}}")#text(" is distributed as ")#mi("{N(0,\\sigma_n)}")#text(", and hence")

#mi("\\displaystyle {\\bf E} G( \\frac{Y^{\\prime}_1+\\dots+Y^{\\prime}_n}{\\sqrt{n}} ) \\rightarrow {\\bf E} G(N)")

#text("as ")#mi("{n \\rightarrow \\infty}")#text(". We conclude that")

#mi("\\displaystyle {\\bf E} G( \\frac{X_{1,\\leq}+\\dots+X_{n,\\leq}}{\\sqrt{n}} ) = {\\bf E} G(N) + O( \\varepsilon ).")

#text("Next, we consider the error term")

#mi("\\displaystyle \\frac{X_{1,>}+\\dots+X_{n,>}}{\\sqrt{n}}.")

#text("The variable ")#mi("{X_>}")#text(" has mean zero, and by dominated convergence, the variance of ")#mi("{X_>}")#text(" goes to zero as ")#mi("{n \\rightarrow \\infty}")#text(". The above error term is also mean zero and has the same variance as ")#mi("{X_>}")#text(". In particular, from Cauchy-Schwarz we have")

#tao-math("\\displaystyle {\\bf E} \\left|\\frac{X_{1,>}+\\dots+X_{n,>}}{\\sqrt{n}}\\right| \\rightarrow 0.", block: false)

#text("As ")#mi("{G}")#text(" is smooth and compactly supported, it is Lipschitz continuous, and hence")

#tao-math("\\displaystyle G( \\frac{X_{1}+\\dots+X_{n}}{\\sqrt{n}} ) = G( \\frac{X_{1,\\leq}+\\dots+X_{n,\\leq}}{\\sqrt{n}} ) + O( \\left|\\frac{X_{1,>}+\\dots+X_{n,>}}{\\sqrt{n}}\\right| ).", block: false)

#text("Taking expectations, and then combining all these estimates, we conclude that")

#mi("\\displaystyle {\\bf E} G( \\frac{X_{1}+\\dots+X_{n}}{\\sqrt{n}} ) = {\\bf E} G(N) + O( \\varepsilon )")

#text("for ")#mi("{n}")#text(" sufficiently large; letting ")#mi("{n}")#text(" go to infinity we obtain ")#link(<tao-fac0f4f77309e3e02254>)[#text("(3)")]#text(" as required. This concludes the proof of Theorem ")#link(<tao-667ae99a22d281e83efd>)[#text("8")]#text(".")#linebreak()#text(" The above argument can be generalised to a central limit theorem for certain triangular arrays, known as the ")#link("https://en.wikipedia.org/wiki/Central_limit_theorem#Lindeberg_CLT")[#text("Lindeberg central limit theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14 (Lindeberg central limit theorem)")]#text(" ")#metadata(none) <tao-c50155e0f3f4c79d78d2>#text(" Let ")#mi("{k_n}")#text(" be a sequence of natural numbers going to infinity in ")#mi("{n}")#text(". For each natural number ")#mi("{n}")#text(", let ")#mi("{X_{1,n},\\dots,X_{k_n,n}}")#text(" be jointly independent real random variables of mean zero and finite variance. (We do not require the random variables ")#mi("{(X_{1,n},\\dots,X_{k_n,n})}")#text(" to be jointly independent in ")#mi("{n}")#text(", or even to be modeled by a common probability space.) Let ")#mi("{\\sigma_n}")#text(" be defined by")

#mi("\\displaystyle \\sigma_n^2 := \\sum_{i=1}^{k_n} {\\bf Var}(X_{i,n})")

#text("and assume that ")#mi("{\\sigma_n>0}")#text(" for all ")#mi("{n}")#text(".")

#list(
[#text("(i) If one assumes the ")#link("https://en.wikipedia.org/wiki/Lindeberg%27s_condition")[#text("Lindeberg condition")]#text(" that")#linebreak()

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\sigma_n^2} \\sum_{i=1}^{k_n} {\\bf E}( \\left|X_{i,n}\\right|^2 1_{\\left|X_{i,n}\\right| > \\varepsilon \\sigma_n} ) \\rightarrow 0", block: true)]]

#linebreak()

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" for any ")#mi("{\\varepsilon > 0}")#text(", then show that the random variables ")#mi("{\\frac{X_{1,n}+\\dots+X_{k_n,n}}{\\sigma_n}}")#text(" converge in distribution to a random variable with the normal distribution ")#mi("{N(0,1)}")#text(".")],
[#text("(ii) Show that the Lindeberg condition implies the ")#emph[#text("Feller condition")]#linebreak()

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\sigma_n^2} \\max_{1 \\leq i \\leq k_n} {\\bf E} \\left|X_{i,n}\\right|^2 \\rightarrow 0", block: true)]]

#linebreak()

#text("as ")#mi("{n \\rightarrow \\infty}")#text(".")]
)
]

#text("Note that Theorem ")#link(<tao-667ae99a22d281e83efd>)[#text("8")]#text(" (after normalising to the mean zero case ")#mi("{\\mu=0}")#text(") corresponds to the special case ")#mi("{k_n = n}")#text(" and ")#mi("{X_{i,n} := X_i}")#text(" (or, if one wishes, ")#mi("{X_{i,n} := X_i/\\sqrt{n}}")#text(") of the Lindeberg central limit theorem. It was shown by Feller that if the situation as in the above exercise and the Feller condition holds, then the Lindeberg condition is necessary as well as sufficient for ")#mi("{X_{1,n}+\\dots+X_{k_n,n}}")#text(" to converge in distribution to a random variable with normal distribution ")#mi("{N(0,\\sigma^2)}")#text("; the combined result is sometimes known as the ")#emph[#text("Lindeberg-Feller theorem")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Weak Berry-Esséen theorem)")]#text(" Let ")#mi("{X_1,\\dots,X_n}")#text(" be iid copies of a real random variable ")#mi("{X}")#text(" of mean zero, unit variance, and finite third moment.")

#list(
[#text("(i) Show that")#linebreak()

#align(center)[#tao-fit-display[#tao-math("{\\bf E} G( \\frac{X_1+\\dots+X_n}{\\sqrt{n}}) = {\\bf E} G(N) + O( n^{-1/2} (\\sup_{x \\in {\\bf R}} \\left|G^{\\prime\\prime\\prime}(x)\\right|) {\\bf E} \\left|X\\right|^3 )", block: true)]]

#linebreak()

#text("whenever ")#mi("{G}")#text(" is three times continuously differentiable and compactly supported, with ")#mi("{N}")#text(" distributed as ")#mi("{N(0,1)}")#text(" and the implied constant in the ")#mi("{O()}")#text(" notation absolute.")],
[#text("(ii) Show that")#linebreak()

#align(center)[#tao-fit-display[#tao-math("{\\bf P} ( \\frac{X_1+\\dots+X_n}{\\sqrt{n}} \\leq t ) = {\\bf P}( N \\leq t) + O( n^{-1/2} {\\bf E} \\left|X\\right|^3 )^{1/4}", block: true)]]

#linebreak()

#text("for any ")#mi("{t \\in {\\bf R}}")#text(", with the implied constant absolute.")]
)
]

#text("We will strengthen the conclusion of this theorem in Theorem ")#link(<tao-be5fe2ee6cf8d5a95850>)[#text("37")]#text(" below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 16")]#text(" The Lindeberg exchange method explains why the limiting distribution of statistics such as ")#mi("{\\frac{X_1+\\dots+X_n}{\\sqrt{n}}}")#text(" depend primarily on the first two moments of the component random variables ")#mi("{X_i}")#text(", if there is a suitable amount of independence between the ")#mi("{X_i}")#text(". It turns out that there is an analogous application of the Lindeberg method in random matrix theory, which (very roughly speaking) asserts that appropriate statistics of random matrices such as ")#mi("{(X_{ij})_{1 \\leq i, j \\leq n}}")#text(" depend primarily on the first four moments of the matrix components ")#mi("{X_{ij}}")#text(", if there is a suitable amount of independence between the ")#mi("{X_{ij}}")#text(". See for instance ")#link("https://terrytao.wordpress.com/2011/12/12/random-matrices-the-four-moment-theorem-for-wigner-ensembles/")[#text("this survey article of Van Vu and myself")]#text(" for more discussion of this. The Lindeberg method also suggests that the more moments of ")#mi("{X}")#text(" one assumes to match with the Gaussian variable ")#mi("{N}")#text(", the faster the rate of convergence (because one can use higher order Taylor expansions).")
]

#text("We now use the Lindeberg central limit theorem to obtain the converse direction of the Kolmogorov three-series theorem (Exercise 29 of ")#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/")[#text("Notes 3")]#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17 (Kolmogorov three-series theorem, converse direction)")]#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be a sequence of jointly independent real random variables, with the property that the series ")#mi("{\\sum_{n=1}^\\infty X_n}")#text(" is almost surely convergent (i.e., the partial sums are almost surely convergent), and let ")#mi("{A>0}")#text(".")

#list(
[#text("(i) Show that ")#tao-math("{\\sum_{n=1}^\\infty {\\bf P}( \\left|X_n\\right| > A )}", block: false)#text(" is finite. (")#emph[#text("Hint:")]#text(" argue by contradiction and use the second Borel-Cantelli lemma.)")],
[#text("(ii) Show that ")#tao-math("{\\sum_{n=1}^\\infty {\\bf Var}( X_n 1_{\\left|X_n\\right| \\leq A} )}", block: false)#text(" is finite. (")#emph[#text("Hint:")]#text(" first use (i) and the Borel-Cantelli lemma to reduce to the case where ")#tao-math("{\\left|X_n\\right| \\leq A}", block: false)#text(" almost surely. If ")#mi("{\\sum_{n=1}^\\infty {\\bf Var}(X_n)}")#text(" is infinite, use Exercise ")#link(<tao-c50155e0f3f4c79d78d2>)[#text("14")]#text(" to show that ")#mi("{\\sum_{n=1}^N (X_n-{\\bf E}X_n) / \\sqrt{\\sum_{n=1}^N {\\bf Var}(X_n)}}")#text(" converges in distribution to a standard normal distribution, and use this to contradict the almost sure convergence of ")#mi("{\\sum_{n=1}^\\infty X_n}")#text(".)")],
[#text("(iii) Show that the series ")#tao-math("{\\sum_{n=1}^\\infty {\\bf E} X_n 1_{\\left|X_n\\right| \\leq A}}", block: false)#text(" is convergent. (")#emph[#text("Hint:")]#text(" reduce as before to the case where ")#tao-math("{\\left|X_n\\right| \\leq A}", block: false)#text(" almost surely, and apply the forward direction of the three-series theorem to ")#mi("{\\sum_n X_n - {\\bf E} X_n}")#text(".)")]
)
]

#strong[#text(" — 2. The Fourier-analytic approach to the central limit theorem — ")]

#text("Let us now give the standard Fourier-analytic proof of the central limit theorem. Given any real random variable ")#mi("{X}")#text(", we introduce the ")#link("https://en.wikipedia.org/wiki/Characteristic_function_(probability_theory)")[#text("characteristic function")]#text(" ")#mi("{\\varphi_X: {\\bf R} \\rightarrow {\\bf C}}")#text(", defined by the formula ")#metadata(none) <tao-ec222e8a5c1f4e1867c6>

#mi("\\displaystyle \\varphi_X(t) := {\\bf E} e^{itX}. \\ \\ \\ \\ \\ (6)")

#linebreak()#text(" Equivalently, ")#mi("{\\varphi_X}")#text(" is the Fourier transform of the probability measure ")#mi("{\\mu_X}")#text(". One should caution that the term “characteristic function” has ")#link("https://en.wikipedia.org/wiki/Characteristic_function")[#text("several other unrelated meanings in mathematics")]#text("; particularly confusingly, in real analysis “characteristic function” is used to denote what in probability one would call an “indicator function”. Note that no moment hypotheses are required to define the characteristic function, because the random variable ")#mi("{e^{itX}}")#text(" is bounded even when ")#mi("{X}")#text(" is not absolutely integrable.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 18")]#text(" ")#metadata(none) <tao-e99270c4fa9f6ea70486>#text(" The signed Bernoulli distribution, which takes the values ")#mi("{+1}")#text(" and ")#mi("{-1}")#text(" with probabilities of ")#mi("{1/2}")#text(" each, has characteristic function ")#mi("{\\phi(t) = \\cos(t)}")#text(".")
]

#text("Most of the standard random variables in probability have characteristic functions that are quite simple and explicit. For the purposes of proving the central limit theorem, the most important such explicit form of the characteristic function is of the normal distribution:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" ")#metadata(none) <tao-1d359c60ec04e10677d7>#text(" Show that the normal distribution ")#mi("{N(\\mu,\\sigma^2)}")#text(" has characteristic function ")#mi("{\\phi(t) = e^{it\\mu} e^{-\\sigma^2 t^2/2}}")#text(".")
]

#text("We record the explicit characteristic functions of some other standard distributions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Let ")#mi("{\\lambda > 0}")#text(", and let ")#mi("{X}")#text(" be a Poisson random variable with intensity ")#mi("{\\lambda}")#text(", thus ")#mi("{X}")#text(" takes values in the non-negative integers with ")#mi("{{\\bf P}(X=k) = e^{-\\lambda} \\frac{\\lambda^k}{k!}}")#text(". Show that ")#mi("{\\varphi_X(t) = \\exp( \\lambda(e^{it}-1) )}")#text(" for all ")#mi("{t \\in {\\bf R}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Let ")#mi("{X}")#text(" be uniformly distributed in some interval ")#mi("{[a,b]}")#text(". Show that ")#mi("{\\varphi_X(t) = \\frac{e^{itb}-e^{ita}}{it(b-a)}}")#text(" for all non-zero ")#mi("{t}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Let ")#mi("{x_0 \\in {\\bf R}}")#text(" and ")#mi("{\\gamma > 0}")#text(", and let ")#mi("{X}")#text(" be a Cauchy random variable with parameters ")#mi("{x_0,\\gamma}")#text(", which means that ")#mi("{X}")#text(" is a real random variable with probability density function ")#mi("{\\frac{\\gamma}{\\pi ((x-x_0)^2+\\gamma^2)}}")#text(". Show that ")#tao-math("{\\varphi_X(t) = e^{ix_0 t} e^{-\\gamma \\left|t\\right|}}", block: false)#text(" for all ")#mi("{t \\in {\\bf R}}")#text(".")
]

#text("The characteristic function is clearly bounded in magnitude by ")#mi("{1}")#text(", and equals ")#mi("{1}")#text(" at the origin. By the dominated convergence theorem, ")#mi("{\\varphi_X}")#text(" is continuous in ")#mi("{t}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23 (Riemann-Lebesgue lemma)")]#text(" Show that if ")#mi("{X}")#text(" is a real random variable that has an absolutely integrable probability density function ")#mi("{f}")#text(", then ")#mi("{\\varphi_X(t) \\rightarrow 0}")#text(" as ")#mi("{t \\rightarrow \\infty}")#text(". (")#emph[#text("Hint:")]#text(" first show the claim when ")#mi("{f}")#text(" is a finite linear combination of intervals, then for the general case show that ")#mi("{f}")#text(" can be approximated in ")#mi("{L^1}")#text(" norm by such finite linear combinations.) Note from Example ")#link(<tao-e99270c4fa9f6ea70486>)[#text("18")]#text(" that the claim can fail if ")#mi("{X}")#text(" does not have a probability density function. (In Fourier analysis, this fact is known as the ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93Lebesgue_lemma")[#text("Riemann-Lebesgue lemma")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Show that the characteristic function ")#mi("{\\varphi_X}")#text(" of a real random variable ")#mi("{X}")#text(" is in fact ")#link("http://en.wikipedia.org/wiki/Uniform_continuity")[#text("uniformly continuous")]#text(" on its domain.")
]

#text("Let ")#mi("{X}")#text(" be a real random variable. If we Taylor expand ")#mi("{e^{itX}}")#text(" and formally interchange the series and expectation, we arrive at the heuristic identity ")#metadata(none) <tao-bcbb0eeac8d6a4240d57>

#mi("\\displaystyle \\varphi_X(t) = \\sum_{k=0}^\\infty \\frac{(it)^k}{k!} {\\bf E} X^k \\ \\ \\ \\ \\ (7)")

#linebreak()#text(" which thus interprets the characteristic function of a real random variable ")#mi("{X}")#text(" as a kind of generating function for the moments. One rigorous version of this identity is as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25 (Taylor expansion of characteristic function)")]#text(" ")#metadata(none) <tao-9d4c90764c2da7f5a69d>#text(" Let ")#mi("{X}")#text(" be a real random variable with finite ")#mi("{k^{th}}")#text(" moment for some ")#mi("{k \\geq 1}")#text(". Show that ")#mi("{\\varphi_X}")#text(" is ")#mi("{k}")#text(" times continuously differentiable, with")

#mi("\\displaystyle \\frac{d^j}{dt^j} \\varphi_X(t) = i^j {\\bf E} X^j e^{itX}")

#text("for all ")#mi("{0 \\leq j \\leq k}")#text(". Conclude in particular the partial Taylor expansion")

#tao-math("\\displaystyle \\varphi_X(t) = \\sum_{j=0}^k \\frac{(it)^j}{j!} {\\bf E} X^j + o( \\left|t\\right|^k )", block: false)

#text("where ")#tao-math("{o(\\left|t\\right|^k)}", block: false)#text(" is a quantity that goes to zero as ")#mi("{t \\rightarrow 0}")#text(", times ")#tao-math("{\\left|t\\right|^k}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" ")#metadata(none) <tao-633ac296aa882e8a15dd>#text(" Let ")#mi("{X}")#text(" be a real random variable, and assume that it is ")#emph[#text("subgaussian")]#text(" in the sense that there exist constants ")#mi("{C, c > 0}")#text(" such that")

#tao-math("\\displaystyle {\\bf P}( \\left|X\\right| \\geq t ) \\leq C e^{-ct^2}", block: false)

#text("for all ")#mi("{t \\in {\\bf R}}")#text(". (Thus for instance a bounded random variable is subgaussian, as is any gaussian random variable.) Rigorously establish ")#link(<tao-bcbb0eeac8d6a4240d57>)[#text("(7)")]#text(" in this case, and show that the series converges locally uniformly in ")#mi("{t}")#text(".")
]

#text("Note that the characteristic function depends only on the distribution of ")#mi("{X}")#text(": if ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are equal in distribution, then ")#mi("{\\varphi_X = \\varphi_Y}")#text(". The converse statement is true also: if ")#mi("{\\varphi_X=\\varphi_Y}")#text(", then ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are equal in distribution. This follows from a more general (and useful) fact, known as ")#link("http://en.wikipedia.org/wiki/L%C3%A9vy%27s_continuity_theorem")[#text("Lévy’s continuity theorem")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 27 (Lévy continuity theorem, special case)")]#text(" ")#metadata(none) <tao-5a1a84de8c2ec09ba6b5>#text(" Let ")#mi("{X_n}")#text(" be a sequence of real random variables, and let ")#mi("{X}")#text(" be an additional real random variable. Then the following statements are equivalent:")

#list(
[#text("(i) ")#mi("{\\varphi_{X_n}}")#text(" converges pointwise to ")#mi("{\\varphi_X}")#text(".")],
[#text("(ii) ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" The implication of (i) from (ii) is immediate from ")#link(<tao-ec222e8a5c1f4e1867c6>)[#text("(6)")]#text(" and Exercise ")#link(<tao-b0846c4700fc211e6822>)[#text("10")]#text("(viii).")

#text("Now suppose that (i) holds, and we wish to show that (ii) holds. We need to show that")

#mi("\\displaystyle {\\bf E} G(X_n) \\rightarrow {\\bf E} G(X)")

#text("whenever ")#mi("{G: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a continuous, compactly supported function. As in the Lindeberg argument, it suffices to prove this when ")#mi("{G}")#text(" is smooth and compactly supported, in particular ")#mi("{G}")#text(" is a ")#link("https://en.wikipedia.org/wiki/Schwartz_space")[#text("Schwartz function")]#text(" (infinitely differentiable, with all derivatives rapidly decreasing). But then we have the Fourier inversion formula")

#mi("\\displaystyle G(X_n) = \\int_{{\\bf R}} \\hat G(t) e^{it \\cdot X_n}\\ dt")

#text("where")

#mi("\\displaystyle \\hat G(t) := \\frac{1}{2\\pi} \\int_{{\\bf R}} G(x) e^{-it \\cdot x}\\ dx")

#text("is Schwartz, and is in particular absolutely integrable (see e.g. these ")#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")[#text("lecture notes of mine")]#text("). From the Fubini-Tonelli theorem, we thus have ")#metadata(none) <tao-e215f82eb7d66a8ea261>

#mi("\\displaystyle {\\bf E} G(X_n) = \\int_{{\\bf R}} \\hat G(t) \\varphi_{X_n}(t)\\ dt \\ \\ \\ \\ \\ (8)")

#text("and similarly for ")#mi("{X}")#text(". The claim now follows from the Lebesgue dominated convergence theorem. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 28")]#text(" ")#metadata(none) <tao-6f482b0b6604c69c6a3c>#text(" Setting ")#mi("{X_n := Y}")#text(" for all ")#mi("{n}")#text(", we see in particular the previous claim that ")#mi("{\\varphi_X = \\varphi_Y}")#text(" if and only if ")#mi("{X}")#text(", ")#mi("{Y}")#text(" have the same distribution. It is instructive to use the above proof as a guide to prove this claim directly.")
]

#text("There is one subtlety with the Lévy continuity theorem: it is possible for a sequence ")#mi("{\\varphi_{X_n}}")#text(" of characteristic functions to converge pointwise, but for the limit to not be the characteristic function of any random variable, in which case ")#mi("{X_n}")#text(" will not converge in distribution. For instance, if ")#mi("{X_n \\equiv N(0,n)}")#text(", then ")#mi("{\\varphi_{X_n}(t) = e^{-t^2/2n}}")#text(" converges pointwise to ")#mi("{1_{t=0}}")#text(" for any ")#mi("{t}")#text(", but this is clearly not the characteristic function of any random variable (as characteristic functions are continuous). However, this lack of continuity is the only obstruction:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29 (Lévy’s continuity theorem, full version)")]#text(" Let ")#mi("{X_n}")#text(" be a sequence of real valued random variables. Suppose that ")#mi("{\\varphi_{X_n}}")#text(" converges pointwise to a limit ")#mi("{\\varphi}")#text(". Show that the following are equivalent:")

#list(
[#text("(i) ")#mi("{\\varphi}")#text(" is continuous at ")#mi("{0}")#text(".")],
[#text("(ii) ")#mi("{X_n}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Tightness_of_measures")[#text("tight")]#text(" sequence (as in Exercise ")#link(<tao-b0846c4700fc211e6822>)[#text("10")]#text("(iii)).")],
[#text("(iii) ")#mi("{\\varphi}")#text(" is the characteristic function of a real valued random variable ")#mi("{X}")#text(" (possibly after extending the sample space).")],
[#text("(iv) ")#mi("{X_n}")#text(" converges in distribution to some real valued random variable ")#mi("{X}")#text(" (possibly after extending the sample space).")]
)

#emph[#text("Hint")]#text(": To get from (ii) to the other conclusions, use Theorem ")#link(<tao-7a9d53f34ec8a3bc03b8>)[#text("11")]#text(" and Theorem ")#link(<tao-5a1a84de8c2ec09ba6b5>)[#text("27")]#text(". To get back to (ii) from (i), use ")#link(<tao-e215f82eb7d66a8ea261>)[#text("(8)")]#text(" for a suitable Schwartz function ")#mi("{G}")#text(". The other implications are easy once Theorem ")#link(<tao-5a1a84de8c2ec09ba6b5>)[#text("27")]#text(" is in hand.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 30")]#text(" Lévy’s continuity theorem is very similar in spirit to ")#link("http://en.wikipedia.org/wiki/Weyl%27s_criterion")[#text("Weyl’s criterion")]#text(" in equidistribution theory.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31 (Esséen concentration inequality)")]#text(" Let ")#mi("{X}")#text(" be a random variable taking values in ")#mi("{{\\bf R}}")#text(". Then for any ")#mi("{r>0}")#text(", ")#mi("{\\varepsilon > 0}")#text(", show that ")#metadata(none) <tao-5b0435f03790e0fa682d>

#tao-math("\\displaystyle \\sup_{x_0 \\in {\\bf R}} {\\bf P}( \\left|X - x_0\\right| \\leq r ) \\leq C_{\\varepsilon} r \\int_{t \\in {\\bf R}: \\left|t\\right| \\leq \\varepsilon/r} |\\varphi_X(t)|\\ dt \\ \\ \\ \\ \\ (9)", block: false)

#text("for some constant ")#mi("{C_{\\varepsilon}}")#text(" depending only on ")#mi("{\\varepsilon}")#text(". (")#emph[#text("Hint:")]#text(" Use ")#link(<tao-e215f82eb7d66a8ea261>)[#text("(8)")]#text(" for a suitable Schwartz function ")#mi("{G}")#text(".) The left-hand side of ")#link(<tao-5b0435f03790e0fa682d>)[#text("(9)")]#text(" (as well as higher dimensional analogues of this quantity) is known as the ")#emph[#text("small ball probability")]#text(" of ")#mi("{X}")#text(" at radius ")#mi("{r}")#text(".")
]

#text("In Fourier analysis, we learn that the Fourier transform is a particularly well-suited tool for studying convolutions. The probability theory analogue of this fact is that characteristic functions are a particularly well-suited tool for studying sums of independent random variables. More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32 (Fourier identities)")]#text(" ")#metadata(none) <tao-2e1712f7908f611efbf8>#text(" Let ")#mi("{X, Y}")#text(" be independent real random variables. Then ")#metadata(none) <tao-8bda670c0fd677f51186>

#mi("\\displaystyle \\varphi_{X+Y}(t) = \\varphi_X(t) \\varphi_Y(t) \\ \\ \\ \\ \\ (10)")

#text("for all ")#mi("{t \\in V}")#text(". Also, for any scalar ")#mi("{c}")#text(", one has")

#mi("\\displaystyle \\varphi_{cX}(t) = \\varphi_X(\\overline{c}t)")

#text("and more generally, for any linear transformation ")#mi("{T: V \\rightarrow V}")#text(", one has")

#mi("\\displaystyle \\varphi_{TX}(t) = \\varphi_X(T^*t).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 33")]#text(" Note that this identity ")#link(<tao-8bda670c0fd677f51186>)[#text("(10)")]#text(", combined with Exercise ")#link(<tao-1d359c60ec04e10677d7>)[#text("19")]#text(" and Remark ")#link(<tao-6f482b0b6604c69c6a3c>)[#text("28")]#text(", gives a quick alternate proof of Lemma ")#link(<tao-a543997d84f12798350c>)[#text("12")]#text(".")
]

#text("In particular, we have the simple relationship ")#metadata(none) <tao-8b5b14c53b1345927e8a>

#mi("\\displaystyle \\varphi_{S_n/\\sqrt{n}}(t) = \\varphi_X( t / \\sqrt{n} )^n \\ \\ \\ \\ \\ (11)")

#linebreak()#text(" that describes the characteristic function of ")#mi("{S_n/\\sqrt{n}}")#text(" in terms of that of ")#mi("{X}")#text(".")#linebreak()#text(" We now have enough machinery to give a quick proof of the central limit theorem:")

#emph[#text("Proof:")]#text(" (Fourier proof of Theorem ")#link(<tao-667ae99a22d281e83efd>)[#text("8")]#text(") We may normalise ")#mi("{X}")#text(" to have mean zero and variance ")#mi("{1}")#text(". By Exercise ")#link(<tao-9d4c90764c2da7f5a69d>)[#text("25")]#text(", we thus have")

#tao-math("\\displaystyle \\varphi_X(t) = 1 - t^2/2 + o(\\left|t\\right|^2)", block: false)

#text("for sufficiently small ")#mi("{t}")#text(", or equivalently")

#tao-math("\\displaystyle \\varphi_X(t) = \\exp( - t^2/2 + o(\\left|t\\right|^2) )", block: false)

#text("for sufficiently small ")#mi("{t}")#text(". Applying ")#link(<tao-8b5b14c53b1345927e8a>)[#text("(11)")]#text(", we conclude that")

#mi("\\displaystyle \\varphi_{S_n/\\sqrt{n}}(t) \\rightarrow \\exp( - t^2/2 )")

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" for any fixed ")#mi("{t}")#text(". But by Exercise ")#link(<tao-1d359c60ec04e10677d7>)[#text("19")]#text(", ")#mi("{\\exp(-t^2/2)}")#text(" is the characteristic function of the normal distribution ")#mi("{N(0,1)}")#text(". The claim now follows from the Lévy continuity theorem. ")#mi("\\Box")#linebreak()#text(" The above machinery extends without difficulty to vector-valued random variables ")#mi("{\\vec X = (X_1,\\dots,X_d)}")#text(" taking values in ")#mi("{{\\bf R}^d}")#text(". The analogue of the characteristic function is then the function ")#mi("{\\varphi_{\\vec X}: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" defined by")

#mi("\\displaystyle \\varphi_{\\vec X}(t_1,\\dots,t_d) := {\\bf E} e^{i (t_1 X_1 + \\dots + t_d X_d)}.")

#text("We leave the routine extension of the above results and proofs to the higher dimensional case to the reader. Most interesting is what happens to the central limit theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34 (Vector-valued central limit theorem)")]#text(" Let ")#mi("{\\vec X=(X_1,\\ldots,X_d)}")#text(" be a random variable taking values in ")#mi("{{\\bf R}^d}")#text(" with finite second moment. Define the ")#link("http://en.wikipedia.org/wiki/Covariance_matrix")[#text("covariance matrix")]#text(" ")#mi("{\\Sigma(\\vec X)}")#text(" to be the ")#mi("{d \\times d}")#text(" matrix ")#mi("{\\Sigma}")#text(" whose ")#mi("{ij^{th}}")#text(" entry is the covariance ")#mi("{{\\bf E} (X_i - {\\bf E}(X_i)) (X_j - {\\bf E}(X_j))}")#text(".")

#list(
[#text("Show that the covariance matrix is positive semi-definite real symmetric.")],
[#text("Conversely, given any positive definite real symmetric ")#mi("{d \\times d}")#text(" matrix ")#mi("{\\Sigma}")#text(" and ")#mi("{\\mu \\in {\\bf R}^d}")#text(", show that the ")#link("https://en.wikipedia.org/wiki/Multivariate_normal_distribution")[#text("multivariate normal distribution")]#text(" ")#mi("{N(\\mu,\\Sigma)_{{\\bf R}^d}}")#text(", given by the absolutely continuous measure")#linebreak()

#align(center)[#tao-fit-display[#mitex("\\frac{1}{((2\\pi)^d \\det \\Sigma)^{1/2}} e^{- (x-\\mu) \\cdot \\Sigma^{-1} (x-\\mu) / 2}\\ dx,")]]

#linebreak()

#text("has mean ")#mi("{\\mu}")#text(" and covariance matrix ")#mi("{\\Sigma}")#text(", and has a characteristic function given by")

#linebreak()

#align(center)[#tao-fit-display[#mitex("\\varphi_{N(\\mu,\\Sigma)_{{\\bf R}^d}}(t) = e^{i \\mu \\cdot t} e^{- t \\cdot \\Sigma t / 2}.")]]

#linebreak()

#text("How would one define the normal distribution ")#mi("{N(\\mu,\\Sigma)_{{\\bf R}^d}}")#text(" if ")#mi("{\\Sigma}")#text(" degenerated to be merely positive semi-definite instead of positive definite?")],
[#text("If ")#mi("{\\vec S_n := \\vec X_1+\\ldots + \\vec X_n}")#text(" is the sum of ")#mi("{n}")#text(" iid copies of ")#mi("{\\vec X}")#text(", show that ")#mi("{\\frac{\\vec S_n - n \\mu}{\\sqrt{n}}}")#text(" converges in distribution to ")#mi("{N(0,\\Sigma(X))_{{\\bf R}^d}}")#text(". (For this exercise, you may assume without proof that the Lévy continuity theorem extends to ")#mi("{{\\bf R}^d}")#text(".)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35 (Complex central limit theorem)")]#text(" Let ")#mi("{X}")#text(" be a complex random variable of mean ")#mi("{\\mu \\in {\\bf C}}")#text(", whose real and imaginary parts have variance ")#mi("{\\sigma^2/2}")#text(" and covariance ")#mi("{0}")#text(". Let ")#mi("{X_1,\\ldots,X_n \\equiv X}")#text(" be iid copies of ")#mi("{X}")#text(". Show that as ")#mi("{n \\rightarrow \\infty}")#text(", the normalised sums ")#mi("{\\frac{\\sqrt{n}}{\\sigma} (\\frac{X_1+\\dots+X_n}{n} - \\mu)}")#text(" converge in distribution to the standard complex gaussian ")#mi("{N(0,1)_{\\bf C}}")#text(", defined as the measure ")#mi("{\\mu}")#text(" on ")#mi("{{\\bf C}}")#text(" with")

#tao-math("\\displaystyle \\mu(S) := \\frac{1}{\\pi} \\int_{S} e^{-\\left|z\\right|^2}\\ dz", block: false)

#text("for Borel ")#mi("{S \\in {\\bf C}}")#text(", where ")#mi("{dz}")#text(" is Lebesgue measure on ")#mi("{{\\bf C}}")#text(" (identified with ")#mi("{{\\bf R}^2}")#text(" in the usual fashion).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36")]#text(" Use characteristic functions and the truncation argument to give an alternate proof of the Lindeberg central limit theorem (Theorem ")#link(<tao-c50155e0f3f4c79d78d2>)[#text("14")]#text(").")
]

#text("A more sophisticated version of the Fourier-analytic method gives a more quantitative form of the central limit theorem, namely the ")#link("http://en.wikipedia.org/wiki/Berry%E2%80%93Esseen_theorem")[#text("Berry-Esséen theorem")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 37 (Berry-Esséen theorem)")]#text(" ")#metadata(none) <tao-be5fe2ee6cf8d5a95850>#text(" Let ")#mi("{X}")#text(" have mean zero and unit variance. Let ")#mi("{S_n := X_1+\\ldots+X_n}")#text(", where ")#mi("{X_1,\\ldots,X_n}")#text(" are iid copies of ")#mi("{X}")#text(". Then we have ")#metadata(none) <tao-c674406e16ee30cbd392>

#tao-math("\\displaystyle {\\bf P}( \\frac{S_n}{\\sqrt{n}} < a ) = {\\bf P}( N < a ) + O( \\frac{1}{\\sqrt{n}} ({\\bf E} \\left|X\\right|^3)) \\ \\ \\ \\ \\ (12)", block: false)

#text("uniformly for all ")#mi("{a \\in {\\bf R}}")#text(", where ")#mi("{N}")#text(" has the distribution of ")#mi("{N(0,1)}")#text(", and the implied constant is absolute.")
]

#emph[#text("Proof:")]#text(" (Optional) Write ")#tao-math("{\\varepsilon := {\\bf E} \\left|X\\right|^3/\\sqrt{n}}", block: false)#text("; our task is to show that ")#metadata(none) <tao-4bc74b21357c6cf5cca8>

#mi("\\displaystyle {\\bf P}( \\frac{S_n}{\\sqrt{n}} < a ) = {\\bf P}( N < a ) + O( \\varepsilon ) \\ \\ \\ \\ \\ (13)")

#linebreak()#text(" for all ")#mi("{a}")#text(". We may of course assume that ")#mi("{\\varepsilon < 1}")#text(", as the claim is trivial otherwise. (In particular, ")#mi("{X}")#text(" has finite third moment.)")#linebreak()#text(" Let ")#mi("{c > 0}")#text(" be a small absolute constant to be chosen later. Let ")#mi("{\\eta: {\\bf R} \\rightarrow {\\bf R}}")#text(" be an non-negative Schwartz function with total mass ")#mi("{1}")#text(" whose Fourier transform is supported in ")#mi("{[-c,c]}")#text("; such an ")#mi("{\\eta}")#text(" can be constructed by taking the inverse Fourier transform of a smooth function supported on ")#mi("{[-c/2,c/2]}")#text(" and equal to one at the origin, and then multiplying that transform by its complex conjugate to make it non-negative.")

#text("Let ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf R}}")#text(" be the smoothed out version of ")#mi("{1_{(-\\infty,0]}}")#text(", defined as")

#mi("\\displaystyle \\psi(x) := \\int_{\\bf R} 1_{(-\\infty,0]}(x - \\varepsilon y) \\eta(y)\\ dy")

#mi("\\displaystyle = \\int_{x/\\varepsilon}^\\infty \\eta(y)\\ dy.")

#text("Observe that ")#mi("{\\psi}")#text(" is decreasing from ")#mi("{1}")#text(" to ")#mi("{0}")#text(". As ")#mi("{\\eta}")#text(" is rapidly decreasing and has mean one, we also have the bound ")#metadata(none) <tao-88ab8860b6f967ad134b>

#tao-math("\\displaystyle \\psi(x) = 1_{(-\\infty,0]}(x) + O_\\eta( (1+\\left|x\\right|/\\varepsilon)^{-100} ) \\ \\ \\ \\ \\ (14)", block: false)

#text("(say) for any ")#mi("{x}")#text(", where subscript indicates that the implied constant depends on ")#mi("{\\eta}")#text(".")#linebreak()#text(" We claim that it suffices to show that ")#metadata(none) <tao-d2efaa6dd6ae6136c199>

#mi("\\displaystyle {\\bf E} \\psi(\\frac{S_n}{\\sqrt{n}} - a) = {\\bf E} \\psi(N - a ) + O_\\eta(\\varepsilon) \\ \\ \\ \\ \\ (15)")

#linebreak()#text(" for every ")#mi("{a}")#text(", where the subscript means that the implied constant depends on ")#mi("{\\eta}")#text(". Indeed, suppose that ")#link(<tao-d2efaa6dd6ae6136c199>)[#text("(15)")]#text(" held. Replacing ")#mi("{a}")#text(" by ")#mi("{a + C \\varepsilon}")#text(" and ")#mi("{a - C\\varepsilon}")#text(" for some large absolute constant ")#mi("{C}")#text(" and subtracting, we have")

#mi("\\displaystyle {\\bf E} \\psi(\\frac{S_n}{\\sqrt{n}} - a - C \\varepsilon) - \\psi(\\frac{S_n}{\\sqrt{n}} - a + C \\varepsilon) = {\\bf E} \\psi(N - a - C \\varepsilon) - {\\bf E} \\psi(N - a + C \\varepsilon)")

#mi("\\displaystyle + O_\\eta(\\varepsilon)")

#text("for any ")#mi("{a}")#text(". From ")#link(<tao-88ab8860b6f967ad134b>)[#text("(14)")]#text(" we see that the function ")#mi("{\\psi(t - a - C \\varepsilon) - \\psi(t - a + C \\varepsilon )}")#text(" is bounded by ")#tao-math("{O_{\\eta,C} ( 1 + \\left|x-a\\right|/\\varepsilon)^{-100} )}", block: false)#text(", and hence by the bounded probability density of ")#mi("{N}")

#mi("\\displaystyle {\\bf E} \\psi(N - a - C \\varepsilon) - {\\bf E} \\psi(N - a + C \\varepsilon) = O_{\\eta,C}(\\varepsilon).")

#text("Also, ")#mi("{\\psi(t - a - C \\varepsilon) - \\psi(t - a + C \\varepsilon )}")#text(" is non-negative, and for ")#mi("{C}")#text(" large enough, it is bounded from below by (say) ")#mi("{1/2}")#text(" on ")#mi("{[a,a+\\varepsilon]}")#text(". We conclude (after choosing ")#mi("{C}")#text(" appropriately) that ")#metadata(none) <tao-668c6650c7124ffaca23>

#mi("\\displaystyle {\\bf E} ( \\frac{S_n}{\\sqrt{n}} \\in [a,a+\\varepsilon] ) = O_\\eta(\\varepsilon) \\ \\ \\ \\ \\ (16)")

#text("for all real ")#mi("{a}")#text(". This implies that")

#tao-math("\\displaystyle {\\bf E} (1 + \\left|\\frac{S_n}{\\sqrt{n}} - a\\right|/\\varepsilon)^{-100} = O_\\eta(\\varepsilon),", block: false)

#text("as can be seen by covering the real line by intervals ")#mi("{[a+j\\varepsilon, a+(j+1)\\varepsilon)]}")#text(" and applying ")#link(<tao-668c6650c7124ffaca23>)[#text("(16)")]#text(" to each such interval. From ")#link(<tao-88ab8860b6f967ad134b>)[#text("(14)")]#text(" we conclude that")

#mi("\\displaystyle {\\bf E} \\psi(\\frac{S_n}{\\sqrt{n}} - a) = {\\bf E} 1{(-\\infty,0]}(\\frac{S_n}{\\sqrt{n}} - a) + O_\\eta(\\varepsilon).")

#text("A similar argument gives")

#mi("\\displaystyle {\\bf E} \\psi(N - a) = {\\bf E} 1{(-\\infty,0]}(N - a) + O_\\eta(\\varepsilon),")

#text("and ")#link(<tao-4bc74b21357c6cf5cca8>)[#text("(13)")]#text(" then follows from ")#link(<tao-d2efaa6dd6ae6136c199>)[#text("(15)")]#text(".")#linebreak()#text(" It remains to establish ")#link(<tao-d2efaa6dd6ae6136c199>)[#text("(15)")]#text(". We write")

#mi("\\displaystyle \\psi(x) = \\lim_{M \\rightarrow \\infty} \\int_{x/\\varepsilon}^{x/\\varepsilon + M} \\eta(y)\\ dy")

#text("(with the expression in the limit being uniformly bounded) and")

#mi("\\displaystyle \\eta(y) = \\int_{\\bf R} \\hat \\eta(t) e^{ity}\\ dt")

#text("to conclude (after applying Fubini’s theorem) that")

#mi("\\displaystyle \\psi(x) = \\lim_{M \\rightarrow \\infty} \\int_{-c}^c \\hat \\eta(t) e^{itx/\\varepsilon} \\frac{e^{itM}-1}{it}\\ dt")

#text("using the compact support of ")#mi("{\\hat \\eta}")#text(". Hence")

#mi("\\displaystyle \\psi(\\frac{S_n}{\\sqrt{n}}-a) - \\psi(N-a) = \\lim_{M \\rightarrow \\infty} \\int_{-c}^c \\hat \\eta(t) (e^{it\\frac{S_n}{\\sqrt{n}}/\\varepsilon} - e^{itN/\\varepsilon}) \\frac{e^{itM}-1}{it} e^{-ita/\\varepsilon}\\ dt.")

#text("By the fundamental theorem of calculus we have ")#tao-math("{e^{it\\frac{S_n}{\\sqrt{n}}/\\varepsilon} - e^{itN/\\varepsilon} = O( \\left|t\\right| (\\left|\\frac{S_n}{\\sqrt{n}}\\right| + \\left|N\\right|) /\\varepsilon)}", block: false)#text(". This factor of ")#tao-math("{\\left|t\\right|}", block: false)#text(" cancels a similar factor on the denominator to make the expression inside the limit dominated by an absolutely integrable random variable. Thus by the dominated convergence theorem")

#mi("\\displaystyle {\\bf E} \\psi(\\frac{S_n}{\\sqrt{n}}) - {\\bf E} \\psi(N) = \\lim_{M \\rightarrow \\infty} \\int_{-c}^c \\hat \\eta(t) (\\varphi_{S_n/\\sqrt{n}}(t/\\varepsilon)-\\varphi_N(t/\\varepsilon)) \\frac{e^{itM}-1}{it} e^{-ita/\\varepsilon}\\ dt")

#text("and so it suffices to show that")

#mi("\\displaystyle \\int_{-c}^c \\hat \\eta(t) (\\varphi_{S_n/\\sqrt{n}}(t/\\varepsilon) - \\varphi_N(t/\\varepsilon)) \\frac{e^{itM}-1}{it} e^{-ita/\\varepsilon}\\ dt = O_\\eta(\\varepsilon)")

#text("uniformly in ")#mi("{M}")#text(". Applying the triangle inequality and the compact support of ")#mi("{\\hat \\eta}")#text(", it suffices to show that ")#metadata(none) <tao-e2ea8eb98a17c6f005f4>

#tao-math("\\displaystyle \\int_{\\left|t\\right| \\leq c} |\\varphi_{S_n/\\sqrt{n}}(t/\\varepsilon) - \\varphi_{N}(t/\\varepsilon)| \\frac{dt}{\\left|t\\right|} = O(\\varepsilon). \\ \\ \\ \\ \\ (17)", block: false)

#text("From Taylor expansion we have")

#tao-math("\\displaystyle e^{itX} = 1 + it X - \\frac{t^2}{2} X^2 + O( \\left|t\\right|^3 \\left|X\\right|^3 )", block: false)

#text("for any ")#mi("{t}")#text("; taking expectations and using the definition of ")#mi("{\\varepsilon}")#text(" we have")

#tao-math("\\displaystyle \\varphi_X(t) = 1 - t^2/2 + O( \\varepsilon \\sqrt{n} \\left|t\\right|^3 )", block: false)

#text("and in particular")

#tao-math("\\displaystyle \\varphi_X(t) = \\exp( - t^2/2 + O( \\varepsilon \\sqrt{n} \\left|t\\right|^3 ) )", block: false)

#text("if ")#tao-math("{\\left|t\\right| \\leq c / \\varepsilon \\sqrt{n}}", block: false)#text(" and ")#mi("{c}")#text(" is small enough. Applying ")#link(<tao-8b5b14c53b1345927e8a>)[#text("(11)")]#text(", we conclude that")

#tao-math("\\displaystyle \\varphi_{S_n/\\sqrt{n}}(t) = \\exp(-t^2/2 + O( \\varepsilon \\left|t\\right|^3 ))", block: false)

#text("if ")#tao-math("{\\left|t\\right| \\leq c/\\varepsilon}", block: false)#text(". Meanwhile, from Exercise ")#link(<tao-1d359c60ec04e10677d7>)[#text("19")]#text(" we have ")#mi("{\\varphi_N(t) = \\exp(-t^2/2)}")#text(". Elementary calculus then gives us")

#tao-math("\\displaystyle \\left|\\varphi_{S_n/\\sqrt{n}}(t) - \\varphi_N(t)\\right| \\leq O( \\varepsilon \\left|t\\right|^3 \\exp( - t^2/4 ) )", block: false)

#text("(say) if ")#mi("{c}")#text(" is small enough. Inserting this bound into ")#link(<tao-e2ea8eb98a17c6f005f4>)[#text("(17)")]#text(" we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38")]#text(" Show that the error terms in Theorem ")#link(<tao-be5fe2ee6cf8d5a95850>)[#text("37")]#text(" are sharp (up to constants) when ")#mi("{X}")#text(" is a signed Bernoulli random variable, or more precisely when ")#mi("{X}")#text(" takes values in ")#mi("{\\{-1,+1\\}}")#text(" with probability ")#mi("{1/2}")#text(" for each.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39")]#text(" Let ")#mi("{X_n}")#text(" be a sequence of real random variables which converge in distribution to a real random variable ")#mi("{X}")#text(", and let ")#mi("{Y_n}")#text(" be a sequence of real random variables which converge in distribution to a real random variable ")#mi("{Y}")#text(". Suppose that, for each ")#mi("{n}")#text(", ")#mi("{X_n}")#text(" and ")#mi("{Y_n}")#text(" are independent, and suppose also that ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are independent. Show that ")#mi("{X_n+Y_n}")#text(" converges in distribution to ")#mi("{X+Y}")#text(". (")#emph[#text("Hint:")]#text(" use the Lévy continuity theorem.)")
]

#text("The following exercise shows that the central limit theorem fails when the variance is infinite.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 40")]#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be iid copies of an absolutely integrable random variable ")#mi("{X}")#text(" of mean zero.")

#list(
[#text("(i) In this part we assume that ")#mi("{X}")#text(" is ")#emph[#text("symmetric")]#text(", which means that ")#mi("{X}")#text(" and ")#mi("{-X}")#text(" have the same distribution. Show that for any ")#mi("{t > 0}")#text(" and ")#mi("{M > 0}")#text(",")#linebreak()

#align(center)[#tao-fit-display[#mitex("{\\bf P}( X_1 + \\dots + X_n \\geq t )")]]

#linebreak()

#align(center)[#tao-fit-display[#tao-math("\\geq \\frac{1}{2} {\\bf P}( X_1 1_{\\left|X_1\\right| \\leq M} + \\dots + X_n 1_{\\left|X_n\\right| \\leq M} \\geq t ).", block: true)]]

#linebreak()

#text("(")#emph[#text("Hint:")]#text(" relate both sides of this inequality to the probability of the event that ")#tao-math("{X_1 1_{\\left|X_1\\right| \\leq M} + \\dots + X_n 1_{\\left|X_n\\right| \\leq M} \\geq t}", block: false)#text(" and ")#tao-math("{X_1 1_{\\left|X_1\\right| > M} + \\dots + X_n 1_{\\left|X_n\\right| > M} \\geq 0}", block: false)#text(", using the symmetry of the situation.)")],
[#text("(ii) If ")#mi("{X}")#text(" is symmetric and ")#mi("{\\frac{X_1+\\dots+X_n}{\\sqrt{n}}}")#text(" converges in distribution to a real random variable ")#mi("{Y}")#text(", show that ")#mi("{X}")#text(" has finite variance. (")#emph[#text("Hint:")]#text(" if this is not the case, then ")#tao-math("{X 1_{\\left|X\\right| \\leq M}}", block: false)#text(" will have arbitrarily large variance as ")#mi("{M}")#text(" increases. On the other hand, ")#mi("{{\\bf P}( Y \\geq u )}")#text(" can be made arbitrarily small by taking ")#mi("{u}")#text(" large enough. For a large threshold ")#mi("{M}")#text(", apply (i) (with ")#mi("{t = u \\sqrt{n}}")#text(") to obtain a contradiction.")],
[#text("(iii) Generalise (ii) by removing the hypothesis that ")#mi("{X}")#text(" is symmetric. (")#emph[#text("Hint:")]#text(" apply the ")#emph[#text("symmetrisation")]#text(" trick of replacing ")#mi("{X}")#text(" by ")#mi("{X-X^{\\prime}}")#text(", where ")#mi("{X^{\\prime}}")#text(" is an independent copy of ")#mi("{X}")#text(", and use the previous exercise. One may need to utilise some truncation arguments to show that ")#mi("{X-X^{\\prime}}")#text(" has infinite variance whenever ")#mi("{X}")#text(" has infinite variance.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 41")]

#list(
[#text("(i) If ")#mi("{X}")#text(" is a real random variable of mean zero and variance ")#mi("{\\sigma^2}")#text(", and ")#mi("{t}")#text(" is a real number, show that")#linebreak()

#align(center)[#tao-fit-display[#mitex("\\varphi_X(t) = 1 + O( \\sigma^2 t^2 )")]]

#linebreak()

#text("and that")

#linebreak()

#align(center)[#tao-fit-display[#tao-math("\\varphi_X(t) = 1 - \\frac{1}{2} \\sigma^2 t^2 + O( t^2 {\\bf E} \\min( \\left|X\\right|^2, t \\left|X\\right|^3 ) ).", block: true)]]

#linebreak()

#text("(")#emph[#text("Hint:")]#text(" first establish the Taylor bounds ")#tao-math("{e^{itX} = 1 + itX + O(t^2 \\left|X\\right|^2)}", block: false)#text(" and ")#tao-math("{e^{itX} = 1 + itX + \\frac{1}{2} t^2 \\left|X\\right|^2 + O( t^3 \\left|X\\right|^3 )}", block: false)#text(".)")],
[#text("(ii) Establish the pointwise inequality")#linebreak()

#align(center)[#tao-fit-display[#tao-math("\\left|z_1 \\dots z_n - z^{\\prime}_1 \\dots z^{\\prime}_n\\right| \\leq \\sum_{i=1}^n \\left|z_i - z^{\\prime}_i\\right|", block: true)]]

#linebreak()

#text("whenever ")#mi("{z_1,\\dots,z_n,z^{\\prime}_1,\\dots,z^{\\prime}_n}")#text(" are complex numbers in the disk ")#tao-math("{\\{ z \\in {\\bf C}: \\left|z\\right| \\leq 1 \\}}", block: false)#text(".")],
[#text("(iii) Suppose that for each ")#mi("{n}")#text(", ")#mi("{X_{1,n},\\dots,X_{n,n}}")#text(" are jointly independent real random variables of mean zero and finite variance, obeying the uniform bound")#linebreak()

#align(center)[#tao-fit-display[#tao-math("\\left|X_{i,n}\\right| \\leq \\varepsilon_n \\sqrt{n}", block: true)]]

#linebreak()

#text("for all ")#mi("{i=1,\\dots,n}")#text(" and some ")#mi("{\\varepsilon_n}")#text(" going to zero as ")#mi("{n \\rightarrow \\infty}")#text(", and also obeying the variance bound")

#linebreak()

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^n {\\bf Var}( X_{i,n} ) \\rightarrow \\sigma^2")]]

#linebreak()

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" for some ")#mi("{0 < \\sigma < \\infty}")#text(". If ")#mi("{S_n := X_{1,n} + \\dots + X_{n,n}}")#text(", use (i) and (ii) to show that")

#linebreak()

#align(center)[#tao-fit-display[#mitex("\\varphi_{S_n/\\sqrt{n}}(t) \\rightarrow e^{-\\sigma^2 t^2/2}")]]

#linebreak()

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" for any given real ")#mi("{t}")#text(".")],
[#text("(iv) Use (iii) and a truncation argument to give an alternate proof of the Lindeberg central limit theorem (Theorem ")#link(<tao-c50155e0f3f4c79d78d2>)[#text("14")]#text("). (Note: one has to address the issue that truncating a random variable may alter its mean slightly.)")]
)
]

#strong[#text(" — 3. The moment method — ")]

#text("The above Fourier-analytic proof of the central limit theorem is one of the quickest (and slickest) proofs available for this theorem, and is accordingly the “standard” proof given in probability textbooks. However, it relies quite heavily on the Fourier-analytic identities in Exercise ")#link(<tao-2e1712f7908f611efbf8>)[#text("32")]#text(", which in turn are extremely dependent on both the commutative nature of the situation (as it uses the identity ")#mi("{e^{A+B}=e^A e^B}")#text(") and on the independence of the situation (as it uses identities of the form ")#mi("{{\\bf E}(e^A e^B) = ({\\bf E} e^A)({\\bf E} e^B)}")#text("). As one or both of these factors can be absent when trying to generalise this theorem, it is also important to look for non-Fourier based methods to prove results such as the central limit theorem. These methods often lead to proofs that are lengthier and more technical than the Fourier proofs, but also tend to be more robust.")

#text("The most elementary (but still remarkably effective) method available in this regard is the ")#emph[#text("moment method")]#text(", which we have already used in previous notes. In principle, this method is equivalent to the Fourier method, through the identity ")#link(<tao-bcbb0eeac8d6a4240d57>)[#text("(7)")]#text("; but in practice, the moment method proofs tend to look somewhat different than the Fourier-analytic ones, and it is often more apparent how to modify them to non-independent or non-commutative settings.")

#text("We first need an analogue of the Lévy continuity theorem. Here we encounter a technical issue: whereas the Fourier phases ")#mi("{x \\mapsto e^{itx}}")#text(" were bounded, the moment functions ")#mi("{x \\mapsto x^k}")#text(" become unbounded at infinity. However, one can deal with this issue as long as one has sufficient decay:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42 (Subgaussian random variables)")]#text(" ")#metadata(none) <tao-4968d0cf3b24d26d1d37>#text(" Let ")#mi("{X}")#text(" be a real random variable. Show that the following statements are equivalent:")

#list(
[#text("(i) There exist ")#mi("{C,c>0}")#text(" such that ")#tao-math("{{\\bf P}(\\left|X\\right| \\geq t) \\leq C e^{-ct^2}}", block: false)#text(" for all ")#mi("{t>0}")#text(".")],
[#text("(ii) There exist ")#mi("{C^{\\prime}>0}")#text(" such that ")#tao-math("{{\\bf E} \\left|X\\right|^k \\leq (C^{\\prime}k)^{k/2}}", block: false)#text(" for all ")#mi("{k \\geq 1}")#text(".")],
[#text("(iii) There exist ")#mi("{C^{\\prime\\prime},c^{\\prime\\prime}>0}")#text(" such that ")#mi("{{\\bf E} e^{tX} \\leq C^{\\prime\\prime} e^{c^{\\prime\\prime} t^2}}")#text(" for all ")#mi("{t \\in {\\bf R}}")#text(".")]
)

#text("Furthermore, show that if (i) holds for some ")#mi("{C,c}")#text(", then (ii) holds for ")#mi("{C^{\\prime}}")#text(" depending only on ")#mi("{C,c}")#text(", and similarly for any of the other implications. Variables obeying (i), (ii), or (iii) are called ")#emph[#text("subgaussian")]#text(". The function ")#mi("{t \\mapsto {\\bf E} e^{tX}}")#text(" is known as the ")#link("https://en.wikipedia.org/wiki/Moment_generating_function")[#text("moment generating function")]#text(" of ")#mi("{X}")#text("; it is of course closely related to the characteristic function of ")#mi("{X}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 43")]#text(" Use the truncation method to show that in order to prove the central limit theorem (Theorem ")#link(<tao-667ae99a22d281e83efd>)[#text("8")]#text("), it suffices to do so in the case when the underlying random variable ")#mi("{X}")#text(" is bounded (and in particular subgaussian).")
]

#text("Once we restrict to the subgaussian case, we have an analogue of the Lévy continuity theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 44 (Moment continuity theorem)")]#text(" ")#metadata(none) <tao-6d05eb6c33124ea53ade>#text(" Let ")#mi("{X_n}")#text(" be a sequence of real random variables, and let ")#mi("{X}")#text(" be a subgaussian random variable. Suppose that for every ")#mi("{k=0,1,2,\\dots}")#text(", ")#mi("{{\\bf E} X_n^k}")#text(" converges pointwise to ")#mi("{{\\bf E} X^k}")#text(". Then ")#mi("{X_n}")#text(" converges in distribution to ")#mi("{X}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{k = 0,1,2,\\dots}")#text(", then by the preceding exercise we have")

#tao-math("\\displaystyle {\\bf E} \\left|X\\right|^{k+1} \\leq (C (k+1))^{(k+1)/2}", block: false)

#text("for some ")#mi("{C}")#text(" independent of ")#mi("{k}")#text(". In particular,")

#tao-math("\\displaystyle {\\bf E} \\left|X_n\\right|^{k+1} \\leq 2(C (k+1))^{(k+1)/2}", block: false)

#text("when ")#mi("{n}")#text(" is sufficiently large depending on ")#mi("{k}")#text(". From Taylor’s theorem with remainder (and Stirling’s formula ")#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/#stirling")[#text("(1)")]#text(") we conclude")

#tao-math("\\displaystyle \\varphi_{X_n}(t) = \\sum_{j=0}^k \\frac{(it)^j}{j!} {\\bf E} X_n^j + O( (C(k+1))^{-(k+1)/2} \\left|t\\right|^{k+1} )", block: false)

#text("uniformly in ")#mi("{t}")#text(", for ")#mi("{n}")#text(" sufficiently large. Similarly for ")#mi("{X}")#text(". Taking limits using (i) we see that")

#tao-math("\\displaystyle \\limsup_{n \\rightarrow \\infty} \\left|\\varphi_{X_n}(t) - \\varphi_X(t)\\right| = O( (C(k+1))^{-(k+1)/2} \\left|t\\right|^{k+1} ).", block: false)

#text("Then letting ")#mi("{k \\rightarrow \\infty}")#text(", keeping ")#mi("{t}")#text(" fixed, we see that ")#mi("{\\varphi_{X_n}(t)}")#text(" converges pointwise to ")#mi("{\\varphi_X(t)}")#text(" for each ")#mi("{t}")#text(", and the claim now follows from the Lévy continuity theorem. ")#mi("\\Box")#linebreak()#text(" We remark that in place of Stirling’s formula, one can use the cruder lower bound ")#mi("{n! \\geq n^n/e^n}")#text(", which is immediate from the observation that ")#mi("{n^n/n!}")#text(" occurs in the Taylor expansion of ")#mi("{e^n}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 45")]#text(" One corollary of Theorem ")#link(<tao-6d05eb6c33124ea53ade>)[#text("44")]#text(" is that the distribution of a subgaussian random variable is uniquely determined by its moments (actually, this could already be deduced from Exercise ")#link(<tao-633ac296aa882e8a15dd>)[#text("26")]#text(" and Remark ")#link(<tao-6f482b0b6604c69c6a3c>)[#text("28")]#text("). The situation can fail for distributions with slower tails, for much the same reason that a smooth function is not determined by its derivatives at one point if that function is not analytic.")#linebreak()#text(" The Fourier inversion formula provides an easy way to recover the distribution from the characteristic function. Recovering a distribution from its moments is more difficult, and sometimes requires tools such as analytic continuation; this problem is known as the ")#emph[#text("inverse moment problem")]#text(" and will not be discussed here.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 46 (Converse direction of moment continuity theorem)")]#text(" Let ")#mi("{X_n}")#text(" be a sequence of uniformly subgaussian random variables (thus there exist ")#mi("{C,c>0}")#text(" such that ")#tao-math("{{\\bf P}(\\left|X_n\\right| \\geq t) \\leq C e^{-ct^2}}", block: false)#text(" for all ")#mi("{t>0}")#text(" and all ")#mi("{n}")#text("), and suppose ")#mi("{X_n}")#text(" converges in distribution to a limit ")#mi("{X}")#text(". Show that for any ")#mi("{k=0,1,2,\\dots}")#text(", ")#mi("{{\\bf E} X_n^k}")#text(" converges pointwise to ")#mi("{{\\bf E} X^k}")#text(".")
]

#text("We now give the moment method proof of the central limit theorem. As discussed above we may assume without loss of generality that ")#mi("{X}")#text(" is bounded (and in particular subgaussian); we may also normalise ")#mi("{X}")#text(" to have mean zero and unit variance. By Theorem ")#link(<tao-6d05eb6c33124ea53ade>)[#text("44")]#text(", it suffices to show that")

#mi("\\displaystyle {\\bf E} S_n^k / n^{k/2} \\rightarrow {\\bf E} N^k")

#text("for all ")#mi("{k=0,1,2,\\ldots}")#text(", where ")#mi("{N \\equiv N(0,1)_{\\bf R}}")#text(" is a standard gaussian variable.")#linebreak()#text(" The moments ")#mi("{{\\bf E} N^k}")#text(" were already computed in Exercise 37 of ")#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/")[#text("Notes 1")]#text(". So now we need to compute ")#mi("{{\\bf E} S_n^k / n^{k/2}}")#text(". Using linearity of expectation, we can expand this as")

#mi("\\displaystyle {\\bf E} S_n^k / n^{k/2} = n^{-k/2} \\sum_{1 \\leq i_1,\\ldots,i_k \\leq n} {\\bf E} X_{i_1} \\ldots X_{i_k}.")

#text("To understand this expression, let us first look at some small values of ")#mi("{k}")#text(".")

#list(
[#text("For ")#mi("{k=0}")#text(", this expression is trivially ")#mi("{1}")#text(".")],
[#text("For ")#mi("{k=1}")#text(", this expression is trivially ")#mi("{0}")#text(", thanks to the mean zero hypothesis on ")#mi("{X}")#text(".")],
[#text("For ")#mi("{k=2}")#text(", we can split this expression into the diagonal and off-diagonal components:")#linebreak()

#align(center)[#tao-fit-display[#mitex("n^{-1} \\sum_{1 \\leq i \\leq n} {\\bf E} X_i^2 + n^{-1} \\sum_{1 \\leq i < j \\leq n} {\\bf E} 2 X_i X_j.")]]

#linebreak()

#text("Each summand in the first sum is ")#mi("{1}")#text(", as ")#mi("{X}")#text(" has unit variance. Each summand in the second sum is ")#mi("{0}")#text(", as the ")#mi("{X_i}")#text(" have mean zero and are independent. So the second moment ")#mi("{{\\bf E} Z_n^2}")#text(" is ")#mi("{1}")#text(".")],
[#text("For ")#mi("{k=3}")#text(", we have a similar expansion")#linebreak()

#align(center)[#tao-fit-display[#mitex("n^{-3/2} \\sum_{1 \\leq i \\leq n} {\\bf E} X_i^3 + n^{-3/2} \\sum_{1 \\leq i < j \\leq n} {\\bf E} 3 X_i^2 X_j + 3 X_i X_j^2")]]

#linebreak()

#align(center)[#tao-fit-display[#mitex("+ n^{-3/2} \\sum_{1 \\leq i < j < k \\leq n} {\\bf E} 6 X_i X_j X_k.")]]

#linebreak()

#text("The summands in the latter two sums vanish because of the (joint) independence and mean zero hypotheses. The summands in the first sum need not vanish, but are ")#mi("{O(1)}")#text(", so the first term is ")#mi("{O(n^{-1/2})}")#text(", which is asymptotically negligible, so the third moment ")#mi("{{\\bf E} Z_n^3}")#text(" goes to ")#mi("{0}")#text(".")],
[#text("For ")#mi("{k=4}")#text(", the expansion becomes quite complicated:")#linebreak()

#align(center)[#tao-fit-display[#mitex("n^{-2} \\sum_{1 \\leq i \\leq n} {\\bf E} X_i^4 + n^{-2} \\sum_{1 \\leq i < j \\leq n} {\\bf E} 4 X_i^3 X_j + 6 X_i^2 X_j^2 + 4 X_i X_j^3")]]

#linebreak()

#align(center)[#tao-fit-display[#mitex("+ n^{-2} \\sum_{1 \\leq i < j < k \\leq n} {\\bf E} 12 X_i^2 X_j X_k + 12 X_i X_j^2 X_k + 12 X_i X_j X_k^2")]]

#linebreak()

#align(center)[#tao-fit-display[#mitex("+ n^{-2} \\sum_{1 \\leq i < j < k < l \\leq n} {\\bf E} 24 X_i X_j X_k X_l.")]]

#linebreak()

#text("Again, most terms vanish, except for the first sum, which is ")#mi("{O( n^{-1} )}")#text(" and is asymptotically negligible, and the sum ")#mi("{n^{-2} \\sum_{1 \\leq i < j \\leq n} {\\bf E} 6 X_i^2 X_j^2}")#text(", which by the independence and unit variance assumptions works out to ")#mi("{n^{-2} 6 \\binom{n}{2} = 3 + o(1)}")#text(". Thus the fourth moment ")#mi("{{\\bf E} Z_n^4}")#text(" goes to ")#mi("{3}")#text(" (as it should).")]
)

#text("Now we tackle the general case. Ordering the indices ")#mi("{i_1,\\ldots,i_k}")#text(" as ")#mi("{j_1 < \\ldots < j_m}")#text(" for some ")#mi("{1 \\leq m \\leq k}")#text(", with each ")#mi("{j_r}")#text(" occuring with multiplicity ")#mi("{a_r \\geq 1}")#text(" and using elementary ")#link("http://en.wikipedia.org/wiki/Enumerative_combinatorics")[#text("enumerative combinatorics")]#text(", we see that ")#mi("{{\\bf E} S_n^k / n^{k/2}}")#text(" is the sum of all terms of the form ")#metadata(none) <tao-397d460b0d90e5d7ea3d>

#mi("\\displaystyle n^{-k/2} \\sum_{1 \\leq j_1 < \\ldots < j_m \\leq n} c_{k,a_1,\\ldots,a_m} {\\bf E} X_{j_1}^{a_1} \\ldots X_{j_m}^{a_m} \\ \\ \\ \\ \\ (18)")

#linebreak()#text(" where ")#mi("{1 \\leq m \\leq k}")#text(", ")#mi("{a_1,\\ldots,a_m}")#text(" are positive integers adding up to ")#mi("{k}")#text(", and ")#mi("{c_{k,a_1,\\ldots,a_m}}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Multinomial_distribution")[#text("multinomial")]#text(" coefficient")

#mi("\\displaystyle c_{k,a_1,\\ldots,a_m} := \\frac{k!}{a_1! \\ldots a_m!}.")

#text("The total number of such terms depends only on ")#mi("{k}")#text(" (in fact, it is ")#mi("{2^{k-1}}")#text(" (exercise!), though we will not need this fact).")

#text("As we already saw from the small ")#mi("{k}")#text(" examples, most of the terms vanish, and many of the other terms are negligible in the limit ")#mi("{n \\rightarrow \\infty}")#text(". Indeed, if any of the ")#mi("{a_r}")#text(" are equal to ")#mi("{1}")#text(", then every summand in ")#link(<tao-397d460b0d90e5d7ea3d>)[#text("(18)")]#text(" vanishes, by joint independence and the mean zero hypothesis. Thus, we may restrict attention to those expressions ")#link(<tao-397d460b0d90e5d7ea3d>)[#text("(18)")]#text(" for which all the ")#mi("{a_r}")#text(" are at least ")#mi("{2}")#text(". Since the ")#mi("{a_r}")#text(" sum up to ")#mi("{k}")#text(", we conclude that ")#mi("{m}")#text(" is at most ")#mi("{k/2}")#text(".")

#text("On the other hand, the total number of summands in ")#link(<tao-397d460b0d90e5d7ea3d>)[#text("(18)")]#text(" is clearly at most ")#mi("{n^m}")#text(" (in fact it is ")#mi("{\\binom{n}{m}}")#text("), and the summands are bounded (for fixed ")#mi("{k}")#text(") since ")#mi("{X}")#text(" is bounded. Thus, if ")#mi("{m}")#text(" is ")#emph[#text("strictly")]#text(" less than ")#mi("{k/2}")#text(", then the expression in ")#link(<tao-397d460b0d90e5d7ea3d>)[#text("(18)")]#text(" is ")#mi("{O( n^{m-k/2} )}")#text(" and goes to zero as ")#mi("{n \\rightarrow \\infty}")#text(". So, asymptotically, the only terms ")#link(<tao-397d460b0d90e5d7ea3d>)[#text("(18)")]#text(" which are still relevant are those for which ")#mi("{m}")#text(" is ")#emph[#text("equal")]#text(" to ")#mi("{k/2}")#text(". This already shows that ")#mi("{{\\bf E} Z_n^k}")#text(" goes to zero when ")#mi("{k}")#text(" is odd. When ")#mi("{k}")#text(" is even, the only surviving term in the limit is now when ")#mi("{m=k/2}")#text(" and ")#mi("{a_1=\\ldots=a_m = 2}")#text(". But then by independence and unit variance, the expectation in ")#link(<tao-397d460b0d90e5d7ea3d>)[#text("(18)")]#text(" is ")#mi("{1}")#text(", and so this term is equal to")

#mi("\\displaystyle n^{-k/2} \\binom{n}{m} c_{k,2,\\ldots,2} = \\frac{1}{(k/2)!} \\frac{k!}{2^{k/2}} + o(1),")

#text("and the main term is happily equal to the moment ")#mi("{{\\bf E} N^k}")#text(" as computed in Exercise 37 of ")#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/")[#text("Notes 1")]#text(". (One could also appeal to Lemma ")#link(<tao-a543997d84f12798350c>)[#text("12")]#text(" here, specialising to the case when ")#mi("{X}")#text(" is normally distributed, to explain this coincidence.) This concludes the proof of the central limit theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 47 (Chernoff bound)")]#text(" Let ")#mi("{X_1,\\dots,X_n}")#text(" be iid copies of a real random variable ")#mi("{X}")#text(" of mean zero and unit variance, which is subgaussian in the sense of Exercise ")#link(<tao-4968d0cf3b24d26d1d37>)[#text("42")]#text(". Write ")#mi("{S_n := X_1+\\dots+X_n}")#text(".")

#list(
[#text("(i) Show that there exist ")#mi("{c^{\\prime\\prime}>0}")#text(" such that ")#mi("{{\\bf E} e^{tX} \\leq e^{c^{\\prime\\prime} t^2}}")#text(" for all ")#mi("{t \\in {\\bf R}}")#text(". Conclude that ")#mi("{{\\bf E} e^{tS_n/\\sqrt{n}} \\leq e^{c^{\\prime\\prime} t^2}}")#text(" for all ")#mi("{t \\in {\\bf R}}")#text(". (")#emph[#text("Hint:")]#text(" the first claim follows directly from Exercise ")#link(<tao-4968d0cf3b24d26d1d37>)[#text("42")]#text(" when ")#tao-math("{\\left|t\\right| \\geq 1}", block: false)#text("; for ")#tao-math("{\\left|t\\right| < 1}", block: false)#text(", use the Taylor approximation ")#mi("{e^{tX} = 1 + tX + O( t^2 (e^{2X} + e^{-2X}) )}")#text(".)")],
[#text("(ii) Conclude the ")#link("https://en.wikipedia.org/wiki/Chernoff_bound")[#text("Chernoff bound")]#linebreak()

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|\\frac{S_n}{\\sqrt{n}}\\right| \\geq \\lambda ) \\leq C e^{-c \\lambda^2}", block: true)]]

#linebreak()

#text("for some ")#mi("{C,c>0}")#text(", all ")#mi("{\\lambda>0}")#text(", and all ")#mi("{n \\geq 1}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 48 (Erdös-Kac theorem)")]#text(" For any natural number ")#mi("{x \\geq 100}")#text(", let ")#mi("{n}")#text(" be a natural number drawn uniformly at random from the natural numbers ")#mi("{\\{1,\\dots,x\\}}")#text(", and let ")#mi("{\\omega(n)}")#text(" denote the number of distinct prime factors of ")#mi("{n}")#text(".")

#list(
[#text("(i) Show that for any ")#mi("{k=0,1,2,\\dots}")#text(", one has")#linebreak()

#align(center)[#tao-fit-display[#mitex("{\\bf E} (\\frac{\\omega(n)-\\log\\log x}{\\sqrt{\\log\\log x}})^k \\rightarrow 0")]]

#linebreak()

#text("as ")#mi("{x \\rightarrow \\infty}")#text(" if ")#mi("{k}")#text(" is odd, and")

#linebreak()

#align(center)[#tao-fit-display[#mitex("{\\bf E} (\\frac{\\omega(n)-\\log\\log x}{\\sqrt{\\log\\log x}})^k \\rightarrow \\frac{k!}{2^{k/2} (k/2)!}")]]

#linebreak()

#text("as ")#mi("{x \\rightarrow \\infty}")#text(" if ")#mi("{k}")#text(" is even. (")#emph[#text("Hint:")]#text(" adapt the arguments in Exercise 16 of ")#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/")[#text("Notes 3")]#text(", estimating ")#mi("{\\omega(n)-\\log\\log x}")#text(" by ")#mi("{\\sum_{p \\leq x^{1/10k}} 1_{p|n} - \\frac{1}{p}}")#text(", using Mertens’ theorem and induction on ")#mi("{k}")#text(" to deal with lower order errors, and treating the random variables ")#mi("{1_{p|n} - \\frac{1}{p}}")#text(" as being approximately independent and approximately of mean zero.)")],
[#text("(ii) Establish the ")#link("https://en.wikipedia.org/wiki/Erd%C5%91s%E2%80%93Kac_theorem")[#text("Erdös-Kac theorem")]#linebreak()

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{x} \\left| \\{ n \\leq x: a \\leq \\frac{\\omega(n)-\\log\\log x}{\\sqrt{\\log\\log x}} \\leq b \\}\\right| \\rightarrow \\frac{1}{\\sqrt{2\\pi}} \\int_a^b e^{-x^2/2}\\ dx", block: true)]]

#linebreak()

#text("as ")#mi("{x \\rightarrow \\infty}")#text(" for any fixed ")#mi("{a < b}")#text(".")]
)

#text("Informally, the Erdös-Kac theorem asserts that ")#mi("{\\omega(n)}")#text(" behaves like ")#mi("{N( \\log\\log n, \\log\\log n)}")#text(" for “random” ")#mi("{n}")#text(". Note that this refines the Hardy-Ramanujan theorem (Exercise 16 of ")#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/")[#text("Notes 3")]#text(").")
]

#heading(level: 1)[#text("Comments (127)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-461373")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2015")])]

#text("may want to add “275A – probability theory” in the tags")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-461397")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2015")])]

#text("In theorem 36, the assumption ")#tao-math("E(\\left|X\\right|^3) < \\infty", block: false)#text(" is not really needed (since otherwise (11) holds trivially!)")

#emph[#text("[Assumption removed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-461411")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2015")])]

#text("You should use ")#mi("\\dots")#text(" instead of ")#mi("\\ldots")#text(" and $\\cdots$, resp.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-461447")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2015")])]

#text("In exercise 13(ii), “")#mi("\\sup")#text("” is in fact “")#mi("\\max")#text("“, and the expectation should be dependent on the index ")#mi("i")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-461473")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2015")])]

#text("According to the Wikipedia articles on the CLT and the Berry-Esseen theorem:")

#text("1. The term “central limit theorem” (in German) was first used by Polya (in 1920) where the word “central” is due to its central importance in probability theory. The later interpretation of “central” in the sense that the CLT describes the behaviour of the distribution near its center is (according to Le Cam) due to the French school on probability.")

#text("2. The best implied constant in the error term in 11, is lower-bounded by ")#mi("0.4097")#text(" (Esseen, 1956) and upper-bounded by ")#mi("0.4748")#text(" (Shevtsova, 2011).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-461475")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2015")])]

#text("In the proof of Theorem 26 you briefly switch to $R^d$")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-461477")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2015")])]

#text("A useful lemma is that if $X_n$ converge in distribution they can be coupled to converge almost surely. This is also an instructive alternate approach to the second direction in Proposition 4.")

#emph[#text("[This was the intention of Exercise 10(iv), though I had previously only asked for convergence in probability, and have now strengthened the conclusion. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-461479")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2015")])]

#text("It seems that exercise 10(vi) generalizes Slutsky’s theorem (which deals with a degenerate(!) limit ")#mi("Y")#text("), but in the Wikipedia article on Slutsky’s theorem (according to the second note) it is claimed that the requirement that ")#mi("Y")#text(" is degenerate(!) is important (the theorem is not (!) valid in general for a non-degenerate limit ")#mi("Y")#text(") – is this claim true?")

#emph[#text("[Oops, this was an error – the exercise has now been corrected. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d59c6bc9f20826d3ef1893b87976d9f38670ed7535f4dc36abdcc23ac7bef213-1f2a281664a32cb81ca5cf3aeb30af8f8696f47aac2e276f375aa14b2f4e50b5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-461508")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2015")])]

#text("Exercise 9, definition of distribution at the beginning has typo.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/14689d63023ea33bbe9c409815d38f93fc4c35757a947fe16ce44cc6fe6cc1da-a9645bc7dcb9059b89e97a76e147dfe9c67228e788d48766f65e6aecf315aac3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-461510")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2015")])]

#text("The Lindberg approach is related to the “renormalization group approach”, as I learned from Yakov Sinai.")

#text("However, I couldn’t not reconcile the discussions of RG in hep-th and the discussion in the probability textbook.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joop de Maat")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-461513")[#strong[#text("Joop de Maat")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2015")])]

#text("A typo (“equvialence” before Remark 3) and a question: How exactly are the two notions of distributions from Remark 3 similar ? You only indicated in what the where different, not in what they are alike.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-461514")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2015")])]

#text("Thanks for the correction! The similarity is both notions of convergence require testing against “nice” functions (continuous compactly supported functions in the case of convergence in distribution, and smooth compactly supported functions in the case of convergence in the sense of distributions). In particular, it is true that a sequence of random variables ")#mi("X_n")#text(" converge in distribution to a random variable ")#mi("X")#text(" if and only if the probability measures ")#mi("\\mu_{X_n}")#text(" converge in the sense of distributions to ")#mi("\\mu_X")#text(". (But once one leaves the setting of probability measures, one can have more exotic distributions as the distributional limit, e.g. derivatives of delta functions.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f51bda6efdfa7d8aa46013ec5813b6206141bbe7c6db6cbf1621449112563a1-775d4dc7c2f2c3d46196d9524c4e1e96f11a75ff1c6102f8e7d162ba95d5210f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Venky")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-461888")[#strong[#text("Venky")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2015")])]

#text("In the Lindberg approach, I was trying to see where the Gaussian nature of the pdf of Y_i is important other than (3). Can one say that an implication of CLT is that the Gaussian pdf is the only pdf that preserves its functional form over countable addition of independent variables? Great notes, thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-461889")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2015")])]

#text("Yes, the gaussian is the only finite-variance ")#link("https://en.wikipedia.org/wiki/Stable_distribution")[#text("stable law")]#text(", and the Lindeberg argument explains why there can be at most one such law. (But there are other stable laws in the infinite variance case, which lie outside of the reach of the CLT: for instance, the ")#link("https://en.wikipedia.org/wiki/Cauchy_distribution")[#text("Cauchy distribution")]#text(" is also stable.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-461892")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2015")])]

#text("I have a question on the Example 5, we have known that Xn converges to X in distribution, where Xn is uniform distributed on {1/n, 2/n, …, n/n} and X is uniform[0,1]. How can we check that if Xn converges to X in prob?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-461895")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2015")])]

#text("This is not possible from the information given, because we do not know the joint distribution of ")#mi("(X,X_n)")#text(", only the individual distributions of ")#mi("X")#text(" and ")#mi("X_n")#text("; the joint distribution is irrelevant for the question of whether there is convergence in distribution, but is very relevant for convergence in probability For instance, ")#mi("X_n")#text(" could be ")#mi("X")#text(" rounded up to the next multiple of ")#mi("1/n")#text(", in which case ")#mi("X_n")#text(" converges to ")#mi("X")#text(" in probability (and almost surely). Or, ")#mi("X_n")#text(" could be independent of ")#mi("X")#text(", in which case it will not converge in probability or almost surely to ")#mi("X")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-462052")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2015")])]

#text("There appears to be a strange issue with one of the wordpress LaTeX renderers right now, as some simple expressions such as ")#mi("\\varphi = 0")#text(" are not rendering properly while others such as ")#mi("\\varphi")#text(" are fine. For those in the class following the notes online, a temporary workaround is to hover one’s mouse over the improperly rendered images to see the uncompiled LaTeX. I do not seem to be able to fix the issue on my end, but I’m hoping that the problem will resolve itself shortly (at which point I will remove this comment).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-462088")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2015")])]

#text("OK, the problem seems to be that as of about 24 hours ago, wordpress has become unable to render any latex fragment that it has not previously rendered, presumably due to the machine that does all the new renderings being somehow offline. I’d be interested to see if other wordpress.com sites are having the same issue, in which case it would make sense to report it. In the meantime, I’ve rolled back these notes to an earlier version for now to avoid the rendering errors. ")#emph[#text("[Update: it now appears that the issue is affecting all wordpress.com blogs, and has been reported. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd86f7b92203b74b0f977a8fd20335ccd94478dcd7fb0ab911937e35084f6ff5-f1d0fa0ac3333f488617c738d65dafdbe1ad7fb1a5ddc25de041910bfa7b0384.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ianmarqz")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-462093")[#strong[#text("ianmarqz")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2015")])]

#text("I have the same problem of well rendering : ( sample: ")#link("https://juanmarqz.wordpress.com/about/sum-of-reciprocals/")[#text("https://juanmarqz.wordpress.com/about/sum-of-reciprocals/")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 5: Variants of the central limit theorem | What's new")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-462099")[#strong[#text("275A, Notes 5: Variants of the central limit theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2015")])]

#text("[…] the previous set of notes we established the central limit theorem, which we formulate here as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea392ebbce42c233c40f790df9ce2b6cd40cb577f03070a663a4f8a438c4783c-accffbe9d6b5a5642d90f557cec04e5a90790305c3d5172b8e1416ce56d57b21.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dillon")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-462303")[#strong[#text("Dillon")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2015")])]

#text("The characteristic function for a uniform distribution on an interval (Exercise 21) is missing an ")#mi("i")#text(" in the denominator. Also some of the preceding exercises still say ")#mi("F")#text(" for the characteristic function where ")#mi("\\varphi")#text(" would be more consistent.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-462376")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2015")])]

#text("In exercise 10 (vii), should it be liminf EG(X_n)>= EG(X)?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d59c6bc9f20826d3ef1893b87976d9f38670ed7535f4dc36abdcc23ac7bef213-1f2a281664a32cb81ca5cf3aeb30af8f8696f47aac2e276f375aa14b2f4e50b5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-462683")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2015")])]

#text("‘non-engative’ should be ‘non-negative’ (search and replace time)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d59c6bc9f20826d3ef1893b87976d9f38670ed7535f4dc36abdcc23ac7bef213-1f2a281664a32cb81ca5cf3aeb30af8f8696f47aac2e276f375aa14b2f4e50b5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-462684")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2015")])]

#text("‘Levi continuity theorem’ should be ‘Lévy continuity theorem’ (search and replace again)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/add00c059619f064d907b5c3c54268ed34e9c40b064ecf5c2668b749c25c6341-d899cd2edf4733e3e1f844f29a1cb48ed5cbed7c3b4c368d84f2a776230d8fd0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jura05")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-462845")[#strong[#text("jura05")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2015")])]

#text("thank you for these lectures!")#linebreak()#text(" some typos:")#linebreak()#text(" – formula after (14) – missing term O(.)")#linebreak()#text(" – before (15): instead of “below by 1/2 on [0,eps]” should be “below by 1/2 on [a,a+eps]”")#linebreak()#text(" – proof of (14) goes for the special case a=0; although there is no difference.. maybe it is convenient to write a general bound")#linebreak()#text(" ")#tao-math("\\left|E\\psi(X)-E\\psi(Y)\\right|\\le \\int_{-c}^c |\\varphi_X(t/\\varepsilon)-\\varphi_Y(t/\\varepsilon)|dt/t", block: false)#text(" and apply it to X=S_n/sqrt{n}-a, Y=N-a")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-469076")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2016")])]

#text("Thanks for the great notes. Small typos:")

#text("1. inequality (2) and the following equation are missing a square in the $(x-x_1)^2$ term.")

#text("2. Closed bracket missing in Ex 17 (ii)")

#text("3. Ex 17 (iii), the indicator function doesn’t appear correctly.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-469079")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2016")])]

#text("What is known about the convergence rate in Erdos-Kac theorem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-469080")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2016")])]

#text("I think this paper by Harper represents the current state of the art: ")#link("http://www.ams.org/mathscinet-getitem?mr=2507311")[#text("http://www.ams.org/mathscinet-getitem?mr=2507311")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-472784")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2016")])]

#text("In Exercise 14, for each ")#mi("n")#text(", ")#mi("{(X_{1,n},\\dots,X_{k_n,n})}")#text(" are jointly independent. What do you mean by “We do not require the random variables ")#mi("{(X_{1,n},\\dots,X_{k_n,n})}")#text(" to be jointly independent in ")#mi("{n}")#text("“? Would you illustrate by giving an example that what could be dependent here?")

#emph[#text("[For instance, we do not require the tuple ")#mi("(X_{1,1},\\dots,X_{k_1,1})")#text(" to be independent of ")#mi("(X_{1,2},\\dots,X_{k_2,2})")#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-472830")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2016")])]

#text("In Exercise 25, can one avoid calculating the ")#mi("j")#text("-th derivative of ")#mi("\\varphi_X(t)")#text(" by just directly integrating the Taylor expansion of ")#mi("e^{it}")#text("?")

#emph[#text("[This should work also, as long as one is careful with estimating error terms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-472831")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2016")])]

#text("For Exercise 19, all the textbooks I have seen use the contour integrals. Can one do it with other methods than the one in complex analysis?")

#emph[#text("[One such method begins by observing that the pdf of the normal distribution obeys an ODE which then translates to an ODE for the characteristic function (cf. Stein’s method). -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-686771")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2024")])]

#text("Dear professor Tao:")

#text("Could you elaborate a bit more on this method by translating an ODE for the pdf of the normal distribution to an ODE for the characteristic function?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-686775")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2024")])]

#text("For instance, the pdf ")#mi("f(x) = \\frac{1}{2\\pi} e^{-x^2/2}")#text(" obeys the ODE ")#mi("f^{\\prime}(x) = -x f(x)")#text(". I invite you to take Fourier transforms of both sides and derive a corresponding ODE for the characteristic function ")#mi("\\Phi(t)")#text(" of this pdf.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-686778")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2024")])]

#text("Thank you professor. If one takes the derivative of the characteristic function inside the integral using dominated convergence, does one still need to justify manipulating complex valued functions?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-472832")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2016")])]

#text("In the Fourier proof of Theorem 8, would you elaborate the “equivalently” part? Is the parenthesis a typo there?")

#emph[#text("[We are using the Taylor approximation ")#mi("1 - x = \\exp( -x + o(x))")#text(" for small ")#mi("x")#text(" (specifically, ")#tao-math("x = t^2/2n - o(\\left|t\\right|^2/n)", block: false)#text("). -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-472848")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2016")])]

#text("By direct substitution, I got")#linebreak()#text(" ")#tao-math("\\displaystyle \\varphi_X(t/\\sqrt{n})^n=\\exp(-t^2+n\\cdot o(\\left|t\\right|^2/n))=\\exp(-t^2+\\cdot o(\\left|t\\right|^2))", block: false)#linebreak()#text(" For fixed $t$, when taking the limit, how do you get rid of the little o term?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-472850")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2016")])]

#text("The asymptotic notation ")#mi("o()")#text(" here is with respect to the limit ")#mi("n \\to \\infty")#text(", rather than ")#mi("t \\to 0")#text(",so the ")#tao-math("o(\\left|t\\right|^2)", block: false)#text(" term goes to zero in the limit when ")#mi("t")#text(" is fixed and ")#mi("n")#text(" goes to infinity. (By the way, I corrected a typo in my previous answer, in which I had omitted a factor of ")#mi("1/n")#text(" in the choice of ")#mi("x")#text(".)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-472883")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2016")])]

#text("In Exercise 14, what is the intuition of the Lindeberg condition?")#linebreak()#text(" ")#tao-math("\\displaystyle  \\frac{1}{\\sigma_n^2} \\sum_{i=1}^{k_n} {\\bf E}( \\left|X_{i,n}\\right|^2 1_{\\left|X_{i,n}\\right| > \\varepsilon \\sigma_n} ) \\rightarrow 0", block: false)

#text("Why would one expect such a condition implies the desired result?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-472908")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2016")])]

#text("The central limit theorem can fail if there is a significant probability that one of the summands ")#mi("X_{i,n}")#text(" is so large that it is comparable to the total standard deviation ")#mi("\\sigma_n")#text(". The Lindeberg condition is basically an assertion that these sort of outlier events are vanishingly rare (and their contribution to the sum has vanishingly small variance) in the limit ")#mi("n \\to \\infty")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-472917")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2016")])]

#text("I saw Billingsley in his Probability and Measure proves Remark 28 by proving the inversion formula:")

#text("If the probability measure ")#mi("\\mu")#text(" has characteristic function ")#mi("\\varphi")#text(" and $\\mu\\{a\\}=\\mu\\{b\\}=0$, then")#linebreak()#text(" ")#mi("\\displaystyle \\mu(a,b]=\\lim_{T\\to\\infty}\\frac{1}{2\\pi}\\int_{-T}^T\\frac{e^{-ita}-e^{-itb}}{it}\\ dt.")

#text("This approach looks rather different from the one in the proof of Theorem 27, which uses the Schwartz functions and is much shorter. What makes the Schwartz function-approach faster and is it hinted somewhere that these two approaches are essentially the same?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-472983")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2016")])]

#text("Ah, the inversion formula should be")#linebreak()#text(" ")#mi("\\displaystyle \\mu(a,b]=\\lim_{T\\to\\infty}\\frac{1}{2\\pi}\\int_{-T}^T\\frac{e^{-ita}-e^{-itb}}{it}\\varphi(t) dt.")

#text("Actually, the proof of the inversion formula is not that long. The key step is just exchanging the integral using Fubini and taking the limit. Still it looks rather different from the Schwartz-function-approach.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-472992")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2016")])]

#text("Basically the difference lies in the use of the ")#link("http://www.tricki.org/article/Smoothing_sums")[#text("smoothing sums technique")]#text(": replacing a rough cutoff such as ")#mi("1_{[a,b]}")#text(" with a smoother cutoff in order to enjoy better decay of the Fourier transform. The price one pays for this is that the formulae become a little less explicit, possibly leading to worse quantitative bounds in some cases, but in many applications this sort of loss is acceptable.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-473255")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2016")])]

#text("In theorem 11, can we replace random variables with random vectors?")

#emph[#text("[Yes; see for instance the linked exercise. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-473298")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2016")])]

#text("Also for Proposition 4 and Exercise 7 one can have random vectors instead? I’m wondering if i missed reading some of the notes about the random vector part or it is just trivial generalization.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-473322")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2016")])]

#text("If one deletes (ii) then the remaining claims are equivalent in the vector-valued case. But it is not clear to me whether there is an analogue for (ii) in the vector-valued case (one has to define the cumulative distribution function properly, and specify exactly what a “point of continuity” would mean for that function); the proof given is restricted to the scalar case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-473324")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2016")])]

#link("https://en.wikipedia.org/wiki/Cumulative_distribution_function#Multivariate_case")[#text("https://en.wikipedia.org/wiki/Cumulative_distribution_function#Multivariate_case")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-473296")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2016")])]

#text("In Exercise 7, do you have a hint for (v) —>(i)? I don’t have any idea why the boundary of ")#mi("E")#text(" would have anything to do with continuity of a function.")

#emph[#text("[Consider sets ")#mi("E")#text(" of the form ")#mi("E = (-\\infty,t]")#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-473297")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2016")])]

#text("In the proof of Proposition 4, is ")#mi("PG(X_n)")#text(" a typo? Likewise for several others?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quantitative continuity estimates | What's new")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-481105")[#strong[#text("Quantitative continuity estimates | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2017")])]

#text("[…] starting point for the Lindeberg exchange method in probability theory, discussed for instance in this previous post. The identity in (ii) can also be used in the Lindeberg exchange method; the terms in the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8674cc28e632d26a5a8fcd71f3fc532d31e93938a9a271e55cf0e7cb79bad0ea-895cfb7908b28a806751cdf4fe30d94acf8d7ad12ca3895cb1536c9fbe2726d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Discotech")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-483142")[#strong[#text("Discotech")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2017")])]

#text("In exercise 35, should the exponent have a $\\pi$? I think maybe it should not. Unless I’m misunderstanding the meaning of the Lebesgue integral over the complex plane, the measure defined isn’t normalized to 1.")

#text("In the hint on exercise 40, do you mean to refer to the probability $P( X_1 1_{|X_1|>M} + \\dots + X_n 1_{|X_d|>M} \\geq 0)$ (greater than signs instead of less than signs)?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-506558")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2018")])]

#text("In Slutsky’s theorem, can one relax the condition regarding the convergence of ")#mi("Y_n")#text(" to be convergence in distribution?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-506613")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2018")])]

#text("When the limit ")#mi("Y")#text(" is deterministic, convergence in distribution is the same as convergence in probability.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31daa2b54d8b78ea8b4ce9d4b326612fe4a5284ffee31fe4a28bbd6c53e16b96-29f296970f058196f3a4840e607b4d177420a8e1c626ae1f027ebe6cc5e34567.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of haonanz")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-512947")[#strong[#text("haonanz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2019")])]

#text("Hello Prof. Tao, I have a question regard Exercise 7 prove ii) => v). I am thinking if I could use sigma algebra like proof. I believe the difficulty comes from the fact we have only convergence at continuity point. If we assume it’s true for all t, then I think I can show that the set of E satisfy this property is closed under countable union and countable closure), then use the fact Borel sets are the smallest sigma algebra generated by the half-intervals to complete the proof. I wonder the fact we know those discontinuity is at most countably many points can somehow be used to show this generated sigma algebra still contains the half-intervals thus the borel set.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-512960")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2019")])]

#text("I’m not sure a sigma algebra approach will be easy to execute, because the set of Borel sets ")#mi("B")#text(" with ")#mi("\\partial B")#text(" of measure zero is not closed under countable union or countable intersection. (The strategy I had in mind instead is to approximate ")#mi("B")#text(" by its interior and its exterior and use (iii), (iv).)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31daa2b54d8b78ea8b4ce9d4b326612fe4a5284ffee31fe4a28bbd6c53e16b96-29f296970f058196f3a4840e607b4d177420a8e1c626ae1f027ebe6cc5e34567.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of haonanz")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-513016")[#strong[#text("haonanz")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2019")])]

#text("A follow up question regard proving i)=>iii), I can prove the claim for the compact case using upper approximation of a CTS and compact supported function. Do you mind providing hint on how can I extend this to the closed case? Thanks again!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-513018")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2019")])]

#text("Show that for large ")#mi("R")#text(", the probability ")#tao-math("{\\bf P}(\\left|X\\right| \\leq R)", block: false)#text(" is close to 1, then show that the probability ")#tao-math("{\\bf P}(\\left|X_n\\right| \\leq 2R)", block: false)#text(" is close to 1 for large ")#mi("n")#text(", thus the probability ")#tao-math("{\\bf P}(\\left|X_n\\right| > 2R)", block: false)#text(" is small.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-685554")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2024")])]

#text("Dear professor Tao:")

#text("As of the direction (i) implies (iii) in Exercise 7, I think the compact case follows directly from using the function ")#mi("1_K")#text(" in the definition of weak convergence. Are we supposed to use inner regularity of the probability measure to generalize to the closed set setting? If possible I would like to hear a little more on this earlier comment of yours on showing that the probability of ")#tao-math("\\left|X_n\\right|", block: false)#text(" being large is small, thank you.")

#emph[#text("[As already stated in the exercise, the hint is to use Urysohn’s lemma. -T]")]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d24ffbd33aa6c91f0594a2885464825cdcc231b65334b8d2e381ee738e28aa4-a966d0607e9aaf920f0bf537f653ff918f49f1208d9afeb947b09a6833ffc0a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-527792")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2019")])]

#text("There should be a $k_n$ instead of $n$ in point (ii) of exercise 14.")

#emph[#text("[Corrected, thanks – T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-553553")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2020")])]

#text("Let ")#mi("X_1, X_2, \\ldots")#text(" be iid Bernoulli(")#mi("p")#text(") random variables, that is, ")#mi("P(X_i=1)=p")#text(" and ")#mi("P(X_i=0)=1-p")#text(".")

#text("Let")

#mi("\\displaystyle D_n=\\sum_{i=1}^n Y_i")

#text("where ")#mi("Y_i=I_{(X_i=1,X_{i+1}=1)}")#text(".")

#text("Show that ")#mi("\\sqrt{n} \\left(\\frac{D_n}{n}-p^2\\right)\\overset{D}{\\rightarrow} N(0, \\sigma^2)")#text(" and determine ")#mi("\\sigma^2")#text(".")

#text("How can we prove this by using some elementary tools?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b5ac6ebd8ae9c0162eeb7b5a7368e7e5b126613b69fd10a323bf2256ab83184-c85c46b24b327451aa4e3a714bccdb3fc062bb67687ded188b2b94ba1079607e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-612505")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2020")])]

#text("You may try to solve it using the central limit theorem and Slutsky’s theorem. I have not done this very exercise, but it seems that this can be done by using these tools. Try it and let us know here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ff75aa3bb52e6fe612c0cf7babaadfc97e62e669021dce6255109b7c248a08a6-9fabe7de7d9471a5869a5523375df8a295fa7cf4be4efbcc48a2c80e1bc05cec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-614646")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2021")])]

#text("Yes that would work. I just checked it.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b5ac6ebd8ae9c0162eeb7b5a7368e7e5b126613b69fd10a323bf2256ab83184-c85c46b24b327451aa4e3a714bccdb3fc062bb67687ded188b2b94ba1079607e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-612267")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2020")])]

#text("On line number 22 of these notes, you have written about applying Paley Zygmund inequality to get the mentioned lower bound.")#linebreak()#text(" I think there is a typo in labelling it as Exercise 42 of Notes 1 ; it should be Exercise 44 of Notes 1.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ff75aa3bb52e6fe612c0cf7babaadfc97e62e669021dce6255109b7c248a08a6-9fabe7de7d9471a5869a5523375df8a295fa7cf4be4efbcc48a2c80e1bc05cec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-614456")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2021")])]

#text("In Exercise 19, we see that from the definition of characteristic function it suffices to show that the result holds when ")#mi("\\mu = 0")#text(" and ")#mi("\\sigma^2 = 1.")#text(" Now that calls for showing ")#mi("\\mathbf{E} [ e^{i tX} ] = e^{-t^2 / 2}")#text(" for all complex numbers ")#mi("t.")#text(" Now rewriting the LHS as an integral one has a holomorphic function on the LHS and the RHS is also a holomorphic function. Now, one can prove this identity for the case when ")#mi("t")#text(" is purely imaginary so that ")#mi("it")#text(" is purely real by a direct evaluation of the integral which appears on the LHS.")#linebreak()#text(" Now, using the fact that non-trivial holomorphic maps have isolated zeroes, and identifying that the holomorphic map LHS – RHS is zero identically on the imaginary axis, one concludes that the identity holds for all complex numbers ")#mi("t.")

#text("Is that correct ?")

#emph[#text("[Sure, this works. One can also compute the integral for arbitrary ")#mi("t")#text(" by completing the square and contour shifting instead of relying on analytic continuation. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b5ac6ebd8ae9c0162eeb7b5a7368e7e5b126613b69fd10a323bf2256ab83184-c85c46b24b327451aa4e3a714bccdb3fc062bb67687ded188b2b94ba1079607e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-614651")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2021")])]

#text("I think to show that ")#mi("\\mathbf{E} [ e^{it X} ]")#text(" is holomorphic over ")#mi("\\mathbf{C}")#text(", an easy way is to notice that it is the derivative of the holomorphic map ")#mi("t \\mapsto \\mathbf{E} [ X e^{itX}]")#text(" and hence the former must also be holomorphic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b5ac6ebd8ae9c0162eeb7b5a7368e7e5b126613b69fd10a323bf2256ab83184-c85c46b24b327451aa4e3a714bccdb3fc062bb67687ded188b2b94ba1079607e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-614653")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2021")])]

#text("Filling a gap in my previous comment: we need to notice that we can interchange the derivative and expectation, thanks to Lebesgue’s dominated convergence theorem.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ff75aa3bb52e6fe612c0cf7babaadfc97e62e669021dce6255109b7c248a08a6-9fabe7de7d9471a5869a5523375df8a295fa7cf4be4efbcc48a2c80e1bc05cec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-614644")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2021")])]

#text("Prof. Tao in lines 4-5 of the proof of Proposition 1 you have cited Theorem 24 from Notes 1. I think you wanted to cite Theorem 25 from Notes 1 (since here we have the premises satisfied for ")#mi("\\varepsilon = 2")#text(").")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c989cb0db1cb53838b8e08894f1f9ae78fe64b1279cdad199123e16c8db98ef3-cad3adc3b643c6ba4e04511616ccc7c7b7ca4cd963882b77631ac7b5c9488f4a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orestis Plevrakis")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-623718")[#strong[#text("Orestis Plevrakis")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2021")])]

#text("I tried to prove Levy’s continuity theorem without using Prokhorov’s theorem, but I failed. However, I cannot see why one must pass through such an argument to get Levy’s theorem. Can you give some intuition?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb24952b2d607b10beae62d68b98f5befbc8b435e6dc6d1e12724f9b07900dff-37a1b061d60c69ce5135b0e8806f5f029547ff0d4b81748d006cd0e4c7b9ea70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-632021")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2021")])]

#text("In the proof of the moment method (after exercise 46) there are two mentions of exercise 36 in Notes 1, but it should be exercise 37.")

#text("Further, a question about theorem 44: in the final equation, the RHS seems to be tending to ")#mi("\\infty")#text(" for fixed ")#mi("t")#text(". How can we argue that ")#mi("\\phi_{X_n}(t) \\rightarrow \\phi_{X}(t)")#text(" point-wise for ")#mi("t")#text("?")

#emph[#text("[Corrected, thanks. There was a negative sign that was omitted by mistake in the exponent of the RHS that has now been restored – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b5ac6ebd8ae9c0162eeb7b5a7368e7e5b126613b69fd10a323bf2256ab83184-c85c46b24b327451aa4e3a714bccdb3fc062bb67687ded188b2b94ba1079607e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-641902")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2022")])]

#text("In Exercise 15 (Weak Berry-Esseen bounds) part (i) is it the right way to do as follows:")

#text("We would do everything verbatim as in Lindeberg’s proof except now we expand the Taylor series till the third derivative, and in the first step instead of specializing to finite third moment we consider the special case of finite fourth moment; then for the general case we use the same truncation method.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b5ac6ebd8ae9c0162eeb7b5a7368e7e5b126613b69fd10a323bf2256ab83184-c85c46b24b327451aa4e3a714bccdb3fc062bb67687ded188b2b94ba1079607e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-641903")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2022")])]

#text("More precisely:")#linebreak()#text(" first of all we consider the case when the fourth moment of ")#mi("X")#text(" is finite, then notice that we can just imitate the construction ")#mi("(X_n , Y_n)")#text(" as done in Lindeberg’s proof of the central limit theorem, with the only difference being that now we are expanding the Taylor series of ")#mi("G(Z + \\frac{1}{\\sqrt{n}} X_n )")#text(" upto third order derivatives to get")#linebreak()#text(" ")#tao-math("G (Z + \\frac{1}{\\sqrt{n}} X_n) = G(Z) + \\frac{1}{\\sqrt{n}} G^{\\prime} (Z) X_n + \\frac{1}{2n} G ^{\\prime\\prime} (Z) X_n^2 + \\frac{1}{6 \\sqrt{n^3} } G ^{\\prime\\prime\\prime} (Z) X_n ^3 + O ( n^{-2} \\left| X_n \\right|^4 )", block: false)#text(";")#linebreak()#text(" now we just imitate all the other steps of Lindeberg’s proof (for the case of finite third moments) the only distinction being that now we keep carrying the third derivative term throughout,")#linebreak()#text(" thus we would obtain at the final step")#linebreak()#text(" ")#tao-math("\\mathbf{E} [ G ( \\frac{X_1 + ..... + X_n}{\\sqrt{n}} ) ] - \\frac{E} [ G ( N ) ] = c \\cdot \\sup_{x} \\left|G ^{\\prime\\prime\\prime} (x)\\right| \\mathbf{E} [ \\left|X\\right|^3 ] n^{-1/2} + o ( n^{-1/2} )", block: false)#linebreak()#text(" where ")#mi("c")#text(" is an absolute constant (the role of ")#mi("G")#text(" got nullified by taking the supremum).")

#text("Now we relax the condition of finite fourth moment in the exact same manner by constructing a truncation and then bounding the remaining portion of the original series to show that ")#tao-math("\\mathbf{E} [ \\frac{\\left|X_{1 , > } + .... + X_{n , >} \\right| }{\\sqrt{n} } ] \\to 0", block: false)#text(" as ")#mi("n \\to \\infty")#text(" and then using the Lipschitz property of ")#mi("G")#text(" which is guaranteed as ")#mi("G")#text(" is three times differentiable and hence at least continuously differentiable, and also compactly supported (thanks to the mean value theorem).")#linebreak()#text(" Now about the truncated portion in a similar way we show that it satisfies the conclusions we had for the finite fourth moment case (the same arguments as in Lindeberg’s proof would go through).")

#text("Finally putting all these together would give us the weak Berry-Esseen bounds.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b5ac6ebd8ae9c0162eeb7b5a7368e7e5b126613b69fd10a323bf2256ab83184-c85c46b24b327451aa4e3a714bccdb3fc062bb67687ded188b2b94ba1079607e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-641904")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2022")])]

#text("I see some typos: that should be ")#mi("o ( n^{-1/2}),")#text(" and ")#mi("\\mathbf{E} [ G ( N ) ]")#text(" respectively in the 13th line of display containing the ")#mi("\\sup")#text(" term.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-641910")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2022")])]

#text("This will not work because the implied constant in the error term depends on bounds on the fourth derivative of G, which will diverge in the limit. A Taylor expansion to third order will suffice here, with no truncation required.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b5ac6ebd8ae9c0162eeb7b5a7368e7e5b126613b69fd10a323bf2256ab83184-c85c46b24b327451aa4e3a714bccdb3fc062bb67687ded188b2b94ba1079607e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-641924")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2022")])]

#text("Yes sir, I realize this now. Thank you for pointing it out to me.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b5ac6ebd8ae9c0162eeb7b5a7368e7e5b126613b69fd10a323bf2256ab83184-c85c46b24b327451aa4e3a714bccdb3fc062bb67687ded188b2b94ba1079607e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-641905")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2022")])]

#text("Sir, towards the end of Lindeberg’s proof you have said that this proves (3).")#linebreak()#text(" I think you meant to label the equation in the 5th line of display after Exercise 13 involving ")#mi("X_i")#text(" s as (3) instead of the one with ")#mi("Y_i")#text(" s.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b5ac6ebd8ae9c0162eeb7b5a7368e7e5b126613b69fd10a323bf2256ab83184-c85c46b24b327451aa4e3a714bccdb3fc062bb67687ded188b2b94ba1079607e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-642135")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2022")])]

#text("Prof Tao in the statement of Berry Esseen theorem (Theorem 37) I think you may like to add the condition that ")#mi("X")#text(" needs to have a finite third moment.")#linebreak()#text(" (Though technically speaking what you have written is still quite correct.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-682386")[#strong[#text("Convergence of mean from almost sure convergence in a super-linear bounded mean setting | Aditya Guha Roy's weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2023")]

#text("[…] (together with Kolmogorov’s 0-1 law) is demonstrated in the proof of the opening proposition here. In a later blogpost I shall discuss consequences of Proposition 1 which are of a similar […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-685538")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2024")])]

#text("Dear professor Tao:")

#text("To clarify, in the proof of Proposition 4, the fact that ")#mi("F_X")#text(" has at most countable number of discontinuities is used to ensure the partition by the ")#mi("t_i")#text(" exists, is this correct?")

#emph[#text("[Yes – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-685552")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2024")])]

#text("Dear professor Tao;")

#text("Possible minor typos in the proof of Proposition 1:")

#mi("t")#text(" should be changed to ")#mi("t_i")#text(" in the expectation of ")#mi("G_\\varepsilon(X_n)")#text(", and the remark should be “the restriction to continuity points of ")#mi("F_X")#text(" is necessary…”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-685572")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2024")])]

#text("Dear professor Tao:")

#text("To deduce (i) from (iii) in Exercise 7, I can see the Urysohn’s lemma is invoked to establish the compact case. From the compact case, it seems that one can get the the limit superior of the probability of ")#mi("X_n")#text(" in ")#mi("K")#text(" bounded by the probability of ")#mi("X")#text(" in ")#mi("K")#text(" plus the limit superior of the probability of ")#tao-math("\\left|X_n\\right| > R", block: false)#text(". Hence my question concerns only the factor 2 in your earlier comment. Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-685584")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2024")])]

#text("Apply Urysohn’s lemma to obtain a non-negative continuous function supported on ")#mi("B(0,2R)")#text(" and equal to one on ")#mi("B(0,R)")#text(". Apply this function to both ")#mi("X_n")#text(" and ")#mi("X")#text(" to be able to compare the indicated probabilities ")#tao-math("{\\bf P}(\\left|X\\right| \\leq R)", block: false)#text(" and ")#tao-math("{\\bf P}(\\left|X_n\\right| \\leq 2R)", block: false)#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-685586")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2024")])]

#text("Dear professor Tao:")

#text("Thank you so much for the feedback. For a compact ")#mi("K")#text(", if we set ")#mi("U_i")#text(" to be the set of distance smaller than ")#mi("1/i")#text(" to ")#mi("K")#text(", and apply Urysohn’s lemma to find a continuous function ")#mi("f_i")#text(" that equals 1 on ")#mi("K")#text(" and 0 on the complement of ")#mi("U_i")#text(", then continuity from above establishes the compact case.")

#text("By (i) the probability of ")#mi("X_n leq +/-R")#text(" converges to the probability of ")#mi("X leq +/-R")#text(", isn’t it follows then that the probability of ")#tao-math("\\left|X_n\\right| leq R", block: false)#text(" converges to the probability of ")#tao-math("\\left|X\\right| leq R", block: false)#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-685589")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2024")])]

#text("Part (i) only gives one-sided bounds; it upper bounds the lim sup, but does not lower bound the lim inf.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-685613")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2024")])]

#text("Dear professor Tao:")

#text("In the proof of De-Moivre Laplace theorem, is it advisable to split into the case of odd/even ")#mi("i")#text(" as in Durrett’s text?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-685617")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2024")])]

#text("And if possible, can you provide a bit more hint on how to proceed here? thank you")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-685619")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2024")])]

#text("There are multiple ways to proceed here, which have varying degrees of efficacy. In general, I recommend you actually *try* multiple approaches, before asking for advice whether it is going to be work or not – these sorts of “failures” are in fact extremely instructive and crucial in building one’s one mathematical confidence; they are part of why these problems are assigned as exercises in the first place. Nobody is going to administer any sort of punishment to you for selecting an initial approach that turns out not to be fruitful.")

#text("See also my advice post “")#link("https://terrytao.wordpress.com/career-advice/ask-yourself-dumb-questions-and-answer-them/")[#text("Ask yourself dumb questions – and answer them!")]#text("“, as well as ")#link("https://gowers.wordpress.com/2011/09/23/welcome-to-the-cambridge-mathematical-tripos/")[#text("this blog post")]#text(" of Tim Gowers warning about being stymied by “fake difficulties”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-1/#comment-685620")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2024")])]

#text("Thank you so much for the encouragement professor Tao.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-685694")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2024")])]

#text("Dear professor Tao:")

#text("In Exercise 10(iv) (Skorokhod’s representation theorem), if one chooses the unit interval ")#mi("[0, 1]")#text(" with Borel measure as the probability space model for the ")#mi("Z_n := X_n^+")#text(" (defined as in Exercise 29 of note 0) and ")#mi("Z := X^+")#text(", can you give some directions as to what the null set might be outside of which one has convergence almost surely?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-685701")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2024")])]

#text("Dear professor Tao:")

#text("For any ")#mi("\\omega")#text(" in ")#mi("(0, 1)")#text(", I worked out that we can use ")#mi("X^+(\\omega)")#text(" to bound both the limsup of ")#mi("X_n^+(\\omega)")#text(" from above, and the liminf of ")#mi("X_n^+(\\omega)")#text(" from below, therefore get convergence almost surely. May I ask if 0 and 1 capture the entire null set on which the convergence might fail?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-685736")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2024")])]

#text("Dear professor Tao:")

#text("In the geometric argument for Lemma 12, is the fact that the joint density of independent Gaussians the density of a multivariate Gaussian variable assumed to be known, as the result of some Exercises in Note 2?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-685741")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2024")])]

#text("The joint density of two independent random variables is always the tensor product of the individual densities (this is an easy consequence of Tonelli’s theorem).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-685802")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2024")])]

#text("Dear professor Tao:")

#text("To derive the error term in the Taylor approximation in the Lindeberg approach, one needs the sum of ")#mi("G^{(3+i)}(Z) / (3 + i)!")#text(" times ")#mi("(X_n / \\sqrt{n})^i")#text(" to be ")#mi("O(1)")#text(", where the implied constant depends on ")#mi("G")#text(". I’d like to ask for some little clarification on this particular step. Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-685803")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2024")])]

#text("Dear professor Tao:")

#text("I apologize for the bothering. It is the Taylor Theorem with remainder.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-685813")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2024")])]

#text("Dear Professor Tao:")

#text("In the Lindeberg approach to the CLT, the error term in the display right below the statement “The same considerations apply after swapping ")#mi("X_n")#text(" and ")#mi("Y_n")#text("…” should be the same as above.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-685814")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2024")])]

#text("My mistake, ")#mi("Y_n")#text(" is a copy of ")#mi("N")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-685817")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2024")])]

#text("Dear Professor Tao:")

#text("In the Lindeberg approach to the CLT, I doubt the expression for variance of ")#mi("X_{\\leq}")#text(" involves ")#mi("+ \\mu_n^2")#text(" rather than ")#mi("- \\mu_n^2")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-685921")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2024")])]

#text("Dear professor Tao:")

#text("To generalize the Lindeberg swapping trick to triangular arrays, I attempted extending the probability space for each row ")#mi("n")#text(" to get iid normal variables ")#mi("Y_{i, n}")#text(" for ")#mi("i")#text(" between 1 and ")#mi("n")#text(", with mean 0 and variance that equals the variance of ")#mi("1 / \\sigma_n X_{k_n, n}")#text(". Yet it’s not clear that on subtraction the error term goes to zero with this construction. Can you provide some hint on how the Lindeberg condition is used in this setting? Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-685931")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2024")])]

#text("Dear professor Tao:")

#text("I see it now that one should extend the probability spaces to get a triangular array of normal variables such that each row have mean zero and variances of the corresponding row of the original variables. Yet it is still a bit unclear as to how the Lindeberg condition is used to control the error term. A little suggestion will be greatly appreciated, thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-685973")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2024")])]

#text("Dear professor Tao:")

#text("For the Lindeberg CLT, denoting the variance of ")#mi("X_{i,n}")#text(" by ")#mi("alpha_{i,n}^2")#text(", and assuming finite third moment for the entire triangular array, one can get the difference between the expectation of the scaled row sums to be such that ")#tao-math("{bf E} G( frac{X_{1,n}+dots+X_{k_n,n}}{sigma_n} ) - {bf E} G( frac{Y_{1,n}+dots+Y_{k_n,n}}{sigma_n} ) = O(frac{k_n}{sigma_n^3} (alpha_{k_n,n}^3 + {bf E}\\left|X_{k_n,n}\\right|^3))", block: false)#text(". But then it’s unclear how the Lindeberg condition implies that the RHS tends to 0. May I ask if there is something missing?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-685981")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2024")])]

#text("Dear professor Tao:")

#text("I apologize for the previous poorly-complied comment. To prove the Lindeberg CLT, assuming finite third moment for the entire triangular array, I got the expectation difference of G(row sum of ")#mi("X_{i, n}")#text(") scaled by ")#mi("1/\\sigma_n")#text(" and G(row sum of ")#mi("Y_{i, n}")#text(") scaled by ")#mi("1/\\sigma_n")#text(", to be the big-O of ")#mi("k_n")#text("(the standard deviation of the last element in row ")#mi("n")#text(" cube + the third moment of the last element in row ")#mi("n")#text("), over ")#mi("\\sigma_n")#text(" cube, which I find hard to control by the given condition. Can you provide some hint on the correct way to generalize the original swapping argument?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-686287")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2024")])]

#text("Dear professor Tao:")

#text("In the hint for part (ii) of Exercise 17, shouldn’t the index in the denominator for the sum of variances ranges from 1 to N instead of from 1 to infinity according to the Lindeberg CLT?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-686485")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2024")])]

#text("As for part (iii) of the converse direction of Kolmogorov’s three-series theorem, can you give some hint on how to show that the variance of the normalized sum is absolutely convergent?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-686486")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2024")])]

#text("Use part (ii).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-686496")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2024")])]

#text("Dear professor Tao")

#text("How much of complex/Fourier analysis do you suggest to be a reasonable prerequisite to the study of the Fourier approach of CLT, including the optional proof of Berry-Essen theorem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-686802")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2024")])]

#text("Dear professor Tao:")

#text("The characteristic function of the Cauchy random variable boils down to calculating an integral with integrand of the form cos(aw)/(1+w^2), is there a way to get the result of Exercise 22 without resorting to complex integration?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-686954")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2024")])]

#text("Dear professor Tao:")

#text("To show the absolutely integrable density function in Exercise 23 can be approximated in L1 norm by finite linear combinations of intervals, are we supposed to use the definition in note 1 together with the dominated convergence theorem?")

#text("[")#emph[#text("This will work – T.")]#text("]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-686960")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2024")])]

#text("Thank you professor and Merry Christmas.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-686956")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2024")])]

#text("Also, isn’t the PDF necessarily absolutes integrable by definition? Thank you.")

#text("[")#emph[#text("Yes, if it exists -T.")]#text("]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-687057")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2025")])]

#text("Dear professor Tao:")

#text("Can you give a little more justification on the statement in Exercise 26 that any gaussian random variable is sub-gaussian ? What inequality are we using here to derive the result?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-687062")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2025")])]

#text("There are multiple ways to obtain this estimate, for instance by using upper bounds on the error function, see ")#link("https://en.wikipedia.org/wiki/Error_function")[#text("https://en.wikipedia.org/wiki/Error_function")]#text(", or by dyadic decomposition.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-687174")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2025")])]

#text("Dear professor Tao:")#linebreak()#text(" Can you provide some hint on why (7) can be established for sub-gaussian variables in Exercise 26?")

#emph[#text("[Fubini’s theorem will suffice here. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-687175")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2025")])]

#text("Subgaussian variables can be shown to have finite moment of all orders, but how do we use the partial expansion to get the desired result? Or is it preferable to apply some convergence theorem instead?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b5ac6ebd8ae9c0162eeb7b5a7368e7e5b126613b69fd10a323bf2256ab83184-c85c46b24b327451aa4e3a714bccdb3fc062bb67687ded188b2b94ba1079607e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-687178")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2025")])]

#text("Hi, thanks for the question because I spent a lot of time on this same question when I was first learning the topic; I am glad someone asked it and I could write it here.")

#text("1. ")#strong[#text("Using MGFs")]#text(". The key thing that you use is that the MGF of a subgaussian random variable is entire and is of order ")#mi("O (e^{ct^2})")#text(" and you can prove that for an entire function which is of order ")#mi("O (e^{ct^2})")#text(" has all derivatives at ")#mi("0")#text(" finite. In particular, the claim follows.")

#text("2. ")#strong[#text("The tail way of doing it")]#text(".")#linebreak()#text("Thanks to the tail-representation of expected values we can write ")#linebreak()#tao-math("\\displaystyle \\mathbf{E} [ \\left|X\\right|^p ] = \\int_{0}^{\\infty} p x^{p-1} \\mathbf{P} { \\left|X\\right| > x } dx", block: false)#linebreak()#text("Now just replace the tail probability on the right hand side of the above line of display by the bound which we get due to the subgaussian property of X and that will give you ")#tao-math("\\mathbf{E} [ \\left|X\\right|^p ] < \\infty", block: false)

#text("Now I think, it’s easier to come up with the 2nd approach because the tail probabilities in the definition of subgaussian random variables would ring a bell, but I really like the MGF approach too.")

#text("3. ")#strong[#text("DCT")]#linebreak()#text("You also talk about using convergence theorems. Well I think one can modify the 2nd approach to find an excuse to use DCT, but I am not sure.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-687186")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2025")])]

#text("Thanks for replying. The 2nd approach is how I got the finite moment of all orders for subgaussian variables. It is hinted now that Fubini’s theorem is enough here, can you elaborate a bit on how they directly lead to (7)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b5ac6ebd8ae9c0162eeb7b5a7368e7e5b126613b69fd10a323bf2256ab83184-c85c46b24b327451aa4e3a714bccdb3fc062bb67687ded188b2b94ba1079607e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-687191")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2025")])]

#text("That’s because Fubini allows us to interchange expectation and sum when things converge like here (because ")#tao-math("\\mathbf{E} \\left|X\\right|^p < \\infty", block: false)#text(" means the sum ")#mi("\\sum t^n /n! \\mathbf{E} [ X^n ]")#text(" converge for each ")#mi("t")

#text("You Taylor expand the Euler-exponential function ")#mi("e^{itX}")#text(" and then take expectation. Then Fubini grants you to interchange the sum and the expectation, with impunity.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-687197")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2025")])]

#text("Thank you for the explanation. One issue only: Isn’t the convergence of the said series depends not only on whether ")#mi("{\\bf E}X^n < \\infty")#text(", but the growth rate of such terms as ")#mi("n \\to \\infty")#text(" as well?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-687184")[#strong[#text("Typical displacement of a SSRW after n steps is like √n | Aditya Guha Roy's weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2025")]

#text("[…] Remark 4. Actually the claim for the case when serves as a motivation for the central limit theorem (see Proposition 1 here). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-687198")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2025")])]

#text("Dear professor Tao:")

#text("From my understanding of your earlier hint on Exercise 26, one invokes the Fubini’s theorem by treating the sum as an integral over ")#mi("{\\bf N}")#text(" with respect to the counting measure $mu’$, is this correct? If so, how does one show that the series expansion converges simply from the condition of finite moment of all orders?")

#emph[#text("[For the non-negative version of Fubini’s theorem (Tonelli’s theorem), convergence is not required. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-687202")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2025")])]

#text("Dear professor Tao:")

#text("Thank you so much for the updated hint. Tonelli theorem justifies the interchange of sum and expectation for the unsigned ")#tao-math("\\left|X\\right|", block: false)#text(" (and ")#tao-math("\\left|t\\right| \\geq 0", block: false)#text("), I’m still a bit at loss as to how it helps to justify the signed case. I guess I’m not using the condition ")#mi("{\\bf E}X^k < \\infty")#text(" correctly.")

#emph[#text("[The analysis for ")#tao-math("\\left|X\\right|", block: false)#text(" from Tonelli’s theorem provides enough estimates to then justify the use of Fubini’s theorem for ")#mi("X")#text(". This combination of the Fubini and Tonelli theorems is very common in these sorts of arguments. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/902d6b8bfde3b82c79241479f440b4773848b34e47f626a557c6d833b3023e6b-cff8933d46268ae7b9f45119e47c9069c1b37a21fd7aa052025825c9ffe08ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-687204")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2025")])]

#text("Dear professor Tao:")

#text("In Exercise 26 one applies Fubini’s theorem to the positive and negative parts of ")#mi("X^k")#text(", and the finite moment condition ensures that one does not run into indeterminant form as ")#mi("\\infty - \\infty")#text(". Is this correct?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-692649")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2026")])]

#text("In the Lindeberg method, we require the function to be continuous and compactly supported. Is this ultimately related to the requirement of continuity and compact support in vague convergence and convergence in distribution, or is there another reason? If so, why do we need the class of functions in Definition 2 to satisfy these specific properties?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-692663")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2026")])]

#text("By the Riesz representation theorem, the space ")#mi("C_c({\\bf R})")#text(" is the predual of the space of finite Radon measures, so it is the natural space of test functions for which to define vague convergence. But, as mentioned in the text, the Lindeberg method actually works best for smoother test functions (I use ")#mi("C^\\infty_c")#text(" in the notes, but this is overkill – three degrees of regularity, for instance, would definitely suffice). But the specific class of test functions turns out to not be of major importance here, since one can use density arguments to pass from the stronger class to the weaker one.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-692790")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2026")])]

#text("Dr Tao, In the first paragraph of the first section of Lindeberg’s method, “depend the choice” should be “depend on the choice.”")

#text("Also, can the Berry-Esséen theorem be proved using Lindeberg’s method? Or is it that you chose the Fourier-analytic approach to prove it because the theorem is not suitable for proof via Lindeberg approach?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-692795")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2026")])]

#text("Thanks for the correction.")

#text("A direct application of the Lindeberg method gives a weaker form of the Berry-Esseen theorem, in which the decay in the error term has a worse exponent, and more regularity is required on the test function, as compared against the Fourier analytic proofs. It is possible that one could work harder and make the Lindeberg approach more competitive with the Fourier analytic approach, but I doubt that it will match (or overtake) it completely.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-693169")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2026")])]

#text("I’ve been struggling with Exercise 9 (ii), I don’t know how Stirling’s formula comes into play. Could you give us a bit hint on Exercise 9 (ii)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-693184")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2026")])]

#text("Use part (i) and express the binomial coefficient in terms of factorials.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-694169")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2026")])]

#text("Dr Tao:")#linebreak()#text(" In the proof of (5) of Theorem 8, why is a telescoping series introduced?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/comment-page-2/#comment-694185")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2026")])]

#text("This is the heart of the exchange method: to approximate a statistic involving one set ")#mi("X_1,\\dots,X_n")#text(" of random variables by the corresponding statistic involving a different set ")#mi("Y_1,\\dots,Y_n")#text(" of random variables, replace the variables one at a time and track how much each individual swap changes the statistic. The telescoping identity merely records the fact that the total effect of performing all the swaps is simply the sum of the influence of each individual swap. (There is a technicality that the ordering in which one performs the swaps affects the precise shape of the intermediate terms; there are some variants of the exchange method in which one uses a random ordering which can be technically advantageous in some contexts.)")
]
]
