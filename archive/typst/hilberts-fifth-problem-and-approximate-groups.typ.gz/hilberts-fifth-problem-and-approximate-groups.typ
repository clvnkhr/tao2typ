// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/07/08/hilberts-fifth-problem-and-approximate-groups/
// Converted to Typst by tao2typ: "2026-10-14T15:19:06.677454+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Hilbert’s fifth problem and approximate groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Hilbert’s fifth problem and approximate groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 July 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/07/08/hilberts-fifth-problem-and-approximate-groups/")[#text("https://terrytao.wordpress.com/2014/07/08/hilberts-fifth-problem-and-approximate-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Due to some requests, I’m uploading to my blog ")#link("https://terrytao.wordpress.com/wp-content/uploads/2014/07/hilbert.pdf")[#text("the slides")]#text(" for my ")#link("http://www.icmat.es/rogers/ERCworkshop/abstracts_main_final.pdf")[#text("recent talk in Segovia")]#text(" (for the ")#link("http://www.icmat.es/rogers/ERCworkshop/")[#text("birthday conference of Michael Cowling")]#text(") on “")#link("https://terrytao.wordpress.com/wp-content/uploads/2014/07/hilbert.pdf")[#text("Hilbert’s fifth problem and approximate groups")]#text("“. The slides cover essentially the same range of topics in ")#link("https://terrytao.wordpress.com/category/teaching/254a-hilberts-fifth-problem/")[#text("this series of lecture notes")]#text(", or in ")#link("https://terrytao.wordpress.com/books/hilberts-fifth-problem-and-related-topics/")[#text("this text of mine")]#text(", though of course in considerably less detail, given that the slides are meant to be presented in an hour.")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03585354855f7d806941960764993efc57a445122797ac530c7c3c231a93ecc6-2df6dfb6b2a3bead700d7e6f9e2aa0a295e013a99afe594efdf0de27ec31e493.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2014/07/08/hilberts-fifth-problem-and-approximate-groups/comment-page-1/#comment-390042")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2014")])]

#text("Of the properties studied, the one least familiar to me is that of the $K-approximate group$ . Do you believe this property of symmetric subsets of a group merits further study? The chronology of this notion starts with Freiman, 1964. Were there pre-cursor concepts in additive combinatorics?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/08/hilberts-fifth-problem-and-approximate-groups/comment-page-1/#comment-390270")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2014")])]

#text("Prior to Freiman’s work, much of the work in additive combinatorics (which back then was generally known as additive number theory or combinatorial number theory) focused on forward sumset problems (e.g. trying to bound the size of sumsets ")#mi("A+B")#text(" for given sets ")#mi("A,B")#text(") rather than inverse sumset problems (trying to understand the structure of ")#mi("A,B")#text(" given information about the sumset ")#mi("A+B")#text("). Forward sumset problems have a very long history, e.g. the Cauchy-Davenport inequality goes back to the 19th century.")

#text("Approximate groups are related to other approximate algebraic structures, such as approximate homomorphisms, and show up a lot in modern arithmetic combinatorics; see for instance my book with Van Vu on the topic.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7683cffa6cda20a213aeb3b4fa057acb2bb93bb4db02bd317d28cdf84622bf39-034ed9d150f53faaa4cda00acaf2402f5415e1bf956d74e2a23f877c190f1dcd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ugeesana")]], [#link("https://terrytao.wordpress.com/2014/07/08/hilberts-fifth-problem-and-approximate-groups/comment-page-1/#comment-401860")[#strong[#text("ugeesana")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2014")])]

#text("Thank you for your sharing. Download the nice slides 🙂")
]
