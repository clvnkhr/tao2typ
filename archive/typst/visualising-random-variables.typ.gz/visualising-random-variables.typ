// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/
// Converted to Typst by tao2typ: "2026-10-14T16:37:55.334950+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Visualising random variables", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Visualising random variables")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 May 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/")[#text("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("When teaching mathematics, the traditional method of lecturing in front of a blackboard is still hard to improve upon, despite all the advances in modern technology. However, there are some nice things one can do in an electronic medium, such as this blog. Here, I would like to experiment with the ability to animate images, which I think can convey some mathematical concepts in ways that cannot be easily replicated by traditional static text and images. Given that many readers may find these animations annoying, I am placing the rest of the post below the fold.")

#metadata(none) <tao-4f56741a0691440a5ae5>

#text("Suppose we are in the classical (")#link("https://en.wikipedia.org/wiki/Probability_axioms")[#text("Kolmogorov")]#text(") framework of probability theory, in which one has a probability space ")#mi("(\\Omega, {\\mathcal F}, {\\mathbb P})")#text(" representing all possible states ")#mi("\\omega \\in \\Omega")#text(". One can make a distinction between ")#emph[#text("deterministic")]#text(" quantities ")#mi("x")#text(" that do not depend on the state ")#mi("\\omega")#text(", and ")#emph[#text("random")]#text(" variables (or stochastic variables) ")#mi("X = X(\\omega)")#text(" that do depend (in some measurable fashion) on the state ")#mi("\\omega")#text(". (As discussed in ")#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/")[#text("this previous post")]#text(", it is often helpful to adopt a perspective that suppresses the sample space ")#mi("\\Omega")#text(" as much as possible, but we will not do so for the current discussion.)")

#text("One can visualise the distinction as follows. If I pick a deterministic integer ")#mi("x")#text(" between ")#mi("1")#text(" and ")#mi("6")#text(", say ")#mi("3")#text(", then this fixes the value of ")#mi("x")#text(" for the rest of the discussion:")

#align(center)[#mi("x=3")#text(".")]

#text("However, if I pick a ")#emph[#text("random")]#text(" integer ")#mi("X")#text(" uniformly from ")#mi("\\{1,\\dots,6\\}")#text(" (e.g. by rolling a fair die), one can think of ")#mi("X")#text(" as a quantity that keeps changing as one flips from one state to the next:")

#align(center)[#image("../assets/11c780f7e4951f64b45ddbbc89d108d18327b25cd73b9f6da03a2d75b2f7b353-447eb724c91ea54ddb6f2ea8cc0aefcef13425b87595daaa06e3383c05abcf63.gif", width: 90%, alt: "aflip.gif")#text(".")]

#text("Here, I have “faked” the randomness by looping together a finite number of images, each of which is depicting one of the possible values ")#mi("X")#text(" could take. As such, one may notice that the above image eventually repeats in an endless loop. One could presumably write some more advanced code to render a more random-looking sequence of ")#mi("X")#text("‘s, but the above imperfect rendering should hopefully suffice for the sake of illustration.")

#text("Here is a (“faked” rendering of a) random variable ")#mi("Y")#text(" that also takes values in ")#mi("\\{1,\\dots,6\\}")#text(", but is non-uniformly distributed, being more biased towards smaller values than larger values:")

#align(center)[#image("../assets/799f0c1e20bd0cf384fe9544e1c5301d9e1d2d30862d7de2c7ba9a89547af717-35b3ba08761d68118a1fa3ae99bbb4eff9e936f2f09f9e4c57231fee07a17126.gif", width: 90%, alt: "yflip")#text(".")]

#text("For continuous random variables, taking values for instance in ")#mi("{\\bf R}^2")#text(" with some distribution (e.g. uniform in a square, multivariate gaussian, etc.) one could display these random variables as a rapidly changing dot wandering over ")#mi("{\\bf R}^2")#text("; if one lets some “afterimages” of previous dots linger for some time on the screen, one can begin to see the probability density function emerge in the animation. This is unfortunately beyond my ability to quickly whip up as an image; but if someone with a bit more programming skill is willing to do so, I would be very happy to see the result :).")

#text("The operation of conditioning to an event corresponds to ignoring all states in the sample space outside of the event. For instance, if one takes the previous random variable ")#mi("X")#text(", and conditions to the event ")#mi("X > 3")#text(", one gets the conditioned random variable")

#align(center)[#image("../assets/fb7b9fffabd19963044af8172cfe8291b125e345ee2f6aa20c82dd52d1b76195-0bd7f68bfc40c9019cce39cc47f3e39c445d464e6c8a37f31bd63f6db5363a8c.gif", width: 90%, alt: "xcond2.gif")#text(".")]

#text("One can use the animation to help illustrate concepts such as independence or correlation. If we revert to the unconditioned random variable")

#image("../assets/11c780f7e4951f64b45ddbbc89d108d18327b25cd73b9f6da03a2d75b2f7b353-447eb724c91ea54ddb6f2ea8cc0aefcef13425b87595daaa06e3383c05abcf63.gif", width: 90%, alt: "aflip.gif")

#text("and let ")#mi("Z")#text(" be an independently sampled uniform random variable from ")#mi("\\{1,\\dots,6\\}")#text(", one can sum the variables together to create a new random variable ")#mi("X+Z")#text(", ranging in ")#mi("\\{2,\\dots,12\\}")#text(":")

#align(center)[#image("../assets/312bfd4af5a92fb79d566efb33b3d7d950c2795dc0a408870647058c86b55dea-fb085d3d41cb4e27dd48804db5269dae2f43fbdf109d9f841996d98641b2df3a.gif", width: 90%, alt: "xzsum")]

#text("(In principle, the above images should be synchronised, so that the value of ")#mi("X")#text(" stays the same from line to line at any given point in time. Unfortunately, due to internet lag, caching, and other web artefacts, you may experience an unpleasant delay between the two. Closing the page, clearing your cache and returning to the page may help.)")

#text("If on the other hand one defines the random variable ")#mi("Z^{\\prime}")#text(" to be ")#mi("Z^{\\prime} := 7-X")#text(", then ")#mi("Z^{\\prime}")#text(" has the same distribution as ")#mi("Z")#text(" (they are both uniformly distributed on ")#mi("\\{1,\\dots,6\\}")#text(", but now there is a very strong correlation between ")#mi("X")#text(" and ")#mi("Z^{\\prime}")#text(", leading to completely different behaviour for ")#mi("X+Z^{\\prime}")#text(":")

#align(center)[#image("../assets/81def83759573df2d2d361797c4694311f4904b9f66455bf51a66bd797209f62-2a92added93a2e1f81147b5e7ff46bb083cf8bc19cd27bb500788f047fcfa39e.gif", width: 90%, alt: "bnew")#text(".")]

#heading(level: 1)[#text("Comments (44)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/809e22dc05c377504f460ce5668561424c752de1fd5453a9a196b39bc75c9d1b-81925532da90a8263811473a0c76854977e708a4d9ab13bd766184a3f6f2eacb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of scottedwards2000")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468590")[#strong[#text("scottedwards2000")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2016")])]

#text("Nice!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468591")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2016")])]

#text("My opinion (It can be wrong of course, it’s just how I see it, I don’t want to argue): I always thought that it was a waste for the professor to write so much on the blackboard when he could have just show PowerPoint slides. Students copying things on notepads is a practice from the times of the Jesuits, when people had no books! Come on, we are on the age of the Internet, the professor should just put the class notes as PDF files for students to download and use the class to explain things, ask students questions, ask students to try to solve problems and explain to the other students, etc… These are some of the things that one can not get by just studying the book at home. The professor writing on the blackboard and the students just copying, not even putting any effort to follow what is being said, is a waste of their and the professor’s time! Just my opinion of course. The “best class possible” varies from student to student, but from my experience, albeit modest, the best students like to have to THINK during class. Please, I do not want to sound arrogant, I know very little about mathematics and teaching, it’s just my opinion, I do not want to argue.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468592")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2016")])]

#text("Thank you for your comments. I’m a teacher myself, and I appreciate hearing different opinions on teaching, particularly from students.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468593")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2016")])]

#text("This visualization seems to be precise (for finitely or countably many states ")#mi("\\omega")#text(") by representing (i.e. modeling) each state ")#mi("\\omega")#text(" as a certain (corresponding) discrete time ")#mi("t")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ecd3505053e823752e133e50092b53322e52a28b1566e42b351cf4683bb37b5-71206d714602e6fa76e941616865d1b5606cc72b044287d8e45e6f273d56bfc0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.P. McCarthy")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468605")[#strong[#text("J.P. McCarthy")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2016")])]

#link("http://mathoverflow.net/questions/80056/using-slides-in-math-classroom/80551#80551")[#text("http://mathoverflow.net/questions/80056/using-slides-in-math-classroom/80551#80551")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e5296b75242012daa1e4d627b7cd5b01010b81d8468fd8fd06c48e351fbb369-b7abc69797d36ef2864be9866590a1d776a5f3c1a4d9dc44a1956eba8d7d4369.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Aldrich")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468615")[#strong[#text("Chris Aldrich")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2016")])]

#text("A lovely little experiment in visual pedagogy in mathematics! We could certainly use more of these types of simple “explorations” particularly for younger math students who may not always be good at visualizing material. These seem reminiscent to me of Wilson Rugh’s ")#link("http://pages.jh.edu/~signals/")[#text("java applets")]#text(" for digital signal processing years ago.")

#text("Some of this pedagogy argument about slides likely fits better into the area of the flipped classroom versus non-flipped. Though slides may be great (particularly if students have copies of them beforehand to take notes on as is often done commercially by many biology textbooks which have 2-4 slides down the left side of the page and note space on the right hand side) for mathematics I much prefer having notes in ")#link("http://refer.livescribe.com/a/clk/2G3Md")[#text("Livescribe")]#text(" .pdf format with embedded audio. This allows a student to not only relisten to the entire lecture, where often a lot of complicated material (especially in higher level abstract courses) is said very quickly and isn’t able to be written down even by some of the best transcriptionists with shorthand (and how many students know this anymore?), but they can skip around to parts they need more work on. As an example, download this ")#link("https://www.dropbox.com/s/7g4rekbuzzr8nfz/Lie%20Groups-Lecture%203.pdf?dl=0")[#text(".pdf file from a Lie Groups lecture")]#text(" and open it up in the most recent version of Adobe Reader to be able to see the visual and audio functionality.")

#text("The particular value often comes in seeing problems worked out in full detail with discussion, which some students need much more of than others. One of my favorite lecture experiences almost a decade ago was hearing an audible gasp from the classroom of undergraduates when Sol Golomb (USC) stopped in the middle of a complicated lecture on combinatorics and worked out a 4th grade simple long division problem on the board to get a final solution. Half the class had pulled out a calculator to get the answer and he’d finished before most of them had the first number input. The class learned more in that one minute of example than most did the entire lecture. Most of the best math is done in the “exploration” and practice than in a stripped down lecture as is highlighted in Ben Orlin’s recent post: ")#link("https://mathwithbaddrawings.com/2016/05/04/the-essence-of-mathematics-in-one-beatles-song/")[#text("The Essence of Mathematics")]#text(". While it’s always lovely seeing theoretical mathematics as if it seemingly sprang fully formed from the head of Zeus, many students should see how the proverbial sausage (or laws) are actually made, especially at an earlier age.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd83ab57967ccfe2fec3a7390f8ee470a99d34703c8a83778c9a2dff057d0298-fd0b212ab9166c7049cdb64effce4a7b0cb415ba88a6226266fd2fd598d74fd0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Davetweed")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468635")[#strong[#text("Davetweed")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2016")])]

#text("Regarding just downloading slide content, there is research in teaching that shows that doing some writing in general improves student understanding compared just to listening knowing the notes will be available later. I’ve known lecturers who take advantage of this while not requiring copying of everything by providing handouts of the lecture slides before the lecture with some key bits missing on each page. To get complete notes that u have to be following and occasionally fill in the blanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468834")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2016")])]

#text("Learning math is not about collecting information, so I do not understand the comment about the sufficiency of slides. As far as I can understand, lectures came about mostly because of lack of resources which necessitated bigger and bigger classes, but the ideal way of learning anything is via conversations. Learning and teaching rarely should be a one directional communication from profs to students: profs, teachers should and will learn from students as well.")

#text("Even in a traditional lecture, using slides is a mistake. Even during a lecture, students should be welcome to ask questions, make comments, and as a result, the lesson plan could and should change. Slides won’t adjust well to this dynamically changing environment.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17afae9cbc0bc3392378424fe8fbffa529de592248138cdda72c84d8ae4c1d27-0abc0ecfa7553c93ee2e3743118745015b69186b71c67c1fba3478aae0b04ab7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rahul")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468594")[#strong[#text("Rahul")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2016")])]

#text("Regarding the animation, was something like this what you had in mind?")

#link("http://i.imgur.com/tI5uWZf.gifv")[#text("http://i.imgur.com/tI5uWZf.gifv")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468610")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2016")])]

#text("Yes, these are exactly what I had in mind! (Well, I had envisioned the afterimages fading a little bit as time proceeds, but you’ve still managed to make it so that the present image is the darkest and the oldest images are the lightest, so it still pretty much matches what I was imagining.) Thanks!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17afae9cbc0bc3392378424fe8fbffa529de592248138cdda72c84d8ae4c1d27-0abc0ecfa7553c93ee2e3743118745015b69186b71c67c1fba3478aae0b04ab7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rahul")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468596")[#strong[#text("Rahul")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2016")])]

#text("Another attempt at an animation. Uniform in a circle.")

#link("http://i.imgur.com/3m0PQig.gifv")[#text("http://i.imgur.com/3m0PQig.gifv")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf439e996e29d20cb552d68ffe9f964d8919f4f9773b9c41c886fb326a5a9695-66573747b7b50dc2532a1c1acd7e23c9482f9aeb4a00f437399c08ade2278ee3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aquazorcarson")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-469056")[#strong[#text("aquazorcarson")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2016")])]

#text("You mean a disk, not a circle.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17afae9cbc0bc3392378424fe8fbffa529de592248138cdda72c84d8ae4c1d27-0abc0ecfa7553c93ee2e3743118745015b69186b71c67c1fba3478aae0b04ab7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rahul")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468607")[#strong[#text("Rahul")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2016")])]

#link("http://i.imgur.com/hmK4S8j.gifv")[#text("http://i.imgur.com/hmK4S8j.gifv")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f802b189f2e8646de5053e3406f853f04ff4c4cee67c9c908e182a407337c154-f2afbb3ead3d9afe13201da98851ae03170a8aecccd0fd632f5087b04e3d358b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468609")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2016")])]

#text("@Rahul – is there any chance you could put up an example for a bivariate normal with a correlation of say 0.75? I would love to show this collection of animations to students in an intro Stats class.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17afae9cbc0bc3392378424fe8fbffa529de592248138cdda72c84d8ae4c1d27-0abc0ecfa7553c93ee2e3743118745015b69186b71c67c1fba3478aae0b04ab7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rahul")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468611")[#strong[#text("Rahul")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2016")])]

#text("@Michael: Sure. I’ll try to post one in a bit.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17afae9cbc0bc3392378424fe8fbffa529de592248138cdda72c84d8ae4c1d27-0abc0ecfa7553c93ee2e3743118745015b69186b71c67c1fba3478aae0b04ab7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rahul")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468612")[#strong[#text("Rahul")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2016")])]

#text("@Michael:")

#text("Here’s a try. Not sure if this is what you had in mind? Not sure. To be honest, my knowledge of Stat is pretty basic.")

#link("http://i.imgur.com/s6IMhOR.gifv")[#text("http://i.imgur.com/s6IMhOR.gifv")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f802b189f2e8646de5053e3406f853f04ff4c4cee67c9c908e182a407337c154-f2afbb3ead3d9afe13201da98851ae03170a8aecccd0fd632f5087b04e3d358b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468616")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2016")])]

#text("@Rahul – Yes! Thank you very much! This looks great! I hope you do not mind me showing a link directly to this in class.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17afae9cbc0bc3392378424fe8fbffa529de592248138cdda72c84d8ae4c1d27-0abc0ecfa7553c93ee2e3743118745015b69186b71c67c1fba3478aae0b04ab7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rahul")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468617")[#strong[#text("Rahul")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2016")])]

#text("@Michael")

#text("Glad I could help!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f802b189f2e8646de5053e3406f853f04ff4c4cee67c9c908e182a407337c154-f2afbb3ead3d9afe13201da98851ae03170a8aecccd0fd632f5087b04e3d358b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468618")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2016")])]

#text("@Rahul – can I ask what you used to create these? It looks like GGPlot in R and I am guessing here, but did you use a for() or an sapply() for successive plots dumping each out to a pdf and then some gif creator to put pauses between plots?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17afae9cbc0bc3392378424fe8fbffa529de592248138cdda72c84d8ae4c1d27-0abc0ecfa7553c93ee2e3743118745015b69186b71c67c1fba3478aae0b04ab7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rahul")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468621")[#strong[#text("Rahul")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2016")])]

#text("@Michael")

#text("Yep. Almost exactly like you said. I used for(). No pdf. Used ggsave() to create a gif.")

#text("ImageMagic to combine the gifs into an agif.")

#text("It can probably be done better and faster. But I’m no R expert and it took me more than an hour to get it all figured out.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b2176960add4d9aae63113ce0e0db74c53f91e5748d18bada1f77d55bd0dd65-b9bdf249b0ad71300c995ec8cca76b0d53d3474b2a6cc4241a1b31eebd2253e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Onur Savas")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468608")[#strong[#text("Onur Savas")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2016")])]

#text("I see the last sum (x + z’) be equal to 5 once in a while. Is it just me? I assume there is some of race condition happening during computation.")

#emph[#text("[Oops, that was a manual typo. I’ve fixed it, although due to caching this may cause some loss of synchronisation in the images that may require one to clear one’s local cache to resolve -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c988dc5aeac7cbcfa8f4f366d2ed8af4074aa7131b2cc6401846be58b5af5441-74ff5027811a3fbcd41bd7a43cfc64952d56b368f1f39d51ae9b390c924a930e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Smith")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468614")[#strong[#text("James Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2016")])]

#text("Ha! Funny, I had a conversation with one of my tutees the other day about the problems of envisioning random variables as opposed conventional ones. Specifically the fact that conventional variables are assigned a single value, albeit a variable one of course, whereas random variables you could say are assigned a set or sequence of values although even that doesn’t seem to quite hit the mark. Then the fact that you can still do algebraic manipulations with random variables despite the right hand sides of their assignments seeming somewhat ill defined. Say “roll a dice and multiply it by two”, for example, to get another random variable. I think your animations come as a good stab at this murky subject, at least murky when you try to explain it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/927132ae87ac5d8451e190b76d3713958b51371387bc2bfcbefee7cecdbec47b-01ef04b5ef1b58a71fbe0cc8f3b459639a6650f6e3bd441f92d2281551b7dd30.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Baptiste Auguie")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468622")[#strong[#text("Baptiste Auguie")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2016")])]

#text("You may be interested to see the efforts of Bret Victor as part of his “KillMath” project (not as contentious as it may sound!). On the technical aspect, he’s refined the user interface to provide truly interactive documents, which I think would be a great framework to pursue your ideas further. There’s also a pedagogical angle to this, as he shares some unique reflections on alternative, more visual and “user-oriented” interfaces to mathematical concepts, enabled by modern web technologies. ")#link("http://worrydream.com/ExplorableExplanations/")[#text("http://worrydream.com/ExplorableExplanations/")]#text(" is a good illustration.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a0a8c0e56e2a07f4142095d09c41084d451048d9a72293520cc524bc1e1509-8715a515aca0b6aa69b1cc21700d65376d2d18dec643368e3a2d3e6576e6b834.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron Sheldon")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468671")[#strong[#text("Aaron Sheldon")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2016")])]

#text("Have you considered incorporating Jupyter notebooks into your lessons?")

#link("http://jupyter.org/")[#text("http://jupyter.org/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebd5593da0b8c869db01124b5f4a9a9b6a18f90c6b4a52d929a7b4f24466c885-b2841deb978a98abfda0f77ee07832e3d6f2a199f492398dc6cdb9922460fa13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Diego")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468676")[#strong[#text("Diego")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2016")])]

#text("I can also recommend this. I’ve been using it to teach and interactively show plots and the students enjoy it very much")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5381d44cc04d2d482c6700f956bd467a1f590bda95d1ebb8723dd0bf77b2fdd-80a958f616b833264693ad17dcbcb25a4a116822258b0a7d2c061000ff428366.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468685")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2016")])]

#text("This is incredible. I currently am doing the second year maths undergrad program at University of St. Andrews and I had a tough time this year learning statistics. One of my biggest conceptual challenges was understanding a random variable and what a PDF/PMF actually meant. It was only in my second term, 1/2 way through learning about Confidence Intervals did I have any idea what was being discussed. The most helpful part of the course was learning R and producing graphs and visuals. I feel if more statistics classes used visuals like above, students would have a better intuition of what was happening.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468725")[#strong[#text("1 – Visualising random variables")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")]

#text("[…] Source:")#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/")[#text("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f226673c3ba4a44d5cf28f96a8de34b8a09ab91685886b70a71bca702000dc95-696cc3c0b28816cebbb2fbf79c595c8142258f4b14bc9caa8b3a9082c13d5832.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jessica Hullman")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468754")[#strong[#text("Jessica Hullman")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("I’m a visualization researcher who has been studying how people understanding distributions through (visualized) hypothetical outcomes for a few years now. We call them hypothetical outcome plots, or HOPs, and have shown how people can interpret plots of two quantities better than they can a pair of error bars or other visual representations of a pdf like violin plots. We’ve written a blog post here: ")#link("https://goo.gl/eORypw")[#text("https://goo.gl/eORypw")]#text(", and you can find more materials here: ")#link("http://idl.cs.washington.edu/papers/hops")[#text("http://idl.cs.washington.edu/papers/hops")]#text(". I also just gave a talk at OpenVis 2016 on the same basic idea: ")#link("https://www.youtube.com/watch?v=pTVAn4oLvbc")[#text("https://www.youtube.com/watch?v=pTVAn4oLvbc")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81c7ee47219767de6af71eb6b5313e9894d7c3914be6d57431ae7e1b00c157a1-a1e079dc8e5844fbe1b13fa79adf07f02d1892bfbe1b6c1e95a39cc933de0cdd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vznvzn")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468868")[#strong[#text("vznvzn")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2016")])]

#text("nice topic, think that scientific visualizations are sometimes somewhat underutilized. is there a ted talk on this? there should be. reminds me of edward tufte who made nearly a career out of this topic, but not nec with newer technology. wish that tufte or a accolyte would revise his theory to the computer age. its a growing field. eg last comment by a “visualization researcher”. anyway the area of algorithm teaching has a lot of visualization possibilities that imho are still largely unexplored, lots of low hanging fruit. the classic example is sorting algorithms. some inquiry into all this in my “code” section on blog although its quite scattered right now. anyway keep up the good work. :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MatjazG")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468889")[#strong[#text("MatjazG")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2016")])]

#text("Your inquiry led me to a search around YouTube for a bit and I indeed found a very nice TEDx talk on scientific visualization: ")#link("https://www.youtube.com/watch?v=Sua0xDCf8MA")[#text("https://www.youtube.com/watch?v=Sua0xDCf8MA")]#text(". Highly recommended :)")

#text("About sorting algorithms, though: those have had nice visualizations on Wikipedia for a very long time. E.g. I just checked and the animated visualization of ")#link("https://en.wikipedia.org/wiki/Quicksort")[#text("Quicksort")]#text(" has been unchanged for 10 years now. Similarly for the ")#link("https://en.wikipedia.org/wiki/Dijkstra's_algorithm")[#text("Dijsktra’s")]#text(" and the ")#link("https://en.wikipedia.org/wiki/A*_search_algorithm")[#text("A*")]#text(" search algorithms, which have had animated visualizations on Wikipedia for at least 5 years. I agree, though, that a nice visualization makes things so much cleared and more intuitive. Which algorithms would you like to see visualized?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81c7ee47219767de6af71eb6b5313e9894d7c3914be6d57431ae7e1b00c157a1-a1e079dc8e5844fbe1b13fa79adf07f02d1892bfbe1b6c1e95a39cc933de0cdd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vznvzn")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468906")[#strong[#text("vznvzn")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2016")])]

#text("forgot to mention, there is ongoing/ active research in many visualization areas eg number theory, one of my personal favorites, wrt collatz, but Riemann has been visualized a lot also & continues to crosspollinate conventional/ technical approaches. more on Collatz ")#link("https://vzn1.wordpress.com/code/collatz-conjecture-experiments/")[#text("https://vzn1.wordpress.com/code/collatz-conjecture-experiments/")]#text(" … btw one also wonders if greats of the field have special “internal” visualization powers … eg Ramanujan etc … see my blog for pointers to great latest movie on him :)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468918")[#strong[#text("Visualising random variables, Terence Tao style « Probability and statistics blog")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2016")]

#text("[…] mathematician Terence Tao posted some ruminations on how to visualize the different values a random variable could take. He created some basic animated loops that cycled through some samples from the distribution, and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa1ff0e615a79aef04cf6e389c5a9213bfa79f2ab713d08aa9cef152f761bddb-228cd34d38fba65e51a4235b00dcaaee94dcdd4413fe640a9125ea1718a3a091.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of statisticsblogdotcom")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-468919")[#strong[#text("statisticsblogdotcom")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2016")])]

#text("I liked this idea so much I’ve added it to my probability distributions library:")

#link("http://statisticsblog.com/probability-distributions/#visualize")[#text("http://statisticsblog.com/probability-distributions/#visualize")]

#text("The values can be shown directly, or interpreted as waiting times where each arrival is shown with a flashing symbol. There are a number of options for how to display the animation and you suppress values that fall outside of a given range (conditionality).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-469058")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2016")])]

#text("What would be useful is to visualize/animate some basic statements in probability.")

#text("1) In case of a random walk, the distance from the expectation is about the square root of the number of steps.")

#text("2) In case of random walk, the distribution of the various values, properly normalized, approaches the Gaussian.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-469068")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2016")])]

#text("Well, the Galton box is a well known demonstration of both (1) and (2), and has often been animated in the past, e.g. ")#link("https://rosettacode.org/wiki/Galton_box_animation")[#text("https://rosettacode.org/wiki/Galton_box_animation")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-470275")[#strong[#text("Visualising random variables, Terence Tao style | A bunch of data")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2016")]

#text("[…] mathematician Terence Tao posted some ruminations on how to visualize the different values a random variable could take. He created some basic animated loops that cycled through some samples from the distribution, and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8621fb593c5007eb1ef8f6a30efbd5b57570c68c408c2585eeb34179b8ce3ad0-d1e560a508ebb0c230b96c71178cc8dd2043b39877f0338001c0fbbd9156fcb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of davidwlocke")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-473334")[#strong[#text("davidwlocke")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2016")])]

#text("Random variables are distributions. Deterministic variables are single numbers. I don’t see how a series displayed one at a time enables me to visualize the underlying distribution. Both could be shown in a single graphic. The deterministic variable would be represented by a vertical line somewhere in the distribution.")

#text("In a Poisson distribution, the deterministic variable would appear as a single and only bar in a histogram. Constraints on either side of that bar would eliminate the rest of the distribution.")

#text("If you still wanted to show each value as it was “measured” build the distribution as each value arrives. Use nominal events to build more complex events. Put the nominal RV1 value in its distribution. Then, build the aggregated event (RV2) putting that value in its own distribution.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-476503")[#strong[#text("De la Statistique Descriptive à la Statistique Mathématique | A bunch of data")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2017")]

#text("[…] des majuscules (correspondant aux variables aléatoires sous-jacentes). Il y a quelques mois, Terry Tao suggérait d’aller un cran plus loin, en notant qu’une variable aléatoire était justement […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f1635561789e5ee7c76c57da6383367095a82d35dbd0d495e767af0ce19359b-7db524b855ba8c0aacec652baae9ce673431d440b23cd22621dc39afdaa6b32e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andres Matos")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-512146")[#strong[#text("Andres Matos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2019")])]

#text("This sounds like a basis of nudge theory; at the very least, it reminds me of it. I am still new at this so correct me if I am wrong. Here is how I see it: The Z’=7-X is the nudge creating that strong correlation between X and Z’ leading to the expected behavior, or at least an increased chance of it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-650127")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2022")])]

#text("Reblogged this on ")#link("https://scoutmathematics.wordpress.com/2022/07/27/visualising-random-variables/")[#text("Aditya Guha Roy's weblog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-689369")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2025")])]

#text("Dr. Tao,")

#text("I found a typo: Here is a (“faked” rendering of) a random variable—— I think you can delete one “a”.")

#text("I am confused about some concepts and I asked about AI, they cannot make things clear. Could you please clarify these doubts for me?")

#text("(a) You said that we can visualize continuous random variables taking values with a probability distribution as rapidly changing dots, and the accumulation of its lingering afterimages reveals PDF—— Does visualizing a probability distribution simply equate to visualizing its PDF? I am confused about the relationship between a probability distribution and its PDF.")

#text("(b) Also, how to visualize other probabilistic concepts, such as Moments?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-689417")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2025")])]

#text("Could you please take some time to clarify the problems? I have been struggling with them.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A random variable visualizer | What's new")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-693324")[#strong[#text("A random variable visualizer | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2026")])]

#text("[…] projects, but I did spend a few hours this weekend on one such project, namely the proposal from this 2016 blog post to visualize random variables as animated quantities, which can be either viewed numerically or […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/#comment-693348")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2026")])]

#text("It might seem somewhat distant, but this and your textbook concerning Hilbert’s Fifth Problem (in which I learned the Gleason-Yamabe theorem) remind me of an area in probability which may have similarly been enabled by computers:")

#text("It is the combination of the Nash-Tognoli theorem concerning embeddings of smooth real manifolds into real projective space as smooth real projective varieties with the so-called Kostlan ensemble on homogeneous degree d polynomials.")

#text("Together, these produce a controlled parameter space of distributions on the countable set of smooth real compact manifolds. There are different parameter spaces based on whether one chooses each polynomial to be of maximal degree d or sampling from homogeneous polynomials of random degree.")

#text("While this is a relatively known concept in random algebraic geometry, it is very much a topic open to projects. I began one by producing in Sage math a random homogeneous polynomial generator. The first obstacle was to create a function which held a (random) Gaussian vector in a separate array with respect to the coefficients of the Kostlan ensemble (which feature choose-n coefficients and are unique with special symmetry properties involving two different O(n)-actions).")

#text("It’s of course exciting for the visuals, but I never made it to that stage. I imagine that many visuals would become available after the development of an atlas finding algorithm (and I think this is a very interesting source of numerical input for it since literally any sequence of homogeneous degree $d_i$ polynomials can be used as input).")
]
