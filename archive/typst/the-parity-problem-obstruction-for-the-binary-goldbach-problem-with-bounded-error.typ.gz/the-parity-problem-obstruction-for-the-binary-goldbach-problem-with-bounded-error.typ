// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/
// Converted to Typst by tao2typ: "2026-10-14T15:19:08.080386+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The parity problem obstruction for the binary Goldbach problem with bounded error", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The parity problem obstruction for the binary Goldbach problem with bounded error")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 July 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/")[#text("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Two of the most famous open problems in additive prime number theory are the ")#link("http://en.wikipedia.org/wiki/Twin_prime")[#text("twin prime conjecture")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Goldbach_conjecture")[#text("binary Goldbach conjecture")]#text(". They have quite similar forms:")

#list(
[#strong[#text("Twin prime conjecture")]#text(" The equation ")#mi("{p_1 - p_2 = 2}")#text(" has infinitely many solutions with ")#mi("{p_1,p_2}")#text(" prime.")],
[#strong[#text("Binary Goldbach conjecture")]#text(" The equation ")#mi("{p_1 + p_2 = N}")#text(" has at least one solution with ")#mi("{p_1,p_2}")#text(" prime for any given even ")#mi("{N \\geq 4}")#text(".")]
)

#text("In view of this similarity, it is not surprising that the partial progress on these two conjectures have tracked each other fairly closely; the twin prime conjecture is generally considered slightly easier than the binary Goldbach conjecture, but broadly speaking any progress made on one of the conjectures has also led to a comparable amount of progress on the other. (For instance, ")#link("http://en.wikipedia.org/wiki/Chen%27s_theorem")[#text("Chen’s theorem")]#text(" has a version for the twin prime conjecture, and a version for the binary Goldbach conjecture.) Also, the notorious ")#link("http://en.wikipedia.org/wiki/Parity_problem_(sieve_theory)")[#text("parity obstruction")]#text(" is present in both problems, preventing a solution to either conjecture by almost all known methods (see ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("this previous blog post")]#text(" for more discussion).")

#text("In this post, I would like to note a divergence from this general principle, with regards to bounded error versions of these two conjectures:")

#list(
[#strong[#text("Twin prime with bounded error")]#text(" The inequalities ")#mi("{0 < p_1 - p_2 < H}")#text(" has infinitely many solutions with ")#mi("{p_1,p_2}")#text(" prime for some absolute constant ")#mi("{H}")#text(".")],
[#strong[#text("Binary Goldbach with bounded error")]#text(" The inequalities ")#mi("{N \\leq p_1+p_2 \\leq N+H}")#text(" has at least one solution with ")#mi("{p_1,p_2}")#text(" prime for any sufficiently large ")#mi("{N}")#text(" and some absolute constant ")#mi("{H}")#text(".")]
)

#text("The first of these statements is now a well-known ")#link("http://annals.math.princeton.edu/2014/179-3/p07")[#text("theorem of Zhang")]#text(", and the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8b project")]#text(" hosted on this blog has managed to lower ")#mi("{H}")#text(" to ")#mi("{H=246}")#text(" unconditionally, and to ")#mi("{H=6}")#text(" assuming the generalised ")#link("http://en.wikipedia.org/wiki/Elliott-Halberstam_conjecture")[#text("Elliott-Halberstam conjecture")]#text(". However, the second statement remains open; the best result that the Polymath8b project could manage in this direction is that (assuming GEH) at least one of the binary Goldbach conjecture with bounded error, or the twin prime conjecture with no error, had to be true.")

#text("All the known proofs of Zhang’s theorem proceed through sieve-theoretic means. Basically, they take as input equidistribution results that control the size of discrepancies such as ")#metadata(none) <tao-6bf99799d0ef91be6c25>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\Delta(f; a\\ (q)) := \\sum_{x \\leq n \\leq 2x; n=a\\ (q)} f(n) - \\frac{1}{\\phi(q)} \\sum_{x \\leq n \\leq 2x} f(n)")]]

#text("for various congruence classes ")#mi("{a\\ (q)}")#text(" and various arithmetic functions ")#mi("{f}")#text(", e.g. ")#mi("{f(n) = \\Lambda(n+h_i)}")#text(" (or more generaly ")#mi("{f(n) = \\alpha * \\beta(n+h_i)}")#text(" for various ")#mi("{\\alpha,\\beta}")#text("). After taking some carefully chosen linear combinations of these discrepancies, and using the trivial positivity lower bound ")#metadata(none) <tao-3312cefd1c8ed98fd620>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("a_n \\geq 0 \\text{ for all } n \\implies \\sum_n a_n \\geq 0")]]

#text("one eventually obtains (for suitable ")#mi("{H}")#text(") a non-trivial lower bound of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq 2x} \\nu(n) 1_A(n) > 0")]]

#text("where ")#mi("{\\nu}")#text(" is some weight function, and ")#mi("{A}")#text(" is the set of ")#mi("{n}")#text(" such that there are at least two primes in the interval ")#mi("{[n,n+H]}")#text(". This implies at least one solution to the inequalities ")#mi("{0 < p_1 - p_2 < H}")#text(" with ")#mi("{p_1,p_2 \\sim x}")#text(", and Zhang’s theorem follows.")

#text("In a similar vein, one could hope to use bounds on discrepancies such as ")#link(<tao-6bf99799d0ef91be6c25>)[#text("(1)")]#text(" (for ")#mi("{x}")#text(" comparable to ")#mi("{N}")#text("), together with the trivial lower bound ")#link(<tao-3312cefd1c8ed98fd620>)[#text("(2)")]#text(", to obtain (for sufficiently large ")#mi("{N}")#text(", and suitable ")#mi("{H}")#text(") a non-trivial lower bound of the form ")#metadata(none) <tao-b3ccc698ef6302ee332a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{n \\leq N} \\nu(n) 1_B(n) > 0")]]

#text("for some weight function ")#mi("{\\nu}")#text(", where ")#mi("{B}")#text(" is the set of ")#mi("{n}")#text(" such that there is at least one prime in each of the intervals ")#mi("{[n,n+H]}")#text(" and ")#mi("{[N-n-H,n]}")#text(". This would imply the binary Goldbach conjecture with bounded error.")

#text("However, the parity obstruction blocks such a strategy from working (for much the same reason that it blocks any bound of the form ")#mi("{H \\leq 4}")#text(" in Zhang’s theorem, as discussed in ")#link("https://www.dropbox.com/sh/0xb4xrsx4qmua7u/AAARQElGfSZFErLIZy9qPM-Aa/Polymath8b/newergap.pdf")[#text("the Polymath8b paper")]#text(".) The reason is as follows. The sieve-theoretic arguments are linear with respect to the ")#mi("{n}")#text(" summation, and as such, any such sieve-theoretic argument would automatically also work in a weighted setting in which the ")#mi("{n}")#text(" summation is weighted by some non-negative weight ")#mi("{\\omega(n) \\geq 0}")#text(". More precisely, if one could control the weighted discrepancies")

#align(center)[#tao-fit-display[#mitex("\\Delta(f\\omega; a\\ (q)) = \\sum_{x \\leq n \\leq 2x; n=a\\ (q)} f(n) \\omega(n) - \\frac{1}{\\phi(q)} \\sum_{x \\leq n \\leq 2x} f(n) \\omega(n)")]]

#text("to essentially the same accuracy as the unweighted discrepancies ")#link(<tao-6bf99799d0ef91be6c25>)[#text("(1)")]#text(", then thanks to the trivial weighted version")

#align(center)[#tao-fit-display[#mitex("a_n \\geq 0 \\text{ for all } n \\implies \\sum_n a_n \\omega(n) \\geq 0")]]

#text("of ")#link(<tao-3312cefd1c8ed98fd620>)[#text("(2)")]#text(", any sieve-theoretic argument that was capable of proving ")#link(<tao-b3ccc698ef6302ee332a>)[#text("(3)")]#text(" would also be capable of proving the weighted estimate ")#metadata(none) <tao-5d9a1d4cfa2828d1471a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{n \\leq N} \\nu(n) 1_B(n) \\omega(n) > 0.")]]

#text("However, ")#link(<tao-5d9a1d4cfa2828d1471a>)[#text("(4)")]#text(" may be defeated by a suitable choice of weight ")#mi("{\\omega}")#text(", namely")

#align(center)[#tao-fit-display[#mitex("\\omega(n) := \\prod_{i=1}^H (1 + \\lambda(n) \\lambda(n+i)) \\times \\prod_{j=0}^H (1 - \\lambda(n) \\lambda(N-n-j))")]]

#text("where ")#mi("{n \\mapsto \\lambda(n)}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Liouville_function")[#text("Liouville function")]#text(", which counts the parity of the number of prime factors of a given number ")#mi("{n}")#text(". Since ")#mi("{\\lambda(n)^2 = 1}")#text(", one can expand out ")#mi("{\\omega(n)}")#text(" as the sum of ")#mi("{1}")#text(" and a finite number of other terms, each of which consists of the product of two or more translates (or reflections) of ")#mi("{\\lambda}")#text(". But from the Möbius randomness principle (or its analogue for the Liouville function), such products of ")#mi("{\\lambda}")#text(" are widely expected to be essentially orthogonal to any arithmetic function ")#mi("{f(n)}")#text(" that is arising from a single multiplicative function such as ")#mi("{\\Lambda}")#text(", even on very short arithmetic progressions. As such, replacing ")#mi("{1}")#text(" by ")#mi("{\\omega(n)}")#text(" in ")#link(<tao-6bf99799d0ef91be6c25>)[#text("(1)")]#text(" should have a negligible effect on the discrepancy. On the other hand, in order for ")#mi("{\\omega(n)}")#text(" to be non-zero, ")#mi("{\\lambda(n+i)}")#text(" has to have the same sign as ")#mi("{\\lambda(n)}")#text(" and hence the opposite sign to ")#mi("{\\lambda(N-n-j)}")#text(" cannot simultaneously be prime for any ")#mi("{0 \\leq i,j \\leq H}")#text(", and so ")#mi("{1_B(n) \\omega(n)}")#text(" vanishes identically, contradicting ")#link(<tao-5d9a1d4cfa2828d1471a>)[#text("(4)")]#text(". This indirectly rules out any modification of the Goldston-Pintz-Yildirim/Zhang method for establishing the binary Goldbach conjecture with bounded error.")

#text("The above argument is not watertight, and one could envisage some ways around this problem. One of them is that the Möbius randomness principle could simply be false, in which case the parity obstruction vanishes. A good example of this is the ")#link("http://www.ams.org/mathscinet-getitem?mr=703977")[#text("result of Heath-Brown")]#text(" that shows that if there are infinitely many Siegel zeroes (which is a strong violation of the Möbius randomness principle), then the twin prime conjecture holds. Another way around the obstruction is to start controlling the discrepancy ")#link(<tao-6bf99799d0ef91be6c25>)[#text("(1)")]#text(" for functions ")#mi("{f}")#text(" that are combinations of more than one multiplicative function, e.g. ")#mi("{f(n) = \\Lambda(n) \\Lambda(n+2)}")#text(". However, controlling such functions looks to be at least as difficult as the twin prime conjecture (which is morally equivalent to obtaining non-trivial lower-bounds for ")#mi("{\\sum_{x \\leq n \\leq 2x} \\Lambda(n) \\Lambda(n+2)}")#text("). A third option is not to use a sieve-theoretic argument, but to try a different method (e.g. the circle method). However, most other known methods also exhibit linearity in the “")#mi("{n}")#text("” variable and I would suspect they would be vulnerable to a similar obstruction. (In any case, the circle method specifically has some other difficulties in tackling binary problems, as discussed in ")#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/")[#text("this previous post")]#text(".)")

#heading(level: 1)[#text("Comments (34)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e1b85380f7185fcf770eb96588054b4a40ad85417fe30014bd6010cde3bff85-aa6cb67c56a93df5b5262485641b606372bd9140d97a5ed49791dbb527c6000b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stijn Hanson")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-391360")[#strong[#text("Stijn Hanson")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2014")])]

#text("Really interesting article. What current evidence is there for the randomness of the Möbius function? I.e. is there anything which would lead us to believe that the Möbius randomness principle should fail?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-391859")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2014")])]

#text("We have a number of results that assert that ")#mi("\\sum_n \\mu(n) f(n)")#text(" exhibits non-trivial cancellation for many reasonable functions ")#mi("f")#text("; see e.g. this ")#link("http://arxiv.org/abs/1406.7243")[#text("recent paper of Liu and Sarnak")]#text(" for some examples. We also have smallness of the Mobius function in the Gowers uniformity norms, thanks to the work of Ben Green, Tamar Ziegler, and myself (see ")#link("http://arxiv.org/abs/1009.3998")[#text("http://arxiv.org/abs/1009.3998")]#text(" ).")

#text("While we do not have any reason to disbelieve the Mobius pseudorandomness heuristic over the integers, the situation is more subtle over function fields, particularly in low characteristic. For instance there is an ")#link("http://www.ams.org/mathscinet-getitem?mr=144891")[#text("observation of Swan")]#text(" that shows that if ")#mi("f")#text(" is any polynomial in ")#mi("{\\bf F}_2[t]")#text(", then ")#mi("(1+tf)^8+t^3")#text(" is always squarefree with an even number of irreducible factors, thus ")#mi("\\mu((1+tf)^8+t^3)")#text(" is identically ")#mi("1")#text(", in violation of the function field Mobius pseudorandomness heuristic. ")#link("http://www.ams.org/mathscinet-getitem?mr=2114671")[#text("Conrad and Conrad")]#text(" have some further examples of this type. However, this phenomenon seems to be localised to low characteristic (and high degree) and does not seem to impact the situation over the integers.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-391561")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2014")])]

#text("the parity problem implies (as already remarked) for ")#mi("k=2")#text(" that for any admissible region ")#mi("R")#text(" (i.e. satisfies the conditions on ")#mi("R+R")#text(") its M-value can’t exceed 2. This application for the Selberg variational problem is quite remarkable in the sense that it seems to be quite difficult to prove that ")#mi("M(R) \\leq 2")#text(" for any admissible ")#mi("R")#text(" by direct analytic method, and the only known proof is via the parity problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45965de4ff904f2194d10c064ee6b3a22e2de1b35da3999fe0612c67ac491ba9-2612c106cbb3807c7cef33b77f960eba87930049677627041ff0902375a88e62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-391597")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2014")])]

#text("After such an interesting post, I hesitate to make such a trivial remark, but I may as well: there’s something odd about your last sentence (the one in brackets), which makes it seem as though there’s a couple of words accidentally missed out.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d0c2029aee59d879cf643858d692d06adae5780b150dd5e97cf3782bc1e737a-4124e598eecd78b28c27c99ebaaa9febf1f678d61675c6a7a48036595285af53.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 0_Lesh_a")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-392057")[#strong[#text("0_Lesh_a")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2014")])]

#text("And if you take information about the equations for 3,4,5,6 … and to prove that they differ in some law. Do you think it will be harder than finding a solution to the exact equation 2?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ccabc610fa31aa649352d775e02817829116f3fad76cca15b6c74067928d000e-422ce9b32bcaa818d23463b01fa625c5a5e9978dd8aad0d4f5707ce1c3b02dac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-392821")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2014")])]

#text("Does the parity problem also applies for the assertion that there are infinitely many solutions for p-q = T where p and q are primes and T is some fixed number other than 2?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-393808")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2014")])]

#text("Yes. As a general rule of thumb, whenever one is trying to find a prime pair ")#mi("(p,q)")#text(" in some graph ")#mi("G")#text(" over the natural numbers (or over “almost primes”), the parity problem arises as an obstruction whenever the graph ")#mi("G")#text(" is 2-colourable (or even “mostly 2-colourable”, in that the proportion of monochromatic edges is tiny), assuming that the 2-colouring is “non-arithmetic” in some sense (so that it does not exhibit correlation with things like the Mobius function). This is for instance the case with the graph with edges ")#mi("(n,m)")#text(" with ")#mi("n-m=T")#text(", which can be 2-coloured by a simple colouring of congruence classes, as well as the Goldbach-with-bounded error graph ")#mi("n+m = N+O(1)")#text(", which can be 2-coloured after deleting the numbers near ")#mi("N/2")#text(" (assuming for sake of argument that there are no primes of the form ")#mi("N/2+O(1)")#text("). In contrast, the graph of edges ")#mi("(n,m)")#text(" with ")#tao-math("\\left|n-m\\right| \\leq 6", block: false)#text(" is not subject to this obstruction, even if one restricts to integers coprime to both 2 and 3, due to the presence of triangles. The situation with ")#tao-math("\\left|n-m\\right| \\leq 4", block: false)#text(" is more interesting; initially it appears that there are triangles, giving hope that the parity problem is not present here, but after deleting multiples of 2 and 3, all triangles are removed, and the parity problem is now evident.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/508783233e0488b2e1ba9a5645f6f6a052108d588a85d6172b77c198717de6c4-478795a6f19cde74a8cb108756fac28ed0e254eba600b8807426d8044ded09e9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mysteriously7770d7ed15")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-687040")[#strong[#text("mysteriously7770d7ed15")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2025")])]

#text("If ")#mi("p_2 + p_1 = N")#text(" then it suffices to say that ")#mi("p_2 - p_1 = 2\\sqrt {(\\frac{N}{2})2 - p_1p_2 }")#text(". This also implies that ")#mi("p_1 = \\frac{N}{2} - \\sqrt {(\\frac{N}{2})^2 - p_1p_2  }")#text(" and ")#mi("p_2 = \\frac{N}{2} + \\sqrt { (\\frac{N}{2})^2 - p_1p_2 }")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-392879")[#strong[#text("Polymath 8 – a Success! | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2014")]

#text("[…] barrier indeed shows up causes this attempt to fail. (Update July 14:) This is further explained in this new post over Tao’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf13615f71535a3704288f6a0a99302cd04d719d27b929a7e1952928255310ee-fb337fbe09520abcc0d21632742b7f4b6b3af6dcfea5805f61f78613142c4eb6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-396072")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("Professor Tao.")

#text("Constant (H) in: 0 < p' – p < H")#linebreak()#text(" N < p' + p < N + H ; is H = 44")

#text("The solution you have in your email from last month (June)..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c24836e719199a18005ae6f6937c7deded9b203845584382b9d505ba1588b3-e64977382554a3c83fb3de2c459f5010d47cd040a8f15c603b960e206c1d7b76.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sylvainjulien")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-427774")[#strong[#text("sylvainjulien")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2014")])]

#text("You might be interested in taking a glance at my blog ideasfornumbertheory.wordpress.com that hopefully could shed a new light on these two conjectures.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02f7cb3a3b5ac56e51b5d0a117514cfb20a33b69bd9b5f936f95302417f8208f-6071fd7255dc2dc3cfe34b4717111edc63fc626958a8ddb601d254afd37d4023.gif", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony Vossman")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-452708")[#strong[#text("Anthony Vossman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2015")])]

#text("I would think that the only way around parity obstruction would have to begin by permitting the identity elements, 0,1, to be considered “conditionally prime” within the trivial range <4, thereby generalizing the binary G conjecture to a full set Z. From there, considering that the identity elements are also perfect squares, the binary G could be restated as, \"Every perfect square is the sum of a semiprime and another perfect square\", thus fully relating the additive and multiplicative universes, and which would make for an easier conjecture to address. These \"tough\" NT problems are really only related to the fact that axiomatic systems in general, are simply constructive edifices honoring a much deeper bilateral symmetry condition that is a pre-conditional for all arithmetic axioms, terms and relations. The only way you will find 'easy' proofs for these problems is to generalize them over the entire Z. Unfortunately, the symmetric beauty of the primes is spoiled by the conventionalities required of \"uniqueness\". Mathematics has to realize that the human brain is a prisoner of the bilateral symmetry that defines it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b20f408da518bb82c0ca77e337893bfb453554d6f4fbcc4e27c04c39d3c2a8ea-171f8443d883392fcaa7dcb4fda183d695ff5b3c4fbea293c4a8453d1380ec62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-453068")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2015")])]

#text("Perhaps some molifer can help solve the problem, such as use in the work of Yitang Zhang:")#linebreak()#text(" ")#mi("\\displaystyle \\sum_{n_{1},n_{2} \\leq N} \\int_{0}^{1}e^{2\\pi \\alpha (\\Theta (n_{1})+\\Theta (n_{2})-\\log N)\\lambda (n_{1},n_{2})^{2}}")

#mi("\\displaystyle S = \\sum_{n \\leq N} e^{2\\pi \\alpha \\Theta (n) \\lambda (n)^{2}}")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b20f408da518bb82c0ca77e337893bfb453554d6f4fbcc4e27c04c39d3c2a8ea-171f8443d883392fcaa7dcb4fda183d695ff5b3c4fbea293c4a8453d1380ec62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-453514")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2015")])]

#mi("\\displaystyle \\sum_{n_1,n_2\\leq N}\\int_{0}^{1}e^{2\\pi i\\alpha (\\varphi  (n_1)+\\varphi  (n_2)+2-N)\\nu (n_1,n_2)}d\\alpha")

#mi("\\displaystyle \\varphi (n)")#text(" – Euler’s totient function")

#text("I’m not sure, but if Mobius inversion possible for the Euler function, you can use the Selberg sieve for finding suitable mollifier to smooth small arcs and possibly remove zero, which occurs in the evaluation of large arcs.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heath-Brown’s theorem on prime twins and Siegel zeroes | What's new")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-458472")[#strong[#text("Heath-Brown’s theorem on prime twins and Siegel zeroes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2015")])]

#text("[…] can distinguish them from other twins of almost primes. The parity problem is discussed in these previous blog posts; this obstruction is ultimately powered by the Möbius pseudorandomness principle […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8d07af71493e7770bc999aa1a705f5dd9bb7f48246f4fad8f7803f7fc8bebae-3fe02b2f40fd9342dba350a33a4ce2984dae1ec00c2ca7f1ac408fab5331aad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boris Sklyar")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-458803")[#strong[#text("Boris Sklyar")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2015")])]

#text("I propose the following:")

#text("MATRIX DEFINITION” OF PRIME NUMBERS:")

#text("There are two 2-dimensional arrays:")#linebreak()#text(" |5 10 15 20 ..|")#linebreak()#text(" 6i^2-1+(6i-1)(j-1)= |23 34 45 56…|")#linebreak()#text(" |53 70 87 104…|")#linebreak()#text(" |95 118 141 164…|")#linebreak()#text(" |149 178 207 236…|")#linebreak()#text(" |… … … … |")

#text("| 5 12 19 26 ..|")#linebreak()#text(" 6i^2-1+(6i+1)(j-1)= |23 36 49 62…|")#linebreak()#text(" |53 72 91 110…|")#linebreak()#text(" |95 120 145 170…|")#linebreak()#text(" |149 180 211 242…|")#linebreak()#text(" |… … … … |")#linebreak()#text(" Positive integers not contained in these arrays are indexes p of all prime numbers in the sequence S1(p)=6p+5, i.e. p=0, 1, 2, 3, 4, , 6, 7, 8, 9, , 11, , 13, 14, , 16, 17, 18, , , 21, 22, , 24, , , 27, 28, 29, …")#linebreak()#text(" and primes are: 5, 11, 17. 23, 29, , 41, 47, 53, 59, , 71, , 83, 89, , 101, 107, 113, , , 131, 137, , 149, , , 167, 173, 179, ….")

#text("There are two 2-dimensional arrays:")#linebreak()#text(" |3 8 13 18 ..|")#linebreak()#text(" 6i^2-1-2i+(6i-1)(j-1)= |19 30 41 52…|")#linebreak()#text(" |47 64 81 98…|")#linebreak()#text(" |87 110 133 156…|")#linebreak()#text(" |139 168 197 226…|")#linebreak()#text(" |… … … … |")

#text("| 7 14 21 28 ..|")#linebreak()#text(" 6i^2-1+2i+(6i+1)(j-1)= |27 40 53 66…|")#linebreak()#text(" |59 78 97 116..|")#linebreak()#text(" |103 128 153 178…|")#linebreak()#text(" |159 190 221 252…|")#linebreak()#text(" |… … … … |")#linebreak()#text(" Positive integers not contained in these arrays are indexes p of all prime numbers in the sequence S2(p)=6p+7, i.e. p=0, 1, 2, , 4, 5, 6, , , 9, 10, 11, 12, , , 15 , 16, 17, , , 20, , 22, , 24, 25 , 26, , , 29, …")#linebreak()#text(" and primes are: 7, 13, 19. , 31, 37, 43, , , 61, 67, 73, 79, , , 97, 103, 109, , , 127, , 139, , 151, 157, 163, , , 181 ….")#linebreak()#text(" ,﻿")#linebreak()#text(" ")#link("http://www.planet-source-code.com/vb/scripts/ShowCode.asp?txtCodeId=13752&lngWId=3")[#text("http://www.planet-source-code.com/vb/scripts/ShowCode.asp?txtCodeId=13752&lngWId=3")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-459429")[#strong[#text("The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2015")])]

#text("[…] are known to be subject to the “parity problem” (discussed numerous times previously on this blog), which roughly speaking means that they cannot be proven solely using […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-461459")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2015")])]

#text("News:")

#text("Finally is resolved the Goldbach conjecture strong.")

#text("Applyin mathematical logis, we have the result that all:")

#mi("\\forall (2n) = [(p + p_{n}); (p + (2c+1)); ((2a+1) + (2c+1));((2a+1) + p_{n})]")

#text("See: ")#link("http://www.hrpub.org/journals/jour_info.php?id=24")[#text("http://www.hrpub.org/journals/jour_info.php?id=24")]#text(" Vol 3 (3) 2015")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7646891fb6e70c55e557fc9f6926d8a18796f38063217927a938ea45f32b7e7c-6a4e7a7cb0ad2bae93e9b82efd2577dae8ac4318b751387b6ca908e83b116e83.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eulogio")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-462031")[#strong[#text("Eulogio")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2015")])]

#text("I think we are in the final shown. Because, as stated in the article, with the two set ")#mi("[p; p_{1}; p_{2};....] = 2N")#text(" and ")#mi("{(2a+1); (2b+1); (2c+1;.....} = 2B.")

#text("We have.")

#mi("(2a+1) + (2b+1) = 2B")#linebreak()#text(" ")#mi("(2a+1) + (2c+1) =  2B_{1}")

#text("If we apply the decomposition of each pair.")

#mi("[(2a+1) - 2] + [(2b+1) + 2] = 2B")

#text("Being ")#mi("(2a+1)")#text(" the minor of the odd not prime, then.")

#mi("[(2a+1) - 2 ] = p")

#text("Turn: ")#mi("[(2b+1) + 2] \\neq (2c+1)")

#text("If ")#mi("[(2b+1) + 2] < (2c+1)")#text(" then.")

#mi("[(2b+1) + 2] = p_{n}")

#text("And so on.")

#text("[profesor Terence Tao, would be so kind as to give his opinión on the show]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on the Bombieri asymptotic sieve | What's new")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-470703")[#strong[#text("Notes on the Bombieri asymptotic sieve | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2016")])]

#text("[…] thus embodies the “parity problem” for the twin prime conjecture (discussed in these previous blog […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/814530a47d1f53d20f746caab2e34b86762565d4bed2a007cbfd775c84770867-44c1f41a3b78ee445289e7f2cc7bc6d8b4e7cb025bd32048c9631888d568a689.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Caceres")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-489347")[#strong[#text("Pedro Caceres")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2017")])]

#text("(Caceres, 2017) has described the complete set of Prime numbers as:")

#text("{Primes} =")#linebreak()#text(" {2,3} ∪")#linebreak()#text(" {6kn+1 | kn≠6xy+x+y and k_n≠6xy-x-y for all x,y∈N} ∪")#linebreak()#text(" {6km-1 | km≠6xy-x+y for all x,y∈N}")

#text("The definition of the twin primes implies that any S2n such that S2n=kn=km will create a pair of twin primes.")

#text("The list of the first S2n is:")

#text("S2n= [1,2,3,5,7,10,12,17,…]")

#text("And the first pairs generated are:")

#text("Twin Primes from S2n = 1 =[ 5 , 7 ]")#linebreak()#text(" Twin Primes from S2n = 2 =[ 11 , 13 ]")#linebreak()#text(" Twin Primes from S2n = 3 =[ 17 , 19 ]")#linebreak()#text(" Twin Primes from S2n = 5 =[ 29 , 31 ]")#linebreak()#text(" Twin Primes from S2n = 7 =[ 41 , 43 ]")#linebreak()#text(" Twin Primes from S2n = 10 =[ 59 , 61 ]")#linebreak()#text(" Twin Primes from S2n = 12 =[ 71 , 73 ]")#linebreak()#text(" Twin Primes from S2n = 17 =[ 101 , 103 ]")

#text("We must add [3,5] to complete the series.")

#text("Is S2n infinite?")

#text("The members of the series S2n must verify the three primality conditions. For every s2n∈S2n there are no x, y in N that satisfy any of the following conditions:")

#text("s2n=6xy+x+y")#linebreak()#text(" s2n=6xy-x-y")#linebreak()#text(" s2n=6xy+x-y")

#text("If S2n is limited, let’s call S the last element of the set and let’s prove that S does not exist using reduction to the absurd.")

#text("If S is the last element of S2n, S is the last number that verifies that there are no (x, y) Natural numbers such that:")

#text("S=6xy+x+y")#linebreak()#text(" S=6xy-x-y")#linebreak()#text(" S=6xy+x-y")

#text("For any T>S, we will always find some values x, y Naturals that verify:")

#text("T=6xy+x+y")#linebreak()#text(" T=6xy-x-y")#linebreak()#text(" T=6xy+x-y")

#text("These conditions can also be expressed as:")

#text("(6T+1) = (6x+1)*(6y+1)")#linebreak()#text(" (6T+1) = (6x-1)*(6y-1)")#linebreak()#text(" (6T- 1) = (6x-1)*(6y+1)")

#text("Which means that all numbers of the form (6T+1) and (6T-1) with T>S are composite which is absurd as we know that all prime numbers can be expressed as (6T+1) or (6T-1) and the number of primes number is infinite.")

#text("So the numbers of Twin primes is infinite.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b5b08a242348fb8ec17e798dd6985bc6fd32a93f6262d45428d3cfefdf0f895-5a381aae187121c346b46a4d5832a7f4b6f6c9804b9f6e562a08f0e35966ffdf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samuel Bonaya Buya")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-519195")[#strong[#text("Samuel Bonaya Buya")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2019")])]

#text("In my opinion there should be a simple method of proving Goldbach Conjecture. Consider a Goldbach number 2k. The number of primes in the interval [1, 2k] is given by (1) π(2k)= 2k(1/2 – r) where r is ratio of composite odd numbers in the interval [1,2k] to the Goldbach number 2k. For 2k<=8 r =0. This means that (2) π(2k)<=k. Here k is a Goldbach integer. Some of the primes in the interval [1, 2k] are used for Goldbach partition of a Goldbach number. I takes pairs of primes for Goldbach in the interval [1,2k] for partition. The number of Goldbach partition is given by:")#linebreak()#text(" (3) R(2k)<= (π(2k))/2 <= k/2.")#linebreak()#text(" Not all the primes in the interval [1,2k] are used for Goldbach partition. Let the number used for Goldbach partition be Npg. Then for a semiprime Goldbach number:")#linebreak()#text(" (4) R(2k) = (Npg +1)/2")#linebreak()#text(" For a non semiprime Goldbach number the number of Goldbach partitions is given by:")#linebreak()#text(" (5) R(2k) = Npg/2.")#linebreak()#text(" The forms (4) and (5) are not useful for proof of the Goldbach conjecture. For proof of the conjecture write:")#linebreak()#text(" (6) R(2k) = k√(k^2 – m) where (7) m =( k +2k/(Npg +1))(k- 2k/(Npg+1)) for a semiprime Goldbach number or (8) m= (k+2k/Npg)(k-2k/Npg) for a non semiprime Goldbach number. Since R(2k) =4. But k>=2 and k is an integer. This implies m>=0. Now m>=0 implies R(2k)>= 1. Therefore the number of Goldbach partitions cannot be greater than 1. Thus Goldbach conjecture is proved.")#linebreak()#text(" I have worked on this proof and posted the same to academia.edu. Currently article is going through review.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b5b08a242348fb8ec17e798dd6985bc6fd32a93f6262d45428d3cfefdf0f895-5a381aae187121c346b46a4d5832a7f4b6f6c9804b9f6e562a08f0e35966ffdf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samuel Bonaya Buya")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-520018")[#strong[#text("Samuel Bonaya Buya")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2019")])]

#text("To Terence Tao,")#linebreak()#text(" While it is true that Goldbach conjecture is challenging to prove, there exists a hidden direct proof based on the basic properties of numbers that enable establishing the minimum number of Goldbach portions as 1. I discussed the direct proof here:")

#link("https://www.quora.com/When-does-a-proof-qualify-to-be-a-direct-proof-Could-there-be-a-direct-proof-of-Goldbach-conjecture/answer/Samuel-Bonaya-Buya-1?ch=8&share=5331393c&srid=3jnd2")[#text("https://www.quora.com/When-does-a-proof-qualify-to-be-a-direct-proof-Could-there-be-a-direct-proof-of-Goldbach-conjecture/answer/Samuel-Bonaya-Buya-1?ch=8&share=5331393c&srid=3jnd2")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/51ffd7d07b9ed40930d8a06a365f52d1abdc9f7998e85fce338ce3ef87f4e215-d35c29adf476ac5fc8ddfd1f5de261bfedfc0af0b34e2b84e5376a55def82ad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Buzzman")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-522965")[#strong[#text("Buzzman")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("There seems to be a slow progress in this direction. I’m suggesting a way to approach this problem. Let ")#mi("x_i \\leq x")#text(", where ")#mi("x_i \\equiv 1, 5\\pmod{6}")#text(" for sufficiently large ")#mi("x \\in \\mathbb{N}")#text(". For the integer pairs ")#mi("(x_i, 2x-x_i)")#text(" satisfying the binary GC for any sufficiently large ")#mi("x")#text(" such that")

#mi("2x = x_i + (2x-x_i)")#text(",")

#text("it is required that ")#mi("x_i, (2x-x_i) \\equiv 1\\pmod{6}")#text(" if ")#mi("x \\equiv 1, 4\\pmod{6}")#text(" or ")#mi("x_i, (2x-x_i) \\equiv 5\\pmod{6}")#text(" if ")#mi("x \\equiv 2, 5\\pmod{6}")#text(", whereas ")#mi("x_i \\equiv 5\\pmod{6}")#text(" and ")#mi("(2x-x_i) \\equiv 1\\pmod{6}")#text(" and vice versa if ")#mi("x \\equiv 0, 3\\pmod{6}")#text(". Let ")#mi("\\chi (z) = 1")#text(" if ")#mi("z")#text(" is prime and ")#mi("0")#text(" otherwise. Then we have the possible cases as")

#text("Case I: ")#mi("\\chi (x_i) + \\chi (2x-x_i) = 2")#text(",")#linebreak()#text(" Case II: ")#mi("\\chi (x_i) + \\chi (2x-x_i) = 1")#text(",")#linebreak()#text(" Case III: ")#mi("\\chi (x_i) + \\chi (2x-x_i) = 0")#text(".")

#text("Let ")#mi("D")#text(" denote the number of pairs ")#mi("(x_i, 2x-x_i)")#text(" satisfying Case III. Obviously, the binary GC fails if the cardinality of Case I is zero, in which case ")#mi("N = 2C+2D")#text(". As usual, let ")#mi("\\pi (2x; a, q)")#text(" denote the number of primes in arithmetic progression $x_i \\equiv a\\pmod{q}$ below ")#mi("2x")#text(". Also let ")#mi("N")#text(" be the number of terms from ")#mi("x_1")#text(" to ")#mi("x_{N}=2x-x_1")#text(", where ")#mi("x_i")#text(" depends on the least residue class ")#mi("\\pmod{6}")#text(" of ")#mi("x")#text(". Suppose ")#tao-math("C = \\left| \\{\\mathbb{P} \\cap \\{x_1, x_2, \\ldots, x_N\\}\\} \\right|", block: false)#text(", where ")#mi("\\mathbb{P}")#text(" is the set of primes. Then for any sufficiently large ")#mi("x \\not \\equiv 0\\pmod{3}")#text(", the binary GC holds if")

#mi("\\pi (2x) + 4D \\geq 2(C +2)")#text(",")

#text("where ")#mi("\\pi (2x)")#text(" is the number of primes not exceeding ")#mi("2x")#text(". This assumes that the primes are equally distributed between the least residue classes ")#mi("\\pmod{6}")#text(". Similarly,")

#mi("\\pi (2x) + 2D \\geq C + 2")

#text("for ")#mi("x \\equiv 0\\pmod{3}")#text(". These suggest that while the primes thin out as ")#mi("x \\to \\infty")#text(", the size of ")#mi("D")#text(" tends to grow larger such that there is an increasing likelihood for at least one pair of primes, not necessarily distinct, to equal ")#mi("2x")#text(". In this setting, the crux of the matter is thus to establish the growth of ")#mi("D")#text(" as ")#mi("x \\to \\infty")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/51ffd7d07b9ed40930d8a06a365f52d1abdc9f7998e85fce338ce3ef87f4e215-d35c29adf476ac5fc8ddfd1f5de261bfedfc0af0b34e2b84e5376a55def82ad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Buzzman")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-522967")[#strong[#text("Buzzman")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("Oops, ")#mi("C")#text(" should be defined above as ")#mi("C = N - \\pi (2x; a, q)")#text(" as the number of composites in the progression ")#mi("x_i \\equiv 1, 5\\pmod{6}")#text(" depending on ")#mi("x")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5c93865b814463b8b3307eb2fa24979fd1b71664ca97ce49ee413edc70c8593-5d63bd56aa61637d4fb8285db005c5f2e9abf54926e44a45ad61e27e9835c9a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aumeunier")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-605383")[#strong[#text("Aumeunier")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2020")])]

#text("hello")

#text("Eq={q premier |q≤√2n}")#linebreak()#text(" Er={q ∈ Eq | (2n)mod(q)}")

#text("∃q ∈ Eq and ∉ Er such as 2n-q=p Prime number ∀ 2n ∈ N")

#text("you will not find a counterexample because")#linebreak()#text(" 4 very small page the most important and at the end")

#link("http://remyaumeunier.chez-alice.fr/pdf/conjecture%20de%20Goldbach_en.pdf")[#text("Click to access conjecture%20de%20Goldbach_en.pdf")]

#text("by these times of confinement a small re-creation")#linebreak()#text(" and it’s not very, very serious, it’s just math.")

#text("cdl remy")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-605386")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2020")])]

#text("A natural generalization of the problem is to find the slowest growth rate of a positive function ")#mi("H(N)")#text(" such that for sufficiently large $N$, the interval ")#mi("[N, N+H(N)]")#text(" should contain at least one integer which is a sum of two primes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7f99e4e757f6b5a5e0ab8d54a8bfeaeb089b754ab981f3c7861d9fcf804c2bd1-e0e5ddd6712195b1699d3514cbd6f4e4d3f7200fd91c992e06c7ed9b88b4f7fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sacirisi")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-640759")[#strong[#text("sacirisi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2022")])]

#text("Goldbach’s conjecture satisfied with the strategy that the young Gauss invented to add the numbers from 1 to 100.")

#link("https://www.reddit.com/user/Proud-Yogurtcloset71/comments/syr9di/goldbachs_conjecture_satisfied_with_the_strategy/")[#text("https://www.reddit.com/user/Proud-Yogurtcloset71/comments/syr9di/goldbachs_conjecture_satisfied_with_the_strategy/")]

#text("Thanks to an intuition and a strategy, Gauss showed that the same odd number, 101, is the sum of the even numbers with the odd")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da19d744742884b296f90b663833fc3be1365a19ac71548cbdb1d6485a479d00-1dab8c54434907750ba3b21ec711b594b7767dd37d2cf5731a8578dc9a0fcad9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phamminhduc2710")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-660104")[#strong[#text("phamminhduc2710")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2022")])]

#text("Professor Terence Tao, can you take a look for me?")#linebreak()#text(" ")#link("https://www.researchgate.net/publication/365265295_THE-GOLDBACH-CONJECTURE")[#text("https://www.researchgate.net/publication/365265295_THE-GOLDBACH-CONJECTURE")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da19d744742884b296f90b663833fc3be1365a19ac71548cbdb1d6485a479d00-1dab8c54434907750ba3b21ec711b594b7767dd37d2cf5731a8578dc9a0fcad9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phamminhduc2710")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-668749")[#strong[#text("phamminhduc2710")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2022")])]

#text("New approach to the Goldbach conjecture")#linebreak()#text(" ")#link("https://www.researchgate.net/publication/365703468_Goldbach")[#text("https://www.researchgate.net/publication/365703468_Goldbach")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-682819")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2024")])]

#text("Aldo Pappalepore: Dear Professor Tao, I would be very grateful for your opinion on this study of the Goldbach and Hardy-Littlewood conjectures: ")#link("https://alpalerweb.altervista.org/Hardy_Littlewood_and_Goldbach_conjectures.pdf")[#text("https://alpalerweb.altervista.org/Hardy_Littlewood_and_Goldbach_conjectures.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17572692a9e61429fc6f1f7fff071fa660ca53e6a55ccdbdc223c9da97003924-7a388d9a5cf735d9fa477ecd830bf4c4a66b789048774d61ae8f1d4407b16621.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sumit shingare")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-686638")[#strong[#text("Sumit shingare")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Dear Prof. Tao,")

#text("I have a question regarding properties similar to Goldbach’s conjecture, whether they are primarily combinatorial or number-theoretic. Specifically, I am curious about the following:")

#text("1. Is there a positive density subset A of naturals such that restricted sumset A ^+ A has density zero?")

#text("2. If A is an infinite subset of naturals for which restricted sumset A^+A has density zero, what can we conclude about the size or growth rate of A ?")

#text("Thank you for your time and any insights you might offer.—")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-686645")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("The density of the restricted sumset of an infinite set ")#mi("A")#text(" is always at least as large as ")#mi("A")#text(" itself. This is because the restricted sumset contains the sum of the smallest element ")#mi("a_1")#text(" of ")#mi("A")#text(", plus the set ")#mi("A \\backslash \\{a_1\\}")#text(" with the smallest element removed, which has the same density as ")#mi("A")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17572692a9e61429fc6f1f7fff071fa660ca53e6a55ccdbdc223c9da97003924-7a388d9a5cf735d9fa477ecd830bf4c4a66b789048774d61ae8f1d4407b16621.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sumit shingare")]], [#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/comment-page-1/#comment-686648")[#strong[#text("Sumit shingare")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Yes Prof,")

#text("if we assume that restricted sumset of A has density zero then how well we can approximate ( upper bound) the size of A intersection {1,2,…, N}?")
]
]
]
