// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/
// Converted to Typst by tao2typ: "2026-10-14T16:36:47.391936+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Every odd integer larger than 1 is the sum of at most five primes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Every odd integer larger than 1 is the sum of at most five primes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 February 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/")[#text("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper “")#link("http://arxiv.org/abs/1201.6656")[#text("Every odd number greater than 1 is the sum of at most five primes")]#text("“, submitted to ")#link("http://www.ams.org/publications/journals/journalsframework/mcom")[#text("Mathematics of Computation")]#text(". The main result of the paper is as stated in the title, and is in the spirit of (though significantly weaker than) the even ")#link("http://en.wikipedia.org/wiki/Goldbach's_conjecture")[#text("Goldbach conjecture")]#text(" (every even natural number is the sum of at most two primes) and ")#link("http://en.wikipedia.org/wiki/Goldbach%27s_weak_conjecture")[#text("odd Goldbach conjecture")]#text(" (every odd natural number greater than 1 is the sum of at most three primes). It also improves on ")#link("http://www.ams.org/mathscinet-getitem?mr=1375315")[#text("a result of Ramaré")]#text(" that every even natural number is the sum of at most six primes. This result had previously also been ")#link("http://www.ams.org/mathscinet-getitem?mr=1348203")[#text("established by Kaniecki")]#text(" under the additional assumption of the Riemann hypothesis, so one can view the main result here as an unconditional version of Kaniecki’s result.")

#text("The method used is the ")#link("http://en.wikipedia.org/wiki/Hardy%E2%80%93Littlewood_circle_method")[#text("Hardy-Littlewood circle method")]#text(", which was for instance also used to prove ")#link("http://en.wikipedia.org/wiki/Vinogradov%27s_theorem")[#text("Vinogradov’s theorem")]#text(" that every sufficiently large odd number is the sum of three primes. Let’s quickly recall how this argument works. It is convenient to use a proxy for the primes, such as the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(" ")#mi("{\\Lambda}")#text(", which is mostly supported on the primes. To represent a large number ")#mi("{x}")#text(" as the sum of three primes, it suffices to obtain a good lower bound for the sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{n_1,n_2,n_3: n_1+n_2+n_3=x} \\Lambda(n_1) \\Lambda(n_2) \\Lambda(n_3).")]]

#text("By Fourier analysis, one can rewrite this sum as an integral")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}/{\\bf Z}} S(x,\\alpha)^3 e(-x\\alpha)\\ d\\alpha")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("S(x,\\alpha) := \\sum_{n \\leq x} \\Lambda(n) e(n\\alpha)")]]

#text("and ")#mi("{e(\\theta) :=e^{2\\pi i \\theta}}")#text(". To control this integral, one then needs good bounds on ")#mi("{S(x,\\alpha)}")#text(" for various values of ")#mi("{\\alpha}")#text(". To do this, one first approximates ")#mi("{\\alpha}")#text(" by a rational ")#mi("{a/q}")#text(" with controlled denominator (using a tool such as the ")#link("http://en.wikipedia.org/wiki/Dirichlet's_approximation_theorem")[#text("Dirichlet approximation theorem")]#text(") ")#mi("{q}")#text(". The analysis then broadly bifurcates into the ")#emph[#text("major arc")]#text(" case when ")#mi("{q}")#text(" is small, and the ")#emph[#text("minor arc")]#text(" case when ")#mi("{q}")#text(" is large. In the major arc case, the problem more or less boils down to understanding sums such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n\\leq x} \\Lambda(n) e(an/q),")]]

#text("which in turn is almost equivalent to understanding the prime number theorem in arithmetic progressions modulo ")#mi("{q}")#text(". In the minor arc case, the prime number theorem is not strong enough to give good bounds (unless one is using some extremely strong hypotheses, such as the ")#link("http://en.wikipedia.org/wiki/Generalized_Riemann_hypothesis")[#text("generalised Riemann hypothesis")]#text("), so instead one uses a rather different method, using truncated versions of divisor sum identities such as ")#mi("{\\Lambda(n) =\\sum_{d|n} \\mu(d) \\log\\frac{n}{d}}")#text(" to split ")#mi("{S(x,\\alpha)}")#text(" into a collection of linear and bilinear sums that are more tractable to bound, typical examples of which (after using a particularly simple truncated divisor sum identity known as ")#link("http://www.ams.org/mathscinet-getitem?mr=498434")[#text("Vaughan’s identity")]#text(") include the “Type I sum”")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq U} \\mu(d) \\sum_{n \\leq x/d} \\log(n) e(\\alpha dn)")]]

#text("and the “Type II sum”")

#align(center)[#tao-fit-display[#mitex("\\sum_{d > U} \\sum_{w > V} \\mu(d) (\\sum_{b|w: b > V} \\Lambda(b)) e(\\alpha dw) 1_{dw \\leq x}.")]]

#text("After using tools such as the triangle inequality or Cauchy-Schwarz inequality to eliminate arithmetic functions such as ")#mi("{\\mu(d)}")#text(" or ")#mi("{\\sum_{b|w: b>V}\\Lambda(b)}")#text(", one ends up controlling plain exponential sums such as ")#mi("{\\sum_{V < w < x/d} e(\\alpha dw)}")#text(", which can be efficiently controlled in the minor arc case.")

#text("This argument works well when ")#mi("{x}")#text(" is extremely large, but starts running into problems for moderate sized ")#mi("{x}")#text(", e.g. ")#mi("{x \\sim 10^{30}}")#text(". The first issue is that of logarithmic losses in the minor arc estimates. A typical minor arc estimate takes the shape ")#metadata(none) <tao-f90e22675ced9c138e19>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|S(x,\\alpha)\\right| \\ll (\\frac{x}{\\sqrt{q}}+\\frac{x}{\\sqrt{x/q}} + x^{4/5}) \\log^3 x", block: true)]]

#text("when ")#mi("{\\alpha}")#text(" is close to ")#mi("{a/q}")#text(" for some ")#mi("{1\\leq q\\leq x}")#text(". This only improves upon the trivial estimate ")#tao-math("{\\left|S(x,\\alpha)\\right| \\ll x}", block: false)#text(" from the prime number theorem when ")#mi("{\\log^6 x \\ll q \\ll x/\\log^6 x}")#text(". As a consequence, it becomes necessary to obtain an accurate prime number theorem in arithmetic progressions with modulus as large as ")#mi("{\\log^6 x}")#text(". However, with current technology, the error term in such theorems are quite poor (terms such as ")#mi("{O(\\exp(-c\\sqrt{\\log x}) x)}")#text(" for some small ")#mi("{c>0}")#text(" are typical, and there is also a notorious “Siegel zero” problem), and as a consequence, the method is generally only applicable for very large ")#mi("{x}")#text(". For instance, the best explicit result of Vinogradov type known currently is due ")#link("http://www.ams.org/mathscinet-getitem?mr=1932763")[#text("to Liu and Wang")]#text(", who established that all odd numbers larger than ")#mi("{10^{1340}}")#text(" are the sum of three odd primes. (However, on the assumption of the GRH, the full odd Goldbach conjecture is known to be true; this is a ")#link("http://www.ams.org/mathscinet-getitem?mr=1469323")[#text("result of Deshouillers, Effinger, te Riele, and Zinoviev")]#text(".)")

#text("In this paper, we make a number of refinements to the general scheme, each one of which is individually rather modest and not all that novel, but which when added together turn out to be enough to resolve the five primes problem (though many more ideas would still be needed to tackle the three primes problem, and as is well known the circle method is very unlikely to be the route to make progress on the two primes problem). The first refinement, which is only available in the five primes case, is to take advantage of the numerical verification of the even Goldbach conjecture up to some large ")#mi("{N_0}")#text(" (we take ")#mi("{N_0=4\\times 10^{14}}")#text(", using a ")#link("http://www.ams.org/mathscinet-getitem?mr=1836932")[#text("verification of Richstein")]#text(", although there are now much larger values of ")#mi("{N_0}")#text(" – ")#link("http://www.ieeta.pt/~tos/goldbach.html")[#text("as high as ")#mi("{2.6 \\times 10^{18}}")]#text(" – for which the conjecture has been verified). As such, instead of trying to represent an odd number ")#mi("{x}")#text(" as the sum of five primes, we can represent it as the sum of three odd primes and a natural number between ")#mi("{2}")#text(" and ")#mi("{N_0}")#text(". This effectively brings us back to the three primes problem, but with the significant additional boost that one can essentially restrict the frequency variable ")#mi("{\\alpha}")#text(" to be of size ")#mi("{O(1/N_0)}")#text(". In practice, this eliminates all of the major arcs except for the principal arc around ")#mi("{0}")#text(". This is a significant simplification, in particular avoiding the need to deal with the prime number theorem in arithmetic progressions (and all the attendant theory of L-functions, Siegel zeroes, etc.).")

#text("In a similar spirit, by taking advantage of the numerical verification of the Riemann hypothesis up to some height ")#mi("{T_0}")#text(", and using the ")#link("http://en.wikipedia.org/wiki/Explicit_formula")[#text("explicit formula")]#text(" relating the von Mangoldt function with the zeroes of the zeta function, one can safely deal with the principal major arc ")#mi("{\\{ \\alpha = O( T_0 / x ) \\}}")#text(". For our specific application, we use the value ")#mi("{T_0= 3.29 \\times 10^9}")#text(", arising from the verification of the Riemann hypothesis of the first ")#mi("{10^{10}}")#text(" zeroes by van de Lune (unpublished) and ")#link("http://www.zetagrid.net/")[#text("Wedeniswki")]#text(". (Such verifications have since been extended further, the ")#link("http://numbers.computation.free.fr/Constants/Miscellaneous/zetazeros1e13-1e24.pdf")[#text("latest being")]#text(" that the first ")#mi("{10^{13}}")#text(" zeroes lie on the line.)")

#text("To make the contribution of the major arc as efficient as possible, we borrow an idea from ")#link("http://www.ams.org/mathscinet-getitem?mr=1726234")[#text("a paper of Bourgain")]#text(", and restrict one of the three primes in the three-primes problem to a somewhat shorter range than the other two (of size ")#mi("{O(x/K)}")#text(" instead of ")#mi("{O(x)}")#text(", where we take ")#mi("{K}")#text(" to be something like ")#mi("{10^3}")#text("), as this largely eliminates the “Archimedean” losses coming from trying to use Fourier methods to control convolutions on ")#mi("{{\\bf R}}")#text(". In our paper, we set the scale parameter ")#mi("{K}")#text(" to be ")#mi("{10^3}")#text(" (basically, anything that is much larger than ")#mi("{1}")#text(" but much less than ")#mi("{T_0}")#text(" will work), but we found that an additional gain (which we ended up not using) could be obtained by averaging ")#mi("{K}")#text(" over a range of scales, say between ")#mi("{10^3}")#text(" and ")#mi("{10^6}")#text(". This sort of averaging could be a useful trick in future work on Goldbach-type problems.")

#text("It remains to treat the contribution of the “minor arc” ")#tao-math("{T_0/x \\ll \\left|\\alpha\\right| \\ll 1/N_0}", block: false)#text(". To do this, one needs good ")#mi("{L^2}")#text(" and ")#mi("{L^\\infty}")#text(" type estimates on the exponential sum ")#mi("{S(x,\\alpha)}")#text(". Plancherel’s theorem gives an ")#mi("{L^2}")#text(" estimate which loses a logarithmic factor, but it turns out that on this particular minor arc one can use tools from the theory of the large sieve (such as ")#link("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/")[#text("Montgomery’s uncertainty principle")]#text(") to eliminate this logarithmic loss almost completely; it turns out that the most efficient way to do this is use an effective upper bound ")#link("http://www.ams.org/mathscinet-getitem?mr=424731")[#text("of Siebert")]#text(" on the number of prime pairs ")#mi("{(p,p+h)}")#text(" less than ")#mi("{x}")#text(" to obtain an ")#mi("{L^2}")#text(" bound that only loses a factor of ")#mi("{8}")#text(" (or of ")#mi("{7}")#text(", once one cuts out the major arc).")

#text("For ")#mi("{L^\\infty}")#text(" estimates, it turns out that existing effective versions of ")#link(<tao-f90e22675ced9c138e19>)[#text("(1)")]#text(" (in particular, the bound ")#link("http://www.ams.org/mathscinet-getitem?mr=1272501")[#text("given by Chen and Wang")]#text(") are insufficient, due to the three logarithmic factors of ")#mi("{\\log x}")#text(" in the bound. By using a ")#link("http://www.tricki.org/article/Smoothing_sums")[#text("smoothed out version")]#text(" ")#mi("{S_\\eta(x,\\alpha) :=\\sum_{n}\\Lambda(n) e(n\\alpha) \\eta(n/x)}")#text(" of the sum ")#mi("{S(\\alpha,x)}")#text(", for some suitable cutoff function ")#mi("{\\eta}")#text(", one can save one factor of a logarithm, obtaining a bound of the form")

#align(center)[#tao-fit-display[#tao-math("\\left|S_\\eta(x,\\alpha)\\right| \\ll (\\frac{x}{\\sqrt{q}}+\\frac{x}{\\sqrt{x/q}} + x^{4/5}) \\log^2 x", block: true)]]

#text("with effective constants. One can improve the constants further by restricting all summations to odd integers (which barely affects ")#mi("{S_\\eta(x,\\alpha)}")#text(", since ")#mi("{\\Lambda}")#text(" was mostly supported on odd numbers anyway), which in practice reduces the effective constants by a factor of two or so. One can also make further improvements in the constants by using the very sharp ")#emph[#text("large sieve inequality")]#text(" to control the “Type II” sums that arise from Vaughan’s identity, and by using integration by parts to improve the bounds on the “Type I” sums. A final gain can then be extracted by optimising the cutoff parameters ")#mi("{U, V}")#text(" appearing in Vaughan’s identity to minimise the contribution of the Type II sums (which, in practice, are the dominant term). Combining all these improvements, one ends up with bounds of the shape")

#align(center)[#tao-fit-display[#tao-math("\\left|S_\\eta(x,\\alpha)\\right| \\ll \\frac{x}{q} \\log^2 x + \\frac{x}{\\sqrt{q}} \\log^2 q", block: true)]]

#text("when ")#mi("{q}")#text(" is small (say ")#mi("{1 < q < x^{1/3}}")#text(") and")

#align(center)[#tao-fit-display[#tao-math("\\left|S_\\eta(x,\\alpha)\\right| \\ll \\frac{x}{(x/q)^2} \\log^2 x + \\frac{x}{\\sqrt{x/q}} \\log^2(x/q)", block: true)]]

#text("when ")#mi("{q}")#text(" is large (say ")#mi("{x^{2/3} < q < x}")#text("). (See the paper for more explicit versions of these estimates.) The point here is that the ")#mi("{\\log x}")#text(" factors have been partially replaced by smaller logarithmic factors such as ")#mi("{\\log q}")#text(" or ")#mi("{\\log x/q}")#text(". Putting together all of these improvements, one can finally obtain a satisfactory bound on the minor arc. (There are still some terms with a ")#mi("{\\log x}")#text(" factor in them, but we use the effective Vinogradov theorem ")#link("http://www.ams.org/mathscinet-getitem?mr=1932763")[#text("of Liu and Wang")]#text(" to upper bound ")#mi("{\\log x}")#text(" by ")#mi("{3100}")#text(", which ends up making the remaining terms involving ")#mi("{\\log x}")#text(" manageable.)")

#heading(level: 1)[#text("Comments (155)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-142750")[#strong[#text("陶哲轩接近证明哥德巴赫猜想 | 博鲨科技 跨界畅游|中国领先的网站制作、电子商务、在线交易方案提供商")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2012")]

#text("[…] 陶哲轩最近在预印本网站arXiv.org发 表论文（已递交到《Mathematics of Computation》），证明每个大于1的奇数可以表示成最多五个质数之和，他表示有希望将数 目从五减少到三。 Leave a Reply 点击这里取消回复。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2281803808cd85326d2ab445457a987bdfdac15c84bf68adadc7ac8f501e12e-36f26a7f8f3fb37836fd96b2013a4198c23aa98354899326c0500e1120d3eb72.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Panu Horsmalahti")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-142824")[#strong[#text("Panu Horsmalahti")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2012")])]

#text("Minor typo in page 36, it should say “used in the proof”.")

#emph[#text("[Thanks, this will be corrected in the next version of the ms.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13db318bdd881fc1a1ab8bc0ee86455e7537859081712f995f3f202ffafab113-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Van Der Kolff")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-142829")[#strong[#text("Michael Van Der Kolff")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2012")])]

#text("Minor typo on page 10, Lemma 3.1: alpha should be a non-integral real, not a coset of Z in R. ")#emph[#text("[Actually, we are identifying the two; see Section 2, especially the paragraph near (2.1).]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa70d2b97f020c3dd45a5d9ee84ce38b700e0570a51a5743a737d56722ee2e13-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Van Der Kolff")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-142880")[#strong[#text("Michael Van Der Kolff")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2012")])]

#text("Yeah, I noticed when rereading it on the train heading down to class. It’s actually really quite interesting – and I hope I can understand the techniques by the end of my degree :)")

#text("It’s really quite fascinating, though :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-142860")[#strong[#text("Some math | pyd's blog")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2012")]

#text("[…] problem a relatively recent update on Goldbach conjecture has be given by a Fields medalist. https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-… Share this:TwitterFacebookLike this:LikeBe the first to like this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-142964")[#strong[#text("La conjetura Golbach, ¿cerca de resolverse? | Matuk.com")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2012")]

#text("[…] Fuente: Terence Tao blog input, textarea{} #authorarea{border:#9EBAC7 1px solid; margin:10px 0px 30px; padding:6px 8px 14px 6px; background-repeat:no-repeat; color:#555; background-color:#e2eaee} #authorarea h3{font-size:14px; color:#333; font-weight:bold; margin:0} #authorarea h3 a{text-decoration:none; color:#333; font-weight:bold} #authorarea img{margin:0; float:left; border:1px solid #ddd; width:60px; height:60px; margin-right:12px} #authorarea p{color:#333; margin:0} #authorarea p a{color:#333} .authorinfo{ } […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-143778")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2012")])]

#text("Hi, I think the proof is wrong.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b1f71d2661d5fe67d6f698960a235191a307ca0b38d67929a86da7a715e248e-eeac516913d6e561892ec25e492005e3e0f10eb45c70a6a041e330bf7b8f0df6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lup")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-143891")[#strong[#text("lup")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2012")])]

#text("@Anonymous[20 May, 2012 at 1:48 pm] as a consolation, the world you are living in where the proof is wrong must certainly have some funny sides.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heuristic limitations of the circle method « What’s new")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-143787")[#strong[#text("Heuristic limitations of the circle method « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2012")])]

#text("[…] famous theorem that every sufficiently large odd integer is the sum of three primes; my own result that all odd numbers greater than can be expressed as the sum of at most five primes is also proven by essentially the same method (modulo a number of minor refinements, and taking […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-144019")[#strong[#text("The Goldbach Conjecture | OU Math Club")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2012")]

#text("[…] Recently, Terry Tao proved that every odd integer is the sum of at most 5 primes. The key thing is that he doesn’t have to assume the validity of the Riemann Hypothesis to do it. So Kaniecki’s theorem is true without any qualifications. It’s a very nice result and Dr. Tao posted about it on his blog.** […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-144109")[#strong[#text("Goldbach Conjecture and Terence Tao » IMatDb")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2012")]

#text("[…] 次日，Tao 在他的博客 之中，写了一篇日志 描述了证明的大概轮廓。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-144110")[#strong[#text("Terence Tao come closer to solving Goldbach’s weak conjecture » IMatDb")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2012")]

#text("[…] 次日，Tao 在他的博客 之中，写了一篇日志 描述了证明的大概轮廓。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-144896")[#strong[#text("El difícil ascenso a la solución de un problema matemático | El Enciclopedista")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2012")]

#text("[…] estadounidense había presentado en febrero de este artículo a una revista para su publicación y la experiencia, pero la revista Scientific […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-146228")[#strong[#text("Terence Tao come closer to solving Goldbach’s weak conjecture » Zyymat")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2012")]

#text("[…] 次日，Tao 在他的博客 之中，写了一篇日志 描述了证明的大概轮廓。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f8e979f6c05540b3d621313d3a7a60224920a1f8c2b5b2b0a2b30dcd7408acc-9a9ec4eea40c405e4278e2c033663bedad542423877587b5178769da1b6cbe6d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon8891")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-148370")[#strong[#text("Anon8891")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2012")])]

#text("Hi there,")

#text("I don’t understand one thing, how does this proof work for all odd integers greater than 1 and not rely upon the Riemann hypothesis?")

#text("The number of odd integers greater than 1 is infinite.")#linebreak()#text(" This proof relies upon the numerical verification of the Riemann hypothesis up to some height.")

#text("Since Kaniecki proved that every odd integer is a sum of at most five primes assuming that the Riemann Hypothesis is true, how does this proof differ much from Kaniecki’s since it relies upon the numerical verification of the Riemann hypothesis up to a certain height?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-148375")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2012")])]

#text("Kaniecki’s argument and mine use the Riemann hypothesis (or partial numerical verifications of it) in somewhat different ways. Kaniecki uses a quantitative version of the a well-known fact that if the Riemann hypothesis was true, then almost all prime gaps would be very small, which (together with numerical verification of the even Goldbach conjecture) implies that almost all odd numbers (in a certain range) are the sum of three primes, and hence that all even numbers (in a similar range) are the sum of six primes. (I’m glossing over a number of details here.) Unfortunately this argument doesn’t work too well with only a partial numerical verification of RH, more or less for the reason you point out, namely that one has to verify the conjecture for an infinite number of numbers. (Actually, thanks to the Vinogradov theorem results of Liu and Wang and others, one only has to verify the numbers up to 10^{1300} or so, but even in this range Kaniecki’s argument would still require far more numerical verification of the RH than is currently available.)")

#text("In my argument, numerical verification of RH is used in a slightly different way, to get a reasonably good error term in the prime number theorem, which in turn leads to control of prime exponential sums at very low frequencies. This, by itself, is nowhere near enough to settle the conjecture (in contrast to Kaniecki’s argument, in which RH is the main tool), again because the numerical verification of RH falls well short of what would be needed to cover the range of numbers desired without additional tools; the estimates from numerical RH have to be combined with effective minor arc estimates (to handle medium frequencies) and numerical verification of Goldbach (to handle large frequencies) in order to cover all the contributions to the counting function associated to this problem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ec1b6a18feedbc702c0f6cafc88103bd621347fdd0798c692890d7c26076301-a24b5d5fb4434c380192f7ce385c55fc38a01b1e1416e21d9fce602efbe90ed7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chanakya")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-148703")[#strong[#text("Chanakya")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2012")])]

#text("According to the preposition, every odd integer greater than 1 is the sum of “at most” five primes. But, if we had an odd number of odd primes, their sum will always be odd. So, it could be possible that an odd number be a sum of 7 odd primes or 9 odd primes.Then the preposition no more remains true. For example : 3+5+7+11+13+17+19= 75. But 75 here is a sum of 7 primes. ?????????")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-148763")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2012")])]

#text("please learn more math before you comments")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca996364b71645cf77ec4575751459f2cf25f0acd7adb69f8f928b644448a580-88165e9a2b56a1d97ddc79d1340a9f83d0f7300e9ff9df89397197bdb7ef720f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-217074")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2013")])]

#text("You don’t understand what’s he saying.")

#text("He’s not saying that “odd integers cannot be the sum of more than 5 primes”")

#text("He’s saying that “all odd integers are the sum of 5 primes or less”")

#text("Meaning that every odd integer can be expressed as the sum of 5 primes or less.")

#text("There are multiple ways that one can gain the sum of 75 using only 5 prime numbers or less.")

#text("Like:")#linebreak()#text(" 75 = 73+2")#linebreak()#text(" 75 = 67+3+5")#linebreak()#text(" 75 = 37+19+17+2")#linebreak()#text(" 75 = 23+19+17+13+3")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3dad12992b3089610f032bf74e5bbe9e329b46ad5337ae9a1aad4b9de5d791ed-5d908cbf1e8153827ba1b534367ff7e42b31e66bc90542b8dfe426463a395e7f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-151012")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2012")])]

#text("Vinogradov three primes theorem implies this result. This does not break any record.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3dad12992b3089610f032bf74e5bbe9e329b46ad5337ae9a1aad4b9de5d791ed-5d908cbf1e8153827ba1b534367ff7e42b31e66bc90542b8dfe426463a395e7f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-151869")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2012")])]

#text("Vinogrodov’s three primes theorem iplies that even integer are sums of four or less primes.")

#text("To beat the Vinogradov’s result, you will have to prove that even integers are sums of three or less primes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-151875")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2012")])]

#text("Vinogradov’s theorem is only applicable for ")#emph[#text("sufficiently large")]#text(" odd natural numbers, not for ")#emph[#text("all")]#text(" odd natural numbers; see for instance ")#link("http://en.wikipedia.org/wiki/Vinogradov's_theorem")[#text("http://en.wikipedia.org/wiki/Vinogradov's_theorem")]#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c4ce08656428146482200e11f94e1d396892354bcb52533acaf74a4f6b7ef862-c898022b4eb99978bd80f539db8c3afbbfd275f6614d93ea2c58a0aaa9f75319.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Silvio")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-152035")[#strong[#text("Silvio")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2012")])]

#text("Hi Tao, do you think that larger numerical verification can be useful to improve this result? if yes, have you an idea of what exponent we must reach at least?")#linebreak()#text(" Thank you and congratulation for the result.")#linebreak()#text(" Silvio")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-152166")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2012")])]

#text("See ")#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/#comment-127669")[#text("my previous comment")]#text(". Basically, by using more numerics, one can reduce the reliance on Vinogradov theorems, but it does not seem easy to get from five primes to four with this method.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f71758d7d36498b87d4e7e88664951529669dbd1abe236e5ff364725e74b1b13-043c847bd43c1e9ebc028ac742231fc0f865fbc6c4482269820e31ba475c74ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ciro")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-167632")[#strong[#text("ciro")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2012")])]

#text("Hi Terry, congratulation for your interesting paper. What abaout the following approach for the strong version of the conjecture?")#linebreak()#text(" ")#link("http://arxiv.org/abs/1208.2244")[#text("http://arxiv.org/abs/1208.2244")]#linebreak()#text(" Thank you")#linebreak()#text(" Ciro")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d36213c4ade28312d322432915a2b6aa042da21f79dbe16588c179d8c5bd9cdb-ea8582a3555f1812797cadab770169f291bdda4b1782818b21dcfe9761434630.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Rubinstein")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-170607")[#strong[#text("Michael Rubinstein")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2012")])]

#text("Just came across this. Regarding inputting numerical verification of RH- most verifications of RH have been experimental and cannot be used as the basis of proof of a rigorous mathematical statement. That includes the computations referenced.")

#text("Luckily, though, RH has been more rigorously verified, by Booker and Platt up to height 30, 610, 046, 000 (103, 800, 788, 359 zeros). ")#link("http://arxiv.org/pdf/1203.5712.pdf")[#text("http://arxiv.org/pdf/1203.5712.pdf")]

#text("They used explicit truncation bounds and interval arithmetic to bound accumulated round off. In principle, their work provides a rigorous verification of RH. However, there is of course a lot that takes place in a black box (ex intel chips) or at a very low level (compilers, assembler). Hardware has never been certified rigorously, and, there have been cases of buggy hardware uncovered experimentally. Compilers also are constantly having bug fixes (look at the version history of any compiler).")

#text("There are some easy test that one can do with zeta zeros to increase one’s level of confidence. For me, testing the explicit formula with many test functions gives me confidence that a given zeta-zeros computation is correct.")

#text("Anyhow, Terry, this work sounds interesting.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d36213c4ade28312d322432915a2b6aa042da21f79dbe16588c179d8c5bd9cdb-ea8582a3555f1812797cadab770169f291bdda4b1782818b21dcfe9761434630.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Rubinstein")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-170616")[#strong[#text("Michael Rubinstein")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2012")])]

#text("Oh, I see that you do refer to Platt’s computation in your arxiv paper (I incorrectly referred, above, to the paper as Booker and Platt’s rather than Platt’s).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-177240")[#strong[#text("Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2012")]

#strong[#text("What are the greatest open problems in math are we closest to solving?…")]

#text("Terence Tao recently proved that every odd integer larger than 1 is the sum of at most five primes. This advance pushes closer to the odd Goldbach conjecture, which replaces five primes with three primes. He said in a talk recently that we are probably…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae1397dfff11bfcefc4ca251723ea72b08e75a6f661912641d5c2c96713c3e49-9ba2336c96092e3c3b01a5eede564f81a93f66d413885d24ff43a861ec5a7a5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The same anonymous as always xP")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-214247")[#strong[#text("The same anonymous as always xP")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2013")])]

#text("Is the paper already being published?")#linebreak()#text(" Today appears in the news (SUPER SCHOLAR test) that Terrence is one of the most inteligent HUMAN BEING alive (IQ 230).")#linebreak()#text(" With that IQ is no merit to find such math wonders ! ( xD ) Congrats!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae1397dfff11bfcefc4ca251723ea72b08e75a6f661912641d5c2c96713c3e49-9ba2336c96092e3c3b01a5eede564f81a93f66d413885d24ff43a861ec5a7a5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ????")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-214345")[#strong[#text("????")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2013")])]

#text("What I said I true, at least that THIS Terence Tao has appeared in the news, with such IQ. Is not worth to congratulate him -no kidding-? ")#link("http://www.superscholar.org/smartest-people/")[#text("http://www.superscholar.org/smartest-people/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca996364b71645cf77ec4575751459f2cf25f0acd7adb69f8f928b644448a580-88165e9a2b56a1d97ddc79d1340a9f83d0f7300e9ff9df89397197bdb7ef720f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-217075")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2013")])]

#text("Terence Tao’s adult IQ has never been tested, his 230 score was gained from childhood or teen IQ estimates (which are multiplied numbers based on ratios)")

#text("I don’t think Tao cares much about IQ either way.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa4d92326c69fc5d387e05b69bcf9cc072d4ab7a35f219492c21103b2363a86c-1b123fa8de1750301d4b77953ec6a2c8735122be4d2878a2b15cdff6733b3974.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian McCormick")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-214598")[#strong[#text("Brian McCormick")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2013")])]

#text("Dear Professor Tao,")

#text("I have seen several references saying Borozkin was the first to find an explicit value for the Vinogradov bound for the odd Goldbach conjecture and he showed the value to be 3^3^15 to be it (that is 3 to the 3rd power to the 15th power).")

#text("However, this result is not published. I would love to figure out how this bound was determined. Do you know of any reference that shows how this bound is determined? Is it so simple that you can give a brief, high-level explanation for it on here?")

#text("Congratulations on your proof. It is indeed a work of art!")

#text("Brian McCormick")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a93d7c8812e190df07255d74c1fa73ad166a7c6f516a2ef5590a63214f734c59-b6b4f112df3719118d8bc48e8193128379b63e9c98d7af2bba2607a5a6ef6432.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of freepublic")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-221556")[#strong[#text("freepublic")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2013")])]

#text("Dear Professor Terry Tao,")#linebreak()#text(" the proof has many special theorem, i can’t understand fully. i wonder what is the large even number?")#linebreak()#text(" if 2 is large number, it can’t express as any sum of primes.")#linebreak()#text(" if inifite is large number, it has 1 add number being inifite always.")#linebreak()#text(" you can look at my idea in ")#link("http://vixra.org/abs/1301.0129")[#text("http://vixra.org/abs/1301.0129")]#linebreak()#text(" Sencerely,")#linebreak()#text(" Liu Ran")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a93d7c8812e190df07255d74c1fa73ad166a7c6f516a2ef5590a63214f734c59-b6b4f112df3719118d8bc48e8193128379b63e9c98d7af2bba2607a5a6ef6432.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of freepublic")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-223040")[#strong[#text("freepublic")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2013")])]

#text("Dear Professor Terry Tao,")#linebreak()#text(" you can look at my new article in ")#link("http://vixra.org/abs/1304.0020")[#text("http://vixra.org/abs/1304.0020")]#linebreak()#text(" both experiment and logic have demonstrated prime being infinite is wrong.")#linebreak()#text(" it means Euclid’s proof had a issue which had misled machemacian for many years.")#linebreak()#text(" i admire you, wish you can discuss this problem. maybe it’s a big event.")#linebreak()#text(" Sencerely,")#linebreak()#text(" Liu Ran")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fce92a724eb666faf16bfe42e294a90908990f55d961f942b0a336e5dcbd6495-446e50182cd06d92db8337227c01697defd9855e2d0fff729ec0a505beb9fb49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of freepublic")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-223838")[#strong[#text("freepublic")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2013")])]

#text("Congratulations!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-229236")[#strong[#text("Three Primes Make an Odd | GCP Archived")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2013")]

#text("[…] ")#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-&#8230")[#text("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-&#8230")]#text("; […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a93d7c8812e190df07255d74c1fa73ad166a7c6f516a2ef5590a63214f734c59-b6b4f112df3719118d8bc48e8193128379b63e9c98d7af2bba2607a5a6ef6432.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of freepublic")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-229378")[#strong[#text("freepublic")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2013")])]

#text("i wonder why need to exclude 5 from your theorem, if it is really true.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db4ff2d16f30f81a2dcee11f5421bee52f082fbe6830ac453c00306db0ec16f6-54423917c7af6c3b5c2382dd64d78121563031b52a45c20ac7b0660fc1360005.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of grutge")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-232136")[#strong[#text("grutge")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2013")])]

#text("Has been already published in a peer reviewed journal this article?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af889f21cffed1bc6bdf27a7fed1fde0389bf12b630f305535d4972157aec4d7-90ef39ba9be26d6fc3d07526c03c555ee74ee9c0411fc741d027ab3597c9af5e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of neymetms")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-242348")[#strong[#text("neymetms")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2013")])]

#text("Дорогой Тао , если взять неравенство A<B<С ,и если выполнятся.")#linebreak()#text(" условия для A и С, то они должны выполняются и для B.")

#text("Слабая проблема Гольдбаха (любое нечётное число, превосходящее единицу, можно представить в виде суммы не более чем трёх простых.) выполняется для малых нечётных чисел. (A) не превосходящих е28. и «достаточно больших» нечётных чисел(С), то почему оно (условие) не должноне выполнятся и для (B) ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7f6ad386cf323eddb2ac863751e50d4a9a14e6ecafec58ae0495abedb0f8a0a7-976e5fe97d615a5c1ff35417abd0014a1920869b48b574a880645cfdd0e49961.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bringing A Riemannian Gun to a Euclidean Knife Fight |")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-243728")[#strong[#text("Bringing A Riemannian Gun to a Euclidean Knife Fight |")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2013")])]

#text("[…] Today, part of the appeal of prime numbers is that there remain many apparently-simple questions about primes whose answers are unknown. (One famous example is Goldbach’s conjecture, posed in 1742 in a letter to Leonhard Euler, that every even integer > 2 can be written as the sum of two primes. Note, however, that Terence Tao has recently proven that every odd integer > 1 is the sum of at most 5 primes). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d03d2663aaed4f124296c50e8de3a7c466dbf527114e3de71a7ca77cec007a33-1ebc3e45a75492c731559b534950bcfd6e62f34c9361344b489c2a1dc1396cb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Huen Yeong Kong")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-249511")[#strong[#text("Huen Yeong Kong")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2013")])]

#text("Odd integer = 17+11+23+5+29+3+31 = 119 derived from the")#linebreak()#text(" following series of twin-primes anchored by 17:")#linebreak()#text(" f(17,17,17)+f(17,11,23)+f(17,5,29)+f(17,3,31)")#linebreak()#text(" This is the sum of seven primes and is odd.")#linebreak()#text(" The sum has more than five primes as stipulated by you.")#linebreak()#text(" Am I wrong?")#linebreak()#text(" Huen Y.K.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9521e98d660cc271844f73bbffc279f55fe0a15b317f2088883011d1c7d85724-f20a2ad7fb6a7f4b7b42f2e267f725604eceed14375e89dfea88ac48dafc2029.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-249537")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2013")])]

#text("119 = 5 + 43 + 71. The theorem says it is possible to write 119 as a sum of at most five primes, not that every way to write it will have at most five primes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d03d2663aaed4f124296c50e8de3a7c466dbf527114e3de71a7ca77cec007a33-1ebc3e45a75492c731559b534950bcfd6e62f34c9361344b489c2a1dc1396cb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Huen Yeong Kong")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-249723")[#strong[#text("Huen Yeong Kong")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2013")])]

#text("Yes, you are right for my example, but could you recommend an")#linebreak()#text(" algorithm which could predict for every odd integer a sum of at most five primes?")#linebreak()#text(" Huen Y.K.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c67be942530c47b7c6347ed73b57c2c5d5640949de5dfecbbacda8b87b7cc4e-fb079e79f4f30364ac2779e094811011902c763bd47b58900cc436db64f7530a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael van der Kolff")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-249731")[#strong[#text("Michael van der Kolff")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2013")])]

#text("In general, I can’t see a way beyond generating all the primes beneath that number, and then trying each partition up to 5 of them. I’m pretty sure that’s *not* polynomial time, though.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d03d2663aaed4f124296c50e8de3a7c466dbf527114e3de71a7ca77cec007a33-1ebc3e45a75492c731559b534950bcfd6e62f34c9361344b489c2a1dc1396cb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Huen Yeong Kong")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-249810")[#strong[#text("Huen Yeong Kong")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2013")])]

#text("You are right. Sounds like a Four-Colour Theorem variant.")#linebreak()#text(" Huen Y.K.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2fa7592c66fc8b5eb40f8670c40c28516a0f8748bf791657509ffad4f77bb5ed-998038497aea5217ac4d52c5bf36132e08c78f8d54efdb7c8d3fc17635a78a1e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-250143")[#strong[#text("Matt")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2013")])]

#text("Forgive my stupidity – this assumes 1 is prime?")

#text("Otherwise 11 cannot be expressed as a sum of primes at all.")

#text("Are there any other prime numbers for which this does not hold if 1 is excluded?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c67be942530c47b7c6347ed73b57c2c5d5640949de5dfecbbacda8b87b7cc4e-fb079e79f4f30364ac2779e094811011902c763bd47b58900cc436db64f7530a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael van der Kolff")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-250158")[#strong[#text("Michael van der Kolff")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2013")])]

#text("11 (it’s prime!), or 3+3+5. Up to 5, not exactly 5…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2fa7592c66fc8b5eb40f8670c40c28516a0f8748bf791657509ffad4f77bb5ed-998038497aea5217ac4d52c5bf36132e08c78f8d54efdb7c8d3fc17635a78a1e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-250286")[#strong[#text("Matt")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2013")])]

#text("Thanks for your reply.")

#text("I thought the primes in the sum could be used only once:")

#text("eg 7 = 5 +2; 13 = 11 + 2 (not 3+3+3+2+2); 17 = 7 + 5 + 3 +2; 19 = 17 + 2 etc")

#text("It seems that (excluding 2 – the first prime), 11 is the only prime that cannot be expressed as a sum of primes (using each only once).")

#text("Wondered whether this was true.")

#text("Thanks again")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2fa7592c66fc8b5eb40f8670c40c28516a0f8748bf791657509ffad4f77bb5ed-998038497aea5217ac4d52c5bf36132e08c78f8d54efdb7c8d3fc17635a78a1e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-250294")[#strong[#text("Matt")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2013")])]

#text("And 3!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d03d2663aaed4f124296c50e8de3a7c466dbf527114e3de71a7ca77cec007a33-1ebc3e45a75492c731559b534950bcfd6e62f34c9361344b489c2a1dc1396cb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Huen Yeong Kong")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-250351")[#strong[#text("Huen Yeong Kong")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2013")])]

#text("Please test this Maxima line on Maxima Online:")#linebreak()#text(" for n from 2 thru 20 do print(sum(f(n,n-k,n+k)*(is(equal(primep(n-k)*primep(n+k),true^2))-unknown)/(true-unknown),k,0,n));")#linebreak()#text(" First six outputs are shown here. all are twinprimes including identical primes.")#linebreak()#text(" f(2,2,2)")#linebreak()#text(" f(3,3,3)")#linebreak()#text(" f(4,3,5)")#linebreak()#text(" f(5,5,5)+f(5,3,7)")#linebreak()#text(" f(6,5,7)")#linebreak()#text(" f(7,7,7)+f(7,3,11)")

#text("These show that every prime is half the sum of two identical copies of itself. Therefore 1 should qualify as a prime i.e. 1 = (1+1)/2.")#linebreak()#text(" Huen Y.K.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c67be942530c47b7c6347ed73b57c2c5d5640949de5dfecbbacda8b87b7cc4e-fb079e79f4f30364ac2779e094811011902c763bd47b58900cc436db64f7530a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael van der Kolff")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-250368")[#strong[#text("Michael van der Kolff")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2013")])]

#text("It’s simply a question of what’s a useful definition. In stating the fundamental theorem of arithmetic, for example, and lots of others, we’d have to say “every prime except 1”, and when stating results about prime ideals we might have to say (when treating the ring as a ZZ module) “every prime apart from 1”, etc. So instead of doing that, we just exclude 1 from the definition.")

#text("Of course, if for your purposes you wish to define it to mean something different, then the only thing you have to do is define it that way in your paper.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d03d2663aaed4f124296c50e8de3a7c466dbf527114e3de71a7ca77cec007a33-1ebc3e45a75492c731559b534950bcfd6e62f34c9361344b489c2a1dc1396cb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Huen Yeong Kong")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-250359")[#strong[#text("Huen Yeong Kong")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2013")])]

#text("For more information on the above, please read my published paper:")#linebreak()#text(" Aditi Journal of Computational Mathematics")

#text("Volume 1 ( 2013 ) , Number 1")#linebreak()#text(" Previous | Next | Back")

#text("Development of General Twin-Prime Number System by the Method of Indirect Induction")

#text("Huen Yeong Kong")

#text("Pages 1-12")

#text("View Details Abstract References")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2fa7592c66fc8b5eb40f8670c40c28516a0f8748bf791657509ffad4f77bb5ed-998038497aea5217ac4d52c5bf36132e08c78f8d54efdb7c8d3fc17635a78a1e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-250533")[#strong[#text("Matt")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2013")])]

#text("Thanks for your thoughts (and time) – personally I don’t think 1 is a prime as it can be described as n to the power of 0")

#text("For the purposes of my conjecture I would exclude 1 as a prime and say that 2,3 and 11 are the only prime numbers that cannot be expressed as a sum of a number of unique primes (ie only using each prime once).")

#text("Thanks again")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-250536")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2013")])]

#text("Your remark on 2 and 3 are correct but not on 11 unless I interprete")#linebreak()#text(" incorrectly.. Here are the evidence::")#linebreak()#text(" f(11,11,11)+f(11,5,17)+f(11,3,19)")#linebreak()#text(" Therefore:")#linebreak()#text(" 11=(11+11)/2, 11=(5+17)/2, 11+3+19)/2")#linebreak()#text(" Huen y.K.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2fa7592c66fc8b5eb40f8670c40c28516a0f8748bf791657509ffad4f77bb5ed-998038497aea5217ac4d52c5bf36132e08c78f8d54efdb7c8d3fc17635a78a1e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-250548")[#strong[#text("Matt")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2013")])]

#text("Sorry I don’t understand Huen")

#text("11 cannot be expressed as a sum of lower unique primes (excluding 1)")#linebreak()#text(" There are only 3 ( 2,3,7)")

#text("eg")

#text("2 + 3 + 5 + 7 = 17")#linebreak()#text(" 2 + 3 + 7 = 12")#linebreak()#text(" 2 + 7 = 9")#linebreak()#text(" 2 + 5 = 7")

#text("etc")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2fa7592c66fc8b5eb40f8670c40c28516a0f8748bf791657509ffad4f77bb5ed-998038497aea5217ac4d52c5bf36132e08c78f8d54efdb7c8d3fc17635a78a1e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-250549")[#strong[#text("Matt")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2013")])]

#text("13 on the other hand can be expressed as:")

#text("2 + 11")

#text("or 7 is:")

#text("2 + 5")

#text("19 is:")

#text("2 + 17 etc")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-250553")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2013")])]

#text("Yes, your are right. I interpret wrong. I do agree that 1 should not be")#linebreak()#text(" defined as a prime because if it is done all primes from 2 to infinity")#linebreak()#text(" will become composites, e.g.:")

#text("factor((3) = 1*3")#linebreak()#text(" factor(23)=1*23 …")

#text("The whole natural number sequence except 1 will be composite only.")#linebreak()#text(" HuenYK")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9589787975dd757f09bfbdf86b22868f53e148b479ab2c7e34de8f948af10c8b-a9003188b370b1600cf9e712b2bed9c1fa9cb1259bb3337322ce9f5b2eb9c9d4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-255845")[#strong[#text("Jason")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2013")])]

#text("What am I missing.")

#text("3 is odd and cannot be represented by the summation of primes.")#linebreak()#text(" 11 is odd and cannot be represented by the summation of primes.")

#text("Doesn’t seem to be accurate.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2fa7592c66fc8b5eb40f8670c40c28516a0f8748bf791657509ffad4f77bb5ed-998038497aea5217ac4d52c5bf36132e08c78f8d54efdb7c8d3fc17635a78a1e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-256061")[#strong[#text("Matt")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2013")])]

#text("That was my point 2,3 & 11 are the only primes that cannot be expressed as a sum of lower unique (ie used only once in the sum) prime numbers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88ca4dcbb618f5c5e91c439083a81c88254c6bb9c64c723e27349d7332abb68c-8bce33cbfc1e20b8cfae623566009ad4734a09ec0116623b8ea8b053f023d285.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-2/#comment-463846")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2015")])]

#text("633 = 139+211+283 3 primes")#linebreak()#text(" 633 = 131+5+3+211+283 5 primes")#linebreak()#text(" 633 = 131+5+3+181+17+13+283 7 primes")#linebreak()#text(" 633 = 131+5+3+181+17+13+163+61+59 9 primes")#linebreak()#text(" 633 = 127+2+2+5+3+181+17+13+163+61+59 11 primes")#linebreak()#text(" 633 = 53+41+37+5+3+181+17+13+163+61+59 11 primes")#linebreak()#text(" 633 = 83+19+29+5+3+181+17+13+163+61+59 11 primes")#linebreak()#text(" 633 = 61+47+23+5+3+181+17+13+163+61+59 11 primes")

#text("and 11 primes is not the upper limit for 633. In fact a necessary and sufficient condition for an odd number N to be sum of 2k+1 primes is N greater than 4k+3.. Hence the numbers 3, 5, 7 and 9 can not be sum of 5 primes. the first odd number to be sum of 5 primes is 11, it happens it is a prime!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ce2f3d6b15795e810ec8257c444dabeed5fcdda8a85024769678d66fad747d7-d79bce078ff3927897af86fd88494d8f74e9fc87db67333baacbfea640abdd99.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luisrguzmanjr")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-125845")[#strong[#text("luisrguzmanjr")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2012")])]

#text("Congratulations Terry!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b10ac4dddfd7869b2f45dbb9f43d28f4237a8e4938892647fd83e295f13c555c-7f56189f74ed2bf31d239fb4220e5e79326b0012e1c36f7d501efdfae2728d25.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-125853")[#strong[#text("Paul")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2012")])]

#text("Congratulations, and thanks for the details!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5fae406c0f9c3934b25edda6f030527eccea3a511752c5648df02be30adb636d-9fb7f05bc365bb2ddacd153f9dab62df293cb762846a8d54d5c2b2e44afff724.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-125910")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2012")])]

#text("Every odd integer larger than 1 is the sum of at most five primes")

#text("41=2+3+5+7+11+13")

#text("Maybe a better title should be:")

#text("Every odd integer greater than 1 can be represented as the sum of five primes or less")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-125977")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2012")])]

#text("dude, 41 is a prime number itself")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126052")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2012")])]

#text("Obviously not every odd integer larger than 1 is the sum of at most 5 primes")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126057")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2012")])]

#text("I believe anon’s point is that the title is technically ambiguous. It’s a minor point and most/all mathematicians will automatically know what was intended, because this is a sort of grammatical oddity that is actually very common in the subject’s literature. But you could interpret the title to mean “every odd integer larger than 1 cannot be written as the sum of more than five primes.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126071")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2012")])]

#text("Read carefully what you say: “every odd integer larger than 1 cannot be written as the sum of more than five primes.”")

#text("41 CAN be written as the sum of 6 primes, hence the condition is not met")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126157")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2012")])]

#text("Prime but ODD…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee7af1aa460b0d695345aa8e7a5ce2a512f922efdb557467231417b37fa336db-68fab33e8e24a668c15eee3fedc46e3186851f2cf5a3703f54d201c5ddb9a3dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126637")[#strong[#text("Curious")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("so what? does exclude the title prime numbers?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126084")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2012")])]

#text("“For every odd integer larger than 1, there exists an equivalent integral sum expression of at most five primes.”")

#text("Hope you guys are happy now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e67a2b3df965651da7c8840f8efe7bac5d74a2b5184a8ed900651ceaaf7c4e8f-9bf5ebcb90a9a5948d45c0158db01a12de4388f334928150ef18214e6b5d12a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aadil Aman")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126594")[#strong[#text("Aadil Aman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2012")])]

#text("The thing that you are talking is a different issue. The statement “41 is the sum of at most five primes” means that every odd number you ll see can be either a prime number , if not then the sum of two primes or the sum of three primes or the sum of four primes and if not even this then definitely five primes.")

#text("Nowhere its mentioning that it can’t be sum of more than five numbers. Here at most precisely means that If you want to express any odd number greater than 1 as a minimum possible sum of primes then you can express it up to at most 5 primes, that’s the simple mathematical statement!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee7af1aa460b0d695345aa8e7a5ce2a512f922efdb557467231417b37fa336db-68fab33e8e24a668c15eee3fedc46e3186851f2cf5a3703f54d201c5ddb9a3dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126640")[#strong[#text("Curious")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("Yes, indeed it says that it can’t be sum of more than five numbers. it. IS … “At the most” means at the most, thus excluding 6. The correction for this should be instead of “is” to say “can be”.")

#text("I am wondering if this is a post for matemathicians that need a course on semantics and logic and basic algebra definitions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e67a2b3df965651da7c8840f8efe7bac5d74a2b5184a8ed900651ceaaf7c4e8f-9bf5ebcb90a9a5948d45c0158db01a12de4388f334928150ef18214e6b5d12a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aadil Aman")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126643")[#strong[#text("Aadil Aman")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("Yes it does! “At the most” means if you keep checking you don’t need to go for 6 primes numbers, that means for every odd integer greater than 1 every number is a sum of at most five prime no.s.")

#text("If you think you are right then give a counter example of an odd number which is NOT the sum of five or less than five prime numbers. According to this theorem you don’t have any such examples. (If you have then show it here!)")

#text("This theorem is perfectly logical and its proof is very very nice. I suggest you to go see and understand the proof. It may clear your doubt!")

#link("http://arxiv.org/pdf/1201.6656v2.pdf")[#text("Click to access 1201.6656v2.pdf")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee7af1aa460b0d695345aa8e7a5ce2a512f922efdb557467231417b37fa336db-68fab33e8e24a668c15eee3fedc46e3186851f2cf5a3703f54d201c5ddb9a3dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126672")[#strong[#text("Curious")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("The problem is that an odd number can be 2 things at the same time (at most of 5, and over 5).")

#text("The counterexample you pretend to give is not appropriate, since the fact that i cannot find it does not affect the fact that i can find the same number with 6 primes.")

#text("“Every odd integer larger than 1 is the sum of at most five primes”")

#text("This excludes 6. Even if the same number can be expressed at the same time with 5.")

#text("The Golbach conjecture says that an even number equal or greater than 4 is the sum of two prime numbers.")

#text("If you could show to me that an even number can be represented by the sum of 3 or more prime numbers, I would shut up.")

#text("Or any such theorems/hypothesis/conjectures well accepted in the literature where an similarity could be done with the title. It is superficially said above that such way to “talk” is common, but I have not seen any example.")

#text("A title that would have no ambiguities at all would be:")

#text("Every odd integer greater than 3 can be represented as the sum of five primes or less.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e67a2b3df965651da7c8840f8efe7bac5d74a2b5184a8ed900651ceaaf7c4e8f-9bf5ebcb90a9a5948d45c0158db01a12de4388f334928150ef18214e6b5d12a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aadil Aman")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126678")[#strong[#text("Aadil Aman")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("2+3+5+7+11=28 is an even no. and can be represented as sum of more than 3 primes. Isn’t that enough counter-example for your interpretation of Gold-Batch Conjecture??")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e67a2b3df965651da7c8840f8efe7bac5d74a2b5184a8ed900651ceaaf7c4e8f-9bf5ebcb90a9a5948d45c0158db01a12de4388f334928150ef18214e6b5d12a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aadil Aman")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126682")[#strong[#text("Aadil Aman")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("sorry it was 2+3+5+7+11=30!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee7af1aa460b0d695345aa8e7a5ce2a512f922efdb557467231417b37fa336db-68fab33e8e24a668c15eee3fedc46e3186851f2cf5a3703f54d201c5ddb9a3dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126702")[#strong[#text("Curious")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("Ok. I was going to write that I would shut up forever, since that is exactly what I was asking for to understand.")

#text("BUT. Before finally giving up I checked the definition of the Goldbach conjecture in wolfram mathematica, that seems to be a reliable source. And then my surprise: they do not use “is”, the use “can be” (Exactly my point):")

#text("As re-expressed by Euler, an equivalent form of this conjecture (called the “strong” or “binary” Goldbach conjecture) asserts that all positive even integers greater or equal than 4 CAN BE expressed as the sum of two primes.")

#text("Even wikipedia does not use “IS”, uses “can be”.")

#text("If wolfram definition /wikipedia would not be “CAN BE expressed” I would understand that mathematicians agree in this misleading language. But the point is that it is not the case.")

#text("Then, I insist again. It should say “can be expressed” and not “is”.")

#text("I really doubt that the oxford university is arbitrarily substituting the “is” for “can be represented” just for fun or casuality with my arguments.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1388c26e46167f886eec40287c1215659083212ef33199428ba2e17b4803fab-ebf2d8b13852d8ea3f6177d126cbc9c2518b2fb847792fd750e5fe1cfeffa3cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of new guy")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-222974")[#strong[#text("new guy")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2013")])]

#text("You’re missing the point. The phrase is used in the relevant literature and so it is well understood in that context. However, in standard English, “at most” would typically imply “not more than”. For example, if you can take at most 2 pieces of luggage onto a plane, it means you can’t take 3 pieces of luggage.")

#text("The analogous conclusion would be that “41 is the sum of at most 5 primes” means you can’t find 6 primes adding up to 41. That’s why the current title is slightly problematical outside of the context of the relevant literature. Obviously this isn’t actually a big deal, just a grammatical quirk.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16d38f5ec0d71264904b47b088cbcbbf16a95b8482fbe18c9255189ccb78664c-3e906f74d4f14c553a7f99d010ebf8af0f171ac6755e38a92b252ab2644bea72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rob Seaman")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126933")[#strong[#text("Rob Seaman")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2012")])]

#text("Make that “five primes or fewer”, not “less”. That said, a concise but somewhat imprecise title is often better than a much longer pedantically correct version. The title benefits from the context of the paper itself, but also of the very rich literature in this area.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee7af1aa460b0d695345aa8e7a5ce2a512f922efdb557467231417b37fa336db-68fab33e8e24a668c15eee3fedc46e3186851f2cf5a3703f54d201c5ddb9a3dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of curious")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-127600")[#strong[#text("curious")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2012")])]

#text("It is not about to be pedantic, it’s about accuracy. Is the university of oxford university pedantic when correctly expressing the Goldbach conjecture -namely, (1) excluding the number 4 [as here should be done for the number 3] and (2) replacing “is” by “can be”?")#linebreak()#text(" It is as well rich the literature where you can read “with a mass of 1kg”… but it does not mean that is correct.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26f15258f2b5502af22d190d1d224fcfa1e4eeddc42feef0dbb10cd83ce381f3-c040b178f55636f6a721cf117ebd76c776b1d0ab1b023170add3265ef853f715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hasler (@hasler)")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-143092")[#strong[#text("hasler (@hasler)")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2012")])]

#text("and what is wrong with “a mass of 1kg” ?! o.O")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-127097")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2012")])]

#text("Also, what’s wrong with “natural numbers” instead “integers greater than 1”? he says, nitpicking & completely missing the awesomeness of the theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0bc0d861b7d3ced07b9f0a8264afb1dcc49117eb873583e2cb8a4cc18ea3047d-2a0e0decb4fc47612dadfb1e8366cf8d794a031180255f35fd76605065504d95.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richie")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-127098")[#strong[#text("Richie")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2012")])]

#text("Also, what’s wrong with “natural numbers” instead “integers greater than 1”? he says, nitpicking & completely missing the awesomeness of the theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-132883")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2012")])]

#text("“Every odd integer greater than 1 could be expressed as the sum of 5 primes or less.”")

#text("I think it should be “It is possible for every odd integer greater than 1 to be expressed as the sum of at most five primes”…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-170546")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2012")])]

#text("41=7+11+23")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21daf14ff491875b029db719ec94e01f4ddb274c27bf5acef738ee325325d3e3-773948677d23b7923ab697746c666267172b340efaf97ed4116c1adfa9c99d0b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-446030")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2014")])]

#text("41 = 11 + 13 + 17")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1845855ddd9fc8e3ebbf65e946a634fb73a8969b20b6b61117c39b328c16058d-eac5f7d4d040e89d74de72547c5745a148d40cd4dc3e7741dbbf7bedf2643065.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Knuth-Super-Fan")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-125927")[#strong[#text("Knuth-Super-Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2012")])]

#text("Brilliant result! By far the best I’ve seen this year.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3512d6ccd15b35a027d0f62325d9b3c005ed8221b415d92d5d134f33fb9a74de-614b5d2a379b65d2eec1d1b6612c74948fa045935f4b4b561160cfd3c34d8d18.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-125933")[#strong[#text("Nick")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2012")])]

#text("This is awesome!")

#text("BTW: Theorem 1.5 in your arxiv pdf has a minor typo; search “zeries” to find it quickly.")

#emph[#text("[This will be corrected in the next revision, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec897fddfce5bb6f7a4e40120bf14ef161bdc401b1266ef2907b1ee818b1f654-3e1cd23a56191243c151a1d57af0cff0323b4df8859b51d96a2402ffb3ab9a85.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-125937")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2012")])]

#text("Section 4, “Basic bounds on S_{\\eta,q}(x,\\alpha)”, paragraph two, has a minor typo. ‘The purpose of this section is to …’ seems to be what was intended.")

#emph[#text("[This will be corrected in the next revision, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02e1a57fd0c917793907bc85f2843b2a9445fad397e2c6c7bf9c2a34154590bc-7337d18678c989e5944c6beea78b768ba9bb066a0b5242a16e6c3ea26c61225a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-125939")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2012")])]

#text("Very minor TeX: in references section [10] Gourdon, Demichel, the number 10^13 should have 3 within superscript.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac1e0543e551f843b22369882fccb8d09eff85db7d3c56acbf18129a5f9a5897-6084e9a7d9a7c41704f462de582d63bd72babdabc512a14cfe0c479ec1491123.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erik Crevier")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-125949")[#strong[#text("Erik Crevier")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2012")])]

#text("Incredible!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-125956")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2012")])]

#text("Kaniecki, Leszek (1995). “On Šnirelman’s constant under the Riemann hypothesis”. Acta Arithmetica 4: pp. 361–374")#linebreak()#text(" shows the same result under Riemann Hypothesis.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e08207609b01b3ff77c889101f1923c9255d7218f3973e17fe5bc78d0b7f68b7-5d53e31ea86fc4af3a287d73fd63dea5360d5790ea80ef208b13f8ee7860964a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mario")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-125968")[#strong[#text("Mario")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2012")])]

#text("even as a physicist, the paper is very good to read (while not understanding all details, the main ideas are clear). thank you! :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a718fe0ae1ce222ea33275174bc93b6011081a9ba6d690bd7cf9c39f0317e62a-6170224188d25c8da1133b3e3d9c851d6c93c48eb9e4532aaaf759d38dceb8b4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mfrasca")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-125981")[#strong[#text("mfrasca")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2012")])]

#text("Excellent!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126028")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2012")])]

#text("Consider the shorthand notation {1^\\theta} rather than {e(\\theta)} for {e^{2\\pi i \\theta}}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126030")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2012")])]

#text("A couple of things I think you should correct are")

#text("1) a typo occurs at page 3,eq. (1.4); by the PNT, the L^2 estimate for S should be X \\log X and not \\log X")

#text("2) the use of smoothed version of S is well known; in fact the original Hardy-Littlewood approach uses an infinite series over primes weighted with an exponential weight. See HL, partitio numerorum III. This should be mentioned in the introduction, I think.")

#emph[#text("[These will be addressed in the next revision of the ms – thanks! – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126036")[#strong[#text("Not quite Goldbach but… | Degree of Freedom")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2012")]

#text("[…] to be peer reviewed but the probability that it’s correct is pretty high. Tao has a nice discussion and summary of his approach on his blog — although it employs some powerful modern mathematical tools, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/461f9cee8215c2b3754538fc5b63812f9d31ae02fc7bd116afeec8a218943930-7d1a78bdebb5e3c8fae6eacd3079a261b1de5b5cda86877040a0d5271b2e2fa9.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Claver")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126064")[#strong[#text("Claver")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2012")])]

#text("Please excuse me for going slightly off-topic, but I have a question regarding series. Is it possible to prove that in the binomial (x + y)^(k) the coefficient of the y^(2)-term >> +infinity when k >>+ infinity?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5eaedcfbfddec51fe3efbe89c21c6a9ad9cab4e92db6fa7dd65b81493d6dbf4-9fe1b54a363b2a8189eb66e31d0de32801b2b4bf4ff52512e116c70e86b78886.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126261")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2012")])]

#text("when k >> infinity? lol. Anyway, we have x^k + kx^(k-1)y + k(k-1)/2 x^(k-2)y^2, where x^k dominates k^2 in any case unless x is 1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef274d11880037ea629ae972bcf0876424d7bd85aa3fad3774cfe54b805430e5-b51040075ba8e8cc84fa990daad1df3a25b900317227e5b137367ad42509c471.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Claver")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126531")[#strong[#text("Claver")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2012")])]

#text("Thank you.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef274d11880037ea629ae972bcf0876424d7bd85aa3fad3774cfe54b805430e5-b51040075ba8e8cc84fa990daad1df3a25b900317227e5b137367ad42509c471.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Claver")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126530")[#strong[#text("Claver")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2012")])]

#text("I apologise for my confusing notation. By k >> +infinity I mean to say that k ‘approaches + infinity’ and NOT k ‘is much greater than +infinity’.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126065")[#strong[#text("Matematikos būrelis » Kiekvienas nelyginis natūralusis skaičius, didesnis už 1, yra ne daugiau kaip 5 pirminių skaičių suma")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2012")]

#text("[…] Apie rezultatą galima paskaityti ir Tao tinklapyje. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/461f9cee8215c2b3754538fc5b63812f9d31ae02fc7bd116afeec8a218943930-7d1a78bdebb5e3c8fae6eacd3079a261b1de5b5cda86877040a0d5271b2e2fa9.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Claver")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126081")[#strong[#text("Claver")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2012")])]

#text("Terry,")

#text("Congragulations on your paper.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of magnus carlsen")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126082")[#strong[#text("magnus carlsen")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2012")])]

#text("very impressive results professor tao.")

#text("congrats")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a382183d3ed7cf33b841b9044414e6aa0b91df1f4ea991fed59aa4ff2caf406-aa091041e3d91f48464237b83b2439f11d347b3a9aaa0c27dc2e4ef3724cb570.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of g")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126093")[#strong[#text("g")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2012")])]

#text("Very nice!")

#text("In section 2 you define floor(x) — well, actually the usual broken-bracket notation — to be “the greatest integer less than x”. Is that, rather than “the greatest integer not exceeding x”, really what you meant? It means that, e.g., [4] = 3, which is not the usual convention.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d31475e62be6e7a99df57f43f6acf5e8dc1beebc2546c53272dcc0f1d26639e7-a3e344f3d88c2c4d60a6ca8aa96f125383154a969d654c5cba6cf34d5835f115.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mario")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126228")[#strong[#text("Mario")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2012")])]

#text("May I ask you – how long did you work on this specific topic?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126478")[#strong[#text("Big News in Number Theory « Mr Toms MathPhys Extravaganza")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2012")]

#text("[…] is a pretty big step forward I think. For details, see Terence’s blog and the paper […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126521")[#strong[#text("Todo número impar mayor que 1 se puede obtener sumando a lo sumo cinco números primos [ENG] | Cuéntamelo España")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2012")]

#text("[…] » noticia original Comparte CommentsPowered by Facebook Comments […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee7af1aa460b0d695345aa8e7a5ce2a512f922efdb557467231417b37fa336db-68fab33e8e24a668c15eee3fedc46e3186851f2cf5a3703f54d201c5ddb9a3dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126524")[#strong[#text("Curious")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2012")])]

#text("And what happens with the number 3 ? You mean 3+0 ? 2+1?")#linebreak()#text(" Please explain to me. The algebraic sum is not defined for only one term. Then your theorem is not valid for the number 3.")#linebreak()#text(" I think you are using the old terminology of Goldbach when he considered 1 as a prime.")#linebreak()#text(" If the answer is that you can only sum one term, then the theorem should be reducible to “any COMPOSITE odd number….” since for the prime numbers would be trivial case.")#linebreak()#text(" In any case I find this unacceptable with the definition of sum.")#linebreak()#text(" I am no mathematician… then I must be wrong.")#linebreak()#text(" In what am I wrong?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02e1a57fd0c917793907bc85f2843b2a9445fad397e2c6c7bf9c2a34154590bc-7337d18678c989e5944c6beea78b768ba9bb066a0b5242a16e6c3ea26c61225a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126593")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2012")])]

#text("Sums are defined for one term. For example, the expression x_1 + x_2 + … + x_n for n=1 is x_1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee7af1aa460b0d695345aa8e7a5ce2a512f922efdb557467231417b37fa336db-68fab33e8e24a668c15eee3fedc46e3186851f2cf5a3703f54d201c5ddb9a3dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126620")[#strong[#text("Curious")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("According this “redefinition of sum” the Goldbach conjecture as said by Euler would not say greater or equal than 4, rather would include all even numbers, namely the number 2.")#linebreak()#text(" I think Euler is on my side.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02e1a57fd0c917793907bc85f2843b2a9445fad397e2c6c7bf9c2a34154590bc-7337d18678c989e5944c6beea78b768ba9bb066a0b5242a16e6c3ea26c61225a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126653")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("Goldbach’s conjecture is about sum of two primes, not at most two primes. See Wikipedia.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee7af1aa460b0d695345aa8e7a5ce2a512f922efdb557467231417b37fa336db-68fab33e8e24a668c15eee3fedc46e3186851f2cf5a3703f54d201c5ddb9a3dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126674")[#strong[#text("Curious")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("I insist then in the other argument. Look for definition of addition in any book of algebra and try to find if it is possible to sum “only one sumber”.")#linebreak()#text(" See wikipedia as well. The summation allows it. The sum (addition), does not allow it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee7af1aa460b0d695345aa8e7a5ce2a512f922efdb557467231417b37fa336db-68fab33e8e24a668c15eee3fedc46e3186851f2cf5a3703f54d201c5ddb9a3dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126684")[#strong[#text("Curious")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("yes. stupid argument on my side. but plese give me a hint on a sum (=addition) with only one term.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e67a2b3df965651da7c8840f8efe7bac5d74a2b5184a8ed900651ceaaf7c4e8f-9bf5ebcb90a9a5948d45c0158db01a12de4388f334928150ef18214e6b5d12a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aadil Aman")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126592")[#strong[#text("Aadil Aman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2012")])]

#text("Sir,")#linebreak()#text(" This is not my doubt.. but I would be happy to know its answer")

#text("“Does the theorem say this is always possible with a set fo primes that has no repeats? e.g., would (3+3+3) be enough to demonstrate that this holds for 9?” (doubt of Vynce Montgomery I saw in a post of G+)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ca7fa99d5b810939593a9768abe9550d75c821ad9f0521c9a04dc9aefda57c1-f5276740f5ea4b9ae6a694b62047cdcb28a8fe48eca26fe5dbc9a9cbf337af95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D555")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126600")[#strong[#text("D555")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2012")])]

#text("Reblogged this on ")#link("http://kriptusagroup.wordpress.com/2012/02/05/1697/")[#text("KRIPTUSA´s Blog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee7af1aa460b0d695345aa8e7a5ce2a512f922efdb557467231417b37fa336db-68fab33e8e24a668c15eee3fedc46e3186851f2cf5a3703f54d201c5ddb9a3dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126611")[#strong[#text("Curious")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("anon, You know what the problem I have? That sum can be translated into Spanish either as “addition” (suma=adición) or “summation” (sumatorio) to the diffence of English. If I am not wrong, SUM in English is at the same time addition and the short for summation.")

#text("I think that we are talking about two things. sum (addition, +) and sum(mation, epsilon).")

#text("I understand that the addition is by definition containing more than one terrm (all definitions I checked so far say that since the operator + needs two terms on each side, it is impossible to sum or add one element of a set to nothing, in any case to 0 that is not prime).")

#text("On the other hand, the summation by definition allows the existence of only one term.")

#text("Then the theorem when it is used “addition” (suma) should not be true for 3. If I am right. It would be correct is sum is translated as “summation”.")

#text("In other words, the addition in algebra is defined for one term? I do not think so. And: is summation defined for one term? I think yes.")

#text("Or is addition possible for only one term?")

#text("Thanks in advance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-469644")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2016")])]

#text("see here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/")[#text("Every odd integer larger than 1 is the sum of at most five primes")]
]

#text("i think the loose definition is why there are so many discussions of definitions in this thread. this definition maybe serves all parties.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee7af1aa460b0d695345aa8e7a5ce2a512f922efdb557467231417b37fa336db-68fab33e8e24a668c15eee3fedc46e3186851f2cf5a3703f54d201c5ddb9a3dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126613")[#strong[#text("Curious")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("And… on the other hand, if sum is not considered as addition, I can demonstrate very fast this theorem, that would be absurd to claim:")#linebreak()#text(" Every prime is the sum of at most five primes.")#linebreak()#text(" Even Every prime is the sum of at most ONE prime")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee7af1aa460b0d695345aa8e7a5ce2a512f922efdb557467231417b37fa336db-68fab33e8e24a668c15eee3fedc46e3186851f2cf5a3703f54d201c5ddb9a3dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126617")[#strong[#text("Curious")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("And to finish. If the title of the article would be right, the Goldbach Conjeture as redifined by Euler would be all positive integers, and not restricted to greater than 4, as it says now.")

#text("From wolfram website:")#linebreak()#text(" As re-expressed by Euler, an equivalent form of this conjecture (called the “strong” or “binary” Goldbach conjecture) asserts that all positive even integers GREATER THAN 4 can be expressed as the sum of two primes.")

#text("So, I am fully convinced that the title of this paper is plainly wrong ;-( The sum is understood as addition, and not only summation in degenerated state.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee7af1aa460b0d695345aa8e7a5ce2a512f922efdb557467231417b37fa336db-68fab33e8e24a668c15eee3fedc46e3186851f2cf5a3703f54d201c5ddb9a3dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126618")[#strong[#text("Curious")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("Sorry, it says greater or equal to 4, that it does not change anything on my arguments and conclusion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee7af1aa460b0d695345aa8e7a5ce2a512f922efdb557467231417b37fa336db-68fab33e8e24a668c15eee3fedc46e3186851f2cf5a3703f54d201c5ddb9a3dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126619")[#strong[#text("Curious")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("The point was the Goldbach conjecture EXCLUDES the even number 2, since it cannot be expressed as the sum of two positive primes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3d006f676961ae0d4d5fa854f9d5b1cb0e439ac5f1d886687f0bb4ef65222df-ab750c2e18ae1a3f7e60bcbf11396199e5e5745a319d6c7b33c8c445118c3c18.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ??")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126697")[#strong[#text("??")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("2=1+1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee7af1aa460b0d695345aa8e7a5ce2a512f922efdb557467231417b37fa336db-68fab33e8e24a668c15eee3fedc46e3186851f2cf5a3703f54d201c5ddb9a3dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126703")[#strong[#text("Curious")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("?? is 1 prime?? lol")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3d006f676961ae0d4d5fa854f9d5b1cb0e439ac5f1d886687f0bb4ef65222df-ab750c2e18ae1a3f7e60bcbf11396199e5e5745a319d6c7b33c8c445118c3c18.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ??")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126706")[#strong[#text("??")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("I think so!")

#text("1 is just divided by 1 and itself (??)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee7af1aa460b0d695345aa8e7a5ce2a512f922efdb557467231417b37fa336db-68fab33e8e24a668c15eee3fedc46e3186851f2cf5a3703f54d201c5ddb9a3dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Riemann")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126712")[#strong[#text("Riemann")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("definition of prime, strictly, excludes 1 :-)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22f0c527e265ed08bd12642d5c1becf053e15382d9ea72dfe4ee2982b6db1158-15b89af7dcc74921a108c6a3119208f32d5987777eb434a392002e8a41b551da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérôme Chauvet")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-127719")[#strong[#text("Jérôme Chauvet")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2012")])]

#text("Can’t help imagine the guy bumping on that comment as he enters Terry’s blog for the first time. He would say: “Waooo, there’s big mathematics to learn here!”")

#text("So I would like to put my stone to your wall, and add the following :")

#text("2 + 1 = 3")

#text("You don’t need to be thankful (it’s completely free of charge)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee7af1aa460b0d695345aa8e7a5ce2a512f922efdb557467231417b37fa336db-68fab33e8e24a668c15eee3fedc46e3186851f2cf5a3703f54d201c5ddb9a3dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126638")[#strong[#text("Curious")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("Would be great that the one(s) disagreeing with me would explain why…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22f0c527e265ed08bd12642d5c1becf053e15382d9ea72dfe4ee2982b6db1158-15b89af7dcc74921a108c6a3119208f32d5987777eb434a392002e8a41b551da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérôme Chauvet")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-127720")[#strong[#text("Jérôme Chauvet")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2012")])]

#text("Dear Curious,")

#text("I look so confused, so let me explain it to you : This is Pr. Tao’s blog here, so it is not well seen by many of his young fans to critisize the title he chose for his article. This is in fact a pre-print, which means it can still be corrected in the final version.")

#text("Now we all know what a “pre-print” means : carefulness and further corrections.")

#text("Best,")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d06a1da18a50ebc7a9bfb52c1488f8b1a998309feb22dce5101294227f315c7-850f082c8d3a111855639dec6fb204547f5e05cffd889ab402a4d777c019ede9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126656")[#strong[#text("Giovanni")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("Almost two or three the infinity is gone! Congratulation!!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee7af1aa460b0d695345aa8e7a5ce2a512f922efdb557467231417b37fa336db-68fab33e8e24a668c15eee3fedc46e3186851f2cf5a3703f54d201c5ddb9a3dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Riemann")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126704")[#strong[#text("Riemann")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("In the paper, it is mentioned twice the relationship with the Riemann hypothesis. If the latter would not be true, would the demonstration of the paper still be valid?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3d006f676961ae0d4d5fa854f9d5b1cb0e439ac5f1d886687f0bb4ef65222df-ab750c2e18ae1a3f7e60bcbf11396199e5e5745a319d6c7b33c8c445118c3c18.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ??")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126708")[#strong[#text("??")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("As far as I understood, the proof is independent from Riemann’s hyp. If it is false (is this going to be proved???) would not be a problem, anyway. Conversely, since Riemann hypoth implies that paper, IF that paper would be false (it is not) then Riemann would be false (??).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee7af1aa460b0d695345aa8e7a5ce2a512f922efdb557467231417b37fa336db-68fab33e8e24a668c15eee3fedc46e3186851f2cf5a3703f54d201c5ddb9a3dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Riemann")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126711")[#strong[#text("Riemann")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("Tx.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a382183d3ed7cf33b841b9044414e6aa0b91df1f4ea991fed59aa4ff2caf406-aa091041e3d91f48464237b83b2439f11d347b3a9aaa0c27dc2e4ef3724cb570.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of g")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126714")[#strong[#text("g")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("Giovanni, the number of primes needed was already known to be finite but I think the previous number was absurdly large — every positive integer is the sum of at most 100,000 primes, or something like that.")

#text("Riemann, it was already known that if the Generalized Riemann Hypothesis is true then 3 primes suffice for all odd numbers and that if the plain ordinary Riemann Hypothesis is true then 5 primes suffice for all. Prof. Tao’s recent work shows that the second of these is true without RH.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe5abad82d1b11c42452250f551c9ae384aa46339448bf281fe909359bb9389e-a4adb42b2cc858da8f4b388f7068a08411f69046d7e6b39d8c2235ec3096678a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kgourgou")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126789")[#strong[#text("kgourgou")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("Reblogged this on ")#link("http://inlieuofabettertitle.wordpress.com/2012/02/06/149/")[#text("Between numbers")]#text(" and commented:")#linebreak()#text(" Check this beautiful result! Even if you don’t know anything about number theory, this theorem leaves you pleasantly shocked. Kudos to professor Terence Tao. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d06a1da18a50ebc7a9bfb52c1488f8b1a998309feb22dce5101294227f315c7-850f082c8d3a111855639dec6fb204547f5e05cffd889ab402a4d777c019ede9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126854")[#strong[#text("Giovanni")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2012")])]

#text("g, do you mean that the number of primes to do a number (infinity) is finite?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d06a1da18a50ebc7a9bfb52c1488f8b1a998309feb22dce5101294227f315c7-850f082c8d3a111855639dec6fb204547f5e05cffd889ab402a4d777c019ede9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126860")[#strong[#text("Giovanni")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2012")])]

#text("Or the number of times for do a integer is finite?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126881")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2012")])]

#text("Please excuse this question if it is answered in your preprint (I did skim through it). Is there something that prevents your methods from showing that every even integer is the sum of 4 or less primes? (which seems to be somewhere inbetween the odd Goldbach conjecture and your result)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126889")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2012")])]

#text("Well, in my paper I spend two of the five primes by using the existing numerical verification of the even Goldbach conjecture that every even number between 4 and ")#mi("4 \\times 10^{14}")#text(" is the sum of two primes. As such, the problem reduces to a variant of the three-primes problem in which one is trying to represent a large number as the sum of three odd primes and a number less than ")#mi("4 \\times 10^{14}")#text(". This has the effect of restricting to a single major arc in the circle method, namely the one near the zero frequency, for which one can use the (very substantial) numerical work on the Riemann hypothesis.")

#text("To mimic this for the four-primes problem, one could try to write a large number as the sum of three primes and a prime less than, say, 10^12. The Fourier transform of the von Mangoldt function on the latter set can be computed numerically (and one can use GRH to predict in advance what the statistics of that Fourier transform will be). However, it will not be completely localised to the principal major arc at 0, but will also have some presence at other rationals a/q for small values of q, simply because the primes involved will mostly be coprime to q. Because of this, when the time comes to apply the circle method, one will eventually have to obtain good prime number theorems in arithmetic progression modulo q for small q, or equivalently to use zero-free regions for Dirichlet L-functions with conductor q. There is certainly some numerical work in this direction, but it is nowhere near as strong as what is known for the Riemann zeta function. As a consequence, I would expect that in the absence of some new ideas, the methods here might be able to show that every even number larger than, say, ")#mi("10^{200}")#text(", is the sum of four primes, but probably would fall short of solving the four-primes problem completely. (I haven’t actually done the calculation, though.)")

#text("Similarly, I would imagine that one could insert the bounds here (together with recent work on zero-free regions for Dirichlet L-functions, such as that of Kadiri) to improve the Chen-Wang result on the three-primes problem to lower the current threshold of ")#mi("10^{1300}")#text(" to something a bit smaller (I would guess something like ")#mi("10^{400}")#text(", though again I have not actually done the calculation, and these guesstimates may be too conservative).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d06a1da18a50ebc7a9bfb52c1488f8b1a998309feb22dce5101294227f315c7-850f082c8d3a111855639dec6fb204547f5e05cffd889ab402a4d777c019ede9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126897")[#strong[#text("Giovanni")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2012")])]

#text("The number of possibilities is different from number of certainties…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5984218a9b2b075fe5b56777623b2ad7105a68c02851645c68b43a36d303e0fe-6071fd7255dc2dc3cfe34b4717111edc63fc626958a8ddb601d254afd37d4023.gif", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bennett Gardiner")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126977")[#strong[#text("Bennett Gardiner")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2012")])]

#text("Out of curiosity, what is the first number that requires 5 primes to write it as a sum of primes?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-126994")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2012")])]

#text("If you subtract 3 from any odd number you can just use the Goldbach conjecture to express the remainder as the sum of two primes. So no positive number requires 5 primes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bd80c8467bab10a3ca10faba90b7dc5076b8c0adfc5f7350f0a0509b8f02f87-085efbd83d2c1ce530e772a4e5e2c62ef9f1533204ee2a681b4a24259944f687.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SRM")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-142846")[#strong[#text("SRM")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2012")])]

#text("Bennett: As I understand it, Tao’s proof proves that all possible numbers should never need more than 5, but all numbers that we’ve ever actually tested need at most three (two for the even numbers, three for the odd numbers). Tao has proved an upper bound in theory, but in practice, the upper bound is less than that. So nothing requires all five, but in theory, there may be such a number way way way out along the number line… or it may be that someone will find a better proof in the future that brings that upper bound down.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-175221")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2012")])]

#text("Bennett: The Goldbach conjecture asserts that every odd integer can be written as a sum of three primes (or equivalently, that every even integer can be written as the sum of two primes), and these conjectures are widely believed to be true. If we could show that there was an integer which could not be written as the sum of four primes (i.,e, if we could find an integer that needed five primes), then this would disprove the Goldbach conjecture.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-127017")[#strong[#text("Every odd integer is the sum of at most five primes: Fields medalist Terry Tao cracks… | Die wunderbare Welt von Isotopp")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2012")]

#text("[…] Reshared post from +Jennifer Ouellette Every odd integer is the sum of at most five primes: Fields medalist Terry Tao cracks Goldbach conjecture-type problem ")#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-")[#text("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-")]#text("… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1991f0a3c618e0c054a7c32e854540e9ca8581ab4380b656501eff89ec2f097c-b61a53ab054931a98dcb61b225df2fb583a09b90c355ba83a7f151778b4efab4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Baillie")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-127644")[#strong[#text("Robert Baillie")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2012")])]

#text("Dear Professor Tao,")

#text("Your paper does not make use of the most extensive computation results. If you had, would all your conclusions be the same?")

#text("Is there any hope that more extensive computational results could enable you to replace “at most ive primes” with “at most four primes” ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-127669")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2012")])]

#text("Unfortunately, to get to at most four primes by this method, one would start having to get good prime number theorems in arithmetic progressions, which would require some numerical work on GRH in addition to RH. There is such work out there, but it is nowhere near as strong as the numerical work on RH.")

#text("On the other hand, if one inserted the best numerical work on the even Goldbach problem, it would be possible to reduce the reliance on Vinogradov-type results. Currently I am using the strongest known result in this direction, namely that every odd integer greater than ")#mi("\\exp(3100)")#text(" is the sum of three odd primes, proven by Liu and Wang. If one used, for instance, the even Goldbach numerics up to ")#mi("10^{17}")#text(" (instead of ")#mi("4 \\times 10^{14}")#text(") then I could replace the Liu-Wang result with the earlier result of Chen and Wang that used ")#mi("\\exp(99012)")#text(" instead of ")#mi("\\exp(3100)")#text(". Also, better numerics would also give more precise bounds on the number of representations of an odd number as the sum of at most five primes (though actually my method does not count all such solutions, but rather a somewhat technical weighted subcount of these solutions, so this refinement would not be of much external interest).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of magnus carlsen")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-128135")[#strong[#text("magnus carlsen")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2012")])]

#text("is it possible using the methods of this paper to prove that every even number can be written as a sum of at most 5 primes too?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-128140")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2012")])]

#text("Unfortunately not; this problem is in fact more or less equivalent to the question of whether every even number can be written as the sum of at most four primes, since to express an even number as the sum of five primes, the five primes cannot all be odd, and so one of them must equal two.")

#text("On the other hand, it is a corollary of the odd five primes result that every even number can be expressed as the sum of at most six primes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-128731")[#strong[#text("Transterrestrial Musings - A New Theory About Primes")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2012")]

#text("[…] it seems misleading to me. The title implies that an odd number could be the sum of two, three, four or five primes, but two […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-128837")[#strong[#text("Algunos resultados camino de la conjetura de Goldbach - Gaussianos | Gaussianos")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2012")]

#text("[…] Tao resume este trabajo en su blog: Every odd integer larger than 1 is the sum of at most five primes. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-129025")[#strong[#text("The Math Factor Podcast » HM. Five Cards")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2012")]

#text("[…] see: First, the “Big News“, a discussion of Carlos May, and another puzzle (a pretty easy […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/990c7be3dc2c06a1617636ed3f9edd668ee9c69e1fb32115b6c4368b98c0a876-a4c9176d47b7311b65611108e1b68e645860a85c93e1a1853ef027f653471528.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shuhua Zhang")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-131121")[#strong[#text("Shuhua Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2012")])]

#text("Reblogged this on ")#link("http://zhangsh.wordpress.com/2012/03/02/33/")[#text("star dust")]#text(" and commented:")#linebreak()#text(" Surprisingly, I could understand most of this post. Tao’s power in exposition is always amazing, in addition to his power in mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-131634")[#strong[#text("Where am I heading to? | weishengx")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2012")]

#text("[…] the results be all odd integers larger than 1 can be expressed in sum of no more than five primes every odd integer larger than 1 is the sum of at most five primes. But most importantly, it brings us incessant challenge, so those guys who seeks for significance […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35c65fd371e7790b1cbb2810e28f89b97b9221e060b8c39639a57ba1f64d4d3f-b34329660638148f6ce3a28539f6c646b62e93aeea91e2ac712105e40acf9b84.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Every odd number greater than 1 is the sum of at most five primes « Suhaimi Ramly")]], [#link("https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-primes/comment-page-1/#comment-134948")[#strong[#text("Every odd number greater than 1 is the sum of at most five primes « Suhaimi Ramly")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2012")])]

#text("[…] up on the paper: https://terrytao.wordpress.com/2012/02/01/every-odd-integer-larger-than-1-is-the-sum-of-at-most-five-… Share this entry:Like this:LikeBe the first to like this […]")
]
