// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/11/13/254a-notes-9-applications-of-the-structural-theory-of-approximate-groups/
// Converted to Typst by tao2typ: "2026-10-14T15:18:16.835739+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 9: Applications of the structural theory of approximate groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 9: Applications of the structural theory of approximate groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 November 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/11/13/254a-notes-9-applications-of-the-structural-theory-of-approximate-groups/")[#text("https://terrytao.wordpress.com/2011/11/13/254a-notes-9-applications-of-the-structural-theory-of-approximate-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the ")#link("https://terrytao.wordpress.com/2011/11/06/254a-notes-8-the-microstructure-of-approximate-groups/")[#text("last set of notes")]#text(", we obtained the following structural theorem concerning approximate groups:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" ")#metadata(none) <tao-0369a36fe856043f6475>#text(" Let ")#mi("{A}")#text(" be a finite ")#mi("{K}")#text("-approximate group. Then there exists a coset nilprogression ")#mi("{P}")#text(" of rank and step ")#mi("{O_K(1)}")#text(" contained in ")#mi("{A^4}")#text(", such that ")#mi("{A}")#text(" is covered by ")#mi("{O_K(1)}")#text(" left-translates of ")#mi("{P}")#text(" (and hence also by ")#mi("{O_K(1)}")#text(" right-translates of ")#mi("{P}")#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Under some mild additional hypotheses (e.g. if the dimensions of ")#mi("{P}")#text(" are sufficiently large, or if ")#mi("{P}")#text(" is placed in a certain “normal form”, details of which may be found in ")#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/")[#text("this paper")]#text("), a coset nilprogression ")#mi("{P}")#text(" of rank and step ")#mi("{O_K(1)}")#text(" will be an ")#mi("{O_K(1)}")#text("-approximate group, thus giving a partial converse to Theorem ")#link(<tao-0369a36fe856043f6475>)[#text("1")]#text(". (It is not quite a full converse though, even if one works qualitatively and forgets how the constants depend on ")#mi("{K}")#text(": if ")#mi("{A}")#text(" is covered by a bounded number of left- and right-translates ")#mi("{gP, Pg}")#text(" of ")#mi("{P}")#text(", one needs the group elements ")#mi("{g}")#text(" to “approximately normalise” ")#mi("{P}")#text(" in some sense if one wants to then conclude that ")#mi("{A}")#text(" is an approximate group.) The mild hypotheses alluded to above can be enforced in the statement of the theorem, but we will not discuss this technicality here, and refer the reader to the above-mentioned paper for details.")
]

#text("By placing the coset nilprogression in a virtually nilpotent group, we have the following corollary in the global case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2")]#text(" ")#metadata(none) <tao-9be28bbe03fa7c43e9a5>#text(" Let ")#mi("{A}")#text(" be a finite ")#mi("{K}")#text("-approximate group in an ambient group ")#mi("{G}")#text(". Then ")#mi("{A}")#text(" is covered by ")#mi("{O_K(1)}")#text(" left cosets of a virtually nilpotent subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(".")
]

#text("In this final set of notes, we give some applications of the above results. The first application is to replace “")#mi("{K}")#text("-approximate group” by “sets of bounded doubling”:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3")]#text(" ")#metadata(none) <tao-3ea6bc47a6277afef178>#text(" Let ")#mi("{A}")#text(" be a finite non-empty subset of a (global) group ")#mi("{G}")#text(" such that ")#tao-math("{\\left|A^2\\right| \\leq K \\left|A\\right|}", block: false)#text(". Then there exists a coset nilprogression ")#mi("{P}")#text(" of rank and step ")#mi("{O_K(1)}")#text(" and cardinality ")#tao-math("{\\left|P\\right| \\gg_K \\left|A\\right|}", block: false)#text(" such that ")#mi("{A}")#text(" can be covered by ")#mi("{O_K(1)}")#text(" left-translates of ")#mi("{P}")#text(", and also by ")#mi("{O_K(1)}")#text(" right-translates of ")#mi("{P}")#text(".")
]

#text("We will also establish (a strengthening of) a ")#link("http://en.wikipedia.org/wiki/Gromov's_theorem_on_groups_of_polynomial_growth")[#text("well-known theorem of Gromov on groups of polynomial growth")]#text(", as promised back in ")#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/")[#text("Notes 0")]#text(", as well as a variant result (of a type known as a “generalised Margulis lemma”) controlling the almost stabilisers of discrete actions of isometries.")

#text("The material here is largely drawn from my ")#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/")[#text("recent paper with Emmanuel Breuillard and Ben Green")]#text(".")

#metadata(none) <tao-66de4f836bff42e872bf>

#heading(level: 1)[#strong[#text(" — 1. Sets of bounded doubling — ")]]

#text("In this section we will deduce Proposition ")#link(<tao-3ea6bc47a6277afef178>)[#text("3")]#text(" from Theorem ")#link(<tao-0369a36fe856043f6475>)[#text("1")]#text(". This can be done using the general (non-abelian) additive combinatorics machinery from ")#link("http://www.ams.org/mathscinet-getitem?mr=2501249")[#text("this paper of mine")]#text(", but we will give here an alternate argument relying on a version of the Croot-Sisask lemma used in ")#link("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/")[#text("Notes 7")]#text(" which is a little weaker with regards to quantitative bounds, but is slightly simpler technically (once one has the Croot-Sisask lemma).")

#text("We recall the Croot-Sisask lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Croot-Sisask)")]#text(" ")#metadata(none) <tao-ba8751ed6c4f017342ec>#text(" Let ")#mi("{A}")#text(" be a non-empty finite subset of a group ")#mi("{G}")#text(" such that ")#tao-math("{\\left|A^2\\right| \\leq K \\left|A\\right|}", block: false)#text(". Then any ")#mi("{M \\geq 1}")#text(", there is a symmetric set ")#mi("{S}")#text(" containing the origin with ")#tao-math("{\\left|S\\right| \\gg_{K,M} \\left|A\\right|}", block: false)#text(" such that ")#metadata(none) <tao-9ddaa151f0782c003302>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| 1_A * 1_A - \\tau(g) 1_A * 1_A \\right\\|_{\\ell^2(G)} \\leq \\frac{1}{M} \\left|A\\right|^{3/2}", block: true)]]

#text("for all ")#mi("{g \\in S}")#text(".")
]

#text("Let ")#mi("{A}")#text(" be as in Proposition ")#link(<tao-3ea6bc47a6277afef178>)[#text("3")]#text(". We apply Lemma ")#link(<tao-ba8751ed6c4f017342ec>)[#text("4")]#text(" with some large ")#mi("{M}")#text(" depending on ")#mi("{K}")#text(" to be chosen later. Then for any ")#mi("{g \\in S^{100}}")#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| 1_A * 1_A - \\tau(g) 1_A * 1_A \\right\\|_{\\ell^2(G)} \\leq \\frac{100}{M} \\left|A\\right|^{3/2}.", block: true)]]

#text("Since ")#mi("{1_A * 1_A}")#text(" has an ")#mi("{\\ell^1(G)}")#text(" norm of ")#tao-math("{\\left|A\\right|^2}", block: false)#text(" and is supported on the set ")#mi("{A^2}")#text(", which has cardinality at most ")#tao-math("{K\\left|A\\right|}", block: false)#text(", we see from Cauchy-Schwarz that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| 1_A * 1_A \\right\\|_{\\ell^2(G)} \\gg_K \\left|A\\right|^{3/2}", block: true)]]

#text("and hence (if ")#mi("{M}")#text(" is large enough depending on ")#mi("{K}")#text(")")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\tau(g) 1_A * 1_A \\right\\|_{\\ell^2(A^2)} \\gg_K \\left|A\\right|^{3/2}.", block: true)]]

#text("In particular, we have ")#tao-math("{\\left|gA^2 \\cap A^2\\right|\\gg_K \\left|A\\right|}", block: false)#text(", thus every element of ")#mi("{S^{100}}")#text(" has ")#tao-math("{\\gg_K \\left|A\\right|}", block: false)#text(" representations of the form ")#mi("{xy^{-1}}")#text(" with ")#mi("{x,y \\in A^2}")#text(". As there are at most ")#tao-math("{K^2 \\left|A\\right|^2}", block: false)#text(" pairs ")#mi("{(x,y)}")#text(" with ")#mi("{x,y \\in A^2}")#text(", we conclude that ")#tao-math("{\\left|S^{100}\\right| \\ll_K \\left|A\\right|}", block: false)#text(". In particular, by the Ruzsa covering lemma (Exercise 21 from ")#link("https://terrytao.wordpress.com/2011/10/27/254a-notes-7-models-of-ultra-approximate-groups/")[#text("Notes 7")]#text(") we see that ")#mi("{S^4}")#text(" can be covered by ")#mi("{O_{K,M}(1)}")#text(" left-translates of ")#mi("{S^2}")#text(", and hence ")#mi("{S^2}")#text(" is a ")#mi("{O_{K,M}(1)}")#text("-approximate group.")

#text("In view of Theorem ")#link(<tao-0369a36fe856043f6475>)[#text("1")]#text(", we thus see that to conclude the proof of Proposition ")#link(<tao-3ea6bc47a6277afef178>)[#text("3")]#text(", it suffices to show that ")#mi("{A}")#text(" can be covered by ")#mi("{O_{K,M}(1)}")#text(" left-translates (or right-translates) of ")#mi("{S^2}")#text(" if ")#mi("{M}")#text(" is sufficiently large depending on ")#mi("{K}")#text(".")

#text("We will just prove the claim for left-translates, as the claim for right-translates is similar. We will need the following useful inequality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5 (Ruzsa triangle inequality)")]#text(" Let ")#mi("{A,B,C}")#text(" be finite non-empty subsets of a group ")#mi("{G}")#text(". Then ")#tao-math("{\\left|A \\cdot C^{-1}\\right| \\leq \\frac{\\left|A \\cdot B^{-1}\\right| \\left|B \\cdot C^{-1}\\right|}{\\left|B\\right|}}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" Observe that if ")#mi("{x}")#text(" is an element of ")#mi("{A \\cdot C^{-1}}")#text(", so that ")#mi("{x=ac^{-1}}")#text(" for some ")#mi("{a \\in A}")#text(" and ")#mi("{c \\in C}")#text(", then ")#mi("{x}")#text(" has at least ")#tao-math("{\\left|B\\right|}", block: false)#text(" representations of the form ")#mi("{x=yz}")#text(" with ")#mi("{y \\in A \\cdot B^{-1}}")#text(" and ")#mi("{z \\in B \\cdot C^{-1}}")#text(", since ")#mi("{ac^{-1} = (ab^{-1})(bc^{-1})}")#text(" for all ")#mi("{b \\in B}")#text(". As there are only ")#tao-math("{\\left|A \\cdot B^{-1}\\right| \\left|B \\cdot C^{-1}\\right|}", block: false)#text(" possible pairs ")#mi("{(y,z)}")#text(" that could form such representations, the claim follows. ")#mi("\\Box")

#text("Now we return to the proof of Proposition ")#link(<tao-3ea6bc47a6277afef178>)[#text("3")]#text(". From ")#link(<tao-9ddaa151f0782c003302>)[#text("(1)")]#text(" and Minkowski’s inequality we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| 1_A * 1_A - \\frac{1}{\\left|S\\right|} 1_S * 1_A * 1_A \\right\\|_{\\ell^2(G)} \\leq \\frac{1}{M} \\left|A\\right|^{3/2},", block: true)]]

#text("and thus (if ")#mi("{M}")#text(" is sufficiently large depending on ")#mi("{K}")#text(")")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\frac{1}{\\left|S\\right|} 1_S * 1_A * 1_A \\right\\|_{\\ell^2(A^2)} \\gg_K \\left|A\\right|^{3/2}", block: true)]]

#text("and in particular")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\frac{1}{\\left|S\\right|} 1_S * 1_A * 1_A \\right\\|_{\\ell^\\infty(A^2)} \\gg_K \\left|A\\right|", block: true)]]

#text("and thus by Young’s inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\frac{1}{\\left|S\\right|} 1_S * 1_A \\right\\|_{\\ell^\\infty(G)} \\gg_K 1,", block: true)]]

#text("and so")

#align(center)[#tao-fit-display[#tao-math("1_S * 1_A(x) \\gg_{K,M} \\left|A\\right|", block: true)]]

#text("for some ")#mi("{x \\in G}")#text(". In other words,")

#align(center)[#tao-fit-display[#tao-math("\\left|S \\cap x A^{-1}\\right| \\gg_{K,M} \\left|A\\right|", block: true)]]

#text("If we then set ")#mi("{B := S \\cap x A^{-1}}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left|B \\cdot S^{-1}\\right| \\leq \\left|S^2\\right| \\ll_{K,M} \\left|A\\right|", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|A \\cdot B^{-1}\\right| \\leq \\left|A^2 x\\right| = \\left|A^2\\right| \\leq K \\left|A\\right|", block: true)]]

#text("and hence by the Ruzsa triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|A \\cdot S\\right| = \\left|A \\cdot S^{-1}\\right| \\ll_{K,M} |A|.", block: true)]]

#text("By the Ruzsa covering lemma, this implies that ")#mi("{A}")#text(" can be covered by ")#mi("{O_{K,M}(1)}")#text(" left-translates of ")#mi("{S}")#text(", as required. This proves Proposition ")#link(<tao-3ea6bc47a6277afef178>)[#text("3")]#text(". By placing the coset nilprogression in a virtually nilpotent group, we obtain a strengthening of Corollary ")#link(<tao-9be28bbe03fa7c43e9a5>)[#text("2")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 6")]#text(" ")#metadata(none) <tao-99d5c56db443b88bd2cd>#text(" Let ")#mi("{A}")#text(" be a finite non-empty subset of an ambient group ")#mi("{G}")#text(" such that ")#tao-math("{\\left|A^2\\right| \\leq K\\left|A\\right|}", block: false)#text(". Then ")#mi("{A}")#text(" is covered by ")#mi("{O_K(1)}")#text(" left cosets (and also by ")#mi("{O_K(1)}")#text(" right-cosets) of a virtually nilpotent subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(".")
]

#text("We remark that there is also an “off-diagonal” version of Proposition ")#link(<tao-3ea6bc47a6277afef178>)[#text("3")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7")]#text(" ")#metadata(none) <tao-69b2302bf65fae0920c7>#text(" Let ")#mi("{A,B}")#text(" be finite non-empty subsets of a (global) group ")#mi("{G}")#text(" such that ")#tao-math("{\\left|AB\\right| \\leq K \\left|A\\right|^{1/2} \\left|B\\right|^{1/2}}", block: false)#text(". Then there exists a coset nilprogression ")#mi("{P}")#text(" of rank and step ")#mi("{O_K(1)}")#text(" and cardinality ")#tao-math("{\\left|P\\right| \\gg_K \\left|A\\right|}", block: false)#text(" such that ")#mi("{A}")#text(" can be covered by ")#mi("{O_K(1)}")#text(" left-translates of ")#mi("{P}")#text(", and ")#mi("{B}")#text(" can be covered by ")#mi("{O_K(1)}")#text(" right-translates of ")#mi("{P}")#text(".")
]

#text("This is a consequence of Theorem ")#link(<tao-0369a36fe856043f6475>)[#text("1")]#text(" combined with Theorem 4.6 from ")#link("http://www.ams.org/mathscinet-getitem?mr=2501249")[#text("this paper of mine")]#text("; we omit the details. There is also a “statistical” variant (using instead Theorem 5.4 from ")#link("http://www.ams.org/mathscinet-getitem?mr=2501249")[#text("this paper of mine")]#text("), based on an additional tool, the (non-abelian) Balog-Szemerédi-Gowers theorem, which will not be discussed in detail here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8")]#text(" ")#metadata(none) <tao-65b3124bba13a1892579>#text(" Let ")#mi("{A,B}")#text(" be finite non-empty subsets of a (global) group ")#mi("{G}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ (a,b,a^{\\prime},b^{\\prime}) \\in A \\times B \\times A \\times B: ab = a^{\\prime}b^{\\prime}\\}\\right| \\geq \\left|A\\right|^{3/2} \\left|B\\right|^{3/2} / K.", block: true)]]

#text("Then there exists a coset nilprogression ")#mi("{P}")#text(" of rank and step ")#mi("{O_K(1)}")#text(" and cardinality ")#tao-math("{\\left|P\\right| \\gg_K \\left|A\\right|}", block: false)#text(" such that ")#mi("{A}")#text(" intersects a left-translate of ")#mi("{P}")#text(" in a set of cardinality ")#tao-math("{\\gg_K \\left|A\\right|}", block: false)#text(", and ")#mi("{B}")#text(" intersects a right-translate of ")#mi("{P}")#text(" in a set of cardinality ")#tao-math("{\\gg_K \\left|A\\right|}", block: false)#text(".")
]

#heading(level: 1)[#strong[#text(" — 2. Polynomial growth — ")]]

#text("The above results show that finite approximate groups ")#mi("{A}")#text(" (as well as related objects, such as finite sets of bounded doubling) can be efficiently covered by virtually nilpotent groups. However, they do not place ")#emph[#text("all")]#text(" of ")#mi("{A}")#text(" inside a virtually nilpotent group. Indeed, this is not possible in general:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Let ")#mi("{G}")#text(" be the “")#mi("{ax+b}")#text(" group”, that is to say the group of all affine transformations ")#mi("{x \\mapsto ax+b}")#text(" on the real line, with ")#mi("{a \\in {\\bf R} \\backslash \\{0\\}}")#text(" and ")#mi("{b \\in {\\bf R}}")#text(". Show that there exists an absolute constant ")#mi("{K}")#text(" and arbitrarily large finite ")#mi("{K}")#text("-approximate groups ")#mi("{A}")#text(" in ")#mi("{G}")#text(" that are not contained in any virtually nilpotent group. (")#emph[#text("Hint:")]#text(" build a set ")#mi("{A}")#text(" which is very “long” in the ")#mi("{b}")#text(" direction and very “thin” in the ")#mi("{a}")#text(" direction.)")
]

#text("Such counterexamples have the feature of being “thin” in at least one of the directions of ")#mi("{G}")#text(". However, this can be fixed by adding a “thickness” assumption to the approximate group. In particular, we have the following result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9 (Thick sets of bounded doubling are virtually nilpotent)")]#text(" For every ")#mi("{K \\geq 1}")#text(" there exists ")#mi("{M \\geq 1}")#text(" such that the following statement holds: whenever ")#mi("{G}")#text(" is a group, ")#mi("{S}")#text(" is a finite symmetric subset of ")#mi("{G}")#text(" containing the identity, and ")#mi("{A}")#text(" is a finite set containing ")#mi("{S^M}")#text(" such that ")#tao-math("{\\left|A^2\\right| \\leq K\\left|A\\right|}", block: false)#text(", then ")#mi("{S}")#text(" generates a virtually nilpotent group.")
]

#emph[#text("Proof:")]#text(" Fix ")#mi("{K}")#text(", and let ")#mi("{M}")#text(" be a sufficiently large natural number depending on ")#mi("{K}")#text(" to be chosen later. Let ")#mi("{S, A, G}")#text(" be as in the theorem. By Proposition ")#link(<tao-3ea6bc47a6277afef178>)[#text("3")]#text(", there exists a virtually nilpotent group ")#mi("{H}")#text(" such that ")#mi("{A}")#text(" is covered by ")#mi("{O_K(1)}")#text(" left-cosets of ")#mi("{H}")#text(". In particular, ")#mi("{S^m H}")#text(" consists of ")#mi("{O_K(1)}")#text(" left-cosets of ")#mi("{H}")#text(" for all ")#mi("{0 \\leq \\leq M}")#text(". On the other hand, as ")#mi("{S}")#text(" contains the identity, ")#mi("{S^m H}")#text(" is nondecreasing in ")#mi("{m}")#text(". If ")#mi("{M}")#text(" is large enough, then by the pigeonhole principle we may thus find some ")#mi("{0 \\leq m < M}")#text(" such that ")#mi("{S^{m+1} H = S^m H}")#text(". By induction this implies that ")#mi("{S^k H = S^m H}")#text(" for all ")#mi("{k \\geq m}")#text("; we conclude that")

#align(center)[#tao-fit-display[#mitex("\\langle S \\rangle \\subset \\langle S \\rangle H = \\bigcup_{k=m}^\\infty S^k H = S^m H.")]]

#text("In particular, ")#mi("{H \\cap \\langle S \\rangle}")#text(" has finite index in ")#mi("{\\langle S \\rangle}")#text(". Since ")#mi("{H}")#text(" is virtually nilpotent, we conclude that ")#mi("{\\langle S\\rangle}")#text(" is virtually nilpotent also. ")#mi("\\Box")

#text("This theorem leads to the following Gromov-type theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2 (Gromov-type theorem)")]#text(" ")#metadata(none) <tao-183ee0870433a102edb9>#text(" Show that for every ")#mi("{C, d>0}")#text(" there exists ")#mi("{M \\geq 1}")#text(" such that the following statement holds: whenever ")#mi("{G}")#text(" is a group generated by a finite symmetric set ")#mi("{S}")#text(" of generators containing the identity, and ")#tao-math("{\\left|S^m\\right| \\geq C m^d \\left|S\\right|}", block: false)#text(" for some ")#mi("{m \\geq M}")#text(", then ")#mi("{G}")#text(" is virtually nilpotent.")
]

#text("Note that this implies as a corollary the ")#link("http://en.wikipedia.org/wiki/Gromov's_theorem_on_groups_of_polynomial_growth")[#text("original theorem of Gromov")]#text(" that every finitely generated group of polynomial growth is virtually nilpotent, but it is stronger because (a) one only needs a polynomial growth bound at a single scale ")#mi("{m}")#text(", rather than at all scales, and (b) the lower bound required on ")#mi("{m}")#text(" does not depend on the size of the generating set ")#mi("{S}")#text(". (A previous result in this direction, which obtained (a) but not (b), was established ")#link("https://terrytao.wordpress.com/2009/10/23/a-finitary-version-of-gromovs-polynomial-growth-theorem/")[#text("by myself and Yehuda Shalom")]#text(", by a rather different argument based on ")#link("http://www.ams.org/mathscinet-getitem?mr=2629989")[#text("this paper of Kleiner")]#text(". The ")#link("http://www.ams.org/mathscinet-getitem?mr=623534")[#text("original proof of Gromov")]#text(" of his theorem had some features in common with the arguments given here, in particular using the machinery of Gromov-Hausdorff limits as well as some of the theory surrounding Hilbert’s fifth problem, and was also amenable to nonstandard analysis methods as demonstrated ")#link("http://www.ams.org/mathscinet-getitem?mr=751150")[#text("by van den Dries and Wilkie")]#text(", but differed in a number of technical details.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" By inspecting the arguments carefully, one can obtain a slightly sharper description of the group ")#mi("{G}")#text(" in Exercise ")#link(<tao-183ee0870433a102edb9>)[#text("2")]#text(", namely that ")#mi("{G}")#text(" contains a normal subgroup ")#mi("{G^{\\prime}}")#text(" of index ")#mi("{O_d(1)}")#text(" which is the extension of a finitely nilpotent group of step and rank ")#mi("{O(d)}")#text(" by a finite group contained in ")#mi("{S^{m}}")#text(". See ")#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/")[#text("this paper")]#text(" for details.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3 (Gap between polynomial and non-polynomial growth)")]#text(" Show that there exists a function ")#mi("{f: {\\bf N} \\rightarrow {\\bf R}^+}")#text(" which grows faster than any polynomial (i.e. ")#mi("{f(m)/m^d \\rightarrow \\infty}")#text(" as ")#mi("{m \\rightarrow +\\infty}")#text(" for any ")#mi("{d}")#text("), with the property that ")#tao-math("{\\left|S^m\\right| \\geq f(m) \\left|S\\right|}", block: false)#text(" whenever ")#mi("{G}")#text(" is any finitely generated group that is not virtually nilpotent, and ")#mi("{S}")#text(" is any symmetric set of generators of ")#mi("{G}")#text(" that contains the identity.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" No effective bound for the function ")#mi("{f}")#text(" in this exercise is explicitly known, though in principle one could eventually extract such a bound by painstakingly finitising the proof of the structure theorem for approximate groups. If one restricts the size of ")#mi("{S}")#text(" to be bounded, then one can take ")#mi("{f(m)}")#text(" to be ")#mi("{m^{(\\log \\log m)^c}}")#text(" for some ")#mi("{c>0}")#text(" and ")#mi("{m}")#text(" sufficiently large depending on the size of ")#mi("{S}")#text(", by the result of my paper with Shalom, but this is unlikely to be best possible. (In the converse direction, ")#link("http://en.wikipedia.org/wiki/Grigorchuk_group")[#text("Grigorchuk’s construction of a group of intermediate growth")]#text(" shows that ")#mi("{f(m)}")#text(" cannot grow faster than ")#mi("{\\exp(m^{\\alpha})}")#text(" for some absolute constant ")#mi("{\\alpha<1}")#text(" (and it is believed that one can take ")#mi("{\\alpha=1/2}")#text(").)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4 (Infinite groups have at least linear growth)")]#text(" If ")#mi("{G}")#text(" is an infinite group generated by a finite symmetric set ")#mi("{S}")#text(" containing the identity, show that ")#tao-math("{\\left|S^m\\right| \\geq \\left|S\\right|+m-1}", block: false)#text(" for all ")#mi("{m \\geq 1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5 (Linear growth implies virtually cyclic)")]#text(" Let ")#mi("{G}")#text(" be an infinite group generated by a finite symmetric set ")#mi("{S}")#text(" containing the identity. Suppose that ")#mi("{G}")#text(" is of ")#emph[#text("linear growth")]#text(", in the sense that ")#tao-math("{\\left|S^m\\right| \\leq Cm}", block: false)#text(" for all ")#mi("{m \\geq 1}")#text(" and some finite ")#mi("{C}")#text(".")

#list(
[#text("(i) Place a left-invariant metric ")#mi("{d}")#text(" on ")#mi("{G}")#text(" by defining ")#mi("{d(x,y)}")#text(" to be the least natural number ")#mi("{m}")#text(" for which ")#mi("{x \\in yS^m}")#text(". Define a geodesic to be a finite or infinite sequence ")#mi("{(g_n)_{n \\in I}}")#text(" indexed by some discrete interval ")#mi("{I \\subset {\\bf Z}}")#text(" such that ")#tao-math("{d(g_n,g_m) = \\left|n-m\\right|}", block: false)#text(" for all ")#mi("{n,m\\in I}")#text(". Show that there exist arbitrarily long finite geodesics.")],
[#text("(ii) Show that there exists a doubly infinite geodesic ")#mi("{(g_n)_{n \\in {\\bf Z}}}")#text(" with ")#mi("{g_0 = 1}")#text(". (")#emph[#text("Hint:")]#text(" use (i) and a compactness argument.)")],
[#text("(iii) Show that ")#tao-math("{\\left|S^{2m}\\right| \\geq 2 \\left|S^m\\right| - 1}", block: false)#text(" for all ")#mi("{m \\geq 1}")#text(". (")#emph[#text("Hint:")]#text(" study the balls of radius ")#mi("{m}")#text(" centred at ")#mi("{g_m}")#text(" and ")#mi("{g_{-m}}")#text(".) More generally, show that ")#tao-math("{\\left|S^{km}\\right| \\geq 2k \\left|S^m\\right| - 2k+1}", block: false)#text(" for all ")#mi("{m,k \\geq 1}")#text(".")],
[#text("(iv) Show that ")#tao-math("{\\left|S^m\\right|/m}", block: false)#text(" converges to a finite non-zero limit ")#mi("{\\alpha}")#text(" as ")#mi("{m \\rightarrow \\infty}")#text(", thus ")#tao-math("{\\left|S^m\\right| = \\alpha m + o(m)}", block: false)#text(" for all ")#mi("{m \\geq 1}")#text(", where ")#mi("{o(m)}")#text(" denotes a quantity which, when divided by ")#mi("{m}")#text(", goes to zero as ")#mi("{m \\rightarrow \\infty}")#text(".")],
[#text("(v) Show that for all ")#mi("{m \\geq 1}")#text(", then all elements of ")#mi("{S^m}")#text(" lie within a distance at most ")#mi("{o(m)}")#text(" of the geodesic ")#mi("{(g_{-m},\\ldots,g_m)}")#text(". (")#emph[#text("Hint:")]#text(" first show that all but at most ")#mi("{o(m)}")#text(" elements of ")#mi("{S^m}")#text(" lie within this distance, using (iv) and the argument used to prove (iii).)")],
[#text("(vi) Show that for sufficiently large ")#mi("{m}")#text(", ")#mi("{g_m^{-1}}")#text(" lies within distance ")#mi("{o(m)}")#text(" of ")#mi("{g_{-m}}")#text(".")],
[#text("(vii) Show that for sufficiently large ")#mi("{m}")#text(", ")#mi("{S^{m+1}}")#text(" lies within distance ")#mi("{m}")#text(" of ")#mi("{\\{1, g_m,g_m^{-1}\\}}")#text(".")],
[#text("(viii) Show that ")#mi("{G}")#text(" is virtually cyclic (i.e. it has a cyclic subgroup of finite index).")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6 (Nilpotent groups have polynomial growth)")]#text(" Let ")#mi("{S}")#text(" be a finite symmetric subset of a nilpotent group ")#mi("{G}")#text(" containing the identity.")

#list(
[#text("(i) Let ")#mi("{s}")#text(" be an element of ")#mi("{S}")#text(" that is not the identity, and let ")#mi("{S^{\\prime}}")#text(" be the minimal symmetric set containing ")#mi("{S \\backslash \\{s,s^{-1}\\}}")#text(" that is closed under the operations ")#mi("{g \\mapsto [g,s^{\\pm 1}]^{\\pm 1}}")#text(". Show that ")#mi("{S^{\\prime}}")#text(" is also a finite symmetric subset of ")#mi("{G}")#text(" containing the identity, and that every element of ")#mi("{S^m}")#text(" can be written in the form ")#mi("{s^i h}")#text(" for some ")#tao-math("{\\left|i\\right| \\leq m}", block: false)#text(" and ")#mi("{h \\in (S^{\\prime})^{O(m^2)}}")#text(", where the implied constant can depend on ")#mi("{S}")#text(", ")#mi("{G}")#text(".")],
[#text("(ii) Show that ")#tao-math("{\\left|S^m\\right| \\leq C m^d}", block: false)#text(" for all ")#mi("{m \\geq 1}")#text(" and some ")#mi("{C, d > 0}")#text(" depending on ")#mi("{S, G}")#text(" (i.e. ")#mi("{G}")#text(" is of polynomial growth).")],
[#text("(iii) Show that every virtually nilpotent group is of polynomial growth.")]
)
]

#heading(level: 1)[#strong[#text(" — 3. Fundamental groups of compact manifolds (optional) — ")]]

#text("This section presupposes some familiarity with Riemannian geometry. In these notes, Riemannian manifolds are always understood to be complete and without boundary.")

#text("We now apply the above theory to establish some relationships between the topology (and more precisely, the ")#link("http://en.wikipedia.org/wiki/Fundamental_group")[#text("fundamental group")]#text(") of a compact Riemannian manifold, and the curvature of such manifolds. A basic theme in this subject is that lower bounds on curvature tend to give somewhat restrictive control on the topology of a manifold. Consider for instance ")#link("http://en.wikipedia.org/wiki/Myers%27_theorem")[#text("Myers’ theorem")]#text(", which among other things tells us that a connected Riemannian manifold ")#mi("{M}")#text(" with a uniform positive lower bound on the ")#link("http://en.wikipedia.org/wiki/Ricci_curvature")[#text("Ricci curvature")]#text(" ")#mi("{\\text{Ric}}")#text(" is necessarily compact (with an explicit upper bound on the diameter). In a similar vein we have the ")#link("http://en.wikipedia.org/wiki/Splitting_theorem")[#text("splitting theorem")]#text(", which asserts that if a connected Riemannian manifold ")#mi("{M}")#text(" has everywhere non-negative Ricci curvature, then it splits as the product of a Euclidean space and a manifold without straight lines (i.e. embedded copises of ")#mi("{{\\bf R}}")#text(").")

#text("To analyse the fundamental group ")#mi("{\\pi_1(M)}")#text(" of a connected Riemannian manifold ")#mi("{M}")#text(", it is convenient to work with its universal cover:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" ")#metadata(none) <tao-3fc5cf82678ab547470a>#text(" Let ")#mi("{M}")#text(" be a connected Riemannian manifold.")

#list(
[#text("(i) (Existence of universal cover) Show that there exists a simply connected Riemannian manifold ")#mi("{\\tilde M}")#text(" with the same dimension as ")#mi("{M}")#text(" with a smooth surjective map ")#mi("{\\pi: \\tilde M \\rightarrow M}")#text(" which is a local diffeomorphism and a Riemannian isometry (i.e. the metric tensors are preserved); such a manifold (or more precisely, the pair ")#mi("{(M,\\pi)}")#text(") is known as a ")#emph[#text("universal cover")]#text(" of ")#mi("{M}")#text(". (")#emph[#text("Hint:")]#text(" take ")#mi("{\\tilde M}")#text(" to be the space of all paths from a fixed base point ")#mi("{p_0}")#text(" in ")#mi("{\\tilde M}")#text(", quotiented out by homotopies fixing the endpoints. Once ")#mi("{\\pi}")#text(" is constructed, pull back the smooth and Riemannian structures.)")],
[#text("(ii) (Universality) Show that if ")#mi("{M^{\\prime}}")#text(" is any smooth connected manifold with a smooth surjective map ")#mi("{f: M^{\\prime} \\rightarrow M}")#text(" that is a local diffeomorphism and Riemannian isometry, and ")#mi("{p^{\\prime} \\in M^{\\prime}, p \\in M, \\tilde p \\in \\tilde M}")#text(" are point such that ")#mi("{f(p^{\\prime}) = \\pi(\\tilde p) = p}")#text(", then there exists a unique smooth map ")#mi("{\\pi^{\\prime}: \\tilde M \\rightarrow M^{\\prime}}")#text(" with ")#mi("{\\pi^{\\prime}(\\tilde p) = p^{\\prime}}")#text(" that makes ")#mi("{\\tilde M}")#text(" a universal cover of ")#mi("{M^{\\prime}}")#text(" also.")],
[#text("(iii) (Uniqueness) Show that a universal cover is unique up to isometric isomorphism.")],
[#text("(iv) (Covering space) Show that for every ")#mi("{p \\in M}")#text(" there exists a neighbourhood ")#mi("{U}")#text(" of ")#mi("{p}")#text(" such that ")#mi("{\\pi^{-1}(U)}")#text(" is isometric (as a Riemannian manifold) to ")#mi("{\\pi_1(M) \\times U}")#text(", where we give the fundamental group ")#mi("{\\pi_1(M)}")#text(" the discrete topology. In particular, the fibres ")#mi("{\\pi^{-1}(\\{p\\})}")#text(" of a point ")#mi("{p \\in M}")#text(" are discrete and can be placed in bijection with ")#mi("{\\pi_1(M)}")#text(".")],
[#text("(v) (Deck transformations) Show that ")#mi("{\\pi_1(M)}")#text(" acts freely and isometrically on ")#mi("{M^{\\prime}}")#text(", in such a way that the orbits of ")#mi("{\\pi_1(M)}")#text(" are the fibres of ")#mi("{\\pi}")#text(". Conversely, show that every isometry on ")#mi("{M^{\\prime}}")#text(" that preserves the fibres of ")#mi("{\\pi}")#text(" arises from an element of ")#mi("{\\pi_1(M)}")#text(".")],
[#text("(vi) (Cocompactness) if ")#mi("{M}")#text(" is compact, and ")#mi("{\\pi^{-1}(\\{p\\})}")#text(" is a fibre of ")#mi("{M}")#text(", show that every element of ")#mi("{M^{\\prime}}")#text(" lies a distance at most ")#mi("{\\text{diam}(M)}")#text(" from an element of the fibre ")#mi("{\\pi^{-1}(\\{p\\})}")#text(".")],
[#text("(vii) (Finite generation) If ")#mi("{M}")#text(" is compact and ")#mi("{p \\in \\tilde M}")#text(", show that the set ")#mi("{\\{ g \\in \\pi_1(M): \\text{dist}(gp,p) \\leq 2\\text{diam}(M) \\}}")#text(" is finite and generates ")#mi("{\\pi_1(M)}")#text(". (")#emph[#text("Hint:")]#text(" if ")#mi("{gp}")#text(" is further than ")#mi("{2\\text{diam}(M)}")#text(" from ")#mi("{p}")#text(", use (vi) to find a factorisation ")#mi("{g=hk}")#text(" such that ")#mi("{kp}")#text(" is closer to ")#mi("{p}")#text(" or ")#mi("{gp}")#text(" than ")#mi("{p}")#text(" is to ")#mi("{gp}")#text(".)")],
[#text("(viii) (Polynomial growth) If ")#mi("{M}")#text(" is compact, show that the group ")#mi("{\\pi_1(M)}")#text(" is of polynomial growth (thus ")#tao-math("{\\left|S^m\\right| \\leq C m^d}", block: false)#text(" for some generating set ")#mi("{S}")#text(", some ")#mi("{C,d \\geq 0}")#text(", and all ")#mi("{m \\geq 1}")#text(") if and only if the universal cover ")#mi("{\\tilde M}")#text(" is of polynomial growth (thus ")#mi("{\\text{Vol}(B(x_0,r)) \\leq Cr^d}")#text(" for some base point ")#mi("{x_0 \\in \\tilde M}")#text(", some ")#mi("{C,d \\geq 0}")#text(", and all ")#mi("{r \\geq 1}")#text(").")]
)
]

#text("The above exercise thus links polynomial growth of groups to polynomial growth of manifolds. To control the latter, a useful tool is the ")#link("http://en.wikipedia.org/wiki/Bishop-Gromov_inequality")[#text("Bishop-Gromov inequality")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10 (Bishop-Gromov inequality)")]#text(" Let ")#mi("{M}")#text(" be a Riemannian manifold whose Ricci curvature is everywhere bounded below by some constant ")#mi("{\\rho \\in {\\bf R}}")#text(". Let ")#mi("{\\tilde M}")#text(" be the simply connected Riemannian manifold of constant curvature ")#mi("{\\rho}")#text(" and the same dimension as ")#mi("{M}")#text(" (this will be a Euclidean space for ")#mi("{\\rho=0}")#text(", a sphere for ")#mi("{\\rho>0}")#text(", and hyperbolic space for ")#mi("{\\rho<0}")#text("). Let ")#mi("{p}")#text(" be a point in ")#mi("{M}")#text(" and ")#mi("{\\tilde p}")#text(" be a point in ")#mi("{\\tilde M}")#text(". Then the expression")

#align(center)[#tao-fit-display[#mitex("\\frac{\\text{vol}(B(p,r))}{\\text{vol}(B(\\tilde p,r))}")]]

#text("is monotone non-increasing in ")#mi("{r}")#text(".")
]

#text("We will not prove this proposition here (as it requires, among other things, a definition of Ricci curvature, which would be beyond the scope of these notes); but see for instance ")#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/")[#text("this previous blog post of mine")]#text(" for a proof. This inequality is consistent with the geometric intuition that an increase in curvature on a manifold should correspond to a stunting of the growth of the volume of balls. For instance, in the positively curved spheres, the volume of balls eventually stabilises as a constant; in the zero curvature Euclidean spaces, the volume of balls grows polynomially; and in the negative curvature hyperbolic spaces, the volume of balls grows exponentially.")

#text("Informally, the balls in ")#mi("{M}")#text(" cannot grow any faster than the balls in ")#mi("{\\tilde M}")#text(". Setting ")#mi("{\\rho=0}")#text(", we conclude in particular that if ")#mi("{M}")#text(" has non-negative Ricci curvature and dimension ")#mi("{d}")#text(", then ")#mi("{\\text{vol}(B(p,r))/r^d}")#text(" is non-decreasing in ")#mi("{r}")#text("; in particular, any manifold of non-negative Ricci curvature is of polynomial growth. Applying Exercise ")#link(<tao-3fc5cf82678ab547470a>)[#text("7")]#text(" and Gromov’s theorem, we conclude that any manifold of non-negative Ricci curvature has a fundamental group which is virtually nilpotent. (In fact, such fundametal groups can be shown, using the splitting theorem, to be virtually abelian; see ")#link("http://www.ams.org/mathscinet-getitem?mr=309010")[#text("this paper of Cheeger and Gromoll")]#text(". However, this improvement seems to be beyond the combinatorial methods used here.)")

#text("The above monotonicity also shows that whenever ")#mi("{M}")#text(" has Ricci curvature at least zero, we have the doubling bound")

#align(center)[#tao-fit-display[#mitex("\\text{vol}(B(p,2r)) \\leq 2^d \\text{vol}(B(p,r)).")]]

#text("A continuity argument then shows that for every ")#mi("{R>0}")#text(" and ")#mi("{\\epsilon > 0}")#text(", there exists ")#mi("{\\delta > 0}")#text(" such that if ")#mi("{M}")#text(" has Ricci curvature at least ")#mi("{-\\delta}")#text(", then one has")

#align(center)[#tao-fit-display[#mitex("\\text{vol}(B(p,2r)) \\leq (2^d+\\epsilon) \\text{vol}(B(p,r))")]]

#text("for all ")#mi("{0 < r \\leq R}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" By using the above observation combined with Exercise ")#link(<tao-3fc5cf82678ab547470a>)[#text("7")]#text(" and Exercise ")#link(<tao-183ee0870433a102edb9>)[#text("2")]#text(", show that for every dimension ")#mi("{d}")#text(" there exists ")#mi("{\\delta>0}")#text(" such that if ")#mi("{M}")#text(" is any compact Riemannian manifold of diameter at most ")#mi("{1}")#text(" and Ricci curvature at least ")#mi("{-\\delta}")#text(" everywhere, then ")#mi("{\\pi_1(M)}")#text(" is virtually nilpotent.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" This result was first conjectured by Gromov, and was proven by ")#link("http://www.ams.org/mathscinet-getitem?mr=1405949")[#text("Cheeger-Colding")]#text(" and ")#link("http://arxiv.org/abs/1105.5955")[#text("Kapovitch-Wilking")]#text(" using deep Riemannian geometry tools (beyond just the Bishop-Gromov inequality). (See also ")#link("http://www.ams.org/mathscinet-getitem?mr=2630041")[#text("this paper of Kapovitch-Petrunin-Tuschmann")]#text(" that established the analogous result assuming a lower bound on ")#link("http://en.wikipedia.org/wiki/Sectional_curvature")[#text("sectional curvature")]#text(" rather than Ricci curvature.)")

#text("The arguments in these papers in fact give more precise information on the fundamental group ")#mi("{\\pi_1(M)}")#text(", namely that there is a nilpotent subgroup of step and rank ")#mi("{O_d(1)}")#text(" and index ")#mi("{O_d(1)}")#text(". The methods here (based purely on controlling the growth of balls in ")#mi("{\\pi_1(M)}")#text(") can give the step and rank bounds, but appear to be insufficient to obtain the index bound. The exercise cannot be immediately obtained via a compactness-and-contradiction argument from the (easier) ")#mi("{\\delta=0}")#text(" case mentioned previously, because of the problem of ")#emph[#text("collapsing")]#text(": there is no lower bound assumed on the injectivity radius of ")#mi("{M}")#text(", and as such the space of all manifolds with the indicated diameter is non-compact even if one bounds the derivatives of the metric to all orders. (An equivalent way of phrasing the problem is that the orbits of ")#mi("{\\pi_1(M)}")#text(" in the universal cover may be arbitrarily dense, and so a ball of bounded radius in ")#mi("{\\tilde M}")#text(" may correspond to an arbitrarily large subset ")#mi("{S}")#text(" of the fundamental group. For this application it is thus of importance that there is no upper bound on the size of the sets ")#mi("{S}")#text(" or ")#mi("{A}")#text(" assumed in Exercise ")#link(<tao-183ee0870433a102edb9>)[#text("2")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" One way to view the above results is as an assertion that it is quite rare for a compact manifold to be equippable with a Riemannian metric with (almost) non-negative Ricci curvature. Indeed, an application of ")#link("http://en.wikipedia.org/wiki/Seifert%E2%80%93van_Kampen_theorem")[#text("van Kampen’s theorem")]#text(" shows that every fundamental group ")#mi("{\\pi_1(M)}")#text(" of a compact manifold is finitely presented, and conversely a gluing argument for four-manifolds shows that every finitely presented group is the fundamental group of some (four-dimensional) manifold. Intuitively, “most” finitely presented groups are not virtually nilpotent, and so “most” compact manifolds cannot have metrics with almost non-negative Ricci curvature.")
]

#heading(level: 1)[#strong[#text(" — 4. A Margulis-type lemma — ")]]

#text("In Exercise ")#link(<tao-3fc5cf82678ab547470a>)[#text("7")]#text(" we saw that the fundamental group ")#mi("{\\pi_1(M)}")#text(" of a connected Riemannian manifold can be viewed as a discrete group of isometries acting on a Riemannian manifold ")#mi("{\\tilde M}")#text(". The curvature properties of ")#mi("{\\tilde M}")#text(" then give doubling properties of the balls in ")#mi("{\\tilde M}")#text(", and hence of ")#mi("{\\pi_1(M)}")#text(", allowing one to use tools such as Exercise ")#link(<tao-183ee0870433a102edb9>)[#text("2")]#text(".")

#text("It turns out that one can abstract this process by replacing the universal cover ")#mi("{\\tilde M}")#text(" by a more general metric space ")#mi("{X}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11 (Margulis-type lemma)")]#text(" Let ")#mi("{K \\geq 1}")#text(". Let ")#mi("{X = (X,d)}")#text(" be a metric space, with the property that every ball of radius ")#mi("{4}")#text(" can be covered by ")#mi("{K}")#text(" balls of radius ")#mi("{1}")#text(". Let ")#mi("{\\Gamma}")#text(" be a group of isometries of ")#mi("{X}")#text(", which acts discretely in the sense that ")#mi("{\\{ g \\in \\Gamma: gx \\in B \\}}")#text(" is finite for every ")#mi("{x \\in X}")#text(" and every bounded set ")#mi("{B \\subset X}")#text(". Then if ")#mi("{x \\in X}")#text(" and ")#mi("{\\epsilon}")#text(" is sufficiently small depending on ")#mi("{K}")#text(", the set ")#mi("{S_\\epsilon := \\{ g \\in \\Gamma: d(gx,x) \\leq \\epsilon \\}}")#text(" generates a virtually nilpotent group.")
]

#emph[#text("Proof:")]#text(" We can can cover ")#mi("{B(x,4)}")#text(" by ")#mi("{K}")#text(" balls ")#mi("{B(x_i,1)}")#text(". If ")#mi("{g,h \\in S_4}")#text(" and ")#mi("{gx,hx \\in B(x_i,1)}")#text(", then (by the isometric action of ")#mi("{\\Gamma}")#text(") we see that ")#mi("{h^{-1} g \\in S_2}")#text(". We conclude that ")#mi("{S_4}")#text(" can be covered by ")#mi("{K}")#text(" right-translates of ")#mi("{S_2}")#text(". Since ")#mi("{S_2^2 \\subset S_4}")#text(" and ")#mi("{S_{2/M}^M \\subset S^2}")#text(" for all ")#mi("{M \\geq 1}")#text(", the claim then follows from Exercise ")#link(<tao-183ee0870433a102edb9>)[#text("2")]#text(". ")#mi("\\Box")

#text("Roughly speaking, the above lemma asserts that for discrete actions of isometries on “spaces of bounded doubling”, the “almost stabiliser” of a point is “virtually nilpotent”. In the case when ")#mi("{X}")#text(" is a Riemannian manifold with a lower bound on curvature, this result was established by ")#link("http://www.ams.org/mathscinet-getitem?mr=1405949")[#text("Cheeger-Colding")]#text(" and ")#link("http://arxiv.org/abs/1105.5955")[#text("Kapovitch-Wilking")]#text(" (and, as mentioned in the previous section, stronger control on ")#mi("{S_\\epsilon}")#text(" was established). The original lemma of Margulis addressed the case when ")#mi("{X}")#text(" was a hyperbolic space, and relied on commutator estimates not unrelated to the commutator estimates of Gleason metrics and of strong approximate groups that were used in previous notes.")

#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31a6a98885f0d97401658393cacf00802dcaf42770cf9f2993e4abbbc01e4e00-9e5c75b822e693f0872dbadefbcfb6013cead9746b12e0b2e623f603be0c5fc6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yan")]], [#link("https://terrytao.wordpress.com/2011/11/13/254a-notes-9-applications-of-the-structural-theory-of-approximate-groups/#comment-104903")[#strong[#text("yan")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2011")])]

#text("Hi Dr Tao")#linebreak()#text(" I am a Chinese student, and i am now a graduate student in university of oklahoma studying math. and this is my first year.")#linebreak()#text(" i never learn logic classes before in China, and i even do not know what is vaculously true~but i think i can do math")#linebreak()#text(" but these days I meet a lot of confusing logic and i have a strong feeling that if i can not solve them at first, i can not do math, and math seems meaningless to me~")#linebreak()#text(" some of my problems are")#linebreak()#text(" G is a group, what does it mean? what I learned before is, every narrative sentence can be written as if,,,,then,,,,,so i can write it as if U is G, then U is a group. or does it mean that there exist a group, and we denote it by symbol G?")#linebreak()#text(" for every x in R, f(x)=f(-x), i usually think it as “if x in R, then f(x)=f(-x)” but if i think it in this way when i take negation or contraposition of this statement i may face problem~")#linebreak()#text(" the most confusing problem is now I do not know when we can take and when we can assume there is an element, because sometimes it is an “if” there, sometimes there is not an “if” there, for example when we proof H from G to M is a homomorphism, the definition is for every a,b in G, H(ab)=H(a)H(b), does this definition mean that “if a,b in G, then…” so whenever I do this proof I do not need to worry about if G is empty or not ,because we assume that , but i see some logic book it says that for every is quantifiers may be it doesn’t mean if.")#linebreak()#text(" i went to ask my professor, he said that i need not worry much about those things, i need to use common sense, but to me, common sense does not work!!! am i too stupid to understand? but my math is excellent at middel school and university. because i do not notice those things before, but when I notice them, i really feel so confused! what should I do now? i even want to drop school~")

#text("I really love math, but now i really confused by those problems and i feel i can not do math anymore, i think it is time for me to learn some logic right now, can you give me some advices and introduce some logic book to me, which can explain my question very clearly in it and easy to read?")

#text("thanks very much Dr Tao")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shillo")]], [#link("https://terrytao.wordpress.com/2011/11/13/254a-notes-9-applications-of-the-structural-theory-of-approximate-groups/#comment-114022")[#strong[#text("shillo")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2011")])]

#text("Actually, there -are- specific rules for this stuff. First, it’s not really true that every mathematical sentence can be written only as ‘if… then…’ – you also need quantifiers. In your example, ‘Let G be a group. Then…’ actually means ‘For every group G, …’ or equivalently, ‘For every unspecified mathematical object G, if G is a group, then …’")

#text("In mathematical logic, ‘for every’ does not imply ‘there exists’. So you do always need to assume or prove that you are not dealing with empty sets. The reason why this is required are deMorgan laws for quantifiers. 1st de Morgan law: FOR ALL x.P(x) NOT EXISTS x.NOT P(x) In other words, ‘every group G has unit element’ is equivalent to saying ‘there is no group G such that is does not have a unit element’. But for this to hold, ‘every group G has unit element’ has to be true even if groups didn’t actually exist, because in that case, ‘there is no group G such that…’ would automatically be true.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tanaka")]], [#link("https://terrytao.wordpress.com/2011/11/13/254a-notes-9-applications-of-the-structural-theory-of-approximate-groups/#comment-105250")[#strong[#text("tanaka")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2011")])]

#text("yan, I think, “group” means all the sets")#linebreak()#text(" that permits group operations and group axioms .")#linebreak()#text(" Therefore, “empty-group” is not a group.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2011/11/13/254a-notes-9-applications-of-the-structural-theory-of-approximate-groups/#comment-105649")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2011")])]

#text("Does Hrushovski’s work already give by itself an alternative proof of Gromov?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2011/11/13/254a-notes-9-applications-of-the-structural-theory-of-approximate-groups/#comment-105653")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2011")])]

#text("Harald: yes it does, and in fact of a generalisation (as we remark in the paper). All of these arguments are fairly related to one another, and indeed to Gromov’s original argument.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/11/13/254a-notes-9-applications-of-the-structural-theory-of-approximate-groups/#comment-105719")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2011")])]

#text("In a bit more detail: given a group G of polynomial growth, Hrushovski shows that large balls in G can be (virtually) modeled by some Lie group L, which gives a homomorphism from (a finite index subgroup of) G into L. This homomorphism may initially be trivial (or have finite image), but by precomposing with a suitable (nonstandard) inner automorphism of G first, we can force it to have infinite image (unless all conjugacy classes are bounded, but in that case it is easy to show that G is virtually abelian). Then, by applying Gromov’s theorem for finitely generated subgroups of Lie groups (which can be established in a number of ways, e.g. Tits alternative) the image of G in L must be virtually nilpotent, which by standard arguments shows that (a finite index subgroup of) G has an infinite abelianisation. Passing to the commutator subgroup, we obtain a group of lower growth (or, alternatively, a group that is asymptotically modeled by a Lie group of smaller dimension) and one can then continue by induction (similarly to the induction on dimension in our result classifying approximate groups). (But one needs to also know something like Gromov’s theorem for solvable groups (i.e. the Milnor-Wolf theorem) to pass back from the commutator subgroup back to the original group.)")

#text("Gromov’s original proof is very similar to this, but models large balls by a finite-dimensional metric space, and has a homomorphism from G to the isometry group of that space.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2011/11/13/254a-notes-9-applications-of-the-structural-theory-of-approximate-groups/#comment-105751")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2011")])]

#text("– but the bit where you look at the Cayley graph from very far away disappears, I take, being replaced by Hrushovski’s argument. Or can Hrushovski’s argument also be understood in these terms?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/11/13/254a-notes-9-applications-of-the-structural-theory-of-approximate-groups/#comment-105762")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2011")])]

#text("It’s very similar. Gromov is studying the asymptotic structure of a large ball in the Cayley graph, viewed as a metric space with a rescaled metric (so that the ball becomes of bounded radius). Hrushovski is studying the asymptotic structure of a large ball in the Cayley graph, viewed as an approximate group – so the focus is on the group structure rather than the metric structure. One could carry both the metric structure and the group structure over to the ultralimit, which would lead to a hybrid between the Hrushovski and Gromov arguments which would be slightly simpler than either argument separately (one would not need things like the Sanders lemma to get the local compactness of the relevant group models, because one already has a lot of small balls available to substitute for this lemma). But then it would be more difficult to get the strengthening of Gromov’s theorem that Hrushovski gives in his paper, in which he considers more general sets than large balls.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2011/11/13/254a-notes-9-applications-of-the-structural-theory-of-approximate-groups/#comment-106140")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2011")])]

#text("There is no difference between metric (on the Cayley graph) and algebraic structure of the group.")

#text("Question: is there any correspondence between these terms:")

#text("– classification of approximate groups up to rough equivalence")

#text("– classification of (Cayley graphs of) groups up to quasi-isometry?")

#text("I think it’s the same problem, only the tools differ.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/11/13/254a-notes-9-applications-of-the-structural-theory-of-approximate-groups/#comment-106378")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2011")])]

#text("Actually, I believe the metric problem is much harder. For instance, it is still an open question whether two non-commensurable finitely generated torsion-free nilpotent groups can be quasi-isometric. (A well-known modification of Pansu’s argument shows that such groups must have the same asymptotic Carnot group, but this does not fully determine the group structure.) In contrast, the approximate groups in torsion-free nilpotent groups have been completely classified ")#link("http://arxiv.org/abs/0906.3598")[#text("by Breuillard and Green")]#text(".")

#text("The problem is that one needs to know the entire metric structure exactly (at both micro and macro scales) to reconstruct the group structure (and vice versa). Knowing the metric structure up to quasi-isometry is not obviously sufficient to reconstruct the group structure, even approximately.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2011/11/13/254a-notes-9-applications-of-the-structural-theory-of-approximate-groups/#comment-106836")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2011")])]

#text("Question (please erase if not appropriate): as a metric space is just a particular example of a normed groupoid, could you point me to papers where “approximate groupoids” are studied? For starters, something like an extension of your paper “Product set estimates for non-commutative groups”, along the lines in the introduction “one also consider partial sum sets …”, could be relevant, but I am unable to locate any. Following your proofs could be straightforward, but lengthy. Has this been done?")

#text("For example, a ")#mi("k")#text(" approximate groupoid ")#mi("A \\subset G")#text(" of a groupoid ")#mi("G")#text(" (where ")#mi("G")#text(" denotes the set of arrows) could be a")

#text("(i)- symmetric subset of ")#mi("G")#text(": ")#mi("A = A^{-1}")#text(", for any ")#mi("x \\in Ob(G)")#text(" ")#mi("id_{x} \\in A")#text(" and")

#text("(ii)- there is another, symmetric subset ")#mi("K \\subset G")#text(" such that for any ")#mi("(u,v)  \\in (A \\times A) \\cap G^{(2)}")#text(" there are ")#mi("(w,g) \\in (A \\times K) \\cap G^{(2)}")#text(" such that")

#mi("uv = wg")#text(",")

#text("(iii)- for any ")#mi("x \\in Ob(G)")#text(" we have ")#mi("\\mid K_{x} \\mid \\leq k")#text(".")

#text("One may replace the cardinal, as you did, by a measure (or random walk kernel, etc), or even by a norm.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 5: Product theorems, pivot arguments, and the Larsen-Pink non-concentration inequality « What’s new")]], [#link("https://terrytao.wordpress.com/2011/11/13/254a-notes-9-applications-of-the-structural-theory-of-approximate-groups/#comment-126698")[#strong[#text("254B, Notes 5: Product theorems, pivot arguments, and the Larsen-Pink non-concentration inequality « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("[…] theorem in solvable groups (or the Helfgott-Lindenstrauss conjecture, discussed in the previous quarter’s notes), one can give even more precise descriptions of (at the cost of losing polynomial dependence of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Approximate groupoids may be useful | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/11/13/254a-notes-9-applications-of-the-structural-theory-of-approximate-groups/#comment-151357")[#strong[#text("Approximate groupoids may be useful | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2012")])]

#text("[…] I just remembered a comment that I have made last november on the blog of Tao, where I proposed to study “approximate […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/11/13/254a-notes-9-applications-of-the-structural-theory-of-approximate-groups/#comment-169145")[#strong[#text("chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2012")])]

#text("Maybe this is the good place to ask the following question. Background first: the computational complexity of (running time of an algorithm for) multiplication in a Lie group varies wildly with the group, for example from the case when the group is abelian, to the case of a general linear group.")

#text("For approximate groups, your result with Breuillard and Green gives models which are noncomutative progressions in nilpotent groups.")

#text("My question is: can we deduce from your result some estimates for the computational complexity of the multiplication operation in an approximate group?")

#text("As a starting point I asked ")#link("http://mathoverflow.net/questions/106899/computational-complexity-of-multiplication-in-a-nilpotent-group")[#text("this question")]#text(" at mathoverflow. See also (edit if spam, please) ")#link("http://chorasimilarity.wordpress.com/2011/09/02/combinatorics-versus-geometric/")[#text("this half-joking post")]#text(" which asks for a positional number system (hence an efficient algorithm for multiplication) in a Carnot group, by using its intrinsic self-similarity.")
]
