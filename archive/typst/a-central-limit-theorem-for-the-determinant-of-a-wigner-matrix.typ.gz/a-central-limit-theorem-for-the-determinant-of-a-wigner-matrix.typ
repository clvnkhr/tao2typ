// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/11/28/a-central-limit-theorem-for-the-determinant-of-a-wigner-matrix/
// Converted to Typst by tao2typ: "2026-10-14T09:21:09.407044+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A central limit theorem for the determinant of a Wigner matrix", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A central limit theorem for the determinant of a Wigner matrix")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 November 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/11/28/a-central-limit-theorem-for-the-determinant-of-a-wigner-matrix/")[#text("https://terrytao.wordpress.com/2011/11/28/a-central-limit-theorem-for-the-determinant-of-a-wigner-matrix/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Van Vu and I have just uploaded to the arXiv our paper ")#link("http://arxiv.org/abs/1111.6300")[#text("A central limit theorem for the determinant of a Wigner matrix")]#text(", submitted to ")#link("http://www.journals.elsevier.com/advances-in-mathematics/")[#text("Adv. Math.")]#text(". It studies the asymptotic distribution of the determinant ")#mi("{\\det M_n}")#text(" of a random Wigner matrix (such as a matrix drawn from the ")#link("http://en.wikipedia.org/wiki/Random_matrix#Gaussian_ensembles")[#text("Gaussian Unitary Ensemble")]#text(" (GUE) or ")#link("http://en.wikipedia.org/wiki/Random_matrix#Gaussian_ensembles")[#text("Gaussian Orthogonal Ensemble")]#text(" (GOE)).")

#text("Before we get to these results, let us first discuss the simpler problem of studying the determinant ")#mi("{\\det A_n}")#text(" of a random ")#emph[#text("iid")]#text(" matrix ")#mi("{A_n = (\\zeta_{ij})_{1 \\leq i,j \\leq n}}")#text(", such as a real gaussian matrix (where all entries are independently and identically distributed using the standard real normal distribution ")#mi("{\\zeta_{ij} \\equiv N(0,1)_{\\bf R}}")#text("), a complex gaussian matrix (where all entries are independently and identically distributed using the standard complex normal distribution ")#mi("{\\zeta_{ij} \\equiv N(0,1)_{\\bf C}}")#text(", thus the real and imaginary parts are independent with law ")#mi("{N(0,1/2)_{\\bf R}}")#text("), or the random sign matrix (in which all entries are independently and identically distributed according to the Bernoulli distribution ")#mi("{\\zeta_{ij} \\equiv \\pm 1}")#text(" (with a ")#mi("{1/2}")#text(" chance of either sign). More generally, one can consider a matrix ")#mi("{A_n}")#text(" in which all the entries ")#mi("{\\zeta_{ij}}")#text(" are independently and identically distributed with mean zero and variance ")#mi("{1}")#text(".")

#text("We can expand ")#mi("{\\det A_n}")#text(" using the Leibniz expansion ")#metadata(none) <tao-6a63d2deee991139261b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\det A_n = \\sum_{\\sigma \\in S_n} I_\\sigma,")]]

#text("where ")#mi("{\\sigma: \\{1,\\ldots,n\\} \\rightarrow \\{1,\\ldots,n\\}}")#text(" ranges over the permutations of ")#mi("{\\{1,\\ldots,n\\}}")#text(", and ")#mi("{I_\\sigma}")#text(" is the product")

#align(center)[#tao-fit-display[#mitex("I_\\sigma := \\text{sgn}(\\sigma) \\prod_{i=1}^n \\zeta_{i\\sigma(i)}.")]]

#text("From the iid nature of the ")#mi("{\\zeta_{ij}}")#text(", we easily see that each ")#mi("{I_\\sigma}")#text(" has mean zero and variance one, and are pairwise uncorrelated as ")#mi("{\\sigma}")#text(" varies. We conclude that ")#mi("{\\det A_n}")#text(" has mean zero and variance ")#mi("{n!}")#text(" (an observation first made by Turán). In particular, from Chebyshev’s inequality we see that ")#mi("{\\det A_n}")#text(" is typically of size ")#mi("{O(\\sqrt{n!})}")#text(".")

#text("It turns out, though, that this is not quite best possible. This is easiest to explain in the real gaussian case, by performing a computation first made ")#link("http://www.ams.org/mathscinet-getitem?mr=145619")[#text("by Goodman")]#text(". In this case, ")#mi("{\\det A_n}")#text(" is clearly symmetrical, so we can focus attention on the magnitude ")#tao-math("{\\left|\\det A_n\\right|}", block: false)#text(". We can interpret this quantity geometrically as the volume of an ")#mi("{n}")#text("-dimensional parallelopiped whose generating vectors ")#mi("{X_1,\\ldots,X_n}")#text(" are independent real gaussian vectors in ")#mi("{{\\bf R}^n}")#text(" (i.e. their coefficients are iid with law ")#mi("{N(0,1)_{\\bf R}}")#text("). Using the classical base-times-height formula, we thus have ")#metadata(none) <tao-ae621822f6aee31fd282>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|\\det A_n\\right| = \\prod_{i=1}^n \\text{dist}(X_i, V_i)", block: true)]]

#text("where ")#mi("{V_i}")#text(" is the ")#mi("{i-1}")#text("-dimensional linear subspace of ")#mi("{{\\bf R}^n}")#text(" spanned by ")#mi("{X_1,\\ldots,X_{i-1}}")#text(" (note that ")#mi("{X_1,\\ldots,X_n}")#text(", having an absolutely continuous joint distribution, are almost surely linearly independent). Taking logarithms, we conclude")

#align(center)[#tao-fit-display[#tao-math("\\log \\left|\\det A_n\\right| = \\sum_{i=1}^n \\log \\text{dist}(X_i, V_i).", block: true)]]

#text("Now, we take advantage of a fundamental symmetry property of the Gaussian vector distribution, namely its invariance with respect to the orthogonal group ")#mi("{O(n)}")#text(". Because of this, we see that if we fix ")#mi("{X_1,\\ldots,X_{i-1}}")#text(" (and thus ")#mi("{V_i}")#text(", the random variable ")#mi("{\\text{dist}(X_i,V_i)}")#text(" has the same distribution as ")#mi("{\\text{dist}(X_i,{\\bf R}^{i-1})}")#text(", or equivalently the ")#link("http://en.wikipedia.org/wiki/Chi_distribution")[#mi("{\\chi}")#text(" distribution")]

#align(center)[#tao-fit-display[#mitex("\\chi_{n-i+1} := (\\sum_{j=1}^{n-i+1} \\xi_{n-i+1,j}^2)^{1/2}")]]

#text("where ")#mi("{\\xi_{n-i+1,1},\\ldots,\\xi_{n-i+1,n-i+1}}")#text(" are iid copies of ")#mi("{N(0,1)_{\\bf R}}")#text(". As this distribution does not depend on the ")#mi("{X_1,\\ldots,X_{i-1}}")#text(", we conclude that the law of ")#tao-math("{\\log \\left|\\det A_n\\right|}", block: false)#text(" is given by the sum of ")#mi("{n}")#text(" independent ")#mi("{\\chi}")#text("-variables:")

#align(center)[#tao-fit-display[#tao-math("\\log \\left|\\det A_n\\right| \\equiv \\sum_{j=1}^{n} \\log \\chi_j.", block: true)]]

#text("A standard computation shows that each ")#mi("{\\chi_j^2}")#text(" has mean ")#mi("{j}")#text(" and variance ")#mi("{2j}")#text(", and then a Taylor series (or Ito calculus) computation (using concentration of measure tools to control tails) shows that ")#mi("{\\log \\chi_j}")#text(" has mean ")#mi("{\\frac{1}{2} \\log j - \\frac{1}{2j} + O(1/j^{3/2})}")#text(" and variance ")#mi("{\\frac{1}{2j}+O(1/j^{3/2})}")#text(". As such, ")#tao-math("{\\log \\left|\\det A_n\\right|}", block: false)#text(" has mean ")#mi("{\\frac{1}{2} \\log n! - \\frac{1}{2} \\log n + O(1)}")#text(" and variance ")#mi("{\\frac{1}{2} \\log n + O(1)}")#text(". Applying a suitable version of the central limit theorem, one obtains the asymptotic law ")#metadata(none) <tao-49915e0d7d4b402e3017>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\frac{\\log \\left|\\det A_n\\right| - \\frac{1}{2} \\log n! + \\frac{1}{2} \\log n}{\\sqrt{\\frac{1}{2}\\log n}} \\rightarrow N(0,1)_{\\bf R},", block: true)]]

#text("where ")#mi("{\\rightarrow}")#text(" denotes convergence in distribution. A bit more informally, we have ")#metadata(none) <tao-d86373564974e3b94895>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|\\det A_n\\right| \\approx n^{-1/2} \\sqrt{n!} \\exp( N( 0, \\log n / 2 )_{\\bf R} )", block: true)]]

#text("when ")#mi("{A_n}")#text(" is a real gaussian matrix; thus, for instance, the median value of ")#tao-math("{\\left|\\det A_n\\right|}", block: false)#text(" is ")#mi("{n^{-1/2+o(1)} \\sqrt{n!}}")#text(". At first glance, this appears to conflict with the second moment bound ")#tao-math("{\\mathop{\\bf E} \\left|\\det A_n\\right|^2 = n!}", block: false)#text(" of Turán mentioned earlier, but once one recalls that ")#mi("{\\exp(N(0,t)_{\\bf R})}")#text(" has a second moment of ")#mi("{\\exp(2t)}")#text(", we see that the two facts are in fact perfectly consistent; the upper tail of the normal distribution in the exponent in ")#link(<tao-d86373564974e3b94895>)[#text("(4)")]#text(" ends up dominating the second moment.")

#text("It turns out that the central limit theorem ")#link(<tao-49915e0d7d4b402e3017>)[#text("(3)")]#text(" is valid for any real iid matrix with mean zero, variance one, and an exponential decay condition on the entries; this was first claimed ")#link("http://www.ams.org/mathscinet-getitem?mr=1453330")[#text("by Girko")]#text(", though the arguments in that paper appear to be incomplete. Another proof of this result, with more quantitative bounds on the convergence rate has been ")#link("http://arxiv.org/abs/1112.0752")[#text("recently obtained by Hoi Nguyen and Van Vu")]#text(". The basic idea in these arguments is to express the sum in ")#link(<tao-ae621822f6aee31fd282>)[#text("(2)")]#text(" in terms of a martingale and apply the martingale central limit theorem.")

#text("If one works with complex gaussian random matrices instead of real gaussian random matrices, the above computations change slightly (one has to replace the real ")#mi("{\\chi}")#text(" distribution with the complex ")#mi("{\\chi}")#text(" distribution, in which the ")#mi("{\\xi_{i,j}}")#text(" are distributed according to the complex gaussian ")#mi("{N(0,1)_{\\bf C}}")#text(" instead of the real one). At the end of the day, one ends up with the law ")#metadata(none) <tao-90498605bb179cd22ca8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\frac{\\log \\left|\\det A_n\\right| - \\frac{1}{2} \\log n! + \\frac{1}{4} \\log n}{\\sqrt{\\frac{1}{4}\\log n}} \\rightarrow N(0,1)_{\\bf R},", block: true)]]

#text("or more informally ")#metadata(none) <tao-54e8f196ebbf32b602cd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left|\\det A_n\\right| \\approx n^{-1/4} \\sqrt{n!} \\exp( N( 0, \\log n / 4 )_{\\bf R} )", block: true)]]

#text("(but note that this new asymptotic is still consistent with Turán’s second moment calculation).")

#text("We can now turn to the results of our paper. Here, we replace the iid matrices ")#mi("{A_n}")#text(" by ")#emph[#text("Wigner matrices")]#text(" ")#mi("{M_n = (\\zeta_{ij})_{1 \\leq i,j \\leq n}}")#text(", which are defined similarly but are constrained to be Hermitian (or real symmetric), thus ")#mi("{\\zeta_{ij} = \\overline{\\zeta_{ji}}}")#text(" for all ")#mi("{i,j}")#text(". Model examples here include the ")#link("http://en.wikipedia.org/wiki/Random_matrix#Gaussian_ensembles")[#text("Gaussian Unitary Ensemble")]#text(" (GUE), in which ")#mi("{\\zeta_{ij} \\equiv N(0,1)_{\\bf C}}")#text(" for ")#mi("{1 \\leq i < j \\leq n}")#text(" and ")#mi("{\\zeta_{ij} \\equiv N(0,1)_{\\bf R}}")#text(" for ")#mi("{1 \\leq i=j \\leq n}")#text(", the ")#link("http://en.wikipedia.org/wiki/Random_matrix#Gaussian_ensembles")[#text("Gaussian Orthogonal Ensemble")]#text(" (GOE), in which ")#mi("{\\zeta_{ij} \\equiv N(0,1)_{\\bf R}}")#text(" for ")#mi("{1 \\leq i < j \\leq n}")#text(" and ")#mi("{\\zeta_{ij} \\equiv N(0,2)_{\\bf R}}")#text(" for ")#mi("{1 \\leq i=j \\leq n}")#text(", and the ")#emph[#text("symmetric Bernoulli ensemble")]#text(", in which ")#mi("{\\zeta_{ij} \\equiv \\pm 1}")#text(" for ")#mi("{1 \\leq i \\leq j \\leq n}")#text(" (with probability ")#mi("{1/2}")#text(" of either sign). In all cases, the upper triangular entries of the matrix are assumed to be jointly independent. For a more precise definition of the Wigner matrix ensembles we are considering, see the introduction to ")#link("http://arxiv.org/abs/1111.6300")[#text("our paper")]#text(".")

#text("The determinants ")#mi("{\\det M_n}")#text(" of these matrices still have a Leibniz expansion. However, in the Wigner case, the mean and variance of the ")#mi("{I_\\sigma}")#text(" are slightly different, and what is worse, they are not all pairwise uncorrelated any more. For instance, the mean of ")#mi("{I_\\sigma}")#text(" is still usually zero, but equals ")#mi("{(-1)^{n/2}}")#text(" in the exceptional case when ")#mi("{\\sigma}")#text(" is a perfect matching (i.e. the union of exactly ")#mi("{n/2}")#text(" ")#mi("{2}")#text("-cycles, a possibility that can of course only happen when ")#mi("{n}")#text(" is even). As such, the mean ")#mi("{\\mathop{\\bf E} \\det M_n}")#text(" still vanishes when ")#mi("{n}")#text(" is odd, but for even ")#mi("{n}")#text(" it is equal to")

#align(center)[#tao-fit-display[#mitex("(-1)^{n/2} \\frac{n!}{(n/2)!2^{n/2}}")]]

#text("(the fraction here simply being the number of perfect matchings on ")#mi("{n}")#text(" vertices). Using Stirling’s formula, one then computes that ")#tao-math("{\\left|\\mathop{\\bf E} \\det A_n\\right|}", block: false)#text(" is comparable to ")#mi("{n^{-1/4} \\sqrt{n!}}")#text(" when ")#mi("{n}")#text(" is large and even. The second moment calculation is more complicated (and uses facts about the distribution of cycles in random permutations, mentioned in ")#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/")[#text("this previous post")]#text("), but one can compute that ")#tao-math("{\\mathop{\\bf E} \\left|\\det A_n\\right|^2}", block: false)#text(" is comparable to ")#mi("{n^{1/2} n!}")#text(" for GUE and ")#mi("{n^{3/2} n!}")#text(" for GOE. (The discrepancy here comes from the fact that in the GOE case, ")#mi("{I_\\sigma}")#text(" and ")#mi("{I_\\rho}")#text(" can correlate when ")#mi("{\\rho}")#text(" contains reversals of ")#mi("{k}")#text("-cycles of ")#mi("{\\sigma}")#text(" for ")#mi("{k \\geq 3}")#text(", but this does not happen in the GUE case.) For GUE, much more precise asymptotics for the moments of the determinant are known, starting from the ")#link("http://www.ams.org/mathscinet-getitem?mr=1794268")[#text("work of Brezin and Hikami")]#text(", though we do not need these more sophisticated computations here.")

#text("Our main results are then as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" Let ")#mi("{M_n}")#text(" be a Wigner matrix.")

#list(
[#text("If ")#mi("{M_n}")#text(" is drawn from GUE, then")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\log \\left|\\det M_n\\right| - \\frac{1}{2} \\log n! + \\frac{1}{4} \\log n}{\\sqrt{\\frac{1}{2}\\log n}} \\rightarrow N(0,1)_{\\bf R}.", block: true)]]],
[#text("If ")#mi("{M_n}")#text(" is drawn from GOE, then")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\log \\left|\\det M_n\\right| - \\frac{1}{2} \\log n! + \\frac{1}{4} \\log n}{\\sqrt{\\log n}} \\rightarrow N(0,1)_{\\bf R}.", block: true)]]],
[#text("The previous two results also hold for more general Wigner matrices, assuming that the real and imaginary parts are independent, a finite moment condition is satisfied, and the entries match moments with those of GOE or GUE to fourth order. (See the paper for a more precise formulation of the result.)")]
)
]

#text("Thus, we informally have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\det M_n\\right| \\approx n^{-1/4} \\sqrt{n!} \\exp( N( 0, \\log n / 2 )_{\\bf R} )", block: true)]]

#text("when ")#mi("{M_n}")#text(" is drawn from GUE, or from another Wigner ensemble matching GUE to fourth order (and obeying some additional minor technical hypotheses); and")

#align(center)[#tao-fit-display[#tao-math("\\left|\\det M_n\\right| \\approx n^{-1/4} \\sqrt{n!} \\exp( N( 0, \\log n )_{\\bf R} )", block: true)]]

#text("when ")#mi("{M_n}")#text(" is drawn from GOE, or from another Wigner ensemble matching GOE to fourth order. Again, these asymptotic limiting distributions are consistent with the asymptotic behaviour for the second moments.")

#text("The extension from the GUE or GOE case to more general Wigner ensembles is a fairly routine application of the ")#emph[#text("four moment theorem")]#text(" for Wigner matrices, although for various technical reasons we do not quite use the existing four moment theorems in the literature, but adapt them to the log determinant. The main idea is to express the log-determinant as an integral ")#metadata(none) <tao-aeb81ee0b74078ec2a7b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\log\\left|\\det M_n\\right| = \\frac{1}{2} n \\log n - n \\text{Im} \\int_0^\\infty s(\\sqrt{-1}\\eta)\\ d\\eta", block: true)]]

#text("of the Stieltjes transform")

#align(center)[#tao-fit-display[#mitex("s(z) := \\frac{1}{n} \\text{tr}( \\frac{1}{\\sqrt{n}} M_n - z )^{-1}")]]

#text("of ")#mi("{M_n}")#text(". Strictly speaking, the integral in ")#link(<tao-aeb81ee0b74078ec2a7b>)[#text("(7)")]#text(" is divergent at infinity (and also can be ill-behaved near zero), but this can be addressed by standard truncation and renormalisation arguments (combined with known facts about the least singular value of Wigner matrices), which we omit here. We then use a variant of the four moment theorem for the Stieltjes transform, as used ")#link("http://arxiv.org/abs/1001.3453")[#text("by Erdos, Yau, and Yin")]#text(" (based on a previous four moment theorem for individual eigenvalues introduced ")#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/")[#text("by Van Vu and myself")]#text("). The four moment theorem is proven by the now-standard Lindeberg exchange method, combined with the usual resolvent identities to control the behaviour of the resolvent (and hence the Stieltjes transform) with respect to modifying one or two entries, together with the delocalisation of eigenvector property (which in turn arises from local semicircle laws) to control the error terms.")

#text("Somewhat surprisingly (to us, at least), it turned out that it was the first part of the theorem (namely, the verification of the limiting law for the invariant ensembles GUE and GOE) that was more difficult than the extension to the Wigner case. Even in an ensemble as highly symmetric as GUE, the rows are no longer independent, and the formula ")#link(<tao-ae621822f6aee31fd282>)[#text("(2)")]#text(" is basically useless for getting any non-trivial control on the log determinant. There is an explicit formula for the joint distribution of the eigenvalues of GUE (or GOE), which does eventually give the distribution of the cumulants of the log determinant, which then gives the required central limit theorem; but this is a lengthy computation, first performed ")#link("http://www.ams.org/mathscinet-getitem?mr=2006448")[#text("by Delannay and Le Caer")]#text(".")

#text("Following a suggestion of my colleague, Rowan Killip, we give an alternate proof of this central limit theorem in the GUE and GOE cases, by using a beautiful ")#link("http://www.ams.org/mathscinet-getitem?mr=761763")[#text("observation of Trotter")]#text(", namely that the GUE or GOE ensemble can be conjugated into a tractable ")#link("http://en.wikipedia.org/wiki/Tridiagonal_matrix")[#text("tridiagonal")]#text(" form. Let me state it just for GUE:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Tridiagonal form of GUE)")]#text(" ")#metadata(none) <tao-1df0ace572bdd885a1a1>#text(" Let ")#mi("{M^{\\prime}_n}")#text(" be the random tridiagonal real symmetric matrix")

#align(center)[#tao-fit-display[#mitex("M^{\\prime}_n = \\begin{pmatrix} a_1 & b_1 & 0 & \\ldots & 0 & 0 \\\\ b_1 & a_2 & b_2 & \\ldots & 0 & 0 \\\\ 0 & b_2 & a_3 & \\ldots & 0 & 0 \\\\ \\vdots & \\vdots & \\vdots & \\ddots & \\vdots & \\vdots \\\\ 0 & 0 & 0 & \\ldots & a_{n-1} & b_{n-1} \\\\ 0 & 0 & 0 & \\ldots & b_{n-1} & a_n \\end{pmatrix}")]]

#text("where the ")#mi("{a_1,\\ldots,a_n, b_1,\\ldots,b_{n-1}}")#text(" are jointly independent real random variables, with ")#mi("{a_1,\\ldots,a_n \\equiv N(0,1)_{\\bf R}}")#text(" being standard real Gaussians, and each ")#mi("{b_i}")#text(" having a ")#mi("{\\chi}")#text("-distribution:")

#align(center)[#tao-fit-display[#tao-math("b_i = (\\sum_{j=1}^i \\left|z_{i,j}\\right|^2)^{1/2}", block: true)]]

#text("where ")#mi("{z_{i,j} \\equiv N(0,1)_{\\bf C}}")#text(" are iid complex gaussians. Let ")#mi("{M_n}")#text(" be drawn from GUE. Then the joint eigenvalue distribution of ")#mi("{M_n}")#text(" is identical to the joint eigenvalue distribution of ")#mi("{M^{\\prime}_n}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{M_n}")#text(" be drawn from GUE. We can write")

#align(center)[#tao-fit-display[#mitex("M_n = \\begin{pmatrix} M_{n-1} & X_n \\\\ X_n^* & a_n \\end{pmatrix}")]]

#text("where ")#mi("{M_{n-1}}")#text(" is drawn from the ")#mi("{n-1\\times n-1}")#text(" GUE, ")#mi("{a_n \\equiv N(0,1)_{\\bf R}}")#text(", and ")#mi("{X_n \\in {\\bf C}^{n-1}}")#text(" is a random gaussian vector with all entries iid with distribution ")#mi("{N(0,1)_{\\bf C}}")#text(". Furthermore, ")#mi("{M_{n-1}, X_n, a_n}")#text(" are jointly independent.")

#text("We now apply the tridiagonal matrix algorithm. Let ")#tao-math("{b_{n-1} := \\left|X_n\\right|}", block: false)#text(", then ")#mi("{b_n}")#text(" has the ")#mi("{\\chi}")#text("-distribution indicated in the proposition. We then conjugate ")#mi("{M_n}")#text(" by a unitary matrix ")#mi("{U}")#text(" that preserves the final basis vector ")#mi("{e_n}")#text(", and maps ")#mi("{X}")#text(" to ")#mi("{b_{n-1} e_{n-1}}")#text(". Then we have")

#align(center)[#tao-fit-display[#mitex("U M_n U^* = \\begin{pmatrix} \\tilde M_{n-1} & b_{n-1} e_{n-1} \\\\ b_{n-1} e_{n-1}^* & a_n \\end{pmatrix}")]]

#text("where ")#mi("{\\tilde M_{n-1}}")#text(" is conjugate to ")#mi("{M_{n-1}}")#text(". Now we make the crucial observation: because ")#mi("{M_{n-1}}")#text(" is distributed according to GUE (which is a unitarily invariant ensemble), and ")#mi("{U}")#text(" is a unitary matrix independent of ")#mi("{M_{n-1}}")#text(", ")#mi("{\\tilde M_{n-1}}")#text(" is also distributed according to GUE, and remains independent of both ")#mi("{b_{n-1}}")#text(" and ")#mi("{a_n}")#text(".")

#text("We continue this process, expanding ")#mi("{U M_n U^*}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} M_{n-2} & X_{n-1} & 0 \\\\ X_{n-1}^* & a_{n-1} & b_{n-1} \\\\ 0 & b_{n-1} & a_n. \\end{pmatrix}")]]

#text("Applying a further unitary conjugation that fixes ")#mi("{e_{n-1}, e_n}")#text(" but maps ")#mi("{X_{n-1}}")#text(" to ")#mi("{b_{n-2} e_{n-2}}")#text(", we may replace ")#mi("{X_{n-1}}")#text(" by ")#mi("{b_{n-2} e_{n-2}}")#text(" while transforming ")#mi("{M_{n-2}}")#text(" to another GUE matrix ")#mi("{\\tilde M_{n-2}}")#text(" independent of ")#mi("{a_n, b_{n-1}, a_{n-1}, b_{n-2}}")#text(". Iterating this process, we eventually obtain a coupling of ")#mi("{M_n}")#text(" to ")#mi("{M^{\\prime}_n}")#text(" by unitary conjugations, and the claim follows. ")#mi("\\Box")

#text("The determinant of a tridiagonal matrix is not quite as simple as the determinant of a triangular matrix (in which it is simply the product of the diagonal entries), but it is pretty close: the determinant ")#mi("{D_n}")#text(" of the above matrix is given by solving the recursion")

#align(center)[#tao-fit-display[#mitex("D_i = a_i D_{i-1} + b_{i-1}^2 D_{i-2}")]]

#text("with ")#mi("{D_0=1}")#text(" and ")#mi("{D_{-1} = 0}")#text(". Thus, instead of the product of a sequence of independent scalar ")#mi("{\\chi}")#text(" distributions as in the gaussian matrix case, the determinant of GUE ends up being controlled by the product of a sequence of independent ")#mi("{2\\times 2}")#text(" matrices whose entries are given by gaussians and ")#mi("{\\chi}")#text(" distributions. In this case, one cannot immediately take logarithms and hope to get something for which the martingale central limit theorem can be applied, but some ")#emph[#text("ad hoc")]#text(" manipulation of these ")#mi("{2 \\times 2}")#text(" matrix products eventually does make this strategy work. (Roughly speaking, one has to work with the logarithm of the Frobenius norm of the matrix first.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad3f3a79ef213c98c05db1ab441cb92661583507ac1a7a5e31f4beaa785f1e3b-bd0c7862157994459c7704585bcfde3a1c363765d691789fd896ca4a5396e667.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Martin")]], [#link("https://terrytao.wordpress.com/2011/11/28/a-central-limit-theorem-for-the-determinant-of-a-wigner-matrix/#comment-110963")[#strong[#text("Greg Martin")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2011")])]

#text("Tiny typo, near the beginning when Chebyshev’s inequality is invoked: I think it should be $O(\\sqrt{n!})$, with a factorial. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aee8b264b23eab4a8ccdcdc0203b3d4da285321c2393053ae490290d2402c621-6051c260508c9a5c6bebd88a873dd2be62b8fc479a50f7353168143c373d680e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Florent Benaych-Georges")]], [#link("https://terrytao.wordpress.com/2011/11/28/a-central-limit-theorem-for-the-determinant-of-a-wigner-matrix/#comment-111003")[#strong[#text("Florent Benaych-Georges")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2011")])]

#text("Tiny typo : “Brezis” should be “Brezin”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/465e452b72a331e7d1d88cdb79c6d3341f87302ad39bc86694c52505eb1ff0c2-7c02a2158a30ac286415431ec989d5a2e3c99c658b54d0851eb77fb9df04283f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Eichelsbacher")]], [#link("https://terrytao.wordpress.com/2011/11/28/a-central-limit-theorem-for-the-determinant-of-a-wigner-matrix/#comment-111039")[#strong[#text("Peter Eichelsbacher")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2011")])]

#text("Tiny typos: in Theorem 3, Wigner matrix obeying Condition C1 (not C0),")#linebreak()#text(" and in the statement for the second moment: If M_n is drawn (twice). ")#emph[#text("[Thanks, this will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xavier Gabaix")]], [#link("https://terrytao.wordpress.com/2011/11/28/a-central-limit-theorem-for-the-determinant-of-a-wigner-matrix/#comment-111090")[#strong[#text("Xavier Gabaix")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2011")])]

#text("Tiny typo: right below (7), the definition of the Stieltjes transform has M in the numerator. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1146a79cf2889ef6240d01295ad856cf6a6896f1c6cb8b06bd68bf80e096d23-1af354bc03cd30b99db4b868249f75e44fa84e428e665f89216cda1fd03d76bf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yunqing2010")]], [#link("https://terrytao.wordpress.com/2011/11/28/a-central-limit-theorem-for-the-determinant-of-a-wigner-matrix/#comment-111129")[#strong[#text("yunqing2010")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2011")])]

#text("Does the right hand of (7) miss a term like ")#tao-fit-display[#tao-math("\\log \\left| det (\\frac{M_n}{\\sqrt{n}} – \\sqrt{-1}\\infty)  \\right|", block: true)]#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/11/28/a-central-limit-theorem-for-the-determinant-of-a-wigner-matrix/#comment-111132")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2011")])]

#text("Yes, one needs to truncate and renormalise the integral in order to eliminate the ")#mi("\\log \\infty")#text(" type divergence. This is discussed in detail in the paper, but I am omitting it in this post as it is a minor technical issue rather than a principal difficulty in the argument.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df59c61dafad977652e1a4415300e637a8501d5d7e59c432f4383a646ecacb77-58c8f9a60c5bb2d85ec88e6a038629761e6ce21a45bcd1854a3d5a4c6c08a384.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jayadev Athreya")]], [#link("https://terrytao.wordpress.com/2011/11/28/a-central-limit-theorem-for-the-determinant-of-a-wigner-matrix/#comment-111242")[#strong[#text("Jayadev Athreya")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2011")])]

#text("In Theorem, 1, should it be M_n instead of A_n? ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e129a68dcf0bb46ecba772753b8f9af1ec273d49cbd7ace8069058648b03b58-7eb33440dcbae163fc1d170d08c9c52deb82d4eb4253cf0fbe7e8b13997f3aa7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2011/11/28/a-central-limit-theorem-for-the-determinant-of-a-wigner-matrix/#comment-111787")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2011")])]

#text("Tiny typo: Below (4), shouldn’t it be the median value of ")#tao-fit-display[#tao-math("\\left| det A_n \\right|", block: true)]#text(", not ")#tao-fit-display[#tao-math("\\log \\left| det A_n \\right|", block: true)]#text("? ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/11/28/a-central-limit-theorem-for-the-determinant-of-a-wigner-matrix/#comment-111831")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2011")])]

#text("Tiny typos: “gaussian” –> “Gaussian” (A total of 12 time if my counting is correct; 13 including the tags.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2424d4aa9d6a62475cee24a84a71be6cd9813da280d642a46ba3d43c726463c6-a4b67f2cdb6c998391c874669869eea482de8b057a7d9ee957572da6980eb32c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antonio")]], [#link("https://terrytao.wordpress.com/2011/11/28/a-central-limit-theorem-for-the-determinant-of-a-wigner-matrix/#comment-112023")[#strong[#text("Antonio")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2011")])]

#text("i Professor Tarece Tao. I am a student of thirteen years and I love math and, therefore, gives great I would do the math. I wanted to ask whether Godel’s incompleteness theorems imply that in mathematics there are many problems unsolved? if it is true, then there are infinitely many complex problems as the ‘Riemann Hypothesis, or even more complex? Thanks Professor, thanks for all she is my idol, I wanted to also ask where can I buy your books? Sorry for my poor English because I’m Italian.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c49b100674b1ac04b4c9171bc03aa01ea9e47b30fd23a6679a2027b2bf6ef6bc-1fea921ccc93a45b3f3239f73890801a801edf63721747bfe8ce0028f2aba5aa.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kmkosinski")]], [#link("https://terrytao.wordpress.com/2011/11/28/a-central-limit-theorem-for-the-determinant-of-a-wigner-matrix/#comment-113031")[#strong[#text("kmkosinski")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2011")])]

#text("The conclusion from (2) is that ")#tao-math("\\left|det A_n\\right|=\\prod_{j=1}^n \\chi_j", block: false)#text(", where ")#mi("\\chi_j")#text(" are independent ")#mi("\\chi")#text("-variables. That is, ")#mi("\\chi_i^2=\\sum_{j=1}^i X_{i,j}^2")#text(" and ")#mi("\\{X_{i,j}\\}")#text(" are iid such that ")#mi("X_{i,j}=Z_{i,j}^2")#text(", ")#mi("\\{Z_{i,j}\\}")#text(" ")#mi("N(0,1)")#text(" distributed.")

#text("Hence, ")#tao-math("\\left|\\det A_n\\right|^2=\\prod_{k=1}^n S_k,", block: false)#text(" where ")#mi("S_k=X_{k,1}+\\ldots+X_{k,k}")#text(". That is, ")#tao-math("\\left|\\det A_n\\right|^2", block: false)#text(" can be seen as a product of independent sums of iid random variables. Central limit theorem for such products (and its connection to Wishart determinants) has been discussed in G. Rempala, J. Wesolowski “Asymptotics for products of independent sums with an application to Wishart determinants”, Stat. Probab. Lett. 74 (2005) 129–138.")#linebreak()#text(" In particular, in this paper, it has been shown that for any sequence of iid positive square integrable random variables ")#mi("\\{X_{i,j}\\}")#text(" with finite absolute moment of order ")#mi("p>2")

#mi("\\left (\\frac{n^{\\gamma^2/2}}{n! \\mu^n}\\prod_{k=1}^n S_k \\right)^{1/(\\gamma\\sqrt{\\log n})}")#linebreak()#text(" ")#linebreak()#text(" tends in distribution to ")#mi("\\exp(N(0,1))")#text(", where ")#mi("\\mu= E X_{1,1}")#text(", ")#mi("\\sigma^2 = Var(X_{1,1})")#text(" and ")#mi("\\gamma=\\sigma/\\mu")#text(" is the coefficient of variation. In this case we have ")#mi("X_{i,j}=Z^2_{i,j}")#text(" so that ")#mi("\\mu=1")#text(", ")#mi("\\sigma^2=2")#text(", ")#mi("\\gamma=\\sqrt {2}")#text(". From this, clearly the result in (3) follows. The assumption on ")#mi("p>2")#text(" was later removed in K. Kosinski “Asymptotics for sums of a function of normalized independent sums, Stat. Probab. Lett. 79 (2009) 415–419, in the sense that a different normalization than ")#mi("n^{\\gamma^2/2}")#text(" is needed in the case ")#mi("p=2")#text(".")#linebreak()#text(" Various other generalizations have been considered for asymptotics for products of (not necessarily independent) sums of random variables.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/11/28/a-central-limit-theorem-for-the-determinant-of-a-wigner-matrix/#comment-114041")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2011")])]

#text("I am new to math research: what’s the significance of this? Should the references be included in the paper by professor Tao? Is the paper by prof. Tao completely derivative or not (is there an original contribution)?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random matrices: Universality of local spectral statistics of non-Hermitian matrices « What’s new")]], [#link("https://terrytao.wordpress.com/2011/11/28/a-central-limit-theorem-for-the-determinant-of-a-wigner-matrix/#comment-146840")[#strong[#text("Random matrices: Universality of local spectral statistics of non-Hermitian matrices « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2012")])]

#text("[…] paper), as well as central limit theorems for log-determinants of Wigner matrices (as we did in this other recent paper). In both of these papers, the main idea was to use the Four Moment Theorem for Wigner matrices […]")
]
