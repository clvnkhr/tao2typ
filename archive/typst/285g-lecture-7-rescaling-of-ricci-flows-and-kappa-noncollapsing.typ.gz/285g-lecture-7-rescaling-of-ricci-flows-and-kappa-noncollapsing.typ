// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/
// Converted to Typst by tao2typ: "2026-10-14T15:16:45.200158+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "285G, Lecture 7: Rescaling of Ricci flows and κ-noncollapsing", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("285G, Lecture 7: Rescaling of Ricci flows and κ-noncollapsing")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 April 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/")[#text("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("We now set aside our discussion of the finite time extinction results for Ricci flow with surgery (Theorem 4 from ")#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")[#text("Lecture 2")]#text("), and turn instead to the main portion of Perelman’s argument, which is to establish the global existence result for Ricci flow with surgery (Theorem 2 from ")#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")[#text("Lecture 2")]#text("), as well as the discreteness of the surgery times (Theorem 3 from ")#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")[#text("Lecture 2")]#text(").")

#text("As mentioned in ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text(", ")#emph[#text("local")]#text(" existence of the Ricci flow is a fairly standard application of nonlinear parabolic theory, once one uses de Turck’s trick to transform Ricci flow into an explicitly parabolic equation. The trouble is, of course, that Ricci flow can and does develop singularities (indeed, we have just spent several lectures showing that singularities must inevitably develop when certain topological hypotheses (e.g. simple connectedness) or geometric hypotheses (e.g. positive scalar curvature) occur). In principle, one can use surgery to remove the most singular parts of the manifold at every singularity time and then restart the Ricci flow, but in order to do this one needs some rather precise control on the geometry and topology of these singular regions. (In particular, there are some hypothetical bad singularity scenarios which cannot be easily removed by surgery, due to topological obstructions; a major difficulty in the Perelman program is to show that such scenarios in fact cannot occur in a Ricci flow.)")

#text("In order to analyse these singularities, Hamilton and then Perelman employed the standard nonlinear PDE technique of “blowing up” the singularity using the scaling symmetry, and then exploiting as much “compactness” as is available in order to extract an “asymptotic profile” of that singularity from a sequence of such blowups, which had better properties than the original Ricci flow. [The PDE notion of a blowing up a solution around a singularity, by the way, is vaguely analogous to the algebraic geometry notion of ")#link("http://en.wikipedia.org/wiki/Blowing_up")[#text("blowing up")]#text(" a variety around a singularity, though the two notions are certainly not identical.] A sufficiently good classification of all the possible asymptotic profiles will, in principle, lead to enough structural properties on general singularities to Ricci flow that one can see how to perform surgery in a manner which controls both the geometry and the topology.")

#text("However, in order to carry out this program it is necessary to obtain geometric control on the Ricci flow which does not deteriorate when one blows up the solution; in the jargon of nonlinear PDE, we need to obtain bounds on some quantity which is both ")#emph[#text("coercive")]#text(" (it bounds the geometry) and either ")#emph[#text("critical")]#text(" (it is essentially invariant under rescaling) or ")#emph[#text("subcritical")]#text(" (it becomes more powerful when one blows up the solution) with respect to the scaling symmetry. The discovery of controlled quantities for Ricci flow which were simultaneously coercive and critical was Perelman’s first major breakthrough in the subject (previously known controlled quantities were either supercritical or only partially coercive); it made it possible, at least ")#emph[#text("in principle")]#text(", to analyse general singularities of Ricci flow and thus to begin the surgery program discussed above. (In contrast, the main reason why questions such as ")#link("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/")[#text("Navier-Stokes global regularity are so difficult")]#text(" is that no controlled quantity which is both coercive and critical or subcritical is known.) The mere existence of such a quantity does not by any means establish global existence of Ricci flow with surgery immediately, but it does give one a non-trivial starting point from which one can hope to make progress.")

#metadata(none) <tao-8474f2ab9170ab5f502b>

#text("To be a more precise, recall from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text(" that the Ricci flow equation ")#mi("\\frac{d}{dt} g = -2 \\text{Ric}")#text(", in any spatial dimension d, has two basic symmetries (besides the geometric symmetry of diffeomorphism invariance); it has the obvious time-translation symmetry ")#mi("g(t) \\mapsto g(t-t_0)")#text(" (keeping the manifold M fixed), but it also has the scaling symmetry")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("g(t) \\mapsto \\lambda^2 g( \\frac{t}{\\lambda^2} )")]]

#text("for any ")#mi("\\lambda > 0")#text(" (again keeping M fixed as a topological manifold). When applied with ")#mi("\\lambda < 1")#text(", this scaling shrinks all lengths on the manifold M by a factor ")#mi("\\lambda")#text(" (recall that the length ")#tao-math("\\left|v\\right|_g", block: false)#text(" of a tangent vector v is given by the ")#emph[#text("square root")]#text(" of ")#mi("g(v,v)")#text("), and also speeds up the flow of time by a factor ")#mi("1/\\lambda^2")#text("; conversely, when applied with ")#mi("\\lambda > 0")#text(", the scaling expands all lengths by a factor ")#mi("\\lambda")#text(", and slows down the flow of time by ")#mi("1/\\lambda^2")#text(".")

#text("Suppose now that one has a Ricci flow ")#mi("t \\mapsto (M,g(t))")#text(" which becomes singular at some time T > 0. To analyse the behaviour of the flow as one approaches the singular time T, one picks a sequence of times ")#mi("t_n \\to T^-")#text(" approaching T from below, a sequence of marked points ")#mi("x_n \\in M(t_n) = M")#text(" on the manifold, and a sequence of length scales ")#mi("L_n > 0")#text(" which go to zero as ")#mi("n \\to \\infty")#text(". One then considers the blown up Ricci flows ")#mi("t \\mapsto (M^{(n)}, g^{(n)}(t))")#text(", where ")#mi("M^{(n)}")#text(" is equal to M as a topological manifold (with ")#mi("x_n")#text(" as a marked point or “origin” O), and ")#mi("g^{(n)}(t)")#text(" is the flow of metrics given by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("g^{(n)}(t) := \\frac{1}{L_n^2} g( t_n + L_n^2 t ).")]]

#text("Thus the flow ")#mi("t \\mapsto (M^{(n)}, g^{(n)}(t))")#text(" represents a renormalised flow in which the time ")#mi("t_n")#text(" has been redesignated as the temporal origin 0, the point ")#mi("x_n")#text(" has been redesignated as the spatial origin O, and the length scale ")#mi("L_n")#text(" has been redesignated as the unit length scale (and the time scale ")#mi("L_n^2")#linebreak()#text(" has been redesignated as the unit time scale). Thus the behaviour of the rescaled flow ")#mi("t \\mapsto (M^{(n)}, g^{(n)}(t))")#text("at unit scales of space and time around the spacetime origin (thus ")#mi("t = O(1)")#text(" and ")#mi("x \\in B(O,O(1))")#text(") correspond to the behaviour of the original flow ")#mi("t \\mapsto (M,g(T))")#text(" at spatial scale ")#mi("L_n")#text(" and time scale ")#mi("L_n^2")#text(" around the spacetime point ")#mi("(t_n,x_n)")#text(", thus ")#mi("t = t_n + O( L_n^2 )")#text(" and ")#mi("x \\in B(x_n,O(L_n))")#text(".")

#text("Because the original Ricci flow existed on the time interval ")#mi("0 \\leq t < T")#text(", the rescaled Ricci flow will exist on the time interval ")#mi("-\\frac{t_n}{L_n^2} \\leq t < \\frac{T-t_n}{L_n^2}")#text(". In particular, in the limit ")#mi("n \\to \\infty")#text(" (leaving aside for the moment the question of what “limit” means precisely here), these Ricci flows become increasingly ")#emph[#text("ancient")]#text(", in that they will have existed on the entire past time interval ")#mi("-\\infty < t \\leq 0")#text(" in the limit.")

#text("The strategy is now to show that these renormalised Ricci flows ")#mi("t \\mapsto (M^{(n)},g^{(n)})")#text(" (with the marked origin O) exhibit enough “compactness” that there exists a subsequence of such flows which converge to some asymptotic limiting profile ")#mi("t \\mapsto (M^{(\\infty)}, g^{(\\infty)})")#text(" in some sense. (We will define the precise notion of convergence of such flows later, but ")#link("http://en.wikipedia.org/wiki/Gromov%E2%80%93Hausdorff_convergence")[#text("pointed Gromov-Hausdorff convergence")]#text(" is a good first approximation of the convergence concept to keep in mind for now.) If the notion of convergence is strong enough, then we will be able to conclude that this limiting profile of Ricci flows is also a Ricci flow. (Actually, due to the parabolic smoothing effects of Ricci flow, we will be able to automatically upgrade weak notions of convergence to strong ones, and so this step is in fact rather easy.) This limiting Ricci flow has better properties than the renormalised flows; for instance, while the renormalised flows are almost ancient, the limiting flow actually ")#emph[#text("is")]#text(" an ancient solution. Also, while the Hamilton-Ivey pinching phenomenon from ")#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/")[#text("Lecture 3 ")]#text("suggests that the renormalised flows have mostly non-negative curvature, the limiting flow will have everywhere non-negative curvature (provided that the points ")#mi("(t_n,x_n)")#text(" and scales ")#mi("L_n")#text(" are chosen properly; we will return to this “point-picking” issue later in this course).")

#text("If one was able to classify all possible asymptotic profiles to Ricci flow, this would yield quite a bit of information on singularities to such flows, by the standard and general nonlinear PDE method of ")#emph[#text("compactness and contradiction")]#text(". This method, roughly speaking, runs as follows. Suppose we want to claim that whenever one is sufficiently close to a singularity, some scale-invariant property P eventually occurs. (In our specific application, P is roughly speaking going to assert that the geometry and topology of high-curvature regions can be classified as belonging to one of a short list of possible “canonical neighbourhood” types, all of which turn out to be amenable to surgery.) To prove this, we argue by contradiction, assuming we can find a Ricci flow ")#mi("t \\mapsto (M,g(t))")#text(" in which P fails on a sequence of points in spacetime that approach the singularity, and on some sequence of scales going to zero. We then rescale the flow to create a sequence of rescaled Ricci flows ")#mi("t \\mapsto (M^{(n)},g^{(n)}(t))")#text(" as discussed above, each of which exhibits failure of P at unit scales near the origin (here we use the hypothesis that P is scale-invariant). Now, we use compactness to find a subsequence of flows converging to an asymptotic profile ")#mi("t \\mapsto (M^{(\\infty)}, g^{(\\infty)}(t))")#text(". If the convergence is strong enough, the asymptotic profile will also exhibit failure of P. But now one simply goes through the list of all possible profiles in one’s classification and verifies that each of them obeys P; and one is done.")

#text("Unfortunately, just knowing that a Ricci flow is ancient and has everywhere non-negative curvature does not seem enough, by itself, to obtain a full classification of asymptotic profiles (though one can definitely say some non-trivial statements about ancient Ricci flows with non-negative curvature, most notably the ")#emph[#text("Li-Yau-Hamilton inequality")]#text(", which we will discuss later). To proceed further, one needs further control on asymptotic profiles ")#mi("t \\mapsto (M^{(\\infty)}, g^{(\\infty)}(t))")#text(". The only reasonable way to obtain such control is to obtain control on the rescaled flows ")#mi("t \\mapsto (M^{(n)}, g^{(n)}(t))")#text(" which is uniform in n. While some control of this sort can be established merely by choosing the points ")#mi("(t_n,x_n)")#text(" and scales ")#mi("L_n")#text(" in a clever manner, there is a limit as to what one can accomplish just by point-picking alone (especially if one is interested in establishing properties P that apply to quite general regions of spacetime and general scales, rather than specific, hand-picked regions and scales). To really get good control on the rescaled flows ")#mi("t \\mapsto (M^{(n)}, g^{(n)}(t))")#text(", one needs to obtain control on the original flow ")#mi("t \\mapsto (M,g(t))")#text(" which does not deteriorate when one passes from the original flow to the rescaled flow.")

#text("One can express what “does not deteriorate” means more precisely using the language of ")#link("http://en.wikipedia.org/wiki/Dimensional_analysis")[#text("dimensional analysis")]#text(", or more precisely using the concepts of subcriticality, criticality, and supercriticality from nonlinear PDE. Suppose we have some (non-negative) scalar quantity ")#mi("F( M, g(\\cdot) )")#text(" that measures some aspect of a flow ")#mi("t \\mapsto (M, g(t))")#text(". [Dimensional analysis becomes trickier when considering tensor-valued quantities, though in practice one can use the magnitude of such quantities as a scalar-valued proxy for these tensor-valued objects; see ")#link("http://arxiv.org/abs/math/0610903")[#text("my paper on Perelman’s argument")]#text(" for some further discussion.] In many situations, this quantity has some specific ")#emph[#text("dimension")]#text(" k, in the sense that one has a scaling relationship")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("F( M, \\lambda^2 g( \\frac{\\cdot}{\\lambda^2} ) ) = \\lambda^k F( M, g(\\cdot) )")]]

#text("that measures how that quantity changes under the rescaling (1). In dimensional analysis language, (3) asserts that F has the units ")#mi("\\text{length}^k")#text(".")

#text("Assuming that F is also invariant under time translation (and under changes of spatial origin), (3) implies that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("F( M^{(n)}, g^{(n)}(\\cdot) ) = L_n^{-k} F( M, g(\\cdot) ).")]]

#text("Thus, if F is ")#emph[#text("critical")]#text(" or ")#link("http://en.wikipedia.org/wiki/Dimensionless_quantity")[#text("dimensionless")]#text(" (which means that k=0) or ")#emph[#text("subcritical")]#text(" (which means that ")#mi("k < 0")#text("), any upper bound on F for the original Ricci flow ")#mi("t \\mapsto (M,g(t))")#text(" will imply uniform bounds on the rescaled flows ")#mi("t \\mapsto (M^{(n)},g^{(n)}(t))")#text(", and thus (assuming the convergence is strong enough, and F has some good continuity properties) on the asymptotic profile ")#mi("t \\mapsto (M^{(\\infty)}, g^{(\\infty)}(t))")#text(". In the subcritical case, F should in fact now vanish in the limit. On the other hand, if F is ")#emph[#text("supercritical")]#text(" (which means that ")#mi("k > 0")#text(") then no information about the asymptotic profile ")#mi("t \\mapsto (M^{(\\infty)}, g^{(\\infty)}(t))")#text(" is obtained.")

#text("In order for control of ")#mi("F(M^{(\\infty)}, g^{(\\infty)}(\\cdot))")#text(" to be truly useful, we would like the quantity F to be ")#emph[#text("coercive")]#text(". This term is not precisely defined (though it is somewhat analogous to the notion of a ")#link("http://en.wikipedia.org/wiki/Proper_map")[#text("proper map")]#text("), but coercivity basically means that upper bounds on ")#mi("F(M, g(\\cdot))")#text(" translate to some upper bounds on various norms or similar quantities measuring the “size” of ")#mi("(M, g(\\cdot))")#text(", and (hopefully) to then obtain useful bounds on the topology and geometry of ")#mi("(M, g(\\cdot))")#text(".")

#text("Let us give some examples of various such quantities F for Ricci flow. We begin with some supercritical quantities:")

#enum(start: 1, 
[#text("Any length-type quantity, e.g. the diameter ")#mi("\\text{diam}(M)")#text(" of the manifold, or the ")#link("http://en.wikipedia.org/wiki/Injectivity_radius")[#text("injectivity radius")]#text(", has dimension 1 and is thus supercritical.")],
[#text("The various widths ")#mi("W_2(t), W_3(t), \\tilde W_3(t)")#text(" of 3-dimensional Ricci flows from the previous lectures, which were based on areas of minimal surfaces, have dimension 2 and are also supercritical. Thus the various bounds we have on these quantities from Lectures ")#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/")[#text("4")]#text(", ")#link("https://terrytao.wordpress.com/2008/04/15/285g-lecture-5-finite-time-extinction-of-the-third-homotopy-group-i/")[#text("5")]#text(", ")#link("https://terrytao.wordpress.com/2008/04/18/285g-lecture-6-finite-time-extinction-of-the-third-homotopy-group-ii/")[#text("6")]#text(" do not directly tell us anything about asymptotic profiles.")],
[#text("The volume ")#mi("\\int_M\\ d\\mu")#text(" of 3-manifolds has dimension 3 and is thus also supercritical. Thus upper bounds on volume, such as Corollary 2 from ")#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/")[#text("Lecture 3")]#text(", do not directly tell us anything about asymptotic profiles (though they are useful for other tasks, most notably for ensuring that surgery times are discrete, see Theorem 3 from ")#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")[#text("Lecture 2")]#text(").")]
)

#text("As for subcritical quantities, one notable one is the minimal scalar curvature ")#mi("R_{\\text{min}}")#text(". One can check (cf. the dimensional analysis at the end of ")#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/")[#text("Lecture 0")]#text(")")#linebreak()#text(" that scalar curvature has dimension -2 and is thus subcritical. The quantity ")#mi("F(M, g(\\cdot)) := \\sup_t \\max( - R_{\\text{min}}, 0 )")#text(", that measures the maximal amount of negative scalar curvature present in a Ricci flow, is then bounded (by the maximum principle, see Proposition 2 of ")#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/")[#text("Lecture 3")]#text("), and so by the previous discussion will vanish for asymptotic profiles; in other words, asymptotic profiles always have non-negative scalar curvature. Unfortunately, this quantity is only partially coercive; it prevents scalar curvature from becoming arbitrarily large and negative, but does not prevent scalar curvature from becoming arbitrarily large and positive. (Also, it is possible for other curvatures, such as Ricci and Riemann curvatures, to be large even while the scalar curvature is small or even zero.) So this quantity does say something non-trivial about asymptotic profiles, but is insufficient by itself to fully control such profiles.")

#text("In the next lecture we shall see that the least eigenvalue ")#mi("\\lambda_1( -4\\Delta + R )")#text(" of the modified Laplace-Beltrami operator, which can be viewed as an analytic analogue of the geometric quantity ")#mi("R_{\\min}")#text(" related to Poincaré inequalities, also enjoys a monotonicity property (which is connected to a certain gradient flow interpretation of (modified) Ricci flow); like ")#mi("R_{\\min}")#text(", the least eigenvalue has dimension -2 and is thus also subcritical, but again it is not fully coercive, as it only prevents scalar curvature from becoming too negative.")

#text("So far we have not discussed any critical quantities. (One can create some trivial examples of critical quantities, such as the dimension ")#mi("\\text{dim}(M)")#text(" or topological quantities such as ")#mi("\\pi_1(M)")#text(", but these are not obviously coercive (the topological coercivity of the latter quantity being, of course, precisely the Poincaré conjecture that we are trying to prove!).) One way to create critical quantities is to somehow combine subcritical and supercritical examples together. Here is one simple example, due ")#link("http://www.ams.org/mathscinet-getitem?mr=1714939")[#text("to Hamilton")]#text(":")

#strong[#text("Exercise 1. ")]#text(" Show that the quantity ")#mi("\\max( - R_{\\min}(t) V(t)^{2/d}, 0 )")#text(" is critical (scale-invariant) and monotone non-increasing in time under d-dimensional Ricci flow, where ")#mi("V = \\int_M\\ d\\mu(t)")#text(" denotes the volume of ")#mi("(M, g(t))")#text(" at time t. (This quantity can be used, for instance, to show that Ricci flow admits no “breather” solutions, i.e. non-constant periodic solutions; see the discussion in ")#link("http://arxiv.org/abs/math/0211159")[#text("Perelman’s paper")]#text(". Unfortunately, as with previous examples, it is not fully coercive.) ")#mi("\\diamond")

#text("In the next few lectures, we will see two more advanced versions of critical controlled quantities of an analytic nature, the ")#emph[#text("Perelman entropy")]#text(" (a scale-invariant version of the minimal eigenvalue ")#mi("\\lambda_1( -4\\Delta + R )")#text(", which is to log-Sobolev inequalities as the latter quantity is to Poincaré inequalities) and the ")#emph[#text("Perelman reduced volume")]#text(" (which measures how heat-type kernels on Ricci flows compare against heat kernels on Euclidean space). These quantities were both introduced in ")#link("http://arxiv.org/abs/math/0211159")[#text("Perelman’s first paper")]#text(". The key feature of these new critical quantities, which distinguishes them from previously known examples, is that they are now ")#emph[#text("coercive")]#text(": they provide a crucial scale-invariant geometric control on a flow ")#mi("t \\mapsto (M, g(t))")#text(", which is now known as ")#emph[#mi("\\kappa")#text("-noncollapsing")]#text(". This control, which describes a relationship between the supercritical quantities of length and volume and the subcritical quantities of curvature, will be discussed next.")

#heading(level: 1)[#text("— Length, volume, curvature, and collapsing —")]

#text("Let p be a point in a d-dimensional complete Riemannian manifold (M,g) (we make no assumptions on the dimension d here). We will establish here some basic results in ")#emph[#text("comparison geometry")]#text(", which seeks to understand the relationship between the Riemann curvature ")#mi("\\text{Riem}")#text(" of the manifold M, and various geometric quantities of M such as the volume of balls and the injectivity radius, especially when compared against model geometries such as the sphere and hyperbolic space. (This is only a brief introduction; see e.g. Chapters 6, 9, and 10 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2243772")[#text("Petersen’s book")]#text(" for a more detailed treatment.)")

#text("Of course, in the case of Euclidean space ")#mi("{\\Bbb R}^d")#text(" with the Euclidean metric, the Riemann curvature is identically zero, and the volume of B(p,r) is ")#mi("c_d r^d")#text(" for some explicit constant ")#mi("c_d := \\frac{\\pi^{d/2}}{\\Gamma(\\frac{d}{2}+1)} > 0")#text(" depending only on dimension. For Riemannian manifolds, it is easy to see that the volume of B(p,r) is ")#mi("(1+o(1)) c_d r^d")#text(" in the limit ")#mi("r \\to 0")#text("; for more precise asymptotics, see Exercises 7 and 8 below.")

#text("One of the most effective tools to study these questions comes from ")#link("http://en.wikipedia.org/wiki/Normal_coordinates")[#text("normal coordinates")]#text(", or more precisely from the ")#link("http://en.wikipedia.org/wiki/Exponential_map")[#text("exponential map")]#text(" ")#mi("\\exp_p: T_p M \\to M")#text(" from the tangent space ")#mi("T_p M")#text(" to M, defined by setting ")#mi("\\exp_p(v)")#text(" to be the value of ")#mi("\\gamma(1)")#text(", where ")#mi("\\gamma:[0,1] \\to M")#text(" is the unique constant-speed geodesic with ")#mi("\\gamma(0)=p")#text(" and ")#mi("\\gamma^{\\prime}(0)=v")#text(". By the ")#link("http://en.wikipedia.org/wiki/Hopf%E2%80%93Rinow_theorem")[#text("Hopf-Rinow theorem")]#text(", M is complete (in the metric sense) if and only if the exponential map is defined on all of ")#mi("T_p M")#text(". Henceforth we will always assume M to be complete. The ball ")#mi("B(p,r)")#text(" of radius ")#mi("r > 0")#text(" in M centred at p is then the image under the exponential map of the ball ")#mi("B_{T_p M}(0,r)")#text(" of the tangent space of the same radius (using the metric ")#mi("g(p)")#text(", of course):")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("B(p,r) = \\exp_p( B_{T_p M}(0,r) ).")]]

#text("Thus we can study the balls centred at p by using the exponential map to pull back to the tangent space ")#mi("T_p M")#text(" and analysing the geometry there. Two radii become relevant for this approach:")

#enum(start: 1, 
[#text("The ")#emph[#text("injectivity radius")]#text(" at p is the supremum of all radii r such that ")#mi("\\exp_p")#text(" is injective on ")#mi("B_{T_p M}(0,r)")#text(".")],
[#text("The ")#emph[#text("conjugate radius")]#text(" at p is the supremum of all radii r such that ")#mi("\\exp_p")#text(" is an ")#link("http://en.wikipedia.org/wiki/Immersion_%28mathematics%29")[#text("immersion")]#text(" on ")#mi("B_{T_p M}(0,r)")#text(".")]
)

#text("In many situations, these two radii are equal, but there are cases in which the injectivity radius is smaller. In fact the injectivity radius is always less than or equal to the conjugate radius; see Exercise 4 below.")

#strong[#text("Example 1.")]#text(" (Sphere) Let ")#mi("K > 0")#text(", and let ")#mi("M = \\frac{1}{\\sqrt{K}} S^d := \\{ (x_1,\\ldots,x_{d+1}) \\in {\\Bbb R}^{d+1}: x_1^2 + \\ldots + x_{d+1}^2 = 1/K \\}")#text(" be the sphere of radius ")#mi("1/\\sqrt{K}")#text(", with the metric induced from the metric ")#mi("ds^2 = dx_1^2 + \\ldots + dx_{d+1}^2")#text(" of Euclidean space ")#mi("{\\Bbb R}^{d+1}")#text(". Then at every point p of M, the injectivity radius and conjugate radius are both equal to ")#mi("\\pi/\\sqrt{K}")#text(", which is also the diameter of the manifold. Note also that this manifold has constant sectional curvature K. ")#mi("\\diamond")

#strong[#text("Example 2.")]#text(" (Hyperbolic space) Let ")#mi("K > 0")#text(", and let ")#mi("M = \\frac{1}{\\sqrt{K}} H^d := \\{ (t,x_1,\\ldots,x_d) \\in {\\Bbb R}^{1+d}: x_1^2 + \\ldots x_d - t^2 = 1/K ; t > 0 \\} \\subset {\\Bbb R}^{1+d}")#text(" be hyperbolic space of hyperbolic radius ")#mi("1/\\sqrt{K}")#text(", with the metric induced from the metric ")#mi("ds^2 = dx_1^2 + \\ldots + dx_d^2 - dt^2")#text(" of Minkowski space. Then at any point p in M, e.g. p = (1,0), the injectivity radius, conjugate radius, and diameter are infinite. This manifold has constant sectional curvature -K. ")#mi("\\diamond")

#strong[#text("Example 3. ")]#text("(Torus) Let ")#mi("r > 0")#text(", and let ")#mi("M = ({\\Bbb R}/r{\\Bbb Z})^d")#text(" be the d-torus which is the product of d circles of length r. Then for any point p in M, the injectivity radius is r/2 and the conjugate radius is infinite. Here the sectional curvature is of course 0 everywhere. ")#mi("\\diamond")

#text("The metric g on M induces a pullback metric on ")#mi("T_p M")#text(", which by abuse of notation we shall also call g. This metric can degenerate once one passes the conjugate radius, but let us ignore this issue for the time being. On ")#mi("T_p M")#text(", we have the radial variable r (defined as the magnitude of a tangent vector with respect to g(p)), and the radial vector field ")#mi("\\partial_r")#text(" (defined as the dual vector field to r using polar coordinates), which is smooth away from the origin.")

#text("In Euclidean space, the vector field ")#mi("\\partial_r")#text(" is the gradient of r. Happily, the same fact is true for more general Riemannian manifolds:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" (Gauss lemma)")

#enum(start: 1, 
[#text("Away from the origin, we have ")#tao-math("\\left|\\partial_r\\right|_g = 1", block: false)#text(" and ")#mi("\\nabla_{\\partial_r} \\partial_r = 0")#text(".")],
[#text("Away from the origin, ")#mi("\\partial_r")#text(" is the gradient ")#mi("\\text{grad} r")#text(" of r with respect to the metric g, thus ")#mi("(\\partial_r)^\\alpha = \\nabla^\\alpha r")#text(".")]
)
]

#strong[#text("Exercise 2.")]#text(" Prove Lemma 1. (Hint: part 1 follows from the geodesic flow equation ")#mi("\\nabla_{\\dot \\gamma} \\dot \\gamma = 0")#text(". For part 2, one way to proceed is to establish the ODE")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\nabla_{\\partial_r} ( \\partial_r - \\text{grad} r )^\\alpha = (\\nabla^\\alpha (\\partial_r)_\\beta) ( \\partial_r - \\text{grad} r )^\\beta")]]

#text("and then apply Gronwall’s inequality. ")#mi("\\diamond")

#text("Lemma 1 gives some important relationships between the radial vector field ")#mi("\\partial_r")#text(" and the Hessian ")#mi("\\text{Hess}(r)_{\\alpha \\beta} := \\nabla_\\alpha \\nabla_\\beta r = \\nabla_\\alpha (\\partial_r)_\\beta")#text(" (which can be viewed as the second fundamental form of the spheres centred at p):")

#strong[#text("Exercise 3. ")]#text("Away from the origin, obtain the deformation formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("{\\mathcal L}_{\\partial_r} g = 2 \\text{Hess}(r)")]]

#text("and the ")#link("http://en.wikipedia.org/wiki/Riccati_equation")[#text("Riccati-type equation")#linebreak()#text(" ")]

#align(center)[#mi("\\nabla_{\\partial_r} \\text{Hess}_{\\alpha \\beta} +\\text{Hess}_{\\alpha \\beta} \\text{Hess}^\\beta_\\gamma = \\text{Riem}_{\\alpha\\gamma\\beta}^\\delta (\\partial_r)^\\gamma (\\partial_r)_\\delta")#text(". ")#mi("\\diamond")#text(" (8)")]

#text("Also, show that ")#mi("\\text{Hess}_{\\alpha \\beta}")#text(" has ")#mi("\\partial_r")#text(" as a null eigenvector. ")#mi("\\diamond")

#strong[#text("Exercise 4.")]#text(" Show that the injectivity radius ")#mi("r_i")#text(" of a point p cannot exceed the conjugacy radius ")#mi("r_c")#text(". (Hint: there are several ways to establish this. Here is one: suppose for contradiction that ")#mi("r_i > r_c")#text(", thus ")#mi("r_i > (1+\\varepsilon) r_c")#text(" for some small ")#mi("\\varepsilon > 0")#text(". Let ")#mi("v \\in T_p M")#text(" be a vector of magnitude at most ")#mi("r_c")#text(". Observe that the function ")#mi("d(p, x) + d( \\exp_p((1+\\varepsilon) v), x)")#text(" achieves a global minimum at ")#mi("\\exp_p(v)")#text(" whenever and so has non-negative Hessian. Use this to obtain a lower bound on ")#mi("\\text{Hess}(r)")#text(" on ")#mi("B(p,r_c)")#text(", and combine this with Exercise 3 to show that the exponential map is in fact immersed on a neighbourhood of ")#mi("B(p,r_c)")#text(", a contradiction. Another approach is based on Klingenberg’s inequality (see Lemma 2 below), while a third approach is based on the second variation formula for the energy of a geodesic.) ")#mi("\\diamond")

#text("Let us now impose the bound that all sectional curvatures are bounded by some ")#mi("K > 0")#text(" on a ball ")#mi("B(p,r_0)")#text(", thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left|g( \\text{Riem}(X,Y) X, Y)\\right| \\leq K", block: true)]]

#text("for all orthonormal tangent vectors X, Y at any point in ")#mi("B(p,r_0)")#text(". From Example 1 we know that the exponential map can become singular past the radius ")#mi("\\pi/\\sqrt{K}")#text(", so let us also assume that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("r_0 \\leq \\pi/\\sqrt{K}.")]]

#text("Note that the sectional curvature bound also implies a Ricci curvature bound ")#tao-math("\\left|\\text{Ric}(X,X)\\right| \\leq (d-1)K", block: false)#text(" for all unit tangent vectors based in ")#mi("B(p,r_0)")#text(".")

#text("From (9) and (10) we see that ")#tao-math("\\left|\\text{Riem}\\right|_g = O_d( r_0^{-2} )", block: false)#text(" on the ball ")#mi("B(p,r_0)")#text(". When this latter property occurs, let us informally say that M has ")#emph[#text("bounded normalised curvature")]#text(" at scale ")#mi("r_0")#text(" at p. Our analysis here can thus be interpreted as a study of the volume of balls (and of related quantities, such as the injectivity radius) under assumptions of bounded normalised curvature.")

#strong[#text("Remark 1.")]#text(" If one wishes, one can rescale to normalise K (or ")#mi("r_0")#text(") to equal 1, although this does not significantly simplify the computations that follow below. ")#mi("\\diamond")

#text("Using equation (8), one can obtain sharp upper and lower bounds for ")#mi("\\text{Hess}(r)")#text(":")

#strong[#text("Exercise 5.")]#text(" (Comparison estimates for ")#mi("\\text{Hess}(r)")#text(") Assume that (9) and (10) hold. At any non-zero point in ")#mi("B_{T_p M}(0,r_0)")#text(", let ")#mi("\\lambda_{\\min} \\leq \\lambda_{\\max}")#text(" be the least and greatest eigenvalues of ")#mi("\\text{Hess}(r)")#text(" on the orthogonal complement of ")#mi("\\partial_r")#text(". Use (8) to establish the differential inequalities")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\nabla_{\\partial_r} \\lambda_{\\max} + \\lambda_{\\max}^2 \\leq K")]]

#text("and")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\nabla_{\\partial_r} \\lambda_{\\min} + \\lambda_{\\min}^2 \\geq -K")]]

#text("for ")#mi("0 < r < r_0")#text(" and also establish the infinitesimal bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\lambda_{\\min}, \\lambda_{\\max} = \\frac{1}{r} + O(r)")]]

#text("for all sufficiently small positive r. From (11), (12), (13), conclude the bounds")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\sqrt{K} \\coth(\\sqrt{K} r) \\leq \\lambda_{\\min} \\leq \\lambda_{\\max} \\leq \\sqrt{K} \\cot(\\sqrt{K} r)")]]

#text("and in particular that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("(d-1) \\sqrt{K} \\coth(\\sqrt{K} r) \\leq \\Delta r \\leq (d-1) \\sqrt{K} \\cot(\\sqrt{K} r).")]]

#text("Using (7) and (14), deduce the bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("dr^2 + \\frac{\\sin^2(\\sqrt{K} r) }{K} d\\theta^2 \\leq dg^2 \\leq dr^2 + \\frac{\\sinh^2(\\sqrt{K} r) }{K} d\\theta^2")]]

#text("where ")#mi("(r,\\theta)")#text(" are the usual Euclidean polar coordinates on ")#mi("T_p M")#text(", thus the Euclidean metric (induced by g(p)) is given by ")#mi("ds^2 = dr^2 + r^2 d\\theta^2")#text("). ")#mi("\\diamond")

#strong[#text("Remark 2. ")]#text(" Each of the above bounds are attained by either the sphere of constant sectional curvature +K (Example 1) or the hyperbolic space of constant sectional curvature -K (Example 2). More generally, one should think of these two examples as the two extreme geometries obeying the assumption (9). In the limit K=0 one recovers the formulae for Euclidean space ")#mi("{\\Bbb R}^d")#text(" or for the torus (Example 3). ")#mi("\\diamond")

#strong[#text("Exercise 6.")]#text(" (Bounded curvature implies lower bound on conjugacy radius) Using Exercise 3, show that if (9) and (10) hold, then the conjugacy radius of p is at least ")#mi("r_0")#text(". ")#mi("\\diamond")

#strong[#text("Remark 3. ")]#text("A converse of sorts to Exercise 6 is provided by ")#link("http://en.wikipedia.org/wiki/Myers_theorem")[#text("Myers’ theorem")]#text(", which asserts that if ")#mi("\\text{Ric} \\geq (d-1) K")#text(", then the diameter of M is at most ")#mi("\\pi/\\sqrt{K}")#text(". Another result in a somewhat similar spirit is the ")#link("http://en.wikipedia.org/wiki/Sphere_theorem")[#text("1/4-pinched sphere theorem")]#text(". The Ricatti-type equations and inequalities developed above play a key role in the proof of such theorems. ")#mi("\\diamond")

#text("Now we relate the Hessian of r to the volume metric ")#mi("d\\mu")#text(" and the Laplacian ")#mi("\\Delta r")#text(":")

#strong[#text("Exercise 7")]#text(". Away from the origin, obtain the deformation formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("{\\mathcal L}_{\\partial_r} d\\mu = (\\Delta r) d\\mu")]]

#text("and the Riccati-type inequality")

#align(center)[#tao-math("\\nabla_{\\partial_r} \\Delta r + \\frac{1}{d-1} (\\Delta r)^2 \\leq \\nabla_{\\partial_r} \\Delta r + \\left|\\text{Hess}(r)\\right|^2 = - \\text{Ric}(\\partial_r, \\partial_r)", block: false)#text(". ")#mi("\\diamond")#text(" (18)")]

#strong[#text("Exercise 8.")]#text(" (Absolute volume comparison) Assume (9) and (10). Using Exercises 5 and 7, show that the volume of ")#mi("B_{T_p M}(0,r_0)")#text(" is maximised in the case of hyperbolic space (Example 2) and minimised in the case of the sphere (Example 1). In particular, if ")#mi("r_0 \\leq O(\\sqrt{K})")#text(", conclude that the volume of ")#mi("B_{T_p M}(0,r_0)")#text(" is comparable to ")#mi("r_0^d")#text(", with the comparability constants depending only on d and on the implied constant in the O() notation. ")#mi("\\diamond")

#strong[#text("Remark 4. ")]#text("Later on in this course we will need a relative variant of this comparison inequality, known as the ")#emph[#text("Bishop-Gromov comparison inequality")]#text(", which will assert that certain ratios between volumes of balls are monotone in the radius ")#mi("r_0")#text(". ")#mi("\\diamond")

#strong[#text("Exercise 9. ")]#text("Show that the volume of ")#mi("B(p,r)")#text(" is ")#mi("(c_d - \\frac{R(p)}{6(d+2)} r^2 + O(r^4)) r^d")#text(" for sufficiently small r, where R(p) is the scalar curvature at p. Thus we see that scalar curvature distorts the infinitesimal volume growth of balls. Develop a similar interpretation of the Ricci curvature ")#mi("\\text{Ric}(p)(v,v)")#text(" as the volume distortion of infinitesimal sectors with apex p and direction v. ")#mi("\\diamond")

#text("If ")#mi("r_0")#text(" is less than the injectivity radius, we see from (5) that ")#mi("B(p,r_0)")#text(" has the same volume as ")#mi("B_{T_p M}(0,r_0)")#text(". From Exercise 8, we thus conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\text{vol}(B(p,r_0)) \\sim_{d} r_0^d")]]

#text("whenever (9) holds, and ")#mi("r_0")#text(" is less than both ")#mi("O(1/\\sqrt{K})")#text(" and the injectivity radius of p.")

#text("What happens if ")#mi("r_0")#text(" exceeds the injectivity radius? We still obtain the upper bound in (18), but can lose the lower bound, as can already be seen by considering the torus example (Example 3) with the injectivity radius r small. Thus we see that failure of injectivity can lead to collapse in the volume of balls.")

#text("A deep ")#link("http://www.ams.org/mathscinet-getitem?mr=263092")[#text("result of Cheeger")]#text(" shows that in fact injectivity failure ")#emph[#text("always")]#text(" collapses the volume of balls (assuming bounded normalised curvature), or equivalently that non-collapsing of volume is equivalent to a lower bound on the injectivity radius:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1. ")]#text("(Cheeger’s lemma) Suppose that ")#tao-math("\\left|\\text{Riem}\\right|_g \\leq C r_0^{-2}", block: false)#text(" on ")#mi("B(p,r_0)")#text(" and that ")#mi("\\text{vol}(B(p,r_0)) \\geq \\delta r_0^d")#text(" for some ")#mi("\\delta > 0")#text(". Then the injectivity radius of p is at least ")#mi("c(C,\\delta,d) r_0")#text(" for some ")#mi("c(C,\\delta,d) > 0")#text(" depending only on ")#mi("C,\\delta,d")#text(".")
]

#strong[#text("Remark 5.")]#text(" This lemma is closely related to the ")#link("http://mathworld.wolfram.com/CheegersFinitenessTheorem.html")[#text("Cheeger finiteness theorem")]#text(", which asserts that the number of possible topologies for the ball ")#mi("B(p,r_0)")#text(" under the assumptions of Theorem 1 is finite, as well as ")#link("http://en.wikipedia.org/wiki/Gromov%27s_compactness_theorem_%28geometry%29")[#text("Gromov’s compactness theorem")]#text(", which essentially asserts that the metrics on these balls form a compact set in a certain topology. ")#mi("\\diamond")

#text("I may discuss the proof of Cheeger’s lemma at a later point in this course, if time permits. Cheeger’s original proof relies on the following inequality which is also of interest:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2.")]#text(" (Klingenberg’s inequality) Assume the conjugacy radius is at least ")#mi("r_0")#text(". Then exactly one of the following holds:")

#enum(start: 1, 
[#text("The injectivity radius of p is at least ")#mi("r_0")#text(".")],
[#text("There exists a non-trivial geodesic starting and ending at p of length less than ")#mi("2r_0")#text(".")]
)
]

#strong[#text("Proof. ")]#text(" (Sketch) It is clear that 1. and 2. cannot both be true. Now suppose that the injectivity radius r is strictly less than ")#mi("r_0")#text(", then there exist two distinct geodesic rays ")#mi("\\gamma_1, \\gamma_2")#text(" from p to another point q, one of length r and the other of length at most r. On the other hand, by hypothesis the exponential map is an immersion on ")#mi("B(x,r_0)")#text(". From the inverse function theorem (and Lemma 1) we can then perturb the rays ")#mi("\\gamma_1, \\gamma_2")#text(" from p to have lengths slightly less than r but still ending up at the same point (thus contradicting the definition of r), unless ")#mi("\\gamma_1, \\gamma_2")#text(" have length exactly r and have equal and opposite tangent vectors at q. But then we have formed a geodesic path from p to p of length 2r, and the claim follows. ")#mi("\\Box")

#strong[#text("Exercise 10. ")]#text(" Show that the injectivity radius of p is equal to the minimum of the conjugacy radius of p, and half the length of the shortest non-trivial geodesic path from p to itself (or ")#mi("+\\infty")#text(" if no such path exists). ")#mi("\\diamond")

#strong[#text("Exercise 11. ")]#text(" Let M be a compact manifold whose sectional curvatures are all bounded in magnitude by K. Show that if the injectivity radius r of M (defined as the infimum of the injectivity radii of every point p in M) is less than ")#mi("\\pi/\\sqrt{K}")#text(", then there exists a closed geodesic loop of length exactly 2r. ")#mi("\\diamond")

#text("Let us informally say that a Riemannian manifold M is ")#emph[#text("non-collapsed")]#text(" at scale ")#mi("r_0")#text(" at a point p if ")#mi("B(p,r_0)")#text(" has volume ")#mi("\\gtrsim_d r_0^d")#text(". The above discussion then says that, under the assumption of bounded normalised curvature at scale ")#mi("r_0")#text(" at p, that non-collapsing is equivalent to a lower bound of ")#mi("\\gtrsim_d r_0")#text(" on the injectivity radius, which is in turn equivalent to a lower bound of ")#mi("\\gtrsim_d r_0")#text(" on the length of any non-trivial geodesic paths from p to itself. Thus we see that the non-collapsing property is quite coercive; it implies some important control on the local geometry of the Riemannian manifold.")

#strong[#text("Example 4. ")]#text("The sphere (example 1) of dimension 2 and higher and hyperbolic space (example 2) are non-collapsed at every point and scale for which one has bounded normalised curvature. (For the sphere, volume collapses at scales bigger than the diameter of the sphere, but one no longer has bounded normalised curvature in this regime.) Similarly for Euclidean space, or for products of any of these three examples. On the other hand, the torus (example 2) (or the sphere of dimension 1) is collapsed at large scales even though one still retains normalised bounded curvature. Similarly for the cylinder ")#mi("S^1 \\times {\\Bbb R}")#text(". ")#mi("\\diamond")

#text("Now we adapt this concept to Ricci flows. The following definition is fundamental to Perelman’s arguments:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1.")]#text(" (")#mi("\\kappa")#text("-collapsing) Let ")#mi("t \\mapsto (M,g(t))")#text(" be a d-dimensional Ricci flow, and let ")#mi("\\kappa > 0")#text(". We say that the Ricci flow is ")#emph[#mi("\\kappa")#text("-collapsed ")]#text("at a point ")#mi("(t_0,x_0)")#text(" in spacetime at scale ")#mi("r_0")#text(" if the following statements hold:")

#enum(start: 1, 
[#text("(Bounded normalised curvature) We have ")#tao-math("\\left|\\text{Riem}(t,x)\\right|_g \\leq r_0^{-2}", block: false)#text(" for all ")#mi("(t,x)")#text(" the spacetime cylinder ")#mi("{}[t_0 - r_0^2, t_0] \\times B_{g(t_0)}(x_0, r_0)")#text(" (in particular, we assume that the lifespan of the Ricci flow includes the time interval ")#mi("{}[t_0 - r_0^2, t_0]")#text(");")],
[#text("(Collapsed volume) At time ")#mi("t_0")#text(", the ball ")#mi("B_{g(t_0)}(x_0,r_0)")#text(" has volume at most ")#mi("\\kappa r_0^d")#text(".")]
)

#text("Otherwise, we say that the Ricci flow is ")#emph[#mi("\\kappa")#text("-noncollapsed")]#text(" at this point and scale.")
]

#text("(One should view ")#mi("\\kappa")#text(" here as a small dimensionless quantity, in order to make the notion of ")#mi("\\kappa")#text("-noncollapsing scale-invariant.)")

#text("It turns out that Perelman’s critical quantities are controlled enough, and coercive enough, to establish ")#mi("\\kappa")#text("-noncollapsing at non-zero times assuming some noncollapsing at time zero. There are many ways to formulate this important non-collapsing result; here is one typical phrasing.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2. ")]#text("(Perelman’s non-collapsing theorem, first version) Let ")#mi("t \\mapsto (M,g(t))")#text(" be a Ricci flow on compact 3-manifolds on a time interval ")#mi("{}[0,T_0]")#text(" such that at time zero, we have the normalised non-collapsing hypotheses ")#tao-math("\\left|\\text{Riem}(p)\\right|_g \\leq 1", block: false)#text(" and ")#mi("\\text{Vol}(B(p,1)) \\geq \\omega")#text(" for all ")#mi("p \\in M")#text(", where ")#mi("\\omega > 0")#text(" is fixed. Then the Ricci flow is ")#mi("\\kappa")#text("-noncollapsed for all ")#mi("(t_0,x_0) \\in [0,T_0] \\times M")#text(" and all scales ")#mi("0 < r_0 < \\sqrt{t_0}")#text(", where ")#mi("\\kappa > 0")#text(" depends only on ")#mi("\\omega")#text(" and ")#mi("T_0")#text(".")
]

#text("Note that the conclusion here is scale-invariant and will therefore persist to asymptotic profiles ")#mi("(M^{(\\infty)}, g^{(\\infty)})")#text(" as discussed in the beginning of this lecture.")

#strong[#text("Remark 6. ")]#text(" Actually, to establish the global existence results for Ricci flow with surgery, we will need to extend Definition 1 and Theorem 2 to Ricci flows with surgery; we shall return to this point later in this course. ")#mi("\\diamond")

#strong[#text("Remark 7. ")]#text("This non-collapsing theorem in fact holds in all dimensions, not just 3, but of course many other aspects of our analysis will only work in three dimensions. ")#mi("\\diamond")

#text("The next few lectures will be devoted to the proof of Theorem 2, and then we will discuss how Theorem 2 can be used to analyse asymptotic profiles near a Ricci flow singularity.")

#text("[")#emph[#text("Update")]#text(", Apr 21: Some corrections.]")

#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/#comment-29207")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2008")])]

#text("Dear Prof. Tao,")

#text("A bit of a layman’s question: which good references would you")#linebreak()#text(" recommend for one to learn about blowup techniques and")#linebreak()#text(" asymptotic profiles of solutions near singularities in PDE’s?")

#text("Thanks in advance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/#comment-29208")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2008")])]

#text("Dear Prof. Tao,")

#text("In the sentence “This control, which describes a relationship between the subcritical quantities of length and volume and the supercritical quantities of curvature, will be discussed next” (just before the first appearance of “")#mi("\\kappa")#text("-noncollapsing”), shouldn’t the “quantities of length and volume” be _super_critical, and the “quantities of curvature” be _sub_critical?")#linebreak()#text(" Judging by your previous discussion on these examples, it seems so…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/#comment-29209")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2008")])]

#text("On the aside: the desired relation between the radius of injectivity and the conjugate radius is in Lemma 5.9.16 of Petersen’s book (it’s due to Klingenberg).")#linebreak()#text(" It roughly states that if ")#mi("y=\\gamma(1)")#text(" is the first cut point of ")#mi("x=\\gamma(0)")#text(" along the geodesic ")#mi("\\gamma")#text(", then either ")#mi("y")#text(" is")#linebreak()#text(" conjugate to ")#mi("x")#text(" along ")#mi("\\gamma")#text(" or there’s another minimal")#linebreak()#text(" geodesic ")#mi("\\gamma^{\\prime}")#text(" linking ")#mi("x")#text(" to ")#mi("y")#text(". In the second case,")#linebreak()#text(" if ")#mi("y")#text(" is not a critical point of ")#mi("exp_x")#text(", then there are exactly two")#linebreak()#text(" geodesic segments linking ")#mi("x")#text(" to ")#mi("y")#text(", and they fit together into")#linebreak()#text(" a smooth geodesic loop (e.g. think about the 2-dimensional cylinder).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/#comment-29219")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2008")])]

#text("Regarding your aside: Doesn’t it just follow from the fact that geodesics cease to be minimizing once you pass the first conjugate point? This fact appears in Jost and do Carmo, and I would imagine that it’s in Petersen, but I don’t have it on hand.")

#text("Also, your discussion motivating the definition of ")#mi("\\kappa")#text("-noncollapsing is very nice, but I think there is a typo in Definition 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/#comment-29226")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2008")])]

#text("Thanks for the comments and corrections! Regarding literature for asymptotic profiles and the compactness method in nonlinear PDE, the method exists in dozens of papers in the subject, but I am not sure whether there is an introductory treatment of it anywhere (part of the problem is that nonlinear PDE, like many other analysis-heavy areas of mathematics, tends to use rather loosely defined “methods” and “strategies” rather than applying general and formal theorems which can be cleanly stated and proved). But I discuss this method (albeit in slightly different contexts than the one discussed here) in my survey articles")

#link("http://arxiv.org/abs/0802.2408")[#text("http://arxiv.org/abs/0802.2408")]

#text("and Section 8 of")

#link("http://arxiv.org/abs/math.AP/0608293")[#text("http://arxiv.org/abs/math.AP/0608293")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/#comment-29230")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2008")])]

#text("I just wanted to clarify that the theorem I mentioned above (that geodesics cease to be minimizing beyond the first conjugate point) is not the same as the Klingenberg lemma described by Pedro (although, for all I know, it could also be due to Klingenberg). Do Carmo attributes it to Jacobi. The proof just uses the index form, and one can think of it as a piece of the Morse Index Theorem. Specifically, we only need that the index jumps up when you pass a critical point; the Morse Index Theorem says that the jump is exactly equal to the multiplicity of the conjugate point.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/#comment-29252")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2008")])]

#text("In the particular case of Petersen’s book, this result follows from the second variation of the energy formula and the discussion following it (Section 6.2),")#linebreak()#text(" although he doesn’t seem to state this explicitly. However, indeed he makes no use of that in proving Klingenberg’s lemma 5.9.16, so they are really independent ways of seeing that the injectivity radius is less than or equal to the conjugate radius. The second variation formula, however, is due to Synge.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/#comment-29255")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2008")])]

#text("Thanks for the comments! I ended up using an alternate argument that I found in Petersen’s book, based on the fact that if x and y are joined by a segment then f(z)=d(x,z)+d(z,y) attains a minimum for all z in that segment, and in particular the Hessian of this function must be non-negative on that segment, which can be used to show that the exponential map from x cannot develop critical points on this segment.")

#text("It does seem that there are many different proofs of this result; I’ll ask Peter tomorrow what his favourite one is. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b167d5bfef9d8ac8ade2c9cfa6c8c36a7e4351521953189a3b1617f943fd57c-a86ab309af770ab33c32ef4ace8814868bd80c3931c7e2fd3d58924f7e22709f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammad")]], [#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/#comment-29271")[#strong[#text("Mohammad")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2008")])]

#text("Dear Prof,Tao")#linebreak()#text(" I am very grateful of founding this website.")#linebreak()#text(" Actually this question is not related to this lecture, I would like to you personally you think what is the best approach for proving backward uniqueness of ricci flow?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285A, Lecture 8: Ricci flow as a gradient flow, log-Sobolev inequalities, and Perelman entropy « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/#comment-29310")[#strong[#text("285A, Lecture 8: Ricci flow as a gradient flow, log-Sobolev inequalities, and Perelman entropy « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2008")])]

#text("[…] any scale – precisely what is needed to carry out the first phase of the strategy outlined in the previous lecture to establish global existence of Ricci flow with […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 9: Comparison geometry, the high-dimensional limit, and Perelman reduced volume « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/#comment-29392")[#strong[#text("285G, Lecture 9: Comparison geometry, the high-dimensional limit, and Perelman reduced volume « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2008")])]

#text("[…] p be a point in a complete d-dimensional Riemannian manifold . As noted in Lecture 7, we can use the exponential map to pull back M and g to the tangent space , which is also equipped […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 12: High curvature regions of Ricci flow and κ-solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/#comment-29827")[#strong[#text("285G, Lecture 12: High curvature regions of Ricci flow and κ-solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2008")])]

#text("[…] a -noncollapsing of Ricci flows with surgery (which, except for the surgery part, is Theorem 2 of Lecture 7). Now we come to the heart of the entire argument: the topological and geometric control of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 11: κ-noncollapsing via Perelman reduced volume « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/#comment-29894")[#strong[#text("285G, Lecture 11: κ-noncollapsing via Perelman reduced volume « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2008")])]

#text("[…] be used to establish -noncollapsing of Ricci flows, thus giving a second proof of Theorem 2 from Lecture 7. Of course, we already proved (a stronger version) of this theorem already in Lecture 8, using the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/#comment-45075")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2010")])]

#text("It should be “slows down the flow of time by 1/\\lambda^2”. ")#emph[#text("[Corrected, thanks – T.]")]
]
