// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/05/17/a-function-field-analogue-of-riemann-zeta-statistics/
// Converted to Typst by tao2typ: "2026-10-14T16:38:33.648927+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A function field analogue of Riemann zeta statistics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A function field analogue of Riemann zeta statistics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 May 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/05/17/a-function-field-analogue-of-riemann-zeta-statistics/")[#text("https://terrytao.wordpress.com/2019/05/17/a-function-field-analogue-of-riemann-zeta-statistics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is another sequel to a ")#link("https://terrytao.wordpress.com/2019/05/03/local-trigonometric-polynomial-approximations-to-the-riemann-zeta-function/")[#text("recent post")]#text(" in which I showed the Riemann zeta function ")#mi("{\\zeta}")#text(" can be locally approximated by a polynomial, in the sense that for randomly chosen ")#mi("{t \\in [T,2T]}")#text(" one has an approximation ")#metadata(none) <tao-4a70fe9aa6436e02c2de>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\zeta(\\frac{1}{2} + it - \\frac{2\\pi i z}{\\log T}) \\approx P_t( e^{2\\pi i z/N} )")]]

#text("where ")#mi("{N}")#text(" grows slowly with ")#mi("{T}")#text(", and ")#mi("{P_t}")#text(" is a polynomial of degree ")#mi("{N}")#text(". It turns out that in the function field setting there is an exact version of this approximation which captures many of the known features of the Riemann zeta function, namely Dirichlet ")#mi("{L}")#text("-functions for a random character of given modulus over a function field. This model was (essentially) studied in a ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3282994")[#text("fairly recent paper by Andrade, Miller, Pratt, and Trinh")]#text("; I am not sure if there is any further literature on this model beyond this paper (though the number field analogue of low-lying zeroes of Dirichlet ")#mi("{L}")#text("-functions is certainly well studied). In this model it is possible to set ")#mi("{N}")#text(" fixed and let ")#mi("{T}")#text(" go to infinity, thus providing a simple finite-dimensional model problem for problems involving the statistics of zeroes of the zeta function.")

#text("In this post I would like to record this analogue precisely. We will need a finite field ")#mi("{{\\mathbb F}}")#text(" of some order ")#mi("{q}")#text(" and a natural number ")#mi("{N}")#text(", and set")

#align(center)[#tao-fit-display[#mitex("T := q^{N+1}.")]]

#text("We will primarily think of ")#mi("{q}")#text(" as being large and ")#mi("{N}")#text(" as being either fixed or growing very slowly with ")#mi("{q}")#text(", though it is possible to also consider other asymptotic regimes (such as holding ")#mi("{q}")#text(" fixed and letting ")#mi("{N}")#text(" go to infinity). Let ")#mi("{{\\mathbb F}[X]}")#text(" be the ring of polynomials of one variable ")#mi("{X}")#text(" with coefficients in ")#mi("{{\\mathbb F}}")#text(", and let ")#mi("{{\\mathbb F}[X]^{\\prime}}")#text(" be the multiplicative semigroup of monic polynomials in ")#mi("{{\\mathbb F}[X]}")#text("; one should view ")#mi("{{\\mathbb F}[X]}")#text(" and ")#mi("{{\\mathbb F}[X]^{\\prime}}")#text(" as the function field analogue of the integers and natural numbers respectively. We use the valuation ")#tao-math("{\\left|n\\right| := q^{\\mathrm{deg}(n)}}", block: false)#text(" for polynomials ")#mi("{n \\in {\\mathbb F}[X]}")#text(" (with ")#tao-math("{\\left|0\\right|=0}", block: false)#text("); this is the analogue of the usual absolute value on the integers. We select an irreducible polynomial ")#mi("{Q \\in {\\mathbb F}[X]}")#text(" of size ")#tao-math("{\\left|Q\\right|=T}", block: false)#text(" (i.e., ")#mi("{Q}")#text(" has degree ")#mi("{N+1}")#text("). The multiplicative group ")#mi("{({\\mathbb F}[X]/Q{\\mathbb F}[X])^\\times}")#text(" can be shown to be cyclic of order ")#tao-math("{\\left|Q\\right|-1=T-1}", block: false)#text(". A ")#link("https://en.wikipedia.org/wiki/Dirichlet_character")[#text("Dirichlet character")]#text(" of modulus ")#mi("{Q}")#text(" is a completely multiplicative function ")#mi("{\\chi: {\\mathbb F}[X] \\rightarrow {\\bf C}}")#text(" of modulus ")#mi("{Q}")#text(", that is periodic of period ")#mi("{Q}")#text(" and vanishes on those ")#mi("{n \\in {\\mathbb F}[X]}")#text(" not coprime to ")#mi("{Q}")#text(". From Fourier analysis we see that there are exactly ")#tao-math("{\\phi(Q) := \\left|Q\\right|-1}", block: false)#text(" Dirichlet characters of modulus ")#mi("{Q}")#text(". A Dirichlet character is said to be ")#emph[#text("odd")]#text(" if it is not identically one on the group ")#mi("{{\\mathbb F}^\\times}")#text(" of non-zero constants; there are only ")#mi("{\\frac{1}{q-1} \\phi(Q)}")#text(" non-odd characters (including the principal character), so in the limit ")#mi("{q \\rightarrow \\infty}")#text(" most Dirichlet characters are odd. We will work primarily with odd characters in order to be able to ignore the effect of the place at infinity.")

#text("Let ")#mi("{\\chi}")#text(" be an odd Dirichlet character of modulus ")#mi("{Q}")#text(". The ")#link("https://en.wikipedia.org/wiki/Dirichlet_L-function")[#text("Dirichlet ")#mi("{L}")#text("-function")]#text(" ")#mi("{L(s, \\chi)}")#text(" is then defined (for ")#mi("{s \\in {\\bf C}}")#text(" of sufficiently large real part, at least) as")

#tao-aligned(keep: true)[


#tao-math("L(s,\\chi)  & := \\sum_{n \\in {\\mathbb F}[X]^{\\prime}} \\frac{\\chi(n)}{\\left|n\\right|^s}", block: true)



#tao-math(" & = \\sum_{m=0}^\\infty q^{-sm} \\sum_{n \\in {\\mathbb F}[X]^{\\prime}: \\left|n\\right| = q^m} \\chi(n).", block: true)
]

#text("Note that for ")#mi("{m \\geq N+1}")#text(", the set ")#tao-math("{n \\in {\\mathbb F}[X]^{\\prime}: \\left|n\\right| = q^m}", block: false)#text(" is invariant under shifts ")#mi("{h}")#text(" whenever ")#tao-math("{\\left|h\\right| < T}", block: false)#text("; since this covers a full set of residue classes of ")#mi("{{\\mathbb F}[X]/Q{\\mathbb F}[X]}")#text(", and the odd character ")#mi("{\\chi}")#text(" has mean zero on this set of residue classes, we conclude that the sum ")#tao-math("{\\sum_{n \\in {\\mathbb F}[X]^{\\prime}: \\left|n\\right| = q^m} \\chi(n)}", block: false)#text(" vanishes for ")#mi("{m \\geq N+1}")#text(". In particular, the ")#mi("{L}")#text("-function is entire, and for any real number ")#mi("{t}")#text(" and complex number ")#mi("{z}")#text(", we can write the ")#mi("{L}")#text("-function as a polynomial")

#align(center)[#tao-fit-display[#mitex("L(\\frac{1}{2} + it - \\frac{2\\pi i z}{\\log T},\\chi) = P(Z) = P_{t,\\chi}(Z) := \\sum_{m=0}^N c^1_m(t,\\chi) Z^j")]]

#text("where ")#mi("{Z := e(z/N) = e^{2\\pi i z/N}}")#text(" and the coefficients ")#mi("{c^1_m = c^1_m(t,\\chi)}")#text(" are given by the formula")

#align(center)[#tao-fit-display[#tao-math("c^1_m(t,\\chi) := q^{-m/2-imt} \\sum_{n \\in {\\mathbb F}[X]^{\\prime}: \\left|n\\right| = q^m} \\chi(n).", block: true)]]

#text("Note that ")#mi("{t}")#text(" can easily be normalised to zero by the relation ")#metadata(none) <tao-16e9e9d806857255d617>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("P_{t,\\chi}(Z) = P_{0,\\chi}( q^{-it} Z ).")]]

#text("In particular, the dependence on ")#mi("{t}")#text(" is periodic with period ")#mi("{\\frac{2\\pi}{\\log q}}")#text(" (so by abuse of notation one could also take ")#mi("{t}")#text(" to be an element of ")#mi("{{\\bf R}/\\frac{2\\pi}{\\log q}{\\bf Z}}")#text(").")

#text("Fourier inversion yields a functional equation for the polynomial ")#mi("{P}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Functional equation)")]#text(" Let ")#mi("{\\chi}")#text(" be an odd Dirichlet character of modulus ")#mi("{Q}")#text(", and ")#mi("{t \\in {\\bf R}}")#text(". There exists a phase ")#mi("{e(\\theta)}")#text(" (depending on ")#mi("{t,\\chi}")#text(") such that")

#align(center)[#tao-fit-display[#mitex("a_{N-m}^1 = e(\\theta) \\overline{c^1_m}")]]

#text("for all ")#mi("{0 \\leq m \\leq N}")#text(", or equivalently that")

#align(center)[#tao-fit-display[#mitex("P(1/Z) = e^{i\\theta} Z^{-N} \\overline{P}(Z)")]]

#text("where ")#mi("{\\overline{P}(Z) := \\overline{P(\\overline{Z})}}")#text(".")
]

#emph[#text("Proof:")]#text(" We can normalise ")#mi("{t=0}")#text(". Let ")#mi("{G}")#text(" be the finite field ")#mi("{{\\mathbb F}[X] / Q {\\mathbb F}[X]}")#text(". We can write")

#align(center)[#tao-fit-display[#mitex("a_{N-m} = q^{-(N-m)/2} \\sum_{n \\in q^{N-m} + H_{N-m}} \\chi(n)")]]

#text("where ")#mi("{H_j}")#text(" denotes the subgroup of ")#mi("{G}")#text(" consisting of (residue classes of) polynomials of degree less than ")#mi("{j}")#text(". Let ")#mi("{e_G: G \\rightarrow S^1}")#text(" be a non-trivial character of ")#mi("{G}")#text(" whose kernel lies in the space ")#mi("{H_N}")#text(" (this is easily achieved by pulling back a non-trivial character from the quotient ")#mi("{G/H_N \\equiv {\\mathbb F}}")#text("). We can use the Fourier inversion formula to write")

#align(center)[#tao-fit-display[#mitex("a_{N-m} = q^{(m-N)/2} \\sum_{\\xi \\in G} \\hat \\chi(\\xi) \\sum_{n \\in T^{N-m} + H_{N-m}} e_G( n\\xi )")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\hat \\chi(\\xi) := q^{-N-1} \\sum_{n \\in G} \\chi(n) e_G(-n\\xi).")]]

#text("From change of variables we see that ")#mi("{\\hat \\chi}")#text(" is a scalar multiple of ")#mi("{\\overline{\\chi}}")#text("; from Plancherel we conclude that ")#metadata(none) <tao-18e1dd392168f601d0e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\hat \\chi = e(\\theta_0) q^{-(N+1)/2} \\overline{\\chi}")]]

#text("for some phase ")#mi("{e(\\theta_0)}")#text(". We conclude that ")#metadata(none) <tao-e96e02d8e47f2a7c03be>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("a_{N-m} = e(\\theta_0) q^{-(2N-m+1)/2} \\sum_{\\xi \\in G} \\overline{\\chi}(\\xi) e_G( T^{N-j} \\xi) \\sum_{n \\in H_{N-j}} e_G( n\\xi ).")]]

#text("The inner sum ")#mi("{\\sum_{n \\in H_{N-m}} e_G( n\\xi )}")#text(" equals ")#mi("{q^{N-m}}")#text(" if ")#mi("{\\xi \\in H_{j+1}}")#text(", and vanishes otherwise, thus")

#align(center)[#tao-fit-display[#mitex("a_{N-m} = e(\\theta_0) q^{-(m+1)/2} \\sum_{\\xi \\in H_{j+1}} \\overline{\\chi}(\\xi) e_G( T^{N-m} \\xi).")]]

#text("For ")#mi("{\\xi}")#text(" in ")#mi("{H_j}")#text(", ")#mi("{e_G(T^{N-m} \\xi)=1}")#text(" and the contribution of the sum vanishes as ")#mi("{\\chi}")#text(" is odd. Thus we may restrict ")#mi("{\\xi}")#text(" to ")#mi("{H_{m+1} \\backslash H_m}")#text(", so that")

#align(center)[#tao-fit-display[#mitex("a_{N-m} = e(\\theta_0) q^{-(m+1)/2} \\sum_{h \\in {\\mathbb F}^\\times} e_G( T^{N} h) \\sum_{\\xi \\in h T^m + H_{m}} \\overline{\\chi}(\\xi).")]]

#text("By the multiplicativity of ")#mi("{\\chi}")#text(", this factorises as")

#align(center)[#tao-fit-display[#mitex("a_{N-m} = e(\\theta_0) q^{-(m+1)/2} (\\sum_{h \\in {\\mathbb F}^\\times} \\overline{\\chi}(h) e_G( T^{N} h)) (\\sum_{\\xi \\in T^m + H_{m}} \\overline{\\chi}(\\xi)).")]]

#text("From the one-dimensional version of ")#link(<tao-18e1dd392168f601d0e5>)[#text("(3)")]#text(" (and the fact that ")#mi("{\\chi}")#text(" is odd) we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{h \\in {\\mathbb F}^\\times} \\overline{\\chi}(h) e_G( T^{N} h) = e(\\theta_1) q^{1/2}")]]

#text("for some phase ")#mi("{e(\\theta_1)}")#text(". The claim follows. ")#mi("\\Box")

#text("As one corollary of the functional equation, ")#mi("{a_N}")#text(" is a phase rotation of ")#mi("{\\overline{a_1} = 1}")#text(" and thus is non-zero, so ")#mi("{P}")#text(" has degree exactly ")#mi("{N}")#text(". The functional equation is then equivalent to the ")#mi("{N}")#text(" zeroes of ")#mi("{P}")#text(" being symmetric across the unit circle. In fact we have the stronger")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Riemann hypothesis for Dirichlet ")#mi("{L}")#text("-functions over function fields)")]#text(" Let ")#mi("{\\chi}")#text(" be an odd Dirichlet character of modulus ")#mi("{Q}")#text(", and ")#mi("{t \\in {\\bf R}}")#text(". Then all the zeroes of ")#mi("{P}")#text(" lie on the unit circle.")
]

#text("We derive this result from the Riemann hypothesis for curves over function fields below the fold.")

#text("In view of this theorem (and the fact that ")#mi("{a_1=1}")#text("), we may write")

#align(center)[#tao-fit-display[#mitex("P(Z) = \\mathrm{det}(1 - ZU)")]]

#text("for some unitary ")#mi("{N \\times N}")#text(" matrix ")#mi("{U = U_{t,\\chi}}")#text(". It is possible to interpret ")#mi("{U}")#text(" as the action of the geometric Frobenius map on a certain cohomology group, but we will not do so here. The situation here is simpler than in the number field case because the factor ")#mi("{\\exp(A)}")#text(" arising from very small primes is now absent (in the function field setting there are no primes of size between ")#mi("{1}")#text(" and ")#mi("{q}")#text(").")

#text("We now let ")#mi("{\\chi}")#text(" vary uniformly at random over all odd characters of modulus ")#mi("{Q}")#text(", and ")#mi("{t}")#text(" uniformly over ")#mi("{{\\bf R}/\\frac{2\\pi}{\\log q}{\\bf Z}}")#text(", independently of ")#mi("{\\chi}")#text("; we also make the distribution of the random variable ")#mi("{U}")#text(" conjugation invariant in ")#mi("{U(N)}")#text(". We use ")#mi("{{\\mathbf E}_Q}")#text(" to denote the expectation with respect to this randomness. One can then ask what the limiting distribution of ")#mi("{U}")#text(" is in various regimes; we will focus in this post on the regime where ")#mi("{N}")#text(" is fixed and ")#mi("{q}")#text(" is being sent to infinity. In the spirit of the ")#link("https://en.wikipedia.org/wiki/Sato%E2%80%93Tate_conjecture")[#text("Sato-Tate conjecture")]#text(", one should expect ")#mi("{U}")#text(" to converge in distribution to the ")#link("https://en.wikipedia.org/wiki/Circular_unitary_ensemble")[#text("circular unitary ensemble")]#text(" (CUE), that is to say Haar probability measure on ")#mi("{U(N)}")#text(". This may well be provable from Deligne’s “Weil II” machinery (in the spirit of this monograph of Katz and Sarnak), though I do not know how feasible this is or whether it has already been done in the literature; here we shall avoid using this machinery and study what partial results towards this CUE hypothesis one can make without it.")

#text("If one lets ")#mi("{\\lambda_1,\\dots,\\lambda_N}")#text(" be the eigenvalues of ")#mi("{U}")#text(" (ordered arbitrarily), then we now have")

#align(center)[#tao-fit-display[#mitex("\\sum_{m=0}^N c^1_m Z^m = P(Z) = \\prod_{j=1}^N (1 - \\lambda_j Z)")]]

#text("and hence the ")#mi("{c^1_m}")#text(" are essentially ")#link("https://en.wikipedia.org/wiki/Elementary_symmetric_polynomial")[#text("elementary symmetric polynomials")]#text(" of the eigenvalues: ")#metadata(none) <tao-5ba20d062a5894849d9a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("c^1_m = (-1)^j e_m( \\lambda_1,\\dots,\\lambda_N).")]]

#text("One can take log derivatives to conclude")

#align(center)[#tao-fit-display[#mitex("\\frac{P^{\\prime}(Z)}{P(Z)} = \\sum_{j=1}^N \\frac{\\lambda_j}{1-\\lambda_j Z}.")]]

#text("On the other hand, as in the number field case one has the Dirichlet series expansion")

#align(center)[#tao-fit-display[#tao-math("Z \\frac{P^{\\prime}(Z)}{P(Z)} = \\sum_{n \\in {\\mathbb F}[X]^{\\prime}} \\frac{\\Lambda_q(n) \\chi(n)}{\\left|n\\right|^s}", block: true)]]

#text("where ")#mi("{s = \\frac{1}{2} + it - \\frac{2\\pi i z}{\\log T}}")#text(" has sufficiently large real part, ")#mi("{Z = e(z/N)}")#text(", and the von Mangoldt function ")#mi("{\\Lambda_q(n)}")#text(" is defined as ")#tao-math("{\\log_q \\left|p\\right| = \\mathrm{deg} p}", block: false)#text(" when ")#mi("{n}")#text(" is the power of an irreducible ")#mi("{p}")#text(" and ")#mi("{0}")#text(" otherwise. We conclude the “explicit formula” ")#metadata(none) <tao-3b283e93debf035e990d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("c^{\\Lambda_q}_m = \\sum_{j=1}^N \\lambda_j^m = \\mathrm{tr}(U^m)")]]

#text("for ")#mi("{m \\geq 1}")#text(", where")

#align(center)[#tao-fit-display[#tao-math("c^{\\Lambda_q}_m := q^{-m/2-imt} \\sum_{n \\in {\\mathbb F}[X]^{\\prime}: \\left|n\\right| = q^m} \\Lambda_q(n) \\chi(n).", block: true)]]

#text("Similarly on inverting ")#mi("{P(Z)}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("P(Z)^{-1} = \\prod_{j=1}^N (1 - \\lambda_j Z)^{-1}.")]]

#text("Since we also have")

#align(center)[#tao-fit-display[#tao-math("P(Z)^{-1} = \\sum_{n \\in {\\mathbb F}[X]^{\\prime}} \\frac{\\mu(n) \\chi(n)}{\\left|n\\right|^s}", block: true)]]

#text("for ")#mi("{s}")#text(" sufficiently large real part, where the Möbius function ")#mi("{\\mu(n)}")#text(" is equal to ")#mi("{(-1)^k}")#text(" when ")#mi("{n}")#text(" is the product of ")#mi("{k}")#text(" distinct irreducibles, and ")#mi("{0}")#text(" otherwise, we conclude that the Möbius coefficients")

#align(center)[#tao-fit-display[#tao-math("c^\\mu_m := q^{-m/2-imt} \\sum_{n \\in {\\mathbb F}[X]^{\\prime}: \\left|n\\right| = q^m} \\mu(n) \\chi(n)", block: true)]]

#text("are just the ")#link("https://en.wikipedia.org/wiki/Complete_homogeneous_symmetric_polynomial")[#text("complete homogeneous symmetric polynomials")]#text(" of the eigenvalues: ")#metadata(none) <tao-707a3c64c7c00e52ae88>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("c^\\mu_m = h_m( \\lambda_1,\\dots,\\lambda_N).")]]

#text("One can then derive various algebraic relationships between the coefficients ")#mi("{c^1_m, c^{\\Lambda_q}_m, c^\\mu_m}")#text(" from various identities involving symmetric polynomials, but we will not do so here.")

#text("What do we know about the distribution of ")#mi("{U}")#text("? By construction, it is conjugation-invariant; from ")#link(<tao-16e9e9d806857255d617>)[#text("(2)")]#text(" it is also invariant with respect to the rotations ")#mi("{U \\rightarrow e^{i\\theta} U}")#text(" for any phase ")#mi("{\\theta \\in{\\bf R}}")#text(". We also have the function field analogue of the Rudnick-Sarnak asymptotics:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Rudnick-Sarnak asymptotics)")]#text(" ")#metadata(none) <tao-571b0e35550136585f65>#text(" Let ")#mi("{a_1,\\dots,a_k,b_1,\\dots,b_k}")#text(" be nonnegative integers. If ")#metadata(none) <tao-7afee126181838479e85>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\sum_{j=1}^k j a_j \\leq N,")]]

#text("then the moment ")#metadata(none) <tao-b6813f3af2d45fbfc768>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("{\\bf E}_{Q} \\prod_{j=1}^k (\\mathrm{tr} U^j)^{a_j} (\\overline{\\mathrm{tr} U^j})^{b_j}")]]

#text("is equal to ")#mi("{o(1)}")#text(" in the limit ")#mi("{q \\rightarrow \\infty}")#text(" (holding ")#mi("{N,a_1,\\dots,a_k,b_1,\\dots,b_k}")#text(" fixed) unless ")#mi("{a_j=b_j}")#text(" for all ")#mi("{j}")#text(", in which case it is equal to ")#metadata(none) <tao-21b5932ed6a0c67b7991>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\prod_{j=1}^k j^{a_j} a_j! + o(1).")]]
]

#text("Comparing this with Proposition 1 from ")#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/")[#text("this previous post")]#text(", we thus see that all the low moments of ")#mi("{U}")#text(" are consistent with the CUE hypothesis (and also with the ACUE hypothesis, again by the previous post). The case ")#mi("{\\sum_{j=1}^k a_j + \\sum_{j=1}^k b_j \\leq 2}")#text(" of this proposition was essentially established by ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3282994")[#text("Andrade, Miller, Pratt, and Trinh")]#text(".")

#emph[#text("Proof:")]#text(" We may assume the homogeneity relationship ")#metadata(none) <tao-2eca094654ff645c50cf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\sum_{j=1}^k j a_j = \\sum_{j=1}^k j b_j")]]

#text("since otherwise the claim follows from the invariance under phase rotation ")#mi("{U \\mapsto e^{i\\theta} U}")#text(". By ")#link(<tao-3b283e93debf035e990d>)[#text("(6)")]#text(", the expression ")#link(<tao-b6813f3af2d45fbfc768>)[#text("(9)")]#text(" is equal to")

#align(center)[#tao-fit-display[#tao-math("q^{-D} {\\bf E}_Q \\sum_{n_1,\\dots,n_l,n^{\\prime}_1,\\dots,n^{\\prime}_{l^{\\prime}} \\in {\\mathbb F}[X]^{\\prime}: \\left|n_i\\right| = q^{s_i}, \\left|n^{\\prime}_i\\right| = q^{s^{\\prime}_i}} (\\prod_{i=1}^l \\Lambda_q(n_i) \\chi(n_i)) \\prod_{i=1}^{l^{\\prime}} \\Lambda_q(n^{\\prime}_i) \\overline{\\chi(n^{\\prime}_i)}", block: true)]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("D  & := \\sum_{j=1}^k j a_j = \\sum_{j=1}^k j b_j", block: true)



#tao-math("l  & := \\sum_{j=1}^k a_j", block: true)



#tao-math("l^{\\prime}  & := \\sum_{j=1}^k b_j", block: true)
]

#text("and ")#mi("{s_1 \\leq \\dots \\leq s_l}")#text(" consists of ")#mi("{a_j}")#text(" copies of ")#mi("{j}")#text(" for each ")#mi("{j=1,\\dots,k}")#text(", and similarly ")#mi("{s^{\\prime}_1 \\leq \\dots \\leq s^{\\prime}_{l^{\\prime}}}")#text(" consists of ")#mi("{b_j}")#text(" copies of ")#mi("{j}")#text(" for each ")#mi("{j=1,\\dots,k}")#text(".")

#text("The polynomials ")#mi("{n_1 \\dots n_l}")#text(" and ")#mi("{n^{\\prime}_1 \\dots n^{\\prime}_{l^{\\prime}}}")#text(" are monic of degree ")#mi("{D}")#text(", which by hypothesis is less than the degree of ")#mi("{Q}")#text(", and thus they can only be scalar multiples of each other in ")#mi("{{\\mathbb F}[X] / Q {\\mathbb F}[X]}")#text(" if they are identical (in ")#mi("{{\\mathbb F}[X]}")#text("). As such, we see that the average")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_Q \\chi(n_1) \\dots \\chi(n_l) \\overline{\\chi(n^{\\prime}_1)} \\dots \\overline{\\chi(n^{\\prime}_{l^{\\prime}})}")]]

#text("vanishes unless ")#mi("{n_1 \\dots n_l = n^{\\prime}_1 \\dots n^{\\prime}_{l^{\\prime}}}")#text(", in which case this average is equal to ")#mi("{1}")#text(". Thus the expression ")#link(<tao-b6813f3af2d45fbfc768>)[#text("(9)")]#text(" simplifies to")

#align(center)[#tao-fit-display[#tao-math("q^{-D} \\sum_{n_1,\\dots,n_l,n^{\\prime}_1,\\dots,n^{\\prime}_{l^{\\prime}}: \\left|n_i\\right| = q^{s_i}, \\left|n^{\\prime}_i\\right| = q^{s^{\\prime}_i}; n_1 \\dots n_l = n^{\\prime}_1 \\dots n^{\\prime}_l} (\\prod_{i=1}^l \\Lambda_q(n_i)) \\prod_{i=1}^{l^{\\prime}} \\Lambda_q(n^{\\prime}_i).", block: true)]]

#text("There are at most ")#mi("{q^D}")#text(" choices for the product ")#mi("{n_1 \\dots n_l}")#text(", and each one contributes ")#mi("{O_D(1)}")#text(" to the above sum. All but ")#mi("{o(q^D)}")#text(" of these choices are square-free, so by accepting an error of ")#mi("{o(1)}")#text(", we may restrict attention to square-free ")#mi("{n_1 \\dots n_l}")#text(". This forces ")#mi("{n_1,\\dots,n_l,n^{\\prime}_1,\\dots,n^{\\prime}_{l^{\\prime}}}")#text(" to all be irreducible (as opposed to powers of irreducibles); as ")#mi("{{\\mathbb F}[X]}")#text(" is a unique factorisation domain, this forces ")#mi("{l=l^{\\prime}}")#text(" and ")#mi("{n_1,\\dots,n_l}")#text(" to be a permutation of ")#mi("{n^{\\prime}_1,\\dots,n^{\\prime}_{l^{\\prime}}}")#text(". By the size restrictions, this then forces ")#mi("{a_j = b_j}")#text(" for all ")#mi("{j}")#text(" (if the above expression is to be anything other than ")#mi("{o(1)}")#text("), and each ")#mi("{n_1,\\dots,n_l}")#text(" is associated to ")#mi("{\\prod_{j=1}^k a_j!}")#text(" possible choices of ")#mi("{n^{\\prime}_1,\\dots,n^{\\prime}_{l^{\\prime}}}")#text(". Writing ")#mi("{\\Lambda_q(n^{\\prime}_i) = s^{\\prime}_i}")#text(" and then reinstating the non-squarefree possibilities for ")#mi("{n_1 \\dots n_l}")#text(", we can thus write the above expression as")

#align(center)[#tao-fit-display[#tao-math("q^{-D} \\prod_{j=1}^k j a_j! \\sum_{n_1,\\dots,n_l,n^{\\prime}_1,\\dots,n^{\\prime}_{l^{\\prime}}\\in {\\mathbb F}[X]^{\\prime}: \\left|n_i\\right| = q^{s_i}} \\prod_{i=1}^l \\Lambda_q(n_i) + o(1).", block: true)]]

#text("Using the prime number theorem ")#tao-math("{\\sum_{n \\in {\\mathbb F}[X]^{\\prime}: \\left|n\\right| = q^s} \\Lambda_q(n) = q^s}", block: false)#text(", we obtain the claim. ")#mi("\\Box")

#text("Comparing this with Proposition 1 from ")#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/")[#text("this previous post")]#text(", we thus see that all the low moments of ")#mi("{U}")#text(" are consistent with the CUE and ACUE hypotheses:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 4 (CUE statistics at low frequencies)")]#text(" Let ")#mi("{\\lambda_1,\\dots,\\lambda_N}")#text(" be the eigenvalues of ")#mi("{U}")#text(", permuted uniformly at random. Let ")#mi("{R(\\lambda)}")#text(" be a linear combination of monomials ")#mi("{\\lambda_1^{a_1} \\dots \\lambda_N^{a_N}}")#text(" where ")#mi("{a_1,\\dots,a_N}")#text(" are integers with either ")#mi("{\\sum_{j=1}^N a_j \\neq 0}")#text(" or ")#tao-math("{\\sum_{j=1}^N \\left|a_j\\right| \\leq 2N}", block: false)#text(". Then")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_Q R(\\lambda) = {\\bf E}_{CUE} R(\\lambda) + o(1).")]]
]

#text("The analogue of the GUE hypothesis in this setting would be the CUE hypothesis, which asserts that the threshold ")#mi("{2N}")#text(" here can be replaced by an arbitrarily large quantity. As far as I know this is not known even for ")#mi("{2N+2}")#text(" (though, as mentioned previously, in principle one may be able to resolve such cases using Deligne’s proof of the Riemann hypothesis for function fields). Among other things, this would allow one to distinguish CUE from ACUE, since as discussed in ")#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/")[#text("the previous post")]#text(", these two distributions agree when tested against monomials up to threshold ")#mi("{2N}")#text(", though not to ")#mi("{2N+2}")#text(".")

#emph[#text("Proof:")]#text(" By permutation symmetry we can take ")#mi("{R}")#text(" to be symmetric, and by linearity we may then take ")#mi("{R}")#text(" to be the symmetrisation of a single monomial ")#mi("{\\lambda_1^{a_1} \\dots \\lambda_N^{a_N}}")#text(". If ")#mi("{\\sum_{j=1}^N a_j \\neq 0}")#text(" then both expectations vanish due to the phase rotation symmetry, so we may assume that ")#mi("{\\sum_{j=1}^N a_j \\neq 0}")#text(" and ")#tao-math("{\\sum_{j=1}^N \\left|a_j\\right| \\leq 2N}", block: false)#text(". We can write this symmetric polynomial as a constant multiple of ")#mi("{\\mathrm{tr}(U^{a_1}) \\dots \\mathrm{tr}(U^{a_N})}")#text(" plus other monomials with a smaller value of ")#tao-math("{\\sum_{j=1}^N \\left|a_j\\right|}", block: false)#text(". Since ")#mi("{\\mathrm{tr}(U^{-a}) = \\overline{\\mathrm{tr}(U^a)}}")#text(", the claim now follows by induction from Proposition ")#link(<tao-571b0e35550136585f65>)[#text("3")]#text(" and Proposition 1 from the ")#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/")[#text("previous post")]#text(". ")#mi("\\Box")

#text("Thus, for instance, for ")#mi("{k=1,2}")#text(", the ")#mi("{2k^{th}}")#text(" moment")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_Q \\left|\\det(1-U)\\right|^{2k} = {\\bf E}_Q \\left|P(1)\\right|^{2k} = {\\bf E}_Q \\left|L(\\frac{1}{2} + it, \\chi)\\right|^{2k}", block: true)]]

#text("is equal to")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_{CUE} \\left|\\det(1-U)\\right|^{2k} + o(1)", block: true)]]

#text("because all the monomials in ")#mi("{\\prod_{j=1}^N (1-\\lambda_j)^k (1-\\lambda_j^{-1})^k}")#text(" are of the required form when ")#mi("{k \\leq 2}")#text(". The latter expectation can be computed exactly (for any natural number ")#mi("{k}")#text(") using a formula")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_{CUE} \\left|\\det(1-U)\\right|^{2k} = \\prod_{j=1}^N \\frac{\\Gamma(j) \\Gamma(j+2k)}{\\Gamma(j+k)^2}", block: true)]]

#text("of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1478074")[#text("Baker-Forrester")]#text(" and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1794265")[#text("Keating-Snaith")]#text(", thus for instance")

#tao-aligned(keep: true)[


#tao-math("{\\bf E}_{CUE} \\left|\\det(1-U)\\right|^2  & = N+1", block: true)



#tao-math("{\\bf E}_{CUE} \\left|\\det(1-U)\\right|^4  & = \\frac{(N+1)(N+2)^2(N+3)}{12}", block: true)
]

#text("and more generally")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_{CUE}\\left|\\det(1-U)\\right|^{2k} = \\frac{g_k+o(1)}{(k^2)!} N^{k^2}", block: true)]]

#text("when ")#mi("{N \\rightarrow \\infty}")#text(", where ")#mi("{g_k}")#text(" are the integers")

#align(center)[#tao-fit-display[#mitex("g_1 = 1, g_2 = 2, g_3 = 42, g_4 = 24024, \\dots")]]

#text("and more generally")

#align(center)[#tao-fit-display[#tao-math("g_k := \\frac{(k^2)!}{\\prod_{i=1}^{2k-1} i^{k-\\left|k-i\\right|}}", block: true)]]

#text("(")#link("https://oeis.org/A039622")[#text("OEIS A039622")]#text("). Thus we have")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_Q \\left|\\det(1-U)\\right|^{2k} = \\frac{g_k+o(1)}{k^2!} N^{k^2}", block: true)]]

#text("for ")#mi("{k=1,2}")#text(" if ")#mi("{Q \\rightarrow \\infty}")#text(" and ")#mi("{N}")#text(" is sufficiently slowly growing depending on ")#mi("{Q}")#text(". The CUE hypothesis would imply that that this formula also holds for higher ")#mi("{k}")#text(". (The situation here is cleaner than in the number field case, in which the GUE hypothesis only suggests the correct lower bound for the moments rather than an asymptotic, due to the absence of the wildly fluctuating additional factor ")#mi("{\\exp(A)}")#text(" that is present in the Riemann zeta function model.)")

#text("Now we can recover the analogue of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=337821")[#text("Montgomery’s work on the pair correlation conjecture")]#text(". Consider the statistic")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_Q \\sum_{1 \\leq i,j \\leq N} R( \\lambda_i / \\lambda_j )")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("R(z) = \\sum_m \\hat R(m) z^m")]]

#text("is some finite linear combination of monomials ")#mi("{z^m}")#text(" independent of ")#mi("{q}")#text(". We can expand the above sum as")

#align(center)[#tao-fit-display[#mitex("\\sum_m \\hat R(m) {\\bf E}_Q \\mathrm{tr}(U^m) \\mathrm{tr}(U^{-m}).")]]

#text("Assuming the CUE hypothesis, then by Example 3 of ")#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/")[#text("the previous post")]#text(", we would conclude that ")#metadata(none) <tao-2ab698dc4b2a66395886>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("{\\bf E}_Q \\sum_{1 \\leq i,j \\leq N} R( \\lambda_i / \\lambda_j ) = N^2 \\hat R(0) + \\sum_m \\min(\\left|m\\right|,N) \\hat R(m) + o(1).", block: true)]]

#text("This is the analogue of Montgomery’s pair correlation conjecture. Proposition ")#link(<tao-571b0e35550136585f65>)[#text("3")]#text(" implies that this claim is true whenever ")#mi("{\\hat R}")#text(" is supported on ")#mi("{[-N,N]}")#text(". If instead we assume the ACUE hypothesis (or the weaker Alternative Hypothesis that the phase gaps are non-zero multiples of ")#mi("{1/2N}")#text("), one should instead have")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_Q \\sum_{1 \\leq i,j \\leq N} R( \\lambda_i / \\lambda_j ) = \\sum_{k \\in {\\bf Z}} N^2 \\hat R(2Nk) + \\sum_{1 \\leq \\left|m\\right| \\leq N} |m| \\hat R(m+2Nk) + o(1)", block: true)]]

#text("for arbitrary ")#mi("{R}")#text("; this is the function field analogue of a recent ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3531237")[#text("result of Baluyot")]#text(". In any event, since ")#mi("{\\mathrm{tr}(U^m) \\mathrm{tr}(U^{-m})}")#text(" is non-negative, we unconditionally have the lower bound ")#metadata(none) <tao-64c5b74ea910c3d45ee3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("{\\bf E}_Q \\sum_{1 \\leq i,j \\leq N} R( \\lambda_i / \\lambda_j ) \\geq N^2 \\hat R(0) + \\sum_{1 \\leq \\left|m\\right| \\leq N} |m| \\hat R(m) + o(1).", block: true)]]

#text("if ")#mi("{\\hat R(m)}")#text(" is non-negative for ")#tao-math("{\\left|m\\right| > N}", block: false)#text(".")

#text("By applying ")#link(<tao-2ab698dc4b2a66395886>)[#text("(12)")]#text(" for various choices of test functions ")#mi("{R}")#text(" we can obtain various bounds on the behaviour of eigenvalues. For instance suppose we take the Fejér kernel")

#align(center)[#tao-fit-display[#tao-math("R(z) = \\left|1 + z + \\dots + z^N\\right|^2 = \\sum_{m=-N}^N (N+1-\\left|m\\right|) z^m.", block: true)]]

#text("Then ")#link(<tao-2ab698dc4b2a66395886>)[#text("(12)")]#text(" applies unconditionally and we conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_Q \\sum_{1 \\leq i,j \\leq N} R( \\lambda_i / \\lambda_j ) = N^2 (N+1) + \\sum_{1 \\leq \\left|m\\right| \\leq N} (N+1-\\left|m\\right|) \\left|m\\right| + o(1).", block: true)]]

#text("The right-hand side evaluates to ")#mi("{\\frac{2}{3} N(N+1)(2N+1)+o(1)}")#text(". On the other hand, ")#mi("{R(\\lambda_i/\\lambda_j)}")#text(" is non-negative, and equal to ")#mi("{(N+1)^2}")#text(" when ")#mi("{\\lambda_i = \\lambda_j}")#text(". Thus")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_Q \\sum_{1 \\leq i,j \\leq N} 1_{\\lambda_i = \\lambda_j} \\leq \\frac{2}{3} \\frac{N(2N+1)}{N+1} + o(1).")]]

#text("The sum ")#mi("{\\sum_{1 \\leq j \\leq N} 1_{\\lambda_i = \\lambda_j}}")#text(" is at least ")#mi("{1}")#text(", and is at least ")#mi("{2}")#text(" if ")#mi("{\\lambda_i}")#text(" is not a simple eigenvalue. Thus")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_Q \\sum_{1 \\leq i, \\leq N} 1_{\\lambda_i \\text{ not simple}} \\leq \\frac{1}{3} \\frac{N(N-1)}{N+1} + o(1),")]]

#text("and thus the expected number of simple eigenvalues is at least ")#mi("{\\frac{2N}{3} \\frac{N+4}{N+1} + o(1)}")#text("; in particular, at least two thirds of the eigenvalues are simple asymptotically on average. If we had ")#link(<tao-2ab698dc4b2a66395886>)[#text("(12)")]#text(" without any restriction on the support of ")#mi("{\\hat R}")#text(", the same arguments allow one to show that the expected proportion of simple eigenvalues is ")#mi("{1-o(1)}")#text(".")

#text("Suppose that the phase gaps in ")#mi("{U}")#text(" are all greater than ")#mi("{c/N}")#text(" almost surely. Let ")#mi("{\\hat R}")#text(" is non-negative and ")#mi("{R(e^{i\\theta})}")#text(" non-positive for ")#mi("{\\theta}")#text(" outside of the arc ")#mi("{[-c/N,c/N]}")#text(". Then from ")#link(<tao-64c5b74ea910c3d45ee3>)[#text("(13)")]#text(" one has")

#align(center)[#tao-fit-display[#tao-math("R(0) N \\geq N^2 \\hat R(0) + \\sum_{1 \\leq \\left|m\\right| \\leq N} |m| \\hat R(m) + o(1),", block: true)]]

#text("so by taking contrapositives one can force the existence of a gap less than ")#mi("{c/N}")#text(" asymptotically if one can find ")#mi("{R}")#text(" with ")#mi("{\\hat R}")#text(" non-negative, ")#mi("{R}")#text(" non-positive for ")#mi("{\\theta}")#text(" outside of the arc ")#mi("{[-c/N,c/N]}")#text(", and for which one has the inequality")

#align(center)[#tao-fit-display[#tao-math("R(0) N < N^2 \\hat R(0) + \\sum_{1 \\leq \\left|m\\right| \\leq N} |m| \\hat R(m).", block: true)]]

#text("By a suitable choice of ")#mi("{R}")#text(" (based on a minorant of Selberg) one can ensure this for ")#mi("{c \\approx 0.6072}")#text(" for ")#mi("{N}")#text(" large; see Section 5 of ")#link("https://arxiv.org/abs/math/0412313")[#text("these notes of Goldston")]#text(". This is not the smallest value of ")#mi("{c}")#text(" currently obtainable in the literature for the number field case (which is currently ")#mi("{0.50412}")#text(", ")#link("https://arxiv.org/abs/1904.06001")[#text("due to Goldston and Turnage-Butterbaugh")]#text(", by a somewhat different method), but is still significantly less than the trivial value of ")#mi("{1}")#text(". On the other hand, due to the compatibility of the ACUE distribution with Proposition ")#link(<tao-571b0e35550136585f65>)[#text("3")]#text(", it is not possible to lower ")#mi("{c}")#text(" below ")#mi("{0.5}")#text(" purely through the use of Proposition ")#link(<tao-571b0e35550136585f65>)[#text("3")]#text(".")

#text("In some cases it is possible to go beyond Proposition ")#link(<tao-571b0e35550136585f65>)[#text("3")]#text(". Consider the mollified moment")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_Q \\left|M(U) P(1)\\right|^2", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("M(U) = \\sum_{m=0}^d a_m h_m(\\lambda_1,\\dots,\\lambda_N)")]]

#text("for some coefficients ")#mi("{a_0,\\dots,a_d}")#text(". We can compute this moment in the CUE case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5")]#text(" We have")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_{CUE} \\left|M(U) P(1)\\right|^2 = \\left|a_0\\right|^2 + N \\sum_{m=1}^d \\left|a_m - a_{m-1}\\right|^2.", block: true)]]
]

#emph[#text("Proof:")]#text(" From ")#link(<tao-5ba20d062a5894849d9a>)[#text("(5)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("P(1) = \\sum_{i=0}^N (-1)^i e_i(\\lambda_1,\\dots,\\lambda_N)")]]

#text("hence")

#align(center)[#tao-fit-display[#mitex("M(U) P(1) = \\sum_{i=0}^N \\sum_{m=0}^d (-1)^i a_m e_i h_m")]]

#text("where we suppress the dependence on the eigenvalues ")#mi("{\\lambda}")#text(". Now observe the ")#link("https://en.wikipedia.org/wiki/Pieri%27s_formula")[#text("Pieri formula")]

#align(center)[#tao-fit-display[#mitex("e_i h_m = s_{m 1^i} + s_{(m+1) 1^{i-1}}")]]

#text("where ")#mi("{s_{m 1^i}}")#text(" are the hook Schur polynomials")

#align(center)[#tao-fit-display[#mitex("s_{m 1^i} = \\sum_{a_1 \\leq \\dots \\leq a_m; a_1 < b_1 < \\dots < b_i} \\lambda_{a_1} \\dots \\lambda_{a_m} \\lambda_{b_1} \\dots \\lambda_{b_i}")]]

#text("and we adopt the convention that ")#mi("{s_{m 1^i}}")#text(" vanishes for ")#mi("{i = -1}")#text(", or when ")#mi("{m = 0}")#text(" and ")#mi("{i > 0}")#text(". Then ")#mi("{s_{m1^i}}")#text(" also vanishes for ")#mi("{i\\geq N}")#text(". We conclude that")

#align(center)[#tao-fit-display[#mitex("M(U) P(1) = a_0 s_{0 1^0} + \\sum_{0 \\leq i \\leq N-1} \\sum_{m \\geq 1} (-1)^i (a_m - a_{m-1}) s_{m 1^i}.")]]

#text("As the Schur polynomials are orthonormal on the unitary group, the claim follows. ")#mi("\\Box")

#text("The CUE hypothesis would then imply the corresponding mollified moment conjecture ")#metadata(none) <tao-94f92db128c686d4006f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("{\\bf E}_{Q} \\left|M(U) P(1)\\right|^2 = \\left|a_0\\right|^2 + N \\sum_{m=1}^d \\left|a_m - a_{m-1}\\right|^2 + o(1).", block: true)]]

#text("(See ")#link("https://pdfs.semanticscholar.org/4d02/754a7ce900f7e0d52866f56a82a2c7bb92db.pdf")[#text("this paper of Conrey")]#text(", and ")#link("https://arxiv.org/abs/1207.6583")[#text("this paper of Radziwill")]#text(", for some discussion of the analogous conjecture for the zeta function, which is essentially ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1239132")[#text("due to Farmer")]#text(".)")

#text("From Proposition ")#link(<tao-571b0e35550136585f65>)[#text("3")]#text(" one sees that this conjecture holds in the range ")#mi("{d \\leq \\frac{1}{2} N}")#text(". It is likely that the function field analogue of the calculations ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1004130")[#text("of Conrey")]#text(" (based ultimately on deep exponential sum estimates ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1004130")[#text("of Deshouillers and Iwaniec")]#text(") can extend this range to ")#mi("{d < \\theta N}")#text(" for any ")#mi("{\\theta < \\frac{4}{7}}")#text(", if ")#mi("{N}")#text(" is sufficiently large depending on ")#mi("{\\theta}")#text("; these bounds thus go beyond what is available from Proposition ")#link(<tao-571b0e35550136585f65>)[#text("3")]#text(". On the other hand, as discussed in Remark 7 of ")#link("https://terrytao.wordpress.com/2019/05/08/the-alternative-hypothesis-for-unitary-matrices/")[#text("the previous post")]#text(", ACUE would also predict ")#link(<tao-94f92db128c686d4006f>)[#text("(14)")]#text(" for ")#mi("{d}")#text(" as large as ")#mi("{N-2}")#text(", so the available mollified moment estimates are not strong enough to rule out ACUE. It would be interesting to see if there is some other estimate in the function field setting that can be used to exclude the ACUE hypothesis (possibly one that exploits the fact that GRH is available in the function field case?).")

#metadata(none) <tao-df5893065b91529f3a9f>

#heading(level: 1)[#strong[#text(" — 1. Deriving RH for Dirichlet ")#mi("{L}")#text("-functions from RH for curves — ")]]

#text("In this section we show how every Dirichlet ")#mi("{L}")#text("-function over a function field with squarefree modulus ")#mi("{m}")#text(" is a factor of the ")#link("https://en.wikipedia.org/wiki/Local_zeta-function")[#text("zeta function of some curve")]#text(" over a function field up to a finite number of local factors, thus giving RH for the former as a consequence of RH for the latter (which can in turn be established by elementary methods such as Stepanov’s method, as discussed in ")#link("https://terrytao.wordpress.com/2014/05/02/the-bombieri-stepanov-proof-of-the-hasse-weil-bound/")[#text("this previous post")]#text("). The non-squarefree case is more complicated (and can be established using the machinery of ")#link("https://en.wikipedia.org/wiki/Drinfeld_module")[#text("Carlitz modules")]#text("), but we will not need to develop that case here. Thanks to Felipe Voloch and Will Sawin for explaining some of the arguments in this section (from ")#link("https://mathoverflow.net/questions/331544/what-is-the-most-direct-proof-of-the-riemann-hypothesis-for-dirichlet-l-function")[#text("this MathOverflow post")]#text(").")

#text("Let ")#mi("{n}")#text(" be the order of the Dirichlet character in question. We first deal with the simplest case, in which the modulus ")#mi("{m}")#text(" is irreducible, and ")#mi("{n}")#text(" divides ")#mi("{q-1}")#text("; furthermore we assume that ")#mi("{(-1)^{\\frac{q-1}{n}} = 1}")#text(" in ")#mi("{{\\mathbb F}}")#text(", that is to say at least one of ")#mi("{q}")#text(" and ")#mi("{\\frac{q-1}{n}}")#text(" is even.")

#text("In this case, we will show that")

#align(center)[#tao-fit-display[#mitex("\\prod_{\\chi: \\chi^n = 1} L(s,\\chi) = \\zeta_C(s)")]]

#text("up to a finite number of local factors, where ")#mi("{\\chi}")#text(" ranges over all Dirichlet characters of modulus ")#mi("{m}")#text(" and order at most ")#mi("{n}")#text(", and ")#mi("{C}")#text(" is the curve ")#mi("{\\{ (x,y): y^n = m(x) \\}}")#text(" over ")#mi("{{\\mathbb F}}")#text(". Taking logarithmic derivatives, this amounts to requiring the identity ")#metadata(none) <tao-780f86745746934c7b4b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\sum_{\\chi: \\chi^n = 1} \\sum_{a \\in {\\mathbb F}[X]^{\\prime}: \\left|a\\right| = q^D} \\chi(a) \\Lambda_q(a) = \\sum_{(x,y) \\in C({\\mathbb F}_{q^D})} 1", block: true)]]

#text("for all ")#mi("{D \\geq 1}")#text(".")

#text("The term ")#mi("{\\Lambda_q(a)}")#text(" is only non-zero when ")#mi("{a}")#text(" is of the form ")#mi("{a = p^j}")#text(" for some ")#mi("{j|D}")#text(" and some irreducible ")#mi("{p \\in {\\mathbb F}[X]^{\\prime}}")#text(" of degree ")#mi("{d = D/j}")#text(", in which case ")#mi("{\\Lambda_q(a) = d}")#text(". Each such ")#mi("{p}")#text(" has ")#mi("{d}")#text(" distinct roots in ")#mi("{{\\mathbb F}_{q^d} \\subset {\\mathbb F}_{q^D}}")#text(", which by the Frobenius action can be given as ")#mi("{\\beta, \\beta^q, \\dots, \\beta^{q^{d-1}}}")#text(". Each such root can be a choice for ")#mi("{x}")#text(" on the right-hand side of ")#link(<tao-780f86745746934c7b4b>)[#text("(15)")]#text(", and gives ")#mi("{n}")#text(" choices for ")#mi("{y}")#text(" if ")#mi("{m(\\beta)}")#text(" is an ")#mi("{n^{th}}")#text(" power in ")#mi("{{\\mathbb F}_{q^{dj}}}")#text(", and ")#mi("{0}")#text(" otherwise. Thus we reduce to showing that for all but finitely many ")#mi("{p}")#text(", we have the ")#mi("{n^{th}}")#text(" power reciprocity law")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\chi: \\chi^n = 1} \\chi(p^j) = n 1_{m(\\beta) = y^n \\text{ for some } {\\mathbb F}_{q^{dj}}}.")]]

#text("We can exclude the case ")#mi("{p=m}")#text(", so ")#mi("{p,m}")#text(" are now coprime. Let ")#mi("{N}")#text(" denote the degree of ")#mi("{m}")#text(". As ")#mi("{m}")#text(" is assumed irreducible, the multiplicative group ")#mi("{({\\mathbb F}[X]/m{\\mathbb F}[X])^\\times}")#text(" is cyclic of order ")#mi("{q^N-1}")#text(". From this it is easy to see that ")#mi("{\\sum_{\\chi: \\chi^n = 1} \\chi(a)}")#text(" is equal to ")#mi("{n}")#text(" when ")#mi("{a^{\\frac{q^N-1}{n}} = 1 \\text{ mod } m}")#text(", and zero otherwise. Thus we need to show that")

#align(center)[#tao-fit-display[#mitex("p^{\\frac{q^N-1}{n} j} = 1 \\text{ mod } m \\iff m(\\beta) = y^n \\text{ for some } {\\mathbb F}_{q^{dj}}.")]]

#text("Let ")#mi("{\\alpha,\\alpha^q,\\dots,\\alpha^{q^{N-1}}}")#text(" denote the roots of ")#mi("{m}")#text(" (in some extension of ")#mi("{{\\mathbb F}}")#text("). The condition ")#mi("{p^{\\frac{q^N-1}{n} j} = 1 \\text{ mod } m}")#text(" can be rewritten as")

#align(center)[#tao-fit-display[#mitex("p^{\\frac{q^N-1}{n} j}(\\alpha) = 1.")]]

#text("Factoring ")#mi("{\\frac{q^N-1}{n} = \\frac{q-1}{N} (1 + q + q^2 + \\dots + q^{N-1})}")#text(", this becomes")

#align(center)[#tao-fit-display[#mitex("(p(\\alpha) p(\\alpha^q) \\dots p(\\alpha^{q^{N-1}})^{\\frac{q-1}{n}j} = 1.")]]

#text("Using ")#link("https://en.wikipedia.org/wiki/Resultant")[#text("resultants")]#text(", this is just")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Res}(m,p)^{\\frac{q-1}{n}j} = 1.")]]

#text("In a similar vein, as the multiplicative group of ")#mi("{{\\mathbb F}_{q^{dj}}}")#text(" is cyclic of order ")#mi("{q^{dj}-1}")#text(", one has ")#mi("{m(\\beta) = y^n}")#text(" for some ")#mi("{n \\in {\\mathbb F}_{q^{dj}}}")#text(" if and only if")

#align(center)[#tao-fit-display[#mitex("m(\\beta)^{\\frac{q^{dj}-1}{n}} = 1,")]]

#text("which on factoring out ")#mi("{\\frac{q-1}{n}}")#text(" (and noting that ")#mi("{\\beta^{q^d} = \\beta}")#text(") becomes")

#align(center)[#tao-fit-display[#mitex("(m(\\beta) m(\\beta^q) \\dots m(\\beta^{q^{d-1}}))^{\\frac{q-1}{n}j} = 1")]]

#text("or using resultants")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Res}(p,m)^{\\frac{q-1}{n}j} = 1.")]]

#text("As ")#mi("{\\mathrm{Res}(p,m) = \\pm \\mathrm{Res}(m,p)}")#text(", we obtain the claim in this case.")

#text("Next, we continue to assume that ")#mi("{n|q-1}")#text(" and ")#mi("{(-1)^{\\frac{q-1}{n}}=1}")#text(", but now allow ")#mi("{m}")#text(" to be the product of distinct irreducibles ")#mi("{m_1,\\dots,m_k}")#text(". The multiplicative group ")#mi("{({\\mathbb F}[X]/m{\\mathbb F}[X])^\\times}")#text(" now splits by the Chinese remainder theorem as the direct product of the cyclic groups ")#mi("{({\\mathbb F}[X]/m_i{\\mathbb F}[X])^\\times}")#text(", ")#mi("{i=1,\\dots,k}")#text(". It is then not difficult to repeat the above arguments, replacing ")#mi("{C}")#text(" by the curve")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y_1,\\dots,y_k): y_i^n = m_i(x) \\text{ for } i=1,\\dots,k\\};")]]

#text("we leave the details to the reader.")

#text("Finally, we now remove the hypotheses that ")#mi("{n|q-1}")#text(" and ")#mi("{(-1)^{\\frac{q-1}{n}}=1}")#text(". As ")#mi("{m}")#text(" is square-free, the Euler totient function ")#mi("{\\phi(m)}")#text(" is the product of quantities of the form ")#mi("{q^d-1}")#text(" and is thus coprime to ")#mi("{q}")#text("; in particular, as ")#mi("{n}")#text(" must divide this Euler totient function, ")#mi("{n}")#text(" is also coprime to ")#mi("{q}")#text(". There must then exist some power ")#mi("{q^k}")#text(" of ")#mi("{q}")#text(" such that ")#mi("{n|q^k-1}")#text("; if ")#mi("{q}")#text(" is odd, one can also ensure that ")#mi("{2n|q^k-1}")#text(", thus in either case we have ")#mi("{(-1)^{\\frac{q^k-1}{n}}=1}")#text(". Thus to reduce to the previous case, we somehow need to change ")#mi("{q}")#text(" to ")#mi("{q^k}")#text(" (note that ")#mi("{m}")#text(" will be squarefree in any field extension, since finite fields are ")#link("https://en.wikipedia.org/wiki/Perfect_field")[#text("perfect")]#text(").")

#text("Let ")#mi("{{\\mathbb F}_{q^k}}")#text(" be a degree ")#mi("{k}")#text(" field extension of ")#mi("{{\\mathbb F}}")#text(", then ")#mi("{{\\mathbb F}_{q^k}(T)}")#text(" is a degree ")#mi("{k}")#text(" extension of ")#mi("{{\\mathbb F}_q(T)}")#text(". Let ")#mi("{\\mathbf{Norm}:{\\mathbb F}_{q^k}(T) \\rightarrow {\\mathbb F}_{q}(T)}")#text(" be the ")#link("https://en.wikipedia.org/wiki/Field_norm")[#text("norm map")]#text(". Let ")#mi("{\\chi_k: {\\mathbb F}_{q^k}[X] \\rightarrow {\\bf C}}")#text(" be the composition ")#mi("{\\chi_k := \\chi \\circ \\mathrm{Norm}}")#text(" of the original Dirichlet character ")#mi("{\\chi}")#text(" with the norm map; this can then be checked to be a Dirichlet character on ")#mi("{{\\mathbb F}_{q^k}[X]}")#text(" with modulus ")#mi("{m}")#text(", of order dividing ")#mi("{n}")#text(". We claim that")

#align(center)[#tao-fit-display[#mitex("\\prod_{\\zeta^k = 1} L(\\zeta s, \\chi) = L( s, \\chi_k )")]]

#text("where ")#mi("{\\zeta}")#text(" ranges over the complex ")#mi("{k^{th}}")#text(" roots of unity, which allows us to establish RH for ")#mi("{L(s,\\chi)}")#text(" from that of ")#mi("{L(s,\\chi_k)}")#text(". Taking logarithms, we see that it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("k \\sum_{a \\in {\\mathbb F}[X]: \\left|a\\right| = q^{kj}} \\log q \\Lambda_q(a) \\chi(a) = \\sum_{b \\in {\\mathbb F}_{q^k}[X]: \\left|b\\right| = q^{kj}} \\log q^k \\Lambda_{q^k}(b) \\chi_k(b)", block: true)]]

#text("or equivalently")

#align(center)[#tao-fit-display[#tao-math("\\sum_{a \\in {\\mathbb F}[X]: \\left|a\\right| = q^{kj}} \\mathrm{deg}(a) \\chi(a) = \\sum_{b \\in {\\mathbb F}_{q^k}[X]: \\left|b\\right| = q^{kj}} \\mathrm{deg}(b) \\chi(\\mathrm{Norm}(b))", block: true)]]

#text("for all ")#mi("{j \\geq 0}")#text(". But each ")#mi("{a}")#text(" that gives a non-zero contribution on the right-hand side is the power of some irreducible ")#mi("{p}")#text(" in ")#mi("{{\\mathbb F}[X]}")#text(", which then splits into (say) ")#mi("{s}")#text(" distinct irreducibles ")#mi("{p_1,\\dots,p_s}")#text(" in ")#mi("{{\\mathbb F}_k[X]}")#text(", with degree ")#mi("{1/s}")#text(" that of ")#mi("{p}")#text(", and all of norm ")#mi("{p^{k/s}}")#text(". This gives ")#mi("{s}")#text(" contributions to the right-hand side, each of which is ")#mi("{\\frac{1}{s}}")#text(" times that of the left-hand side; conversely, every term in the right-hand side arises precisely once in this fashion. The claim follows.")

#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a778b2ba58f0a83758d062a31b82125493a164e454bac4ed73a5f0b4cb8b8e89-caa1cd9f5051dd9589cb04a35a3d8e1d4fec68bd79393a9eb54194c68326ea90.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of BR")]], [#link("https://terrytao.wordpress.com/2019/05/17/a-function-field-analogue-of-riemann-zeta-statistics/#comment-516409")[#strong[#text("BR")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2019")])]

#text("You mention the large q, fixed N limit and there is indeed a result in this case due to Katz (the main theorem in ")#link("http://web.math.princeton.edu/~nmk/dirichlet32.pdf")[#text("http://web.math.princeton.edu/~nmk/dirichlet32.pdf")]#text(". For a re-statement in language closer to analytic number theory, see Theorem 5.2 in this paper of Keating and Rudnick: ")#link("https://arxiv.org/pdf/1204.0708.pdf")[#text("https://arxiv.org/pdf/1204.0708.pdf")]#text("). It would be interesting if there was an elementary way to see this equidistribution result if only for characters modulo some ‘fixed’ small squarefree polynomial e.g. X^3+1. I would guess the consensus is that it requires some machinery even in this very simple setting.")

#text("In your previous post you mentioned that one can sometimes go a little further using estimates for Kloosterman sums. Are function field analogues of these already worked out some place?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f0b9a908987dfdfc75dae02356a635e8ff78f8d3d1ca98913514ae4baf88d46-d00c0befd789903b432aea6071945fa92bf8636b4820e83fbd2e6a03dea15f9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2019/05/17/a-function-field-analogue-of-riemann-zeta-statistics/#comment-516431")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2019")])]

#text("Even for a cubic polynomial the problem is going to be quite tricky. The problem you typically face is given a sum over characters, because there is no way to attack it directly, the only route seems to be to use orthogonality of characters to return it to a sum over polynomials. But a very strong estimate for the resulting sums follows from the Reimann hypothesis from the resulting L-functions. This estimate is hard to prove other than by returning to the world of L-functions and using either non-elementary means or Bombieri-Stepanov, and to prove equidistribution you need to get an even stronger estimate, without resorting to L-functions!")

#text("The super strong form of the Riemann hypothesis due to Deligne (combined with categorical arguments) provides a solution, as in the result of Katz you mention, but this only gets an additional factor of sqrt(q) beyong the Riemann savings, where really (except in the case of cubic poynomials, I guess) much more should be true.")

#text("With regards to Kloosterman sums, I believe the mentioned estimates over the integers involve passing through automorphic problems using tools like the Kusnetsov formula. These tools are not fully developed over function fields, so the best current results on the fourth moment (see e.g. ")#link("https://arxiv.org/abs/1901.06295")[#text("https://arxiv.org/abs/1901.06295")]#text(") give only a little cancellation in the error term.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f0b9a908987dfdfc75dae02356a635e8ff78f8d3d1ca98913514ae4baf88d46-d00c0befd789903b432aea6071945fa92bf8636b4820e83fbd2e6a03dea15f9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2019/05/17/a-function-field-analogue-of-riemann-zeta-statistics/#comment-516434")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2019")])]

#text("1. I suspect elementary methods to rule out the alternative hypothesis and other similar scenarios are not available. One reason this may be tricky is that, if we change the rules slightly (allow ")#mi("Q")#text(" to be reducible and work with even characters) then a version of the alternate hypothesis can actually happen:")

#text("Suppose that ")#mi("q")#text(" is a power of ")#mi("5")#text(" and that ")#mi("Q =X^4")#text(". In this case a result of Katz shows the relevant monodromy group is finite, which has some surprising consequences (all spacings are integer multiples of some fixed spacing, but unlike in the alternative hypothesis, a spacing of zero happens with positive probability). So any method to rule out this kind of behavior over function fields must somehow fail badly in this case.")

#text("2. As BR mentioned, the full equidistribution is known, by work of Katz, in the ")#mi("q\\to\\infty")#text(" limit, via a geometric method, as one of several recent papers on ")#mi("L")#text("-function equidistribution over function fields. Let me mention an interesting fact about them:")

#text("These geometric results always require calculation of a monodromy group. There are two main strategies for the calculation of this group. One of these (not the one Katz used for this particular result, though it can probably be proved by this method) relies on as the key statement exactly the story of low-frequency equidistribution you prove in Proposition 3 and Corollary 4. Groups have a rigidity property that allows one to deduce high-frequency equidistribution from low-frequency equidistribution.")

#text("3. For the large ")#mi("N")#text(" and fixed ")#mi("q")#text(" case of these problems (or even for ")#mi("N")#text(" growing faster than a constant multiple of ")#mi("\\log q")#text(") we do not know much more here than over the integers (and on some things, know less).")

#text("In some of my own research I have guessed that the best approach to the problem is to study the average of the trace of one irreducible representation of ")#mi("U(N)")#text(" at a time. For this reason it might be interesting to look at the average of traces of irreducible representations over the distribution of the alternative hypothesis, and see how they grow or shrink with N and with the highest weight of the irreducible representation. Do you know how these averages behave?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/05/17/a-function-field-analogue-of-riemann-zeta-statistics/#comment-516451")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2019")])]

#text("1. is quite interesting! It means that in addition to the ACUE distribution, there is another “fake CUE” distribution that is consistent with all the low-frequency CUE statistics but now has a positive proportion of repeated zeroes. So there is a limit to what one can do to bound the proportion of repeated zeroes from this sort of information. I assume the explicit form of distribution can be extracted from Katz’s work?")

#text("[EDIT: I wonder if there is any relation between Katz’s examples and the ")#link("http://math.stanford.edu/~conrad/papers/genuszerofinal.pdf")[#text("examples of Conrad-Conrad-Gross")]#text(" regarding the failure of the polynomial Chowla conjecture in function fields for certain specific polynomials in low characteristic?]")

#text("As for your last question, one can compute ")#mi("{\\bf E}_{ACUE} s_\\lambda(U) \\overline{s_\\mu(U)}")#text(" for any two Schur polynomials ")#mi("s_\\lambda,s\\mu")#text(" (where by abuse of notation we use ")#mi("s_\\lambda(U)")#text(" to denote ")#mi("s_\\lambda")#text(" applied to the eigenvalues of ")#mi("U")#text(") without too much difficulty. For CUE this is just ")#mi("1_{\\lambda=\\mu}")#text(" by character orthogonality. Returning to ACUE, this amounts (up to some normalisation factors) to sampling ")#tao-math("s_\\lambda(\\theta) \\overline{s_\\mu(\\theta)} \\left|V(\\theta)\\right|^2", block: false)#text(" on the ")#mi("2N^{th}")#text(" roots of unity, which by Poisson summation amounts to summing the Fourier integrals ")#tao-math("\\int_{({\\bf R}/{\\bf Z})^N} s_\\lambda(\\theta) \\overline{s_\\mu(\\theta)} \\left|V(\\theta)\\right|^2 e(2Nk \\cdot \\theta)\\ d\\theta", block: false)#text(" for ")#mi("k \\in {\\bf Z}^N")#text(". Using the determinantal formula for the Schur polynomials, which cancels off the Vandermonde determinant factors, one ends up with the combinatorial problem of counting solutions to the equation ")#mi("\\pi( \\lambda + \\rho ) - \\pi^{\\prime}( \\mu + \\rho ) \\in 2N {\\bf Z}^N")#text(" for permutations ")#mi("\\pi,\\pi^{\\prime}")#text(" (weighted by ")#mi("\\mathrm{sgn}(\\pi) \\mathrm{sgn}(\\pi^{\\prime})")#text("), where ")#mi("\\rho")#text(" is the long word (and I guess dividing by ")#mi("n!")#text(" to normalise). For comparison with the CUE case, one is counting solutions to ")#mi("\\pi( \\lambda + \\rho ) - \\pi^{\\prime}( \\mu + \\rho ) = 0")#text(" (weighted by ")#mi("\\mathrm{sgn}(\\pi) \\mathrm{sgn}(\\pi^{\\prime})")#text("), which after dividing by ")#mi("n!")#text(" is just ")#mi("1_{\\lambda = \\mu}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f0b9a908987dfdfc75dae02356a635e8ff78f8d3d1ca98913514ae4baf88d46-d00c0befd789903b432aea6071945fa92bf8636b4820e83fbd2e6a03dea15f9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2019/05/17/a-function-field-analogue-of-riemann-zeta-statistics/#comment-516460")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2019")])]

#text("Unfortunately 1 may not be as interesting as you think. The relevant distribution is valid only for ")#mi("N=2")#text(". I convinced myself that the monodromy group is the central extension of ")#mi("A_5")#text(", so one just takes the distribution of the characteristic polynomials of random elements of this central extension inside ")#mi("SU_2")#text(" (and then rotates them around the unit circle, if desired. Such a measure satisfies your Corollary 4 except with ")#mi("2N=4")#text(" replaced by the stronger bound of ")#mi("11")#text(".")

#text("But this is an exceptional phenomenon in low dimension and it is not possible for a measure arising from a group to satisfy Corollary 4 but not full equidistribution if ")#mi("N")#text(" is large (")#mi("N \\geq 4")#text(" should be enough). Since large ")#mi("N")#text(" is what is relevant for the actual Riemann zeta function, groups will not tell us anything new about zeta. Unless there is some trick where the ")#mi("N=2")#text(" case can be used to say something about larger ")#mi("N")#text("?")

#text("With regards to Conrad-Conrad-Gross, I suspect not, as Conrad-Congrad-Gross is a large-degree phenomenon, while this is a phenomenon mainly about low-degree polynomials. The Schur polynomials associated to the complete symmetric functions are related to Mobius sums, but I do not think they are the same sort of Mobius sums.")

#text("Right, so with the expectation of Schur functions over the ACUE, if you take the case natural to me where ")#mi("s_\\mu")#text(" corresponds to a one-dimensional character, you can see that the normalized expectation is always ")#mi("1")#text(" or ")#mi("0")#text(", because fixing ")#mi("\\pi")#text(" there can be at most one choice for ")#mi("\\pi^{\\prime}")#text(", and if there is one choice for a given ")#mi("\\pi")#text(", there is one for every ")#mi("\\pi^{\\prime}")#text(". One strange consequence of this nice formula is that there could maybe be a perfectly reasonable geometric explanation for the distribution of the function field ")#mi("L")#text("-function zeroes being ")#mi("(1- 1/q^c) \\cdot CUE + (1/q^c) \\cdot ACUE")#text(" for some constant ")#mi("c")#text(", uniform in ")#mi("q")#text(" and ")#mi("N")#text(", which would be quite strange behavior.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eae988277ab5af26a6868faf07ff52f678d6d4e55bf19dbae4de9ccc10f05921-36880b05d4b5563fa1a528f8c5decdf570948629ea58099fd0532ef22820807e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shabiatiya")]], [#link("https://terrytao.wordpress.com/2019/05/17/a-function-field-analogue-of-riemann-zeta-statistics/#comment-516464")[#strong[#text("shabiatiya")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2019")])]

#text("Hi Will, in your cv, you mentioned a paper to appear with Xiochun Li. Are you sure this name is correct?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/05/17/a-function-field-analogue-of-riemann-zeta-statistics/#comment-516485")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2019")])]

#text("I think the expectation of Schur functions (divided by the normalising power of the determinant) over ACUE may also be equal to ")#mi("-1")#text(" when the permutations ")#mi("\\pi,\\pi^{\\prime}")#text(" have opposing sign.")

#text("I’ll try to work out exactly what distribution your example of the binary icosahedral group gives. When N=2 and one does the arbitrary phase rotation, the only independent random variable is ")#tao-math("\\left|\\mathrm{tr}(U)\\right|", block: false)#text(", or equivalently the even moments ")#tao-math("{\\bf E} \\left|\\mathrm{tr}(U)\\right|^{2k}", block: false)#text(". For CUE this variable has the quarter-circle distribution ")#mi("\\frac{1}{\\pi} \\sqrt{4-x^2}\\ dx\\downharpoonright_{[0,2]}")#text(" and the moments are the Catalan numbers ")#mi("1,1,2,5,14,42,132,429,1430,\\dots")#text(" for ")#mi("k=0,1,2,\\dots")#text(" (i.e. equal to ")#mi("\\frac{1}{k+1} \\binom{2k}{k}")#text("). For ACUE the variable is uniformly distributed on ")#mi("\\{0,\\sqrt{2}\\}")#text(" and the moments are ")#mi("1,1,2,4,8,16,32,64,128,\\dots")#text(" (i.e. equal to ")#mi("2^{k-1}")#text(" for ")#mi("k \\geq 1")#text("). For Dirichlet characters one is trying to count solutions to the system ")#mi("p_1 \\dots p_k = c q_1 \\dots q_k \\text{ mod } m")#text(" for monic linear polynomials ")#mi("p_1,\\dots,p_k,q_1,\\dots,q_k")#text(" and various scalars ")#mi("c \\in {\\bf F}^\\times")#text(" (with ")#mi("c=0")#text(" given a weight of ")#mi("+1")#text(" and all other ")#mi("c")#text(" a weight of ")#mi("-\\frac{1}{q-2}")#text("); this is trivial for ")#mi("k=0,1,2")#text(" when ")#mi("m")#text(" has degree 3 but I don’t know how easy it is to use the Weil II machinery to count this for higher ")#mi("k")#text(".")

#text("UPDATE: Okay, for the binary icosahedral group (viewed as a finite subgroup of the unit quaternion group) the variable ")#tao-math("\\left|\\mathrm{tr}(U)\\right|", block: false)#text(" takes values in ")#mi("\\{0, \\phi^{-1}, 1, \\phi, 2 \\}")#text(" with probabilities ")#mi("1/4, 1/5, 1/3, 1/5, 1/60")#text(", so the moments are ")#mi("1, 1, 2, 5, 14, 42, 133, 442, 1534, \\dots")#text(", given by ")#mi("\\frac{1}{5} L_{2k} + \\frac{1}{3} + \\frac{1}{60} 4^k")#text(" for ")#mi("k \\geq 1")#text(", where ")#mi("\\phi")#text(" is the golden ratio and ")#mi("L_n")#text(" are the Lucas numbers. (This moment sequence does not appear to be in the OEIS, though for some reason ")#link("https://oeis.org/A202061")[#text("https://oeis.org/A202061")]#text(" is a near miss; I’ve just submitted it to the OEIS. UPDATE: Now at ")#link("https://oeis.org/A308329")[#text("https://oeis.org/A308329")]#text(" ) It is remarkable how closely the moments of this discrete distribution match the Catalan number moments of the semicircular distribution – as you said, one has to go to degree 12 moments before one can distinguish this distribution from CUE. (There is also presumably some representation theoretic reason as to why these moments are all integers, although it eludes me at present. EDIT: Duh. It’s the dimension of the invariant component of the tensor product of the k^th tensor power of the standard representation of the binary icosahedral group with its conjugate.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/17/a-function-field-analogue-of-riemann-zeta-statistics/#comment-516486")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2019")])]

#text("It would be interesting to find the generating function of these moments (which may help explaining why they are all integers.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e56585db621b41a08296d5c75274bec46a17836a6830fb83773a5f2164759dd7-e8e57b7792a08c4612542db934f36f2ef1215b4825ead7345e8179acf0255d7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vincent")]], [#link("https://terrytao.wordpress.com/2019/05/17/a-function-field-analogue-of-riemann-zeta-statistics/#comment-516514")[#strong[#text("Vincent")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2019")])]

#text("Sorry, minor notational issue: when you say that the multiplicative group is cyclic of order $Q – 1$ do you mean order $|Q| -1 = T -1$?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e56585db621b41a08296d5c75274bec46a17836a6830fb83773a5f2164759dd7-e8e57b7792a08c4612542db934f36f2ef1215b4825ead7345e8179acf0255d7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vincent")]], [#link("https://terrytao.wordpress.com/2019/05/17/a-function-field-analogue-of-riemann-zeta-statistics/#comment-516515")[#strong[#text("Vincent")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2019")])]

#text("Sorry to keep going on about notation, but I don’t understand the second sum in the definition of the $L$-function. To me it looks like the $(n)$ should be below the bar and then above the bar there should be some extra brackets or bars indicating that you are counting the number of elements of a set. But then the expression as written comes back a number of times in the text so maybe it is written as intended? But then I there is probably some notational convention at work that I don’t know. Could you clarify? Thanks in advance!")

#emph[#text("[Oops, this was a TeX error propagated by cut and paste, now fixed – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c59963b6d2558c5b60f7e6b74c7224730591e1cfd59cf79bfddcf043ee2892a7-50879559a5ff15fbb657e22dbf7a6dd31266d8a9a6912cde5ff631f43387f1af.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quinons")]], [#link("https://terrytao.wordpress.com/2019/05/17/a-function-field-analogue-of-riemann-zeta-statistics/#comment-517157")[#strong[#text("Quinons")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2019")])]

#text("this is why terence tao doesnt come to my sleepovers anymore: ")#link("https://twitter.com/benorlin/status/1136687249653981184?s=19")[#text("https://twitter.com/benorlin/status/1136687249653981184?s=19")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e13182a44f061c8601df5e94f22e72296f833f4520df4541d553abd1d800ae6d-d61f54a7c7316c5d6beeb53fc2349dfd34e87cbd7cb78d48522eb5466abf1291.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michele Nardelli")]], [#link("https://terrytao.wordpress.com/2019/05/17/a-function-field-analogue-of-riemann-zeta-statistics/#comment-519161")[#strong[#text("Michele Nardelli")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2019")])]

#text("Dear Prof. Tao,")#linebreak()#text(" with regard the Riemann zeta-function, in particular the value of zeta(2) = 1.6449, can be obtained interesting mathematical connections with some developements of the Ramanujan’s Mock Theta Functions, in turn connected with some sectors of Particle Physics, Cosmology and some expressions concerning the Black Hole entropies and the hypothetical mass of Dark Matter particles. The link of paper which concerns these mathematical results, also including zeta(2), is:")

#link("http://vixra.org/pdf/1906.0253v1.pdf")[#text("Click to access 1906.0253v1.pdf")]

#text("Thank You and best regards")
]
