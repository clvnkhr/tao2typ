// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/
// Converted to Typst by tao2typ: "2026-10-14T16:39:08.768912+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Yoneda’s lemma as an identification of form and function: the case study of polynomials", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Yoneda’s lemma as an identification of form and function: the case study of polynomials")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 August 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/")[#text("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("As someone who had a relatively light graduate education in algebra, the import of ")#link("https://en.wikipedia.org/wiki/Yoneda_lemma")[#text("Yoneda’s lemma")]#text(" in category theory has always eluded me somewhat; the statement and proof are simple enough, but definitely have the “")#link("https://en.wikipedia.org/wiki/Abstract_nonsense")[#text("abstract nonsense")]#text("” flavor that one often ascribes to this part of mathematics, and I struggled to connect it to the more grounded forms of intuition, such as those based on concrete examples, that I was more comfortable with. There is a ")#link("https://mathoverflow.net/questions/3184/philosophical-meaning-of-the-yoneda-lemma")[#text("popular MathOverflow post")]#text(" devoted to this question, with many answers that were helpful to me, but I still felt vaguely dissatisfied. However, recently when pondering the very concrete concept of a polynomial, I managed to accidentally stumble upon a special case of Yoneda’s lemma in action, which clarified this lemma conceptually for me. In the end it was a very simple observation (and would be extremely pedestrian to anyone who works in an algebraic field of mathematics), but as I found this helpful to a non-algebraist such as myself, and I thought I would share it here in case others similarly find it helpful.")

#text("In algebra we see a distinction between a polynomial ")#emph[#text("form")]#text(" (also known as a ")#emph[#text("formal polynomial")]#text("), and a polynomial ")#emph[#text("function")]#text(", although this distinction is often elided in more concrete applications. A polynomial form in, say, one variable with integer coefficients, is a formal expression ")#mi("{P}")#text(" of the form ")#metadata(none) <tao-148de9c5a7a44d19e56c>#mi("\\displaystyle  P = a_d {\\mathrm n}^d + \\dots + a_1 {\\mathrm n} + a_0 \\ \\ \\ \\ \\ (1)")#text(" ")#text(" where ")#mi("{a_0,\\dots,a_d}")#text(" are coefficients in the integers, and ")#mi("{{\\mathrm n}}")#text(" is an ")#link("https://en.wikipedia.org/wiki/Indeterminate_(variable)")[#text("indeterminate")]#text(": a symbol that is often intended to be interpreted as an integer, real number, complex number, or element of some more general ring ")#mi("{R}")#text(", but is for now a purely formal object. The collection of such polynomial forms is denoted ")#mi("{{\\bf Z}[{\\mathrm n}]}")#text(", and is a commutative ring.")

#text("A polynomial form ")#mi("{P}")#text(" can be interpreted in any ring ")#mi("{R}")#text(" (even non-commutative ones) to create a ")#emph[#text("polynomial function")]#text(" ")#mi("{P_R : R \\rightarrow R}")#text(", defined by the formula ")#metadata(none) <tao-0510eddd781102030eb8>#mi("\\displaystyle  P_R(n) := a_d n^d + \\dots + a_1 n + a_0 \\ \\ \\ \\ \\ (2)")#text(" ")#text(" for any ")#mi("{n \\in R}")#text(". This definition ")#link(<tao-0510eddd781102030eb8>)[#text("(2)")]#text(" looks so similar to the definition ")#link(<tao-148de9c5a7a44d19e56c>)[#text("(1)")]#text(" that we usually abuse notation and conflate ")#mi("{P}")#text(" with ")#mi("{P_R}")#text(". This conflation is supported by the ")#link("https://en.wikipedia.org/wiki/Identity_theorem")[#text("identity theorem")]#text(" for polynomials, that asserts that if two polynomial forms ")#mi("{P, Q}")#text(" agree at an infinite number of (say) complex numbers, thus ")#mi("{P_{\\bf C}(z) = Q_{\\bf C}(z)}")#text(" for infinitely many ")#mi("{z}")#text(", then they agree ")#mi("{P=Q}")#text(" as polynomial forms (i.e., their coefficients match). But this conflation is sometimes dangerous, particularly when working in finite characteristic. For instance:")

#list(
[#text("(i) The linear forms ")#mi("{{\\mathrm n}}")#text(" and ")#mi("{-{\\mathrm n}}")#text(" are distinct as polynomial forms, but agree when interpreted in the ring ")#mi("{{\\bf Z}/2{\\bf Z}}")#text(", since ")#mi("{n = -n}")#text(" for all ")#mi("{n \\in {\\bf Z}/2{\\bf Z}}")#text(".")],
[#text("(ii) Similarly, if ")#mi("{p}")#text(" is a prime, then the degree one form ")#mi("{{\\mathrm n}}")#text(" and the degree ")#mi("{p}")#text(" form ")#mi("{{\\mathrm n}^p}")#text(" are distinct as polynomial forms (and in particular have distinct degrees), but agree when interpreted in the ring ")#mi("{{\\bf Z}/p{\\bf Z}}")#text(", thanks to ")#link("https://en.wikipedia.org/wiki/Fermat%27s_little_theorem")[#text("Fermat’s little theorem")]#text(".")],
[#text("(iii) The polynomial form ")#mi("{{\\mathrm n}^2+1}")#text(" has no roots when interpreted in the reals ")#mi("{{\\bf R}}")#text(", but has roots when interpreted in the complex numbers ")#mi("{{\\bf C}}")#text(". Similarly, the linear form ")#mi("{2{\\mathrm n}-1}")#text(" has no roots when interpreted in the integers ")#mi("{{\\bf Z}}")#text(", but has roots when interpreted in the rationals ")#mi("{{\\bf Q}}")#text(".")]
)

#text("The above examples show that if one only interprets polynomial forms in a specific ring ")#mi("{R}")#text(", then some information about the polynomial could be lost (and some features of the polynomial, such as roots, may be “invisible” to that interpretation). But this turns out not to be the case if one considers interpretations in all rings simultaneously, as we shall now discuss.")

#text("If ")#mi("{R, S}")#text(" are two different rings, then the polynomial functions ")#mi("{P_R: R \\rightarrow R}")#text(" and ")#mi("{P_S: S \\rightarrow S}")#text(" arising from interpreting a polynomial form ")#mi("{P}")#text(" in these two rings are, strictly speaking, different functions. However, they are often closely related to each other. For instance, if ")#mi("{R}")#text(" is a subring of ")#mi("{S}")#text(", then ")#mi("{P_R}")#text(" agrees with the restriction of ")#mi("{P_S}")#text(" to ")#mi("{R}")#text(". More generally, if there is a ring homomorphism ")#mi("{\\phi: R \\rightarrow S}")#text(" from ")#mi("{R}")#text(" to ")#mi("{S}")#text(", then ")#mi("{P_R}")#text(" and ")#mi("{P_S}")#text(" are intertwined by the relation ")#metadata(none) <tao-fc8fbb48a3a16bfdd853>#mi("\\displaystyle  \\phi \\circ P_R = P_S \\circ \\phi, \\ \\ \\ \\ \\ (3)")#text(" ")#text(" which basically asserts that ring homomorphism respect polynomial operations. Note that the previous observation corresponded to the case when ")#mi("{\\phi}")#text(" was an inclusion homomorphism. Another example comes from the complex conjugation automorphism ")#mi("{z \\mapsto \\overline{z}}")#text(" on the complex numbers, in which case ")#link(<tao-fc8fbb48a3a16bfdd853>)[#text("(3)")]#text(" asserts the identity")

#align(center)[#tao-fit-display[#mitex("\\overline{P_{\\bf C}(z)} = P_{\\bf C}(\\overline{z})")]]

#text("for any polynomial function ")#mi("{P_{\\bf C}}")#text(" on the complex numbers, and any complex number ")#mi("{z}")#text(".")

#text("What was surprising to me (as someone who had not internalized the Yoneda lemma) was that the converse statement was true: if one had a function ")#mi("{F_R: R \\rightarrow R}")#text(" associated to every ring ")#mi("{R}")#text(" that obeyed the intertwining relation ")#metadata(none) <tao-dd2547547797ad9e133d>#mi("\\displaystyle  \\phi \\circ F_R = F_S \\circ \\phi \\ \\ \\ \\ \\ (4)")#text(" ")#text(" for every ring homomorphism ")#mi("{\\phi: R \\rightarrow S}")#text(", then there was a unique polynomial form ")#mi("{P \\in {\\bf Z}[\\mathrm{n}]}")#text(" such that ")#mi("{F_R = P_R}")#text(" for all rings ")#mi("{R}")#text(". This seemed surprising to me because the functions ")#mi("{F}")#text(" were ")#emph[#text("a priori")]#text(" arbitrary functions, and as an analyst I would not expect them to have polynomial structure. But the fact that ")#link(<tao-dd2547547797ad9e133d>)[#text("(4)")]#text(" holds for ")#emph[#text("all")]#text(" rings ")#mi("{R,S}")#text(" and ")#emph[#text("all")]#text(" homomorphisms ")#mi("{\\phi}")#text(" is in fact rather powerful. As an analyst, I am tempted to proceed by first working with the ring ")#mi("{{\\bf C}}")#text(" of complex numbers and taking advantage of the aforementioned identity theorem, but this turns out to be tricky because ")#mi("{{\\bf C}}")#text(" does not “talk” to all the other rings ")#mi("{R}")#text(" enough, in the sense that there are not always as many ring homomorphisms from ")#mi("{{\\bf C}}")#text(" to ")#mi("{R}")#text(" as one would like. But there is in fact a more elementary argument that takes advantage of a particularly relevant (and “talkative”) ring to the theory of polynomials, namely the ring ")#mi("{{\\bf Z}[\\mathrm{n}]}")#text(" of polynomials themselves. Given any other ring ")#mi("{R}")#text(", and any element ")#mi("{n}")#text(" of that ring, there is a unique ring homomorphism ")#mi("{\\phi_{R,n}: {\\bf Z}[\\mathrm{n}] \\rightarrow R}")#text(" from ")#mi("{{\\bf Z}[\\mathrm{n}]}")#text(" to ")#mi("{R}")#text(" that maps ")#mi("{\\mathrm{n}}")#text(" to ")#mi("{n}")#text(", namely the evaluation map")

#align(center)[#tao-fit-display[#mitex("\\phi_{R,n} \\colon a_d {\\mathrm n}^d + \\dots + a_1 {\\mathrm n} + a_0 \\mapsto a_d n^d + \\dots + a_1 n + a_0")]]

#text("that sends a polynomial form to its evaluation at ")#mi("{n}")#text(". Applying ")#link(<tao-dd2547547797ad9e133d>)[#text("(4)")]#text(" to this ring homomorphism, and specializing to the element ")#mi("{\\mathrm{n}}")#text(" of ")#mi("{{\\bf Z}[\\mathrm{n}]}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\phi_{R,n}( F_{{\\bf Z}[\\mathrm{n}]}(\\mathrm{n}) ) = F_R( n )")]]

#text("for any ring ")#mi("{R}")#text(" and any ")#mi("{n \\in R}")#text(". If we then define ")#mi("{P \\in {\\bf Z}[\\mathrm{n}]}")#text(" to be the formal polynomial")

#align(center)[#tao-fit-display[#mitex("P := F_{{\\bf Z}[\\mathrm{n}]}(\\mathrm{n}),")]]

#text("then this identity can be rewritten as")

#align(center)[#tao-fit-display[#mitex("F_R = P_R")]]

#text("and so we have indeed shown that the family ")#mi("{F_R}")#text(" arises from a polynomial form ")#mi("{P}")#text(". Conversely, from the identity")

#align(center)[#tao-fit-display[#mitex("P = P_{{\\bf Z}[\\mathrm{n}]}(\\mathrm{n})")]]

#text("valid for any polynomial form ")#mi("{P}")#text(", we see that two polynomial forms ")#mi("{P,Q}")#text(" can only generate the same polynomial functions ")#mi("{P_R, Q_R}")#text(" for all rings ")#mi("{R}")#text(" if they are identical as polynomial forms. So the polynomial form ")#mi("{P}")#text(" associated to the family ")#mi("{F_R}")#text(" is unique.")

#text("We have thus created an identification of form and function: polynomial forms ")#mi("{P}")#text(" are in one-to-one correspondence with families of functions ")#mi("{F_R}")#text(" obeying the intertwining relation ")#link(<tao-dd2547547797ad9e133d>)[#text("(4)")]#text(". But this identification can be interpreted as a special case of the Yoneda lemma, as follows. There are two ")#link("https://en.wikipedia.org/wiki/Category_(mathematics)")[#text("categories")]#text(" in play here: the category ")#mi("{\\mathbf{Ring}}")#text(" of rings (where the morphisms are ring homomorphisms), and the category ")#mi("{\\mathrm{Set}}")#text(" of sets (where the morphisms are arbitrary functions). There is an obvious ")#link("https://en.wikipedia.org/wiki/Forgetful_functor")[#text("forgetful functor")]#text(" ")#mi("{\\mathrm{Forget}: \\mathbf{Ring} \\rightarrow \\mathbf{Set}}")#text(" between these two categories that takes a ring and removes all of the algebraic structure, leaving behind just the underlying set. A collection ")#mi("{F_R: R \\rightarrow R}")#text(" of functions (i.e., ")#mi("{\\mathbf{Set}}")#text("-morphisms) for each ")#mi("{R}")#text(" in ")#mi("{\\mathbf{Ring}}")#text(" that obeys the intertwining relation ")#link(<tao-dd2547547797ad9e133d>)[#text("(4)")]#text(" is precisely the same thing as a ")#link("https://en.wikipedia.org/wiki/Natural_transformation")[#text("natural transformation")]#text(" from the forgetful functor ")#mi("{\\mathrm{Forget}}")#text(" to itself. So we have identified formal polynomials in ")#mi("{{\\bf Z}[\\mathbf{n}]}")#text(" ")#emph[#text("as a set")]#text(" with natural endomorphisms of the forgetful functor: ")#metadata(none) <tao-ba54fd7d3fd116058f29>#mi("\\displaystyle  \\mathrm{Forget}({\\bf Z}[\\mathbf{n}]) \\equiv \\mathrm{Hom}( \\mathrm{Forget}, \\mathrm{Forget} ). \\ \\ \\ \\ \\ (5)")#text(" ")#text(" Informally: polynomial forms are precisely those operations on rings that are respected by ring homomorphisms.")

#text("What does this have to do with Yoneda’s lemma? Well, remember that every element ")#mi("{n}")#text(" of a ring ")#mi("{R}")#text(" came with an evaluation homomorphism ")#mi("{\\phi_{R,n}: {\\bf Z}[\\mathrm{n}] \\rightarrow R}")#text(". Conversely, every homomorphism from ")#mi("{{\\bf Z}[\\mathrm{n}]}")#text(" to ")#mi("{R}")#text(" will be of the form ")#mi("{\\phi_{R,n}}")#text(" for a unique ")#mi("{n}")#text(" – indeed, ")#mi("{n}")#text(" will just be the image of ")#mi("{\\mathrm{n}}")#text(" under this homomorphism. So the evaluation homomorphism provides a one-to-one correspondence between elements of ")#mi("{R}")#text(", and ring homomorphisms in ")#mi("{\\mathrm{Hom}({\\bf Z}[\\mathrm{n}], R)}")#text(". This correspondence is at the level of sets, so this gives the identification")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Forget} \\equiv \\mathrm{Hom}({\\bf Z}[\\mathrm{n}], -).")]]

#text("Thus our identification can be written as")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Forget}({\\bf Z}[\\mathbf{n}]) \\equiv \\mathrm{Hom}( \\mathrm{Hom}({\\bf Z}[\\mathrm{n}], -), \\mathrm{Forget} )")]]

#text("which is now clearly a special case of the Yoneda lemma")

#align(center)[#tao-fit-display[#mitex("F(A) \\equiv \\mathrm{Hom}( \\mathrm{Hom}(A, -), F )")]]

#text("that applies to any functor ")#mi("{F: {\\mathcal C} \\rightarrow \\mathbf{Set}}")#text(" from a (locally small) category ")#mi("{{\\mathcal C}}")#text(" and any object ")#mi("{A}")#text(" in ")#mi("{{\\mathcal C}}")#text(". And indeed if one inspects the standard proof of this lemma, it is essentially the same argument as the argument we used above to establish the identification ")#link(<tao-ba54fd7d3fd116058f29>)[#text("(5)")]#text(". More generally, it seems to me that the Yoneda lemma is often used to identify “formal” objects with their “functional” interpretations, as long as one simultaneously considers interpretations across an entire category (such as the category of rings), as opposed to just a single interpretation in a single object of the category in which there may be some loss of information due to the peculiarities of that specific object. Grothendieck’s “")#link("https://en.wikipedia.org/wiki/Functor_represented_by_a_scheme")[#text("functor of points")]#text("” interpretation of a scheme, discussed in ")#link("https://terrytao.wordpress.com/2012/09/05/a-trivial-remark-about-schemes/")[#text("this previous blog post")]#text(", is one typical example of this.")

#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/#comment-681181")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2023")])]

#text("There is an exponenet p missing in ")#mi("n^p")#text(" when you mention Fermat’s little theorem")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d33b7136a506a6b0e8deb05d0ba9cfa4997c269e3c0901344c1562ebc50c4808-7a1849d23fba6196afe727988c83396bf2d3b5befcd9e9b6ecbddcfb3a612242.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thebirdreader")]], [#link("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/#comment-681183")[#strong[#text("thebirdreader")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2023")])]

#text("“the degree p form n” -> “the degree p form n^p”\\")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/#comment-681187")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2023")])]

#text("I think of the Yoneda lemma and the functor of points perspective as being the algebraic analogue of an analytic notion which you are very familiar with: distributions.")

#text("Any smooth, compactly-supported function on the real line defines a distribution by the formula ")#mi("f \\longmapsto [\\cdot,f]")#text(" where ")#mi("[\\cdot,f]")#text(" denotes the functional ")#mi("g \\longmapsto \\int_{\\mathbf{R}} gf \\, dx")#text(". The analytic version of the Yoneda lemma amounts to saying that this map from the class of functions to the class of distributions is injective.")

#text("Note that the objects in the two settings are formally very similar. Just as a distribution is something which you integrate functions against to get a well-defined value, a “presheaf” (i.e. a contravariant functor from your category of interest ")#mi("\\mathcal{C}")#text(" to the category of sets) is something which you “integrate against” (meaning hom against) with objects in ")#mi("\\mathcal{C}")#text(" to obtain a well-defined value (which in category theory means a set). The formula is the same: ")#mi("X \\longmapsto [\\cdot,X]")#text(" where ")#mi("[\\cdot,X]")#text(" now means ")#mi("Y \\longmapsto \\mathrm{Hom}_{\\mathcal{C}}(Y,X)")#text(".")

#text("The reason for doing all of this abstract nonsense is the same as in analysis. In PDE, one runs into solutions and constructions which are not honest functions. So we are led to create settings of generalized functions where we can work with such objects and hopefully relate them to actual functions.")

#text("Similarly, in algebraic geometry, one runs into algebraic “spaces” which are not quite varieties (nor schemes, nor algebraic spaces, …), so one is forced to move to larger (and larger) categories of “generalized algebraic spaces” to incorporate the objects we encounter and treat them on an even footing with more classical varieties.")

#text("This process of generalization is necessary even to give rigorous grounding for very classical objects, such as the moduli space ")#mi("\\mathcal{M}_g")#text(" of smooth compact Riemann surfaces of genus ")#mi("g")#text(". Riemann knew of this moduli space and he could informally compute the dimension of ")#mi("\\mathcal{M}_g")#text(", but one must consider the functor of points they define (and a little bit beyond) to finally arrive at an object with the correct properties befitting the name of “moduli space of curves”.")

#text("None of this resemblence is a coincidence, by the way. Schwartz was Grothendieck’s advisor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/#comment-681195")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2023")])]

#text("Is it possible to extend this identification between forms and function from polynomials to a larger class of formal power series (satisfying e.g. certain growth conditions on the coefficients)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/#comment-681202")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2023")])]

#text("Formally, yes, though the correspondence is a bit strange. Consider for instance the ring ")#mi("{\\bf Z}[[\\mathbf{n}]]")#text(" of formal power series with integer coefficients (with no constraint on convergence). The Yoneda lemma says that elements ")#mi("P")#text(" ring can be identified (as a set) with a family of functions ")#mi("P_R")#text(" associated to each ring ")#mi("R")#text(" obeying the natural transformation rule, but this time instead of functions from ")#mi("R")#text(" to ")#mi("R")#text(", they are functions from ")#mi("\\mathrm{Hom}({\\bf Z}[[\\mathbf{n}]], R)")#text(" to ")#mi("R")#text(", arising from evaluating a ring homomorphism from ")#mi("{\\bf Z}[[\\mathbf{n}]]")#text(" to ")#mi("R")#text(" at ")#mi("P")#text(". Unfortunately the space ")#mi("\\mathrm{Hom}({\\bf Z}[[\\mathbf{n}]], R)")#text(" is rather strange and not easy to describe, in contrast to ")#mi("\\mathrm{Hom}({\\bf Z}[\\mathbf{n}], R)")#text(" which is canonically identifiable with ")#mi("R")#text(".")

#text("In general it seems the more analysis is present in one’s objects (e.g., infinite series, topology, smoothness, etc.), the less intuitive and reasonable the Yoneda lemma becomes. But perhaps there are still some surprising uses of that lemma in analytic categories…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4e11a7d49fdff39d5cc275ab1120954e83a6f7e6b508329161fb80bd0d7c821-ff9c7350b78e85c3ea0df313cedd34930a4b72e1a4f69efd0ecb138984506eb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Z. M.")]], [#link("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/#comment-681207")[#strong[#text("Z. M.")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2023")])]

#text("It might be conceptually more correct to look at the topological ring ")#mi("\\mathbf Z\\llbracket t\\rrbracket")#text(" in place of the discrete ring. In other words, we look at endomorphisms of the functor ")#mi("\\mathrm{Ring}\\to\\mathrm{Set}")#text(" of taking the nilradical, often called the de Rham prestack.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4e11a7d49fdff39d5cc275ab1120954e83a6f7e6b508329161fb80bd0d7c821-ff9c7350b78e85c3ea0df313cedd34930a4b72e1a4f69efd0ecb138984506eb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Z. M.")]], [#link("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/#comment-681208")[#strong[#text("Z. M.")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2023")])]

#text("Sorry, it should be called the formal affine line ")#mi("\\mathrm{Spf}(\\mathbf{Z}\\llbracket t \\rrbracket)")#text(", not the de Rham prestack.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01fdcac1723a7fe5e68e5fcb51f297bd49b6202912f38174788e984c0fe5a705-66dadc0504706f0a9668615282af50b4f2fc1983135293859fdbbd3af0fbab6f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Star")]], [#link("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/#comment-681284")[#strong[#text("Star")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2023")])]

#text("Hey, Terry! I got fascinated by your Masterclass course and have watched all of it!")

#text("Can you do yet another toned-down version for the public level like me? I just started at a really good manufacturing company so I really want something that I could apply on a real-life basis. Besides that, I’m barely aware that there are obviously *techniques *than dull-brained force involved in *motorcycle riding; *I barely got my license but am struggling starting from the car. I know I have to learn the KBB stuff eventually on my own, only that I’m so distracted throughout my day.")

#text("I’m not sure if you will actually get to read this reply, but here goes nothing.")

#text("Much Regards,")

#text("Star")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/#comment-681329")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2023")])]

#text("Is there a similar results for algebraic (multi)function (i.e. algebraic correspondence between variables) by considering the (formal) minimal polynomial representing this correspondence?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a6be96d0b33334c6a31c2b3bf2f20ef8ce2f7d97e0c701463b95bf4270e9e25-ce514ac0ea720ed87fa8c8930f4a34ce09507f5e810209a52d960dbea35d2d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of venkyclement")]], [#link("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/#comment-681778")[#strong[#text("venkyclement")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2023")])]

#text("The polynomial P is a function from Z[n] to itself where n goes to P(n). But I do not see where we use the fact every element x of Z[n] needs to map to P(x). Why can’t I represent ")#mi("F_{Z[n]}")#text(" by an equivalence class of functions all of which map n to P(n) but could do something completely different for other elements of Z[n]. Thank you for a great post.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/#comment-681779")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2023")])]

#text("To be more explicit, I realize that building off a function that takes n to P(n) but other elements of Z[n] to something else may lead to functions in other rings that do not satisfy (4), but how do we know that a function that takes x to P(x) for all elements of Z[n] is the only function that does?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/#comment-681784")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2023")])]

#text("From applying the identity ")#mi("\\phi_{R,n}(F_{{\\bf Z}[\\mathrm{n}]}(\\mathrm{n})) = F_R(n)")#text(" with ")#mi("R = {\\bf Z}[\\mathrm{n}]")#text(", ")#mi("n=x")#text(", and ")#mi("P = F_{{\\bf Z}[\\mathrm{n}]}")#text(" we get ")#mi("F_{{\\bf Z}[\\mathrm{n}]}(x) = P(x)")#text(" for any ")#mi("x \\in {\\bf Z}[\\mathrm{n}]")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/#comment-681806")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2023")])]

#text("P ≥ 5 (mod6) professor Tao. ( I must insist )")

#text("This observation is interesting because it suggests that the sequence generates composite numbers composed exclusively of prime factors congruent to 1 or 5 modulo 6, leading to a unique structure reminiscent of polynomial forms.")

#text("In summary, by “reminiscent of polynomial forms,” I meant that the numbers in your sequence possess properties and characteristics that are akin to those of polynomial expressions in algebra. These properties include algebraic structure, prime factorization, unique composition, combinatorial operations, and a ring-like behavior. While not polynomials in the strict mathematical sense, they share some similarities in their mathematical behavior.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/#comment-681873")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2023")])]

#text("An interesting/trivial special case is replacing ")#mi("Z[x]")#text(" by the integer ring ")#mi("Z")#text(". Since there are only two possible ring homomorphisms: either a trivial map 0 or the unique map mapping 1 to the unity of the ring ")#mi("R")#text(". Then Yoneda Lemma can be read as ")#mi("Hom(Discrete, Forget)=Forget(Z)")#text(". Here ")#mi("Discrete")#text(" functor maps a ring ")#mi("R")#text(" to ")#mi("\\{0\\}")#text(" if R doesn’t have a unity or to $\\{0, 1\\}$ otherwise. Philosophically, it says “maps preserve discrete structure can by represented by the simplest discrete structure ")#mi("Z")#text("” which is similar to professor Tao’s example: “maps preserve ring structure can be represented by the simplest algebraic structure ")#mi("Z[x]")#text("” :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a7dbf0fc4f87d9dd7d9265b8d742254449560def99ea67f4a0bdffbedeff30-6357b353d4083e451e5adfb16009055f7689e1058db5dc6c29d9cb3641abf55b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Baez")]], [#link("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/#comment-681919")[#strong[#text("John Baez")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2023")])]

#text("By coincidence tomorrow I’m giving a talk about a categorified version of this whole set of ideas, based on work with Joe Moeller and Todd Trimble, and I’ve put my lecture notes ")#link("https://golem.ph.utexas.edu/category/2023/10/the_free_2rig_on_one_object.html")[#text("here")]#text(". A “2-rig” is a kind of category that has a way to multiply and add objects, with multiplication distributing over addition; the examples I’m interested in include the category of representations of a group or the category of vector bundles on a topological space, with tensor product as multiplication and direct sum as addition.")

#text("Just as polynomials are the free ring on one generator, the category of “Schur functors” is the free 2-rig on one object. And by an argument exactly paralleling the one you gave, Schur functors act naturally on the underlying category of any 2-rig. Examples include “taking the nth tensor power” or “taking the nth exterior power”. To carry out this argument we need a 2-categorical version of the Yoneda lemma. But in my talk, when it comes time to give the proof I’ll switch gears and do the humbler case of polynomials acting on rings, since that’s already interesting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/905d6364a317868f21b78206d17960492ed8fa7bdf16a70cfcc70208af6074db-81b249a619372c3bb4542f081eaf2c7fd00955cf685e27b9ec6f23b3c37066ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sébastien Martineau")]], [#link("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/#comment-682021")[#strong[#text("Sébastien Martineau")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2023")])]

#text("Thanks a lot for sharing this insight, it has been very enlightening!")

#text("Inspired by your blog post and by the comment (*), here is a nice puzzle or exercice to toy around with, in the Yoneda philosophy.")

#text("Consider all unital rings. Call a “choice function” the data, for each unital ring, of an element in it. Say that a choice function x is “coherent” if, for any morphism of unital rings f : A –> B, we have x(B)=f(x(A)).")

#text("1. Find one coherent choice function.")#linebreak()#text(" 2. Find another one.")#linebreak()#text(" 3. Find infintely many choice functions.")#linebreak()#text(" 4. It is very likely that you have now found all possible choice functions: try to prove it!")

#text("Technically speaking, this instance is more basic than the study of polynomials. However, we have to start right away with how to intertwine things, while the storytelling with polynomials can start with more familiar subtleties and bring very smoothly this notion of intertwining.")

#text("I stated the puzzle in the framework of unital rings. To me, its essence rather lies around the notion of marked group. I prefer giving the statement for unital rings because this framework is more widely known, and because I wanted to sweep markings under the carpet.")

#text("—")

#text("(*) : ")#link("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/#comment-681873")[#text("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/#comment-681873")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/905d6364a317868f21b78206d17960492ed8fa7bdf16a70cfcc70208af6074db-81b249a619372c3bb4542f081eaf2c7fd00955cf685e27b9ec6f23b3c37066ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sébastien Martineau")]], [#link("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/#comment-682022")[#strong[#text("Sébastien Martineau")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2023")])]

#text("All questions 1-4 are about coherent choice functions (the word “coherent” is missing in 3 and 4).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/08/25/yonedas-lemma-as-an-identification-of-form-and-function-the-case-study-of-polynomials/#comment-686983")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2024")])]

#text("My layman’s interpretation of the Yoneda Lemma is that it says “what an object ")#emph[#text("is")]#text(" is simply what it ")#emph[#text("does")]#text("“, and by ")#emph[#text("does")]#text(" I mean how it interacts with all other objects. It’s a way of saying that the information content of an object is nothing more or less than this set of interactions. (In a sense the object ")#strong[#text("is")]#text(" the set of interactions.)")

#text("If my understanding is correct, it is essentially a mathematical formulation of Peirce’s ")#link("https://en.wikipedia.org/wiki/Pragmatic_maxim")[#text("pragmatic maxim")]#text(":")

#text("“It appears, then, that the rule for attaining the third grade of clearness of apprehension is as follows: Consider what effects, that might conceivably have practical bearings, we conceive the object of our conception to have. Then, our conception of these effects is the whole of our conception of the object.”")
]
