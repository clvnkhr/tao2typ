// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/
// Converted to Typst by tao2typ: "2026-10-14T15:18:55.826524+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "“New equidistribution estimates of Zhang type, and bounded gaps between primes” – and a retrospective", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("“New equidistribution estimates of Zhang type, and bounded gaps between primes” – and a retrospective")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 February 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/")[#text("https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("There are multiple purposes to this blog post.")

#text("The first purpose is to announce the uploading of the paper “")#link("http://arxiv.org/abs/1402.0811")[#text("New equidistribution estimates of Zhang type, and bounded gaps between primes")]#text("” by D.H.J. Polymath, which is the main output of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8a project on bounded gaps between primes")]#text(", to the arXiv, and to describe the main results of this paper below the fold.")

#text("The second purpose is to roll over the ")#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/")[#text("previous thread")]#text(" on all remaining Polymath8a-related matters (e.g. updates on the submission status of the paper) to a fresh thread. (Discussion of the ongoing Polymath8b project is however being kept on a ")#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/")[#text("separate thread")]#text(", to try to reduce confusion.)")

#text("The final purpose of this post is to coordinate the writing of a retrospective article on the Polymath8 experience, which has been solicited for the ")#link("http://www.ems-ph.org/journals/journal.php?jrn=news")[#text("Newsletter of the European Mathematical Society")]#text(". I suppose that this could encompass both the Polymath8a and Polymath8b projects, even though the second one is still ongoing (but I think we will soon be entering the endgame there). I think there would be two main purposes of such a retrospective article. The first one would be to tell a story about the ")#emph[#text("process")]#text(" of conducting mathematical research, rather than just describe the ")#emph[#text("outcome")]#text(" of such research; this is an important aspect of the subject which is given almost no attention in most mathematical writing, and it would be good to be able to capture some sense of this process while memories are still relatively fresh. The other would be to draw some tentative conclusions with regards to what the strengths and weaknesses of a Polymath project are, and how appropriate such a format would be for other mathematical problems than bounded gaps between primes. In my opinion, the bounded gaps problem had some fairly unique features that made it particularly amenable to a Polymath project, such as (a) a high level of interest amongst the mathematical community in the problem; (b) a very focused objective (“improve ")#mi("{H}")#text("!”), which naturally provided an obvious metric to measure progress; (c) the modular nature of the project, which allowed for people to focus on one aspect of the problem only, and still make contributions to the final goal; and (d) a very reasonable level of ambition (for instance, we did not attempt to prove the twin prime conjecture, which in my opinion would make a terrible Polymath project at our current level of mathematical technology). This is not an exhaustive list of helpful features of the problem; I would welcome other diagnoses of the project by other participants.")

#text("With these two objectives in mind, I propose a format for the retrospective article consisting of a brief introduction to the polymath concept in general and the polymath8 project in particular, followed by a collection of essentially independent contributions by different participants on their own experiences and thoughts. Finally we could have a conclusion section in which we make some general remarks on the polymath project (such as the remarks above). I’ve started a ")#link("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/WqefTsWlmC/Retrospective")[#text("dropbox subfolder")]#text(" for this article (currently in a very skeletal outline form only), and will begin writing a section on my own experiences; other participants are of course encouraged to add their own sections (it is probably best to create separate files for these, and then input them into the main file retrospective.tex, to reduce edit conflicts. If there are participants who wish to contribute but do not currently have access to the Dropbox folder, please email me and I will try to have you added (or else you can supply your thoughts by email, or in the comments to this post; we may have a section for shorter miscellaneous comments from more casual participants, for people who don’t wish to write a lengthy essay on the subject).")

#text("As for deadlines, the EMS Newsletter would like a submitted article by mid-April in order to make the June issue, but in the worst case, it will just be held over until the issue after that.")

#metadata(none) <tao-75ca281f201987dc9130>

#heading(level: 1)[#strong[#text(" — 1. Description of Polymath8a results — ")]]

#text("Let ")#mi("{H_1}")#text(" denote the quantity")

#align(center)[#tao-fit-display[#mitex("H_1 := \\liminf_{n \\rightarrow \\infty} p_{n+1}-p_n,")]]

#text("where ")#mi("{p_n}")#text(" denotes the ")#mi("{n^{th}}")#text(" prime. Thus for instance the notorious ")#link("http://en.wikipedia.org/wiki/Twin_prime")[#text("twin prime conjecture")]#text(" is equivalent to the claim that ")#mi("{H_1=2}")#text(". However, even establishing the finite nature of ")#mi("{H_1}")#text(" unconditionally was an open problem until the celebrated ")#link("http://annals.math.princeton.edu/articles/7954")[#text("work of Zhang")]#text(" last year, who established the bound")

#align(center)[#tao-fit-display[#mitex("H_1 \\leq 70,000,000.")]]

#text("Zhang’s argument, which built upon ")#link("http://www.ams.org/mathscinet-getitem?mr=2552109")[#text("earlier work of Goldston, Pintz, and Yildirim")]#text(", can be summarised as follows. For any natural number ")#mi("{k}")#text(", define an ")#emph[#text("admissible ")#mi("{k}")#text("-tuple")]#text(" to be a tuple ")#mi("{(h_1,\\dots,h_k)}")#text(" of increasing integers, which avoids at least one residue class modulo ")#mi("{p}")#text(" for each prime ")#mi("{p}")#text(". For instance, ")#mi("{(0,2,6)}")#text(" is an admissible ")#mi("{3}")#text("-tuple, but ")#mi("{(0,2,4)}")#text(" is not. The ")#link("http://en.wikipedia.org/wiki/Prime_k-tuple")[#text("Hardy-Littlewood prime tuples conjecture")]#text(" asserts that if ")#mi("{(h_1,\\dots,h_k)}")#text(" is an admissible ")#mi("{k}")#text("-tuple, then there exists infinitely many ")#mi("{n}")#text(" such that ")#mi("{n+h_1,\\dots,n+h_k}")#text(" are simultaneously prime. This conjecture is currently out of reach for any ")#mi("{k \\geq 2}")#text("; for instance, the case when ")#mi("{k=2}")#text(" and the tuple is ")#mi("{(0,2)}")#text(" is the twin prime conjecture. However, Zhang was able to prove a weaker claim, which we call ")#mi("{DHL[k,2]}")#text(", for sufficiently large ")#mi("{k}")#text(". Specifically, (following the notation ")#link("http://arxiv.org/abs/1305.6289")[#text("of Pintz")]#text(") let ")#mi("{DHL[k,2]}")#text(" denote the assertion that given any admissible ")#mi("{k}")#text("-tuple ")#mi("{(h_1,\\dots,h_k)}")#text(", one has infinitely many ")#mi("{n}")#text(" such that ")#emph[#text("at least two")]#text(" of the ")#mi("{n+h_1,\\dots,n+h_k}")#text(" are prime. It is easy to see that if ")#mi("{DHL[k,2]}")#text(" holds and ")#mi("{(h_1,\\dots,h_k)}")#text(" is an admissible ")#mi("{k}")#text("-tuple, then ")#mi("{H_1 \\leq h_k-h_1}")#text(". So to bound ")#mi("{H_1}")#text(", it suffices to show that ")#mi("{DHL[k,2]}")#text(" holds for some ")#mi("{k}")#text(", and then find as narrow an admissible ")#mi("{k}")#text("-tuple as possible.")

#text("Zhang was able to obtain ")#mi("{DHL[k,2]}")#text(" for ")#mi("{k=3,500,000}")#text(", and then took the first ")#mi("{k}")#text(" primes larger than ")#mi("{k}")#text(" to be the admissible ")#mi("{k}")#text("-tuple, observing that this tuple had diameter at most ")#mi("{70,000,000}")#text(". (Actually, it has diameter ")#mi("{59,874,594}")#text(", as observed ")#link("http://arxiv.org/abs/1305.6369")[#text("by Trudgian")]#text(".) The earliest phase of the Polymath8a project consisted of using increasingly sophisticated methods to search for narrow admissible tuples of a given cardinality; in the case of this particular ")#mi("{k}")#text(", we were able to find an admissible tuple whose diameter was ")#mi("{55,223,504}")#text(". On the other hand, an application of the large sieve inequalities shows that admissible ")#mi("{k}")#text("-tuples asymptotically must have size at least ")#mi("{(\\frac{1}{2}+o(1)) k\\log k}")#text(" (and we conjecture that the narrowest ")#mi("{k}")#text("-tuple in fact has size ")#mi("{(1+o(1)) k \\log k}")#text("), so there is a definite limit to how much one can improve the bound on ")#mi("{H_1}")#text(" purely from finding ever narrower admissible tuples. (As part of the Polymath8a project, a database of narrow tuples was set up ")#link("http://math.mit.edu/~primegaps/")[#text("here")]#text(" (and is still accepting submissions), building upon previous data ")#link("http://www.opertech.com/primes/k-tuples.html")[#text("of Engelsma")]#text(".)")

#text("To make further progress, one has to analyse how the result ")#mi("{DHL[k,2]}")#text(" is proven. Here, Zhang follows the arguments of Goldston, Pintz, and Yildirim, which are based on constructing a sieve function ")#mi("{\\nu: {\\bf Z} \\rightarrow {\\bf R}^+}")#text(", supported on (say) the interval ")#mi("{[x,2x]}")#text(" for a large ")#mi("{x}")#text(", such that the sum ")#metadata(none) <tao-c83609695e1a999d6280>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_n \\nu(n)")]]

#text("has good upper bounds, and the sums ")#metadata(none) <tao-8decffe5f1980b2635f6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_n \\nu(n) 1_{n+h_i \\text{ prime}}")]]

#text("has good lower bounds for ")#mi("{i=1,\\dots,k}")#text(". Provided that the ratio between the lower and upper bounds is big enough, one can then easily deduce ")#mi("{DHL[k,2]}")#text(" (essentially from the pigeonhole principle).")

#text("One then needs to find a good choice of ")#mi("{\\nu}")#text(", which on the one hand is simple enough that the sums ")#link(<tao-c83609695e1a999d6280>)[#text("(1)")]#text(", ")#link(<tao-8decffe5f1980b2635f6>)[#text("(2)")]#text(" can be bounded rigorously, but on the other hand are sophisticated enough that one gets a good ratio between ")#link(<tao-8decffe5f1980b2635f6>)[#text("(2)")]#text(" and ")#link(<tao-c83609695e1a999d6280>)[#text("(1)")]#text(". Goldston, Pintz, and Yildirim eventually settled on a choice essentially of the form")

#align(center)[#tao-fit-display[#mitex("\\nu(n) = 1_{[x,2x]} (\\sum_{d|n: d \\leq R} \\mu(d) \\log^{k+l}(\\frac{\\log d}{\\log R}))^2")]]

#text("for some auxiliary parameter ")#mi("{l \\geq 0}")#text(" and some ")#mi("{R = x^{\\theta/2}}")#text("; this is a variant of the Selberg sieve. With this choice, they were already able to establish upper bounds of ")#mi("{H_1}")#text(" as strong as ")#mi("{16}")#text(" on the ")#link("http://en.wikipedia.org/wiki/Elliott%E2%80%93Halberstam_conjecture")[#text("Elliott-Halberstam conjecture")]#text(", which asserts that ")#metadata(none) <tao-0c044a36c373b6a8955c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\sum_{q \\leq x^\\theta} \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\sum_{n \\in [x,2x]; n=a\\ (q)} \\Lambda(n) - \\frac{1}{\\phi(q)} \\sum_{n \\in [x,2x]} \\Lambda(n)\\right| \\ll x\\log^{-A} x", block: true)]]

#text("for all ")#mi("{0 < \\theta < 1}")#text(" and ")#mi("{A >0}")#text(" and to obtain the weaker result ")#mi("{\\liminf_{n \\rightarrow \\infty} \\frac{p_{n+1}-p_n}{\\log p_n} = o(1)}")#text(" without this conjecture. Furthermore, any nontrivial progress on the Elliott-Halberstam conjecture (beyond what is provided by the ")#link("http://en.wikipedia.org/wiki/Bombieri-Vinogradov_theorem")[#text("Bombieri-Vinogradov theorem")]#text(", which covers the case ")#mi("{0 < \\theta <1/2}")#text(") would give some finite bound on ")#mi("{H_1}")#text(".")

#text("Even after all the recent progress on bounded gaps, we still do not have any direct progress on the Elliott-Halberstam conjecture ")#link(<tao-0c044a36c373b6a8955c>)[#text("(3)")]#text(" for any ")#mi("{\\theta \\geq 1/2}")#text(". However, Zhang (and independently, ")#link("http://www.ams.org/mathscinet-getitem?mr=2414788")[#text("Motohashi and Pintz")]#text(") observed that one does not need the full strength of ")#link(<tao-0c044a36c373b6a8955c>)[#text("(3)")]#text(" in order to obtain the conclusions of Goldston-Pintz-Yildirim. Firstly, one does not need all residue classes ")#mi("{a \\in ({\\bf Z}/q{\\bf Z})}")#text(" here, but only those classes that are the roots of a certain polynomial. Secondly, one does not need all moduli here, but can restrict attention to ")#emph[#text("smooth")]#text(" (or ")#emph[#text("friable")]#text(" moduli – moduli with no large prime factors – as the error incurred by ignoring all other moduli turns out to be exponentially small in ")#mi("{k}")#text(". With these caveats, Zhang was able to obtain a restricted form of ")#link(<tao-0c044a36c373b6a8955c>)[#text("(3)")]#text(" with ")#mi("{\\theta}")#text(" as large as ")#mi("{\\frac{1}{2} + \\frac{2}{1168}}")#text(", which he then used to obtain ")#mi("{k}")#text(" as small as ")#mi("{3,500,000}")#text(".")

#text("Actually, Zhang’s treatment of the truncation error is not optimal, and by being more careful here (and by relaxing the requirement of smooth moduli to the less stringent requirement of “densely divisible” moduli) we were able to reduce ")#mi("{k}")#text(" down to ")#mi("{341,640}")#text(". Furthermore, by replacing the monomial ")#mi("{\\log^{k+l}(\\frac{\\log d}{\\log R})}")#text(" with the more flexible cutoff ")#mi("{f( \\frac{\\log d}{\\log R})}")#text(" and then optimising in ")#mi("{f}")#text(" (a computation first made in unpublished work of Conrey, and then in the ")#link("http://www.renyi.hu/~revesz/ThreeCorr0grey.pdf")[#text("paper of Farkas, Pintz, and Revesz")]#text(", with the optimal ")#mi("{f}")#text(" turning out to come from a Bessel function), one could reduce ")#mi("{k}")#text(" to be as small as ")#mi("{34,429}")#text(" (leading to a bound of ")#mi("{H_1}")#text(" that ended up to be ")#mi("{386,344}")#text(").")

#text("To go beyond this, we had to unpack Zhang’s proof of (a weakened version of) the Elliott-Halberstam type bound ")#link(<tao-0c044a36c373b6a8955c>)[#text("(3)")]#text(". His approach follows a well known sequence of papers by Bombieri, Fouvry, Friedlander, and Iwaniec on various restricted breakthroughs beyond the Bombieri-Vinogradov barrier, although with the key difference that Zhang did not use automorphic form techniques, which (at our current level of understanding) are almost entirely restricted to the regime where the residue class ")#mi("{a}")#text(" is fixed in ")#mi("{q}")#text(" (as opposed to varying amongst the roots of a polynomial modulo ")#mi("{q}")#text(", which is what is needed for the current application). However, the remaining steps are familiar: first one uses the Heath-Brown identity to decompose (a variant of) the expression in ")#link(<tao-0c044a36c373b6a8955c>)[#text("(3)")]#text(" into some simpler bilinear and trilinear sums, which Zhang called “Type I”, “Type II”, and “Type III” (though one should caution that these are slightly different from the “Type I” and “Type II” sums arising from ")#link("http://en.wikipedia.org/wiki/Vaughan's_identity")[#text("Vaughan-type identities")]#text("). The Type I and Type II sums turn out to be treatable using a careful combination of the Cauchy-Schwarz inequality (as embodied in tools such as the ")#link("http://www.encyclopediaofmath.org/index.php/Dispersion_method")[#text("dispersion method of Linnik")]#text("), the Polya-Vinogradov completion of sums method, and estimates on one-dimensional exponential sums (which are variants of Kloosterman sums) which can ultimately be handled by the Riemann hypothesis for curves over finite fields, first established by Weil (and which can in this particular context also be proven by the elementary method of Stepanov). The Type III sums can be treated by a variant of these methods, except that one-dimensional exponential sum estimates are insufficient; Zhang instead needed to turn to the three-dimensional exponential sum estimates of Birch and Bombieri to get an adequate amount of cancellation, and these estimates ultimately arose from the deep work of Deligne on the Riemann hypothesis for higher dimensional varieties (see this previous blog post for a discussion of ")#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/")[#text("these hypotheses")]#text(").")

#text("In our work, we were able to improve the Cauchy-Schwarz components of these arguments in a number of ways, with the most significant gain coming from applying the “")#mi("{q}")#text("-van der Corput ")#mi("{A}")#text("-process” of ")#link("http://www.ams.org/mathscinet-getitem?mr=1084186")[#text("Graham and Ringrose")]#text(" to the Type I sums; we also have a slightly different way to handle the Type III sums (based on a ")#link("http://arxiv.org/abs/1304.3199")[#text("recent preprint of Fouvry, Kowalski, and Michel")]#text("), based on correlations of hyper-Kloosterman sums (again coming from Deligne’s work), which gives significantly better results for these sums (so much so, in fact, that the Type III sums are no longer the dominant obstruction to further improvement of the numerology). Putting all these computations together, we can stretch Zhang’s improvement to Bombieri-Vinogradov by about an order of magnitude, with ")#mi("{\\theta}")#text(" now allowed to be as large as ")#mi("{\\frac{1}{2} + \\frac{7}{300} = 0.5233\\dots}")#text(" rather than ")#mi("{\\frac{1}{2} + \\frac{2}{1158} = 0.5017\\dots}")#text(". This leads to a value of ")#mi("{k}")#text(" as low as ")#mi("{632}")#text(", which in turn leads to the bound ")#mi("{H_1 \\leq 4680}")#text(". These latter bounds have since been improved by Maynard and by Polymath8b, mostly by significant improvements to the sieve-theoretic part of the argument (and no longer using any distributional result on the primes beyond the Bombieri-Vinogradov theorem), but the distribution result of Polymath8a is still the best distribution result known on the primes, and may well have other applications beyond the bounded gaps problem.")

#text("Interestingly, the ")#mi("{q}")#text("-van der Corput ")#mi("{A}")#text("-process is strong enough, in fact, that we can still get non-trivial bounds of (weakened versions of) the form ")#link(<tao-0c044a36c373b6a8955c>)[#text("(3)")]#text(" even if we don’t attempt to estimate the Type III sums, so in particular we can obtain a Zhang-type distribution theorem even without using Deligne’s theorems, with ")#mi("{\\theta}")#text(" now reaching as large as ")#mi("{\\frac{1}{2}+\\frac{2}{168} = 0.5119\\dots}")#text(".")

#heading(level: 1)[#text("Comments (17)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/#comment-270286")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2014")])]

#text("The right parenthesis in the definition of the GPY ")#mi("\\nu(n)")#text(" is missing.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/#comment-270294")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2014")])]

#text("Annals link ")#link("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")[#text("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")]#text(" is broken.")

#text("“smooth (or friable moduli – moduli with no small prime factors” – should say no large prime factors.")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/#comment-270299")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2014")])]

#text("I’ll start adding a file with my perspective soon. By the way, in “well-known sequence of papers by Bombieri, Friedlander and Iwaniec”, one should add Fouvry’s name.")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/#comment-270310")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2014")])]

#text("I would suggest that the educational aspect of a public discussion about serious open problems should be mentioned. I am well beyond my sell by date as a serious mathematician, but this has engaged me throughout. The fact that this is near enough to a high-stakes problem to be interesting, but not obviously the key to glory, seems to have created the dynamic within which significant progress has been made. The bifurcation on 8a, which realised that a significant result could be accessible to a wide audience reminds me a bit of the way the Prime Number Theorem is tackled in Hardy and Wright. Even before I went to university I could understand each step – the proof made sense – but how anyone ever discovered it was a mystery, only to be revealed at a deeper level of understanding.")

#text("On the other hand (I think this was from Tim Gowers) it would be sad to spike a viable doctoral thesis on which someone had been working in this way. Collaboration does not necessarily fit the academic models of credit and tenure on which much research activity is currently predicated")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/#comment-270716")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("Mark, is the “spiking” comment based on a belief that collaborative efforts are particularly likely to do this, or that *when* they do this, it’s particularly unfortunate, or .. (something else)? (I’m assuming that “spiking” here means roughly “anticipate the results of”; and yes I’m a layperson:-)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/618cf1f04f8a18eecb1f10f266821e7393feeb97598d32289f48ad8030cb9938-cfc0ce0b3d592e30da34d56ba5b8e4e05f67604304a8cea7731d51a12818b5ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/#comment-270314")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2014")])]

#text("May I just say that I approve of “")#emph[#text("friable")]#text("“, and hope for wider use of this term, with its precision, non-ambiguity, quasi-poetic feeling in English (as with many terms used by geologists, a field with amateur British gentleman-scholar early history), and, of course, its vanguard role in Kowalski’s “")#link("https://blogs.ethz.ch/kowalski/2008/12/08/more-mathematical-terminology-friable/")[#text("French-derived insurgency")]#text("“.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/#comment-270324")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2014")])]

#text("In (3), the outer summation should be over ")#mi("q")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27781d5f9f1cf309d2c329dbf6557cd2df23148c92092930998ea479fa2916d7-cac8d40de9451c0568a412d2bbe715c9180e9857e2bedf8ffaea49ab3538a06c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of HUMBERTO TRIVIÑO")]], [#link("https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/#comment-270344")[#strong[#text("HUMBERTO TRIVIÑO")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2014")])]

#text("en (3) recalcar el comportamiento de la indeterminada x y tomar en cuenta el intervalo o restricciones empleando la sugerencia de EYTAN PALDI")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/#comment-270733")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("Here is one sign of the remarkable level of public interest in Yitang Zhang’s story and bounded gaps between primes: ")#link("http://playground-sf.org/topic/")[#text("http://playground-sf.org/topic/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/#comment-270737")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("It seemed as though there was concern for awhile that in Polymath 8b your increasing efforts might only be getting you asymptotically closer to 2. If so it would be interesting to hear whether you think that the collaborative approach increased not only your capability, but also your gumption.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/#comment-270742")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("Here are some retrospectives on previous Polymath (or Polymath-like) projects:")

#text("Tim Gowers and Michael Nielsen on Polymath1: ")#link("http://www.nature.com/nature/journal/v461/n7266/full/461879a.html")[#text("http://www.nature.com/nature/journal/v461/n7266/full/461879a.html")]

#text("Dick Lipton and Ken Regan on the Polymath-like project to analyse a claimed proof of P != NP: ")#link("http://link.springer.com/chapter/10.1007%2F978-3-642-41422-0_1")[#text("http://link.springer.com/chapter/10.1007%2F978-3-642-41422-0_1")]

#text("Alison Pease and Ursula Martin analysing Mini-Polymath3: ")#link("http://homepages.inf.ed.ac.uk/apease/papers/seventy-four.pdf")[#text("http://homepages.inf.ed.ac.uk/apease/papers/seventy-four.pdf")]

#text("Our format would be a bit different (giving more first-person perspectives), but these prior articles might give some sense of the type of story a retrospective could give.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/#comment-271411")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2014")])]

#text("In the abstract of the retrospective paper, it should be ")#mi("4680")#text(" (without the decimal point)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/#comment-271694")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2014")])]

#text("Terry, the time is 2013 not 2014 as you wrote in retrospective paper")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5b0bfe2d96285a0efd446bd2c0f527099140d7c74579b5abff92ee26e3db3d2-ae646caa2db2637a475b51671338f2ed54efedbc52fe6bf28bd916e984cc0a6a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rhaflimarouane")]], [#link("https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/#comment-312067")[#strong[#text("rhaflimarouane")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2014")])]

#text("hi,")#linebreak()#text(" I developed new prime numbers finding algrithm and i approve the TWIN PRIME NUMBERSCONECTURE , the file is in pdf format and can be downloaded from my blog ")#link("http://rhaflimarouane.wordpress.com/")[#text("http://rhaflimarouane.wordpress.com/")]#linebreak()#text(" thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8: wrapping up | What's new")]], [#link("https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/#comment-375399")[#strong[#text("Polymath8: wrapping up | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2014")])]

#text("[…] the retrospective paper), superseding the previous Polymath8b thread (which was quite full) and the Polymath8a/retrospective thread (which was more or less […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Variants of the Selberg sieve, and bounded intervals containing many primes | What's new")]], [#link("https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/#comment-399051")[#strong[#text("Variants of the Selberg sieve, and bounded intervals containing many primes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2014")])]

#text("[…] which is the second paper to be produced from the Polymath8 project (the first one being discussed here). We’ll refer to this latter paper here as the Polymath8b paper, and the former as the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/#comment-458622")[#strong[#text("Polymath 8 | Euclidean Ramsey Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2015")]

#text("[…] There is an uploaded version of 8a. Also there is going to be a article about the experience of working on 8a and possibly 8b for the newsletter of the European Mathematical society. The deadline is around April. For more check this post. […]")
]
