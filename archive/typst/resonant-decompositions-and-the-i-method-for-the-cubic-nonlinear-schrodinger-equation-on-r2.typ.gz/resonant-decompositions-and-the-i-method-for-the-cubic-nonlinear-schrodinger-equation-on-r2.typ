// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/04/24/resonant-decompositions-and-the-i-method-for-the-cubic-nonlinear-schrodinger-equation-on-r2/
// Converted to Typst by tao2typ: "2026-10-14T06:52:28.464593+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Resonant decompositions and the I-method for the cubic nonlinear Schrodinger equation on R^2", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Resonant decompositions and the I-method for the cubic nonlinear Schrodinger equation on R^2")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 April 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/04/24/resonant-decompositions-and-the-i-method-for-the-cubic-nonlinear-schrodinger-equation-on-r2/")[#text("https://terrytao.wordpress.com/2007/04/24/resonant-decompositions-and-the-i-method-for-the-cubic-nonlinear-schrodinger-equation-on-r2/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("My paper “")#link("http://arxiv.org/abs/0704.2730")[#text("Resonant decompositions and the I-method for the cubic nonlinear Schrodinger equation on ")#mi("{\\Bbb R}^2")]#text("“, with ")#link("http://www.math.utoronto.ca/colliand/")[#text("Jim Colliander")]#text(", ")#link("http://www.math.umn.edu/~keel/")[#text("Mark Keel")]#text(", ")#link("http://www-math.mit.edu/~gigliola/")[#text("Gigliola Staffilani")]#text(", and ")#link("http://www.math.kobe-u.ac.jp/HOME/takaoka/takaoka.html")[#text("Hideo Takaoka")]#text(" (aka the “")#link("http://tosio.math.toronto.edu/wiki/index.php/I-team")[#text("I-team")]#text("“), has just been uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(", and submitted to ")#link("http://www.aimsciences.org/journals/dcdsA/index.htm")[#text("DCDS-A")]#text(". In this (long-delayed!) paper, we improve ")#link("http://www.ams.org/mathscinet-getitem?mr=1906069")[#text("our previous result")]#text(" on the global well-posedness of the cubic non-linear defocusing Schrödinger equation")

#align(center)[#tao-fit-display[#tao-math("i u_t+ \\Delta u = \\left|u\\right|^2 u", block: true)]]

#text("in two spatial dimensions, thus ")#mi("u: {\\Bbb R} \\times {\\Bbb R}^2 \\to {\\Bbb C}")#text(". In that paper we used the “first generation ")#link("http://tosio.math.toronto.edu/wiki/index.php/I-method")[#text("I-method")]#text("” (centred around an almost conservation law for a mollified energy ")#mi("E(Iu)")#text(") to obtain global well-posedness in ")#mi("H^s({\\Bbb R}^2)")#text(" for ")#mi("s > 4/7")#text(" (improving on an earlier result of ")#mi("s > 2/3")#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=1616917")[#text("by Bourgain")]#text("). Here we use the “second generation I-method”, in which the mollified energy ")#mi("E(Iu)")#text(" is adjusted by a correction term to damp out “non-resonant interactions” and thus lead to an improved almost conservation law, and ultimately to an improvement of the well-posedness range to ")#mi("s > 1/2")#text(". (The conjectured region is ")#mi("s \\geq 0")#text("; beyond that, the solution becomes unstable and even local well-posedness is not known.) A similar result (but using Morawetz estimates instead of correction terms) has recently been established ")#link("http://arxiv.org/abs/math/0703606")[#text("by Colliander-Grillakis-Tzirakis")]#text("; this attains the superior range of ")#mi("s > 2/5")#text(", but in the focusing case it does not give global existence all the way up to the ground state due to a slight inefficiency in the Morawetz estimate approach. Our method is in fact rather robust and indicates that the “first-generation” I-method can be pushed further for a large class of dispersive PDE.")

#metadata(none) <tao-93d0dbb6d76226195384>#text("The correction method technique was already utilised by us for ")#link("http://www.ams.org/mathscinet-getitem?mr=1969209")[#text("the Korteweg-de Vries")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1950826")[#text("one-dimensional NLS")]#text(" equations. However, in this two-dimensional, not-completely-integrable setting, the resonant interactions are far more significant and cannot be entirely eliminated via a correction term. However, by using an angular refinement of the standard bilinear Strichartz estimate, in conjunction with an improved multiplier estimate (stemming ultimately from the cosine rule, of all things) to partially counteract the “small divisor” problem in the resonant interaction case, we can obtain the range ")#mi("s > 1/2")#text(". The same result holds in the focusing case, except we must impose the standard condition that the mass of the initial data is strictly less than that of the ground state: ")#tao-math("\\left\\|u(0)\\right\\|_{L^2} < \\left\\|Q\\right\\|_{L^2}", block: false)#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10363e310bcdb54abcb59c65fb564f203d0022984d3e0814b67c8c4d6252d093-4042af8a57ba07ecc00848c889610a827652d19e91beae7a2b42a15620ff9dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nets Katz")]], [#link("https://terrytao.wordpress.com/2007/04/24/resonant-decompositions-and-the-i-method-for-the-cubic-nonlinear-schrodinger-equation-on-r2/#comment-669")[#strong[#text("Nets Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2007")])]

#text("Terry,")

#text("I’m interested in learning more about NLS after hearing an inspiring talk by Ana Vargas at the BMC in Wales. She made a big point about the open problem of global solvability for mass-critical defocusing NLS in dimension greater than or equal 3, for which you, Visan, and Zhang obtained the result in the radial case.")

#text("Would you say that problem is close to resolution? If not, can you say something about what might make it less tractable than other global solvability questions in the critical setting which have fallen in recent years?")

#text("One thing I found interesting about Vargas’ talk was her work (with Bezout?)")#linebreak()#text(" in which she gets superior estimates for data which are not well concentrated")#linebreak()#text(" in frequency space. It made me wonder whether one should expect supercritical defocusing NLS to satisfy partial regularity results analogous")#linebreak()#text(" to Caffarelli Kohn Nirenberg for Navier Stokes.")

#text("Do you consider defocusing supercritical NLS to be a more or less tractable")#linebreak()#text(" object of study than Navier Stokes?")

#text("Nets")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/24/resonant-decompositions-and-the-i-method-for-the-cubic-nonlinear-schrodinger-equation-on-r2/#comment-673")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2007")])]

#text("Dear Nets,")

#text("One can broadly measure the difficulty of a critical equation by just how many symmetries are present; the more symmetries, the more difficult the problem, because all of your technology better be invariant under the relevant symmetries if it is going to be efficient – and for critical problems, one ")#emph[#text("needs")]#text(" efficient technology.")

#text("For a typical NLS, one only has spacetime symmetry to deal with. For energy-critical NLS, one also has scaling, while for mass-critical NLS one has scaling and Galilean invariance. On the other hand, the assumption of spherical symmetry eliminates spatial translation and Galilean invariance. Finally, all things being equal, the large data defocusing problem is easier than the large data focusing problem, where in the focusing problem “large” is understood to mean “nearly as big as the ground state”. For various technical reasons, 3+ dimensions is also easier than 1 or 2 dimensions (Morawetz inequalities are favourable, as is the rapid decay of the fundamental solution). With these heuristics one can understand the historical development of critical global regularity and scattering results: energy-critical defocusing radial NLS (Bourgain, etc.) -> energy-critical defocusing NLS (CKSTT, etc.) -> energy-critical focusing radial NLS (Kenig-Merle) -> 3+ D defocusing mass-critical NLS (TVZ).")

#text("Monica and I are currently looking at the 2D radial problem. The higher-dim non-radial problem looks nasty (though not intractable) due to the triple symmetry: translation, scaling, Galilean. Perhaps the first step is to do the energy-critical focusing non-radial case (I think Kenig-Merle are looking at this), or to redo the energy-critical defocusing non-radial case (our proof is 80+ pages, surely there is a better way!). I get the sense that these problems are only a few years away from resolution, though. (The 2D non-radial mass-critical NLS will be a bit tougher, and the 1D critical problems (quintic NLS and quintic mKdV) will certainly have to wait for the next decade. I’m also looking at the energy-critical wave maps problem, of course, hopefully I’ll have something meaningful to report about that in the nearish future.)")

#text("The Begout-Vargas estimates actually play a crucial role in my work with Visan and Zhang on mass-critical NLS, as they show that the only way in which the nonlinearity is strong enough to counteract the dispersive effect of the linear Schrodinger equation (in the finite mass case of course) is if the solution is simultaneously concentrated in space and frequency. This lets us compactify the evolution of the minimal-mass blowup solutions modulo the symmetry group.")

#text("I know that people are actively looking at the partial regularity problem for supercritical NLS, or (what is very closely related) getting good mass/energy concentration estimates near singular points. The infinite speed of propagation is a significant issue, though. I think even in the radial case (where partial regularity is of course rather easy), the technology for getting the expected mass and energy concentration is still not quite perfect.")

#text("My guess is that the GWP problem for defocusing supercritical NLS is harder than Navier-Stokes, just because dispersive equations tend to be harder than parabolic ones, although in the former case one can at least impose spherical symmetry, which has no interesting analogue for Navier-Stokes. But I think spherically symmetric supercritical NLW is easier than both; note for instance this is the only place where we have penetrated the scaling barrier at all, albeit only by a lousy logarithm.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87083ed6e747731c415cc3afdd28c711879a4394525e2a20789bc74914942ff2-3d0b62b6a379feb32d6b5e47050421890580326e9fc20c991dc4c530150a8001.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Malcom Marshall")]], [#link("https://terrytao.wordpress.com/2007/04/24/resonant-decompositions-and-the-i-method-for-the-cubic-nonlinear-schrodinger-equation-on-r2/#comment-504828")[#strong[#text("Malcom Marshall")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2018")])]

#text("Your articles are always outstanding and this is one of those that have been able to provide intense knowledge. I really appreciate your efforts in putting up everything in one place.")
]
