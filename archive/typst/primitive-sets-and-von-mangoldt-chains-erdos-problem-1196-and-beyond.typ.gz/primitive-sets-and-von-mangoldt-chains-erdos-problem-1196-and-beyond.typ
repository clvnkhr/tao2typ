// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/
// Converted to Typst by tao2typ: "2026-10-14T16:39:23.500644+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Primitive sets and von Mangoldt chains: Erdős Problem #1196 and beyond", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Primitive sets and von Mangoldt chains: Erdős Problem #1196 and beyond")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 May 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/")[#text("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://borisalexeev.com/")[#text("Boris Alexeev")]#text(", Kevin Barreto, Yanyang Li, ")#link("https://mathematics.stanford.edu/people/jared-duker-lichtman")[#text("Jared Duker Lichtman")]#text(", Liam Price, Jibran Iqbal Shah, Quanyu Tang, and I have just uploaded to the arXiv our paper ")#link("https://arxiv.org/abs/2605.00301")[#text("Primitive sets and von Mangoldt chains: Erdős Problem #1196 and beyond")]#text(". This paper (which is a work in progress) represents our efforts to digest and document the recent flurry of developments around the ")#link("https://www.erdosproblems.com/1196")[#text("following problem of Erdős, Sárközy, and Szemerédi")]#text(" on primitive sets:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Erdős problem #1196)")]#text(" ")#metadata(none) <tao-369b906a75d372193bbe>#text(" Suppose that ")#mi("{A \\subset [x,+\\infty)}")#text(" is a primitive set of integers, which means that no element of ")#mi("{A}")#text(" divides another. Then")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in A} \\frac{1}{n \\log n} \\le 1 + o(1)")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(".")
]

#text("One can show that the upper bound of ")#mi("{1 + o(1)}")#text(" is best possible up to the ")#mi("{o(1)}")#text(" error by taking ")#mi("{A}")#text(" to be the set of products of ")#mi("{k}")#text(" primes for some suitable parameter ")#mi("{k}")#text(". This was one of the most well-known open problems in the study of primitive sets, and had attracted some number of partial results (for instance, Lichtman was able to show the upper bound of ")#mi("{e^\\gamma \\frac{\\pi}{4} + o(1) \\approx 1.399}")#text("). It was thus notable that this problem was ")#link("https://chatgpt.com/share/69dd1c83-b164-8385-bf2e-8533e9baba9c")[#text("first solved by an autonomous AI query")]#text(" (by the fifth author) a few weeks ago. This solution introduced a proof technique – based on Markov chains in the divisibility poset – which in retrospect is very natural for controlling primitive sets, but which had not been explicitly used in previous literature, though in retrospect many of the arguments in that literature involved a specific Markov chain which we call the ")#emph[#text("downwards Mertens chain")]#text(". The proof instead revolved around a different Markov chain, which we call the ")#emph[#text("downwards von Mangoldt chain")]#text(", which manages to neatly avoid the “")#mi("{e^\\gamma}")#text("” type losses in the previous Mertens-based arguments, and resolve Conjecture ")#link(<tao-369b906a75d372193bbe>)[#text("1")]#text(". In this paper we develop the Markov chain approach more systematically, and show that it settles several further conjectures concerning primitive sets, and also provides simpler proofs of some previous results in the literature. More precisely, in addition to Conjecture ")#link(<tao-369b906a75d372193bbe>)[#text("1")]#text(", we establish the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Erdős primitive set conjecture, #164)")]#text(" ")#metadata(none) <tao-240403cad27ca6588e22>#text(" For any primitive ")#mi("{A}")#text(" consisting of numbers greater than ")#mi("{1}")#text(",")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in A} \\frac{1}{n \\log n} \\le \\sum_p \\frac{1}{p \\log p}.")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Odd Banks–Martin)")]#text(" ")#metadata(none) <tao-a8149eb0c674d68cd15f>#text(" Let ")#mi("{k\\ge 1}")#text(" and suppose ")#mi("{A}")#text(" is a primitive set consisting of odd numbers with at most ")#mi("{k}")#text(" prime factors. Then")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in A} \\frac{1}{n \\log n} \\leq \\sum_{n \\in \\mathbb N_k(\\mathcal Q)} \\frac{1}{n \\log n},")]]

#text("where ")#mi("{\\mathcal Q}")#text(" denotes the primes appearing as factors of elements of ")#mi("{A}")#text(", and ")#mi("{\\mathbb N_k({\\mathcal Q})}")#text(" is the collection of products of ")#mi("{k}")#text(" primes from ")#mi("{\\mathcal Q}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (")#mi("{2}")#text(" is Erdős-strong)")]#text(" ")#metadata(none) <tao-df4f8e526eeaf453334d>#text(" If ")#mi("{A}")#text(" is a primitive set consisting of even numbers, then")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in A} \\frac{1}{n \\log n} \\le \\frac{1}{2\\log 2}.")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Ahlswede–Khachatrian–Sárközy)")]#text(" ")#metadata(none) <tao-c54346d96d93860ae851>#text(" If ")#mi("{A}")#text(" is a primitive set, then")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in A \\cap [y/x,y]} \\frac{1}{n} \\ll \\frac{\\log x}{\\sqrt{\\log\\log x}}")]]

#text("whenever ")#mi("{3 \\leq x \\leq y}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Erdős–Sárközy–Szemerédi, #1217)")]#text(" ")#metadata(none) <tao-4c2e52a259142ca91fbe>#text(" Let ")#mi("{A \\subset {\\bf N}}")#text(" be such that the upper doubly logarithmic density")

#align(center)[#tao-fit-display[#mitex("\\Delta := \\limsup_{x\\rightarrow\\infty}\\frac{1}{\\log\\log x} \\sum_{n \\in A \\cap [2,x]} \\frac{1}{n \\log n}")]]

#text("is positive. Then there exists a strictly increasing infinite divisibility chain")

#align(center)[#tao-fit-display[#mitex("n_0 | n_1 | n_2 | \\dots")]]

#text("in ")#mi("{A}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\limsup_{x\\rightarrow\\infty}\\frac{1}{\\log\\log x} \\# \\{ i: n_i \\leq x \\} \\geq \\Delta.")]]
]

#text("Theorem ")#link(<tao-240403cad27ca6588e22>)[#text("2")]#text(" and Theorem ")#link(<tao-c54346d96d93860ae851>)[#text("5")]#text(" had been previously established by Lichtman and Ahlswede–Khachatrian–Sárközy respectively, but the Markov chain formalism gives shorter (and more unified) proofs of both. Theorems ")#link(<tao-a8149eb0c674d68cd15f>)[#text("3")]#text(", ")#link(<tao-df4f8e526eeaf453334d>)[#text("4")]#text(", ")#link(<tao-4c2e52a259142ca91fbe>)[#text("6")]#text(" were open conjectures that can now be settled by this method. These results were obtained with varying levels of AI involvement, ranging from completely autonomous AI queries to traditional pen-and-paper calculations, to various hybrid approaches (for instance, with humans suggesting key inequalities that could then be rapidly tested numerically or even proved by various AI tools).")

#metadata(none) <tao-9553f540fcaba6f43ca8>

#heading(level: 1)[#strong[#text(" — 1. Chain/antichain duality and Markov chains — ")]]

#text("I’ll now discuss the basic method of proof and try to motivate the main ideas, which have become much clearer in retrospect. Primitive sets can be viewed as ")#link("https://en.wikipedia.org/wiki/Antichain")[#text("antichains")]#text(" in the divisibility poset ")#mi("{({\\bf N},|)}")#text(", in which the partial ordering is given by the divisibility relation ")#mi("{a|b}")#text(". So, one can pose the following more abstract question: given a general poset ")#mi("{({\\mathcal N}, \\leq)}")#text(" and a weight function ")#mi("{\\nu : {\\mathcal N} \\rightarrow {\\bf R}^+}")#text(", what is the maximal value of ")#mi("{\\sum_{n \\in A} \\nu(n)}")#text(" as ")#mi("{A}")#text(" ranges over all antichains in ")#mi("{{\\mathcal N}}")#text("?")

#text("One can attack this problem using the well known duality between antichains and chains ")#mi("{C}")#text(" (totally ordered subsets of ")#mi("{{\\mathcal N}}")#text("): every antichain and chain can meet in at most one point, thus one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in A} 1_{n \\in C} \\leq 1")]]

#text("for any chain ")#mi("{C}")#text(" and any antichain ")#mi("{A}")#text(". In particular, if one has a measure ")#mi("{\\mu}")#text(" on the space ")#mi("{{\\mathcal C}}")#text(" of all chains (viewed as a compact subspace of the power set of ")#mi("{{\\mathcal N}}")#text(", equipped with the product topology) with the property that")

#metadata(none) <tao-18f48b681eb76361ac60>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\mu \\{ C : n \\in C \\} \\geq \\nu(n)")]]

#text("for all ")#mi("{n \\in {\\mathcal N}}")#text(", then by integrating the previous inequality against ")#mi("{\\mu}")#text(" and using Tonelli’s theorem one would obtain the upper bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in A} \\nu(n) \\leq \\mu({\\mathcal C}).")]]

#text("In fact this duality is completely tight:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7 (Chain/antichain duality)")]#text(" ")#metadata(none) <tao-9414886b1ebf025db067>#text(" Let ")#mi("{({\\mathcal N}, \\leq)}")#text(" be a poset, let ")#mi("{\\nu : {\\mathcal N} \\rightarrow {\\bf R}^+}")#text(" be a weight function, and let ")#mi("{M > 0}")#text(". Then the following are equivalent:")

#list(
[#text("(i) ")#mi("{\\sum_{n \\in A} \\nu(n) \\leq M}")#text(" for all antichains ")#mi("{A}")#text(".")],
[#text("(ii) There exists a measure ")#mi("{\\mu}")#text(" of total mass at most ")#mi("{M}")#text(" on the space of chains, such that ")#link(<tao-18f48b681eb76361ac60>)[#text("(1)")]#text(" holds for all ")#mi("{n \\in {\\mathcal N}}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" We have already indicated how (ii) implies (i). Now we need to show that (i) implies (ii). A standard compactness argument allows us to reduce to the case when ")#mi("{{\\mathcal N}}")#text(" is finite. If (i) holds, then we also have ")#metadata(none) <tao-9390298f3fb0c5b16049>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{n \\in {\\mathcal N}} f(n) \\nu(n) \\leq M")]]

#text(" ")#text(" for all ")#mi("{f : {\\mathcal N} \\rightarrow {\\bf R}}")#text(" in the ")#emph[#text("Stanley chain polytope")]#text(", defined as the convex hull of the indicator functions of antichains. By a ")#link("https://math.mit.edu/~rstan/pubs/pubfiles/66.pdf")[#text("classic result of Stanley")]#text(", this polytope can also be defined as the space of all ")#mi("{f : {\\mathcal N} \\rightarrow {\\bf R}}")#text(" obeying the inequalities")

#metadata(none) <tao-3f524cdc07a11d7c6220>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("0 \\leq f(n) \\text{ for all } n \\in {\\mathcal N}")]]

#text("and")

#metadata(none) <tao-e4ab4e3b1493d5a997b4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{n \\in C} f(n) \\leq 1 \\text{ for all chains } C.")]]

#text("Applying ")#link("https://en.wikipedia.org/wiki/Dual_linear_program")[#text("linear programming duality")]#text(" (or the ")#link("https://en.wikipedia.org/wiki/Farkas%27_lemma")[#text("Farkas lemma")]#text("), we conclude that the inequality ")#link(<tao-9390298f3fb0c5b16049>)[#text("(2)")]#text(" must be a non-negative linear combination of the inequalities ")#link(<tao-3f524cdc07a11d7c6220>)[#text("(3)")]#text(", ")#link(<tao-e4ab4e3b1493d5a997b4>)[#text("(4)")]#text(" (as well as the trivial inequality ")#mi("{0 \\leq 1}")#text("). Equivalently, we can find non-negative weights ")#mi("{\\mu(C)}")#text(" for each chain ")#mi("{C}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\sum_{C \\in {\\mathcal C}} \\mu(C) \\leq M")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sum_{C: n \\in C} \\mu(C) \\geq \\nu(n)")]]

#text("for all ")#mi("{n \\in {\\mathcal N}}")#text(". The claim follows by viewing ")#mi("{\\mu}")#text(" as a measure on the space of chains. ")#mi("\\Box")

#text("Thus, the “universal” problem of obtaining a uniform upper bound on ")#mi("{\\sum_{n \\in A} \\nu(n)}")#text(" for all antichains ")#mi("{A}")#text(" is replaced with the equivalent “existential” dual problem of exhibiting a single measure ")#mi("{\\mu}")#text(" on chains of controlled mass, which hits each element ")#mi("{n}")#text(" of the poset with a mass of at least the original weight ")#mi("{\\nu}")#text(". Thus, such problems are now reduced to that of finding a sufficiently clever construction of such a measure ")#mi("{\\mu}")#text(". If the mass of ")#mi("{\\mu}")#text(" was normalized to equal ")#mi("{1}")#text(", this becomes a probability problem: find a random chain process in the poset ")#mi("{{\\mathcal N}}")#text(" that hits each element ")#mi("{n}")#text(" of the poset with a sufficiently high probability. (Though in our paper we found it more convenient for technical reasons to not normalize the measure, and allow the mass to take values other than ")#mi("{1}")#text(".)")

#text("It turns out (in a manner that was not explicitly appreciated in past literature) that particularly good choices of random chain to use here can come from ")#link("https://en.wikipedia.org/wiki/Markov_chain")[#text("Markov chains")]#text(". (Here, the term “chain” is now being used in two different ways, but fortunately the order-theoretic concept of a chain and the Markov process-theoretic concept of a chain will be quite compatible in this discussion.) There will be two types of Markov chains on the poset ")#mi("{{\\mathcal N}}")#text(" that will be relevant: downwards Markov chains and upwards Markov chains. Here is our notation for a downwards Markov chain:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 8 (Downwards Markov chain)")]#text(" Let ")#mi("{({\\mathcal N}, \\leq)}")#text(" be a poset, and suppose we designate some subset ")#mi("{{\\mathcal A}}")#text(" of ")#mi("{{\\mathcal N}}")#text(" to be the “absorbing states” (in practice these will be the minimal elements of ")#mi("{{\\mathcal N}}")#text(", although they do not have to be). A downwards Markov chain on ")#mi("{{\\mathcal N}}")#text(" with absorbing states ")#mi("{{\\mathcal A}}")#text(" is a collection of ")#emph[#text("transition probabilities")]#text(" ")#mi("{P(n \\searrow m)}")#text(" for ")#mi("{n, m \\in {\\mathcal N}}")#text(" obeying the following axioms:")

#list(
[#text("(i) ")#mi("{P(n \\searrow m) \\geq 0}")#text(", with equality unless ")#mi("{m < n}")#text(" and ")#mi("{n \\notin {\\mathcal A}}")#text(", or if ")#mi("{m = n}")#text(" and ")#mi("{n \\in {\\mathcal A}}")#text(".")],
[#text("(ii) For any ")#mi("{n \\in {\\mathcal N}}")#text(", one has ")#mi("{\\sum_{m \\in {\\mathcal N}} P(n \\searrow m) = 1}")#text(".")]
)

#text("(Thus for instance one has ")#mi("{P(n \\rightarrow n)=1}")#text(" for any absorbing state ")#mi("{n \\in {\\mathcal A}}")#text(".)")
]

#text("Given such a downwards Markov chain and an initial state ")#mi("{n_0 \\in {\\mathcal N}}")#text(", one can generate a random decreasing sequence ")#mi("{n_0 \\geq n_1 \\geq n_2 \\geq \\dots}")#text(" by having each ")#mi("{n_i}")#text(" transition to ")#mi("{n_{i+1}}")#text(" with probability ")#mi("{P(n_i \\searrow n_{i+1})}")#text(" after conditioning on the past history ")#mi("{n_0,\\dots,n_i}")#text(" of the chain. This sequence will (almost surely) be strictly decreasing until it hits an absorbing state, in which case it stays there forever, although if the ")#link("https://en.wikipedia.org/wiki/Ascending_chain_condition")[#text("descending chain condition")]#text(" is not satisfied it is also possible for the sequence to be strictly decreasing indefinitely. We let ")#mi("{{\\mathbb P}_{n_0 \\searrow}}")#text(" denote the law of this decreasing sequence. This construction is already enough to recover the ")#link("https://en.wikipedia.org/wiki/Lubell%E2%80%93Yamamoto%E2%80%93Meshalkin_inequality")[#text("Lubell-Yamomoto-Meshalkin (LYM) inequality")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9 (LYM inequality)")]#text(" If ")#mi("{({\\mathcal N}, \\subset)}")#text(" is the power set of ")#mi("{\\{1,\\dots,n\\}}")#text(" with the inclusion partial ordering, and ")#mi("{A}")#text(" is an antichain in this poset (i.e., a ")#link("https://en.wikipedia.org/wiki/Sperner_family")[#text("Sperner family")]#text("), then")

#align(center)[#tao-fit-display[#tao-math("\\sum_{S \\in A} \\frac{1}{\\binom{n}{\\left|S\\right|}} \\leq 1.", block: true)]]
]

#emph[#text("Proof:")]#text(" We introduce the downwards Markov chain with absorbing state ")#mi("{\\emptyset}")#text(" in which each non-empty subset of ")#mi("{\\{1,\\dots,n\\}}")#text(" of some cardinality ")#mi("{0 < k \\leq n}")#text(" transitions to a ")#mi("{k-1}")#text("-element subset chosen uniformly at random (i.e., with probability ")#mi("{1/k}")#text(" of transitioning to each). If we start the descending sequence from the maximal element ")#mi("{\\{1,\\dots,n\\}}")#text(" of ")#mi("{{\\mathcal N}}")#text(", then one can easily check that each ")#mi("{S \\in {\\mathcal N}}")#text(" is hit with probability ")#tao-math("{1/\\binom{n}{\\left|S\\right|}}", block: false)#text(". Applying Proposition ")#link(<tao-9414886b1ebf025db067>)[#text("7")]#text(" with ")#tao-math("{\\nu(S) = 1/\\binom{n}{\\left|S\\right|}}", block: false)#text(", ")#mi("{M=1}")#text(", and ")#mi("{\\mu = {\\mathbb P}_{\\{1,\\dots,n\\} \\searrow}}")#text(", we obtain the claim. ")#mi("\\Box")

#text("In the above argument we fixed the initial location ")#mi("{n_0}")#text(" of the Markov chain, but more generally one can start with any source mass ")#mi("{b : {\\mathcal N} \\rightarrow {\\bf R}^+}")#text(" and work with the measure ")#mi("{\\mu = \\sum_{n_0 \\in {\\mathcal N}} b(n_0) {\\mathbb P}_{n_0 \\searrow}}")#text(" for the purposes of applying Proposition ")#link(<tao-9414886b1ebf025db067>)[#text("7")]#text(".")

#text("One can also define upwards Markov chains ")#mi("{P(n \\nearrow m)}")#text(" in exact analogy with downwards Markov chains ")#mi("{P(n \\searrow m)}")#text(" (reversing the order in the poset), which now generate random increasing sequences ")#mi("{n_0 \\leq n_1 \\leq n_2 \\leq \\dots}")#text(" rather than decreasing sequences. There is a useful ")#emph[#text("adjoint")]#text(" construction that can convert a downwards Markov chain into an upwards Markov chain: if we have a positive weight ")#mi("{\\nu : {\\mathcal N} \\rightarrow (0,+\\infty)}")#text(" which is ")#emph[#text("invariant")]#text(" under the chain in the sense that")

#align(center)[#tao-fit-display[#mitex("\\nu(n) = \\sum_{m \\in {\\mathcal N} : m > n} \\nu(m) P(m \\searrow n)")]]

#text("for any ")#mi("{n \\in {\\mathcal N}}")#text(", then we can define an ")#emph[#text("adjoint")]#text(" upwards Markov chain ")#mi("{P(n \\nearrow m)}")#text(" (with no absorbing state) by the formula")

#align(center)[#tao-fit-display[#mitex("P(n \\nearrow m) = \\frac{\\nu(m)}{\\nu(n)} P(m \\searrow n)")]]

#text("for any ")#mi("{n < m}")#text(" in ")#mi("{{\\mathcal N}}")#text(". More generally, if ")#mi("{\\nu}")#text(" is merely ")#emph[#text("sub-invariant")]#text(" in the sense that")

#align(center)[#tao-fit-display[#mitex("\\nu(n) \\leq \\sum_{m \\in {\\mathcal N} : m > n} \\nu(m) P(m \\searrow n)")]]

#text("for all ")#mi("{n \\in {\\mathcal N}}")#text(", one can still construct an adjoint upwards chain as before, but now one must also add an additional absorbing maximal state ")#mi("{\\infty}")#text(" to ensure that the transition probabilities still sum to one.")

#text("A downwards or upwards Markov chain, when equipped with an invariant or sub-invariant measure, also induces a ")#link("https://en.wikipedia.org/wiki/Flow_network")[#text("flow network")]#text(" on the poset, in which an edge from ")#mi("{n}")#text(" to ")#mi("{m}")#text(" is assigned a flow capacity of")

#align(center)[#tao-fit-display[#mitex("\\nu(m) P(m \\searrow n) = \\nu(n) P(n \\nearrow m).")]]

#text("One can rewrite the Markov chain arguments in the paper in terms of such flow networks, in which case the arguments often boil down to an application of the discrete divergence theorem, giving very short proofs of many of the above results; see the paper for more discussion. However, we chose to focus more on the Markov chain approach in our presentation, as this formalism is also natural and could potentially be more flexible for further applications.")

#heading(level: 1)[#strong[#text(" — 2. The Mertens and von Mangoldt chains — ")]]

#text("For the purpose of analyzing primitive sets, there are two downward chains on the natural numbers (with absorbing state ")#mi("{1}")#text(")that, in retrospect, are particularly natural to use:")

#list(
[#text("The ")#emph[#text("downwards Mertens chain")]#text(", in which each ")#mi("{n>1}")#text(" transitions deterministically to ")#mi("{n/P(n)}")#text(", where ")#mi("{P(n)}")#text(" is the largest prime factor of ")#mi("{n}")#text("; and")],
[#text("the ")#emph[#text("downwards von Mangoldt chain")]#text(", in which each ")#mi("{n>1}")#text(" transitions to ")#mi("{n/q}")#text(" with probability ")#mi("{\\Lambda(q)/\\log n}")#text(" for each ")#mi("{q}")#text(" dividing ")#mi("{n}")#text(", with ")#mi("{\\Lambda}")#text(" the ")#link("https://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(".")]
)

#text("The von Mangoldt weight ")#mi("{\\Lambda}")#text(" is a natural choice here thanks to the fundamental identity")

#align(center)[#tao-fit-display[#mitex("\\sum_{q|n} \\Lambda(q) = \\log n")]]

#text("which encodes the fundamental theorem of arithmetic. The two chains are similar in many way to each other: the von Mangoldt process ")#emph[#text("favors")]#text(" the division by the largest prime factor, but does not ")#emph[#text("require it")]#text(".")

#text("The Mertens chain generates deterministic downward divisibility chains")

#align(center)[#tao-fit-display[#mitex("1 | p_1 | p_1 p_2 | \\dots | p_1 \\dots p_k")]]

#text("starting from a product of ")#mi("{k}")#text(" primes ")#mi("{p_1 \\leq p_2 \\leq \\dots \\leq p_k}")#text(", and as such this process was implicit in much of the previous literature on primitive sets. However, it does not quite interact well with the ")#mi("{\\frac{1}{n \\log n}}")#text(" weight, which is not invariant or subinvariant with respect to this process. Intuitively, the process of dividing ")#mi("{n}")#text(" by ")#mi("{P(n)}")#text(" tends to increasingly select for numbers ")#mi("{n}")#text(" for which ")#mi("{P(n)}")#text(" is smaller than expected. Instead, the natural invariant measure for this chain is the ")#emph[#text("Mertens weight")]

#align(center)[#tao-fit-display[#mitex("\\nu_{\\mathrm{Mertens}}(n) := \\frac{e^\\gamma}{n} \\prod_{p < P(n)} \\left(1-\\frac{1}{p}\\right) \\approx \\frac{1}{n \\log P(n)};")]]

#text("the verification that this is indeed an invariant weight is a nice exercise in telescoping series. Taking the adjoint of the downwards Mertens chain with respect to this weight and running that chain from ")#mi("{1}")#text(" gives the ")#emph[#text("upwards Mertens divisibility chain")]

#align(center)[#tao-fit-display[#mitex("1 | p_1 | p_1 p_2 | \\dots")]]

#text("in which each ")#mi("{n}")#text(" transitions to ")#mi("{np}")#text(" for some prime ")#mi("{p \\geq P(n)}")#text(" with probability ")#mi("{\\frac{1}{p} \\prod_{P(n) \\leq p^{\\prime} < p} \\left(1-\\frac{1}{p^{\\prime}}\\right)}")#text(". A routine induction shows that each ")#mi("{n}")#text(" is hit by this chain with a probability of ")#mi("{\\prod_{p < P(n)} \\left(1-\\frac{1}{p}\\right)}")#text("; this for instance gives a weak version")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in A} \\frac{1}{n \\log n} \\le e^\\gamma + o(1)")]]

#text("of Theorem ")#link(<tao-369b906a75d372193bbe>)[#text("1")]#text(", and similarly for the other results discussed above.")

#text("The key innovation (which was uncovered by the AI-assisted proofs, though not quite in the notation and framework presented here) is to switch to the von Mangoldt chain, which removes the bias towards numbers whose largest prime factor is small. Indeed, the weight ")#mi("{\\frac{1}{n \\log n}}")#text(" now turns out to be sub-invariant (after removing ")#mi("{n=1}")#text(") under this chain, and there is a modification")

#align(center)[#tao-fit-display[#mitex("\\nu_\\Lambda(n) := \\int_1^\\infty \\frac{\\log n}{\\zeta(s) n^s}\\ ds = \\frac{1 + o(1)}{n \\log n}")]]

#text("of this weight which turns out to be perfectly invariant. (We have an interpretation of this formula in terms of a ")#emph[#text("zeta process")]#text(" that couples together various ")#link("https://en.wikipedia.org/wiki/Zeta_distribution")[#text("zeta distributions")]#text(" into a continuous divisibility chain; see the paper for further details.) Taking the adjoint with respect to this weight (or with the original weight ")#mi("{\\frac{1}{n \\log n}}")#text(") can eliminate the ")#mi("{e^\\gamma}")#text(" loss in the previous argument, and give one of the proofs of Theorem ")#link(<tao-369b906a75d372193bbe>)[#text("1")]#text(" recorded in our paper (there are several other variants of this method that we also present).")

#text("One slight defect of the von Mangoldt chain, as compared to the Mertens chain, is that it can “jump over” primitive sets (such as the set of products of ")#mi("{k}")#text(" primes) due to the fact that it will sometimes multiply or divide by a power of a prime rather than a prime itself. This turns out to be a technical difficulty for many of our applications, resulting in a need to make various small ")#emph[#text("ad hoc")]#text(" modifications to the von Mangoldt chain to eliminate this type of jump.")

#text("In order to establish some crucial sub-invariance properties, it turns out (after some standard manipulations) to be useful to obtain good bounds on the negative log-derivative")

#align(center)[#tao-fit-display[#mitex("- \\frac{\\zeta^{\\prime}}{\\zeta}(s) = \\sum_{n=1}^\\infty \\frac{\\Lambda(n)}{n^s}")]]

#text("of the Riemann zeta function ")#mi("{\\zeta}")#text(" in the region ")#mi("{s > 1}")#text(". Here it turns out that there is a clean (and rather efficient) upper bound")

#align(center)[#tao-fit-display[#mitex("- \\frac{\\zeta^{\\prime}}{\\zeta}(s) \\leq \\frac{\\log 2}{2^{s-1}-1}")]]

#text("which is equivalent to the non-decreasing nature of the Dirichlet eta function")

#align(center)[#tao-fit-display[#mitex("\\eta(s) = (1-2^{1-s}) \\zeta(s)")]]

#text("in this region. There are many proofs of this fact in the literature, but I would like to record a particularly cute proof, that is in the spirit of other arguments in the paper: one can interpret ")#mi("{\\eta(s)}")#text(" probabilistically as")

#align(center)[#tao-fit-display[#mitex("\\eta(s) = {\\mathbb E} \\frac{1}{1+e^{-X_s}}")]]

#text("where ")#mi("{X_s}")#text(" is a ")#link("https://en.wikipedia.org/wiki/Gamma_distribution")[#text("gamma random variable")]#text(" of shape ")#mi("{s}")#text(" and scale ")#mi("{1}")#text(". Because the sum of independent copies of ")#mi("{X_s}")#text(" and ")#mi("{X_t}")#text(" has the distribution of ")#mi("{X_{s+t}}")#text(", one can couple together all the ")#mi("{X_s}")#text(" so that they are increasing in ")#mi("{s}")#text(", at which point the claim follows.")

#heading(level: 1)[#strong[#text(" — 3. Further directions — ")]]

#text("Will Sawin and Ofir Gorodetsky have obtained analogues of several of the above results for function field models or permutation models respectively; we briefly discuss these in the paper, although we do not plan to cover these models in depth. We also note another ")#link("https://www.erdosproblems.com/forum/thread/858")[#text("recent use of this technique")]#text(" to solve a separate Erdős problem (#858) relating to antichains in a variant of the divisibility poset.")

#text("The zeta process that we have discovered hints at an emerging theory of the “developmental anatomy of integers”, which differs from the existing topic of anatomy of integers in that it views a large integer ")#mi("{n}")#text(" (and its prime factor “organs”) not as a static entity, but rather as an evolving ")#emph[#text("process")]#text(" in which primes (or powers of primes, in the case of the von Mangoldt process) are added or removed to the integer over time. With this perspective, primitive sets can be viewed as singular moments in such a developmental process, which are only encountered at most once in the life cycle of a given integer. It seems of interest to study this developmental perspective further.")

#text("The paper is currently a work in progress; we have released an early version due to the public interest in this problem. We plan to explore some further applications, and also to formalize more of the above results in Lean (currently two of the six main theorems are formalized), before submitting the paper for publication. The situation here highlights a distinction I have ")#link("https://mathstodon.xyz/@tao/116450581967483825")[#text("recently made")]#text(" between three components of the problem solving process in mathematics, namely proof generation, proof verification, and proof digestion. In this particular case, the first two steps were extremely rapid due to modern AI tools; however, properly digesting the AI-generated proofs into a coherent exposition that places the arguments in context with both past literature and future directions remains a slower process that requires expert human attention.")

#heading(level: 1)[#text("Comments (24)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692475")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2026")])]

#text("Hi, i was just about to ask if you’d usually do a popular science version of this, as this is way beyond most people. anyway i just realized i could use ai to parse it into something more edible, so i guess it’s all okay then :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692477")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2026")])]

#text("So amazing.")

#text("As an ordinary person and a mother of two little kids, I’ve always found mathematics incredibly charming and fascinating.")

#text("Reading your thoughtful writings on mathematics before bedtime is my most precious quiet escape — a gentle, wonderful intellectual adventure for my tired soul.")

#text("I can’t help feeling that the singularity of the mathematical world is coming, or has already arrived.")

#text("Thank you so much for your constant sharing, Professor Tao.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692479")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2026")])]

#text("Dr Tao:")

#text("…")#emph[#text("the term “chain” is now being used in two different ways, but fortunately the order-theoretic concept of a chain and the Markov process-theoretic concept of a chain will be quite compatible in this discussion.")]#text("..")

#text("After reading this paper, I seem to have mixed up the term “chain” (Though it is compatible). Could you elaborate on how this term differs in each context?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692481")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2026")])]

#text("In order theory, a ")#link("https://en.wikipedia.org/wiki/Total_order#Chains")[#text("chain")]#text(" is a totally ordered set. In the theory of Markov processes, a ")#text("Markov chain")#text(" is a stochastic process in which each element of the process transitions to the next in a memoryless fashion. When one iterates a (discrete) Markov process, one gets a sequence of states, but in general there is no reason to expect any ordering on that states that would make that process a chain in the order-theoretic sense. However, in this paper we restrict ourselves to two special types of Markov chains on posets – upwards Markov chains and downwards Markov chains – in which the sequences produced by the Markov chains are also order-theoretic chains. Because of this, it is relatively safe to conflate the two (otherwise distinct) notions of “chain” for the purpose of this paper, though if one wished to consider Markov chains that were not upward or downward, or order-theoretic chains that were not generated by Markov processes, then it would be advisable to keep these two notions separate.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c178ba988fe8b7652fe2cfa7fb096700dc3d0910064663771996c86eb02c9d3-0b6815b40bdffd5a97b51e7ba037f120758ea9a471a2872687d4c13680f3cfcf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ilya Mironov")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692483")[#strong[#text("Ilya Mironov")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2026")])]

#text("Am I correct in observing that Adam Kalai’s algorithm (")#link("https://www.microsoft.com/en-us/research/wp-content/uploads/2016/11/2003-Generating_Random_Factored_Numbers_Easily-SODA.pdf")[#text("here")]#text(") for generating uniform integers with known factorization is effectively the upward Mertens chain with a stopping rule?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692485")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2026")])]

#text("Nice find! Yes, it does seem that there is a relation. Consider the process of generating some non-decreasing sequence of primes such as ")#mi("2, 2, 3, 5, 5, 7, 13, \\dots")#text(", where each prime ")#mi("p")#text(" appears ")#mi("\\mathrm{Geom}(1/p)")#text(" many times (thus it appears ")#mi("j")#text(" times with probability ")#mi("p^{-j}(1-1/p)")#text("). One can think of this as rolling a ")#mi("p")#text("-sided die repeatedly until one stops getting a ")#mi("1")#text(", and taking one copy of ")#mi("p")#text(" for each ")#mi("1")#text(" rolled this way. Exposing this sequence lexicographically (so, in the above example, one would take the sequence ")#mi("1, 2, 2^2, 2^2 \\times 3")#text(", and so forth) is the upwards Mertens process, with each ")#mi("n")#text(" being hit by this process with a probability of ")#mi("\\frac{1}{n} \\prod_{p \\leq P(n)} (1-1/p)")#text(".")

#text("If one fixes a threshold ")#mi("N")#text(" and takes all the primes in this process up to ")#mi("N")#text(", one gets a restricted zeta distribution in which every ")#mi("N")#text("-smooth number ")#mi("n")#text(" appears with probability proportional to ")#mi("1/n")#text("; in particular every number up to ")#mi("N")#text(" appears in this fashion. Kalai then uses rejection sampling to adjust this to get a uniform distribution up to ")#mi("N")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692488")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2026")])]

#text("Two thoughts:")

#text("1) I wonder how tough it would be to use this method to make a version of 1196 for the Gaussian integers? From a quick look it looks like just replacing ")#mi("a")#text(" everywhere with ")#mi("\\sqrt{N(a)}")#text(" should be sufficient, but I’m not sure.")

#text("2) Since we now have two chains, the Mertens chain and the von Mangoldt chain, can we construct others with number theoretic significance? In particular, is it reasonable to construct other chains that look or act nice and then see what inequalities one can get from them?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692490")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2026")])]

#text("1) Yes, one should be able to extend the constructions easily to any number field or function field with unique factorization; Will Sawin has already worked out all the analogues in the simplest function field case of irreducible polynomials over a finite field. The question of what happens with non-trivial class group is less clear – one could presumably still build some analogues of these processes on ideals rather than individual elements of the ring of integers, but perhaps some additional complications arise. (Also, for many of the results here, we needed quite precise numerical bounds on the Riemann zeta function; getting the analogous bounds for other zeta functions is in principle possible, but the numerical inequalities one needs to verify may end up being false in some settings.)")

#text("2) Certainly! In one of our applications (the AKS theorem, in Section 8) we use a different upwards chain than either the von Mangoldt or Mertens processes, namely a multiplicative simple random walk where we multiply the current number by a random prime drawn from a zeta-type distribution to get the next number in the sequence, though it took some trial and error to land on this particular choice of process (which was hinted at *very* implicitly in the original AKS paper, but took a while to tease out, as they phrased their argument in terms of a double counting argument involving Sperner type cubes instead). To prove Sperner’s lemma or the LYM inequality one can use a simple downwards process where one divides out every number by a prime factor chosen uniformly at random (rather than with von Mangoldt weighting); see Example 2.6. For any given problem one may have to proceed by a trial-and-error process in which one experiments with one type of random chain, identify the places where it is not performing optimally, and tweak the chain as needed to try to address these problems. For instance in several of our applications we had to modify the von Mangoldt chain to patch the issue that it would sometimes “jump over” the primitive sets we wanted to detect because it would multiply or divide by powers of primes rather than a single prime.")

#text("Knowing the anatomy of “typical” elements of the distribution of natural numbers one is trying to emulate can help. The (normalized) prime factorization of a typical large number is known to follow the Poisson-Dirichlet process (by Billingsley’s theorem), which in turn is well-known to be generated by the ")#link("https://en.wikipedia.org/wiki/Dirichlet_process#The_stick-breaking_process")[#text("stick-breaking process")]#text(". In retrospect, this was already a large hint that the von Mangoldt chain (which corresponds to the first breaking of the stick) should be relevant for such problems. But when working with numbers with more unusual anatomy, some other process may be better adapted to understand them.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692497")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2026")])]

#text("It seems Theorem 4 is stronger than Theorem 5. Set A will be missing some prime number if we use the approximation 1/p = (loglogN_q + err_1)/(loglogN_p + err), where p and q are consecutive prime numbers. And of course 1/p < (loglogN_q)/(loglogN_p). I haven’t tried the best limit of \\sum_{n \\in A} \\frac{1}{n \\log n}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692505")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2026")])]

#text("You should say in Conjecture 1 that A is a set of *integers*")

#text(".")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71201f395df7767381e6f128fb702b6b806f8684a24a9f379cba33ba9c365fbe-44615daa6b4ed9c2ef237f863a907f77c1fe89e219bd8133ad8fcd03956ddad3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christopher")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692564")[#strong[#text("Christopher")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("properly digesting the AI-generated proofs into a coherent exposition that places the arguments in context with both past literature and future directions remains a slower process that requires expert human attention")
]

#text("How much do current LLMs help with this? Intuitively it seems like they should be quite good at this, since they are designed to process language. On the other hand, digestion is hard to appraise and current LLMs do better with a clear objective function. Maybe literate programming in Lean could help so that at least factual claims in the exposition could be checked for correctness?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71201f395df7767381e6f128fb702b6b806f8684a24a9f379cba33ba9c365fbe-44615daa6b4ed9c2ef237f863a907f77c1fe89e219bd8133ad8fcd03956ddad3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christopher")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692571")[#strong[#text("Christopher")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2026")])]

#text("In the inequality after (4), μ(n) doesn’t make sense since μ is a measure over chains. I think it should be μ(C) summed over the chains?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692592")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2026")])]

#text("Let n> 3. Is it true that the largest prime p dividing N= 1!+2!+…n! occurs only once in the prime factorization of N?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692595")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2026")])]

#text("Judging from ")#link("https://mathoverflow.net/questions/476702/on-the-p-adic-valuation-of-the-sum-of-the-first-n-factorials")[#text("https://mathoverflow.net/questions/476702/on-the-p-adic-valuation-of-the-sum-of-the-first-n-factorials")]#text(" , this problem remains open; standard probabilistic heuristics suggest that it is overwhelmingly likely to be true, but proving this looks out of reach of current methods. (As a general rule, multiplicative problems involving factorials are somewhat tractable, but additive problems involving factorials are hopelessly difficult.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692613")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2026")])]

#text("If the multiplicative chains 1∣p1∣p1p2∣⋯become additive walks under logarithims, and if the markov chain is able to induce asymptotic drift in log space, then could an inverse counting mechanism induce a floor mechanism similar to that of a beatty sequence ? apologies if this is already a known result")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692814")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2026")])]

#text("Is there a possibility of seeing the original AI reasoning in which this proof occurred? I’m interested in seeing how rigorous the original arguments was, i.e. whether it contained gaps (and which it contained) and how it presented to overall arguments. Thanks in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692827")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2026")])]

#text("The original (summarized) chain of thought ")#link("https://chatgpt.com/share/69dd1c83-b164-8385-bf2e-8533e9baba9c")[#text("can be found here")]#text(", though the full trace is not available. Some discussion of it can be found ")#link("https://www.erdosproblems.com/forum/thread/1196#post-5497")[#text("here")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692819")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2026")])]

#text("I’m interested in how much from the original proof by ChatGPT is actually relevant for the mathematical outcomes described here. As far as I can see it is the main proof technique you described above (the new use of Markov chains) that was taken over, but not all the details? The ChatGPT proof claims to prove a slightly stronger statement but, as far as I can see, that does not appear in the draft you linked. Is this because the stronger statement is not that interesting (mathematically speaking) or just because it has not been fully digested yet? Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692828")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2026")])]

#text("Certainly if the AI-generated proof did not exist, there would not be the impetus for humans to explore these ideas; from our literature searches we were not able to find the key Markov chain idea in previous literature on primitive sets, even though it is rather natural in retrospect (and this field is no stranger to the utilization of other probabilistic tools).")

#text("The original GPT proof did involve an additional parameter ")#mi("\\delta")#text(" but it ends up playing little role; if one optimizes the argument in that parameter one ends up with a bound comparable to the one we have in our paper. Actually the original proof does give a slightly sharper constant than the one in our paper; see Remark 4.1. But most likely neither argument is optimal, and further improvements are possible.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/84695016bafdeb331838d7af7594d1d4f46973b9a891b020abd5ceb85406af1e-aa4dbfdeec683ceed77a7f89b286681ed35d8a3129fa58a03dbde91910175355.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of garylangford")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692862")[#strong[#text("garylangford")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2026")])]

#text("The recent primitive-set work seems to replace a difficult extremal problem with the construction of a suitable chain process. Do you view the chain as the explanation, or as a computational proxy for some deeper invariant structure of the divisibility poset? How do you decide when a proof has identified the underlying object versus merely an effective mechanism?")

#text("The notion of a “developmental anatomy of integers” is particularly intriguing. The paper constructs several effective divisibility chains (Mertens, von Mangoldt, modified variants), but this raises a structural question: is there a principle that selects an optimal chain from the anatomy of the integers themselves, rather than through trial-and-error construction? In other words, can the chain be derived from an invariant organizational property of the divisibility poset rather than chosen as an external tool? It seems this could lead to a classification of admissible divisibility processes and perhaps explain why the von Mangoldt chain is so effective.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692866")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2026")])]

#text("Well, as discussed in Remark 1.8 of the paper, the duality is basically reversible: any bound on primitive sets is equivalent to the existence of a random process obeying a certain hitting bound. However, this process is not necessarily Markovian; the fact that Markov processes seem to be a particularly good choice for the dual process certificate is still slightly mysterious, although Markov processes are a natural type of process to consider in other problems and so it is perhaps not extremely surprising in retrospect that they also show up here.")

#text("As for why the von Mangoldt process (and its variants) seem particularly well suited for this problem – given the need to “hit” primitive sets such as ")#mi("{\\mathbb N}_k")#text(", it is natural to consider processes that usually just divide out one prime at a time, which the von Mangoldt process comes close to doing. Asking for near-invariance of the Erdos weight ")#mi("1/n \\log n")#text(" then boils down to asking for transition probabilities ")#mi("{\\bf P}(np \\searrow n)")#text(" that approximately obey the equation")

#mi("\\displaystyle \\sum_p {\\bf P}(np \\searrow n) \\frac{1}{np \\log (np)} \\approx \\frac{1}{n \\log n}.")

#text("Given the shape of this equation, it is plausible that a good choice of transition probability ")#mi("{\\bf P}(np \\searrow n)")#text(" should depend primarily on the relative sizes of ")#mi("\\log n")#text(" and ")#mi("\\log p")#text(", rather than the specific anatomy of ")#mi("n")#text(". Due to the identity ")#mi("\\sum_q \\Lambda(q) = \\log n")#text(" (which is morally ")#mi("\\sum_{p|n} \\log p = \\log n")#text(" if one ignores prime power effects), the von Mangoldt choice (which basically sets ")#mi("{\\bf P}(np \\searrow n)")#text(" to ")#mi("\\frac{\\log p}{\\log p + \\log n}")#text(" if one ignores the effect of prime powers) is then the natural choice here, and happily turns out to work.")

#text("To put it another way: most other candidates for processes (such as the Mertens process, which requires ")#mi("p")#text(" to be the largest prime factor of ")#mi("np")#text(") are more sensitive to the anatomy of ")#mi("n")#text(", and will typically show some bias in their invariant weights that depends on that anatomy (e.g., smooth numbers might be weighted more highly than rough numbers, or vice versa). Since the target invariant weight ")#mi("\\frac{1}{n \\log n}")#text(" depends only on the magnitude of ")#mi("n")#text(" and not on its anatomy, this then suggests that the most efficient choice of processes are the ones whose transition probabilities depend only on the (log-)magnitude of ")#mi("n")#text(" and ")#mi("p")#text(" rather than the anatomy. This leaves the von Mangoldt family of processes as close to the only available choice in retrospect.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692887")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2026")])]

#text("Unless n and p aren’t far enough apart?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/84695016bafdeb331838d7af7594d1d4f46973b9a891b020abd5ceb85406af1e-aa4dbfdeec683ceed77a7f89b286681ed35d8a3129fa58a03dbde91910175355.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of garylangford")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-692987")[#strong[#text("garylangford")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2026")])]

#text("Your explanation suggests that the von Mangoldt kernel is distinguished because it depends primarily on logarithmic magnitude rather than arithmetic anatomy. Has anyone tried to formalize this as a variational principle?")

#text("For example, among downward divisibility kernels preserving the Erdős weight, is the von Mangoldt kernel the unique minimizer of some notion of anatomy bias?")

#text("Very roughly, one could imagine defining anatomy through statistics such as largest prime factor, smoothness, (\\omega(n)), or (\\Omega(n)), and then asking whether the von Mangoldt kernel is characterized by minimizing sensitivity to those statistics while still preserving the desired invariant weight.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Two more apps: visualizing the zeta process and the motions of the heavens | What's new")]], [#link("https://terrytao.wordpress.com/2026/05/03/primitive-sets-and-von-mangoldt-chains-erdos-problem-1196-and-beyond/#comment-693431")[#strong[#text("Two more apps: visualizing the zeta process and the motions of the heavens | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2026")])]

#text("[…] two further apps. The first app illustrates the “zeta process” that was introduced in my recent paper with Alexeev, Barreto, Li, Lichtman, Price, Shah, and Tang, though it was first discovered by an AI. For each , the zeta distribution is a random natural […]")
]
