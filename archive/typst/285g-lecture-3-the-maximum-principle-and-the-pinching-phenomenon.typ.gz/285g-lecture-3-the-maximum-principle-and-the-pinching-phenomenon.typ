// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/
// Converted to Typst by tao2typ: "2026-10-14T15:16:43.792314+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "285G, Lecture 3: The maximum principle, and the pinching phenomenon", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("285G, Lecture 3: The maximum principle, and the pinching phenomenon")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 April 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/")[#text("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

#text("We now begin the study of (smooth) solutions ")#mi("t \\mapsto (M(t),g(t))")#text(" to the Ricci flow equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{d}{dt} g_{\\alpha \\beta} = - 2 \\text{Ric}_{\\alpha \\beta},")]]

#text("particularly for compact manifolds in three dimensions. Our first basic tool will be the ")#emph[#text("maximum principle")]#text(" for parabolic equations, which we will use to bound (sub-)solutions to nonlinear parabolic PDE by (super-)solutions, and vice versa. Because the various curvatures ")#mi("\\text{Riem}_{\\alpha \\beta \\gamma}^\\delta")#text(", ")#mi("\\text{Ric}_{\\alpha \\beta}")#text(", R of a manifold undergoing Ricci flow do indeed obey nonlinear parabolic PDE (see equations (31) from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text("), we will be able to obtain some important lower bounds on curvature, and in particular establishes that the curvature is either bounded, or else that the positive components of the curvature dominate the negative components. This latter phenomenon, known as the ")#emph[#text("Hamilton-Ivey pinching phenomenon")]#text(", is particularly important when studying singularities of Ricci flow, as it means that the geometry of such singularities is almost completely dominated by regions of non-negative (and often quite high) curvature.")

#metadata(none) <tao-ec56186f2a58249997c7>

#heading(level: 1)[#text("— The maximum principle —")]

#text("In freshman calculus, one learns that if a smooth function ")#mi("u: [a,b] \\to {\\Bbb R}")#text(" has a local minimum at an interior point ")#mi("x_0")#text(", then the first derivative ")#mi("u^{\\prime}(x_0)")#text(" vanishes and the second derivative ")#mi("u^{\\prime\\prime}(x_0)")#text(" is non-negative. This implies a higher-dimensional version: if U is an open domain in ")#mi("{\\Bbb R}^d")#text(" and ")#mi("u: U \\to {\\Bbb R}")#text(" has a local minimum at some ")#mi("x_0 \\in U")#text(", then ")#mi("\\nabla u(x_0) = 0")#text(" and ")#mi("\\Delta u(x_0) \\geq 0")#text(". Geometrically, the Laplacian ")#mi("\\Delta u(x_0)")#text(" measures the extent to which u at ")#mi("x_0")#text(" dips below the average value of u near ")#mi("x_0")#text(", which explains why the Laplacian is non-negative at local minima.")

#text("The same phenomenon occurs for Riemannian manifolds.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" Let ")#mi("(M,g)")#text(" be a d-dimensional Riemannian manifold, and let ")#mi("u: M \\to {\\Bbb R}")#text(" be a ")#mi("C^2")#text(" function that has a local minimum at a point ")#mi("x_0 \\in M")#text(". Then ")#mi("\\nabla_\\alpha u(x_0) = 0")#text(" and ")#mi("\\Delta u(x_0) \\geq 0")#text(".")
]

#strong[#text("Proof. ")]#text(" The vanishing ")#mi("\\nabla_\\alpha u(x_0) = 0")#text(" of the first derivative is clear, so we turn to the second derivative estimate. We let ")#mi("e_1,\\ldots,e_d")#text(" be a (local) orthonormal frame of M. Then (by the Leibniz rule)")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\Delta u = e_a^\\alpha e_a^\\beta \\nabla_\\alpha \\nabla_\\beta u = \\nabla_{e_a} \\nabla_{e_a} u - \\nabla_{\\nabla_{e_a} e_a} u.")]]

#text("Since u has vanishing first derivative at ")#mi("x_0")#text(", we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\Delta u(x_0) =  \\nabla_{e_a} \\nabla_{e_a} u(x_0).")]]

#text("But as u has a local minimum at ")#mi("x_0")#text(", it also has a local minimum on the geodesic through ")#mi("x_0")#text(" with velocity ")#mi("e_a")#text(". From one-dimensional calculus we conclude that ")#mi("\\nabla_{e_a} \\nabla_{e_a} u(x_0)")#text(" is non-negative for each a, and the claim follows. ")#mi("\\Box")

#text("For applications to nonlinear parabolic PDE, we need a time-dependent version of this fact, in which the function u and the metric g also vary with time. It is also convenient to consider work not with one function u, but with a pair u, v, and to consider relative local minima of u with respect to v (i.e. local minima of u-v).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2.")]#text(" (Dichotomy) Let ")#mi("t \\mapsto (M,g(t))")#text(" be a smooth flow of compact Riemannian manifolds on a time interval ")#mi("{}[0,T]")#text(". Let ")#mi("u, v: [0,T] \\times M \\to {\\Bbb R}")#text(" be ")#mi("C^2")#text(" functions such that ")#mi("u(0,x) \\geq v(0,x)")#text(" for all ")#mi("x \\in M")#text(". Let ")#mi("A \\in {\\Bbb R}")#text(". Then exactly one of the following is true:")

#enum(start: 1, 
[#mi("u(t,x) \\geq v(t,x)")#text(" for all ")#mi("(t,x) \\in [0,T] \\times M")#text(".")],
[#text("There exists ")#mi("(t,x) \\in (0,T] \\times M")#text(" such that")]
)

#mi("u(t,x) < v(t,x)")

#mi("\\nabla_\\alpha u(t,x)  = \\nabla_\\alpha v(t,x)")

#mi("\\Delta_{g(t)} u(t,x) \\geq \\Delta_{g(t)} v(t,x)")#text(" (1′)")

#mi("\\frac{d}{dt} u(t,x) \\leq \\frac{d}{dt} v(t,x) - A (v(t,x)-u(t,x))")

#text("where ")#mi("\\Delta_{g(t)}")#text(" is the Laplacian with respect to the metric ")#mi("g(t)")#text(".")
]

#strong[#text("Proof. ")]#text("By replacing u, v with u-v,0 respectively we may assume that v=0. If we then replace u(t,x) by ")#mi("e^{At} u(t,x)")#text(" we may also assume that A=0.")

#text("Clearly 1 and 2 cannot both hold. If 1 fails, then there exists ")#mi("\\varepsilon > 0")#text(" such that ")#mi("u(t,x) \\leq -\\varepsilon")#text(" for some ")#mi("(t,x) \\in [0,T] \\times M")#text(". Let t be the first time for which this occurs, and let ")#mi("x \\in M")#text(" be a point such that ")#mi("u(t,x) = -\\varepsilon")#text(". Then ")#mi("t > 0")#text(". Also x is a local minimum of u(t) and thus ")#mi("\\nabla_\\alpha u(t,x) = 0")#text(" and ")#mi("\\Delta_{g(t)} u(t,x) \\geq 0")#text(" by Lemma 1. Also, since ")#mi("u(t^{\\prime},x) > -\\varepsilon")#text(" for all ")#mi("t^{\\prime} < t")#text(" we have ")#mi("\\frac{d}{dt} u(t,x) \\leq 0")#text(". The claim follows. ")#mi("\\Box")

#text("This gives us our first version of the parabolic maximum principle.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1.")]#text(" (Supersolutions dominate subsolutions) Let the assumptions be as in Lemma 2. Suppose also that we have the supersolution property")

#align(center)[#mi("\\frac{d}{dt} u(t,x) \\geq \\Delta_{g(t)} u(t,x) + \\nabla_{X(t)} u(t,x) + F(t, u(t,x))")#text(" (2′)")]

#text("and the subsolution property")

#align(center)[#mi("\\frac{d}{dt} v(t,x) \\leq \\Delta_{g(t)} v(t,x) + \\nabla_{X(t)} v(t,x) + F(t, v(t,x))")#text(" (3′)")]

#text("for all ")#mi("(t,x) \\in [0,T] \\times M")#text(" where for each time t, ")#mi("X(t)")#text(" is a vector field, and ")#mi("F(t): {\\Bbb R} \\to {\\Bbb R}")#text(" is a Lipschitz function of constant less than A. Then ")#mi("u(t,x) \\geq v(t,x)")#text(" for all ")#mi("0 \\leq t \\leq T")#text(".")
]

#strong[#text("Proof. ")]#text("If we subtract (2′) from (3′) and use the Lipschitz nature of F we obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\frac{d}{dt} (u-v)(t,x) \\geq \\Delta_{g(t)} (u-v)(t,x) + \\nabla_{X(t)} (u-v)(t,x) - A^{\\prime} \\left|u(t,x)-v(t,x)\\right|", block: true)]]

#text("for some ")#mi("A^{\\prime} < A")#text(". But this is inconsistent with the set of equations (1′). The claim then follows immediately from Lemma 2. ")#mi("\\Box")

#text("In our applications, the subsolution ")#mi("v(t,x) = v(t)")#text(" will in fact be independent of x, and so is really an ODE subsolution rather than a PDE subsolution:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\frac{d}{dt} v(t) \\leq F(t,v(t))")]]

#text("Thus the parabolic maximum principle allows us to lower bound PDE supersolutions by ODE subsolutions, as long as we have a bound at time zero.")

#text("The above maximum principle is already very useful for scalar solutions (or supersolutions) ")#mi("u: [0,T] \\times M \\to {\\Bbb R}")#text(" to scalar nonlinear parabolic PDE, but we will in fact need a more general version of this principle for vector-valued solutions ")#mi("u: [0,T] \\mapsto \\Gamma(  V )")#text(" to nonlinear parabolic PDE, where V is a vector bundle over M, equipped with some connection ")#mi("\\nabla")#text(". (In practice, V will be derived from the tangent bundle, and ")#mi("\\nabla")#text(" will be derived from the Levi-Civita connection.)")

#text("We will need some more notation. Let us say that a subset K of a tensor bundle V is ")#emph[#text("fibrewise convex")]#text(" if the fiber ")#mi("K_x := K \\cap V_x")#text(" over each point ")#mi("x \\in M")#text(" is a convex subset of the vector space ")#mi("V_x")#text(". We say that a subset K of a vector bundle V is ")#emph[#text("parallel")]#text(" to the connection ")#mi("\\nabla")#text(" if for any vector field ")#mi("X")#text(" on M, the induced vector field ")#mi("\\nabla_X")#text(" preserves K (i.e. K is preserved by parallel transport).")

#text("To avoid some technical issues we shall refer vaguely to terms such as “tangent vector”, “inward-pointing vector”, and “outward-pointing vector” to a convex body at a boundary point. These terms can be made more precise, but an intuitive understanding of these concepts will have to suffice for now. [I may return to clean up these issues later, when I have a bit more time.]")

#text("We have a tensor variant of Lemma 1:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3.")]#text(" Let ")#mi("(M,g)")#text(" be a d-dimensional Riemannian manifold, let V be a vector bundle over M with a connection ")#mi("\\nabla")#text(", and let K be a closed, fibrewise convex subset of V which is parallel with respect to the connection. Let ")#mi("u \\in \\Gamma(V)")#text(" be a section such that ")#mi("u(x) \\in \\partial K_x")#text(" at some point ")#mi("x \\in M")#text(", and ")#mi("u(y) \\in K_y")#text(" for all y in a neighbourhood of x (thus u in some sense “attains a local maximum” at x with respect to K). Then every directional derivative ")#mi("\\nabla_X u(x) \\in T_x M")#text(" u at x is a tangent vector to ")#mi("K_x")#text(" at u(x), and the Laplacian ")#mi("\\nabla^\\alpha \\nabla_\\alpha u(x) \\in T_x M")#text(" is an inward or tangential pointing vector to ")#mi("K_x")#text(" at ")#mi("u(x)")#text(" (i.e. it lives in the closed ")#link("http://en.wikipedia.org/wiki/Convex_cone")[#text("convex cone")]#text(" of ")#mi("K_x - u(x)")#text("). Here the space ")#mi("T^* M \\times V")#text(" that ")#mi("\\nabla u")#text(" is a section of is equipped with the direct sum of the Levi-Civita connection and the connection on V; by abuse of notation, we refer to all of these connections as ")#mi("\\nabla")#text(".")
]

#text("Note that Lemma 1 corresponds to the special case when ")#mi("V = M \\times {\\Bbb R}")#text(" and ")#mi("K = M \\times [a,+\\infty)")#text(" for some a.")

#strong[#text("Proof.")]#text(" We begin with the claim concerning the first derivatives ")#mi("\\nabla_X u(x)")#text(". One can restrict attention from M to (a local piece of) the one-dimensional geodesic through x with velocity ")#mi("X(x)")#text(", thus essentially reducing matters to the case d=1. Any one-dimensional connection can be locally trivialised (this is essentially the ")#link("http://en.wikipedia.org/wiki/Picard-Lindel%C3%B6f_theorem")[#text("Picard existence theorem for ODE")]#text(") and so we may take M to be a small interval ")#mi("(-\\varepsilon,\\varepsilon)")#text(" (with x now being identified with 0), take V to be the trivial bundle ")#mi("M \\times V_0")#text(", and take ")#mi("\\nabla")#text(" to be the trivial connection. The set K can then be identified with ")#mi("M \\times K_0")#text(", and u can be viewed as a smooth function from ")#mi("(-\\varepsilon,\\varepsilon)")#text(" to ")#mi("K_0")#text(" that attains the boundary of ")#mi("K_0")#text(" at 0. It is then clear that the first derivative of u at 0 is tangent to ")#mi("K_0")#text(" at u(0).")

#text("Now we turn to the second derivatives. As in the proof of Lemma 1, we introduce an orthonormal frame ")#mi("e_a")#text(" and express the Laplacian in terms of this frame via the Leibniz rule as in (2). The first derivative terms are already tangential, so it suffices by convexity to show that ")#mi("\\nabla_{e_a} \\nabla_{e_a} u(x)")#text(" is tangential or inward pointing for each ")#mi("a=1,\\ldots,d")#text(" separately. But for fixed a, we can reduce to the one-dimensional setting considered previously by restricting to the geodesic through x with velocity ")#mi("e_a(x)")#text(" as before, so that once again ")#mi("u")#text(" is now a smooth function from ")#mi("(-\\varepsilon, \\varepsilon)")#text(" to ")#mi("K_0")#text(" which attains a boundary value of ")#mi("K_0")#text(" at 0. In particular, if ")#mi("\\{ v \\in V_0: \\lambda(v) \\leq c \\}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Supporting_hyperplane")[#text("supporting halfspace")]#text(" for ")#mi("K_0")#text(" at ")#mi("u(0)")#text(" for some linear functional ")#mi("\\lambda: V_0 \\to {\\Bbb R}")#text(", then the scalar function ")#mi("x \\mapsto \\lambda(u(x)) \\cdot w")#text(" attains a maximum at 0 and thus has non-negative second derivative. The claim follows. ")#mi("\\Box")

#text("As a consequence we can establish a rather general and powerful tensor maximum principle of Hamilton:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" (Hamilton’s maximum principle) Let ")#mi("t \\mapsto (M,g(t))")#text(" be a smooth flow of compact Riemannian manifolds on a time interval ")#mi("{}[0,T]")#text(". Let V be a vector bundle over M with connection ")#mi("\\nabla")#text(", and let ")#mi("u: [0,T] \\mapsto \\Gamma(V)")#text(" be a smoothly varying family of sections that obeys the nonlinear PDE")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\frac{d}{dt} u(t,x) = \\nabla^\\alpha \\nabla_\\alpha u + F(t,x,u)")]]

#text("where for each ")#mi("(t,x) \\in [0,T] \\times M")#text(", ")#mi("F(t,x): V_x \\to V_x")#text(" is a locally Lipschitz function (using the metric on ")#mi("V_x")#text(" induced by g) which is continuous in t,x with uniformly bounded Lipschitz constant in the 1-neighbourhood (say) of ")#mi("K_x")#text(". For each time ")#mi("t \\in [0,T]")#text(", let ")#mi("K(t) \\subset V")#text(" a closed fibrewise convex parallel set varying continuously in t. We assume that K is preserved by F in the sense that for each ")#mi("(t,x) \\in [0,T) \\times M")#text(" and each boundary point ")#mi("v \\in \\partial K_x(t) \\subset V_x")#text(", the spacetime vector ")#mi("(1,F(t,x,v)) \\in {\\Bbb R} \\times V_x")#text(" is an inward or tangential vector to the spacetime body ")#mi("K_x := \\{ (t^{\\prime},v^{\\prime}): t^{\\prime} \\in [0,T], v^{\\prime} \\in K_x(t^{\\prime}) \\}")#text(" at the boundary point (t,v). Suppose also that ")#mi("u(0,x) \\in K_x(0)")#text(" for all ")#mi("x \\in M")#text(". Then ")#mi("u(t,x) \\in K_x(t)")#text(" for all ")#mi("(t,x) \\in [0,T] \\times M")#text(".")
]

#strong[#text("Proof.")]#text(" By continuity in time, it suffices to prove the claim in ")#mi("{}[0,T) \\times M")#text(" rather than ")#mi("{}[0,T] \\times M")#text(".")

#text("Let us first give an “almost proof” of the claim, and then explain how to modify this to an actual proof. Suppose the claim failed; then ")#mi("u(t,x)")#text(" must exit ")#mi("K_x(t)")#text(" for some ")#mi("(t,x) \\in [0,T) \\times M")#text(". If we let t be the first time at which this occurs, then ")#mi("t > 0")#text(" and there exists ")#mi("x \\in M")#text(" such that ")#mi("u(t,x) \\in \\partial K_x(t)")#text(", and ")#mi("u(t,y) \\in K_y(t)")#text(" for all other ")#mi("y \\in M")#text(". By Lemma 3, this implies that ")#mi("\\nabla^\\alpha \\nabla_\\alpha u(t,x)")#text(" is a tangential or inward pointing vector to ")#mi("K_x(t)")#text(" at ")#mi("u(t,x)")#text(". Also, since ")#mi("u(t^{\\prime},x) \\in K_x(t^{\\prime})")#text(" for all ")#mi("t^{\\prime} < t")#text(", we see that ")#mi("(1,\\frac{d}{dt} u(t,x))")#text(" is a tangential or outward pointing vector of ")#mi("K_x")#text(" at ")#mi("(t, u(t,x))")#text(". From (6) we conclude that ")#mi("(1, F(u,t,x))")#text(" is also a tangential or outward pointing vector. This ")#emph[#text("almost ")]#text("contradicts the hypothesis, except that it is still possible that ")#mi("(1,F(u,t,x))")#text(" is tangential.")

#text("To modify this, what we do is that we enlarge the set K slightly. Let A be a large number (essentially this is the bound on the local Lipschitz constant on F) ")#mi("\\varepsilon > 0")#text(" be small. For each ")#mi("(t,x) \\in [0,T] \\times M")#text(", let ")#mi("K^{(\\varepsilon,A)}_x(t)")#text(" be the ")#mi("\\varepsilon e^{At}")#text("-neighbourhood of ")#mi("K_x(t)")#text(" in ")#mi("V_x")#text(". If ")#mi("\\varepsilon")#text(" is small enough compared to A, this new set ")#mi("K^{(\\varepsilon,A)}_x(t)")#text(" lives in the 1-neighbourhood of the old set ")#mi("K_x(t)")#text(". If A is sufficiently large compared to the local Lipschitz constant of F, then (by the growth of the exponential function ")#mi("e^{At}")#text(", and the hypotheses on F) the vector ")#mi("(1, F(t,x,u))")#text(" will now always be inward pointing, and not just tangential or inward pointing, to the spacetime body ")#mi("K^{(\\varepsilon,A)}")#text(" whenever ")#mi("(t,x,u)")#text(" is at a boundary point of this body. This allows us to use the previous arguments with ")#mi("K_x(t)")#text(" replaced by ")#mi("K^{(\\varepsilon,A)}")#text(" throughout, to show that ")#mi("u(t,x)")#text(" cannot escape ")#mi("K^{(\\varepsilon,A)}")#text(" if A is large enough. Sending ")#mi("\\varepsilon \\to 0")#text(" we obtain the claim. ")#mi("\\Box")

#strong[#text("Remark 1. ")]#text("One can easily also add a drift term ")#mi("\\nabla_{X(t)} u(t,x)")#text(" to (6), as in Corollary 1, though we will not need to do so here. With some more effort, one could start defining notions of “tensor supersolutions” and “tensor subsolutions”, which take values as fibrewise convex sets rather than sections, to try to obtain a true tensor generalisation of Corollary 1, but this becomes very technical and we will not need to use such generalisations here. ")#mi("\\diamond")

#strong[#text("Remark 2.")]#text(" The above maximum principles are known as ")#emph[#text("weak")]#text(" maximum principles: starting from an assumption of non-negativity (or similar closed bounds) at time zero, they ensure non-negativity (or closed bounds) at later times. Later on we shall also need ")#emph[#text("strong")]#text(" maximum principles, in which one additionally assumes ")#emph[#text("positivity")]#text(" at some initial point at time zero, and that the manifold is connected, and concludes positivity ")#emph[#text("everywhere")]#text(" at later times. (This can be viewed as a substantial generalisation of the fact that the heat kernel on a connected manifold is everywhere strictly positive, or more informally that Brownian motion has a positive probability of hitting any given non-empty open region of the manifold.) Actually, it is the contrapositive of these strong maximum principles which will be of use to us, as they allow one to use vanishing of some key curvature at one point in spacetime to deduce vanishing of curvatures at many other points in spacetime also, which in particular will lead to some very important ")#emph[#text("splitting theorems")]#text(" that will arise in the arguments later. ")#mi("\\diamond")

#heading(level: 1)[#text("— Applications of the maximum principle —")]

#text("We now apply the maximum principle (in both its scalar and tensor forms) to solutions of the Ricci flow (1) on some time interval ")#mi("{}[0,T]")#text(". The simplest application of these principles arises from exploiting the equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\frac{d}{dt} R = \\Delta R + 2 \\left|\\text{Ric}\\right|^2", block: true)]]

#text("for the scalar curvature (see (31) from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text(").")

#strong[#text("Remark 3. ")]#text("Intuitively, the two components on the RHS of (7) can be interpreted as follows. The dissipative term ")#mi("\\Delta R")#text(" reflects the fact that a point in M with much higher (resp. lower) curvature than its neighbours (or more precisely, than the average curvature of its neighbours) will tend to revert to the mean, because the Ricci flow (1) will strongly contract the metric at regions of particularly high curvature (resp. strongly expand the metric at regions of particularly low curvature); one may visualise Ricci flow on a very pointed cigar, or a highly curved saddle, to try to see what is going on. The nonlinear term ")#tao-math("2 \\left|\\text{Ric}\\right|^2", block: false)#text(" reflects the fact that if one is in a positive curvature region (e.g. a region behaving like a sphere), then the metric will contract under Ricci flow, thus increasing the curvature to be even more positive; conversely, if one is in a negative curvature region (such as a region behaving like a saddle), then the metric will expand, thus weakening the negativity of curvature. Note that in both cases the curvature is trending upwards, which is consistent with the non-negativity of ")#tao-math("2 \\left|\\text{Ric}\\right|^2", block: false)#text(". ")#mi("\\diamond")

#strong[#text("Remark 4. ")]#text("Another source of intuition can come from ")#link("http://en.wikipedia.org/wiki/Einstein_manifold")[#text("Einstein metrics")]#text(", which are those metrics with the property that ")#mi("\\text{Ric}_{\\alpha \\beta} = k g_{\\alpha \\beta}")#text(" for some constant k; in particular we have constant scalar curvature ")#mi("R = kd")#text(", where d is the dimension. It is not hard to show (using the equations for dilation, see (22) from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text(") that the Ricci flow for such metrics is given explicitly by the formulae")

#tao-aligned(keep: true)[


#tao-math("g_{\\alpha \\beta}(t)  & = (1 - 2kt) g_{\\alpha \\beta}(0)", block: true)



#tao-math("g^{\\alpha \\beta}(t)  & = \\frac{1}{1-2kt} g^{\\alpha \\beta}(0)", block: true)



#tao-math("\\text{Ric}_{\\alpha \\beta}(t)  & = \\text{Ric}_{\\alpha\\beta}(0)", block: true, numbering: n => [#text("(8)")])
]

#align(center)[#mi("R(t) = \\frac{1}{1-2kt} R(0) = \\frac{1}{1-2kt} kd")#text(".")]

#text("Of course, this is completely consistent with (7). Note that if k is positive (which occurs for instance in manifolds of constant positive sectional curvature, such as the sphere and its quotients) then a singularity develops at time 1/2k, in which the diameter of the manifold has shrunk to zero and the curvature has become infinitely positive. In contrast, if k is negative (which occurs for manifolds of constant negative sectional curvature, such as hyperbolic space) the metric expands, becomes increasingly flat over time and does not develop singularities. ")#mi("\\diamond")

#text("Since R is the trace of the self-adjoint tensor ")#mi("\\text{Ric}_{\\alpha \\beta}")#text(", one has the decomposition")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left|\\text{Ric}\\right|^2 = \\frac{1}{d} R^2 + \\left|\\text{Ric}^0\\right|^2,", block: true)]]

#text("where ")#mi("\\text{Ric}^0_{\\alpha \\beta} := \\text{Ric}_{\\alpha \\beta} - \\frac{1}{d} R g_{\\alpha \\beta}")#text(" is the traceless component of the Ricci tensor. We conclude that R is a supersolution to a nonlinear parabolic PDE:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\frac{d}{dt} R \\geq \\Delta R + \\frac{2}{d} R^2.")]]

#text("For each time t, let ")#mi("R_{\\text{min}}(t)")#text(" denote the minimum value of the scalar curvature. We thus conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" (Lower bounds on scalar curvature). Let ")#mi("(M,g(t))")#text(" be a Ricci flow on a compact d-dimensional manifold on some time interval ")#mi("{}[0,T]")#text(". Then for every ")#mi("t \\in [0,T]")#text(", we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("R_{\\text{min}}(t) \\geq \\frac{R_{\\text{min}}(0)}{ 1 - \\frac{2t}{d} R_{\\text{min}}(0)}.")]]

#text("In particular, if ")#mi("R \\geq c")#text(" at time zero for some ")#mi("c \\in {\\Bbb R}")#text(", then ")#mi("R \\geq c")#text(" for all subsequent times for which the flow exists; and if furthermore c is positive, then the flow cannot be extended beyond time ")#mi("\\frac{d}{2c}")#text(".")
]

#text("From Remark 4 we see that for Einstein metrics, (11) is obeyed with equality, so that (11) can be quite sharp.")

#strong[#text("Exercise 1. ")]#text("Use Corollary 1 to deduce Proposition 2. ")#mi("\\diamond")

#text("Proposition 2 asserts that while the scalar curvature can become extremely large and positive as time increases, it cannot become extremely large and negative. One quick corollary of this is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2. ")]#text("(Upper bound on volume growth) Let ")#mi("(M,g(t))")#text(" be a Ricci flow on a compact d-dimensional manifold on some time interval ")#mi("{}[0,T]")#text(", such that we have the pointwise lower bound ")#mi("R \\geq c")#text(" at time zero. Then we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\text{Vol}(M,g(t)) \\leq e^{-2ct} \\text{Vol}(M,g(0))")]]

#text("for all ")#mi("0 \\leq t \\leq T")#text(".")
]

#strong[#text("Proof. ")]#text(" From the variation formula for the volume measure ")#mi("d\\mu")#text(" (see (33) from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text(") we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13).")])
#mitex("\\frac{d}{dt} \\text{Vol}(M,g(t)) = -\\int_M 2 R(t,x)\\ d\\mu_{g(t)}(x)")]]

#text("By Proposition 2, R is bounded from below by c, leading to the inequality ")#mi("\\frac{d}{dt} \\text{Vol}(M,g(t)) \\leq - 2c \\text{Vol}(M,g(t))")#text(". The claim now follows from ")#link("http://en.wikipedia.org/wiki/Gr%C3%B6nwall%27s_inequality")[#text("Gronwall’s inequality")]#text(". ")#mi("\\Box")

#strong[#text("Exercise 2.")]#text(" Strengthen the bound (12) to")

#align(center)[#mi("\\text{Vol}(M,g(t)) \\leq (1-\\frac{2ct}{d})^d \\text{Vol}(M,g(0))")#text(" (13′)")]

#text("and show that this inequality is sharp for Einstein metrics. Note that this improved bound demonstrates rather visibly that when ")#mi("c > 0")#text(", some singularity must develop at or before time ")#mi("d/2c")#text(". ")#mi("\\diamond")

#text("We now turn to applications of the tensor maximum principle. It is natural to apply this principle to the equation for the Riemann tensor,")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\frac{d}{dt} \\text{Riem}_{\\alpha \\beta} = \\Delta \\text{Riem}_{\\alpha \\beta} + {\\mathcal O}(\\text{Riem}^2)")]]

#text("(see equation (31) from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text("). In principle, this expression is of the required form (6), but the nonlinearity ")#mi("{\\mathcal O}(\\text{Riem}^2)")#text(", while explicit, is rather messy to work with. It is convenient to simplify (14) further by viewing things in a certain evolving orthonormal frame. For ease of notation, let us assume that the compact manifold M=M(0) is ")#link("http://en.wikipedia.org/wiki/Parallelizable_manifold")[#text("parallelisable")]#text(", so that it enjoys a global orthonormal frame ")#mi("e_1(0), \\ldots, e_d(0) \\in \\Gamma(TM(0))")#text(" for the metric g(0). (To handle the general case, one could work locally, or pass to a covering space, and/or replace the trivial bundle ")#mi("M \\times {\\Bbb R}^d")#text(" appearing below by a non-trivial bundle and eliminate explicit mention of the orthonormal frame altogether; we leave the details to the interested reader. In three dimensions, every orientable manifold is parallelisable, so it is even easier to reduce to the parallelisable case in that setting.) This orthonormal frame induces a linear identification between the tangent bundle ")#mi("TM(0)")#text(" and the trivial bundle ")#mi("M \\times {\\Bbb R}^d")#text(", with ")#mi("e_1(0), \\ldots, e_d(0)")#text(" being identified with the standard basis sections of the trivial bundle. The metric ")#mi("g_{\\alpha \\beta}(0)")#text(" is then identified with the Euclidean section ")#mi("\\eta_{\\alpha \\beta} := e^a_\\alpha e^a_\\beta \\in \\text{Sym}^2(M \\times {\\Bbb R}^d")#text(") (which is giving the fibres of ")#mi("M \\times {\\Bbb R}^d")#text(" a Euclidean structure). Note that this is NOT directly a metric on M, since ")#mi("M \\times {\\Bbb R}^d")#text(" is distinct from the tangent bundle TM, but the orthonormal frame provides an identification between the section ")#mi("\\eta")#text(" and the metric g(0).")

#text("Now we start the Ricci flow, creating a family of new metrics ")#mi("g(t)")#text(" for ")#mi("t \\in [0,T]")#text(". There is no reason why the frame ")#mi("e_1(0),\\ldots, e_d(0)")#text(" should remain orthonormal in these new metrics. However, if we evolve the frame by the equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\frac{d}{dt} e_a^\\alpha := \\text{Ric}^{\\alpha \\beta} (e_a)_\\beta")]]

#text("(which, by ")#link("http://en.wikipedia.org/wiki/Picard-Lindel%C3%B6f_theorem")[#text("Picard’s existence theorem for ODE")]#text(", exists for all ")#mi("t \\in [0,T]")#text(") then an easy computation using (1) (and Gronwall’s inequality) reveals that ")#mi("e_1(t), \\ldots, e_d(t)")#text(" remain orthonormal with respect to g(t).")

#strong[#text("Exercise 3.")]#text(" Prove this. (Hint: differentiate ")#mi("g_{\\alpha \\beta} e_a^\\alpha e_b^\\alpha")#text(" in time and use (1), (15).) ")#mi("\\diamond")

#text("The frame ")#mi("e_1(t), \\ldots, e_d(t)")#text(" can be used to identify the tangent manifold ")#mi("TM(t)")#text(" at time t with the trivial bundle ")#mi("M \\times {\\Bbb R}^d")#text(", which identifies g(t) with ")#mi("\\eta")#text(". In particular, the Levi-Civita connection ")#mi("\\nabla_{g(t)}")#text(" can be identified with a connection ")#mi("\\nabla(t)")#text(" on ")#mi("M \\times {\\Bbb R}^d")#text(" to which ")#mi("\\eta")#text(" is parallel (thus parallel transport by ")#mi("\\nabla(t)")#text(" proceeds by rotations). Similarly, we can identify the Riemann tensor ")#mi("\\text{Riem}(t) \\in \\text{Hom}( \\bigwedge^2 T^* M, \\bigwedge^2 T^* M )")#text(" at that time with a tensor ")#mi("{\\mathcal T}(t) \\in M \\times \\text{Hom}( \\bigwedge^2 {\\Bbb R}^d, \\bigwedge^2 {\\Bbb R}^d )")#text(". Using the natural identification between ")#mi("\\bigwedge^2 {\\Bbb R}^d")#text(" and the Lie algebra ")#mi("\\mathfrak{so}(d)")#text(", one can thus view ")#mi("{\\mathcal T}(t)")#text(" as a section of ")#mi("M \\times \\text{Hom}( \\mathfrak{so}(d), \\mathfrak{so}(d) )")#text(". Actually, since the Riemann tensor is self-adjoint, ")#mi("{\\mathcal T}(t,x): \\mathfrak{so}(d) \\to \\mathfrak{so}(d)")#text(" is self-adjoint also (using the Killing form on ")#mi("\\mathfrak{so}(d)")#text(").")

#text("After some significant algebraic computation, the equation (14) can be revealed to take the form")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\frac{d}{dt} {\\mathcal T} = \\nabla^\\gamma \\nabla_\\gamma {\\mathcal T} + {\\mathcal T}^2 + {\\mathcal T}^\\#")]]

#text("where the connection ")#mi("\\nabla = \\nabla(t)")#text(" has been extended from ")#mi("M \\times {\\Bbb R}^d")#text(" to ")#mi("M \\times \\text{Hom}( \\mathfrak{so}(d), \\mathfrak{so}(d) )")#text(" in the usual manner, ")#mi("{\\mathcal T}^2")#text(" is the usual square of ")#mi("{\\mathcal T}")#text(" (viewed as a linear operator from ")#mi("\\mathfrak{so}(d)")#text(" to itself), and ")#mi("{\\mathcal T}^\\#")#text(" is the ")#emph[#text("Lie algebra square")]#text(" of ")#mi("{\\mathcal T}")#text(", defined by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\langle {\\mathcal T}^\\# X, Y \\rangle := \\text{tr}( {\\mathcal T} (\\text{ad} X) {\\mathcal T} (\\text{ad} Y))")]]

#text("for all ")#mi("X, Y \\in \\mathfrak{so}(d)")#text(" where ")#mi("\\text{ad} X: Y \\to [X,Y]")#text(" is the usual adjoint operator and ")#mi("\\langle X, Y\\rangle = \\text{tr}( \\text{ad} X \\text{ad} Y )")#text(" is the Killing form. One easily verifies that if ")#mi("{\\mathcal T}")#text(" is self-adjoint, then so are ")#mi("{\\mathcal T}^2")#text(" and ")#mi("{\\mathcal T}^\\#")#text(". (Curiously, in four and higher dimensions the Bianchi identity that ")#mi("{\\mathcal T}")#text(" will satisfy if it comes from the Riemann tensor is not preserved by either ")#mi("{\\mathcal T}^2")#text(" or ")#mi("{\\mathcal T}^\\#")#text(", but it is preserved by their sum ")#mi("{\\mathcal T}^2 + {\\mathcal T}^\\#")#text(".)")

#strong[#text("Exercise 4. ")]#text(" Show that (17) implies (7). ")#mi("\\diamond")

#text("If ")#mi("{\\mathcal T}")#text(" is positive semi-definite (which is equivalent to the Riemann tensor being non-negative), then it is easy to see that ")#mi("{\\mathcal T}^2 + {\\mathcal T}^\\#")#text(" are also. Since the space ")#mi("{\\mathcal P}")#text(" of positive semi-definite self-adjoint elements of ")#mi("\\text{Hom}(\\mathfrak{so}(d),\\mathfrak{so}(d))")#text(" forms a closed convex cone which is invariant under the action of SO(d) (and in particular, ")#mi("M\\times {\\mathcal P}")#text(" is parallel with respect to the connections ")#mi("\\nabla_{g(t)}")#text("), one can then apply the tensor maximum principle to conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3")]#text(" (Non-negative Riemann curvature is preserved). Let ")#mi("(M,g(t))")#text(" be a Ricci flow on a compact d-dimensional manifold on some time interval ")#mi("{}[0,T]")#text(". Suppose that the Riemann curvature is everywhere non-negative at time zero. Then the Riemann curvature is everywhere non-negative for all times ")#mi("t \\in [0,T]")#text(".")
]

#strong[#text("Remark 6.")]#text(" Strictly speaking, there is an issue because the nonlinearity ")#mi("{\\mathcal T} \\mapsto {\\mathcal T}^2 + {\\mathcal T}^\\#")#text(" is only locally Lipschitz rather than globally Lipschitz. But as we are assuming that the manifold is compact and the metrics vary smoothly, ")#mi("{\\mathcal T}")#text(" is already bounded, and so one can truncate the nonlinearity by brute force outside of these bounds to ensure global Lipschitz bounds. We shall take advantage of this trick again below without further comment. ")#mi("\\diamond")#linebreak()#text(" Now we specialise to three dimensions, in which the situation simplifies substantially, because ")#mi("\\mathfrak{so}(3) \\equiv\\bigwedge^2 {\\Bbb R}^3")#text(" can be identified with ")#mi("{\\Bbb R}^3")#text(" by Hodge duality. If the self-adjoint map ")#mi("{\\mathcal T}: {\\Bbb R}^3 \\to {\\Bbb R}^3")#text(" is diagonalised as ")#mi("\\text{diag}(\\lambda,\\mu,\\nu)")#text(" in some orthonormal frame, then we have ")#mi("{\\mathcal T}^2 = \\text{diag}(\\lambda^2,\\mu^2,\\nu^2)")#text(" and ")#mi("{\\mathcal T}^\\# = \\text{diag}(\\mu \\nu, \\lambda \\nu, \\lambda \\mu)")#text(". Also, if ")#mi("{\\mathcal T}")#text(" was representing the Riemann tensor, then the Ricci curvature in the same frame can be computed to be ")#mi("\\text{diag}(\\mu+\\nu, \\lambda+\\nu, \\lambda+\\mu)")#text(", and so the scalar curvature is ")#mi("2(\\lambda+\\mu+\\nu)")#text(". [")#emph[#text("Aside")]#text(": there may be some factors of 2 that are off here; I did not have time to recheck these calculations.]")

#text("Heuristically, the tensor maximum principle predicts that the evolution of the equation (16) should be somehow “controlled” by the evolution of the ODE")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\frac{d}{dt} (\\lambda,\\mu,\\nu) = F( \\lambda, \\mu, \\nu )")]]

#text("where ")#mi("F(\\lambda,\\mu,\\nu) := ( \\lambda^2+\\mu \\nu, \\mu^2+\\lambda \\nu, \\nu^2 + \\lambda \\mu)")#text(". It seems difficult to formulate this heuristic rigorously in complete generality (the main problem being that the convexity requirements of the maximum principle ultimately translate to rather significant constraints on what types of properties of the eigenvalues ")#mi("\\lambda,\\mu,\\nu")#text(" one can study with this principle). However, we can do so in two important special cases. We begin with the simpler one.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4.")]#text(" (Non-negative Ricci curvature is preserved in three dimensions) Let ")#mi("(M,g(t))")#text(" be a Ricci flow on a compact 3-dimensional manifold on some time interval ")#mi("{}[0,T]")#text(". Suppose that the Ricci curvature is everywhere non-negative at time zero. Then the Ricci curvature is everywhere non-negative for all times ")#mi("t \\in [0,T]")#text(".")
]

#strong[#text("Proof.")]#text(" By the previous discussion, having non-negative Ricci curvature is equivalent to having all sums of pairs ")#mi("\\lambda+\\mu, \\mu+\\nu, \\nu+\\lambda")#text(" of ")#mi("{\\mathcal T}")#text(" non-negative. Equivalently, this is asserting that the partial traces ")#mi("\\text{tr}( {\\mathcal T}|_V )")#text(" of ")#mi("{\\mathcal T}")#text(" on any two-dimensional subspace of V is non-negative. If we let ")#mi("K = K(t) \\subset M \\times \\text{Hom}({\\Bbb R}^3, {\\Bbb R}^3)")#text(" denote all the pairs ")#mi("(x, {\\mathcal T})")#text(" for which this is true, we see that K is closed, convex, and parallel with respect to the connections ")#mi("\\nabla(t)")#text(", since parallel transport by these connections acts on ")#mi("\\text{Hom}({\\Bbb R}^3, {\\Bbb R}^3)")#text(" by orthogonal conjugation. Elementary algebraic computation also reveals that if the triplet ")#mi("(\\lambda, \\mu, \\nu)")#text(" has the property that the sum of any two elements is non-negative, then the same is true of ")#mi("F(\\lambda, \\mu, \\nu)")#text(". From this we see that the hypotheses of Proposition 1 are satisfied, and the claim follows. ")#mi("\\Box")

#strong[#text("Remark 7. ")]#text("This claim is special to three (and lower) dimensions; it fails for four and higher dimensions. Similarly, in three dimensions, since non-negative Riemann curvature is equivalent to non-negative sectional curvature, we see from Proposition 3 that the latter is also preserved by three-dimensional Ricci flow. However, this claim also fails in four and higher dimensions. [")#emph[#text("Aside")]#text(": I may be slightly confused on these points; I will check on them later, once I have access to some literature.] ")#mi("\\diamond")

#text("Results such as Proposition 3 and Proposition 4 are of course useful if one has an initial assumption of non-negative curvature. But for our applications, we need to understand what is going on for manifolds which may have combinations of both positive and negative curvature at various points and in various directions. The bound on scalar curvature given by Proposition 2 is helpful in this regard, but it only partially controls the situation (in terms of the eigenvalues ")#mi("\\lambda,\\mu,\\nu")#text(", it offers a lower bound on ")#mi("\\lambda+\\mu+\\nu")#text(", but not on ")#mi("\\lambda,\\mu,\\nu")#text(" individually). It turns out that one cannot completely establish a unilateral lower bound on the individual curvatures ")#mi("\\lambda, \\mu, \\nu")#text(", but one can at least show that if one of these curvatures is large and negative, then one of the others must be extremely large and positive, and so in regions of high curvature, the positive curvature components dominate. This important phenomenon for Ricci flow is known as ")#emph[#text("Hamilton-Ivey pinching")]#text(", and is formalised as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" (Hamilton-Ivey pinching phenomenon) Let ")#mi("(M,g(t))")#text(" be a Ricci flow on a compact 3-dimensional manifold on some time interval ")#mi("{}[0,T]")#text(". Suppose that the least eigenvalue ")#mi("\\nu(t,x)")#text(" of the Riemann curvature tensor is bounded below by -1 at times t=0 and all ")#mi("x \\in M")#text(". Then, at all spacetime points ")#mi("(t,x) \\in [0,T] \\times M")#text(", we have the scalar curvature bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("R \\geq \\frac{-6}{4t+1}")]]

#text("and furthermore whenever one has negative curvature in the sense that ")#mi("\\nu(t,x) < 0")#text(", then one also has the pinching bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("R \\geq 2|\\nu| ( \\log \\left|\\nu\\right| + \\log(1+t) - 3).", block: true)]]
]

#strong[#text("Exercise 5. ")]#text("With the assumptions of Theorem 1, use (19) and (20) to establish the lower bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("(1+t) \\nu \\geq - C \\frac{100 + (1+t) R}{\\log( 100 + (1+t) R )}")]]

#text("for all ")#mi("(t,x) \\in [0,T] \\times M")#text(" and some absolute constant C (note that ")#mi("100+(1+t) R > 1")#text(", thanks to (19). Conclude in particular that the scalar curvature controls the Riemann and Ricci tensors in the sense that we have the pointwise bounds")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#tao-math("\\left|\\text{Ric}\\right|_g, \\left|\\text{Riem}\\right|_g \\leq C(100 + (1+t) R)", block: true)]]

#text("for another absolute constant C.")

#strong[#text("Proof. ")]#text("Since ")#mi("R = 2(\\lambda+\\mu+\\nu)")#text(" and the least eigenvalue ")#mi("\\nu")#text(" is at least -1 at time zero, we have ")#mi("R \\geq -6")#text(" at time zero. The claim (19) then follows immediately from Proposition 2.")

#text("The proof of (20) requires more work. Starting with the tensor ")#mi("{\\mathcal T}")#text(" and its eigenvalues ")#mi("\\lambda \\geq \\mu \\geq \\nu")#text(", we define the trace ")#mi("S := \\lambda+\\mu+\\nu = \\frac{1}{2} R")#text(" and the quantity ")#mi("X := \\max( - \\nu, 0 )")#text(". We write ")#mi("f_t(x) := x(\\log x + \\log(1+t)-3)")#text(" and let ")#mi("\\Omega_t")#text(" be the set of all pairs ")#mi("(x,s)")#text(" such that ")#mi("s \\geq \\frac{-3}{1+t}")#text(" and such that ")#mi("s \\geq f_t(x)")#text(" if ")#mi("x > \\frac{1}{1+t}")#text(". (For ")#mi("x < \\frac{1}{1+t}")#text(", the only constraint we place on s is that ")#mi("s \\geq \\frac{-3}{1+t}")#text(". Elementary calculus shows that ")#mi("\\Omega_t")#text(" is a convex set, and furthermore is left-monotone in the sense that if ")#mi("(x,s) \\in \\Omega_t")#text(" and ")#mi("x^{\\prime} < x")#text(", then ")#mi("(x^{\\prime},s) \\in \\Omega_t")#text(". Because trace is a linear functional and the least eigenvalue ")#mi("\\nu")#text(" is a convex functional, it is not hard to then see that the set ")#mi("K(t) := \\{ (x,{\\mathcal T}): (X,S) \\in \\Omega_t \\} \\subset M \\times \\text{Hom}({\\Bbb R}^3, {\\Bbb R}^3)")#text(" is closed and fibrewise convex. Also, since parallel transport on the connections ")#mi("\\nabla(t)")#text(" acts by orthogonal conjugation, K(t) is also parallel.")

#text("The initial conditions easily ensure that ")#mi("{\\mathcal T}")#text(" lies in ")#mi("K(0)")#text(" at time zero (since ")#mi("X \\leq 1")#text(" and ")#mi("S \\geq -3")#text(" in this case). Similarly, the conclusion (20) follows easily from the claim that ")#mi("{\\mathcal T}")#text(" lies in ")#mi("K(t)")#text(" at all later times t (note that in the case ")#mi("X \\leq \\frac{1}{1+t}")#text(", one can use the trivial bound ")#mi("S \\geq -3X")#text(" to establish the claim, rather than by exploiting the inclusion ")#mi("{\\mathcal T} \\in K(t)")#text("). So to finish the proof, it suffices by Proposition 1 to show that K is preserved by the ODE (18). This can be accomplished by a (rather tedious) elementary calculation, the key point being that if ")#mi("(\\lambda,\\mu,\\nu)")#text(" solve (18) with ")#mi("\\lambda \\geq \\mu \\geq \\nu")#text(" and X, S are defined as before, then one has the inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\frac{d}{dt} ( \\frac{S}{X} - \\log X ) \\geq X")]]

#text("whenever ")#mi("X > 0")#text(".")

#text("The set K(t) can be viewed as the region in which either ")#mi("X \\leq \\frac{1}{1+t}")#text(", or ")#mi("X > \\frac{1}{1+t}")#text(" and ")#mi("\\frac{S}{X} - \\log X \\geq \\log(1+t)-3")#text(", and then (23) implies that this region is preserved by the ODE. ")#mi("\\Box")

#strong[#text("Remark 8.")]#text(" One can informally see how (18) is forcing some sort of pinching towards positive curvature as follows. In order for pinching not to occur, one needs ")#mi("\\nu")#text(" to be large and negative, and ")#mi("\\lambda")#text(" to be of order ")#tao-math("O(\\left|\\nu\\right|)", block: false)#text(" in magnitude. Given the lower bounds on the scalar curvature, this in fact forces ")#mi("\\lambda")#text(" to be positive and comparable to ")#tao-math("\\left|\\nu\\right|", block: false)#text(" in magnitude. Now if ")#mi("\\mu")#text(" is also positive, then the equation ")#mi("\\frac{d}{dt} \\nu = \\nu^2 + \\lambda \\mu")#text(" rapidly causes ")#mi("\\nu")#text(" to be less negative, while the equation ")#mi("\\frac{d}{dt} \\lambda = \\lambda^2 + \\mu \\nu")#text(" can cause ")#mi("\\lambda")#text(" to decrease, but not as rapidly as ")#mi("\\nu")#text(" is increasing, thus the geometry does not become more pinched. If instead ")#mi("\\mu")#text(" is negative, then ")#mi("\\nu")#text(" can become more negative, but now ")#mi("\\lambda")#text(" will increase faster than ")#mi("\\nu")#text(" is decreasing, thus increasing the pinching towards positive (consider e.g. the case when ")#mi("\\nu=\\mu=-\\lambda/2")#text("). ")#mi("\\diamond")

#strong[#text("Remark 9.")]#text(" There are further applications of the tensor maximum principle to Ricci flow. One notable one is ")#emph[#text("Hamilton’s rounding theorem")]#text(", which asserts that if the Ricci curvature of a compact 3-manifold is strictly positive at time zero, then not only does a singularity develop in finite time (by Proposition 2), but the geometry becomes increasingly round in the sense that the ratio between the largest and smallest eigenvalues of this curvature go to 1 as one approaches the singularity. In fact, the rescaled limit of the geometry here has constant positive sectional curvature and is thus either a sphere or a spherical space form. ")#mi("\\diamond")

#text("[")#emph[#text("Update, Apr 7")]#text(": Some corrections, including rewording of proof of Proposition 1.]")

#heading(level: 1)[#text("Comments (25)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of km")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-27898")[#strong[#text("km")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2008")])]

#text("Dear Terence,")

#text("Do you know any good books on maximum principle for parabolic differential equations? Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PS")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-28050")[#strong[#text("PS")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2008")])]

#text("Two very minor remarks:")

#text("In the proof of Lemma 1 it appears that “f” should be replaced by “u”. In the first paragraph “establishes” should be “establish”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PS")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-28054")[#strong[#text("PS")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2008")])]

#text("To me it seems that the reason Corollary 1 is true is that (4) is inconsistent with Case 2 given in Lemma 2. I’m therefore a little confused by the statement “But this is inconsistent with (3)” that appears in the proof of the corollary.")

#text("Also, in the commentary following Corollary 1, I think that you mean to say that we may lower bound PDE supersolutions by ODE subsolutions rather than by ODE supersolutions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-28069")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2008")])]

#text("I have written the following essay to show how the mathematical education that is provided by USQ’s Mathematics Department yields concrete dividends, and thereby help make the case for its preservation and growth.")

#text("Also, this post is mathematical fan-mail for Prof. Tao’s Ricci flow lectures. Two birds with one stone!")

#text("Concretely speaking, we engineers are particularly interested in problems of adaptation and optimization. It is fruitful to view these problems geometrically, as entailing “flow” from a poorly adapted state-space or estimate, to a well-adapted state-space or estimate.")

#text("This geometric viewpoint motivates us to read Prof. Tao’s Ricci flow lectures with a view toward (eventually) adapting the lecture’s abstract ideas and mathematical tools to solve concrete problems of state-space adaptation and optimization.")

#text("For reasons of computational efficiency, engineering state-spaces typically are algebraic manifolds … not the topological manifolds of Prof. Tao’s lecture. But “no worries, mate” … the Ricci flow *does* evolve 3-manifolds toward spheres, which of course *are* algebraic manifolds.")

#text("There are at least *some* additional examples of Ricci flow evolving geometry toward algebraic manifolds. The Slater determinants of quantum chemistry provide a good examples. These quantum state-spaces are of course of immense practical interest to engineers, physicists and chemists. It is straightforward to establish that they are known to mathematicians as Grassmannians … a result that—almost incredibly—seems not to be widely recognized by either mathematicians or chemists.")

#text("Apparently the mathematical flow “from the abstract to the concrete” can sometimes be quite slow! :)")

#text("Of course, Grassmannian manifolds, when endowed with a Fubini-Study metric, are a good example of the (geometrically uniform) Einstein manifolds that Prof. Tao’s lecture mentioned. So we have the interesting concept (according to my imperfect understanding of Ricci flow) that a high-dimension Kahler-Ricci flow will (in some cases anyway) generate classes algebraic manifolds that are of substantial concrete interest to chemists and quantum system engineers.")

#text("From a broader perspective, it is widely appreciated (by engineers) that state-space “flow” computations at least as much global computing power as any other class of computations. The reason is that almost all large-scale computations—quantum chemistry, computational fluid dynamics, convex programming—expend a large fraction of their cycles adaptively”flowing” their state-space to suit the problem at-hand.")

#text("And *that* is a major reason why Prof. Tao’s weblog is so popular with engineers like me. Our own UW QSE Group has already embraced another abstract idea of Prof. Tao’s lectures: random sparse sampling. We were astounded to numerically verify—as Prof. Tao’s “Dantzig Selector” article predicted would happen—-that our large-scale quantum simulations can reconstruct wave functions from sparse random projections, with near-perfect fidelity. Amazing!")

#text("So, gee … now we wonder whether the ideas in Prof. Tao’s Ricci flow lectures can be adapted to flow poorly adapted algebraic manifolds into better-adapted manifolds? That would be very exciting … and very useful to scientists and engineers! You can bet we read each lecture with intense interest!")

#text("To return to the starting-point of this long post—for which I beg forgiveness—our engineering experience has definitely been that mathematical ideas can “flow from the abstract to the concrete” … and thus provide concrete returns upon society’s investment in departments like USQ Mathematics.")

#text("My thanks are hereby expressed to all who contribute to this fine weblog, especially Prog. Tao, whose immense efforts are reaching a highly appreciative engineering audience.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-28249")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2008")])]

#text("Very nice. I am not a mathematician but my interest in the subject is growing day by day. Are this lecture notes available as a one set note to download?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-28292")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2008")])]

#text("$(t,x) \\in [0,T] \\times M$??")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PS")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-28308")[#strong[#text("PS")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2008")])]

#text("In the second paragraph of the proof of Proposition 1, should the “outward pointing” vectors instead actually be inward pointing ones?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-28330")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2008")])]

#text("Dear PS: Thanks for the corrections! (Regarding the proof of Proposition 1, the wording was a little unclear: the point is that if one touched the boundary of the enlarged set ")#mi("K^{(A,\\varepsilon)}")#text(", then on the one hand the vector ")#mi("(1, F(t,x,u))")#text(" would be outward or tangential (in order to escape) but also inward (by hypotheses on F and the growth of ")#mi("e^{At})")#text(", leading to a contradiction.)")

#text("I will be updating these pages a little slower than usual this week, due to travel and also because of issues related to USQ, so please be patient for now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d509e4a67398165676196d672585ced90e7a9aff3d5e153a8ae82ca3a3719829-6913ece6216ee2882ebb73ce44bcf73b0437e510ad495f289d6450d43f808d08.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Danny Calegari")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-28633")[#strong[#text("Danny Calegari")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2008")])]

#text("One very quick comment: oriented 3-manifolds are parallelizable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-28654")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2008")])]

#text("Thanks for the comment, Danny!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/004b49d95248f124ffb7bce8cfcb59223aae2628bbdaadfad2d47577b5c7d9c0-c0d2796e0a0318ab220da653ebc8e404e23789c91b1e82db09d49304ef26a859.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tumur")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-29112")[#strong[#text("tumur")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2008")])]

#text("Can somebody please refer me to tensor sub- and super-solution literature?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 6: Finite time extinction of the third homotopy group, II « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-29140")[#strong[#text("285G, Lecture 6: Finite time extinction of the third homotopy group, II « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2008")])]

#text("[…] that by combining this corollary with the maximum principle (Corollary 1 of Lecture 3) we can get upper bounds on k for short times based on upper bounds for k at time zero. (By using […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 7: Rescaling of Ricci flows and kappa-noncollapsing « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-29206")[#strong[#text("285G, Lecture 7: Rescaling of Ricci flows and kappa-noncollapsing « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2008")])]

#text("[…] flow actually is an ancient solution. Also, while the Hamilton-Ivey pinching phenomenon from Lecture 3 suggests that the renormalised flows have mostly non-negative curvature, the limiting flow will have […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285A, Lecture 8: Ricci flow as a gradient flow, log-Sobolev inequalities, and Perelman entropy « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-29313")[#strong[#text("285A, Lecture 8: Ricci flow as a gradient flow, log-Sobolev inequalities, and Perelman entropy « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2008")])]

#text("[…] 4. Show that , and use this to conclude an analogue of Proposition 1 from Lecture 3 for . In particular conclude that Ricci flow must develop a finite time singularity if is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-29618")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2008")])]

#text("Regarding your aside to Remark 7: There is a 4d example due to Lei Ni that demonstrates that nonnegative sectional curvature is not preserved by Ricci flow. Bohm and Wilking have a higher dimensional compact example that also demonstrates that various weaker conditions are also not preserved. They’re described in the second volume of the Ricci Flow book by Chow, Chu et. al.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 11: κ-noncollapsing via Perelman reduced volume « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-29751")[#strong[#text("285G, Lecture 11: κ-noncollapsing via Perelman reduced volume « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2008")])]

#text("[…] can then obtained by an application of Hamilton’s maximum principle (Proposition 1 from Lecture 3); we leave this as an exercise to the reader. As in the heuristic discussion, the bounds on the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 12: High curvature regions of Ricci flow and κ-solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-29822")[#strong[#text("285G, Lecture 12: High curvature regions of Ricci flow and κ-solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2008")])]

#text("[…] of the Hamilton-Ivey pinching phenomenon (Theorem 1 from Lecture 3), we expect the rescaled flows to have non-negative Ricci curvature in the limit (and hence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 13: Li-Yau-Hamilton Harnack inequalities and κ-solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-29892")[#strong[#text("285G, Lecture 13: Li-Yau-Hamilton Harnack inequalities and κ-solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2008")])]

#text("[…] that F dominates at times close to . Applying the scalar maximum principle (Corollary 1 from Lecture 3) we conclude that . The claim (8) now follows from (5) and the chain […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 16: Classification of asymptotic gradient shrinking solitons « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-30141")[#strong[#text("285G, Lecture 16: Classification of asymptotic gradient shrinking solitons « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2008")])]

#text("[…] 2 and reaches a minimum value at some point x. If we rewrite things in terms of the tensor from Lecture 3, the gradient shrinking soliton structure means […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 17: The structure of κ-solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-30185")[#strong[#text("285G, Lecture 17: The structure of κ-solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2008")])]

#text("[…] At the times , we have for some . Applying the tensor maximum principle (Proposition 1 from Lecture 3) and the analysis from Case 4 of the previous lecture, we thus see that for all times ; sending n […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 18: The structure of high-curvature regions of Ricci flow « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-30219")[#strong[#text("285G, Lecture 18: The structure of high-curvature regions of Ricci flow « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2008")])]

#text("[…] from the Hamilton-Ivey pinching theorem (Theorem 1 from Lecture 3) we have and whenever . Rescaling this, we obtain and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Classification of Almost Quarter-Pinched Manifolds « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-31137")[#strong[#text("Classification of Almost Quarter-Pinched Manifolds « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2008")])]

#text("[…] Hamilton maximum principle (which was already observed in Hamilton’s original paper; see also Lecture 3 from my class) that showed that as these almost quarter-pinched manifolds initially had almost […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21aa472f8f494bc91b3f99127ecfb240005ad8fd92924bde9342f28755854eba-7971f5b8170dffe3c80165b7c231573ce5686efec2b955b95c917ec0dd874252.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammad")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-31147")[#strong[#text("Mohammad")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2008")])]

#text("Dear Prof. Tao,")

#text("First of all, there are again some mistakes with numbering. The numbers 1, 2, 3, 13 has been assigned twice.")#linebreak()#text(" I have also a question about the definition of “preservation of K by parallel transport”, How the covariant differentiation with respect to X is a vector field?")#linebreak()#text(" If we think of K as a plane distribution, then we can interprete this as closedness of K under covariant differentiation. But, Is this equivalent to closedness of K under parallel transportion? Or does this implies it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-31164")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2008")])]

#text("Dear Mohammad: Thanks for the corrections!")

#text("With respect to being parallel, a connection ")#mi("\\nabla")#text(" on a vector bundle is not directly a vector field ")#emph[#text("per se")]#text(", but it lifts every vector field X on the base to a vector field ")#mi("\\nabla_X")#text(" on the bundle. Being parallel with respect to the connection is then equivalent to being parallel with respect to each of these ")#mi("\\nabla_X")#text(", which is indeed the same as being closed with respect to parallel transport.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tricks Wiki: Give yourself an epsilon of room « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/#comment-36200")[#strong[#text("Tricks Wiki: Give yourself an epsilon of room « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2009")])]

#text("[…] PDE (for example, it is used heavily in the proof of the Poincaré conjecture, see e.g. my lecture notes on this topic). Here is a model example of this principle: Proposition 1. Let be a smooth harmonic function on […]")
]
