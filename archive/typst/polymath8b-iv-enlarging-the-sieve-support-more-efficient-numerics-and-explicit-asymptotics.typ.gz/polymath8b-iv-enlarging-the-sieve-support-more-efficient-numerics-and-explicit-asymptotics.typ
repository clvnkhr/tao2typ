// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/
// Converted to Typst by tao2typ: "2026-10-14T15:18:53.592344+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath8b, IV: Enlarging the sieve support, more efficient numerics, and explicit asymptotics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath8b, IV: Enlarging the sieve support, more efficient numerics, and explicit asymptotics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 December 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/")[#text("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is the fourth thread for the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8b project")]#text(" to obtain new bounds for the quantity")

#align(center)[#tao-fit-display[#mitex("H_m := \\liminf_{n \\rightarrow\\infty} (p_{n+m} - p_n),")]]

#text("either for small values of ")#mi("{m}")#text(" (in particular ")#mi("{m=1,2}")#text(") or asymptotically as ")#mi("{m \\rightarrow \\infty}")#text(". The previous thread may be found ")#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/")[#text("here")]#text(". The currently best known bounds on ")#mi("{H_m}")#text(" are:")

#list(
[#text("(Maynard) Assuming the Elliott-Halberstam conjecture, ")#mi("{H_1 \\leq 12}")#text(".")],
[#text("(Polymath8b, tentative) ")#mi("{H_1 \\leq 272}")#text(". Assuming Elliott-Halberstam, ")#mi("{H_2 \\leq 272}")#text(".")],
[#text("(Polymath8b, tentative) ")#mi("{H_2 \\leq 429{,}822}")#text(". Assuming Elliott-Halberstam, ")#mi("{H_4 \\leq 493{,}408}")#text(".")],
[#text("(Polymath8b, tentative) ")#mi("{H_3 \\leq 26{,}682{,}014}")#text(". (Presumably a comparable bound also holds for ")#mi("{H_6}")#text(" on Elliott-Halberstam, but this has not been computed.)")],
[#text("(Polymath8b) ")#mi("{H_m \\leq \\exp( 3.817 m )}")#text(" for sufficiently large ")#mi("{m}")#text(". Assuming Elliott-Halberstam, ")#mi("{H_m \\ll m e^{2m}}")#text(" for sufficiently large ")#mi("{m}")#text(".")]
)

#text("While the ")#mi("{H_1}")#text(" bound on the Elliott-Halberstam conjecture has not improved since the start of the Polymath8b project, there is reason to hope that it will soon fall, hopefully to ")#mi("{8}")#text(". This is because we have begun to exploit more fully the fact that when using “multidimensional Selberg-GPY” sieves of the form")

#align(center)[#tao-fit-display[#mitex("\\nu(n) := \\sigma_{f,k}(n)^2")]]

#text("with")

#align(center)[#tao-fit-display[#mitex("\\sigma_{f,k}(n) := \\sum_{d_1|n+h_1,\\dots,d_k|n+h_k} \\mu(d_1) \\dots \\mu(d_k) f( \\frac{\\log d_1}{\\log R},\\dots,\\frac{\\log d_k}{\\log R}),")]]

#text("where ")#mi("{R := x^{\\theta/2}}")#text(", it is not necessary for the smooth function ")#mi("{f: [0,+\\infty)^k \\rightarrow {\\bf R}}")#text(" to be supported on the simplex")

#align(center)[#tao-fit-display[#mitex("{\\cal R}_k := \\{ (t_1,\\dots,t_k)\\in [0,1]^k: t_1+\\dots+t_k \\leq 1\\},")]]

#text("but can in fact be allowed to range on larger sets. First of all, ")#mi("{f}")#text(" may instead be supported on the slightly larger polytope")

#tao-aligned(keep: true)[


#tao-math("{\\cal R}^{\\prime}_k  & := \\{ (t_1,\\dots,t_k)\\in [0,1]^k: t_1+\\dots+t_{j-1}+t_{j+1}+\\dots+t_k \\leq 1", block: true)



#tao-math("\\text{ for all } j & =1,\\dots,k\\}.", block: true)
]

#text("However, it turns out that more is true: given a sufficiently general version of the Elliott-Halberstam conjecture ")#mi("{EH[\\theta]}")#text(" at the given value of ")#mi("{\\theta}")#text(", one may work with functions ")#mi("{f}")#text(" supported on more general domains ")#mi("{R}")#text(", so long as the sumset ")#mi("{R+R := \\{ t+t^{\\prime}: t,t^{\\prime}\\in R\\}}")#text(" is contained in the non-convex region ")#metadata(none) <tao-c697d2981bf416569a16>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\bigcup_{j=1}^k \\{ (t_1,\\dots,t_k)\\in [0,\\frac{2}{\\theta}]^k: t_1+\\dots+t_{j-1}+t_{j+1}+\\dots+t_k \\leq 2 \\} \\cup \\frac{2}{\\theta} \\cdot {\\cal R}_k,")]]

#text("and also provided that the restriction ")#metadata(none) <tao-d594a7cbe7414e044ad5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("(t_1,\\dots,t_{j-1},t_{j+1},\\dots,t_k) \\mapsto f(t_1,\\dots,t_{j-1},0,t_{j+1},\\dots,t_k)")]]

#text("is supported on the simplex")

#tao-aligned(keep: true)[


#tao-math("{\\cal R}_{k-1}  & := \\{ (t_1,\\dots,t_{j-1},t_{j+1},\\dots,t_k)\\in [0,1]^{k-1}:", block: true)



#tao-math("t_1+\\dots+t_{j-1}+t_{j+1}+\\dots t_k  & \\leq 1\\}.", block: true)
]

#text("More precisely, if ")#mi("{f}")#text(" is a smooth function, not identically zero, with the above properties for some ")#mi("{R}")#text(", and the ratio ")#metadata(none) <tao-1348beb03ed9067bd422>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{j=1}^k \\int_{{\\cal R}_{k-1}} f_{1,\\dots,j-1,j+1,\\dots,k}(t_1,\\dots,t_{j-1},0,t_{j+1},\\dots,t_k)^2")]]

#align(center)[#tao-fit-display[#mitex("dt_1 \\dots dt_{j-1} dt_{j+1} \\dots dt_k")]]

#align(center)[#tao-fit-display[#mitex("/ \\int_R f_{1,\\dots,k}^2(t_1,\\dots,t_k)\\ dt_1 \\dots dt_k")]]

#text("is larger than ")#mi("{\\frac{2m}{\\theta}}")#text(", then the claim ")#mi("{DHL[k,m+1]}")#text(" holds (assuming ")#mi("{EH[\\theta]}")#text("), and in particular ")#mi("{H_m \\leq H(k)}")#text(".")

#text("I’ll explain why one can do this below the fold. Taking this for granted, we can rewrite this criterion in terms of the mixed derivative ")#mi("{F := f_{1,\\dots,k}}")#text(", the upshot being that if one can find a smooth function ")#mi("{F}")#text(" supported on ")#mi("{R}")#text(" that obeys the vanishing marginal conditions")

#align(center)[#tao-fit-display[#mitex("\\int F( t_1,\\dots,t_k )\\ dt_j = 0")]]

#text("whenever ")#mi("{1 \\leq j \\leq k}")#text(" and ")#mi("{t_1+\\dots+t_{j-1}+t_{j+1}+\\dots+t_k > 1}")#text(", and the ratio ")#metadata(none) <tao-2f04a79ef13b95c1f6a2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\frac{\\sum_{j=1}^k J_k^{(j)}(F)}{I_k(F)}")]]

#text("is larger than ")#mi("{\\frac{2m}{\\theta}}")#text(", where")

#align(center)[#tao-fit-display[#mitex("I_k(F) := \\int_R F(t_1,\\dots,t_k)^2\\ dt_1 \\dots dt_k")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("J_k^{(j)}(F) := \\int_{{\\cal R}_{k-1}} (\\int_0^{1/\\theta} F(t_1,\\dots,t_k)\\ dt_j)^2 dt_1 \\dots dt_{j-1} dt_{j+1} \\dots dt_k")]]

#text("then ")#mi("{DHL[k,m+1]}")#text(" holds. (To equate these two formulations, it is convenient to assume that ")#mi("{R}")#text(" is a downset, in the sense that whenever ")#mi("{(t_1,\\dots,t_k) \\in R}")#text(", the entire box ")#mi("{[0,t_1] \\times \\dots \\times [0,t_k]}")#text(" lie in ")#mi("{R}")#text(", but one can easily enlarge ")#mi("{R}")#text(" to be a downset without destroying the containment of ")#mi("{R+R}")#text(" in the non-convex region ")#link(<tao-c697d2981bf416569a16>)[#text("(1)")]#text(".) One initially requires ")#mi("{F}")#text(" to be smooth, but a limiting argument allows one to relax to bounded measurable ")#mi("{F}")#text(". (To approximate a rough ")#mi("{F}")#text(" by a smooth ")#mi("{F}")#text(" while retaining the required moment conditions, one can first apply a slight dilation and translation so that the marginals of ")#mi("{F}")#text(" are supported on a slightly smaller version of the simplex ")#mi("{{\\cal R}_{k-1}}")#text(", and then convolve by a smooth approximation to the identity to make ")#mi("{F}")#text(" smooth, while keeping the marginals supported on ")#mi("{{\\cal R}_{k-1}}")#text(".)")

#text("We are now exploring various choices of ")#mi("{R}")#text(" to work with, including the prism")

#align(center)[#tao-fit-display[#mitex("\\{ (t_1,\\dots,t_k) \\in [0,1/\\theta]^k: t_1+\\dots+t_{k-1} \\leq 1 \\}")]]

#text("and the symmetric region")

#align(center)[#tao-fit-display[#mitex("\\{ (t_1,\\dots,t_k) \\in [0,1/\\theta]^k: t_1+\\dots+t_k \\leq \\frac{k}{k-1} \\}.")]]

#text("By suitably subdividing these regions into polytopes, and working with piecewise polynomial functions ")#mi("{F}")#text(" that are polynomial of a specified degree on each subpolytope, one can phrase the problem of optimising ")#link(<tao-2f04a79ef13b95c1f6a2>)[#text("(4)")]#text(" as a quadratic program, which we have managed to work with for ")#mi("{k=3}")#text(". Extending this program to ")#mi("{k=4}")#text(", there is a decent chance that we will be able to obtain ")#mi("{DHL[4,2]}")#text(" on EH.")

#text("We have also been able to numerically optimise ")#mi("{M_k}")#text(" quite accurately for medium values of ")#mi("{k}")#text(" (e.g. ")#mi("{k \\sim 50}")#text("), which has led to improved values of ")#mi("{H_1}")#text(" without EH. For large ")#mi("{k}")#text(", we now also have the asymptotic ")#mi("{M_k=\\log k - O(1)}")#text(" with explicit error terms (details ")#link("http://michaelnielsen.org/polymath1/index.php?title=Selberg_sieve_variational_problem#Lower_bounds")[#text("here")]#text(") which have allowed us to slightly improve the ")#mi("{m=2}")#text(" numerology, and also to get explicit ")#mi("{m=3}")#text(" numerology for the first time.")

#metadata(none) <tao-ac5a1108cbaa25540749>

#heading(level: 1)[#strong[#text(" — 1. More details on the relaxed support conditions — ")]]

#text("Fix ")#mi("{R}")#text(" as above, which we take to be a polytope that is also a downset, and let ")#mi("{{\\cal F}}")#text(" be the class of smooth functions ")#mi("{f}")#text(", not identically zero, supported on ")#mi("{R}")#text(" whose restrictions ")#link(<tao-d594a7cbe7414e044ad5>)[#text("(2)")]#text(" are all supported on ")#mi("{{\\cal R}_{k-1}}")#text(". We need a technical analysis result, that any ")#mi("{f}")#text(" in ")#mi("{{\\cal F}}")#text(" can be approximated by a finite linear combination ")#mi("{\\tilde f}")#text(" of tensor products ")#mi("{f_1(t_1) \\dots f_k(t_k)}")#text(", each of which supported in a cube in the interior of ")#mi("{R}")#text(" of arbitrarily small specified side length, such that the ratio ")#link(<tao-1348beb03ed9067bd422>)[#text("(3)")]#text(" for ")#mi("{f}")#text(" and ")#mi("{\\tilde f}")#text(" are arbitrary close. This is almost a standard application of Stone-Weierstrass, but the vanishing properties of ")#mi("{f}")#text(" mean that some care has to be taken.")

#text("First, by using a slight dilation to shrink ")#mi("{f}")#text(" a bit, we can assume that ")#mi("{f}")#text(" is supported on ")#mi("{(1-\\epsilon) \\cdot R}")#text(" for some small ")#mi("{\\epsilon>0}")#text(", and all the restrictions ")#link(<tao-d594a7cbe7414e044ad5>)[#text("(2)")]#text(" supported on ")#mi("{(1-\\epsilon)\\cdot {\\cal R}_{k-1}}")#text(", while only modifying ")#link(<tao-2f04a79ef13b95c1f6a2>)[#text("(4)")]#text(" by an epsilon. We extend ")#mi("{f}")#text(" from ")#mi("{[0,\\infty)^k}")#text(" to ")#mi("{{\\bf R}^k}")#text(" by setting")

#align(center)[#tao-fit-display[#mitex("f(t_1,\\dots,t_k):= f(\\max(t_1,0),\\dots,\\max(t_k,0));")]]

#mi("{f}")#text(" is now Lipschitz and piecewise smooth instead of smooth. Applying a translation (and then truncating back to ")#mi("{[0,+\\infty)^k}")#text(", we can keep ")#mi("{f}")#text(" supported in ")#mi("{(1-\\frac{\\epsilon}{2}) \\cdot R}")#text(" while also vanishing in a neighbourhood of the regions ")#metadata(none) <tao-67f047db155161e99851>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\{ (t_1,\\dots,t_{j-1},0,t_{j+1},\\dots,t_k): \\sum_{i \\neq j} t_i \\geq 1 \\}")]]

#text("for each ")#mi("{j}")#text(". This does not affect ")#link(<tao-1348beb03ed9067bd422>)[#text("(3)")]#text(", but ")#mi("{f}")#text(" is now piecewise smooth and Lipschitz rather than smooth. However, by convolving with an appropriate approximation to the identity, we can make ")#mi("{f}")#text(" smooth again, while still supported in a slightly smaller version of ")#mi("{R}")#text(" obeying the above-mentioned vanishing property. By using the Lebesgue differentiation theorem one can show that ")#link(<tao-1348beb03ed9067bd422>)[#text("(3)")]#text(" is almost unaffected by this if we make the approximation to the identity sufficiently narrow. We can then smoothly partition ")#mi("{f}")#text(" into smooth functions supported on small cubes, each contained in ")#mi("{R}")#text(" and avoiding the regions ")#link(<tao-67f047db155161e99851>)[#text("(5)")]#text(" even after a slight dilation, and then by using Fourier series one can approximate each such component of ")#mi("{f}")#text(" by a finite combination of tensor products of smooth functions, that are still supported in ")#mi("{R}")#text(" and avoiding ")#link(<tao-67f047db155161e99851>)[#text("(5)")]#text(", and the claim follows.")

#text("From all this (and the fact that the property of ")#link(<tao-1348beb03ed9067bd422>)[#text("(3)")]#text(" being larger than ")#mi("{\\frac{2m}{\\theta}}")#text(" is an open condition) we may assume that ")#mi("{f}")#text(" is a finite sum of tensor products ")#mi("{f_i}")#text(" supported on small cubes in ")#mi("{R}")#text(" avoiding ")#link(<tao-67f047db155161e99851>)[#text("(5)")]#text(". For the GPY argument to work (as laid out in ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/")[#text("this previous post")]#text("), we need the asymptotics")

#align(center)[#tao-fit-display[#mitex("\\sum_{x\\leq n \\leq 2x: n = b\\ (W)} \\nu(n) = (\\alpha_{f,f}+o(1)) B\\frac{x}{W}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sum_{x\\leq n \\leq 2x: n = b\\ (W)} \\nu(n) \\theta(n+h_j) = (\\beta_{j,f,f}+o(1)) B\\frac{x}{W} \\log R")]]

#text("to hold, where")

#tao-aligned(keep: true)[


#tao-math("B  & := (\\frac{W}{\\phi(W)})^k \\frac{1}{\\log^k R}", block: true)



#tao-math("\\alpha_{f,f}  & = \\int_{{\\cal R}_k} f_{1,\\dots,k}^2(t_1,\\dots,t_k)\\ dt_1 \\dots dt_k", block: true)



#tao-math("\\beta_{j,f,f}  & := \\int_{{\\cal R}_{k-1}} f_{1,\\dots,j-1,j+1,\\dots,k}^2(t_1,\\dots,t_{j-1},0,t_{j+1},\\dots,t_k)", block: true)
]

#align(center)[#tao-fit-display[#mitex("dt_1 \\dots dt_{j-1} dt_{j+1} \\dots dt_k.")]]

#text("We can generalise these bounds slightly to the depolarised bounds ")#metadata(none) <tao-1b112ee7d79cd37d93b3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{x\\leq n \\leq 2x: n = b\\ (W)} \\sigma_{f,k}(n) \\sigma_{f^{\\prime},k}(n) = (\\alpha_{f,f^{\\prime}}+o(1)) B\\frac{x}{W}")]]

#text("and ")#metadata(none) <tao-721e9f2ae20a050bcf10>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\sum_{x\\leq n \\leq 2x: n = b\\ (W)} \\sigma_{f,k}(n) \\sigma_{f^{\\prime},k}(n) \\theta(n+h_j) = (\\beta_{j,f,f^{\\prime}}+o(1)) B\\frac{x}{W} \\log R")]]

#text("to hold, where")

#tao-aligned(keep: true)[


#tao-math("\\alpha_{f,f^{\\prime}}  & = \\int_{{\\cal R}_k} f_{1,\\dots,k}(t_1,\\dots,t_k) f^{\\prime}_{1,\\dots,k}(t_1,\\dots,t_k)\\ dt_1 \\dots dt_k", block: true)



#tao-math("\\beta_{j,f,f^{\\prime}}  & := \\int_{{\\cal R}_{k-1}} f_{1,\\dots,j-1,j+1,\\dots,k}(t_1,\\dots,t_{j-1},0,t_{j+1},\\dots,t_k)", block: true)
]

#align(center)[#tao-fit-display[#mitex("f^{\\prime}_{1,\\dots,j-1,j+1,\\dots,k}(t_1,\\dots,t_{j-1},0,t_{j+1},\\dots,t_k)\\ dt_1 \\dots dt_{j-1} dt_{j+1} \\dots dt_k.")]]

#text("and ")#mi("{f,f^{\\prime}}")#text(" are linear combinations of smooth tensor products supported on small cubes in ")#mi("{R}")#text(". By linearity, we may assume that ")#mi("{f,f^{\\prime}}")#text(" are each supported on a small cube ")#mi("{Q,Q^{\\prime}}")#text(" respectively.")

#text("For the sums ")#link(<tao-721e9f2ae20a050bcf10>)[#text("(7)")]#text(", the “")#mi("{\\beta}")#text("” calculations in ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/")[#text("the previous blog post")]#text(" already suffice, because ")#mi("{Q+Q^{\\prime}}")#text(" avoids the ")#link(<tao-67f047db155161e99851>)[#text("(5)")]#text(" and so divisors appearing in ")#mi("{\\sigma_f(n) \\sigma_{f^{\\prime}}(n)}")#text(" have magnitude at most ")#mi("{R}")#text(" (or ")#mi("{x^{-\\epsilon} R}")#text(" for some small ")#mi("{\\epsilon>0}")#text("). For ")#link(<tao-1b112ee7d79cd37d93b3>)[#text("(6)")]#text(", a compactness argument and the inclusion of ")#mi("{R+R}")#text(" in ")#link(<tao-c697d2981bf416569a16>)[#text("(1)")]#text(" shows that if the cubes are small enough, we have either")

#align(center)[#tao-fit-display[#mitex("Q+Q^{\\prime} \\subset (\\frac{2}{\\theta}-\\epsilon) \\cdot {\\cal R}_k")]]

#text("or")

#tao-aligned(keep: true)[


#tao-math("Q+Q^{\\prime}  & \\subset \\{ (t_1,\\dots,t_k)\\in [0,\\frac{2}{\\theta}-\\epsilon]^k:", block: true)



#tao-math("t_1+\\dots+t_{j-1}+t_{j+1}+\\dots+t_k  & \\leq 2-\\epsilon \\}", block: true)
]

#text("for some ")#mi("{j}")#text(" and some ")#mi("{\\epsilon>0}")#text(". In the former case, we can compute much as in the “")#mi("{\\alpha}")#text("” calculation in ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/")[#text("the previous blog post")]#text(". Now suppose that we are in the latter case. Without loss of generality let us take ")#mi("{j=k}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("Q+Q^{\\prime} \\subset \\{ (t_1,\\dots,t_k)\\in [0,\\frac{2}{\\theta}-\\epsilon]^k: t_1+\\dots+t_{k-1} \\leq 2-\\epsilon \\}.")]]

#text("If we use the tensor product structure to write")

#align(center)[#tao-fit-display[#mitex("f(t_1,\\dots,t_{k}) = \\tilde f(t_1,\\dots,t_{k-1}) f_k(t_k)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("f^{\\prime}(t_1,\\dots,t_{k}) = \\tilde f^{\\prime}(t_1,\\dots,t_{k-1}) f^{\\prime}_k(t_k)")]]

#text("for smooth ")#mi("{\\tilde f, f_k, \\tilde f^{\\prime}, f^{\\prime}_k}")#text(" supported in appropriate cubes or intervals, we can refactor")

#align(center)[#tao-fit-display[#mitex("\\sum_{x\\leq n \\leq 2x: n = b\\ (W)} \\sigma_f(n) \\sigma_{f^{\\prime}}(n) =")]]

#metadata(none) <tao-695bea96672a2ede031d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\sum_{x\\leq n \\leq 2x: n = b\\ (W)} \\sigma_{\\tilde f,k-1}(n) \\sigma_{\\tilde f^{\\prime},k-1}(n) \\tilde \\theta_{f_k,\\tilde f_k}(n+h_k)")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\tilde \\theta_{f_k,\\tilde f_k}(n) := (\\sum_{d|n} \\mu(d) f_k(\\frac{\\log d}{\\log R})) (\\sum_{d^{\\prime}|n} \\mu(d^{\\prime}) f^{\\prime}_k(\\frac{\\log d^{\\prime}}{\\log R})).")]]

#text("One can write ")#mi("{\\tilde \\theta_{f_k,\\tilde f_k}}")#text(" as a Dirichlet convolution ")#mi("{\\gamma*1}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\gamma(n) := \\sum_{d,d^{\\prime}: [d,d^{\\prime}] = n} \\mu(d) \\mu(d^{\\prime}) f_k(\\frac{\\log d}{\\log R}) f^{\\prime}_k( \\frac{\\log d^{\\prime}}{\\log R} ).")]]

#text("As ")#mi("{Q+Q^{\\prime}}")#text(" has ")#mi("{t_k}")#text(" component in ")#mi("{[0,\\frac{2}{\\theta}-\\epsilon]}")#text(", ")#mi("{\\gamma}")#text(" is supported on values of ")#mi("{n}")#text(" that are at most ")#mi("{R^{\\frac{2}{\\theta}-\\epsilon}= x^{1-\\epsilon \\theta/2}}")#text(". Assuming an Elliott-Halberstam conjecture ")#mi("{EH[\\theta]}")#text(" for such Dirichlet convolutions, we see that ")#mi("{\\tilde \\theta_{f_k,\\tilde f_k}(n)}")#text(" is well-distributed in most residue classes of modulus up to ")#mi("{x^\\theta = R^2}")#text(", and one can then obtain asymptotics for ")#link(<tao-695bea96672a2ede031d>)[#text("(8)")]#text(" by a computation very similar to that used to establish ")#link(<tao-721e9f2ae20a050bcf10>)[#text("(7)")]#text("; we omit the details.")

#heading(level: 1)[#text("Comments (149)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1e5a1f8fedf06dc288a89076e2da2ef431c2a3d2382d8380d5e54d12189c87e-ed01907680b2daad77e4a6aee1babf0bb370efeae586d3d3cd26d5bb51b23604.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Derek O.")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258024")[#strong[#text("Derek O.")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("As an amateur mathematician and number theorist, I’ve been keeping up with this project since May. I know Tao states the possibilities for H_1 in the very beginning; however, I just want to confirm. What’s the lowest unconditional bound we have on H_1? I know Maynard got it down to 600 but since then, I’ve seen 576, 330, 300, and 272. I know that H_1 is 16 if we assume EH. But under no assumptions, what’s the lowest H_1 we have? Thanks in advance for your response!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258042")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("We are currently at 272 under no assumptions other than my program is computing correctly. (I would place the accuracy very high, because even after working with a completely new basis, I still get the same results.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d62cc495739d57c707a5605bfbbe47d8850217cccc8444136ea1793fa3dc38b4-3c12148a12ed29af8284811eb104bf992392f47d631f55c40850feee831ab232.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klaus Lange")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258155")[#strong[#text("Klaus Lange")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("If I understand right, under EH it seems like H_1 = 8.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258028")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("A couple of small observations, relating to the ")#mi("\\theta = 1")#text(" case but possibly generalisable to ")#mi("\\theta < 1")#text(", about the search for the ideal R:")

#text("1) When ")#mi("k > 3")#text(", the “Pace polytope” (the subset of the unit cube in which ")#mi("{\\sum_i t_i} \\leq k/k-1")#text(") is strictly smaller than the prism in which ")#mi("{\\sum_{i < k} t_i} \\leq 1")#text(". I think all other polytopes defined by slicing the cube through (1/k-1,1/k-1…) also are.")

#text("2) No admissible R can be created by adding material to the prism. This can be seen for any candidate point t = (t_1,..t_k) where ")#mi("{\\sum_{i < k} t_i} > 1")#text(" by considering the point u = (u_1,..u_k) where u_k = 1 and the other ")#mi("u_i")#text(" are ")#mi("t_i / {\\sum_{i < k} t_i}")#text(" : the midpoint between t and u does not lie within the union-of-prisms, so t+u fails the sumset constraint.")

#text("This seems to suggest, though clearly it does not rigorously prove, that the prism is the optimal R’’ for ")#mi("k > 3")#text(" (assuming the Selberg sieve). I wonder if this can be rigorised.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258032")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("It seems that there is a typo in the definition of ")#mi("\\mathcal R^{\\prime}_k")#text(" above.")

#emph[#text("[Reformatted -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258052")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("This definition is somewhat different from that in the wiki page (with the additional constraint on ")#mi("t_j")#text(" to be the minimal one.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258053")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("The two are equivalent: requiring that ")#mi("t_1+\\ldots+t_{j-1}+t_{j+1}+\\ldots+t_k \\leq 1")#text(" for all ")#mi("1 \\leq j \\leq k")#text(" is equivalent to requiring that ")#mi("t_1+\\ldots+t_k \\leq 1 + \\min(t_1,\\ldots,t_k)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258057")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("Thanks! I understand (it is somewhat confusing.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258062")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("Dear Terry, when you say the ")#mi("H_1")#text(" bound will hopefully fall to ")#mi("8")#text(" soon, do you mean it under Elliott-Halberstam, or unconditionally?")

#emph[#text("[Um, the former; I’ve added a clarification. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258077")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("Thanks! Also, there is a typo in the formula for ")#mi("\\sigma_{f,k}(n)")#text(": the argument of ")#mi("f")#text(" should be ")#mi("k")#text(" fractions, not just one.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258120")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("If you use “\\dots” instead of “\\ldots”, you will (automatically) get the correct placement of the ellipsis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258233")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("In advance of a computed value for M”_4 (let alone higher M”_k), and indeed while there remains decided uncertainty as to whether current ideas can feasibly support calculation of M”_k for double-digit k, I was just looking at the data for M’_k, and I noticed an intriguing detail – the current lower and upper bounds on M’_k do not diverge, being (albeit only slightly) closer for k=5 than for k=4. I’m presuming that combinatorial explosions prevent James’s or Pace’s code from deriving M’_k (even for small d) for k in the range of current interest for H_1 on BV, but, in the recent spirit of examining numerical trends in order to guess key values to investigate, I’m wondering whether extrapolation from single-digit k could still be a cheap route to predicting (and then, of course, hopefully confirming) a k less than 54 for which M’_k exceeds 4.. The starting-point would be to calculate just a few more values of M’_k, for k = 6, 7 etc, and see whether the sequence of shortfalls relative to the corresponding upper bounds fits some simple curve or other tightly enough (and, of course, converges fast enough) to lead to a confident (though approximate) prediction of the threshold k. James, Pace: I’m unclear as to how far you can push your M’_k computations in feasible CPU times. What can you tell us?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258246")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("It seems that in (1), a union with ")#mi("(2 / \\theta) \\mathcal R_k")#text(" (which appears in the wiki page) is missing.")

#emph[#text("[Ah, I had forgotten about that additional region; I’ve modified the argument in the post to accomodate it. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258255")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("Therefore we can replace the symmetric region ")#mi("R")#text(" above by its union with ")#mi("(1 / \\theta) \\mathcal R_k")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258264")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("Good point! In particular, in the Bombieri-Vinogradov case ")#mi("\\theta=1/2")#text(", one can take ")#mi("R = 2 {\\cal R}_k")#text(", so the problem is now to maximise the usual Rayleigh quotient over functions on ")#mi("2 {\\cal R}_k")#text(" whose marginals are supported on ")#mi("{\\cal R}_{k-1}")#text(". Note that ")#mi("2 {\\cal R}_k")#text(" has ")#mi("2^k")#text(" the volume of ")#mi("{\\cal R}_k")#text(", so in principle we have gained a huge amount of extra room to work with here (though even in the best case in which marginal conditions are ignored, ")#mi("M_k")#text(" only improves by a factor of 2).")

#text("One nice feature of this problem is that we can in principle attack it without subdividing the polytope, as follows. Observe from the fundamental theorem of calculus that if ")#mi("f")#text(" is a polynomial on ")#mi("2 {\\cal R}_k")#text(" that vanishes to order k on the slanted boundary ")#mi("t_1+\\ldots+t_k=2")#text(" and to first order at the remaining boundary (i.e. it is a multiple of ")#mi("(2-e_1)^k e_k = (2-t_1-\\ldots-t_k)^k t_1 \\ldots t_k")#text("), then the k^th partial derivative ")#mi("f_{1,\\ldots,k}")#text(" has vanishing marginals. Thus, we can work with functions F on ")#mi("2{\\cal R}_k")#text(" of the form")

#mi("F = F_0 1_{{\\cal R}_k} + (f(2-e_1)^k e_k)_{1,\\ldots,k}")

#text("for arbitrary smooth ")#mi("F_0,f")#text(", and the vanishing marginal property will be automatically satisfied (indeed the marginals for F are just the marginals for ")#mi("F_0 1_{{\\cal R}_k}")#text("). One can then try to optimise this numerically by selecting ")#mi("F_0,f")#text(" from symmetric polynomials of bounded degree as before; I’m not sure that this covers all possible F, so it may not give the optimal M”_k, but it should at least beat M_k, and might be computable for medium values of k, say k=50, allowing us to improve the current value of k=55 that we have on Bombieri-Vinogradov.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258282")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("I’m unfamiliar with the notation ")#mi("f_{1,\\ldots,k}")#text(". Is this just the partial derivative of ")#mi("f")#text(" with respect to each of the variables ")#mi("t_1,\\ldots, t_k")#text("?")

#text("Also, do you not need an indicator function on the second summand (in your decomposition of ")#mi("F")#text("), so it is only supported on ")#mi("2\\mathcal{R}_k")#text("? [I imagine the answer is that it was implicitly assumed that ")#mi("F")#text(" is only supported on ")#mi("2\\mathcal{R}_k")#text(", but I just want to double-check.]")

#emph[#text("[Yes to both -T.]")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258324")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2013")])]

#text("I think that this nice parametrization of ")#mi("F")#text(" with the vanishing marginals property should considerably decrease the computational complexity.")#linebreak()#text(" It seems however, that for real analytic (in particular, polynomial) ")#mi("F_0")#text(" on ")#mi("2 \\mathcal  R_k")#text(", any marginal which vanish outside ")#mi("\\mathcal R_{k-1}")#text(" should vanish identically (which is more than required.)")

#text("A possible generalization is to dissect the outside of ")#mi("\\mathcal R_k")#text(" into a small number of polytopes and try to find similar parametrizations (perhaps with additional small number of linear constraints) for the vanishing marginals on them.")

#text("Perhaps it is possible to estimate (by similar upper and lowers bounds) the resulting ")#mi("M^{\\prime\\prime}_k")#text(" (which may improve the current asymptotic bounds for ")#mi("H_m")#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258319")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2013")])]

#text("Might it be worth adding a column to the table at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Selberg_sieve_variational_problem")[#text("http://michaelnielsen.org/polymath1/index.php?title=Selberg_sieve_variational_problem")]#text(" to distinguish the M” bounds for theta = 1 versus theta = 1/2 ? It currently seems a little misleading that k seems to need to reach 20 or so in order for the upper bound on M”_k to reach 4, whereas when theta = 1/2 the threshold k would be only 6. Or can a better upper bound on M”_k,1/2 be given now, since the current one was based on R”_k being the prism?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258360")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2013")])]

#text("Interestingly, condition (2) above does not include the slanted boundary vanishing condition.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258361")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2013")])]

#text("The function F need not vanish on the slanted boundary, but in order for ")#mi("f_{1,\\dots,k}")#text(" to have vanishing marginals, one needs f to vanish to order k at this boundary (but this does not give any vanishing of ")#mi("f_{1,\\dots,k}")#text(" at this boundary).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258409")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2013")])]

#text("It seems that the only difficulty in applying this method is the choice of a basis of symmetric polynomials such that the coefficients of the two matrices needed for the optimization program should be evaluated efficiently (this could be difficult because of the repeated partial derivatives – which for medium-sized k can produce many monomials from a single one.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258463")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2013")])]

#text("I’m a little confused. In the decomposition above, take ")#mi("F_0=0,f=1")#text(". Thus ")#mi("F=((2-e_1)^k)e_k)_{1,\\ldots, k}1_{2\\mathcal{R}_k}")#text(". For simplicity, take ")#mi("k=2")#text(" (but any ")#mi("k\\geq 2")#text(" will do); in this case we have ")#mi("F=(4-8t_1-8t_2+8t_1 t_2+3t_1^2+3t_2^2)1_{2\\mathcal{R}_2}")#text(". Thus, ")#mi("\\int_{0}^{2} F(t_1,t_2)\\ dt_1=6t_2^2 1_{2\\mathcal{R}_1}")#text(", which is not merely supported on ")#mi("\\mathcal{R}_{1}")#text(", hence does not have the vanishing marginal condition. I’m probably just missing something simple here.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258466")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2013")])]

#text("One has to integrate ")#mi("t_1")#text(" from 0 to ")#mi("2-t_2")#text(", rather than from 0 to 2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258471")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2013")])]

#text("I just figured out where I went wrong, but you beat me to the punch. Thanks for the answer. (Another way to put it is that one can integrate from 0 to 2, but then the integral has to break into two pieces, due to presence of the indicator function.)")

#text("It appears that this new term ")#mi("F^{\\prime}=F-F_0:=(f(2-e_1)^k e_k)_{1,\\ldots,k} 1_{2\\mathcal{R}_k}")#text(" is making no contribution at all the the ")#mi("J_k^{(m)}")#text(" integrals, so the hope is to somehow use it to make the ")#mi("I_k")#text(" integral smaller.")

#text("Write ")#mi("F^{\\prime}=F_1+F_2")#text(" where ")#mi("F_1")#text(" is supported on ")#mi("\\mathcal{R}_k")#text(" and ")#mi("F_2")#text(" is supported on ")#mi("2\\mathcal{R}_k\\setminus \\mathcal{R}_k")#text(". Then ")#mi("F^2=(F_0+F_1)^2+F_2^2")#text(". It looks like the extra area in ")#mi("2\\mathcal{R}_{k}\\setminus \\mathcal{R}_k")#text(" is both working for and against us, because it both allows us to try and make ")#mi("F_0+F_1")#text(" small, but at the same time makes the integral of ")#mi("F_2^2")#text(" larger. I’ll try to do some computations tomorrow if I can.")

#text("If anyone has a specific ")#mi("k")#text(" they want me to look at, just post it and I’ll look tomorrow morning.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258516")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("Since no one else has suggested a specific k, I’ll go out on a limb and suggest 43 and 24, since they give H = exactly 200 and 100 respectively.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258305")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2013")])]

#text("Some further improvements to bounds on H:")

#link("http://math.mit.edu/~drew/admissible_35146_395154.txt")[#text("395,154")]#text(" for m=2 using k=35,146.")#linebreak()#text(" ")#link("http://math.mit.edu/~drew/admissible_1630680_24490410.txt")[#text("24,490,410")]#text(" for m=3 using k=1,630,680.")#linebreak()#text(" 485,825,850 for m=4 using k=25,589,558.")

#text("The last bound is obtained by taking k consecutive primes starting with 2,504,011.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258368")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2013")])]

#text("The bound for m=2 can be improved to ")#link("http://math.mit.edu/~drew/admissible_35146_395122.txt")[#text("395,122")]#text(". The bound for m=4 can be improved to 473,244,502.")

#text("The last bound comes from the (symmetric) Hensley-Richards sieve, which yields the admissible 25,589,558-tuple consisting of the primes in [2623573,236622251], their negations, and +/-1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5abba5dd562f9355e60dc4c9893442e683e37151512bafa0a62957a87138f8ac-758fe84da47080c2384192dc09d20727c346092a341b0ed9fcbbbdf425655802.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258411")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2013")])]

#text("There appears to be a precision issue with the value of k for m = 4. One can increase the precision by putting e.g. Digits := 50; on top of the maple file (the default value is 10).")

#text("For m = 2 and m = 3 I think the values are correct, although it seems that for m = 3 one can improve k to 1,628,944 by letting c := 1.0043/log(k) and T := 0.8008/log(k).")

#text("For m = 4 one can obtain k = 75,000,000 by letting c := 0.999/log(k) and T := 0.838/log(k).")

#text("For m = 5 one can similarly find k = 3,400,000,000 by taking c := 1.012/log(k) and T := 0.710/log(k).")

#text("Note that the ratios")#linebreak()#text(" ")#mi("\\displaystyle{ \\frac{3400000000}{75000000}, \\frac{75000000}{1628944}, \\frac{1628944}{35146} }")#linebreak()#text(" all lie close to the asymptotic upper bound ")#mi("\\exp(3.817)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258415")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2013")])]

#text("Thanks for catching that! I had noticed that the m=4 values of k were curiously small, but I trusted in Maple without investigating it further.")

#text("I’ve moved the enormous table to a subpage of the wiki ( ")#link("http://michaelnielsen.org/polymath1/index.php?title=Timeline_of_prime_gap_bounds")[#text("http://michaelnielsen.org/polymath1/index.php?title=Timeline_of_prime_gap_bounds")]#text(" ), leaving only the current “world records” for the main page. For anyone interested in filling in the blanks:")

#text("* to get a value of k for a given m on EH, one can run the previous Maple code (with enough digit precision, of course), with the aim of getting M_k (which in the maple code is called M0-Delta) greater than 2m. For instance, if one can get M0-Delta larger than 6, then this will be a good value of k for the m=3 EH problem. (The portion of the code relating to varpi and delta may be deleted in this case.)")

#text("* to get a value of k for a given m without EH but with Deligne, run the code as is.")

#text("* to get a value of k for a given m without EH or Deligne, replace 1080*varpi/13+ 330*delta/13 in the last line of the code with 168*varpi+48*delta.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258433")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2013")])]

#text("For m=3 under EH, it appears that with k=5511, c=0.965 and T=0.973, we get M0-Delta > 6. This then gives the bound ")#link("http://math.mit.edu/~drew/admissible_5511_52130.txt")[#text("52,130")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258451")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2013")])]

#text("For m=3 without EH or Deligne, it appears that k=2114964, c=1.00/log(k), T=0.83/log(k) works.")

#text("Hensley-Richards then gives the bound ")#link("http://math.mit.edu/~drew/admissible_2114964_33661442.txt")[#text("33,661,442")]#text(".")

#text("(also, the values for c and T given for m=3 with EH above should of course be divided by log(k)).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258515")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("The value for m=2 without EH or Deligne is still the value under just BV, I think (identical to the value for m=4 under EH); presumably it can be (slightly) reduced.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258529")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("Actually, both values can be reduced.")

#text("For m=2 without EH or Deligne we can get k=41709 using c=0.9972/log(k) and T=0.84/log(k). This gives the bound ")#link("http://math.mit.edu/~drew/admissible_41709_476322.txt")[#text("476,322")]#text(".")

#text("For m=4 with EH we can get k=41589 using c=0.9793/log(k) and T=0.94/log(k). This gives the bound ")#link("http://math.mit.edu/~drew/admissible_41589_474600.txt")[#text("474,600")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258530")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("That’s odd; I thought that any k that works for m=2N under EH should also work for m=N under BV, and a smaller k should always be achievable when we only ask to avoid EH or Deligne (except when N=1 because k is now so small). Is that not so?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258537")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("I was independently optimizing the parameters in the two cases, per Terry’s post above. I certainly don’t claim to have found the optimal values of c, T, k, so possibly there are parameter choices that give the same value of k in both cases, but I don’t think so. This doesn’t contradict what you are saying, because the maple computations are giving upper bounds on k that aren’t necessarily tight.")

#text("If this is indeed the case, it suggests that optimizing the EH case for m=2N might give slightly better bounds on k for the BV case with m=N.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258594")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("If one takes values of c,T that work for m=2N under EH, then they will automatically work for m=N under BV; the value of varpi computed will be negative, but that’s OK, BV basically is the assertion that all negative values of varpi are admissible.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258572")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("For k=2,114,964 (m=3 no EH or Deligne) we can get H down to ")#link("http://math.mit.edu/~drew/admissible_2114964_32313942.txt")[#text("32,313,942")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258599")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("Of course, this makes sense (I hadn’t actually noticed that varpi was negative), thanks for the clarification.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258457")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2013")])]

#text("For m=5 under EH it looks like k=309954, c=0.9821/log(k),T=0.95/log(k) works.")

#text("Hensley-Richards then gives the bound ")#link("http://math.mit.edu/~drew/admissible_309954_4316446.txt")[#text("4,316,466")]#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258528")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("Using a greedy sieve, the m=5 EH bound with k=309954 can be improved to ")#link("http://math.mit.edu/~drew/admissible_309954_4146936.txt")[#text("4,146,936")]#text(".")

#text("Also, the m=3 EH bound with k=5511 can be improved to ")#link("http://math.mit.edu/~drew/admissible_5511_52116.txt")[#text("52,116")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258467")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2013")])]

#text("For m=4, k can be decreased to ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi1080d13_74487363_m4.mpl")[#text("74487363")]#text(".")

#text("For m=3, k can only be decreased 1 to ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi1080d13_1628943_m3.mpl")[#text("1628943")]#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258527")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("For m=3, k=1628943 (Deligne, no EH) we can get ")#link("http://math.mit.edu/~drew/admissible_1628943_24462774.txt")[#text("24,462,774")]#text(".")

#text("For m=4, k=74487363 (Deligne, no EH) we can get 1,512,832,958 by taking the first k primes greater than k.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258568")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("There is a slight error in what I wrote above, for m=4, k=74487363 (Deligne, no EH) the bound you get by taking the first k primes greater than k is 1,512,832,950.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258518")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("It seems better to place several explanations and links to wiki pages (now appearing above the large table) above the current records in the main page.")

#emph[#text("[Explanation and links moved – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258520")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("Terry: is there a simple function of varpi and delta that gives rise to the quantities 52/283 and 4/43 in the asymptotic formulae shown in the new table?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258550")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("Ah, of course: 4*varpi / (1/4 + varpi).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258555")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("For m=4 with EH, k can be ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi1080d13_41588_m4EH.mpl")[#text("41588")]#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258569")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("With k=41588 we can get H down to ")#link("http://math.mit.edu/~drew/admissible_41588_474460.txt")[#text("474,460")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258609")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("With k=41588 we can get H down to ")#link("http://math.mit.edu/~drew/admissible_41588_474372.txt")[#text("474,372")]#text(", which is relevant to both the m=4 EH and m=2 BV cases.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258774")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2013")])]

#text("By the same token, there’s a good chance that the current m=3 value avoiding EH and Deligne can be reduced by exploring m=6 under EH.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258811")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2013")])]

#text("Yes, I actually took a look at this yesterday. But, in contrast to the m=4 EH and m=2 BV cases, the parameters k=2114964, m=3, c=1.0/log(k), T=0.83/log(k) (which surely can be optimized further) used in the BV case actually don’t give M_k > 12 and I couldn’t easily find a choice of parameters that works for the EH case with m=6 with k smaller than 2114964 (it’s a bit time consuming to check with k this large and the precision set higher, so I admittedly did not look all that hard).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258558")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("For m=5 with EH, k can be ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi1080d13_309661_m5EH.mpl")[#text("309661")]#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258570")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("With k=309661 we can get H down to ")#link("http://math.mit.edu/~drew/admissible_309661_4143140.txt")[#text("4,143,140")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258587")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("For m=4 without EH or Deligne it looks like k=")#link("http://math.mit.edu/~drew/maple_4_BV.txt")[#text("105,754,838")]#text(" works. Taking the first k primes greater than k gives the bound 2,186,561,568 on H.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258626")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("Just for the sake of filling in the last blank spot in the table, for m=5 without EH or Deligne it looks like we can get k=")#link("https://math.mit.edu/~drew/maple_5_BV.txt")[#text("5,300,000,000")]#text(".")

#text("Taking the first k primes greater than k then gives the bound 131,161,149,090 on H.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258419")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2013")])]

#text("Taking the first k primes greater than k gives the bounds 1,523,781,850")#linebreak()#text(" 82,575,303,678 on H for m=4 and m=5, respectively.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258452")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2013")])]

#text("Using Wouter’s improved k=1,628,944 for m=3 (with Deligne, no EH) the bound on H can be improved to ")#link("http://math.mit.edu/~drew/admissible_1628944_24462790.txt")[#text("24,462,790")]#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258581")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("I thought I’d give a quick update on the computation for ")#mi("M_4^{\\prime\\prime}")#text(" using the prism ")#mi("\\{x+y+z \\leq 1,w \\leq 1\\}")#text(", I get the bound ")#mi("M^{\\prime\\prime}_4 > 1.951")#text(", which is only a modest improvement on the previous bound ")#mi("M^{\\prime}_4>1.937")#text(".")

#text("It is possible that one needs to take rather higher degree approximations, since the vanishing conditions severely restrict the number of degrees of freedom of small degree polynomials (with degree 5, they reduce about 200 degrees of freedom for the coefficients of polynomials outside of ")#mi("R_4^{\\prime}")#text(" to only 20, and its much more restrictive for degree 3 or 4). There are currently some RAM issues using higher degree polynomials, however. There’s also a pretty good chance there are typos in my code since the decompositions are in quite a few regions, although the results seem to pass some simple sanity checks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258586")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("Many thanks James. Is your code easily modifiable to explore the theta = 1/2 case, and in particular the double-size simplex that has just arisen as an option in that setting? I note that it is larger than the prism even when k=3, so the possibilities are most tantalising.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258590")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("To clarify: I realise that when k = 4 we are only interested in theta = 1, but since the double-size simplex so hugely expands R in the BV setting I’m thinking that the “low k” and “medium k” analyses are now effectively merging, such that your and Pace’s computational approaches will increasingly synergise.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258596")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("I think one of the differences between our computations is that unless we come up with a better characterization of the disappearing marginal conditions, my decompositions will be restricted to the form Terry came up with above [to avoid having to break the simplex into an enormous number of subcomponents], whereas it appears that James can take advantage of all degrees of freedom. So it still may be worthwhile to see how the numerics behave for small ")#mi("k")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258593")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("James, did you try the ")#mi("k=3")#text(" case for the simplex ")#mi("\\{(x,y,z)\\in [0,1]^3\\ :\\ x+y+z\\leq 4/3 \\}")#text("? What happens as the degree increases in the simpler ")#mi("k=3")#text(" case? Do you run into RAM issues as quickly?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258621")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("I haven’t got round to that yet, but I don’t think there should be the same issues in the ")#mi("k=3")#text(" case, since I’d guess it should work more-or-less like the prism.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-259660")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2013")])]

#text("3/2 not 4/3 ! (You’ll almost certainly have caught that, but I guess it can’t hurt to make sure.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258603")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("Also, James, how does M”_4 vary with degree? The recent analysis of M_k (with medium k) in the BV setting suggests that one might be able to use extrapolation to get a pretty good feel for the magnitude of the benefit for M”_4 from increasing d. Maybe that’s overoptimistic if the furthest you’ve been able to go in this case is d=5, but it can’t hurt to have a look at the d<5 values for a speculative trend.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258623")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("I think its difficult to extrapolate much because of the vanishing constraints. If I remember correctly, when the degree was 2 or less then the polynomials outside of ")#mi("R_k^{\\prime}")#text(" had to just be 0. When the degree was 3 there was only one degree of freedom, and it was only when the degree was 4 that one was really able to overcome the constraints and have enough flexibility to really get an improvement. (By comparison, the polynomial approximations on the region ")#mi("R_k^{\\prime}")#text(" seem to converge quickly, and one can guess quite easily what we might expect here)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258608")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("That’s slightly disappointing, but at least it is still progress. (Though the k=4 problem is beginning to feel like a real-life Zeno’s paradox, in that we keep halving the distance to the goal without actually reaching it…)")

#text("I was trying to see how much this extra room (especially in the BV regime ")#mi("\\theta=1/2")#text(") gives us in the asymptotic analysis for large m, but thus far the gains I could get in ")#mi("M_k")#text(" were exponentially small in k, which is perhaps consistent with the degradation we are experiencing as we pass from k=3 to k=4.")

#text("Actually this reminds me of your earlier idea to try to compute ")#mi("{\\bf P}( n+h_1,\\ldots,n+h_k \\text{ all composite})")#text(" as an additional term that can essentially be added on top of the M”_k quantity; roughly speaking, we win (in the m=1 case) when")

#mi("M^{\\prime\\prime}_k + \\frac{2}{\\theta} {\\bf P}( n+h_1,\\ldots,n+h_k \\text{ all composite}) > \\frac{2}{\\theta}.")

#text("Previously, I had thought this trick was not useful in the EH setting, but now that we have this additional room beyond ")#mi("{\\cal R}_k")#text(" to play with, and it’s not proving to be super-useful in directly improving M_k, one could perhaps “borrow” some of this room to instead get some nontrivial lower bound on ")#mi("{\\bf P}( n+h_1,\\ldots,n+h_k \\text{ all composite})")#text(". This is another quantity that is likely to decay exponentially in k, but it could possibly be enough, combined with everything else, to push us over the top. (But there is a tradeoff; in order to get a nontrivial lower bound for this quantity, one has to retract the support of F to be a bit away from the slanted boundaries of R.)")

#text("I’m not sure how to best compute this quantity though, and the optimisation could be tricky (it won’t be a simple quadratic program any more). I guess we still have some simpler things to try right now (switching to a different polytope, or increasing the degree), so maybe we can wait until the other ideas are exhausted before taking a harder look at this one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258610")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("A variant of the above idea is to modify the Selberg sieve ")#mi("\\nu(n)")#text(" combinatorially to remove small prime factors, e.g. by multiplying it with a Brun sieve, say")

#mi("\\nu(n) (1 - \\sum_{p<z} 1_{p|n} + \\sum_{p<q<z} 1_{pq|n})")

#text("where ")#mi("z = x^\\varepsilon")#text(" is a small power of x. But then one has to keep the support of F at distance ")#mi("2\\varepsilon")#text(" or so away from the slanted boundary of R, so it's not clear that this is a win. (But combinatorial sieves can perform slightly better than Selberg sieves when one is sifting very small primes, so there is some hope here.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258622")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("The two choices for ")#mi("R")#text(" above should be replaced by their corresponding unions with ")#mi("(1/ \\theta) \\mathcal R_k")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258628")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("Unfortunately it’s a bit more complicated than this, due to non-convexity: the condition is that")

#mi("R+R \\subset \\bigcup_{j=1}^k \\{ t_1+\\ldots+t_{j-1}+t_{j+1}+\\ldots+t_k \\leq 2; t_j \\leq 2/\\theta \\} \\cup \\frac{2}{\\theta} {\\cal R}_k")

#text("but one cannot simply take R to be the union of, say, the prism ")#mi("\\{ t_1+\\ldots+t_{k-1} \\leq 1; t_k \\leq 1/\\theta \\}")#text(" and the simplex ")#mi("\\frac{1}{\\theta} {\\cal R}_k")#text(", because of the cross terms r+r’ where r lies in the prism and r’ lies in the simplex.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258638")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("Right. Generalising my earlier comment about the impossibility to add to the prism when theta = 1 (which is still appearing at the very bottom of the page, presumably as a side-effect of Terry’s kind repair of my broken LaTeX): the only way that a non-convex polytope can work is if the half-size version of any convex subregion of it, when translated half-way towards any point in it that is not in that subregion, always lies within the half-size version of the polytope Terry describes for R+R. That’s a very onerous criterion, which I’m not sure can ever hold for an R that is not itself contained within an admissible convex R.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258637")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("I’m recording a comment which is not directly helpful for the immediate problems at hand, but might be useful later:")

#text("For the non-EH cases, in which ")#mi("\\theta")#text(" is close to 1/2, it may be possible to enlarge the region that R+R can range in a little bit more (although it is beginning to appear that such enlargements do not offer a huge amount of gain in the large k case). There are at least two ways to squeeze a bit of further improvement. Firstly, an inspection of the argument in the blog post shows that for the purposes of determining this region, we do not need the EH hypothesis ")#mi("EH[\\theta]")#text(" for arbitrary Dirichlet convolutions ")#mi("\\alpha \\ast \\beta")#text(", but rather for convolutions of the form ")#mi("\\alpha \\ast 1")#text(". Such sums are better behaved than the “Type I/II/III” sums considered in Polymath8a, and it is likely that we can improve the numerology a bit here, which would correspond to adding some additional space to the R+R region (but unfortunately does not improve the support condition on the marginals, as this requires EH for the von Mangoldt function).")

#text("Another possible gain comes from trying to get non-trivial estimates on expressions such as")

#mi("\\sum_{d_1} \\ldots \\sum_{d_k} \\lambda_{d_1} \\ldots \\lambda_{d_k} (\\sum_{n \\sim x} 1_{n+h_1=0\\ (d_1), \\ldots, n+h_k = 0\\ (d_k)} - EMT)")

#text("where each ")#mi("d_i")#text(" lives in a range ")#mi("d_i \\sim x^{\\theta t_i/2}")#text(", and EMT is the expected main term (basically ")#mi("\\frac{x}{d_1 \\ldots d_k}")#text("). Currently, we can control this expression either when ")#mi("t_1+\\ldots+t_k < \\frac{2}{\\theta}")#text(" (so that ")#mi("d_1 \\ldots d_k \\leq x")#text(" and the inner sum is then easy to compute) or when ")#mi("t_1+\\ldots+t_{j-1}+t_{j+1}+\\ldots+t_k < 2")#text(" (in which case we can apply ")#mi("EH[\\theta]")#text(" to the ")#mi("d_j")#text(" divisor sum). There may however be a way to control this sum more directly, by completion of sums and then somehow eliminating the ")#mi("\\lambda_{d_j}")#text(" sieve weights, either by Cauchy-Schwarz or by using the special structure of these weights (they behave very roughly like smoothly truncated Mobius functions).")

#text("Again, this only enlarges the region that R+R is allowed to lie in,and does not improve the condition on the marginals of F, so any gain here is likely to be very modest (and only likely to be useful in the non-EH setting; it's hard for unconditional arguments such as completion of sums to compete with the consequences of the powerful EH conjecture.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64389c17250b3d319b86b3c181f3921311c9879486577f2cca707e9dd053db72-416a3091cf092305d8c97a30c1230a8dab20b23709f014fae6525265bd081ea3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hcl891017")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258797")[#strong[#text("hcl891017")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2013")])]

#text("Reblogged this on ")#link("http://hcl891017.wordpress.com/2013/12/24/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/")[#text("hcl891017's Blog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258810")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2013")])]

#text("Some further improvements to bounds on H:")

#text("Under EH:")

#text("For m=4 with k=41,588: ")#link("http://math.mit.edu/~drew/admissible_41588_474320.txt")[#text("474,320")]#text(".")#linebreak()#text(" For m=5 with k=309,661: ")#link("http://math.mit.edu/~drew/admissible_309661_4137872.txt")[#text("4,137,872")]#text(".")

#text("Without EH:")

#text("For m=3 with k=1,628,943: ")#link("http://math.mit.edu/~drew/admissible_1628943_24462654.txt")[#text("24,462,654")]#text(".")#linebreak()#text(" For m=4 with k=74,487,363: 1,497,901,734 is obtained by taking k consecutive primes beginning with 6,663,067 and ending with 1,504,564,801.")

#text("Without EH or Deligne:")

#text("For m=2 with k=41,588: 474,320 (per EH, m=4 bound above)")#linebreak()#text(" For m=3 with k=2,114,964: ")#link("http://math.mit.edu/~drew/admissible_2114964_32313878.txt")[#text("32,313,878")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-259813")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2013")])]

#text("A few more improvements under EH:")

#text("For m=4 with k=41,588: ")#link("http://math.mit.edu/~drew/admissible_41588_474296.txt")[#text("474,296")]#text(".")#linebreak()#text(" For m=5 with k=309,661: ")#link("http://math.mit.edu/~drew/admissible_309661_4137854.txt")[#text("4,137,854")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-260937")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2014")])]

#text("For k=41,588 we can bound H by ")#link("http://math.mit.edu/~drew/admissible_41588_474290.txt")[#text("474,290")]#text(". This improves both the m=4 with EH and m=2 without EH or Deligne bounds.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262665")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("Further improvement: ")#link("http://math.mit.edu/~drew/admissible_41588_474266.txt")[#text("474,266")]#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258827")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2013")])]

#text("In the current records table, is it possible to estimate the orders of the two ")#mi("o(1)")#text(" terms in the exponents? (i.e. their rates of decay for large m.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258871")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2013")])]

#text("I did some calculations and it looks like that the o(1) terms are in fact ")#mi("\\log m + O(1)")#text(", so for instance we have ")#mi("H_m \\ll m \\exp((4 - \\frac{52}{283}) m)")#text(" using Deligne. The point is that the lower bound ")#mi("M_k \\geq \\log k - O(1)")#text(" is applicable with T comparable to ")#mi("1/\\log k")#text(", which means that we can take ")#mi("\\delta")#text(" comparable to ")#mi("1/\\log k")#text(" also. Using our best MPZ estimate, this allows us to take ")#mi("\\varpi")#text(" as large as ")#mi("\\frac{13}{1080} - O(\\frac{1}{\\log k})")#text(". We win when ")#mi("M_k \\geq \\frac{m}{1/4+\\varpi}")#text("; putting this all together, it appears that k can be taken to be of size ")#mi("O( \\exp((4 - \\frac{52}{283}) m) )")#text(", which on taking the first k primes past k gives ")#mi("H_m \\ll m \\exp((4 - \\frac{52}{283}) m)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258878")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2013")])]

#text("That’s good! (I asked that because for the EH case there was no ")#mi("o(1)")#text(" term.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-259142")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2013")])]

#text("Terry, does this mean there should be refinements to your Maple code that Drew and xfxie are using to improve the world records? Since the expressions with and without EH are now equivalent (setting varpi = 1/4 in the EH case), I’m wondering whether the anomaly of sometimes obtaining lower k for m=2N under EH than for m=N without EH or Deligne will go away (or if not, why not).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-259684")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2013")])]

#text("If for some ")#mi("\\theta \\in [1/2, 1)")#text(", ")#mi("\\liminf (M^{\\prime\\prime}_{k, \\theta}/ \\log k) > 1")#text(" (for the region ")#mi("R = (1/ \\theta) \\mathcal R_k")#text("), then the current exponents in the asymptotic bounds for ")#mi("H_m")#text(" can be improved.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-259982")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2013")])]

#text("The definition of ")#mi("H_m")#text(" under the the title “current records” in the main page should be for ")#mi("m+1")#text(" primes (not “")#mi("m+1")#text(" consecutive primes”.)")#linebreak()#text(" (perhaps the modified ")#mi("H_m")#text(" for consecutive primes may also be studied here.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-259986")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2013")])]

#text("I see now my error: according to the current definition of ")#mi("H_m")#text(", it is indeed for consecutive primes!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-260200")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2013")])]

#text("In the last bullet at the beginning of the post: Maybe ")#mi("\\exp(3.817m)")#text(" should be changed to ")#mi("\\exp((4-52/283)m)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-260233")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2013")])]

#text("A simple constraints formulation for ")#mi("R = (1/ \\theta) \\mathcal R_k")#text(":")

#text("Let ")#mi("\\theta \\in [1/2, 1)")#text(". Let ")#mi("F = P")#text(" on ")#mi("\\mathcal R_k")#text(" and ")#mi("F = Q")#text(" on ")#mi("R - \\mathcal R_k")#text(" (for polynomials ")#mi("P, Q")#text(".)")

#text("Observe that if ")#mi("(t_1, ... , t_{m-1}, t_{m+1}, ..., t_k)")#text(" is outside ")#mi("\\mathcal R_{k-1}")#text(" then ")#mi("(t_1, ... ,t_k)")#text(" is outside ")#mi("\\mathcal R_k")#text(".")

#text("Therefore, the marginals vanishing constraints are (for ")#mi("m = 1, ... , k")#text(")")

#text("(1) ")#mi("\\int_0^{1/ \\theta - \\sum_{i \\neq m} t_i} Q(t_1, ... , t_k) d t_m = 0")

#text("Note that the ")#mi("k")#text(" constraints in (1) are only for the polynomial Q.")

#text("Remarks:")

#text("1. Under the restriction of ")#mi("Q")#text(" to be symmetric, only one constraint in (1) (e.g. for ")#mi("m = 1")#text(") is required.")

#text("2. In general (as seen by the above remark) the resulting constraints may be dependent.")

#text("3. Let ")#mi("G(t_1, ... ,t_k)")#text(" be a polynomial satisfying ")#mi("G_{t_1} = F")#linebreak()#text(" than the constraint for ")#mi("m=1")#text(" in (1) is")

#mi("G(1/\\theta - \\sum_{i \\neq 1} t_i, t_2, ..., t_k) = G(0, t_2, ... , t_k)")

#text("Which is equivalent to")

#mi("(1/\\theta - \\sum_i t_i) | [G(t_1, ... , t_k) - G(0, t_2, ... , t_k)]")

#text("i.e. there is a polynomial ")#mi("H(t_1, ... , t_k)")#text(" such that")

#mi("G(t_1, ... , t_k) = (1/ \\theta - \\sum_i t_i) H(t_1, ... , t_k) + G(0, t_2, ..., t_k)")

#text("Now, by taking the derivative with respect to ")#mi("t_1")#text(" we get the representation")

#text("(2) ")#mi("F = G_{t_1} = -H + (1/\\theta -\\sum_i t_i) H_{t_1}")

#text("With obvious generalization for the other values of ")#mi("m")#text(" (note that the representing polynomial ")#mi("H")#text(" is dependent on ")#mi("m")#text(" !)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-260234")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2013")])]

#text("Very interesting! But please let’s not use “H” for this purpose, given its other use here for the past many months… and the same goes for “m”…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-260304")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2013")])]

#text("The third remark above is for ")#mi("F")#text(" on the region ")#mi("R - \\mathcal R_k")#text(" (on which ")#mi("F = Q")#text(") – i.e. each “")#mi("F")#text("” appearing in that remark should be understood as the polynomial ")#mi("Q")#text(".")#linebreak()#text(" Note also that the computational complexity of the constrained problem (using the above formulation) should have the same order of magnitude as for the original unconstrained one (for ")#mi("M_k")#text(" approximation) – enabling approximation of ")#mi("M^{\\prime\\prime}_{k, \\theta}")#text(" for medium-sized ")#mi("k")#text(" (e.g. ")#mi("k \\le 110")#text(") for which the original optimization program for ")#mi("M_k")#text(" is practical.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-260499")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2013")])]

#text("It occurs to me that in order to get some understanding of how much additional gain one gets by enlarging the simplex ")#mi("{\\mathcal R}_k")#text(" to a larger region such as ")#mi("\\frac{1}{\\theta} \\cdot {\\mathcal R}_k")#text(" (while retaining the vanishing marginal conditions of the original simplex), one can work in the more tractable situation of cubes, in particular one can study how the analogue of ")#mi("M_k")#text(" improves when one replaces a cube ")#mi("[0,L]^k")#text(" with a larger cube ")#mi("[0,L/\\theta]^k")#text(", while requiring that the function have marginals supported on ")#mi("[0,L]^k")#text(". As a crude zeroth approximation (ignoring log factors), ")#mi("{\\mathcal R}_k")#text(" is a bit like ")#mi("[0,1/k]^k")#text(" (although this approximation is too crude – the log factor is critical in making ")#mi("M_k")#text(" grow in k!).")

#text("First observe that the analogue of the original ")#mi("M_k")#text(", namely the supremum of the ratio ")#mi("\\sum_{m=1}^k J_k^{(m)}(F)/I_k(F)")#text(" for ")#mi("F")#text(" supported on ")#mi("[0,L]^k")#text(", is equal to ")#mi("k L")#text(", as can be seen by a routine Cauchy-Schwarz argument (and the extremiser occurs when F is the indicator function of ")#mi("[0,L]^k")#text(").")

#text("The analogue of ")#mi("M^{\\prime\\prime}_k")#text(" is the supremum of the ratio ")#mi("\\sum_{m=1}^k J_k^{(m)}(F)/I_k(F)")#text(" for ")#mi("F")#text(" supported on ")#mi("[0,L/\\theta]^k")#text(", but having marginals supported on ")#mi("[0,L]^{k-1}")#text(". Restricting to symmetric functions, we are now trying to maximise")

#mi("k (\\int_{[0,L/\\theta]^{k-1}} (\\int_0^{L/\\theta} F(t_1,\\ldots,t_k)\\ dt_k)^2\\ dt_1 \\ldots dt_{k-1}) / \\int_{[0,L/\\theta]^k} F^2")#text(" (*)")

#text("subject to ")#mi("\\int_0^{L/\\theta} F(t_1,\\ldots,t_k)\\ dt_k")#text(" being supported in ")#mi("[0,L]^{k-1}")#text(".")

#text("Another application of Cauchy-Schwarz shows that ")#mi("M^{\\prime\\prime}_k")#text(" cannot exceed ")#mi("kL/\\theta")#text(", and it is certainly at least ")#mi("kL")#text(", but the key question is which of these two bounds is closer to the truth.")

#text("We can convert this to a variational problem on ")#mi("[0,L]^{k-1}")#text(" as follows. Fix a symmetric function ")#mi("G")#text(" supported on ")#mi("[0,L]^{k-1}")#text(", and consider the problem of maximising (*) subject to F being symmetric and having marginals G. This problem can be solved by Fourier analysis on the cube ")#mi("[0,L/\\theta]^k")#text(", which we identify (discontinuously) with the torus ")#mi("{\\bf R}/(L/\\theta {\\bf R})^k")#text(". The marginal conditions (and symmetry) constrain all the Fourier coefficients ")#mi("\\hat F( n_1,\\ldots,n_k)")#text(" of ")#mi("F")#text(" that have at least one zero frequency ")#mi("n_i")#text("; the remaining Fourier coefficients of F (when all the ")#mi("n_i")#text(" are non-zero) serve to increase the denominator of (*) (by Plancherel’s theorem) but do not affect the numerator. Thus, the extremum occurs when those coefficients are set to zero. After a bit of fiddling, the extremum of (*) for a given choice of marginals G is then")

#tao-math("\\displaystyle \\frac{kL}{\\theta} \\frac{ \\left\\|G\\right\\|_{L^2}^2 }{ \\sum_{i=0}^{k-1} \\binom{k}{i} \\left\\|\\pi_i G \\right\\|_{L^2([0,L/\\theta]^{k-1}}^2}", block: false)#text(" (**)")

#text("where ")#mi("\\pi_i G")#text(" is the orthogonal projection of ")#mi("G")#text(" to those functions on ")#mi("L^2([0,L/\\theta]^{k-1})")#text(" whose Fourier coefficients are only non-vanishing for those frequencies ")#mi("(n_1,\\ldots,n_{k-1})")#text(" with ")#mi("n_1,\\ldots,n_i")#text(" non-zero and ")#mi("n_{i-1},\\ldots,n_{k-1}")#text(" zero. Thus for instance")

#tao-math("\\left\\|G\\right\\|_{L^2}^2 = \\sum_{i=0}^{k-1} \\binom{k-1}{i} \\left\\|\\pi_i G \\right\\|_{L^2([0,L/\\theta]^{k-1}}^2.", block: false)

#text("At this point I’ll resort to back of the envelope calculations. In one dimension, if we set ")#mi("G = 1_{[0,L]}")#text(", then ")#mi("\\pi_0 G = \\theta 1_{[0,L/\\theta]}")#text(" and ")#mi("\\pi_1 G = G - \\pi_0 G")#text(". In this case, ")#tao-math("\\left\\|\\pi_0 G\\right\\|_{L^2}^2", block: false)#text(" absorbs a ")#mi("\\theta")#text(" fraction of the total energy ")#tao-math("\\left\\|G\\right\\|_{L^2}^2", block: false)#text(", with ")#tao-math("\\left\\|\\pi_1 G\\right\\|_{L^2}^2", block: false)#text(" absorbing the other ")#mi("1-\\theta")#text(". Tensoring this and using the law of large numbers, we expect in high dimension that the ")#tao-math("\\left\\|\\pi_i G \\right\\|_{L^2}^2", block: false)#text(" with ")#mi("i \\sim (1-\\theta) (k-1)")#text(" will be absorbing the bulk of the energy of G. For such i, we have ")#mi("\\binom{k-1}{i} / \\binom{k}{i} = \\frac{k-i}{k} \\approx \\theta")#text(". So the second ratio in (**) is approximately ")#mi("\\theta")#text(", suggesting that ")#mi("M^{\\prime\\prime}_k")#text(" is unfortunately close to ")#mi("M_k = kL")#text(". (If one considers the tensor power of other functions on ")#mi("[0,L]")#text(" than the indicator function, the situation gets worse.)")

#text("This suggests that the gain from the additional room is going to be modest. I’ll try and compute (**) more precisely in the case ")#mi("G = 1_{[0,L]^{k-1}}")#text(" to get a better idea of what the gain will be (my initial guess is that it is exponentially small in k, but I have not yet done a real calculation here yet).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-260506")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2013")])]

#text("I’ve now done the calculation and the gain is indeed exponentially small in this case :(. We have ")#tao-math("\\left\\| \\pi_i G \\right\\|_{L^2}^2 = (1-\\theta)^i \\theta^{k-1-i} \\left\\|G\\right\\|_{L^2}^2", block: false)#text(", so by the binomial theorem")

#tao-math("\\sum_{i=0}^{k-1} \\binom{k}{i} \\left\\|\\pi_i G \\right\\|_{L^2}^2 = \\frac{1}{\\theta} ( 1 - (1-\\theta)^k )", block: false)

#text("and so it appears that")

#mi("M^{\\prime\\prime}_k = kL (1 - (1-\\theta)^k )^{-1}")

#text("with extremiser")

#mi("F(t_1,\\ldots,t_k) = 1_{[0,L]^k}(t_1,\\ldots,t_k) - \\prod_{i=1}^k ( 1_{[0,L]}(t_i) - \\theta 1_{[0,L/\\theta]}(t_i))")

#text("which is basically shaving off an exponentially small piece from ")#mi("1_{[0,L]^k}")#text(". (I’ve not yet fully verified that this is indeed the extremiser, but I’m reasonably sure of this.)")

#text("The situation appears to be very similar to that of James’ old suggestion of trying to lower bound the portion of the sieve where all of the ")#mi("n+h_i")#text(" are simultaneously composite. We expect this contribution to be exponentially small. On the other hand, any modification of the sieve that does not affect the marginals is only going to change the sieve on precisely those ")#mi("n")#text(" for which none of the ")#mi("n+h_i")#text(" are prime.")

#text("There is still a small ray of hope though that in the simplex case things are a little better. One thing about the cube is that every symmetric function on ")#mi("[0,L]^{k-1}")#text(" can be written as the marginal of a symmetric function on ")#mi("[0,L]^k")#text(" (this can be seen by Fourier series), however it is not clear to me yet that every symmetric function on ")#mi("{\\cal R}_{k-1}")#text(" can be written as the marginal of a symmetric function on ")#mi("{\\cal R}_k")#text(". If this is not the case, then there could be additional gain coming from enlarging the ")#mi("{\\cal R}_k")#text(" simplex that is not present in the cube case. (But the pessimist in me thinks that this additional gain will also be exponentially small.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714d8c2f1ed8d3b1be04d8a23a36bce0f5d29c60c225ae36c4a61207a30cc42f-6a4413f17425ffb6926dda61ec55f153dd33fd24918b6df3394b5760ee7a1412.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Nicholson")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-260683")[#strong[#text("John Nicholson")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2014")])]

#text("Is ")#mi("\\displaystyle H_m := \\liminf_{n \\rightarrow\\infty} (p_{n+m} - p_n)")#text(" equivilent to ")#mi("\\displaystyle H_m := \\liminf_{n \\rightarrow\\infty} (p_n - p_{n-m})")#text(" The reason for the question is the Ramanujan prime corollary found here:")

#link("https://en.wikipedia.org/wiki/Ramanujan_prime#Ramanujan_prime_corollary")[#text("https://en.wikipedia.org/wiki/Ramanujan_prime#Ramanujan_prime_corollary")]

#text("It is similar to what is stated above, but brings the n values lower.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261034")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2014")])]

#text("I managed to work out the gain from James’ idea of subtracting off the contribution of when all the ")#mi("n+h_i")#text(" are simultaneously composite. I unfortunately don’t know how to get any nontrivial bound on this in the EH case (unless one pulls the support of F away from the boundary of the simplex, but then one will almost certainly lose more from the reduced support than one gains from the simultaneously composite term). In the BV case it appears one can shave about ")#mi("\\frac{1}{2^k k!}")#text(" from ")#mi("M_k")#text(", which unfortunately is too tiny to be of much use (unless we have the exceptional coincidence that ")#mi("M_k")#text(" is really, really, really close to 4).")

#text("The cleanest way to subtract appears to be to replace the sieve ")#mi("\\nu")#text(" (which, in the BV case, is a divisor sum with moduli going up to about ")#mi("x^{1/2}")#text(") by the modified sieve")

#mi("\\nu^{\\prime}(n) := \\nu(n) ( 1 - \\sum_{p_1,\\ldots,p_k: p_1 \\ldots p_k \\leq x^{1/2}: p_i | n+h_i \\text{ for } i=1,\\ldots,k} \\frac{\\log p_1}{\\log x} \\ldots \\frac{\\log p_k}{\\log x} ).")

#text("Note that the big sum here is bounded by ")#mi("\\prod_{i=1}^k \\sum_{p_i: p_i | n+h_i} \\frac{\\log p_i}{\\log x}")#text(", which is basically 1 by the fundamental theorem of arithmetic, so the sieve remains positive (modulo negligible errors). The cap ")#mi("p_1 \\ldots p_k \\leq x^{1/2}")#text(" is needed to keep the total divisor less than x, otherwise one can’t estimate the sum ")#mi("\\sum_n \\nu^{\\prime}(n)")#text(" accurately. The additional factor does not impact the sums ")#mi("\\sum_n \\nu(n) 1_{n+h_i \\text{ prime}}")#text(", but reduces ")#mi("\\sum_n \\nu(n)")#text(" slightly, by approximately")

#mi("1 - \\sum_{p_1,\\ldots,p_k: p_1 \\ldots p_k \\leq x^{1/2}} \\frac{\\log p_1}{p_1 \\log x} \\ldots \\frac{\\log p_k}{p_k \\log x}")

#text("which by Mertens theorem is roughly ")#mi("1 - \\frac{1}{2^k k!}")#text(". (Actually the presence of the sieve ")#mi("\\nu")#text(" distorts this calculation a bit, but not significantly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261207")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2014")])]

#text("Here is an idea that seems to give some flexibility in going beyond the simplex ")#mi("{\\cal R}_{k-1}")#text(" that the marginals of F are currently restricted to, at the cost of degrading the lower bounds that end up in the numerator of the M_k-type optimisation problem.")

#text("For sake of concreteness let us take k=3 and assume EH. We would like to lower bound quantities such as")

#mi("\\sum_n \\theta(n) \\nu(n)")#text(" (*)")

#text("where ")#mi("\\nu(n)")#text(" is the GPY Selberg sieve")

#mi("\\nu(n) = (\\sum_{d_1|n; d_2|n+2; d_3|n+6} \\mu(d_1 d_2 d_3) f(\\frac{\\log d_1}{\\log R}, \\frac{\\log d_2}{\\log R}, \\frac{\\log d_3}{\\log R}))^2")

#text("for some smooth function ")#mi("f: [0,+\\infty)^3 \\to {\\bf R}")#text(", with ")#mi("R=x^{1/2-}")#text(" in the EH case; we usually write things in terms of the mixed derivative ")#mi("F = f_{123}")#text(" of ")#mi("f")#text(", for instance ")#mi("\\sum_n \\nu(n)")#text(" is proportional to ")#mi("\\int F^2(t_1,t_2,t_3)\\ dt_1 dt_2 dt_3")#text(" (i.e. ")#mi("I_3(F)")#text(") if F is supported in a suitable polytope (e.g. ")#mi("{\\cal R}_3")#text(" will do, we can also work with some larger regions R as discussed in the past).")

#text("For (*), the cutoff ")#mi("\\theta(n)")#text(" ensures that the ")#mi("d_1")#text(" factor in the definition of ")#mi("\\nu")#text(" must be 1, and the expression simplifies a bit to")

#mi("\\sum_n \\theta(n) \\alpha(n)^2")

#text("where ")#mi("\\alpha")#text(" is the (signed) divisor sum")

#mi("\\alpha(n) := \\sum_{d_2|n+2; d_3|n+6} \\mu(d_2) \\mu(d_3) f( 0, \\frac{\\log d_2}{\\log R}, \\frac{\\log d_3}{\\log R} )")#text(".")

#text("If ")#mi("f(0,t_2,t_3)")#text(" is supported on the simplex ")#mi("t_2+t_3 \\leq 1")#text(" (which, in terms of F, means that the marginal ")#mi("\\int F(t_1,t_2,t_3)\\ dt_1")#text(" vanishes for ")#mi("t_2+t_3 > 1")#text("), then the divisor sum in ")#mi("\\alpha")#text(" only involves moduli up to ")#mi("R^2 = x^{1-}")#text(", and so on EH we can compute an asymptotic for (*) which is proportional to the familiar expression")

#mi("J^{(1)}_3(F) = \\int (\\int F(t_1,t_2,t_3)\\ dt_1)^2\\ dt_2 dt_3.")

#text("Now suppose instead that ")#mi("f(0,t_2,t_3)")#text(" is supported on a slightly larger simplex ")#mi("t_2+t_3 \\leq 1 + \\varepsilon")#text(" for some ")#mi("\\varepsilon > 0")#text(". Then ")#mi("\\alpha^2")#text(" now involves moduli larger than ")#mi("x")#text(", and even EH can no longer help us get asymptotics for (*). However, we don’t truly need asymptotics here; a lower bound might suffice. For instance, we have the trivial lower bound of 0 no matter what the support of ")#mi("f(0,t_2,t_3)")#text(" is. Less trivially, we split ")#mi("\\alpha^2 = \\tilde \\alpha^2 + (\\alpha^2 - \\tilde \\alpha^2)")#text(", where")

#mi("\\tilde \\alpha(n) := \\sum_{d_2|n+2; d_3|n+6} \\mu(d_2) \\mu(d_3) \\tilde f( 0, \\frac{\\log d_2}{\\log R}, \\frac{\\log d_3}{\\log R} )")

#text("and ")#mi("\\tilde f(0,t_2,t_3)")#text(" is chosen to agree with ")#mi("f(0,t_2,t_3)")#text(" for ")#mi("t_2+t_3 \\geq 1-\\varepsilon")#text(" but is otherwise arbitrary. The point is then that ")#mi("\\alpha^2-\\tilde \\alpha^2")#text(" only involves moduli up to ")#mi("R^2")#text(" (the moduli larger than ")#mi("R^2")#text(" appear in both ")#mi("\\alpha^2")#text(" and ")#mi("\\tilde \\alpha^2")#text(", but they cancel each other out) and so EH can again be used to get an asymptotic for this part, which is proportional to ")#mi("\\int f_{23}(0,t_2,t_3)^2 - \\tilde f_{23}(0,t_2,t_3)^2")#text(". As for the ")#mi("\\tilde \\alpha^2")#text(" component, we apply the trivial lower bound of 0. The net lower bound then is proportional to")

#mi("\\int (\\int F(t_1,t_2,t_3)\\ dt_1)^2 - (\\int \\tilde F(t_1,t_2,t_3)\\ dt_1)^2\\ dt_2 dt_3")

#text("where ")#mi("\\tilde F := \\tilde f_{123}")#text(" is the mixed derivative of ")#mi("\\tilde f")#text(".")#linebreak()#text(" We can choose ")#mi("\\tilde F")#text(" to vanish for ")#mi("t_2+t_3 \\leq 1-\\varepsilon")#text(" and agree with ")#mi("F")#text(" otherwise (well actually we need to smooth this function infinitesimally, but never mind this technicality), so we get a final lower bound of")

#mi("J^{(1),\\varepsilon}_3(F) := \\int_{t_2+t_3 \\leq 1-\\varepsilon} (\\int F(t_1,t_2,t_3)\\ dt_1)^2\\ dt_2 dt_3.")

#text("The upshot is that we can now allow the marginal ")#mi("\\int F(t_1,t_2,t_3)\\ dt_1")#text(" to be supported on the larger region ")#mi("t_2+t_3 \\leq 1+\\varepsilon")#text(", at the cost of replacing the functional ")#mi("J^{(1)}_3(F)")#text(" appearing in the numerator of the ")#mi("M_3")#text(" variational problem with the slightly smaller quantity ")#mi("J^{(1),\\varepsilon}_3(F)")#text(". Similarly for the other two functionals ")#mi("J^{(2)}_3(F)")#text(" and ")#mi("J^{(3)}_3(F)")#text(". This leads to the more general variational problem of maximising")

#mi("\\displaystyle \\frac{J^{(1),\\varepsilon_1}_3(F) + J^{(2),\\varepsilon_2}_3(F) + J^{(3),\\varepsilon_3}_3(F)}{I_3(F)}")

#text("subject to the constraints that the marginals ")#mi("\\int F\\ dt_1")#text(", ")#mi("\\int F\\ dt_2")#text(", ")#mi("\\int F\\ dt_3")#text(" are supported on ")#mi("t_2+t_3 \\leq 1+\\varepsilon_1")#text(", ")#mi("t_1+t_3 \\leq 1+\\varepsilon_2")#text(", ")#mi("t_1+t_2 \\leq 1+\\varepsilon_3")#text(" respectively, and ")#mi("\\varepsilon_1,\\varepsilon_2,\\varepsilon_3 \\geq 0")#text(" are parameters that can be chosen arbitrarily, while F also needs to be constrained to a polytope R with ")#mi("R+R \\subset \\{ t_1+t_2, t_3 \\leq 2\\} \\cup \\{ t_1+t_3,t_2 \\leq 2\\} \\cup \\{t_2+t_3,t_1 \\leq 2\\}")#text(" (e.g. one can take the prism ")#mi("R = \\{ t_1+t_2,t_3 \\leq 1\\}")#text(" or the truncated simplex ")#mi("R = \\{t_1+t_2+t_3 \\leq \\frac{3}{2}; t_1,t_2,t_3 \\leq 1 \\}")#text("). The case ")#mi("\\varepsilon_1=\\varepsilon_2=\\varepsilon_3=0")#text(" is our existing M”_3 optimisation problem, so this new problem can’t do worse than what we already have. The question is whether it actually does better, in that the increased flexibility given by relaxing the vanishing marginal conditions “beats” the loss in the numerator; I plan to do a perturbative analysis of the case when the ")#mi("\\varepsilon_i")#text(" are infinitesimal to see if this is the case. One reason for hope is that (in the k=3 case) if one sets ")#mi("\\varepsilon_3")#text(" all the way to 1 while keeping ")#mi("\\varepsilon_1,\\varepsilon_2")#text(" at zero (and taking R to be something like ")#mi("\\{ t_1,t_2 \\leq 1-\\delta, t_3 \\leq \\delta \\}")#text(" for some small ")#mi("\\delta")#text("), then one collapses to the M”_2 problem, for which we already have a bound of 2 which is better than the current bound on M”_3 we have.")

#text("So these epsilon parameters help explain the puzzling lack of monotonicity of the M”_k that was pointed out some time ago, I think by Pace. Indeed the way I discovered this more flexible lower bound was by trying to reconcile the k=2 theory (in which we have the extensive analysis of Bombieri on EH, for instance) with the k=3 theory by trying to smoothly interpolate between the two.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261252")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2014")])]

#text("Is it still possible to get ")#mi("M^{\\prime\\prime}_2 > 2")#text(" for some enlarged region ")#mi("R")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261260")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2014")])]

#text("I meant that arbitrarily small improvement of the current result ")#mi("M^{\\prime\\prime}_2 =  2")#text(" by arbitrarily small perturbation of ")#mi("R")#text(" (if possible) is sufficient to show that EH implies ")#mi("H_1 = 2")#text(" (i.e. the twin primes conjecture!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261265")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2014")])]

#text("Unfortunately, the parity problem blocks this: given any sieve ")#mi("\\nu(n)")#text(" coming from this sort of framework (as a divisor sum), one expects ")#mi("\\sum_n \\nu(n) \\mu(n)")#text(" and ")#mi("\\sum_n \\nu(n) \\mu(n+2)")#text(" to be small (this is because of the Mobius randomness heuristic, that predicts the Mobius function to fluctuate as if it were random on short progressions), which implies that neither of ")#mi("\\sum_n \\nu(n) 1_{n \\text{ prime}}")#text(" and ")#mi("\\sum_n \\nu(n) 1_{n+2 \\text{ prime}}")#text(" can be much larger than ")#mi("\\frac{1}{2} \\sum_n \\nu(n)")#text(", which basically means that none of the M”_2 type quantities can be larger than 2.")

#text("The ")#link("http://www.ams.org/mathscinet-getitem?mr=396435")[#text("analysis of Bombieri on the twin prime problem")]#text(" suggests that the parity problem is the only obstruction to the twin prime conjecture assuming EH; roughly speaking, Bombieri shows that if EH is true and twin prime is false, then for “almost all” n, the Mobius functions ")#mi("\\mu(n)")#text(" and ")#mi("\\mu(n+2)")#text(" have opposite sign (so if n has an odd number of prime factors, then n+2 almost always has an even number of prime factors). Similarly, if ")#mi("H_1 > 6")#text(", then for “almost all” n, ")#mi("\\mu(n)")#text(" and ")#mi("\\mu(n+6)")#text(" have opposite sign, and for “almost all” n, ")#mi("\\mu(n+2), \\mu(n+6)")#text(" have opposite sign. Since it is not possible for ")#mi("\\mu(n), \\mu(n+2), \\mu(n+6)")#text(" to all have opposite sign, this looks like a proof that ")#mi("H_1 \\leq 6")#text(". Unfortunately, the three notions of “almost all” here are quite different; roughly speaking, we only get ")#mi("\\mu(n), \\mu(n+2)")#text(" opposite sign for most n with ")#mi("n, n+2")#text(" almost prime (but ")#mi("n+6")#text(" arbitrary), and similarly for other permutations of ")#mi("n,n+2,n+6")#text(". I played around for quite some time today to try to salvage something from this approach, but without much success unfortunately.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261446")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2014")])]

#text("I have tried a perturbative analysis of the effect of the epsilon parameters in my previous comment, but the results are frustratingly inconclusive: it seems that this additional freedom _can_ improve M”_k if the extremisers to that problem obey a rather random-looking inequality (roughly speaking, that the directional derivative of M”_k in epsilon is positive), but that this inequality need not hold in all cases. (For instance, perturbing off of the M”_2 extremiser in the k=3 setting appears to make the constant dip below 2, thus preventing a cheap proof of H_1 <= 6. On the other hand, since M”_3 is currently less than 2 when all epsilons are set to zero, and we can reach 2 by sending one of the epsilons to 1, the mean value theorem tells us that there must be at least some situation in which increasing epsilon helps.)")

#text("It may well be that the best way to see whether this flexibility has promise is to do some numerics, e,g. to recompute M'_3 but with the region ")#mi("\\{x+y,y+z,z+x \\leq 1\\}")#text(" enlarged to ")#mi("\\{x+y,y+z,z+x \\leq 1+\\varepsilon\\}")#text(" for some small ")#mi("\\varepsilon")#text(" (e.g. 0.1), but with the ")#mi("J^{(m)}_k")#text(" functionals replaced with ")#mi("J^{(m),\\varepsilon}_k")#text(". (Ideally we should perturb off of M''_k instead of M'_k, but this might be harder to code because we have to redo all the polytope partitioning.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261527")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2014")])]

#text("Might it be preferable to do such numerics for the k=4 case rather than k=3? I’m thinking that not only is k=4 the case of most current interest in the EH setting, but also that unless the non-monotonicity of M is particularly sadistic the result will give a more reliable indication of what would be worth trying for two-digit k, and these considerations may outweigh the drawback of the greater complexity than the k=3 case.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261235")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2014")])]

#text("I’ve been notified that the polymath wiki is currently experiencing some issues that make it either load very slowly, or not at all. They should be fixed soon, however.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261540")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2014")])]

#text("A necessary condition for solutions of the constrained optimization problem:")

#text("Let ")#mi("D_j, E_j")#text(" for ")#mi("j = 1, ... , k")#text(" be measurable subsets of ")#mi("\\mathbb R^{k-1}")#text(" and let ")#mi("R")#text(" be a closed subset of ")#mi("\\mathbb R^k")#text(".")

#text("Consider the (somewhat generalized) problem")

#mi("\\sup_{F \\in L^2(\\mathbb R^k)} J(F)")

#text("Where ")#mi("J(F) := \\sum_{j=1}^k J^{(j)}(F)")

#mi("J^{(j)}(F) := \\int_{E_j} (\\int_{\\mathbb R} F(t_1, ... , t_k) d t_j)^2 d t_1 \\cdots d  t_{j-1} d t_{j+1} \\cdots d t_k")

#text("Subject to")

#text("(1) ")#mi("\\langle F, F \\rangle = 1")

#text("(2) ")#mi("\\int_{\\mathbb R} F(t_1, ... , t_k) d t_j")#text(" is supported on ")#mi("D_j")

#text("(for ")#mi("j = 1, ... , k")#text(")")

#text("(3) ")#mi("F")#text(" is supported on ")#mi("R")#text(".")

#text("Remark: w.l.o.g. we may assume that ")#mi("E_j \\subseteq D_j \\subseteq \\pi_j  R")#text(" for ")#mi("j = 1, ... , k")#text(" where ")#mi("\\pi_j R")#text(" denotes the projection of ")#mi("R")#text(" on the hyperplane ")#mi("t_j = 0")#text(".")

#text("The functional ")#mi("J(F)")#text(" can be represented as")

#text("(4) ")#mi("J(F) = \\langle F, \\mathcal L F \\rangle")#text(", where")

#text("(4′) ")#mi("{\\mathcal L} F)(t_1, ..., t_k) := \\sum_{j=1}^k 1_{E_j}(t_1,..., t_{j-1},  t_{j+1},..., t_k)  \\int_{\\mathbb R} F(t_1, ... , t_k) d t_j")

#text("Observe that the constraint (2) is equivalent to")

#text("(2′) ")#mi("\\int_{\\mathbb R^k} h(t_1, ... , t_{j-1}, t_{j+1}, ... , t_k) F(t_1, ... , t_k) d  t_1 \\cdots d t_k=0")#text(" for each ")#mi("h \\in L^2(\\mathbb R^{k-1})")#text(" vanishing on ")#mi("D_j")#text(" (for ")#mi("j = 1, ... , k")#text(").")

#text("Motivated by this equivalence, denote (for ")#mi("j = 1, ... , k")#text(") by ")#mi("\\mathcal  F_j")#text(" the subspace of functions ")#mi("h(t_1, ... , t_{j-1}, t_{j+1}, ... , t_k")#text(" in ")#mi("L^2(\\mathbb R^{k-1})")#text(" and vanishing on ")#mi("D_j")#text(".")

#text("Therefore (by a standard calculus of variations argument), under the constraints (1), (2) (i.e. (1), (2′)) any variation ")#mi("\\delta F")#text(" of ")#mi("F")#text(" should be orthogonal to ")#mi("F")#text(" and to the functions in the subspaces ")#mi("\\mathcal  F_1, ... , \\mathcal F_k")#text(". Therefore if ")#mi("F")#text(" is a solution to the optimization problem, it follows (from (4)) that ")#mi("\\mathcal L F")#text(" is orthogonal to any such variation, implying")

#text("Theorem: If ")#mi("F")#text(" is a solution to the optimization problem, then")

#mi("\\mathcal L F = \\lambda F + \\sum_{j=1}^k h_j,  h_j \\in \\mathcal F_j")

#text("Moreover, ")#mi("\\lambda = J(F)")#text(" is the optimal value of the objective function.")

#text("Remarks:")

#text("1. This theorem shows that an optimal solution may be discontinuous on the boundaries of ")#mi("D_1, ... , D_k")#text(" and ")#mi("E_1, ... , E_k")#text(" – with some implications to polytopes partition for piecewise polynomial approximation (the approximation usually converges slowly with the polynomials degrees if the solution is not smooth inside some polytope.)")

#text("2. It seems possible to find the optimal solution also for the region ")#mi("R = 2  \\mathcal R_2")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261720")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2014")])]

#text("Is it possible to apply the idea of enlarging the sieve support also to the original one dimensional sieve (e.g. by using ")#mi("F")#text(" of type ")#mi("f(\\sum_i t_i)")#text(" over the enlarge simplex ")#mi("R")#text(")?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261749")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2014")])]

#text("Yes, I believe so, and this is a good model problem to work on since one can in principle solve the optimisation problems explicitly in this case.")

#text("The one-dimensional analogue of M_k is the supremum of")

#mi("\\displaystyle k \\frac{\\int_0^1 f(t)^2 \\frac{t^{k-2}}{(k-2)!}\\ dt}{\\int_0^1 f^{\\prime}(t)^2 \\frac{t^{k-1}}{(k-1)!}\\ dt}")

#text("as f ranges over smooth functions ")#mi("f: [0,+\\infty) \\to {\\bf R}")#text(" that are compactly supported in [0,1] (and not identically zero). This supremum was calculated to be ")#mi("\\frac{4k(k-1)}{j_{k-2}^2}")#text(", attained when")

#mi("\\displaystyle f(t) = t^{1-k/2} J_{k-2}( j_{k-2} \\sqrt{t} ).")

#text("(Strictly speaking one should smooth this out at t=1, but never mind this technicality.) The modified optimisation problem ")#mi("M_{k,\\varepsilon}")#text(" in one dimension is the supremum of")

#mi("\\displaystyle k \\frac{\\int_0^{1-\\varepsilon} f(t)^2 \\frac{t^{k-2}}{(k-2)!}\\ dt}{\\int_0^{1+\\varepsilon} f^{\\prime}(t)^2 \\frac{t^{k-1}}{(k-1)!}\\ dt}")

#text("as f ranges over smooth functions compactly supported in ")#mi("[0,1+\\varepsilon]")#text(". At present, I do not know what this supremum is, but it looks like it can be computed explicitly, presumably in terms of Bessel functions. It does not seem obvious to me which way things will go: on the one hand we have more functions to optimise over (being supported on ")#mi("[0,1+\\varepsilon]")#text(" instead of ")#mi("[0,1]")#text("), but on the other hand the numerator has been shaved off by an epsilon.")

#text("Incidentally, the one-dimensional lower bounds for M_k are surprisingly competitive for small k. For instance, for k=2, the Bessel bound is 1.383, compared with the true optimum of 1.386; similarly for k=3 it is 1.635 versus 1.646, and for k=4 it is 1.820 versus 1.845.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261838")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2014")])]

#text("The modified problem for ")#mi("M_{k, \\epsilon}")#text(" can be solved as follows:")

#text("1. Let ")#mi("\\lambda := \\inf_f \\int_0^{1+\\epsilon} a(t)f^{\\prime}(t)^2 d t")#text(", subject to")

#mi("\\int_0^{1+\\epsilon} b(t) f(t)^2 d t = 1")

#text("where ")#mi("a(t) := t^{k-1}")#text(" , ")#mi("b(t) := t^{k-2} 1_{[0, 1-\\epsilon]}(t)")#linebreak()#text(" and ")#mi("f")#text(" ranges over the same smooth functions as above.")

#text("Clearly, ")#mi("M_{k, \\epsilon} := k(k-1)/ \\lambda")#text(".")

#text("2. In order to find the above infimum ")#mi("\\lambda")#text(", we assume that it is attained by some ")#mi("f")#text(" which satisfies the Euler-Lagrange equation")

#text("(1) ")#mi("(a y^{\\prime})^{\\prime} + \\lambda b y = 0")#text(" on ")#mi("(0, 1+\\epsilon)")#text(".")

#text("and the regularity conditions")

#text("(1′) ")#mi("a f f^{\\prime}")#text(" has zero limits at the endpoints of ")#mi("[0, 1+\\epsilon]")#text(".")

#text("It is easy to verify (using integration by parts) that ")#mi("\\lambda")#text(" in the equation is the same ")#mi("\\lambda")#text(" which was defined as an infimum.")

#text("In order to show that the infimum ")#mi("\\lambda")#text(" is attained by certain solution ")#mi("f")#text(" of (1), we use the identity")

#text("(2) ")#mi("\\int_0^{1+\\epsilon} a(y^{\\prime}-f^{\\prime} y/f)^2 d t = \\int_0^{1+\\epsilon} (a y^{\\prime 2} - \\lambda b y^2) d t")

#text("Which follows (via integration by parts) for any smooth ")#mi("y")#text(" and any non-vanishing solution ")#mi("f")#text(" of (1) satisfying the regularity conditions")

#text("(2′) ")#mi("a f^{\\prime 2} y^2/ f")#text(" has zero limits at the endpoints of ")#mi("[0,  1+\\epsilon]")#text(".")

#text("3. The equation (1) has on ")#mi("[0, 1-\\epsilon]")#text(" the (familiar) solution")

#mi("f(t) = t^{1-k/2} J_{k-2}(2 \\sqrt{\\lambda t})")#text(", on ")#mi("[0, 1-\\epsilon]")#text(".")

#text("While on the remaining interval ")#mi("[1-\\epsilon, 1+\\epsilon]")#text(" we have")

#mi("f(t) = A + B t^{2-k}")#text(", on ")#mi("[1-\\epsilon, 1+\\epsilon]")#text(" (for some constants ")#mi("A, B")#text(")")

#text("The constants ")#mi("A, B")#text(" are determined such that the solution ")#mi("f")#text(" and its derivative ")#mi("f^{\\prime}")#text(" are continuous at ")#mi("t=1 - \\epsilon")#text(".")

#text("This gives ")#mi("A, B")#text(" as explicit linear combinations of ")#mi("f, f^{\\prime}")#text(" at ")#mi("t = 1-\\epsilon")#text(". It is easy to verify (e.g. by Taylor series) that")

#mi("f^{\\prime}(t) = -\\sqrt{\\lambda}t^{(1-k)/2}J_{k-1}(2\\sqrt{\\lambda t})")#text(", on ")#mi("[0, 1-\\epsilon]")#text(".")

#text("This gives the solution ")#mi("f(t)")#text(" on the whole interval in terms of ")#mi("\\lambda")#text(" as the only parameter. It remains only to use this expression for the remaining constraint ")#mi("f(1+\\epsilon) = 0")#text(" to get the final result")

#text("Theorem: ")#mi("\\lambda = \\frac{x^2}{4(1-\\epsilon)}")#text(" , where x is the minimal positive zero of the function")

#mi("[1-(\\frac{1-\\epsilon}{1+\\epsilon})^{k-2}]x J_{k-1}(x)-2(k-2) J_{k-2}(x)")

#text("Finally ")#mi("M_{k, \\epsilon}")#text(" is determined from ")#mi("\\lambda")#text(" (as described at the end of step 1).")

#text("Remark: Now it is possible to optimize ")#mi("\\epsilon")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261914")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2014")])]

#text("A preliminary perturbative analysis looks encouraging: for ")#mi("\\varepsilon")#text(" small, we expect ")#mi("x = j - \\varepsilon y")#text(", where ")#mi("j = j_{k-2}")#text(" is the first zero of ")#mi("J_{k-2}")#text(" and ")#mi("y")#text(" is bounded. We Taylor expand")

#mi("1 - (\\frac{1-\\varepsilon}{1+\\varepsilon})^{k-2} = 2(k-2) \\varepsilon + O(\\varepsilon^2)")

#mi("x J_{k-1}(x) = j J_{k-1}(j) + O(\\varepsilon)")

#mi("J_{k-2}(x) = - \\varepsilon y J^{\\prime}_{k-2}(j) + O(\\varepsilon^2)")

#text("to arrive at")

#mi("2 (k-2) \\varepsilon j J_{k-1}(j) + 2(k-2) \\varepsilon y J^{\\prime}_{k-2}(j) + O(\\varepsilon^2) = 0")#text(".")

#text("Standard Bessel identities tell us that ")#mi("J_{k-1}(j) = - J^{\\prime}_{k-2}(j) = - J_{k-3}(j)")#text(", so that")

#mi("y = j + O(\\varepsilon)")

#text("and hence")

#mi("\\lambda = \\frac{j^2}{4} (1-\\varepsilon + O(\\varepsilon^2))")

#text("and so")

#mi("M_{k,\\varepsilon} = \\frac{4k(k-1)}{j^2} ( 1 + \\varepsilon + O(\\varepsilon^2))")

#text("indicating that there is an improvement to be had (for one-dimensional sieving at least) by taking ")#mi("\\varepsilon")#text(" to be positive! Of course it would be good to back this up with numerical data.")

#text("Incidentally I have a somewhat more geometric way to explain why we have the “graceful failing” of the Selberg sieve in that when one enlarges the sieve cutoff support to the simplex of sidelength ")#mi("1+\\varepsilon")#text(", one still gets a lower bound restricted to the smaller simplex of sidelength ")#mi("1-\\varepsilon")#text(" (as opposed to getting no nontrivial lower bound whatsoever). As I remarked previously in ")#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253205")[#text("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253205")]#text(" , the Selberg sieve is the square of a linear combination of products ")#mi("c_{d_1}(n+h_1) \\ldots c_{d_k}(n+h_k)")#text(" of Ramanujan sums. Distribution hypotheses such as Elliott-Halberstam tell us, roughly speaking, that two such products ")#mi("c_{d_1}(n+h_1) \\ldots c_{d_k}(n+h_k)")#text(", ")#mi("c_{d^{\\prime}_1}(n+h_1) \\ldots c_{d^{\\prime}_k}(n+h_k)")#text(" behave orthogonally (on average) if ")#mi("d_1 \\ldots d_k d^{\\prime}_1 \\ldots d^{\\prime}_k")#text(" lies below a given threshold (or, if one is weighting against (say) ")#mi("\\Lambda(n+h_1)")#text(", if ")#mi("d_2 \\ldots d_k d^{\\prime}_2 \\ldots d^{\\prime}_k")#text(" lies below a given threshold). A model problem is then to lower bound the norm of a sum ")#mi("\\sum_j v_j")#text(" of vectors in an abstract Hilbert space, with the property that distinct ")#mi("v_j")#text(" and ")#mi("v_{j^{\\prime}}")#text(" are orthogonal if ")#mi("j+j^{\\prime} \\geq N")#text(" for some threshold ")#mi("N")#text(". (One should think of ")#mi("v_j")#text(" as corresponding to a linear combination of the ")#mi("c_{d_1}(n+h_1) \\ldots c_{d_k}(n+h_k)")#text(" in which ")#mi("d_1 \\ldots d_k")#text(" (or ")#mi("d_2 \\ldots d_k")#text(") is of a certain logarithmic size proportional to ")#mi("j")#text(", e.g. ")#mi("R^{j/N}")#text(".)")

#text("If one is only summing values of j up to ")#mi("N/2")#text(", then all the ")#mi("v_j")#text(" are orthogonal, and by Pythagoras we have")

#tao-math("\\left\\| \\sum_{j \\leq N/2} v_j \\right\\|^2 = \\sum_{j \\leq N/2} \\left\\|v_j\\right\\|^2", block: false)

#text("which corresponds to the standard Selberg sieve calculations. But if we sum up to ")#mi("(1+\\varepsilon)N/2")#text(", there are some inner products between ")#mi("v_j")#text(" for which we do not have good control. However, all the ")#mi("v_j")#text(" with ")#mi("(1-\\varepsilon) N/2 \\leq j \\leq (1+\\varepsilon)N/2")#text(" are orthogonal to those ")#mi("v_j")#text(" with ")#mi("j < (1-\\varepsilon)N/2")#text(", so we have")

#tao-math("\\left\\| \\sum_{j \\leq (1+\\varepsilon)N/2} v_j \\right\\|^2 \\geq \\left\\| \\sum_{j < (1-\\varepsilon)N/2} v_j \\right\\|^2 = \\sum_{j < (1-\\varepsilon)N/2} \\left\\|v_j\\right\\|^2", block: false)

#text("which corresponds to the gracefully degrading bound we have when we push beyond the classical Selberg sieve support region. In fact this bound is sharp if we happen to have the odd symmetry ")#mi("v_{N/2+k} = - v_{N/2-k}")#text(" for ")#mi("k \\leq \\varepsilon N/2")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261923")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2014")])]

#text("Typographical comment: If \\dots is used instead of \\ldots, the correct formatting of the ellipsis is automatically obtained. It shouldn’t always be lowered dots.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261936")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2014")])]

#text("It seems that a second order expansion of ")#mi("M_{k, \\epsilon}")#text(" should give an initial approximation for the optimal value of ")#mi("\\epsilon")#text(" as well as an estimate of the gain in ")#mi("M_k")#text(". (this may also be used to derive a Newton-type iteration for the optimal ")#mi("\\epsilon")#text(".)")

#text("Another possibility is to apply the enlarged simplex")#linebreak()#text(" ")#mi("R = \\max (1/\\theta, k/(k-1)) \\mathcal R_k")#linebreak()#text(" with the vanishing marginals constraints to the one dimensional sieve and see if these constraints can be satisfied by a one dimensional sieve of the form ")#mi("F = f(\\sum_i t_i)")#text(". It seems that since in this case ")#mi("F")#text(" is symmetric, only one constraint is needed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261993")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2014")])]

#text("There are two typos in the perturbation analysis (with the same conclusions):")#linebreak()#text(" 1. In the line above the standard Bessel identities, the sign of the second term should be “+”.")#linebreak()#text(" 2. The main term of ")#mi("y")#text(" should be ")#mi("j")#text(". (i.e. ")#mi("x")#text(" should be less than ")#mi("j")#text(")")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262001")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2014")])]

#text("Regarding second order expansion: this can in principle be done, but is a little messy; it may be faster simply to work things out numerically for small k. (For large k, the one-dimensional version of M_k never exceeds 4; after optimising in epsilon, it is potentially possible that one could breach 4 (giving yet another proof of Maynard’s theorem!), but it is unlikely to be competitive with the multidimensional sieving.)")

#text("Incidentally, there is an annoying technicality when trying to apply the one-dimensional improvements to the EH problems. Basically, the one-dimensional functions f supported on ")#mi("[0,1+\\varepsilon]")#text(" are only admissible when ")#mi("1+\\varepsilon \\leq \\frac{1}{\\theta}")#text(". Thus, strictly speaking, in the EH case ")#mi("\\theta=1")#text(" we don’t get to increase epsilon past 0 at all. But the problem is only at the “corners” of the simplex ")#mi("1 +\\varepsilon \\cdot {\\cal R}_k")#text("; if one truncates away the portion of this simplex that pokes outside of ")#mi("[0,1]^k")#text(" then the cutoff is admissible again, and a back-of-the-envelope calculation indicates that this only costs ")#mi("O(\\varepsilon^k)")#text(" to the M_k quantity. So the perturbative analysis still suggests a gain in this case, though actually calculating it would be messy.")

#text("Unfortunately, if one insists on the one-dimensional ansatz ")#mi("F(t_1,\\ldots,t_k) = G(t_1+\\ldots+t_k)")#text(" then there is no gain by enlarging the region ")#mi("{\\cal R}_k")#text(" and imposing additional vanishing marginal conditions; these marginal conditions basically collapse to requiring that the antiderivative of G vanishes outside of the original interval [0,1] (or ")#mi("[0,1+\\varepsilon]")#text(", if one is playing the epsilon game) and so we don’t actually get any new functions this way. One can play with more complicated ansatze to deal with this, but this gives up the key advantage the one-dimensional analysis had, namely that it was simple enough to solve exactly, and we may as well return to the numerical analysis of the multidimensional problem at that point.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262016")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2014")])]

#text("I think that in the EH case we still have ")#mi("1+\\epsilon \\le k /(k-1)")#text(" for the enlarged simplex (so we can increase ")#mi("\\epsilon")#text(" up to ")#mi("1/(k-1)")#text(".)")#linebreak()#text(" In general, we can increase ")#mi("\\epsilon")#text(" up to ")#mi("\\max (1/\\theta, k/(k-1)) -1")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262154")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2014")])]

#text("In principle yes, but there is a truncation problem: the function F cannot range in the entire simplex ")#mi("\\frac{k}{k-1} \\cdot {\\cal R}_k")#text(", but only in the truncated simplex ")#mi("[0,\\frac{1}{\\theta}]^k \\cap \\frac{k}{k-1} \\cdot {\\cal R}_k")#text(". For instance when k=3 on EH one can be supported in ")#mi("\\{ x,y,z \\leq 1: x+y+z \\leq \\frac{3}{2} \\}")#text(", as identified by Pace. So a function of the form ")#mi("F(x,y,z) = G(x+y+z)")#text(" doesn’t directly work if G is supported on ")#mi("[0,3/2]")#text(". One can try working with truncated functions ")#mi("G(x+y+z) 1_{x,y,z \\leq 1}")#text(", with G supported on ")#mi("[0,1+\\varepsilon]")#text(" for some ")#mi("0 \\leq \\varepsilon \\leq 1/2")#text(", and the marginals of F being integrated up to ")#mi("1-\\varepsilon")#text(" (and no vanishing marginal conditions required), but the variational problem becomes a bit trickier. Let’s see: with the setup given, the denominator ")#mi("I(F)")#text(" is ")#mi("\\int_0^{1+\\varepsilon} \\frac{t^2}{2!} G(t)^2\\ dt - 3 \\int_0^{\\varepsilon} \\frac{t^2}{2!} G(1+t)^2\\ dt")#text(" (viewing the support of F as the simplex ")#mi("(1+\\varepsilon) \\cdot {\\cal R}_3")#text(" with three copies of ")#mi("\\varepsilon \\cdot {\\cal R}_3")#text(" removed), and a numerator ")#mi("J^{(1),\\varepsilon}_3(F) = J^{(2),\\varepsilon}_3(F) = J^{(3),\\varepsilon}_3(F)")#text(" being equal to")

#mi("\\int_0^\\varepsilon (\\int_t^{1+t} G(s)\\ ds)^2 \\frac{t^1}{1!}\\ dt + \\int_\\varepsilon^{1-\\varepsilon} (\\int_t^{1+\\varepsilon} G(s)\\ ds)^2 \\frac{t^1}{1!}\\ dt;")

#text("writing ")#mi("f(t) = - \\int_t^{1+\\varepsilon} G(s)\\ ds")#text(" as the antiderivative of G, the problem is now to maximise")

#mi("\\displaystyle 3 \\frac{ \\int_0^\\varepsilon (f(t)-f(1+t))^2\\ t dt + \\int_\\varepsilon^{1-\\varepsilon} f(t)^2\\ t dt }{ \\int_0^{1+\\varepsilon} f^{\\prime}(t)^2\\ \\frac{t^2}{2!} dt - 3 \\int_0^\\varepsilon f^{\\prime}(1+t)^2\\ \\frac{t^2}{2!}\\ dt}.")

#text("This looks too messy to optimise exactly, but perhaps a numerical optimisation is still feasible (but in that case we may as well work with arbitrary polynomials on this polytope, rather than those coming from the one-dimensional ansatz.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262267")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2014")])]

#text("On the evaluation of ")#mi("M_{2, \\epsilon}")#text(":")

#text("The theorem in my comment above (representation of x as a minimal positive zero for a certain function) holds only for ")#mi("k >2")#text(" and should be slightly modified for the case ")#mi("k = 2")#text(" because for this case the solution of the corresponding Euler-Lagrange equation on ")#mi("[1 - \\epsilon,  1 +  \\epsilon")#text(" is given by ")#mi("f(t) = A + B \\log t")#text(" for some constants ")#mi("A, B")#text(". Using the same solution method as before we get almost the same theorem as before except that now x is the minimal positive zero of the modified function")

#mi("J_0(x) - \\frac{1}{2} \\log(\\frac{1+\\epsilon}{1-\\epsilon}) x J_1(x)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262156")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2014")])]

#text("As in Eytan’s post, letting ")#mi("M_{k,\\epsilon}:=k(k-1)/\\lambda")#text(" where ")#mi("\\lambda=x^2/4(1-\\epsilon)")#text(" with ")#mi("x")#text(" the minimal positive zero of the function ")#mi("[1-(\\frac{1-\\epsilon}{1+\\epsilon})^{k-2}]x J_{k-1}(x)-2(k-2) J_{k-2}(x)")#text(", numerical calculations show that when ")#mi("k=3")#text(" the maximum is achieved at:")

#mi("\\epsilon\\approx 0.243")#text(", with ")#mi("M_{3,\\epsilon}\\approx 1.87459")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262158")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2014")])]

#text("And if I’m doing this correctly, we also get for ")#mi("k=4")#text(" and ")#mi("\\epsilon =0.18")#text(" that ")#mi("M_{k,\\epsilon}\\approx 2.01869")#text(". So, assuming this can be verified, we just passed the $k=5$ barrier under EH.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262163")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2014")])]

#text("That’s very promising! Unfortunately, there is a technical speedbump right now: Eytan’s analysis is only directly applicable when ")#mi("1+\\varepsilon \\leq \\frac{1}{\\theta}")#text(" (because the cutoff F cannot range freely in ")#mi("(1+\\varepsilon) \\cdot {\\cal R}_k")#text(", but must also stay inside ")#mi("[0,1/\\theta]^k")#text("). So strictly speaking we don’t get anything new under EH (in which ")#mi("\\theta=1")#text(") yet. However it should be possible to develop a truncated version of this analysis. The situation is getting a bit complicated, I will try to lay out where we’re at exactly in the next blog post (which we’re about due for anyway), though it may have to wait until tomorrow, as I have some other things to attend to today.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262167")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2014")])]

#text("In a bit more detail:")

#text("given any function ")#mi("F: [0,+\\infty)^k \\to {\\bf R}")#text(" of compact support, define the functionals")

#mi("I_k(F) := \\int_{[0,+\\infty)^k} F(t_1,\\ldots,t_k)^2\\ dt_1 \\dots dt_k")

#text("and")

#mi("J_{k,\\varepsilon}^{(m)}(F) := \\int_{t_1+\\ldots+t_{m-1}+t_{m+1}+\\dots+t_k \\leq 1-\\varepsilon} (\\int_0^\\infty F(t_1,\\dots,t_k)\\ dt_m)^2 dt_1 \\dots dt_{m-1} dt_{m+1} \\dots dt_k.")

#text("Define ")#mi("M_{k,\\varepsilon,\\theta}")#text(" to be the supremum of the ratio")

#mi("\\frac{\\sum_{m=1}^k J_{k,\\varepsilon}^{(m)}(F)}{I_k(F)}")

#text("as F ranges over non-zero functions supported on the polytope ")#mi("\\{ (t_1,\\ldots,t_k): t_1+\\ldots+t_k \\leq 1+\\varepsilon; t_1,\\ldots,t_k \\leq \\frac{1}{\\theta} \\}")#text(". Note one can restrict to symmetric F, in which case the numerator may be simplified to ")#mi("k J_{k,\\varepsilon}^{(1)}(F)")#text(".")

#text("Then we can prove that ")#mi("EH[\\theta]")#text(" implies ")#mi("DHL[k,m+1]")#text(" whenever we can find ")#mi("0 \\leq \\varepsilon \\leq \\frac{1}{k-1}")#text(" such that ")#mi("M_{k,\\varepsilon,\\theta} > \\frac{2m}{\\theta}")#text(". For instance on EH we have ")#mi("DHL[k,2]")#text(" whenever ")#mi("M_{k,\\varepsilon,1} > 2")#text(".")

#text("In the range ")#mi("1+\\varepsilon \\leq \\frac{1}{\\theta}")#text(", ")#mi("M_{k,\\varepsilon,\\theta}")#text(" collapses to ")#mi("M_{k,\\varepsilon}")#text(", defined as above but with F allowed to range over the entire simplex ")#mi("\\{ (t_1,\\ldots,t_k): t_1+\\dots+t_k \\leq 1+\\varepsilon \\}")#text(". Otherwise, ")#mi("M_{k,\\varepsilon,\\theta}")#text(" could be smaller than ")#mi("M_{k,\\varepsilon}")#text(", but the key question is how much smaller (in particular, can we still get ")#mi("M_{4,\\varepsilon,1}")#text(" larger than 2 for ")#mi("\\varepsilon")#text(" close to 0.18).")

#text("Define ")#mi("M^{1D}_{k,\\varepsilon}")#text(" be the same quantity as ")#mi("M_{k,\\varepsilon}")#text(", but with the function F restricted to have the one-dimensional form ")#mi("F(t_1,\\dots,t_k) = G(t_1+\\dots+t_k)")#text(" for some G supported on ")#mi("[0,1+\\varepsilon]")#text(". This quantity ")#mi("M^{1D}_{k,\\varepsilon}")#text(", which is a lower bound for ")#mi("M_{k,\\varepsilon}")#text(", was computed by Eytan as ")#mi("\\frac{k(k-1)}{\\lambda}")#text(" with a moderately complicated formula for ")#mi("\\lambda")#text(".")

#text("In a previous comment ")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262154")[#text("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262154")]#text(" I worked out the variational problem for ")#mi("M^{1D}_{3,\\varepsilon,1}")#text(", where ")#mi("M^{1D}_{k,\\varepsilon,\\theta}")#text(" is the same as ")#mi("M_{k,\\varepsilon,\\theta}")#text(" but with F restricted to be of the form ")#mi("F(t_1,\\ldots,t_k) = G(t_1+\\ldots+t_k) 1_{t_1,\\ldots,t_k \\leq 1/\\theta}")#text(". It may well be that ")#mi("M^{1D}_{4,\\varepsilon,1}")#text(" is already greater than 2 for some ")#mi("0 \\leq \\varepsilon \\leq 1/3")#text(", in which case we win.")

#text("Perhaps one could modify the previous code for computing M’_k for small values of k to now numerically compute lower bounds on ")#mi("M_{4,\\varepsilon,1}")#text(" or ")#mi("M^{1D}_{4,\\varepsilon,1}")#text(" by testing various symmetric polynomials on the polytope ")#mi("\\{(t_1,\\ldots,t_4): t_1+\\ldots+t_4 \\leq 1+\\varepsilon; t_1,\\ldots,t_4 \\leq 1 \\}")#text(". (As a warmup and a checksum, one could check that for ")#mi("M^{1D}_{4,\\varepsilon}")#text(" one recovers the numbers obtained by Eytan’s exact analysis.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262195")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2014")])]

#text("p.s. it looks like one can also enlarge the domain of F, the same way that it was enlarged to get from M_k to M’_k or M”_k. More precisely, rather than F being supported in the region ")#mi("\\{ (t_1,\\dots,t_k): t_1,\\dots,t_k \\leq 1/\\theta; t_1+\\dots+t_k \\leq 1+\\varepsilon \\}")#text(", one can have F supported in a larger polytope R, so long as R+R is contained in")

#mi("\\bigcup_{m=1}^k \\{ (t_1,\\dots,t_k): t_1+\\dots+t_{m-1}+t_{m+1}+\\dots+t_k \\leq 2; t_m \\leq 2/\\theta \\} \\cup \\frac{2}{\\theta} \\cdot {\\cal R}_k")

#text("and the marginals of F are supported in ")#mi("(1+\\varepsilon) \\cdot {\\cal R}_{k-1}")#text(". For instance, one could have F supported in")

#mi("\\bigcap_{m=1}^k \\{ (t_1,\\dots,t_k): t_1+\\dots+t_{m-1}+t_{m+1}+\\dots+t_k \\leq 1+\\varepsilon; t_m \\leq 1/\\theta \\} \\cap (\\frac{k}{k-1} \\cdot {\\cal R}_k)")

#text("which gives a slight enlargement of the region on which ")#mi("M_{k,\\varepsilon,\\theta}")#text(" is optimised over (similar to how the polytope ")#mi("{\\cal R}^{\\prime}_k = \\bigcap_{m=1}^k \\{ (t_1,\\dots,t_k): t_1+\\dots+t_{m-1}+t_{m+1}+\\dots+t_k \\leq 1 \\}")#text(" gives a slightly larger value M’_k to the variational problem than the value M_k associated to the simplex ")#mi("{\\cal R}_k")#text("). So there is a lot of opportunity here to bump up the ratio to be above 2 in the k=4 case!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261984")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2014")])]

#text("Computations now show that one can take ")#mi("k=54")#text(" which gives bounded gaps of size ")#mi("H=270")#text(". In particular, searching over the space of symmetric polynomials of the form ")#mi("(1-P_1)^a m(\\alpha)")#text(" where the total degree is ")#mi("\\leq 23")#text(" and ")#mi("\\alpha")#text(" is a signature which involves only even entries with total degree ")#mi("\\leq 22")#text(" (and dropping the last three such signatures, due to RAM issues) yields")

#mi("H_{54}\\geq 4.001115\\ldots")

#text("There were a few things that made it difficult for me to do this computation. First, I went on vacation and when I returned I found out that the computer with 64GB of RAM had gone to sleep. Also, I found that I ran into another RAM issue when trying to compute the inverses of ")#mi("2000\\times 2000")#text(" or larger matrices (and a similar problem when finding the largest eigenvector of similarly sized matrices). Fortunately, after quite a few hits and misses I obtained the stated result.")

#text("It seems very suprising to me that restricting to symmetric polynomials of the given form works so well. Other choices for the basis don’t give very good results.")

#text("For ")#mi("k=53")#text(", the following are the bounds I get using all symmetric polynomials of a given degree ")#mi("d")#text(".")

#text("For ")#mi("d=1")#text(", ")#mi("H_{53}\\geq 2.840745\\ldots")#linebreak()#text(" For ")#mi("d=2")#text(", ")#mi("H_{53}\\geq 3.158178\\ldots")#linebreak()#text(" For ")#mi("d=3")#text(", ")#mi("H_{53}\\geq 3.341049\\ldots")#linebreak()#text(" For ")#mi("d=4")#text(", ")#mi("H_{53}\\geq 3.472697\\ldots")#linebreak()#text(" For ")#mi("d=5")#text(", ")#mi("H_{53}\\geq 3.572894\\ldots")#linebreak()#text(" For ")#mi("d=6")#text(", ")#mi("H_{53}\\geq 3.651206\\ldots")#linebreak()#text(" For ")#mi("d=7")#text(", ")#mi("H_{53}\\geq 3.713979\\ldots")#linebreak()#text(" For ")#mi("d=8")#text(", ")#mi("H_{53}\\geq 3.764542\\ldots")#linebreak()#text(" For ")#mi("d=9")#text(", ")#mi("H_{53}\\geq 3.805925\\ldots")#linebreak()#text(" For ")#mi("d=10")#text(", ")#mi("H_{53}\\geq 3.839756\\ldots")#linebreak()#text(" For ")#mi("d=11")#text(", ")#mi("H_{53}\\geq 3.867726\\ldots")#linebreak()#text(" For ")#mi("d=12")#text(", ")#mi("H_{53}\\geq 3.890762\\ldots")#linebreak()#text(" For ")#mi("d=13")#text(", ")#mi("H_{53}\\geq 3.909898\\ldots")

#text("It would be an easy computation to push this up to ")#mi("d\\leq 18")#text(". It appears that, at present, the convergence rate is somewhere in the interval ")#mi("[0.82,0.83]")#text(" (just as it was for ")#mi("k=54")#text("). If the numbers continue at the rate ")#mi("0.82")#text(" then it doesn’t appear that we ever get ")#mi("M_{53}\\geq 4")#text(", but if the rate is ")#mi("0.83")#text(" then we would need about ")#mi("d\\approx 30")#text(" to finally get ")#mi("M_{53}\\geq 4")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261995")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2014")])]

#text("Thank you for your perseverance, Pace! Let us hope that this (or a similarly efficient) choice of signatures is similarly effective for M’ and especially M”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262000")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2014")])]

#text("This confirms our earlier expectations about ")#mi("k = 53, 54")#text(" (it was expected that ")#mi("M_53")#text(" should be within 0.001 from 4.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262113")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2014")])]

#mi("M_k \\geq 4")#text(" is needed for EH[1/2], but with our current ")#mi("\\theta")#text(" it seems that we need only to have ")#mi("M_k \\geq 4-52/283 = 3.81625...")#text(" which is satisfied by ")#mi("k=53")#text(" (and expected to hold even for ")#mi("k = 45")#text(") but not for ")#mi("k = 41")#text(" (since the upper bound on ")#mi("M_{41}")#text(" is 3.806…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262128")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2014")])]

#text("It should be remarked that the above is not rigorous because")

#text("1. It is based on MPZ[")#mi("\\varpi, \\delta")#text("] for which the current estimates are only for the asymptotic case of ")#mi("H_m")#text(".")

#text("2. It is based on a tentative value of ")#mi("\\varpi")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262160")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2014")])]

#text("Yes, we still have to figure out how to effectively apply ")#mi("MPZ[\\varpi,\\delta]")#text(" to these low-k situations. The main problem is that ")#mi("\\delta")#text(" is no longer negligible in this regime – even with our most optimistic MPZ estimate, we cannot get ")#mi("\\delta")#text(" larger than ")#mi("\\frac{13}{330}")#text(", and so the quantity ")#mi("\\delta^{\\prime} = \\frac{\\delta}{1/4+\\varpi}")#text(" cannot be taken any larger than ")#mi("4 \\times \\frac{13}{330} = 0.157\\ldots")#text(". Now, a naive truncation of the simplex ")#mi("{\\cal R}_k")#text(" to allow us to use MPZ would leave us with ")#mi("{\\cal R}_k \\cap [0,\\delta^{\\prime}]^k")#text(". For large k, this is exponentially negligible, but with k being about 50, it’s somewhat noticeable; the fraction of volume of ")#mi("{\\cal R}_k")#text(" that is lost when passing to ")#mi("[0,\\delta^{\\prime}]^k")#text(" is roughly ")#mi("k (1-\\delta^{\\prime})^k")#text(", which for the best-case value of ")#mi("\\delta^{\\prime}")#text(", is about 0.01, so in principle this changes M_k by about 1% which corresponds to worsening k by one or two here.")

#text("In principle we can use the more advanced truncation used in Polymath8a, but it will be harder to estimate the errors; in 8a we had the advantage of some convexity properties of the Bessel function which allowed one to get civilised bounds on the errors, but from the numerical polynomials we have here, it is unlikely that we will be able to detect any analogous convexity.")

#text("An alternative approach would be to try to redo the Type I/II/III estimates with the aim of getting delta as large as possible (rather than varpi). We can take ")#mi("\\delta = 1/4+\\varpi")#text(" for free with the Selberg sieve construction; our Type III estimates can cope with such large values of delta (taking sigma=1/10), but not the Type I or Type II estimates, with the Type I being the bottleneck.")

#text("I guess what one can do is to start with the extremisers for the untruncated polytope that Pace located for a test value of k, say k=50, and try to compute what happens to M_k when one applies naive truncation for a given value of delta; i’ll try to work out some relevant formulae at some point (but today is busy for other reasons for me…).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262197")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2014")])]

#text("Inspired by the accuracy of my earlier prediction that M_54 would hit 4 when d=22, I’ve looked a little harder and found a way to quantify more precisely the trajectory of M_k with increasing d, which takes account of the fact that the convergence rate C_k,d = (M_k,d – M_k,d-1)/(M_k,d-1 – M_k,d-2) creeps up with d, and also of the fluctuation we have noted, i.e. that C_k,d is slightly larger than the trend when d is odd and smaller than the trend when d is even. Using the numbers that Pace just provided for M_53,d for d up to 13, I looked at the trend of C_k,d for even d and for odd d separately, and it seems that (C_k,d+2 – C_k,d) is very close to half of (C_k,d – C_k,d-2) when d exceeds 8; this also holds for the k=54 numbers that Pace provided before Christmas. I conclude that C_53,d converges to about 0.832, and that M_53,d is expected to surpass 4 at d=31. This may be of lower priority to explore than looking at M’ and M”, but the validity of the technique may be worth checking (in due course) in those settings too so that one can quickly home in on the right range of d to get the optimal k.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262206")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2014")])]

#text("In order to explore whether the above extrapolation is likely to hold up, let me give the values it predicts for M_53 for d=14 through 18, since Pace notes that those are easy to compute. I get 3.925720, 3.938891, 3.949805, 3.958898, 3.966443.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262221")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2014")])]

#text("PS: this extrapolation does not take into account the feature, mentioned by Pace earlier, that M may rise more slowly with d once d exceeds k/2. However, the extrapolation has M reaching 3.995 by the time d=26, so there’s reason for optimism that the remaining 0.005 can be bridged, even though d=31 may not quite suffice.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262397")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("Here are the actual values: 3.925704, 3.938848, 3.949699, 3.958708, 3.966121. [I’m now leaving these sorts of computations in favor of the ")#mi("\\epsilon")#text(" idea Terry introduced. I should have some results there later today.]")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262377")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("Considering the one dimensional approximation of ")#mi("F(t_1,...,t_k)")#text(" by a function ")#mi("f(P_1(t_1,...,t_k))")#text(" represented as a one dimensional integral (using e.g. probabilistic interpretation of the integral), is it possible to generalize it for approximation of type ")#mi("f(P_1, P_2)")#text(" by a (sufficiently simple) two dimensional integral ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262381")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("I meant that perhaps there is a sufficiently simple corresponding variational problem involving ratio of two dimensional integrals with optimal solution ")#mi("f(P_1, P_2)")#text(" which may be found exactly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262390")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("Well, in some sense this is what James and Pace have been doing numerically for moderate k: in James’ orginal paper he worked with polynomial combinations ")#mi("f(P_1,P_2)")#text(" of the first two symmetric polynomials ")#mi("P_1 = t_1+\\dots+t_k")#text(", ")#mi("P_2 = t_1^2+\\dots+t_k^2")#text(".")

#text("In principle, with the ansatz ")#mi("F = f(P_1,P_2)")#text(" the problem does collapse to a two-dimensional one, but I am not sure it is so easily solvable. The thing is that the marginal distribution ")#mi("\\int F\\ dt_m")#text(" of ")#mi("F")#text(" becomes an integral of f along a parabola. If one replaces P_2 by the elementary symmetric polynomial ")#mi("\\sum_{i<j} t_i t_j")#text(" then the marginal becomes an integral of f along a line, which looks a bit like a Radon transform so perhaps there is some chance of a clean formula there. On the other hand, the image of the simplex could be a little weird in these coordinates (I haven't tried to do the calculations yet).")

#text("Pace mentioned the phenomenon that the (partial) basis consisting of ")#mi("(1-P_1)^a m(\\alpha)")#text(" with all coefficients of ")#mi("\\alpha")#text(" even was a surprisingly efficient basis. I wonder if a similar phenomenon happens with James' original choice ")#mi("(1-P_1)^a P_2^b")#text(" of partial basis. If so, this may suggest further investigation of the ")#mi("f(P_1,P_2)")#text(" ansatz.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262398")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("Following Terry’s description of the ")#mi("\\epsilon")#text(" expansion, I think I have worked out the ")#mi("k=3")#text(" case, but I want to double-check here that the formulas I’m using for the integrals are correct. I used:")

#mi("I_{3,\\epsilon}(F) =\\int_{z=0}^{\\epsilon}\\int_{y=0}^{\\epsilon-z} \\int_{x=0}^{1} +\\int_{z=0}^{\\epsilon}\\int_{y=\\epsilon-z}^{1}\\int_{x=0}^{1+\\epsilon-y-z}")

#mi("+ \\int_{z=\\epsilon}^{1}\\int_{y=0}^{1+\\epsilon-z}\\int_{x=0}^{1+\\epsilon-y-z} F^2\\ dx\\ dy\\ dz")

#text("and")

#mi("J_{3,\\epsilon}^{(1)}(F)= \\int_{z=0}^{\\epsilon}\\int_{y=0}^{\\epsilon-z}(\\int_{x=0}^{1}F\\ dx)^2\\ dy\\ dz")

#mi("+ \\int_{z=0}^{\\epsilon}\\int_{y=\\epsilon-z}^{1-\\epsilon-z}+\\int_{z=\\epsilon}^{1-\\epsilon}\\int_{y=0}^{1-\\epsilon-z} (\\int_{x=0}^{1+\\epsilon-y-z}F\\ dx)^2\\ dy\\ dz")

#text("If those are correct, my computations yield that ")#mi("M_{3,0.23}\\geq 1.8615")#text(" using an arbitrary polynomial symmetric ")#mi("F")#text(" of degree 3. Increasing the degree further allows for slight improvements in the value of ")#mi("M_{3,\\epsilon}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262402")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("Yes, this looks like the correct formulae to me (assuming ")#mi("0 \\leq \\varepsilon \\leq 1/2")#text(", of course).")

#text("The fact that M_3 improved from 1.646 to 1.8615 (close to the 1.87459 that you got earlier from the 1D analysis without truncating to the unit cube) is a very promising sign, given that the separate improvement of getting from M_3 to M”_3 moves from 1.646 to 1.914. It gives hope that a combination of the two ways to “think outside the simplex” could even crack 2 in the k=3 case, giving ")#mi("H_1 \\leq 6")#text(" on EH (which I think would be a good point to declare victory for the EH case ;-) – if we somehow manage to get a fantastic value of M_3 like 2.5 or so then we might think about using the ")#mi("P_{0,6}")#text(" trick to even hope for ")#mi("H_1 \\leq 4")#text(", but I doubt that all our ideas put together will get that far yet.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262403")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("I worked out the ")#mi("k=4")#text(" case and get that ")#mi("M_{4,0.18}\\geq 2.0023")#text(". If someone would like to look over my Mathematica code to verify the computation just email me. (It involves a mixture of stuff I wrote, and stuff I borrowed from James; but it is very straightforward.)")

#text("I’ll start thinking about how to do the ")#mi("k=3")#text(" case with vanishing marginals and ")#mi("\\epsilon")#text(" expansion together. For some reason the vanishing marginals condition is still somewhat mysterious to me, and I have a few other jobs to finish this week, but I hope to get to it soon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262404")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("Bravo! As Terry has noted in the new thread, the vanishing is automatic for M’ (though not for M”), so it may be useful to start with M’, especially since (in the pre-epsilon world) M’_3 beats M_3 by almost 2/3 as much as M”_3 does.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262407")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("can you please give more information on the maximal degree and the number of monomials used for this new record?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262409")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("Actually this seems even more promising when noting that (again in the pre-epsilon setting) M’_3 is only 0.003 less than M_4 – hence you only need a similar improvement of M’ from introducing epsilon as you achieved for M, in order to reach 2 without any need to explore vanishing marginals.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262412")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("Eytan, I only used degree 1. It appears that when using larger degree, you can get close to the number predicted by your work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262418")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("It is really surprising (almost “too good to be true”) to get this remarkable record using only degree 1 monomials!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262426")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("I agree it is almost too good to be true, which is why I want someone to double check my computation. (But given that the computations agree with the old ones when ")#mi("\\epsilon =0")#text(", and that the numerics seem to be converging below the bound you obtained, I think everything is okay.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262435")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("The bound ")#mi("M_{4, \\epsilon}")#text(" is not sufficient (a modified bound corresponding to a variational problem for a simplex truncated by a cube is needed – I’m trying to solve it.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262437")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("I think there may be some confusion with regards to notation: I believe (based on his description of his k=3 analysis) that when Pace is referring to ")#mi("M_{k,\\varepsilon}")#text(", he is in fact referring to what we’ve also called ")#mi("M_{k,\\varepsilon,1}")#text(", in which the function F is supported on the truncated simplex ")#mi("(1+\\varepsilon) \\cdot {\\cal R}_k \\cap [0,1]^k")#text(", rather than the untruncated simplex ")#mi("(1+\\varepsilon) \\cdot {\\cal R}_k")#text(". For the latter, Pace got a lower bound of 2.01869 for k=4 using the 1D ansatz at ")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262158")[#text("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262158")]#text(", which is consistent with the slightly smaller bound of 2.0023 reported for (what I believe is) the truncated simplex problem ")#mi("M_{4,\\varepsilon,1}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262469")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("Terry is correct, I was using the wrong notation. Those bounds are for ")#mi("M_{k,\\epsilon,1}")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262436")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("Excellent! So it looks like we have k=4 (and hence ")#mi("H_1 \\leq 8")#text(") on EH, finally dethroning that stubborn bound of 12 on EH that we had not been able to improve upon since the start of Polymath8b. (If you have explicit coefficients for the polynomial optimiser, we would be able to check the various four-dimensional integrals separately with just about any computational mathematics package.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262470")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("I’ll get those coefficients to you tomorrow.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262499")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("I planned to give you the polynomial from my work computer tomorrow, but knowing that we only need a linear solution it was a simple task to solve for the polynomial another way. So take ")#mi("k=4,\\epsilon=0.18,F(x,y,z,w)=1-0.784(x+y+z+w)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262511")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("Maple confirms the value of 2.002351848 for these choices of parameters – looks like ")#mi("H_1 \\leq 8")#text(" on EH is solid.")

#raw("\neps := 0.18;\na := 0.784;\ndenominator := int( (1-a*t)^2 * t^3/6, t=0..1+eps) - 4 * int( (1-a*(t+1))^2 * t^3/6, t=0..eps );\nnumerator := int( int( 1-a*(t+s), s = 0..1)^2 * t^2/2, t=0..eps) + int( int( 1-a*(t+s), s=0..1+eps-t)^2 * t^2/2, t=eps..1-eps);\nM := 4 * numerator / denominator;\nevalf(M);\n")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262627")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("It is really impressive to get this new record using only linear one dimensional sieve! this shows that the ")#mi("\\epsilon")#text("-relaxation method is very powerful!")#linebreak()#text(" (now it seems that even ")#mi("k=3")#text(" is possible.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3bc492b7ea80151fc0bf64df5c32a90a4d37a7b60ece3ba1189b7d488e14c363-5fec9fc931274369e5b19078054064ef3387a3350b4d0c9b384ee81f82f18dcf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tony Feng")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-301776")[#strong[#text("Tony Feng")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2014")])]

#text("I apologize if I am misunderstanding, but this requires only EH and not GEH, right? I am wondering why the wiki page still says that 12 is the best result known on EH only.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-301788")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2014")])]

#text("Back in January we didn’t fully appreciate the difference between EH and GEH, and referred to the two hypotheses interchangeably. As it turns out, if we wish to leave the standard simplex ")#mi("{\\mathcal R}_k")#text(" (i.e. to rely on any M-quantity other than the “vanilla” ")#mi("M_k")#text(") then (when ")#mi("\\theta=1")#text(") we have to use GEH to control the “denominator” in the sieve analysis; it *may* be possible to rely just on EH using Bombieri’s asymptotic sieve, but this has not been attempted.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8b, V: Stretching the sieve support further | What's new")]], [#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262399")[#strong[#text("Polymath8b, V: Stretching the sieve support further | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("[…] for small values of (in particular ) or asymptotically as . The previous thread may be found here. The currently best known bounds on can be found at the wiki page (which has recently returned to […]")
]
