// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/
// Converted to Typst by tao2typ: "2026-10-14T11:12:39.884109+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The equational theories project: a brief tour", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The equational theories project: a brief tour")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 October 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/")[#text("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Almost three weeks ago, I ")#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/")[#text("proposed a collaborative project")]#text(", combining the efforts of professional and amateur mathematicians, automatic theorem provers, AI tools, and the proof assistant language Lean, to describe the implication graph relating the ")#link("https://github.com/teorth/equational_theories/blob/main/data/equations.txt")[#text("4694 equational laws for magmas")]#text(" that can be expressed using up to four invocations of the magma operation. That is to say, one needs to determine the truth or falsity of the ")#mi("{4694*(4694-1)=22028942}")#text(" possible implications between the these 4694 laws.")

#text("The project ")#link("https://teorth.github.io/equational_theories/")[#text("was launched")]#text(" on the day of the blog post, and has been running for a hectic 19 days thus far; see ")#link("https://github.com/teorth/equational_theories/wiki/Terence-Tao's-personal-log")[#text("my personal log of the project")]#text(" for a day-by-day summary of events. From the perspective of raw implications resolved, the project is (of the time of writing) 99.9963% complete: of the ")#mi("{22028942}")#text(" implications to resolve, ")#mi("{8178279}")#text(" have been proven to be true, ")#mi("{13854531}")#text(" have been proven to be false, and only ")#mi("{826}")#text(" remain open, although even within this set, there are ")#mi("{249}")#text(" implications that we conjecture to be false and for which we are likely to be able to formally disprove soon. For reasons of compilation efficiency, we do not record the proof of every single one of these assertions in Lean; we only prove a smaller set of ")#mi("{592790}")#text(" implications in Lean, which then imply the broader set of implications through transitivity (for instance, using the fact that if Equation ")#mi("{X}")#text(" implies Equation ")#mi("{Y}")#text(" and Equation ")#mi("{Y}")#text(" implies Equation ")#mi("{Z}")#text(", then Equation ")#mi("{X}")#text(" implies Equation ")#mi("{Z}")#text("); we will also shortly implement a further reduction utilizing a duality symmetry of the implication graph.")

#text("Thanks to the tireless efforts of ")#link("https://github.com/teorth/equational_theories/graphs/contributors")[#text("many volunteer contributors to the project")]#text(", we now have a number of nice visualization tools to inspect various portions of the (not quite completed) implication graph. For instance, ")#link("https://teorth.github.io/equational_theories/graphiti/?render=true&implies=1491&highlight_red=1491")[#text("this graph")]#text(" depicts all the consequences of ")#link("https://teorth.github.io/equational_theories/implications/?1491")[#text("Equation 1491")]#text(": ")#mi("{x = (y \\diamond x) \\diamond (y \\diamond (y \\diamond x))}")#text(", which I have nicknamed the “")#link("https://github.com/teorth/equational_theories/wiki/Tour-of-selected-equations#equations-65-x--y--x--y--x-1491-x--y--x--y--y--x-asterix-and-obelix")[#text("Obelix law")]#text("” (and it has a companion, the “")#link("https://github.com/teorth/equational_theories/wiki/Tour-of-selected-equations#equations-65-x--y--x--y--x-1491-x--y--x--y--y--x-asterix-and-obelix")[#text("Asterix law")]#text("“, ")#link("https://teorth.github.io/equational_theories/implications/?65")[#text("Equation 65")]#text(": ")#mi("{x = (y \\diamond (x \\diamond (y \\diamond x)))}")#text("). And here is a ")#link("https://teorth.github.io/equational_theories/implications/")[#text("table of all the equational laws")]#text(" we are studying, together with a count of how many laws they imply, or are implied by. These interfaces are also somewhat integrated with Lean: for instance, you can ")#link("https://live.lean-lang.org/#codez=JYWwDg9gTgLgBAWQIYwBYBtgCMB0AVJAYxmEICgzD0kBnGxJAcxCTgApBG4DgC448BPMAFM4AfQCUcAO6ohUIWThwIYHnC6AkwnVwtHCsAB2AM2AAPbgDYArHABEcQOOkduAF4AfA2ZIcKikixY8gBucACiAI4ArijAEAYAjAAsAJzx7ADivALCYpIA2shecOkAujwucIAARHCmcPxq6QA0Na7s9U6mkk5s7W2ONeLifgHBYVExcQDMVskZWYIiEnAFTCzFZdwV1bW8TS0drWy1HV01FGhC0EIgY9EkcUmpoqBgmEI0ohF3sQbTs2yZPgLXLLQprUrsVC8L4TBIpNLpSTQ8b3X4zYrlOBYfiKOA0aBQfhAA")[#text("click here")]#text(" to try your hand at showing that the Obelix law implies ")#link("https://teorth.github.io/equational_theories/implications/?359")[#text("Equation 359")]#text(", ")#mi("{x \\diamond x = (x \\diamond x) \\diamond x}")#text("; I’ll leave this as a challenge (a four-line proof in Lean is possible).")

#text("Over the last few weeks, I’ve learned that many of these laws have previously appeared in the literature, and compiled a “tour” of these equations ")#link("https://github.com/teorth/equational_theories/wiki/Tour-of-selected-equations")[#text("here")]#text(". For instance, in addition to the very well known commutative law (")#link("https://teorth.github.io/equational_theories/implications/?43")[#text("Equation 43")]#text(") and associative law (")#link("https://teorth.github.io/equational_theories/implications/?4512")[#text("Equation 4512")]#text("), some equations (")#link("https://teorth.github.io/equational_theories/implications/?14")[#text("Equation 14")]#text(", ")#link("https://teorth.github.io/equational_theories/implications/?29")[#text("Equation 29")]#text(", ")#link("https://teorth.github.io/equational_theories/implications/?381")[#text("Equation 381")]#text(", ")#link("https://teorth.github.io/equational_theories/implications/?3722")[#text("Equation 3722")]#text(", and ")#link("https://teorth.github.io/equational_theories/implications/?3744")[#text("Equation 3744")]#text(") appeared in some Putnam math competitions; ")#link("https://teorth.github.io/equational_theories/implications/?168")[#text("Equation 168")]#text(" defines a fascinating structure, known as a “central groupoid”, that was studied in particular ")#link("https://zbmath.org/0207.32901")[#text("by Evans")]#text(" and ")#link("https://zbmath.org/0192.34501")[#text("by Knuth")]#text(", and was a key inspiration for the ")#link("https://en.wikipedia.org/wiki/Knuth%E2%80%93Bendix_completion_algorithm")[#text("Knuth-Bendix completion algorithm")]#text("; and ")#link("https://teorth.github.io/equational_theories/implications/?1571")[#text("Equation 1571")]#text(" classifies abelian groups of exponent two.")

#text("Thanks to the ")#link("https://en.wikipedia.org/wiki/Birkhoff%27s_theorem_(equational_logic)")[#text("Birkhoff completeness theorem")]#text(", if one equational law implies another, then it can be proven by a finite number of rewrite operations; however the number of rewrites needed could be quite lengthy. The implication of 359 from 1491 mentioned above is already moderately challenging, requiring four or five rewrites; the implication of Equation 2 from ")#link("https://teorth.github.io/equational_theories/implications/?1689")[#text("Equation 1689")]#text(" is incredibly long (")#link("https://live.lean-lang.org/#codez=JYWwDg9gTgLgBAWQIYwBYBtgCMB0AVJAYxmEICgzD0kBnGxJAcxCTgApBG4DgC448BPMAFM4AfQCUcAO6ohUIWThwIYHnC6AkwnVwtHCsAB2AM2AAPbgDYArHABEcQOOkduAF4AfA2ZIcKikixY8gBucACiAI4ArijAEAYAjBYAHACc7ADivALCYpIA2shecOkAujwucIAARHCmcPxwAF5q6QA0Na7s9U6mkk5sbLVODb2N4n4BwWFRMXEATBlZgiIScAVMLMVl3BXVtfW8re0V/BRoQtBCIFPRJHGJqaKgYJhCNKIRN7EG82yZfEu5VaFDaldioXgfGYJZJpdKSCHTW7fYrlOBYE5KGjQKD8IA")[#text("try it")]#text("!). Nevertheless, standard automated theorem provers, such as ")#link("https://en.wikipedia.org/wiki/Vampire_(theorem_prover)")[#text("Vampire")]#text(", are quite capable of proving the vast majority of these implications.")

#text("More subtle are the ")#emph[#text("anti-implications")]#text(", in which we have to show that a law ")#mi("{X}")#text(" does not imply a law ")#mi("{Y}")#text(". In principle, one just has to exhibit a magma that obeys ")#mi("{X}")#text(" but not ")#mi("{Y}")#text(". In a large fraction of cases, one can simply search through small finite magmas – such as magmas on two, three, or four elements – to obtain this anti-implication; but they do not always suffice, and in fact we know of anti-implications that can only be proven through a construction of an infinite magma. For instance, the “Asterix law” is now known (from the efforts of this project) to ")#link("https://teorth.github.io/equational_theories/blueprint/asterix-chapter.html")[#text("not imply")]#text(" the “Obelix law”, but all counterexamples are necessarily infinite. Curiously, the known constructions have some affinity with the famous technique of ")#link("https://en.wikipedia.org/wiki/Forcing_(mathematics)")[#text("forcing")]#text(" in set theory, in that we continually add “generic” elements to a (partial) magma in order to force a counterexample with certain specified properties to exist, though the constructions here are certainly far simpler than in the set-theoretic constructions.")

#text("We have also obtained profitable mileage out of constructions of “linear” magmas ")#mi("{x \\diamond y = ax + by}")#text(" in both commutative and non-commutative rings; free magmas associated to “")#link("https://en.wikipedia.org/wiki/Confluence_(abstract_rewriting)")[#text("confluent")]#text("” equational laws, and more generally laws with complete ")#link("https://en.wikipedia.org/wiki/Abstract_rewriting_system")[#text("rewriting systems")]#text(". As such, the number of unresolved implications continues to shrink at a steady pace, although we are not yet ready to declare victory on the project.")

#text("After quite hectic amount of back end setup and “putting out fires”, the project is now running fairly smoothly, with activity coordinated on a ")#link("https://leanprover.zulipchat.com/#narrow/stream/458659-Equational")[#text("Lean Zulip channel")]#text(", and all contributions going through a pull request process on Github, and tracked via an ")#link("https://github.com/users/teorth/projects/1")[#text("issues-based Github project")]#text(" with the invaluable oversight provided by the other two maintainers of the project, ")#link("https://github.com/pitmonticone")[#text("Pietro Monticone")]#text(" and ")#link("https://www.maths.ox.ac.uk/study-here/postgraduate-study/msc-mathematics-and-foundations-computer-science/mfocs-student/shreyas")[#text("Shreyas Srinivas")]#text(". In contrast to the prior ")#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/")[#text("PFR formalization project")]#text(", the workflow follows standard Github practices and proceeds roughly as follows: if, during the course of the Zulip discussion, it becomes clear that some specific task needs to be done to move the project forward (e.g., to formalize in Lean the proof of an implication that had been worked out in the discussion threads), an “issue” is made (often by myself or one of the other maintainers), which other contributors can then “claim”, work on separately (using a local copy of the main Github repository), and then submit a “pull request” to merge their contribution back into the main repository. This request can then be reviewed by both maintainers and other contributors, and if approved, closes the relevant issue.")

#text("More generally, we are trying to document all of the processes and lessons learned from this setup, and this will be part of a forthcoming paper on this project, which we are now in the ")#link("https://github.com/teorth/equational_theories/wiki/Plan-of-paper")[#text("preliminary stages of planning")]#text(", and will likely include dozens of authors.")

#text("While the project is still ongoing, I can say that I am quite satisfied with the progress accomplished to date, and that many of my hopes for such a project have already been realized. On the scientific side, we have discovered some new techniques and constructions to show that a given equational theory does not imply another one, and have also discovered some exotic algebraic structures, such as the “Asterix” and “Obelix” pair, that have interesting features, and which would likely not have been discovered by any means other than the type of systematic search conducted here. The participants are very diverse, ranging from mathematicians and computer scientists at all stages of career, to interested students and amateurs. The Lean platform has worked well in integrating both human-generated and machine-generated contributions; the latter are numerically by far the largest source of contributions, but many of the automatically generated results were first obtained in special cases by humans, and then generalized and formalized (often by different members of the project). We still make many informal mathematical arguments on the discussion thread, but they tend to be rapidly formalized in Lean, at which point disputes about correctness disappear, and we can instead focus on how best to deploy various verified techniques to tackle the remaining implications.")

#text("Perhaps the only thing that I was expecting to see at this point that has not yet materialized is significant contributions from modern AI tools. They are being used in a number of secondary ways in this project, for instance through tools such as Github copilot to speed up the writing of Lean proofs, the ")#link("https://teorth.github.io/equational_theories/blueprint/")[#text("LaTeX blueprint")]#text(", and other software code, and several of our visualization tools were also largely co-written using large language models such as Claude. However, for the core task of resolving implications, the more “good old-fashioned” automated theorem provers have so far proven superior. However, most of the remaining 700 or so implications are not amenable to these older tools, and several (particularly the ones involving “Asterix” and “Obelix” had stymied the human collaborators for several days), so I can still see a role for modern AI to play a more active role in finishing off the hardest and most stubborn of the remaining implications.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (28)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of WFL")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686013")[#strong[#text("WFL")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2024")])]

#link("https://www.imdb.com/title/tt14164922/")[#text("Astérix & Obélix")]#text(" , s’il vous plait! WFL")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b9d2b471a95950cf9ab900a2a956433a802e53dd7dce19b8f99e969eecbfb6d-928b219cdc034ba412fab685a5c24ece80537934e15e706cc872bf337f74deba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of allenknutson")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686019")[#strong[#text("allenknutson")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2024")])]

#text("Indeed, it’s Obelix not Oberlix, by Toutatis!")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b4b839e096870bd0a232e5aa9457125af1c2515d8a27c51f3f43896bbce740b-ab922a9613e39f5f7a45c484e5a137613e8928de1fbfde28f3953381436e9307.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tony Vladusich")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686015")[#strong[#text("Tony Vladusich")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2024")])]

#text("It’s really amazing to see the group use standard GitHub tooling and procedures for this project. I hope this sort of collaborative approach to problem solving can be generalised in future to other scientific domains to which it may be amenable. I have in mind projects like collaboratively developing mathematical / computational models to solve problems in computer and human vision, at least in cases where the problem can be stated succinctly and clearly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686017")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2024")])]

#text("The tools are standard. The procedures are not. In the typical OSS project on GitHub you don’t have any rules about who can open an issue or open a PR. If someone opens an issue or PR that doesn’t make sense, maintainers can just close it. You can also have competing PRs, that address the same issue. This model doesn’t make sense for projects where cooperation and taking one’s time to solve the problem is important. We have tried to fix this with a GitHub project plus CI scripts that makes sure that only one person can claim a project at a time, and then propose or withdraw a PR. On the one hand this gives contributors the assurance that they can work in peace on the task. On the maintainers’ side, this means we only have to look at PRs linked to tasks on the project dashboard, which only maintainers can put issues on. When a contributor wants to put a task up there, we ask them to create an issue and discuss it on zulip. This makes the maintainers’ job somewhat simpler. The movement of the task between various columns on the dashboard is more or less automatic (modulo bugs)")

#text("All that being said, GitHub projects has to improve a lot to support this collaboration more easily.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686018")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2024")])]

#text("Same commenter as above:")

#text("This is a drastic improvement over the process followed in last year’s Polynomial Freeman Rusza project which was managed by manually updated task lists and manually processed claims + tracking completion on zulip every other evening.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686021")[#strong[#text("对等式理论项目的一次参观 - 偏执的码农")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2024")]

#text("[…] 详情参考 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686023")[#strong[#text("An Interesing Algebra Exercise Challenge – Poelogic's Possible World")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2024")]

#text("[…] I have an interesting reading of Terrence Tao’s community-collaborative project on the equational theories. He mentioned an interesting algebra exercise as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686045")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2024")])]

#text("I have some questions about computability theory. As far as the discussion here involving the Birkhoff completeness theorem goes, should there be any effective bound on the number of sets? Should the least number of steps in terms of the size of the input (number of variables, or characters in the equation etc) grow faster than any computable function? Do busy beaver numbers start coming up? Is this general problem undecidable?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686051")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2024")])]

#text("The general problem is indeed undecidable – this is a [result of McKenzie](")#link("https://www.cambridge.org/core/journals/journal-of-symbolic-logic/article/on-spectra-and-the-negative-solution-of-the-decision-problem-for-identities-having-a-finite-nontrivial-model1/101AF2F2F2858A6265074FD677B154E0")[#text("https://www.cambridge.org/core/journals/journal-of-symbolic-logic/article/on-spectra-and-the-negative-solution-of-the-decision-problem-for-identities-having-a-finite-nontrivial-model1/101AF2F2F2858A6265074FD677B154E0")]#text(") – and as a consequence the shortest length of a proof will in fact eventually grow faster than any computable function and thus exhibit busy beaver type behavior.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686048")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2024")])]

#text("(by number of “sets” I meant “steps” or as you call them, “rewrites”)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686049")[#strong[#text("等式理论项目：简短介绍 - 偏执的码农")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2024")]

#text("[…] 详情参考 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f450d911a1b431419d0bba7c46fc6e84febb235170a84aa90a5ddb8f948ef81-b9a063b5b2c61598381cf3d9411536bb6ce91886a1cfc756cc136f738d70c0ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomtom2357")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686052")[#strong[#text("tomtom2357")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2024")])]

#text("Could you explain the difference between explicitly true and implicitly true in the stats on your daily log?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686112")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2024")])]

#text("At present we are not attempting to explicitly formalize all 22 million implications or anti-implications in Lean, as the compilation time would be prohibitively large. Instead, we are only explicitly formalizing in Lean a much smaller set of (anti-)implications, which imply the remaining (anti-)implications by transitivity (and duality). For instance, if we know that equation X implies equation Y, and equation Y implies equation Z, we can also conclude that equation X implies equation Z, but at present we only explicitly formalize the first two statements in the Lean codebase and not formalize the third.")

#link("https://leanprover.zulipchat.com/#narrow/channel/458659-Equational/topic/A.20final.20end-to-end.20theorem.20in.20Lean")[#text("We are discussing")]#text(" how to refactor the codebase once the project is complete to obtain an “end-to-end Lean” theorem that actually formalizes the entire implication graph 100% inside Lean, but this is not an urgent priority at this stage of the project.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686053")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2024")])]

#text("It is good to see Vampire winning over LLMs on these problems. For people working with ATP systems, this is not surprising. LLMs are usually not so good on hard new reasoning problems where a lot of search is needed. One useful analogy to consider are SAT solvers. They are orders of magnitude better on the kind of open math problems they solve than LLMs would be. As for “modern AI”, perhaps some mathematicians can use this to update their beliefs, bias and language. We pay scientists to be critical and to use the scientific method, not to parrot various industry hypes and fads.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a184084c74063b451bb0437d7efa56e0538bb780ccb4fb5add45a7d15cc34832-b10e62482610839a3087fb84d1b0fb0d549ef5abf20f40c9a1fd8c3a875500f5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of diofeq")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686504")[#strong[#text("diofeq")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2024")])]

#text("Where it is possible to see explicitly 8 open implications, and whether any of them are equivalent?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686507")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2024")])]

#text("One can use our “")#link("https://teorth.github.io/equational_theories/implications/")[#text("Equation explorer")]#text("” tool for this. If you click on “hide fully-solved equations” and unclick “Treat conjectures as unknown” then you will see all the equations with conjecturally unresolved incoming and outgoing implications; clicking on any one of them will then lead to another page where you can see the specific implications.")

#text("At this time of writing, we have eight unresolved implications: 1323->2744 (and its dual 2304->883), 1516->255 (and its dual 2091->47), 1729->817 (and its dual 1898->2644), and 1729->917 (and its dual 1898->2710).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11eed6da60c8c3306b786526064a8733f4f9d93b704ca3e0f3fb4adf50337aaf-60a0d2262bea3c0344fd29fb667c13ed056a99cc3408620fae5cf70e30ad4e21.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Mertens")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686578")[#strong[#text("Martin Mertens")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2024")])]

#text("Were there any surprising cases where two equations turned out to be logically equivalent?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686579")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2024")])]

#text("There are a few equivalences where the proof is extremely long, most notably the equivalence of ")#link("https://teorth.github.io/equational_theories/implications/?1689")[#text("equation 1689")]#text(" ")#mi("x = (y \\diamond x) \\diamond ((x \\diamond z) \\diamond z)")#text(" and the trivial law. However, all the positive implications we have found, are within the reach of current automated theorem provers, so in some sense there were no “surprises” on the positive end. All the difficult results we have obtained that required human ingenuity have been on the negative side, i.e., in constructing counterexamples that obeyed one law but not another.")

#text("However, there was a recent surprising positive implication when restricting to *finite* magmas: just today, ")#link("https://leanprover.zulipchat.com/#narrow/channel/458659-Equational/topic/Austin.20pairs/near/480601897")[#text("we showed")]#text(" that equation 3308 ")#mi("x \\diamond y = x \\diamond (x \\diamond (y \\diamond x))")#text(" implies equation 3549 ")#mi("x \\diamond y = x \\diamond ((x \\diamond y) \\diamond x)")#text(" for finite magmas, even though this implication does not hold for infinite magmas. The proof required a combinatorial lemma that is not entirely trivial to prove: given two functions ")#mi("f, g: X \\to X")#text(" on a finite set ")#mi("X")#text(", the identity ")#mi("f \\circ f \\circ g = f")#text(" implies the identity ")#mi("f \\circ g \\circ f = f")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686585")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2024")])]

#text("Hello Prof. Tao,")

#text("thanks for your great blog. I did read your linked proof of Lemma 1 in the zulip chat and I couldn’t follow one step. Maybe you could help me understand it:")

#text("You write in the middle part of that proof that if ")#mi("n_x > 1")#text(", one has that ")#mi("g(x), f(g(x)), f(f(g(x)))")#text(" are not periodic and that ")#mi("n_{g(x)} = n_x + 1")#text(". In the next sentence you note that ")#mi("n_x \\geq 1")#text(".")

#text("How do you make that implication from the first sentence to the second one.")

#text("Thanks a lot!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686597")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2024")])]

#text("Since ")#mi("X")#text(" is finite, there must be an element ")#mi("x")#text(" that maximizes the quantity ")#mi("n_x")#text(". If this maximum exceeds 1, this leads to a contradiction by the first sentence, since ")#mi("n_{g(x)}")#text(" exceeds the maximum. Thus the maximum can be at most 1, that is to say ")#mi("n_x \\leq 1")#text(" for all ")#mi("x")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686600")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2024")])]

#text("Thank you!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-686838")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2024")])]

#text("Just a small note regarding your personal log: I think the dates for “Day 59” and “Day 62” are off by one; if I’m not mistaken, the former should be “Nov 26,” while the latter should be “Nov 29.”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-687149")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2025")])]

#text("Sorry for this question being naive as I’m an amateur but am curious if the effort to determine the implication graph of up to 4 invocations of the magma operations bears some relationship to that of documenting all Turing machines (of up to say 4 steps) to determine which ones halt or don’t and finding the busy beaver number?")

#text("The two seem to have a similar ‘flavor’, like in how some implications end up particularly hard to prove vs. some turing machines behaving in a hard-to-pin-down way, so was wondering if one project maps onto the other in some way?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-687150")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2025")])]

#text("Tristan Sterin, who launched the Busy Beaver challenge, made ")#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/#comment-685895")[#text("a very insightful comment on a previous blog post")]#text(" on this project. They are not directly related, but certainly share many similarities: in both projects, the majority of contributors were not professional mathematicians, but were able to self-organize due to the modular nature of the project, a clear numerical goal (basically, in reducing the number of unresolved implications on ")#link("https://teorth.github.io/equational_theories/dashboard/")[#text("this dashboard")]#text("), a variety of useful visualization tools, and a ")#link("https://leanprover.zulipchat.com/#narrow/channel/458659-Equational")[#text("highly active chat forum")]#text(" (though less active now that the project is winding down).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-687869")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2025")])]

#text("I know this is shoehorning things in and implicitly violates the 4 operation limitation, but bending the rules somewhat eq 3734 looks like the self-distributive law for a rack —")

#link("https://wikimedia.org/api/rest_v1/media/math/render/svg/821f8ac6acef4d7904e52aad0192e9d5ba219f31")[#text("https://wikimedia.org/api/rest_v1/media/math/render/svg/821f8ac6acef4d7904e52aad0192e9d5ba219f31")]

#text("by the following substitutions —")

#text("a –> x")

#text("b < c –> y")

#text("b–> z")

#text("c –> w")

#text("Again, understand this bending the rules, but racks have been on my mind recently, so was looking for a pattern here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-687901")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2025")])]

#text("Thanks for the observation! In our numbering system, this is equation 56085; I’ve added it to the extended list of notable laws at ")#link("https://github.com/teorth/equational_theories/wiki/Tour-of-selected-equations")[#text("https://github.com/teorth/equational_theories/wiki/Tour-of-selected-equations")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Equational Theories Project: Advancing Collaborative Mathematical Research at Scale | What's new")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-689290")[#strong[#text("The Equational Theories Project: Advancing Collaborative Mathematical Research at Scale | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2025")])]

#text("[…] for the Equational Theories Project, which was proposed in this blog post and also showcased in this subsequent blog post. The aim of this project was to see whether one could collaboratively achieve a large-scale […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mathematics Distillation Challenge – Equational Theories | What's new")]], [#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/#comment-691980")[#strong[#text("Mathematics Distillation Challenge – Equational Theories | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2026")])]

#text("[…] And in 2024, I launched the Equational Theories Project (ETP) (discussed on this blog here and here), combining the rigor of Lean formalization with “good old fashioned AI” (in the form […]")
]
