// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/22/open-problems-open-mathematics/
// Converted to Typst by tao2typ: "2026-10-16T11:41:31.961543+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Open problems, open mathematics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Open problems, open mathematics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/22/open-problems-open-mathematics/")[#text("https://terrytao.wordpress.com/2026/09/22/open-problems-open-mathematics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-16 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://sites.math.northwestern.edu/~auffing/")[#text("Antonio Auffinger")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("Despite writing papers in pure mathematics, much of my time in the past decade was spent talking (mostly listening, to be accurate) to biologists, computer scientists, and physicists. Theoretical physics and computer science are grounded in mathematics and thus share much of our language and, to some extent, our culture. The barriers between biology and mathematics are an order of magnitude higher. I am convinced that biologists are part of a different species. The language, incentives, culture, training, and everything else you might think of appear to be completely disconnected from the way we do mathematics. Yet, the similarities are abundant: the pursuit of understanding, the excitement of discovery when new patterns or phenomena emerge, and the hours needed to make minor advances, sometimes leaving us with just frustration. The intuition of setting up a new experiment feels like witchcraft to me, much like our way of finding connections between different abstract objects feels like magic to them.")

#text("What does talking to biologists have to do with the future of mathematics?")

#text("It could be beneficial to look at what is happening and what has happened with our neighbors, even if none of us can predict where we will be two years (or even three months) from now. A first lesson that I learned is that a large part of biology is technology-driven. Fields completely change, emerge, and die in a matter of years. The advent of ")#link("https://en.wikipedia.org/wiki/CRISPR")[#text("CRISPR")]#text(", ")#link("https://en.wikipedia.org/wiki/RNA-Seq")[#text("RNA-seq")]#text(", and ")#link("https://en.wikipedia.org/wiki/Cryogenic_electron_microscopy")[#text("cryo-EM")]#text(", for instance, suddenly allowed humans to observe and manipulate phenomena that were previously inaccessible. These tools generate precious data, and the incentives often favor a culture of seclusion, where discoveries are frequently not shared until the final product is complete.")

#text("This has made me appreciate the culture of mathematics. Mathematics has never been free of competition or secrecy, but we abundantly share. We share ideas, we share problems, and we share entire skeletons of approaches with our colleagues, with visitors we just met, in talks, in public forums, and on YouTube. I suspect the enormous effort often needed to produce a proof, even with a full outline, has helped sustain this openness. Mathematicians and mathematics have deeply benefited from this open attitude. Many new connections and major discoveries have started with honest conversations at coffee breaks, in hallways, or on hiking trails. Sharing ideas or arguments before they are fully formed allows others to see pathways we missed, point out obstacles, or take the problem in directions we had not imagined. Also, it is simply more fun to do math together.")

#text("My worry is that this unselfish openness will become a thing of the past. If proof generation becomes a fast, accessible commodity while our ways of giving credit remain unchanged, mathematicians (especially those still building their careers) may feel encouraged to optimize locally in ways that weaken our culture of sharing. In the past few weeks, I have had colleagues reach out for advice and tell me they will no longer post on ")#link("https://arxiv.org/")[#text("arXiv")]#text(". I have witnessed trainees posting rushed papers online for fear that others could quickly carry out strategies already outlined in previous work. I am also part of the problem, as I have started advising my students to be extra careful when sharing work in progress.")

#text("Biology also offers examples of communities deliberately changing these incentives. During the ")#link("https://en.wikipedia.org/wiki/Human_Genome_Project")[#text("Human Genome Project")]#text(", the ")#link("https://en.wikipedia.org/wiki/Bermuda_Principles")[#text("Bermuda Principles")]#text(" called for the rapid public release of sequence data. Later, the ")#link("https://www.sanger.ac.uk/wp-content/uploads/fortlauderdalereport.pdf")[#text("Fort Lauderdale Agreement")]#text(" tried to balance this openness with proper recognition of those generating the data, placing responsibilities not only on researchers producing and using the data but also on funding agencies. Although it is focused on data, it is an example where the status quo was changed by community intervention.")

#text("I do not know what the right analogue is for mathematics, but I believe we need to start thinking about it. I encourage the community to reshape our incentives and the way we give credit, to ensure broad accessibility to these new tools, and to make openness a reasonable choice, especially for those still building their careers. Senior mathematicians must engage in serious conversations about ethical use with their trainees. In turn, trainees should be encouraged to truly explore, because many of the solutions to the issues we currently face as a community will come from them.")

#text("None of this is an argument against the use of AI in mathematics. I believe these tools will raise the ceiling of the things we can discover, leading mathematicians to ask new questions and understand new phenomena.")

#text("This brings me to the second lesson I learned from my biology colleagues: many of the questions I hear from biologists need mathematics. New mathematics. There is room here for topologists, number theorists, dynamicists, algebraic geometers, analysts, etc. This is not just because of our capacity as proof builders, but also because of our capacity for abstraction and for understanding phenomena. Applied sciences are generating complex, time-dependent data that require new methods and theories. This is also a two-way street. Decades ago, topology and knot theory unexpectedly provided a framework for understanding ")#link("https://en.wikipedia.org/wiki/Topoisomerase")[#text("how enzymes untangle and rearrange DNA")]#text(". In the other direction, attempts to understand population genetics and ")#link("https://en.wikipedia.org/wiki/Genetic_drift")[#text("how gene frequencies drift over time")]#text(" helped motivate new classes of infinite-dimensional stochastic processes, including ")#link("https://en.wikipedia.org/wiki/Fleming%E2%80%93Viot_process")[#text("measure-valued diffusions")]#text(". Today, geometry and probability underlie ")#link("https://en.wikipedia.org/wiki/Nonlinear_dimensionality_reduction")[#text("dimension reduction methods")]#text(" that biologists use daily to make sense of massive ")#link("https://en.wikipedia.org/wiki/Single-cell_sequencing")[#text("single-cell datasets")]#text(", such as ")#link("https://en.wikipedia.org/wiki/T-distributed_stochastic_neighbor_embedding")[#text("t-SNE")]#text(" and ")#link("https://en.wikipedia.org/wiki/Nonlinear_dimensionality_reduction#Uniform_manifold_approximation_and_projection")[#text("UMAP")]#text(".")

#text("I am not suggesting that mathematicians need to pivot to biology or any applied science. The pursuit of mathematics for its own sake is the absolute bedrock of our field and that must remain intact. However, as AI changes the landscape, looking outward presents an incredible opportunity to discover new questions, new phenomena and new mathematics, and perhaps AI might even lower the barriers to taking that leap.")

#text("Mathematics has much to offer the other sciences, and much to learn from them. I am looking forward to what comes next. Proofs may increasingly be generated by machines, but the ultimate purpose of mathematics remains exactly what it has always been: to ask questions and to understand.")

#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/open-problems-open-mathematics/comment-page-1/#comment-696134")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("You say “Senior mathematicians must engage in serious conversations about ethical use with their trainees”. This is impossible. Ethics requires community standardization and systemic enforcement. Currently, with AI, none exists.")

#text("Take the following example. A mathematician posts a paper, and says “in forthcoming work we will use these methods to address problem X”. Another mathematician then yanks their paper, throws it into AI, and quickly posts an unreadable paper that claims a solution to problem X. This is not an ethical violation and the second mathematician has infinite time to polish their result into a readable form to submit for publication, as they have pissed on their patch of grass. Even if the initially generated argument is wrong, they in some sense of primacy.")

#text("This example is morally abhorrent, but there has not been a movement by any mathematical body to rule out examples like this with citeable ethics, like exists for determining whether someone is a co-author or not. This needs to change quickly, and all discussions should reflect the fact that no such standard exists.")

#text("Biology does not have this issue. Perhaps we need to form a mathematical IRB?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/open-problems-open-mathematics/comment-page-1/#comment-696533")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("In your example, what prevents the first mathematician to prove the result quickly themselves with AI as well? If there is some difficulty, maybe the second mathematician contributed something after all. And if there isn’t, maybe there was not much to take credit for in the first place")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/open-problems-open-mathematics/comment-page-1/#comment-697460")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("One possible reason. The first does not pay $500/month.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/open-problems-open-mathematics/comment-page-1/#comment-696138")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("I like this post! Mathematics is about connections, and both those between its sub-fields and those between it and other fields. History shows that many of the great discoveries of mathematicians from the past were motivated by problems from outside.")

#link("https://mathshistory.st-andrews.ac.uk/Extras/Von_Neumann_Part_1/")[#text("https://mathshistory.st-andrews.ac.uk/Extras/Von_Neumann_Part_1/")]#linebreak()#link("https://mathshistory.st-andrews.ac.uk/Extras/Von_Neumann_Part_2/")[#text("https://mathshistory.st-andrews.ac.uk/Extras/Von_Neumann_Part_2/")]

#text("These writings of Von Neumann are still relevant today!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0638f8025e96d915d66b224c4075737a02701e62e30a2d836fcda36598360d3-bb0d4ee5ce1d65f1f1daab94cbddb5f4ca0c1db5e7927da2097f36f3aeb988dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phenomenal18e147ff2c")]], [#link("https://terrytao.wordpress.com/2026/09/22/open-problems-open-mathematics/comment-page-1/#comment-696144")[#strong[#text("phenomenal18e147ff2c")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("The issue of “credit” remained dominant in this discussions, due to the advent of AI. This discussion remained how things are perceived by the elite schools members (and their students). The issue of credit has stopped being perfect since a long time. Journals and Funding sources are controlled by the elites and the powerful. I personally accused some group of attempting to censor my work. It has been difficult for me to publish anything in a western or US journal (because of the control they have). It is difficult to have an open discussion on such issues.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/406f072599fd85ed35b8ea217e9554741b1c05630a46bd088b9b1b7b55008493-c40263d2061b4d362abab78abbb2cf5dc234f49f63bf4cfa8a8a9617748a739c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valiantlyzombie1f56868d16")]], [#link("https://terrytao.wordpress.com/2026/09/22/open-problems-open-mathematics/comment-page-1/#comment-696155")[#strong[#text("valiantlyzombie1f56868d16")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("The hardest part for me and several of my friends right now, as first-year university students, is motivating ourselves to choose mathematics as a career path and pursue a PhD and so on.")

#emph[#text("(Sorry, I don’t know if this message is meant to be posted here or somewhere else…)")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/open-problems-open-mathematics/comment-page-1/#comment-696160")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("The history of math will forever be divided into the times before and after 2026. Today’s mathematicians can achieve colossal feats with the help of AI. But we must all now assume that it was with the help of AI.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0638f8025e96d915d66b224c4075737a02701e62e30a2d836fcda36598360d3-bb0d4ee5ce1d65f1f1daab94cbddb5f4ca0c1db5e7927da2097f36f3aeb988dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phenomenal18e147ff2c")]], [#link("https://terrytao.wordpress.com/2026/09/22/open-problems-open-mathematics/comment-page-1/#comment-696171")[#strong[#text("phenomenal18e147ff2c")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("History depends on who writes it – a Nixon quote!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/open-problems-open-mathematics/comment-page-1/#comment-696182")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("We have many issues to confront, one is how we are going to evaluate mathematical research. For this too we likely can learn from other fields.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/open-problems-open-mathematics/comment-page-1/#comment-696239")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("I collaborated closely with colleagues in Physics and physiology over a couple of decades. Many things are different, including how hiring occurs.")

#text("Unlike in Math, where we seem to have a more ‘centralized’ timeframe for postdoc and professorship hiring (at least in North America), and infrastructure like the AMS Mathjobs – in these other disciplines it’s lab-by-lab. Basically a grad student from our group needs to contact the labs of other people in a very close research area, and hope they are hiring. Networks and who-you-know matter very much, and to a larger extent than in math.")

#text("When hiring a new colleague, my colleagues expect things of applicants such as a record of securing major grants and running a lab. It is not uncommon in the physiology subdiscipline for an applicant to have up to 8 years of postdoctoral experience. My colleagues in biology labs spend a very large amount of their time writing grant proposals, to help pay for equipment/facilities and the people. As one pointed out – in his field, the last time you do science yourself in a fully immersive way is during your postdoc. You accept that afterwards you’ll be spending the major part of your time running the operation.")

#text("In experimental high energy physics, very large collaborations are the norm. Authors are expected to have close to 100 papers per year, each paper has hundreds of authors. My collaborator works on a major shared experiment. All hiring in his group is restricted to students who have worked on the same experiment (supervised in a different group). It’s a different ‘credit’ system than the one in mathematics.")

#text("The humanities are entirely different in their practices.")

#text("So, yes, we should look to other fields to see how they do it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/22/open-problems-open-mathematics/comment-page-1/#comment-696246")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("In recent months it became clear to me that the best path for researchers in mathematics right now is to abandon whatever they are doing and start working in AI, because it’s a war we can’t let OpenAI, Google, Microsoft, Anthropic, Meta, xAI or “whatever” tech company win. Their tools are based on the hard work of mathematicians from the past. You are behind in the race, but there is still time. ")#strong[#text("Mathematicians still have deeper understanding of math than chatbots, and are well-positioned to surpass all technology companies, but they need to unite and use their expertise to do so.")]#text(" Setting aside their research in “pure mathematics” (at least for now) is what is going to bring the best fruits for them. So, form your teams. Also, you are losing a chance to become very rich and use that to influence in the world towards a more promising path than that from the plans of the current billionaires. The strategic goal to defeat those companies is clear to me, and the top researchers in math should unite towards that goal. ")#strong[#text("The world would be much better if Terence Tao was richer than Elon Musk")]#text(". My suggestion is to just ignore all those famous problems whose solutions AI companies use to get more money. IGNORE those solutions, don’t give them a word about them. You WORK towards your own AI research. We need more AI tools “for mathematicians, developed by mathematicians”. Many mathematicians don’t care much about money, but ")#strong[#text("it has never been easier for a great mathematician to become extremely rich than it is now!")]#text(" In the era of AI, many can become much richer than the mathematician James Harris Simons was, with much less work. ")#strong[#text("“Numbers rule the world”")]#text(", and mathematicians should be the rulers of this planet, not those CEOs.")
]
