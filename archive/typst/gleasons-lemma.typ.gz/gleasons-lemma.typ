// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/07/12/gleasons-lemma/
// Converted to Typst by tao2typ: "2026-10-14T09:12:09.484930+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Gleason’s lemma", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Gleason’s lemma")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 July 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/07/12/gleasons-lemma/")[#text("https://terrytao.wordpress.com/2011/07/12/gleasons-lemma/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is another installment of my ")#link("https://terrytao.wordpress.com/tag/hilberts-fifth-problem/")[#text("my series of posts")]#text(" on ")#link("http://en.wikipedia.org/wiki/Hilbert's_fifth_problem")[#text("Hilbert’s fifth problem")]#text(". One formulation of this problem is answered by the following theorem of ")#link("http://www.ams.org/mathscinet-getitem?mr=49203")[#text("Gleason")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=49204")[#text("Montgomery-Zippin")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Hilbert’s fifth problem)")]#text(" ")#metadata(none) <tao-3d169fef15f916664516>#text(" Let ")#mi("{G}")#text(" be a ")#link("http://en.wikipedia.org/wiki/Topological_group")[#text("topological group")]#text(" which is ")#link("http://en.wikipedia.org/wiki/Locally_Euclidean")[#text("locally Euclidean")]#text(". Then ")#mi("{G}")#text(" is isomorphic to a Lie group.")
]

#text("Theorem ")#link(<tao-3d169fef15f916664516>)[#text("1")]#text(" is deep and difficult result, but the discussion in the previous posts has reduced the proof of this Theorem to that of establishing two simpler results, involving the concepts of a ")#link("http://en.wikipedia.org/wiki/No_small_subgroup")[#text("no small subgroups")]#text(" (NSS) subgroup, and that of a ")#emph[#text("Gleason metric")]#text(". We briefly recall the relevant definitions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2 (NSS)")]#text(" A topological group ")#mi("{G}")#text(" is said to have ")#emph[#text("no small subgroups")]#text(", or is ")#emph[#text("NSS")]#text(" for short, if there is an open neighbourhood ")#mi("{U}")#text(" of the identity in ")#mi("{G}")#text(" that contains no subgroups of ")#mi("{G}")#text(" other than the trivial subgroup ")#mi("{\\{ \\text{id}\\}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3 (Gleason metric)")]#text(" Let ")#mi("{G}")#text(" be a topological group. A ")#emph[#text("Gleason metric")]#text(" on ")#mi("{G}")#text(" is a left-invariant metric ")#mi("{d: G \\times G \\rightarrow {\\bf R}^+}")#text(" which generates the topology on ")#mi("{G}")#text(" and obeys the following properties for some constant ")#mi("{C>0}")#text(", writing ")#tao-math("{\\left\\|g\\right\\|}", block: false)#text(" for ")#mi("{d(g,\\text{id})}")#text(":")

#list(
[#text("(Escape property) If ")#mi("{g \\in G}")#text(" and ")#mi("{n \\geq 1}")#text(" is such that ")#tao-math("{n \\left\\|g\\right\\| \\leq \\frac{1}{C}}", block: false)#text(", then")

#metadata(none) <tao-cb65a96799cc2a3c19fc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\|g^n\\right\\| \\geq \\frac{1}{C} n \\|g\\|.", block: true)]]],
[#text("(Commutator estimate) If ")#mi("{g, h \\in G}")#text(" are such that ")#tao-math("{\\left\\|g\\right\\|, \\left\\|h\\right\\| \\leq \\frac{1}{C}}", block: false)#text(", then")

#metadata(none) <tao-0a83d217c9ff25c77929>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\|[g,h]\\right\\| \\leq C \\left\\|g\\right\\| \\left\\|h\\right\\|,", block: true)]]

#text("where ")#mi("{[g,h] := g^{-1}h^{-1}gh}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Commutator")[#text("commutator")]#text(" of ")#mi("{g}")#text(" and ")#mi("{h}")#text(".")]
)
]

#text("The remaining steps in the resolution of Hilbert’s fifth problem are then as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Reduction to the NSS case)")]#text(" ")#metadata(none) <tao-a0f22a76f364c3fed016>#text(" Let ")#mi("{G}")#text(" be a locally compact group, and let ")#mi("{U}")#text(" be an open neighbourhood of the identity in ")#mi("{G}")#text(". Then there exists an open subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(", and a compact subgroup ")#mi("{N}")#text(" of ")#mi("{G^{\\prime}}")#text(" contained in ")#mi("{U}")#text(", such that ")#mi("{G^{\\prime}/N}")#text(" is NSS and locally compact.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Gleason’s lemma)")]#text(" ")#metadata(none) <tao-630ba1ae8cfff3112b61>#text(" Let ")#mi("{G}")#text(" be a locally compact NSS group. Then ")#mi("{G}")#text(" has a Gleason metric.")
]

#text("The purpose of this post is to establish these two results, using arguments that are originally due to Gleason. We will split this task into several subtasks, each of which improves the structure on the group ")#mi("{G}")#text(" by some amount:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6 (From locally compact to metrisable)")]#text(" ")#metadata(none) <tao-14103b1425f04ac9b3e7>#text(" Let ")#mi("{G}")#text(" be a locally compact group, and let ")#mi("{U}")#text(" be an open neighbourhood of the identity in ")#mi("{G}")#text(". Then there exists an open subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(", and a compact subgroup ")#mi("{N}")#text(" of ")#mi("{G^{\\prime}}")#text(" contained in ")#mi("{U}")#text(", such that ")#mi("{G^{\\prime}/N}")#text(" is locally compact and metrisable.")
]

#text("For any open neighbourhood ")#mi("{U}")#text(" of the identity in ")#mi("{G}")#text(", let ")#mi("{Q(U)}")#text(" be the union of all the subgroups of ")#mi("{G}")#text(" that are contained in ")#mi("{U}")#text(". (Thus, for instance, ")#mi("{G}")#text(" is NSS if and only if ")#mi("{Q(U)}")#text(" is trivial for all sufficiently small ")#mi("{U}")#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7 (From metrisable to subgroup trapping)")]#text(" ")#metadata(none) <tao-8564388283117bb31df2>#text(" Let ")#mi("{G}")#text(" be a locally compact metrisable group. Then ")#mi("{G}")#text(" has the ")#emph[#text("subgroup trapping property")]#text(": for every open neighbourhood ")#mi("{U}")#text(" of the identity, there exists another open neighbourhood ")#mi("{V}")#text(" of the identity such that ")#mi("{Q(V)}")#text(" generates a subgroup ")#mi("{\\langle Q(V) \\rangle}")#text(" contained in ")#mi("{U}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8 (From subgroup trapping to NSS)")]#text(" ")#metadata(none) <tao-e0f953ec8ff68d020aa7>#text(" Let ")#mi("{G}")#text(" be a locally compact group with the subgroup trapping property, and let ")#mi("{U}")#text(" be an open neighbourhood of the identity in ")#mi("{G}")#text(". Then there exists an open subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(", and a compact subgroup ")#mi("{N}")#text(" of ")#mi("{G^{\\prime}}")#text(" contained in ")#mi("{U}")#text(", such that ")#mi("{G^{\\prime}/N}")#text(" is locally compact and NSS.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9 (From NSS to the escape property)")]#text(" ")#metadata(none) <tao-b3140286ac71ad2acf69>#text(" Let ")#mi("{G}")#text(" be a locally compact NSS group. Then there exists a left-invariant metric ")#mi("{d}")#text(" on ")#mi("{G}")#text(" generating the topology on ")#mi("{G}")#text(" which obeys the escape property ")#link(<tao-cb65a96799cc2a3c19fc>)[#text("(1)")]#text(" for some constant ")#mi("{C}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10 (From escape to the commutator estimate)")]#text(" ")#metadata(none) <tao-62eea8ff090f5d19b3d0>#text(" Let ")#mi("{G}")#text(" be a locally compact group with a left-invariant metric ")#mi("{d}")#text(" that obeys the escape property ")#link(<tao-cb65a96799cc2a3c19fc>)[#text("(1)")]#text(". Then ")#mi("{d}")#text(" also obeys the commutator property ")#link(<tao-0a83d217c9ff25c77929>)[#text("(2)")]#text(".")
]

#text("It is clear that Propositions ")#link(<tao-14103b1425f04ac9b3e7>)[#text("6")]#text(", ")#link(<tao-8564388283117bb31df2>)[#text("7")]#text(", and ")#link(<tao-e0f953ec8ff68d020aa7>)[#text("8")]#text(" combine to give Theorem ")#link(<tao-a0f22a76f364c3fed016>)[#text("4")]#text(", and Propositions ")#link(<tao-b3140286ac71ad2acf69>)[#text("9")]#text(", ")#link(<tao-62eea8ff090f5d19b3d0>)[#text("10")]#text(" combine to give Theorem ")#link(<tao-630ba1ae8cfff3112b61>)[#text("5")]#text(".")

#text("Propositions ")#link(<tao-14103b1425f04ac9b3e7>)[#text("6")]#text("–")#link(<tao-62eea8ff090f5d19b3d0>)[#text("10")]#text(" are all proven separately, but their proofs share some common strategies and ideas. The first main idea is to construct metrics on a locally compact group ")#mi("{G}")#text(" by starting with a suitable “bump function” ")#mi("{\\phi \\in C_c(G)}")#text(" (i.e. a continuous, compactly supported function from ")#mi("{G}")#text(" to ")#mi("{{\\bf R}}")#text(") and pulling back the metric structure on ")#mi("{C_c(G)}")#text(" by using the translation action ")#mi("{\\tau_g \\phi(x) := \\phi(g^{-1} x)}")#text(", thus creating a (semi-)metric ")#metadata(none) <tao-32fc1aae0cb54f8a2b24>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("d_\\phi( g, h ) := \\left\\| \\tau_g \\phi - \\tau_h \\phi \\right\\|_{C_c(G)} := \\sup_{x \\in G} \\left|\\phi(g^{-1} x) - \\phi(h^{-1} x)\\right|.", block: true)]]

#text("One easily verifies that this is indeed a (semi-)metric (in that it is non-negative, symmetric, and obeys the triangle inequality); it is also left-invariant, and so we have ")#tao-math("{d_\\phi(g,h) = \\left\\|g^{-1} h \\right\\|_\\phi = \\left\\| h^{-1} g \\right\\|_\\phi}", block: false)#text(", where")

#align(center)[#tao-fit-display[#tao-math("\\left\\| g \\right\\|_\\phi = d_\\phi(g,\\text{id}) = \\left\\| \\partial_g \\phi \\right\\|_{C_c(G)}", block: true)]]

#text("where ")#mi("{\\partial_g}")#text(" is the difference operator ")#mi("{\\partial_g = 1 - \\tau_g}")#text(",")

#align(center)[#tao-fit-display[#mitex("\\partial_g \\phi(x) = \\phi(x) - \\phi(g^{-1} x).")]]

#text("This construction was already seen in the proof of the ")#link("https://terrytao.wordpress.com/2011/05/17/the-birkhoff-kakutani-theorem/")[#text("Birkhoff-Kakutani theorem")]#text(", which is the main tool used to establish Proposition ")#link(<tao-14103b1425f04ac9b3e7>)[#text("6")]#text(". For the other propositions, the idea is to choose a bump function ")#mi("{\\phi}")#text(" that is “smooth” enough that it creates a metric with good properties such as the commutator estimate ")#link(<tao-0a83d217c9ff25c77929>)[#text("(2)")]#text(". Roughly speaking, to get a bound of the form ")#link(<tao-0a83d217c9ff25c77929>)[#text("(2)")]#text(", one needs ")#mi("{\\phi}")#text(" to have “")#mi("{C^{1,1}}")#text(" regularity” with respect to the “right” smooth structure on ")#mi("{G}")#text(" By ")#mi("{C^{1,1}}")#text(" regularity, we mean here something like a bound of the form ")#metadata(none) <tao-ef8873ba84900479ff61>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\| \\partial_g \\partial_h \\phi \\right\\|_{C_c(G)} \\ll \\left\\|g\\right\\|_\\phi \\left\\|h\\right\\|_\\phi", block: true)]]

#text("for all ")#mi("{g,h \\in G}")#text(". Here we use the usual asymptotic notation, writing ")#mi("{X \\ll Y}")#text(" or ")#mi("{X=O(Y)}")#text(" if ")#mi("{X \\leq CY}")#text(" for some constant ")#mi("{C}")#text(" (which can vary from line to line).")

#text("The following lemma illustrates how ")#mi("{C^{1,1}}")#text(" regularity can be used to build Gleason metrics.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11")]#text(" ")#metadata(none) <tao-b7ff806a7961036ca120>#text(" Suppose that ")#mi("{\\phi \\in C_c(G)}")#text(" obeys ")#link(<tao-ef8873ba84900479ff61>)[#text("(4)")]#text(". Then the (semi-)metric ")#mi("{d_\\phi}")#text(" (and associated (semi-)norm ")#mi("{\\|\\|_\\phi}")#text(") obey the escape property ")#link(<tao-cb65a96799cc2a3c19fc>)[#text("(1)")]#text(" and the commutator property ")#link(<tao-0a83d217c9ff25c77929>)[#text("(2)")]#text(".")
]

#emph[#text("Proof:")]#text(" We begin with the commutator property ")#link(<tao-0a83d217c9ff25c77929>)[#text("(2)")]#text(". Observe the identity")

#align(center)[#tao-fit-display[#mitex("\\tau_{[g,h]} = \\tau_{hg}^{-1} \\tau_{gh}")]]

#text("whence")

#tao-aligned(keep: true)[


#tao-math("\\partial_{[g,h]}  & = \\tau_{hg}^{-1} ( \\tau_{hg} - \\tau_{gh} )", block: true)



#tao-math(" & = \\tau_{hg}^{-1} ( \\partial_h \\partial_g - \\partial_g \\partial_h ).", block: true)
]

#text("From the triangle inequality (and translation-invariance of the ")#mi("{C_c(G)}")#text(" norm) we thus see that ")#link(<tao-0a83d217c9ff25c77929>)[#text("(2)")]#text(" follows from ")#link(<tao-ef8873ba84900479ff61>)[#text("(4)")]#text(". Similarly, to obtain the escape property ")#link(<tao-cb65a96799cc2a3c19fc>)[#text("(1)")]#text(", observe the telescoping identity")

#align(center)[#tao-fit-display[#mitex("\\partial_{g^n} = n \\partial_g + \\sum_{i=0}^{n-1} \\partial_g \\partial_{g^i}")]]

#text("for any ")#mi("{g \\in G}")#text(" and natural number ")#mi("{n}")#text(", and thus by the triangle inequality ")#metadata(none) <tao-72d9f85b4e4fda3ed392>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| g^n \\right\\|_\\phi = n \\left\\| g \\right\\|_\\phi + O( \\sum_{i=0}^{n-1} \\left\\| \\partial_g \\partial_{g^i} \\phi \\right\\|_{C_c(G)} ).", block: true)]]

#text("But from ")#link(<tao-ef8873ba84900479ff61>)[#text("(4)")]#text(" (and the triangle inequality) we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\partial_g \\partial_{g^i} \\phi \\right\\|_{C_c(G)} \\ll \\left\\|g\\right\\|_\\phi \\left\\|g^i \\right\\|_\\phi \\ll i \\left\\|g\\right\\|_\\phi^2", block: true)]]

#text("and thus we have the “Taylor expansion”")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g^n\\right\\|_\\phi = n \\left\\|g\\right\\|_\\phi + O( n^2 \\left\\|g\\right\\|_\\phi^2 )", block: true)]]

#text("which gives ")#link(<tao-cb65a96799cc2a3c19fc>)[#text("(1)")]#text(". ")#mi("\\Box")

#text("It remains to obtain ")#mi("{\\phi}")#text(" that have the desired ")#mi("{C^{1,1}}")#text(" regularity property. In order to get such regular bump functions, we will use the trick of ")#link("http://en.wikipedia.org/wiki/Convolution")[#text("convolving")]#text(" together two lower regularity bump functions (such as two functions with “")#mi("{C^{0,1}}")#text(" regularity” in some sense to be determined later). In order to perform this convolution, we will use the fundamental tool of (left-invariant) ")#link("http://en.wikipedia.org/wiki/Haar_measure")[#text("Haar measure")]#text(" ")#mi("{\\mu}")#text(" on the locally compact group ")#mi("{G}")#text(". Here we exploit the basic fact that the convolution ")#metadata(none) <tao-a11e43a95d8ce33b525d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("f_1 * f_2(x) := \\int_G f_1(y) f_2(y^{-1} x)\\ d\\mu(y)")]]

#text("of two functions ")#mi("{f_1,f_2 \\in C_c(G)}")#text(" tends to be smoother than either of the two factors ")#mi("{f_1,f_2}")#text(". This is easiest to see in the abelian case, since in this case we can distribute derivatives according to the law")

#align(center)[#tao-fit-display[#mitex("\\partial_g (f_1 * f_2) = (\\partial_g f_1) * f_2 = f_1 * (\\partial_g f_2),")]]

#text("which suggests that the order of “differentiability” of ")#mi("{f_1*f_2}")#text(" should be the sum of the orders of ")#mi("{f_1}")#text(" and ")#mi("{f_2}")#text(" separately.")

#text("These ideas are already sufficient to establish Proposition ")#link(<tao-62eea8ff090f5d19b3d0>)[#text("10")]#text(" directly, and also Proposition ")#link(<tao-b3140286ac71ad2acf69>)[#text("9")]#text(" when comined with an additional bootstrap argument. The proofs of Proposition ")#link(<tao-8564388283117bb31df2>)[#text("7")]#text(" and Proposition ")#link(<tao-e0f953ec8ff68d020aa7>)[#text("8")]#text(" use similar techniques, but is more difficult due to the potential presence of small subgroups, which require an application of the ")#link("http://en.wikipedia.org/wiki/Peter%E2%80%93Weyl_theorem")[#text("Peter-Weyl theorem")]#text(" to properly control. Both of these theorems will be proven below the fold, thus (when combined with the preceding posts) completing the proof of Theorem ")#link(<tao-3d169fef15f916664516>)[#text("1")]#text(".")

#text("The presentation here is based on some unpublished notes of van den Dries and Goldbring on Hilbert’s fifth problem. I am indebted to Emmanuel Breuillard, Ben Green, and Tom Sanders for many discussions related to these arguments.")

#metadata(none) <tao-0e32137cad6f6f8adbe1>

#heading(level: 1)[#strong[#text(" — 1. From escape to the commutator estimate — ")]]

#text("The general strategy here is to keep using the Gleason strategy of using the regularity one already has on the group ")#mi("{G}")#text(" to build good bump functions ")#mi("{\\phi}")#text(" to create metrics that give even more regularity on ")#mi("{G}")#text(". As with many such “bootstrap” arguments, the deepest and most difficult steps are the earliest ones, in which one has very little regularity to begin with; conversely, the easiest and most straightforward steps tend to be the final ones, when one already has most of the regularity that one needs, thus having plenty of structure and tools available to climb the next rung of the regularity ladder. (For instance, to get from ")#mi("{C^{1,1}}")#text(" regularity of a topological group to ")#mi("{C^\\infty}")#text(" or real analytic regularity is relatively routine, with two different such approaches indicated in the ")#link("https://terrytao.wordpress.com/2011/06/17/hilberts-fifth-problem-and-gleason-metrics/")[#text("preceding")]#text(" ")#link("https://terrytao.wordpress.com/2011/06/21/the-c11-baker-campbell-hausdorff-formula/")[#text("blog posts")]#text(".) In particular, the easiest task to accomplish will be that of Proposition ")#link(<tao-62eea8ff090f5d19b3d0>)[#text("10")]#text(", which establishes the commutator estimate ")#link(<tao-0a83d217c9ff25c77929>)[#text("(2)")]#text(" once the rest of the structural control on the group ")#mi("{G}")#text(" is in place.")

#text("We now prove this proposition. As indicated in the introduction, the key idea here is to involve a bump function ")#mi("{\\phi}")#text(" formed by convolving together two Lipschitz functions. The escape property ")#link(<tao-cb65a96799cc2a3c19fc>)[#text("(1)")]#text(" will be crucial in obtaining quantitative control of the metric geometry at very small scales, as one can study the size of a group element ")#mi("{g}")#text(" very close to the origin through its powers ")#mi("{g^n}")#text(", which are further away from the origin.")

#text("Specifically, let ")#mi("{\\epsilon > 0}")#text(" be a small quantity to be chosen later, and let ")#mi("{\\psi \\in C_c(G)}")#text(" be a non-negative Lipschitz function supported on the ball ")#mi("{B(0,\\epsilon)}")#text(" which is not identically zero. For instance, one could use the explicit function")

#align(center)[#tao-fit-display[#tao-math("\\psi(x) := (1 - \\frac{\\left\\|x\\right\\|}{\\epsilon})_+", block: true)]]

#text("where ")#mi("{y_+ := \\max(y,0)}")#text(". Being Lipschitz, we see that ")#metadata(none) <tao-355c34e7c2a90b66f5f0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left\\| \\partial_g \\psi \\right\\|_{C_c(G)} \\ll \\left\\|g\\right\\|", block: true)]]

#text("for all ")#mi("{g \\in G}")#text(" (where we allow implied constants to depend on ")#mi("{G}")#text(", ")#mi("{\\epsilon}")#text(", and ")#mi("{\\psi}")#text(").")

#text("Let ")#mi("{\\mu}")#text(" be a non-trivial left-invariant Haar measure on ")#mi("{G}")#text(" (see for instance ")#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")[#text("this previous blog post")]#text(" for a construction of Haar measure on locally compact groups). We then form the convolution ")#mi("{\\phi := \\psi * \\psi}")#text(", with convolution defined using ")#link(<tao-a11e43a95d8ce33b525d>)[#text("(6)")]#text("; this is a continuous function supported in ")#mi("{B(0,2\\epsilon)}")#text(", and gives a metric ")#mi("{d_\\phi}")#text(" and a norm ")#mi("{\\| \\|_\\phi}")#text(".")

#text("We now prove a variant of ")#link(<tao-ef8873ba84900479ff61>)[#text("(4)")]#text(", namely that ")#metadata(none) <tao-866ab33b8463db1b3906>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left\\| \\partial_g \\partial_h \\phi \\right\\|_{C_c(G)} \\ll \\left\\|g\\right\\| \\left\\| h \\right\\|", block: true)]]

#text("whenever ")#mi("{g, h \\in B(0,\\epsilon)}")#text(". We first use the left-invariance of Haar measure to write ")#metadata(none) <tao-8ac52d7d0c530608a22f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\partial_h \\phi = (\\partial_h \\psi) * \\psi,")]]

#text("thus")

#align(center)[#tao-fit-display[#mitex("\\partial_h \\phi(x) = \\int_G (\\partial_h \\psi)(y) \\psi(y^{-1} x)\\ d\\mu(y).")]]

#text("We would like to similarly move the ")#mi("{\\partial_g}")#text(" operator over to the second factor, but we run into a difficulty due to the non-abelian nature of ")#mi("{G}")#text(". Nevertheless, we can still do this provided that we twist that operator by a conjugation. More precisely, we have ")#metadata(none) <tao-ed72acc8c987fe55546a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\partial_g \\partial_h \\phi(x) = \\int_G (\\partial_h \\psi)(y) (\\partial_{g^y} \\psi)(y^{-1} x)\\ d\\mu(y)")]]

#text("where ")#mi("{g^y := y^{-1} g y}")#text(" is ")#mi("{g}")#text(" conjugated by ")#mi("{y}")#text(". If ")#mi("{h \\in B(0,\\epsilon)}")#text(", the integrand is only non-zero when ")#mi("{y \\in B(0,2\\epsilon)}")#text(". Applying ")#link(<tao-355c34e7c2a90b66f5f0>)[#text("(7)")]#text(", we obtain the bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\partial_g \\partial_h \\phi \\right\\|_{C_c(g)} \\ll \\left\\|h\\right\\| \\sup_{y \\in B(0,2\\epsilon)} \\left\\|g^y\\right\\|.", block: true)]]

#text("To finish the proof of ")#link(<tao-866ab33b8463db1b3906>)[#text("(8)")]#text(", it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g^y\\right\\| \\ll \\left\\|g\\right\\|", block: true)]]

#text("whenever ")#mi("{g \\in B(0,\\epsilon)}")#text(" and ")#mi("{y \\in B(0,2\\epsilon)}")#text(".")

#text("We can achieve this by the escape property ")#link(<tao-cb65a96799cc2a3c19fc>)[#text("(1)")]#text(". Let ")#mi("{n}")#text(" be a natural number such that ")#tao-math("{n \\left\\|g\\right\\| \\leq \\epsilon}", block: false)#text(", then ")#tao-math("{\\left\\|g^n\\right\\| \\leq \\epsilon}", block: false)#text(" and so ")#mi("{g^n \\in B(0,\\epsilon)}")#text(". Conjugating by ")#mi("{y}")#text(", this implies that ")#mi("{(g^y)^n \\in B(0,5\\epsilon)}")#text(", and so by ")#link(<tao-cb65a96799cc2a3c19fc>)[#text("(1)")]#text(", we have ")#tao-math("{\\left\\|g^y\\right\\| \\ll \\frac{1}{n}}", block: false)#text(" (if ")#mi("{\\epsilon}")#text(" is small enough), and the claim follows.")

#text("Next, we claim that the norm ")#mi("{\\| \\|_\\phi}")#text(" is locally comparable to the original norm ")#mi("{\\| \\|}")#text(". More precisely, we claim:")

#enum(start: 1, 
[#text("If ")#mi("{g \\in G}")#text(" with ")#tao-math("{\\left\\| g \\right\\|_\\phi}", block: false)#text(" sufficiently small, then ")#tao-math("{\\left\\| g \\right\\| \\ll \\left\\| g\\right\\|_\\phi}", block: false)#text(".")],
[#text("If ")#mi("{g \\in G}")#text(" with ")#tao-math("{\\left\\| g \\right\\|}", block: false)#text(" sufficiently small, then ")#tao-math("{\\left\\|g\\right\\|_\\phi \\ll \\left\\|g\\right\\|}", block: false)#text(".")]
)

#text("Claim 2 follows easily from ")#link(<tao-8ac52d7d0c530608a22f>)[#text("(9)")]#text(" and ")#link(<tao-355c34e7c2a90b66f5f0>)[#text("(7)")]#text(", so we turn to Claim 1. Let ")#mi("{g \\in G}")#text(", and let ")#mi("{n}")#text(" be a natural number such that")

#align(center)[#tao-fit-display[#tao-math("n \\left\\|g\\right\\|_\\phi < \\left\\| \\phi \\right\\|_{C_c(G)}.", block: true)]]

#text("Then by the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g^n \\right\\|_\\phi < \\left\\|\\phi \\right\\|_{C_c(G)}.", block: true)]]

#text("This implies that ")#mi("{\\phi}")#text(" and ")#mi("{\\tau_{g^n} \\phi}")#text(" have overlapping support, and hence ")#mi("{g^n}")#text(" lies in ")#mi("{B(0,4\\epsilon)}")#text(". By the escape property ")#link(<tao-cb65a96799cc2a3c19fc>)[#text("(1)")]#text(", this implies (if ")#mi("{\\epsilon}")#text(" is small enough) that ")#tao-math("{\\left\\|g\\right\\| \\ll \\frac{1}{n}}", block: false)#text(", and the claim follows.")

#text("Combining Claim 2 with ")#link(<tao-866ab33b8463db1b3906>)[#text("(8)")]#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\partial_g \\partial_h \\phi \\right\\|_{C_c(G)} \\ll \\left\\|g\\right\\|_\\phi \\left\\| h \\right\\|_\\phi", block: true)]]

#text("whenever ")#tao-math("{\\left\\|g\\right\\|_\\phi, \\left\\|h\\right\\|_\\phi}", block: false)#text(" are small enough; arguing as in the proof of Lemma ")#link(<tao-b7ff806a7961036ca120>)[#text("11")]#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| [g,h] \\right\\|_\\phi \\ll \\left\\|g\\right\\|_\\phi \\left\\|h\\right\\|_\\phi", block: true)]]

#text("whenever ")#tao-math("{\\left\\|g\\right\\|_\\phi, \\left\\|h\\right\\|_\\phi}", block: false)#text(" are small enough. Proposition ")#link(<tao-62eea8ff090f5d19b3d0>)[#text("10")]#text(" then follows from Claim 1 and Claim 2.")

#heading(level: 1)[#strong[#text(" — 2. From NSS to the escape property — ")]]

#text("Now we turn to establishing Proposition ")#link(<tao-b3140286ac71ad2acf69>)[#text("9")]#text(". An important concept will be that of an ")#emph[#text("escape norm")]#text(" associated to an open neighbourhood ")#mi("{U}")#text(" of a group ")#mi("{G}")#text(", defined by the formula ")#metadata(none) <tao-4cd0e21a9a0795a14ec9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left\\|g\\right\\|_{e,U} := \\inf \\{ \\frac{1}{n+1}: g, g^2, \\ldots, g^n \\in U \\}", block: true)]]

#text("for any ")#mi("{g \\in G}")#text(". Thus, the longer it takes for the orbit ")#mi("{g, g^2, \\ldots}")#text(" to escape ")#mi("{U}")#text(", the smaller the escape norm.")

#text("Strictly speaking, the escape norm is not necessarily a norm, as it need not obey the symmetry, non-degeneracy, or triangle inequalities; however, we shall see that in many situations, the escape norm behaves similarly to a norm, even if it does not exactly obey the norm axioms. Also, as the name suggests, the escape norm will be well suited for establishing the escape property ")#link(<tao-cb65a96799cc2a3c19fc>)[#text("(1)")]#text(".")

#text("It is possible for the escape norm ")#tao-math("{\\left\\|g\\right\\|_{e,U}}", block: false)#text(" of a non-identity element ")#mi("{g \\in G}")#text(" to be zero, if ")#mi("{U}")#text(" contains the group ")#mi("{\\langle g \\rangle}")#text(" generated by ")#mi("{U}")#text(". But if the group ")#mi("{G}")#text(" has the NSS property, then we see that this cannot occur for all sufficiently small ")#mi("{U}")#text(" (where “sufficiently small” means “contained in a suitably chosen open neighbourhood ")#mi("{U_0}")#text(" of the identity”). In fact, more is true: if ")#mi("{U, U^{\\prime}}")#text(" are two sufficiently small open neighbourhoods of the identity in a locally compact NSS group ")#mi("{G}")#text(", then the two escape norms are comparable, thus we have ")#metadata(none) <tao-d11db1eb7e3ecfbdab04>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\left\\|g \\right\\|_{e,U} \\ll \\left\\|g\\right\\|_{e,U^{\\prime}} \\ll \\left\\|g\\right\\|_{e,U}", block: true)]]

#text("for all ")#mi("{g \\in G}")#text(" (where the implied constants can depend on ")#mi("{U, U^{\\prime}}")#text(").")

#text("By symmetry, it suffices to prove the second inequality in ")#link(<tao-d11db1eb7e3ecfbdab04>)[#text("(12)")]#text(". By ")#link(<tao-4cd0e21a9a0795a14ec9>)[#text("(11)")]#text(", it suffices to find an integer ")#mi("{m}")#text(" such that whenever ")#mi("{g \\in G}")#text(" is such that ")#mi("{g, g^2, \\ldots, g^m \\in U}")#text(", then ")#mi("{g \\in U^{\\prime}}")#text(". Equivalently: for every ")#mi("{g \\not \\in U^{\\prime}}")#text(", one has ")#mi("{g^i \\not \\in U}")#text(" for some ")#mi("{1 \\leq i \\leq m}")#text(". If ")#mi("{U}")#text(" is small enough, then by the NSS property, we know that for each ")#mi("{g \\in \\overline{U} \\backslash U^{\\prime}}")#text(", we have ")#mi("{g^i \\not \\in U}")#text(" for some ")#mi("{i \\geq 0}")#text(". As ")#mi("{G}")#text(" is locally compact, we can make ")#mi("{\\overline{U}}")#text(" and hence ")#mi("{\\overline{U} \\backslash U^{\\prime}}")#text(" compact, and so we can make ")#mi("{i}")#text(" uniformly bounded in ")#mi("{g}")#text(" by a compactness argument, and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Let ")#mi("{G}")#text(" be a locally compact group. Show that if ")#mi("{d}")#text(" is a left-invariant metric on ")#mi("{G}")#text(" obeying the escape property ")#link(<tao-cb65a96799cc2a3c19fc>)[#text("(1)")]#text(" that generates the topology, then ")#mi("{G}")#text(" is NSS, and ")#tao-math("{\\left\\| g\\right\\|}", block: false)#text(" is comparable to ")#tao-math("{\\left\\|g\\right\\|_{e,U}}", block: false)#text(" for all sufficiently small ")#mi("{U}")#text(". (In particular, any two left-invariant metrics obeying the escape property and generating the topology are comparable to each other.)")
]

#text("Henceforth ")#mi("{G}")#text(" is a locally compact NSS group.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 12 (Approximate triangle inequality)")]#text(" ")#metadata(none) <tao-6309089b4e49323ae874>#text(" Let ")#mi("{U_0}")#text(" be a sufficiently small open neighbourhood of the identity. Then for any ")#mi("{n}")#text(" and any ")#mi("{g_1,\\ldots,g_n \\in G}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| g_1 \\ldots g_n \\right\\|_{e,U_0} \\ll \\sum_{i=1}^n \\left\\|g_i\\right\\|_{e,U_0}", block: true)]]

#text("(where the implied constant can depend on ")#mi("{U_0}")#text(").")
]

#text("Of course, in view of ")#link(<tao-d11db1eb7e3ecfbdab04>)[#text("(12)")]#text(", the exact choice of ")#mi("{U_0}")#text(" is irrelevant, so long as it is small. It is slightly convenient to take ")#mi("{U_0}")#text(" to be symmetric (thus ")#mi("{U_0 = U_0^{-1}}")#text("), so that ")#tao-math("{\\left\\|g\\right\\|_{e,U_0} = \\left\\|g^{-1}\\right\\|_{e,U_0}}", block: false)#text(" for all ")#mi("{g}")#text(".")

#emph[#text("Proof:")]#text(" We will use a bootstrap argument. Assume to start with that we somehow already have a weaker form of the conclusion, namely ")#metadata(none) <tao-cb5ae32cbd84a47c77ab>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left\\| g_1 \\ldots g_n \\right\\|_{e,U_0} \\leq M \\sum_{i=1}^n \\left\\|g_i\\right\\|_{e,U_0}", block: true)]]

#text("for all ")#mi("{n,g_1,\\ldots,g_n}")#text(" and some huge constant ")#mi("{M}")#text(", and deduce the same estimate with a smaller value of ")#mi("{M}")#text(". Afterwards we will show how to remove the hypothesis ")#link(<tao-cb5ae32cbd84a47c77ab>)[#text("(13)")]#text(".")

#text("Now suppose we have ")#link(<tao-cb5ae32cbd84a47c77ab>)[#text("(13)")]#text(" for some ")#mi("{M}")#text(". Motivated by the argument in the previous section, we now try to convolve together two “Lipschitz” functions. For this, we will need some metric-like functions. Define the modified escape norm ")#tao-math("{\\left\\|g\\right\\|_{*,U_0}}", block: false)#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g\\right\\|_{*,U_0} := \\inf \\{ \\sum_{i=1}^n \\left\\|g_i\\right\\|_{e,U_0}: g = g_1 \\ldots g_n \\}", block: true)]]

#text("where the infimum is over all possible ways to split ")#mi("{g}")#text(" as a finite product of group elements. From ")#link(<tao-cb5ae32cbd84a47c77ab>)[#text("(13)")]#text(", we have ")#metadata(none) <tao-2996bdd364ce0c6d76cc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\frac{1}{M}\\left\\|g\\right\\|_{e,U_0} \\leq \\left\\|g\\right\\|_{*,U_0} \\leq \\left\\|g\\right\\|_{e,U_0}", block: true)]]

#text("and we have the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|gh\\right\\|_{*,U_0} \\leq \\left\\|g\\right\\|_{*,U_0} + \\left\\|h\\right\\|_{*,U_0}", block: true)]]

#text("for any ")#mi("{g,h \\in G}")#text(". We also have the symmetry property ")#tao-math("{\\left\\|g\\right\\|_{*,U_0} = \\left\\|g^{-1} \\right\\|_{*,U_0}}", block: false)#text(". Thus ")#mi("{\\| \\|_{*,U_0}}")#text(" gives a left-invariant semi-metric on ")#mi("{G}")#text(" by defining")

#align(center)[#tao-fit-display[#tao-math("\\text{dist}_{*,U_0}(g,h) := \\left\\|g^{-1} h \\right\\|_{*,U_0}.", block: true)]]

#text("We can now define a “Lipschitz” function ")#mi("{\\psi: G \\rightarrow {\\bf R}}")#text(" by setting")

#align(center)[#tao-fit-display[#mitex("\\psi(x) := (1 - M \\text{dist}_{*,U_0}(x, U_0))_+.")]]

#text("On the one hand, we see from ")#link(<tao-2996bdd364ce0c6d76cc>)[#text("(14)")]#text(" that this function takes values in ")#mi("{[0,1]}")#text(" obeys the Lipschitz bound ")#metadata(none) <tao-55b077ccbb0acccbafc2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left|\\partial_g \\psi(x)\\right| \\leq M \\left\\|g\\right\\|_{e,U_0}", block: true)]]

#text("for any ")#mi("{g, x \\in G}")#text(". On the other hand, it is supported in the region where ")#mi("{\\text{dist}_{*,U_0}(x,U_0) \\leq 1/M}")#text(", which by ")#link(<tao-2996bdd364ce0c6d76cc>)[#text("(14)")]#text(" (and ")#link(<tao-4cd0e21a9a0795a14ec9>)[#text("(11)")]#text(") is contained in ")#mi("{U_0^2}")#text(".")

#text("We could convolve ")#mi("{\\psi}")#text(" with itself in analogy to the preceding section, but in doing so, we will eventually end up establishing a much worse estimate than ")#link(<tao-cb5ae32cbd84a47c77ab>)[#text("(13)")]#text(" (in which the constant ")#mi("{M}")#text(" is replaced with something like ")#mi("{M^2}")#text("). Instead, we will need to convolve ")#mi("{\\psi}")#text(" with another function ")#mi("{\\eta}")#text(", that we define as follows. We will need a large natural number ")#mi("{L}")#text(" (independent of ")#mi("{M}")#text(") to be chosen later, then a small open neighbourhood ")#mi("{U_1 \\subset U_0}")#text(" of the identity (depending on ")#mi("{L, U_0}")#text(") to be chosen later. We then let ")#mi("{\\eta: G \\rightarrow {\\bf R}}")#text(" be the function")

#align(center)[#tao-fit-display[#mitex("\\eta(x) := \\sup \\{ 1 - \\frac{j}{L}: x \\in U_1^j U_0; j = 0,\\ldots,L \\} \\cup \\{0\\}.")]]

#text("Similarly to ")#mi("{\\psi}")#text(", we see that ")#mi("{\\eta}")#text(" takes values in ")#mi("{[0,1]}")#text(" and obeys the Lipschitz-type bound ")#metadata(none) <tao-9ace10752e5bc55d2c76>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left|\\partial_g \\eta(x)\\right| \\leq \\frac{1}{L}", block: true)]]

#text("for all ")#mi("{g \\in U_1}")#text(" and ")#mi("{x \\in G}")#text(". Also, ")#mi("{\\eta}")#text(" is supported in ")#mi("{U_1^L U_0}")#text(", and hence (if ")#mi("{U_1}")#text(" is sufficiently small depending on ")#mi("{L,U_0}")#text(") is supported in ")#mi("{U_0^2}")#text(", just as ")#mi("{\\psi}")#text(" is.")

#text("The functions ")#mi("{\\psi, \\eta}")#text(" need not be continuous, but they are compactly supported, bounded, and Borel measurable, and so one can still form their convolution ")#mi("{\\phi := \\psi * \\eta}")#text(", which will then be continuous and compactly supported; indeed, ")#mi("{\\phi}")#text(" is supported in ")#mi("{U_0^4}")#text(".")

#text("We have a lower bound on how big ")#mi("{\\phi}")#text(" is, since")

#align(center)[#tao-fit-display[#mitex("\\phi(0) \\geq \\mu(U_0) \\gg 1")]]

#text("(where we allow implied constants to depend on ")#mi("{\\mu, U_0}")#text(", but remain independent of ")#mi("{L}")#text(", ")#mi("{U_1}")#text(", or ")#mi("{M}")#text("). This gives us a way to compare ")#mi("{\\| \\|_{\\phi}}")#text(" with ")#mi("{\\| \\|_{e,U_0}}")#text(". Indeed, if ")#tao-math("{n \\left\\|g\\right\\|_{\\phi} < \\phi(0)}", block: false)#text(", then (as in the proof of Claim 1 in the previous section) we have ")#mi("{g^n \\in U_0^8}")#text("; this implies that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| g \\right\\|_{e,U_0^8} \\ll \\left\\| g \\right\\|_{\\phi}", block: true)]]

#text("for all ")#mi("{g \\in G}")#text(", and hence by ")#link(<tao-d11db1eb7e3ecfbdab04>)[#text("(12)")]#text(" we have ")#metadata(none) <tao-9ad66d3ac3c3fba69d99>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\left\\| g \\right\\|_{e,U_0} \\ll \\left\\| g \\right\\|_{\\phi}", block: true)]]

#text("also. In the converse direction, we have")

#tao-aligned(keep: true)[


#tao-math("\\left\\|g\\right\\|_\\phi  & = \\left\\| \\partial_g (\\psi * \\eta) \\right\\|_{C_c(G)}", block: true)



#tao-math(" & = \\left\\| (\\partial_g \\psi) * \\eta \\right\\|_{C_c(G)}", block: true)
]

#metadata(none) <tao-c3ccedf562d9529001d8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\ll M \\left\\|g\\right\\|_{e,U_0}", block: true)]]

#text("thanks to ")#link(<tao-55b077ccbb0acccbafc2>)[#text("(15)")]#text(". But we can do better than this, as follows. For any ")#mi("{g, h \\in G}")#text(", we have the analogue of ")#link(<tao-ed72acc8c987fe55546a>)[#text("(10)")]#text(", namely")

#align(center)[#tao-fit-display[#mitex("\\partial_g \\partial_h \\phi(x) = \\int_G (\\partial_h \\psi)(y) (\\partial_{g^y} \\eta)(y^{-1} x)\\ d\\mu(y)")]]

#text("If ")#mi("{h \\in U_0}")#text(", then the integrand vanishes unless ")#mi("{y \\in U_0^3}")#text(". By continuity, we can find a small open neighbourhood ")#mi("{U_2 \\subset U_1}")#text(" of the identity such that ")#mi("{g^y \\in U_1}")#text(" for all ")#mi("{g \\in U_2}")#text(" and ")#mi("{y \\in U_0^3}")#text("; we conclude from ")#link(<tao-55b077ccbb0acccbafc2>)[#text("(15)")]#text(", ")#link(<tao-9ace10752e5bc55d2c76>)[#text("(16)")]#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\partial_g \\partial_h \\phi(x)\\right| \\ll \\frac{M}{L} \\left\\|h\\right\\|_{e,U_0}.", block: true)]]

#text("whenever ")#mi("{h \\in U_0}")#text(" and ")#mi("{g \\in U_2}")#text(". To use this, we apply ")#link(<tao-72d9f85b4e4fda3ed392>)[#text("(5)")]#text(" and conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g^n\\right\\|_\\phi = n \\left\\|g\\right\\|_\\phi + O( n \\frac{M}{L} \\left\\|g\\right\\|_{e,U_0} )", block: true)]]

#text("whenever ")#mi("{n \\geq 1}")#text(" and ")#mi("{g,\\ldots,g^n \\in U_2}")#text(". Using the trivial bound ")#tao-math("{\\left\\|g^n\\right\\|_\\phi = O(1)}", block: false)#text(", we then have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g\\right\\|_\\phi \\ll \\frac{1}{n} + \\frac{M}{L} \\left\\|g\\right\\|_{e,U_0};", block: true)]]

#text("optimising in ")#mi("{n}")#text(" we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g\\right\\|_\\phi \\ll \\left\\|g\\right\\|_{e,U_2} + \\frac{M}{L} \\left\\|g\\right\\|_{e,U_0}", block: true)]]

#text("and hence by ")#link(<tao-d11db1eb7e3ecfbdab04>)[#text("(12)")]

#align(center)[#tao-fit-display[#tao-math("\\left\\|g\\right\\|_\\phi \\ll (\\frac{M}{L} + O_{U_2}(1)) \\left\\|g\\right\\|_{e,U_0}", block: true)]]

#text("where the implied constant in ")#mi("{O_{U_2}(1)}")#text(" can depend on ")#mi("{U_0,U_1,U_2, L}")#text(", but is crucially independent of ")#mi("{M}")#text(". Note the essential gain of ")#mi("{\\frac{1}{L}}")#text(" here compared with ")#link(<tao-c3ccedf562d9529001d8>)[#text("(18)")]#text(". We also have the norm inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g_1 \\ldots g_n \\right\\|_\\phi \\leq \\sum_{i=1}^n \\left\\|g_i\\right\\|_\\phi.", block: true)]]

#text("Combining these inequalities with ")#link(<tao-9ad66d3ac3c3fba69d99>)[#text("(17)")]#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| g_1 \\ldots g_n \\right\\|_{e,U_0} \\ll (\\frac{1}{L} M + O_{U_2}(1)) \\sum_{i=1}^n \\left\\|g_i\\right\\|_{e,U_0}.", block: true)]]

#text("Thus we have improved the constant ")#mi("{M}")#text(" in the hypothesis ")#link(<tao-cb5ae32cbd84a47c77ab>)[#text("(13)")]#text(" to ")#mi("{O( \\frac{1}{L} M ) + O_{U_2}(1)}")#text(". Choosing ")#mi("{L}")#text(" large enough and iterating, we conclude that we can bootstrap any finite constant ")#mi("{M}")#text(" in ")#link(<tao-cb5ae32cbd84a47c77ab>)[#text("(13)")]#text(" to ")#mi("{O(1)}")#text(".")

#text("Of course, there is no reason why there has to be a finite ")#mi("{M}")#text(" for which ")#link(<tao-cb5ae32cbd84a47c77ab>)[#text("(13)")]#text(" holds in the first place. However, one can rectify this by the usual trick of creating an epsilon of room. Namely, one replaces the escape norm ")#tao-math("{\\left\\| g \\right\\|_{e,U_0}}", block: false)#text(" by, say, ")#tao-math("{\\left\\|g\\right\\|_{e,U_0}+\\epsilon}", block: false)#text(" for some small ")#mi("{\\epsilon > 0}")#text(" in the definition of ")#mi("{\\| \\|_{*,U_0}}")#text(" and in the hypothesis ")#link(<tao-cb5ae32cbd84a47c77ab>)[#text("(13)")]#text(". Then the bound ")#link(<tao-cb5ae32cbd84a47c77ab>)[#text("(13)")]#text(" will be automatic with a finite ")#mi("{M}")#text(" (of size about ")#mi("{O(1/\\epsilon)}")#text("). One can then run the above argument with the requisite changes and conclude a bound of the form")

#align(center)[#tao-fit-display[#tao-math("\\left\\| g_1 \\ldots g_n \\right\\|_{e,U_0} \\ll \\sum_{i=1}^n (\\left\\|g_i\\right\\|_{e,U_0}+\\epsilon)", block: true)]]

#text("uniformly in ")#mi("{\\epsilon}")#text("; we omit the details. Sending ")#mi("{\\epsilon \\rightarrow 0}")#text(", we have thus shown Proposition ")#link(<tao-6309089b4e49323ae874>)[#text("12")]#text(". ")#mi("\\Box")

#text("Now we can finish the proof of Proposition ")#link(<tao-b3140286ac71ad2acf69>)[#text("9")]#text(". Let ")#mi("{G}")#text(" be a locally compact NSS group, and let ")#mi("{U_0}")#text(" be a sufficiently small neighbourhood of the identity. From Proposition ")#link(<tao-6309089b4e49323ae874>)[#text("12")]#text(", we see that the escape norm ")#mi("{\\| \\|_{e,U_0}}")#text(" and the modified escape norm ")#mi("{\\| \\|_{*,U_0}}")#text(" are comparable. We have seen ")#mi("{d_{*,U_0}}")#text(" is a left-invariant semi-metric. As ")#mi("{G}")#text(" is NSS and ")#mi("{U_0}")#text(" is small, there are no non-identity elements with zero escape norm, and hence no non-identity elements with zero modified escape norm either; thus ")#mi("{d_{*,U_0}}")#text(" is a genuine metric.")

#text("We now claim that ")#mi("{d_{*,U_0}}")#text(" generates the topology of ")#mi("{G}")#text(". Given the left-invariance of ")#mi("{d_{*,U_0}}")#text(", it suffices to establish two things: firstly, that any open neighbourhood of the identity contains a ball around the identity in the ")#mi("{d_{*,U_0}}")#text(" metric; and conversely, any such ball contains an open neighbourhood around the identity.")

#text("To prove the first claim, let ")#mi("{U}")#text(" be an open neighbourhood around the identity, and let ")#mi("{U^{\\prime} \\subset U}")#text(" be a smaller neighbourhood of the identity. From ")#link(<tao-d11db1eb7e3ecfbdab04>)[#text("(12)")]#text(" we see (if ")#mi("{U^{\\prime}}")#text(" is small enough) that ")#mi("{\\| \\|_{*,U_0}}")#text(" is comparable to ")#mi("{\\| \\|_{e,U^{\\prime}}}")#text(", and ")#mi("{U^{\\prime}}")#text(" contains a small ball around the origin in the ")#mi("{d_{*,U_0}}")#text(" metric, giving the claim. To prove the second claim, consider a ball ")#mi("{B(0,r)}")#text(" in the ")#mi("{d_{*,U_0}}")#text(" metric. For any positive integer ")#mi("{m}")#text(", we can find an open neighbourhood ")#mi("{U_m}")#text(" of the identity such that ")#mi("{U_m^m \\subset U_0}")#text(", and hence ")#tao-math("{\\left\\|g\\right\\|_{e,U_0} \\leq \\frac{1}{m}}", block: false)#text(" for all ")#mi("{g \\in U_m}")#text(". For ")#mi("{m}")#text(" large enough, this implies that ")#mi("{U_m \\subset B(0,r)}")#text(", and the claim follows.")

#text("To finish the proof of Proposition ")#link(<tao-b3140286ac71ad2acf69>)[#text("9")]#text(", we need to verify the escape property ")#link(<tao-cb65a96799cc2a3c19fc>)[#text("(1)")]#text(". Thus, we need to show that if ")#mi("{g \\in G}")#text(", ")#mi("{n \\geq 1}")#text(" are such that ")#tao-math("{n \\left\\|g\\right\\|_{*,U_0}}", block: false)#text(" is sufficiently small, then we have ")#tao-math("{\\left\\|g^n\\right\\|_{*,U_0} \\gg n \\left\\|g\\right\\|_{*,U_0}}", block: false)#text(". We may of course assume that ")#mi("{g}")#text(" is not the identity, as the claim is trivial otherwise. As ")#mi("{\\|\\|_{*,U_0}}")#text(" is comparable to ")#mi("{\\| \\|_{e,U_0}}")#text(", we know that there exists a natural number ")#tao-math("{m \\ll 1 / \\left\\| g \\right\\|_{*,U_0}}", block: false)#text(" such that ")#mi("{g^m \\not \\in U_0}")#text(". Let ")#mi("{U_1}")#text(" be a neighbourhood of the identity small enough that ")#mi("{U_1^2 \\subset U_0}")#text(". We have ")#tao-math("{\\left\\|g^i\\right\\|_{*,U_0} \\leq n \\left\\|g\\right\\|_{*,U_0}}", block: false)#text(" for all ")#mi("{i=1,\\ldots,n}")#text(", so ")#mi("{g^i \\in U_1}")#text(" and hence ")#mi("{m > n}")#text(". Let ")#mi("{m+i}")#text(" be the first multiple of ")#mi("{n}")#text(" larger than ")#mi("{n}")#text(", then ")#mi("{i \\leq n}")#text(" and so ")#mi("{g^i \\in U_1}")#text(". Since ")#mi("{g^m \\not \\in U_0}")#text(", this implies ")#mi("{g^{m+i} \\not \\in U_1}")#text(". Since ")#mi("{m+i}")#text(" is divisible by ")#mi("{n}")#text(", we conclude that ")#tao-math("{\\left\\| g^n \\right\\|_{e,U_1} \\geq \\frac{n}{m+i} \\gg n \\left\\| g \\right\\|_{*,U_0}}", block: false)#text(", and the claim follows from ")#link(<tao-d11db1eb7e3ecfbdab04>)[#text("(12)")]#text(".")

#heading(level: 1)[#strong[#text(" — 3. From subgroup trapping to NSS — ")]]

#text("We now turn to the task of proving Proposition ")#link(<tao-e0f953ec8ff68d020aa7>)[#text("8")]#text(". Intuitively, the idea is to use the subgroup trapping property to find a small compact normal subgroup ")#mi("{N}")#text(" that contains ")#mi("{Q(V)}")#text(" for some small ")#mi("{V}")#text(", and then quotient this group out to get an NSS group. Unfortunately, because ")#mi("{N}")#text(" is not necessarily contained in ")#mi("{V}")#text(", this quotienting operation may create some additional small subgroups. To fix this, we need to pass from the compact subgroup ")#mi("{N}")#text(" to a smaller one. In order to understand the subgroups of compact groups, the main tool will be the ")#link("http://en.wikipedia.org/wiki/Peter%E2%80%93Weyl_theorem")[#text("Peter-Weyl theorem")]#text(". Actually, we will just need the following weak version of that theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 13 (Weak Peter-Weyl theorem)")]#text(" ")#metadata(none) <tao-f9fbbc375d07f67ff36b>#text(" Let ")#mi("{G}")#text(" be a compact group, and let ")#mi("{U}")#text(" be a neighbourhood of the identity in ")#mi("{G}")#text(". Then there exists a finite-dimensional real linear representation ")#mi("{\\rho: G \\rightarrow GL(V)}")#text(" of ")#mi("{G}")#text(" (i.e. a continuous homomorphism from ")#mi("{G}")#text(" to the general linear group ")#mi("{GL(V)}")#text(" of a finite-dimensional real vector space ")#mi("{V}")#text(") whose kernel ")#mi("{\\text{ker}(\\rho)}")#text(" lies in ")#mi("{U}")#text(". Equivalently, there exists a compact normal subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" contained in ")#mi("{U}")#text(" such that ")#mi("{G/H}")#text(" is isomorphic to a compact subgroup of ")#mi("{GL(V)}")#text(".")
]

#emph[#text("Proof:")]#text(" As ")#mi("{G}")#text(" is compact, it has a Haar probability measure ")#mi("{\\mu}")#text(". Let ")#mi("{W}")#text(" be a symmetric open neighbourhood of the identity such that ")#mi("{W^2 \\subset U}")#text(". The convolution operator ")#mi("{T: L^2(G) \\rightarrow L^2(G)}")#text(" given by ")#mi("{Tf := f * 1_W}")#text(" is a self-adjoint integral operator on a probability space with bounded measurable kernel and is thus ")#link("http://en.wikipedia.org/wiki/Compact_operator")[#text("compact")]#text(" (indeed, it is a ")#link("http://en.wikipedia.org/wiki/Hilbert-Schmidt_integral_operator")[#text("Hilbert-Schmidt integral operator")]#text("). By the spectral theorem, ")#mi("{L^2(G)}")#text(" then decomposes as the orthogonal sum of the eigenspaces of ")#mi("{T}")#text(", with all the eigenspaces ")#mi("{V_\\lambda}")#text(" corresponding to non-zero eigenvalues ")#mi("{\\lambda}")#text(" being finite-dimensional.")

#text("Note that ")#mi("{T}")#text(" commutes with the left translation operators ")#mi("{\\tau_g}")#text(" for every ")#mi("{g \\in G}")#text(", so all of the eigenspaces ")#mi("{V_\\lambda}")#text(" are invariant with respect to this action, and so we have finite-dimensional linear represenations ")#mi("{\\rho_\\lambda: G \\rightarrow GL(V_\\lambda)}")#text(" for each non-zero eigenvalue ")#mi("{\\lambda}")#text(".")

#text("Let ")#mi("{g \\in G \\backslash U}")#text(", then ")#mi("{\\tau_g T 1_W \\neq T 1_W}")#text(" (the supports are disjoint). The function ")#mi("{T1_W}")#text(" lies in the direct sum of the ")#mi("{V_\\lambda}")#text(" with ")#mi("{\\lambda}")#text(" non-zero, and so there must exist at least one ")#mi("{V_\\lambda}")#text(" such that the projections of ")#mi("{T1_W}")#text(" and ")#mi("{\\tau_g T 1_W}")#text(" to ")#mi("{V_\\lambda}")#text(" are distinct. We conclude that ")#mi("{\\rho_\\lambda(g)}")#text(" is non-trivial for this ")#mi("{\\lambda}")#text(" and ")#mi("{g}")#text("; by continuity, the same is true for all ")#mi("{g^{\\prime}}")#text(" in an open neighbourhood of ")#mi("{g}")#text(". By compactness of ")#mi("{G \\backslash U}")#text(", we may thus find a finite number ")#mi("{\\lambda_1,\\ldots,\\lambda_k}")#text(" of non-zero eigenvalues such that for each ")#mi("{g \\in G \\backslash U}")#text(", ")#mi("{\\rho_{\\lambda_i}(g)}")#text(" is non-trivial for at least one ")#mi("{i=1,\\ldots,k}")#text(". The representation ")#mi("{\\rho := \\rho_{\\lambda_1} \\oplus \\ldots \\oplus \\rho_{\\lambda_k}}")#text(" can then be seen to have all the required properties. ")#mi("\\Box")

#text("For us, the main reason why we need the Peter-Weyl theorem is that the linear spaces ")#mi("{GL(V)}")#text(" automatically have the NSS property, even though ")#mi("{G}")#text(" need not. Thus, one can view Theorem ")#link(<tao-f9fbbc375d07f67ff36b>)[#text("13")]#text(" as giving the compact case of Theorem ")#link(<tao-a0f22a76f364c3fed016>)[#text("4")]#text(".")

#text("We now prove Proposition ")#link(<tao-e0f953ec8ff68d020aa7>)[#text("8")]#text(", using an argument ")#link("http://www.ams.org/mathscinet-getitem?mr=54613")[#text("of Yamabe")]#text(". Let ")#mi("{G}")#text(" be a locally compact group with the subgroup trapping property, and let ")#mi("{U}")#text(" be an open neighbourhood of the identity. We may find a smaller neighbourhood ")#mi("{U_1}")#text(" of the identity with ")#mi("{U_1^2 \\subset U}")#text(", which in particular implies that ")#mi("{\\overline{U_1} \\subset U}")#text("; by shrinking ")#mi("{U_1}")#text(" if necessary, we may assume that ")#mi("{\\overline{U_1}}")#text(" is compact. By the subgroup trapping property, one can find an open neighbourhood ")#mi("{U_2}")#text(" of the identity such that ")#mi("{\\langle Q(U_2) \\rangle}")#text(" is contained in ")#mi("{U_1}")#text(", and thus ")#mi("{H := \\overline{\\langle Q(U_2) \\rangle}}")#text(" is a compact subgroup of ")#mi("{G}")#text(" contained in ")#mi("{U_1}")#text(". By shrinking ")#mi("{U_2}")#text(" if necessary we may assume ")#mi("{U_2 \\subset U_1}")#text(".")

#text("Ideally, if ")#mi("{H}")#text(" were normal and contained in ")#mi("{U_2}")#text(", then the quotient group ")#mi("{G/H}")#text(" would have the NSS property. Unfortunately ")#mi("{H}")#text(" need not be normal, and need not be contained in ")#mi("{U_2}")#text(", but we can fix this as follows. Applying Theorem ")#link(<tao-f9fbbc375d07f67ff36b>)[#text("13")]#text(", we can find a compact normal subgroup ")#mi("{N}")#text(" of ")#mi("{H}")#text(" contained in ")#mi("{U_2 \\cap H}")#text(" such that ")#mi("{H/N}")#text(" is isomorphic to a linear group, and in particular is NSS. In particular, we can find an open symmetric neighbourhood ")#mi("{U_3}")#text(" of the identity in ")#mi("{G}")#text(" such that ")#mi("{U_3 N U_3 \\subset U_2}")#text(" and that the quotient space ")#mi("{\\pi(U_3 N U_3 \\cap H)}")#text(" has no non-trivial subgroups in ")#mi("{H/N}")#text(", where ")#mi("{\\pi: H \\rightarrow H/N}")#text(" is the quotient map.")

#text("We now claim that ")#mi("{N}")#text(" is normalised by ")#mi("{U_3}")#text(". Indeed, if ")#mi("{g \\in U_3}")#text(", then the conjugate ")#mi("{N^g := g^{-1} N g}")#text(" of ")#mi("{N}")#text(" is contained in ")#mi("{U_3 N U_3}")#text(" and hence in ")#mi("{U_2}")#text(". As ")#mi("{N^g}")#text(" is a group, it must thus be contained in ")#mi("{Q(U_2)}")#text(" and hence in ")#mi("{H}")#text(". But then ")#mi("{\\pi(N^g)}")#text(" is a subgroup of ")#mi("{H/N}")#text(" that is contained in ")#mi("{\\pi(U_3 N U_3 \\cap H)}")#text(", and is hence trivial by construction. Thus ")#mi("{N^g \\subset N}")#text(", and so ")#mi("{N}")#text(" is normalised by ")#mi("{U_3}")#text(". If we then let ")#mi("{G^{\\prime}}")#text(" be the subgroup of ")#mi("{G}")#text(" generated by ")#mi("{N}")#text(" and ")#mi("{U_3}")#text(", we see that ")#mi("{G^{\\prime}}")#text(" is an open subgroup of ")#mi("{G}")#text(", with ")#mi("{N}")#text(" a compact normal subgroup of ")#mi("{G^{\\prime}}")#text(".")

#text("To finish the job, we need to show that ")#mi("{G^{\\prime}/N}")#text(" has the NSS property. It suffices to show that ")#mi("{U_3 N U_3 / N}")#text(" has no nontrivial subgroups. But any subgroup in ")#mi("{U_3 N U_3 / N}")#text(" pulls back to a subgroup in ")#mi("{U_3 N U_3}")#text(", hence in ")#mi("{U_2}")#text(", hence in ")#mi("{Q(U_2)}")#text(", hence in ")#mi("{H}")#text("; since ")#mi("{(U_3 N U_3 \\cap H)/N}")#text(" has no nontrivial subgroups, the claim follows.")

#heading(level: 1)[#strong[#text(" — 4. From metrisable to subgroup trapping — ")]]

#text("We now perform the most difficult step, which is to establish Proposition ")#link(<tao-8564388283117bb31df2>)[#text("7")]#text(". This step will require both the weak Peter-Weyl theorem (Theorem ")#link(<tao-f9fbbc375d07f67ff36b>)[#text("13")]#text(") and the Gleason technology, as well as some of the basic theory of Hausdorff distance; as such, this is perhaps the most “infinitary” of all the steps in the argument.")

#text("The Gleason-type arguments can be encapsulated in the following proposition, which is a weak version of the subgroup trapping property:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 14 (Finite trapping)")]#text(" ")#metadata(none) <tao-d27d1a09d9f1be229304>#text(" Let ")#mi("{G}")#text(" be a locally compact group, let ")#mi("{U}")#text(" be an open neighbourhood of the identity, and let ")#mi("{m \\geq 1}")#text(" be an integer. Then there exists an open neighbourhood ")#mi("{V}")#text(" of the identity with the following property: if ")#mi("{Q \\subset Q[V]}")#text(" is a symmetric set containing the identity, and ")#mi("{n \\geq 1}")#text(" is such that ")#mi("{Q^n \\subset U}")#text(", then ")#mi("{Q^{mn} \\subset U^8}")#text(".")
]

#text("Informally, Proposition ")#link(<tao-d27d1a09d9f1be229304>)[#text("14")]#text(" asserts that subsets of ")#mi("{Q[V]}")#text(" grow much more slowly than “large” sets such as ")#mi("{U}")#text(". We remark that if one could replace ")#mi("{U^8}")#text(" in the conclusion here by ")#mi("{U}")#text(", then a simple induction on ")#mi("{n}")#text(" (after first shrinking ")#mi("{V}")#text(" to lie in ")#mi("{U}")#text(") would give Proposition ")#link(<tao-8564388283117bb31df2>)[#text("7")]#text(". It is the loss of ")#mi("{8}")#text(" in the exponent that necessitates some non-trivial additional arguments.")

#emph[#text("Proof:")]#text(" } Let ")#mi("{V}")#text(" be small enough to be chosen later, and let ")#mi("{Q, n}")#text(" be as in the proposition. Once again we will convolve together two “Lipschitz” functions ")#mi("{\\psi, \\eta}")#text(" to obtain a good bump function ")#mi("{\\phi = \\psi*\\eta}")#text(" which generates a useful metric for analysing the situation. The first bump function ")#mi("{\\psi: G \\rightarrow {\\bf R}}")#text(" will be defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\psi(x) := \\sup \\{ 1 - \\frac{j}{n}: x \\in Q^j U; j = 0,\\ldots,n \\} \\cup \\{0\\}.")]]

#text("Then ")#mi("{\\psi}")#text(" takes values in ")#mi("{[0,1]}")#text(", equals ")#mi("{1}")#text(" on ")#mi("{U}")#text(", is supported in ")#mi("{U^2}")#text(", and obeys the Lipschitz type property ")#metadata(none) <tao-409a14887e0958f1efcd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("\\left|\\partial_q \\psi(x)\\right| \\leq \\frac{1}{n}", block: true)]]

#text("for all ")#mi("{q \\in Q}")#text(". The second bump function ")#mi("{\\eta: G \\rightarrow {\\bf R}}")#text(" is similarly defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\eta(x) := \\sup \\{ 1 - \\frac{j}{M}: x \\in (V^{U^4})^j U; j = 0,\\ldots,M \\} \\cup \\{0\\},")]]

#text("where ")#mi("{V^{U^4} := \\{ g^{-1} x g: x \\in V, g \\in U^4 \\}}")#text(", where ")#mi("{M}")#text(" is a quantity depending on ")#mi("{m}")#text(" and ")#mi("{U}")#text(" to be chosen later. If ")#mi("{V}")#text(" is small enough depending on ")#mi("{U}")#text(" and ")#mi("{m}")#text(", then ")#mi("{(V^{U^4})^M \\subset U}")#text(", and so ")#mi("{\\eta}")#text(" also takes values in ")#mi("{[0,1]}")#text(", equals ")#mi("{1}")#text(" on ")#mi("{U}")#text(", is supported in ")#mi("{U^2}")#text(", and obeys the Lipschitz type property ")#metadata(none) <tao-847901fd867ee75b5f12>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("\\left|\\partial_g \\psi(x)\\right| \\leq \\frac{1}{M}", block: true)]]

#text("for all ")#mi("{g \\in V^{U^4}}")#text(".")

#text("Now let ")#mi("{\\phi := \\psi * \\eta}")#text(". Then ")#mi("{\\phi}")#text(" is supported on ")#mi("{U^4}")#text(" and ")#tao-math("{\\left\\| \\phi \\right\\|_{C_c(G)} \\gg 1}", block: false)#text(" (where implied constants can depend on ")#mi("{U}")#text(", ")#mi("{\\mu}")#text("). As before, we conclude that ")#mi("{g \\in U^8}")#text(" whenever ")#tao-math("{\\left\\|g\\right\\|_\\phi}", block: false)#text(" is sufficiently small.")

#text("Now suppose that ")#mi("{q \\in Q[V]}")#text("; we will estimate ")#tao-math("{\\left\\|q\\right\\|_\\phi}", block: false)#text(". From ")#link(<tao-72d9f85b4e4fda3ed392>)[#text("(5)")]#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\|q\\right\\|_\\phi \\ll \\frac{1}{n} \\left\\| q^n \\right\\|_\\phi + \\sup_{0 \\leq i \\leq n} \\left\\| \\partial_{q^i} \\partial_{q} \\phi \\right\\|_{C_c(G)}", block: true)]]

#text("(note that ")#mi("{\\partial_{q^i}}")#text(" and ")#mi("{\\partial_q}")#text(" commute). For the first term, we can compute")

#align(center)[#tao-fit-display[#tao-math("\\left\\| q^n \\right\\|_\\phi = \\sup_x \\left|\\partial_{q^n} (\\psi * \\eta)(x)\\right|", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\partial_{q^n} (\\psi * \\eta)(x) = \\int_G \\psi(y) \\partial_{(q^n)^y}(y^{-1} x) d\\mu(y).")]]

#text("Since ")#mi("{q \\in Q[V]}")#text(", ")#mi("{q^n \\in V}")#text(", so by ")#link(<tao-847901fd867ee75b5f12>)[#text("(20)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| q^n \\right\\|_\\phi \\ll \\frac{1}{M}.", block: true)]]

#text("For the second term, we similarly expand")

#align(center)[#tao-fit-display[#mitex("\\partial_{q^i} \\partial_{q^i} \\phi(x) = \\int_G (\\partial_q \\psi)(y) \\partial_{(q^n)^y}(y^{-1} x) d\\mu(y).")]]

#text("Using ")#link(<tao-847901fd867ee75b5f12>)[#text("(20)")]#text(", ")#link(<tao-409a14887e0958f1efcd>)[#text("(19)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\partial_{q^i} \\partial_{q^i} \\phi(x)\\right| \\ll \\frac{1}{Mn}.", block: true)]]

#text("Putting this together we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|q\\right\\|_\\phi \\ll \\frac{1}{Mn}", block: true)]]

#text("for all ")#mi("{q \\in Q[V]}")#text(", which in particular implies that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| g \\right\\|_\\phi \\ll \\frac{m}{M}", block: true)]]

#text("for all ")#mi("{g \\in Q^{mn}}")#text(". For ")#mi("{M}")#text(" sufficiently large, this gives ")#mi("{Q^{mn} \\subset U^8}")#text(" as required. ")#mi("\\Box")

#text("We will also need the following compactness result in the ")#link("http://en.wikipedia.org/wiki/Hausdorff_distance")[#text("Hausdorff distance")]

#align(center)[#tao-fit-display[#mitex("d_H( E, F ) := \\max( \\sup_{x \\in E} \\text{dist}(x,F), \\sup_{y \\in F} \\text{dist}(E, y) )")]]

#text("between two non-empty closed subsets ")#mi("{E, F}")#text(" of a metric space ")#mi("{(X,d)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" In ")#mi("{{\\bf R}}")#text(" with the usual metric, the finite sets ")#mi("{\\{ \\frac{i}{n}: i=1,\\ldots,n\\}}")#text(" converge in Hausdorff distance to the closed interval ")#mi("{[0,1]}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 15")]#text(" ")#metadata(none) <tao-59bd2e1fa31d7ce676a3>#text(" The space ")#mi("{K(X)}")#text(" of non-empty closed subsets of a compact metric space ")#mi("{X}")#text(" is itself a compact metric space (with the Hausdorff distance as the metric).")
]

#emph[#text("Proof:")]#text(" It is easy to see that the Hausdorff distance is indeed a metric on ")#mi("{K(X)}")#text(", and that this metric is complete. The total boundedness of ")#mi("{X}")#text(" easily implies the total boundedness of ")#mi("{K(X)}")#text(" (indeed, once one can cover ")#mi("{X}")#text(" by the ")#mi("{\\epsilon}")#text("-neighbourhood of a finite set ")#mi("{F}")#text(", one can cover ")#mi("{K(X)}")#text(" by the ")#mi("{2\\epsilon}")#text("-neighbourhood of ")#mi("{K(F)}")#text(", by “rounding” off any closed subset of ")#mi("{X}")#text(" to the nearest subset of ")#mi("{F}")#text("). The claim then follows from the Heine-Borel theorem. ")#mi("\\Box")

#text("Now we can prove Proposition ")#link(<tao-8564388283117bb31df2>)[#text("7")]#text(". Let ")#mi("{G}")#text(" be a locally compact group endowed with some metric ")#mi("{d}")#text(", and let ")#mi("{U}")#text(" be an open neighbourhood of the identity; by shrinking ")#mi("{U}")#text(" we may assume that ")#mi("{U}")#text(" is precompact. Let ")#mi("{V_i}")#text(" be a sequence of balls around the identity with radius going to zero, then ")#mi("{Q[V_i]}")#text(" is a symmetric set in ")#mi("{V_i}")#text(" that contains the identity. If, for some ")#mi("{i}")#text(", ")#mi("{Q[V_i]^n \\subset U}")#text(" for every ")#mi("{n}")#text(", then ")#mi("{\\langle Q (V_i) \\rangle \\subset U}")#text(" and we are done. Thus, we may assume for sake of contradiction that there exists ")#mi("{n_i}")#text(" such that ")#mi("{Q[V_i]^{n_i} \\subset U}")#text(" and ")#mi("{Q[V_i]^{n_i + 1} \\not \\subset U}")#text("; since the ")#mi("{V_i}")#text(" go to zero, we have ")#mi("{n_i \\rightarrow \\infty}")#text(". By Proposition ")#link(<tao-d27d1a09d9f1be229304>)[#text("14")]#text(", we can also find ")#mi("{m_i \\rightarrow \\infty}")#text(" such that ")#mi("{Q[V_i]^{m_i n_i} \\subset U^8}")#text(".")

#text("The sets ")#mi("{\\overline{Q[V_i]}^{n_i}}")#text(" are closed subsets of ")#mi("{\\overline{U}}")#text("; by Lemma ")#link(<tao-59bd2e1fa31d7ce676a3>)[#text("15")]#text(", we may pass to a subsequence and assume that they converge to some closed subset ")#mi("{E}")#text(" of ")#mi("{\\overline{U}}")#text(". Since the ")#mi("{Q[V_i]}")#text(" are symmetric and contain the identity, ")#mi("{E}")#text(" is also symmetric and contains the identity. For any fixed ")#mi("{m}")#text(", we have ")#mi("{Q[V_i]^{m n_i} \\subset U^8}")#text(" for all sufficiently large ")#mi("{i}")#text(", which on taking Hausdorff limits implies that ")#mi("{E^m \\subset \\overline{U^8}}")#text(". In particular, the group ")#mi("{H := \\overline{\\langle E \\rangle}}")#text(" is a compact subgroup of ")#mi("{G}")#text(" contained in ")#mi("{\\overline{U^8}}")#text(".")

#text("Let ")#mi("{U_1}")#text(" be a small neighbourhood of the identity in ")#mi("{G}")#text(" to be chosen later. By Theorem ")#link(<tao-f9fbbc375d07f67ff36b>)[#text("13")]#text(", we can find a normal subgroup ")#mi("{N}")#text(" of ")#mi("{H}")#text(" contained in ")#mi("{U_1 \\cap H}")#text(" such that ")#mi("{H/N}")#text(" is NSS. Let ")#mi("{B}")#text(" be a neigbourhood of the identity in ")#mi("{H/N}")#text(" so small that ")#mi("{B^{10}}")#text(" has no small subgroups. A compactness argument then shows that there exists a natural number ")#mi("{k}")#text(" such that for any ")#mi("{g \\in H/N}")#text(" that is not in ")#mi("{B}")#text(", at least one of ")#mi("{g, \\ldots,g^k}")#text(" must lie outside of ")#mi("{B^{10}}")#text(".")

#text("Now let ")#mi("{\\epsilon > 0}")#text(" be a small parameter. Since ")#mi("{Q[V_i]^{n_i+1} \\not \\subset U}")#text(", we see that ")#mi("{Q[V_i]^{n_i+1}}")#text(" does not lie in the ")#mi("{\\epsilon}")#text("-neighbourhood ")#mi("{\\pi^{-1}(B)_\\epsilon}")#text(" of ")#mi("{\\pi^{-1}(B)}")#text(" if ")#mi("{\\epsilon}")#text(" is small enough, where ")#mi("{\\pi: H \\rightarrow H/N}")#text(" is the projection map. Let ")#mi("{n^{\\prime}_i}")#text(" be the first integer for which ")#mi("{Q[V_i]^{n^{\\prime}_i}}")#text(" does not lie in ")#mi("{\\pi^{-1}(B)_\\epsilon}")#text(", then ")#mi("{n^{\\prime}_i \\leq n_i+1}")#text(" and ")#mi("{n^{\\prime}_i \\rightarrow \\infty}")#text(" as ")#mi("{i \\rightarrow \\infty}")#text(" (for fixed ")#mi("{\\epsilon}")#text("). On the other hand, as ")#mi("{Q[V_i]^{n^{\\prime}_i-1} \\subset \\pi^{-1}(B)_\\epsilon}")#text(", we see from another application of Proposition ")#link(<tao-d27d1a09d9f1be229304>)[#text("14")]#text(" that ")#mi("{Q[V_i]^{kn^{\\prime}_i} \\subset (\\pi^{-1}(B)_\\epsilon)^8}")#text(" if ")#mi("{i}")#text(" is sufficiently large depending on ")#mi("{\\epsilon}")#text(".")

#text("On the other hand, since ")#mi("{Q[V_i]^{n_i}}")#text(" converges to a subset of ")#mi("{H}")#text(" in the Hausdorff distance, we know that for ")#mi("{i}")#text(" large enough, ")#mi("{Q[V_i]^{2n_i}}")#text(" and hence ")#mi("{Q[V_i]^{n^{\\prime}_i}}")#text(" is contained in the ")#mi("{\\epsilon}")#text("-neighbourhood of ")#mi("{H}")#text(". Thus we can find an element ")#mi("{g_i}")#text(" of ")#mi("{Q[V_i]^{n^{\\prime}_i}}")#text(" that lies within ")#mi("{\\epsilon}")#text(" of a group element ")#mi("{h_i}")#text(" of ")#mi("{H}")#text(", but does not lie in ")#mi("{B_\\epsilon}")#text("; thus ")#mi("{h_i}")#text(" lies inside ")#mi("{H \\backslash \\pi^{-1}(B)}")#text(". By construction of ")#mi("{B}")#text(", we can find ")#mi("{1 \\leq j_i \\leq k}")#text(" such that ")#mi("{h^{j_i}_i}")#text(" lies in ")#mi("{H \\backslash \\pi^{-1}(B^{10})}")#text(". But ")#mi("{h_i^{j_i}}")#text(" also lies within ")#mi("{o(1)}")#text(" of ")#mi("{g_i^{j_i}}")#text(", which lies in ")#mi("{Q[V_i]^{kn^{\\prime}_i}}")#text(" and hence in ")#mi("{(\\pi^{-1}(B)_\\epsilon)^8}")#text(", where ")#mi("{o(1)}")#text(" denotes a quantity depending on ")#mi("{\\epsilon}")#text(" that goes to zero as ")#mi("{\\epsilon \\rightarrow 0}")#text(". We conclude that ")#mi("{H \\backslash \\pi^{-1}(B^{10})}")#text(" and ")#mi("{\\pi^{-1}(B^8)}")#text(" are separated by ")#mi("{o(1)}")#text(", which leads to a contradiction if ")#mi("{\\epsilon}")#text(" is sufficiently small (note that ")#mi("{\\overline{\\pi^{-1}(B^8)}}")#text(" and ")#mi("{H \\backslash \\pi^{-1}(B^{10})}")#text(" are compact and disjoint, and hence separated by a positive distance), and the claim follows.")

#heading(level: 1)[#strong[#text(" — 5. From locally compact to metrisable — ")]]

#text("We finally establish Proposition ")#link(<tao-14103b1425f04ac9b3e7>)[#text("6")]#text(", which is actually one of the easier steps of the argument (because the conclusion is so weak). This argument is also ")#link("http://www.ams.org/mathscinet-getitem?mr=39730")[#text("due to Gleason")]#text(". Let ")#mi("{G}")#text(" be a locally compact group, and let ")#mi("{U}")#text(" be an open neighbourhood of the identity. Let ")#mi("{U_0}")#text(" be a symmetric precompact neighbourhood of the identity in ")#mi("{U}")#text(". We can then recursively construct a sequence")

#align(center)[#tao-fit-display[#mitex("U_0 \\supset U_1 \\supset U_2 \\supset \\ldots")]]

#text("of symmetric precompact neighbourhoods such that ")#mi("{(U_{n+1}^{U_0})^2 \\subset U_n}")#text(" for each ")#mi("{n \\geq 0}")#text(". In particular")

#align(center)[#tao-fit-display[#mitex("U_{n+1} \\subset \\overline{U_{n+1}} \\subset U_{n+1}^2 \\subset U_n.")]]

#text("If we then form")

#align(center)[#tao-fit-display[#mitex("N := \\bigcap_n U_n = \\bigcap_n \\overline{U_n}")]]

#text("then ")#mi("{N}")#text(" is compact, symmetric, contains the origin, and ")#mi("{N^2=N}")#text("; thus ")#mi("{N}")#text(" is normal. Also, since ")#mi("{U_{n+1}^{U_0} \\subset U_n}")#text(", we have ")#mi("{N^{U_0} \\subset N}")#text(", thus ")#mi("{N}")#text(" is normalised by ")#mi("{U_0}")#text(". Thus if ")#mi("{G^{\\prime}}")#text(" is the group generated by ")#mi("{U_0}")#text(", then ")#mi("{G^{\\prime}}")#text(" is an open subgroup of ")#mi("{G}")#text(" and ")#mi("{N}")#text(" is a normal subgroup of ")#mi("{G^{\\prime}}")#text(".")

#text("Let ")#mi("{\\pi: G^{\\prime} \\rightarrow G^{\\prime}/N}")#text(" be the quotient map, then we see that ")#mi("{\\pi(U_n)}")#text(" are nested open sets with ")#mi("{\\overline{\\pi(U_n)}}")#text(" compact and whose intersection is the identity. From this one easily verifies that they form a neighbourhood base for ")#mi("{G^{\\prime}/N}")#text(". Thus ")#mi("{G^{\\prime}/N}")#text(" is first countable and Hausdorff, and thus metrisable by the ")#link("https://terrytao.wordpress.com/2011/05/17/the-birkhoff-kakutani-theorem/")[#text("Birkhoff-Kakutani theorem")]#text(". As ")#mi("{G}")#text(" is locally compact, ")#mi("{G^{\\prime}}")#text(" and ")#mi("{G^{\\prime}/N}")#text(" are also locally compact, and the claim follows.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tou")]], [#link("https://terrytao.wordpress.com/2011/07/12/gleasons-lemma/#comment-56096")[#strong[#text("Tou")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2011")])]

#text("I really eager to know how will your team to use these knowledge to solve sum-product problem.Looking forward new posts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a dog")]], [#link("https://terrytao.wordpress.com/2011/07/12/gleasons-lemma/#comment-56120")[#strong[#text("a dog")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2011")])]

#text("— 1. From escape to the commutator estimate —")

#text("↑ 9 line above from this comined→combined")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Escape property of the Gleason metric and sub-riemannian distances again | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/07/12/gleasons-lemma/#comment-56389")[#strong[#text("Escape property of the Gleason metric and sub-riemannian distances again | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2011")])]

#text("[…] last post of Tao from his series of posts on the Hilbert’s fifth problem contains interesting results which […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pros and cons of higher order Pansu derivatives | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/07/12/gleasons-lemma/#comment-56513")[#strong[#text("Pros and cons of higher order Pansu derivatives | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2011")])]

#text("[…] This should be read in conjunction with this post. Please look at Lemma 11 from the last post of Tao and also at the notations made previously in that post. Now, relation (4) contains an […]")
]
