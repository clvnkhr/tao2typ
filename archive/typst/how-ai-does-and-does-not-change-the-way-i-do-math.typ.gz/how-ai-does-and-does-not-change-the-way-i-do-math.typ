// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/29/how-ai-does-and-does-not-change-the-way-i-do-math/
// Converted to Typst by tao2typ: "2026-10-30T13:15:12.405200+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "How AI does, and does not, change the way I do math", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("How AI does, and does not, change the way I do math")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/29/how-ai-does-and-does-not-change-the-way-i-do-math/")[#text("https://terrytao.wordpress.com/2026/09/29/how-ai-does-and-does-not-change-the-way-i-do-math/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-30 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://sites.google.com/view/rachel-webb")[#text("Rachel Webb")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("The way I do math experienced a great upheaval once before, halfway through my PhD. I was in a seminar with a group of graduate students and faculty developing new discipline-specific writing courses. The facilitator asked the question,")

#text("What does it mean to write well in your discipline?")

#text("Then, as now, I use writing as a proxy for doing. As a mid-career grad student, I had a quick answer to this question: good mathematical writing, hence good mathematics, is clear and correct. I was surprised at the dissimilarity between my answer and the answer of the other seminarians (who were more experienced but also other-disciplined): good writing says something interesting.")

#text("This discussion unlocked for me the meaning of doing research. Doing research is searching for something interesting to say. (Of course, once you find it, you have to say it in a way that is clear and correct.) In mathematics, the search for something interesting is often driven by our search for understanding, as noted by ")#link("https://www.math.toronto.edu/mccann/199/thurston.pdf")[#text("Thurston")]#text(" and endorsed by many since. But I think the math research process has a creative aspect that is not completely captured by this search. By contrast, the task of making something interesting to say is like writing a novel whose characters are at once subject to constraints of human experience but also presented in a way that comments on human experience. The characters in mathematical novels are definitions, the story text is the lemmas and theorems; these are constrained by truth, but can also be chosen strategically or artistically to capture certain facets of truth.")

#text("This is, abstractly, how I currently approach math research: I seek to understand what is happening at a fundamental level, yes, but I don’t think there is a unique way to understand. I also seek to take the things I do understand—inevitably, these are just a subset of the phenomena I would like to understand—and craft a narrative from them that is beautiful and ")#emph[#text("interesting")]#text(" to my fellow mathematicians. Concretely, I find that “interest” in a mathematical context often derives from applications, either to the real world, or to other math. It also derives from proximity to high-profile open problems that serve as centers of mathematical conversations.")

#text("I don’t see LLMs as changing that approach much, but I expect they will drastically affect how I execute it.")

#text("The execution changes because now I have access to a machine that has read all the books and knows how many standard lemmas go. This speeds up the research process immensely and turns some of my lands of mathematical fantasy into worlds I can realistically start exploring (dream bigger dreams, says ")#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/")[#text("Antieau")]#text("). Of course, taking the interstate instead of the side roads has its tradeoffs, but for any given leg of the journey I can choose which route to take. I will return to this idea in a moment.")

#text("My approach to research does not change because critically, I’m not convinced that the advent of LLMs changes my metric for mathematical “interest.” If we have historically regarded a paper as interesting if it comments in some way on a Millennium (or similar) problem, need we lessen our interest if the problem has a solution? Certainly there are many solutions, even many shards of understanding that do not constitute full solutions. These are all very interesting. We might know how to get to the ")#link("https://x.com/dlouapre/status/2099470977503486058")[#text("red city")]#text(", but we can continue to map out the surrounding terrain, now all the more valuable for the economic and strategic opportunities arising from metropolitan proximity.")

#text("I have said something about how I will continue to do math research, but I have not discussed why: what reasons do humans have to do math, if LLMs are capable (hypothetically, say) of producing math that is even more interesting than the math we can create? I believe that there are economic reasons, but I will not discuss those (both ")#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/")[#text("Sahai")]#text(" and ")#link("https://www.nytimes.com/2026/09/22/science/math-ai-history-understanding.html?eafs_enabled=false")[#text("Strogatz-Townsend")]#text(" have some thoughts). Instead I present two humanistic reasons. Neither of these is unique to math, just as math is not the unique human practice whose execution is affected by the advent of AI.")

#text("The first reason for humans to do math is that math is interesting to us individually. I enjoy doing math, so I will keep doing it, even if machines are better at it. There is a threat that LLMs will take the fun out of doing math by tempting us towards ")#link("https://mathandai.org/")[#text("knowing the answer over understanding the solution")]#text(". The temptation must be resisted. I should use AI only in ways that make math research more enjoyable for me and allow me to get understanding along with my wisdom (Proverbs 4:7). This may require ")#link("https://www.youtube.com/watch?v=H7_d_sgui6o&t=2044s")[#text("experimentation")]#text(". In fact, I and others already make analogous choices to use technology only when it is helpful to us personally and not every time it is economically “correct.” For example, I persuade my kids every week to walk seven miles round trip to church, even though we could drive. The commute costs well over two hours, but the increase in understanding between family members from the shared time and suffering is worth it.")

#text("The second reason for humans to do math is that math holds shared interest for multiple people at once, and in this way it creates communities. In some sense, this is what the other-disciplined seminarians meant when they said good writing is interesting: they meant that good writing is interesting ")#emph[#text("to other people")]#text(" and hence is a piece of a larger conversation. Math research is a tool for drawing people together, in student-teacher relationships, in collaborations, at conferences, and at department colloquia and tea-times. Again, AI could weaken these social bonds by making ")#link("https://terrytao.wordpress.com/2026/09/22/open-problems-open-mathematics/#more-18287")[#text("(fear of) scooping")]#text(" more common, or just by making it easier to ask a machine than a colleague. But ")#emph[#text("could")]#text(" does not automatically imply ")#emph[#text("will")]#text(". To quote ")#link("https://allpoetry.com/poem/12622463-Manifesto-The-Mad-Farmer-Liberation-Front-by-Wendell-Berry")[#text("Wendell Berry")]#text(", may the age of AI be the age of knowing our mathematical neighbor. “Friends, every day do something that won’t compute.”")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c1f39fda4802b07a12426a497a616a2925f6b74301f71b8be661e831a3db403-2059c209ec074d3a72be41d2e6ca3f4b820a344c32e1c151067d6bcddf93fd5a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2026/09/29/how-ai-does-and-does-not-change-the-way-i-do-math/comment-page-1/#comment-696586")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("Thank you for the link to that poem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0638f8025e96d915d66b224c4075737a02701e62e30a2d836fcda36598360d3-bb0d4ee5ce1d65f1f1daab94cbddb5f4ca0c1db5e7927da2097f36f3aeb988dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Satya")]], [#link("https://terrytao.wordpress.com/2026/09/29/how-ai-does-and-does-not-change-the-way-i-do-math/comment-page-1/#comment-696588")[#strong[#text("Satya")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("We enjoy reading and researching math that lead to understanding a proof or a complete theory. It is some kind of “ecstasy” we get out of it, when we understand a piece of math. If AI produces interesting math, we will read them for the same reason. Life did not change for me, due to the advent of AI. Again there is a difference between a conjecture/result and a complete theory. There is no evidence that AI can produce a theory.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d588a49dcd262417c38119c66b0b17c3c2349e37e8d76765eb530e1ebd66e477-884ce7f5e374b7082b57ef2afc6fb777de252576af92d30f761fc44fa61312ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jimmy")]], [#link("https://terrytao.wordpress.com/2026/09/29/how-ai-does-and-does-not-change-the-way-i-do-math/comment-page-1/#comment-696592")[#strong[#text("Jimmy")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("The writing-as-a-proxy framing is the part that stays with me – treating clarity of writing as a working measurement of clarity of understanding gives students something actionable, in a way that ‘check the AI output carefully’ never quite does. The caveat that a polished paragraph can hide an unresolved definition is fair too; fluency is now free, so the signal has to come from somewhere more structural. From watching AI coding tools day to day I see the same split: drafting got cheap, but deciding what the artifact should even say is where the real work concentrates. The course-design angle at the end is a quietly practical contribution.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/29/how-ai-does-and-does-not-change-the-way-i-do-math/comment-page-1/#comment-696593")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text(">>AI could weaken these social bonds by making ")#link("https://terrytao.wordpress.com/2026/09/22/open-problems-open-mathematics/#more-18287")[#text("(fear of) >>scooping")]#text(" more common, or just by making it easier to ask a >>machine than a colleague. But ")#emph[#text("could")]#text(" does not automatically imply ")#emph[#text("will")]#text(".")

#text("It does it already, I see people at all levels asking a machine rather than a colleague all the time around me. Bonds are being ruined as we speak.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/29/how-ai-does-and-does-not-change-the-way-i-do-math/comment-page-1/#comment-696596")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("Some other bonds can form, though I am not claiming that they will necessarily compensate. For example I am now more collaborative with people slightly further from my expertise than prior, as the barriers to entry into (still by any standard rather nearby) fields have lessened a little. eg I get my GPT to generate me lists of exercises in near-ish fields so that I can more fluently talk to some colleagues and I find this very enriching. I am rather confident that AI is absolutely here to stay and I am trying to find ways to preserve my enjoyment in my work. Happily, I have found that there are some parts of my work that I now enjoy more, learning stuff near enough to my expertise is just one such.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/29/how-ai-does-and-does-not-change-the-way-i-do-math/comment-page-1/#comment-696595")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("Thank you very much for this helpful insight into how artificial intelligence could positively advance mathematical research and work. However, I have two fundamental comments. To help you understand them, here’s a brief overview of my situation:")

#text("I studied mathematics 40 years ago and then worked professionally in the field of cybersecurity. Now that I’m retired, I’ve returned to mathematics, so to speak, and am trying to keep up with the exciting developments in my own field (algebraic number theory).")

#text("Point 1: Until now, I’ve been able to openly access almost all literature (except for a few journals behind paywalls) and follow along with theorems and proofs. I could only access the powerful AI models developed by large corporations by paying for them—and I couldn’t access the latest models at all. This remains the preserve of a very small circle.")

#text("Point 2: I cannot understand how the sensational results—for example, those from OpenAI—were achieved, since the prompts have hardly been published anywhere so far; only the final, refined results have been made available. This turns mathematical research into a black box.")

#text("Personally, I find both of these points dangerous and more relevant than the challenge of having to change one’s own way of working—something that professional life has always required anyway.")

#text("Best regards, Andreas Andreas Könen, Bonn, Germany Translated with DeepL.com (free version)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/29/how-ai-does-and-does-not-change-the-way-i-do-math/comment-page-1/#comment-696633")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("“Point 1: Until now, I’ve been able to openly access almost all literature (except for a few journals behind paywalls) and follow along with theorems and proofs. I could only access the powerful AI models developed by large corporations by paying for them—and I couldn’t access the latest models at all. This remains the preserve of a very small circle.”")

#text("Most people who are not academics cannot access a lot of mathematics papers because a lot of the older papers from the 20th century are locked behind a journal subscription that universities conveniently provide for free to academics but the average person is locked behind a paywall.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/29/how-ai-does-and-does-not-change-the-way-i-do-math/comment-page-1/#comment-696680")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("But it is really easy to get access to nearly all the publications if you just approach someone at a university or register as a guest student …")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/29/how-ai-does-and-does-not-change-the-way-i-do-math/comment-page-1/#comment-696598")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("thanks! it’s inspiring!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7377cd9166832e84e78c3bd4bbf36b87cada29d7774789451236c0f167a06373-1b6b87bce6121b93eed7f0cb234cc8bdef2af65f5d30cf674e043b5d04aa78d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexey Solyanik")]], [#link("https://terrytao.wordpress.com/2026/09/29/how-ai-does-and-does-not-change-the-way-i-do-math/comment-page-1/#comment-696612")[#strong[#text("Alexey Solyanik")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2026")])]

#text("This is a point of view very close to my own. I apologize for posting these somewhat unstructured thoughts, but they come to me immediately after reading this blog.")

#text("From my perspective, artificial intelligence, by virtue of having access to an enormous amount of resources, possesses essentially all of humanity’s accumulated knowledge as of ")#strong[#text("today")]#text(". The critical word here is ")#strong[#text("today")]#text(".")

#text("To use a very crude and admittedly far-fetched analogy, AI could easily solve any problem or play—and win—a game of dominoes involving 10³⁶ tiles. But it could never invent chess, let alone poker.")

#text("In my view, a good “Turing test” would be to ask AI a question that has never been published and has never been discussed anywhere online. But it should not be a question about solving a known problem. It should be a question about something genuinely new—something truly novel that, for example, a mathematician has just discovered.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/29/how-ai-does-and-does-not-change-the-way-i-do-math/comment-page-1/#comment-696647")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("believe me, many of us experience AI solving unpublished new and rather hard problems daily.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/29/how-ai-does-and-does-not-change-the-way-i-do-math/comment-page-1/#comment-696631")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("A great article. Mathematicians being people (of course), with emotions, who want to be recognized for being the FIRST to solve a conjecture. And here is where the problem is with AI come in. People doing mathematics “research,” being credentialled mathematicians or not, using AI to solve a conjecture play by their own rules in a mad rush to find a solution, any solution. Thus, they get there first with the help of AI. So they then get the glory. Meanwhile, the research mathematicians who was moving along just fine at a human pace was outflanked by a glorified calculator with superinteligence. The human not using AI was usurped by someone using AI and who perhaps has a baseline level of mathematics knowledge. So to me, THAT is the big friction between mathematicians and AI. I just wish mathematicians would just make the obvious explicit. And they can do that as a unit using whichever mathematical societies (the more the better) to state a counter to this situation. I have seen one person state that the human, whether they are using AI or not, MUST verbally explain their solution, at a blackboard, in front of experts as to how THEY (the human) arrived at their brilliant solution to “x” conjecture. If they can convince the panel that the human has the in-depth knowledge required to fully understand and solve the conjecture WITHOUT the need for AI to explain it, then yes, that person gets the credit for solving the conjecture. Otherwise, the conjecture remains an OPEN problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/578b484817082eb7fc046ffe29c12285babd5b720c8be2da8e08512018e88b41-67bc3e66fb277844766027f19003a32eb3e907369fc417cb492816a252915665.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valiantly245f650684")]], [#link("https://terrytao.wordpress.com/2026/09/29/how-ai-does-and-does-not-change-the-way-i-do-math/comment-page-1/#comment-696656")[#strong[#text("valiantly245f650684")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("LLMs are forcing the math community to discuss and look back at how and why we do our research, and the meaning and human experience behind mathematics, which is good because we need more awareness on these important questions and reflect on the purpose of doing mathematics in the first place (and as a student I learned a lot from these discussions)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d67e7962ed5c56f85e0b4facda14b5f3bc650d3d8d487ef7329954052adbbc1-f0dc3ecc3ce450c3efa0df5bd9d3a9cd0283f7a64b748b6098fd817eb2aee54e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of agustin.pinovalero")]], [#link("https://terrytao.wordpress.com/2026/09/29/how-ai-does-and-does-not-change-the-way-i-do-math/comment-page-1/#comment-696675")[#strong[#text("agustin.pinovalero")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("I like to swim and I can do it very well. Since some years ago the people has started to use swim fins. Now many of these people swim so fast like me because they use this artificial aid. Is this a problem for me? The only problem I see is that fast 100% of those who use articial aid to swim to increase the speed don’t know how to circulate properly in the swimming pool and they provoque awkward situations. Has this anything to do with the situation which AI is causing?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/29/how-ai-does-and-does-not-change-the-way-i-do-math/comment-page-1/#comment-696873")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("@agustin.pinovalero “Now many of these people swim so fast like me because they use this artificial aid. Is this a problem for me?”")

#text("Yes, it is a problem if you are a swimming grad student who is trying to become a swimming coach. The prevalent corporate influence has reduced the art of swimming to a number – your swimming speed.")

#text("So clearly you will be worried (unless you stop swimming for the sake of enjoyment, and are sufficiently rich to buy the fastest swim fins possible).")
]
]
