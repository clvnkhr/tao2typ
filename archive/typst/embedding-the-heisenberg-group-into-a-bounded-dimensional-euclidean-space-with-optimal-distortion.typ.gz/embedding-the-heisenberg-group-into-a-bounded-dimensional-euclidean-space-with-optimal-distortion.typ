// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/11/26/embedding-the-heisenberg-group-into-a-bounded-dimensional-euclidean-space-with-optimal-distortion/
// Converted to Typst by tao2typ: "2026-10-14T16:38:28.492788+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Embedding the Heisenberg group into a bounded dimensional Euclidean space with optimal distortion", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Embedding the Heisenberg group into a bounded dimensional Euclidean space with optimal distortion")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 November 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/11/26/embedding-the-heisenberg-group-into-a-bounded-dimensional-euclidean-space-with-optimal-distortion/")[#text("https://terrytao.wordpress.com/2018/11/26/embedding-the-heisenberg-group-into-a-bounded-dimensional-euclidean-space-with-optimal-distortion/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper “")#link("https://arxiv.org/abs/1811.09223")[#text("Embedding the Heisenberg group into a bounded dimensional Euclidean space with optimal distortion")]#text("“, submitted to ")#link("http://www.ems-ph.org/journals/journal.php?jrn=RMI")[#text("Revista Matematica Iberoamericana")]#text(". This paper concerns the extent to which one can accurately embed the metric structure of the ")#link("https://en.wikipedia.org/wiki/Heisenberg_group")[#text("Heisenberg group")]

#align(center)[#tao-fit-display[#mitex("H := \\begin{pmatrix} 1 & {\\bf R} & {\\bf R} \\\\ 0 & 1 & {\\bf R} \\\\ 0 & 0 & 1 \\end{pmatrix}")]]

#text("into Euclidean space, which we can write as ")#mi("{\\{ [x,y,z]: x,y,z \\in {\\bf R} \\}}")#text(" with the notation")

#align(center)[#tao-fit-display[#mitex("[x,y,z] := \\begin{pmatrix} 1 & x & z \\\\ 0 & 1 & y \\\\ 0 & 0 & 1 \\end{pmatrix}.")]]

#text("Here we give ")#mi("{H}")#text(" the right-invariant ")#link("https://en.wikipedia.org/wiki/Sub-Riemannian_manifold")[#text("Carnot-Carathéodory metric")]#text(" ")#mi("{d}")#text(" coming from the right-invariant vector fields")

#align(center)[#tao-fit-display[#mitex("X := \\frac{\\partial}{\\partial x} + y \\frac{\\partial}{\\partial z}; \\quad Y := \\frac{\\partial}{\\partial y}")]]

#text("but not from the commutator vector field")

#align(center)[#tao-fit-display[#mitex("Z := [Y,X] = \\frac{\\partial}{\\partial z}.")]]

#text("This gives ")#mi("{H}")#text(" the geometry of a ")#link("https://en.wikipedia.org/wiki/Carnot_group")[#text("Carnot group")]#text(". As observed ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1402671")[#text("by Semmes")]#text(", it follows from the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=979599")[#text("Carnot group differentiation theory of Pansu")]#text(" that there is no bilipschitz map from ")#mi("{(H,d)}")#text(" to any Euclidean space ")#mi("{{\\bf R}^D}")#text(" or even to ")#mi("{\\ell^2}")#text(", since such a map must be differentiable almost everywhere in the sense of Carnot groups, which in particular shows that the derivative map annihilate ")#mi("{Z}")#text(" almost everywhere, which is incompatible with being bilipschitz.")

#text("On the other hand, if one ")#emph[#text("snowflakes")]#text(" the Heisenberg group by replacing the metric ")#mi("{d}")#text(" with ")#mi("{d^{1-\\varepsilon}}")#text(" for some ")#mi("{0 < \\varepsilon < 1}")#text(", then it follows from the general theory of Assouad on embedding snowflaked metrics of doubling spaces that ")#mi("{(H,d^{1-\\varepsilon})}")#text(" may be embedded in a bilipschitz fashion into ")#mi("{\\ell^2}")#text(", or even to ")#mi("{{\\bf R}^{D_\\varepsilon}}")#text(" for some ")#mi("{D_\\varepsilon}")#text(" depending on ")#mi("{\\varepsilon}")#text(".")

#text("Of course, the distortion of this bilipschitz embedding must degenerate in the limit ")#mi("{\\varepsilon \\rightarrow 0}")#text(". From the work of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3095705")[#text("Austin-Naor-Tessera")]#text(" and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2990137")[#text("Naor-Neiman")]#text(" it follows that ")#mi("{(H,d^{1-\\varepsilon})}")#text(" may be embedded into ")#mi("{\\ell^2}")#text(" with a distortion of ")#mi("{O( \\varepsilon^{-1/2} )}")#text(", but no better. The Naor-Neiman paper also embeds ")#mi("{(H,d^{1-\\varepsilon})}")#text(" into a finite-dimensional space ")#mi("{{\\bf R}^D}")#text(" with ")#mi("{D}")#text(" independent of ")#mi("{\\varepsilon}")#text(", but at the cost of worsening the distortion to ")#mi("{O(\\varepsilon^{-1})}")#text(". They then posed the question of whether this worsening of the distortion is necessary.")

#text("The main result of this paper answers this question in the negative:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" There exists an absolute constant ")#mi("{D}")#text(" such that ")#mi("{(H,d^{1-\\varepsilon})}")#text(" may be embedded into ")#mi("{{\\bf R}^D}")#text(" in a bilipschitz fashion with distortion ")#mi("{O(\\varepsilon^{-1/2})}")#text(" for any ")#mi("{0 < \\varepsilon \\leq 1/2}")#text(".")
]

#text("To motivate the proof of this theorem, let us first present a bilipschitz map ")#mi("{\\Phi: {\\bf R} \\rightarrow \\ell^2}")#text(" from the snowflaked line ")#mi("{({\\bf R},d_{\\bf R}^{1-\\varepsilon})}")#text(" (with ")#mi("{d_{\\bf R}}")#text(" being the usual metric on ")#mi("{{\\bf R}}")#text(") into complex Hilbert space ")#mi("{\\ell^2({\\bf C})}")#text(". The map is given explicitly as a Weierstrass type function")

#align(center)[#tao-fit-display[#mitex("\\Phi(x) := \\sum_{k \\in {\\bf Z}} 2^{-\\varepsilon k} (\\phi_k(x) - \\phi_k(0))")]]

#text("where for each ")#mi("{k}")#text(", ")#mi("{\\phi_k: {\\bf R} \\rightarrow \\ell^2}")#text(" is the function")

#align(center)[#tao-fit-display[#mitex("\\phi_k(x) := 2^k e^{2\\pi i x / 2^k} e_k.")]]

#text("and ")#mi("{(e_k)_{k \\in {\\bf Z}}}")#text(" are an orthonormal basis for ")#mi("{\\ell^2({\\bf C})}")#text(". The subtracting of the constant ")#mi("{\\phi_k(0)}")#text(" is purely in order to make the sum convergent as ")#mi("{k \\rightarrow \\infty}")#text(". If ")#mi("{x,y \\in {\\bf R}}")#text(" are such that ")#mi("{2^{k_0-2} \\leq d_{\\bf R}(x,y) \\leq 2^{k_0-1}}")#text(" for some integer ")#mi("{k_0}")#text(", one can easily check the bounds")

#align(center)[#tao-fit-display[#tao-math("2^{-\\varepsilon k}\\left|\\phi_k(x) - \\phi_k(y)\\right| \\lesssim d_{\\bf R}(x,y)^{(1-\\varepsilon)} \\min( 2^{-(1-\\varepsilon) (k_0-k)}, 2^{-\\varepsilon (k-k_0)} )", block: true)]]

#text("with the lower bound")

#align(center)[#tao-fit-display[#tao-math("2^{-\\varepsilon k_0}\\left|\\phi_{k_0}(x) - \\phi_{k_0}(y)\\right| \\gtrsim d_{\\bf R}(x,y)^{(1-\\varepsilon)}", block: true)]]

#text("at which point one finds that")

#align(center)[#tao-fit-display[#tao-math("d_{\\bf R}(x,y)^{1-\\varepsilon} \\lesssim \\left|\\Phi(x) - \\Phi(y)\\right| \\lesssim \\varepsilon^{-1/2} d_{\\bf R}(x,y)^{1-\\varepsilon}", block: true)]]

#text("as desired.")

#text("The key here was that each function ")#mi("{\\phi_k}")#text(" oscillated at a different spatial scale ")#mi("{2^k}")#text(", and the functions were all orthogonal to each other (so that the upper bound involved a factor of ")#mi("{\\varepsilon^{-1/2}}")#text(" rather than ")#mi("{\\varepsilon^{-1}}")#text("). One can replicate this example for the Heisenberg group without much difficulty. Indeed, if we let ")#mi("{\\Gamma := \\{ [a,b,c]: a,b,c \\in {\\bf Z} \\}}")#text(" be the discrete Heisenberg group, then the nilmanifold ")#mi("{H/\\Gamma}")#text(" is a three-dimensional smooth compact manifold; thus, by the ")#link("https://en.wikipedia.org/wiki/Whitney_embedding_theorem")[#text("Whitney embedding theorem")]#text(", it smoothly embeds into ")#mi("{{\\bf R}^6}")#text(". This gives a smooth immersion ")#mi("{\\phi: H \\rightarrow {\\bf R}^6}")#text(" which is ")#mi("{\\Gamma}")#text("-automorphic in the sense that ")#mi("{\\phi(p\\gamma) = \\phi(p)}")#text(" for all ")#mi("{p \\in H}")#text(" and ")#mi("{\\gamma \\in \\Gamma}")#text(". If one then defines ")#mi("{\\phi_k: H \\rightarrow \\ell^2 \\otimes {\\bf R}^6}")#text(" to be the function")

#align(center)[#tao-fit-display[#mitex("\\phi_k(p) := 2^k \\phi( \\delta_{2^{-k}}(p) ) \\otimes e_k")]]

#text("where ")#mi("{\\delta_\\lambda: H \\rightarrow H}")#text(" is the scaling map")

#align(center)[#tao-fit-display[#mitex("\\delta_\\lambda([x,y,z]) := [\\lambda x, \\lambda y, \\lambda^2 z],")]]

#text("then one can repeat the previous arguments to obtain the required bilipschitz bounds")

#align(center)[#tao-fit-display[#mitex("d(p,q)^{1-\\varepsilon} \\lesssim |\\Phi(p) - \\Phi(q) \\lesssim \\varepsilon^{-1/2} d(p,q)^{1-\\varepsilon}")]]

#text("for the function")

#align(center)[#tao-fit-display[#mitex("\\Phi(p) :=\\sum_{k \\in {\\bf Z}} 2^{-\\varepsilon k} (\\phi_k(p) - \\phi_k(0)).")]]

#text("To adapt this construction to bounded dimension, the main obstruction was the requirement that the ")#mi("{\\phi_k}")#text(" took values in orthogonal subspaces. But if one works things out carefully, it is enough to require the weaker orthogonality requirement")

#align(center)[#tao-fit-display[#mitex("B( \\phi_{k_0}, \\sum_{k>k_0} 2^{-\\varepsilon(k-k_0)} \\phi_k ) = 0")]]

#text("for all ")#mi("{k_0 \\in {\\bf Z}}")#text(", where ")#mi("{B(\\phi, \\psi): H \\rightarrow {\\bf R}^2}")#text(" is the bilinear form")

#align(center)[#tao-fit-display[#mitex("B(\\phi,\\psi) := (X \\phi \\cdot X \\psi, Y \\phi \\cdot Y \\psi ).")]]

#text("One can then try to construct the ")#mi("{\\phi_k: H \\rightarrow {\\bf R}^D}")#text(" for bounded dimension ")#mi("{D}")#text(" by an iterative argument. After some standard reductions, the problem becomes this (roughly speaking): given a smooth, slowly varying function ")#mi("{\\psi: H \\rightarrow {\\bf R}^{D}}")#text(" whose derivatives obey certain quantitative upper and lower bounds, construct a smooth oscillating function ")#mi("{\\phi: H \\rightarrow {\\bf R}^{D}}")#text(", whose derivatives also obey certain quantitative upper and lower bounds, which obey the equation ")#metadata(none) <tao-bbc7250080821c5b268b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("B(\\phi,\\psi) = 0.")]]



#text(" We view this as an underdetermined system of differential equations for ")#mi("{\\phi}")#text(" (two equations in ")#mi("{D}")#text(" unknowns; after some reductions, our ")#mi("{D}")#text(" can be taken to be the explicit value ")#mi("{36}")#text("). The trivial solution ")#mi("{\\phi=0}")#text(" to this equation will be inadmissible for our purposes due to the lower bounds we will require on ")#mi("{\\phi}")#text(" (in order to obtain the quantitative immersion property mentioned previously, as well as for a stronger “freeness” property that is needed to close the iteration). Because this construction will need to be iterated, it will be essential that the regularity control on ")#mi("{\\phi}")#text(" is the same as that on ")#mi("{\\psi}")#text("; one cannot afford to “lose derivatives” when passing from ")#mi("{\\psi}")#text(" to ")#mi("{\\phi}")#text(".")

#text("This problem has some formal similarities with the isometric embedding problem (discussed for instance in ")#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/")[#text("this previous post")]#text("), which can be viewed as the problem of solving an equation of the form ")#mi("{Q(\\phi,\\phi) = g}")#text(", where ")#mi("{(M,g)}")#text(" is a Riemannian manifold and ")#mi("{Q}")#text(" is the bilinear form")

#align(center)[#tao-fit-display[#mitex("Q(\\phi,\\psi)_{ij} = \\partial_i \\phi \\cdot \\partial_j \\psi.")]]

#text("The isometric embedding problem also has the key obstacle that naive attempts to solve the equation ")#mi("{Q(\\phi,\\phi)=g}")#text(" iteratively can lead to an undesirable “loss of derivatives” that prevents one from iterating indefinitely. This obstacle was famously resolved by ")#link("https://en.wikipedia.org/wiki/Nash%E2%80%93Moser_theorem")[#text("the Nash-Moser iteration scheme")]#text(" in which one alternates between perturbatively adjusting an approximate solution to improve the residual error term, and mollifying the resulting perturbation to counteract the loss of derivatives. The current equation ")#link(<tao-bbc7250080821c5b268b>)[#text("(1)")]#text(" differs in some key respects from the isometric embedding equation ")#mi("{Q(\\phi,\\phi)=g}")#text(", in particular being linear in the unknown field ")#mi("{\\phi}")#text(" rather than quadratic; nevertheless the key obstacle is the same, namely that naive attempts to solve either equation lose derivatives. Our approach to solving ")#link(<tao-bbc7250080821c5b268b>)[#text("(1)")]#text(" was inspired by the Nash-Moser scheme; in retrospect, I also found similarities with ")#link("http://www.ams.org/mathscinet-getitem?mr=666111")[#text("Uchiyama’s constructive proof")]#text(" of the Fefferman-Stein decomposition theorem, discussed in ")#link("https://terrytao.wordpress.com/2007/02/23/uchiyamas-constructive-proof-of-the-fefferman-stein-decomposition/")[#text("this previous post")]#text(" (and in ")#link("https://terrytao.wordpress.com/2018/11/21/the-nonlinearity-of-the-fefferman-stein-decomposition/")[#text("this recent one")]#text(").")

#text("To motivate this iteration, we first express ")#mi("{B(\\phi,\\psi)}")#text(" using the product rule in a form that does not place derivatives directly on the unknown ")#mi("{\\phi}")#text(": ")#metadata(none) <tao-4cf1e7c350e20e009299>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("B(\\phi,\\psi) = \\left( W(\\phi \\cdot W \\psi) - \\phi \\cdot WW \\psi\\right)_{W = X,Y}")]]



#text(" This reveals that one can construct solutions ")#mi("{\\phi}")#text(" to ")#link(<tao-bbc7250080821c5b268b>)[#text("(1)")]#text(" by solving the system of equations ")#metadata(none) <tao-cc9e80c60a47c8de9a2b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\phi \\cdot W \\psi = \\phi \\cdot WW \\psi = 0")]]



#text(" for ")#mi("{W \\in \\{X, Y \\}}")#text(". Because this system is zeroth order in ")#mi("{\\phi}")#text(", this can easily be done by linear algebra (even in the presence of a forcing term ")#mi("{B(\\phi,\\psi)=F}")#text(") if one imposes a “freeness” condition (analogous to the notion of a free embedding in the isometric embedding problem) that ")#mi("{X \\psi(p), Y \\psi(p), XX \\psi(p), YY \\psi(p)}")#text(" are linearly independent at each point ")#mi("{p}")#text(", which (together with some other technical conditions of a similar nature) one then adds to the list of upper and lower bounds required on ")#mi("{\\psi}")#text(" (with a related bound then imposed on ")#mi("{\\phi}")#text(", in order to close the iteration). However, as mentioned previously, there is a “loss of derivatives” problem with this construction: due to the presence of the differential operators ")#mi("{W}")#text(" in ")#link(<tao-cc9e80c60a47c8de9a2b>)[#text("(3)")]#text(", a solution ")#mi("{\\phi}")#text(" constructed by this method can only be expected to have two degrees less regularity than ")#mi("{\\psi}")#text(" at best, which makes this construction unsuitable for iteration.")

#text("To get around this obstacle (which also prominently appears when solving (linearisations of) the isometric embedding equation ")#mi("{Q(\\phi,\\phi)=g}")#text("), we instead first construct a smooth, low-frequency solution ")#mi("{\\phi_{\\leq N_0} \\colon H \\rightarrow {\\bf R}^{D}}")#text(" to a low-frequency equation ")#metadata(none) <tao-962f7c7aef93f6e82579>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("B( \\phi_{\\leq N_0}, P_{\\leq N_0} \\psi ) = 0")]]



#text(" where ")#mi("{P_{\\leq N_0} \\psi}")#text(" is a mollification of ")#mi("{\\psi}")#text(" (of Littlewood-Paley type) applied at a small spatial scale ")#mi("{1/N_0}")#text(" for some ")#mi("{N_0}")#text(", and then gradually relax the frequency cutoff ")#mi("{P_{\\leq N_0}}")#text(" to deform this low frequency solution ")#mi("{\\phi_{\\leq N_0}}")#text(" to a solution ")#mi("{\\phi}")#text(" of the actual equation ")#link(<tao-bbc7250080821c5b268b>)[#text("(1)")]#text(".")

#text("We will construct the low-frequency solution ")#mi("{\\phi_{\\leq N_0}}")#text(" rather explicitly, using the Whitney embedding theorem to construct an initial oscillating map ")#mi("{f}")#text(" into a very low dimensional space ")#mi("{{\\bf R}^6}")#text(", composing it with a Veronese type embedding into a slightly larger dimensional space ")#mi("{{\\bf R}^{27}}")#text(" to obtain a required “freeness” property, and then composing further with a slowly varying isometry ")#mi("{U(p) \\colon {\\bf R}^{27} \\rightarrow {\\bf R}^{36}}")#text(" depending on ")#mi("{P_{\\leq N_0}}")#text(" and constructed by a quantitative topological lemma (relying ultimately on the vanishing of the first few homotopy groups of high-dimensional spheres), in order to obtain the required orthogonality ")#link(<tao-962f7c7aef93f6e82579>)[#text("(4)")]#text(". (This sort of “quantitative null-homotopy” was first proposed ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1660471")[#text("by Gromov")]#text(", with some recent progress on optimal bounds ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3816519")[#text("by Chambers-Manin-Weinberger")]#text(" and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3836564")[#text("by Chambers-Dotterer-Manin-Weinberger")]#text(", but we will not need these more advanced results here, as one can rely on the classical qualitative vanishing ")#mi("{\\pi^k(S^d)=0}")#text(" for ")#mi("{k < d}")#text(" together with a compactness argument to obtain (ineffective) quantitative bounds, which suffice for this application).")

#text("To perform the deformation of ")#mi("{\\phi_{\\leq N_0}}")#text(" into ")#mi("{\\phi}")#text(", we must solve what is essentially the linearised equation ")#metadata(none) <tao-99ff69b1974510f8d60e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("B( \\dot \\phi, \\psi ) + B( \\phi, \\dot \\psi ) = 0")]]



#text(" of ")#link(<tao-bbc7250080821c5b268b>)[#text("(1)")]#text(" when ")#mi("{\\phi}")#text(", ")#mi("{\\psi}")#text(" (viewed as low frequency functions) are both being deformed at some rates ")#mi("{\\dot \\phi, \\dot \\psi}")#text(" (which should be viewed as high frequency functions). To avoid losing derivatives, the magnitude of the deformation ")#mi("{\\dot \\phi}")#text(" in ")#mi("{\\phi}")#text(" should not be significantly greater than the magnitude of the deformation ")#mi("{\\dot \\psi}")#text(" in ")#mi("{\\psi}")#text(", when measured in the same function space norms.")

#text("As before, if one directly solves the difference equation ")#link(<tao-99ff69b1974510f8d60e>)[#text("(5)")]#text(" using a naive application of ")#link(<tao-4cf1e7c350e20e009299>)[#text("(2)")]#text(" with ")#mi("{B(\\phi,\\dot \\psi)}")#text(" treated as a forcing term, one will lose at least one derivative of regularity when passing from ")#mi("{\\dot \\psi}")#text(" to ")#mi("{\\dot \\phi}")#text(". However, observe that ")#link(<tao-4cf1e7c350e20e009299>)[#text("(2)")]#text(" (and the symmetry ")#mi("{B(\\phi, \\dot \\psi) = B(\\dot \\psi,\\phi)}")#text(") can be used to obtain the identity ")#metadata(none) <tao-11d4373668b983189ef1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("B( \\dot \\phi, \\psi ) + B( \\phi, \\dot \\psi ) = \\left( W(\\dot \\phi \\cdot W \\psi + \\dot \\psi \\cdot W \\phi) - (\\dot \\phi \\cdot WW \\psi + \\dot \\psi \\cdot WW \\phi)\\right)_{W = X,Y}")]]



#text(" and then one can solve ")#link(<tao-99ff69b1974510f8d60e>)[#text("(5)")]#text(" by solving the system of equations")

#align(center)[#tao-fit-display[#mitex("\\dot \\phi \\cdot W \\psi = - \\dot \\psi \\cdot W \\phi")]]

#text("for ")#mi("{W \\in \\{X,XX,Y,YY\\}}")#text(". The key point here is that this system is zeroth order in both ")#mi("{\\dot \\phi}")#text(" and ")#mi("{\\dot \\psi}")#text(", so one can solve this system without losing any derivatives when passing from ")#mi("{\\dot \\psi}")#text(" to ")#mi("{\\dot \\phi}")#text("; compare this situation with that of the superficially similar system")

#align(center)[#tao-fit-display[#mitex("\\dot \\phi \\cdot W \\psi = - \\phi \\cdot W \\dot \\psi")]]

#text("that one would obtain from naively linearising ")#link(<tao-cc9e80c60a47c8de9a2b>)[#text("(3)")]#text(" without exploiting the symmetry of ")#mi("{B}")#text(". There is still however one residual “loss of derivatives” problem arising from the presence of a differential operator ")#mi("{W}")#text(" on the ")#mi("{\\phi}")#text(" term, which prevents one from directly evolving this iteration scheme in time without losing regularity in ")#mi("{\\phi}")#text(". It is here that we borrow the final key idea of the Nash-Moser scheme, which is to replace ")#mi("{\\phi}")#text(" by a mollified version ")#mi("{P_{\\leq N} \\phi}")#text(" of itself (where the projection ")#mi("{P_{\\leq N}}")#text(" depends on the time parameter). This creates an error term in ")#link(<tao-99ff69b1974510f8d60e>)[#text("(5)")]#text(", but it turns out that this error term is quite small and smooth (being a “high-high paraproduct” of ")#mi("{\\nabla \\phi}")#text(" and ")#mi("{\\nabla\\psi}")#text(", it ends up being far more regular than either ")#mi("{\\phi}")#text(" or ")#mi("{\\psi}")#text(", even with the presence of the derivatives) and can be iterated away provided that the initial frequency cutoff ")#mi("{N_0}")#text(" is large and the function ")#mi("{\\psi}")#text(" has a fairly high (but finite) amount of regularity (we will eventually use the Hölder space ")#mi("{C^{20,\\alpha}}")#text(" on the Heisenberg group to measure this).")

#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ddfdb66f4a959b8a74e6c9cc558c499ef652ebaf456d60cc4478166433cfd00f-f917906bb5e5c012f2f6a42675d8d41576ff37dc8fc5feb959258524b3f6116a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of terryx6")]], [#link("https://terrytao.wordpress.com/2018/11/26/embedding-the-heisenberg-group-into-a-bounded-dimensional-euclidean-space-with-optimal-distortion/#comment-507787")[#strong[#text("terryx6")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2018")])]

#text("Master Tao，I am a Chinese college’s freshman·And i am a philomath.I have a problem to ask you.Can you tell me the limitation of this formula？lim（n→+∞）∑sinnx／[n（n＋sinnx）]，n start form2.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fc9ca25686dd903e99a56114e02849b3373e7a4ccfd2e33222cc1bc8546a981-2a48592bb49424d613684353f98792acf20924eb19bf5b2a19391aa0689e0171.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathisgood")]], [#link("https://terrytao.wordpress.com/2018/11/26/embedding-the-heisenberg-group-into-a-bounded-dimensional-euclidean-space-with-optimal-distortion/#comment-507797")[#strong[#text("mathisgood")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2018")])]

#text("Please stop doing this. This is not a place to ask your homework.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ano")]], [#link("https://terrytao.wordpress.com/2018/11/26/embedding-the-heisenberg-group-into-a-bounded-dimensional-euclidean-space-with-optimal-distortion/#comment-507873")[#strong[#text("Ano")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2018")])]

#text("Dr. Tao do you see any relation between")#linebreak()#text(" ")#link("https://en.m.wikipedia.org/wiki/Collatz_conjecture#Syracuse_function")[#text("https://en.m.wikipedia.org/wiki/Collatz_conjecture#Syracuse_function")]#linebreak()#text(" and C^-12 M^2 ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/596a5ce6c3aa843bd676512c7e18a71cf316763eaf8ce4e7797d3fc6a67a8c82-6071fd7255dc2dc3cfe34b4717111edc63fc626958a8ddb601d254afd37d4023.gif", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Mina")]], [#link("https://terrytao.wordpress.com/2018/11/26/embedding-the-heisenberg-group-into-a-bounded-dimensional-euclidean-space-with-optimal-distortion/#comment-507942")[#strong[#text("Paul Mina")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2018")])]

#text("Maths attempts to model the the limitless but imposing constraints.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/11/26/embedding-the-heisenberg-group-into-a-bounded-dimensional-euclidean-space-with-optimal-distortion/#comment-507945")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2018")])]

#text("Well,ProTao is consider as a great master artist who draws a picture with many lines cross and down.Initially,you cannot understand what he is drawing.This is Pro.Tao’s special working style that is not seen by any other mathematician.The final result is very amzing .So, he will not answer your question.Gradually,you will see a clear picture that appears before you someday in near future.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/11/26/embedding-the-heisenberg-group-into-a-bounded-dimensional-euclidean-space-with-optimal-distortion/#comment-508033")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2018")])]

#text("Should it be 0 < epsilon < 1/2 in the main theorem? Otherwise the Hausdorff dimension increases without bound.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/11/26/embedding-the-heisenberg-group-into-a-bounded-dimensional-euclidean-space-with-optimal-distortion/#comment-508097")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2018")])]

#text("Ah, you’re right, I had not carefully analysed the situation with ")#mi("\\varepsilon")#text(" close to 1. This will be corrected in the next revision of the ms.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/11/26/embedding-the-heisenberg-group-into-a-bounded-dimensional-euclidean-space-with-optimal-distortion/#comment-508106")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2018")])]

#text("No problem. And just to point out, the paragraph beginning “On the other hand, if one…” is correct with 0 < epsilon < 1. The only issue is the bound on the target dimension, which necessarily goes to infinity as epsilon goes to 1.")

#emph[#text("[Paragraph updated, thanks -T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2018/11/26/embedding-the-heisenberg-group-into-a-bounded-dimensional-euclidean-space-with-optimal-distortion/#comment-508345")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2018")])]

#text("The paper “Fourier uniformity of bounded multiplicative functions in short intervals on average” sounds highly interesting, will there be a more overview blog post on it? Would be great")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a1adb9d4c785f9eb998fb7b772369e568171e5c3c19a8dec4a45fd2bc0ce79fa-159d68e156aaca8a0b074a8fea3b132f6a20cc8cb56c4b4b639df2e5007e504d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alexanderklotz")]], [#link("https://terrytao.wordpress.com/2018/11/26/embedding-the-heisenberg-group-into-a-bounded-dimensional-euclidean-space-with-optimal-distortion/#comment-509848")[#strong[#text("alexanderklotz")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#text("I am curious as to your reasoning for submitting paper to a regional journal that does not correspond to your region. Is that journal known for significant papers in this field?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/070b691e65ae1f2ad230cb2f13a4d46b2390c6957c8556fa1d53553131c0b159-06105701f8de8b2b41098a6f9b6988a3dbf1bbb6c15624de403dbe30af8cd787.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/11/26/embedding-the-heisenberg-group-into-a-bounded-dimensional-euclidean-space-with-optimal-distortion/#comment-509854")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#text("The Naor–Neiman paper referenced in the blog was published in Revista. The question that Tao’s paper answers originates in the Naor-Neiman paper.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2018/11/26/embedding-the-heisenberg-group-into-a-bounded-dimensional-euclidean-space-with-optimal-distortion/#comment-607447")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2020")])]

#text("Should there be a factor of ")#mi("2^{-\\varepsilon k}")#text(" in the LHS of both of the following lines?")

#tao-math("\\displaystyle \\left|\\phi_k(x) - \\phi_k(y)\\right| \\lesssim d_{\\bf R}(x,y)^{(1-\\varepsilon)} \\min( 2^{-(1-\\varepsilon) (k_0-k)}, 2^{-\\varepsilon (k-k_0)} )", block: false)

#tao-math("\\displaystyle \\left|\\phi_{k_0}(x) - \\phi_{k_0}(y)\\right| \\gtrsim d_{\\bf R}(x,y)^{(1-\\varepsilon)}", block: false)

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2018/11/26/embedding-the-heisenberg-group-into-a-bounded-dimensional-euclidean-space-with-optimal-distortion/#comment-608723")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2020")])]

#text("Now it says “formula does not parse”")

#emph[#text("[Corrected, thanks -T.]")]
]
]
