// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/10/05/unipotent-elements-of-the-lorentz-group-and-conic-sections/
// Converted to Typst by tao2typ: "2026-10-14T06:52:50.741989+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Unipotent elements of the Lorentz group, and conic sections", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Unipotent elements of the Lorentz group, and conic sections")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 October 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/10/05/unipotent-elements-of-the-lorentz-group-and-conic-sections/")[#text("https://terrytao.wordpress.com/2007/10/05/unipotent-elements-of-the-lorentz-group-and-conic-sections/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In my discussion of the ")#link("http://en.wikipedia.org/wiki/Oppenheim_conjecture")[#text("Oppenheim conjecture")]#text(" in ")#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/")[#text("my recent post on Ratner’s theorems")]#text(", I mentioned in passing the simple but crucial fact that the (")#link("http://en.wikipedia.org/wiki/Lorentz_group#Connected_components")[#text("orthochronous")]#text(") ")#link("http://en.wikipedia.org/wiki/Special_orthogonal_group")[#text("special orthogonal group")]#text(" ")#mi("SO(Q)^+")#text(" of an ")#link("http://en.wikipedia.org/wiki/Definite_bilinear_form")[#text("indefinite quadratic form")]#text(" on ")#mi("{\\Bbb R}^3")#text(" can be generated by ")#link("http://en.wikipedia.org/wiki/Unipotent")[#text("unipotent")]#text(" elements. This is not a difficult fact to prove, as one can simply diagonalise Q and then explicitly write down some unipotent elements (the magic words here are “")#link("http://en.wikipedia.org/wiki/Lorentz_group#Conjugacy_classes")[#text("null rotations")]#text("“). But this is a purely algebraic approach; I thought it would also be instructive to show the ")#emph[#text("geometric")]#text(" (or ")#emph[#text("dynamic")]#text(") reason for why unipotent elements appear in the orthogonal group of indefinite quadratic forms in three dimensions. (I’ll give away the punch line right away: it’s because the parabola is a ")#link("http://en.wikipedia.org/wiki/Conic_section")[#text("conic section")]#text(".) This is not a particularly deep or significant observation, and will not be surprising to the experts, but I would like to record it anyway, as it allows me to review some useful bits and pieces of elementary linear algebra.")

#metadata(none) <tao-8f8fa7958fe6f8a0a7e3>

#heading(level: 1)[#text("— Unipotent matrices —")]

#text("Before we get to unipotent elements of a group, let us first understand geometrically what a unipotent matrix (or linear transformation) A is. Suppose we consider an orbit ")#mi("x_n = A^n x")#text(" of some initial vector x with respect to this transformation A (thus ")#mi("x_n")#text(" is a linear recurrence sequence). How does ")#mi("x_n")#text(" behave geometrically as ")#mi("n \\to \\infty")#text("?")

#text("Despite the simple and explicit description ")#mi("x_n = A^n x")#text(" of the orbit, the geometric behaviour can be rather complicated, depending crucially on the spectrum of A (and, to a lesser extent, on the choice of ")#mi("x")#text("). If for instance A has an eigenvalue ")#mi("\\lambda")#text(" with ")#mi("\\lambda > 1")#text(", and ")#mi("x")#text(" is an eigenvector of A with eigenvalue ")#mi("\\lambda")#text(", then we will of course have ")#mi("x_n = \\lambda^n x_0")#text(", thus this orbit will grow exponentially. Similarly, if one has an eigenvalue between 0 and 1, then it is possible for the orbit to decay exponentially.")

#text("If one has eigenvalues with a complex phase, one can have oscillation. If for instance A is the rotation matrix ")#mi("A = R_\\theta := \\begin{pmatrix} \\cos \\theta & -\\sin \\theta \\\\ \\sin \\theta & \\cos \\theta \\end{pmatrix}")#text(" corresponding to anticlockwise rotation around the origin by some non-trivial angle ")#mi("\\theta")#text(" (and which has complex eigenvalues ")#mi("e^{i\\theta}")#text(" and ")#mi("e^{-i\\theta}")#text("), and (say) ")#mi("x_0 = \\begin{pmatrix} 1 \\\\ 0 \\end{pmatrix}")#text(", then the orbit ")#mi("x_n = \\begin{pmatrix} \\cos n \\theta \\\\ \\sin n\\theta \\end{pmatrix}")#text(" will oscillate around the unit circle indefinitely.")

#text("If an eigenvalue has non-trivial magnitude ")#emph[#text("and")]#text(" non-trivial phase, one gets a combination of exponential growth or decay and oscillation, leading for instance to orbits which follow a ")#link("http://en.wikipedia.org/wiki/Logarithmic_spiral")[#text("logarithmic spiral")]#text(" (this will be the case for instance if ")#mi("A = \\lambda R_\\theta")#text(" for some rotation matrix ")#mi("R_\\theta")#text(" and some dilation factor ")#mi("\\lambda > 0")#text(").")

#text("One can have even more complicated behaviour if there are multiple eigenvalues in play. Consider for instance the matrix ")#mi("A := \\begin{pmatrix} \\lambda & 0 \\\\ 0 & 1/\\lambda \\end{pmatrix}")#text(" with ")#mi("\\lambda > 1")#text(", with the initial vector ")#mi("x := \\begin{pmatrix} y \\\\ z \\end{pmatrix}")#text(" with both ")#mi("y")#text(" and ")#mi("z")#text(" non-zero (so that x has a non-trivial presence in both the unstable and stable modes of A). Then the orbit ")#mi("x_n = \\begin{pmatrix} \\lambda^n y \\\\ \\lambda^{-n} z\\end{pmatrix}")#text(" will expand exponentially in the unstable mode and contract exponentially in the stable mode, and the orbit will lie along the rectangular hyperbola ")#mi("\\{ \\begin{pmatrix} a \\\\ b \\end{pmatrix}: ab = yz \\}")#text(".")

#text("As the above examples show, orbits of linear transformations can exhibit a variety of behaviours, from exponential growth to exponential decay to oscillation to some combination of all three. But there is one special case in which the behaviour is much simpler, namely that the orbit remains polynomial. This occurs when A is a ")#link("http://en.wikipedia.org/wiki/Unipotent")[#text("unipotent")]#text(" matrix, i.e. A = I + N where N is ")#link("http://en.wikipedia.org/wiki/Nilpotent_element")[#text("nilpotent")]#text(" (i.e. ")#mi("N^m=0")#text(" for some finite m). A typical example of a unipotent matrix is")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("A = \\begin{pmatrix} 1 & 1 & 0 \\\\ 0 & 1 & 1 \\\\ 0 & 0 & 1 \\end{pmatrix}")]]

#text("(and indeed, by the ")#link("http://en.wikipedia.org/wiki/Jordan_canonical_form")[#text("Jordan canonical form")]#text(", all unipotent matrices are similar to direct sums of matrices of this type). For unipotent matrices, the binomial formula terminates after m terms to obtain a polynomial expansion for ")#mi("A^n")#text(":")

#tao-aligned(keep: true)[


#tao-math("A^n  & = (I + N)^n", block: true)



#tao-math(" & = I + n N + \\frac{n(n-1)}{2} N^2 + \\ldots + \\frac{n \\ldots (n-m+2)}{(m-1)!} N^{m-1}.", block: true)
]

#text("From this we easily see that, regardless of the choice of initial vector x, the coefficients of ")#mi("x_n")#text(" are polynomial in n. (Conversely, if the coefficients of ")#mi("x_n")#text(" are polynomial in n for every x, it is not hard to show that A is unipotent; I’ll leave this as an exercise.) It is instructive to see what is going on at the coefficient level, using the matrix (1) as an example. If we express the orbit ")#mi("x_n")#text(" in coordinates as ")#mi("x_n = \\begin{pmatrix} a_n \\\\ b_n \\\\ c_n \\end{pmatrix}")#text(", then the recurrence ")#mi("x_{n+1} = A x_n")#text(" becomes")

#tao-aligned(keep: true)[


#tao-math("a_{n+1}  & = a_n + b_n", block: true)



#tao-math("b_{n+1}  & = b_n + c_n", block: true)
]

#align(center)[#mi("c_{n+1} = c_n")#text(".")]

#text("We thus see that the sequence ")#mi("c_n")#text(" is constant, the sequence ")#mi("b_n")#text(" grows linearly, and ")#mi("a_n")#text(" grows quadratically, so the whole orbit ")#mi("x_n")#text(" has polynomial coefficients. If one views the recurrence ")#mi("x_{n+1} = A x_n")#text(" as a dynamical system, the polynomial nature of the dynamics are caused by the absence of (both positive and negative) ")#link("http://en.wikipedia.org/wiki/Feedback_loop")[#text("feedback loops")]#text(": c affects b, and b affects a, but there is no loop in which a component ultimately affects itself, which is the source of exponential growth, exponential decay, and oscillation. Indeed, one can view this absence of feedback loops as a ")#emph[#text("definition")]#text(" of unipotence.")

#text("For the purposes of proving a dynamical theorem such as Ratner’s theorem, unipotence is important for several reasons. The lack of exponential growing modes means that the dynamics is not exponentially unstable going forward in time; similarly, the lack of exponentially decaying modes means that the dynamics is not exponentially unstable going backward in time. The lack of oscillation does not improve the stability further, but it does have an important effect on the ")#emph[#text("smoothness ")]#text("of the dynamics. Indeed, because of this lack of oscillation, orbits which are polynomial in nature obey an important dichotomy: either they go to infinity, or they are constant. There is a quantitative version of this statement, known as ")#link("http://en.wikipedia.org/wiki/Bernstein%27s_inequality_%28mathematical_analysis%29")[#text("Bernstein’s inequality")]#text(": if a polynomial remains bounded over a long interval, then its derivative is necessarily small. (From a Fourier-analytic perspective, being polynomial with low degree is analogous to being “low frequency”; the Fourier-analytic counterpart of Bernstein’s inequality is closely related to the Sobolev inequality, and is extremely useful in PDE. But I digress.) These facts seem to play a fundamental role in all arguments that yield Ratner-type theorems.")

#heading(level: 1)[#text("— Unipotent actions —")]

#text("Now that we understand unipotent matrices, let us now understand what it means for the action ")#mi("g: x \\mapsto gx")#text(" of a group element ")#mi("g \\in G")#text(" on a homogeneous space ")#mi("G/\\Gamma")#text(" to be unipotent. By definition, this means that the adjoint action ")#mi("g: X \\mapsto g X g^{-1}")#text(" on the Lie algebra ")#mi("{\\mathfrak g}")#text(" of G is unipotent. By the above discussion, this is the same as saying that the orbit ")#mi("(g^n X g^{-n})_{n \\in {\\Bbb Z}}")#text(" always behaves polynomially in n.")

#text("This statement can be interpreted via the dynamics on the homogeneous space ")#mi("G/\\Gamma")#text(". Consider a point ")#mi("x \\in G/\\Gamma")#text(", and look at the orbit ")#mi("(g^n x)_{n \\in {\\Bbb Z}}")#text(". Now let us perturb x infinitesimally in the direction of some Lie algebra element X to create a new point ")#mi("x_\\epsilon := (1 + \\epsilon X) x")#text(", where one should think of ")#mi("\\epsilon")#text(" as being infinitesimally small (or alternatively, one can insert errors of ")#mi("O(\\epsilon^2)")#text(" all over the place). Then the perturbed orbit ")#mi("g^n x_\\epsilon")#text(" at time n is located at")

#align(center)[#mi("\\displaystyle g^n (1 + \\epsilon X) x = (1 + \\epsilon g^n X g^{-n}) g^n x")#text(".")]

#text("If g is unipotent, we thus see that the two orbits ")#mi("(g^n x)_{n \\in {\\Bbb Z}}")#text(" and ")#mi("(g^n x_\\epsilon)_{n \\in {\\Bbb Z}}")#text(" only diverge polynomially in n, without any oscillation. In particular, we have the dichotomy that two orbits either diverge, or are translates of each other, together with Bernstein-like quantitative formulations of this dichotomy. This dichotomy is a crucial component in the proof of Ratner’s theorem, and explains why we need the group action to be generated by unipotent elements.")

#heading(level: 1)[#text("— Elliptic, parabolic, and hyperbolic elements of ")#mi("SL_2({\\Bbb R})")#text(" —")]

#text("I have described the distinction between exponential growth/decay, oscillation, and unipotent (polynomial) behaviour. This distinction is particularly easy to visualise geometrically in the context of actions of ")#mi("SL(2,{\\Bbb R})")#text(" on the (affine) plane. Specifically, let us consider an affine linear recurrence sequence")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("x_{n+1} := A x_n + b; \\quad x_0 := x")]]

#text("where ")#mi("x \\in {\\Bbb R}^2")#text(" is an element of the plane, ")#mi("A \\in SL(2,{\\Bbb R})")#text(" is a special linear transformation (i.e. a ")#mi("2 \\times 2")#text(" matrix of determinant 1), and ")#mi("b \\in {\\Bbb R}^2")#text(" is a shift vector. If ")#mi("A-I")#text(" is invertible, one can eliminate the shift b by translating the orbit ")#mi("x_n")#text(", or more specifically making the substitution")

#align(center)[#tao-fit-display[#mitex("y_n := x_n + (A-I)^{-1} b")]]

#text("which simplifies (2) to")

#align(center)[#tao-fit-display[#mitex("y_{n+1} := A y_n; \\quad y_0 := x + (A-I)^{-1} b")]]

#text("which allows us to solve for the orbit ")#mi("x_n")#text(" explicitly as")

#align(center)[#tao-fit-display[#mitex("x_n = A^n (x + (A-I)^{-1} b) - (A-I)^{-1} b.")]]

#text("Of course, we have to analyse things a little differently in the degenerate case that ")#mi("A-I")#text(" is not invertible, in particular the lower order term b plays a more significant role in this case. Leaving that case aside for the moment, we see from the above formula that the behaviour of the orbit ")#mi("x_n")#text(" is going to be largely controlled by the spectrum of A. In this case, A will have two (generalised) eigenvalues ")#mi("\\lambda, 1/\\lambda")#text(" whose product is 1 (since ")#mi("\\det(A)=1")#text(") and whose sum is real (since A clearly has real trace). This gives three possibilities:")

#enum(start: 1, 
[#strong[#text("Elliptic case")]#text(". Here ")#mi("\\lambda = e^{i\\theta}")#text(" is a non-trivial unit phase. Then A is similar (after a real linear transformation) to the rotation matrix ")#mi("R_\\theta")#text(" described earlier, and so the orbit ")#mi("x_n")#text(" lies along a linear transform of a circle, i.e. the orbit lies along an ellipse.")],
[#strong[#text("Hyperbolic case")]#text(". Here ")#mi("\\lambda")#text(" is real with ")#tao-math("\\left|\\lambda\\right| > 1", block: false)#text(" or ")#tao-math("0 < \\left|\\lambda\\right| < 1", block: false)#text(". In this case A is similar to the diagonal matrix ")#mi("\\begin{pmatrix} \\lambda & 0 \\\\ 0 & 1/\\lambda \\end{pmatrix}")#text(", and so by previous discussion we see that the orbit ")#mi("x_n")#text(" lies along a linear transform of a rectangular hyperbola, i.e. the orbit lies along a general hyperbola.")],
[#strong[#text("Parabolic case")]#text(". This is the boundary case between the elliptic and hyperbolic cases, in which ")#mi("\\lambda = 1")#text(". Then either A is the identity (in which case ")#mi("x_n")#text(" travels along a line, or is constant), or else (by the Jordan canonical form) A is similar to the matrix ")#mi("\\begin{pmatrix} 1 & 1 \\\\ 0 & 1 \\end{pmatrix}")#text(". Applying a linear change of coordinates, we thus see that the affine recurrence ")#mi("x_{n+1} = A x_n + b")#text(" is equivalent to the ")#mi("2 \\times 2")#text(" system")

#align(center)[#mi("y_{n+1} = y_n + z_n + c")#linebreak()#text(" ")#mi("z_{n+1} = z_n + d")]

#text("for some real constants c, d and some real sequences ")#mi("y_n, z_n")#text(". If c, d are non-zero, we see that ")#mi("z_n")#text(" varies linearly in n and ")#mi("y_n")#text(" varies quadratically in n, and so ")#mi("(y_n,z_n)")#text(" lives on a parabola. Undoing the linear change of coordinates, we thus see in this case that the original orbit ")#mi("x_n")#text(" also lies along a parabola. (If c or d vanish, the orbit lies instead on a line.)")]
)

#text("Thus we see that all elements of ")#mi("SL(2,{\\Bbb R})")#text(" preserve some sort of conic section. The elliptic elements trap their orbits along ellipses, the hyperbolic elements trap their orbits along hyperbolae, and the parabolic elements trap their orbits along parabolae (or along lines, in some degenerate cases). The elliptic elements thus generate oscillation, the hyperbolic elements generate exponential growth and decay, and the parabolic elements are unipotent and generate polynomial growth. (If one interprets elements of ")#mi("SL(2,{\\Bbb R})")#text(" as area-preserving linear or affine transformations, then elliptic elements are rotations around some origin (and in some coordinate system), hyperbolic elements are compressions along one axis and dilations along another, and parabolic elements are shear transformations and translations.)")

#text("[It is curious that every element of ")#mi("SL(2,{\\Bbb R})")#text(" preserves at least one non-trivial quadratic form; this statement is highly false in higher dimensions (consider for instance what happens to diagonal matrices). I don’t have a “natural” explanation of this fact – some sort of fixed point theorem at work, perhaps? I can cobble together a proof using the observations that (a) every matrix in ")#mi("SL(2,{\\Bbb R})")#text(" is similar to its inverse, (b) the space of quadratic forms on ")#mi("{\\Bbb R}^2")#text(" is odd-dimensional, (c) any linear transformation on an odd-dimensional vector space which is similar to its inverse has at least one eigenvalue equal to ")#mi("\\pm 1")#text(", (d) the action of a non-degenerate linear transformation on quadratic forms preserves positive definiteness, and thus cannot have negative eigenvalues, but this argument seems rather ")#emph[#text("ad hoc")]#text(" to me.]")

#text("One can view the parabolic elements of ")#mi("SL(2,{\\Bbb R)}")#text(" as the limit of elliptic or hyperbolic ones in a number of ways. For instance, the matrix ")#mi("\\begin{pmatrix} 1 & 1 \\\\ \\epsilon & 1 \\end{pmatrix}")#text(" is hyperbolic when ")#mi("\\epsilon > 0")#text(", parabolic when ")#mi("\\epsilon = 0")#text(", and elliptic when ")#mi("\\epsilon < 0")#text(". This is related to how the hyperbola, parabola, and ellipse emerge as sections of the light cone. Another way to obtain the parabola a limit is to view that parabola as an infinitely large ellipse (or hyperbola), with centre infinitely far away. For instance, the ellipse of vertical radius R and horizontal radius ")#mi("\\sqrt{R}")#text(" centred at (0,R) is given by the equation ")#mi("\\frac{x^2}{R} + \\frac{(y-R)^2}{R^2} = 1")#text(", which can be rearranged as ")#mi("y = \\frac{1}{2} x^2 + \\frac{1}{2R} y^2")#text(". In the limit ")#mi("R \\to \\infty")#text(", this ellipse becomes the parabola ")#mi("y = \\frac{1}{2} x^2")#text(", and rotations associated with those ellipses can converge to parabolic affine maps of the type described above. A similar construction allows one to view the parabola as a limit of hyperbolae; incidentally, one can use (the Fourier transform of) this limit to show (formally, at least) that the ")#link("http://en.wikipedia.org/wiki/Schr%C3%B6dinger_equation")[#text("Schrödinger equation")]#text(" emerges as the ")#link("http://tosio.math.toronto.edu/wiki/index.php/Non-relativistic_limit")[#text("non-relativistic limit")]#text(" of the ")#link("http://en.wikipedia.org/wiki/Klein-Gordon_equation")[#text("Klein-Gordon equation")]#text(".")

#heading(level: 1)[#text("— The Lorentz group —")]

#text("Every non-degenerate quadratic form Q on d variables comes with its own symmetry group ")#mi("SO(Q) \\leq SL(d,{\\Bbb R})")#text(", defined as the group of special linear transformations which preserve Q. (Note that Q determines a translation-invariant ")#link("http://en.wikipedia.org/wiki/Pseudo-Riemannian_manifold")[#text("pseudo-Riemannian metric")]#text(", and thus a ")#link("http://en.wikipedia.org/wiki/Haar_measure")[#text("Haar measure")]#text("; so any transformation which preserves Q must be volume-preserving and thus have a determinant of ")#mi("\\pm 1")#text(". So the requirement that the linear transformation be special is not terribly onerous.) Equivalently, SO(Q) is the space of special linear transformations which preserve each of the level sets ")#mi("\\{ x \\in {\\Bbb R}^d: Q(x) = \\text{const} \\}")#text(" (which, by definition, is a ")#link("http://en.wikipedia.org/wiki/Quadric")[#text("quadric surface")]#text(").")

#text("A non-degenerate quadratic form can always be diagonalised (e.g. by applying the ")#link("http://en.wikipedia.org/wiki/Gram%E2%80%93Schmidt_process")[#text("Gram-Schmidt orthogonalisation process")]#text("), and so after a linear change of coordinates one can express Q as")

#align(center)[#tao-fit-display[#mitex("Q(x_1,\\ldots,x_d) = x_1^2 + \\ldots + x_r^2 - x_{r+1}^2 - \\ldots - x_d^2")]]

#text("for some ")#mi("0 \\leq r \\leq d")#text(". The pair ")#mi("(r,d-r)")#text(" is the signature of Q, and SO(Q) is isomorphic to the group SO(r,d-r). The signature is an invariant of Q; this is ")#link("http://en.wikipedia.org/wiki/Sylvester%27s_law_of_inertia")[#text("Sylvester’s law of inertia")]#text(".")

#text("In the Euclidean (i.e. definite) case r=d (or r=0), the level sets of Q are spheres (in diagonalised form) or ellipsoids (in general), and so the orbits of elements in ")#mi("SO(Q) \\cong SO(d)")#text(" stay trapped on spheres or ellipsoids. Thus their orbits cannot exhibit exponential growth or decay, or polynomial behaviour; they must instead oscillate, much like the elliptic elements of ")#mi("SL(2,{\\Bbb R})")#text(". In particular, SO(Q) does not contain any non-trivial unipotent elements.")

#text("In the indefinite case d=2, r=1, the level sets of Q are hyperbolae (as well as the light cone ")#mi("\\{ (x_1,x_2): x_1^2 - x_2^2 = 0 \\}")#text(", which in two dimensions is just a pair of intersecting lines). It is then geometrically clear that most elements of ")#mi("SO(Q) \\cong SO(1,1)")#text(" are going to be hyperbolic, as their orbits will typically escape to infinity along hyperbolae. (The only exceptions are the identity and the negative identity.) Elements of SO(1,1) are also known as ")#link("http://en.wikipedia.org/wiki/Lorentz_boost")[#text("Lorentz boosts")]#text(". (More generally, SO(d,1) (or SO(1,d)) is the structure group for ")#link("http://en.wikipedia.org/wiki/Special_relativity")[#text("special relativity ")]#text("in d-1 space and 1 time dimensions.)")

#text("Now we turn to the case of interest, namely d=3 and Q indefinite, thus r=1 or r=2. By changing the sign of Q if necessary we may take r=1, and after diagonalising we can write")

#align(center)[#tao-fit-display[#mitex("Q(x_1, x_2, x_3) = x_1^2 + x_2^2 - x_3^2.")]]

#text("The level sets of Q are mostly hyperboloids, together with the ")#link("http://en.wikipedia.org/wiki/Light_cone")[#text("light cone ")]#mi("\\{ (x_1,x_2,x_3): x_1^2 + x_2^2 - x_3^2 = 0 \\}")#text(". So a typical element of ")#mi("SO(Q) \\cong SO(2,1)")#text(" will have orbits that are trapped inside light cones or on hyperboloids.")

#text("In general, these orbits will wander in some complicated fashion over such a cone or hyperboloid. But for some special elements of SO(Q), the orbit is contained in a smaller variety. For instance, consider a Euclidean rotation around the ")#mi("x_3")#text(" axis by some angle ")#mi("\\theta")#text(". This clearly preserves Q, and the orbits of this rotation lie on horizontal circles, which are of course each contained in a hyperboloid or light cone. So we see that SO(Q) contains elliptical elements, and this is “because” we can get ellipses as sections of hyperboloids and cones, by slicing them with ")#link("http://en.wikipedia.org/wiki/Spacelike#Causal_structure")[#text("spacelike")]#text(" planes.")

#text("Similarly, if one considers a Lorentz boost in the ")#mi("x_1, x_2")#text(" directions, we also preserve Q, and the orbits of this rotation lie on vertical hyperbolae (or on a one-dimensional light cone). So we see that SO(Q) contains hyperbolic elements, which is “because” we can get hyperbolae as sections of hyperbolae and cones, by slicing them with ")#link("http://en.wikipedia.org/wiki/Spacelike#Causal_structure")[#text("timelike")]#text(" planes.")

#text("So, to get unipotent elements of SO(Q), it is clear what we should do: we should exploit the fact that ")#emph[#text("parabolae")]#text(" are also sections of hyperboloids and cones, obtained by slicing these surfaces along ")#link("http://en.wikipedia.org/wiki/Spacelike#Causal_structure")[#text("null")]#text(" planes. For instance, if we slice the hyperboloid ")#mi("\\{ (x_1,x_2,x_3): x_1^2 + x_2^2 - x_3^2 = 1\\}")#text(" with the null plane ")#mi("\\{ (x_1,x_2,x_3): x_3 = x_2 + 1 \\}")#text(" we obtain the parabola ")#mi("\\{ (x_1, x_3-1, x_3): 2x_3 = x_1^2 \\}")#text(". A small amount of calculation then lets us find a linear transformation which preserves both the hyperboloid and the null plane (and thus preserves Q and preserves the parabola); indeed, if we introduce null coordinates ")#mi("(y_1,y_2,y_3) := (x_1, x_3-x_2, x_3+x_2)")#text(", then the hyperboloid and null plane are given by the equations ")#mi("y_1^2 = y_2 y_3 + 1")#text(" and ")#mi("y_2 = 1")#text(" respectively; a little bit of algebra shows that the linear transformations ")#mi("(y_1,y_2,y_3) \\mapsto (y_1+ay_2, y_2, y_3 + 2a y_1 + a^2 y_2)")#text(" will preserve both surfaces for any constant a. This provides a one-parameter family (a parabolic subgroup, in fact) of unipotent elements (known as ")#link("http://en.wikipedia.org/wiki/Lorentz_group#Conjugacy_classes")[#text("null rotations")]#text(") in SO(Q). By rotating the null plane around we can get many such one-parameter families, whose orbits trace out all sorts of parabolae, and it is not too hard at this point to show that the unipotent elements can in fact be used to generate all of SO(Q) (or ")#mi("SO(Q)^+")#text(").")

#text("[Incidentally, the fact that the parabola is a section of a cone or hyperboloid of one higher dimension allows one (via the Fourier transform) to embed solutions to the free ")#link("http://en.wikipedia.org/wiki/Schrodinger_equation")[#text("Schrödinger equation")]#text(" as solutions to the ")#link("http://en.wikipedia.org/wiki/Wave_equation")[#text("wave")]#text(" or ")#link("http://en.wikipedia.org/wiki/Klein-Gordon_equation")[#text("Klein-Gordon equations")]#text(" of one higher dimension; this trick allows one, for instance, to derive the conservation laws of the former from those of the latter. See for instance Exercises 2.11, 3.2, and 3.30 of ")#link("http://www.math.ucla.edu/~tao/preprints/chapter.ps")[#text("my book on dispersive PDE")]#text(".]")

#text("[")#emph[#text("Update")]#text(", Oct 6: Typos corrected.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/10/05/unipotent-elements-of-the-lorentz-group-and-conic-sections/#comment-11230")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2007")])]

#text("A small typo: the matrix depending on ")#mi("\\epsilon")#text(" (before the section on Lorentz group) has a ")#mi("1")#text(" missing in the right-hand corner.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Attila Smith")]], [#link("https://terrytao.wordpress.com/2007/10/05/unipotent-elements-of-the-lorentz-group-and-conic-sections/#comment-11236")[#strong[#text("Attila Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2007")])]

#text("Dear Terence,")#linebreak()#text(" on line 14 of the first section (“Unipotent matrices”) when you define A=R_(theta), I think you might have to exchange the signs preceding the two occurrences of sin(theta) on the antidiagonal of your matrix.")

#text("Your devoted,")#linebreak()#text(" Attila")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/05/unipotent-elements-of-the-lorentz-group-and-conic-sections/#comment-11264")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2007")])]

#text("Thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/25bacd5741fc5cb19847fc0aa06b225e946cc6a7bbf940a2397878bf942001e7-6c6574c65aa5d617029be65573184a0a01f1aaa8380d7cf58cd0d30e3eb16c62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Genghis Khan")]], [#link("https://terrytao.wordpress.com/2007/10/05/unipotent-elements-of-the-lorentz-group-and-conic-sections/#comment-11419")[#strong[#text("Genghis Khan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2007")])]

#text("I envy you guys who can handle numbers and make them jump hoops. I can’t.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/38402dbc99ad5a6abbbb15d83072d4c4ad5f8871c79365e5bca94f6be40dfe7c-fc3ffed2abcbc47b701a1e75f11c27ad5bdce9e9db524f44370344e94faa6f2d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike R.")]], [#link("https://terrytao.wordpress.com/2007/10/05/unipotent-elements-of-the-lorentz-group-and-conic-sections/#comment-11431")[#strong[#text("Mike R.")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2007")])]

#text("Great article, Terence. Classifying orbits on homogeneous spaces (for G, an exceptional group) arises in the study of black holes in supergravity. This is one of the topics covered in Phys 261 this fall. The class starts this Thursday (Oct. 11th) in PAB 4-330. Feel free to stop by.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/10/05/unipotent-elements-of-the-lorentz-group-and-conic-sections/#comment-11451")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2007")])]

#text("Hi Terence,")

#text("Is there a PDF version of your book referenced above in the last sentence of your incidental note as: “my book on dispersive PDE.”?")

#text("I am not able to open a PS file.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/05/unipotent-elements-of-the-lorentz-group-and-conic-sections/#comment-11458")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2007")])]

#text("Dear Doug: The sample chapters are now in PDF format.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/10/05/unipotent-elements-of-the-lorentz-group-and-conic-sections/#comment-12248")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2007")])]

#text("I have noticed that some factors of the Monster [Borcherds] may be written in a [psuedo?]-unipotent format?")

#text("((19*3*2^5-1)*3^3*2^2)-1=")#linebreak()#text(" ((19*3*32)-1)*27*4)-1=")#linebreak()#text(" 196884-1=196883=(71*59*47)")#linebreak()#text(" =(72-1)*(60-1)*(48-1)")#linebreak()#text(" =(2^3*3^2-1)*(2^2*3*5-1)*(2^4*3-1)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4cf6003baa512435e75697928486e72bf10754d61ef249872d72461c5f7baf7-82d1ff5f5848e36b71848ca62dfba6a875506f2f284804551809ff9c2402e437.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dawes86")]], [#link("https://terrytao.wordpress.com/2007/10/05/unipotent-elements-of-the-lorentz-group-and-conic-sections/#comment-693483")[#strong[#text("dawes86")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2026")])]

#text("Re the ad hoc argument about every matrix in ")#mi("SL_2(\\mathbb{R})")#text(" preserving a quadratic form:")

#text("I think this can be thought about in the following way. By the very definition of ")#mi("SL_2")#text(", if one has an eigenvalue ")#mi("\\lambda")#text(" of some matrix ")#mi("A")#text(", then one must also have another eigenvalue ")#mi("\\lambda^{-1}")#text(", in order to preserve the area. In this case, the eigenvectors ")#mi("x,y")#text(", which may or may not be distinct, give an invariant monomial ")#mi("xy")#text(" which is invariant under ")#mi("A")#text(" and is a parabola if ")#mi("x=y")#text(", and a hyperbola if not. Thankfully, rotations are fundamentally 2 dimensional phenomena (every rotation can be decomposed into a product of invariant planes, which is the JNF over R), and so ellipses cover the last case.")

#text("Alternatively, every degree 2 polynomial over R, either has 2 conjugate complex roots, or 2 real roots with multiplicity. Being in ")#mi("SL_2(\\mathbb{R})")#text(" forces these to also satisfy ")#mi("\\lambda_1 \\lambda_2=1")#text(", which means that in the complex case, these lie on the unit circle. One can phrase this in some fixed point form: we have an operator ")#mi("T:SL_2(\\mathbb{R}) \\rightarrow End(QF(\\mathbb{R^2}))")#text(" where ")#mi("QF")#text(" is the space of quadratic forms on ")#mi("\\mathbb{R^2}")#text(", and ")#mi("T(A)=:T_A(S)=S \\circ A")#text(" for ")#mi("S\\in QF")#text(". Then every matrix ")#mi("A")#text(" preserves a quadratic form iff ")#mi("T_A")#text(" has eigenvalue $1$. Now a basis for ")#mi("QF(\\mathbb{R^2})")#text(" is ")#mi("\\{x^2,xy,y^2\\}")#text(", and there is some basis in which ")#mi("A")#text(" is upper triangular. Then one can calculate that the matrix for ")#mi("T_A")#text(" in this basis is lower triangular with diagonal ")#mi("\\{\\lambda_1^2, \\lambda_1 \\lambda_2, \\lambda_2^2\\}")#text(". The middle term is always 1, and so it has an eigenvalue equal to 1 i.e. it preserves a quadratic form.")

#text("I think this also shows why it fails in higher degrees, eg in ")#mi("SL_3(\\mathbb{R})")#text(": the monomials of quadratic forms over ")#mi("\\mathbb{R^3}")#text(" are still generated by the terms $\\lambda_i \\lambda_j$, and the condition of being in ")#mi("SL_3(\\mathbb{R})")#text(" just does not guarantee this. So it is in some sense the wrong question: ")#mi("SL_3(\\mathbb{R})")#text(" ")#strong[#text("does preserve")]#text(" cubic forms, which can be shown in the same way as above. Furthermore it will preserve a quadratic form iff there is pair of eigenvalues such that ")#mi("\\lambda_i \\lambda_j=1")#text(". And so on for higher dimensions.")

#text("Finally, if one finds the fact that the determinant is an n-form on ")#mi("\\mathbb{R^n}")#text(" particularly geometric, then they can quickly see that ")#mi("det(A(x_1,...x_n))=det(x_1,...,x_n)")#text(" for ")#mi("x_i \\in \\mathbb{R^n}")#text(". And so ")#mi("T_A(v)=det([v,Av,...,A^n v])")#text(" defines an ")#mi("n")#text("-form which is ")#mi("A")#text("-invariant since ")#mi("T_A(Av)=det([A(v),A(Av),...,A(A_n v)])=det([v,Av,...,A^n v])")#text(" by ")#mi("A")#text("-invariance of the determinant. This will be non-trivial for all ")#mi("A")#text(" not a direct sum of ")#mi("Id_1")#text(" and ")#mi("-Id_2")#text(". But these cases preserve many forms anyway. In the ")#mi("n=2")#text(" case, this of course specialises back down to quadratic forms and ")#mi("SL_2(\\mathbb{R})")#text(". Phrasing it this way might make it seem almost like a triviality, but I think the magic is hidden in the definitions.")
]
