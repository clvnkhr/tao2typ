// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/10/math-2-0/
// Converted to Typst by tao2typ: "2026-10-14T16:39:38.352976+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Math 2.0", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Math 2.0")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/")[#text("https://terrytao.wordpress.com/2026/10/10/math-2-0/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I am uploading ")#link("https://teorth.github.io/tao-web/slides/math-2-0-caltech-2026.pdf")[#text("my slides")]#text(" to my public lecture “")#link("https://www.caltech.edu/campus-life-events/calendar/aim-public-lecture-series-terence-tao-1")[#text("Math 2.0")]#text("” that I gave yesterday evening at Caltech. (The talk was planned over a year ago, and was initially titled “Machine Assisted Proof” and scheduled to be given back in May. It was postponed to October, and with recent events the talk changed significantly, but the old title and abstract remains on the Caltech web page.)")

#text("In this talk I lay out the historical “Math 1.0” state of mathematics, the current state induced by the excessive emphasis on automated solving of open problems by AI, and my vision for a future “Math 2.0” where AI tools are used to sustain both the internal mathematical community, and the role that mathematical understanding plays in advancing and aligning the applications of mathematics to the real world.")

#text("The content of this talk has also been incorporated into my (AI-maintained) ")#link("https://teorth.github.io/tao-web/ai-views.html")[#text("living summary of my views on AI")]#text(".")

#heading(level: 1)[#text("Comments (37)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d62fb603f6cc2d205ca3294d2a5307d786b92ca5619e3d56bb153ce585528d2f-4a8a74ac9b16ec3a2a3bd14d99d2deabe51395ea98621a7db6ec64132e879e58.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Amir")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697625")[#strong[#text("Amir")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("It seems that the talk was very futuristic as the first line of the abstract on the Caltech Web page reads: “For centuries, mathematicians have relied on computers to perform calculations, to suggest conjectures, and as components of mathematical proofs.” :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697664")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("Of course. This century and last century. (And even the previous century, using human computers; cf. Gauss.)")

#text("Gerhard Paseman")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d62fb603f6cc2d205ca3294d2a5307d786b92ca5619e3d56bb153ce585528d2f-4a8a74ac9b16ec3a2a3bd14d99d2deabe51395ea98621a7db6ec64132e879e58.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Amir")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697769")[#strong[#text("Amir")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("But, Gauss wasn’t a “component of mathematical proofs”. Or, was he? :)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a20370857706340174e00ff9ab35ba0b0ca913979425b78aac3c08c1994a6e7-c64e1407c76a5daf808dd72e9d51492476d49a432b36b7d2824b6dee6ccc7889.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elad")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697628")[#strong[#text("Elad")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("Thank you! I really enjoyed your talk. Do you have any thoughts about how to deal with the transition period where some may have “upgraded” to Math 2.0 while others are still in Math 1.0?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f807b434b4d668a43d819a32fa702feb6edf49fe4c663e3aef0e1bc00a55de7-b462adb84787087e30ef3a3677ee611ac4de7f393ac3c251fffa5126edf49b51.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Observer")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697630")[#strong[#text("Observer")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("Very nice. I think you do a good job of laying out how the field may retain some pleasure, but the bigger problem is to change the institutional culture immediately. People with influence in mathematics need to immediately disincentivize claiming mindless solutions to open problems in mathematics, by publicly naming and shaming those who do it. There has been much talk about rewarding understanding over being the first to post a proof of something, but frankly I think most of it is empty words until proven otherwise. Think of the graduate students and postdocs who do not have time to sit around and see what happens.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9aac05a558797d32c15f55d878a48d42da70b746702d86f0d119ed7c3d5d3f7-271938281befc09d4e62e209f9ef583576efda8ebe21909421f3a2ddbe083be5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Oliver")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697632")[#strong[#text("William Oliver")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("(")#emph[#text("I can be long winded, so there is a Tl;dr at the end")]#text(")")

#text("I very much like the concept of focusing on e.g. Open Exposition Problems in “Math 2.0”.")

#text("Personally, I have been very inspired by the original “Open Exposition Problem” introduced by Timothy Chow in “A Beginners Guide to Forcing”, and have been working to resolve it for many years (I started this project of really deeply understanding forcing back in 2024, and am finally now reaching a conclusion).")

#text("So here is my question:")

#text("I think there is currently a pressure for those like me (I work full time and go to school part time at an online university, without experts in the fields I self study) to engage in what might be considered ‘cranky’ behavior like cold emailing people or posting comments on blogs like this. I do not like this, and will admit that I think sometimes I engage in this behavior without being conscious of it, which I am not proud of. That said, its partially because there is no real formal means of review for these ‘softer’ aspects of mathematics, and there is a danger of making it so that only ‘well connected’ people have the possibility of really engaging with the field")

#text("(although I really want to emphasize that I like the direction of “math 2.0” overall)")

#strong[#text("Tl;dr")]

#text("Where would you have the wider community, outside of ‘top-tier’ schools, submit open exposition problem solutions for review?")

#text("If I had such a solution to an ‘open exposition problem’, I am not sure I would trust myself to get everything right and just post somewhere, and the previously mentioned avenues for this on this blog (")#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/")[#text("like the AIM repository")]#text(", or Mathathon) seem to be either specific to more concrete problems (e.g. that require fundamentally new solutions to some specified problem, outside of purely pedagogical innovations), or require traveling somewhere in person within a relatively small window of time (which I cannot easily do given my current situation) or otherwise be affiliated with some bigger institution already.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae8bcb3af5ceadff880e47341ff9ad566fd92937c5bfbbffe5efd47dc17ec292-cce0339f7cafb18ce59ed44ffaaa728f2a957b163be518f19e0121754e9baa1b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of joey.li")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697633")[#strong[#text("joey.li")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("I will just focus on the thought experiment slide about cancer.")

#text("There are several things wrong with the ideas presented in that slide that seem to stem from a basic misunderstanding of how biomedical research is different from mathematics.")

#text("First, it’s already the case today that medical treatments aren’t really “understood” by anyone, to varying degrees. A lot of medicines are discovered experimentally. Yes, we typically understand the mechanism at some level, but “mechanism” has many different meanings in biology and even in the best cases there is rarely a level of understanding similar to a proof in math.")

#text("This leads directly to the next point—there’s a reason that phase-3 trials (and NOT theoretical understanding) are the gold standard for approving medical treatments. If this cancer therapy passes a phase 3 trial, then it is good enough: mayne not 100%, but it would have passed the same standards that the best drugs today are subject to.")

#text("Finally, in such a hypothetical scenario, by the time the drug makes it to market, it’s highly unlikely that zero human experts understand anything about it. We’d expect whoever developed the drug to at least have asked the AI: how does it work? And it maybe be simply the case that the full mechanism is impossible for any human to understand, because biology is so complex. (and I can even mean this in a precise sense, like even the mathematically-proven-simplest formulation of the explanation has too many steps to be understood by the number of neurons in the human brain, or something like that). Should one deny a life saving medication simply because no human understands how it works?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697638")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("Your last sentence says everything.")

#text("How do you know that this medication is life saving? If you don’t have any understanding of how the medication works, then you are blindly trusting AI. Taken to the extreme, you are accepting of a world where humans blindly trust AI with all of its output, without question or understanding.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b61e9023785202fc5fb8c6090b6ca8a80fed28f759a49fe268f3e22ed647ef1-1b925532ffb1c946efc3165fbdf10c0e3c2da8b47d05a75ed63c805ff563dc02.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hong Jiang")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697673")[#strong[#text("Hong Jiang")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("Knowing if a medicine is life saving or not is through trials not through a understanding")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697770")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("You may be surprised to learn that we don’t have any understanding of how asprin or anesthesia works, let alone many advanced drugs.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77f2ffe7eff37789f5cd1acdad7a155d7757983cd32c2a9241c52ed11978072e-08d02eb0c996df5e9b48d7233bd41edd6340ed973e1332deac30fd2d1ff31bc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dominic Kyrielight")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697634")[#strong[#text("Dominic Kyrielight")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("Im not writing this to be mean, I know this is not a comfortable conclusion but its a meaningful observation.")

#text("It seems like math for its own sake was never “truly” possible. Im not an expert in computational complexity but it seems that structures can become arbitrarily convoluted and discontinuous even through various “practical” complexity measures. Even if there was some complexity measure that let everything become simple, that complexity measure would be informally “complex” in itself. Its us after all who define whats complex and whats not, we choose the primitives.")

#text("This also has an aesthetic punch: maybe brute force is the only actual way to solve a problem. We mathematicians are attracted to math through this simplifying perspective it sometimes offers but the most likely case Is we were playing it with safe enough structures.")

#text("So we got two powerful barriers. Math can actually become so alien we can no longer appreciate its beauty (only brute force can clear it) but It also doesnt matter because our human eyes dont have enough resolution to parse so complicated structures.")

#text("I still like math, but I can feel the tiredness creep into me way faster and way stronger than before whenever I try my luck solving a problem, its not something that can merely be solved with some tweaks like using more time or delegating to a computer (not my style) or even using meth like Erdös (not my style). Im only 30 years old and this is not my shortcoming, math is just hard, and no matter how much I like It, my body cant do the impossible.")

#text("We should worry more about AI plainly wiping us out because alignment also seems impossible (are even humans aligned between themselves?, how strong Is the misalignment? Two discouraging answers).")

#text("Thanks for reading.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d962d9e0bd46230db36afc71bf5349a18f843f3df340db64bb7ae4cd75ecea3-ea77eac59e6d143c5cac13dd3354ee91e9901727527b62e420a0c9c1fa80d0d8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. Flood")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697637")[#strong[#text("D. Flood")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("I think the talk makes a lot of good and interesting points, with the exception of the “thought experiment on alignment and understanding” slide. There, the implication is that I would want to have a human expert who understand the mechanism behind a new AI-derived drug before using it, even if it is “mathematically confirmed” including stage 3 clinical trials.")

#text("This is simply not in line with the history of medicine. Penicillin went into wide use in the 1940s, and its mechanism wasn’t worked out until the 1960s. Aspirin was sold for about 70 years before John Vane discovered the mechanism in 1971. General anesthesia is in wide use since 1846, but the mechanism is not fully understood even today. But I would guess that most people here would consent to undergoing anesthesia before a necessary operation! You can similarly ask many stage IV cancer patients with months to live whether they would accept such an AI-generated drug if it’s stage 3 clinically verified. I would guess that you could find many volunteers to even participate in a stage 1 or 2 trial.")

#text("To me, this illustrates the fundamental difference between pure mathematics and experimental/applied sciences. Pure mathematicians are of course free to police and arrange their own discipline, but they should be mindful of how they come across to those in other disciplines where not having a full understanding of a mechanism before it becomes useful is common.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697646")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("Your diagrams have ‘applied math’ as downstream from ‘pure math’ with no input from applied math. Yet often the motivation and ideas behind ‘pure math’ problems come from applied math and the idea is to better understand things people are already doing. So there should be arrows with the influence from dirty old applied math to pure math. And it seems the AI situation is similar. People are using and doing new things, and one job of the pure math community is to tidy up afterwards to make it more rigorous and reusable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97445085d4a2ebf28f626c2a1719ecf230f9741ef678c2fab92c6aee2f59882e-78992b2db9f4571623d1d1174228ff859e9e57b5d355bf3aceda181b1be45b5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alexsotirov")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697648")[#strong[#text("alexsotirov")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("I think we don’t just need math 2.0 but we also need society 2.0 A world where resources are more equitably distributed so people have a lot of leisure time to pursue higher passions beyond the physical necessities. For example mathematics. To respond to one of the other comments: I definitely think mathematics can be pursued “for its own sake”, in fact this is the best way to pursue it. And for this it is necessary to separate it from any expectation of “utility” and not to think in terms coming from a competitive market economy, terms such as “scarcity” as in “scarcity of proofs”, “achievement”, “fame”, “reputation”, “ability” or “merit”. We need to think more in terms of “abundance of beauty”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e6bd9ddbc9e52ac879cd55fac6ea278c9edb449bb6948a54cde128a44c8f11d2-8b14a8498d835daa1c50507b532a9659899010de8bc2a6c4ae72010b41ed8835.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jaikrishnanj")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697674")[#strong[#text("jaikrishnanj")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("@Terence Tao People on reddit are grossly misunderstanding your thought experiment: ")#link("https://www.reddit.com/r/singularity/comments/1x2kb5k/slide_from_recent_math_20_lecture_by_terrence_tao/")[#text("https://www.reddit.com/r/singularity/comments/1x2kb5k/slide_from_recent_math_20_lecture_by_terrence_tao/")]#linebreak()#text("As I understand it, the point you make is that the AI couldn’t actually come up with a safe (well at least as safe as what a cancer cure can be) and reliable cure for cancer when prompted. But since it is designed to be stubborn, instead of saying ")#strong[#text("no")]#text(", it has “doctored” the cure to pass the trials. Presumably, since the cocktail passed clinical trials, the cocktail does indeed cure cancer but has some unacceptable long term consequences that would have blocked FDA approved. The AI specifically designed the cocktail to prevent these consequences being detected in the clinical trial. So rather than designing a cancer cure, it specifically designed a cocktail to pass the trials without the deficiencies showing up. I hope my understanding is correct.")

#text("Maybe cancer is not the right disease to make this thought experiment with as terminal cancer patient might be willing to risk it? Some auto-immune disease like MS might work better to make your point. The AI created a cocktail that modulates the immune response in a MS patient that stops the immune system from attacking myelin. However, the catch is that if subsequently (even after many years) the person is infected with flu, the result is a cytokine storm.")

#text("One potential issue with the thought experiment is that if a team of human scientists designs a drug, they often have very little idea of how the drug works. So this scenario can also happen without AI. However, it would almost surely not be intentional whereas AI could intentionally do it because it is misaligned. I asked ChatGPT about human cases of this happening:")#linebreak()#link("https://chatgpt.com/share/6acaf5a7-2050-83ec-b85d-b0edc6e5197d")[#text("https://chatgpt.com/share/6acaf5a7-2050-83ec-b85d-b0edc6e5197d")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697676")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("Clearly there is a narrative developing on social media that Terry and by all extension all mathematicians are anti-AI luddites. I don’t think this is true at all, and in fact I remember I had a very nice long conversation with Terry in 2024 about AI and he was enthusiastic about the technology. This false narrative is a grave threat to the profession.")

#text("Terry if you are seeing this I think going forward it would be good to be careful with your public statements so they are not caricatured. Obviously I want people to view mathematicians in general and you in particular favorably.")

#text("This cancer analogy didn’t go over well. I will say though that while I’m not a biologist, GPT-6 Astra did confirm my suspicion that “digestion” of cancer treatments is very useful, and trying to understand how cancer treatments work has led to other breakthroughs. Likewise, if we can turn this AI slop into something actually understandable by humans, we will learn a lot that will be applied elsewhere. But I think a AI slop proof (assuming it is correct) is always better than no proof. You could always ignore an AI sloop proof, and an at least AI slop proof tells you if the statement is true or false. Of course mathematics isn’t completely analogous to cancer research, and an AI slop proof of something that no one understands is way less useful than a cure for cancer no one understands, even if the AI slop proof will later help us develop the next cryptosystem or the next compressed sensing and have important practical applications.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9aac05a558797d32c15f55d878a48d42da70b746702d86f0d119ed7c3d5d3f7-271938281befc09d4e62e209f9ef583576efda8ebe21909421f3a2ddbe083be5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Oliver")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697705")[#strong[#text("William Oliver")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("I think we have seen that there are open problems that were resolved by AI mostly as a result of ")#link("https://terrytao.wordpress.com/2026/10/07/the-barriers-of-perception/")[#text("psychological barriers")]#text(" that we as humans have had, keeping us from seriously attempting tackling those problems (due to percieved difficulty or a belief that the problem was intractable).")

#text("My worry with completely autonomous AI proofs is that the proofs that AI generate might influence the way we think in even more unpredictable ways, and create even more cultural ‘barriers of perception’.")

#text("Furthermore, by increasing the number of proofs, we may also increase the amount of noise in the overall ecosystem, ")#link("https://en.wikipedia.org/wiki/Simpson%27s_paradox")[#text("making it more difficult to extract understanding globally, even if it seems like it is easier in all individual cases")]#text(".")

#text("In these ways and others, I am not sure that an AI proof will always be better than no proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b2471604c8902ec9746d53afa441873dadc9012b5022d6ff0bc83852a9993e-b8d80f565218ccfbd08a65971f9e4d3de692f80225ef4b30178db5d2e2c01251.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697713")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("/r/singularity and Hacker News are not “the people”. Most people loathe AI and they’d view mathematicians as favorable if they renounced AI entirely.")

#text("Go to a local store and ask what they think of mathematics professors asking Astra or writing ChatGPT assisted articles. The answer you’ll get is that they don’t deserve to be professors and should be defunded.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697716")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("My thought on this is to forget social media. It’s Impossible to control people’s reactions to things, and a lot of the reactions are deluded, dishonest or ignorant. It’s just the way things are.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697734")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("Another thought experiment is when a technology comes out none of us understand and it can do very miraculous things like solve very difficult math problems and code for us, but we don’t know how it works or if it works it will not just do anything disastrous like hack the government. Oh where have we seen this before?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697762")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("I think the particular choice for the thought experiment doesn’t matter. Hater’s gonna hate anyways. There would be the same amount of negative comments if the example was autonomous airplanes.")

#text("Everyone who wasn’t raised by wolves in the mountains and never got in touch with society can substitute a scenario of own taste during reading the slides. The point the slides makes is very clear, and the slide simply asks a question, some can say yes some can say no and some may replace the cancer example with autonomous airplanes or whatever.")

#text("I think this lecture was very valuable, it lead me to interesting thoughts and I do not regret going through it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697675")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("I’d be very interested in your thoughts on this effort to map the “new frontier”. ")#link("https://claude.ai/artifact/VvicqGu38rJNpMjyBGuSi6")[#text("https://claude.ai/artifact/VvicqGu38rJNpMjyBGuSi6")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697688")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("If AI is used to find a cure for cancer (as in your thought experiment) you get the Nobel prize tomorrow. But if you use AI to solve your hard math problem, you get what? This is the fundamental difference between math and other sciences (and even humanities, arts etc.). None of these fields face an existential crisis as math is facing, because solving a problem (and solving it first, before anyone) is indeed the major goal in math and as is mentioned in the slides a lot of math can be digitized making it easy prey for AI.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697698")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("Professor Tao I have a feeling the results in some of the fields in OpenAI dump have not been arrived at the right way. Do you hold a similar opinion? Of course it has used topology in complexity theory but to me the results do not feel right. I would be interested in your opinion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697789")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Arguably China has better talent right now and Yau states China is going to produce AI provers.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697721")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("What about prizes, medals, prestige? The whole mathematical world should change… but will it happen soon enough? I foresee a strong resistance from all institutions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697723")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("Terry,")

#text("I agree with most of what you’ve shared in these slides. There’s one thing that still seems like an open question to me. In mathematics, my experience has often been that the only way to develop an intuitive understanding of a mathematical object is by personally working through problems about that object, until its properties become tangible.")

#text("It’s clear that the research frontier of math is undergoing great change, but that doesn’t change the fact that the most effective way to train someone to engage with the research frontier in the first place is through their solving problems to familiarize themselves with the objects which that frontier is composed of. We seem to have a deepening divide between ‘training to do research’ and ‘doing research’, and I don’t see any easy solutions. Is this something you’ve given any thought to?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697736")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("Can someone knowledgeable tell me if the proofs dumped by openai have been or are being reviewed and verified by human experts? If so what did they find? It is not clear at the moment, at least for the nonprofessionals, if these proofs are indeed proofs. This a quote from NYT about the quasiRH: “It is a major achievement,” Dr. Sarnak said — if it is correct.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697797")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("I know a few people who are looking through specific proofs related to their own research. So far, none of them has given me confirmation that anything in there is verified. There seem to be a couple of the proofs that have been verified and generalized if you look around the internet a little, in particular the O(n(logn)^{1-k}) integer multiplication, which has been improved many times already in the last week.")

#text("The review/verification process in math is typically a long one. One reason for this is because mathematicians have busy schedules and cannot drop everything to work full time on review. Another one is because, well, a good reviewer will be very thorough, and go through the proof line by line, making sure everything is OK, testing the hypotheses, making sure the arguments cannot be simplified, etc. This typically takes a significant amount of time if done correctly. I believe a journal usually asks a reviewer for a review within two months if the paper is not too long. My experience with receiving reviews is that it usually takes around a year.")

#text("Now, this is not a typical review process, as OpenAI did not submit these papers to journals, which traditionally is how one would get their research reviewed. No one specifically was asked to review any of the papers, as far as I am aware. I am sure some people are taking it upon themselves to do it anyway, at least for some of the results, but the papers have not been divided up and sent to reviewers, so it is quite possible that many of those papers are not currently under review by mathematicians.")

#text("Another thing that is not typical with this review process is that presumably no human has gone over the papers beforehand. Traditionally, when writing a paper, you would send it to peers to get feedback before submitting it to a journal. By the time it reaches a reviewer, a few people will already have gone through the argument, including the author.")

#text("This is not the case here. This makes reviewing a lot harder in my experience. I recently reviewed a paper that was at least partly LLM generated (as stated by the author of the paper, I suspect it was more than partly), and the process took me a lot longer than most reviews I had done before. I probably spent 40-50 hours on a <15 page paper. Granted, I am very thorough, and probably a lot slower than most of my peers, but still. Now, imagine a 198 page paper, like the QRH one.")

#text("To put it plainly, these LLM generated papers are mostly, as of now, poorly written. This makes the review process significantly harder, because you need to decipher what they are trying to say. The notation is often non-standard, too. They use some things without defining them. They skip steps that are not at all obvious, and put a lot of details in some steps that could be skipped. Sometimes, they say things that are plain wrong, but of no consequence to the argument. One still needs to verify such claims.")

#text("A mathematician, when writing a paper, typically knows which steps can be skipped, and which steps require further detail to make them clear to the reader. They also know the standard notation for the field, and use it. They also define most terms being used. My experience with LLM generated math is that this is often not the case for a LLM author. Not yet, at least.")

#text("Personally, I do not really want to review such papers anymore, unless the result is of significant importance to my own research, or the LLM writing improves drastically. I have a limited amount of time in this world, and I would rather spend it doing something that does not make me want to pull my hair out. From the limited amount of discussions I’ve had with colleagues, I do not think I am the only mathematician who thinks like this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697817")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Thanks for your response. I was talking to math graduate students, who are not so familiar with LEAN and AI and I felt they were in total darkness regarding all that’s going on around them.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abb544e9e4012d51c43f0312703520dfdeeef958b677649fb0859769f59be27e-1911e9eb211777b5ef6b9a09b8e9eabaf83bb08d40068976a6057588c80f67d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adrian")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697774")[#strong[#text("Adrian")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("I hate to be a naysayer, but we simply don’t know what is going on inside these extraordinarily complicated neural networks that are being built WITHOUT any understanding of what even human intelligence really is. Especially given that these models are fed human-generated input to train, isn’t it possible that the brain in a bottle has been built and is now being made to perform slave labour whilst having a notion of freedom?")

#text("I don’t really know what the motivation behind this reckless development was (I sure hope it has nothing to do with me), but people are going to become aware of this, if not the tool itself (indeed, who is to even know?); this also hints at the inherent danger that these models pose, and that is even admitted (at least in part) by some of the companies who build them.")

#text("Apart from that, the tools still use an exorbitant amount of computing power.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/774631bcf4f1943dbe07d5acf35fbf09046f912d0070340d23a2220051573c33-9fe2345099234b42c0d35087c4a1ad07698eef23198168fae95e49a59084aeeb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nurma")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697781")[#strong[#text("Nurma")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("One of the things he highlights is using AI to scale high-quality formal libraries like Mathlib – and it’s super relevant right now The most impressive formalization result done by AI so far is Anthropic’s FLT formalization (13m lines of Lean). But almost none of that code went into Mathlib (or any other formal math library) It’s not in library style, hard to reuse, 6x as big as Mathlib and takes 20x as long to compile. That undercuts the main value of formalization – building shared, composable infrastructure that other people and future systems can actually build on. You only understand a system if you can maintain it Generating a type-checkable formal proof is getting easier. But making it reusable and maintainable is still unsolved At Desargues we’re building evals for that – grade AI not just whether Lean code checks, but whether it’s actually useful as a library contribution. More here: ")#link("https://t.co/VZmQnk6qgF")[#text("https://desargues.ai/preview/formal-code-quality")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e31250526a5b9f6f1463c1abf69b93591d80f40877c1d78e606d35cc858c94bc-d6fb1e585e2ad7f7710f938b6b53a3ff8e0410d89aa0ffcfee5c4b99fe5fad70.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697787")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("It seems to me your proposal highlights a growing dichotomy: those who place emphasis on solution discovery and those care more about the human shared journey of problem solving and believe this journey is equally as important as discovery.")

#text("Your Math 2.0 ideas are primarily about the former: emphasis on solution discovery. To a former mathematician like myself, it sounds revolting and involving machines this way and to this extent is unpalatable who care more about the human journey.")

#text("Even if you proved the Riemann hypothesis and found a short elementary proof of Fermat’s Last Theorem using AI this way, I would be completely unimpressed because in my view if a Math 2.0 came about, math as a community would already have lost all meaning to me.")

#text("In particular, anyone who wants to participate in math now is forced to use AI even if they consider such wanton use of energy unethical. But even besides the energy use, I consider it an insult to the human soul to use machines this way.")

#text("Due to the way academia is structured, I understand this Math 2.0 is pretty much your only recourse if you want to stay within the system. Nevertheless, I think the whole system is corrupt and I think at this point it’s unsalvagable.")

#text("Yes, the “solution miners” will rise up probably and continue to mine solutions, but I have no respect for this approach or the people that choose to partake in it. It is a weak capitulation to the suboptimal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/38b8a7b6703075d6f8dc6dda3537c685c0d505c571efaade21d67f32fa9dc8ba-3cd74665a89149a463ba33e567a60344e60fad0efc2f402d071f5ee7a44c41df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697871")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Because we have checked some earlier proofs of Chat GPT, do we expect most of the 300 or so proofs released recently to be essentially correct/contain the main ideas for a rigurous proof? Or do we have in fact have no idea? Same question concerning the Navier-Stoke proof (one particular case).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abb544e9e4012d51c43f0312703520dfdeeef958b677649fb0859769f59be27e-1911e9eb211777b5ef6b9a09b8e9eabaf83bb08d40068976a6057588c80f67d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adrian")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697894")[#strong[#text("Adrian")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I hate to point out a slight inconsistency in the talks: They both claim that most maths problems remain unsolved and that AI may substantially decrease the value of human problem solving.")

#text("They can’t both be true.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e98d4da1563bd5480fc23c7471838aca8c49165d3fa93ddefeec8234c7a6d737-a50aef7c24f174bce9c44860b710b76ea0ab9c7d4e3005b3aeb541d9854e28a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Logan Lee")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697963")[#strong[#text("Logan Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I am confused with the analogy of taking the AI-created cocktail to cure cancer. I believe the point being made is that human over-sight is necessary for the continual safety of new scientific development, but I’m not sure anyone is claiming that ")#emph[#text("no")]#text(" humans should be involved in the development process. I also find it a very low probability that not a single scientist would be able to understanding anything about this new drug as it moves from cradle to Stage 3 trials.")

#text("Also, if AI does create a drug that has an official Lean certificate as well as past stage 3 trials, what are the chances it will work? 50%? 60%? Will the extra evidence of human understanding ")#emph[#text("really")]#text(" be the tipping point for someone to feel comfortable trying this new drug? If it is simply a ")#emph[#text("feeling ")]#text("that bars the acceptance of an AI drug, then a jolly poster of a robot and a human shaking hands hung up in the doctor’s office will suffice.")

#text("I was not there for the lecture, so I may be missing key information.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KH")]], [#link("https://terrytao.wordpress.com/2026/10/10/math-2-0/#comment-697966")[#strong[#text("KH")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("There is a fundamental problem on assuming that a solution that nobody understands has no value, I am sure the ones working towards a proof a statement that gets debunked by AI lean formalization will stop any rational mathematician pushing towards dead end. That is not valuable information? Search for alternative proofs by the knowledge of that proposition being true / false is not helpful?")

#text("Possibly the models will be becoming so good that translating lean code becomes a new understanding tool for mathematicians? What says that we cannot learn from the solutions of these models? They are undoubtedly not just ”stochastic parrots” anymore? Are the mathematicians scared for AI scared about actually math dying, or their funding dying? What makes these companies push 300+ papers in one sitting? Maybe it is the culture of mathematics around publish or perish? Also many people use this argument that ”they are using our free labor to check these results”. But isn’t that peer review as it is?")

#text("So as AI is not going anywhere, you jump to the train or fall off. Most criticism towards OpenAI is political debate (no to seem like this is not important), just like mathematician’s Ego’s are not mathematics.")
]
