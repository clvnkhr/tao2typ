// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/
// Converted to Typst by tao2typ: "2026-10-14T16:36:50.839703+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "New version of algebra game", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("New version of algebra game")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 April 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/")[#text("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a quick update on ")#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/")[#text("my previous post")]#text(" on gamifying the problem-solving process in high school algebra. I had a little time to spare (on an airplane flight, of all things), so I decided to rework ")#link("http://scratch.mit.edu/projects/teorth/2472326")[#text("the mockup version of the algebra game")]#text(" into something a bit more structured, namely as ")#link("http://scratch.mit.edu/projects/teorth/2477436")[#text("12 progressively difficult levels of solving a linear equation in one unknown")]#text(". (Requires either Java or Flash.) Somewhat to my surprise, I found that one could create fairly challenging puzzles out of this simple algebra problem by carefully restricting the moves available at each level. Here is a screenshot of a typical level:")

#link("http://scratch.mit.edu/projects/teorth/2477436")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://terrytao.wordpress.com/wp-content/uploads/2012/04/algebra-screenshot.jpg?w=490")[Original image]]]]#linebreak()#text(" After completing each level, an icon appears which one can click on to proceed to the next level. (There is no particular rationale, by the way, behind my choice of icons; these are basically selected arbitrarily from the default collection of icons (or more precisely, “costumes”) available in Scratch.)")

#text("The restriction of moves made the puzzles significantly more artificial in nature, but I think that this may end up ultimately being a good thing, as to solve some of the harder puzzles one is forced to really start thinking about how the process of solving for an unknown actually works. (One could imagine that if one decided to make a fully fledged game out of this, one could have several modes of play, ranging from a puzzle mode in which one solves some carefully constructed, but artificial, puzzles, to a free-form mode in which one can solve arbitrary equations (including ones that you input yourself) using the full set of available algebraic moves.)")

#text("One advantage to gamifying linear algebra, as opposed to other types of algebra, is that there is no need for disjunction (i.e. splitting into cases). In contrast, if one has to solve a problem which involves at least one quadratic equation, then at some point one may be forced to divide the analysis into two disjoint cases, depending on which branch of a square root one is taking. I am not sure how to gamify this sort of branching in a civilised manner, and would be interested to hear of any suggestions in this regard. (A similar problem also arises in proving propositions in Euclidean geometry, which I had thought would be another good test case for gamification, because of the need to branch depending on the order of various points on a line, or rays through a point, or whether two lines are parallel or intersect.)")

#heading(level: 1)[#text("Comments (49)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10363e310bcdb54abcb59c65fb564f203d0022984d3e0814b67c8c4d6252d093-4042af8a57ba07ecc00848c889610a827652d19e91beae7a2b42a15620ff9dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nets Katz")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-138873")[#strong[#text("Nets Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("Terry,")

#text("I’m interested in this for what I suspect are similar reasons. It’s good work!")

#text("I don’t have any good suggestions for how to deal with branching beyond the trivial one. (Aren’t all square roots simultaneously positive and negative?) It seems a gamified version of completing the square to derive the quadratic equation, or of factoring in more generality could be interesting. Is it important that the order of the factors doesn’t matter?")

#text("As to geometry, I could claim it is already gamified, though not as restrictively, by Geometer’s sketchpad. Only certain kinds of moves are allowed and you want to build a robust construction. Sketchpad deals with branching of course. The user selects which point on the intersection of two circles he wants.")

#text("Nets")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb46e9468b9293294c965a63da931237a22f1829016df4d09d0afde27ef7bae1-a6b58f15ba4ab565f50f8de4af01cba391c895188c22639ed485f03c0ce6e1e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kevinjardine")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-138886")[#strong[#text("kevinjardine")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("It is common for puzzle games to have multiple solutions. Perhaps you could have a square root function that randomly returns one or the other root at any given time. You could leave the fact that the puzzle allows multiple solutions as something for the student to discover for himself/herself either by attempting to solve the puzzle more than once or by discussing the problem with others. It would be interesting if solving the equation reveals the next step in a path to a secret treasure (with different solutions creating different paths), and so depending upon the solutions arrived at, two students playing the game might discover that they have followed different paths and won different treasures.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Crust")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-138875")[#strong[#text("Crust")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("Looks great! I’m definitely going to show it to my kids. The following is the key:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("I found that one could create fairly challenging puzzles out of this simple algebra problem by carefully restricting the moves available at each level…. [T]his may end up ultimately being a good thing, as to solve some of the harder puzzles one is forced to really start thinking about how the process of solving for an unknown actually works.")
]

#text("One comment: in level 11, it seemed a little painful, as at the end I had to click “subtract 1” 256 times, though perhaps I missed the point of the problem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9558584a3ca6515d0fafc5021b7a439a04b9df1c75eed9e68b7d16aa4a2d59bd-9aa2f6a3bc9c0ce5b1be56e99194d974e8f662bedaed136b97e34d5b34578acf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-138892")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("I think the point is using divide by 2 to make the numbers smaller (temporarily making the coefficient of x a small fraction). Use subtract 1 a few times, then use multiply by 2 to return the coefficient of x back to 1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Crust")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-138897")[#strong[#text("Crust")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("D’oh! Thanks.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Crust")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-138877")[#strong[#text("Crust")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("PS Assuming I haven’t missed anything, I’d suggest adding a “subtract 50” or similar sprite to level 11.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d28baa24384f844a611fc2d7be3e8c8a4bd35262e8c79d8b29ab8f3312c4741-622a21b7b42093e4a41dfa73e09bc06fa2fa8a614fb4de5852aa47a9ae630029.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cammcleman")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-138891")[#strong[#text("cammcleman")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("Yup, you missed something! Level 11 was my favorite.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2e6ae09609e2af75674e0148c5ccdfd1890b2141c5957bcbe6e66b3708dff06-86e24ab119777fcf481bacc29a0775c178571d32b0c54d3c6f9d054968ed2846.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan L")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-138894")[#strong[#text("Dan L")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("I really like your implementation of the restricted moves idea. I think it moves away from the goal of teaching basic algebraic manipulation and into a true puzzle game, albeit one that uses and teaches actual math skills. I think that this (along with the troubles with quadratics) points to the idea that we don’t necessarily need one good “algebra puzzle game” but rather a wide array of mathematical puzzle games.")

#text("Ironically, I think that the visual nature of geometry makes geometry proofs difficult to gamify, in the sense that a geometric diagram is always telling you things that may or may not be true. (e.g. “This figure not to scale.”) On the other hand, I think propositional logic proofs could be gamified pretty easily (although I don’t have high hopes for how fun such a game can be).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02e1a57fd0c917793907bc85f2843b2a9445fad397e2c6c7bf9c2a34154590bc-7337d18678c989e5944c6beea78b768ba9bb066a0b5242a16e6c3ea26c61225a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-138896")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("To prohibit “cheating” on some levels, I suggest adding a restriction of 20 moves.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02e1a57fd0c917793907bc85f2843b2a9445fad397e2c6c7bf9c2a34154590bc-7337d18678c989e5944c6beea78b768ba9bb066a0b5242a16e6c3ea26c61225a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-138900")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("Correction: 30 should be enough (I can do level 11 in 22 moves.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2e6ae09609e2af75674e0148c5ccdfd1890b2141c5957bcbe6e66b3708dff06-86e24ab119777fcf481bacc29a0775c178571d32b0c54d3c6f9d054968ed2846.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan L")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-138926")[#strong[#text("Dan L")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("Most modern games let you “pass” a level even if you do it inefficiently but also draw some distinction between passing it efficiently or inefficiently. That seems especially appropriate for this sort of game.")

#emph[#text("[This feature is now added to the game – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3876e36d8bf54c779f3c1e92c9b1c772b4eb51235441fccf428a0bedfac6c04d-36188731545c09c1dde61524a206e237dcfee203eae6ef85141c5329c5e29452.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ulrik")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-138899")[#strong[#text("Ulrik")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("Michael Beeson has argued (see ")#link("http://www.michaelbeeson.com/research/papers/ConstructiveGeometryLong.pdf")[#text("http://www.michaelbeeson.com/research/papers/ConstructiveGeometryLong.pdf")]#text(") that Euclidean geometry can be done without disjunctions. In fact, the only Proposition in Euclid that requires disjunction is Book I, Prop 2 (rigid compass can be simulated using a collapsible compass), but then you simply take the rigid compass as axiomatic instead!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/881129b35acf6b9a3253370c1ec853c923ad4973a05c0709e9f5e82ac2307faa-5f5e2be7d616d800aab509e0afa54c55c512397bf3203f4820d49af68e6ef5ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pablo Lessa")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-138909")[#strong[#text("Pablo Lessa")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("Maybe something similar can be done for (algorithmic aspects of) Calculus? For example the puzzle might be an indefinite integral and the available moves would be applications of integration by parts or substitution. No disjunction seems to be required (but an undo button would be nice!).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of monsieurcactus")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-138913")[#strong[#text("monsieurcactus")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("In the beginning of abstract algebra class, we have to prove frustrating things like 0a = a0 = 0 and (-1)(-1) = 1. This is also like a game.")

#text("The set of possible “statements”, left = right, are transformed using the group or ring axioms. A “proof” is a path from a tautology to the theorem statements. I always wondered how equivalent different group theory proofs were and if we can “deform” one proof into another.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/986de1e85f64e2ab2ff0203025858134a52e5461109fdb752d88ed2bec1a5c9d-d1415462ab7feeb15e5af493d515fcefc413872c7b5a46d2053725703d12827e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Cherniavsky")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-138915")[#strong[#text("John Cherniavsky")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("Regarding logic games, the Logical Journey of The Zoombinis is a nice game imparting logical thinking though not formal propositional logic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of monsieurcactus")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-138917")[#strong[#text("monsieurcactus")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("I really enjoyed the game. Even though I could solve the equation by hand, I had to think about which sequence of moves to make and whether I used the least moves possible (or at least minimal) in some sense.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-138918")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("I broke level 6 :(")#linebreak()#text(" ")#link("http://i44.tinypic.com/2gv4vlz.png")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/i44.tinypic.com/2gv4vlz.png")[Original image]]]]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/191ef87d126a1d5fe0245fd1b6c569b8d32cc96ab1be1668ee19e382ca8c3942-b1b05a6d0cfb0a97cf6a2248ad440a4c9b0a99cdeea0b522a3245a3d73f61bdd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jedharris")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-138932")[#strong[#text("jedharris")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("Great stuff.")

#text("I very much like this perspective because it makes clear that doing math is solving inverse problems. Often the way math is presented, we only see the forward version — a completed proof — so the goal oriented reasoning, the set of possible choices at each step, and so on is invisible.")

#text("Terry’s description, and his games, make the moves and the reasoning the focus, which is as it should be. (This suggests that the moves could be recorded in a “tape” which when one is done would be a little proof.)")

#text("Now, I’d like to have all math domains recast as sets of moves one can make, along with advice about how to pick them in different cases.")

#text("Often Terry’s pieces have this flavor already. I think always talking this way would make math much more accessible and fun. Most of “mathematical intuition” is a sense of the set of applicable moves, and how to choose among them to create a useful path.")

#text("One important point implicit in Terry’s previous post: We all make mistakes along the way. So part of the skill of math, programming, etc. is how to detect and correct errors. Often one chooses sub-problems to solve along the way because the results are fairly easy to “sanity check”. In programming test-driven development makes this central; I don’t know if there’s any equivalent style of math.")

#text("I think the game style can easily incorporate this point — one encounters dead ends or makes wrong guesses, then has to back up. I’m less clear on how to help students learn good skills for how to check and correct for errors, but the game format makes errors expected and OK.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/938039d8e9e20d3403dabd878685e0a6cc6fc81b9b3309ceae13ebeab92a29d2-85d65adada1ad6d83af1efd1431260184f7ed203e46c2001c73e4c1c44fd9983.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mttpd")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-138943")[#strong[#text("mttpd")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("What do you think about the tests available here: ")#link("http://www.tradertest.org/")[#text("http://www.tradertest.org/")]#text(" ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c16c30c289e80af5b904d7430e4f5176fb1a3ec4e141640470e163a4679d239-ae72aaaefa7fe758e89168d67b8577c71b9e6561c7230b7f4ea026262ac0308b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of walkerjian")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-138996")[#strong[#text("walkerjian")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("Hi Terry")#linebreak()#text(" Here is another take on computational geometry as a game")

#link("http://www.tomshardware.com/news/Minecraft-Calculator-Graphing-MaxSGB-Scientific,15109.html")[#text("http://www.tomshardware.com/news/Minecraft-Calculator-Graphing-MaxSGB-Scientific,15109.html")]

#text("Kind of min blowing no?")

#text("ps: whilst coding your game in java and flash is admirable dare i suggest that javascript and webgl/html5 may be a better way to go")

#link("http://www.khronos.org/webgl/wiki/Main_Page")[#text("http://www.khronos.org/webgl/wiki/Main_Page")]

#link("http://www.khronos.org/webgl/wiki/Demo_Repository")[#text("http://www.khronos.org/webgl/wiki/Demo_Repository")]

#text("cheers")#linebreak()#text(" ian walker")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39b1026746a8b90b2f194ebf2db1b84b6f3c26f017aba6b68a8861f500a2f36a-d911fe2fc6ec91278fd1d4b914b82fa997650d9a3b11969b7b8773ad97cae05b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shinku bara")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-139169")[#strong[#text("Shinku bara")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2012")])]

#text("Sugoi, KawaiiIii, dai-dai-daisuki desu")#linebreak()#text(" Sensei Tao, Arigatou")

#text("Thank you so much for this game")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/063b675704132fba480f5d8523d45eaa6dc1a29606f3921d71f5ba0b6df3a79b-85ac7e85c91e2494dd2382e5ffdaa6d08684f7e06205f699a9f94f45d85b434f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan Reich")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-139176")[#strong[#text("Ryan Reich")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2012")])]

#text("This is a great game. After getting through a few levels with trivial arithmetic, I hit one where I looked at the options and thought “why would I multiply by 3? I’d rather just subtract that constant”. When I realized that the only addition option was to subtract a multiple of 3, it made sense. Same thing happened when I got to the one where I’d have to subtract 1 256 times and I finally acceded to the division option even though it created a horrible decimal in front of x. It’s an unnatural strategy but it forces the player to think about their mathematical options, and of course, in the context of a higher-order equation or a system, sometimes these “counterproductive” options are the best general method of simplifying.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef1b812c33559687a2db67b51dc74304941c38d4a8f8af435ff9a9fb34708f0c-a39ca97e34aefcf8138c790d52a33377bff4b8a9a3c29d83f797098665a7f801.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-139180")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2012")])]

#text("I’ve never had a chance to use the software, but, based on their book ")#link("http://www.amazon.com/Logical-Reasoning-Diagrams-Studies-Computation/dp/0195104277")[#text("http://www.amazon.com/Logical-Reasoning-Diagrams-Studies-Computation/dp/0195104277")]#text(", the Hyperproof environment described in the article on heterogeneous logic has a nice, albeit fairly overtly formal, approach to dealing with disjunctions that could perhaps be adapted to this setting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0fd56049a8189a380fda42273fee0bc2b9ce50a7a224700afce1fe96194008-d71b4d207f9bb85a02159d9eb02ffc3ded2bfbce61de425e7d3d85b4f53db867.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uwe Stroinski")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-139279")[#strong[#text("Uwe Stroinski")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2012")])]

#text("In version 2.1 some of the bubbles overlap, so that one cannot read their content.")

#text("Great idea. A game like that for higher degree equations would be a tremendous help for teachers.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/063b675704132fba480f5d8523d45eaa6dc1a29606f3921d71f5ba0b6df3a79b-85ac7e85c91e2494dd2382e5ffdaa6d08684f7e06205f699a9f94f45d85b434f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan Reich")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-139400")[#strong[#text("Ryan Reich")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2012")])]

#text("In reply to the correction: at least in level 6, they still overlap — and the one that’s blocked is the question. ")#emph[#text("[Oops, I guess I didn’t playtest the previous correction thoroughly enough. Hopefully this time will do the trick – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-139313")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2012")])]

#text("Just want to chime in and say this is a great idea. So much so that it spurred me to start thinking about a massively multiplayer maths game; imagine an simple RPG where you start off as a weak character, and as you encounter enemies in the world, you have to solve mathematical problems to defeat them. In the starting area, you might have simple linear equations to solve, and as you get stronger, you’ll have to contend with polynomials, simultaneous equations, so on and so forth.")

#text("Boss creatures are extra hard and you need to collaborate with your team mates to solve the problems; but as a reward you get special gear and in-game equipment as a reward, not to mention unlocking new areas of the game.")

#text("Any subject could be added to this game, it needn’t be just basic arithmetic and algebra. Dare you and your friends tackle the Forest of Logic and Sets? Do you have what it takes to climb Mt. Calculus?")

#text("Of course, there will come a point where subjects go into theorems and proofs and that will not be something that could easily gamified, but for anything that can be solved as a problem, there’s a lot of ground to cover.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2e6ae09609e2af75674e0148c5ccdfd1890b2141c5957bcbe6e66b3708dff06-86e24ab119777fcf481bacc29a0775c178571d32b0c54d3c6f9d054968ed2846.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan L")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-139868")[#strong[#text("Dan L")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2012")])]

#text("While the game you are describing is not a gamification of mathematics in the sense Professor Tao describes, it could be awesome with the right implementation. The important part of the game would be the instructional part, where you are taught how to solve problems. The cool thing is that running around finding people to teach you things is already a big part of RPG game mechanics. (But I’m skeptical about the multiplayer component. It’s true that collaboration makes math problems easier, but it is extremely difficult to *force* collaboration.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3a58732a079e92192bdb66f32dd0eb6716edceba669e0b2c581c81bb2797b944-c08744b6c37c0be1cd15d79a25527f2f5312f8a9b81436862c6f11ae0d880add.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonmath")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-139394")[#strong[#text("anonmath")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2012")])]

#text("Just a sidenote: Algebraic manipulation in a form of game can be interesting to people even after they leave school, if it is wrapped up in something they find intriguing. For instance, there is a little game I programmed 5-6 months ago, based on Landau’s license plate game (")#link("http://dau.etf.ba/")[#text("http://dau.etf.ba/")]#text("). More than a few college students interested in mathematics, puzzles or history of science found it interesting – and although the edu games have the students as their primary target, it shows that secondary targets can have their share of fun too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lewis Carroll logic puzzles « What’s new")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-139649")[#strong[#text("Lewis Carroll logic puzzles « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2012")])]

#text("[…] types of logical argument (and one of the few that avoids the disjunction problem mentioned in the previous post), namely the Aristotlean logic of syllogistic reasoning, most famously exemplified by the classic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8931762d160f15f48b27a9cc345242c2a1a3514200b27cb2152493d66f861c91-445fc5d0611d909b06e007fc2d56790c49cf26992a8a239aaaa38c148ced9c75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JonesMath")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-139651")[#strong[#text("JonesMath")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2012")])]

#text("As you pointed out, the game is currently more of a puzzle of how to use an arbitrary set of operations in order to solve for ")#mi("x")#text(" than a game that would help students efficiently choose operations to solve a linear equation.")

#text("What if you put in operations that were closer to what a student might actually try? For example, for the problem ")#mi("2x-7=11")#text(", why not have the option to add 7 and subtract 7? If they make the common error to subtract 7, it will be readily visible to them that subtracting 7 in fact does not help to isolate ")#mi("x")#text(". Several rounds of a problem like that and I imagine students would pick up pretty quickly that they need to use inverse operations rather than the same operation in order to “get ")#mi("x")#text(" by itself.” You could also have an option to multiply by 2 and divide by 2. Perhaps even add 11 and subtract 11.")

#text("You would be able to use the same approach for problems like ")#mi("4x - 7 = -2x + 5")#text(". Have the option to add ")#mi("4x")#text(" and subtract ")#mi("4x")#text(", as well as the option to add ")#mi("2x")#text(" and subtract ")#mi("2x")#text(".")

#text("For the above two types of linear equation solving, I think the program would work well. However, I feel the game wouldn’t be able to adequately handle problems that require simplification before solving, e.g., problems like ")#mi("-4(x-7)=16")#text(" or ")#mi("8x + 2 - 9 = 12")#text(". Such problems require students to perform an initial operation before using an inverse operation to solve [Of course, you could still just use inverse operations to solve, but then the student misses out on identifying and using the distributive property and recognizing and combining like terms].")

#text("When I see students make mistakes with linear equations, it is not usually what inverse operation to use that is the problem (equations with a term like ")#mi("-\\frac{2}{3}x")#text(" being the exception). Usually, the problem is with (like you pointed out) carrying out several arithmetic operations without error. Other problems that crop up are distributing errors (e.g., ")#mi("-4(x-7)=-4x-28")#text(") or performing both inverse operations on one side of the equation (e.g., for ")#mi("8x + 2 - 9 = 12")#text(", adding 9 to the 2 and the -9). Unfortunately, a game as outlined above would have difficulty helping students improve in these areas.")

#text("It’s my own opinion that it is extremely difficult to computerize or ‘gamify’ mathematics beyond memorization and practice of basic addition/subtraction/etc. facts. Even when dealing with introductory mathematics such as linear equations, and especially when creating a game that approaches the math in terms of strategic moves rather than “Solve this math problem, enter a numerical value, then hit enter,” there are numerous considerations and limitations that I think take away from the student’s learning experience. For example, consider the following questions:")

#text("– If arithmetic is still a significant hindrance to students working on this level of math, should we really being doing all the operations for them?")

#text("– If we choose to do the operations for them, should we show the operations being done instantly (students wouldn’t be instantly doing the arithmetic) or should we include an animation that shows how these operations are affecting the current equation?")

#text("– If we don’t do the operations for them, should we provide them with an in-game calculator to do operations?")

#text("– How much additional help should we code into the game so that players don’t get significantly bogged down by the arithmetic when that’s not the point of the game? How much will the game be limited for students with mediocre or poor arithmetic skills?")

#text("I mean, these questions are just the tip of the iceberg. Considering, answering, designing, and coding all of the answers to these problems would be a huge undertaking. Yet, all of the above would be necessary to make a game accessible to students from highly variable math backgrounds.")

#text("And even if you do answer all of the above questions, and design a perfectly accessible game, you still have the problem where students are practicing math in a medium that is not conducive to doing higher level math. Ultimately, mathematics on a computer is tantamount to mental mathematics. The big difference is that now the computer is responsible for keeping track of the steps, rather than the student. As students progress beyond linear equations, they will be responsible for more and more steps, each one of which can throw a wrench into the problem and cause a final solution to be incorrect. Take a look at any basic calculus problem and count how many steps an average student might take to solve it, including arithmetic, rearranging terms, simplification, key insights to solving, etc. I think you’d be surprised just how many of those steps are required to be automatized lest the problem (even simple problems) be a significant affair. By letting a computer be responsible for keeping track of these steps (and, in fact, doing some of these steps!) at an early level, you limit the practice of a very important skill necessary for that student to make any progress towards higher mathematics.")

#text("I have yet to see a math learning program that deals with subjects beyond arithmetic that has any educational value (although some might have entertainment value to players that already have a firm grasp on the subject, such as game you’ve created). I feel it would be almost impossible to address the above issue about the computer being responsible for keeping track of all the steps required to solve the problem. However, I would love to be proven wrong, as I feel games in general have a certain motivational element to them that would be indispensable to learning new material, such as math. It would definitely be a great resource for my future students (if I ever get offered a job, that is! Come on schools, hire me already!).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3a58732a079e92192bdb66f32dd0eb6716edceba669e0b2c581c81bb2797b944-c08744b6c37c0be1cd15d79a25527f2f5312f8a9b81436862c6f11ae0d880add.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonmath")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-139687")[#strong[#text("anonmath")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2012")])]

#text("Bug report – floating point mess.")

#link("http://img21.imageshack.us/img21/9842/snimakekranakao20120422.png")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/img21.imageshack.us/img21/9842/snimakekranakao20120422.png")[Original image]]]]

#emph[#text("[Hopefully fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b474e23098e8addf4cc571987d5bfa478aa877fcdc6d156f83d9fd51d613bb4-500ea6beb3f2be061290167cc9f95d270fb4e14e36b4194b0c03ca19ed153dc0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff VanderKam")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-139779")[#strong[#text("Jeff VanderKam")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2012")])]

#text("My kids loved it–thanks! I certainly agree with your complaints about quiz-based math “games”, we’ve been very disappointed with those. But this one appealed to them in a nice puzzle-solving (almost Angry-Birdsish) way. It was great to hear my 6th grader excitedly yell “I got it!” when he solved #12.")

#text("Any chance you could make it randomly generate new ones? If it were to start with a value for x, pick three or four simple operations, and randomly walk backwards 10 steps, how hard would the resulting problem be? Or is that about what you did to create the problems in the first place? I guess keeping the problems integral is a constraint, and having related operations (like both multiply-by-3 and divide-by-3) might make for more interesting setups.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-139974")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2012")])]

#text("Jeff, thanks for the feedback! I quickly wrote up a variant of the game at ")#link("http://scratch.mit.edu/projects/teorth/2491144")[#text("http://scratch.mit.edu/projects/teorth/2491144")]#text(" which has 12 random levels instead of 12 preset levels, with the n^th level requiring n moves to solve. I found that things began to get a bit tricky around level 6 or so if one wanted to stay strictly under the n move limit…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/063b675704132fba480f5d8523d45eaa6dc1a29606f3921d71f5ba0b6df3a79b-85ac7e85c91e2494dd2382e5ffdaa6d08684f7e06205f699a9f94f45d85b434f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan Reich")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-139980")[#strong[#text("Ryan Reich")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2012")])]

#text("I like the SUPER speed bonus :) Any way of getting the decimals rounded to, say, 4 places (at least for the display; internally you probably want maximum precision)? The question box can get quite fat.")

#text("It’s fascinating what state of mind these puzzles put me in. I forget entirely what the numbers ")#emph[#text("are")]#text(" and think only about how they can be ")#emph[#text("defeated")]#text(" with the weapons I’m given. I learn quickly to mentally separate x from the constants and deal with it first. I’m encouraged to think many steps ahead. I am constantly reminded that subtraction is addition of the negative. When “add” and “subtract” options are presented asymmetrically along with a “negate”, I start thinking about the number line as a way to understand the possibilities. I lose all shame talking about something I’ve known since I was eleven as though it were difficult and profound :)")

#text("It’s interesting to me to hear that kids love it; it’s a very smart game, almost too smart. But it’s not smart in the way that you can’t make progress even if you are unable to see the whole solution, so it’s not frustrating. (Alternative explanation: Jeff’s kids are very smart.)")

#emph[#text("[Now rounded to four decimal places in the display – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2e6ae09609e2af75674e0148c5ccdfd1890b2141c5957bcbe6e66b3708dff06-86e24ab119777fcf481bacc29a0775c178571d32b0c54d3c6f9d054968ed2846.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan L")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-140120")[#strong[#text("Dan L")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2012")])]

#text("I love the latest version of the game. The game mechanics are great. All it needs is a snazzier interface and an upgrade to fractions rather than decimals, and this thing is ready for the app store.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Crust")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-139892")[#strong[#text("Crust")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2012")])]

#text("I agree that in general case-splitting makes it challenging to present a friendly interface. But for the special case of quadratic equations, I don’t think it’s bad at all.")

#text("I think the best way to first learn about solving quadratics is by completing the square. The key point is that once you take a square root, you need to do the same steps in both cases. So e.g. if you have:")

#text("(x-1)^2 = 4")

#text("and the gamer presses a “square root” button, the equation would transform to:")

#text("x-1 = 2 OR x-1 = -2")

#text("Then after pressing a “add1” button it would become:")

#text("x = 3 OR x = -1")

#text("For more general problems, you would need to distinguish between “add 1 to left equation” and “add 1 to right equation”, which gets clunky especially considering that the number of equations is changing. Perhaps the best way to handle it would be for the button to ask you which equations it should be applied to via a pop up. But for quadratic equations, you don’t need this.")

#text("PS the game was a hit in my family!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-142013")[#strong[#text("Nice Mental Mathematics photos | Learning Jigsaw")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2012")]

#text("[…] inter-visto issue ]. Gratis!An Introduction to Vedic MathematicsAn Introduction to Vedic MathematicsNew version of algebra game var analyticsFileTypes = ['']; var analyticsEventTracking = 'enabled'; var _gaq = _gaq || []; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2645a222d90ee9983d521751011d314ec6073fc8df973a1df2042f71efc5a4e-1eee3c874dab37ecee7c7c243fb496face203c5346d346e4319e79eec3246ef7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dwees")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-143030")[#strong[#text("dwees")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2012")])]

#text("I really liked this game, thank you for sharing. What I appreciated about it most was that you sometimes gave algebraic tools that didn’t solve the problem in a deterministic way; which requires students to think about what the tools do. I also like the “number of moves” metric, as opposed to the “get so many points” metric.")

#text("I think the game needs a few more levels, but of course I recognize how difficult that is. I wonder, would you mind if I borrowed the concept and tried to create a HTML 5 version of this game?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-143054")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2012")])]

#text("Yes, I would like to see this sort of idea developed in other platforms, so I am happy to grant permission to use the concept for this purpose.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e9836239a5eabe310aea0b9f7c74ac0aa01ab56a1521ae055ace74e76743572-f79f6654a8572d95781f63fe940fc8ce4ea3703f73a2cf98640f7b58b07292b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rob O")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-143032")[#strong[#text("Rob O")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2012")])]

#text("I stumbled upon your blog post via a Google+ share for this algebra game a couple of weeks ago, and was quite taken by the game’s concept. I have a daughter in fourth grade, and some ideas she is learning are enough like algebra that I have tried to instill some algebra into her, and think that such a game as this would be wonderful.")

#text("I see that another commenter has already thought of porting this to HTML 5; I came to ask if you wouldn’t mind my porting the concept as an Android app? Being an educational tool, I would have no plans for commercializing it should I release it on the Android market (I’ll release it for free), and I would certainly credit you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2645a222d90ee9983d521751011d314ec6073fc8df973a1df2042f71efc5a4e-1eee3c874dab37ecee7c7c243fb496face203c5346d346e4319e79eec3246ef7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dwees")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-143034")[#strong[#text("dwees")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2012")])]

#text("Yeah, I should clarify that as well. I would not build the HTML5 as a money maker, but more as a tool to give to students to learn.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2e6ae09609e2af75674e0148c5ccdfd1890b2141c5957bcbe6e66b3708dff06-86e24ab119777fcf481bacc29a0775c178571d32b0c54d3c6f9d054968ed2846.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan L")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-146984")[#strong[#text("Dan L")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2012")])]

#text("Professor Tao, this game looks like it is very much in the spirit of what you are talking about (though quite different from your game). I plan to buy it today and see if it lives up to the hype:")

#link("http://www.wired.com/geekdad/2012/06/dragonbox/all/")[#text("http://www.wired.com/geekdad/2012/06/dragonbox/all/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-147195")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2012")])]

#text("I have made a variation of first Terry’s algebra game.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-147196")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2012")])]

#link("http://scratch.mit.edu/projects/dussau/2613929")[#text("http://scratch.mit.edu/projects/dussau/2613929")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e9836239a5eabe310aea0b9f7c74ac0aa01ab56a1521ae055ace74e76743572-f79f6654a8572d95781f63fe940fc8ce4ea3703f73a2cf98640f7b58b07292b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rob O")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-157512")[#strong[#text("Rob O")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2012")])]

#text("I’m reporting back that I just released the android app game version based on this concept that I asked permission for earlier. It is available on Google Play for free:")#linebreak()#text(" ")#link("https://play.google.com/store/apps/details?id=com.oakonell.findx")[#text("https://play.google.com/store/apps/details?id=com.oakonell.findx")]

#text("I created some more levels, and intermixed them with Terry’s original ones. It is difficult to come up with good levels, with a meaningful progression between them.")

#text("I also allow the users to create their own levels (in a way that guarantees a solution, even if an optimal one is not findable due to the possible large search space) and share the levels with others.")

#text("Give the game a try, and let me know of any comments or suggestions!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcf22dffa854fbbcb5fd06274aee7ae9e8df4aa15e5083bf59d2f437cc4c83e8-9fc79fc414cbf48e0267b10a1e3d3ac9f7965ce8f235cc41a05ad34673acb1a6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave Taylor")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-170010")[#strong[#text("Dave Taylor")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2012")])]

#text("Solid game, man! Some of the solutions have a whiff of control theory on em. Feels like you’re sorta honing in on a target. I think all it really needs is a new title: “Algebra By Computational Iteration: Mark 3.14159…”")

#text("The pacing’s a little rough on mere morons like me, though. I’d consider allowing any number of moves but awarding bonuses for using fewer moves, and some ignoble awards for using a ton of moves, and even allow them to finish close but not quite, with a dubious achievement for their mad low-precision skillzors. ;)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-446616")[#strong[#text("Game or gamified application for teaching/learning mathematics | CL-UAT")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2014")]

#text("[…] Terry Tao’s linear equation games: ")#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/")[#text("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e9836239a5eabe310aea0b9f7c74ac0aa01ab56a1521ae055ace74e76743572-f79f6654a8572d95781f63fe940fc8ce4ea3703f73a2cf98640f7b58b07292b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rob O")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-449128")[#strong[#text("Rob O")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2015")])]

#text("Hey,")#linebreak()#text(" Back again- I released a version 2.0 of the android app Find X, modeled off Terry’s original idea above.")#linebreak()#text(" ")#link("https://play.google.com/store/apps/details?id=com.oakonell.findx")[#text("https://play.google.com/store/apps/details?id=com.oakonell.findx")]

#text("I added some built in new stages and levels to the game, and also added new operations: square root, factor, and wild card. Which now allows quadractics to be solved for X- each “branch” of the solution is solved subsequently.")

#text("I also improved the custom level sharing- user created custom levels can now be posted to a server to share with everyone- there are probably others that are more imaginative with level creation than I am and I look forward to trying to solve their contributed levels.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gamifying propositional logic: QED, an interactive textbook | What's new")]], [#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/#comment-503386")[#strong[#text("Gamifying propositional logic: QED, an interactive textbook | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2018")])]

#text("[…] six years ago on this blog, I started thinking about trying to make a web-based game based around high-school algebra, and ended up using Scratch to write a […]")
]
