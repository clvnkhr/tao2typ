// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/03/29/an-erratum-to-strongly-dense-free-subgroups-of-semisimple-lie-groups/
// Converted to Typst by tao2typ: "2026-10-14T09:07:12.931841+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An erratum to “Strongly dense free subgroups of semisimple Lie groups”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An erratum to “Strongly dense free subgroups of semisimple Lie groups”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 March 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/03/29/an-erratum-to-strongly-dense-free-subgroups-of-semisimple-lie-groups/")[#text("https://terrytao.wordpress.com/2011/03/29/an-erratum-to-strongly-dense-free-subgroups-of-semisimple-lie-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Last year, Emmanuel Breuillard, Ben Green, Bob Guralnick, and I wrote a paper entitled “")#link("https://terrytao.wordpress.com/2010/10/21/strongly-dense-free-subgroups-of-semisimple-algebraic-groups/")[#text("Strongly dense free subgroups of semisimple Lie groups")]#text("“. The main theorem in that paper asserted that given any semisimple algebraic group ")#mi("{G(k)}")#text(" over an uncountable algebraically closed field ")#mi("{k}")#text(", there existed a free subgroup ")#mi("{\\Gamma}")#text(" which was ")#emph[#text("strongly dense")]#text(" in the sense that any non-abelian subgroup of ")#mi("{\\Gamma}")#text(" was Zariski dense in ")#mi("{G(k)}")#text(". This type of result is useful for establishing expansion in finite simple groups of Lie type, as we will discuss in a subsequent paper.")

#text("An essentially equivalent formulation of the main result is that if ")#mi("{w_1, w_2 \\in F_2}")#text(" are two non-commuting elements of the free group ")#mi("{F_2}")#text(" on two generators, and ")#mi("{(a, b)}")#text(" is a ")#emph[#text("generic")]#text(" pair of elements in ")#mi("{G(k) \\times G(k)}")#text(", then ")#mi("{w_1(a,b)}")#text(" and ")#mi("{w_2(a,b)}")#text(" are not contained in any proper closed algebraic subgroup ")#mi("{H}")#text(" of ")#mi("{G(k)}")#text(". Here, “generic” means “outside of at most countably many proper subvarieties”. In most cases, one expects that if ")#mi("{(a, b)}")#text(" are generically drawn from ")#mi("{G(k) \\times G(k)}")#text(", then ")#mi("{(w_1(a,b), w_2(a,b))}")#text(" will also be generically drawn from ")#mi("{G(k) \\times G(k)}")#text(", but this is not always the case, which is a key source of difficulty in the paper. For instance, if ")#mi("{w_2}")#text(" is conjugate to ")#mi("{w_1}")#text(" in ")#mi("{F_2}")#text(", then ")#mi("{w_1(a,b)}")#text(" and ")#mi("{w_2(a,b)}")#text(" must be conjugate in ")#mi("{G(k)}")#text(" and so the pair ")#mi("{(w_1(a,b), w_2(a,b))}")#text(" lie in a proper subvariety of ")#mi("{G(k) \\times G(k)}")#text(". It is currently an open question to determine all the pairs ")#mi("{w_1, w_2}")#text(" of words for which ")#mi("{(w_1(a,b), w_2(a,b))}")#text(" is not generic for generic ")#mi("{a,b}")#text(" (or equivalently, the double word map ")#mi("{(a,b) \\mapsto (w_1(a,b),w_2(a,b))}")#text(" is not dominant).")

#text("The main strategy of proof was as follows. It is not difficult to reduce to the case when ")#mi("{G}")#text(" is simple. Suppose for contradiction that we could find two non-commuting words ")#mi("{w_1, w_2}")#text(" such that ")#mi("{w_1(a,b), w_2(a,b)}")#text(" were generically trapped in a proper closed algebraic subgroup. As it turns out, there are only finitely many conjugacy classes of such groups, and so one can assume that ")#mi("{w_1(a,b), w_2(a,b)}")#text(" were generically trapped in a conjugate ")#mi("{H^g}")#text(" of a fixed proper closed algebraic subgroup ")#mi("{H}")#text(". One can show that ")#mi("{w_1(a,b)}")#text(", ")#mi("{w_2(a,b)}")#text(", and ")#mi("{[w_1(a,b),w_2(a,b)]}")#text(" are generically regular semisimple, which implies that ")#mi("{H}")#text(" is a maximal rank semisimple subgroup. The key step was then to find another proper semisimple subgroup ")#mi("{H^{\\prime}}")#text(" of ")#mi("{G}")#text(" which was ")#emph[#text("not")]#text(" a ")#emph[#text("degeneration")]#text(" of ")#mi("{H}")#text(", by which we mean that there did not exist a pair ")#mi("{(x,y)}")#text(" in the Zariski closure ")#mi("{\\overline{\\bigcup_{g \\in G} H^g \\times H^g}}")#text(" of the products of conjugates of ")#mi("{H}")#text(", such that ")#mi("{x, y}")#text(" generated a Zariski-dense subgroup of ")#mi("{H^{\\prime}}")#text(". This is enough to establish the theorem, because we could use an induction hypothesis to find ")#mi("{a,b}")#text(" in ")#mi("{H^{\\prime}}")#text(" (and hence in ")#mi("{G(k)}")#text(" such that ")#mi("{w_1(a,b), w_2(a,b)}")#text(" generated a Zariski-dense subgroup of ")#mi("{H^{\\prime}}")#text(", which contradicts the hypothesis that ")#mi("{(w_1(a,b),w_2(a,b))}")#text(" was trapped in ")#mi("{\\bigcup_{g \\in G} H^g \\times H^g}")#text(" for generic ")#mi("{(a,b)}")#text(" (and hence in ")#mi("{\\overline{\\bigcup_{g \\in G} H^g \\times H^g}}")#text(" for all ")#mi("{(a,b)}")#text(".")

#text("To illustrate the concept of a degeneration, take ")#mi("{G(k) = SO(5)}")#text(" and let ")#mi("{H = SO(3) \\times SO(2)}")#text(" be the stabiliser of a non-degenerate ")#mi("{2}")#text("-space in ")#mi("{k^5}")#text(". All other stabilisers of non-degenerate ")#mi("{2}")#text("-spaces are conjugate to ")#mi("{H}")#text(". However, stabilisers of ")#emph[#text("degenerate")]#text(" ")#mi("{2}")#text("-spaces are not conjugate to ")#mi("{H}")#text(", but are still degenerations of ")#mi("{H}")#text(". For instance, the stabiliser of a totally singular ")#mi("{2}")#text("-space (which is isomorphic to the affine group on ")#mi("{k^2}")#text(", extended by ")#mi("{k}")#text(") is a degeneration of ")#mi("{H}")#text(".")

#text("A significant portion of the paper was then devoted to verifying that for each simple algebraic group ")#mi("{G}")#text(", and each maximal rank proper semisimple subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(", one could find another proper semisimple subgroup ")#mi("{H^{\\prime}}")#text(" which was not a degeneration of ")#mi("{H}")#text("; roughly speaking, this means that ")#mi("{H^{\\prime}}")#text(" is so “different” from ")#mi("{H}")#text(" that no conjugate of ")#mi("{H}")#text(" can come close to covering ")#mi("{H^{\\prime}}")#text(". This required using the standard classification of algebraic groups via Dynkin diagrams, and knowledge of the various semisimple subgroups of these groups and their representations (as we used the latter as obstructions to degeneration, for instance one can show that a reducible representation cannot degenerate to an irreducible one).")

#text("During the refereeing process for this paper, we discovered that there was precisely one family of simple algebraic groups for which this strategy did not actually work, namely the group ")#mi("{G = Sp(4) = Spin(5)}")#text(" (or the group ")#mi("{SO(5)}")#text(" that is double-covered by this group) in characteristic ")#mi("{3}")#text(". This group (which has Dynkin diagram ")#mi("{B_2=C_2}")#text(", as ")#link("https://terrytao.wordpress.com/2011/03/11/exceptional-isogenies-between-the-classical-lie-groups/")[#text("discussed in this previous post")]#text(") has one maximal rank proper semisimple subgroup up to conjugacy, namely ")#mi("{SO(4)}")#text(", which is the stabiliser of a line in ")#mi("{k^5}")#text(". To find a proper semisimple group ")#mi("{H^{\\prime}}")#text(" that is not a degeneration of this group, we basically need to find a subgroup ")#mi("{H^{\\prime}}")#text(" that does not stabilise any line in ")#mi("{k^5}")#text(". In characteristic larger than three (or characteristic zero), one can proceed by using the action of ")#mi("{SL_2(k)}")#text(" on the five-dimensional space ")#mi("{\\text{Sym}^4(k^2)}")#text(" of homogeneous degree four polynomials on ")#mi("{k^2}")#text(", which preserves a non-degenerate symmetric form (the four-fold tensor power of the area form on ")#mi("{k^2}")#text(") and thus embeds into ")#mi("{SO(5)}")#text("; as no polynomial is fixed by all of ")#mi("{SL_2(k)}")#text(", we see that this copy of ")#mi("{SL_2(k)}")#text(" is not a degeneration of ")#mi("{H}")#text(".")

#text("Unfortunately, in characteristics two and three, the symmetric form on ")#mi("{\\text{Sym}^4(k^2)}")#text(" degenerates, and this embedding is lost. In the characteristic two case, one can proceed by using the characteristic ")#mi("{2}")#text(" fact that ")#mi("{SO(5)}")#text(" is isomorphic to ")#mi("{Sp(4)}")#text(" (because in characteristic two, the space of null vectors is a hyperplane, and the symmetric form becomes symplectic on this hyperplane), and thus has an additional maximal rank proper semisimple subgroup ")#mi("{Sp(2) \\times Sp(2)}")#text(" which is not conjugate to the ")#mi("{SO(4)}")#text(" subgroup. But in characteristic three, it turns out that there are no further semisimple subgroups of ")#mi("{SO(5)}")#text(" that are not already contained in a conjugate of the ")#mi("{SO(4)}")#text(". (This is not a difficulty for larger groups such as ")#mi("{SO(6)}")#text(" or ")#mi("{SO(7)}")#text(", where there are plenty of other semisimple groups to utilise; it is only this smallish group ")#mi("{SO(5)}")#text(" that has the misfortune of having exactly one maximal rank proper semisimple group to play with, and not enough other semisimples lying around in characteristic three.)")

#text("As a consequence of this issue, our argument does not actually work in the case when the characteristic is three and the semisimple group ")#mi("{G}")#text(" contains a copy of ")#mi("{SO(5)}")#text(" (or ")#mi("{Sp(4)}")#text("), and we have had to modify our paper to delete this case from our results. We believe that such groups still do contain strongly dense free subgroups, but this appears to be just out of reach of our current method.")

#text("One thing that this experience has taught me is that algebraic groups behave somewhat pathologically in low characteristic; in particular, intuition coming from the characteristic zero case can become unreliable in characteristic two or three.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/03/29/an-erratum-to-strongly-dense-free-subgroups-of-semisimple-lie-groups/#comment-51085")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2011")])]

#text("typo in paragraph 6: “which this” instead of “this this”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/85a188b385a378b90299ed773ab1af8bd6b68720a58f3c1a01880221a92773ea-0f6bee3bb8f9ca5c929594aa64a739946773ec2f7e24c059441b8fe685297059.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yiftach")]], [#link("https://terrytao.wordpress.com/2011/03/29/an-erratum-to-strongly-dense-free-subgroups-of-semisimple-lie-groups/#comment-51087")[#strong[#text("Yiftach")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2011")])]

#text("Should be Bob Guralnick rather than Rob (unless there is a mysterious Rob Guralnick in addition to Bob).")

#emph[#text("[Gah, that was silly of me – corrected, thanks! – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pila")]], [#link("https://terrytao.wordpress.com/2011/03/29/an-erratum-to-strongly-dense-free-subgroups-of-semisimple-lie-groups/#comment-51118")[#strong[#text("Pila")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2011")])]

#text("A weakly related question: do you give somewhere in your general advices the way you check your papers (or the way you suggests to check one’s papers) ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/29/an-erratum-to-strongly-dense-free-subgroups-of-semisimple-lie-groups/#comment-51119")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2011")])]

#text("I discuss this sort of thing at")

#link("http://www.google.com/buzz/114134834346472219368/WJkEENg19Sz")[#text("http://www.google.com/buzz/114134834346472219368/WJkEENg19Sz")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4446c85e3613ea1aef783cdd2aaeed5d9f638867f5cdfb83371a8fd5eafdc802-4128d38439c3f262811511bc43edaa02d1195286a805d81c47cc20f3556adcce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Neville Campbell")]], [#link("https://terrytao.wordpress.com/2011/03/29/an-erratum-to-strongly-dense-free-subgroups-of-semisimple-lie-groups/#comment-51327")[#strong[#text("Neville Campbell")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2011")])]

#text("Exceptional behavior of small cases is common in group theory. It can be viewed as the reason for the existence of exceptional finite simple groups.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/03/29/an-erratum-to-strongly-dense-free-subgroups-of-semisimple-lie-groups/#comment-51375")[#strong[#text("Weekly Picks « Mathblogging.org — the Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2011")]

#text("[…] campus interviews at grad schools, punk rock OR explained what OR teaches you about having a baby, Terry Tao posted an exemplary erratum on a paper, Women in mathematics (in Berlin) studied websites of fellow BMS grad students and James Colliander […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Expansion in finite simple groups of Lie type | What's new")]], [#link("https://terrytao.wordpress.com/2011/03/29/an-erratum-to-strongly-dense-free-subgroups-of-semisimple-lie-groups/#comment-244502")[#strong[#text("Expansion in finite simple groups of Lie type | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2013")])]

#text("[…] are also some related results established in the paper. Firstly, as we discovered after writing our first paper, there was one class of algebraic groups for which our demonstration of strongly dense subgroups […]")
]
