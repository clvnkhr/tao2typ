// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/
// Converted to Typst by tao2typ: "2026-10-14T11:11:55.712318+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Salem prize now accepting nominations for 2024", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Salem prize now accepting nominations for 2024")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 July 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/")[#text("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The ")#link("https://en.wikipedia.org/wiki/Salem_Prize")[#text("Salem prize")]#text(" was established in 1968 and named in honor of Raphaël Salem (1898-1963), a mathematician famous notably for his deep study of the links between Fourier series and number theory and for pioneering applications of probabilistic methods to these fields. It was not awarded from 2019-2022, due to both the COVID pandemic and the death of Jean Bourgain who had been almost single-handedly administering the prize, but is ")#link("https://www.ias.edu/math/activities/salem-prize")[#text("now active again")]#text(", being administered by Akshay Ventakesh and the IAS. I chair the scientific committee for this prize, whose other members are Guy David and Mikhail Sodin. Last year, the prize was awarded to ")#link("https://www.ias.edu/math/2023-salem-prize-winners")[#text("Sarah Peluse and Julian Sahasrabudhe")]#text(".")

#text("Nominations for the 2024 Salem Prize ")#link("https://www.mathprograms.org/db/programs/1636")[#text("are now open")]#text(" until September 1st. Nominations should include a CV of the nominee and a nomination letter explaining the significance of the nominee’s work. Supplementary documentation, such as supporting letters of recommendation or key publications, can additionally be provided, but are not required.")

#text("Nominees may be individuals from any country or institution. Preference will be given to nominees who have received their PhD in the last ten years, although this rule may be relaxed if there are mitigating personal circumstances, or if there have been few Salem prize winners in recent years. Self-nominations will not be considered, nor are past Prize winners or Scientific Committee members eligible.")

#text("The prize does not come with a direct monetary award, but winners will be invited to visit the IAS and to give a lecture associated with the award of the prize.")

#text("See also ")#link("https://terrytao.wordpress.com/2023/06/21/salem-prize-now-accepting-nominations/")[#text("the previous year’s announcement")]#text(" of the Salem prize nomination period.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (22)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-685263")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2024")])]

#text("I nominate Hong Wang.")

#emph[#text("[Formal nominations can be made at ")#link("https://www.mathprograms.org/db/programs/1636")[#text("https://www.mathprograms.org/db/programs/1636")]#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-685264")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2024")])]

#text("Is there a link between Salem numbers and Fourier series?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-685270")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2024")])]

#text("Salem showed that if ")#mi("\\tau")#text(" is a Salem number, then the fractional parts of the powers ")#mi("\\tau^n")#text(" mod 1 are dense, but not uniformly distributed; their distribution is in fact a sort of random Fourier series (the sum of independent cosines of uniform random variables). Because of this phenomenon, Fourier transforms of various measures relating to powers of ")#mi("\\tau")#text(" or dynamical systems involving multiplication by ")#mi("\\tau")#text(", such as Bernoulli convolutions with parameter ")#mi("\\tau")#text(", tend to have unusual properties. See for instance ")#link("https://www.maths.ed.ac.uk/~chris/papers/Salem_survey220315.pdf")[#text("this survey of Smyth")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-685265")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2024")])]

#text("Prizewinners are horrendously skewed in subject matter. A definite tendency towards analytic number theorists of the ‘right’ type, adherents of Hungarian style combinatorics, and ergodic theorists.")

#text("Where are the Geometric Langlandists? Where are the algebraic numberists? Where are the integrable systemsists? The bias is real.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-685269")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2024")])]

#text("The Salem prize was founded by the widow of Raphael Salem after his death in 1963, and is explicitly tasked to award prizes in the research areas that were of interest to Salem, which broadly speaking encompass harmonic analysis, probability, and analytic number theory, as well as adjacent areas in combinatorics and dynamics. It is not intended as a prize in the general field of mathematics. There are of course ")#link("https://en.wikipedia.org/wiki/List_of_mathematics_awards")[#text("other notable mathematical prizes")]#text(" that are indeed generalist prizes, or focus on other areas of mathematics than that of the Salem prize (e.g., the ")#link("https://en.wikipedia.org/wiki/Cole_Prize")[#text("Cole Prize")]#text(" in algebra and number theory, the ")#link("https://www.ams.org/prizes-awards/paview.cgi?parent_id=34")[#text("Veblen prize")]#text(" in geometry and topology, etc.).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-685282")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2024")])]

#text("Are probability theorists also eligible for the prize? If yes I nominate Amol Aggarwal")

#emph[#text("[Formal nominations can be submitted at ")#link("https://www.mathprograms.org/db/programs/1636")[#text("https://www.mathprograms.org/db/programs/1636")]#text(" . Probability theory is certainly within the scope of the prize; for instance, Schramm and Smirnov were previous recipients of the prize. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/142e7fced4b51bdd5995004ea382c41ee231079391693c762238a52f499c206b-f379a9f99b9a196e9544261de4c285edaf0a29a5ff4ba1b18fe00e9b5c5312fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian DiZio")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-685287")[#strong[#text("Brian DiZio")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2024")])]

#text("Hi Dr. Tao. I am testing my commenting from my WordPress blog.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-685349")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2024")])]

#text("Hello Professor Tao")

#text("I am interested in mathematics. You and Shing-Tung Yau are my favorite mathematicians. I also follow the work of talented Chinese mathematicians participating in the World Mathematical Olympiad. From 2000 to 2011, there are three internationally successful mathematicians among the Chinese medalists of the World Mathematical Olympiad. Lin Chen (2011 Gold medal – Proof of Geometric Langlands 2024), and Zhiwei Yun(2000 Gold Medal- 2018 New Horizons in mathematics prize) are well-known figures in the West. But the third place is Dongyi Wei, the most talented mathematician in China at the moment, who has won the full score of the Mathematical Olympiad twice in 2008 and 2009. Please see his works in Arxiv.")

#link("https://www.imo-official.org/team_r.aspx?code=CHN&year=2008")[#text("https://www.imo-official.org/team_r.aspx?code=CHN&year=2008")]

#link("https://www.imo-official.org/team_r.aspx?code=CHN&year=2009")[#text("https://www.imo-official.org/team_r.aspx?code=CHN&year=2009")]

#link("https://www.scmp.com/news/people-culture/china-personalities/article/3268097/wei-dongyi-obsessive-peerless-china-maths-genius-who-declined-us140000-prize")[#text("https://www.scmp.com/news/people-culture/china-personalities/article/3268097/wei-dongyi-obsessive-peerless-china-maths-genius-who-declined-us140000-prize")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-685354")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2024")])]

#text("Anyway dear, in the next few years, Dongyi wei will show a brilliance that will amaze you. I just wanted to tell you early, don’t be surprised later and don’t ask each other where this friend has been so far.")

#link("https://greatwall.co.id/article/china-peking-universitys-ugliest-maths-teacher-once-thought-an-idiot-now-internet-celebrity-after-awkward-interview")[#text("https://greatwall.co.id/article/china-peking-universitys-ugliest-maths-teacher-once-thought-an-idiot-now-internet-celebrity-after-awkward-interview")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-685417")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2024")])]

#text("Hello Prof. Terence Tao")#linebreak()#text(" Now I saw the work of a good and promising mathematician from the University of Tokyo. In 2021, he won the gold medal of the World Olympiad. Now at a young age, he has also given a paper that has been praised by the great mathematicians of Japan on social networks.")#linebreak()#text(" ")#link("https://www.imo-official.org/participant_r.aspx?id=30011")[#text("https://www.imo-official.org/participant_r.aspx?id=30011")]

#link("https://arxiv.org/pdf/2407.17105")[#text("https://arxiv.org/pdf/2407.17105")]#text(" (A solution to the first Lawvere’s problem A Grothendieck topos that has a proper class many quotient topoi)")

#link("https://x.com/FumiharuKato/status/1816492897296134440?t=3u0x29t8OfQ1aon9u3ek1w&s=19")[#text("https://x.com/FumiharuKato/status/1816492897296134440?t=3u0x29t8OfQ1aon9u3ek1w&s=19")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-685418")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2024")])]

#text("Yuhi Kamio")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-685423")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2024")])]

#text("Twitter page close to Shinichi Mochizuki about Yuhi Kamio’s article")

#link("https://x.com/GeMoChi08/status/1817555512130671080?t=HX7YCs8X-0rCR_2GXFCo3w&s=19")[#text("https://x.com/GeMoChi08/status/1817555512130671080?t=HX7YCs8X-0rCR_2GXFCo3w&s=19")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-685362")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2024")])]

#text("Dear Dr Tao")

#text("The new work of Shinichi Mochizuki and Hoshi will be completed in the next few months before 2025. According to him, you will see the solutions to most of the number theory questions that you never thought you would see in your lifetime and you wish to see their solutions in your lifetime. Shinichi Mochizuki is developing the theory of IUTT. I think Mochizuki is a suitable mathematician for any award in mathematics.")

#link("https://x.com/math_jin/status/1811837453294358732?t=3_ogy3dAFPuNSoQVcR0-Rg&s=19")[#text("https://x.com/math_jin/status/1811837453294358732?t=3_ogy3dAFPuNSoQVcR0-Rg&s=19")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-685363")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2024")])]

#text("Why are comments agreeing with logic here being disliked?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-685364")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2024")])]

#text("Prof. Dr. Tao")

#text("just saw the list of awards of the legendary mathematician Shing-Tung Yau. Salem prize is not allowed among them. In his opinion, his name is also a very good option to give value to any award. Let’s not forget that he has an h index of 124 in the branches of geometry such as differential geometry, algebraic geometry and even algebraic topology (your weak point in math). Again, let’s not forget that he won the Fields Medal for the two-page proof of the Calabi conjecture. I nominate Shing-Tung Yau.")

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-685365")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2024")])]

#text("Dr Tao")

#text("if you want to give an award to a young and intelligent Japanese mathematician, I suggest Yasuhiro Wakabayashi. In my opinion, he is Shinichi Mochizuki’s most intelligent student. The complexity of their mathematical knowledge is from the future.")

#link("http://math.ist.osaka-u.ac.jp/course/course_wakabayashiyasuhiro/")[#text("http://math.ist.osaka-u.ac.jp/course/course_wakabayashiyasuhiro/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-685415")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2024")])]

#text("Hello Dr Tao")

#text("Dennis Gaitsgory is a great mathematician. It is very interesting that in the best works of modern mathematics, the number of references to Dennis Gaitsgory is very interesting ( ")#link("https://www.math.ias.edu/~akshay/research/BZSVpaperV1.pdf")[#text("https://www.math.ias.edu/~akshay/research/BZSVpaperV1.pdf")]#text(" ). Anyway, right now I think Dennis Gaitsgory, Shinichi Mochizuki and Andrew Wiles are the best mathematicians out there. He is very attractive. He explains the difficult subjects of mathematics very attractively and easily and he enjoys explaining them. (Mochizuki’s weakness).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-685453")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2024")])]

#text("But with all these talks and research and familiarity with different branches of mathematics, by proving one of the million dollar questions, for example the Navier-Stokes equation, Terence Tao will be the best mathematician on earth by a large margin. Of course, even now he is one of the best mathematicians.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-685588")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2024")])]

#text("Are people who completed their PhD in 2014 still eligible for this year’s prize?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-685590")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2024")])]

#text("Yes. As stated on the web page, preference is given to candidates whose PhD was awarded within the last ten years (the intent being to direct the prize more towards early career researchers than mid career ones), but it is not a strict rule; in particular mitigating personal circumstances (e.g., personal reasons to leave full-time research for some extended period) can be taken into account, and we will not try to pin down the dating of the granting of the PhD at any finer level of accuracy than a year.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-685591")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2024")])]

#text("Thanks and regards")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Salem Prize now accepting nominations for 2025 | What's new")]], [#link("https://terrytao.wordpress.com/2024/07/02/salem-prize-now-accepting-nominations-for-2024/#comment-688412")[#strong[#text("Salem Prize now accepting nominations for 2025 | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2025")])]

#text("[…] also the previous year’s announcement of the Salem prize nomination […]")
]
