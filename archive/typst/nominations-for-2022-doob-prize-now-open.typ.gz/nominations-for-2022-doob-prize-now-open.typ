// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/04/07/nominations-for-2022-doob-prize-now-open/
// Converted to Typst by tao2typ: "2026-10-14T11:06:35.109952+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Nominations for 2023 Doob prize now open", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Nominations for 2023 Doob prize now open")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 April 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/04/07/nominations-for-2022-doob-prize-now-open/")[#text("https://terrytao.wordpress.com/2022/04/07/nominations-for-2022-doob-prize-now-open/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a brief announcement that the AMS is now accepting (until June 30) nominations for the 2023 ")#link("http://www.ams.org/prizes-awards/paview.cgi?parent_id=21")[#text("Joseph L. Doob Prize")]#text(", which recognizes a single, relatively recent, outstanding research book that makes a seminal contribution to the research literature, reflects the highest standards of research exposition, and promises to have a deep and long-term impact in its area. The book must have been published within the six calendar years preceding the year in which it is nominated. Books may be nominated by members of the Society, by members of the selection committee, by members of AMS editorial committees, or by publishers. (I am ")#link("http://www.ams.org/about-us/governance/committees/doob-past.html")[#text("currently on the committee for this prize")]#text(".) A list of previous winners ")#link("http://www.ams.org/prizes-awards/pabrowse.cgi?parent_id=21")[#text("may be found here")]#text(". The nomination procedure may be found at the bottom of ")#link("http://www.ams.org/prizes-awards/paview.cgi?parent_id=21")[#text("this page")]#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2022/04/07/nominations-for-2022-doob-prize-now-open/#comment-642534")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2022")])]

#text("I became a member of AMS specifically to nominate myself for several prizes, including this one. Here is my work for which I nominated myself:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://science.vporton.name/2021/10/06/algebraic-general-topology-book/")[#text("Algebraic Theory of General Topology and Discontinuous Analysis book")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ac08578e0edfc897ba8259f941762c2c4419cb63fb57bafed3975794bd8573a-78dfc549694bf79c3787425760bffa7b7a0389839d3af0e3c06010309348dcf7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam Hopkins")]], [#link("https://terrytao.wordpress.com/2022/04/07/nominations-for-2022-doob-prize-now-open/#comment-642610")[#strong[#text("Sam Hopkins")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2022")])]

#text("“The Disc Embedding Theorem” (")#link("https://doi.org/10.1093/oso/9780198841319.001.0001")[#text("https://doi.org/10.1093/oso/9780198841319.001.0001")]#text(") would be a very reasonable choice.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ac08578e0edfc897ba8259f941762c2c4419cb63fb57bafed3975794bd8573a-78dfc549694bf79c3787425760bffa7b7a0389839d3af0e3c06010309348dcf7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam Hopkins")]], [#link("https://terrytao.wordpress.com/2022/04/07/nominations-for-2022-doob-prize-now-open/#comment-642611")[#strong[#text("Sam Hopkins")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2022")])]

#text("Another reasonable choice: “Elements of ∞-Category Theory” (")#link("https://doi.org/10.1017/9781108936880")[#text("https://doi.org/10.1017/9781108936880")]#text(")")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/04/07/nominations-for-2022-doob-prize-now-open/#comment-642649")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2022")])]

#text("Please feel free to submit a formal nomination for either of these two texts for our committee to consider!")
]
]
]
