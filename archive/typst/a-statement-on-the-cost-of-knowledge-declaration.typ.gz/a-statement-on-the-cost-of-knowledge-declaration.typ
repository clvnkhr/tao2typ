// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/
// Converted to Typst by tao2typ: "2026-10-14T15:18:23.114340+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A statement on the cost of knowledge declaration", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A statement on the cost of knowledge declaration")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 February 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/")[#text("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("It has been a little over two weeks now since the protest site at ")#link("http://thecostofknowledge.com/")[#text("thecostofknowledge.com")]#text(" was set up to register declarations of non-cooperation with ")#link("http://www.reedelsevier.com/Pages/Home.aspx")[#text("Reed Elsevier")]#text(" in protest of their research publishing practices, inspired by ")#link("http://gowers.wordpress.com/2012/01/21/elsevier-my-part-in-its-downfall/")[#text("this blog post of Tim Gowers")]#text(". Awareness of the protest has certainly grown in these two weeks; ")#link("http://thecostofknowledge.com/")[#text("the number of signatories")]#text(" is now well over four thousand, across a broad array of academic disciplines, and the protest has been covered ")#link("http://michaelnielsen.org/polymath1/index.php?title=Journal_publishing_reform#The_cost_of_knowledge")[#text("by many blogs and also the mainstream media")]#text(" (e.g. ")#link("http://www.guardian.co.uk/science/2012/feb/02/academics-boycott-publisher-elsevier")[#text("the Guardian")]#text(", ")#link("http://www.economist.com/node/21545974")[#text("the Economist")]#text(", ")#link("http://www.forbes.com/sites/timworstall/2012/01/28/elseviers-publishing-model-might-be-about-to-go-up-in-smoke/")[#text("Forbes")]#text(", etc.), and even ")#link("http://gowers.wordpress.com/2012/02/08/a-more-formal-statement-about-mathematical-publishing/")[#text("by Elsevier stock analysts")]#text(". (Elsevier itself released an open letter responding to the protest ")#link("http://www.elsevier.com/wps/find/intro.cws_home/elsevieropenletter")[#text("here")]#text(".) My interpretation of events is that there was a significant amount of latent or otherwise undisclosed dissatisfaction already with the publishing practices of Elsevier (and, to a lesser extent, some other commercial academic publishers), and a desire to support alternatives such as university or society publishers, and the more recent open access journals; and that this protest (and parallel protests, such as the ")#link("http://scienceblogs.com/confessions/2012/02/around_the_web_research_works.php")[#text("movement to oppose the Research Works Act")]#text(") served to drive these feelings out into the open.")

#text("The ")#link("http://thecostofknowledge.com/")[#text("statement of the protest itself")]#text(", though, is rather brief, reflecting the improvised manner in which the site was created. A group of mathematicians including myself therefore decided to ")#link("http://gowers.files.wordpress.com/2012/02/elsevierstatementfinal.pdf")[#text("write and sign a more detailed explanation")]#text(" of why we supported this protest, giving more background and references to support our position. The 34 signatories are ")#link("http://en.wikipedia.org/wiki/Scott_Aaronson")[#text("Scott Aaronson")]#text(", ")#link("http://en.wikipedia.org/wiki/Douglas_N._Arnold")[#text("Douglas N. Arnold")]#text(", ")#link("http://en.wikipedia.org/wiki/Artur_%C3%81vila")[#text("Artur Avila")]#text(", ")#link("http://en.wikipedia.org/wiki/John_C._Baez")[#text("John Baez")]#text(", ")#link("http://www-m3.ma.tum.de/Allgemeines/FolkmarBornemann")[#text("Folkmar Bornemann")]#text(", ")#link("http://en.wikipedia.org/wiki/Danny_Calegari")[#text("Danny Calegari")]#text(", ")#link("http://research.microsoft.com/en-us/um/people/cohn/")[#text("Henry Cohn")]#text(", ")#link("http://en.wikipedia.org/wiki/Ingrid_Daubechies")[#text("Ingrid Daubechies")]#text(", ")#link("http://en.wikipedia.org/wiki/Jordan_Ellenberg")[#text("Jordan Ellenberg")]#text(", ")#link("http://www.math.uchicago.edu/~emerton/")[#text("Matthew Emerton")]#text(", ")#link("http://wavelets.ens.fr/EQUIPE/marie.htm")[#text("Marie Farge")]#text(", ")#link("http://en.wikipedia.org/wiki/David_Gabai")[#text("David Gabai")]#text(", ")#link("http://en.wikipedia.org/wiki/Timothy_Gowers")[#text("Timothy Gowers")]#text(", ")#link("http://en.wikipedia.org/wiki/Ben_J._Green")[#text("Ben Green")]#text(", ")#link("http://de.wikipedia.org/wiki/Martin_Gr%C3%B6tschel")[#text("Martin Grotschel")]#text(", ")#link("http://en.wikipedia.org/wiki/Michael_Harris")[#text("Michael Harris")]#text(", ")#link("http://en.wikipedia.org/wiki/Frederic_Helein")[#text("Frederic Helein")]#text(", ")#link("http://en.wikipedia.org/wiki/Robion_Kirby")[#text("Rob Kirby")]#text(", ")#link("http://en.wikipedia.org/wiki/Vincent_Lafforgue")[#text("Vincent Lafforgue")]#text(", ")#link("http://en.wikipedia.org/wiki/Greg_Lawler")[#text("Gregory F. Lawler")]#text(", ")#link("http://en.wikipedia.org/wiki/Randall_J._LeVeque")[#text("Randall J. LeVeque")]#text(", ")#link("http://en.wikipedia.org/wiki/Laszlo_lovasz")[#text("Laszlo Lovasz")]#text(", ")#link("http://www.math.umn.edu/~olver/")[#text("Peter J. Olver")]#text(", ")#link("http://www.maths.qmul.ac.uk/~olof/")[#text("Olof Sisask")]#text(", ")#link("http://en.wikipedia.org/wiki/Richard_Taylor_(mathematician)")[#text("Richard Taylor")]#text(", ")#link("http://en.wikipedia.org/wiki/Bernard_Teissier")[#text("Bernard Teissier")]#text(", ")#link("http://en.wikipedia.org/wiki/Burt_Totaro")[#text("Burt Totaro")]#text(", ")#link("http://en.wikipedia.org/wiki/Lloyd_Trefethen")[#text("Lloyd N. Trefethen")]#text(", ")#link("http://kyokan.ms.u-tokyo.ac.jp/~tsuboi/")[#text("Takashi Tsuboi")]#text(", ")#link("http://en.wikipedia.org/wiki/Marie-France_Vign%C3%A9ras")[#text("Marie-France Vigneras")]#text(", ")#link("http://en.wikipedia.org/wiki/Wendelin_Werner")[#text("Wendelin Werner")]#text(", ")#link("http://math.uchicago.edu/~wilkinso/")[#text("Amie Wilkinson")]#text(", ")#link("http://page.mi.fu-berlin.de/gmziegler/")[#text("Gunter M. Ziegler")]#text(", and myself. (Note that while Daubechies is current president of the ")#link("http://www.mathunion.org/")[#text("International Mathematical Union")]#text(", Lovasz is a past president, and Grotschel is the current secretary, they are signing this letter as individuals and not as representatives of the IMU. Similarly for Trefethen and Arnold (current and past president of ")#link("http://www.siam.org/")[#text("SIAM")]#text(").)")

#text("Of course, the 34 of us do not presume to speak for the remaining four thousand signatories to the protest, but I hope that our statement is somewhat representative of the position of many of its supporters.")

#text("Further discussion of this statement can be found at ")#link("http://gowers.wordpress.com/2012/02/08/a-more-formal-statement-about-mathematical-publishing/")[#text("this blog post of Tim Gowers")]#text(".")

#text("EDIT: I think it is appropriate to quote the following excerpt from our statement:")

#text("All mathematicians must decide for themselves whether, or to what extent, they wish to participate in the boycott. Senior mathematicians who have signed the boycott bear some responsibility towards junior colleagues who are forgoing the option of publishing in Elsevier journals, and should do their best to help minimize any negative career consequences.")

#text("Whether or not you decide to join the boycott, there are some simple actions that everyone can take, which seem to us to be uncontroversial:")

#enum(start: 1, 
[#text("Make sure that the final versions of all your papers, particularly new ones, are freely available online, ideally both on the ")#link("http://arxiv.org/")[#text("arXiv")]#text(" and on your home page.")],
[#text("If you are submitting a paper and there is a choice between an expensive journal and a cheap (or free) journal of the same standard, then always submit to the cheap one.")]
)

#heading(level: 1)[#text("Comments (28)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22f0c527e265ed08bd12642d5c1becf053e15382d9ea72dfe4ee2982b6db1158-15b89af7dcc74921a108c6a3119208f32d5987777eb434a392002e8a41b551da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérôme Chauvet")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-127421")[#strong[#text("Jérôme Chauvet")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2012")])]

#text("Dear Pr. Tao,")

#text("Agreed ! Making profit with scientific knowledge is rather suspicious, even un-ethical. How can a publisher make money with articles without paying neither the writer nor the reviewers and still be ethicproof? This tight link between pure knowledge and financial interests threatens the quality of knowledge itself, and it is good that the community is now becoming aware of this fact at the highest level.")

#text("Publishers like Elsevier are merely abusing scientist’s passion for their research field, who nonetheless get their rewarding in recognition and notoriety for their hardworking. Having their mind monopolized by their work, the majority of scientists do not find the strength and the energy to take care of the problem.")

#text("However, people with great influence in the science world CAN change things by turning the peer-review process into a collaborative task, rather than letting it be an industrial-like publishing process, as it is now.")

#text("A possible way to change things would be that universities get their hands back onto things. A sort of peer-reviewed arXiv would probably be the solution.")

#text("I guess it will happen someday ; it just needs time.")

#text("Best regards,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-127422")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2012")])]

#text("Congratulations! It took so many years to begin to declare openly, massively (and rather timidly) the obvious truth.")

#text("There is a striking similarity between this situation and the degradation (and then revolution), which happened in the field of academic painting, by the practice of “peer reviewing” and “publishing” of painting only in official")#linebreak()#text(" exhibitions, then classifying the painters by number of accepted paintings.")

#text("This led to the derisive term of “art pompier”, a terrible waste of creativity by a flood of mediocrity. Traditions in painting (say in analogy with geometry) were crippled by official mythology, and so on.")

#text("A brief description of this analogy has been made here: ")#link("http://arxiv.org/abs/1011.3465")[#text("Boring mathematics, artistes pompiers and impressionists")]#text(".")

#text("Well, it seems that this will change!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22f0c527e265ed08bd12642d5c1becf053e15382d9ea72dfe4ee2982b6db1158-15b89af7dcc74921a108c6a3119208f32d5987777eb434a392002e8a41b551da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérôme Chauvet")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-127425")[#strong[#text("Jérôme Chauvet")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2012")])]

#text("Hi Marius,")

#text("The comparison you do between mathematics and art is interesting,relevant and instructive. Indeed, it seems like, whatever kind of creation one considers (scioentific or artistic), abrasive patterns merge in the peer-reviewing process again if the system get managed by people craving for anything else but the very subject of the field (i.e. science or art).")

#text("The very problem is the selection of the few among the many : How can we be certain that a piece or an article bears not a certain value a priori.")

#text("Art and Science share a lot of instances of this kind : Van Gogh was considered by gallerists to be crappy art like Darwin’s theory was considered by some being fantasy.")

#text("Anyway, considering peer-reviewing in the science, the solution lies to me in the concept of peer-reviewed arXiv site. According to the art analogy, it would mean exhibiting all and every paintings ever made, but provide together a googling machine able to sort up them according to some criteria. Then “good” groups of piece of works can be peer-reviewed in realtime, discussed, arraged, etc…")

#text("But, this precludes the competition in the science world and many are not yet prepared to it!")

#text("Best regards,")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/273e81da7c69226e3a81fc1e5e1a7c7cef97aa606491b5828117e953f9e50be9-b73c2bda2d58be9fe7020cbb953e73394134ac9490b957c53fc6fa72aeb24190.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-127441")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2012")])]

#text("What I have been wondering for some time:")

#text("Why not have the Publishers offer a (small) financial compensation for editorial and refereeing tasks? This would reward those who do the actual work (the referees) and, at least to some extent mitigate the critique that publishers are making a lot of money without doing much.")

#text("Well, I could imaging all kinds of issues coming up with such a system, but is there one single argument why this is not an option?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22f0c527e265ed08bd12642d5c1becf053e15382d9ea72dfe4ee2982b6db1158-15b89af7dcc74921a108c6a3119208f32d5987777eb434a392002e8a41b551da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérôme Chauvet")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-127443")[#strong[#text("Jérôme Chauvet")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2012")])]

#text("Dear Anonymous,")

#text("The fact is, publication was primarily (back in 1900, for example) rather a collaborative work, which only had the cost of printing and diffusing information, as there was no big money to do with it. Editors and scientists made bigger money with books popularizing the science. Nowadays there are a lot of laboratories world wide having libraries to be filled up, which opens a… market.")

#text("Why are then scientists not paid for their contribution ? Because they do not “want” to, as every one still clings to the very tradition of the ancient time (i.e. we do scence for science, not for money) while publishers knows well the business stuff… But a scientist does more or less the same job as a journalist-reporter (e.g. make searchings in other countries and bring back new informations…), who on the contrary does get money for his articles.")

#text("Crazy isn’t it?")

#text("This is a question of awareness, and not a question of impossibility.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/273e81da7c69226e3a81fc1e5e1a7c7cef97aa606491b5828117e953f9e50be9-b73c2bda2d58be9fe7020cbb953e73394134ac9490b957c53fc6fa72aeb24190.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-127444")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2012")])]

#text("As a mathematician who writes 40+ referee reports per year, I personally would not mind being compensated for it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22f0c527e265ed08bd12642d5c1becf053e15382d9ea72dfe4ee2982b6db1158-15b89af7dcc74921a108c6a3119208f32d5987777eb434a392002e8a41b551da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérôme Chauvet")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-127445")[#strong[#text("Jérôme Chauvet")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2012")])]

#text("Well, I guess how much one would get would depend on one’s notoriety, but… winning, say, 500 dollars per article or referee report would bring to you 20000 dollars per year, with which you could perhaps hire someone, and write better articles the year after, and so on.")

#text("Would be sure a could thing for the research!")

#text("Best,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/273e81da7c69226e3a81fc1e5e1a7c7cef97aa606491b5828117e953f9e50be9-b73c2bda2d58be9fe7020cbb953e73394134ac9490b957c53fc6fa72aeb24190.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-127448")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2012")])]

#text("I am actually not talking about sums of this order but more like, say 50 dollars per article or so…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22f0c527e265ed08bd12642d5c1becf053e15382d9ea72dfe4ee2982b6db1158-15b89af7dcc74921a108c6a3119208f32d5987777eb434a392002e8a41b551da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérôme Chauvet")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-127454")[#strong[#text("Jérôme Chauvet")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2012")])]

#text("Paying the authors and the referees would indeed act as negative feedback upon overproduction of mediocre articles by publishers.")

#text("So yes, it should be so…")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60206d41a404eb8bdf7a9a9b59ee982ceb0d347a2c54dde08f347850691c3cc9-e1143ae1b28cbe3efaefb9e1472d91c3cfeea91b6596a3b722d64796ddc50e18.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aram")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-127587")[#strong[#text("aram")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2012")])]

#text("I’m already paid a salary. I wouldn’t want to be paid extra for my participation in refereeing and writing articles, if I knew that this would decrease access to knowledge, and slow down the advance of science.")

#text("I do think the refereeing process is overdue for change, but paying referees out of library budgets is the wrong direction to go in.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22f0c527e265ed08bd12642d5c1becf053e15382d9ea72dfe4ee2982b6db1158-15b89af7dcc74921a108c6a3119208f32d5987777eb434a392002e8a41b551da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérôme Chauvet")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-127596")[#strong[#text("Jérôme Chauvet")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2012")])]

#text("Hello aram,")

#text("The problem is well in the fact that some publishers make profit and invent business strategies to do it. It is then no longer a question of putting knowledge at disposal for researchers, but a question of earning money based on the fact people have no other choice but to go along with it. It is clearly non ethical.")

#text("Giving the benefit of sellings to authors and referees would be rather interpreted as a “regulating tax” which would allow making sure the knowledge produced by researchers is not endowed with economic value.")

#text("Best,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/25281f3e6111559b789f24c0c19ed6809ac84aee118f6361598c1295aee75652-bc925710a5b17071eeeb278474a64334c46084856941bd5d947b501a959890a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luke G")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-128968")[#strong[#text("Luke G")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2012")])]

#text("But your time spent refereeing is time spent not researching, teaching, blogging, etc. There has to be some balance between the different duties of a scholar to maximize the advancement of science. Money can be a useful way (though not the only way) to prioritize different tasks according to the benefit.")

#text("If you think of money as a way of *communicating preferences*, rather than merely a reward, you can see how useful it is in creating efficiency across different possible ways of people spending their time.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of UC(I) alumni")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-127810")[#strong[#text("UC(I) alumni")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2012")])]

#text("Why can’t you professors do the same think for undergraduate lower division text books for all majors? It makes no sense that such books are sold at exorbitant prices even though the “edit distance” of these texts are miniscule from year to year. Why only academic journals?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of UC(I) alumni")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-127811")[#strong[#text("UC(I) alumni")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2012")])]

#text("same thing*")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-127812")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2012")])]

#text("Yes, there are have been campaigns to lower textbook prices as well, for instance there was one in 2006 that my department was involved in, reported for instance at ")#link("http://www.ams.org/notices/200607/comm-textbook.pdf")[#text("http://www.ams.org/notices/200607/comm-textbook.pdf")]#text(" . (Among other things, we voted to immediately seek to replace any text that had undergone more than three revisions without major pedagogical improvement.) But the situation with textbooks is not as severe with journals because there is more genuine competition and choice in the textbook market, as opposed to journals where it is more or less necessary to subscribe to all the leading journals.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/314a82598b802a0ac84384868efe538d54c042bfc96029ee368cac89dc0f9aca-b4c5258fab169a505f1d4f6da7f19bff321a3c9ce0a8b3865287796b01dc7236.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of talegari")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-129493")[#strong[#text("talegari")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2012")])]

#text("Dear Tao,")

#text("@ But the situation with textbooks is not as severe with journals because there is more genuine competition and choice in the textbook market")

#text("imho, its the other way. On an average, a good under/grad level text in math costs about $60. Not all libraries are equipped to get a decent set of textbooks. Further, what books are bought by the library, depends upon the orientation of head/dean. If your department is oriented towards say fluid mechanics, then forget about getting to see good books on combinatorics, or number theory. Here at an university in India, $60 is my two month living expense.")

#text("It would be welcome move if profs/authors write books in open format, use GNU free license OR at least make an ecopy available (something like diestel’s graph theory book).")

#text("With sites like library.nu coming down, it’s a death knell for students like me not from a wealthy background to realise our dreams.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db448376857e6cc4029e2e47f39e6f74c9d9a1f11d00652a1e4bef71184c53c7-1e4a12a458d4ea357f8b5976706fbe13d6091a20726fc4f3dcb4141b2468174e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-133070")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2012")])]

#text("can’t you find cheaper replacement on the same or similar subjects by Indian mathematicians ?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/314a82598b802a0ac84384868efe538d54c042bfc96029ee368cac89dc0f9aca-b4c5258fab169a505f1d4f6da7f19bff321a3c9ce0a8b3865287796b01dc7236.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of talegari")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-133161")[#strong[#text("talegari")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2012")])]

#text("@ Anonymous: We are talking about making textbooks accessible to students irrespective of where the student or the author hails from. Most number of times replacements may not exist. Also, the problem I am pointing at is more generic, not just Indian students.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of UC(I) alumni")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-128009")[#strong[#text("UC(I) alumni")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2012")])]

#text("Thankyou for the effort:)!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd4bfb06bd050a989093ed573685723febc2f7fbc97be93869ddd8bab3257fc9-7fe956b9f8b7dae1686b686a0691c02b9667dd8802e8de59c9cf328efac02d71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boicote a Elsevier, Higgs e Moriond « Ars Physica")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-128176")[#strong[#text("Boicote a Elsevier, Higgs e Moriond « Ars Physica")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2012")])]

#text("[…] matemáticos como signatários, entre eles alguns famosos na internet como o Terence Tao (mais aqui) e o John Baez. O único brasileiro signatário dessa lista é o matemático do IMPA Artur Ávila. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-128181")[#strong[#text("Math 2.0 and Peer Review 2.0, or A revolution in math and science publishing just around the corner? « Researcher's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2012")]

#text("[…] with an online petition to boycott the Elsevier publishing house (see also this recent post by the Fields medalist Terence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-128840")[#strong[#text("Academic journals – a new business model coming? | Delaney Foresight")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2012")]

#text("[…] protest against Elsevier, the world’s largest scientific journal publisher, is rapidly gaining momentum since it began as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-129000")[#strong[#text("randform » Blog Archive » Tracing intellectual properties and a lockable patent archive")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2012")]

#text("[…] “protests” Sheila is probably referring to the current protests against the publisher Elsevier and the increasing discussions (see e.g. the forum math2.0) about different models for scientific […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/06ca176c2a5464f2186dfa94ec79a02e112985047ae33dcd4b5eddcacc0ee95f-991fd68827cc5cd7d3eb4023228d7b9aecaf280c489240cc464f2ab79f1b253f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KY")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-129252")[#strong[#text("KY")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2012")])]

#text("Talking with a colleague still in PhD programs, he did not seem so interested in this issue. Making a stand and raising voice against publishers is certainly doable for those with tenure track professorship already, but for some young ones, to publish as much as possible (while considering quality of course) is the priority and he/she may not want to take any journal to the other side.")

#text("In that regard, as Prof. Tao said, not necessarily taking a stand too clearly but rather just posting final accepted versions of the papers on his/her own website just to expand access to anybody interested in knowledge sounds like a really good idea. Thank you very much, Prof. Tao for always considering young mathematicians’ perspectives.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d74ec92a35d414a8a4e5993cff30f2d3d6881f701383456fd182d3a42955ba88-b3f94d9292074f5cf0d6df191b3b779ca0a193e86493b1489cd9ace4c6fbf402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M. P. Casey")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-129778")[#strong[#text("M. P. Casey")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2012")])]

#text("Hello Professor Tao,")

#text("I, and most likely other people, have been following this blog through its rss feed. It appears that, with this post, feed readers can’t parse the feed properly any more. Passing the feed through a validator:")

#link("http://feedvalidator.org/check.cgi?url=https://terrytao.wordpress.com/feed/")[#text("http://feedvalidator.org/check.cgi?url=https://terrytao.wordpress.com/feed/")]

#text("shows that there is apparently an extra character between the “i” and “n” in the word “final” in the sentence “Make sure that the final versions of all your papers…”. Removing this extra character in the xml for the feed should hopefully fix this.")

#text("I am glad that I found this post, since as a 1st year grad student, one isn’t always made aware of such issues.")

#emph[#text("[Hmm, there does not appear to be such a character in the blog post itself, so I don’t know what the issue is. Unfortunately, I can’t edit the feed directly. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d74ec92a35d414a8a4e5993cff30f2d3d6881f701383456fd182d3a42955ba88-b3f94d9292074f5cf0d6df191b3b779ca0a193e86493b1489cd9ace4c6fbf402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M. P. Casey")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-130222")[#strong[#text("M. P. Casey")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2012")])]

#text("It appears to be working now.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-133168")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2012")])]

#text("This “academic spring” could also help the mathematicians (or scientists) community to improve its practices. It is clear that we are also responsible for this situation, by example by inducing to the juniors the idea of the ")#link("http://en.wikipedia.org/wiki/Least_publishable_unit")[#text("“least publishable unit” or “salami publication”")]#text(". (I think everyone lives in a neighbourhood of a scientist who is propagating this behaviour as a success model.)")

#text("How beneficial would be if some set of outstanding mathematicians would publicly declare that LPU is bad practice, for example!")

#text("Also, how hard is it to put links to arxiv e-prints in the bibliographies? Or, at least, to cite properly a paper from arxiv, instead of “author x, title y, arxiv preprint”?")

#text("And so on, there are plenty of things which can be done, maybe is a good moment to advance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/#comment-511527")[#strong[#text("La difficile transizione all’Open Access – Chiara Sabelli")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2019")]

#text("[…] E ancora il boicottaggio delle riviste Elsevier promosso dal matematico vincitore della medaglia Fields Tim Gowers. Nel 2012 Gowers dichiarò di non volere aver a che fare in nessuna forma con le riviste del gruppo Reed Elsevier, né come autore, né come membro dell’editorial board, né come revisore, spiegando le sue ragioni in questo blog post. La presa di posizione di Gowers ispirò altri matematici e nacque così la pagina The Cost of Knowledge, dove si può sottoscrivere pubblicamente il manifesto di opposizione alle pratiche di Elsevier. Tra i sottoscrittori arrivò presto un’altra medaglia Fields, Terrence Tao. […]")
]
