// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:36:25.578618+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Szemeredi-Trotter theorem via the polynomial ham sandwich theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Szemeredi-Trotter theorem via the polynomial ham sandwich theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 February 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/")[#text("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://en.wikipedia.org/wiki/Ham_sandwich_theorem")[#text("ham sandwich theorem")]#text(" asserts that, given ")#mi("{d}")#text(" bounded open sets ")#mi("{U_1,\\ldots,U_d}")#text(" in ")#mi("{{\\bf R}^d}")#text(", there exists a hyperplane ")#mi("{\\{ x \\in {\\bf R}^d: x \\cdot v = c \\}}")#text(" that bisects each of these sets ")#mi("{U_i}")#text(", in the sense that each of the two half-spaces ")#mi("{\\{ x \\in {\\bf R}^d: x \\cdot v < c \\}, \\{ x \\in {\\bf R}^d: x \\cdot v > c \\}}")#text(" on either side of the hyperplane captures exactly half of the volume of ")#mi("{U_i}")#text(". The shortest proof of this result proceeds by invoking the ")#link("http://en.wikipedia.org/wiki/Borsuk%E2%80%93Ulam_theorem")[#text("Borsuk-Ulam theorem")]#text(".")

#text("A useful generalisation of the ham sandwich theorem is the ")#emph[#text("polynomial ham sandwich theorem")]#text(", which asserts that given ")#mi("{m}")#text(" bounded open sets ")#mi("{U_1,\\ldots,U_m}")#text(" in ")#mi("{{\\bf R}^d}")#text(", there exists a hypersurface ")#mi("{\\{ x \\in {\\bf R}^d: Q(x)=0\\}}")#text(" of degree ")#mi("{O_d( m^{1/d} )}")#text(" (thus ")#mi("{P: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" is a polynomial of degree ")#mi("{O(m^{1/n})}")#text(" such that the two semi-algebraic sets ")#mi("{\\{ Q > 0 \\}}")#text(" and ")#mi("{\\{ Q < 0\\}}")#text(" capture half the volume of each of the ")#mi("{U_i}")#text(". (More precisely, the degree will be at most ")#mi("{D}")#text(", where ")#mi("{D}")#text(" is the first positive integer for which ")#mi("{\\binom{D+d}{d}}")#text(" exceeds ")#mi("{m}")#text(".) This theorem can be deduced from the Borsuk-Ulam theorem in the same manner that the ordinary ham sandwich theorem is (and can also be deduced directly from the ordinary ham sandwich theorem via the ")#link("http://en.wikipedia.org/wiki/Veronese_surface")[#text("Veronese embedding")]#text(").")

#text("The polynomial ham sandwich theorem is a theorem about continuous bodies (bounded open sets), but a simple limiting argument leads one to the following discrete analogue: given ")#mi("{m}")#text(" ")#emph[#text("finite")]#text(" sets ")#mi("{S_1,\\ldots,S_m}")#text(" in ")#mi("{{\\bf R}^d}")#text(", there exists a hypersurface ")#mi("{\\{ x \\in {\\bf R}^d: Q(x)=0\\}}")#text(" of degree ")#mi("{O_d( m^{1/d} )}")#text(", such that each of the two semi-algebraic sets ")#mi("{\\{ Q > 0 \\}}")#text(" and ")#mi("{\\{ Q < 0\\}}")#text(" contain at most half of the points on ")#mi("{S_i}")#text(" (note that some of the points of ")#mi("{S_i}")#text(" can certainly lie on the boundary ")#mi("{\\{Q=0\\}}")#text("). This can be iterated to give a useful cell decomposition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Cell decomposition)")]#text(" Let ")#mi("{P}")#text(" be a finite set of points in ")#mi("{{\\bf R}^d}")#text(", and let ")#mi("{D}")#text(" be a positive integer. Then there exists a polynomial ")#mi("{Q}")#text(" of degree at most ")#mi("{D}")#text(", and a decomposition")

#align(center)[#tao-fit-display[#mitex("{\\bf R}^d = \\{ Q = 0\\} \\cup C_1 \\cup \\ldots \\cup C_m")]]

#text("into the hypersurface ")#mi("{\\{Q=0\\}}")#text(" and a collection ")#mi("{C_1,\\ldots,C_m}")#text(" of cells bounded by ")#mi("{\\{P=0\\}}")#text(", such that ")#mi("{m = O_d(D^d)}")#text(", and such that each cell ")#mi("{C_i}")#text(" contains at most ")#tao-math("{O_d( \\left|P\\right|/D^d )}", block: false)#text(" points.")
]

#text("A proof is sketched in ")#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/")[#text("this previous blog post")]#text(". The cells in the argument are not necessarily connected (being instead formed by intersecting together a number of semi-algebraic sets such as ")#mi("{\\{ Q > 0\\}}")#text(" and ")#mi("{\\{Q<0\\}}")#text("), but it is a classical result (established independently by ")#link("http://www.ams.org/mathscinet-getitem?mr=34600")[#text("Oleinik-Petrovskii")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=161339")[#text("Milnor")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=200942")[#text("Thom")]#text(") that any degree ")#mi("{D}")#text(" hypersurface ")#mi("{\\{Q=0\\}}")#text(" divides ")#mi("{{\\bf R}^d}")#text(" into ")#mi("{O_d(D^d)}")#text(" connected components, so one can easily assume that the cells are connected if desired. (Incidentally, one does not need the full machinery of the results in the above cited papers – which control not just the number of components, but all the ")#link("http://en.wikipedia.org/wiki/Betti_number")[#text("Betti numbers")]#text(" of the complement of ")#mi("{\\{Q=0\\}}")#text(" – to get the bound on connected components; one can instead observe that every bounded connected component has a critical point where ")#mi("{\\nabla Q = 0}")#text(", and one can control the number of these points by Bezout’s theorem, after perturbing ")#mi("{Q}")#text(" slightly to enforce genericity, and then count the unbounded components by an induction on dimension.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" ")#metadata(none) <tao-9c844717aa8098b204b2>#text(" By setting ")#mi("{D}")#text(" as large as ")#tao-math("{O_d(\\left|P\\right|^{1/m})}", block: false)#text(", we obtain as a limiting case of the cell decomposition the fact that any finite set ")#mi("{P}")#text(" of points in ")#mi("{{\\bf R}^d}")#text(" can be captured by a hypersurface of degree ")#tao-math("{O_d(\\left|P\\right|^{1/m})}", block: false)#text(". This fact is in fact true over arbitrary fields (not just over ")#mi("{{\\bf R}}")#text("), and can be proven by a simple linear algebra argument (see e.g. ")#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/")[#text("this previous blog post")]#text("). However, the cell decomposition is more flexible than this algebraic fact due to the ability to arbitrarily select the degree parameter ")#mi("{D}")#text(".")
]

#text("The cell decomposition can be viewed as a structural theorem for arbitrary large configurations of points in space, much as the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(" can be viewed as a structural theorem for arbitrary large dense graphs. Indeed, just as many problems in the theory of large dense graphs can be profitably attacked by first applying the regularity lemma and then inspecting the outcome, it now seems that many problems in combinatorial incidence geometry can be attacked by applying the cell decomposition (or a similar such decomposition), with a parameter ")#mi("{D}")#text(" to be optimised later, to a relevant set of points, and seeing how the cells interact with each other and with the other objects in the configuration (lines, planes, circles, etc.). This strategy was spectacularly illustrated recently with ")#link("http://arxiv.org/abs/1011.4105")[#text("Guth and Katz")]#text("‘s use of the cell decomposition to resolve the Erdös distinct distance problem (up to logarithmic factors), as discussed ")#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/")[#text("in this blog post")]#text(".")

#text("In this post, I wanted to record a simpler (but still illustrative) version of this method (that I learned from Nets Katz), namely to provide yet another proof of the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di%E2%80%93Trotter_theorem")[#text("Szemerédi-Trotter")]#text(" theorem in incidence geometry:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Szemerédi-Trotter theorem)")]#text(" Given a finite set of points ")#mi("{P}")#text(" and a finite set of lines ")#mi("{L}")#text(" in ")#mi("{{\\bf R}^2}")#text(", the set of incidences ")#mi("{I(P,L):= \\{ (p,\\ell) \\in P \\times L: p \\in \\ell \\}}")#text(" has cardinality")

#align(center)[#tao-fit-display[#tao-math("\\left|I(P,L)\\right| \\ll \\left|P\\right|^{2/3} \\left|L\\right|^{2/3} + \\left|P\\right| + \\left|L\\right|.", block: true)]]
]

#text("This theorem has many short existing proofs, including one via crossing number inequalities (as ")#link("https://terrytao.wordpress.com/2007/09/18/the-crossing-number-inequality/")[#text("discussed in this previous post")]#text(") or via a slightly different type of cell decomposition (as ")#link("https://terrytao.wordpress.com/2009/06/12/the-szemeredi-trotter-theorem-and-the-cell-decomposition/")[#text("discussed here")]#text("). The proof given below is not that different, in particular, from the latter proof, but I believe it still serves as a good introduction to the polynomial method in combinatorial incidence geometry.")

#metadata(none) <tao-d20e17bf49e384537c38>

#text("Let us begin with a trivial bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Trivial bound)")]#text(" For any finite set of points ")#mi("{P}")#text(" and finite set of lines ")#mi("{L}")#text(", we have ")#tao-math("{\\left|I(P,L)\\right| \\ll \\left|P\\right| \\left|L\\right|^{1/2} + \\left|L\\right|}", block: false)#text(".")
]

#text("The slickest way to prove this lemma is by the Cauchy-Schwarz inequality. If we let ")#mi("{\\mu(\\ell)}")#text(" be the number of points ")#mi("{P}")#text(" incident to a given line ")#mi("{\\ell}")#text(", then we have")

#align(center)[#tao-fit-display[#tao-math("\\left|I(P,L)\\right| = \\sum_{\\ell \\in L} \\mu(\\ell)", block: true)]]

#text("and hence by Cauchy-Schwarz")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\ell \\in L} \\mu(\\ell)^2 \\geq \\left|I(P,L)\\right|^2 / \\left|L\\right|.", block: true)]]

#text("On the other hand, the left-hand side counts the number of triples ")#mi("{(p,p^{\\prime},\\ell) \\in P \\times P \\times L}")#text(" with ")#mi("{p,p^{\\prime} \\in \\ell}")#text(". Since two distinct points ")#mi("{p,p^{\\prime}}")#text(" determine at most one line, one thus sees that the left-hand side is at most ")#tao-math("{\\left|P\\right|^2 + \\left|I(P,L)\\right|}", block: false)#text(", and the claim follows.")

#text("Now we return to the Szemerédi-Trotter theorem, and apply the cell decomposition with some parameter ")#mi("{D}")#text(". This gives a decomposition")

#align(center)[#tao-fit-display[#mitex("{\\bf R}^2 = \\{Q=0\\} \\cup C_1 \\cup \\ldots \\cup C_m")]]

#text("into a curve ")#mi("{\\{Q=0\\}}")#text(" of degree ")#mi("{O(D)}")#text(", and at most ")#mi("{O(D^2)}")#text(" cells ")#mi("{C_1,\\ldots,C_m}")#text(", each of which contains ")#tao-math("{O(\\left|P\\right|/D^2)}", block: false)#text(" points. We can then decompose")

#align(center)[#tao-fit-display[#tao-math("\\left|I(P,L)\\right| = \\left|I(P \\cap \\{Q=0\\},L)\\right| + \\sum_{i=1}^m |I(P \\cap C_i,L)|.", block: true)]]

#text("By removing repeated factors, we may take ")#mi("{Q}")#text(" to be square-free.")

#text("Let us first deal with the incidences coming from the cells ")#mi("{C_i}")#text(". Let ")#mi("{L_i}")#text(" be the lines in ")#mi("{L}")#text(" that pass through the ")#mi("{i^{th}}")#text(" cell ")#mi("{C_i}")#text(". Clearly")

#align(center)[#tao-fit-display[#tao-math("\\left|I(P \\cap C_i,L)\\right| =\\left|I(P \\cap C_i,L_i)\\right|", block: true)]]

#text("and thus by the trivial bound")

#align(center)[#tao-fit-display[#tao-math("\\left|I(P \\cap C_i,L)\\right| \\ll \\left|P \\cap C_i\\right| \\left|L_i\\right|^{1/2} + \\left|L_i\\right| \\ll \\frac{\\left|P\\right|}{D^2} \\left|L_i\\right|^{1/2} + \\left|L_i\\right|.", block: true)]]

#text("Now we make a key observation (coming from ")#link("http://en.wikipedia.org/wiki/B%C3%A9zout's_theorem")[#text("Bezout’s theorem")]#text(": each line in ")#mi("{\\ell}")#text(" can meet at most ")#mi("{O(D)}")#text(" cells ")#mi("{C_i}")#text(", because the cells ")#mi("{C_i}")#text(" are bounded by a degree ")#mi("{D}")#text(" curve ")#mi("{\\{Q=0\\}}")#text("). Thus")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i=1}^m \\left|L_i\\right| \\ll D \\left|L\\right|", block: true)]]

#text("and hence by Cauchy-Schwarz, we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i=1}^m \\left|L_i\\right|^{1/2} \\ll D^{3/2} \\left|L\\right|^{1/2}.", block: true)]]

#text("Putting all this together, we see that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i=1}^m \\left|I(P \\cap C_i,L)\\right| \\ll D^{-1/2} \\left|P\\right| \\left|L\\right|^{1/2} + D |L|.", block: true)]]

#text("Now we turn to the incidences coming from the curve ")#mi("{\\{Q=0\\}}")#text(". Applying Bezout’s theorem again, we see that each line in ")#mi("{L}")#text(" either lies in ")#mi("{\\{Q=0\\}}")#text(", or meets ")#mi("{\\{Q=0\\}}")#text(" in ")#mi("{O(D)}")#text(" points. The latter case contributes at most ")#tao-math("{O(D \\left|L\\right|)}", block: false)#text(" incidences, so now we restrict attention to lines that are completely contained in ")#mi("{\\{Q=0\\}}")#text(". The points in the curve ")#mi("{\\{Q=0\\}}")#text(" are of two types: smooth points (for which there is a unique tangent line to the curve ")#mi("{\\{Q=0\\}}")#text(") and singular points (where ")#mi("{Q}")#text(" and ")#mi("{\\nabla Q}")#text(" both vanish). A smooth point can be incident to at most one line in ")#mi("{\\{Q=0\\}}")#text(", and so this case contributes at most ")#tao-math("{\\left|P\\right|}", block: false)#text(" incidences. So we may restrict attention to the singular points. But by one last application of Bezout’s theorem, each line in ")#mi("{L}")#text(" can intersect the zero-dimensional set ")#mi("{\\{Q=\\nabla Q = 0 \\}}")#text(" in at most ")#mi("{O(D)}")#text(" points (note that each partial derivative of ")#mi("{Q}")#text(" also has degree ")#mi("{O(D)}")#text("), giving another contribution of ")#tao-math("{O(D \\left|L\\right|)}", block: false)#text(" incidences. Putting everything together, we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left|I(P,L)\\right| \\ll D^{-1/2} \\left|P\\right| \\left|L\\right|^{1/2} + D \\left|L\\right| + \\left|P\\right|", block: true)]]

#text("for any ")#mi("{D \\geq 1}")#text(". An optimisation in ")#mi("{D}")#text(" then gives the claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" If one used the extreme case of the cell decomposition noted in Remark ")#link(<tao-9c844717aa8098b204b2>)[#text("1")]#text(", one only obtains the trivial bound")

#align(center)[#tao-fit-display[#tao-math("\\left|I(P,L)\\right| \\ll \\left|P\\right|^{1/2} \\left|L\\right| + \\left|P\\right|.", block: true)]]

#text("On the other hand, this bound holds over arbitrary fields ")#mi("{k}")#text(" (not just over ")#mi("{{\\bf R}}")#text("), and can be sharp in such cases (consider for instance the case when ")#mi("{k}")#text(" is a finite field, ")#mi("{P}")#text(" consists of all the points in ")#mi("{k^2}")#text(", and ")#mi("{L}")#text(" consists of all the lines in ")#mi("{k^2}")#text(".)")
]

#heading(level: 1)[#text("Comments (23)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mircea")]], [#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-50316")[#strong[#text("mircea")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2011")])]

#text("Dear Prof. Tao,")#linebreak()#text(" Are there higher-dimensional versions of the Trotter-Szemeridi inequality? I ask this because the ham sandwich theorem seems not to be influenced by the dimension, whereas it would seem that the T-S theorem is.")#linebreak()#text(" Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-50320")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2011")])]

#text("Yes (in principle, at least); and indeed, this is one of the advantages of the polynomial method over the other methods used to prove the Szemeredi-Trotter theorem (though the algebraic geometry can get more complicated in higher dimensions than the analysis of plane curves discussed in this post). Of course, since one can embed the plane in higher dimensions (or project a higher-dimensional incidence structure down to the plane), one needs to impose some additional non-degeneracy hypotheses in order to obtain a genuinely different higher-dimensional version of the theorem. One such theorem (in three dimensions, and assuming that not too many lines concentrate in a plane or regulus) is discussed at")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/")[#text("The Guth-Katz bound on the Erdős distance problem")]
]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-681814")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2023")])]

#text("Hello sir. I was wondering if this theorem had any applications in games (with ray tracing or binary space partition, even if very small?)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-50323")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2011")])]

#text("This is very nice! Can you deduce also the crossing lemma from the polynomial ham sandwitch theorem? (Or even the weak crossing lemma?)")

#text("There are some nice incidence and crossing problems in high dimension like: Conjecture: Let K be a 2-dimensional simplicial complex with e edges and t triangles. Then for every embedding of K into the number of crossing is at least ")#mi("Ct^4/e^3")#text(". Problem: What is the maximum number of incidences between s lines and t planes in ")#mi("R^d")#text("?")#linebreak()#text(" (Those are taken from ")#link("http://gilkalai.wordpress.com/2008/07/17/extermal-combinatorics-ii-some-geometry-and-number-theory/")[#text("http://gilkalai.wordpress.com/2008/07/17/extermal-combinatorics-ii-some-geometry-and-number-theory/")]#text(" )")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-50324")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2011")])]

#text("(In the second problem it should be ")#mi("R^4")#text("; The crux for the first conjecture is to show that when you have a simplicial complex with ")#mi("e")#text(" edges and ")#mi("100000e")#text(" triangles then when you embed it to ")#mi("R^4")#text(" you must have at least one crossing.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-50379")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2011")])]

#text("Dear Gil: I don’t see a way to use the polynomial method to bound crossing numbers in general, because the curves connecting points in a drawing are not restricted to be curves of bounded degree (and thus have no particular reason to be localised to only a small number of cells). Perhaps the method might be usable though to study crossings of restricted classes of drawings, such as drawings where the edges are straight line segments.")

#text("It would certainly be interesting to extend the method to higher-dimensional objects such as planes, but it seems that some non-trivial algebraic geometry would be needed to get sharp results.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-50397")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2011")])]

#text("Dear Terry: Doing it for the case of straight -line segments will already be interesting and having a crosing lemma for planar triangles in ")#mi("R^4")#text(" will be quite spectacular.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca264d74c3afdc1e08b2daf5d0d27ce73b6178a91464e29d3a88e4814f9fcd10-3858853065ad1cb6b8db9ea67feb2668e3e1aa33f1c1679686fb0186d3640760.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alfredo Hubard")]], [#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-50570")[#strong[#text("Alfredo Hubard")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2011")])]

#text("I think this can be done, at least to some extent. If the curves representing the edges (or hyperedges) are algebraic, with bounded complexity. Check out theorem 18 in")#linebreak()#text(" ")#link("http://arxiv.org/pdf/1102.1275v1")[#text("http://arxiv.org/pdf/1102.1275v1")]#linebreak()#text(" It is a version of the so called “same type lemma”, another way of saying “geometric Szemeredi” type result.")#linebreak()#text(" The application there is exactly of this type, a bound from below on the so called ” space crossing number” of straight line drawings of expanders in R3. The argument also gives good bounds for the crossing number of dense or random like graphs (in R2) or 2 complexes (in R4) or any other semialgebraic relation. If the graph (complex) is not dense nor random-like then something can be said with some classic extremal combinatorics but is rather weak")#linebreak()#text(" Some references:")#linebreak()#text(" Fox, Lafforgue, Gromov, Naor and Pach used another version of the same type lemma in a very similar way, I think that they also knew the lemma for semialgebraic relations.")#linebreak()#text(" Pach has several versions of it in different papers with different coauthors and applications, a very nice one to a Tverberg type theorem, Barany and Valtr coined the term (and proved one) “same type lemma” . All the versions are based on Ham Sandwiching, the particular ham sandwich type result used in BH11 and in FLGNP10 is the Yao-Yao partition, Lehec has a very nice proof the Yao Yao partition (which uses only the intermediate value theorem) and Alon was the first to use it in this combinatorial context.")#linebreak()#text(" I wonder if one can get the Katz-Guth decomposition in one stroke with the appropriate topological statement….")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nirman")]], [#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-50374")[#strong[#text("Nirman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2011")])]

#text("Dear Prof. Tao,")

#text("are there any S-T type theorems for Projective spaces, maybe just planes, at least nicely behaved ones?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-50381")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2011")])]

#text("One can obtain projective Szemeredi-Trotter theorems from affine ones simply by covering projective space by copies of affine space. (One may lose some constant factors by doing so, but this is usually not a major concern in applications.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9ec593e2c01b89a472bd5edc5c7c954da2411cd33c3fa06fdc9fda6bf6f1ed6-bac3b042971f346683630d68ecca0bcb2c3b7b3fa33229c5678c0106e814f885.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arnab")]], [#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-50386")[#strong[#text("arnab")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2011")])]

#text("Thanks! Do you know if it is possible to obtain ")#link("http://en.wikipedia.org/wiki/Beck's_theorem_(geometry)#Beck.27s_theorem")[#text("Beck’s theorem")]#text(" directly using this method, instead of going through Szemeredi-Trotter?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-50398")[#strong[#text("Weekly picks « Mathblogging.org developer.blog")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2011")]

#text("[…] Friday you could also get some classic Terry Tao exposition, in this case, how to derive the Szemerédi-Trotter Theorem via the polynomial ham sandwich […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/735100dd31344c03189dd3286bc294d681d2fd7556adac12a18fbcb944b68cc5-42cd81408e697baae438b1defa20f504fce658de69288b9e569a0d4558a153dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Misha Rudnev")]], [#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-50447")[#strong[#text("Misha Rudnev")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2011")])]

#text("Dear Terry,")

#text("The question is more about the ham sandwich, but should extend, in principle, to ST-type results (where one should be careful as to what the “lines” are, etc.) In your Proposition 1, suppose d=3. Can one now replace R^3 with a three-dimensional manifold, which is “nicely”, by way of polynomials of bounded degree, embedded in some higher dimension, like say SO3 in R^9? Basically one would like to have a cell decomposition for a point set in a manifold, rather than the Euclidean space, with the estimates being controlled by Bezout, “as if” the manifold were R^3, as much as possible regardless of the dimension in which it is embedded.")

#text("Many Thanks,")#linebreak()#text(" Misha")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-50448")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2011")])]

#text("Yes, one can do this, either by randomly projecting, say, a 3-manifold in R^9 back down to R^3, performing the cell decomposition there, and pulling back, or else modifying the proof of the polynomial ham sandwich theorem (via Borsuk-Ulam) directly. In the latter case one has to (lower) bound the ")#link("http://en.wikipedia.org/wiki/Hilbert_polynomial")[#text("Hilbert function")]#text(" of the algebraic set one is working in, but there is an extensive literature on this function (at least in the bounded degree regime).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An incidence theorem in higher dimensions « What’s new")]], [#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-50820")[#strong[#text("An incidence theorem in higher dimensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2011")])]

#text("[…] In this paper we use the polynomial Ham Sandwich method of Guth and Katz (as discussed previously on this blog) to establish higher-dimensional versions of the Szemerédi-Trotter theorem, albeit […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-89970")[#strong[#text("拓扑学奇趣之Borsuk-Ulam定理 « Fight with Infinity")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2011")]

#text("[…] The Szemerédi-Trotter theorem via the polynomial Ham Sandwich […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d75c1e506dc65356d0041c9ba11820cec5bd9dc4f51b1bfa0b6c26aa39d6149-4bb23d56be5f0bf17292f32542c2eca8123dbf53855b965bdefda6353bbcc15c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew Kahle")]], [#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-216444")[#strong[#text("Matthew Kahle")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2013")])]

#text("I am a little bit confused by the end of the argument “An optimization in $D$ then gives the claim.”")

#text("Optimizing for $D$ seems to yield something like $D \\approx L^{-1/3} P^{2/3}$.")

#text("But then plugging in gives ")#tao-fit-display[#tao-math("I(P,L) \\ll \\left|P\\right|^{2/3}L^{2/3} + P.", block: true)]

#text("This seems to prove the claim, but it is too strong. For example, consider the set of all lines through a single point.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-216466")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2013")])]

#text("Dear Matthew, one also has the constraint that D is a positive integer (in particular ")#mi("D \\geq 1")#text(") which means that the optimal value of D is more like ")#mi("L^{-1/3} P^{2/3}+1")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-236916")[#strong[#text("Polynomial partitioning: the basics (part 1) | Some Plane Truths")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")]

#text("[…] We already discussed the Elekes-Sharir framework from item (i) here, here, and here (and due to several new developments, I might write more posts about this subject soon). This series of posts surveys the polynomial partitioning technique from item (ii). Basically, this is a technique for partitioning a -dimensional Euclidean space into a small number of “well behaved” cells. While the technique was originally introduced by Guth and Katz to solve the planar distinct distances problem, it already has several additional applications and extensions: a slightly improved upper bound for the three-dimensional unit distances problem (see here and here), improved bounds for various incidence problems (e.g., see here, here, and here), an alternative proof for the existence of a spanning tree with a low crossing number, and even a new range searching algorithm. Several recent works survey the basics of polynomial partitioning such as Zeev Dvir’s survey, Larry Guth’s lecture notes, this paper by Kaplan, Matoušek, and Sharir, and this blog post by Terry Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Algebraic combinatorial geometry: the polynomial method in arithmetic combinatorics, incidence combinatorics, and number theory | What's new")]], [#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-249021")[#strong[#text("Algebraic combinatorial geometry: the polynomial method in arithmetic combinatorics, incidence combinatorics, and number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2013")])]

#text("[…] near-complete solution to the Erdos distance problem in the plane, and can be used to give a short proof of the Szemeredi-Trotter theorem. One of the aims of this survey is to try to present all of these disparate applications of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-255457")[#strong[#text("An incidence conjecture of Bourgain over fields of positive characteristic (with Hablicsek) | Quomodocumque")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2013")]

#text("[…] In other words, the only way for a big family of lines to have lots of multiple intersections is for all those lines to be contained in a plane. (In the worst case where all the lines are in a plane, the incidences between points and lines are governed by the Szemeredi-Trotter theorem.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-524332")[#strong[#text("Configurations with many incidences and no triangles – Cosmin Pohoata")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2019")]

#text("[…] theorem of Matousek (used also by Solymosi); see for instance these lecture notes of Guth or this blog post of Tao). Solymosi’s main observation is that under the additional assumption that the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52199fa021c337c1315ca742cb5f11ddbb063546fdfab7b8e3ffdfe5bf11cf1b-7c732e386466770316e978619f8228a1388b783fbcf060fc75f647127b3efab3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Freddie Manners")]], [#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/#comment-643852")[#strong[#text("Freddie Manners")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2022")])]

#text("For what it’s worth, I think you can get away without the smooth points / singular points analysis in the final paragraph of the proof.")

#text("Certainly there can be at most ")#mi("O(D)")#text(" lines ")#mi("\\ell")#text(" contained in ")#mi("\\{ Q = 0 \\}")#text(", as each one gives a divisor of ")#mi("Q")#text(" in ")#mi("\\mathbb{R}[x,y]")#text(". So you can bound the number of incidences arising from these lines crudely by ")#tao-math("O(D) \\left|P\\right|", block: false)#text(".")

#text("If ")#tao-math("\\left|L\\right| \\ge \\left|P\\right|", block: false)#text(" this gets absorbed by the existing ")#tao-math("O(D) \\left|L\\right|", block: false)#text(" and the the final optimization is not affected. If ")#tao-math("\\left|P\\right| \\ge \\left|L\\right|", block: false)#text(", apply the theorem with the roles of ")#mi("P")#text(" and ")#mi("L")#text(" reversed.")
]
