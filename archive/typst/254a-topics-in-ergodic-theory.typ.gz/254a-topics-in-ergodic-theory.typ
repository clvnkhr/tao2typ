// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/12/14/254a-topics-in-ergodic-theory/
// Converted to Typst by tao2typ: "2026-10-14T16:35:06.775963+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A: Topics in Ergodic Theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A: Topics in Ergodic Theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 December 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/12/14/254a-topics-in-ergodic-theory/")[#text("https://terrytao.wordpress.com/2007/12/14/254a-topics-in-ergodic-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Next quarter, starting on Wednesday January 9, I will be teaching a graduate course entitled “")#link("http://www.math.ucla.edu/~tao/254a.1.08w/")[#text("Topics in Ergodic Theory")]#text("“. As an experiment, I have decided to post my lecture notes on this blog as the course progresses, as it seems to be a good medium to encourage feedback and corrections. (On the other hand, I expect that my frequency of posting on non-ergodic theory topics is going to go down substantially during this quarter.) All of my class posts will be prefaced with the course number, 254A, and will be placed in their ")#link("https://terrytao.wordpress.com/tag/254a-ergodic-theory/")[#text("own special category")]#text(".")

#text("The topics I plan to cover include")

#list(
[#text("Topological dynamics;")],
[#text("Classical ergodic theorems;")],
[#text("The Furstenberg-Zimmer structure theory of measure preserving systems;")],
[#text("Multiple recurrence theorems, and the connections with Szemerédi-type theorems;")],
[#text("Orbits in homogeneous spaces (and in particular, in nilmanifolds);")],
[#text("(Special cases of) Ratner’s theorem, and applications to number theory (e.g. the Oppenheim conjecture).")]
)

#text("If time allows I will cover some other topics in ergodic theory as well (I haven’t decided yet exactly which ones to discuss yet, and might be willing to entertain some suggestions in this regard.)")

#text("If this works out well then I plan to also do the same for my spring class, in which I will cover as much of Perelman’s proof of the Poincaré conjecture as I can manage. (Note though that this latter class will build upon a class on Ricci flow given by my colleague ")#link("http://www.math.ucla.edu/~wylie/")[#text("William Wylie")]#text(" in the winter quarter, which will thus be a ")#emph[#text("de facto")]#text(" prerequisite for my spring course.)")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/14/254a-topics-in-ergodic-theory/#comment-20485")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2007")])]

#text("Hello,")

#text("Ratner’s theorem is quite different from the other theme of your course. The only connection I see is that both apply to NT. That’s the reason for the choice ?")

#text("A")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/14/254a-topics-in-ergodic-theory/#comment-20487")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2007")])]

#text("Dear Anonymous,")

#text("I am planning to focus mainly on Ratner’s theorem for nilmanifolds, which does have some connections to Furstenberg’s multiple recurrence theorem due to the emergence of nilmanifolds as characteristic factors for this type of multiple ergodic average. Of course, the real applications of Ratner’s theorem are for more sophisticated homogeneous spaces than nilmanifolds; I haven’t yet decided how much of those I will cover.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/12/14/254a-topics-in-ergodic-theory/#comment-20507")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2007")])]

#text("Hi Terence,")

#text("Two questions about ergodic theory possibly relating to other mathematical concepts:")

#text("1 – Is there a link to the Richard Bellman concept of")#link("http://en.wikipedia.org/wiki/Dynamic_programming")[#text(" dynamic programming")]#text("?")

#text("2 – Can the 2006 Gauss prize concepts of")#link("http://www.mathunion.org/medals/2006/gauss_eng_long.pdf")[#text(" Kiyosi Itô")]#text(", stochastic analysis, be utilized as they were for explaining Brownian motion in terms of probability as opposed to randomness?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/12/14/254a-topics-in-ergodic-theory/#comment-20554")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2007")])]

#text("A more pertinent question is how the ergodic hypothesis is")#linebreak()#text(" related to the dynamics of finite systems of spherical particles,")#linebreak()#text(" where a fraction of the kinetic energy may be lost during collisions.")#linebreak()#text(" After a sufficient time such a system decouples into maximal subsystems")#linebreak()#text(" (clusters). This was officially conjectured by van der Waals in his Nobel")#linebreak()#text(" lecture (pseudoassociations) and shown by L. N. Vaserstein in Commun. Math. Phys. 69, 31-56 (1979).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ecd3505053e823752e133e50092b53322e52a28b1566e42b351cf4683bb37b5-71206d714602e6fa76e941616865d1b5606cc72b044287d8e45e6f273d56bfc0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.P.")]], [#link("https://terrytao.wordpress.com/2007/12/14/254a-topics-in-ergodic-theory/#comment-45831")[#strong[#text("J.P.")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2010")])]

#text("Hello,")

#text("Do you think any of this machinary is suited to the case of Random Walks on Groups? I’m doing an MSc on the cut-off phenomenon there and I can see the dynamical system ")#mi("\\delta^eP^n")#text(" where ")#mi("P")#text(" is the stochastic operator induced by the driving probability, ")#mi("\\nu")#text(", and ")#mi("\\delta^e")#text(" is the Dirac measure on the group identity. Of course the state space is the set of probability measures on the group, ")#mi("M_p(G)")#text(", and under mild conditions on the support of ")#mi("\\nu")#text(" the system converges to the uniform distribution, ")#mi("\\pi")#text(".")

#text("I can’t seem to put any structure on ")#mi("M_p(G)")#text(" to use any of the ideas from this ergodic theory.")

#text("I have a few obvious results that are relevent when the stochastic operator is invertible and nobody in the field seems to have considered this possibility. A sufficient condition from Gershgorin circle theorem for ")#mi("P")#text(" to be invertible is that ")#mi("\\nu(e)>1/2")#text(" and its straighforward to show that the condition on ")#mi("\\nu")#text(" for ")#mi("P")#text(" to be invertible may not be exclusively on its support; e.g. the simple walk with loops on the cube is not invertible but if we change the driving propability to be ")#mi("2/3")#text(" on the identity and ")#mi("1/9")#text(" on the basic vectors the support is the same but the stochastic operator is now invertible. I have a hunch that an invertible stochastic operator may not show this cut-off phenomenon.")

#text("OK, that would was a bit of a rant. I suppose my question is, is there any structure that can be put on ")#mi("M_p(G)")#text(" that lets any of this Ergodic Theory useful (or even on the signed probability measures)?")

#text("Also I think it is an interesting question(for its own sake), what is the condition on the driving probability for the induced stochastic operator to be invertible?")

#text("Regards,")#linebreak()#text(" J.P.")
]
