// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/09/14/structure-and-randomness-in-the-prime-numbers-imo-festschrift-submission/
// Converted to Typst by tao2typ: "2026-10-14T07:27:05.086758+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Structure and randomness in the prime numbers (IMO Festschrift submission)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Structure and randomness in the prime numbers (IMO Festschrift submission)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 September 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/09/14/structure-and-randomness-in-the-prime-numbers-imo-festschrift-submission/")[#text("https://terrytao.wordpress.com/2009/09/14/structure-and-randomness-in-the-prime-numbers-imo-festschrift-submission/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("A few months ago, ")#link("https://terrytao.wordpress.com/2009/07/20/structure-and-randomness-in-the-prime-numbers-2/")[#text("I gave a talk")]#text(" at the IMO in Bremen on “Structure and randomness in the prime numbers”. I have now converted the ")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/07/primes1.pdf")[#text("slides from that talk")]#text(" into a ")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/09/primes_paper.pdf")[#text("more traditional paper")]#text(" (7 pages in length), for submission to a Festschrift for the Bremen Olympiad. The content is much the same as the slides, but some references have been added.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/09/14/structure-and-randomness-in-the-prime-numbers-imo-festschrift-submission/#comment-41407")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2009")])]

#text("Interesting! (There’s a typo in the third paragraph of the first section)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/079cb57937093f8327931689e37fbb2200cfc232528e21aa0977888321d71bc7-f2117a98624bb427e54718daad39bba5d3b2ff5987d9b7ab60f6a074ea3be262.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manjil P. Saikia")]], [#link("https://terrytao.wordpress.com/2009/09/14/structure-and-randomness-in-the-prime-numbers-imo-festschrift-submission/#comment-41412")[#strong[#text("Manjil P. Saikia")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2009")])]

#text("Interesting, maybe the other talks like the one on Poincare Conjecture can also be made into such a format.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thuris")]], [#link("https://terrytao.wordpress.com/2009/09/14/structure-and-randomness-in-the-prime-numbers-imo-festschrift-submission/#comment-41428")[#strong[#text("Thuris")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2009")])]

#text("Thank you for posting this. Although a non-mathematician, I found it very clear. (Which gives me hope to understand some of the other posts eventually!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/53018bf07e5a84f33b3c4498318841a3daae8a59657fecec1f6466e6ad3e9045-a43fec4903f4b3dab12fdee3145a572a0b891d38a2133fdf3ebc4bbdba38c0bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hassan Mohy-ud-Din")]], [#link("https://terrytao.wordpress.com/2009/09/14/structure-and-randomness-in-the-prime-numbers-imo-festschrift-submission/#comment-41446")[#strong[#text("Hassan Mohy-ud-Din")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2009")])]

#text("Greetings Professor Terence Tao.")

#text("How be you? I am a PhD student at Johns Hopkins University. My request is that if you can kindly upload the videos of the talks/lectures along with the slides it will be very helpful and also make a tab of upcoming seminars/conferences/workshops. Thank You")

#text("Good Bye")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b83a5bcd3cfbd3197517da804244ff1c4efe35c179a7afda416081442e5d2973-3d292328ef8dbf5c4dd00be2dc2cb8138d906bf6a45bac2ee55375992bfe5a70.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xi'an")]], [#link("https://terrytao.wordpress.com/2009/09/14/structure-and-randomness-in-the-prime-numbers-imo-festschrift-submission/#comment-41451")[#strong[#text("xi'an")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2009")])]

#text("Dear Terence, there is a typo in the references: de La Vallée Poussin’s book is “Recherches analytiques sur la théorie des nombres premiers”")#linebreak()#text(" Best regards,")#linebreak()#text(" Xi’an")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7d6474433bb56dcac83ed185bc92aa4856bff0330a3cd9c42958b94f0e94d5f0-75340bd680a085224ef71cc5c6b2a23dc61761f82d9321186d74cdad5e8c2a8c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zeynel")]], [#link("https://terrytao.wordpress.com/2009/09/14/structure-and-randomness-in-the-prime-numbers-imo-festschrift-submission/#comment-41635")[#strong[#text("zeynel")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2009")])]

#text("Yes, thank you for the slides. I enjoyed reading it as a non-mathematician. In your last slide you say that primes are *mostly* odd. Does this suggest that there may be even primes except 2?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ARN")]], [#link("https://terrytao.wordpress.com/2009/09/14/structure-and-randomness-in-the-prime-numbers-imo-festschrift-submission/#comment-41639")[#strong[#text("ARN")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2009")])]

#text("Zeynel , I think that was probably a joke. There can be no even primes > 2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/09/14/structure-and-randomness-in-the-prime-numbers-imo-festschrift-submission/#comment-41642")[#strong[#text("links for 2009-09-30 « Blarney Fellow")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2009")]

#text("[…] Structure and randomness in the prime numbers (IMO Festschrift submission) « What’s new (tags: random primes math complexity computation) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6eb3d3a191875bbf14be57031ecfc18c65090385142b9eaef445331e1b239ecf-8fb2361e95b4cf3ff1d48aa5d804732a6f84b5c3963d1716a88144a5a712c0ea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Verhoeff")]], [#link("https://terrytao.wordpress.com/2009/09/14/structure-and-randomness-in-the-prime-numbers-imo-festschrift-submission/#comment-49843")[#strong[#text("Tom Verhoeff")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2011")])]

#text("The grammar seems broken in the sentence containing “to not obey behave pseudorandomly”. You can delete “obey” to fix the grammar, but probably “not” should be deleted as well to fix the semantics. This is both on the slides and in the paper.")

#emph[#text("[Thanks! I think this was fixed in the published version of the text – T.]")]
]
