// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/
// Converted to Typst by tao2typ: "2026-10-14T16:34:49.949417+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Open question: scarring for the Bunimovich stadium", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Open question: scarring for the Bunimovich stadium")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 March 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/")[#text("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("This is a well known problem (see for instance this ")#link("http://math.berkeley.edu/~zworski/bz1.pdf")[#text("survey")]#text(") in the area of “")#link("http://en.wikipedia.org/wiki/Quantum_chaos")[#text("quantum chaos")]#text("” or “quantum unique ergodicity”; I am attracted to it both for its simplicity of statement (which I will get to eventually), and also because it focuses on one of the key weaknesses in our current understanding of the Laplacian, namely is that it is difficult with the tools we know to distinguish between ")#emph[#text("eigenfunctions")]#text(" (exact solutions to ")#mi("-\\Delta u_k = \\lambda_k u_k")#text(") and ")#emph[#text("quasimodes")]#text(" (approximate solutions to the same equation), unless one is willing to work with generic energy levels rather than specific energy levels.")

#text("The ")#link("http://en.wikipedia.org/wiki/Dynamical_billiards")[#text("Bunimovich stadium")]#text(" ")#mi("\\Omega")#text(" is the name given to any planar domain consisting of a rectangle bounded at both ends by semicircles. Thus the stadium has two flat edges (which are traditionally drawn horizontally) and two round edges, as this picture from Wikipedia shows:")

#align(center)[#image("../assets/9cbc987e841234ccd3352d8d1d632c79b5f4e788f9f78c79bf293c98535a56ae-182e46916ea9003e59f3b02e10ab7d51a46207bdc6e8214df87b02b26e27e7e9.png", width: 90%, alt: "Bunimovich stadium - Wikipedia")]

#text("Despite the simple nature of this domain, the stadium enjoys some interesting classical and quantum dynamics. The classical dynamics, or ")#link("http://en.wikipedia.org/wiki/Dynamical_billiards")[#text("billiard dynamics")]#text(" on ")#mi("\\Omega")#text(" is ")#emph[#text("ergodic")]#text(" (as ")#link("http://www.ams.org/mathscinet-getitem?mr=357736")[#text("shown by Bunimovich")]#text(") but not ")#emph[#text("uniquely ergodic")]#text(". In more detail: we say the dynamics is ergodic because a billiard ball with randomly chosen initial position and velocity (as depicted above) will, over time, be uniformly distributed across the billiard (as well as in the energy surface of the phase space of the billiard). On the other hand, we say that the dynamics is not uniquely ergodic because there do exist some exceptional choices of initial position and velocity for which one does not have uniform distribution, namely the vertical trajectories in which the billiard reflects orthogonally off of the two flat edges indefinitely.")

#metadata(none) <tao-b223e57bb29df380cbbe>#text("Rather than working with (classical) individual trajectories, one can also work with (classical) ")#emph[#text("invariant ensembles")]#text(" – probability distributions in phase space which are invariant under the billiard dynamics. Ergodicity then says that (at a fixed energy) there are no invariant absolutely continuous ensemble other than the obvious one, namely the probability distribution with uniformly distributed position and velocity direction. On the other hand, unique ergodicity would say the same thing but dropping the “absolutely continuous” – but each vertical bouncing ball mode creates a singular invariant ensemble along that mode, so the stadium is not uniquely ergodic.")

#text("Now from physical considerations we expect the quantum dynamics of a system to have similar qualitative properties as the classical dynamics; this can be made precise in many cases by the mathematical theories of ")#emph[#text("semi-classical analysis")]#text(" and ")#emph[#text("microlocal analysis")]#text(". The quantum analogue of the dynamics of classical ensembles is the dynamics of the ")#link("http://en.wikipedia.org/wiki/Schr%C3%B6dinger_equation")[#text("Schrödinger equation")]#text(" ")#mi("i\\hbar \\partial_t \\psi + \\frac{\\hbar^2}{2m} \\Delta \\psi = 0")#text(", where we impose ")#link("http://en.wikipedia.org/wiki/Dirichlet_boundary_condition")[#text("Dirichlet boundary conditions")]#text(" (one can also impose ")#link("http://en.wikipedia.org/wiki/Neumann_boundary_condition")[#text("Neumann conditions")]#text(" if desired, the problems seem roughly the same). The quantum analogue of an invariant ensemble is a single eigenfunction ")#mi("-\\Delta u_k = \\lambda_k u_k")#text(", which we normalise in the usual ")#mi("L^2")#text(" manner, so that ")#tao-math("\\int_\\Omega \\left|u_k\\right|^2 = 1", block: false)#text(". (Due to the compactness of the domain ")#mi("\\Omega")#text(", the set of eigenvalues ")#mi("\\lambda_k")#text(" of the Laplacian ")#mi("-\\Delta")#text(" is discrete and goes to infinity, though there is some multiplicity arising from the symmetries of the stadium. These eigenvalues are the same eigenvalues that show up in the famous “")#link("http://en.wikipedia.org/wiki/Hearing_the_shape_of_a_drum")[#text("can you hear the shape of a drum?")]#text("” problem.) Roughly speaking, quantum ergodicity is then the statement that ")#emph[#text("almost all ")]#text("eigenfunctions are uniformly distributed in physical space (as well as in the energy surface of phase space), whereas quantum unique ergodicity (QUE) is the statement that ")#emph[#text("all ")]#text("eigenfunctions are uniformly distributed. In particular:")

#list(
[#text("If quantum ergodicity holds, then for any open subset ")#mi("A \\subset \\Omega")#text(" we have ")#tao-math("\\int_A \\left|u_k\\right|^2 \\to \\left|A\\right|/\\left|\\Omega\\right|", block: false)#text(" as ")#mi("\\lambda_k \\to \\infty")#text(", provided we exclude a set of exceptional k of density zero.")],
[#text("If quantum unique ergodicity holds, then we have the same statement as before, except that we do not need to exclude the exceptional set.")]
)

#text("(In fact, quantum ergodicity and quantum unique ergodicity say somewhat stronger things than the above two statements, but I would need tools such as ")#link("http://en.wikipedia.org/wiki/Pseudo-differential_operator")[#text("pseudodifferential operators")]#text(" to describe these more technical statements, and so I will not do so here.)")

#text("Now it turns out that for the stadium, quantum ergodicity is known to be true; this specific result was first obtained by ")#link("http://www.ams.org/mathscinet-getitem?mr=1233448")[#text("Gérard and Leichtman")]#text(", although “classical ergodicity implies quantum ergodicity” results of this type go back ")#link("http://www.ams.org/mathscinet-getitem?mr=402834")[#text("to Schnirelman")]#text(" (see also ")#link("http://www.ams.org/mathscinet-getitem?mr=1081652")[#text("Zelditch")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=819779")[#text("Colin de Verdière")]#text("). These results are established by microlocal analysis methods, which basically proceed by aggregating all the eigenfunctions together into a single object (e.g. a heat kernel, or some other function of the Laplacian) and then analysing the resulting aggregate semiclassically. It is because of this aggregation that one only gets to control almost all eigenfunctions, rather than all eigenfunctions. Here is a picture of a typical eigenfunction for the stadium (from ")#link("http://www.eng.yale.edu/stonegroup/")[#text("Douglas Stone’s page")]#text("):")

#align(center)[#image("../assets/c28a63c825a92c51c765abc0c2682f600b837e8859acfe960bea710c6489e868-08ea28527011df3c6b249e930e9fe3ea258566e2efcfe445883d4ab813188f42.gif", width: 90%, alt: "Typical stadium eigenfunction")]

#text("In analogy to the above theory, one generally expects classical unique ergodicity should correspond to QUE. For instance, there is the famous (and very difficult) ")#link("http://www.ams.org/mathscinet-getitem?mr=1266075")[#text("quantum unique ergodicity conjecture of Rudnick and Sarnak")]#text(", which asserts that QUE holds for all compact manifolds without boundary with negative sectional curvature. This conjecture will not be discussed here (it would warrant an entire post in itself, and I would not be the best placed to write it). Instead, we focus on the Bunimovich stadium. The stadium is clearly not classically uniquely ergodic due to the vertical bouncing ball modes, and so one would conjecture that it is not QUE either. In fact one conjectures the slightly stronger statement:")

#list(
[#strong[#text("Scarring conjecture")]#text(": there exists a subset ")#mi("A \\subset \\Omega")#text(" and a sequence ")#mi("u_{k_j}")#text(" of eigenfunctions with ")#mi("\\lambda_{k_j} \\to\\infty")#text(", such that ")#tao-math("\\int_A \\left|u_{k_j}\\right|^2", block: false)#text(" does ")#emph[#text("not")]#text(" converge to ")#tao-math("\\left|A\\right|/\\left|\\Omega\\right|", block: false)#text(". Informally, the eigenfunctions either concentrate (or “scar”) in A, or on the complement of A.")]
)

#text("Indeed, one expects to take A to be a union of vertical bouncing ball trajectories (from Egorov’s theorem (in microlocal analysis, not the one in real analysis), this is almost the only choice). This type of failure of QUE even in the presence of quantum ergodicity has already been observed for some simpler systems, ")#link("http://www.ams.org/mathscinet-getitem?mr=2000926")[#text("such as the Arnold cat map")]#text(". Some further discussion of this conjecture ")#link("http://www.ams.org/mathscinet-getitem?mr=2149100")[#text("can be found here")]#text(". Here are some pictures from ")#link("http://www.physik.tu-dresden.de/~baecker/")[#text("Arnd Bäcker")]#text("‘s page of some eigenfunctions (displaying just one quarter of the stadium to save space) which seem to exhibit scarring:")

#align(center)[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #text("Scarring eigenfunctions") · #link("https://i0.wp.com/www.physik.tu-dresden.de/~baecker/pictures/bbm.gif")[Original image]]]]

#text("Of course, each of these eigenfunctions has a fixed finite energy, and so these numerics do not directly establish the scarring conjecture, which is a statement about the asymptotic limit as the energy becomes infinite.")

#text("One reason this conjecture appeals to me (apart from all the gratuitous pretty pictures one can mention while discussing it) is that there is a very plausible physical argument, due ")#link("http://www.ams.org/mathscinet-getitem?mr=1188425")[#text("to Heller")]#text(" and refined ")#link("http://www.ams.org/mathscinet-getitem?mr=2051153")[#text("by Zelditch")]#text(", which indicates the conjecture is almost certainly true. Roughly speaking, it runs as follows. Using the rectangular part of the stadium, it is easy to construct (high-energy) ")#emph[#text("quasimodes of order 0")]#text(" which scar (concentrate on a proper subset A of ")#mi("\\Omega")#text(") – roughly speaking, these are solutions u to an approximate eigenfunction equation ")#mi("-\\Delta u = (\\lambda + O(1)) u")#text(" for some ")#mi("\\lambda")#text(". For instance, if the two horizontal edges of the stadium lie on the lines y=0 and y=1, then one can take ")#mi("u(x,y) = \\varphi(x) \\sin(\\pi n y)")#text(" and ")#mi("\\lambda = \\pi^2 n^2")#text(" for some large integer n and some suitable bump function ")#mi("\\varphi")#text(". Using the spectral theorem, one expects u to concentrate its energy in the band ")#mi("{}[\\pi^2 n^2 - O(1), \\pi^2 n^2 + O(1)]")#text(". On the other hand, in two dimensions the Weyl law for distribution of eigenvalues asserts that the eigenvalues have an average spacing comparable to 1. If (and this is the non-rigorous part) this average spacing also holds on a typical band ")#mi("{}[\\pi^2 n^2 - O(1), \\pi^2 n^2 + O(1)]")#text(", this shows that the above quasimode is essentially generated by only O(1) eigenfunctions. Thus, by the pigeonhole principle (or more precisely, Pythagoras’ theorem), at least one of the eigenfunctions must exhibit scarring.")

#text("[")#emph[#text("Update")]#text(", Mar 28: As Greg Kuperberg pointed out, I oversimplified the above argument. The quasimode is so weak that the eigenfunctions that comprise it could in fact spread out (as per the uncertainty principle) and fill out the whole stadium. However, if one looks in momentum space rather than physical space, the scarring of the quasimode is so strong that it must persist to one of the eigenfunctions, leading to failure of QUE even if this may not quite be detectable purely in the physical space sense described above.]")

#text("The big gap in this argument is that nobody knows how to take the Weyl law (which is proven by the microlocal analysis approach, i.e. aggregate all the eigenstates together and study the combined object) and localise it to such an extremely sparse set of narrow energy bands. (Using the standard error term in Weyl’s law one can localise to bands of width O(n) around, say, ")#mi("\\pi^2 n^2")#text(", and by using the ergodicity one can squeeze this down to o(n), but to even get control on a band of with width ")#mi("O(n^{1-\\epsilon})")#text(" would require a heroic effort (analogous to establishing a zero-free region ")#mi("\\{ s: \\text{Re}(s) > 1-\\epsilon\\}")#text(" for the Riemann zeta function). The enemy is somehow that around each energy level ")#mi("\\pi^2 n^2")#text(", a lot of exotic eigenfunctions spontaneously appear, which manage to dissipate away the bouncing ball quasimodes into a sea of quantum chaos. This is exceedingly unlikely to happen, but we do not seem to have tools available to rule it out.")

#text("One indication that the problem is not going to be entirely trivial is that one can show (basically by unique continuation or control theory arguments) that no pure eigenfunction can be solely concentrated within the rectangular portion of the stadium (where all the vertical bouncing ball modes are); a significant portion of the energy must leak out into the two “wings” (or at least into arbitrarily small neighbourhoods of these wings). This was established ")#link("http://www.ams.org/mathscinet-getitem?mr=2149100")[#text("by Burq and Zworski")]#text(".")

#text("On the other hand, the stadium is a very simple object – it is one of the simplest and most symmetric domains for which we cannot actually compute eigenfunctions or eigenvalues explicitly. It is tempting to just discard all the microlocal analysis and just try to construct eigenfunctions by brute force. But this has proven to be surprisingly difficult; indeed, despite decades of sustained study into the eigenfunctions of Laplacians (given their many applications to PDE, to number theory, to geometry, etc.) we still do not know very much about the shape and size of any ")#emph[#text("specific")]#text(" eigenfunction for a general manifold, although we know plenty about the average-case behaviour (via microlocal analysis) and also know the worst-case behaviour (by Sobolev embedding or restriction theorem type tools). This conjecture is one of the simplest conjectures which would force us to develop a new tool for understanding eigenfunctions, which could then conceivably have a major impact on many areas of analysis.")

#text("One might consider modifying the stadium in order to make scarring easier to show, for instance by selecting the dimensions of the stadium appropriately (e.g. obeying a Diophantine condition), or adding a potential or magnetic term to the equation, or perhaps even changing the metric or topology. To have even a single rigorous example of a reasonable geometric operator for which scarring occurs despite the presence of quantum ergodicity would be quite remarkable, as any such result would have to involve a method that can deal with a very rare set of special eigenfunctions in a manner quite different from the generic eigenfunction.")

#text("Actually, it is already interesting to see if one can find better quasimodes than the ones listed above which exhibit scarring, i.e. to improve the O(1) error in the spectral bandwidth. My good friend ")#link("http://math.berkeley.edu/~zworski/")[#text("Maciej Zworski")]#text(" has ")#link("http://math.berkeley.edu/~zworski/bz1.pdf")[#text("offered a dinner in a good French restaurant")]#text(" for this precise problem, as well as a dinner in a ")#emph[#text("very")]#text(" good French restaurant for the full scarring conjecture. (While I may not know as many three-star restaurants as Maciej, I can certainly offer a nice all-expenses-paid trip to sunny Los Angeles for anyone who achieves a breakthrough on any of the open problems listed here. ;-) ).")

#heading(level: 1)[#text("Comments (36)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-192")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2007")])]

#text("I am not sure whether this is a helpful suggestion for actually proving this conjecture, but let me ask whether the following stronger version appears to be the truth.")

#text("Suppose that you start with an eigenstate of a rectangle, whose Laplacian can of course be solved explicitly. Not just any eigenstate, but one whose momentum is almost entirely vertical; the horizontal quantum number is the smallest possible. Then suppose that you continuously bulge the sides of the rectangle, say by attaching half-ellipses whose horizontal semiradii grow from 0 to half the height of the rectangle. There should be a spectral flow. Do the eigenstates in question flow to counterexamples to QUE?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thomas1111")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-193")[#strong[#text("thomas1111")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2007")])]

#text("Very naive question: is there any chance to ever know about “the shape and size of specific eigenfunctions for a general manifold” since there might not be analytical ways of expressing them in closed form, except in highly non-generic cases (just like the Galois theory story for roots of polynomials) ?")

#text("(Aside comment: isn’t there a latex formula missing in the paragraph “The big gap…” after “but to even get control…”)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-194")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2007")])]

#text("NB — there may be geometrically easier ways to do the spectral flow. The question of course has both quantum and classical interpretations. You can imagine a stadium drumhead, for example. If the semicircular sides are covered with heavy rubber mats, then the drumhead reduces to a rectangle. But now you can shave rubber mats continuously until they disappear. Again, the question is whether a vertical mode flows to a scarred state.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-195")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2007")])]

#text("Dear Thomas: thanks for the correction, I think I fixed it. It is true that, like many other PDE questions, exact closed-form solutions are probably impossible. But that doesn’t necessarily prevent us from establishing more “fuzzy” properties of these solutions, such as their size in various function space norms, or how they are distributed in space, indeed much of the previous century’s work in PDE was (and still is) devoted to these sorts of questions. For instance, we understand very well how large these eigenfunctions will be in the Sobolev norms ")#mi("H^s(\\Omega) = W^{s,2}(\\Omega)")#text(", which describe the regularity of these eigenfunctions, although our understanding of the ")#mi("L^p(\\Omega)")#text(" norms, which describe the distribution of these eigenfunctions, is still far from satisfactory.")

#text("Greg: this is an interesting suggestion. There is a problem when two eigenvalues come close to colliding, at which point the spectral flow can become very unstable; a scarred state may end up switching identities with a non-scarred state that it nearly collides with (sort of a quantum version of an elastic collision). I haven’t done the requisite dimensional analysis back-of-the-envelope calculation, but I would imagine that the number of near-collisions one would experience over the lifetime of the deformation would be a positive power of the energy, making it almost hopeless to maintain control of the final state in terms of the initial state. One might hope that the effect of all these collisions cancel themselves out (some sort of quantum second law of thermodynamics), but this brings us back to the seemingly intractable problem of how to show that deterministic dynamical systems exhibit pseudorandom behaviour, which as I mentioned in the Navier-Stokes post is a basic problem which plagues a lot of modern analysis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-196")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2007")])]

#text("I would even have to learn how to do such a dimensional analysis, but even if it is unfavorable, it seems possible that the vertical modes are protected by their emergent translational symmetry. (That is, the mode locally looks more and more like f(x)sin(ky), which has a translational symmetry in the y direction.)")

#text("Life would be a little cruel if you can’t find a spectral flow that even works numerically. Spectral flow is related to one’s faith in the quasimodes in the first place.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-197")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2007")])]

#text("Greg, that’s a good point. Though the interesting thing is that the quasimode f(x) sin(ky) does not seem to be concentrated in a single pure mode, but is instead a superposition of O(1) pure modes; conversely, each pure mode consists only partly of the translation-symmetric quasimode but also has a significant fraction of chaotic junk as well. The basic problem is that in the quasimode, f(x) needs to vanish to high order near both open ends of the rectangle; however, to be a pure mode, f(x) “wants” to be an eigenfunction of ")#mi("-d^2/dx^2")#text(". These two facts are incompatible (since f of course needs to be non-zero). However, because smooth compactly supported functions have rapidly convergent Fourier series, one can express f(x) as a very rapidly convergent sum of pure modes of the interval, and so by analogy we expect something similar in the stadium.")

#text("So the spectral dynamics should not be spread out over a huge-dimensional space, but instead should be focused on some low-dimensional “cabal” of O(1) modes, which trade fragments of the quasimode between themselves. This makes things a bit more promising, though it’s still not clear how to proceed. Perhaps one approach is not to focus on a single mode but rather on the space spanned by all the relevant modes (or maybe some associated projection operator, i.e. a mixed state rather than a pure state). This may be a bit more stable than trying to evolve a single mode.")

#text("Part of the problem stems from the fact that the operator ")#mi("\\partial/\\partial y")#text(", despite appearances, does not actually commute with the Laplacian ")#mi("-\\Delta")#text(", due to effects coming from the non-horizontal portions of the boundary. One can localize that operator to within the rectangle with a cutoff function, but then it is the cutoff which doesn’t commute with the Laplacian. Indeed the uncertainty principle then forces a spectral spreading of O(1), as discussed in the main post, which by the Weyl law heuristic then incorporates a non-trivial number of pure modes (indeed, even in the rectangle, the quasimode f(x) sin ny is split up among the pure modes sin mx sin ny for m = O(1)). If one could tighten the spectral bandwidth from O(1) to o(1) then one might be in much better shape, but this is already looking difficult.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-198")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2007")])]

#text("I can’t quite tell if you’re still saying that spectral flow stories are outright false (you won’t sustain scarring) or merely difficult to prove. You could also be saying that spectral flow is a spurious model on the grounds thta whathever you could prove with it, you could also prove without it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-199")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2007")])]

#text("Oh, sorry, I read the middle paragraph more closely; I get the discussion now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-200")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2007")])]

#text("Greg, my guess is that you will have to somehow get either ")#mi("\\partial/\\partial x")#text(" or ")#mi("\\partial/\\partial y")#text(" involved in the spectral flow equation (which will force one to leave the world of single pure modes and work with more mixed objects), otherwise one will be faced with the identity switching problem.")

#text("A model case may illustrate the issue. Let A and B be two Hermitian matrices of size n, and consider their direct sum ")#mi("A \\oplus B")#text(", which is of size 2n. The spectrum of this sum is simply the union of the spectra of A and B. Now suppose we evolve A and B until one of the eigenvalues of A crosses one of the eigenvalues of B. What happens to the eigenstate of A under naive spectral flow in this case? Well, the flow becomes singular at the moment of collision.")

#text("But this is a highly non-generic case. Suppose we now add an epsilon of noise to the direct sum. This lets one avoid the codimension-2 set where eigenvalues collide; instead, the eigenvalues will bounce off of each other after getting within epsilon (or maybe square root of epsilon) of each other (the famous repulsion-of-eigenvalues effect). But then, if we evolve eigenvalues continuously, an eigenvalue which was previously close to an eigenvalue of A, would become something close to an eigenvalue of B instead after a collision; hence, an eigenstate close to an eigenstate of A will, after the collision, flow to an eigenstate close to that of B. The state which was close to that of A is now assigned to an eigenvalue ")#mi("\\lambda_k")#text(" with a different value of k, because of the crossing. There has been an identity switch.")

#text("My guess is that a numerical scheme which somehow can detect when this switching has occurred (e.g. by using the above momentum operators) may be fairly stable. As long as only O(1) pure modes are present in the spectral band of the quasimode, things should be OK. As mentioned in the main post, though, the enemy is if the special energy levels ")#mi("\\pi^2 n^2")#text(" have some very weird “attractor” property, in that many more eigenvalues get attracted to these levels than Weyl’s law would predict. One can’t have too many (more than n) in this band, as that really would contradict Weyl’s law, but with our current understanding of the error term in Weyl’s law (and even with the conjectured best bounds on this term) one still can have far too many modes in this band for comfort. This shouldn’t happen, at least for generic values of n, but I have no idea how to prove that would be the case.")

#text("Incidentally, one can phrase this problem as a question of determining how stable the method of separation of variables is in solving PDE. This method trivially lets us determine the eigenfunctions of a rectangle; why shouldn’t some variant of it still give some control on eigenfunctions of a near-rectangle?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-201")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2007")])]

#text("I certainly understand that symmetric matrices with eigenvalue multiplicity have codimension 2, that Hermitian matrices with multiplicity have codimension 3, and that spectral flow can end up permuting the eigenvalues adversarilally. These principles show up, for example, in adiabatic quantum computing.")

#text("I think that you and may agree that there could be truths about spectral flows that could make this problem easier to solve, unlike for example the Navier-Stokes question, where a variety of truths are known to make the problem harder to solve.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-202")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2007")])]

#text("Oops, you’re right; the codimension in the Hermitian case is indeed 3, not 2.")

#text("Certainly I rate this question as significantly easier than Navier-Stokes – not that that is really saying all that much. The problem here is one of linear constant coefficient elliptic PDE, rather than a nonlinear parabolic PDE, and the domain is about as simple as one can get without actually being able to get explicit closed-form solutions. The domain even has a little bit of symmetry, though this is unlikely to be terribly useful (and it does cause a minor amount of headache here, for instance many of the eigenvalues here will acquire some trivial multiplicity due to the symmetries).")

#text("Spectral flows are very pretty, but the fact that they don’t react well to eigenvalue collisions or multiplicity is somewhat disconcerting. It comes down to the fact that, from a functional calculus point of view, it doesn’t actually make much sense to talk about things like “the ")#mi("k^{th}")#text(" eigenfunction”, because this doesn’t depend smoothly on the operator when multiplicity occurs. Whereas aggregate objects such as heat kernels, resolvents, wave propagators, etc. are much more robust, and make a lot more sense from the functional calculus perspective. So we can control eigenmodes on the average by very stable and robust methods, but it isn’t obvious that we can do something similar for individual eigenmodes.")

#text("Perhaps one needs to transform the question to a very different looking question which looks more stable. For instance, it is tempting to perform a Fourier expansion inside the rectangle and a spherical harmonic expansion (i.e. a Fourier expansion in polar coordinates) in the wings. Matching the two boundaries leads to a problem which looks very vaguely like an Anderson localisation problem, which is a fairly stable phenomenon in generic cases. I played around with this a bit in the past but didn’t really get anywhere, though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-205")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2007")])]

#text("Actually there is something that I don’t quite understand about the existence argument that you credit to Heller and Zelditch. Is it supposed to apply to rectangles? At first glance, most rectangles do satisfy QUE.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-206")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2007")])]

#text("Hmm, you’re right, I oversimplified the argument a bit.")

#text("It’s true that for rectangles with irrational sidelengths, all eigenfunctions, being plane waves, are uniformly distributed in physical space. I was hiding however the full definition of QUE – one has to look at the distribution of the eigenfunctions not just in physical space, but in momentum space and more generally in phase space. The plane waves are incredibly highly concentrated in momentum space, and rectangles are not quantum ergodic (which is unsurprising given that they are also not classically ergodic).")

#text("The formal definition of quantum ergodicity and QUE is a little technical; one can ask that the Wigner transform of the eigenfunction, suitably normalised, converges weakly to the uniform distribution; or one can ask that ")#mi("\\langle a(X,D) u_k, u_k \\rangle \\to \\int a")#text(" for all pseudo-differential operators (or quantum observables, if you will) a(X,D) of order 0, where ")#mi("\\int a")#text(" is the integral of the symbol of a on the energy surface (the cosphere bundle). More informally, you want to see “quantum chaos” – the eigenfunction should be in all positions and all momenta at once.")

#text("The Heller-Zelditch argument for the rectangle would start with a quasimode, which is highly concentrated in frequency space (aka momentum space), and conclude the existence of pure modes with the same property; this would count as scarring, albeit in frequency space rather than physical space. One could pull something similar off in the stadium, provided that there are not too many eigenvalues in the relevant spectral band.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-208")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2007")])]

#text("With these remarks, I only have more trouble believing the story of out-of-control spectral flow. That story makes a lot of sense for many kinds of spectral flow, for example an overly optimistic adiabatic quantum algorithm. But in this case, suppose that you have a particle in a convex region which is somehow a pregnant rectangle. (A regular hexagon, a stadium, etc.) If a state is highly localized in momentum space, perpendicular to the parallel sides, then the pregnant regions in position space have to be blank. But if these regions are blank, then it is stable as you reshape the pregnant sides. If you execute spectral flow from a perfect rectangle, then the momentum must delocalize either fairly quickly or not at all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-211")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2007")])]

#text("Dear Greg, I suppose I should have said “concentrated” in frequency space rather than “localised”; the particle has a significant portion of its ")#mi("L^2(\\Omega)")#text(" norm located in the vertical frequency, but also a significant portion outside. Look for instance at the second and third eigenfunctions on the final image of the main post. At a PDE level, this is coming from the compatibility condition between the eigenfunction equation on the half-open rectangle (which wants to concentrate vertically) and the semicircular wings (which want to distribute the mode more evenly in phase space). Physically, I guess a quantum particle in this mode spends part of its time resonating vertically, then leaks out to bounce around arbitrarily around the stadium for a while, then returns to resonating vertically. (Of course, one can’t really use classical language to describe a mode like this, so one has to take this analogy with the usual grain of quantum salt.)")

#text("It’s because of this that I suspect that the spectral flow is going to be rather subtle. As we discussed earlier, the crossing of two eigenvalues of even two totally unrelated modes can cause a switch as long as there is even an epsilon of coupling between the dynamics of the two modes. One has to somehow restrict to the much smaller set of modes which exhibit at least some concentration in the desired vertical frequency before one would get a reasonable dynamics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-213")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2007")])]

#text("Sure, if you want me to speak quantumly: x and y momentum are commuting quantum random variables, so you may as well consider them to be classical random variables, unless you were to attempt a joint distribution with variables that they don’t commute with. (*) I agree that no eigenstate of the Hamiltonian can be completely localized in a bounded region around +k and -k in momentum space, nor even localized with exponential decay.")

#text("(*) And non-commutation with position is sufficiently gentle that there is a kind of joint distribution, the Wigner function.")

#text("However, from two of the example plots, it looks like there exist eigenstates with pretty good momentum localization, i.e., with adequate polynomial bounds. (I admit that I have no idea how good they are.) There also exist eigenstates with less good momentum localization.")

#text("I also admit that I have no idea how to rigorously prove any really good theorem in PDEs; I have no practice. That said, I’m going to provocative and conjecture that spectral flow, as you get just by changing the shape of the corral from a square to a stadium, works. I think that it can be simulated without much more difficulty than solving the Laplacian with one shape. If it is really true that the spectral flow is merely subtle and not provably anomalous, then maybe the thing to do is just try it and see. (Could that qualify as agreeing to disagree?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-214")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2007")])]

#text("Actually, I can come up with a rigorous argument as to why spectral flow won’t work. The basic problem is that spectral flow preserves the index k of the eigenvalue, which when combined with Weyl’s law will force an energy shift, whilst the quasimode stays at a roughly fixed energy.")

#text("Let A(t) be a Hermitian operator depending on a time parameter t; in this case, A(0) might be the Laplacian on the rectangle and A(1) the Laplacian on the stadium, with some continuous deformation in between. (Yeah, I know, the domains aren’t the same. We can fix this in a number of ways, e.g. conformally mapping all domains to a single reference domain, or something.) Suppose ")#mi("A(0) u_k(0) = \\lambda_k(0) u_k(0)")#text(" is the ")#mi("k^{th}")#text(" eigenvector and eigenvalue of A(0), normalised in ")#mi("L^2")#text(". If we then start spectral flow to create the time-evolved eigenvalues and eigenvectors ")#mi("\\lambda_k(t)")#text(" and ")#mi("u_k(t)")#text(", one observes that barring an actual eigenvalue collision (which is unlikely, since this is a codimension 3 set that one is trying to hit with a dimension 1 trajectory), the eigenvalue ")#mi("\\lambda_k(t)")#text(" will retain its position as the ")#mi("k^{th}")#text(" eigenvalue; for instance, we will have ")#mi("\\lambda_{k-1}(t) < \\lambda_k(t) < \\lambda_{k+1}(t)")#text(". If there is an eigenvalue collision, then of course the spectral flow becomes singular and the whole strategy is moot anyway.")

#text("Now we have Weyl’s law, which asserts that the number of eigenvalues of a Laplacian ")#mi("-\\Delta")#text(" in a domain ")#mi("\\Omega(t)")#text(" with eigenvalues less than ")#mi("\\lambda")#text(" is asymptotically ")#tao-math("\\lambda \\left|\\Omega(t)\\right|/\\pi", block: false)#text(". This implies the asymptotic ")#tao-math("\\lambda_k(t) \\sim k \\pi / \\left|\\Omega(t)\\right|", block: false)#text(".")

#text("Now let’s start the spectral flow with ")#mi("\\Omega(0)")#text(" the unit square and ")#mi("u_k(0) = \\sin(\\pi n y)")#text(", then ")#mi("\\lambda_k(0) = \\pi^2 n^2")#text(" and ")#mi("k \\sim \\pi n^2")#text(". We flow this to time 1, where ")#mi("\\Omega(1)")#text(" is now the stadium. Because spectral flow preserves k, we still have ")#mi("k \\sim \\pi n^2")#text(", so by Weyl’s law the energy has dropped to ")#tao-math("\\lambda_k(1) \\sim \\pi^2 n^2 / \\left|\\Omega(1)\\right|", block: false)#text(". But the stadium has area strictly larger than that of the square, and so the spectral flow has left one with an eigenstate of energy far lower than the energy band ")#mi("{}[\\pi^2 n^2 - O(1), \\pi^2 n^2 + O(1)]")#text(" where the quasimode ")#mi("f(x) \\sin(\\pi ny)")#text(" lives in. Thus the spectral flow has necessarily flowed away from the quasimode.")

#text("Now one can try to repair this by flowing from the stadium to a rectangle of equal area to the stadium, which would be better, but I don’t think it fixes things perfectly. The basic problem is that in order for spectral flow to work, the number of eigenvalues less than the eigenvalue of the scarred state in the stadium needs to be ")#emph[#text("exactly")]#text(" equal to the number of eigenvalues less than the eigenvalue of the scarred state in the rectangle. Due to the error term in Weyl’s law, one is unlikely to hit this number exactly on the nose.")

#text("p.s. because of the effects of the boundary of the stadium, the x and y momenta operators don’t quite commute, but it’s close enough that one can still meaningfully talk about a joint distribution as long as one doesn’t try to localise to too fine a scale (one is pretty safe as long as one tolerates uncertainties of more than O(1) in both momenta).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-215")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2007")])]

#emph[#text("Actually, I can come up with a rigorous argument as to why spectral flow won’t work. The basic problem is that spectral flow preserves the index k of the eigenvalue, which when combined with Weyl’s law will force an energy shift, whilst the quasimode stays at a roughly fixed energy.")]

#text("Sigh. I was provocative all right, but I only provoked you to rigorously disprove my thinking. :-( I agree, there is no reason to believe that the qualitative attributes of the eigenvalues are strictly compatible with their ordering.")

#text("You’re absolutely right, it takes more thought to properly select the right eigenstates under any kind of spectral flow. Even a low-dimensional space of eigenstates is not good enough, by the same ordering argument. It could perhaps be interesting if you thought of a joint spectral flow of some kind involving two or more commuting operators. It isn’t worth a numerical simulation without more thought.")

#emph[#text("p.s. because of the effects of the boundary of the stadium, the x and y momenta operators don’t quite commute")]

#text("Okay, this one is a purely semantic point, but I maintain that d/dx and d/dy do commute with each other. What you are saying is that they don’t quite commute with the Hamiltonian. That is perfectly true, but what it means is that when the Hamiltonian is definite, d/dx and d/dy have a (joint) distribution.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-216")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2007")])]

#emph[#text("Okay, this one is a purely semantic point, but I maintain that d/dx and d/dy do commute with each other. What you are saying is that they don’t quite commute with the Hamiltonian. That is perfectly true, but what it means is that when the Hamiltonian is definite, d/dx and d/dy have a (joint) distribution.")]

#text("This point confused me for a long time when I first learnt it, but just because d/dx and d/dy commute on a dense subspace of ")#mi("L^2(\\Omega)")#text(", e.g. the smooth functions supported on a compact subset of the interior, does not mean that their functional calculi commute with each other. You can see this already by thinking about the eigenfunction equations for d/dx and d/dy. (These operators are not elliptic and so don’t have discrete spectrum, but this exercise is illuminating nonetheless.) To be an eigenfunction for d/dx, the eigenfunction must look like a sine wave on each horizontal slice of the stadium. Similarly, to be an eigenfunction for d/dy, the eigenfunction must look like a sine wave on each vertical slice. Due to the funny geometry of the stadium and the Dirichlet boundary conditions, these two conditions are incompatible.")

#text("In fact there is a nice ")#link("http://www.ams.org/mathscinet-getitem?mr=470754")[#text("theorem of Fuglede")]#text(" which asserts that on a domain ")#mi("\\Omega \\subset {\\Bbb R}^d")#text(", the partial derivative operators ")#mi("\\partial/\\partial{x_1},\\ldots, \\partial/\\partial{x_d}")#text(" have a joint functional calculus if and only if ")#mi("L^2(\\Omega)")#text(" enjoys an orthonormal basis consisting entirely of (normalised) plane waves. He then conjectured that this latter condition holds if and only if ")#mi("\\Omega")#text(" tiles Euclidean space by translations (note that the stadium manifestly does not have this property, whereas the rectangle does). This conjecture was proven for convex bodies in the plane ")#link("http://www.ams.org/mathscinet-getitem?mr=2024715")[#text("by Iosevich, Katz, and myself")]#text(", but is false in higher dimensions (a ")#link("http://www.ams.org/mathscinet-getitem?mr=2067470")[#text("result of myself")]#text(", as well as one of ")#link("http://www.ams.org/mathscinet-getitem?mr=2237932")[#text("Kolountzakis and Matolcsi")]#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-217")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2007")])]

#text("My conventions are a bit different from this, but I believe that they work. Instead of looking at ")#mi("L^2(\\Omega)")#text(", I would still define ")#mi("\\partial/\\partial x_k")#text(" as operators on ")#mi("L^2({\\Bbb R}^d)")#text(". Then they do commute exactly and have a meaningful joint distribution.")

#text("Now you could object that the Hamiltonian ")#mi("H")#text(" does not make sense on this larger Hilbert space. But you can extend it to an operator whose spectrum lies in ")#mi("[0,\\infty]")#text(", by assigning infinite energy to any state outside ")#mi("\\Omega")#text(". Another way to describe ")#mi("H")#text(" is that ")#mi("\\tan^{-1} H")#text(" is a perfectly good bounded operator.")

#text("Another way to describe the momenta is that the projection from ")#mi("L^2({\\Bbb R}^d)")#text(" to ")#mi("L^2(\\Omega)")#text(" changes ")#mi("\\partial/\\partial x_k")#text(" from a Hermitian operator to a POVM (on the smaller Hilbert space, ")#mi("L^2(\\Omega)")#text("). The POVMs still commute.")

#text("Now, your operators ")#mi("\\partial/\\partial x_k")#text(" are also perfectly valid mathematically, although I think that they are not self-adjoint (or rather, non-normal) due to the boundary conditions. If so, they are technically not allowed as quantum random variables. However, you may have reason to like them better otherwise for the purpose of obtaining estimates in analysis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-218")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2007")])]

#emph[#text("The POVMs still commute.")]

#text("Sorry, argh, they probably do not. But they have a mutual refinement, a positive operator-valued measure from momentum-space ")#mi("\\mathbb{R}^d")#text(" to ")#mi("L^2(\\Omega)")#text(". That’s the real trick: POVMs don’t strictly have to commute to admit a mutual refinement.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-228")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2007")])]

#text("Is there a way to define/explain quantum ergodicity and quantum unique ergodicity in the context of graph Laplacians? (I suppose that since these are asymptotic properties they apply to sequences of graphs rather than a single graph; like the notion of expanders.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-230")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2007")])]

#text("Dear Gil, I believe the analogous notions for graph Laplacians are as follows. Let ")#mi("G_n = (V_n, E_n)")#text(" be a graph sequence of increasingly large graphs; one should probably think of these graphs as having bounded degree, with polynomial growth of metric balls, otherwise the concepts below are likely to be trivial or useless. For each fixed k, let ")#mi("\\phi_k^{(n)}: V_n \\to {\\Bbb C}")#text(" be the ")#mi("k^{th}")#text(" eigenfunction of ")#mi("G_n")#text(", normalised to have ")#mi("l^2(V_n)")#text(" norm equal to 1. Then one would say that the graph sequence is quantum uniquely ergodic if for each k, the eigenfunction density ")#tao-math("\\left|\\phi_k^{(n)}\\right|^2", block: false)#text(" is asymptotically uniformly distributed on large balls ")#mi("B(x_n,r_n)")#text(" in the graph metric, thus for arbitrary choices of ")#mi("x_n")#text(" and ")#mi("r_n")#text(" we have")

#tao-math("\\sum_{v \\in B(x_n,r_n)} \\left|\\phi_k^{(n)}(v)\\right|^2 - \\frac{\\left|B(x_n,r_n)\\right|}{\\left|V_n\\right|} \\to 0", block: false)

#text("as n goes to infinity (with k kept fixed). Quantum ergodicity would be the same statement but one would be allowed to exclude a set of k’s of density zero. For instance, a graph sequence which was disconnected with multiple components of positive density would not be quantum ergodic or quantum uniquely ergodic in the above senses.")

#text("I believe (but haven’t checked the details) that the above notions of quantum ergodicity (ignoring for now the technical distinction between physical space and phase space) correspond to the continuous notions defined above if we discretise the domain ")#mi("\\Omega")#text(" in the obvious manner, namely replacing the domain by the finite set ")#mi("\\Omega \\cap (\\frac{1}{n} \\cdot {\\Bbb Z}^2)")#text(" for some large n, and then connecting any pair of adjacent vertices in this set (separated by either a horizontal or vertical displacement of 1/n) by an edge to form the graph ")#mi("G_n")#text(".")

#text("Incidentally, there appears to be some literature on “quantum graphs”, for which notions of quantum ergodicity and quantum unique ergodicity can be defined, but this seems to be a slightly different concept.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-237")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2007")])]

#text("Thanks, Terry. Usually the graph of the discrete cube is an interesting example to look at/start with. Here, with the naive definition it has QUE because all entries of all eigenvalues are plus or minus one. I suspect that with the notion of “phase spece” you referred to, it might be decorated with many scarrs related to its faces to the extent of desrving the title “scarface”. So maybe the discrete cube is a good example to demonstrate these notions and extra subtelties.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-242")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2007")])]

#text("Dear Gil,")

#text("I don’t think I can transplant the notion of phase space properly to the graph theory setting; I would need some notion of “momentum” or “frequency” to assign to the eigenfunction, which seems to require a Riemannian geometry structure (which one needs to define the notion of a plane wave). We do have a metric coming from the graph, but it isn’t obviously Riemannian unless one adds additional structure to the graph (e.g. one embeds it into a Riemannian manifold, such as the stadium, but then we are leaving graph theory and returning to geometry). The faces are not exactly the problem; for the discretised torus one also gets eigenfunctions which are evenly distributed in physical space but are highly localised in momentum space. (I do like the term “scarface” though, I wish I could cook up some situation where I coud introduce the term naturally. :-) )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ee9cd996e9a026199313f197ecc1494d1ff85f69513b6162e84297d7002222a-ca7a02841d7c29efac5913b31cf4e883d9542febdd732eb7fd83be37dd3399df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of barry Friedman")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-480")[#strong[#text("barry Friedman")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2007")])]

#text("In the quantum case, is there some “physically observable” consequence for the existence of the scar states at “arbitrarily” high energy?")

#text("For classical billiards, such physical observables exist. For example, for the Sinai billiard, looking at the velocity autocorrelation function")#linebreak()#text(" (vacf) averaged over the microcanonical ensemble distinguishes the case of bounded and unbounded horizon. for unbounded horizon the vacf decays with a power law vs the exponential decay in the bounded horizon case. the difference in the 2 situations is the presence of arbitrarily long trajectories that don’t collide with the central obstacle. (analogous to the bouncing ball trajectories in the stadium). even though these initial conditions have zero measure, they still make themselves felt in certain averaged quantities.")

#text("Does something of this nature occur in the quantum case ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-494")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2007")])]

#text("Dear Barry,")

#text("A good question! I’m not entirely sure as to the answer. The thing is that (a) the scarred states will be very infrequent, as we know that almost all of the eigenstates do not exhibit scarring, and (b) there are also a large number of scarred quasimodes which behave physically like scarred states under either the wave equation or Schrodinger equation for bounded amounts of time, and could thus “spoof” the scarred states on these intervals. However it may be that the very long time singularity propagation behaviour of either the wave or Schrodinger equation may hinge on the existence of scarred states; if there are many such states one could imagine that a wave which is initially singular on a periodic trajectory (e.g. take a horizontal wave front moving vertically) will retain some residual version of that singularity for indefinite periods of time, whereas in the absence of scarring this singularity will eventually be “evenly distributed” across phase space, whatever that means. I don’t have a rigorous version of this statement though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dima Jakobson")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-793")[#strong[#text("Dima Jakobson")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2007")])]

#text("Hi Terry, one can define classical dynamics for graphs, this will just be a random walk. One can also define directions, just look at oriented edges (take a line graph). You can put weights on them, this will define the metric etc. You can write laplacian as d*d, where d would be the difference operator (that’s how Kirckhoff’s theorem can be proved). About uniform distribution, one should (as you suggest) take a sequence of graphs of growing size, and call it ergodic if “almost all” eigenvectors become equidistributed (as the size of the graph grows). This seems like a nice “random graph” problem. Btway, here is my favorite question about the spectrum of random regular graphs: is it simple (you are not allowed to put weights on the edges, of course)?")#linebreak()#text(" About scarring in different systems: the best understood case seems to be (quantum) cat maps, where you have both examples of scars (due to De Bievre, Faure and Nonnenmacher), and “non-scarring” results of Kurlberg-Rudnick. In the continuous case, the best chance for scarring is either Bunimovich stadium or Donnelly’s examples; in other situations (e.g. for Sinai billiard or in strictly negative curvature) you have much less chance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hassell’s proof of scarring for the Bunimovich stadium « What’s new")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-30847")[#strong[#text("Hassell’s proof of scarring for the Bunimovich stadium « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2008")])]

#text("[…] series (now long since on hiatus), I featured one of my favorite problems, namely that of establishing scarring for the Bunimovich stadium. I’m now happy to say that this problem has been solved (for generic stadiums, at least, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-35258")[#strong[#text("Michael Nielsen » Doing science online")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2009")]

#text("[…] Tao has hundreds of other posts, on topics like Perelman’s proof of the Poincare conjecture, quantum chaos, and gauge theory. Many posts contain remarkable insights, often related to open research problems, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a741897f9c44b82887e3343447f240280ac4efb25887c2097e871edb4b1195bf-b85a0645aba2bd760fcb9a0cc715264e97a0e8e9b0caff88f3e6d9c55c281e77.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-468032")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2016")])]

#text("Hope you’re still reading these – the figures on this article seem to be broken, hopefully they’re still kicking around somewhere and can be fixed.")

#emph[#text("[Unfortunately the sites linked to seem to no longer have the images. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-468076")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2016")])]

#text("Everybody can still see the images via the (Internet Archive) Wayback Machine and Terry, if you want, throught it, you can also save a copy of each of them and restore them inside this post. [Just my two cents, hope this helps.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a7dbf0fc4f87d9dd7d9265b8d742254449560def99ea67f4a0bdffbedeff30-6357b353d4083e451e5adfb16009055f7689e1058db5dc6c29d9cb3641abf55b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Baez")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-474330")[#strong[#text("John Baez")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2016")])]

#text("By the way, the picture “Scarring eigenfunctions” has disappeared from this blog post, leaving those words.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-477051")[#strong[#text("Polygonal billiards | Bahçemizi Yetiştermeliyiz")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2017")]

#text("[…] The Bunimovich stadium is an example of a dynamical system—a planar billiard, in fact, although not polygonal—which is known to be ergodic but not uniquely ergodic. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-486825")[#strong[#text("Хаос: эффект бабочки, фигуры Хладни и тайны мироздания | ТЕХНОЛОГИИ, ИНЖИНИРИНГ, ИННОВАЦИИ")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2017")]

#text("[…] Примеры профилей амплитуд колебаний в стоячих волнах в хаотических квантовых бильярдах «улитка Паскаля» и «стадион». […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b3980ad22dc765f26895663d2a9b45b69af3c948f310a52311fd194b13aeb26-6d8a5d85949bd342b0fcc3f68ab87c5e69cf21c584be8b24f774f743fef57192.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CL")]], [#link("https://terrytao.wordpress.com/2007/03/28/open-question-scarring-for-the-bunimovich-stadium/#comment-498564")[#strong[#text("CL")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2018")])]

#text("A somehow related question from a non-mathematician:")

#text("Weyl’s conjecture gives us the asymptotic distribution of the eigenvalues $\\lambda$ of the Laplace operator in a domain $\\Omega$ with homogeneous Dirichlet boundary condition on $\\partial \\Omega$.")#linebreak()#text(" According to this conjecture, the asymptotic distribution of the eigenvalues depends only on the volume and perimeter of the domain. However, I recall having read somewhere that “chaotic” domains (like billiards) support more eigenvalues in the same interval $[\\lambda_1,\\lambda_2]$ than “regular” domains (like squares, rectangles, circles etc.).")

#text("Is this qualitative, somehow vague statement true in any sense? If so, is this due to the degeneracy of some eigenvalues in regular domains, or are there other, “deeper” reasons? I have read that the statistics of the eigenvalue distribution depends on the form and the degree of “chaoticity” of the domain, so maybe this is a plausible reason. Any hint to the literature would be greatly appreciated!")
]
