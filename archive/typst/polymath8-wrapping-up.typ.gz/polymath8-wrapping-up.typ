// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/
// Converted to Typst by tao2typ: "2026-10-14T15:19:05.980458+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath8: wrapping up", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath8: wrapping up")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 June 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/")[#text("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("This should be the final thread (for now, at least) for the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8 project")]#text(" (encompassing the original ")#link("http://arxiv.org/abs/1402.0811")[#text("Polymath8a paper")]#text(", the nearly finished ")#link("https://www.dropbox.com/sh/0xb4xrsx4qmua7u/AAARQElGfSZFErLIZy9qPM-Aa/Polymath8b/newergap.pdf")[#text("Polymath8b paper")]#text(", and the ")#link("https://www.dropbox.com/sh/koxbhwvw1ysybk9/AADTJ4w3yegvgTut_Tsv0Sana/retrospective.pdf")[#text("retrospective paper")]#text("), superseding the previous ")#link("https://terrytao.wordpress.com/2014/05/17/polymath-8b-xi-finishing-up-the-paper/")[#text("Polymath8b thread")]#text(" (which was quite full) and the ")#link("https://terrytao.wordpress.com/2014/02/07/new-equidistribution-estimates-of-zhang-type-and-bounded-gaps-between-primes-and-a-retrospective/")[#text("Polymath8a/retrospective thread")]#text(" (which was more or less inactive).")

#text("On Polymath8a: I talked briefly with Andrew Granville, who is handling the paper for ")#link("http://msp.org/ant/about/journal/about.html")[#text("Algebra & Number Theory")]#text(", and he said that a referee report should be coming in soon. Apparently length of the paper is a bit of an issue (not surprising, as it is 163 pages long) and there will be some suggestions to trim the size down a bit.")

#text("In view of the length issue at A&NT, I’m now leaning towards taking up Ken Ono’s offer to submit the Polymath8b paper to the new open access journal “")#link("http://www.springer.com/mathematics/journal/40687")[#text("Research in the Mathematical Sciences")]#text("“. I think the paper is almost ready to be submitted (after the current participants sign off on it, of course), but it might be worth waiting on the Polymath8a referee report in case the changes suggested impact the 8b paper.")

#text("Finally, it is perhaps time to start working on the ")#link("https://www.dropbox.com/sh/koxbhwvw1ysybk9/AADTJ4w3yegvgTut_Tsv0Sana/retrospective.pdf")[#text("retrospective article")]#text(", and collect some impressions from participants. I wrote up a quick draft of my own experiences, and also pasted in Pace Nielsen’s thoughts, as well as a contribution from an undergraduate following the project (Andrew Gibson). Hopefully we can collect a few more (either through comments on this blog, through email, or through Dropbox), and then start working on editing them together and finding some suitable concluding points to make about the Polymath8 project, and what lessons we can take from it for future projects of this type.")

#heading(level: 1)[#text("Comments (86)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f748edb4e50bd0eb515b1d1d778ae4d6d8c3d0e9b91b0982a99ebebf1728b0b-bfedad3b1d6d2a5a826707abdb1932af9554c2ba0b223afd50147ad66d902fa2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-375713")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2014")])]

#text("I just made a final pass of Appendix A and caught a couple of minor typos that I fixed in tuples.tex — I did not recompile newergap.pdf, so the fixes will not be visible until this is done. I also double checked the bounds in Theorems 1.4 and 3.3, and they all look good. For my part I’m happy with the paper as it stands.")

#text("As far as the journal goes, Research in the Mathematical Sciences is fine by me. I don’t think they will have any issues with the length of the paper, and as a new journal I expect the time to publication will be shorter.")

#text("(BTW, the hyperlink on “Research in the Mathematical Sciences” may not be pointing where you intended – it leads to the retrospective thread).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-375746")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2014")])]

#text("A table of contents (and perhaps also a list of special notation – e.g. types of M-values) may be helpful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66eca99689997d86d6fdcace50088b42e974e7677128ca9c8f99ffb2f11ccd75-c6d63a4946106161abdb4f4977f27babe82b89a1c8383df487867e22b7ceb4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-375759")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2014")])]

#text("I’ve prepared a clean version of my optimised Pace-code; I’ll hold on to it pending the possibility of further refinements in the coming days, but I’ll upload it when there is a stable location for it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26045845f2398f9404199f4ab704f0dfd758b12a525c8cd45e1c501caeb80f1b-7949ef8c7f9f89d7856357b49c7c0e64ecd2a20e8b50cdddc710d05a469add9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-375946")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2014")])]

#text("I’ve uploaded an updated version of my retrospective. Once the file is recompiled, any and all comments or suggestions are appreciated.")

#text("I should be able to carefully re-read the polymath8b paper over the next week or so.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-376400")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2014")])]

#text("Page 58: In the line below ")#mi("b_i")#text(" definition, it should be “Hankel form” (instead of “Toeplitz form”).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2d0117ab6d8435931fc7474a057b74f4ebb9e2ef56f7067b698b125177a9cac-87cbcf9e840848e3e481e694111f026de5c1764a9a48eb3347eb3cfc36ac6434.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of interested non-expert")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-377084")[#strong[#text("interested non-expert")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2014")])]

#text("The link to the retrospective article gives a 404 error.")

#emph[#text("[Fixed, hopefully – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-377120")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2014")])]

#text("The link to the polymath8b paper (in the main page) becomes the link to the retrospective paper.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-377518")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2014")])]

#text("Now the link to the Polymath8b paper gives this error.")

#emph[#text("[Fixed, hopefully – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-377544")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2014")])]

#text("Significant news on the Polymath8a front: A&NT has now supplied a quite lengthy referee report on the 8a paper (actually a synthesis of multiple referee reports, as different sections were apparently handled by different referees), which can be found at ")#link("https://www.dropbox.com/sh/0xb4xrsx4qmua7u/AAANw1yXYBckm0Ao9aQEe-lKa/report1C.pdf")[#text("https://www.dropbox.com/sh/0xb4xrsx4qmua7u/AAANw1yXYBckm0Ao9aQEe-lKa/report1C.pdf")]#text(" . The report is broadly positive, but they do insist that the paper be shortened significantly, focusing on the most original and useful portions of the paper, and relegating the more encyclopedic portions to supplementary files (which can be placed on the A&NT web page). There is also an extensive list of corrections for each section.")

#text("Many of the corrections are minor, but there are some extensive revisions required in some areas, particularly Section 3 and (to a lesser extent) Section 4; we may need to discuss exactly how to proceed in those sections. There may also be some mathematical issues in Sections 9/10 that may need some nontrivial attention.")

#text("The revisions in Sections 5-7 look straightforward, and I will try to implement them soon. If one of the other participants is willing to help implement revisions in other sections, that would certainly be appreciated. 🙂")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-377548")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2014")])]

#text("p.s. I have spun off a copy of the Polymath8a paper at ")#link("https://www.dropbox.com/sh/0xb4xrsx4qmua7u/AACaCh2DCRRHVls485EfGz5xa/newgap-submitted.pdf")[#text("https://www.dropbox.com/sh/0xb4xrsx4qmua7u/AACaCh2DCRRHVls485EfGz5xa/newgap-submitted.pdf")]#text(" , so that we have a permanent copy of the paper that the referee reports are referring to (in case the revisions we implement in one section affect the page numbering or equation numbering in another section, before we get to the referee suggestions for that section).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-377568")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2014")])]

#text("Section 5 revisions implemented (this was the shortest section of the referee report). Will turn to Section 6 later today.")

#text("EDIT: Oops, I forgot that we had merged all the old files (heath-brown.tex, etc.) into one single huge tex file, newgap.tex. This makes it more difficult for different participants to simultaneously edit different sections. What I think I’ll do is de-merge newgap.tex back into the component files for now, and then merge them back later; it’s a little awkward, but given that we are relying on Dropbox rather than on more advanced version control software here, I don’t see a better option.")

#text("EDIT II: I’ve now split newgap.tex back into component files. This inserted some page breaks which have increased the length of the paper, so it was a good thing that I spun off the submitted file previously as otherwise the page and line references in the referee report would be hard to locate.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f748edb4e50bd0eb515b1d1d778ae4d6d8c3d0e9b91b0982a99ebebf1728b0b-bfedad3b1d6d2a5a826707abdb1932af9554c2ba0b223afd50147ad66d902fa2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-377629")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2014")])]

#text("In view of the referee comments and the concerns about length, I would suggest we simply eliminate Section 3 from the A&NT version and move Theorem 3.1 and its short (half-page) proof either to the end of Section 2 or to an appendix. Theorem 3.1 is the only part of Section 3 that is mathematically necessary; those who are interested in a broader discussion of the asymptotics and algorithms for computing narrow admissible tuples can always refer to the arXiv version.")

#text("In any case, I would suggest doing the revisions in two passes: a first pass for corrections and a second pass to edit for length. That way we could post the results of the first pass as a corrected full-length version to the arXiv.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-377733")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2014")])]

#text("This sounds like a good suggestion to me.")

#text("I implemented all the Section 6 corrections, except for the penultimate one which requires some change to the mathematics. It’s the old “")#mi("q_0")#text("” issue again – our main incomplete exponential sum estimate, Corollary 6.15, is stated under the assumption that the modulus d divides both ")#mi("d_1")#text(" and ")#mi("d_2")#text(", but when we use this corollary (in each of the non-advanced Type I/II estimates), d (which is now called ")#mi("q_0")#text(") only divides the first modulus ")#mi("d_1")#text(" and not the second. However, the proof of Corollary 6.15 as written requires d to divide both moduli. This should be fixable, but I need to check some calculations carefully.")

#text("EDIT: I made a change to the conclusion of Corollary 6.15, basically deleting the factors of d from ")#mi("\\delta_1,\\delta_2")#text(", and this seems to fix the problem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09e3c96bac2808389d664bf095c56ba0ea57aaa60f178c110a384117d60702d5-7f4d65d1706e958f7ef47f12eed02126e8555f0043cd90aefbd30a044fd96de1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-377980")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2014")])]

#text("I’ve started reading the report and I (or Philippe) will make the small changes needed for the exponential sums sections.")

#text("With the benefit of time and hindsight (and the many developpments of Polymath8b since the paper was submitted), I would like to suggest concentrating even more on the Zhang-style equidistribution theorems. Except for a few pages of historical background and context, there does not seem to me to be a very strong case for keeping (for instance) those sieve-theoretic aspects that are tuned up for the gaps, when much stronger / simpler / better bounds now exist. Doing so might lead to a significantly shorter paper whose goal and achievements would be clearer. Parts which are genuinely useful for Polymath8b would then be more usefully transfered to that second paper.")

#text("Once the basic corrections following the report(s) are made, I could try to produce a file going in this direction to see what it would look like.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-378212")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2014")])]

#text("Thanks for this! I already went through Section 6 (exponential.tex) to implement the changes there, but it may be good to have another pair of eyes take a look at the fix I had to implement on Corollary 6.16 (replacing the delta_1, delta_2 by delta’_1, delta’_2) to deal with one of the issues the referee raised there. I haven’t touched the later sections (other than some slight changes to Section 7 at each point where Corollary 6.16 is used).")

#text("You raise a good point that the sieve-theoretic portion of the paper (Section 4) is now obsolete in view of Maynard and Polymath8b; indeed neither of these papers even use the material in Section 4 of this paper. So we could slim down the 8a paper down significantly (almost 50%) by essentially ditching Sections 3,4 (and most of Section 2 and some of Section 1, such as the flowchart), establishing just the distributional estimate, and mentioning that these estimates could be used to prove the now-obsolete bound H_1 <= 4680, referring to the longer version on the arXiv for details. Whatever portions of Section 3 that are needed for Polymath8b can then be moved to that paper instead, as you say. (We'll have to proofread Polymath8b again to make sure that all references to 8a are still accurate.)")

#text("Of course, a lot of participants put a lot of effort into the portions of the paper that we are thinking of removing, but these efforts have still been valuable in either directly or indirectly inspiring the more advanced results that have superseded these portions, and we will still be able to record these efforts in full even if they only end up as a remark in the officially published writeup of the project. (Indeed, one could view the history of Polymath8 as being a continual process of superseding one’s previous results.)")

#text("I think I might go over Section 4 next; even if it is going to be removed in the published version of 8a, it will still be on the arXiv version, so we may as well still get all the corrections done there.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09e3c96bac2808389d664bf095c56ba0ea57aaa60f178c110a384117d60702d5-7f4d65d1706e958f7ef47f12eed02126e8555f0043cd90aefbd30a044fd96de1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-378268")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2014")])]

#text("I definitely agree that all corrections suggested by the referees should first be implemented before a shorter streamlined version is made, so that the arXiv version remains as a reference and is complete and correct. I will review the changes (and make corrections where someone else hasn’t yet done them) as soon as I have time. I hope I didn’t forget too much of the notation and all that…")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18ac32f1757df2128ad3a7dbe5ae836196e52ea337899648b1954fd17de88a53-604117642946f3f93e6b67fa3d6ac648db2fa29093c98f5c5b218b96551f81a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-379080")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2014")])]

#text("I could not download the report from the above link. Dropbox tells me “Nothing Here. The file you’re looking for has been deleted or moved.”")

#emph[#text("[Fixed, hopefully; the file was moved to mark off some corrections, and I saved a copy of that back to the original file. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d815cf5704012394db2ca4090a05f042432268426dc0d796b07dbe928ab0113-744df7ba6c1c283202fc26e4e29016bb9e811f40b4786bd46e580745dd5a9849.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-379087")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2014")])]

#text("The link to the referee report gives a ‘nothing here’ error for me.")

#emph[#text("[Hopefully fixed now – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/771b7023a71d63c21bea85e7a45e733c7935f9911d9796ea75f982ec57f068f3-5b2ba67e8fabc30c169d738eb46ca2768224775933f6e95d0e778df894004bcc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gaal Yahas")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-377666")[#strong[#text("Gaal Yahas")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2014")])]

#text("The abstract for the retrospective paper has")#linebreak()#text(" “[…] buth conditional and unconditional, on H_m.”")

#text("typo: buth -> both")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-377719")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2014")])]

#text("In theorem 1.5(b), can “sufficiently large” be made effective?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-377755")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2014")])]

#text("I assume you’re referring to Polymath8b (now that this thread is discussing three papers simultaneously, one probably has to specify which paper one is discussing at any given time). The answer to your question depends on whether the constants in the GEH assumption are effective. Since we don’t actually have a proof of GEH with or without effective constants, the issue is moot at present. (But given that even Bombieri-Vinogradov is not known to hold with effective constants, it is likely that the first proof of GEH will also be ineffective, so that any result relying on GEH will be very likely to be ineffective also.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f748edb4e50bd0eb515b1d1d778ae4d6d8c3d0e9b91b0982a99ebebf1728b0b-bfedad3b1d6d2a5a826707abdb1932af9554c2ba0b223afd50147ad66d902fa2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-378098")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2014")])]

#text("The m=5 bound under the 1080/13*varpi+330/13*delta < 1 constraint can been improved. We have")

#text("H(3,393,468,735) <= 78,602,310,160,")

#text("using the tuple described ")#link("http://math.mit.edu/~drew/schinzel_3393468735_78602310160.txt")[#text("here")]#text(".")

#text("This can be verified using")

#text("schinzelverify schinzel_3393468735_78602310160.txt")

#emph[#text("[Records added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-378432")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2014")])]

#text("I’ve made the Section 4 corrections (ignoring the suggestions to shorten the section, since we’re actually planning to remove it entirely). One moderately significant change (though it doesn’t affect anything outside of this section, and in any event this analysis is rendered obsolete by Maynard and Polymath8b): I made w a “sufficiently slowly” growing function of x rather than log log log x, because it was pointed out by the referee that the proof of Lemma 4.2 doesn’t quite work as stated (the o(1) decay need not be less than ")#mi("\\phi(W)/W")#text(").")

#text("On a separate note, I talked with Ken Ono who is keen to handle the 8b paper, and is promising a quick refereeing process. I guess one thing we can do to move that along is to rework Appendix A of the 8b paper to incorporate material from section 3 of Polymath8a, given that this section is going to be removed from the published version of 8a.")

#text("I’ll look at the Section 3 corrections next.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26045845f2398f9404199f4ab704f0dfd758b12a525c8cd45e1c501caeb80f1b-7949ef8c7f9f89d7856357b49c7c0e64ecd2a20e8b50cdddc710d05a469add9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-379085")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2014")])]

#text("Here are some comments on the Polymath8b paper. Most of them are just minor typos and English improvements. The only big question I have is point #12 below.")

#text("1. Page 3, line below Theorem 1.5. “who”->”which”")

#text("2. Page 11, equation (3.13). Change ")#mi("\\theta")#text(" to ")#mi("\\vartheta")#text(".")

#text("3. Page 15, statement of Theorem 3.12. Do we want to specify that ")#mi("\\vartheta")#text(" is fixed? (If so, a similar change to happen in Theorem 3.14.)")

#text("4. Page 16, statement of Theorem 3.15. The function ")#mi("F")#text(" should be said to be “fixed”.")

#text("5. Page 17, offset equation between (4.3) and (4.4). In the subscript of the sum, should there be a comma between ")#mi("W")#text(" and ")#mi("N")#text(" (like there is in (4.1))?")

#text("6. Page 26, equation (4.17). Change ")#mi("\\theta")#text(" to ")#mi("\\vartheta")#text(".")

#text("7. Page 27, equation (4.24). There should be a period at the end of the equation. The next sentence also doesn’t have to be a new paragraph.")

#text("8. Page 29, offset equation after (4.29). There is a missing ")#mi("dt")#text(".")

#text("9. Page 35, line -2 (the line directly after the offset equation). I believe that ")#mi("\\delta")#text(" should be ")#mi("\\delta_1")#text(" here.")

#text("10. Page 41, equation (6.2). There is an “ess” in the equation. Not sure why it is there.")

#text("11. Page 45, sentence after equation (6.5). There is a missing parenthesis at the end of the sentence.")

#text("12. Page 52, middle of the page when computing ")#mi("k\\mu")#text(". I admit to not following the rest of the argument, but this equality does not look correct. In particular where does the extra ")#mi("-1/\\log(k)")#text(" come from, and where did the ")#mi("-c")#text(" go?")

#text("13. Page 57. Change “maximize the quantity")#mi("C")#text("” to “maximizes the quantity ")#mi("C")#text("”. (Add a space before ")#mi("C")#text(", and an “s” to “maximize”.)")

#text("14. Page 59, last line. The web address is off the page.")

#text("15. Page 65, equation between ")#mi("J_6,J_7")#text(". When it says ")#mi("f(y,x)")#text(" it should be ")#mi("f(x,y)")#text(". [This occurs twice.]")

#emph[#text("[Corrections implemented, thanks – T>]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26045845f2398f9404199f4ab704f0dfd758b12a525c8cd45e1c501caeb80f1b-7949ef8c7f9f89d7856357b49c7c0e64ecd2a20e8b50cdddc710d05a469add9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-379342")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2014")])]

#text("On #12, I see now that somehow I just missed where ")#mi("c")#text(" was specified. The fix introduced an extraneous period.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-379469")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2014")])]

#text("In Polymath8b paper, the lower bounds ")#mi("M")#text(" in table 1 (page 54) should be sufficiently accurate (in order to imply parts of theorems 3.9 and 3.11) but in order to verify that, one needs sufficiently good upper bounds on the numerical integration errors in the calculation of the (non-elementary) integrals in (6.14)-(6.16).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66eca99689997d86d6fdcace50088b42e974e7677128ca9c8f99ffb2f11ccd75-c6d63a4946106161abdb4f4977f27babe82b89a1c8383df487867e22b7ceb4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-379508")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2014")])]

#text("Is there any remaining issue with revising item 1 in the “avenues to possible improvements” section? I think my (second attempt at a) paragraph summarising our state of knowledge/belief is accurate – posted at ")#link("https://terrytao.wordpress.com/2014/05/17/polymath-8b-xi-finishing-up-the-paper/#comment-365217")[#text("https://terrytao.wordpress.com/2014/05/17/polymath-8b-xi-finishing-up-the-paper/#comment-365217")]#text(" – but maybe others have improvements.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-379586")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2014")])]

#text("It seems that the current Krylov subspace method for obtaining lower bounds for ")#mi("M_k")#text(" by using a fixed number (currently 51) of precomputed inner products ")#mi("W_k ^i")#text(" (whose computation is very expansive) can be improved to get better lower bounds for ")#mi("M_k")#text(" – using the same(!) number of inner products.")#linebreak()#text(" I’ll describe the idea (improved processing of the inner products) in my next comment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-379911")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2014")])]

#text("Improved lower bounds for ")#mi("M_k")#text(":")#linebreak()#text(" Let ")#mi("\\mathcal L := \\mathcal L_k")#text(" and the basis functions")#linebreak()#text(" ")#mi("b_i := \\mathcal L^{i-1} 1")#text(" for ")#mi("i=1, ... , n")#text(" (defined as in page 58 of the Polymath8b paper). Let (for ")#mi("i = 0, 1, 2, ...")#text(")")

#mi("w_i := \\langle \\mathcal L^i 1 , 1 \\rangle")

#mi("w := (w_0, ... , w_{2 n -1})")

#text("and denote by ")#mi("A(w), B(w)")#text(" the ")#mi("n \\times n")#text(" Hankel matrices ")#mi("M_2, M_1")#text(" (as defined in page 58).")

#text("The lower bound for ")#mi("M_k")#text(" by the current method is the maximal generalized eigenvalue for the pencil ")#mi("(A(w), B(w))")#text(" which can be represented as")

#text("(1) ")#mi("\\min_t")#text(" subject to")

#mi("t B(w) - A(w)")#text(" is positive semi-definite.")

#text("Now suppose that")

#mi("w^{\\prime} := (w_0, ... , w_N)")#text(" is given for some ")#mi("N")#text(".")

#text("Therefore the current method can be applied only if ")#mi("2 n -1 \\leq N")#text(".")

#text("Since it is not clear that the current Krylov subspace method gives the best lower bound for ")#mi("M_k")#text(" (based on the given vector ")#mi("w^{\\prime}")#text("), it seems natural to consider the following problem:")

#text("“what is the best lower bound for ")#mi("M_k")#text(" where ")#mi("w^{\\prime}")#text(" is given?”")

#text("It seems that the answer is given by")

#tao-math("\\inf_{\\mathcal A} \\left|\\left|\\mathcal A\\right|\\right|", block: false)

#text("Where the infimum ranges over all the positive semi-definite linear operators ")#mi("\\mathcal A")#text(" on ")#mi("L^2(\\mathcal R_k)")#text(" such that")

#mi("\\langle \\mathcal A^i 1, 1 \\rangle = w_i")#text(" for ")#mi("i = 0, ... , N")

#text("Therefore, by increasing the number ")#mi("n")#text(" of basis functions, we can approximate the optimal lower bound for ")#mi("M_k")#text(" (for given ")#mi("w^{\\prime}")#text(" – without the current need to satisfy ")#mi("2 n -1 \\leq N")#text(") as the solution of")

#text("(2) ")#mi("\\min_t")#text(" subject to")

#text("$A(w), B(w), t B(w) – A(w)$ are positive semi-definite.")

#text("Remark: observe that for ")#mi("2 n -1 > N")#text(" the vector")#linebreak()#text(" ")#mi("x := (x_1, ... , x_m) = (w_{N+1}, ... , w_{2 n - 1})")#text(" should be optimized in (2) in addition to the parameter ")#mi("t")#text(".")#linebreak()#text(" Clearly, the Hankel matrices ")#mi("A(w), B(w)")#text(" are affinely dependent on the vector ")#mi("x")#text(" of free parameters, i.e. can be represented as")

#mi("A(w)=A_0+\\sum_{i=1}^m x_i A_i , B(w)=B_0+\\sum_{i=1}^m x_i  B_i")

#text("where all the symmetric matrices ")#mi("A_i, B_i")#text(" are known.")

#text("Since the feasibility domain in the problem (2) is a convex cone, any local minimum must be a global one. Moreover, this problem (known as generalized eigenvalue minimization) can be solved by efficient algorithms, implemented (in MATLAB) by the LMI solver gevp – as described in")#linebreak()#text(" “LMI control toolbox user’s guide”, the MathWorks Inc. 1995.")

#text("The gevp solver is based on Nesterov and Nemirovski’s projective method.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-379965")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2014")])]

#text("If I understand correctly, the idea here is to see if there is a better bound on the operator norm of ")#mi("{\\mathcal L}")#text(" that one can squeeze from knowledge of ")#mi("w_i = \\langle {\\mathcal L}^i 1, 1 \\rangle")#text(" for ")#mi("i=0,\\dots,N")#text(" than can be obtained from the Krylov method. I analysed a problem similar to this when trying to find a better sieve than the Selberg sieve. In that setting, I came to the conclusion that Selberg could not be significantly improved upon, and I think a similar argument works here, at least if N is odd (which is what Krylov needs).")

#text("One can see this using the spectral measure ")#mi("\\mu")#text(" of ")#mi("{\\mathcal L}")#text(" wrt the vector 1. The inputs ")#mi("w_i = \\langle {\\mathcal L}^i 1, 1 \\rangle")#text(" are then the moments of ")#mi("\\mu")#text(":")

#mi("w_i = \\int x^i\\ d\\mu(x).")

#text("A lower bound ")#tao-math("\\left\\| {\\mathcal L} \\right\\| > M", block: false)#text(" is then the assertion that ")#mi("\\mu")#text(" cannot be supported on ")#mi("[0,M]")#text(". From the Hahn-Banach theorem, such a lower bound can be deduced from the given values of ")#mi("w_0,\\dots,w_N")#text(" (without any further knowledge of the spectral measure) iff there exists a polynomial")

#mi("P(x) = a_0 + \\dots + a_N x^N")

#text("which is non-negative on ")#mi("[0,M]")#text(", but such that")

#mi("\\sum_{i=0}^N a_i w_i < 0")#text(". (*)")

#text("If ")#mi("N=2n+1")#text(", then by counting degrees of freedom, I think the optimal choice of P (generically) has to have a zero at M and n double zeroes in the interior of [0,M], or in other words it has to take the form ")#mi("P(x) = (M-x) Q(x)^2")#text(" for some degree n polynomial Q. In such a situation, the requirement (*) is the same requirement arising in the Krylov method, namely that there is a vector ")#mi("v")#text(" such that ")#mi("v^T M_2 v / v^T M_1 v > M")#text(". (Indeed, the vector v is basically the coeffiicents of Q.) So one doesn’t improve upon Krylov in this case.")

#text("One may be able to do a little bit better when N is even, but my guess is that either there is no gain or it is negligible (it may depend on how anomalously large ")#mi("w_N")#text(" is).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-380207")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2014")])]

#text("Thanks! It seems that your simpler (spectral) formulation of the problem may be easier to solve numerically by appropriate convex programming. It is clear that any zero of ")#mi("P(x)")#text(" in ")#mi("(0, M)")#text(" should have even multiplicity (not necessarily 2), but I still don’t see how to infer the multiplicities of possible zeros of ")#mi("P(x)")#text(" at the endpoints ")#mi("x =0, M")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-380212")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2014")])]

#text("Basically, if P has fewer than N zeroes in [0,M] (counting multiplicity), then there should be enough degrees of freedom to move P around (while preserving the number of zeroes it already has), and also shrink M a bit (unless there is a zero at M blocking this), until another zero of P is created in [0,M]. I haven’t worked out the rigorous details for this, but I think this process will generically terminate when P has n double zeroes inside (0,M) and one zero at M.")

#text("I think one can also proceed using the one-dimensional Positivstellensatz, which I think tells us that any polynomial that is nonnegative on [0,M] is a positive linear combination of polynoimals of the form ")#mi("x Q(x)^2")#text(" and ")#mi("(M-x) Q(x)^2")#text(" (I haven’t checked the details of this either, though).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-389654")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2014")])]

#text("It seems that the complete solution (both even and odd cases) was given by Curto and Fialkov in “Recursiveness, positivity, and truncated moment problems”, Houston J. math. 17(1991), 603-635.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c85b1951f8a78f312e438ee638df9d5874d7ac9e2468cd092ac4124a5293f350-52fc9493ff777e3522ac72f04d77065d71f50f5221e7ad6749d5e7fb81ad1ebe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-389695")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2014")])]

#text("The paper can be found at ")#link("http://www.math.uh.edu/~hjm/v017n4/0603CURTO.pdf")[#text("http://www.math.uh.edu/~hjm/v017n4/0603CURTO.pdf")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-389870")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2014")])]

#text("Thanks for this. It looks like that this paper confirms that outside of some degenerate singular cases, the positive definiteness of the Krylov matrix is the optimal criterion that one can derive from knowledge of a finite number of moments ")#mi("\\langle {\\mathcal L}^n 1, 1 \\rangle")#text("; there is a potential loophole in the odd case when the highest moment is unusually large in magnitude (in which case it could give a better lower bound for ")#mi("M_k")#text(" than the bound that one would get by ignoring this odd moment), but I doubt that this will actually arise in our application.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66eca99689997d86d6fdcace50088b42e974e7677128ca9c8f99ffb2f11ccd75-c6d63a4946106161abdb4f4977f27babe82b89a1c8383df487867e22b7ceb4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-380017")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2014")])]

#text("I’m wondering whether anyone else is seeing a strangeness at the dropbox: when I downloaded the 8b paper yesterday using the altogether correct-looking link at the top of this thread, it saved with the bizarre filename “bugJhUAfdbKE15Krps4JhSWAubUNrzHrdQaKHdkSRdjH7C4LBPHkH1FFZVcokSzg”. It opens fine (despite the lack of a .pdf extension), but if others are seeing the same thing (as opposed to this being some aneurysm of my computer brought on by a Mathematica overdose :-)) then maybe it’s worth looking for a fix before the paper is submitted.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-380301")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2014")])]

#text("I’ve managed to go through the Section 7 corrections. (Section 3 ended up having no actionable items, so given that it is scheduled for deletion in the published version, I decided not to touch it.) With Phillippe having tackled the Section 8 corrections already, this leaves only the (lengthy) Section 9/10 list of corrections to deal with. I think I might try to tackle the Section 10 half of this either today or tomorrow. There are two suggestions here marked “Important”, one in Sec 9 and another in Sec 10, that I haven’t had a chance to look at in detail yet; hopefully they are not serious.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-380867")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2014")])]

#text("Gone through the Section 10 corrections; the “Important” correction turned out to only require a slight rearrangement of two portions of the argument (as the referee in fact indicated). So there’s only Section 9 left to do, which I might do today or tomorrow.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6bbba1e1d5c23ba7304d32f5a54f847503548c7699ff24dd467e829a36670cc8-1826e30e0fa50731d77fab47ebbfae75ed316cd8c76c352c3419f603f106279f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-381899")[#strong[#text("A")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2014")])]

#text("Just a layman passing through: Why does the project separately state results obtained with and without Deligne’s theorems?")#linebreak()#text(" I am not familiar with the theorems, but I understand that they have been proved (as opposed to Fermat’s Last Theorem when it was still a conjecture); and thus I am curious as to why anyone should bother obtaining results while avoiding the use of these theorems.")

#text("(I realize it is fun, and sometimes enlightening, to try and solve the same problem in different ways. I am posting this because I imagine this is not the sole reason.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-382448")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2014")])]

#text("This distinction was more relevant early in the project, in which it was not clear that one could get any bound at all without the difficult theorems of Deligne. Now, one can get a proof of bounded gaps between primes ih a handful of graduate lectures (at least if one assumes the Bombieri-Vinogradov theorem as a black box, but even that theorem is not too difficult, perhaps occupying a few more lectures in an analytic number theory course). In contrast, I’m not sure that one could cover the proof of Deligne’s theorem on the Riemann hypothesis for sheaves in an introductory graduate course without assuming quite a large amount of arithmetic geometry as background.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09e3c96bac2808389d664bf095c56ba0ea57aaa60f178c110a384117d60702d5-7f4d65d1706e958f7ef47f12eed02126e8555f0043cd90aefbd30a044fd96de1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-384266")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2014")])]

#text("There have been graduate courses presenting Deligne’s second version of the Riemann Hypothesis (which is the relevant version for the sharper estimates). For instance, there is one by Katz in the early 1980’s (the notes are available on his web page), but they basically assume a working knowledge of all the background used by Deligne, which is a very significant amount of algebraic geometry, and I think Katz presents some material as black-boxes (e.g., Lefschetz pencils, if I remember right). Katz’s “Four lectures on Weil 2” give a proof of an important part of Deligne’s work which is definitely shorter and easier, but I don’t know offhand if it would be enough for us, and it begins with the same type of prerequisites.")

#text("Setting up these necessary foundations of étale cohomology, assuming knowledge of Hartshorne’s book (for instance) is also probably a year-long endeavor (there are notes of a course by de Jong on étale cohomology in some sections of the Stacks project; I think it was only a semester-long course, but it doesn’t cover everything Deligne requires, if I remember right).")

#text("And presenting the material at the level of Hartshorne’s book (beginning with the content of a standard introductory graduate algebra class) that is needed is also probably something that requires at least a year.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-382447")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2014")])]

#text("I’ve finished the Section 10 corrections from the (remarkably thorough) referee report; the comment marked “Important” required a tweak to a couple definitions and computations (we had taken the triangle inequality prematurely before a Cauchy-Schwarz, and so some reorganisation was in order) but nothing that wasn’t fixable.")

#text("Emmanuel, if you want to start on forming the abridged version of Polymath8a (in a subfolder, perhaps), I guess now would be a good time. At some point I’ll upload the full-length revision to the arXiv, but perhaps in a week or so after I and others have had a chance to take one last look at it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09e3c96bac2808389d664bf095c56ba0ea57aaa60f178c110a384117d60702d5-7f4d65d1706e958f7ef47f12eed02126e8555f0043cd90aefbd30a044fd96de1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-384256")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2014")])]

#text("Sorry for the delay in answering, I was hiking the last two days…")

#text("I’ll start preparing the shorter version hopefully today and hopefully a first draft will be available by the end of the week.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09e3c96bac2808389d664bf095c56ba0ea57aaa60f178c110a384117d60702d5-7f4d65d1706e958f7ef47f12eed02126e8555f0043cd90aefbd30a044fd96de1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-389756")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2014")])]

#text("The first draft of the shorter version is now in (or will soon sync with) the dropbox folder, in a subfolder shorter/.")

#text("The new parts are the introduction, and a file technical.tex contains those things needed from the removed sections (e.g., definition and facts on dense divisibility).")

#text("There were very few dangling references after removing subtheorems, narrow, gpy and optimize, which confirms that the new version is very cleanly extracted from the previous one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-389875")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2014")])]

#text("Looks good (and is significantly shorter, down from 163 pages to 106). I guess I’ll see you soon in person at IHES, so we can coordinate further editing of the draft then.")

#text("The longer version of 8a looks stable now, and I will shortly upload it to the arXiv to replace our previous draft.")

#text("We can now also move ahead with editing the portions of 8b involving narrow admissible tuples. A lazy way to proceed would be to refer to the long arXiv version of 8a that will shortly be posted, but perhaps for the sake of putting everything we use into the published literature, we should import the relevant portions of 8a into 8b (particularly the appendix of 8b).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f748edb4e50bd0eb515b1d1d778ae4d6d8c3d0e9b91b0982a99ebebf1728b0b-bfedad3b1d6d2a5a826707abdb1932af9554c2ba0b223afd50147ad66d902fa2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-391687")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2014")])]

#text("I went through the appendix of 8b and incorporated a shortened version of the content on narrow admissible tuples from 8a that I thought was directly relevant to 8b. I refer the reader to the long version of 8a for further details in a couple of places, but I think the appendix of 8b is now reasonably self-contained (and not all that much longer than it was).")

#text("I did not include any of the material on lower bounds for H(k), but if others think that this (or any other material) should be there, feel free to make further changes to appendix.tex, I’m done with the file.")

#text("In the process I noticed a couple of typos in the 8a narrow.tex which I fixed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-392512")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2014")])]

#text("Thanks, it looks good! I changed some references to Polymath8a to a new “unabridged Polymath8a” which should be online on the arXiv in a day or two. Otherwise, 8b looks in good shape; I’ll wait a few more days for any further comments, but I think it’s ready for submission.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-386281")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2014")])]

#text("In Polymath8b paper, in the sixth line below (7.9), “will never exceed 5” may now be updated to “will never exceed 3”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-387689")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2014")])]

#text("In the Polymath8b paper, in the third line from the end of the abstract, it seems clearer to insert “unconditional” before “asymptotic”.")

#emph[#text("[Inserted, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-388592")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2014")])]

#text("In the Polymath8b paper, in the fifth line of the introduction, it should be “where ")#mi("H(k)")#text("” (instead of “where ")#mi("H(m)")#text("“).")

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-392201")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2014")])]

#text("In page 66 of Polymath8b paper, the vanishing of ")#mi("F")#text(" on ")#mi("D_{x  y z}")#text(" (although stated in page 63), may be added (for completeness).")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-392634")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2014")])]

#text("In the Polymath8b paper, Fig. 1 (now in page 73 – before the appendix) should be moved into the appendix (along with Fig. 2 and Fig. 3 to the end of A.1. subsection.)")

#emph[#text("[I’ll wait on fixing this until the final galleys of the paper, formatted to the journal house style, are in, as the conversion to that style may automatically solve the problem. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-392659")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2014")])]

#text("In Polymath8b paper, in the second line of subsection A.2. (page 73), it should be “(5)-(9)” (instead of “(4)-(8)”).")

#text("Also, in the second line of subsection A.3. (page 76), it should be “(10) and (11)” (instead of “(9) and (10)” ).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-393242")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2014")])]

#text("In Polymath8b paper, “between primes” is missing from the title of reference [40].")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-393865")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2014")])]

#text("In polymath8b paper, It would be helpful to add some information after theorem 3.2 on the (quite complicated) dependence of its several parts on other theorems.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-394522")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2014")])]

#text("Hmm, this is a good idea in principle, but I’m not sure how to convey this information in a concise, high-level manner; the distinctions between the various tools used to prove different parts of Theorem 3.2 are rather technical (e.g. using epsilon trick or not, using polynomials or piecewise polynomials, using a vanishing marginal constraint, etc.) and I don’t know if it will be very illuminating to make these distinctions explicit, particularly before the more technical theorems (Theorems 3.5-3.14) have even been stated. (Compare with Polymath8a, where we had a nice high-level breakdown of the logic that we made into a graphic.) But if anyone has some specific suggestions on how to collect this information (which is currently scattered in a bunch of sentences across Section 3), I can try to implement them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-394565")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2014")])]

#text("It is perhaps sufficient just to state (perhaps in a small table) that")#linebreak()#text(" parts (vii)-(xi) (of theorem 3.2) will follow from theorems 3.8 and 3.9.")#linebreak()#text(" parts (ii)-(vi) from theorems 2.5 and 3.11.")#linebreak()#text(" parts (i), (xiii) from theorems 2.3 and 3.13.")#linebreak()#text(" part (xii) from theorems 3.14 and 3.15.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-394572")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2014")])]

#text("Correction: in my comment above, parts (ii)-(vi) will follow from theorems 2.5, 3.10 and 3.11 (i.e. theorem 3.10 is also needed.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-394674")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2014")])]

#text("Correction: in my comment above, parts (i), (xiii) will follow from theorems 2.3, 3.12 and 3.13 (i.e. theorem 3.12 is also needed.)")

#text("Remark: Note that in theorem 3.13(xiii)")

#mi("\\epsilon = 1/50 = 1/(k-1)")#text(" – which is not covered by theorem 3.12(ii), but the desired conclusion still holds (e.g. by slightly reducing the numerical value of ")#mi("\\epsilon")#text(" in theorem 3.13(xiii)).")

#emph[#text("[Table added -T.]")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26045845f2398f9404199f4ab704f0dfd758b12a525c8cd45e1c501caeb80f1b-7949ef8c7f9f89d7856357b49c7c0e64ecd2a20e8b50cdddc710d05a469add9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-394113")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2014")])]

#text("Mathematica 10 was just released, and it appears they have updated their matrix routines. Aubrey, if you would email me the most recent version of your code, I’d be happy to do some timing testing (and double check the code still works on this new version).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66eca99689997d86d6fdcace50088b42e974e7677128ca9c8f99ffb2f11ccd75-c6d63a4946106161abdb4f4977f27babe82b89a1c8383df487867e22b7ceb4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-394186")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2014")])]

#text("Will do – and I’ll wait to upload it to the dropbox until you confirm that it does.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66eca99689997d86d6fdcace50088b42e974e7677128ca9c8f99ffb2f11ccd75-c6d63a4946106161abdb4f4977f27babe82b89a1c8383df487867e22b7ceb4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-394912")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2014")])]

#text("Pace confirms that my latest code still works with Mathematica 10, so I’ve just uploaded it to the main Polymath8b dropbox folder with name “Mfinder-clean.nb”. I didn’t find time to explore beyond the refinements I reported on July 17th, so the code just implements what I described there. It still isn’t very well commented, but I hope it can be a viable starting-point for anyone who wants to go further (especially in respect of exploring domains larger than the simplex of size 1+epsilon), and I remain available to provide help.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26045845f2398f9404199f4ab704f0dfd758b12a525c8cd45e1c501caeb80f1b-7949ef8c7f9f89d7856357b49c7c0e64ecd2a20e8b50cdddc710d05a469add9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-401184")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2014")])]

#text("I just wanted to report on the Mathematica 10 run times. (I was hoping to report two weeks ago, but I had a flight to Poland, and so didn’t have access to my computer.)")

#text("Running Aubrey’s code on my desktop, which is a decent (but not decked-out) 5-year-old computer with 4-cores and 12 GB of RAM it took:")

#text("22 minutes to verify that ")#mi("k=50")#text(" should work")#linebreak()#text(" 14 minutes to approximate the ")#mi("M")#text(" value to within ")#mi("10^{-6}")#linebreak()#text(" 4.25 hours to approximate an eigenvector with which to do exact rational computations to prove ")#mi("M>4")

#text("The most RAM ever used was a little below 3 GB.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-394808")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2014")])]

#text("In Polymath8b paper, in the new table (table 1, page 9), it seems that for parts (vii)-(xi) it should be “3.9” (instead of “3.10”).")

#text("Also, since the components of theorem 3.2 are not directly implied by lemma 3.4 (they are directly implied by the other theorems inside table 1), it seems clearer to move lemma 3.4 to the title of table 1 (along with theorems 3.5, 3.6).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-395338")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2014")])]

#text("In the second version of the Polymath8a arxiv paper, “14950” somehow disappeared from the end of the abstract.")

#emph[#text("[Noted, though I’ll wait for more major revisions to post a correction to the arXiv version. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-395986")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2014")])]

#text("I’ve put Polymath8b in the house format for Research in the Mathematical Sciences, which happens to be the Biomed Central format, of all things; the draft PDF can be found ")#link("https://www.dropbox.com/s/85pt6mvzf5ghukw/newergap-submitted.pdf")[#text("here")]#text("; I’ll give it a day or so for any final comments and then I’ll arXiv and submit it (of course, we can keep doing minor revisions after this process).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7dec45a3fdf722914fe313513b45df071749e6db58e3e23d41028ba8617afb66-0df391e5984d406764fc2dc9d41af9532758707b43527c0f5ac39c1c1f7e3bf4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S Jung")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-395995")[#strong[#text("S Jung")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2014")])]

#text("small typo: in the abstract, last para, “one can obtain” appears twice in a row")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-396147")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("That line also begins with an unnecessary “the”.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-396049")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("Some remarks (for Polymath8b new format):")

#text("1. Page 8: in Table 1 (in its third line) it should be “Theorems 3.9, 3.10” (instead of “Theorems 3.8, 3.10”) – as explained in the two lines above theorem 3.9.")#linebreak()#text(" Additionally, since the components of theorem 3.2 follow from the theorems inside the table (without lemma 3.4) it seems better to place lemma 3.4 in the title of the table (along with theorems 3.5, 3.6).")

#text("2. Page 15: in the footnote [4], it may be added that in fact (by the continuity of ")#mi("M_{k, \\epsilon}")#text(" wrt ")#mi("\\epsilon")#text("), theorem 3.12(ii) holds also for ")#mi("\\epsilon = 1/(k-1)")#text(".")

#text("3. Page 64: there is a display (“xyplot”) problem (fifth line from below) with the diagram.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-396071")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("Correction: in my first remark above, it should be “Theorems 3.8, 3.9”. (instead of “Theorems 3.9, 3.10”).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-396180")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("More remarks:")

#text("Page 13: in the first line above theorem 3.9, it should be “sections 6, 7” (instead of “section 6”) – since theorem 3.9(vii) is proved in subsection 7.1 (page 58).")

#text("Page 55: In the title of table 2, it should be “Theorems 3.9 and 3.11” (instead of “Theorem 3.9”) – as explained in the last ten lines of the previous page.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-396693")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2014")])]

#text("Remarks for Polymath8b paper (new format):")

#text("1. In the line below theorem 3.3, “theorem 3.2 in Appendix 10” should be “theorem 3.3 in Section 10”.")

#text("2. Since in the new format “Appendix A” is now “Section 10”, perhaps in the first line of section 10 (page 73), “this appendix” should be updated to “this section”.")

#text("(since section 10 seems to be an appendix, it is not clear if its current name is better than in the previous format.)")

#emph[#text("[Corrected, although I had just posted the paper to the arXiv and so the arXiv version will not currently have this correction. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-397389")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2014")])]

#text("In the line below theorem 3.3 (see my first remark above), “theorem 3.2” should be “theorem 3.3”.")

#text("Additionally, in the new abstract, it seems clearer to have ")#mi("p_{n+m} - p_n")#text(" inside parentheses.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-397980")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2014")])]

#text("In Polymath8b paper (new format), page 60 second line, “Theorem 3.9(i)” should be “Theorem 3.13(i)”.")#linebreak()#text(" (hopefully, this is the last typo of this kind)")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-396242")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("Let ")#mi("N")#text(" be called a Polignac number if it appears as a gap between consecutive primes infinitely often. Clearly, Zhang’s theorem implies the existence of at least one Polignac number in ")#mi("[2, H_1]")#text(".")

#text("Is it possible to deduce from the current knowledge on ")#mi("H_m")#text(" (")#mi("m = 1, 2, ...")#text(") the existence of at least two Polignac numbers?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26045845f2398f9404199f4ab704f0dfd758b12a525c8cd45e1c501caeb80f1b-7949ef8c7f9f89d7856357b49c7c0e64ecd2a20e8b50cdddc710d05a469add9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-396325")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("Yes. Let ")#mi("N")#text(" be one Polignac number. We know that there are infinitely many sets of prime triplets ")#mi("p_1,p_2,p_3")#text(" a bounded distance (say ")#mi("M")#text(") apart. Given such a triple, let ")#mi("q_1< q_2< \\cdots< q_k")#text(" be the set of all primes in that bounded interval (so ")#mi("k\\geq 3")#text(" and ")#mi("q_k-q_1\\leq M")#text("). Note that we cannot have ")#mi("q_{i+1}-q_i=N")#text(" for each ")#mi("i")#text(", since that would contradict the fact that the primes must form an admissible tuple.")

#text("More generally, given a finite set ")#mi("N_1,N_2,\\ldots, N_{\\ell}")#text(" of Polignac numbers, we cannot form an arbitrarily long admissible tuple using only jumps of those sizes, so there must exist another Polignac number.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18ac32f1757df2128ad3a7dbe5ae836196e52ea337899648b1954fd17de88a53-604117642946f3f93e6b67fa3d6ac648db2fa29093c98f5c5b218b96551f81a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-396408")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("In fact János Pintz proved that the set of Polignac numbers has positive density, and the density can be bounded effectively in terms of ")#mi("k")#text(". Moreover, he also proved that the maximal gap size between Polignac numbers is bounded by an ineffective constant. The latter constant remains ineffective without significant new ideas, because there exist sequences with arbitrary large (but finite) maximal gap size which contain a difference from any ")#mi("3")#text("-tuple.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-396386")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("If ")#mi("N=6")#text(" is a Polignac number, than the triple ")#mi("0, N, 2 N")#text(" is admissible (enabling the possibility of infinitely many prime triples ")#mi("q_1, q_1+N, q_1+2 N")#text(") – so your argument can’t work for ")#mi("N =6")#text(" (or more generally if the Polignac number ")#mi("N")#text(" is a multiple of 6.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f748edb4e50bd0eb515b1d1d778ae4d6d8c3d0e9b91b0982a99ebebf1728b0b-bfedad3b1d6d2a5a826707abdb1932af9554c2ba0b223afd50147ad66d902fa2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-396388")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("I think for N=6 you want to take use the fact that there are infinitely many quintuplets of primes a bounded distance apart to get a contradiction of admissibility modulo 5, and in general you want to construct a contradiction of admissibility modulo the least prime p that does not divide N using the existence of infinitely many of p-tuplets occurring within an interval of bounded size.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-396420")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("Yes. It seems that with your modification, Pace’s argument (for the existence of at least two Polignac numbers) works (since there are only finitely many arithmetic progressions of primes with difference ")#mi("N")#text(" and length ")#mi("k")#text(" – provided that ")#mi("N, k")#text(" are relatively primes).")#linebreak()#text(" Since the smallest Polignac number is ")#mi("H_1")#text(", we need to choose ")#mi("k")#text(" to be relatively prime to ")#mi("H_1")#text(" – so (for an unconditional argument) we may choose ")#mi("k")#text(" to be the least prime above 246.")

#text("It is still not sufficiently clear how to (rigorously) generalize this argument for more than two Polignac numbers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18ac32f1757df2128ad3a7dbe5ae836196e52ea337899648b1954fd17de88a53-604117642946f3f93e6b67fa3d6ac648db2fa29093c98f5c5b218b96551f81a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-396430")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("See my previous comment on this blog (at 2:21pm). See also Theorems 1 and 2 in Pintz’s paper ")#link("http://arxiv.org/abs/1305.6289")[#text("http://arxiv.org/abs/1305.6289")]#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514a66d5a7e07e53b5283a23f1cb25e10d5af51f339bb8ec65c3d16d24eb43d4-a1d6380796d3a643532a0e284cf77b8b1d4a205fc43bd7a7f3dab3d41a805bfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-396451")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("Thanks! (It is quite remarkable that the main ideas for these theorems are from 2010 – before Zhang’s theorem!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26045845f2398f9404199f4ab704f0dfd758b12a525c8cd45e1c501caeb80f1b-7949ef8c7f9f89d7856357b49c7c0e64ecd2a20e8b50cdddc710d05a469add9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-396506")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("Thanks Gergely. I had failed to account for small primes in my argument above, so it’s nice there is a clean proof due to Pintz.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f748edb4e50bd0eb515b1d1d778ae4d6d8c3d0e9b91b0982a99ebebf1728b0b-bfedad3b1d6d2a5a826707abdb1932af9554c2ba0b223afd50147ad66d902fa2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew V. Sutherland")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-396397")[#strong[#text("Andrew V. Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("A simpler argument is to get a contradiction on the the maximal density of the elements of an admissible tuple. The Omega(k*log k) lower bound on the diameter of an admissible tuple implies that for for any constant N we can pick k large enough so that every admissible k-tuple has an average gap size greater than N, and in particular has at least one gap larger than N.")

#text("Now suppose the number of Polignac numbers is finite, and fix a constant N that is larger than any of them. Pick k as above and use the fact that there are infinitely many k-tuples of primes a bounded distance M apart. If we go out far enough, all the gaps in our k-tuples of primes have to be smaller than N (otherwise there is another Polignac number between N and M), but this contradicts the fact that our admissible k-tuple must have at least one gap larger than N.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-398296")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2014")])]

#text("I’m rolling over to a new (and perhaps final) Polymath8 thread at ")#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/")[#text("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/")]#text(" . I’ve just arXiv’ed the 8b paper and submitted it to RIMS; apparently, some referees are already looking at the manuscript.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mathematics")]], [#link("https://terrytao.wordpress.com/2014/06/19/polymath8-wrapping-up/comment-page-1/#comment-398447")[#strong[#text("Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2014")])]

#text("The END?")
]
