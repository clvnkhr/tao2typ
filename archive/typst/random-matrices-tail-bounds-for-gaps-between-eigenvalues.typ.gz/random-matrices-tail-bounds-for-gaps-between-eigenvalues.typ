// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/
// Converted to Typst by tao2typ: "2026-10-14T16:37:40.703845+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Random matrices: tail bounds for gaps between eigenvalues", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Random matrices: tail bounds for gaps between eigenvalues")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 April 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/")[#text("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://people.math.osu.edu/nguyen.1261/")[#text("Hoi Nguyen")]#text(", ")#link("http://users.math.yale.edu/public_html/People/vuha.html")[#text("Van Vu")]#text(", and myself have just uploaded to the arXiv our paper “")#link("http://arxiv.org/pdf/1504.00396v1.pdf")[#text("Random matrices: tail bounds for gaps between eigenvalues")]#text("“. This is a followup paper to my ")#link("https://terrytao.wordpress.com/2014/12/04/random-matrices-have-simple-spectrum/")[#text("recent paper with Van")]#text(" in which we showed that random matrices ")#mi("{M_n}")#text(" of Wigner type (such as the adjacency matrix of an Erdös-Renyi graph) asymptotically almost surely had simple spectrum. In the current paper, we push the method further to show that the eigenvalues are not only distinct, but are (with high probability) separated from each other by some negative power ")#mi("{n^{-A}}")#text(" of ")#mi("{n}")#text(". This follows the now standard technique of replacing any appearance of discrete Littlewood-Offord theory (a key ingredient in our previous paper) with its continuous analogue (inverse theorems for small ball probability). For general Wigner-type matrices ")#mi("{M_n}")#text(" (in which the matrix entries are not normalised to have mean zero), we can use the ")#link("http://www.ams.org/mathscinet-getitem?mr=2775902")[#text("inverse Littlewood-Offord theorem")]#text(" of Nguyen and Vu to obtain (under mild conditions on ")#mi("{M_n}")#text(") a result of the form")

#align(center)[#tao-fit-display[#mitex("{\\bf P} (\\lambda_{i+1}(M_n) - \\lambda_i(M_n) \\leq n^{-A} ) \\leq n^{-B}")]]

#text("for any ")#mi("{B}")#text(" and ")#mi("{i}")#text(", if ")#mi("{A}")#text(" is sufficiently large depending on ")#mi("{B}")#text(" (in a linear fashion), and ")#mi("{n}")#text(" is sufficiently large depending on ")#mi("{B}")#text(". The point here is that ")#mi("{B}")#text(" can be made arbitrarily large, and also that no continuity or smoothness hypothesis is made on the distribution of the entries. (In the continuous case, one can use the machinery of Wegner estimates to obtain results of this type, as was done in a ")#link("http://www.ams.org/mathscinet-getitem?mr=2587574")[#text("paper of Erdös, Schlein, and Yau")]#text(".)")

#text("In the mean zero case, it becomes more efficient to use an ")#link("http://www.ams.org/mathscinet-getitem?mr=2407948")[#text("inverse Littlewood-Offord theorem of Rudelson and Vershynin")]#text(" to obtain (with the normalisation that the entries of ")#mi("{M_n}")#text(" have unit variance, so that the eigenvalues of ")#mi("{M_n}")#text(" are ")#mi("{O(\\sqrt{n})}")#text(" with high probability), giving the bound ")#metadata(none) <tao-ee58dc2ac168ba351fec>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("{\\bf P} (\\lambda_{i+1}(M_n) - \\lambda_i(M_n) \\leq \\delta / \\sqrt{n} ) \\ll \\delta")]]

#text("for ")#mi("{\\delta \\geq n^{-O(1)}}")#text(" (one also has good results of this type for smaller values of ")#mi("{\\delta}")#text("). This is only optimal in the regime ")#mi("{\\delta \\sim 1}")#text("; we expect to establish some eigenvalue repulsion, improving the RHS to ")#mi("{\\delta^2}")#text(" for real matrices and ")#mi("{\\delta^3}")#text(" for complex matrices, but this appears to be a more difficult task (possibly requiring some ")#emph[#text("quadratic")]#text(" inverse Littlewood-Offord theory, rather than just ")#emph[#text("linear")]#text(" inverse Littlewood-Offord theory). However, we can get some repulsion if one works with larger gaps, getting a result roughly of the form")

#align(center)[#tao-fit-display[#mitex("{\\bf P} (\\lambda_{i+k}(M_n) - \\lambda_i(M_n) \\leq \\delta / \\sqrt{n} ) \\ll \\delta^{ck^2}")]]

#text("for any fixed ")#mi("{k \\geq 1}")#text(" and some absolute constant ")#mi("{c>0}")#text(" (which we can asymptotically make to be ")#mi("{1/3}")#text(" for large ")#mi("{k}")#text(", though it ought to be as large as ")#mi("{1}")#text("), by using a higher-dimensional version of the Rudelson-Vershynin inverse Littlewood-Offord theorem.")

#text("In the case of Erdös-Renyi graphs, we don’t have mean zero and the Rudelson-Vershynin Littlewood-Offord theorem isn’t quite applicable, but by working carefully through the approach based on the Nguyen-Vu theorem we can almost recover ")#link(<tao-ee58dc2ac168ba351fec>)[#text("(1)")]#text(", except for a loss of ")#mi("{n^{o(1)}}")#text(" on the RHS.")

#text("As a sample applications of the eigenvalue separation results, we can now obtain some information about ")#emph[#text("eigenvectors")]#text("; for instance, we can show that the components of the eigenvectors all have magnitude at least ")#mi("{n^{-A}}")#text(" for some ")#mi("{A}")#text(" with high probability. (Eigenvectors become much more stable, and able to be studied in isolation, once their associated eigenvalue is well separated from the other eigenvalues; see ")#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/")[#text("this previous blog post")]#text(" for more discussion.)")

#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f2d5d3cc620cde0716551a9c140681def32044452bb86503a4e308c233dad9-9771e7221f6d26752c0ed4cd8eb973d214a1ceec966cc3e6071d86303236a715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurice de Gosson")]], [#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/#comment-453773")[#strong[#text("Maurice de Gosson")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2015")])]

#text("Is it interesting?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/#comment-453777")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2015")])]

#text("dear Terry,")#linebreak()#text(" page 6 section 3.2")#linebreak()#text(" you write: Let u be an eigenvalue of A_n(p).")#linebreak()#text(" if I am not mistaken it should be let u be an eigenvector.")

#emph[#text("[Thanks, this will be corrected in the next version of the ms. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/#comment-453797")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2015")])]

#text("Is it possible to extend the results to some class of random (infinite dimensional) hermitian operators (e.g. to show that the probability of a spectrum gap less than ")#mi("\\delta")#text(" is bounded by ")#mi("\\varepsilon")#text(" whenever ")#mi("\\delta")#text(" is bounded by a fixed positive power ")#mi("A /B")#text(" of a sufficiently small ")#mi("\\varepsilon >0")#text(")?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/#comment-453802")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2015")])]

#text("I think one could make some artificial infinite-dimensional random operator model for which the currently known techniques would extend, but for the models that people care the most about (e.g. discrete or continuous random Schrodinger operators), these sorts of methods aren’t yet applicable (they rely too much on having all of the entries having non-zero variance, and so don’t cope well with the band-limited or otherwise localised nature of operators such as Schrodinger operators). But there is certainly an effort to push a lot of the Wigner theory in the direction of more physically relevant matrices and operators, such as discrete random Schrodinger operators (e.g. there are now some results on band-limited matrices which are sort of an interpolant between the random Schrodinger models and the Wigner models).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/#comment-453895")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2015")])]

#text("Is it possible to (effectively) compute an upper bound for the ratio ")#mi("A/B")#text(" (for all sufficiently large n)?")

#emph[#text("[Yes; see the remark after Theorem 2.6 of the paper. -T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10f59a9a63778a358f0760f771e73d5079ab4c7c7f6bac9eade6394f2f26dcab-d4277f69e367e34a2edd8a5b73e0464302d931c25534a3aa4fe8e5b3ddafe1c7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Romulo, O R³. (@romulor3)")]], [#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/#comment-453800")[#strong[#text("Romulo, O R³. (@romulor3)")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2015")])]

#text("On the fourth line of your post do you mean “adjacency matrix” instead of “adjacency graph”?")

#text("“(such as the adjacency graph of an Erd\\H{o}s-Renyi graph)”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c03330103a939e0c139e7eccd4a2cc8dded784193a97bfd58909a1e90e559f6c-29c144cf0008fdce5334452b99abdac1a4d459d6ab5ed1c9868580dd898ba8f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Святослав Шмидт")]], [#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/#comment-453804")[#strong[#text("Святослав Шмидт")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2015")])]

#text("Professor, could you explain how to do involution for the hypercomplex numbers?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf583c08c239325492a9f4ca3ae29058554a70b19a68ba678c5592cb62bedbe-4df0da82f9f6d4ddde9d9fd0d6698bf06b541c0ee37d90dec7bee0c0759fd84a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zoltan B.")]], [#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/#comment-453813")[#strong[#text("Zoltan B.")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2015")])]

#text("Dear Terry,")

#text("I wonder if you could comment about analogous statements for non-Hermitian matrices? For example, suppose you generate a random graph as in G(n,p) but now throwing in directed edges. Would the results you describe here (simple spectrum, no eigenvector with zero entry) still hold and how difficult would they be to prove?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/#comment-453821")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2015")])]

#text("The techniques in this paper break down (among other things, they rely on the Cauchy interlacing law, which breaks down in non-Hermitian settings), but I have a student looking into this problem who is trying some other methods.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab82efe8db2841454b1457793a9953a5a2a37cfd671dc7a9b01203b83c318270-25487a2c0a8940e06137563ee9850144e03d4637018ec997716042f03779ecb3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of XiangYu")]], [#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/#comment-453837")[#strong[#text("XiangYu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2015")])]

#text("Reblogged this on ")#link("https://xiangyu14.wordpress.com/2015/04/06/random-matrices-tail-bounds-for-gaps-between-eigenvalues/")[#text("xiangyu14")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29d3fae4c923c89142c794895e8cb1349e887c30833a5c71ce664b35ed2480a1-cb657d8af08b64bd90e5c779b4061f2ba0f49f8b8586e5cdc233393a1e037138.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lam")]], [#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/#comment-453922")[#strong[#text("Lam")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2015")])]

#text("Dear Terry,")

#text("You wrote “almost surely have simple spectrum”, did you mean “with high probability”?")

#emph[#text("[Clarified to “asymptotically almost surely” – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arik")]], [#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/#comment-467386")[#strong[#text("Arik")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2016")])]

#text("So, if we look at specific types of matrices then randomly and asymptomatically they will likely fall into a small spectrum of distinct eigenvalues, potentially with the sign flipped. If this is symmetric you can look for those eigenvalues and find those types of matrices? Where might that be useful? Or is that not within the scope of study?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arik")]], [#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/#comment-467397")[#strong[#text("Arik")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2016")])]

#text("Would appreciate an explanation, thanks sir")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d153d1a3850d220e42bb130bd71c95a04be97117c47c7519d0e19a8f66c95204-b530244e8bc08c7b5fc779124da8ecc347a25f1a11484e6ebf0ff304dae812c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mk")]], [#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/#comment-491267")[#strong[#text("Mk")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2018")])]

#text("For an adjacency matrix A, is it then possible to give a similar bound on the sum of the gaps? Or in other words the difference between the maximum and minimum eigenvalues of A?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/#comment-491292")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2018")])]

#text("There is now a quite precise understanding of the distribution of the extreme eigenvalues of an Erdos-Renyi adjacency matrix, see e.g., ")#link("https://arxiv.org/abs/1103.3869")[#text("https://arxiv.org/abs/1103.3869")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d153d1a3850d220e42bb130bd71c95a04be97117c47c7519d0e19a8f66c95204-b530244e8bc08c7b5fc779124da8ecc347a25f1a11484e6ebf0ff304dae812c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mk")]], [#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/#comment-491268")[#strong[#text("Mk")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2018")])]

#text("Also, if the entries of a random matrix are iid and Poisson distributed, then can we say something about how the corresponding eigenvalues are distributed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/#comment-491293")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2018")])]

#text("for iid Poisson matrices this is covered by the circular law (for the bulk distribution), see ")#link("https://arxiv.org/abs/1109.3343")[#text("https://arxiv.org/abs/1109.3343")]#text(" . Local spacing universality is still open for this (the best result so far, ")#link("https://arxiv.org/abs/1206.1893")[#text("due to Van and myself")]#text(", requires four matching moments with a Gaussian). For symmetric Poisson matrices the semicircular law is classical (due to Pastur?) and the universality of spacing is also known (see e.g. ")#link("https://arxiv.org/abs/1407.5606")[#text("https://arxiv.org/abs/1407.5606")]#text(" ).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/#comment-634948")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2021")])]

#text("A recent extension of Littlewood-Offord problems and related results to definable sets with respect to o-minimal structures (e.g. semialgebraic sets) appears in ")#link("https://arxiv.org/pdf/2106.04894.pdf")[#text("https://arxiv.org/pdf/2106.04894.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/#comment-687113")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2025")])]

#text("Hi, Prof. Tao!")

#text("I was wondering if there are any results relevant to concentration of multiplicative eigenvalue gaps for random matrices (Gaussian or sub-Gaussian or even under any weaker distributional assumptions). I couldn’t transform the above results for the case I’m mentioning.")

#text("Say, if my Gaussian distribution N(0,Σ) is over R^n. Suppose for some 1>=k>n,")#linebreak()#text("λ_k(Σ)/λ_{k+1}(Σ) = γ^2,")#linebreak()#text("where γ^2 is very large (say, greater than n).")

#text("Let’s say I have m i.i.d. column vectors (call the matrix, M). Is there any result involving m and n describing tight concentration of λ_{k}(M)/λ_{k+1}? I have tried out the concentration inequalities for the eigenvalues of M from ")#link("https://www.math.uci.edu/~rvershyn/papers/HDP-book/HDP-book.pdf")[#text("this book")]#text(", but the best I’m able to get is a sqrt(n) multiplicative approximation to that gap as the minimum possible empirical gap.")

#text("Thanks!!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/#comment-687116")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2025")])]

#text("I was not able to parse the precise inequality you are looking for, but one suggestion would be to perform a dyadic decomposition into the magnitudes of the eigenvalues ")#mi("\\lambda_k")#text(" and ")#mi("\\lambda_{k+1}")#text(", for instance partitioning into events in which ")#mi("\\lambda_k \\in [2^j, 2^{j+1}]")#text(" for some ")#mi("j")#text(". A large value of ")#mi("\\lambda_{k+1} / \\lambda_k")#text(" is then basically equivalent to some lower bound on ")#mi("\\lambda_{k+1}")#text(", e.g., if ")#mi("\\lambda_{k+1}/\\lambda_k \\geq A")#text(" and ")#mi("\\lambda_k \\in [2^j, 2^{j+1}]")#text(" then ")#mi("\\lambda_{k+1} \\geq 2^j A")#text(" (and ")#mi("\\lambda_{k+1}-\\lambda_k \\geq 2^j (A-1)")#text("), thus effectively converting the multiplicative gap to an additive gap. One could then try to control these events using known eigenvalue rigidity results (such as those in Vershynin’s book) or eigenvalue gap bounds, and then apply the union bound to sum over ")#mi("j")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/04/03/random-matrices-tail-bounds-for-gaps-between-eigenvalues/#comment-687122")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2025")])]

#text("Thank you so much for the response!")

#text("The inequality I was hoping to find was something along the lines of:")#linebreak()#text("λ_{k}(MM^T)/λ_{k+1}(MM^T) * f_1(m,n) <= λ_{k}(Σ)/λ_{k+1}(Σ) <= λ_{k}(MM^T)/λ_{k+1}(MM^T) * f_2(m,n)")#linebreak()#text("for some functions f_1 and f_2.")

#text("There are a few results in Vershynin’s book that could help determining this kind of inequality, but I’m wondering if there’s any that characterises this multiplicative eigenvalue gap tightly in cases where γ is very large (say, n).")

#text("I am aware that, in general, determining even the top eigenvalue of Σ up to a multiplicative factor of 2 with probability 0.9 necessitates m=Ω(n), but I was thinking if m=O(k) were possible in this large γ case.")
]
]
]
