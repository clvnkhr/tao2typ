// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/
// Converted to Typst by tao2typ: "2026-10-14T16:39:36.311738+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "AIM: an invitation to explore mathematics together", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("AIM: an invitation to explore mathematics together")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/")[#text("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://www.damtp.cam.ac.uk/user/mjc249/home.html")[#text("Matthew Colbrook")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("(Disclosure: ChatGPT helped me write and refine this post.)")

#text("Inspired in part by the recent discussions on this blog, we have started a new project, AIM, an initiative to create a community-led opportunity for mathematical exploration. Since AI can make some conjectures easier to resolve, we would like to explore how these developments can be used to benefit the mathematical community, enhancing our learning and understanding. Modern developments in AI bring both excitement and uncertainty in our field. We hope to create opportunities for mathematicians, especially students and early career researchers, to shape what comes next by asking good questions, working on problems, and developing the ideas and applications that come with them.")

#metadata(none) <tao-d774e68328195eb3ea1e>

#text("We have collected a list of open problems in applied mathematics and related fields along with their precise statements, motivation, and references:")

#link("https://github.com/MColbrook/AIM")[#text("https://github.com/MColbrook/AIM")]

#text("This repository of problems is intended to benefit the mathematical community and become a place for collaborative exploration as well as a place where mathematicians can share proposed proofs and solutions for others to see. Our primary purpose is mathematical. Rather than using a set of problems to benchmark AI systems, we want to let the community shape the questions that we pursue, whether or not AI is used, and how we learn from this work. We warmly invite readers to contribute problems to the list, directions, and solutions to those problems already in the repository. Partial results, proofs, counterexamples, references, and corrections are most welcome. Contributions with or without AI are perfectly acceptable, with careful checking and attribution.")

#text("The companion site, ")#emph[#text("AIM, explained")]#text(" (")#link("https://mathematics-explained.com/")[#text("https://mathematics-explained.com/")]#text(" ), welcomes papers and videos exploring and explaining the mathematical arguments behind the solutions of these problems. A solution to a problem should not be the end of our engagement with a question, for it can open up further questions about why an argument works, whether a different formulation is more insightful, and how the ideas from a solution connect to other mathematics or applications. We want to acknowledge this work.")

#text("To encourage participation, we are also running a competition for explanatory papers and videos of up to ten minutes. The competition is split into two strands: for those who have not yet completed a first degree, and for graduate students and postdoctoral researchers at academic institutions. The emphasis is on accuracy, clarity and understanding, rather than on being first to solve or explain a problem. Entries close on 1 January 2027 at 23:59 UTC, with prizes for winning entries and a curated publication of selected contributions. The wider explanation library is open to all, independently of the competition.")

#text("Our repository and website are a starting point, and we would be most glad to hear your suggestions. Please share problems that you would like others to explore (across all of pure and applied mathematics), progress on those already listed, and other ideas that might make AIM useful to you or your students. Problems and corrections can be submitted through the repository; broader suggestions are welcome here in the comments or directly to the organisers.")

#text("Sent on behalf of the organisers, Steve Brunton, Matthew Colbrook, Maarten V. de Hoop, George Stepaniants, Alex Townsend, and Rachel Ward.")

#heading(level: 1)[#text("Comments (20)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2119dfe0cb3c4024a9db51fc268c1343e352ca4d59fe421dec13b77a2c2bdb3d-d22dafb3c0484c26eb914803d0661dd0da21fba1205edfd7b3ff2488c739a817.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bredrindeacon")]], [#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/#comment-696703")[#strong[#text("bredrindeacon")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("Thanks a lot, Professor Tao! My appetite for mathematics is much bigger than my abilities. I’m a K-12 math teacher with a strong interest in mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/#comment-696707")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("There’s already vibemathed.com, so I don’t see any substantial novelty here. The new passion for videos in the community looks strange to me, I assume people will soon realize that that won’t change much.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1789c2fff339de003ae8410f6ea2c7c643819c27b526bfb71bdc0448211bd758-0a27fdf35477313d47203bd75341084cfcc2d42b87b30bd40ce01e2c2564a2e4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of holdenrhit")]], [#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/#comment-696710")[#strong[#text("holdenrhit")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("Is this related to ")#link("https://aimath.org/")[#text("https://aimath.org/")]#text(" ? If not, that’s rather confusing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ef179a4845f930977921170262dfa5f55128d5d279f0ddee59d0f0eb19f204d-6349196ea317397f75ebde55cc50147a50ffd0250864465256422f06122d4566.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mjc249")]], [#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/#comment-696723")[#strong[#text("mjc249")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("Thanks a lot for pointing this out. No it’s not, we will add a remark about this to the website.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b717f71d6adaad4c83a3537394871ed2142006eb376c8da2d1b4f85de1a50ed-624523c701ef0fc127d2ca0bce537e0b30baff27206a1907776d1f1634eb6657.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ecstatic3bfbcbea40")]], [#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/#comment-696717")[#strong[#text("ecstatic3bfbcbea40")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("do you provide tokens for students ho don’t have them ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ef179a4845f930977921170262dfa5f55128d5d279f0ddee59d0f0eb19f204d-6349196ea317397f75ebde55cc50147a50ffd0250864465256422f06122d4566.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mjc249")]], [#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/#comment-696724")[#strong[#text("mjc249")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("Unfortunately not. Inequality of token access is one of our worries, particularly for students, and something we are looking into.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/#comment-696720")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("No clearer death knell for academia than the number of researchers who can’t even write 500 words anymore without AI assistance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23788221ab18c931b75c1afe3fa1682d38c015e6d56e782358f24b6d8ecafec3-14a21404742907208ff46a358b0fd0aca78fedf87ff36a1c23f443c9428d2116.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thoughtfully829ed2a577")]], [#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/#comment-696734")[#strong[#text("thoughtfully829ed2a577")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2026")])]

#text("Similar death knells have been sounded at the advent of many technologies. When typing became a thing, teachers of cursive bemoaned “the number of writers who can’t even write 500 words anymore without pressing keys”. When calculators became a thing: “the number of accountants who can’t multiply two three-digit numbers without a gadget requiring batteries”.")

#text("There are very serious threats that AI poses that weren’t posed by typewriters or calculators. I think engaging with it as in this post – whether it gathers momentum or not – is the best attempt at socially learning to wield a potentially harmful tool.")

#text("-S")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/#comment-696740")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2026")])]

#text("Engaging with it in public in discussions about the future of mathematics just has the effect of normalizing AI usage rather than pointing out the dangers.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/#comment-696727")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("Given the incentive to crack open problems using AI with a competition and prizes: why was there so much outcry against the Mathathon and this is getting an infomercial ad space on this website?")

#text("Moreover, is there some kind of restriction to free and open source models or is this basically a way for the math community to actively create a disparity between those with and without access (how are those at institutes, or independents, without money to pay for equally strong AI tools not at a disadvantage)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0cb9a16c41cc4080a9f9e82a01551b6273133004933a6d46832335d49e35de0-8485d8fac0235050190ae32eebeb6fc6b31effe5518ecd689d9853fb3e14a461.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabio Durastante")]], [#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/#comment-696742")[#strong[#text("Fabio Durastante")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2026")])]

#text("I had published the following comment to the GitHub issues of the repository earlier this morning, but one of the admin had closed the issue immediately after, and then has completely removed it from the repo history. Maybe I’ll have a better luck here.")

#strong[#text("Advanced Idea Mechanics")]

#text("It is unclear to me why we are working towards transforming mathematics into a benchmark for evaluating commercial LLM products. Poisoning the wells by making lists of problems of which we maybe don’t personally care, but on which colleagues or, far worse, doctoral students are likely working in order to learn the trade.")

#text("When King Ptolemy asked Euclid if there was an easier or shorter way to learn geometry than reading and understanding through proofs he got the answer: “There is no royal road to geometry.” Is our objective opening such a royal road with the money we transfer to malicious actors who have no interest whatsoever in doing mathematics? What effect do we want to achieve by creating these lists? To ensure that no one talks about what they are working on until they have actually refined it? Creating a two-tier system, distinguishing between those who can afford subscriptions and have no problems about transferring money to companies with questionable side activities?")

#text("Clearly these instruments are now there, and people will use them to assist producing proofs, but Journals are absolutely packed with submissions built around the smallest possible publishable units, carelessly written and churned out at an insane speed; arXiv has rate limited the number of submission, like a server under a denial-of-service attack. We have finally reached the outcome that years of bibliometric assessment promised us: publish ")#emph[#text("and")]#text(" perish. The best part? We are cheerfully participating in the massacre, and making lists of things people can use to launch DDoS attacks.")

#text("There is a part of me that also finds the name you chose for this joyful activity particularly “amusing”, the acronym of a fictional Marvel criminal organization depicted as a think tank of brilliant scientists dedicated to world domination through technological means. Perhaps there is a part of us that realizes just what a terrible idea this all is.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/#comment-696744")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2026")])]

#text("The criticism expressed in the comments resonates strongly with me. Colbrook’s efforts create damage and are in contradiction to what several top mathematicians expressed during the last weeks. Many of the problems on Colbrook’s list are not particularly well known, but surely PhD students are working on quite a few of them, who are now put in a rather miserable position. This begs the question whether this damage is justified by the potential benefits. Here, the text does not convince me. It says “We hope to create opportunities … by asking good questions, working on problems, and developing the ideas and applications that come with them.” This list does exactly the opposite; how does an invitation to button pushers create opportunities, lead to “asking good questions” and “developing the ideas”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/#comment-696748")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2026")])]

#text("The text is just nonsense slop. No sane person would think that this project makes sense. Covetous engineers, sloppers and laymen are joining forces to ruin math to everyone. Good job yall.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1d538fe3b2422e0e16e568b12ccc26a9f8b68d5c7b99329084f8f02cd7df7c9-24b0eeb1a83b1abf7ea39057bdccbc69c0288bef4e2b0ea13cbb02f3b7baac78.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of repagulum")]], [#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/#comment-696745")[#strong[#text("repagulum")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2026")])]

#text("Sorry, could you clarify the selection of open problems? Why these, specifically? E. g., in the field of snarks, you chose 3 open problems, all of them quite niche and all are about permutation graphs, but why?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ef179a4845f930977921170262dfa5f55128d5d279f0ddee59d0f0eb19f204d-6349196ea317397f75ebde55cc50147a50ffd0250864465256422f06122d4566.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mjc249")]], [#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/#comment-696760")[#strong[#text("mjc249")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2026")])]

#text("Thanks for the comment. The current list is not intended to be comprehensive but rather a start. We will be expanding the list in the coming weeks. Are there any problems in particular you would want to see added?")

#text("In case it helps some of the other commentators, it’s probably helpful to further clarify a key point from our initial post. The initiative is not about a race to solve open problems on a list. The focus is the follow-up website to collect human understanding (you don’t even have to have been the one to push the solution to the GitHub repo to submit something to that website, nor do you have to have used AI). In that way we hope that the mathematical community can engage with these new tools on their own terms, whilst preserving the values we all cherish.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a19a2493755d72307e0727793c9074c3f1dc30c5123bd19c3d6136d1b92d8510-168c47670ea16627b9fcaf784ddbf812831529df9e4b5aa98e05ca45864696c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vanni Noferini")]], [#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/#comment-696763")[#strong[#text("Vanni Noferini")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("I am not surprised that this post is leading to heated discussions.")

#text("I have the impression that the big fracture is between result-driven people (“I don’t care HOW the theorem was discovered, as long as the result is correct and I can use it; so it is perfectly acceptable to prompt an LLM to solve a problem and then write a paper with my name on it”) and understanding-driven people (“I might perhaps accept using AI to prove a long technical lemma rather than spend two months on it myself, but I do not see the point of writing a paper if the main ideas do not come from me or my human collaborators, or I have not fully understood the results”).")

#text("I am definitely part of the latter group, and I have already had some private discussions with Alex and Matt about their initiatives, but perhaps this is precisely the main source of misunderstanding. The two groups are probably trying to optimise two different objective functions in light of the new technology, and both call the resulting activity “doing mathematics”. I also see some other issues in the viewpoint of the former group, some of which have already been pointed out, e.g., possibly scooping early career people who were working on “within reach” problems, or putting journals (or even the arxiv) on the edge of collapse.")

#text("I would really dislike a schism in the community, so this comment is an attempt at facilitating communication between the two groups.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ef179a4845f930977921170262dfa5f55128d5d279f0ddee59d0f0eb19f204d-6349196ea317397f75ebde55cc50147a50ffd0250864465256422f06122d4566.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mjc249")]], [#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/#comment-696776")[#strong[#text("mjc249")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("Thanks for the comment Vanni. The explanation website is set up to sit in the latter group, and this is something the organisers feel strongly about (who also see themselves as being in the latter group). It’s possibly also more complicated than two groups, with many people on all sorts of ends of the spectrum of enjoying problem solving (with or without the help of AI and to varying degrees) and understanding. I also think there are many instances of people using AI in a healthy way for their mathematics (one only has to look at the rich variety of different guest posts on this blog in recent weeks). That might of course be a somewhat controversial statement! There is a mixture of dangers and opportunity with AI and I think your call of wider discussion and communication is an excellent one. This is exactly what we want to come our of this initiative.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9aac05a558797d32c15f55d878a48d42da70b746702d86f0d119ed7c3d5d3f7-271938281befc09d4e62e209f9ef583576efda8ebe21909421f3a2ddbe083be5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Oliver")]], [#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/#comment-696782")[#strong[#text("William Oliver")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("I agree with this whole-heartedly, except in so far as I disagree about the source of the ‘fracture’. I don’t think it is the difference between ‘results-driven’ and ‘understanding-driven’ people.")

#text("It seems to me like all sides agree that mathematics is about ‘understanding’, and I think the ‘problem-solver’ kind of people would take some offense to being characterized as not caring about understanding. Its just that they don’t all seem to care about ")#emph[#text("human ")]#text("understanding. The various ‘declarations’ that have been made by mathematicians, and the various responses to these declarations, seem to provide some evidence for this view.")

#text("The real issue, I think, is a fundamental disagreement about what ‘understanding’ actually ")#emph[#text("is, ")]#text("and whether or not it is possible for an AI to demonstrate some kind of understanding. This disagreement is extremely natural because this question, in some form or another, has arguably been a subject of philosophical debate in various traditions for millennia, and we should not expect all modern day mathematicians to naturally have any agreement about the nature of this term. To think that we should come to some easy natural agreement, or that the question “what is understanding?” is ‘easy’ would be, in my opinion, extremely prideful and perhaps offensive to the practice of philosophy. On the other hand, to think that we should not address this question as mathematicians, just because we are not ‘philosophers’ is equally problematic, because not tackling this question head on only creates more division.")

#text("I have tried to be relatively vocal about this in the comments of these posts without coming off as aggressive. I think the modern mathematical culture of philosophical agnosticism has become increasingly frustrating, and I think it needs to be (at least temporarily) suspended so that we can come to some agreement on this matter. I think most mathematicians do have some philosophical position about the nature of ‘understanding’ in mathematics, and these philosophical positions are guiding their decisions, but they are not stating these positions publicly, so there is no way to challenge them. To me, this seems rather misguided. If the decisions of our mathematical leaders are based on fundamentally wrong assumptions but these assumptions never have a chance to be genuinely challenged, then there is no hope for the direction mathematics will take in the future.")

#text("I also would like to say that another reason the question “what is understanding?” is so important is that I believe the environmental, economic, and political issues related to AI in general are all downstream consequences of our ignoring this question. In other words, the AI companies are ")#emph[#text("trying")]#text(" to get AI to demonstrate true ‘understanding’ in some sense, and if this is impossible, then of course they will need to use more and more energy, engage in data theft, carry out shady marketing tactics, engage in political manipulation, and in general be dishonest to keep up the illusion. This would be true even if they did not have any ill-intentions. It is like if a company claimed to sell a perpetual motion machine: such a company would need to resort to all kinds of shady practices, even if they actually believed that they were creating a perpetual motion machine and believed they were being honest.")

#text("So I think a more concerted effort to actually get at what ‘understanding’ means and in general to iron out the limitations of modern AI, would")

#list(
[#text("Create far more ‘alignment’ between the two sides of this debate.")],
[#text("Help stop AI companies from engaging in bad faith tactics, in a similar sense to how the invention of thermodynamics laid the groundwork for all kinds of helpful regulations and initiatives surrounding energy production and use after the industrial revolution.")]
)
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/61115be3303f3c205803299e0f7bf10b3305a7a5b3b99af57971a12009f46491-63729fdb74bb55e8200d8e15acc0ea84e12cf455832076b37fe44337571b35fe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lammartin")]], [#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/#comment-696766")[#strong[#text("lammartin")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("I’d like to be clear from the outset that I’m not opposed to the use of AI in research and welcome whatever tools are available to advance the field.")

#text("What I don’t quite understand are the incentives for participating in such a project, either by contributing problems or solutions.")

#text("1) Why should one submit a problem? Sharing the problem with a wider mathematical audience is obviously a good idea, but I don’t see the motivation for doing so by putting it on a hit list that will likely be more the focus of scraping AI agents that are spawned by people with no intrinsic interest.2) Why should I attempt to prompt myself to a solution of a problem I know nothing about? I’ll not understand the solution, can’t claim it as my own, and may end up preempting someone who is genuinely invested. Personally, I’d rather see a solution arrive from someone who has thought deeply about the question, even if that solution is eventually reached with substantial AI assistance.")

#text("There are other issues that have been mentioned in other comments. I do understand the argument that if you don’t do it, someone else will (and sites like VibeMathed already exist). Blame the game, not the player. But then again, when I see a wallet I will not steal it just because if I don’t do it, someone else will. In any case, I think it’s good to have a discussion, as I think this needs more thought. I agree with the focus on the presentation, simplification and dissemination of results. That is likely the way forward for problem-sovling oriented math.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ef179a4845f930977921170262dfa5f55128d5d279f0ddee59d0f0eb19f204d-6349196ea317397f75ebde55cc50147a50ffd0250864465256422f06122d4566.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mjc249")]], [#link("https://terrytao.wordpress.com/2026/10/02/aim-an-invitation-to-explore-mathematics-together/#comment-696783")[#strong[#text("mjc249")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("Thanks for this.")

#text("Going first to your analogy, I would like to think we can somehow find a way of achieving the act of turning the wallet into lost property to be returned to it’s owner (which I guess would be some suitable collection of mathematicians) before it gets stolen. Of course even the word “owner” in this context could be loaded (who and how should decide what that is?). The hope is that seeking human explanations in the “explained” website acts as a filter in this manner, by providing a space that’s more moderated (in particular guarded against papers that are completely AI generated with no human component) and less rapid than what has been happening recently. Whether or not this is the best way to achieve that scenario remains to be seen. Any thoughts on how to do this are most welcome.")

#text("Regarding your earlier points.")

#text("1) It’s now possible in a matter of hours to cook up a problem list with 100s of problems. I am not sure whether a problem that’s already in the public domain is “safe” just because it’s not on a list. Likely it probably is a little more safe, at least for the time being, but I don’t think anything that’s public is safe from AI scrapers. The sad effect of this is that researchers will be less inclined to share results before they are complete and answer every question. The hope is that the “explained” website is a less chaotic place where those interested in the problems (especially students) get credit for the explanation.")

#text("2) I agree and would say don’t. But I hope that those interested in the problems are the ones who actually do the proper write ups or videos. People may even become interested in and think deeply about problems through the collection.")

#text("I hope that helps clarifies your questions. Please do continue to provide thoughts.")
]
]
