// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/
// Converted to Typst by tao2typ: "2026-10-14T16:37:48.733174+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "275A, Notes 2: Product measures and independence", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("275A, Notes 2: Product measures and independence")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 October 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/")[#text("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the ")#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/")[#text("previous set of notes")]#text(", we constructed the measure-theoretic notion of the Lebesgue integral, and used this to set up the probabilistic notion of expectation on a rigorous footing. In this set of notes, we will similarly construct the measure-theoretic concept of a ")#link("https://en.wikipedia.org/wiki/Product_measure")[#text("product measure")]#text(" (restricting to the case of probability measures to avoid unnecessary technicalities), and use this to set up the probabilistic notion of ")#link("https://en.wikipedia.org/wiki/Independence_(probability_theory)")[#text("independence")]#text(" on a rigorous footing. (To quote Durrett: “measure theory ends and probability theory begins with the definition of independence.”) We will be able to take virtually any collection of random variables (or probability distributions) and couple them together to be independent via the product measure construction, though for infinite products there is the slight technicality (a requirement of the ")#link("https://en.wikipedia.org/wiki/Kolmogorov_extension_theorem")[#text("Kolmogorov extension theorem")]#text(") that the random variables need to range in ")#link("https://en.wikipedia.org/wiki/Borel_equivalence_relation")[#text("standard Borel spaces")]#text(". This is not the only way to couple together such random variables, but it is the simplest and the easiest to compute with in practice, as we shall see in the next few sets of notes.")#linebreak()

#metadata(none) <tao-de0b5efc0d4d841c0c2a>

#strong[#text(" — 1. Product measures — ")]

#text("It is intuitively obvious that Lebesgue measure ")#mi("{m^2}")#text(" on ")#mi("{{\\bf R}^2}")#text(" ought to be related to Lebesgue measure ")#mi("{m}")#text(" on ")#mi("{{\\bf R}}")#text(" by the relationship ")#metadata(none) <tao-09c5ad78abd4846482f8>

#mi("\\displaystyle m^2( E_1 \\times E_2 ) = m(E_1) m(E_2) \\ \\ \\ \\ \\ (1)")

#text("for any Borel sets ")#mi("{E_1, E_2 \\subset {\\bf R}}")#text(". This is in fact true (see Exercise ")#link(<tao-597c28c381ef1feee61f>)[#text("5")]#text(" below), and is part of a more general phenomenon, which we phrase here in the case of probability measures:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Product of two probability spaces)")]#text(" ")#metadata(none) <tao-6754af9632a2745e85c2>#text(" Let ")#mi("{(\\Omega_1, {\\mathcal F}_1, \\mu_1)}")#text(" and ")#mi("{(\\Omega_2, {\\mathcal F}_2, \\mu_2)}")#text(" be probability spaces. Then there is a unique probability measure ")#mi("{\\mu_1 \\times \\mu_2}")#text(" on ")#mi("{(\\Omega_1 \\times \\Omega_2, {\\mathcal F}_1 \\times {\\mathcal F}_2)}")#text(" with the property that ")#metadata(none) <tao-f4a4ce5fa6340a35aa5d>

#mi("\\displaystyle \\mu_1 \\times \\mu_2( E_1 \\times E_2 ) = \\mu_1(E_1) \\mu_2(E_2) \\ \\ \\ \\ \\ (2)")

#text("for all ")#mi("{E_1 \\in {\\mathcal F}_1, E_2 \\in {\\mathcal F}_2}")#text(". Furthermore, we have the following two facts:")

#list(
[#text("(Tonelli theorem) If ")#mi("{f: \\Omega_1 \\times \\Omega_2 \\rightarrow [0,+\\infty]}")#text(" is measurable, then for each ")#mi("{\\omega_1 \\in \\Omega_1}")#text(", the function ")#mi("{\\omega_2 \\mapsto f(\\omega_1,\\omega_2)}")#text(" is measurable on ")#mi("{\\Omega_2}")#text(", and the function ")#mi("{\\omega_1 \\mapsto \\int_{\\Omega_2} f(\\omega_1,\\omega_2)\\ d\\mu_2(\\omega_2)}")#text(" is measurable on ")#mi("{\\Omega_1}")#text(". Similarly, for each ")#mi("{\\omega_2 \\in \\Omega_2}")#text(", the function ")#mi("{\\omega_1 \\mapsto f(\\omega_1,\\omega_2)}")#text(" is measurable on ")#mi("{\\Omega_1}")#text("and ")#mi("{\\omega_2 \\mapsto \\int_{\\Omega_1} f(\\omega_1,\\omega_2)\\ d\\mu_1(\\omega_1)}")#text(" is measurable on ")#mi("{\\Omega_2}")#text(". Finally, we have")#linebreak()

#align(center)[#tao-fit-display[#mitex("\\int_{\\Omega_1 \\times \\Omega_2} f\\ d(\\mu_1 \\times \\mu_2) = \\int_{\\Omega_1} (\\int_{\\Omega_2} f(\\omega_1,\\omega_2)\\ d\\mu_2(\\omega_2)) d\\mu_1(\\omega_1)")]]

#linebreak()

#align(center)[#tao-fit-display[#mitex("= \\int_{\\Omega_2} (\\int_{\\Omega_1} f(\\omega_1,\\omega_2)\\ d\\mu_1(\\omega_1)) d\\mu_2(\\omega_2).")]]

#linebreak()],
[#text("(Fubini theorem) If ")#mi("{f: \\Omega_1 \\times \\Omega_2 \\rightarrow {\\bf C}}")#text(" is absolutely integrable, then for ")#mi("{\\mu_1}")#text("-almost every ")#mi("{\\omega_1 \\in \\Omega_1}")#text(", the function ")#mi("{\\omega_2 \\mapsto f(\\omega_1,\\omega_2)}")#text(" is absolutely integrable on ")#mi("{\\Omega_2}")#text(", and the function ")#mi("{\\omega_1 \\mapsto \\int_{\\Omega_2} f(\\omega_1,\\omega_2)\\ d\\mu_2(\\omega_2)}")#text(" is absolutely integrable on ")#mi("{\\Omega_1}")#text(". Similarly, for ")#mi("{\\mu_2}")#text("-almost every ")#mi("{\\omega_2 \\in \\Omega_2}")#text(", the function ")#mi("{\\omega_1 \\mapsto f(\\omega_1,\\omega_2)}")#text(" is absolutely integrable on ")#mi("{\\Omega_1}")#text(" and ")#mi("{\\omega_2 \\mapsto \\int_{\\Omega_1} f(\\omega_1,\\omega_2)\\ d\\mu_1(\\omega_1)}")#text(" is absolutely integrable on ")#mi("{\\Omega_2}")#text(". Finally, we have")#linebreak()

#align(center)[#tao-fit-display[#mitex("\\int_{\\Omega_1 \\times \\Omega_2} f\\ d(\\mu_1 \\times \\mu_2) = \\int_{\\Omega_1} (\\int_{\\Omega_2} f(\\omega_1,\\omega_2)\\ d\\mu_2(\\omega_2)) d\\mu_1(\\omega_1)")]]

#linebreak()

#align(center)[#tao-fit-display[#mitex("= \\int_{\\Omega_2} (\\int_{\\Omega_1} f(\\omega_1,\\omega_2)\\ d\\mu_1(\\omega_1)) d\\mu_2(\\omega_2).")]]

#linebreak()]
)
]

#text("The Fubini and Tonelli theorems are often used together (so much so that one may refer to them as a single theorem, the ")#link("https://en.wikipedia.org/wiki/Fubini%27s_theorem")[#text("Fubini-Tonelli theorem")]#text(", often also just referred to as ")#emph[#text("Fubini’s theorem")]#text(" in the literature). For instance, given an absolutely integrable function ")#mi("{f_1: \\Omega_1 \\rightarrow {\\bf C}}")#text(" and an absolutely integrable function ")#mi("{f_2: \\Omega_2 \\rightarrow {\\bf C}}")#text(", the Tonelli theorem tells us that the ")#link("https://en.wikipedia.org/wiki/Tensor_product")[#text("tensor product")]#text(" ")#mi("{f_1 \\otimes f_2: \\Omega_1 \\times \\Omega_2 \\rightarrow {\\bf C}}")#text(" defined by")

#mi("\\displaystyle (f_1 \\otimes f_2)(\\omega_1, \\omega_2) := f_1(\\omega_1) f_2(\\omega_2)")

#text("for ")#mi("{\\omega_1 \\in \\Omega_1,\\omega_2 \\in \\Omega_2}")#text(", is absolutely integrable and one has the factorisation ")#metadata(none) <tao-41a093100bbbb59e31dc>

#mi("\\displaystyle \\int_{\\Omega_1 \\times \\Omega_2} f_1 \\otimes f_2\\ d(\\mu_1 \\times \\mu_2) = (\\int_{\\Omega_1} f_1\\ d\\mu_1) (\\int_{\\Omega_2} f_2\\ d\\mu_2). \\ \\ \\ \\ \\ (3)")

#text("Our proof of Theorem ")#link(<tao-6754af9632a2745e85c2>)[#text("1")]#text(" will be based on the ")#link("https://en.wikipedia.org/wiki/Monotone_class_theorem")[#text("monotone class lemma")]#text(" that allows one to conveniently generate a ")#mi("{\\sigma}")#text("-algebra from a Boolean algebra. (In Durrett, the closely related ")#link("https://en.wikipedia.org/wiki/Pi_system#The_.CF.80-.CE.BB_Theorem")[#mi("{\\pi-\\lambda}")#text(" theorem")]#text(" is used in place of the monotone class lemma.) Define a ")#emph[#text("monotone class")]#text(" in a set ")#mi("{\\Omega}")#text(" to be a collection ")#mi("{{\\mathcal F}}")#text(" of subsets of ")#mi("{\\Omega}")#text(" with the following two closure properties:")

#list(
[#text("If ")#mi("{E_1 \\subset E_2 \\subset \\ldots}")#text(" are a countable increasing sequence of sets in ")#mi("{{\\mathcal F}}")#text(", then ")#mi("{\\bigcup_{n=1}^\\infty E_n \\in {\\mathcal F}}")#text(".")],
[#text("If ")#mi("{E_1 \\supset E_2 \\supset \\ldots}")#text(" are a countable decreasing sequence of sets in ")#mi("{{\\mathcal F}}")#text(", then ")#mi("{\\bigcap_{n=1}^\\infty E_n \\in {\\mathcal F}}")#text(".")]
)

#text("Thus for instance any ")#mi("{\\sigma}")#text("-algebra is a monotone class, but not conversely. Nevertheless, there is a key way in which monotone classes “behave like” ")#mi("{\\sigma}")#text("-algebras:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Monotone class lemma)")]#text(" ")#metadata(none) <tao-64a19348509e818eb08a>#text(" Let ")#mi("{{\\mathcal A}}")#text(" be a Boolean algebra on ")#mi("{\\Omega}")#text(". Then ")#mi("{\\langle {\\mathcal A} \\rangle}")#text(" is the smallest monotone class that contains ")#mi("{{\\mathcal A}}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{{\\mathcal F}}")#text(" be the intersection of all the monotone classes that contain ")#mi("{{\\mathcal A}}")#text(". Since ")#mi("{\\langle {\\mathcal A} \\rangle}")#text(" is clearly one such class, ")#mi("{{\\mathcal F}}")#text(" is a subset of ")#mi("{\\langle {\\mathcal A} \\rangle}")#text(". Our task is then to show that ")#mi("{{\\mathcal F}}")#text(" contains ")#mi("{\\langle {\\mathcal A} \\rangle}")#text(".")#linebreak()#text(" It is also clear that ")#mi("{{\\mathcal F}}")#text(" is a monotone class that contains ")#mi("{{\\mathcal A}}")#text(". By replacing all the elements of ")#mi("{{\\mathcal F}}")#text(" with their complements, we see that ")#mi("{{\\mathcal F}}")#text(" is necessarily closed under complements.")#linebreak()#text(" For any ")#mi("{E \\in {\\mathcal A}}")#text(", consider the set ")#mi("{{\\mathcal C}_E}")#text(" of all sets ")#mi("{F \\in {\\mathcal F}}")#text(" such that ")#mi("{F \\backslash E}")#text(", ")#mi("{E \\backslash F}")#text(", ")#mi("{F \\cap E}")#text(", and ")#mi("{\\Omega \\backslash (E \\cup F)}")#text(" all lie in ")#mi("{{\\mathcal F}}")#text(". It is clear that ")#mi("{{\\mathcal C}_E}")#text(" contains ")#mi("{{\\mathcal A}}")#text("; since ")#mi("{{\\mathcal F}}")#text(" is a monotone class, we see that ")#mi("{{\\mathcal C}_E}")#text(" is also. By definition of ")#mi("{{\\mathcal F}}")#text(", we conclude that ")#mi("{{\\mathcal C}_E = {\\mathcal F}}")#text(" for all ")#mi("{E \\in {\\mathcal A}}")#text(".")#linebreak()#text(" Next, let ")#mi("{{\\mathcal D}}")#text(" be the set of all ")#mi("{E \\in {\\mathcal F}}")#text(" such that ")#mi("{F \\backslash E}")#text(", ")#mi("{E \\backslash F}")#text(", ")#mi("{F \\cap E}")#text(", and ")#mi("{\\Omega \\backslash (E \\cup F)}")#text(" all lie in ")#mi("{{\\mathcal F}}")#text(" for all ")#mi("{F \\in {\\mathcal F}}")#text(". By the previous discussion, we see that ")#mi("{{\\mathcal D}}")#text(" contains ")#mi("{{\\mathcal A}}")#text(". One also easily verifies that ")#mi("{{\\mathcal D}}")#text(" is a monotone class. By definition of ")#mi("{{\\mathcal F}}")#text(", we conclude that ")#mi("{{\\mathcal D} = {\\mathcal F}}")#text(". Since ")#mi("{{\\mathcal F}}")#text(" is also closed under complements, this implies that ")#mi("{{\\mathcal F}}")#text(" is closed with respect to finite unions. Since this class also contains ")#mi("{{\\mathcal A}}")#text(", which contains ")#mi("{\\emptyset}")#text(", we conclude that ")#mi("{{\\mathcal F}}")#text(" is a Boolean algebra. Since ")#mi("{{\\mathcal F}}")#text(" is also closed under increasing countable unions, we conclude that it is closed under arbitrary countable unions, and is thus a ")#mi("{\\sigma}")#text("-algebra. As it contains ")#mi("{{\\mathcal A}}")#text(", it must also contain ")#mi("{\\langle {\\mathcal A} \\rangle}")#text(". ")#mi("\\Box")#linebreak()#text(" We now begin the proof of Theorem ")#link(<tao-6754af9632a2745e85c2>)[#text("1")]#text(". We begin with the uniqueness claim. Suppose that we have two measures ")#mi("{\\nu, \\nu^{\\prime}}")#text(" on ")#mi("{\\Omega_1 \\times \\Omega_2}")#text(" that are product measures of ")#mi("{\\mu_1}")#text(" and ")#mi("{\\mu_2}")#text(" in the sense that ")#metadata(none) <tao-826c51aba84f3fb0d272>

#mi("\\displaystyle \\nu(E_1 \\times E_2) = \\nu^{\\prime}(E_1 \\times E_2) = \\mu_1(E_1) \\times \\mu_2(E_2) \\ \\ \\ \\ \\ (4)")

#text("for all ")#mi("{E_1 \\in {\\mathcal F}_1}")#text(" and ")#mi("{E_2 \\in {\\mathcal F}_2}")#text(". If we then set ")#mi("{{\\mathcal F}}")#text(" to be the collection of all ")#mi("{E \\in {\\mathcal F}_1 \\times {\\mathcal F}_2}")#text(" such that ")#mi("{\\nu(E) = \\nu^{\\prime}(E)}")#text(", then ")#mi("{{\\mathcal F}}")#text(" contains all sets of the form ")#mi("{E_1 \\times E_2}")#text(" with ")#mi("{E_1 \\in {\\mathcal F}_1}")#text(" and ")#mi("{E_2 \\in {\\mathcal F}_2}")#text(". In fact ")#mi("{{\\mathcal F}}")#text(" contains the collection ")#mi("{{\\mathcal A}}")#text(" of all sets that are “elementary” in the sense that they are of the form ")#mi("{\\bigcup_{i=1}^n E_{1,i} \\times E_{2,i}}")#text(" for finite ")#mi("{n}")#text(" and ")#mi("{E_{1,i} \\in {\\mathcal F}_1, E_{2,i} \\in {\\mathcal F}_2}")#text(" for ")#mi("{i=1,\\dots,n}")#text(", since such sets can be easily decomposed into a finite union of ")#emph[#text("disjoint")]#text(" products ")#mi("{E^{\\prime}_{1,i} \\times E^{\\prime}_{2,i}}")#text(", at which point the claim follows from ")#link(<tao-826c51aba84f3fb0d272>)[#text("(4)")]#text(" and finite additivity. But ")#mi("{{\\mathcal A}}")#text(" is a Boolean algebra that generates ")#mi("{{\\mathcal F}_1 \\times {\\mathcal F}_2}")#text(" as a ")#mi("{\\sigma}")#text("-algebra, and from continuity from above and below we see that ")#mi("{{\\mathcal F}}")#text(" is a monotone class. By the monotone class lemma, we conclude that ")#mi("{{\\mathcal F}}")#text(" is all of ")#mi("{{\\mathcal F}_1 \\times {\\mathcal F}_2}")#text(", and hence ")#mi("{\\nu=\\nu^{\\prime}}")#text(". This gives uniqueness. Now we prove existence. We first claim that for any measurable set ")#mi("{E \\in {\\mathcal F}_1 \\times {\\mathcal F}_2}")#text(", the sets ")#mi("{E_{\\omega_1} := \\{ \\omega_2 \\in \\Omega_2: (\\omega_1 \\times \\omega_2) \\in E\\}}")#text(" are measurable in ")#mi("{{\\mathcal F}_2}")#text(". Indeed, the claim is obvious for sets ")#mi("{E}")#text(" that are “elementary” in the sense that they belong to the Boolean algebra ")#mi("{{\\mathcal A}}")#text(" defined previously, and the collection of all such sets is a monotone class, so the claim follows from the monotone class lemma. A similar argument (relying on monotone or dominated convergence) shows that the function")

#mi("\\displaystyle \\omega_1 \\mapsto \\mu_2(E_{\\omega_1}) = \\int_{\\Omega_2} 1_E( \\omega_1, \\omega_2)\\ d\\mu_2(\\omega_2)")

#text("is measurable in ")#mi("{\\Omega_1}")#text(" for all ")#mi("{E \\in {\\mathcal F}_1 \\times {\\mathcal F}_2}")#text(". Thus, for any ")#mi("{E \\in {\\mathcal F}_1 \\times {\\mathcal F}_2}")#text(", we can define the quantity ")#mi("{(\\mu_1 \\times \\mu_2)(E)}")#text(" by")

#mi("\\displaystyle (\\mu_1 \\times \\mu_2)(E) := \\int_{\\Omega_1} \\mu_2(E_{\\omega_1})\\ d\\mu_1(\\omega_1)")

#mi("\\displaystyle = \\int_{\\Omega_1}(\\int_{\\Omega_2} 1_E( \\omega_1, \\omega_2)\\ d\\mu_2(\\omega_2))\\ d\\mu_1(\\omega_1).")

#text("A routine application of the monotone convergence theorem verifies that ")#mi("{\\mu_1 \\times \\mu_2}")#text(" is a countably additive measure; one easily checks that ")#link(<tao-f4a4ce5fa6340a35aa5d>)[#text("(2)")]#text(" holds for all ")#mi("{E_1 \\in {\\mathcal F}_1, E_2 \\in {\\mathcal F}_2}")#text(", and in particular ")#mi("{\\mu_1 \\times \\mu_2}")#text(" is a probability measure.")#linebreak()#text(" By construction, we see that the identity")

#mi("\\displaystyle \\int_{\\Omega_1 \\times \\Omega_2} f\\ d(\\mu_1 \\times \\mu_2) = \\int_{\\Omega_1} (\\int_{\\Omega_2} f(\\omega_1,\\omega_2)\\ d\\mu_2(\\omega_2))\\ d\\mu_1(\\omega_1)")

#text("holds (with all functions integrated being measurable) whenever ")#mi("{f}")#text(" is an indicator function ")#mi("{f=1_E}")#text(" with ")#mi("{E \\in {\\mathcal F}_1 \\times {\\mathcal F}_2}")#text(". By linearity of integration, the same identity holds (again with all functions measurable) when ")#mi("{f: \\Omega_1 \\times \\Omega_2 \\rightarrow [0,+\\infty]}")#text(" is an unsigned simple function. Since any unsigned measurable function ")#mi("{f}")#text(" can be expressed as the monotone non-decreasing limit of unsigned simple functions ")#mi("{f_n}")#text(" (for instance, one can round ")#mi("{f}")#text(" down to the largest multiple of ")#mi("{2^{-n}}")#text(" that is less than ")#mi("{n}")#text(" and ")#mi("{f}")#text("), the above identity also holds for unsigned measurable ")#mi("{f}")#text(" by the monotone convergence theorem. Applying this fact to the absolute value ")#tao-math("{\\left|f\\right|}", block: false)#text(" of an absolutely integrable function ")#mi("{f: \\Omega_1 \\times \\Omega_2 \\rightarrow {\\bf C}}")#text(", we conclude for such functions that")

#mi("\\displaystyle \\int_{\\Omega_1} (\\int_{\\Omega_2} |f|(\\omega_1,\\omega_2)\\ d\\mu_2(\\omega_2))\\ d\\mu_1(\\omega_1) < \\infty")

#text("which by Markov’s inequality implies that")

#mi("\\displaystyle \\int_{\\Omega_2} |f|(\\omega_1,\\omega_2)\\ d\\mu_2(\\omega_2) < \\infty")

#text("for ")#mi("{\\mu_1}")#text("-almost every ")#mi("{\\omega_1 \\in \\Omega_1}")#text(". In other words, the function ")#mi("{\\omega_2 \\mapsto f(\\omega_1,\\omega_2)}")#text(" is absolutely integrable on ")#mi("{\\Omega_2}")#text(" for ")#mi("{\\mu_1}")#text("-almost every ")#mi("{\\omega_1 \\in \\Omega_1}")#text(". By monotonicity we conclude that")

#mi("\\displaystyle \\int_{\\Omega_1} |\\int_{\\Omega_2} f(\\omega_1,\\omega_2)\\ d\\mu_2(\\omega_2)|\\ d\\mu_1(\\omega_1) < \\infty")

#text("and hence the function ")#mi("{\\omega_1 \\mapsto \\int_{\\Omega_2} f(\\omega_1,\\omega_2)\\ d\\mu_2(\\omega_2)}")#text(" is absolutely integrable. Hence it makes sense to ask whether the identity")

#mi("\\displaystyle \\int_{\\Omega_1 \\times \\Omega_2} f\\ d(\\mu_1 \\times \\mu_2) = \\int_{\\Omega_1} \\int_{\\Omega_2} f(\\omega_1,\\omega_2)\\ d\\mu_2(\\omega_2)\\ d\\mu_1(\\omega_1)")

#text("holds for absolutely integrable ")#mi("{f}")#text(", as both sides are well-defined. We have already established this claim when ")#mi("{f}")#text(" is unsigned and absolutely integrable; by subtraction this implies the claim for real-valued absolutely integrable ")#mi("{f}")#text(", and by taking real and imaginary parts we obtain the claim for complex-valued absolutely integrable ")#mi("{f}")#text(".")#linebreak()#text(" We may reverse the roles of ")#mi("{\\Omega_1}")#text(" and ")#mi("{\\Omega_2}")#text(", and define ")#mi("{\\mu_1 \\times \\mu_2}")#text(" instead by the formula")

#mi("\\displaystyle (\\mu_1 \\times \\mu_2)(E) = \\int_{\\Omega_2}(\\int_{\\Omega_1} 1_E( \\omega_1, \\omega_2)\\ d\\mu_1(\\omega_1))\\ d\\mu_2(\\omega_2).")

#text("By the previously proved uniqueness of product measure, we see that this defines the same product measure ")#mi("{\\mu_1 \\times \\mu_2}")#text(" as previously. Repeating the previous arguments we obtain all the above claims with the roles of ")#mi("{\\Omega_1}")#text(" and ")#mi("{\\Omega_2}")#text(" reversed. This gives all the claims required for Theorem ")#link(<tao-6754af9632a2745e85c2>)[#text("1")]#text(".")#linebreak()#text(" One can extend the product construction easily to finite products:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3 (Finite products)")]#text(" ")#metadata(none) <tao-5aef96240bca5582e6fd>#text(" Show that for any finite collection ")#mi("{(\\Omega_i, {\\mathcal F}_i, \\mu_i)_{i \\in A}}")#text(" of probability spaces, there exists a unique probability measure ")#mi("{\\prod_{i \\in A} \\mu_i}")#text(" on ")#mi("{(\\prod_{i \\in A} \\Omega_i, \\prod_{i \\in A} {\\mathcal F}_i)}")#text(" such that")

#mi("\\displaystyle (\\prod_{i \\in A}\\mu_i)(\\prod_{i \\in A} E_i) = \\prod_{i \\in A} \\mu_i(E_i)")

#text("whenever ")#mi("{E_i \\in {\\mathcal F}_i}")#text(" for ")#mi("{i \\in A}")#text(". Furthermore, show that")

#mi("\\displaystyle \\prod_{i \\in A}\\mu_i = (\\prod_{i \\in A_1}\\mu_i) \\times (\\prod_{i \\in A_2}\\mu_i)")

#text("for any partition ")#mi("{A = A_1 \\uplus A_2}")#text(" (after making the obvious identification between ")#mi("{\\prod_{i \\in A} \\Omega_i}")#text(" and ")#mi("{(\\prod_{i \\in A_1} \\Omega_i) \\times (\\prod_{i \\in A_2} \\Omega_i)}")#text("). Thus for instance one has the associativity property")

#mi("\\displaystyle \\mu_1 \\times \\mu_2 \\times \\mu_3 = (\\mu_1 \\times \\mu_2) \\times \\mu_3 = \\mu_1 \\times (\\mu_2 \\times \\mu_3)")

#text("for any probability spaces ")#mi("{(\\Omega_i, {\\mathcal F}_i, \\mu_i)}")#text(" for ")#mi("{i=1,\\dots,3}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Let ")#mi("{\\mu_1,\\dots,\\mu_n}")#text(" be probability measures on ")#mi("{{\\bf R}}")#text(", and let ")#mi("{F_1,\\dots,F_n: {\\bf R} \\rightarrow [0,1]}")#text(" be their Stieltjes measure functions. Show that ")#mi("{\\mu_1 \\times \\dots \\mu_n}")#text(" is the unique probability measure ")#mi("{\\mu}")#text(" on ")#mi("{{\\bf R}^n}")#text(" whose Stietljes measure function ")#mi("{(t_1,\\dots,t_n) := \\mu( (-\\infty,t_1] \\times \\dots \\times (-\\infty,t_n])}")#text(" is the tensor product ")#mi("{(t_1,\\dots,t_n) \\mapsto F_1(t_1) \\dots F_n(t_n)}")#text(" of ")#mi("{F_1,\\dots,F_n}")#text(".")
]

#text("By writing ")#mi("{\\prod_{i \\in A} \\mu_i}")#text(" as products of pairs of probability spaces in many different ways, one can obtain a higher-dimensional analogue of the Fubini and Tonelli theorems; we leave the precise statement of such a theorem to the interested reader.")#linebreak()#text(" It is important to be aware that the Fubini theorem identity ")#metadata(none) <tao-6f79f083a467060dee42>

#mi("\\displaystyle \\int_{\\Omega_1} (\\int_{\\Omega_2} f(\\omega_1,\\omega_2)\\ d\\mu_2(\\omega_2)) d\\mu_1(\\omega_1) = \\int_{\\Omega_2} (\\int_{\\Omega_1} f(\\omega_1,\\omega_2)\\ d\\mu_1(\\omega_1)) d\\mu_2(\\omega_2) \\ \\ \\ \\ \\ (5)")

#text("for measurable functions ")#mi("{f: \\Omega_1 \\times \\Omega_2 \\rightarrow {\\bf C}}")#text(" that are not unsigned, are usually only justified when ")#mi("{f}")#text(" is absolutely integrable on ")#mi("{\\Omega_1 \\times \\Omega_2}")#text(", or equivalently (by the Tonelli theorem) the function ")#mi("{\\omega_1 \\mapsto \\int_{\\Omega_2} |f(\\omega_1,\\omega_2)|\\ d\\mu_2(\\omega_2)}")#text(" is absolutely integrable on ")#mi("{\\Omega_1}")#text(" (or that ")#mi("{\\omega_2 \\mapsto \\int_{\\Omega_1} |f(\\omega_1,\\omega_2)|\\ d\\mu_1(\\omega_1)}")#text(" is absolutely integrable on ")#mi("{\\Omega_2}")#text(". Without this joint absolute integrability (and without any unsigned property on ")#mi("{f}")#text("), the identity ")#link(<tao-6f79f083a467060dee42>)[#text("(5)")]#text(" can fail even if both sides are well-defined. For instance, let ")#mi("{\\Omega_1 = \\Omega_2}")#text(" be the unit interval ")#mi("{[0,1]}")#text(", and let ")#mi("{\\mu_1 = \\mu_2}")#text(" be the uniform probability measure on this interval, and set")

#mi("\\displaystyle f(\\omega_1,\\omega_2) := \\prod_{n=1}^\\infty 2^n 1_{[2^{-n}, 2^{-n+1})}(\\omega_1)")

#mi("\\displaystyle \\times (2^n 1_{[2^{-n}, 2^{-n+1})}(\\omega_2) - 2^{n+1} 1_{[2^{-n-1}, 2^{-n})}(\\omega_2)).")

#text("One can check that both sides of ")#link(<tao-6f79f083a467060dee42>)[#text("(5)")]#text(" are well-defined, but that the left-hand side is ")#mi("{0}")#text(" and the right-hand side is ")#mi("{1}")#text(". Of course, this function is neither unsigned nor jointly absolutely integrable, so this counterexample does not violate either of the Fubini or Tonelli theorems. Thus one should take care to only interchange integrals when the integrands are known to be either unsigned or jointly absolutely integrable, or if one has another way to rigorously justify the exchange of integrals.")#linebreak()#text(" The above theory extends from probability spaces to finite measure spaces, and more generally to measure spaces that are ")#link("https://en.wikipedia.org/wiki/%CE%A3-finite_measure")[#mi("{\\sigma}")#text("-finite")]#text(", that is to say they are expressable as the countable union of sets of finite measure. (With a bit of care, some portions of product measure theory are even extendible to non-sigma-finite settings, though I urge caution in applying these results blindly in that case.) We will not give the details of these generalisations here, but content ourselves with one example:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" ")#metadata(none) <tao-597c28c381ef1feee61f>#text(" Establish ")#link(<tao-09c5ad78abd4846482f8>)[#text("(1)")]#text(" for all Borel sets ")#mi("{E_1,E_2 \\subset {\\bf R}}")#text(". (")#emph[#text("Hint:")]#text(" ")#mi("{{\\bf R}}")#text(" can be viewed as the disjoint union of a countable sequence of sets of measure ")#mi("{1}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" When doing real analysis (as opposed to probability), it is convenient to ")#link("https://en.wikipedia.org/wiki/Complete_measure")[#text("complete")]#text(" the Borel ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}[{\\bf R}^n]}")#text(" on spaces such as ")#mi("{{\\bf R}^n}")#text(", to form the larger ")#emph[#text("Lebesgue ")#mi("{\\sigma}")#text("-algebra")]#text(" ")#mi("{{\\mathcal L}[{\\bf R}^n]}")#text(", defined as the collection of all subsets ")#mi("{E}")#text(" in ")#mi("{{\\bf R}^n}")#text(" that differ from a Borel set ")#mi("{F}")#text(" in ")#mi("{{\\bf R}^n}")#text(" by a sub-null set, in the sense that ")#mi("{E \\Delta F \\subset G}")#text(" for some Borel subset ")#mi("{G}")#text(" of ")#mi("{{\\bf R}^n}")#text(" of zero Lebesgue measure. There are analogues of the Fubini and Tonelli theorems for such complete ")#mi("{\\sigma}")#text("-algebras; see ")#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/")[#text("this previous lecture notes")]#text(" for details. However one should be cautioned that the product ")#mi("{{\\mathcal L}[{\\bf R}^{n_1}] \\times {\\mathcal L}[{\\bf R}^{n_2}]}")#text(" of Lebesgue ")#mi("{\\sigma}")#text("-algebras is ")#emph[#text("not")]#text(" the Lebesgue ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal L}[{\\bf R}^{n_1+n_2}]}")#text(", but is instead an intermediate ")#mi("{\\sigma}")#text("-algebra between ")#mi("{{\\mathcal B}[{\\bf R}^{n_1+n_2}]}")#text(" and ")#mi("{{\\mathcal L}[{\\bf R}^{n_1+n_2}]}")#text(", which causes some additional small complications. For instance, if ")#mi("{f: {\\bf R}^{n_1+n_2} \\rightarrow {\\bf C}}")#text(" is Lebesgue measurable, then the functions ")#mi("{x_2 \\mapsto f(x_1,x_2)}")#text(" can only be found to be Lebesgue measurable on ")#mi("{{\\bf R}^{n_2}}")#text(" for ")#emph[#text("almost every")]#text(" ")#mi("{x_1 \\in {\\bf R}^{n_1}}")#text(", rather than for ")#emph[#text("all")]#text(" ")#mi("{x_1 \\in {\\bf R}^{n_1}}")#text(". We will not dwell on these subtleties further here, as we will rarely have any need to complete the ")#mi("{\\sigma}")#text("-algebras used in probability theory.")
]

#text("It is also important in probability theory applications to form the product of an ")#emph[#text("infinite")]#text(" number of probability spaces ")#mi("{(\\Omega_i, {\\mathcal F}_i, \\mu_i)}")#text(" for ")#mi("{i \\in A}")#text(", where ")#mi("{A}")#text(" can be infinite or even uncountable. Recall from ")#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/")[#text("Notes 0")]#text(" that the product ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal F}_A := \\prod_{i \\in A} {\\mathcal F}_i}")#text(" on ")#mi("{\\Omega_A := \\prod_{i \\in A} \\Omega_i}")#text(" is defined to be the ")#mi("{\\sigma}")#text("-algebra generated by the sets ")#mi("{\\pi_j^{-1}(E_j)}")#text(" for ")#mi("{j \\in A}")#text(" and ")#mi("{E_j \\in {\\mathcal F}_j}")#text(", where ")#mi("{\\pi_j: \\Omega_A \\rightarrow \\Omega_j}")#text(" is the usual coordinate projection. Equivalently, if we define an ")#emph[#text("elementary set")]#text(" to be a subset of ")#mi("{\\Omega_A}")#text(" of the form ")#mi("{\\pi_B^{-1}(E_B)}")#text(", where ")#mi("{B}")#text(" is a finite subset of ")#mi("{A}")#text(", ")#mi("{\\pi_B: \\Omega_A \\rightarrow \\Omega_B}")#text(" is the obvious projection map to ")#mi("{\\Omega_B := \\prod_{i \\in B} \\Omega_i}")#text(", and ")#mi("{E_B}")#text(" is a measurable set in ")#mi("{{\\mathcal F}_B := \\prod_{i \\in B} {\\mathcal F}_i}")#text(", then ")#mi("{{\\mathcal F}_A}")#text(" can be defined as the ")#mi("{\\sigma}")#text("-algebra generated by the collection ")#mi("{{\\mathcal A}}")#text(" of elementary sets. (Elementary sets are the measure-theoretic analogue of ")#link("https://en.wikipedia.org/wiki/Cylinder_set")[#text("cylinder sets")]#text(" in point set topology.) For future reference we note the useful fact that ")#mi("{{\\mathcal A}}")#text(" is a Boolean algebra.")#linebreak()#text(" We define a ")#emph[#text("product measure")]#text(" ")#mi("{\\mu_A = \\prod_{i \\in A} \\mu_i}")#text(" to be a probability measure on the measurable space ")#mi("{(\\Omega_A, {\\mathcal F}_A)}")#text(" which extends all of the finite products in the sense that")

#mi("\\displaystyle \\mu_A( \\pi_B^{-1}(E_B) ) = \\mu_B(E_B)")

#text("for all finite subsets ")#mi("{B}")#text(" of ")#mi("{A}")#text(" and all ")#mi("{E_B}")#text(" in ")#mi("{{\\mathcal F}_B}")#text(", where ")#mi("{\\mu_B := \\prod_{i \\in B} \\mu_i}")#text(". If this product measure exists, it is unique:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" ")#metadata(none) <tao-4b4d5589e12d32d58935>#text(" Show that for any collection of probability spaces ")#mi("{(\\Omega_i, {\\mathcal F}_i, \\mu_i)}")#text(" for ")#mi("{i \\in A}")#text(", there is at most one product measure ")#mi("{\\mu_A}")#text(". (")#emph[#text("Hint:")]#text(" adapt the uniqueness argument in Theorem ")#link(<tao-6754af9632a2745e85c2>)[#text("1")]#text(" that used the monotone class lemma.)")
]

#text("In the case of finite ")#mi("{A}")#text(", the finite product constructed in Exercise ")#link(<tao-5aef96240bca5582e6fd>)[#text("3")]#text(" is clearly the unique product. But for infinite ")#mi("{A}")#text(", the construction of product measure is a more nontrivial issue. We can generalise the problem as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 8 (Extension problem)")]#text(" ")#metadata(none) <tao-ebd000993b178bfb5761>#text(" Let ")#mi("{(\\Omega_i, {\\mathcal F}_i)_{i \\in A}}")#text(" be a collection of measurable spaces. For each finite ")#mi("{B \\subset A}")#text(", let ")#mi("{\\mu_B}")#text(" be a probability measure on ")#mi("{(\\Omega_B, {\\mathcal F}_B)}")#text(" obeying the compatibility condition ")#metadata(none) <tao-6b34aac75fa8f22f4f29>

#mi("\\displaystyle \\mu_B( \\pi_{B \\rightarrow C}^{-1}(E_C) ) = \\mu_C(E_C) \\ \\ \\ \\ \\ (6)")

#text("for all finite ")#mi("{C \\subset B \\subset A}")#text(" and ")#mi("{E_C \\in {\\mathcal F}_C}")#text(", where ")#mi("{\\pi_{B \\rightarrow C}: \\Omega_B \\rightarrow \\Omega_C}")#text(" is the obvious restriction. Can one then define a probability measure ")#mi("{\\mu_A}")#text(" on ")#mi("{(\\Omega_A, {\\mathcal F}_A)}")#text(" such that ")#metadata(none) <tao-2c5eabe54a77de0e53c2>

#mi("\\displaystyle \\mu_A( \\pi_{B}^{-1}(E_B) ) = \\mu_B(E_B) \\ \\ \\ \\ \\ (7)")

#text("for all finite ")#mi("{B \\subset A}")#text(" and ")#mi("{E_B \\subset {\\mathcal F}_B}")#text("?")
]

#text("Note that the compatibility condition ")#link(<tao-6b34aac75fa8f22f4f29>)[#text("(6)")]#text(" is clearly necessary if one is to find a measure ")#mi("{\\mu_A}")#text(" obeying ")#link(<tao-2c5eabe54a77de0e53c2>)[#text("(7)")]#text(".")#linebreak()#text(" Again, one has uniqueness:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" ")#metadata(none) <tao-4d0282941aaf2d694dda>#text(" Show that for any ")#mi("{(\\Omega_i, {\\mathcal F}_i)_{i \\in A}}")#text(" and ")#mi("{\\mu_B}")#text(" for finite ")#mi("{B \\subset A}")#text(" as in the above extension problem, there is at most one probability measure ")#mi("{\\mu_A}")#text(" with the stated properties.")
]

#text("The extension problem is trivial for finite ")#mi("{A}")#text(", but for infinite ")#mi("{A}")#text(" there are unfortunately examples where the probability measure ")#mi("{\\mu_A}")#text(" fails to exist. However, there is one key case in which we can build the extension, thanks to the ")#link("https://en.wikipedia.org/wiki/Kolmogorov_extension_theorem")[#text("Kolmogorov extension theorem")]#text(". Call a measurable space ")#mi("{(\\Omega,{\\mathcal F})}")#text(" ")#link("https://en.wikipedia.org/wiki/Borel_equivalence_relation")[#text("standard Borel")]#text(" if it is isomorphic as a measurable space to a Borel subset of the unit interval ")#mi("{[0,1]}")#text(" with Borel measure, that is to say there is a bijection ")#mi("{f}")#text(" from ")#mi("{\\Omega}")#text(" to a Borel subset ")#mi("{E}")#text(" of ")#mi("{[0,1]}")#text(" such that ")#mi("{f: \\Omega \\rightarrow E}")#text(" and ")#mi("{f^{-1}: E \\rightarrow \\Omega}")#text(" are both measurable. (In Durrett, such spaces are called ")#emph[#text("nice spaces")]#text(".) Note that one can easily replace ")#mi("{[0,1]}")#text(" by other standard spaces such as ")#mi("{{\\bf R}}")#text(" if desired, since these spaces are isomorphic as measurable spaces (why?).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 10 (Kolmogorov extension theorem)")]#text(" ")#metadata(none) <tao-ff47bb1aedd9ede5de2a>#text(" Let the situation be as in Problem ")#link(<tao-ebd000993b178bfb5761>)[#text("8")]#text(". If all the measurable spaces ")#mi("{(\\Omega_i,{\\mathcal F}_i)}")#text(" are standard Borel, then there exists probability measure ")#mi("{\\mu_A}")#text(" solving the extension problem (which is then unique, thanks to Exercise ")#link(<tao-4d0282941aaf2d694dda>)[#text("9")]#text(").")
]

#text("The proof of this theorem is lengthy and is deferred to the next (optional) section. Specialising to the product case, we conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 11")]#text(" ")#metadata(none) <tao-bd86e3303063c60af9dc>#text(" Let ")#mi("{(\\Omega_i, {\\mathcal F}_i, \\mu_i)_{i \\in A}}")#text(" be a collection of probability spaces with ")#mi("{(\\Omega_i, {\\mathcal F}_i)}")#text(" standard Borel. Then there exists a product measure ")#mi("{\\prod_{i \\in A} \\mu_i}")#text(" (which is then unique, thanks to Exercise ")#link(<tao-4b4d5589e12d32d58935>)[#text("7")]#text(").")
]

#text("Of course, to use this theorem we would like to have a large supply of standard Borel spaces. Here is one tool that often suffices:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 12")]#text(" Let ")#mi("{(X,d)}")#text(" be a complete separable metric space, and let ")#mi("{\\Omega}")#text(" be a Borel subset of ")#mi("{X}")#text(". Then ")#mi("{\\Omega}")#text(" (with the Borel ")#mi("{\\sigma}")#text("-algebra) is standard Borel.")
]

#emph[#text("Proof:")]#text(" Let us call two topological spaces ")#link("https://en.wikipedia.org/wiki/Borel_isomorphism")[#text("Borel isomorphic")]#text(" if their corresponding Borel structures are isomorphic as measurable spaces. Using the binary expansion, we see that ")#mi("{[0,1]}")#text(" is Borel isomorphic to ")#mi("{\\{0,1\\}^{\\bf N}}")#text(" (the countable number of points that have two binary expansions can be easily permuted to obtain a genuine isomorphism). Similarly ")#mi("{[0,1]^{\\bf N}}")#text(" is Borel isomorphic to ")#mi("{\\{0,1\\}^{{\\bf N} \\times {\\bf N}}}")#text(". Since ")#mi("{{\\bf N} \\times {\\bf N}}")#text(" is in bijection with ")#mi("{{\\bf N}}")#text(", we conclude that ")#mi("{[0,1]^{\\bf N}}")#text(" is Borel isomorphic to ")#mi("{[0,1]}")#text(". Thus it will suffice to to show that every complete separable metric space ")#mi("{(X,d)}")#text(" is Borel isomorphic to a Borel subset of ")#mi("{[0,1]^{\\bf N}}")#text(". But if we let ")#mi("{q_1,q_2,\\dots}")#text(" be a countable dense subset in ")#mi("{X}")#text(", the map")

#mi("\\displaystyle x \\mapsto (\\frac{d(x,q_i)}{1+d(x,q_i)})_{i \\in {\\bf N}}")

#text("can easily be seen to be a Borel isomorphism between ")#mi("{X}")#text(" and a Borel subset of ")#mi("{[0,1]^{\\bf N}}")#text(" (note the image is the closure of the points ")#mi("{(\\frac{d(q_j,q_i)}{1+d(q_j,q_i)})_{i \\in {\\bf N}}}")#text(" in the uniform norm). The claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Kolmogorov extension theorem, alternate form)")]#text(" For each natural number ")#mi("{n}")#text(", let ")#mi("{\\mu_n}")#text(" be a probability measure on ")#mi("{{\\bf R}^n}")#text(" with the property that")

#mi("\\displaystyle \\mu_{n+1}( B \\times {\\bf R} ) = \\mu_n(B)")

#text("for ")#mi("{n \\geq 1}")#text(" and any box ")#mi("{B = [a_1,b_1] \\times \\dots \\times [a_n,b_n]}")#text(" in ")#mi("{{\\bf R}^n}")#text(", where we identify ")#mi("{{\\bf R}^n \\times {\\bf R}}")#text(" with ")#mi("{{\\bf R}^{n+1}}")#text(" in the usual manner. Show that there exists a unique probability measure ")#mi("{\\mu_{\\bf N}}")#text(" on ")#mi("{{\\bf R}^{\\bf N}}")#text(" (with the product ")#mi("{\\sigma}")#text("-algebra, or equivalently the Borel ")#mi("{\\sigma}")#text("-algebra on the product topology) such that")

#mi("\\displaystyle \\mu_{\\bf N}( \\{ (\\omega_i)_{i \\in {\\bf N}}: (\\omega_1,\\dots,\\omega_n) \\in E \\} ) = \\mu_n(E)")

#text("for all ")#mi("{n \\geq 1}")#text(" and Borel sets ")#mi("{E \\subset {\\bf R}^n}")#text(".")
]

#strong[#text(" — 2. Proof of the Kolmogorov extension theorem (optional) — ")]

#text("We now prove Theorem ")#link(<tao-ff47bb1aedd9ede5de2a>)[#text("10")]#text(". By the definition of a standard Borel space, we may assume without loss of generality that each ")#mi("{\\Omega_i}")#text(" is a Borel subset of ")#mi("{[0,1]}")#text(" with the Borel ")#mi("{\\sigma}")#text("-algebra, and then by extending each ")#mi("{\\Omega_i}")#text(" to ")#mi("{[0,1]}")#text(" we may in fact assume without loss of generality that each ")#mi("{\\Omega_i}")#text(" is simply ")#mi("{[0,1]}")#text(" with the Borel ")#mi("{\\sigma}")#text("-algebra. Thus each ")#mi("{\\mu_B}")#text(" for finite ")#mi("{B \\subset A}")#text(" is a probability measure on the cube ")#mi("{[0,1]^B}")#text(".")#linebreak()#text(" We will exploit the regularity properties of such measures:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" ")#metadata(none) <tao-827951b0c9cb29e7571f>#text(" Let ")#mi("{B}")#text(" be a finite set, and let ")#mi("{\\mu_B}")#text(" be a probability measure on ")#mi("{[0,1]^B}")#text(" (with the Borel ")#mi("{\\sigma}")#text("-algebra). For any Borel set ")#mi("{E}")#text(" in ")#mi("{[0,1]^B}")#text(", establish the ")#emph[#text("inner regularity")]#text(" property")

#mi("\\displaystyle \\mu_B(E) = \\sup_{K \\subset E, K \\text{ compact}} \\mu_B(K)")

#text("and the ")#emph[#text("outer regularity")]#text(" property")

#mi("\\displaystyle \\mu_B(E) = \\inf_{U \\supset E, U \\text{ open}} \\mu_B(U).")

#emph[#text("Hint:")]#text(" use the monotone class lemma.")
]

#text("Another way of stating the above exercise is that finite Borel measures on the cube are automatically ")#link("https://en.wikipedia.org/wiki/Radon_measure")[#text("Radon measures")]#text(". In fact there is nothing particularly special about the unit cube ")#mi("{[0,1]^B}")#text(" here; the claim holds for any compact separable metric spaces. Radon measures are often used in real analysis (see e.g. ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("these lecture notes")]#text(") but we will not develop their theory further here.")#linebreak()#text(" Observe that one can define the ")#emph[#text("elementary measure")]#text(" ")#mi("{\\mu_0(E)}")#text(" of any elementary set ")#mi("{E = \\pi_B^{-1}(E_B)}")#text(" in ")#mi("{[0,1]^A}")#text(" by defining")

#mi("\\displaystyle \\mu_0( \\pi_B^{-1}(E_B) ) := \\mu_B( E_B )")

#text("for any finite ")#mi("{B \\subset A}")#text(" and any Borel ")#mi("{E_B \\subset [0,1]^B}")#text(". This definition is well-defined thanks to the compatibility hypothesis ")#link(<tao-6b34aac75fa8f22f4f29>)[#text("(6)")]#text(". From the finite additivity of the ")#mi("{\\mu_B}")#text(" it is easy to see that ")#mi("{\\mu_0}")#text(" is a ")#emph[#text("finitely")]#text(" additive probability measure on the Boolean algebra ")#mi("{{\\mathcal A}}")#text(" of elementary sets.")#linebreak()#text(" We would like to extend ")#mi("{\\mu_0}")#text(" to a ")#emph[#text("countably")]#text(" additive probability measure on ")#mi("{{\\mathcal F}_A}")#text(". The standard approach to do this is via the ")#link("https://en.wikipedia.org/wiki/Carath%C3%A9odory%27s_extension_theorem")[#text("Carathéodory extension theorem")]#text(" in measure theory (or the closely related ")#link("https://en.wikipedia.org/wiki/Hahn%E2%80%93Kolmogorov_theorem")[#text("Hahn-Kolmogorov theorem")]#text("); this approach is presented in ")#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/")[#text("these previous lecture notes")]#text(", and a similar approach is taken in Durrett. Here, we will try to avoid developing the Carathéodory extension theorem, and instead take a more direct approach similar to the direct construction of Lebesgue measure, given for instance in ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("these previous lecture notes")]#text(".")#linebreak()#text(" Given any subset ")#mi("{E \\subset [0,1]^A}")#text(" (not necessarily Borel), we define its ")#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/???")[#text("outer measure")]#text(" ")#mi("{\\mu^*(E)}")#text(" to be the quantity")

#mi("\\displaystyle \\mu^*(E) := \\inf \\{ \\sum_{i=1}^\\infty \\mu_0(E_i): E_i \\text{ open elementary cover of } E \\},")

#text("where we say that ")#mi("{E_1,E_2,\\dots}")#text(" is an ")#emph[#text("open elementary cover")]#text(" of ")#mi("{E}")#text(" if each ")#mi("{E_i}")#text(" is an open elementary set, and ")#mi("{E \\subset \\bigcup_{i=1}^\\infty E_i}")#text(". Some properties of this outer measure are easily established:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]

#list(
[#text("(i) Show that ")#mi("{\\mu^*(\\emptyset) = 0}")#text(".")],
[#text("(ii) (Monotonicity) Show that if ")#mi("{E \\subset F \\subset [0,1]^A}")#text(" then ")#mi("{\\mu^*(E) \\leq \\mu^*(F)}")#text(".")],
[#text("(iii) (Countable subadditivity) For any countable sequence ")#mi("{E_1,E_2,\\dots}")#text(" of subsets of ")#mi("{[0,1]^A}")#text(", show that ")#mi("{\\mu^*( \\bigcup_{i=1}^\\infty E_i) \\leq \\sum_{i=1}^\\infty \\mu^*(E_i)}")#text(". In particular (from part (i)) we have the finite subadditivity ")#mi("{\\mu^*(E \\cup F) \\leq \\mu^*(E) + \\mu^*(F)}")#text(" for all ")#mi("{E,F \\subset [0,1]^A}")#text(".")],
[#text("(iv) (Elementary sets) If ")#mi("{E}")#text(" is an elementary set, show that ")#mi("{\\mu^*(E) = \\mu_0(E)}")#text(". (")#emph[#text("Hint:")]#text(" first establish the claim when the elementary set ")#mi("{E}")#text(" is also compact , relying heavily on the regularity properties of the ")#mi("{\\mu_B}")#text(" provided by Exercise ")#link(<tao-827951b0c9cb29e7571f>)[#text("14")]#text(", then extend to the general case by further heavy reliance on regularity.) In particular, we have ")#mi("{\\mu^*([0,1]^A) = 1}")#text(".")],
[#text("(v) (Approximation) Show that if ")#mi("{E \\in {\\mathcal F}_A}")#text(", then for any ")#mi("{\\varepsilon > 0}")#text(" there exists an elementary set ")#mi("{E_\\varepsilon}")#text(" such that ")#mi("{\\mu^*(E \\Delta E_\\varepsilon) < \\varepsilon}")#text(". (")#emph[#text("Hint:")]#text(" use the monotone class lemma. When dealing with an increasing sequence of measurable sets ")#mi("{E_n}")#text(" obeying the required property, approximate these sets by an increasing sequence of elementary sets ")#mi("{E^{\\prime}_n}")#text(", and use the finite additivity of elementary measure and the fact that bounded monotone sequences converge.)")]
)
]

#text("From part (v) of the above exercise, we see that every ")#mi("{E \\in {\\mathcal F}_A}")#text(" can be viewed as a “limit” of a sequence ")#mi("{E_n}")#text(" of elementary sets such that ")#mi("{\\mu^*(E \\Delta E_{n}) < 1/n}")#text(". From parts (iii), (iv) we see that the sequence ")#mi("{\\mu_0(E_n)}")#text(" is a Cauchy sequence and thus converges to a limit, which we denote ")#mi("{\\mu(E)}")#text("; one can check from further application of (iii), (iv) that this quantity does not depend on the specific choice of ")#mi("{E_n}")#text(". (Indeed, from subadditivity we see that ")#mi("{\\mu(E) = \\mu^*(E)}")#text(".) From definition we see that ")#mi("{\\mu}")#text(" extends ")#mi("{\\mu_0}")#text(" (thus ")#mi("{\\mu(E) = \\mu_0(E)}")#text(" for any elementary set ")#mi("{E}")#text("), and from the above exercise one checks that ")#mi("{\\mu}")#text(" is countably additive. Thus ")#mi("{\\mu}")#text(" is a probability measure with the desired properties, and the proof of the Kolmogorov extension theorem is complete.")

#strong[#text(" — 3. Independence — ")]

#text("Using the notion of product measure, we can now quickly define the notion of independence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 16")]#text(" A collection ")#mi("{(X_i)_{i \\in A}}")#text(" of random variables ")#mi("{X_i}")#text(" (each of which take values in some measurable space ")#mi("{R_i}")#text(") is said to be ")#emph[#text("jointly independent")]#text(", if the distribution of ")#mi("{(X_i)_{i \\in A}}")#text(" is the product of the distributions of the ")#mi("{X_i}")#text(". Or equivalently (after expanding all the definitions), we have")

#mi("\\displaystyle {\\bf P}( \\bigwedge_{i \\in B} (X_i \\in S_i) ) = \\prod_{i \\in B} {\\bf P}(X_i \\in S_i)")

#text("for all finite ")#mi("{B \\subset A}")#text(" and all measurable subsets ")#mi("{S_i}")#text(" of ")#mi("{R_i}")#text(". We say that two random variables ")#mi("{X,Y}")#text(" are ")#emph[#text("independent")]#text(" (or that ")#mi("{X}")#text(" is independent of ")#mi("{Y}")#text(") if the pair ")#mi("{(X,Y)}")#text(" is jointly independent.")
]

#text("It is worth reiterating that unless otherwise specified, all random variables under consideration are being modeled by a single probability space. The notion of independence between random variables does not make sense if the random variables are only being modeled by separate probability spaces; they have to be coupled together into a single probability space before independence becomes a meaningful notion.")#linebreak()#text(" Independence is a non-trivial notion only when one has two or more random variables; by chasing through the definitions we see that any collection of zero or one variables is automatically jointly independent.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 17")]#text(" If we let ")#mi("{(X,Y)}")#text(" be drawn uniformly from a product ")#mi("{E \\times F}")#text(" of two Borel sets ")#mi("{E,F}")#text(" in ")#mi("{{\\bf R}}")#text(" of positive finite Lebesgue measure, then ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are independent. However, if ")#mi("{(X,Y)}")#text(" is drawn from uniformly from another shape (e.g. a parallelogram), then one usually does not expect to have independence.")
]

#text("As a special case of the above definition, a finite family ")#mi("{X_1,\\dots,X_n}")#text(" of random variables taking values in ")#mi("{R_1,\\dots,R_n}")#text(" is jointly independent if one has")

#mi("\\displaystyle {\\bf P}( \\bigwedge_{i=1}^n (X_i\\in S_i) ) = \\prod_{i=1}^n {\\bf P}( X_i \\in S_i )")

#text("for all measurable ")#mi("{S_i}")#text(" in ")#mi("{R_i}")#text(" for ")#mi("{i=1,\\dots,n}")#text(".")#linebreak()#text(" Suppose that ")#mi("{(X_i)_{i \\in A}}")#text(" is a family of independent random variables, with each ")#mi("{X_i}")#text(" taking values in ")#mi("{R_i}")#text(". From Exercise ")#link(<tao-5aef96240bca5582e6fd>)[#text("3")]#text(" we see that")

#mi("\\displaystyle {\\bf P}( \\bigwedge_{j=1}^J (X_{A_j} \\in S_j) ) = \\prod_{j=1}^J {\\bf P}( X_{A_j} \\in S_j )")

#text("whenever ")#mi("{A_1,\\dots,A_J}")#text(" are disjoint finite subsets of ")#mi("{A}")#text(", ")#mi("{X_{A_j}}")#text(" is the tuple ")#mi("{(X_i)_{i \\in A_j}}")#text(", and ")#mi("{S_j}")#text(" is a measurable subset of ")#mi("{\\prod_{i \\in A_j} R_i}")#text(". In particular, we see that the tuples ")#mi("{X_{A_1},\\dots,X_{A_J}}")#text(" are also jointly independent. This implies in turn that ")#mi("{F_1(X_{A_1}),\\dots,F_J(X_{A_J})}")#text(" are jointly independent for any measurable functions ")#mi("{F_j: \\prod_{i \\in A_j} X_i \\rightarrow Y_j}")#text(". Thus, for instance, if ")#mi("{X_1,X_2,X_3,X_4}")#text(" are jointly independent random variables taking values in ")#mi("{R_1,R_2,R_3,R_4}")#text(" respectively, then ")#mi("{F(X_1,X_2)}")#text(" and ")#mi("{G(X_3)}")#text(" are independent for any measurable ")#mi("{F: R_1 \\times R_2 \\rightarrow Y}")#text(" and ")#mi("{G: R_3 \\rightarrow Y^{\\prime}}")#text(". In particular, if two scalar random variables ")#mi("{X,Y}")#text(" are jointly independent of a third random variable ")#mi("{Z}")#text(" (i.e. the triple ")#mi("{X,Y,Z}")#text(" are jointly independent), then combinations such as ")#mi("{X+Y}")#text(" or ")#mi("{XY}")#text(" are also independent of ")#mi("{Z}")#text(".")#linebreak()#text(" We remark that there is a quantitative version of the above facts used in information theory, known as the ")#link("https://en.wikipedia.org/wiki/Data_processing_inequality")[#text("data processing inequality")]#text(", but this is beyond the scope of this course.")#linebreak()#text(" If ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are independent scalar random variables, then from the Fubini and Tonelli theorems we see that ")#metadata(none) <tao-769a4e6d0003189c7e96>

#mi("\\displaystyle {\\bf E} XY = ({\\bf E} X) ({\\bf E} Y) \\ \\ \\ \\ \\ (8)")

#text("if")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are either both unsigned, or both absolutely integrable. We caution however that the converse is not true: just because two random variables ")#mi("{X,Y}")#text(" happen to obey ")#link(<tao-769a4e6d0003189c7e96>)[#text("(8)")]#text(" does not necessarily mean that they are independent; instead, we say merely that they are ")#emph[#text("uncorrelated")]#text(", which is a weaker statement.")#linebreak()#text(" More generally, if ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are random variables taking values in ranges ")#mi("{R, R^{\\prime}}")#text(" respectively, then")

#mi("\\displaystyle {\\bf E} F(X) G(Y) = ({\\bf E} F(X)) ({\\bf E} G(Y))")

#text("for any scalar functions ")#mi("{F,G}")#text(" on ")#mi("{R,R^{\\prime}}")#text(" respectively, provided that ")#mi("{F(X)}")#text(" and ")#mi("{G(Y)}")#text(" are either both unsigned, or both absolutely integrable. ")#emph[#text("This")]#text(" is the property of ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" which is equivalent to independence (as can be seen by specialising to those ")#mi("{F,G}")#text(" that take values in ")#mi("{\\{0,1\\}}")#text("): thus for instance independence of two unsigned random variables ")#mi("{X,Y}")#text(" entails not only ")#link(<tao-769a4e6d0003189c7e96>)[#text("(8)")]#text(", but ")#mi("{{\\bf E} X^2 Y = ({\\bf E} X^2) ({\\bf E} Y)}")#text(", ")#mi("{{\\bf E} e^X e^Y = ({\\bf E} e^X) ({\\bf E} e^Y)}")#text(", etc.. Similarly when discussing the joint independence of larger numbers of random variables. It is this ability to easily decouple expectations of independent random variables that make independent variables particularly easy to compute with in probability.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" Show that a random variable ")#mi("{X}")#text(" taking values in a locally compact, ")#mi("{\\sigma}")#text("-compact metric space is independent of itself (i.e. ")#mi("{X}")#text(" and ")#mi("{X}")#text(" are independent) if and only if ")#mi("{X}")#text(" is almost surely equal to a constant.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Show that a constant (deterministic) random variable is independent of any other random variable.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Let ")#mi("{X_1,\\dots,X_n}")#text(" be discrete random variables (i.e. they take values in at most countable spaces ")#mi("{R_1,\\dots,R_n}")#text(" equipped with the discrete sigma-algebra). Show that ")#mi("{X_1,\\dots,X_n}")#text(" are jointly independent if and only if one has")

#mi("\\displaystyle {\\bf P}( \\bigwedge_{i=1}^n (X_i=x_i) ) = \\prod_{i=1}^n {\\bf P}(X_i = x_i)")

#text("for all ")#mi("{x_1 \\in R_1,\\dots, x_n \\in R_n}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Let ")#mi("{X_1,\\dots,X_n}")#text(" be real scalar random variables. Show that ")#mi("{X_1,\\dots,X_n}")#text(" are jointly independent if and only if one has")

#mi("\\displaystyle {\\bf P}( \\bigwedge_{i=1}^n (X_i \\leq t_i) ) = \\prod_{i=1}^n {\\bf P}( X_i \\leq t_i )")

#text("for all ")#mi("{t_1,\\dots,t_n \\in {\\bf R}}")#text(".")
]

#text("The following exercise demonstrates that probabilistic independence is analogous to linear independence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Let ")#mi("{V}")#text(" be a finite-dimensional vector space over a finite field ")#mi("{F}")#text(", and let ")#mi("{X}")#text(" be a random variable drawn uniformly at random from ")#mi("{V}")#text(". Let ")#mi("{\\langle, \\rangle: V \\times V \\rightarrow F}")#text(" be a non-degenerate bilinear form on ")#mi("{V}")#text(", and let ")#mi("{v_1,\\dots,v_n}")#text(" be non-zero vectors in ")#mi("{V}")#text(". Show that the random variables ")#mi("{\\langle X, v_1 \\rangle, \\dots, \\langle X, v_n \\rangle}")#text(" are jointly independent if and only if the vectors ")#mi("{v_1,\\dots,v_n}")#text(" are linearly independent.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" ")#metadata(none) <tao-f1483207e8b56e5c989c>#text(" Give an example of three random variables ")#mi("{X,Y,Z}")#text(" which are ")#emph[#text("pairwise independent")]#text(" (that is, any two of ")#mi("{X,Y,Z}")#text(" are independent of each other), but not ")#emph[#text("jointly independent")]#text(". (")#emph[#text("Hint:")]#text(" one can use the preceding exercise.)")
]

#text("Another analogy is with orthogonality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Let ")#mi("{X}")#text(" be a random variable taking values in ")#mi("{{\\bf R}^n}")#text(" with the Gaussian distribution, in the sense that")

#tao-math("\\displaystyle \\mathop{\\bf P}( X \\in S ) = \\int_S \\frac{1}{(2\\pi)^{n/2}} e^{-\\left|x\\right|^2/2}\\ dx", block: false)

#text("(where ")#tao-math("{\\left|x\\right|}", block: false)#text(" denotes the Euclidean norm on ")#mi("{{\\bf R}^n}")#text("), and let ")#mi("{v_1,\\dots,v_m}")#text(" be vectors in ")#mi("{{\\bf R}^n}")#text(". Show that the random variables ")#mi("{X \\cdot v_1, \\dots, X \\cdot v_m}")#text(" (with ")#mi("{\\cdot}")#text(" denoting the Euclidean inner product) are jointly independent if and only if the ")#mi("{v_1,\\dots,v_m}")#text(" are pairwise orthogonal.")
]

#text("We say that a family of events ")#mi("{(E_i)_{i \\in A}}")#text(" are ")#emph[#text("jointly independent")]#text(" if their indicator random variables ")#mi("{(1_{E_i})_{i \\in A}}")#text(" are jointly independent. Undoing the definitions, this is equivalent to requiring that")

#mi("\\displaystyle {\\bf P}( \\bigwedge_{i \\in A_1} E_{i} \\wedge \\bigwedge_{j \\in A_2} \\overline{E_{j}}) = \\prod_{i \\in A_1} {\\bf P}(E_i) \\prod_{j \\in A_2} {\\bf P}(\\overline{E_j})")

#text("for all disjoint finite subsets ")#mi("{A_1, A_2}")#text(" of ")#mi("{A}")#text(". This condition is complicated, but simplifies in the case of just two events:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]

#list(
[#text("(i) Show that two events ")#mi("{E,F}")#text(" are independent if and only if ")#mi("{{\\bf P}(E \\wedge F) = {\\bf P}(E) {\\bf P}(F)}")#text(".")],
[#text("(ii) If ")#mi("{E,F,G}")#text(" are events, show that the condition ")#mi("{{\\bf P}(E \\wedge F \\wedge G) = {\\bf P}(E) {\\bf P}(F) {\\bf P}(G)}")#text(" is necessary, but not sufficient, to ensure that ")#mi("{E,F,G}")#text(" are jointly independent.")],
[#text("(iii) Given an example of three events ")#mi("{E,F,G}")#text(" that are pairwise independent, but not jointly independent.")]
)
]

#text("Because of the product measure construction, it is easy to insert independent sources of randomness into an existing randomness model by extending that model, thus giving a more useful version of Corollaries 27 and 31 of Notes 0:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 26")]#text(" Suppose one has a collection of events and random variables modeled by some probability space ")#mi("{\\Omega}")#text(", and let ")#mi("{\\nu}")#text(" be a probability measure on a measurable space ")#mi("{R = (R,{\\mathcal B})}")#text(". Then there exists an extension ")#mi("{\\Omega^{\\prime}}")#text(" of the probability space ")#mi("{\\Omega}")#text(", and a random variable ")#mi("{X}")#text(" modeled by ")#mi("{\\Omega^{\\prime}}")#text(" taking values in ")#mi("{R}")#text(", such that ")#mi("{X}")#text(" has distribution ")#mi("{\\nu}")#text(" and is independent of all random variables that were previously modeled by ")#mi("{\\Omega}")#text(".")#linebreak()#text(" More generally, given a finite collection ")#mi("{(\\nu_i)_{i \\in A}}")#text(" of probability measures on measurable spaces ")#mi("{R_i}")#text(", there exists an extension ")#mi("{\\Omega^{\\prime}}")#text(" of ")#mi("{\\Omega}")#text(" and random variables ")#mi("{X_i}")#text(" modeled by ")#mi("{\\Omega^{\\prime}}")#text(" taking values in ")#mi("{R_i}")#text(" for each ")#mi("{i \\in A}")#text(", such that each ")#mi("{X_i}")#text(" has distribution ")#mi("{\\nu_i}")#text(" and ")#mi("{(X_i)_{i \\in A}}")#text(" and ")#mi("{Y}")#text(" are jointly independent for any random variable ")#mi("{Y}")#text(" that was previously modeled by ")#mi("{\\Omega}")#text(".")#linebreak()#text(" If the ")#mi("{R_i}")#text(" are all standard Borel spaces, then one can also take ")#mi("{A}")#text(" to be infinite (even if ")#mi("{A}")#text(" is uncountable).")
]

#emph[#text("Proof:")]#text(" For the first part, we define the extension ")#mi("{\\Omega^{\\prime}}")#text(" to be the product of ")#mi("{\\Omega}")#text(" with the probability space ")#mi("{(R,{\\mathcal B},\\nu)}")#text(", with factor map ")#mi("{\\pi: \\Omega \\times R \\rightarrow \\Omega}")#text(" defined by ")#mi("{\\pi(\\omega,x) := \\omega}")#text(", and with ")#mi("{X}")#text(" modeled by ")#mi("{X_\\Omega(\\omega,x) := x}")#text(". It is then routine to verify all the claimed properties. The other parts of the proposition are proven similarly, using Proposition ")#link(<tao-bd86e3303063c60af9dc>)[#text("11")]#text(" for the final part. ")#mi("\\Box")#linebreak()#text(" Using this proposition, for instance, one can start with a given random variable ")#mi("{X}")#text(" and create an ")#emph[#text("independent copy")]#text(" ")#mi("{Y}")#text(" of that variable, which has the same distribution as ")#mi("{X}")#text(" but is independent of ")#mi("{X}")#text(", by extending the probability model. Indeed one can create any finite number of independent copies, or even an infinite number of ")#mi("{X}")#text(" takes values in a standard Borel space (in particular, one can do this if ")#mi("{X}")#text(" is a scalar random variable). A finite or infinite sequence ")#mi("{X_1, X_2, \\dots}")#text(" of random variables that are jointly independent and all have the same distribution is said to be an independent and identically distributed (or ")#emph[#text("iid")]#text(" for short) sequence of random variables. The above proposition allows us to easily generate such sequences by extending the sample space as necessary.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" Let ")#mi("{\\epsilon_1, \\epsilon_2, \\dots \\in \\{0,1\\}}")#text(" be random variables that are independent and identically distributed copies of the Bernoulli random variable with expectation ")#mi("{1/2}")#text(", that is to say the ")#mi("{\\epsilon_1,\\epsilon_2,\\dots}")#text(" are jointly independent with ")#mi("{{\\bf P}( \\epsilon_i = 1 ) = {\\bf P}(\\epsilon_i = 0 ) = 1/2}")#text(" for all ")#mi("{i}")#text(".")

#list(
[#text("(i) Show that the random variable ")#mi("{\\sum_{n=1}^\\infty 2^{-n} \\epsilon_n}")#text(" is uniformly distributed on the unit interval ")#mi("{[0,1]}")#text(".")],
[#text("(ii) Show that the random variable ")#mi("{\\sum_{n=1}^\\infty 2 \\times 3^{-n} \\epsilon_n}")#text(" has the distribution of ")#link("https://en.wikipedia.org/wiki/Cantor_distribution")[#text("Cantor measure")]#text(" (constructed for instance in Example 1.2.4 of Durrett).")]
)
]

#text("Note that part (i) of this exercise provides a means to construct Lebesgue measure on the unit interval ")#mi("{[0,1]}")#text(" (although, when one unpacks the construction, it is actually not too different from the standard construction, as given for instance in ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("this previous set of notes")]#text(").")#linebreak()#text(" Given two square integrable real random variables ")#mi("{X, Y}")#text(", the ")#link("https://en.wikipedia.org/wiki/Covariance")[#text("covariance")]#text(" ")#mi("{\\text{Cov}(X,Y)}")#text(" between the two is defined by the formula")

#mi("\\displaystyle \\text{Cov}(X,Y) := {\\bf E}( (X - {\\bf E} X) (Y - {\\bf E} Y) ).")

#text("The covariance is well-defined thanks to the Cauchy-Schwarz inequality, and it is not difficult to see that one has the alternate formula")

#mi("\\displaystyle \\text{Cov}(X,Y) = {\\bf E}(X Y) - ({\\bf E} X) ({\\bf E} Y)")

#text("for the covariance. Note that the variance is a special case of the covariance: ")#mi("{\\text{Var}(X) = \\text{Cov}(X,X)}")#text(".")#linebreak()#text(" From construction we see that if ")#mi("{X,Y}")#text(" are independent square integrable variables, then the covariance ")#mi("{\\text{Cov}(X,Y)}")#text(" vanishes. The converse is not true:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" Give an example of two square-integrable real random variables ")#mi("{X,Y}")#text(" which have vanishing covariance ")#mi("{\\text{Cov}(X,Y)}")#text(", but are not independent.")
]

#text("However, there is one key case in which the converse does hold, namely that of ")#link("https://en.wikipedia.org/wiki/Multivariate_normal_distribution")[#text("gaussian random vectors")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29")]#text(" A random vector ")#mi("{(X_1,\\dots,X_n)}")#text(" taking values in ")#mi("{{\\bf R}^n}")#text(" is said to be a ")#emph[#text("gaussian random vector")]#text(" if there exists ")#mi("{\\mu = (\\mu_1,\\dots,\\mu_n) \\in {\\bf R}^n}")#text(" and an ")#mi("{n \\times n}")#text(" positive definite real symmetric matrix ")#mi("{\\Sigma := (\\sigma_{ij})_{1 \\leq i,j \\leq n}}")#text(" such that")

#mi("\\displaystyle \\mathop{\\bf P}( (X_1,\\dots,X_n) \\in S) = \\frac{1}{(2\\pi)^{n/2} (\\det \\Sigma)^{1/2}} \\int_S e^{-\\frac{1}{2} (x-\\mu)^T \\Sigma^{-1} (x-\\mu)}\\ dx")

#text("for all Borel sets ")#mi("{S \\subset {\\bf R}^n}")#text(" (where we identify elements of ")#mi("{{\\bf R}^n}")#text(" with column vectors). The distribution of ")#mi("{(X_1,\\dots,X_n)}")#text(" is called a ")#emph[#text("multivariate normal distribution")]#text(".")

#list(
[#text("(i) If ")#mi("{(X_1,\\dots,X_n)}")#text(" is a gaussian random vector with the indicated parameters ")#mi("{\\mu, \\Sigma}")#text(", show that ")#mi("{{\\bf E} X_i = \\mu_i}")#text(" and ")#mi("{\\text{Cov}(X_i,X_j) = \\sigma_{ij}}")#text(" for ")#mi("{1 \\leq i,j \\leq n}")#text(". In particular ")#mi("{\\text{Var}(X_i) = \\sigma_{ii}}")#text(". Thus we see that the parameters of a gaussian random variable can be recovered from the mean and covariances.")],
[#text("(ii) If ")#mi("{(X_1,\\dots,X_n)}")#text(" is a gaussian random vector and ")#mi("{1 \\leq i, j \\leq n}")#text(", show that ")#mi("{X_i}")#text(" and ")#mi("{X_j}")#text(" are independent if and only if the covariance ")#mi("{\\text{Cov}(X_i,X_j)}")#text(" vanishes. Furthermore, show that ")#mi("{(X_1,\\dots,X_n)}")#text(" are jointly independent if and only if all the covariances ")#mi("{\\text{Cov}(X_i,X_j)}")#text(" for ")#mi("{1 \\leq i < j \\leq n}")#text(" vanish. In particular, for gaussian random vectors, joint independence is equivalent to pairwise independence. (Contrast this with Exercise ")#link(<tao-f1483207e8b56e5c989c>)[#text("23")]#text(".)")],
[#text("(iii) Give an example of two real random variables ")#mi("{X,Y}")#text(", each of which is gaussian, and for which ")#mi("{\\text{Cov}(X,Y)=0}")#text(", but such that ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are not independent. (")#emph[#text("Hint:")]#text(" take ")#mi("{Y}")#text(" to be the product of ")#mi("{X}")#text(" with a random sign.) Why does this not contradict (ii)?")]
)
]

#text("We have discussed independence of random variables, and independence of events. It is also possible to define a notion of independence of ")#emph[#mi("{\\sigma}")#text("-algebras")]#text(". More precisely, define a ")#emph[#mi("{\\sigma}")#text("-algebra of events")]#text(" to be a collection ")#mi("{{\\mathcal F}}")#text(" of events that contains the empty event, is closed under Boolean operations (in particular, under complements ")#mi("{E \\mapsto \\overline{E}}")#text(") and under countable conjunctions and countable disjunctions. Each such ")#mi("{\\sigma}")#text("-algebra, when using a probability space model ")#mi("{\\Omega}")#text(", is modeled by a ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal F}_\\Omega}")#text(" of measurable sets in ")#mi("{\\Omega}")#text(", which behaves under an extension ")#mi("{\\pi: \\Omega^{\\prime} \\rightarrow \\Omega}")#text(" in the obvious pullback fashion:")

#mi("\\displaystyle {\\mathcal F}_{\\Omega^{\\prime}} = \\{ \\pi^{-1}(E): E \\in {\\mathcal F}_\\Omega \\}.")

#text("A random variable ")#mi("{X}")#text(" taking values in some range ")#mi("{R}")#text(" is said to be ")#emph[#text("measurable")]#text(" with respect to a ")#mi("{\\sigma}")#text("-algebra of events ")#mi("{{\\mathcal F}}")#text(" if the event ")#mi("{X \\in S}")#text(" lies in ")#mi("{{\\mathcal F}}")#text(" for every measurable subset ")#mi("{S}")#text(" of ")#mi("{R}")#text("; in terms of a probabilistic model ")#mi("{\\Omega}")#text(", ")#mi("{X}")#text(" is measurable with respect to ")#mi("{{\\mathcal F}}")#text(" if and only if ")#mi("{X_\\Omega}")#text(" is measurable with respect to ")#mi("{{\\mathcal F}_\\Omega}")#text(". Note that every random variable ")#mi("{X}")#text(" generates a ")#mi("{\\sigma}")#text("-algebra ")#mi("{\\sigma(X)}")#text(" of events, defined to be the collection of all events of the form ")#mi("{X \\in S}")#text(" for ")#mi("{S}")#text(" a measurable subset of ")#mi("{R}")#text("; this is the smallest ")#mi("{\\sigma}")#text("-algebra with respect to which ")#mi("{X}")#text(" is measurable. More generally, any collection ")#mi("{(X_i)_{i \\in A}}")#text(" of random variables, one can define the ")#mi("{\\sigma}")#text("-algebra ")#mi("{\\sigma( (X_i)_{i \\in A} )}")#text(" to be the smallest ")#mi("{\\sigma}")#text("-algebra of events with respect to which all of the ")#mi("{X_i}")#text(" are measurable; in terms of a model ")#mi("{\\Omega}")#text(", we have")

#mi("\\displaystyle \\sigma( (X_i)_{i \\in A} )_\\Omega = \\langle \\{ (X_i)_\\Omega^{-1}(S_i): i \\in A, S_i \\in {\\mathcal B}_i \\} \\rangle")

#text("where ")#mi("{(R_i,{\\mathcal B}_i)}")#text(" is the range of ")#mi("{X_i}")#text(". Similarly, any collection ")#mi("{(E_i)_{i \\in A}}")#text(" of events generates a ")#mi("{\\sigma}")#text("-algebra of events ")#mi("{\\sigma(( E_i)_{i \\in A})}")#text(", defined as the smallest ")#mi("{\\sigma}")#text("-algebra of events that contains all of the ")#mi("{E_i}")#text("; with respect to a model ")#mi("{\\Omega}")#text(", one has")

#mi("\\displaystyle \\sigma( (E_i)_{i \\in A} )_\\Omega = \\langle \\{ (E_i)_\\Omega: i \\in A \\} \\rangle.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 30")]#text(" A collection ")#mi("{({\\mathcal F}_i)_{i \\in A}}")#text(" of ")#mi("{\\sigma}")#text("-algebras of events are said to be ")#emph[#text("jointly independent")]#text(" if, whenever ")#mi("{X_i}")#text(" is a random variable measurable with respect to ")#mi("{{\\mathcal F}_i}")#text(" for ")#mi("{i \\in A}")#text(", the tuple ")#mi("{(X_i)_{i \\in A}}")#text(" is jointly independent. Equivalently, ")#mi("{({\\mathcal F}_i)_{i \\in A}}")#text(" is jointly independent if and only if one has")

#mi("\\displaystyle {\\bf P}( \\bigcap_{i \\in B} E_i ) = \\prod_{i \\in B} {\\bf P}( E_i )")

#text("whenever ")#mi("{B}")#text(" is a finite subset of ")#mi("{A}")#text(" and ")#mi("{E_i \\in {\\mathcal F}_i}")#text(" for ")#mi("{i \\in B}")#text(" (why is this equivalent?).")
]

#text("Thus, for instance, ")#mi("{{\\mathcal F}_1}")#text(" and ")#mi("{{\\mathcal F}_2}")#text(" are independent ")#mi("{\\sigma}")#text("-algebras of events if and only if one has")

#mi("\\displaystyle {\\bf P}( E_1 \\wedge E_2 ) = {\\bf P}(E_1) {\\bf P}(E_2)")

#text("for all ")#mi("{E_1 \\in {\\mathcal F}_1}")#text(" and ")#mi("{E_2 \\in {\\mathcal F}_2}")#text(", that is to say that all the events in ")#mi("{{\\mathcal F}_1}")#text(" are independent of all the events in ")#mi("{{\\mathcal F}_2}")#text(".")#linebreak()#text(" The above notion generalises the notion of independence for random variables:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31")]#text(" If ")#mi("{(X_i)_{i \\in A}}")#text(" are a collection of random variables, show that ")#mi("{(X_i)_{i \\in A}}")#text(" are jointly independent random variables if and only if ")#mi("{(\\sigma(X_i))_{i \\in A}}")#text(" are jointly independent ")#mi("{\\sigma}")#text("-algebras.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32")]#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be a sequence of random variables. Show that ")#mi("{(X_n)_{n=1}^\\infty}")#text(" are jointly independent if and only if ")#mi("{\\sigma(X_{n+1})}")#text(" is independent of ")#mi("{\\sigma(X_1,\\dots,X_n)}")#text(" for all natural numbers ")#mi("{n}")#text(".")
]

#text("Suppose one has a sequence ")#mi("{X_1, X_2, \\dots}")#text(" of random variables (such a sequence can be referred to as a ")#link("https://en.wikipedia.org/wiki/Stochastic_process")[#text("discrete stochastic process")]#text("). For each natural number ")#mi("{n}")#text(", we can define the ")#mi("{\\sigma}")#text("-algebras ")#mi("{\\sigma( X_i: i >n )}")#text(", as the smallest ")#mi("{\\sigma}")#text(" algebra that makes all of the ")#mi("{X_i}")#text(" for ")#mi("{i >n}")#text(" measurable; for instance, this ")#mi("{\\sigma}")#text("-algebra contains any event that is definable in terms of measurable relations of finitely many of the ")#mi("{X_{n+1}, X_{n+2}, \\dots}")#text(", together with countable boolean operations on such events. These ")#mi("{\\sigma}")#text("-algebras are clearly decreasing in ")#mi("{n}")#text(". We can define the ")#link("https://en.wikipedia.org/wiki/Kolmogorov%27s_zero%E2%80%93one_law")[#text("tail ")#mi("{\\sigma}")#text("-algebra")]#text(" ")#mi("{{\\mathcal T}}")#text(" to be the intersection of all these ")#mi("{\\sigma}")#text("-algebras, that is to say ")#mi("{{\\mathcal T}}")#text(" consists of those events which lie in ")#mi("{\\sigma(X_i: i > n)}")#text(" for every ")#mi("{n}")#text(". For instance, if the ")#mi("{X_i}")#text(" are scalar random variables that converge almost surely to a limit ")#mi("{X}")#text(", then we see that (after modification on a null set) ")#mi("{X}")#text(" is measurable with respect to the tail ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal T}}")#text(".")#linebreak()#text(" We have the remarkable ")#link("https://en.wikipedia.org/wiki/Kolmogorov%27s_zero%E2%80%93one_law")[#text("Kolmogorov 0-1 law")]#text(" that says that the tail ")#mi("{\\sigma}")#text("-algebra of a sequence of ")#emph[#text("independent")]#text(" random variables is essentially trivial:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 33 (Kolmogorov zero-one law)")]#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be a sequence of ")#emph[#text("jointly independent")]#text(" random variables. Then every event ")#mi("{E}")#text(" in the tail ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal T}}")#text(" has probability equal to either ")#mi("{0}")#text(" or ")#mi("{1}")#text(".")
]

#text("As a corollary of the zero-one law, note that any real scalar tail random variable ")#mi("{Y}")#text(" will be almost surely constant (because, for each rational ")#mi("{t}")#text(", the event ")#mi("{Y \\geq t}")#text(" is either almost surely true or almost surely false). Similarly for tail random variables taking values in ")#mi("{{\\bf C}}")#text(" or ")#mi("{[-\\infty,+\\infty]}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 34")]#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be a sequence of jointly independent random variables in ")#mi("{[-\\infty,+\\infty]}")#text(" (not necessarily identically distributed). The random variable ")#mi("{\\limsup_{n \\rightarrow \\infty} X_n}")#text(" is measurable in the tail algebra, and hence must be almost surely constant, thus there exists ")#mi("{c_+ \\in [-\\infty,\\infty]}")#text(" such that ")#mi("{\\limsup_{n \\rightarrow \\infty} X_n = c_+}")#text(" almost surely. Similarly there exists ")#mi("{c_- \\in [-\\infty,\\infty]}")#text(" such that ")#mi("{\\liminf_{n \\rightarrow \\infty} X_n = c_-}")#text(". Thus, either we have ")#mi("{c_-=c_+}")#text(" and the ")#mi("{X_n}")#text(" converge almost surely to a deterministic limit, or ")#mi("{c_- \\neq c_+}")#text(" and the ")#mi("{X_n}")#text(" almost surely do not converge. What cannot happen is (for instance) that ")#mi("{X_n}")#text(" converges with probability ")#mi("{1/2}")#text(", and diverges with probability ")#mi("{1/2}")#text("; the zero-one law forces the only available probabilities of tail events to be zero or one.")
]

#emph[#text("Proof:")]#text(" Since ")#mi("{X_1,X_2,\\dots}")#text(" are jointly independent, the ")#mi("{\\sigma}")#text("-algebra ")#mi("{\\sigma( X_i: i > n )}")#text(" is independent of ")#mi("{\\sigma(X_1,\\dots,X_n)}")#text(" for any ")#mi("{n}")#text(". In particular, ")#mi("{{\\mathcal T}}")#text(" is independent of ")#mi("{\\sigma(X_1,\\dots,X_n)}")#text(". Since the ")#mi("{\\sigma}")#text("-algebra ")#mi("{\\sigma(X_i: i \\geq 1)}")#text(" is generated by the ")#mi("{\\sigma(X_1,\\dots,X_n)}")#text(" for ")#mi("{n=1,2,3,\\dots}")#text(", a simple application of the monotone class lemma then shows that ")#mi("{{\\mathcal T}}")#text(" is also independent of ")#mi("{\\sigma(X_i: i \\geq 1)}")#text(". But ")#mi("{\\sigma(X_i: i \\geq 1)}")#text(" contains ")#mi("{{\\mathcal T}}")#text(", hence ")#mi("{{\\mathcal T}}")#text(" is independent of itself. But the only events ")#mi("{E}")#text(" that are independent of themselves have probability ")#mi("{0}")#text(" or ")#mi("{1}")#text(", and the claim follows. ")#mi("\\Box")#linebreak()#text(" Note that the zero-one law gives no guidance as to which of the two probabilities ")#mi("{0, 1}")#text(" actually occurs for a given tail event. This usually cannot be determined from such “soft” tools as the zero-one law; instead one often has to work with more “hard” estimates, in particular in explicit inequalities for the probabilities of various events that approximate the given tail event. On the other hand, the proof technique used to prove the Kolmogorov zero-one law is quite general, and is often adapted to prove other zero-one laws in the probability literature.")#linebreak()#text(" The zero-one law suggests that many asymptotic statistics of random variables will almost surely have deterministic values. We will see specific examples of this in the next few notes, when we discuss the ")#link("https://en.wikipedia.org/wiki/Law_of_large_numbers")[#text("law of large numbers")]#text(" and the ")#link("https://en.wikipedia.org/wiki/Central_limit_theorem")[#text("central limit theorem")]#text(".")

#heading(level: 1)[#text("Comments (156)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-681868")[#strong[#text("Han Bing")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2023")]

#text("Also, may I ask why is the compatibility condition (6) in the extension problem necessary if one is to find a measure ")#mi("{\\mu_A}")#text(" obeying (7)?")

#emph[#text("[(7) follows from two applications of (6) since ")#mi("\\pi_B^{-1}( \\pi_{B \\rightarrow C}^{-1}(E_C) ) = \\pi_C^{-1}(E_C)")#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-681869")[#strong[#text("Han Bing")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2023")]

#text("Finally, I have a question regarding the definition of product measure following Remark 5: ")#mi("\\mu_A( \\pi_B^{-1}(E_B) ) = \\mu_B(E_B)")#text(", for it seems that the set ")#mi("\\pi_B^{-1}(E_B)")#text(" in ")#mi("\\Omega_A")#text(" is not unique.")

#emph[#text("The pre-image ")#mi("\\pi_B^{-1}(E_B) := \\{ \\omega: \\pi_B(\\omega) \\in E_B \\}")#text(" is uniquely determined by ")#mi("\\pi_B")#text(" and ")#mi("E_B")#text(". -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-681876")[#strong[#text("Han Bing")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2023")]

#text("Thank you Prof Tao, see it now.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-681885")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2023")])]

#text("Dear Prof Tao:")#linebreak()#text(" What differs the solution of Exercise 9 to that of Exercise 7? It seems that in both cases one directly show that the collection ")#mi("\\mathcal{F}")#text(" of sets on which $\\mu_A$ and $\\mu’_A$ agree is a monotone class containing the elementary sets, and hence is the entire ")#mi("\\mathcal{F}_A")#text(" by the monotone class lemma. But then where is the compatibility condition on ")#mi("\\mu_B")#text(" used?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-681887")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2023")])]

#text("The compatibility condition is not, strictly speaking, needed for the uniqueness aspect for Problem 8, but it is needed for existence.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-681889")[#strong[#text("Han Bing")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2023")]

#text("So we can use the same argument for both Exercise 7 and Exercise 9?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-681936")[#strong[#text("Han Bing")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2023")]

#text("Dear prof Tao:")#linebreak()#text(" In the proof of Lemma 12, how do we show that the map ")#mi("x \\mapsto (\\frac{d(x,q_i)}{1+d(x,q_i)})_{i \\in {\\bf N}}")#text(" is measurable?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-681937")[#strong[#text("Han Bing")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2023")]

#text("And do we assume the fact that the binary expansion of points in ")#mi("[0, 1]")#text(" is essentially unique to be known?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-681943")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2023")])]

#text("Yes, broadly speaking I would permit anything covered in a standard undergraduate mathematics curriculum to be applied to these sorts of arguments.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-681942")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2023")])]

#text("One can first show that each individual function $x \\mapsto \\frac{d(x,q_i)}{1+d(x,q_i)}$ is measurable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-681961")[#strong[#text("Han Bing")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2023")]

#text("Thank you professor.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-681962")[#strong[#text("Han Bing")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2023")]

#text("Dear professor Tao:")#linebreak()#text(" In the second display of Exercise 13 (the alternate Kolmogorov extension), ")#mi("\\mu_\\infty")#text(" should be ")#mi("\\mu_{\\mathbf N}")#text(". And do we expect to do this Exercise after reading the next section on the proof of the original extension theorem?")

#emph[#text("[Corrected, thanks. One can establish Exercise 13 using the Kolmogorov Extension Theorem (Theorem 10) as a “black box”; reading the proof may provide additional intuition but is not, strictly speaking, necessary. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-681982")[#strong[#text("Han Bing")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2023")]

#text("Thank you professor. Following your hint, one first show that ")#mi("\\mu_n")#text(" obeys the compatibility condition of Theorem 10 by showing that ")#mi("\\displaystyle \\mu_n(\\pi^{-1}_{\\mathbf{R}^n \\to \\mathbf{R}^m}(B)) = \\mu_m(B)")#text(" for any box ")#mi("B")#text(" in ")#mi("\\mathbf{R}^m")#text(" and any ")#mi("m \\leq n")#text(", is this what you mean by “black box”?")

#emph[#text("[Yes – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682000")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" For Exercise 14, if we let ")#mi("\\mathcal{G}")#text(" be the collection of Borel sets in the unit cube that can be approximated from inside by compact ")#mi("K")#text(" and from outside by open ")#mi("U")#text(" such that ")#mi("\\mu_B(U \\setminus K)  0")#text(", then we want $latex $ to be the Borel ")#mi("\\sigma")#text("-algebra of the cube, can you give some further hint on how the monotone class lemma is being used to obtain this conclusion?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682017")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2023")])]

#text("Hello professor Tao: Regarding the hint on part 4 of Exercise 15, I struggle to justify the fact that compact sets are elementary, given a compact ")#mi("K \\subset [0,1]^A")#text(", how can we express it as ")#mi("\\pi^{-1}_B(E_B)")#text("?")

#emph[#text("[Not all compact sets are elementary; but the intention of the hint is to first work with sets that are both compact and elementary. I will reword the hint to reduce confusion. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682053")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2023")])]

#text("Thank you for clarification professor Tao. Can you provide some further hint on how to establish the claim for elementary sets? If ")#mi("E = pi_B^{-1}(E_B)")#text(" is compact, then so is ")#mi("E_B")#text(", but I struggled to see how this helps.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682102")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2023")])]

#text("After one shows the result for compact elementary sets, then one generalizes to all elementary sets by showing that outer measure is inner regular on elementary sets. May I ask if this is what the hint is suggesting?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682140")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2023")])]

#text("That is what the second part of the hint is indicating. For the first part, you may find some of the techniques in ")#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")[#text("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")]#text(" to be helpful.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682163")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2023")])]

#text("Thank you so much for clarification, dear prof Tao. For any elementary set ")#mi("E \\subset [0,1]^A")#text(", we show that ")#mi("\\displaystyle \\mu^*(E) = \\inf_{V \\supset E, \\text{V open elementary}} \\mu_0(V)")#text(" by noting that LHS ")#mi("\\leq")#text(" RHS by definition of outer measure, and LHS ")#mi("\\geq")#text(" RHS by outer regularity of ")#mi("\\mu_B")#text(". From this can’t one derive the result for all elementary ")#mi("E")#text(" rather than ")#mi("E")#text(" compact elementary?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682195")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" For Exercise 14 if one let ")#mi("G")#text(" be the collection of Borel sets of ")#mi("[0,1]^B")#text(" on which $\\mu_B$ is regular, can’t we show that ")#mi("G")#text(" is a ")#mi("\\sigma")#text("-algebra and thus ")#mi("G = \\mathcal{B}[[0,1]^B]")#text("? Why is the monotone class lemma necessary for the solution?")

#emph[#text("[Perhaps this can be done directly, but I don’t think it is completely obvious to show that ")#mi("G")#text(" is a ")#mi("\\sigma")#text("-algebra just from the definitions. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682197")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2023")])]

#text("Set ")#mi("\\displaystyle G = \\{E \\in \\mathcal{B}[[0,1]^B]: \\forall \\varepsilon > 0, \\exists K \\subset E \\subset U\\ \\text{with}\\ \\mu_B(U \\setminus K) < \\varepsilon\\}")#text(", ")#mi("K")#text(" compact and ")#mi("U")#text(" open. We can verify that ")#mi("G")#text(" is a Boolean algebra. Let ")#mi("E_1, E_2, \\ldots \\in G")#text(", with ")#mi("K_i \\subset E_i \\subset U_i")#text(" be such that ")#mi("\\mu_B(U_i \\setminus K_i) < \\varepsilon / 2^i")#text(" for all ")#mi("i")#text(", we see that ")#mi("\\mu_B(\\bigcup_{i=1}^\\infty U_i \\setminus \\bigcup_{i=1}^\\infty K_i) = \\mu_B(U \\setminus K) < \\varepsilon")#text(". From this and continuity from below we obtain ")#mi("\\displaystyle \\mu_B(U \\setminus K) = \\lim_{n \\to \\infty} \\mu_B(U \\setminus \\bigcup_{i=1}^n K_i)  0")#text(" such that ")#mi("K’ = \\bigcup_{i=1}^n K_i")#text(", ")#mi("K’ \\subset \\bigcup_{i=1}^\\infty E_i \\subset U")#text(" with ")#mi("\\mu_B(U \\setminus K’) < \\varepsilon")#text(", ")#mi("K’")#text(" compact and ")#mi("U")#text(" open. That is, ")#mi("\\bigcup_{i=1}^\\infty E_i \\in G")#text(". Hence ")#mi("G")#text(" is a ")#mi("\\sigma")#text("-algebra. Note that ")#mi("G")#text(" contains all open sets ")#mi("U")#text(". For if ")#mi("U \\subset [0,1]^B")#text(" is open, then clearly it can be approximated from above by itself. By expressing ")#mi("U")#text(" as the union of a sequence of closed boxes ")#mi("\\bigcup_{n=1}^\\infty B_n")#text(", and taking ")#mi("K_n = \\bigcup_{i=1}^n B_n")#text(" so the sequence is increasing, we see again by continuity from below that ")#mi("U")#text(" can be approximated from below by compact sets as well. As the Borel ")#mi("\\sigma")#text("-algebra is generated by the open sets, we get the desired result.")

#text("May I ask why the hint prefers the approach by the monotone class lemma? Or is this solution flawed?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682346")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2023")])]

#text("Dear professor Tao: As for for the last part of Exercise 15, can you provide a bit hint on how to construct the increasing sequence ")#mi("E^{\\prime}_n")#text(" and how the finite additivity of the elementary measure is used to control ")#mi("\\mu^*(\\bigcup_n E_n \\Delta \\bigcup_{m=1}^N E^{\\prime}_m)")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682363")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2023")])]

#text("I meant to ask how should we construct the approximating sequence and how the hint on the finite additivity of elementary measure is used subsequently.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682379")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2023")])]

#text("Dear professor Tao: May I ask why do we also need an increasing sequence of elementary sets ")#mi("E^{\\prime}_n")#text(" in the last part of Exercise 15? For an increasing sequence of ")#mi("E_n")#text(" obeying the required property, and ")#mi("E = \\bigcup_n E_n")#text(", don’t we have by triangle inequality and the fact that bounded monotone sequences converge, that ")#mi("\\mu^*(E \\Delta E^{\\prime}_N) < \\mu^*(E \\Delta E_N) + \\mu^*(E_N \\Delta E^{\\prime}_N) < 2 \\varepsilon")#text(" for large enough ")#mi("N")#text("?")

#emph[#text("[This argument works also. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682384")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2023")])]

#text("Thank you so much professor Tao. Yet I realized to control the term ")#mi("\\mu^*(E \\Delta E_N) =  \\mu^*(E \\setminus E_N)")#text(", one needs to establish the superadditivity of $\\mu^*$ too, can you provide a bit more explanation on your original hint on using an increasing sequence of ")#mi("E^{\\prime}_n")#text(" and the finite additivity of elementary measure?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682390")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2023")])]

#text("If one selects ")#mi("E^{\\prime}_n")#text(" to be elementary increasing with ")#mi("\\mu^*(E_n \\Delta E^{\\prime}_n) \\leq 2^n")#text(", then ")#mi("\\mu^*(E^{\\prime}_{n+1} \\backslash E^{\\prime}_n) = \\mu_0(E^{\\prime}_{n+1} \\backslash E^{\\prime}_n)")#text(" is summable (because the bounded monotone sequence ")#mi("\\mu_0(E^{\\prime}_n)")#text(" converges, and from this and countable subadditivity (and the triangle inequality) one can show that ")#mi("\\mu(E \\Delta E^{\\prime}_n)")#text(" goes to zero as ")#mi("n \\to \\infty")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682391")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2023")])]

#text("Thank you so much professor Tao!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682393")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2023")])]

#text("For the approximating sequence ")#mi("E^{\\prime}_n")#text(", and ")#mi("E^{\\prime} = \\bigcup_n E^{\\prime}_n")#text(", I use the increasing sequence ")#mi("F^{\\prime}_n = \\bigcup_{m=1}^n E^{\\prime}_m")#text(", then the triangle inequality finally gives ")#mi("\\mu^*(E \\Delta F^{\\prime}_N) \\leq \\mu^*(E \\Delta E^{\\prime}) + \\mu^*(E^{\\prime} \\backslash F^{\\prime}_N) < 2\\varepsilon")#text(" for some big ")#mi("N")#text(". However I struggled to construct the initial approximating sequence ")#mi("E^{\\prime}_n")#text(" to be increasing.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682396")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2023")])]

#text("Actually it will be easier (and already enough) to show that it is increasing up to an error that goes to zero quickly as ")#mi("n \\to \\infty")#text(" (e.g., up to an error of ")#mi("O(2^{-n})")#text(").")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682427")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" A minor typo: A redundant word “from” in Example 17. Also, following the second display after Example 17, the domain for the measurable functions ")#mi("F_j")#text(" should be ")#mi("{\\prod_{i \\in A_j} R_i}")#text(" instead of ")#mi("{\\prod_{i \\in A_j} X_i}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qshuyu")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682465")[#strong[#text("qshuyu")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" May I ask why we fail to have independence in Example 17 if ")#mi("{(X,Y)}")#text(" is drawn uniformly from say a parallelogram?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682472")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2023")])]

#text("If ")#mi("X,Y")#text(" is drawn from a general shape (rather than a rectangle), then in general, knowing the value of ")#mi("X")#text(" will give some information about ")#mi("Y")#text(" and vice versa. This is for instance the observation that powers ")#link("https://en.wikipedia.org/wiki/Berkson%27s_paradox")[#text("Berkson’s paradox")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qshuyu")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682466")[#strong[#text("qshuyu")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2023")])]

#text("Also, can you elaborate more on your comment above Exercise 18 where you state “This is the property of ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" which is equivalent to independence (as can be seen by specialising to those ")#mi("{F,G}")#text(" that take values in ")#mi("{\\{0,1\\}}")#text("“)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682473")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2023")])]

#text("If for instance ")#mi("F = 1_S")#text(" and ")#mi("G = 1_T")#text(" then ")#mi("{\\bf E} F(X) G(Y) = {\\bf P} (X \\in S \\wedge Y \\in T)")#text(" and ")#mi("{\\bf E} F(X) {\\bf E} G(Y) = {\\bf P}(X \\in S) {\\bf P}(Y \\in T)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qshuyu")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682477")[#strong[#text("qshuyu")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2023")])]

#text("Thank you so much.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682484")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" For Exercise 18, by the fact that every ")#mi("\\sigma")#text("-compact space is Lindelöf, we can find a point ")#mi("y")#text(" in the range of ")#mi("X")#text(" such that ")#mi("{\\bf P}(X \\in B(y, \\varepsilon)) = 1")#text(" for arbitrarily small ")#mi("\\varepsilon")#text(". Yet I’m not sure how to get from this to ${\\bf P}(X = y) = 1$, does this involve the unused condition of local compactness?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682488")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2023")])]

#text("It seems that once we get this, then continuity from above alone implies that ")#mi("{\\bf P}(X = y) = 1")#text(", may I ask if I miss some technical detail regarding the local compactness part of the condition?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682615")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2023")])]

#text("One can probably relax the topological conditions here somewhat (e.g., a common relaxation is to assume one is on a Polish space, rather than a locally compact, sigma-compact space), but for these notes I did not seek the absolutely minimal regularity hypotheses required to make the assertions valid, as these sorts of technicalities are not really the focus of this probability theory course.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682593")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" Concerning Exercise 21, I was trying to induct on boxes of the form ")#mi("(-\\infty, t_i]")#text(" to extend the independence property to the Borel algebra ")#mi("{\\mathcal B}[{\\bf R}^n]")#text(", but run into issues in showing that this property is closed under complement and countable union, is this a valid approach?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682594")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2023")])]

#text("I mean boxes of the form ")#mi("\\prod_{i=1}^n (-\\infty, t_i]")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682618")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2023")])]

#text("Try working as an intermediate step with half-open rectangular boxes (which can be expressed as finite boolean combinations of boxes), and then with half-open elementary sets (finite boolean combinations of those boxes).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682633")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" Thank you so much for replying. Let ")#mi("\\mu")#text(" be the law of ")#mi("(X_i)_{i=1}^n")#text(" and ")#mi("v")#text(" the product measure, if ")#mi("C")#text(" is the collection of Borel subsets ")#mi("S")#text(" s.t ")#mi("\\mu(S) = v(S)")#text(", then ")#mi("C")#text(" can be shown to be a monotone class. Are you suggesting we show that ")#mi("C")#text(" contains a Boolean algebra containing the half-open elementary sets, and use the monotone class theorem?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682638")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" A small typo: In Exercise 22, the random variables ")#mi("{\\langle X, v_1 \\rangle, \\dots, \\langle X, v_n \\rangle}")#text(" should be ")#mi("{\\langle X_1, v_1 \\rangle, \\dots, \\langle X_n, v_n \\rangle}")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682640")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2023")])]

#text("(I apologize for my misunderstanding, nothing is wrong here.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682648")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" Can you give a bit hint on how linear independence can imply joint independence in Exercise 22?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682656")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2023")])]

#text("Without loss of generality, set ")#mi("V = F^r")#text(" with basis ")#mi("\\{e_1, \\dots, e_r\\}")#text(", and ")#tao-math("\\left|F\\right| = q", block: false)#text(". The event ")#mi("\\bigwedge_{i=1}^n (\\langle X,v_i \\rangle = t_i)")#text(" with ")#mi("t_i \\in F")#text(" corresponds to the system of linear equations ")#mi("Bx = t")#text(", where ")#mi("B")#text(" is the ")#mi("n \\times r")#text(" matrix with rows ")#mi("(\\langle e_k,v_i \\rangle)_{1 \\leq k \\leq r}, 1 \\leq i \\leq n")#text(", and ")#mi("t = (t_1, \\dots, t_n)^t")#text(". If ")#mi("s")#text(" is the dimension of the span of ")#mi("e_1, \\dots, e_r")#text(", then rank(")#mi("B")#text(") is exactly ")#mi("s")#text(" since it has ")#mi("s")#text(" independent rows. Hence the dimension of the solution space equals ")#mi("r - s")#text(", and ")#mi("{\\bf P}(\\bigwedge_{i=1}^n (\\langle X,v_i \\rangle = t_i)) = q^{r-s}/q^r = 1/q^s")#text(". Similarly ")#mi("{\\bf P}(\\langle X,v_i \\rangle = t_i) = 1/q")#text(", so by Exercise 20 the random variables are jointly independent iff the ")#mi("s = n")#text(". i.e. iff the vectors are linearly independent. I don’t see how the non-degeneracy assumption is used here. Is this argument flawed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682658")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2023")])]

#text("I think I see where we need the non-degeneracy assumption. It ensures that we don’t get ")#mi("0")#text(" as row vectors of ")#mi("B")#text(" (since none of the ")#mi("v_i = 0")#text("), only then can we safely deduce that ")#mi("B")#text(" has ")#mi("s")#text(" linearly independent rows. Is this correct, professor Tao?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682682")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" Can you provide a little more directions on Exercise 24(orthogonality and independence)?")

#emph[#text("[First try the model case where ")#mi("v_1,\\dots,v_m")#text(" are the standard coordinate bases ")#mi("e_1,\\dots,e_m")#text(". You can set ")#mi("m=n=2")#text(" if you wish to make things a little more concrete. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682695")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2024")])]

#text("Thank you for replying professor. I find it hard though to use the fact that ")#mi("X")#text(" is a Gaussian random variable. Are we supposed to show this by definition?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682699")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2024")])]

#text("Yes; for instance in the model case ")#mi("n=2, v_1 = e_1, v_2 = e_2")#text(", one can compute the distributions of ")#mi("X \\cdot v_1, X \\cdot v_2")#text(" by direct computation (performing one-dimensional Gaussian integrals), and show that the product of these distributions agrees with the distribution of the joint random variable ")#mi("X = (X \\cdot v_1, X \\cdot v_2)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682705")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2024")])]

#text("Let ")#mi("f_i(\\omega) = X(\\omega) \\cdot v_i for all 1 \\leq i \\leq m")#text(", then ")#tao-math("\\displaystyle \\mu_{(X \\cdot v_i)_{1 \\leq i \\leq m}} (\\prod_{i=1}^m S_i) = \\int_{\\bigcap_{i=1}^m f_i^{-1}(S_i)} \\frac{1}{(2\\pi)^{n/2}} e^{-\\left|x\\right|^2/2}\\ dx", block: false)#text(". By direct computation, are you suggesting one show that the integral splits over the intersection if and only if we have orthogonality, professor Tao?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682742")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2024")])]

#text("Dear professor Tao: For this Exercise is it required to use the rotational invariance of the standard Gaussian distribution, and the linear change of variables formula?")

#emph[#text("[Yes – T.]")]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682717")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2024")])]

#text("Dear professor Tao:")#linebreak()#text(" I believe we need the scalar r.v ")#mi("X")#text(" and ")#mi("Y")#text(" to be independent in the display tagged ")#mi("(8)")#text(", because later it is said that “we caution however that the converse is not true…”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682764")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2024")])]

#text("Dear professor Tao;")#linebreak()#text(" In the proof of proposition 26, ")#mi("{X}")#text(" should be modeled by ")#mi("{X_{\\Omega^{\\prime}}(\\omega,x) := x}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682816")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2024")])]

#text("Dear professor Tao:")#linebreak()#text(" I have a conceptual misunderstanding of Exercise 29. Let ")#mi("D = Q^{-1} \\Sigma Q")#text(" be the eigenvalue decomposition of ")#mi("\\Sigma")#text(", where ")#mi("Q")#text(" is orthogonal, ")#mi("D")#text(" is diagonal with its ")#mi("j^{th}")#text(" diagonal entry ")#mi("\\lambda_j")#text(" the eigenvalue of ")#mi("\\Sigma")#text(" corresponding to the ")#mi("j^{th}")#text(" column of ")#mi("Q")#text(". Then by consecutive linear change of variables, one seems to get ")#mi("\\displaystyle {\\bf P}(X \\in S) = c\\int_{S} e^{-\\frac{1}{2} (w-\\mu)^TD^{-1}(w-\\mu)}\\ dw")#text(", where ")#mi("c = \\frac{1}{(2\\pi)^{n/2}(\\det{\\Sigma})^{1/2}}")#text(". In particular, the joint distribution splits into product of the marginal distribution of the components, and we get independence automatically, which is obviously incorrect, where did it possibly go wrong?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682822")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2024")])]

#text("Dear professor Tao:")#linebreak()#text(" Actually I see the blunder in the derivation now. But may I still ask how should one get the marginal distribution of each component ")#mi("X_i")#text(" to calculate ")#mi("{\\bf E}(X_i)")#text(" when the joint pdf does not readily split into product of the marginal pdfs?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682832")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2024")])]

#text("Dear professor Tao:")#linebreak()#text(" Regarding Exercise 29, if ")#mi("\\Sigma = QDQ^T")#text(" is the eigenvalue decomposition of ")#mi("\\Sigma")#text(", and ")#mi("Y \\sim N(0_{{\\bf R}^n}, D)")#text(", then ")#mi("QY + \\mu")#text(" is a copy of ")#mi("X")#text(" and the fact that ")#mi("{\\bf E}X_i = \\mu_i")#text(" follows by linearity.")

#text("This approach gives no information however on the marginal distribution of the components $X_i$, is there a way to calculate the marginal distributions without using the linear transformation theorem for multivariate normal distribution, the proof of which relies in turn on the use of generating functions or characteristic functions, which have not yet been fully developed at this point in the notes?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682835")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2024")])]

#text("Finally, by change of variables ")#mi("\\text{Cov}(X_i, X_j) = \\int_{{\\bf R}^n} (x_i - \\mu_i)(x_j - \\mu_j)\\ d\\mu_X(x)")#text(", I have some difficulties showing this evaluate to ")#mi("\\sigma_{ij}")#text(", can you provide some hint on this, professor Tao?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682844")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2024")])]

#text("Dear professor Tao: In the second part of Exercise 29, we should have the covariances vanish for all off-diagonal entries rather than just the entries above the diagonal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-682858")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2024")])]

#text("Dear professor Tao:")#linebreak()#text(" In the proof of the Kolmogorov zero-one law, the monotone class lemma is used to show that ")#mi("\\mathcal{T}")#text(" is independent of ")#mi("\\sigma(X_i: i \\geq 1)")#text(", may I ask what is the larger class containing the generators ")#mi("\\sigma(X_1, \\dots, X_n)")#text(" to which ")#mi("\\mathcal{T}")#text(" is independent, that allow us to use the said lemma? Why can’t we use induction in this case?")

#emph[#text("[One applies the monotone class lemma to the collection of events that are independent of ")#mi("\\mathcal{T}")#text(", which is easily seen to be a monotone class containing each of the ")#mi("\\sigma(X_1, \\dots, X_n)")#text(", and hence ")#mi("\\sigma(X_i: i \\geq 1)")#text(". Note that the latter ")#mi("\\sigma")#text("-algebra is not simply the union of the preceding ones, but is instead the ")#mi("\\sigma")#text("-algebra (or monotone class) generated by that union. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1b5115725e622317906df30d3cdd85833296d17c832c3cf9b9658daac45f263-d487ba56d8c17a305bd37f35bf65c1dd4bee5bbb96f7ce25ddac20f656f65bc3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tuo Wang")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-687482")[#strong[#text("Tuo Wang")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2025")])]

#text("Dear prof Tao:")#linebreak()#text(" I would like to ask the following question.")#linebreak()#text(" We have a probability space ")#mi("(\\Omega, \\mathcal{F},\\mathbb{P})")#text(". If ")#mi("X, Y: (\\Omega, \\mathcal{F}) \\to (R, B(R))")#text(" are independent real-valued random variables, and if the mappings ")#mi("f")#text(" and ")#mi("g")#text(" are not necessarily ")#mi("B(R)")#text(" measurable, but ")#mi("f(X)")#text(" and ")#mi("g(Y)")#text(" are random variables from ")#mi("(\\Omega, \\mathcal{F})")#text(" to ")#mi("(R, B(R))")#text(". In this case, is f(X) and g(Y) still independent?")#linebreak()#text(" I already know that if ")#mi("f")#text(" and ")#mi("g")#text(" are ")#mi("B(R)")#text(" measurable, then the answer is right, but what if they are not measurable?")#linebreak()#text(" Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-687485")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2025")])]

#text("I think this is false. Take ")#mi("R = \\{0,1\\}^2")#text(" with the vertical topology/sigma algebra generated by ")#mi("\\{0\\} \\times \\{0,1\\}")#text(" and ")#mi("\\{1\\} \\times \\{0,1\\}")#text(", and let ")#mi("f=g: R \\to R")#text(" be the (non-measurable) reflection map ")#mi("(x_1,x_2) \\mapsto (x_2,x_1)")#text(". Then take ")#mi("X = (X_1,X_2)")#text(", ")#mi("Y = (Y_1,Y_2)")#text(" where ")#mi("X_1,Y_1")#text(" are independent but ")#mi("X_2, Y_2")#text(" are not; I think this gives the desired counterexample.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1b5115725e622317906df30d3cdd85833296d17c832c3cf9b9658daac45f263-d487ba56d8c17a305bd37f35bf65c1dd4bee5bbb96f7ce25ddac20f656f65bc3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tuo Wang")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-687489")[#strong[#text("Tuo Wang")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2025")])]

#text("Thank you for your reply. But I’ sorry that maybe I forgot to mention that the symbol R in my question denotes the set of real numbers. So I’m wandering is there also a counterexample for this problem? Thank you!")

#emph[#text("[This would be a good exercise for you to work out – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-692207")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2026")])]

#text("Dr Tao,")

#text("My understanding is that the strategy of the proof of Lemma 2 is to show the intersection class F is a σ-algebra by verifying it contains the empty set, the generating set A, and is closed under complements and countable unions (using De Morgan’s laws to bypass intersections). BTW I don’t know if this a correct understanding of the strategy.")

#text("However I am confused about a step to show F is a Boolean algebra: define the class C_E and D based on the condition that the four sets all lie in F. I am wondering how and why to construct these four specific sets?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-692217")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2026")])]

#text("I am outsourcing ")#link("https://chatgpt.com/share/69dbf489-7064-83e8-bc75-68d5287d9d0e")[#text("this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-692225")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2026")])]

#text("Dear Prof. Tao,")

#text("In theorem 33, you wrote that “…the proof technique used to prove the Kolmogorov zero-one law is quite general…”-I’m not quite sure what exactly “technique” refers to here. Could you elaborate on that?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-692229")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2026")])]

#text("The general technique here is to show that any sort of “tail-like” event or random variable must be almost surely constant (e.g., almost surely zero or almost surely one) by establishing that it is independent of every source of randomness in the system.")

#text("One can also establish zero-one laws through ergodicity, for instance by demonstrating that the random variable is invariant with respect to finite exchanges of the random inputs; this is not identical to the previous strategy but is in a similar spirit.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-692555")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2026")])]

#emph[#text("The above theory extends from probability spaces to finite measure spaces, and more generally to measure spaces that are σ-finite.")]#text(" Why would probabilists care about the spaces that are ")#strong[#text("σ-finite")]#text("? Since the probability space itself is a finite space with total measure 1. Isn’t finiteness good enough?")

#emph[#text("[There are useful applications of product measures beyond probability theory. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-692633")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2026")])]

#text("…the Tonelli theorem tells us that the ")#emph[#text("tensor product")]#text("…")

#text("When I check the link of tensor product, I find that it links to a paper in arXiv by Ellenberg and Hablicsek. Is it a typo?")

#text("Also, could you elaborate on what a tensor product is in an intuitive way? It seems that even in your measure theory textbook’s introduction to the Fubini-Tonelli theorem, the tensor product wasn’t introduced.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-692641")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2026")])]

#text("The link is now updated to point to the Wikipedia page.")

#text("The (concrete) tensor product ")#mi("f \\otimes g(x,y) = f(x) g(y)")#text(" is to functions as the Cartesian product ")#mi("A \\times B = \\{ (a,b): a \\in A, b \\in B \\}")#text(" is to sets. Indeed, the tensor product ")#mi("1_A \\otimes 1_B")#text(" of two indicator functions is the indicator function ")#mi("1_{A \\times B}")#text(" of the Cartesian product.")

#text("This concrete tensor product can be viewed as an explicit representation of a more abstract tensor product that is the focus of most of the Wikipedia article and ultimately the more “natural” or “universal” way to interpret this construction, but for the purposes of initial intuition I would recommend working primarily with concrete models, at least until one is comfortable with abstract algebra. See also ")#link("https://www.math3ma.com/blog/the-tensor-product-demystified")[#text("https://www.math3ma.com/blog/the-tensor-product-demystified")]#text(" for an analogous discussion of the tensor product of vectors.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fef06046c3e3f2eb0c11c98a8c4a11ed84b25ccbc023d13f15062e426e1fdf3a-366938429a206590b60f422cbbb17608d068f86905fb2652141d3f9024626ae7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elias Lam")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-693190")[#strong[#text("Elias Lam")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2026")])]

#text("I feel like Kolmogorov’s zero-one law can be interpreted as an all-or-nothing dichotomy—I wonder if that’s accurate. However, we can’t determine which of the two probabilities, 0 or 1, actually occurs using Kolmogorov’s zero-one law. Thus, what hard-analytic tools do we need to estimate or determine that?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-693700")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2026")])]

#text("It can perhaps be largely asserted that the Monotone Class Lemma and Dynkin π-λ Theorem are equivalent. In this set of notes, only the Monotone Class Lemma is used, but in other probability theory textbooks, π-λ Theorem is more commonly seen. So, does the use of these two theorems simply come down to personal preference, or do they each offer certain advantages in different situations?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-693703")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2026")])]

#text("I am ")#link("https://claude.ai/share/3589da1d-d0eb-4a83-8bbc-24370d71758f")[#text("outsourcing this question to an AI")]#text(".")

#text("Personally I have a slight preference for the monotone class lemma because on a conceptual level I like to see Boolean algebras as a stepping stone to sigma-algebras, but for others who would like to bypass Boolean algebras and jump to sigma algebras directly, the pi-lambda lemma is more convenient.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-2/#comment-693808")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2026")])]

#text("I like your idea of treating Boolean algebra as a stepping stone. Also, I think that when dealing with continuous martingales, the pi-lambda lemma is probably used more often. I may not be accurate, of course, but if it is true, I’d like to ask: what is the advantage of using the pi-lambda theorem in the case of continuous martingales?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Colin Rust")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460463")[#strong[#text("Colin Rust")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2015")])]

#text("I think Exercise 22 is wrong as stated. It does not suffice for the ")#mi("v_i")#text(" to be linearly independent. For example, take ")#mi("n= 2")#text(" and the standard (dot) inner product on $R^2$, then $X_1$ and $X_1+X_2$ are not independent even though ")#mi("v_1=(1,0)")#text(" and ")#mi("v_2 = (1,1)")#text(" are linearly independent.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460465")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2015")])]

#text("Actually, I don’t see the problem here. ")#mi("X_1,X_2")#text(" are drawn uniformly and independently at random from a finite field ")#mi("F")#text(", and the shear ")#mi("(X_1,X_2) \\mapsto (X_1,X_1+X_2)")#text(" is a bijection on the plane ")#mi("F^2")#text(", so the pair ")#mi("X_1, X_1+X_2")#text(" should still be independent (in the probabilistic sense).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Colin Rust")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460487")[#strong[#text("Colin Rust")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2015")])]

#text("You’re right, sorry about that! (I was confused about the statement of the exercise, as was probably already clear by my referring to $\\latex R$ rather than a finite field.)")

#text("This result is surprising to me. Normally, I think of linear independence of two vectors (generically true) as being a much weaker condition than the independence of two random variables (which I think of as generically false). Of course, this is a very special case since the distributions are uniform, so maybe it’s not so surprising.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a6be96d0b33334c6a31c2b3bf2f20ef8ce2f7d97e0c701463b95bf4270e9e25-ce514ac0ea720ed87fa8c8930f4a34ce09507f5e810209a52d960dbea35d2d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Venky")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460554")[#strong[#text("Venky")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2015")])]

#text("Colin, doesn’t this depend on whether you think of two variables as already coming from a joint distribution, in which case they are unlikely to be independent, but otherwise, you just can just take the product and assert they are independent?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Colin Rust")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460598")[#strong[#text("Colin Rust")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2015")])]

#text("That’s a fair point, I was thinking of two variables coming from a joint distribution.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b712095acdd09411e4bcac3ca14c4586d808708686fefcb7f32ae9dbc5af4c9-34297a8522af6f4a25424ed196d5f8b4c23e27770275bc314d5e137c7185eb56.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chao Huang")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460467")[#strong[#text("Chao Huang")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2015")])]

#text("Hi Prof. Tao,")

#text("Do you have any intuitive explanation or example for the conclusion of Exercise 23 above, i.e. pairwise independent random variables are not necessarily jointly independent? Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460469")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2015")])]

#text("Not every dependency between a triplet X,Y,Z of variables is caused by dependencies between pairs. For instance, it could be that X,Y,Z are random variables with X+Y+Z=0, thus creating a dependency in the triplet (X,Y,Z) that prevents joint independence, but such that there is no dependency between just X and Y, or between X and Z, or between Y and Z. (This can be made rigorous if X,Y,Z take values in a finite field, as per Exercise 22. The linear algebra analogue would be a triplet of vectors u,v,w which are pairwise linearly independent, but not jointly linearly independent.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460489")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2015")])]

#text("It’s interesting that the example given seems at odds w/ my naive intuition. If X+Y+Z=0 is the only constraint, and in a given instance we know only that X (say) takes on a particularly *large* value, this would appear to *increase* the probability that Z (say) takes on an especially *small* value.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460499")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2015")])]

#text("This intuition is valid for random variables in ordered fields such as ")#mi("{\\bf R}")#text(", in which notions such as “small” and “large” make sense. However, finite fields are not ordered.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460474")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2015")])]

#text("In exercise 4, “the bound” may be deleted.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/070548c5f283d5da8bc06d5ee4ecf9174139faa45d02e3c408c967e6ec3771b0-96317c989091e8e46020f553fc3a6f996a51998c5bca5c719f77f5ef4cb0a09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of victor")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460486")[#strong[#text("victor")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2015")])]

#text("Is Exercise 13 another way of saying that for any (discrete time) stochastic process on the reals is actually a Markov process on a different (much larger) state space?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460488")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2015")])]

#text("Not really, because it only produces a model of the individual ")#mi("X_i")#text(" in which all of the variables are independent, so if one starts with a discrete stochastic process ")#mi("X_i")#text(" which has some coupling between the ")#mi("X_i")#text(", Exercise 13 does not produce a model of that process, though it does give each individual term ")#mi("X_i")#text(" of the process the correct distribution. There should however be other constructions that can model an essentially arbitrary non-independent process ")#mi("X_i")#text(" as some deterministic functions ")#mi("X_i = F_i(Y_1,\\dots,Y_i)")#text(" of some jointly independent (and in particular, Markovian) process ")#mi("Y_1,Y_2,\\dots")#text(", modeled by some enormous probability space, though I don’t know how useful such constructions would be.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/688438fe3308dc9194aff70cc698cf1f8680d662e98030459501358379194561-c2e47f871f9ec3f8bfd63870a5cc3e88c5e51b413ec271a205b4d0b29e88ee17.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack Hamill")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460491")[#strong[#text("Jack Hamill")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2015")])]

#text("Hello Dr. Tao,")

#text("My name is Jack Hamill. I am a 12 year old boy from Australia. We have an event at school coming up about eminent people. I have picked you for this event because I found your mathematic discoveries very important and eminent to the mathematics world.")

#text("For this event, all boys dress up as their eminent people.")#linebreak()#text(" Because of this, I need to know all the facts that you know.")#linebreak()#text(" Can you please explain all your knowledge for a kid? (even though your knowledge is infinite. 😀)")#linebreak()#text(" Thank you an advance,")#linebreak()#text(" Jack Hamill.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460521")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2015")])]

#text("Hello Prof. Tao,")

#text("We usually suppose that we have an i.i.d. collection of random variables.")

#text("But in practice, how can we check the i.i.d. assumption for a given data set ")#mi("X_1,X_2,X_3, \\cdots")#text("? Namely, what are the some possible statistical tests we could apply to our data to determine if it is indeed i.i.d. or not?")

#text("Thanks,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460531")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2015")])]

#text("I’m not an expert in statistics, so I don’t know the most advanced tests for things like this, but there are certainly tests such as the ")#link("https://en.wikipedia.org/wiki/Pearson%27s_chi-squared_test")[#text("Pearson chi-squared test")]#text(" which can be used to test for independence and for whether a random variable has a given distribution. So one could for instance use all but one of the data variables to obtain an empirical distribution that one could then test the remaining variable against. One can also compute empirical correlations, though these only capture pairwise independence rather than joint independence.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Colin Rust")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460532")[#strong[#text("Colin Rust")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2015")])]

#text("Correlation is a necessary but not sufficient condition for pairwise independence. (For the very special case where ")#mi("X_1")#text(" and ")#mi("X_2")#text(" are marginals of a bivariate normal, it does suffice. But even assuming that each is normally distributed is not sufficient.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c28c160914c3c704d904b785cc41af38a1f2a954c05fe6e468b9b0d3a762a163-019a9b45190592833132144570945cf9b27821730be3de44cbb1950d79db1684.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460534")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2015")])]

#text("Do you have any advice for the maths in general including high school math, also do you have any tips to make it easier to solve word problems and do algebraic equations -well really advice for all of algebra would be helpful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460563")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2015")])]

#text("Dear Dr.Tao,")#linebreak()#text(" After Erdos problem, all of us (200 people) wish someday recent all magazines announce that “Terence Tao has just solved Riemann hypothesis”.N o one in the world can do this problem, except to you.This is a fate.A human’s life is very short.You should be urgent.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a6be96d0b33334c6a31c2b3bf2f20ef8ce2f7d97e0c701463b95bf4270e9e25-ce514ac0ea720ed87fa8c8930f4a34ce09507f5e810209a52d960dbea35d2d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Venky")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460573")[#strong[#text("Venky")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2015")])]

#text("The definition of \\pi_j (right after Remark 5) has a small typo: the projection goes to sigma_j, not \\pi_j. Also, the Notes 0 product measure has a box topology flavor, but elementary sets have a product topology flavor. Do you think you can remark on we should think of measures and topologies?")

#emph[#text("[Corrected, thanks. There are certainly many analogies between point-set topology and measure theory, but I don’t know of many precise connections beyond the level of mere analogy (though there are some curious results of this flavour, e.g. Erdos-Sierpinski duality). -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Colin Rust")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460599")[#strong[#text("Colin Rust")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2015")])]

#text("I think a way to think about this difference is that sigma-algebras are closed under countable intersection whereas topologies are only closed under finite intersection (by “topology” here I mean the set of open sets). The product structure (topology or measure) is the minimal one such that the projections are well-behaved (respectively, continuous or measurable).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a6be96d0b33334c6a31c2b3bf2f20ef8ce2f7d97e0c701463b95bf4270e9e25-ce514ac0ea720ed87fa8c8930f4a34ce09507f5e810209a52d960dbea35d2d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Venky")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460604")[#strong[#text("Venky")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2015")])]

#text("Thanks Colin. I now realize that p < 1 can only be meaningfully multiplied to itself a finite number of times.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90dc3a80e880832979dd9695dfb17e7d8e2675e10237a1201c76e01b428f0821-7a33084dbb6fedff82935f90b129463904fb71305b94281c3d36ce5c59aca43b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicolás Sanhueza-Matamala")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460576")[#strong[#text("Nicolás Sanhueza-Matamala")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2015")])]

#text("A small typo: the first paragraph says “infintie” instead of “infinite”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a6be96d0b33334c6a31c2b3bf2f20ef8ce2f7d97e0c701463b95bf4270e9e25-ce514ac0ea720ed87fa8c8930f4a34ce09507f5e810209a52d960dbea35d2d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Venky")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460600")[#strong[#text("Venky")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2015")])]

#text("Small typo: in the definition of standard borel after Exercise 9, f doesn’t biject from E to [0,1].")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f42aa55b229b95cbb705672e1a181dea4a096b55f0a759e84fc4cfc8c9e42a58-61e9646899b70d6ccd1b5184915d6d0c6d95d5f42a8d398654590abdab10af7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460615")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2015")])]

#text("This is a trivial remark, but may complement the last paragraph: it may occasionally be possible to combine the zero-one law with a symmetry argument to actually determine a probability. For instance, if")#linebreak()#text(" $X_n$ are independent identically distributed with Ber(1/2) distribution, then the series $\\sum_{n=1} X_n/n$ is divergent with probability $1$. With a simple coupling argument you can replace $1/2$ by any parameter $p \\ge 1/2$. Of course, this gives no clue about the situation $p<1/2$.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a6be96d0b33334c6a31c2b3bf2f20ef8ce2f7d97e0c701463b95bf4270e9e25-ce514ac0ea720ed87fa8c8930f4a34ce09507f5e810209a52d960dbea35d2d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Venky")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460619")[#strong[#text("Venky")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2015")])]

#text("Small typo: below equation (4), v(E) = v'(E) not v(E’). This is a great proof. I saw the connection between the continuity and extension of measure and monotone classes.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1caade7d5519839750d0cd92318d8720fdbaa6168f0bbfc666d887b07fae55e-fa312207221d23cab4231237c4c67c2ecaae19ae9abdfc750f5bc4b7dabf2918.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of leaner")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460652")[#strong[#text("leaner")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2015")])]

#text("dear tao,I am a student from university .I want to ask you a question.I like math.when I learn by myself,l read the text carefully and try to prove every theorem.Then l’ll do some practice .And read thesis if I can.I think our class may be a little easy.I fell quite confused whether I should listen to him .can you give me some advise if you are available?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d9e338e0cd3c5854d68f121b5bf4dd9161377bdb81e3cdc27ffbef30ef3227b-78ebb2d5d5bd8641134d35ec8cda100165b35ec3350266a25bb780abe9cd2e13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460765")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2015")])]

#text("What was Kolmogorov’s issue in building his extension theorem? It seems quite laborious.")

#text("My guess: without too much difficulty we can assign measures or “probability” to many subsets of ")#mi("\\mathbb{R}")#text(" or even ")#mi("\\mathbb{R}^2")#text(". However in order to talk about repeated experiments or the Law of Large Numbers we need to define subspaces on an infinite product of copies of ")#mi("\\mathbb{R}")#text(". Even the infinite product ")#mi("\\{ 0,1 \\}^\\mathbb{Z}")#text(" with ")#mi("\\mu(0) = \\mu(1) = \\frac{1}{2}")#text(" can have unmeasurable subsets.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d9e338e0cd3c5854d68f121b5bf4dd9161377bdb81e3cdc27ffbef30ef3227b-78ebb2d5d5bd8641134d35ec8cda100165b35ec3350266a25bb780abe9cd2e13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460768")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2015")])]

#text("Any collection of experiments I can think of are not independent. There will always be trace amounts of interdependence.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460771")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2015")])]

#text("This is certainly true (and particularly relevant, for instance, when applying probabilistic models to mathematical finance). However, thanks to the mathematical phenomenon of universality, many of the results obtained from perfectly independent models (e.g. the central limit theorem) often also hold for more realistic models in which there is a weak amount of coupling. The perfectly independent case thus serves as an excellent toy model for more general models, as it is by far the best understood type of coupling. (The situation is somewhat analogous to linear PDE and nonlinear PDE; almost any real-world PDE is going to have some nonlinearity in it, but the linear case is an incredibly important toy model that must be understood first if one is to have any hope to get a hold of the nonlinear models.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460773")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2015")])]

#text("Measure theory has a lot of subtleties (e.g. Banach-Tarski paradoxes, inability to exchange limits, integrals, or sums with each other, interpreting divergent or non-measurable integrals or sums, or distinctions between different modes of convergence) that require care to address correctly, and so many of the foundational results in measure theory (such as the Kolmogorov extension theorem) are rather technical to prove. However, it is relatively easy to ")#emph[#text("apply")]#text(" these theorems once they are proven (as long as one actually verifies whatever technical hypotheses are needed for the theorem to hold, of course).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 3: The weak and strong law of large numbers | What's new")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-460849")[#strong[#text("275A, Notes 3: The weak and strong law of large numbers | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2015")])]

#text("[…] the law of large numbers with what one can obtain from the Kolmogorov zero-one law, discussed in Notes 2. Observe that if the are real-valued, then the limit superior and are tail random variables in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-461033")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2015")])]

#text("In Exercise 29, do we have any more additional assumptions on ")#mi("\\Sigma")#text("? It seems that the result of part (i) would need that ")#mi("\\Sigma")#text(" is also symmetric.")

#emph[#text("[I was using the convention that positive definite matrices are understood to be real symmetric (or at least Hermitian), but I reworded the exercise to clarify this point. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 4: The central limit theorem | What's new")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-461368")[#strong[#text("275A, Notes 4: The central limit theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2015")])]

#text("[…] be iid copies of ; by extending the probability space used to model (using Proposition 26 from Notes 2), we can model the and by a common model, in such a way that the combined collection of random […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/943eabd45b2b1ff577b3878c2c36f5e7fc21fd4e3a00d3e45f3fed604c939bdc-bd7b8c3392cdaac95ab3bd5e440d6e5cd5aff675bcb9ab12747ca9efa806ecab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-461410")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2015")])]

#text("There seems to be a typo in Exercise 14 in the definition of outer regularity. U should contain E and not the other way around.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-461536")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2015")])]

#text("Dear Terence Tao, in the paragraph above Theorem 33, I don’t understand the statement “the ")#mi("\\sigma")#text("-algebra ")#mi("\\sigma(X_i: i>n)")#text(" contains any event that is definable in terms of measurable relations of [finitely many] of the ")#mi("X_{n+1},X_{n+2},...")#text(", together with countable bollean operations on such evetns”. So why can’t we directly say that an event in ")#mi("\\sigma(X_i: i>n)")#text(" is definable or involves infinitely many ")#mi("X_i")#text("‘s? Or do you mean that such an event can always be generated by countable operations of events which only involve finitely many ")#mi("X_i")#text("‘s? Thanks very much.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-461537")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2015")])]

#text("The ")#mi("\\sigma")#text("-algebra ")#mi("\\sigma(X_i: i > n)")#text(" does indeed consist of all events that can be described as measurable combinations of the ")#mi("X_i")#text(" for ")#mi("i>n")#text(", which by the definition of the product ")#mi("\\sigma")#text("-algebra, is the same thing as countable boolean combinations of measurable combinations of finitely many of the ")#mi("X_i")#text(" for ")#mi("i>n")#text(". (The countable boolean combinations can be rather complicated though; most of the time one can get away with fairly simple combinations such as countable unions of countable intersections or vice versa, but in principle one could consider combinations that involve iterating the countable intersection and union operations along an arbitrarily countable ordinal.)")

#text("So it doesn’t really matter which way one views the ")#mi("\\sigma")#text("-algebra, but I prefer thinking more concretely in terms of countable boolean combinations of events that depend on finitely many variables, as this makes it explicit why random variables such as ")#mi("\\limsup_{n \\to \\infty} X_n")#text(" would be measurable in this ")#mi("\\sigma")#text("-algebra. (On the other hand, asking whether the set ")#mi("\\{ n: X_n > 0 \\}")#text(" belongs to a given non-principal ultrafilter will not, in general, be measurable in this ")#mi("\\sigma")#text("-algebra even though it does only depend on the ")#mi("X_i")#text(" for ")#mi("i>n")#text(", because it usually cannot be expressed as such a countable combination of events depending only on finitely many variables and so one does not get measurability in the product ")#mi("\\sigma")#text("-algebra.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-461540")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2015")])]

#text("Would you happen to know a natural example where Kolmogorov extension fails?")

#text("Or, for that matter, a natural example of non-Borel space which arises as a sample space in practice?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-461619")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2015")])]

#text("Dear Terry,")

#text("So is there no simple example of this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-461624")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2015")])]

#text("I don’t know of any “natural” example. The construction of Andersen and Jessen (see e.g. ")#link("http://www.sdu.dk/media/bibpdf/Bind%2020-29/Bind/mfm-25-4.pdf")[#text("http://www.sdu.dk/media/bibpdf/Bind%2020-29/Bind/mfm-25-4.pdf")]#text(" ) uses a variant of the Banach-Tarski paradox to build the counterexample, so it is arguably rather “unnatural”.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-461570")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2015")])]

#text("Typo: “We have the remarkable that says that the tail”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-461579")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2015")])]

#text("This typo is in the second line above theorem 33.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-461590")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2015")])]

#text("Now it seems that some formula in example 34 is not parsing.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab82efe8db2841454b1457793a9953a5a2a37cfd671dc7a9b01203b83c318270-25487a2c0a8940e06137563ee9850144e03d4637018ec997716042f03779ecb3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of XiangYu")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-462581")[#strong[#text("XiangYu")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2015")])]

#text("Dear Professor Tao")

#text("In paragraph below exercise 15, since ")#mi("\\mu^*(E)-1/n<\\mu(E_n)<\\mu*(E)+1/n")#text(" for every ")#mi("E\\in\\mathcal{F}_A")#text(". Can we say that ")#mi("\\mu(E)")#text(" is actually equal to ")#mi("\\mu*(E)")#text("?")

#emph[#text("[Yes; I’ve updated the text accordingly. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-464960")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2016")])]

#text("Extremely minor typo: $X$ in lieu of $\\Omega$ in proof of Lemma 2.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-466920")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2016")])]

#text("The following definition is taught in the undergraduate stochastic process course:")

#text("Given a probability space ")#mi("(\\Omega, \\mathcal{F}, P)")#text(" and a measurable space ")#mi("(S,\\Sigma)")#text(", an ")#mi("S")#text("-valued stochastic process is a collection of ")#mi("S")#text("-valued random variables on ")#mi("\\Omega")#text(", indexed by a totally ordered set ")#mi("T")#text(" (“time”). That is, a stochastic process $X$ is a collection")

#mi("\\{ X_t : t \\in T \\}")#linebreak()#text(" where each ")#mi("X_t")#text(" is an ")#mi("S")#text("-valued random variable on ")#mi("\\Omega")#text(". The space ")#mi("S")#text(" is then called the state space of the process.")

#text("It is said that one needs the Kolmogorov’s Existence Theorem to construct such stochastic processes. I don’t understand why one needs to do so. Why knowing the distribution of each ")#mi("X_t")#text(" is not enough to give a stochastic process ")#mi("X=:\\{X_t: t\\in T\\}")#text("? Isn’t ")#mi("X")#text(" just a family of random variables?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-466921")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2016")])]

#text("Knowing the distribution of each ")#mi("X_t")#text(" is not enough information to determine the distribution of the joint variable ")#mi("X")#text("; for instance, the ")#mi("X_t")#text(" could be independent, or they could be coupled together. (As discussed in Notes 0, knowing the distribution of each ")#mi("X_t")#text(" lets one model each ")#mi("X_t")#text(" by its own probability space ")#mi("(\\Omega_t, {\\mathcal F}_t, {\\mathbb P}_t)")#text(", but the point is that one has to couple all these random variables together to live on a common probability space ")#mi("(\\Omega, {\\mathcal F}, {\\mathbb P})")#text(". If one wants to specify the joint distributions of any finite number of the ")#mi("X_t")#text(" (e.g. if one wishes the ")#mi("X_t")#text(" to all be jointly independent), one needs the Kolmogorov extension theorem in order to construct such a common probability space for all of the ")#mi("X_t")#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-466923")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2016")])]

#text("I’m not sure if I have understood all your points.")

#text("As a special case , if it is already assumed that ")#mi("(\\Omega_t, {\\mathcal F}_t, {\\mathbb P}_t)=(\\Omega, {\\mathcal F}, {\\mathbb P})")#text(" for all ")#mi("t")#text(", namely, all the random variables ")#mi("X_t")#text(" are ")#emph[#text("assumed")]#text(" to live in a common probability space, then can one claim that ")#mi("\\{X_t:t\\in T\\}")#text(" is a stochastic process (as in the definition given in the previous comment) without using the Kolmogorov extension theorem?")

#text("I see that “Knowing the distribution of each $X_t$ is not enough information to determine the distribution of the joint variable $X$”. Does this suggest that the definition of stochastic processes given in the previous comment is not complete? All I can see from the definition of a stochastic process is that ")#mi("X=\\{X_t:t\\in T\\}")#text(" is just an indexed “set” of random variables which live in a common probability space and no consideration (even the existence) of “joint distribution” for ")#mi("X")#text(" is found in the definition. It seems from your comment that ")#mi("X")#text(" is also a “random variable” ")#mi("X:\\Omega\\to S^T")#text(" (using the notations in that definition).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-466928")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2016")])]

#text("An ordered tuple ")#mi("(X_t)_{t \\in T}")#text(" of random variables (modeled using a common probability space ")#mi("(\\Omega, {\\mathcal F}, {\\mathbb P})")#text("), with each ")#mi("X_t")#text(" taking values in some range ")#mi("R_t")#text(", can be viewed as a single random variable ")#mi("X")#text(" (modeled using the same probability space) taking values in the product space ")#mi("\\prod_{t \\in T} R_t")#text(", using the canonical identification of ")#mi("\\prod_{t \\in T} \\text{Hom}(\\Omega, R_t)")#text(" with ")#mi("\\text{Hom}(\\Omega, \\prod_{t \\in T} R_t)")#text(" (in the category of measurable spaces). So, yes, one can in principle describe a stochastic process by writing down a sample space, and then using that sample space to model a tuple of random variables ")#mi("X_t")#text(".")

#text("But in practice, one doesn’t want to specify the sample space explicitly (see ")#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/")[#text("Notes 0")]#text(" for more discussion of this point) – one would prefer to work in a “coordinate-free” fashion, and only describe those aspects of the stochastic process that are independent of the choice of sample space model, such as the individual distribution of the ")#mi("X_t")#text(", or the joint distribution of any finite number of the ")#mi("X_t")#text(". The Kolmogorov extension theorem tells us that the latter gives us all the information we need to describe the entire process up to change of sample space model (modulo the technical restriction to standard Borel spaces).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-468638")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2016")])]

#text("You use ")#mi("\\times")#text(" for the product of two ")#mi("\\sigma")#text("-algebra while some people use ")#mi("\\otimes")#text(". After all, this is just a matter of notation preference. On the other hand, ")#mi("\\mathcal{F}_1\\times\\mathcal{F}_2")#text(" is not a Cartesian product, where the notation ")#mi("\\times")#text(" is usually used. Is it some sort of “tensor product”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-468640")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2016")])]

#text("More or less, yes. More precisely, the category of measurable spaces ")#mi("(\\Omega, {\\mathcal F})")#text(" is a ")#link("https://en.wikipedia.org/wiki/Monoidal_category")[#text("monoidal category")]#text(" (which abstracts the concept of having a tensor product), with the operation ")#mi("(\\Omega_1, {\\mathcal F}_1), (\\Omega_2, {\\mathcal F}_2) \\mapsto (\\Omega_1 \\times \\Omega_2, {\\mathcal F}_1 \\times {\\mathcal F}_2)")#text(" being the tensor product. The Cartesian product can similarly be thought of as the tensor product in the monoidal category of sets. (Actually, in both cases the tensor product is also just the categorical product.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-473063")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2016")])]

#text("I have never seen that the concept ")#mi("\\pi")#text("–")#mi("\\lambda")#text(" system is used in real analysis. Why is it useful in probability theory? Can one say that everything can be done with the ")#mi("\\pi")#text("–")#mi("\\lambda")#text(" system is essentially can be done by “monotone class”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-473091")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2016")])]

#text("My understanding is that the monotone class theorem and the Dynkin pi-lambda theorem are basically equivalent, in that it is not difficult to use one to deduce the other, though I have not worked through the details myself (I have always used the monotone class theorem when I had to understand some tricky sigma-algebra). But there may be some minor technical advantages to using the pi-lambda formalism in probability theory (perhaps when working with continuous martingales?). The consensus seems to be though that the differences are small, and the choice of which to use is largely a matter of personal taste.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-473064")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2016")])]

#text("Is Halmos who first gave the proof of the Monotone class theorem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-473481")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Given a sequence of probability measure ")#mi("\\mu_n")#text(" on ")#mi("({\\bf R}^k, \\mathcal{B}_{\\bf R^k})")#text(", can one construct a sequence of independent random variables ")#mi("X_n")#text(" such that each ")#mi("X_n")#text(" has probability measure ")#mi("\\mu_n")#text("?")

#emph[#text("[Yes; see Proposition 26. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-474343")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("I find all the versions of the proof of the monotone class lemma I read before very difficult to remember until I read the following one from Billingsley’s Probability and Measure.")

#text("Replace ")#mi("\\mathcal{A}")#text(" with ")#mi("\\mathcal{F}")#text(" in the notes above.")

#text("Let ")#mi("m(\\mathcal{F})")#text(" be the minimal monotone class over ")#mi("\\mathcal{F}")#text(". It suffices to show that ")#mi("\\sigma(\\mathcal{F})\\subset m(\\mathcal{F})")#text(".")

#text("It suffices to show that ")#mi("m(\\mathcal{F})")#text(" is a ")#mi("\\sigma")#text("-field. But since a monotone field is a ")#mi("\\sigma")#text("-field, it suffices to show that ")#mi("m(\\mathcal{F})")#text(" is a field.")

#text("The essential goal now is to show that")

#mi("m(\\mathcal{F})")#text(" is closed under complementation and finite union.")

#text("Instead of doing the proof directly, define")#linebreak()#text(" ")#mi("\\displaystyle \\mathcal{G}=\\{A\\subset\\Omega\\mid A^c\\in m(\\mathcal{F})\\}")#linebreak()#text(" ")#mi("\\displaystyle \\mathcal{G}_1=\\{A\\subset\\Omega\\mid A\\cup B\\in m(\\mathcal{F})\\textrm{ for all } B\\in\\mathcal{F} \\},")#linebreak()#text(" and")#linebreak()#text(" ")#mi("\\displaystyle \\mathcal{G}_2=\\{A\\subset\\Omega\\mid A\\cup B\\in m(\\mathcal{F})\\textrm{ for all } B\\in m(\\mathcal{F}) \\}")#linebreak()#text(" It suffices to show that")#linebreak()#text(" ")#mi("\\displaystyle m(\\mathcal{F})\\subset\\mathcal{G},\\quad \\textrm{and }  m(\\mathcal{F})\\subset\\mathcal{G}_2.")#linebreak()#text(" All we need to do now is to show that both ")#mi("\\mathcal{G}")#text(" and ")#mi("\\mathcal{G}_2")#text(" are monotone classes containing ")#mi("\\mathcal{F}")#text(".")

#text("I’m quite curious that how you internalize a tricky proof like the one you gave in your notes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-474344")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("In Problem 8, would you elaborate why (6) is “clearly necessary”?")

#emph[#text("[Apply (7) to a set ")#mi("E_B")#text(" of the form ")#mi("E_B = \\pi_{B\\to C}^{-1}(E_C)")#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-474345")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("I can do Exercise 23 by considering the set ")#mi("\\Omega=\\{1,2,3,4\\}")#text(" and ")#mi("\\{1,2\\},\\{2,3\\},\\{3,4\\}")#text(".")

#text("How can I do it with the hint you gave? Would you elaborate?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-474425")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2016")])]

#text("Looking at the definition of independence, I’m not able to give an answer to the following question:")

#text("Given any real number ")#mi("c")#text(", is there a sequence of independent random variables such that they are all equal to ")#mi("c")#text(" surely?")

#text("Since they are all equal to to a same constant, must they be dependent?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-474429")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2016")])]

#text("Deterministic variables are simultaneously independent of each other, and dependent on each other; see also Exercises 18 and 19.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6f9a3759cfddec88c718f544268196f9c50877a9e8e363f4248f70c62498bb7-3c4aed7e15e2029d7f9c2e9de5ee55e0732281720cd2d2347b4bab3bc8ed91b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-475282")[#strong[#text("Tim")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2016")])]

#text("I have a question: if X and Y are normal (0,1) random variable with correlation coefficient r, then what’s the distribution of the tensor product of X and Y? Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-477089")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2017")])]

#text("In the Wikipedia arcticle (")#link("https://en.wikipedia.org/wiki/Kolmogorov_extension_theorem")[#text("https://en.wikipedia.org/wiki/Kolmogorov_extension_theorem")]#text("), the ")#emph[#text("Kolmogorov’s extension theorem")]#text(" says that if a given system of measures satisfies two “consistency conditions”, then there exists a stochastic process having these finite-dimensional distributions.")

#text("How different is this one from Theorem 10? Or are they equivalent? The consistency conditions in Wikipedia becomes the part of the conclusions of Theorem 10 in this note. Is the “standard Borel” condition corresponding to something in the Wikipedia article?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-477090")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2017")])]

#text("Sorry for this stupid question. The version in this note gives a more general form of the extension theorem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: The central limit theorem | What's new")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-478166")[#strong[#text("254A, Notes 2: The central limit theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("[…] be iid copies of ; by extending the probability space used to model (using Proposition 26 from Notes 2), we can model the and by a common model, in such a way that the combined collection of random […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doubtful determinism")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-482914")[#strong[#text("Doubtful determinism")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2017")])]

#text("This may be a question that is naive, but I can’t see why the uniqueness claim in Theorem 1 necessitates the more complicated proof that was given, using various structural properties of the sets ")#mi("\\mathcal{F}")#text(" that satisfy (4). Why is it not, instead, possible to do the following simpler proof, which uses the fact that ")#mi("\\nu,\\nu^{\\prime}")#text(" are already completely determined by (4) ?")#linebreak()#text(" Proof: For every ")#mi("E_1,E_2")#text(", the right-hand side ")#mi("\\mu_1(E_1)\\mu_2(E_2)")#text(" is a fixed number, which implies that if ")#mi("\\nu(E_1 \\times E_2)=\\mu_1(E_1)\\mu_2(E_2)")#text(" and ")#mi("\\nu^{\\prime}(E_1 \\times E_2)=\\mu_1(E_1)\\mu_2(E_2)")#text(", then ")#mi("\\nu(E_1 \\times E_2)=\\nu^{\\prime}(E_1 \\times E_2)")#text(". Since this holds for all ")#mi("E_1,E_2")#text(", the claim is proved.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-483060")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2017")])]

#text("Not every measurable set in ")#mi("\\Omega_1 \\times \\Omega_2")#text(" is of the form ")#mi("E_1 \\times E_2")#text(" (consider for instance the union of two disjoint rectangles in the plane). The sets ")#mi("E_1 \\times E_2")#text(" generate the ")#mi("\\sigma")#text("-algebra ")#mi("\\Omega_1 \\times \\Omega_2")#text(" (as noted in Exercise 14 of ")#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/")[#text("Notes 0")]#text("), but are not the only elements of that algebra.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/421d1bc187822d1a425403c66768a0e4bc4bb7ae836128fffed2def83958afbc-32201946d05599d122add0dd8f4faf3cd32916378a0cb7d2554da8d3199319d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of haonanz")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-488647")[#strong[#text("haonanz")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2017")])]

#text("Hello Professor Tao, I think I am having some confusions regard the fundamentals. My confusion can be illustrated in the following example: Assuming it’s a flipping coin experiment that follows Bernoulli Trial with probability p heads (denoted as 1), and probability (1-p) tail (Denoted as 0). The experiment is performed independently n times with corresponding sequence of random variables ")#mi("X_1, ..., X_n")#text(". I am interested in the conditional probability of ")#mi("P(X_n|X_1,...X_n-1)")#text(". By independence, we know that ")#mi("P(X_n|X_1,...X_n-1)=P(X_n)")#text(". However, we can infer on p based on the realization of ")#mi("X_1,...,X_{n-1}")#text(" through which indirectly affect $P(X_n)$ through p. In an extreme case, we can consider the situation ")#mi("X_1=X_2=...X_{n-1}=1")#text(". I think in summary, my point is that given a sequence of i.i.d R.Vs ")#mi("X_1,...X_n")#text(", The random variables are independent, but then there are some ‘dependency’ through the underlying distribution P. Right now, I am thinking that maybe the best way to resolve this is to look at an extended probability space which include the distribution, then $X_1…X_n$ is rather interpreted as conditional independent on the distribution. I wonder if this is the right way to look at this, Thanks so much.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-488649")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2017")])]

#text("It depends on the status of ")#mi("p")#text(" in your probabilistic model. If ")#mi("p")#text(" is a deterministic quantity, then the ")#mi("X_1,\\dots,X_n")#text(" are jointly independent. Inferring ")#mi("p")#text(" from some subset of this data does not actually give any additional information, since ")#mi("p")#text(" was not random to begin with. If instead ")#mi("p")#text(" is itself a random variable, then ")#mi("(X_1,\\dots,X_n)")#text(" is distributed according to a mixture of iid variables, rather than being iid, and so as you say the ")#mi("X_1,\\dots,X_n")#text(" are now only conditionally independent relative to ")#mi("p")#text(", but not jointly independent since knowledge of ")#mi("X_1,\\dots,X_{n-1}")#text(" does influence one’s posterior distribution of ")#mi("p")#text(", which in turn influences ")#mi("X_n")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-504726")[#strong[#text("Need help proving $[0,1]$ is Borel isomorphic to ${0,1}^mathbb{N}$. – eeem")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2018")]

#text("[…] 275A, Notes 2: Product measures and independence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-505756")[#strong[#text("Need help proving $[0,1]$ is Borel isomorphic to ${0,1}^mathbb{N}$. – Website Information")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2018")]

#text("[…] 275A, Notes 2: Product measures and independence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97d74f6011d21473399781084a4e5d6cd57c42f1b9c2bcd7cb816a4a1b0731b0-628f667ae65d8ca2979632e69a7e3464e7995f827e42e4dfa891f03579cd54f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hhhenforce")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-527003")[#strong[#text("hhhenforce")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2019")])]

#text("Hello Terence. Is there any analogue of the Tonelli-Fubini theorem when I is infinite ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-548557")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2020")])]

#text("There is a typo in the first line of Exercise 28.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/84e213380af91c3169b14eea5df3a2eb4cc323da240ee658d82a1e8ed9d9732e-c0ef6f984eeb07ce1ba19ddaea16b15116c439246b0cfe7e745c329f2fa02242.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-630837")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2021")])]

#text("In Exercise 4, the link should be to equation (1) and not (4).")#linebreak()#text(" In Exercise 24, the last line should be v_1, …, v_m.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2481608a3c1491886ff2976f3738a2b87de544fc1700c50cf789d5a2748af02-b6975050e465e7529ea8f12f3d017f803e46800cc5129dcd6f4385099392576e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymouse")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-634150")[#strong[#text("Anonymouse")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2021")])]

#text("In Exercise 18, I think you are missing some assumptions on the range. In particular, you need all singletons to be measurable, otherwise $X = c$ need not be an event and it doesn’t make sense to talk about a.s. constant r.v.")

#emph[#text("[Hypotheses added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48371f94215fc33bf9c630616ed4525ef86899d4a286dfcf3f691eadfed9f7c7-a587d8e49364f289dc20ee786716a9f09bb855d148bf0f70b8228830485487f9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yaver Gulusoy")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-634301")[#strong[#text("Yaver Gulusoy")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2021")])]

#text("Exercise 13, second display: the closing bracket for the set in question is missing.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/be89a0e232c3813ade17098f89e5c900c1955cda5531f7f44bb43c6477913954-f22ce890b81b59464d5c373ab6b8ee60dabfd5d8674faa3386ecbf8a7fd0983e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-643756")[#strong[#text("Kevin")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2022")])]

#text("Hello Professor Tao,")

#text("I have trouble understanding the end of the proof of lemma 12, which states that the image of the map is a ")#mi("G_\\delta")#text(" subset of ")#mi("[0,1]^\\mathbb{N}")#text(". It suffices to show that for each i, ")#mi("\\{ d(x, q_i) : x \\in X \\}")#text(" is a ")#mi("G_\\delta")#text(" subset of [0,1], but I have trouble showing that (I have replaced the original d with the equivalent metric d(x,y) = d(x,y) / (1 + d(x,y))). Or should I try a different approach?")

#text("Thanks in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-643788")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2022")])]

#text("Oops, you’re right, it’s only a countable intersection of ")#mi("F_\\sigma")#text(" sets. I’ve adjusted the text appropriately.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-678626")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2023")])]

#text("In Proposition 26, shouldn’t the /nu_i be probability measures not spaces?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3654189dd67ef2873d98bf28cb99ce604ef4bc258233e13ea0e6985b543bc8d6-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Han Bing")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-681832")[#strong[#text("Han Bing")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2023")])]

#text("Dear prof Tao:")#linebreak()#text(" In the proof of theorem 1, the function ")#mi("\\omega_1 \\mapsto \\mu_{\\Omega_2}(E_{\\omega_1})")#text(" should be ")#mi("\\omega_1 \\mapsto \\mu_2(E_{\\omega_1})")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3654189dd67ef2873d98bf28cb99ce604ef4bc258233e13ea0e6985b543bc8d6-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Han Bing")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-681843")[#strong[#text("Han Bing")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2023")])]

#text("Dear prof Tao:")#linebreak()#text(" Again in the proof of Theorem 1, the sentence “We have already established this claim when ")#mi("{f}")#text(" is unsigned and absolutely integrable.” should be “We have already established this claim when ")#mi("{f}")#text(" is unsigned and measurable”, since the absolute integrable case is what we’re trying to establish after this statement.")

#emph[#text("[Actually, this is intentional; we only wish to subtract the unsigned absolutely integrable cases to obtain the real absolutely integrable cases. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3654189dd67ef2873d98bf28cb99ce604ef4bc258233e13ea0e6985b543bc8d6-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Han Bing")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-681846")[#strong[#text("Han Bing")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2023")])]

#text("And a minor misspelling in the introduction: “techncialities” should be “technicalities”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3654189dd67ef2873d98bf28cb99ce604ef4bc258233e13ea0e6985b543bc8d6-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Han Bing")]], [#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-681849")[#strong[#text("Han Bing")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2023")])]

#text("Also in the proof of Theorem 1, the sets ")#mi("E_{\\omega_1}")#text(" should be ")#mi("E_{\\omega_1} := \\{ \\omega_2 \\in \\Omega_2: (\\omega_1, \\omega_2) \\in E\\}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/comment-page-1/#comment-681865")[#strong[#text("Han Bing")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2023")]

#text("Dear prof Tao:")#linebreak()#text(" In Exercise 7, the Stieltjes transform of the product measure should be given by ")#mi("(t_1, \\ldots ,t_n) \\mapsto F_1(t_1) \\ldots F_n(t_n)")#text(". And may I ask if this transform is defined similarly as the Stieltjes measure function in note 0 as ")#mi("(t_1, \\ldots ,t_n) \\mapsto \\mu_1 \\times \\ldots \\times \\mu_n(\\prod_{i=1}^n(-\\infty, t_i])")#text("?")

#emph[#text("[Corrected (also exercise has been moved). -T]")]
]
