// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/
// Converted to Typst by tao2typ: "2026-10-14T15:19:45.662894+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Heuristic computation of correlations of higher order divisor functions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Heuristic computation of correlations of higher order divisor functions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 31 August 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/")[#text("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is a postscript to ")#link("https://terrytao.wordpress.com/2016/08/30/heuristic-computation-of-correlations-of-the-divisor-function/")[#text("the previous blog post")]#text(" which was concerned with obtaining heuristic asymptotic predictions for the correlation ")#metadata(none) <tao-e07f52f45ffcfe004432>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{n \\leq x} \\tau(n) \\tau(n+h),")]]



#text(" for the ")#link("https://en.wikipedia.org/wiki/Divisor_function")[#text("divisor function")]#text(" ")#mi("{\\tau(n) := \\sum_{d|n} 1}")#text(", in particular recovering the ")#link("http://www.ams.org/mathscinet-getitem?mr=1574426")[#text("calculation of Ingham")]#text(" that obtained the asymptotic ")#metadata(none) <tao-da6cab8c95b41e375ec5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{n \\leq x} \\tau(n) \\tau(n+h) \\sim \\frac{6}{\\pi^2} \\sigma_{-1}(h) x \\log^2 x")]]



#text(" when ")#mi("{h}")#text(" was fixed and non-zero and ")#mi("{x}")#text(" went to infinity. It is natural to consider the more general correlations")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\tau_k(n) \\tau_l(n+h)")]]

#text("for fixed ")#mi("{k,l \\geq 1}")#text(" and non-zero ")#mi("{h}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\tau_k(n) := \\sum_{d_1 \\dots d_k = n} 1")]]

#text("is the order ")#mi("{k}")#text(" divisor function. The sum ")#link(<tao-e07f52f45ffcfe004432>)[#text("(1)")]#text(" then corresponds to the case ")#mi("{k=l=2}")#text(". For ")#mi("{l=1}")#text(", ")#mi("{\\tau_1(n) = 1}")#text(", and a routine application of the Dirichlet hyperbola method (or Perron’s formula) gives the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\tau_k(n) \\sim \\frac{\\log^{k-1} x}{(k-1)!} x,")]]

#text("or more accurately")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\tau_k(n) \\sim P_k(\\log x) x")]]

#text("where ")#mi("{P_k(t)}")#text(" is a certain explicit polynomial of degree ")#mi("{k-1}")#text(" with leading coefficient ")#mi("{\\frac{1}{(k-1)!}}")#text("; see e.g. Exercise 31 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory")[#text("this previous post")]#text(" for a discussion of the ")#mi("{k=3}")#text(" case (which is already typical). Similarly if ")#mi("{k=1}")#text(". For more general ")#mi("{k,l \\geq 1}")#text(", there is a ")#link("http://www.ams.org/mathscinet-getitem?mr=1828303")[#text("conjecture of Conrey and Gonek")]#text(" which predicts that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\tau_k(n) \\tau_l(n+h) \\sim P_{k,l,h}(\\log x) x")]]

#text("for some polynomial ")#mi("{P_{k,l,h}(t)}")#text(" of degree ")#mi("{k+l-2}")#text(" which is explicit but whose form is rather complicated (one has to compute residues of a various complicated products of zeta functions and local factors). This conjecture has been verified when ")#mi("{k \\leq 2}")#text(" or ")#mi("{l \\leq 2}")#text(", by the work of ")#link("http://www.ams.org/mathscinet-getitem?mr=168543")[#text("Linnik")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=558887")[#text("Motohashi")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=836283")[#text("Fouvry-Tenenbaum")]#text(", and others, but all the remaining cases when ")#mi("{k,l \\geq 3}")#text(" are currently open.")

#text("In principle, the calculations of the previous post should recover the predictions of Conrey and Gonek. In this post I would like to record this for the top order term:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1")]#text(" ")#metadata(none) <tao-d1a73570aa079cee4251>#text(" If ")#mi("{k,l \\geq 2}")#text(" and ")#mi("{h \\neq 0}")#text(" are fixed, then")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\tau_k(n) \\tau_l(n+h) \\sim \\frac{\\log^{k-1} x}{(k-1)!} \\frac{\\log^{l-1} x}{(l-1)!} x \\prod_p {\\mathfrak S}_{k,l,p}(h)")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(", where the product is over all primes ")#mi("{p}")#text(", and the local factors ")#mi("{{\\mathfrak S}_{k,l,p}(h)}")#text(" are given by the formula ")#metadata(none) <tao-8425180f45cbd8b1f524>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("{\\mathfrak S}_{k,l,p}(h) := (\\frac{p-1}{p})^{k+l-2} \\sum_{j \\geq 0: p^j|h} \\frac{1}{p^j} P_{k,l,p}(j)")]]



#text(" where ")#mi("{P_{k,l,p}}")#text(" is the degree ")#mi("{k+l-4}")#text(" polynomial")

#align(center)[#tao-fit-display[#mitex("P_{k,l,p}(j) := \\sum_{k^{\\prime}=2}^k \\sum_{l^{\\prime}=2}^l \\binom{k-k^{\\prime}+j-1}{k-k^{\\prime}} \\binom{l-l^{\\prime}+j-1}{l-l^{\\prime}} \\alpha_{k^{\\prime},l^{\\prime},p}")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\alpha_{k^{\\prime},l^{\\prime},p} := (\\frac{p}{p-1})^{k^{\\prime}-1} + (\\frac{p}{p-1})^{l^{\\prime}-1} - 1")]]

#text("and one adopts the conventions that ")#mi("{\\binom{-1}{0} = 1}")#text(" and ")#mi("{\\binom{m-1}{m} = 0}")#text(" for ")#mi("{m \\geq 1}")#text(".")
]

#text("For instance, if ")#mi("{k=l=2}")#text(" then")

#align(center)[#tao-fit-display[#mitex("P_{2,2,p}(h) = \\frac{p}{p-1} + \\frac{p}{p-1} - 1 = \\frac{p+1}{p-1}")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak S}_{2,2,p}(h) = (1 - \\frac{1}{p^2}) \\sum_{j \\geq 0: p^j|h} \\frac{1}{p^j}")]]

#text("and the above conjecture recovers the Ingham formula ")#link(<tao-da6cab8c95b41e375ec5>)[#text("(2)")]#text(". For ")#mi("{k=2, l=3}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("P_{2,3,p}(h) =")]]

#align(center)[#tao-fit-display[#mitex("(\\frac{p}{p-1} + (\\frac{p}{p-1})^2 - 1) + (\\frac{p}{p-1} + \\frac{p}{p-1} - 1) j")]]

#align(center)[#tao-fit-display[#mitex("= \\frac{p^2+p-1}{(p-1)^2} + \\frac{p+1}{p-1} j")]]

#text("and so we predict")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\tau(n) \\tau_3(n+h) \\sim \\frac{x \\log^3 x}{2} \\prod_p {\\mathfrak S}_{2,3,p}(h)")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak S}_{2,3,p}(h) = \\sum_{j \\geq 0: p^j|h} \\frac{\\frac{p^3 - 2p + 1}{p^3} + \\frac{(p+1)(p-1)^2}{p^3} j}{p^j}.")]]

#text("Similarly, if ")#mi("{k=l=3}")#text(" we have")

#tao-aligned(keep: true)[


#tao-math("P_{3,3,p}(h)  & = ((\\frac{p}{p-1})^2 + (\\frac{p}{p-1})^2 - 1) + 2 (\\frac{p}{p-1} + (\\frac{p}{p-1})^2 - 1) j", block: true)



#tao-math(" & + (\\frac{p}{p-1} + \\frac{p}{p-1} - 1) j^2", block: true)



#tao-math(" & = \\frac{p^2+2p-1}{(p-1)^2} + 2 \\frac{p^2+p-1}{(p-1)^2} j + \\frac{p+1}{p-1} j^2", block: true)
]

#text("and so we predict")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\tau_3(n) \\tau_3(n+h) \\sim \\frac{x \\log^4 x}{4} \\prod_p {\\mathfrak S}_{3,3,p}(h)")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak S}_{3,3,p}(h) = \\sum_{j \\geq 0: p^j|h} \\frac{\\frac{p^4 - 4p^2 + 4p - 1}{p^4} + 2 \\frac{(p^2+p-1)(p-1)^2}{p^4} j + \\frac{(p+1)(p-1)^3}{p^4} j^2}{p^j}.")]]

#text("and so forth.")

#text("As in the previous blog, the idea is to factorise")

#align(center)[#tao-fit-display[#mitex("\\tau_k(n) = \\prod_p \\tau_{k,p}(n)")]]

#text("where the local factors ")#mi("{\\tau_{k,p}(n)}")#text(" are given by")

#align(center)[#tao-fit-display[#mitex("\\tau_{k,p}(n) := \\sum_{j_1,\\dots,j_k \\geq 0: p^{j_1+\\dots+j_k} || n} 1")]]

#text("(where ")#mi("{p^j || n}")#text(" means that ")#mi("{p}")#text(" divides ")#mi("{n}")#text(" precisely ")#mi("{j}")#text(" times), or in terms of the valuation ")#mi("{v_p(n)}")#text(" of ")#mi("{n}")#text(" at ")#mi("{p}")#text(", ")#metadata(none) <tao-e40d16db6ea0c7b0cca1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\tau_{k,p}(n) = \\binom{k-1+v_p(n)}{k-1}.")]]





#text("We then have the following exact local asymptotics:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Local correlations)")]#text(" ")#metadata(none) <tao-fbea0f7cc3310d1ccdc6>#text(" Let ")#mi("{{\\bf n}}")#text(" be a ")#link("https://en.wikipedia.org/wiki/Profinite_integer")[#text("profinite integer")]#text(" chosen uniformly at random, let ")#mi("{h}")#text(" be a profinite integer, and let ")#mi("{k,l \\geq 2}")#text(". Then ")#metadata(none) <tao-866089a1c6f9e9f1a014>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("{\\bf E} \\tau_{k,p}({\\bf n}) = (\\frac{p}{p-1})^{k-1}")]]



#text(" and ")#metadata(none) <tao-851ada0272c216952e49>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("{\\bf E} \\tau_{k,p}({\\bf n}) \\tau_{l,p}({\\bf n}+h) = (\\frac{p}{p-1})^{k+l-2} {\\mathfrak S}_{k,l,p}(h).")]]




]

#text("(For profinite integers it is possible that ")#mi("{v_p({\\bf n})}")#text(" and hence ")#mi("{\\tau_{k,p}({\\bf n})}")#text(" are infinite, but this is a probability zero event and so can be ignored.)")

#text("Conjecture ")#link(<tao-d1a73570aa079cee4251>)[#text("1")]#text(" can then be heuristically justified from the local calculations ")#link(<tao-fbea0f7cc3310d1ccdc6>)[#text("(2)")]#text(" by various pseudorandomness heuristics, as discussed in the ")#link("https://terrytao.wordpress.com/2016/08/30/heuristic-computation-of-correlations-of-the-divisor-function/")[#text("previous post")]#text(".")

#text("I’ll give a short proof of the above proposition below, basically using the recursive methods of the previous post. This short proof actually took be quite a while to find; I spent several hours and a fair bit of scratch paper working out the cases ")#mi("{k,l = 2,3}")#text(" laboriously by hand (with some assistance and cross-checking from Maple). Here is an unorganised sample of some of this scratch, just to show how the sausage is actually made:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2016/08/wp_20160831_12_53_59_pro2.jpg")[#image("../assets/f3eba874f1da88978782840f4a16848d3ee9fa6fe3a9c29be82f2c3721a42167-5a20e299f37b965d66851677183c565e1b63489fc8c13e1fb62c2405575a291f.jpg", width: 90%, alt: "WP_20160831_12_53_59_Pro")]

#text("It was only after expending all this effort that I realised that it would be much more efficient to compute the correlations for all values of ")#mi("{k,l}")#text(" simultaneously by using ")#link("https://en.wikipedia.org/wiki/Generating_function")[#text("generating functions")]#text(". After performing this computation, it then became apparent that there would be a direct combinatorial proof of ")#link(<tao-851ada0272c216952e49>)[#text("(6)")]#text(" that was shorter than even the generating function proof. (I will not supply the full generating function calculations here, but will at least show them for the easier correlation ")#link(<tao-866089a1c6f9e9f1a014>)[#text("(5)")]#text(".)")

#text("I am confident that Conjecture ")#link(<tao-d1a73570aa079cee4251>)[#text("1")]#text(" is consistent with the explicit asymptotic in the Conrey-Gonek conjecture, but have not yet rigorously established that the leading order term in the latter is indeed identical to the expression provided above.")

#metadata(none) <tao-c6a1dec4f56ea94a9245>

#text("We now prove ")#link(<tao-866089a1c6f9e9f1a014>)[#text("(5)")]#text(". Here we will use the generating function method. From the binomial formula we have the formal expansion")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=1}^\\infty \\tau_{k,p}(n) t^{k-1} = (1-t)^{-v_p(n)-1}")]]

#text("for any ")#mi("{n}")#text(". By the geometric series formula, it thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} (1-t)^{-v_p({\\bf n})-1} = (1 - \\frac{p}{p-1} t)^{-1}")]]

#text("in the ring of formal power series in ")#mi("{t}")#text(".")

#text("With probability ")#mi("{\\frac{p-1}{p}}")#text(", ")#mi("{{\\bf n}}")#text(" is coprime to ")#mi("{p}")#text(" and thus ")#mi("{(1-t)^{-v_p({\\bf n})-1} = \\frac{1}{1-t}}")#text(". In the remaining probability ")#mi("{\\frac{1}{p}}")#text(" event, ")#mi("{{\\bf n} = p {\\bf n}^{\\prime}}")#text(" for some ")#mi("{{\\bf n}^{\\prime}}")#text(" with the same distribution as the original random variable ")#mi("{{\\bf n}}")#text(", and ")#mi("{(1-t)^{-v_p({\\bf n})-1} = \\frac{1}{1-t} (1-t)^{-v_p({\\bf n}^{\\prime})-1}}")#text(". This leads to the identity")

#align(center)[#tao-fit-display[#mitex("{\\bf E} (1-t)^{-v_p({\\bf n})-1} = \\frac{p-1}{p} \\frac{1}{1-t} + \\frac{1}{p} \\frac{1}{1-t} {\\bf E} (1-t)^{-v_p({\\bf n})-1}")]]

#text("and the claim then follows from a brief amount of high-school algebra.")

#text("Now we prove ")#link(<tao-851ada0272c216952e49>)[#text("(6)")]#text(". By ")#link(<tao-8425180f45cbd8b1f524>)[#text("(3)")]#text(", our task is to show that ")#metadata(none) <tao-43ed826ae8a2caf94a28>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("{\\bf E} \\tau_{k,p}({\\bf n}) \\tau_{l,p}({\\bf n}+h) = \\sum_{k^{\\prime}=2}^k \\sum_{l^{\\prime}=2}^l \\sum_{j \\geq 0: p^j|h} \\frac{1}{p^j} \\binom{k-k^{\\prime}+j-1}{k-k^{\\prime}} \\binom{l-l^{\\prime}+j-1}{l-l^{\\prime}} \\alpha_{k^{\\prime},l^{\\prime},p}.")]]



#text(" The above generating function method will establish this (and, as I said above, this was how I originally discovered the formula), but we give here a combinatorial proof. We first deal with the case when ")#mi("{h}")#text(" is not divisible by ")#mi("{p}")#text(". In this case, at least one of ")#mi("{\\tau_{k,p}({\\bf n})}")#text(" and ")#mi("{\\tau_{l,p}({\\bf n}+h)}")#text(" must equal ")#mi("{1}")#text("; we can phrase this fact algebraically as the identity")

#align(center)[#tao-fit-display[#mitex("(\\tau_{k,p}({\\bf n})-1) (\\tau_{l,p}({\\bf n}+h)-1) = 0")]]

#text("or equivalently ")#metadata(none) <tao-1a7674eb4ee78df7e1ac>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\tau_{k,p}({\\bf n}) \\tau_{l,p}({\\bf n}+h) = \\tau_{k,p}({\\bf n}) + \\tau_{l,p}({\\bf n}+h) - 1.")]]



#text(" By linearity (and translation invariance) of expectation and ")#link(<tao-866089a1c6f9e9f1a014>)[#text("(5)")]#text(" we thus have")

#tao-aligned(keep: true)[


#tao-math("{\\bf E} \\tau_{k,p}({\\bf n}) \\tau_{l,p}({\\bf n}+h)  & = (\\frac{p}{p-1})^{k-1} + (\\frac{p}{p-1})^{l-1} - 1", block: true)



#tao-math(" & = \\alpha_{k,l,p}", block: true)
]

#text("which gives ")#link(<tao-43ed826ae8a2caf94a28>)[#text("(7)")]#text(" in this case.")

#text("Now suppose that ")#mi("{h = ph^{\\prime}}")#text(" for some (profinite) integer ")#mi("{h^{\\prime}}")#text(". With probability ")#mi("{\\frac{p-1}{p}}")#text(", ")#mi("{{\\bf n}}")#text(" is coprime to ")#mi("{p}")#text(", so that ")#mi("{\\tau_{k,p}({\\bf n}) = \\tau_{l,p}({\\bf n}+h) = 1}")#text("; in particular ")#link(<tao-1a7674eb4ee78df7e1ac>)[#text("(8)")]#text(" holds here. In the remaining probability ")#mi("{\\frac{1}{p}}")#text(" event, we can write ")#mi("{{\\bf n} = p {\\bf n}^{\\prime}}")#text(". From ")#link(<tao-e40d16db6ea0c7b0cca1>)[#text("(4)")]#text(" and Pascal triangle identities, we have")

#align(center)[#tao-fit-display[#mitex("\\tau_{k,p}({\\bf n}) = 1 + \\sum_{k^{\\prime}=2}^k \\tau_{k^{\\prime},p}({\\bf n}^{\\prime})")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("\\tau_{l,p}({\\bf n}+h) = 1 + \\sum_{l^{\\prime}=2}^l \\tau_{l^{\\prime},p}({\\bf n}^{\\prime}+h^{\\prime})")]]

#text("and hence on subtracting ")#mi("{1}")#text(" from both equations, multiplying, and rearranging we have a variant of ")#link(<tao-1a7674eb4ee78df7e1ac>)[#text("(8)")]#text(":")

#tao-aligned(keep: true)[


#tao-math("\\tau_{k,p}({\\bf n}) \\tau_{l,p}({\\bf n}+h)  & = \\tau_{k,p}({\\bf n}) + \\tau_{l,p}({\\bf n}+h) - 1", block: true)



#tao-math(" & + \\sum_{k^{\\prime}=2}^k \\sum_{l^{\\prime}=2}^l \\tau_{k^{\\prime},p}({\\bf n}^{\\prime}) \\tau_{l^{\\prime},p}({\\bf n}^{\\prime}+h^{\\prime}).", block: true)
]

#text("Putting this together, we see that")

#tao-aligned(keep: true)[


#tao-math("\\mathop{\\bf E} \\tau_{k,p}({\\bf n}) \\tau_{l,p}({\\bf n}+h)  & = \\mathop{\\bf E} \\tau_{k,p}({\\bf n}) + \\tau_{l,p}({\\bf n}+h) - 1", block: true)



#tao-math(" & + \\frac{1}{p} \\sum_{k^{\\prime}=2}^k \\sum_{l^{\\prime}=2}^l \\mathop{\\bf E} \\tau_{k^{\\prime},p}({\\bf n}^{\\prime}) \\tau_{l^{\\prime},p}({\\bf n}^{\\prime}+h^{\\prime})", block: true)
]

#text("and hence by ")#link(<tao-866089a1c6f9e9f1a014>)[#text("(5)")]#text(" as before")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\tau_{k,p}({\\bf n}) \\tau_{l,p}({\\bf n}+h) = \\alpha_{k,l,p} + \\frac{1}{p} \\sum_{k^{\\prime}=2}^k \\sum_{l^{\\prime}=2}^l \\mathop{\\bf E} \\tau_{k^{\\prime},p}({\\bf n}) \\tau_{l^{\\prime},p}({\\bf n}+h^{\\prime}).")]]

#text("The claim is now easily verified from an induction on ")#mi("{v_p(h)}")#text(", as well as many applications of Pascal triangle identities.")

#heading(level: 1)[#text("Comments (24)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sylvainjulien")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-472048")[#strong[#text("sylvainjulien")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2016")])]

#text("In conjecture 1, I get a message ‘formula doesn’t parse’ after ‘local factors’.")

#emph[#text("[Corrected now – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5300af1818b8761458a6f02cfea203aa82326dfa94d21ebf450c03d10cbb52ee-cf9c768b018abac89ec66cccb335f859e5e145972366ade7b7ce092b5046b429.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dejan Kovacevic")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-472055")[#strong[#text("Dejan Kovacevic")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2016")])]

#text("It’s interesting to see how the sausage is actually made ;-)")#linebreak()#text(" Not sure about the others, but I am not using paper at all, although there are no fully appropriate software tools on the market for what Terry showed. Maple and Mathematica are useful just for small subset for all that work (and one to follow)…Here is my ‘meatball shop’:")#linebreak()#text(" ")#link("http://ateravis.com/owncloud/index.php/s/jG3A3WvFA7dw4RV")[#text("http://ateravis.com/owncloud/index.php/s/jG3A3WvFA7dw4RV")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-472056")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2016")])]

#text("Is it possible to get similar conjectures for ")#mi("\\tau(n)^k")#text(" instead of (or perhaps in addition to) ")#mi("\\tau_k(n)")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-472057")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2016")])]

#text("Certainly! Actually the two types of functions are related to each other by various linear identites such as ")#mi("\\tau(n)^2 =2 \\tau_2(n) - \\tau(n)")#text(", so it is fairly easy to pass from one to the other.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcac903803a1b0a0534f5b0f152de2326a53080f21a6bd85e0eb64b76f82fea8-b9cdcca583d21e3a75a6a8aaa86d4d4c4f033a66432bf5cf392ef95304daca50.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Irene Klaas")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-630328")[#strong[#text("Irene Klaas")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2021")])]

#text("The identity you mentioned appears to be wrong. I get from your notation that")#linebreak()#text(" ")#tao-fit-display[#mitex("\\tau=\\tau_2.")]#linebreak()#text(" In fact, if you take $h \\rightarrow 0$ then your factor in (2) explodes. You get logarithmic divergence and this is what you would expect, isn’t it?")

#emph[#text("[See my correction from Sep 1 2016 below – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-472072")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2016")])]

#text("Since ")#mi("\\zeta(s)^k = \\sum_{n \\geq 1} \\tau_k(n) n^{-s}")#text(" is meromorphic on ")#mi("\\mathbb C")#text(" for ")#mi("k=1, 2, ...")#text(", while for the more general generating function ")#mi("f_{k,r} (s) := \\sum_{n \\geq 1}\\tau_k(n)^r n^{-s}")#text(", it was proved (see Ramanujan’s collected papers, p. 339) by Estermann (probably in his paper “On certain functions represented by Dirichlet series” Proc. London Math. Soc.(2) 27 (1928) 435-448) that for ")#mi("k \\geq 2, r \\geq 1")#text(", the function ")#mi("f_{k, r}(s)")#text(" is meromorphic in the right half plane ")#mi("\\Re (s) > 0")#text(" and, except the cases ")#mi("r=1")#text(" or ")#mi("r=k=2")#text(", has the line ")#mi("\\Re (s) = 0")#text(" as its natural boundary!")

#text("Therefore it is not clear how such linear identities representing ")#mi("\\tau(n)^r")#text(" for ")#mi("r= 3, 4, ...")#text(" (whose generating function has the imaginary axis as its natural boundary) as linear combinations of ")#mi("\\tau_k(n)")#text(" (whose generating function is a polynomial in ")#mi("\\zeta(s)")#text(" and therefore meromorphic on ")#mi("\\mathbb C")#text(") can possibly exist?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-472085")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2016")])]

#text("Oops, you’re right; the identities I had in mind were only true locally, for instance ")#mi("\\tau_p(n)^2 = 2 \\tau_{2,p}(n) - \\tau_p(n)")#text(". So the local factors for ")#mi("\\tau^k")#text(" correlations can be derived from those of ")#mi("\\tau_k")#text(" correlations, which can then be multiplied together to establish the global prediction. But a proof of the global correlation estimates for ")#mi("\\tau_k")#text(" do not directly imply those for ")#mi("\\tau^k")#text(" or vice versa. Nevertheless, the theory of both functions ought to be very similar. For instance ")#mi("\\tau^k")#text(" agrees with ")#mi("\\tau_{2^k+1}")#text(" on squarefree numbers.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0eb3a55089dd81695aa0035558947aeeea8b50c25e1e82823368fd27619de13e-e864f13c8c0741baba64613683a4586340b195fd86b1e3c0c978509ad0725c80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-472081")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2016")])]

#text("I’m so happy to see your work.We’re gonna meet one day.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-472091")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2016")])]

#text("I’d be interested in a higher res picture of the scratch paper, to get a look at the actual calculations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-472098")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2016")])]

#text("Is there a j^2 missing from the 3rd term in the numerator of the expression for ")#mi("{\\mathfrak S}_{3,3,p}(h)")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-472192")[#strong[#text("Heuristic computation of correlations of higher order divisor functions — What’s new – hakoblog")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2016")]

#text("[…] via Heuristic computation of correlations of higher order divisor functions — What’s new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5300af1818b8761458a6f02cfea203aa82326dfa94d21ebf450c03d10cbb52ee-cf9c768b018abac89ec66cccb335f859e5e145972366ade7b7ce092b5046b429.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dejan Kovacevic")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-472242")[#strong[#text("Dejan Kovacevic")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2016")])]

#text("Question: I noticed that some sheets of paper on shared image contains either special characters or, more likely, some symbolic/graphic notation. I wonder if that is something formal/established or it is a mechanism which you use to simplify analysis?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8c4d6459b6ce0e7b782f470031d2b7806f42f6352b83927b667f6a65f6b2379b-1632e51caaf69db6f1317bcc9e69e1060f45277aacfd70b1293361c5805b3084.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ken")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-472258")[#strong[#text("Ken")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2016")])]

#text("It is already published before, isn’t? ")#link("http://vixra.org/abs/1609.0030")[#text("http://vixra.org/abs/1609.0030")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a2570c0511ae3f9d7899d707e21705867e367f1ea597013f83579ddf46430c77-4724d458bf35118306d3ebc5bf1bfc86aa722f5ed8e96aae59903ac4556bc16e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-472395")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2016")])]

#text("Is there a nice form known for the ordinary generating function of $\\tau_k(n)$, i.e. $\\sum_{n=1}^{\\infty} \\tau_k(n) x^n$? Or a nice way to estimate this for a fixed value of $x$ with $|x|<1$?")

#text("This came up recently in the course of some calculations I was making, and I can only seem to find info about the Dirichlet generating function of $\\tau_k(n)$.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-472396")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2016")])]

#text("I doubt there is a closed form expression for ")#mi("\\sum_{n=1}^\\infty \\tau_k(n) x^n = \\sum_{n_1,\\dots,n_k \\geq 1} x^{n_1 \\dots n_k}")#text(". One can use the geometric series formula to remove one of the summations, e.g. ")#mi("\\sum_{n=1}^\\infty \\tau_2(n) x^n = \\sum_m \\frac{x^m}{1-x^m}")#text(", but after that there isn’t much else one can do. (The divisor functions ")#mi("\\tau_k")#text(" have multiplicative structure but not much additive structure, which is the main reason why they have a nice Dirichlet series but not such a nice generating function.)")

#text("On the other hand, one can use summation by parts to estimate an expression such as ")#mi("\\sum_{n =1}^\\infty \\tau_k(n) x^n")#text(" in terms of partial sums ")#mi("\\sum_{n \\leq X} \\tau_k(n)")#text(". Roughly speaking, for ")#mi("x")#text(" of the form ")#mi("x = 1-\\varepsilon")#text(", a sum of the form ")#mi("\\sum_{n=1}^\\infty a_n x^n")#text(" should behave like (a smoothed version) of ")#mi("\\sum_{n \\leq 1/\\varepsilon} a_n")#text(", since the range ")#mi("n \\leq 1/\\varepsilon")#text(" is roughly where the weight ")#mi("x^n")#text(" is large.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a2570c0511ae3f9d7899d707e21705867e367f1ea597013f83579ddf46430c77-4724d458bf35118306d3ebc5bf1bfc86aa722f5ed8e96aae59903ac4556bc16e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-472397")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2016")])]

#text("Thank you for your prompt and helpful comment!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-472400")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2016")])]

#text("Your example for the generating function for ")#mi("\\tau_2(n)")#text(" is a particular Lambert series, and indeed the Wikipedia article on Lambert series gives the generating function for ")#mi("\\sigma_{\\alpha}(n)")#text(" (for any complex ")#mi("\\alpha")#text(") as a simple Lambert series.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-473206")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2016")])]

#text("Very enlightening!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-473207")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2016")])]

#text("The conclusion of this paper is true?")#linebreak()#text(" The Distribution of Prime Numbers in an Interval")#linebreak()#text(" American Journal of Mathematics and Statistics, 2015 5(6), pp. 325-328")#linebreak()#text(" 10.5923/j.ajms.20150506.01")#linebreak()#text(" ")#link("http://article.sapub.org/10.5923.j.ajms.20150506.01.html")[#text("http://article.sapub.org/10.5923.j.ajms.20150506.01.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28a186d404df5ca8c54b5a2ffa0bae90ff1bf67bbf41973066f81f7066a23565-c08d340c13ac4472e221851e2d5659c7010f2b5b4154f5851578de2ca8b248c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of heverson01")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-475262")[#strong[#text("heverson01")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2016")])]

#text("“The first mathematical fact that amazed me was the Pythagorean theorem,” said mathematician Daina Taimina of Cornell University (USA). “I was a child and it seemed so incredible that it worked in geometry and worked with numbers!")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://johanneshaertel.wordpress.com/2016/12/24/8-os-beneficios-do-abacate/")[#text("8 Os beneficios do abacate")]
]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2616d77bfe269dd7e5a859b312b2f5f223df621a2a57c6d8cd851255303a0c55-85157bed679281d136eacd9e0407bcb5c8bfafb73cc9283263d790b9686d573e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin Smith")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-478349")[#strong[#text("Kevin Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2017")])]

#text("Hello Terry, I am wondering if the asymptotic correlations will remain the same here when $k$, $l$ are positive real numbers and not necessarily integer. What is your opinion on this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-478402")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2017")])]

#text("The top order term in the asymptotics should be basically the same (replacing factorials with Gamma functions as appropriate, of course). The lower order terms are more subtle, I think one should get an infinite asymptotic series in powers of ")#mi("\\log x")#text(" now, rather than just a polynomial. (One already sees this behavior just for the 1-point correlations ")#mi("\\sum_{n \\leq x} \\tau_k(n)")#text(" when ")#mi("k")#text(" is non-integer.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Correlations of the von Mangoldt and higher divisor functions II. Divisor correlations in short ranges | What's new")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-490842")[#strong[#text("Correlations of the von Mangoldt and higher divisor functions II. Divisor correlations in short ranges | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2017")])]

#text("[…] discussed in this previous post, one heuristically expects an asymptotic of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b5fcb88c9ab5b0793fe7c14e056ae27817b078a8afce60204d515de6ef4d809-f599d4173b17f9eb4328d7a652e280c44df05fd53449e3cfe876363cd260b3bf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Moriarty")]], [#link("https://terrytao.wordpress.com/2016/08/31/heuristic-computation-of-correlations-of-higher-order-divisor-functions/#comment-541615")[#strong[#text("James Moriarty")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2020")])]

#text("Apparently you were unhappy with Windows Phone 8/8.1. What’s the feature you missed? What’s what you didn’t like?")
]
