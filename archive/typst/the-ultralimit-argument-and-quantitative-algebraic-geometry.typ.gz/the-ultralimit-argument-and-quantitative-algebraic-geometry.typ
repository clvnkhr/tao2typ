// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/
// Converted to Typst by tao2typ: "2026-10-14T15:17:37.972408+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Ultralimit analysis, and quantitative algebraic geometry", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Ultralimit analysis, and quantitative algebraic geometry")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 January 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("have blogged")]#text(" ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("a number")]#text(" ")#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")[#text("of times")]#text(" ")#link("https://terrytao.wordpress.com/2009/12/13/approximate-bases-sunflowers-and-nonstandard-analysis/")[#text("in the past")]#text(" about the relationship between finitary (or “hard”, or “quantitative”) analysis, and infinitary (or “soft”, or “qualitative”) analysis. One way to connect the two types of analysis is via ")#emph[#text("compactness arguments")]#text(" (and more specifically, ")#emph[#text("contradiction and compactness")]#text(" arguments); such arguments can convert qualitative properties (such as continuity) to quantitative properties (such as bounded), basically because of the fundamental fact that continuous functions on a compact space are bounded (or the closely related fact that sequentially continuous functions on a sequentially compact space are bounded).")

#text("A key stage in any such compactness argument is the following: one has a sequence ")#mi("{X_n}")#text(" of “quantitative” or “finitary” objects or spaces, and one has to somehow end up with a “qualitative” or “infinitary” limit object ")#mi("{X}")#text(" or limit space. One common way to achieve this is to embed everything inside some universal space and then use some weak compactness property of that space, such as the ")#link("http://en.wikipedia.org/wiki/Banach%E2%80%93Alaoglu_theorem")[#text("Banach-Alaoglu theorem")]#text(" (or its sequential counterpart). This is for instance the idea behind the ")#emph[#text("Furstenberg correspondence principle")]#text(" relating ergodic theory to combinatorics; see for instance ")#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")[#text("this post of mine")]#text(" on this topic.")

#text("However, there is a slightly different approach, which I will call ")#emph[#text("ultralimit analysis")]#text(", which proceeds via the machinery of ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilters")]#text(" and ")#link("http://en.wikipedia.org/wiki/Ultraproduct")[#text("ultraproducts")]#text("; typically, the limit objects ")#mi("{X}")#text(" one constructs are now the ultraproducts (or ultralimits) of the original objects ")#mi("{X_\\alpha}")#text(". There are two main facts that make ultralimit analysis powerful. The first is that one can take ultralimits of ")#emph[#text("arbitrary")]#text(" sequences of objects, as opposed to more traditional tools such as metric completions, which only allow one to take limits of ")#link("http://en.wikipedia.org/wiki/Cauchy_sequence")[#text("Cauchy sequences")]#text(" of objects. The second fact is ")#link("http://en.wikipedia.org/wiki/Los's_theorem#.C5.81o.C5.9B.27s_theorem")[#text("Los’s theorem")]#text(", which tells us that ")#mi("{X}")#text(" is an ")#emph[#text("elementary limit")]#text(" of the ")#mi("{X_\\alpha}")#text(" (i.e. every sentence in first-order logic which is true for the ")#mi("{X_\\alpha}")#text(" for ")#mi("{\\alpha}")#text(" large enough, is true for ")#mi("{X}")#text("). This existence of elementary limits is a manifestation of the ")#link("http://en.wikipedia.org/wiki/Compactness_theorem")[#text("compactness theorem")]#text(" in logic; see ")#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/")[#text("this earlier blog post")]#text(" for more discussion. So we see that compactness methods and ultrafilter methods are closely intertwined. (See also ")#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/")[#text("my earlier class notes")]#text(" for a related connection between ultrafilters and compactness.)")

#text("Ultralimit analysis is very closely related to ")#link("http://en.wikipedia.org/wiki/Nonstandard_analysis")[#text("nonstandard analysis")]#text(". I already discussed some aspects of this relationship in ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("an earlier post")]#text(", and will expand upon it at the bottom of this post. Roughly speaking, the relationship between ultralimit analysis and nonstandard analysis is analogous to the relationship between measure theory and probability theory.")

#text("To illustrate how ultralimit analysis is actually used in practice, I will show later in this post how to take a qualitative infinitary theory – in this case, basic algebraic geometry – and apply ultralimit analysis to then deduce a quantitative version of this theory, in which the complexity of the various algebraic sets and varieties that appear as outputs are controlled uniformly by the complexity of the inputs. The point of this exercise is to show how ultralimit analysis allows for a relatively painless conversion back and forth between the quantitative and qualitative worlds, though in some cases the quantitative translation of a qualitative result (or vice versa) may be somewhat unexpected. In an upcoming paper of myself, Ben Green, and Emmanuel Breuillard (announced in the previous blog post), we will rely on ultralimit analysis to reduce the messiness of various quantitative arguments by replacing them with a qualitative setting in which the theory becomes significantly cleaner.")

#text("For sake of completeness, I also redo some earlier instances of the correspondence principle via ultralimit analysis, namely the deduction of the quantitative Gromov theorem from the qualitative one, and of Szemerédi’s theorem from the Furstenberg recurrence theorem, to illustrate how close the two techniques are to each other.")

#metadata(none) <tao-ef06c9edfb45371b5f7e>

#heading(level: 1)[#strong[#text(" — 1. Ultralimit analysis — ")]]

#text("In order to perform ultralimit analysis, we need to prepare the scene by deciding on three things in advance:")

#list(
[#text("The ")#emph[#text("standard universe")]#text(" ")#mi("{{\\mathcal U}}")#text(" of standard objects and spaces.")],
[#text("A distinction between ")#emph[#text("ordinary objects")]#text(", and ")#emph[#text("spaces")]#text(".")],
[#text("A choice of ")#emph[#text("non-principal ultrafilter")]#text(" ")#mi("{\\alpha_\\infty \\in \\beta {\\mathbb N} \\backslash {\\mathbb N}}")#text(".")]
)

#text("We now discuss each of these three preparatory ingredients in turn.")

#text("We assume that we have a ")#emph[#text("standard universe")]#text(" or ")#emph[#text("superstructure")]#text(" ")#mi("{{\\mathcal U}}")#text(" which contains all the “standard” sets, objects, and structures that we ordinarily care about, such as the natural numbers, the real numbers, the power set of real numbers, the power set of the power set of real numbers, and so forth. For technical reasons, we have to limit the size of this universe by requiring that it be a set, rather than a class; thus (by ")#link("http://en.wikipedia.org/wiki/Russell's_paradox")[#text("Russell’s paradox")]#text("), not all sets will be standard (e.g. ")#mi("{{\\mathcal U}}")#text(" itself will not be a standard set). However, in many areas of mathematics (particularly those of a “finitary” or at most “countable” flavour, or those based on finite-dimensional spaces such as ")#mi("{{\\mathbb R}^d}")#text("), the type of objects considered in a field of mathematics can often be contained inside a single set ")#mi("{{\\mathcal U}}")#text(". For instance, the class of all groups is too large to be a set. But in practice, one is only interested in, say, groups with an at most countable number of generators, and if one then enumerates these generators and considers their relations, one can identify each such group (up to isomorphism) to one in some fixed set of model groups. One can then take ")#mi("{{\\mathcal U}}")#text(" to be the collection of these groups, and the various objects one can form from these groups (e.g. power sets, maps from one group to another, etc.). Thus, in practice, the requirement that we limit the scope of objects to care about is not a significant limitation. (If one does not want to limit one’s scope in this fashion, one can proceed instead using the machinery of ")#link("http://en.wikipedia.org/wiki/Grothendieck_universe")[#text("Grothendieck universes")]#text(".)")

#text("It is important to note that while we primarily ")#emph[#text("care")]#text(" about objects inside the standard universe ")#mi("{{\\mathcal U}}")#text(", we allow ourselves to ")#emph[#text("use")]#text(" objects outside the standard universe (but still inside the ambient set theory) whenever it is convenient to do so. The situation is analogous to that of using complex analysis to solve real analysis problems; one may only care about statements that have to do with real numbers, but sometimes it is convenient to introduce complex numbers within the ")#emph[#text("proofs")]#text(" of such statements. (More generally, the trick of passing to some ")#emph[#text("completion")]#text(" ")#mi("{\\overline{{\\mathcal U}}}")#text(" of one’s original structure ")#mi("{{\\mathcal U}}")#text(" in order to more easily perform certain mathematical arguments is a common theme throughout modern mathematics.)")

#text("We will also assume that there is a distinction between two types of objects in this universe: ")#emph[#text("spaces")]#text(", which are sets that can contain other objects, and ")#emph[#text("ordinary objects")]#text(", which are all the objects that are not spaces. Thus, for instance, a group element would typically be considered an ordinary object, whereas a group itself would be a space that group elements can live in. It is also convenient to view functions ")#mi("{f: X \\rightarrow Y}")#text(" between two spaces as itself a type of ordinary object (namely, an element of a space ")#mi("{\\text{Hom}(X,Y)}")#text(" of maps from ")#mi("{X}")#text(" to ")#mi("{Y}")#text("). The precise concept of what constitutes a space, and what constitutes an ordinary object, is somewhat hard to formalise, but the basic rule of thumb to decide whether an object ")#mi("{X}")#text(" should be a space or not is to ask whether mathematical phrases such as ")#mi("{x \\in X}")#text(", ")#mi("{f: X \\rightarrow Y}")#text(", or ")#mi("{A \\subset X}")#text(" are likely to make useful sense. If so, then ")#mi("{X}")#text(" is a space; otherwise, ")#mi("{X}")#text(" is an ordinary object.")

#text("Examples of spaces include sets, groups, rings, fields, graphs, vector spaces, topological spaces, metric spaces, function spaces, measure spaces, dynamical systems, and operator algebras. Examples of ordinary objects include points, numbers, functions, matrices, strings, and equations.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Note that in some cases, a single object may seem to be both an ordinary object and a space, but one can often separate the two roles that this object is playing by making a sufficiently fine distinction. For instance, in Euclidean geometry, a line ")#mi("{\\ell}")#text(" in is both an ordinary object (it is one of the primitive concepts in that geometry), but it can also be viewed as a space of points. In such cases, it becomes useful to distinguish between the ")#emph[#text("abstract line")]#text(" ")#mi("{\\ell}")#text(", which is the primitive object, and its ")#emph[#text("realisation")]#text(" ")#mi("{\\ell[{\\mathbb R}]}")#text(" as a space of points in the Euclidean plane. This type of distinction is quite common in algebraic geometry, thus, for instance, the imaginary circle ")#mi("{C := \\{ (x,y): x^2 + y^2 = -1 \\}}")#text(" has an empty realisation ")#mi("{C[{\\mathbb R}] = \\emptyset}")#text(" in the real plane ")#mi("{{\\mathbb R}^2}")#text(", but has a non-trivial realisation ")#mi("{C[{\\mathbb C}]}")#text(" in the complex plane ")#mi("{{\\mathbb C}^2}")#text(" (or over finite fields), and so we do not consider ")#mi("{C}")#text(" (as an abstract algebraic variety) to be empty. Similarly, given a function ")#mi("{f}")#text(", we distinguish between the function ")#mi("{f}")#text(" itself (as an abstract object) and the graph ")#mi("{f[X] := \\{ (x,f(x)): x \\in X \\}}")#text(" of that function over some given domain ")#mi("{X}")#text(".")
]

#text("We also fix a ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("nonprincipal ultrafilter")]#text(" ")#mi("{\\alpha_\\infty}")#text(" on the natural numbers. Recall that this is a collection of subsets of ")#mi("{{\\mathbb N}}")#text(" with the following properties:")

#list(
[#text("No finite set lies in ")#mi("{\\alpha_\\infty}")#text(".")],
[#text("If ")#mi("{A \\subset {\\mathbb N}}")#text(" is in ")#mi("{\\alpha_\\infty}")#text(", then any subset of ")#mi("{{\\mathbb N}}")#text(" containing ")#mi("{A}")#text(" is in ")#mi("{\\alpha_\\infty}")#text(".")],
[#text("If ")#mi("{A, B}")#text(" lie in ")#mi("{\\alpha_\\infty}")#text(", then ")#mi("{A \\cap B}")#text(" also lies in ")#mi("{\\alpha_\\infty}")#text(".")],
[#text("If ")#mi("{A \\subset {\\mathbb N}}")#text(", then exactly one of ")#mi("{A}")#text(" and ")#mi("{{\\mathbb N} \\backslash A}")#text(" lies in ")#mi("{\\alpha_\\infty}")#text(".")]
)

#text("Given a property ")#mi("{P(\\alpha)}")#text(" which may be true or false for each natural number ")#mi("{\\alpha}")#text(", we say that ")#mi("{P}")#text(" is true for ")#mi("{\\alpha}")#text(" ")#emph[#text("sufficiently close to")]#text(" ")#mi("{\\alpha_\\infty}")#text(" if the set ")#mi("{\\{ \\alpha \\in {\\mathbb N}: P(\\alpha) \\text{ holds}\\}}")#text(" lies in ")#mi("{\\alpha_\\infty}")#text(". The existence of a non-principal ultrafilter ")#mi("{\\alpha_\\infty}")#text(" is guaranteed by the ")#link("http://en.wikipedia.org/wiki/Ultrafilter_lemma#The_ultrafilter_lemma")[#text("ultrafilter lemma")]#text(", which can be proven using the axiom of choice.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One can view ")#mi("{\\alpha_\\infty}")#text(" as a point in the ")#link("http://en.wikipedia.org/wiki/Stone%E2%80%93%C4%8Cech_compactification")[#text("Stone-Čech compactification")]#text(", in which case “for ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text("” acquires the familiar topological meaning “for all ")#mi("{\\alpha}")#text(" in a neighbourhood of ")#mi("{\\alpha_\\infty}")#text("“.")
]

#text("We can use this ultrafilter to take limits of standard objects and spaces. Indeed, given any two sequences ")#mi("{(x_\\alpha)_{\\alpha \\in {\\mathbb N}}}")#text(", ")#mi("{(y_\\alpha)_{\\alpha \\in {\\mathbb N}}}")#text(" of standard ordinary objects, we say that such sequences are ")#emph[#text("equivalent")]#text(" if we have ")#mi("{x_\\alpha = y_\\alpha}")#text(" for all ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text(". We then define the ")#emph[#text("ultralimit")]#text(" ")#mi("{\\lim_{\\alpha \\rightarrow \\alpha_\\infty} x_\\alpha}")#text(" of a sequence ")#mi("{(x_\\alpha)_{\\alpha \\in {\\mathbb N}}}")#text(" to be the equivalence class of ")#mi("{(x_\\alpha)_{\\alpha \\in {\\mathbb N}}}")#text(" (in the space ")#mi("{{\\mathcal U}^{\\mathbb N}}")#text(" of all sequences in the universe). In other words, we have")

#align(center)[#tao-fit-display[#mitex("\\lim_{\\alpha \\rightarrow \\alpha_\\infty} x_\\alpha = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} y_\\alpha")]]

#text("if and only if ")#mi("{x_\\alpha = y_\\alpha}")#text(" for all ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text(".")

#text("The ultralimit ")#mi("{\\lim_{\\alpha \\rightarrow \\alpha_\\infty} x_\\alpha}")#text(" lies outside the standard universe ")#mi("{{\\mathcal U}}")#text(", but is still constructible as an object in the ambient set theory (because ")#mi("{{\\mathcal U}}")#text(" was assumed to be a set). Note that we do not need ")#mi("{x_\\alpha}")#text(" to be well-defined for all ")#mi("{\\alpha}")#text(" for the limit ")#mi("{(x_\\alpha)_{\\alpha \\in {\\mathbb N}}}")#text(" to make sense; it is enough that ")#mi("{x_\\alpha}")#text(" is well-defined for all ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text(".")

#text("If ")#mi("{x = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} x_\\alpha}")#text(", we refer to the sequence ")#mi("{x_\\alpha}")#text(" of ordinary objects as a ")#emph[#text("model")]#text(" for the limit ")#mi("{x}")#text(". Thus, any two models for the same limit object ")#mi("{x}")#text(" will agree in a sufficiently small neighbourhood of ")#mi("{\\alpha_\\infty}")#text(".")

#text("Similarly, given a sequence of standard spaces ")#mi("{(X_\\alpha)_{\\alpha \\in {\\mathbb N}}}")#text(", one can form the ")#emph[#text("ultralimit")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Ultraproduct")[#text("ultraproduct")]#text(") ")#mi("{\\lim_{\\alpha \\rightarrow \\alpha_\\infty} X_\\alpha}")#text(", defined as the collection of all ultralimits ")#mi("{\\lim_{\\alpha \\rightarrow \\alpha_\\infty} x_\\alpha}")#text(" of sequences ")#mi("{x_\\alpha}")#text(", where ")#mi("{x_\\alpha \\in X_\\alpha}")#text(" for all ")#mi("{\\alpha \\in {\\mathbb N}}")#text(" (or for all ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text("). Again, this space will lie outside the standard universe, but is still a set. (This will not conflict with the notion of ultralimits for ordinary objects, so long as one always takes care to keep spaces and ordinary objects separate.) If ")#mi("{X = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} X_\\alpha}")#text(", we refer to the sequence ")#mi("{X_\\alpha}")#text(" of spaces as a ")#emph[#text("model")]#text(" for ")#mi("{X}")#text(".")

#text("As a special case of an ultralimit, given a single space ")#mi("{X}")#text(", its ultralimit ")#mi("{\\lim_{\\alpha \\rightarrow \\alpha_\\infty} X}")#text(" is known as the ")#emph[#text("ultrapower")]#text(" of ")#mi("{X}")#text(" and will be denoted ")#mi("{{}^* X}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" One can view ")#mi("{{}^* X}")#text(" as a type of ")#emph[#text("completion")]#text(" of ")#mi("{X}")#text(", much as the reals are the ")#link("http://en.wikipedia.org/wiki/Complete_metric_space#Completion")[#text("metric completion")]#text(" of the rationals. Indeed, just as the reals encompass all limits ")#mi("{\\lim_{n \\rightarrow \\infty} x_n}")#text(" of Cauchy sequences ")#mi("{x_1,x_2,\\ldots}")#text(" in the rationals, up to equivalence, the ultrapower ")#mi("{{}^* X}")#text(" encompass all limits of ")#emph[#text("arbitrary")]#text(" sequences in ")#mi("{X}")#text(", up to agreement sufficiently close to ")#mi("{\\alpha_\\infty}")#text(". The ability to take limits of arbitrary sequences, and not merely Cauchy sequences or convergent sequences, is the underlying source of power of ultralimit analysis. (This ability ultimately arises from the universal nature of the Stone-Čech compactification ")#mi("{\\beta {\\mathbb N}}")#text(", as well as the discrete nature of ")#mi("{{\\mathbb N}}")#text(", which makes all sequences ")#mi("{n \\mapsto x_n}")#text(" continuous.)")
]

#text("Of course, we embed the rationals into the reals by identifying each rational ")#mi("{x}")#text(" with its limit ")#mi("{\\lim_{n \\rightarrow \\infty} x}")#text(". In a similar spirit, we identify every standard ordinary object ")#mi("{x}")#text(" with its ultralimit ")#mi("{\\lim_{\\alpha \\rightarrow \\alpha_\\infty} x}")#text(". In particular, a standard space ")#mi("{X}")#text(" is now identified with a subspace of ")#mi("{{}^* X}")#text(". When ")#mi("{X}")#text(" is finite, it is easy to see that this embedding of ")#mi("{X}")#text(" to ")#mi("{{}^* X}")#text(" is surjective; but for infinite ")#mi("{X}")#text(", the ultrapower is significantly larger than ")#mi("{X}")#text(" itself.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" One could collect the ultralimits of all the ordinary objects and spaces in the standard universe ")#mi("{{\\mathcal U}}")#text(" and form a new structure, the ")#emph[#text("nonstandard universe")]#text(" ")#mi("{\\overline{{\\mathcal U}}_{\\alpha_\\infty}}")#text(", which one can view as a ")#emph[#text("completion")]#text(" of the standard universe, in much the same way that the reals are a completion of the rationals. However, we will not have to explicitly deal with this nonstandard universe and will not discuss it again in this post.")
]

#text("In nonstandard analysis, an ultralimit of standard ordinary object in a given class is referred to as (or more precisely, ")#emph[#text("models")]#text(") a ")#emph[#text("nonstandard")]#text(" object in that class. To emphasise the slightly different philosophy of ultralimit analysis, however, I would like to call these objects ")#emph[#text("limit objects")]#text(" in that class instead. Thus, for instance:")

#list(
[#text("An ultralimit ")#mi("{n = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} n_\\alpha}")#text(" of standard natural numbers is a ")#emph[#text("limit natural number")]#text(" (or a nonstandard natural number, or an element of ")#mi("{{}^* {\\mathbb N}}")#text(");")],
[#text("An ultralimit ")#mi("{x = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} x_\\alpha}")#text(" of standard real numbers is a ")#emph[#text("limit real number")]#text(" (or a nonstandard real number, or a ")#link("http://en.wikipedia.org/wiki/Hyperreal_number")[#text("hyperreal")]#text(", or an element of ")#mi("{{}^* {\\mathbb R}}")#text(");")],
[#text("An ultralimit ")#mi("{\\phi = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} \\phi_\\alpha}")#text(" of standard functions ")#mi("{\\phi_\\alpha: X_\\alpha \\rightarrow Y_\\alpha}")#text(" between two sets ")#mi("{X_\\alpha,Y_\\alpha}")#text(" is a ")#emph[#text("limit function")]#text(" (also known as an internal function, or a nonstandard function);")],
[#text("An ultralimit ")#mi("{\\phi = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} \\phi_\\alpha}")#text(" of standard continuous functions ")#mi("{\\phi_\\alpha: X_\\alpha \\rightarrow Y_\\alpha}")#text(" between two topological spaces ")#mi("{X_\\alpha,Y_\\alpha}")#text(" is a ")#emph[#text("limit continuous function")]#text(" (or internal continuous function, or nonstandard continuous function);")],
[#text("etc.")]
)

#text("Clearly, all standard ordinary objects are limit objects of the same class, but not conversely.")

#text("Similarly, ultralimits of spaces in a given class will be referred to ")#emph[#text("limit spaces")]#text(" in that class (in nonstandard analysis, they would be called nonstandard spaces or internal spaces instead). For instance:")

#list(
[#text("An ultralimit ")#mi("{X = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} X_\\alpha}")#text(" of standard sets is a limit set (or internal set, or nonstandard set);")],
[#text("An ultralimit ")#mi("{G = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} G_\\alpha}")#text(" of standard groups is a limit group (or internal group, or nonstandard group);")],
[#text("An ultralimit ")#mi("{(X,{\\mathcal B},\\mu) = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} (X_\\alpha,{\\mathcal B}_\\alpha,\\mu_\\alpha)}")#text(" of standard measure spaces is a limit measure space (or internal measure space, or nonstandard measure space);")],
[#text("etc.")]
)

#text("Note that finite standard spaces will also be limit spaces of the same class, but infinite standard spaces will not. For instance, ")#mi("{{\\mathbb Z}}")#text(" is a standard group, but is not a limit group, basically because it does not contain limit integers such as ")#mi("{\\lim_{\\alpha \\rightarrow \\alpha_\\infty} \\alpha}")#text(". However, ")#mi("{{\\mathbb Z}}")#text(" is contained in the limit group ")#mi("{{}^* {\\mathbb Z}}")#text(". The relationship between standard spaces and limit spaces is analogous to that between incomplete spaces and complete spaces in various fields of mathematics (e.g. in metric space theory or field theory).")

#text("Any operation or result involving finitely many standard objects, spaces, and first-order quantifiers carries over to their nonstandard or limit counterparts (the formal statement of this is ")#link("http://en.wikipedia.org/wiki/Los's_theorem#.C5.81o.C5.9B.27s_theorem")[#text("Los’s theorem")]#text("). For instance, the addition operation on standard natural numbers gives an addition operation on limit natural numbers, defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\lim_{\\alpha \\rightarrow \\alpha_\\infty} n_\\alpha + \\lim_{\\alpha \\rightarrow \\alpha_\\infty} m_\\alpha := \\lim_{\\alpha \\rightarrow \\alpha_\\infty} (n_\\alpha + m_\\alpha).")]]

#text("It is easy to see that this is a well-defined operation on the limit natural numbers ")#mi("{{}^* {\\mathbb N}}")#text(", and that the usual properties of addition (e.g. the associative and commutative laws) carry over to this limit (much as how the associativity and commutativity of addition on the rationals automatically implies the same laws of arithmetic for the reals). Similarly, we can define the other arithmetic and order relations on limit numbers: for instance we have")

#align(center)[#tao-fit-display[#mitex("\\lim_{\\alpha \\rightarrow \\alpha_\\infty} n_\\alpha \\geq \\lim_{\\alpha \\rightarrow \\alpha_\\infty} m_\\alpha")]]

#text("if and only if ")#mi("{n_\\alpha \\geq m_\\alpha}")#text(" for all ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_0}")#text(", and similarly define ")#mi("{\\leq, >, <}")#text(", etc. Note from the definition of an ultrafilter that we still have the usual order trichotomy: given any two limit numbers ")#mi("{n, m}")#text(", exactly one of ")#mi("{n < m}")#text(", ")#mi("{n=m}")#text(", and ")#mi("{n>m}")#text(" is true.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" The limit natural number ")#mi("{\\omega := \\lim_{\\alpha \\rightarrow \\alpha_\\infty} \\alpha}")#text(" is larger than all standard natural numbers, but ")#mi("{\\omega^2 = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} \\alpha^2}")#text(" is even larger still.")
]

#text("The following two exercises should give some intuition of how Los’s theorem is proved, and what it could be useful for:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Show that the following two formulations of ")#link("http://en.wikipedia.org/wiki/Goldbach%27s_conjecture")[#text("Goldbach’s conjecture")]#text(" are equivalent:")

#list(
[#text("Every even natural number greater than two is the sum of two primes.")],
[#text("Every even limit natural number greater than two is the sum of two prime limit natural numbers.")]
)

#text("Here, we define a limit natural number ")#mi("{n}")#text(" to be ")#emph[#text("even")]#text(" if we have ")#mi("{n=2m}")#text(" for some limit natural number ")#mi("{m}")#text(", and a limit natural number ")#mi("{n}")#text(" to be ")#emph[#text("prime")]#text(" if it is greater than ")#mi("{1}")#text(" but cannot be written as the product of two limit natural numbers greater than ")#mi("{1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" ")#metadata(none) <tao-15f19fd1977a6974efaf>#text(" Let ")#mi("{k_\\alpha}")#text(" be a sequence of algebraically closed fields. Show that the ultralimit ")#mi("{k := \\lim_{\\alpha \\rightarrow \\alpha_\\infty} k_\\alpha}")#text(" is also an algebraically closed field. In other words, every limit algebraically closed field is an algebraically closed field.")
]

#text("Given an ultralimit ")#mi("{\\phi := \\lim_{\\alpha \\rightarrow \\alpha_\\infty} \\phi_\\alpha}")#text(" of functions ")#mi("{\\phi_\\alpha: X_\\alpha \\rightarrow Y_\\alpha}")#text(", we can view ")#mi("{\\phi}")#text(" as a function from the limit space ")#mi("{X := \\prod_{\\alpha \\rightarrow \\alpha_\\infty} X_\\alpha}")#text(" to the limit space ")#mi("{Y := \\prod_{\\alpha \\rightarrow \\alpha_\\infty} Y_\\alpha}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\phi( \\lim_{\\alpha \\rightarrow \\alpha_\\infty} x_\\alpha ) := \\lim_{\\alpha \\rightarrow \\alpha_\\infty} \\phi_\\alpha(x_\\alpha).")]]

#text("Again, it is easy to check that this is well-defined. Thus every limit function from a limit space ")#mi("{X}")#text(" to a limit space ")#mi("{Y}")#text(" is a function from ")#mi("{X}")#text(" to ")#mi("{Y}")#text(", but the converse is not true in general.")

#text("One can easily show that limit sets behave well with respect to finitely many boolean operations; for instance, the intersection of two limit sets ")#mi("{X = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} X_\\alpha}")#text(" and ")#mi("{Y = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} Y_\\alpha}")#text(" is another limit set, namely ")#mi("{X \\cap Y = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} X_\\alpha \\cap Y_\\alpha}")#text(". However, we caution that the same is not necessarily true for infinite boolean operations; the countable union or intersection of limit sets need not be a limit set. (For instance, each individual standard integer in ")#mi("{{\\mathbb Z}}")#text(" is a limit set, but their union ")#mi("{{\\mathbb Z}}")#text(" is not.) Indeed, there is an analogy between the limit subsets of a limit set, and the ")#link("http://en.wikipedia.org/wiki/Clopen_set")[#text("clopen")]#text(" subsets of a topological space (or the ")#link("http://en.wikipedia.org/wiki/Constructible_set_(topology)")[#text("constructible sets")]#text(" in an algebraic variety).")

#text("By the same type of arguments used to show Exercise ")#link(<tao-15f19fd1977a6974efaf>)[#text("2")]#text(", one can check that every limit group is a group (albeit one that usually lies outside the standard universe ")#mi("{{\\mathcal U}}")#text("), every limit ring is a ring, every limit field is a field, etc.")

#text("The situation with vector spaces is a little more interesting. The ultraproduct ")#mi("{V = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} V_\\alpha}")#text(" of a collection of standard vector spaces ")#mi("{V_\\alpha}")#text(" over ")#mi("{{\\mathbb R}}")#text(" is a vector space over the larger field ")#mi("{{}^* {\\mathbb R}}")#text(", because the various scalar multiplication operations ")#mi("{\\cdot_\\alpha: {\\mathbb R} \\times V_\\alpha \\rightarrow V_\\alpha}")#text(" over the standard reals become a scalar multiplication operation ")#mi("{\\cdot: {}^* {\\mathbb R} \\times V \\rightarrow V}")#text(" over the limit reals. Of course, as the standard reals ")#mi("{{\\mathbb R}}")#text(" are a subfield of the limit reals ")#mi("{{}^* {\\mathbb R}}")#text(", ")#mi("{V}")#text(" is also a vector space over the standard reals ")#mi("{{\\mathbb R}}")#text("; but when viewed this way, the properties of the ")#mi("{V_\\alpha}")#text(" are not automatically inherited by ")#mi("{V}")#text(". For instance, if each of the ")#mi("{V_\\alpha}")#text(" are ")#mi("{d}")#text("-dimensional over ")#mi("{{\\mathbb R}}")#text(" for some fixed finite ")#mi("{d}")#text(", then ")#mi("{V}")#text(" is ")#mi("{d}")#text("-dimensional over the ")#emph[#text("limit")]#text(" reals ")#mi("{{}^* {\\mathbb R}}")#text(", but is infinite dimensional over the reals ")#mi("{{\\mathbb R}}")#text(".")

#text("Now let ")#mi("{A = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} A_\\alpha}")#text(" be a limit finite set, i.e. a limit of finite sets ")#mi("{A_\\alpha}")#text(". Every finite set is a limit finite set, but not conversely; for instance, ")#mi("{\\lim_{\\alpha \\rightarrow \\alpha_\\infty} \\{1,\\ldots,\\alpha\\}}")#text(" is a limit finite set which has infinite cardinality. On the other hand, because every finite set ")#mi("{A_\\alpha}")#text(" has a cardinality ")#tao-math("{\\left|A_\\alpha\\right| \\in {\\mathbb N}}", block: false)#text(" which is a standard natural number, we can assign to every limit finite set ")#mi("{A = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} A_\\alpha}")#text(" a ")#emph[#text("limit cardinality")]#text(" ")#tao-math("{\\left|A\\right| \\in {}^* {\\mathbb N}}", block: false)#text(" which is a limit natural number, by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left|\\lim_{\\alpha \\rightarrow \\alpha_\\infty} A_\\alpha\\right| := \\lim_{\\alpha \\rightarrow \\alpha_\\infty} \\left|A_\\alpha\\right|.", block: true)]]

#text("This limit cardinality inherits all of the first-order properties of ordinary cardinality. For instance, we have the inclusion-exclusion formula")

#align(center)[#tao-fit-display[#tao-math("\\left|A \\cup B\\right| + \\left|A \\cap B\\right| = \\left|A\\right| + \\left|B\\right|", block: true)]]

#text("for any two limit finite sets; this follows from the inclusion-exclusion formula for standard finite sets by an easy limiting argument.")

#text("It is not hard to show that ")#mi("{\\lim_{\\alpha \\rightarrow \\alpha_\\infty} A_\\alpha}")#text(" is finite if and only if the ")#tao-math("{\\left|A_\\alpha\\right|}", block: false)#text(" are bounded for ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text(". Thus, we see that one feature of passage to ultralimits is that it converts the term “bounded” to “finite”, while the term “finite” becomes “limit finite”. This makes ultralimit analysis useful for deducing facts about bounded quantities from facts about finite quantities. We give some examples of this in the next section.")

#text("In a similar vein, an ultralimit ")#mi("{(X,d) = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} (X_\\alpha,d_\\alpha)}")#text(" of standard metric spaces ")#mi("{(X_\\alpha,d_\\alpha)}")#text(" yields a ")#emph[#text("limit")]#text(" metric space, thus for instance ")#mi("{d: X \\times X \\rightarrow {}^* {\\mathbb R}}")#text(" is now a metric taking values in the ")#emph[#text("limit")]#text(" reals. Now, if the spaces ")#mi("{(X_\\alpha,d_\\alpha)}")#text(" were uniformly bounded, then the limit space ")#mi("{(X,d)}")#text(" would be bounded by some (standard) real diameter. From the ")#link("http://en.wikipedia.org/wiki/Bolzano%E2%80%93Weierstrass_theorem")[#text("Bolzano-Weierstrass theorem")]#text(" we see that every bounded limit real number ")#mi("{x}")#text(" has a unique ")#emph[#text("standard part")]#text(" ")#mi("{\\text{st}(x)}")#text(" which differs from ")#mi("{x}")#text(" by an ")#emph[#text("infinitesimal")]#text(", i.e. a limit real number of the form ")#mi("{\\lim_{\\alpha \\rightarrow \\alpha_\\infty} x_\\alpha}")#text(" where ")#mi("{x_\\alpha}")#text(" converges to zero in the classical sense. As a consequence, the standard part ")#mi("{\\text{st}(d)}")#text(" of the limit metric function ")#mi("{d: X \\times X \\rightarrow {}^* {\\mathbb R}}")#text(" is a genuine metric function ")#mi("{\\text{st}(d): X \\times X \\rightarrow {\\mathbb R}}")#text(". The resulting metric space ")#mi("{(X, \\text{st}(d))}")#text(" is often referred to as an ")#link("http://en.wikipedia.org/wiki/Ultralimit")[#text("ultralimit")]#text(" of the original metric spaces ")#mi("{(X_\\alpha,d_\\alpha)}")#text(", although strictly speaking this conflicts slightly with the notation here, because we consider ")#mi("{(X,d)}")#text(" to be the ultralimit instead.")

#heading(level: 1)[#strong[#text(" — 2. Application: quantitative algebraic geometry — ")]]

#text("As a sample application of the above machinery, we shall use ultrafilter analysis to quickly deduce some quantitative (but not explicitly effective) algebraic geometry results from their more well-known qualitative counterparts. Significantly stronger results than the ones given here can be provided by the field of ")#emph[#text("effective algebraic geometry")]#text(", but that theory is somewhat more complicated than the classical qualitative theory, and the point I want to stress here is that one can obtain a “cheap” version of this effective algebraic geometry from the qualitative theory by a straightforward ultrafilter argument. I do not know of a comparably easy way to get such ineffective quantitative results without the use of ultrafilters or closely related tools (e.g. nonstandard analysis or elementary limits).")

#text("We first recall a basic definition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Algebraic set)")]#text(" An (affine) ")#link("http://en.wikipedia.org/wiki/Algebraic_set")[#text("algebraic set")]#text(" over an algebraically closed field ")#mi("{k}")#text(" is a subset of ")#mi("{k^n}")#text(", where ")#mi("{n}")#text(" is a positive integer, of the form ")#metadata(none) <tao-96bcd55ca5483390fb09>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\{ x \\in k^n: P_1(x) = \\ldots = P_m(x) = 0 \\}")]]

#text("where ")#mi("{P_1,\\ldots,P_m: k^n \\rightarrow k}")#text(" are a finite collection of polynomials.")
]

#text("Now we turn to the quantitative theory, in which we try to control the ")#emph[#text("complexity")]#text(" of various objects. Let us say that an algebraic set in ")#mi("{k^n}")#text(" has ")#emph[#text("complexity at most")]#text(" ")#mi("{M}")#text(" if ")#mi("{n \\leq M}")#text(", and one can express the set in the form ")#link(<tao-96bcd55ca5483390fb09>)[#text("(1)")]#text(" where ")#mi("{m \\leq M}")#text(", and each of the polynomials ")#mi("{P_1,\\ldots,P_m}")#text(" has degree at most ")#mi("{M}")#text(". We can then ask the question of to what extent one can make the above qualitative algebraic statements quantitative. For instance, it is known that a dimension ")#mi("{0}")#text(" algebraic set is finite; but can we bound ")#emph[#text("how")]#text(" finite it is in terms of the complexity ")#mi("{M}")#text(" of that set? We are particularly interested in obtaining bounds here which are uniform in the underlying field ")#mi("{k}")#text(".")

#text("One way to do so is to open up an algebraic geometry textbook and carefully go through the ")#emph[#text("proofs")]#text(" of all the relevant qualitative facts, and carefully track the dependence on the complexity. For instance, one could bound the cardinality of a dimension ")#mi("{0}")#text(" algebraic set using ")#link("http://en.wikipedia.org/wiki/B%C3%A9zout%27s_theorem")[#text("Bézout’s theorem")]#text(". But here, we will use ultralimit analysis to obtain such quantitative analogues “for free” from their qualitative counterparts. The catch, though, is that the bounds we obtain are ")#emph[#text("ineffective")]#text("; they use the qualitative facts as a “black box”, and one would have to go through the proof of these facts in order to extract anything better.")

#text("To begin the application of ultrafilter analysis, we use the following simple lemma.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Ultralimits of bounded complexity algebraic sets are algebraic)")]#text(" ")#metadata(none) <tao-d1d331d578e5dae801ca>#text(" Let ")#mi("{n}")#text(" be a dimension. Suppose we have a sequence of algebraic sets ")#mi("{A_\\alpha \\subset k_\\alpha^n}")#text(" over algebraically closed fields ")#mi("{k_\\alpha}")#text(", whose complexity is bounded by a quantity ")#mi("{M}")#text(" which is uniform in ")#mi("{\\alpha}")#text(". Then if we set ")#mi("{k := \\lim_{\\alpha \\rightarrow \\alpha_\\infty} k_\\alpha}")#text(" and ")#mi("{A :=\\lim_{\\alpha \\rightarrow \\alpha_\\infty} A_\\alpha}")#text(", then ")#mi("{k}")#text(" is an algebraically closed field and ")#mi("{A \\subset k^n}")#text(" is an algebraic set (also of complexity at most ")#mi("{M}")#text(").")

#text("Conversely, every algebraic set in ")#mi("{k^n}")#text(" is the ultralimit of algebraic sets in ")#mi("{k_\\alpha^n}")#text(" of bounded complexity.")
]

#emph[#text("Proof:")]#text(" The fact that ")#mi("{k}")#text(" is algebraically closed comes from Exercise ")#link(<tao-15f19fd1977a6974efaf>)[#text("2")]#text(". Now we look at the algebraic sets ")#mi("{A_\\alpha}")#text(". By adding dummy polynomials if necessary, we can write")

#align(center)[#tao-fit-display[#mitex("A_\\alpha = \\{ x \\in k_\\alpha^n: P_{\\alpha,1}(x) = \\ldots = P_{\\alpha,M}(x) = 0 \\}")]]

#text("where the ")#mi("{P_{\\alpha,1},\\ldots,P_{\\alpha,M}: k_\\alpha^n \\rightarrow k_\\alpha}")#text(" of degree at most ")#mi("{M}")#text(".")

#text("We can then take ultralimits of the ")#mi("{P_{\\alpha,i}}")#text(" to create polynomials ")#mi("{P_{1},\\ldots,P_{M}: k^n \\rightarrow k}")#text(" of degree at most ")#mi("{M}")#text(". One easily verifies on taking ultralimits that")

#align(center)[#tao-fit-display[#mitex("A = \\{ x \\in k^n: P_{1}(x) = \\ldots = P_{M}(x) = 0 \\}")]]

#text("and the first claim follows. The converse claim is proven similarly. ")#mi("\\Box")

#text("Ultralimits preserve a number of key algebraic concepts (basically because such concepts are definable in first-order logic). We first illustrate this with the algebraic geometry concept of ")#emph[#text("dimension")]#text(". It is known that every non-empty algebraic set ")#mi("{V}")#text(" in ")#mi("{k^n}")#text(" has a ")#emph[#text("dimension")]#text(" ")#mi("{\\dim(V)}")#text(", which is an integer between ")#mi("{0}")#text(" and ")#mi("{n}")#text(", with the convention that the empty set has dimension ")#mi("{-1}")#text(". There are many ways to define this dimension, but one way is to proceed by induction on the dimension ")#mi("{n}")#text(" as follows. A non-empty algebraic subset of ")#mi("{k^0}")#text(" has dimension ")#mi("{0}")#text(". Now if ")#mi("{n \\geq 1}")#text(", we say that an algebraic set ")#mi("{V}")#text(" has dimension ")#mi("{d}")#text(" for some ")#mi("{0 \\leq d \\leq n}")#text(" if the following statements hold:")

#list(
[#text("For all but finitely many ")#mi("{t \\in k}")#text(", the slice ")#mi("{V_t := \\{ x \\in k^{n-1}: (x,t) \\in V \\}}")#text(" either all have dimension ")#mi("{d-1}")#text(", or are all empty.")],
[#text("For the remaining ")#mi("{t \\in k}")#text(", the slice ")#mi("{V_t}")#text(" has dimension at most ")#mi("{d}")#text(". If the generic slices ")#mi("{V_t}")#text(" were all empty, then one of the exceptional ")#mi("{V_t}")#text(" has to have dimension exactly ")#mi("{d}")#text(".")]
)

#text("Informally, ")#mi("{A}")#text(" has dimension ")#mi("{d}")#text(" iff a generic slice of ")#mi("{A}")#text(" has dimension ")#mi("{d-1}")#text(".")

#text("It is a non-trivial fact to show that every algebraic set in ")#mi("{k^n}")#text(" does indeed have a well-defined dimension between ")#mi("{-1}")#text(" and ")#mi("{n}")#text(".")

#text("Now we see how dimension behaves under ultralimits.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Continuity of dimension)")]#text(" ")#metadata(none) <tao-8a4f479c9bef058a0e39>#text(" Suppose that ")#mi("{A_\\alpha \\subset k_\\alpha^n}")#text(" are algebraic sets over various algebraically closed fields ")#mi("{k_\\alpha}")#text(" of uniformly bounded complexity, and let ")#mi("{A := \\lim_{\\alpha \\rightarrow \\alpha_\\infty} A_\\alpha}")#text(" be the limiting algebraic set given by Lemma ")#link(<tao-d1d331d578e5dae801ca>)[#text("2")]#text(". Then ")#mi("{\\dim(A) = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} \\dim(A_\\alpha)}")#text(". In other words, we have ")#mi("{\\dim(A) = \\dim(A_\\alpha)}")#text(" for all ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text(".")
]

#emph[#text("Proof:")]#text(" One could obtain this directly from ")#link("http://en.wikipedia.org/wiki/Los's_theorem#.C5.81o.C5.9B.27s_theorem")[#text("Los’s theorem")]#text(", but it is instructive to do this from first principles.")

#text("We induct on dimension ")#mi("{n}")#text(". The case ")#mi("{n=0}")#text(" is trivial, so suppose that ")#mi("{n \\geq 1}")#text(" and the claim has already been shown for ")#mi("{n-1}")#text(". Write ")#mi("{d}")#text(" for the dimension of ")#mi("{A}")#text(". If ")#mi("{d=-1}")#text(", then ")#mi("{A}")#text(" is empty and so ")#mi("{A_\\alpha}")#text(" must be empty for all ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text(", so suppose that ")#mi("{d \\geq 0}")#text(". By the construction of dimension, the slice ")#mi("{A_t}")#text(" all have dimension ")#mi("{d-1}")#text(" (or are all empty) for all but finitely many values ")#mi("{t_1,\\ldots,t_r}")#text(" of ")#mi("{t \\in k}")#text(". Let us assume that these generic slices ")#mi("{A_t}")#text(" all have dimension ")#mi("{d-1}")#text("; the other case is treated similarly and is left to the reader. As ")#mi("{k}")#text(" is the ultralimit of the ")#mi("{k_\\alpha}")#text(", we can write ")#mi("{t_i = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} t_{\\alpha,i}}")#text(" for each ")#mi("{1 \\leq i \\leq r}")#text(". We claim that for ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text(", the slices ")#mi("{(A_\\alpha)_{t_{\\alpha}}}")#text(" have dimension ")#mi("{d-1}")#text(" whenever ")#mi("{t_{\\alpha} \\neq t_{\\alpha,1},\\ldots,t_{\\alpha,r}}")#text(". Indeed, suppose that this were not the case. Carefully negating the quantifiers (and using the ultrafilter property), we see that for ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text(", we can find ")#mi("{t_{\\alpha} \\neq t_{\\alpha,1},\\ldots,t_{\\alpha,r}}")#text(" such that ")#mi("{(A_\\alpha)_{t_{\\alpha}}}")#text(" has dimension different from ")#mi("{d-1}")#text(". Taking ultralimits and writing ")#mi("{t := \\lim_{\\alpha \\rightarrow \\alpha_\\infty} t_\\alpha}")#text(", we see from the induction hypothesis that ")#mi("{A_t}")#text(" has dimension different from ")#mi("{d-1}")#text(", contradiction.")

#text("We have shown that for ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text(", all but finitely many slices of ")#mi("{A_\\alpha}")#text(" have dimension ")#mi("{d-1}")#text(", and thus by the definition of dimension, ")#mi("{A_\\alpha}")#text(" has dimension ")#mi("{d}")#text(", and the claim follows. ")#mi("\\Box")

#text("We can use this to deduce quantitative algebraic geometry results from qualitative analogues. For instance, from the definition of dimension we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Qualitative Bezout-type theorem)")]#text(" ")#metadata(none) <tao-1db592d795855682eba4>#text(" Every dimension ")#mi("{0}")#text(" algebraic variety is finite.")
]

#text("Using ultrafilter analysis, we immediately obtain the following quantitative analogue:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5 (Quantitative Bezout-type theorem)")]#text(" Let ")#mi("{A \\subset k^n}")#text(" be an algebraic set of dimension ")#mi("{0}")#text(" and complexity at most ")#mi("{M}")#text(" over a field ")#mi("{k}")#text(". Then the cardinality ")#mi("{A}")#text(" is bounded by a quantity ")#mi("{C_M}")#text(" depending only on ")#mi("{M}")#text(" (in particular, it is independent of ")#mi("{k}")#text(").")
]

#emph[#text("Proof:")]#text(" By passing to the algebraic closure, we may assume that ")#mi("{k}")#text(" is algebraically closed.")

#text("Suppose this were not the case. Carefully negating the quantifiers (and using the axiom of choice), we may find a sequence ")#mi("{A_\\alpha \\subset k_\\alpha^n}")#text(" of dimension ")#mi("{0}")#text(" algebraic sets and uniformly bounded complexity over algebraically closed fields ")#mi("{k_\\alpha}")#text(", such that ")#tao-math("{\\left|A_\\alpha\\right| \\rightarrow \\infty}", block: false)#text(" as ")#mi("{\\alpha \\rightarrow \\infty}")#text(". We pass to an ultralimit to obtain a limit algebraic set ")#mi("{A := \\lim_{\\alpha \\rightarrow \\alpha_\\infty} A_\\alpha}")#text(", which by Lemma ")#link(<tao-8a4f479c9bef058a0e39>)[#text("3")]#text(" has dimension ")#mi("{0}")#text(", and is thus finite by Lemma ")#link(<tao-1db592d795855682eba4>)[#text("4")]#text(". But then this forces ")#mi("{A_\\alpha}")#text(" to be bounded for ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text(" (indeed we have ")#tao-math("{\\left|A_\\alpha\\right| = \\left|A\\right|}", block: false)#text(" in such a neighbourhood), contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" Note that this proof gives absolutely no bound on ")#mi("{C_M}")#text(" in terms of ")#mi("{M}")#text("! One can get such a bound by using more effective tools, such as the actual Bezout theorem, but this requires more actual knowledge of how the qualitative algebraic results are proved. If one only knows the qualitative results as a black box, then the ineffective quantitative result is the best one can do.")
]

#text("Now we give another illustration of the method. The following fundamental result in algebraic geometry is known:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (Qualitative Noetherian condition)")]#text(" ")#metadata(none) <tao-719b4802f549f1ceca27>#text(" There does not exist an infinite decreasing sequence of algebraic sets in a affine space ")#mi("{k^n}")#text(", in which each set is a proper subset of the previous one.")
]

#text("Using ultralimit analysis, one can convert this qualitative result into an ostensibly stronger quantitative version:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7 (Quantitative Noetherian condition)")]#text(" ")#metadata(none) <tao-545350c7b143576d012a>#text(" Let ")#mi("{F: {\\mathbb N} \\rightarrow {\\mathbb N}}")#text(" be a function. Let ")#mi("{A_1 \\supsetneq A_2 \\supsetneq \\ldots \\supsetneq A_R}")#text(" be a sequence of properly nested algebraic sets in ")#mi("{k^n}")#text(" for some algebraically closed field ")#mi("{k}")#text(", such that each ")#mi("{A_i}")#text(" has complexity at most ")#mi("{F(i)}")#text(". Then ")#mi("{R}")#text(" is bounded by ")#mi("{C_F}")#text(" for some ")#mi("{C_F}")#text(" depending only on ")#mi("{F}")#text(" (in particular, it is independent of ")#mi("{k}")#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" Specialising to the case when ")#mi("{F}")#text(" is a constant ")#mi("{M}")#text(", we see that there is an upper bound on proper nested sequences of algebraic sets of bounded complexity; but the statement is more powerful than this because we allow ")#mi("{F}")#text(" to be non-constant. Note that one can easily use this strong form of the quantitative Noetherian condition to recover Lemma ")#link(<tao-719b4802f549f1ceca27>)[#text("6")]#text(" (why?), but if one only knew Lemma ")#link(<tao-545350c7b143576d012a>)[#text("7")]#text(" in the constant case ")#mi("{F=M}")#text(" then this does not obviously recover Lemma ")#link(<tao-719b4802f549f1ceca27>)[#text("6")]#text(".")
]

#emph[#text("Proof:")]#text(" Note that ")#mi("{n}")#text(" is bounded by ")#mi("{F(1)}")#text(", so it will suffice to prove this claim for a fixed ")#mi("{n}")#text(".")

#text("Fix ")#mi("{n}")#text(". Suppose the claim failed. Carefully negating all the quantifiers (and using the axiom of choice), we see that there exists an ")#mi("{F}")#text(", a sequence ")#mi("{k_\\alpha}")#text(" of algebraically closed fields, a sequence ")#mi("{R_\\alpha}")#text(" going to infinity, and sequences")

#align(center)[#tao-fit-display[#mitex("A_{\\alpha,1} \\supsetneq \\ldots \\supsetneq A_{\\alpha,R_\\alpha}")]]

#text("of properly nested algebraic sets in ")#mi("{k_\\alpha^n}")#text(", with each ")#mi("{A_{\\alpha,i}}")#text(" having complexity at most ")#mi("{F(i)}")#text(".")

#text("We take an ultralimit of everything that depends on ")#mi("{\\alpha}")#text(", creating an algebraically closed field ")#mi("{k = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} k_\\alpha}")#text(", and an infinite sequence")

#align(center)[#tao-fit-display[#mitex("A_1 \\supsetneq A_2 \\supsetneq \\ldots")]]

#text("of properly nested algebraic sets in ")#mi("{k^n}")#text(". (In fact, we could continue this sequence into a limit sequence up to the unbounded limit number ")#mi("{\\lim_{\\alpha \\rightarrow \\alpha_\\infty} R_\\alpha}")#text(", but we will not need this ")#link("http://en.wikipedia.org/wiki/Overspill")[#text("overspill")]#text(" here.) But this contradicts Lemma ")#link(<tao-719b4802f549f1ceca27>)[#text("6")]#text(". ")#mi("\\Box")

#text("Again, this argument gives absolutely no clue as to how ")#mi("{C_F}")#text(" is going to depend on ")#mi("{F}")#text(". (Indeed, I would be curious to know what this dependence is exactly.)")

#text("Let us give one last illustration of the ultralimit analysis method, which contains an additional subtlety. Define an ")#emph[#text("algebraic variety")]#text(" to be an algebraic set which is ")#emph[#text("irreducible")]#text(", which means that it cannot be expressed as the union of two proper subalgebraic sets. This notation is stable under ultralimits:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8 (Continuity of irreducibility)")]#text(" ")#metadata(none) <tao-c1dee73a87788070bd26>#text(" Suppose that ")#mi("{A_\\alpha \\subset k_\\alpha^n}")#text(" are algebraic sets over various algebraically closed fields ")#mi("{k_\\alpha}")#text(" of uniformly bounded complexity, and let ")#mi("{A := \\lim_{\\alpha \\rightarrow \\alpha_\\infty} A_\\alpha}")#text(" be the limiting algebraic set given by Lemma ")#link(<tao-d1d331d578e5dae801ca>)[#text("2")]#text(". Then ")#mi("{A}")#text(" is an algebraic variety if and only if ")#mi("{A_\\alpha}")#text(" is an algebraic variety for all ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text(".")
]

#text("However, this lemma is somewhat harder to prove than previous ones, because the notion of irreducibility is not quite a first order statement. The following exercises show the limit of what one can do without using some serious algebraic geometry:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" ")#metadata(none) <tao-df660c39d42d1f106706>#text(" Let the notation and assumptions be as in Lemma ")#link(<tao-c1dee73a87788070bd26>)[#text("8")]#text(". Show that if ")#mi("{A}")#text(" is ")#emph[#text("not")]#text(" an algebraic variety, then ")#mi("{A_\\alpha}")#text(" is a not algebraic variety for all ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" ")#metadata(none) <tao-f9e22e9585100e065f4f>#text(" Let the notation and assumptions be as in Lemma ")#link(<tao-c1dee73a87788070bd26>)[#text("8")]#text(". Call an algebraic set ")#emph[#mi("{M}")#text("-irreducible")]#text(" if it cannot be expressed as the union of two proper algebraic sets of complexity at most ")#mi("{M}")#text(". Show that if ")#mi("{A}")#text(" ")#emph[#text("is")]#text(" an algebraic variety, then for every ")#mi("{M \\geq 1}")#text(", ")#mi("{A_\\alpha}")#text(" is ")#mi("{M}")#text("-irreducible for all ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text(".")
]

#text("These exercises are not quite strong enough to give Lemma ")#link(<tao-c1dee73a87788070bd26>)[#text("8")]#text(", because ")#mi("{M}")#text("-irreducibility is a weaker concept than irreducibility. However, one can do better by applying some further facts in algebraic geometry. Given an algebraic set ")#mi("{A}")#text(" of dimension ")#mi("{d \\geq 0}")#text(" in an affine space ")#mi("{k^n}")#text(", one can assign a ")#emph[#text("degree")]#text(" ")#mi("{\\deg(A)}")#text(", which is a positive integer such that ")#tao-math("{\\left|A \\cap V\\right| = \\deg(A)}", block: false)#text(" for ")#emph[#text("generic")]#text(" ")#mi("{n-d}")#text("-dimensional affine subspaces of ")#mi("{k^n}")#text(", which means that ")#mi("{V}")#text(" belongs to the ")#emph[#text("affine Grassmannian")]#text(" ")#mi("{Gr}")#text(" of ")#mi("{n-d}")#text("-dimensional affine subspaces of ")#mi("{k^n}")#text(", after removing an algebraic subset of ")#mi("{Gr}")#text(" of dimension strictly less than that of ")#mi("{Gr}")#text(". It is a standard fact of algebraic geometry that every algebraic set can be assigned a degree. Somewhat less trivially, the degree controls the complexity:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9 (Degree controls complexity)")]#text(" ")#metadata(none) <tao-99da742cd4690153fa90>#text(" Let ")#mi("{A}")#text(" be an algebraic variety of ")#mi("{k^n}")#text(" of degree ")#mi("{D}")#text(". Then ")#mi("{A}")#text(" has complexity at most ")#mi("{C_{n,D}}")#text(" for some constants ")#mi("{n, D}")#text(" depending only on ")#mi("{n, D}")#text(".")
]

#emph[#text("Proof:")]#text(" (We thank Jordan Ellenberg and Ania Otwinowska for this argument.) It suffices to show that ")#mi("{A}")#text(" can be cut out by polynomials of degree ")#mi("{D}")#text(", since the space of polynomials of degree ")#mi("{D}")#text(" that vanish on ")#mi("{A}")#text(" is a vector space of dimension bounded only by ")#mi("{n}")#text(" and ")#mi("{D}")#text(".")

#text("Let ")#mi("{A}")#text(" have dimension ")#mi("{d}")#text(". We pick a generic affine subspace ")#mi("{V}")#text(" of ")#mi("{k^n}")#text(" of dimension ")#mi("{n-d-2}")#text(", and consider the cone ")#mi("{C(V,A)}")#text(" formed by taking all the union of all the lines joining a point in ")#mi("{V}")#text(" to a point in ")#mi("{A}")#text(". This is an algebraic image of ")#mi("{V \\times A \\times {\\mathbb R}}")#text(" and is thus generically an algebraic set of dimension ")#mi("{n-1}")#text(", i.e. a hypersurface. Furthermore, as ")#mi("{A}")#text(" has degree ")#mi("{D}")#text(", it is not hard to see that ")#mi("{C(V,A)}")#text(" has degree ")#mi("{D}")#text(" as well. Since a hypersurface is necessarily cut out by a single polynomial, this polynomial must have degree ")#mi("{D}")#text(".")

#text("To finish the claim, it suffices to show that the intersection of the ")#mi("{C(V,A)}")#text(" as ")#mi("{V}")#text(" varies is exactly ")#mi("{A}")#text(". Clearly, this intersection contains ")#mi("{A}")#text(". Now let ")#mi("{p}")#text(" be any point not in ")#mi("{A}")#text(". The cone of ")#mi("{A}")#text(" over ")#mi("{p}")#text(" can be viewed as an algebraic subset of the projective space ")#mi("{P^{n-1}}")#text(" of dimension ")#mi("{d}")#text("; meanwhile, the cone of a generic subspace ")#mi("{V}")#text(" of dimension ")#mi("{n-d-2}")#text(" is a generic subspace of ")#mi("{P^{n-1}}")#text(" of the same dimension. Thus, for generic ")#mi("{V}")#text(", these two cones do not intersect, and thus ")#mi("{p}")#text(" lies outside ")#mi("{C(V,A)}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" There is a stronger theorem that asserts that if the degree of a ")#emph[#text("scheme")]#text(" in ")#mi("{k^n}")#text(" is bounded, then the complexity of that scheme is bounded as well. The main difference between a variety and a scheme here is that for a scheme, we not only specify the set of points cut out by the scheme, but also the ideal of functions that we want to think of as vanishing on that set. This theorem is significantly more difficult than the above result; it is ")#link("http://www.msri.org/publications/books/sga/sga/6/6t_659.html")[#text("Corollary 6.11")]#text(" of Kleiman’s SGA6 article.")
]

#text("Given this theorem, we can now prove Lemma ")#link(<tao-c1dee73a87788070bd26>)[#text("8")]#text(".")

#emph[#text("Proof:")]#text(" In view of Exercise ")#link(<tao-df660c39d42d1f106706>)[#text("3")]#text(", it suffices to show that if ")#mi("{A}")#text(" is irreducible, then the ")#mi("{A_\\alpha}")#text(" are irreducible for ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_0}")#text(".")

#text("The algebraic set ")#mi("{A}")#text(" has some dimension ")#mi("{d}")#text(" and degree ")#mi("{D}")#text(", thus ")#tao-math("{\\left|A \\cap V\\right| = D}", block: false)#text(" for generic affine ")#mi("{n-d}")#text("-dimensional subspaces ")#mi("{V}")#text(" of ")#mi("{k^n}")#text(". Undoing the limit using Lemma ")#link(<tao-d1d331d578e5dae801ca>)[#text("2")]#text(" and Lemma ")#link(<tao-8a4f479c9bef058a0e39>)[#text("3")]#text(" (adapted to the Grassmannian ")#mi("{Gr}")#text(" rather than to affine space), we see that for ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_0}")#text(", ")#tao-math("{\\left|A_\\alpha \\cap V_\\alpha\\right| = D}", block: false)#text(" for generic affine ")#mi("{n-d}")#text("-dimensional subspaces ")#mi("{V_\\alpha}")#text(" of ")#mi("{k_\\alpha^n}")#text(". In other words, ")#mi("{A_\\alpha}")#text(" has degree ")#mi("{D}")#text(", and thus by Theorem ")#link(<tao-99da742cd4690153fa90>)[#text("9")]#text(", any algebraic variety of ")#mi("{A_\\alpha}")#text(" of the same dimension ")#mi("{d}")#text(" as ")#mi("{A_\\alpha}")#text(" will have complexity bounded by ")#mi("{C_{n,D}}")#text(" uniformly in ")#mi("{\\alpha}")#text(". Let ")#mi("{B_\\alpha}")#text(" be a ")#mi("{d}")#text("-dimensional algebraic subvariety of ")#mi("{A_\\alpha}")#text(", and let ")#mi("{B}")#text(" be the ultralimit of the ")#mi("{B_\\alpha}")#text(". Then by Lemma ")#link(<tao-d1d331d578e5dae801ca>)[#text("2")]#text(", Lemma ")#link(<tao-8a4f479c9bef058a0e39>)[#text("3")]#text(" and the uniform complexity bound, ")#mi("{B}")#text(" is a ")#mi("{d}")#text("-dimensional algebraic subset of ")#mi("{A}")#text(", and thus must equal all of ")#mi("{A}")#text(" by irreducibility of ")#mi("{A}")#text(". But this implies that ")#mi("{B_\\alpha=A_\\alpha}")#text(" for all ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_0}")#text(", and the claim follows. ")#mi("\\Box")

#text("We give a sample application of this result. From the Noetherian condition we easily obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10 (Qualitative decomposition into varieties)")]#text(" Every algebraic set can be expressed as a union of finitely many algebraic varieties.")
]

#text("Using ultralimit analysis, we can make this quantitative:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11 (Quantitative decomposition into varieties)")]#text(" Let ")#mi("{A \\subset k^n}")#text(" be an algebraic set of complexity at most ")#mi("{M}")#text(" over an algebraically closed field ")#mi("{k}")#text(". Then ")#mi("{A}")#text(" can be expressed as the union of at most ")#mi("{C_M}")#text(" algebraic varieties of complexity at most ")#mi("{C_M}")#text(", where ")#mi("{C_M}")#text(" depends only on ")#mi("{M}")#text(".")
]

#emph[#text("Proof:")]#text(" As ")#mi("{n}")#text(" is bounded by ")#mi("{M}")#text(", it suffices to prove the claim for a fixed ")#mi("{n}")#text(".")

#text("Fix ")#mi("{n}")#text(" and ")#mi("{M}")#text(". Suppose the claim failed. Carefully negating all the quantifiers (and using the axiom of choice), we see that there exists a sequence ")#mi("{A_\\alpha\\subset k_\\alpha^n}")#text(" of uniformly bounded complexity, such that ")#mi("{A_\\alpha}")#text(" cannot be expressed as the union of at most ")#mi("{\\alpha}")#text(" algebraic varieties of complexity at most ")#mi("{\\alpha}")#text(". Now we pass to an ultralimit, obtaining a limit algebraic set ")#mi("{A \\subset k^n}")#text(". As discussed earlier, ")#mi("{A}")#text(" is an algebraic set over an algebraically closed field and is thus expressible as the union of a finite number of algebraic varieties ")#mi("{A_1,\\ldots,A_m}")#text(". By Lemma ")#link(<tao-d1d331d578e5dae801ca>)[#text("2")]#text(" and Lemma ")#link(<tao-c1dee73a87788070bd26>)[#text("8")]#text(", each ")#mi("{A_i}")#text(" is an ultralimit of algebraic varieties ")#mi("{A_{\\alpha,i}}")#text(" of bounded complexity. The claim follows. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 3. Application: Quantitative Gromov theorem — ")]]

#text("As a further illustration, I’ll redo an application of the correspondence principle from a ")#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")[#text("previous post of mine")]#text(". The starting point is the following famous ")#link("http://en.wikipedia.org/wiki/Gromov%27s_theorem_on_groups_of_polynomial_growth")[#text("theorem of Gromov")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 12 (Qualitative Gromov theorem)")]#text(" ")#metadata(none) <tao-8a5c6e9d071ebbf687f2>#text(" Every finitely generated group of polynomial growth is virtually nilpotent.")
]

#text("Let us now make the observation (already observed in Gromov’s original paper) that this theorem implies (and is in fact equivalent to) a quantitative version:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 13 (Quantitative Gromov theorem)")]#text(" ")#metadata(none) <tao-d9befec7779a2e9b797e>#text(" For every ")#mi("{C, d}")#text(" there exists ")#mi("{R}")#text(" such that if ")#mi("{G}")#text(" is generated by a finite set ")#mi("{S}")#text(" with the growth condition ")#tao-math("{\\left|B_S(r)\\right| \\leq Cr^d}", block: false)#text(" for all ")#mi("{1 \\leq r \\leq R}")#text(", then ")#mi("{G}")#text(" is virtually nilpotent, and furthermore it has a nilpotent subgroup of step and index at most ")#mi("{M_{C,d}}")#text(" for some ")#mi("{M_{C,d}}")#text(" depending only on ")#mi("{C,d}")#text(". Here ")#mi("{B_S(r)}")#text(" is the ball of radius ")#mi("{r}")#text(" generated by the set ")#mi("{S}")#text(".")
]

#emph[#text("Proof:")]#text(" We use ultralimit analysis. Suppose this theorem failed. Carefully negating the quantifiers, we find that there exists ")#mi("{C, d}")#text(", as well as a sequence ")#mi("{G_\\alpha}")#text(" of groups generated by a finite set ")#mi("{S_\\alpha}")#text(" such that ")#tao-math("{\\left|B_{S_\\alpha}(r)\\right| \\leq C r^d}", block: false)#text(" for all ")#mi("{1 \\leq r \\leq \\alpha}")#text(", and such that ")#mi("{G_\\alpha}")#text(" does not contain any nilpotent subgroup of step and index at most ")#mi("{\\alpha}")#text(".")

#text("Now we take ultralimits, setting ")#mi("{G := \\lim_{\\alpha \\rightarrow \\alpha_\\infty} G_\\alpha}")#text(" and ")#mi("{S := \\lim_{\\alpha \\rightarrow \\alpha_\\infty} S_\\alpha}")#text(". As the ")#mi("{S_\\alpha}")#text(" have cardinality uniformly bounded (by ")#mi("{Cr^1}")#text("), ")#mi("{S}")#text(" is finite. The set ")#mi("{S}")#text(" need not generate ")#mi("{G}")#text(", but it certainly generates some subgroup ")#mi("{\\langle S \\rangle}")#text(" of this group. Since ")#tao-math("{\\left|B_{S_\\alpha}(r)\\right| \\leq C r^d}", block: false)#text(" for all ")#mi("{\\alpha}")#text(" and all ")#mi("{1 \\leq r \\leq \\alpha}")#text(", we see on taking ultralimits that ")#tao-math("{\\left|B_S(r)\\right| \\leq Cr^d}", block: false)#text(" for all ")#mi("{r}")#text(". Thus ")#mi("{\\langle S \\rangle}")#text(" is of polynomial growth, and is thus virtually nilpotent.")

#text("Now we need to undo the ultralimit, but this requires a certain amount of preparation. We know that ")#mi("{\\langle S \\rangle}")#text(" contains a finite index nilpotent subgroup ")#mi("{G^{\\prime}}")#text(". As ")#mi("{\\langle S \\rangle}")#text(" is finitely generated, the finite index subgroup ")#mi("{G^{\\prime}}")#text(" is also. (Proof: for ")#mi("{R}")#text(" large enough, ")#mi("{B_S(R)}")#text(" will intersect every coset of ")#mi("{G^{\\prime}}")#text(". As a consequence, one can describe the action of ")#mi("{\\langle S\\rangle}")#text(" on the finite set ")#mi("{\\langle S \\rangle/G^{\\prime}}")#text(" using only knowledge of ")#mi("{B_S(2R+1) \\cap G^{\\prime}}")#text(". In particular, ")#mi("{B_S(2R+1) \\cap G^{\\prime}}")#text(" generates a finite index subgroup. Increasing ")#mi("{R}")#text(", the index of this subgroup is non-increasing, and thus must eventually stabilise. At that point, we generate all of ")#mi("{G^{\\prime}}")#text(".) Let ")#mi("{S^{\\prime}}")#text(" be a set of generators for ")#mi("{G^{\\prime}}")#text(". Since ")#mi("{G^{\\prime}}")#text(" is nilpotent of some step ")#mi("{s}")#text(", all commutators of ")#mi("{S^{\\prime}}")#text(" of length at least ")#mi("{s+1}")#text(" vanish.")

#text("Writing ")#mi("{S^{\\prime}}")#text(" as an ultralimit of ")#mi("{S^{\\prime}_\\alpha}")#text(", we see that the ")#mi("{S^{\\prime}_\\alpha}")#text(" are finite subsets of ")#mi("{G_\\alpha}")#text(" which generate some subgroup ")#mi("{G^{\\prime}_\\alpha}")#text(". Since all commutators of ")#mi("{S^{\\prime}}")#text(" of length at least ")#mi("{s+1}")#text(" vanish, the same is true for ")#mi("{S^{\\prime}_\\alpha}")#text(" for ")#mi("{\\alpha}")#text(" close enough to ")#mi("{\\alpha_\\infty}")#text(", and so ")#mi("{G^{\\prime}_\\alpha}")#text(" is nilpotent for such ")#mi("{\\alpha}")#text(" with step bounded uniformly in ")#mi("{\\alpha}")#text(".")

#text("Finally, if we let ")#mi("{R}")#text(" be large enough that ")#mi("{B_S(R)}")#text(" intersects every coset of ")#mi("{G^{\\prime}}")#text(", then we can cover ")#mi("{B_S(R+1)}")#text(" by a product of ")#mi("{B_S(R)}")#text(" and some elements of ")#mi("{G^{\\prime}}")#text(" (which are of course finite products of elements in ")#mi("{S^{\\prime}}")#text(" and their inverses). Undoing the ultralimit, we see that for ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text(", we can cover ")#mi("{B_{S_\\alpha}(R+1)}")#text(" by the product of ")#mi("{B_{S_\\alpha}(R)}")#text(" and some elements of ")#mi("{G^{\\prime}_\\alpha}")#text(". Iterating this we see that we can cover all of ")#mi("{G_\\alpha}")#text(" by ")#mi("{B_{S_\\alpha}(R)}")#text(" times ")#mi("{G^{\\prime}_\\alpha}")#text(", and so ")#mi("{G^{\\prime}_\\alpha}")#text(" has finite index bounded uniformly in ")#mi("{\\alpha}")#text(". But this contradicts the construction of ")#mi("{G_\\alpha}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" As usual, the argument gives no effective bound on ")#mi("{M_{C,d}}")#text(". Obtaining such an effective bound is in fact rather non-trivial; see ")#link("https://terrytao.wordpress.com/2009/10/23/a-finitary-version-of-gromovs-polynomial-growth-theorem/")[#text("this paper of Yehuda Shalom and myself")]#text(" for further discussion.")
]

#heading(level: 1)[#strong[#text(" — 4. Application: Furstenberg correspondence principle — ")]]

#text("Let me now redo another application of the correspondence principle via ultralimit analysis. We will begin with the following ")#link("http://www.ams.org/mathscinet-getitem?mr=498471")[#text("famous result of Furstenberg")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 14 (Furstenberg recurrence theorem)")]#text(" ")#metadata(none) <tao-411195755a2354f96708>#text(" Let ")#mi("{(X, {\\mathcal B}, \\mu, T)}")#text(" be a measure-preserving system, and let ")#mi("{A \\subset X}")#text(" have positive measure. Let ")#mi("{k \\geq 1}")#text(". Then there exists ")#mi("{r > 0}")#text(" such that ")#mi("{A \\cap T^r A \\cap \\ldots \\cap T^{(k-1)r} A}")#text(" is non-empty.")
]

#text("We then use this theorem and ultralimit analysis to derive the following well-known ")#link("http://www.scholarpedia.org/article/Szemer%C3%A9di's_Theorem")[#text("result of Szemerédi")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 15 (Szemerédi’s theorem)")]#text(" Every set of integers of positive upper density contains arbitrarily long arithmetic progressions.")
]

#emph[#text("Proof:")]#text(" Suppose this were not the case. Then there exists ")#mi("{k \\geq 1}")#text(" and a set ")#mi("{A}")#text(" of positive upper density with no progressions of length ")#mi("{k}")#text(". Unpacking the definition of positive upper density, this means that there exists ")#mi("{\\delta > 0}")#text(" and a sequence ")#mi("{N_\\alpha \\rightarrow \\infty}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|A \\cap [-N_\\alpha, N_\\alpha]\\right| \\geq \\delta \\left|[-N_\\alpha, N_\\alpha]\\right|", block: true)]]

#text("for all ")#mi("{\\alpha}")#text(". We pass to an ultralimit, introducing the limit natural number ")#mi("{N := \\lim_{\\alpha \\rightarrow \\alpha_\\infty} N_\\alpha}")#text(" and using the ultrapower ")#mi("{{}^* A =\\lim_{\\alpha \\rightarrow \\alpha_\\infty} A}")#text(" (note that ")#mi("{A}")#text(" is a space, not an ordinary object). Then we have")

#align(center)[#tao-fit-display[#tao-math("\\left|{}^*A \\cap [-N, N]\\right| \\geq \\delta \\left|[-N, N]\\right|", block: true)]]

#text("where the cardinalities are in the limit sense. Note also that ")#mi("{{}^*A}")#text(" has no progressins of length ")#mi("{k}")#text(".")

#text("Consider the space of all boolean combinations of shifts ")#mi("{{}^* A + r}")#text(" of ")#mi("{{}^* A}")#text(", where ")#mi("{r}")#text(" ranges over (standard) integers, thus for instance")

#align(center)[#tao-fit-display[#mitex("({}^* A + 3) \\cap ({}^* A + 5) \\backslash ({}^* A - 7)")]]

#text("would be such a set. We call such sets ")#emph[#text("definable sets")]#text(". We give each such definable set ")#mi("{B}")#text(" a limit measure")

#align(center)[#tao-fit-display[#tao-math("\\mu(B) := \\left|B \\cap [-N,N]\\right| / [-N,N].", block: true)]]

#text("This measure takes values in the limit interval ")#mi("{{}^*[0,1]}")#text(" and is clearly a finitely additive probability measure. It is also nearly translation invariant in the sense that")

#align(center)[#tao-fit-display[#mitex("\\mu(B+k) = \\mu(B) + o(1)")]]

#text("for any standard integer ")#mi("{k}")#text(", where ")#mi("{o(1)}")#text(" is an ")#emph[#text("infinitesimal")]#text(" (i.e. a limit real number which is smaller in magnitude than any positive standard real number). In particular, the standard part ")#mi("{st(\\mu)}")#text(" of ")#mi("{\\mu}")#text(" is a finitely additive ")#emph[#text("standard")]#text(" probability measure. Note from construction that ")#mi("{st(\\mu)(A) \\geq \\delta}")#text(".")

#text("Now we convert this finitely additive measure into a countably additive one. Let ")#mi("{2^{\\mathbb Z}}")#text(" be the set of all subsets ")#mi("{B}")#text(" of the integers. This is a compact metrisable space, which we endow with the Borel ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}}")#text(" and the standard shift ")#mi("{T: B \\mapsto B+1}")#text(". The Borel ")#mi("{\\sigma}")#text("-algebra is generated by the clopen sets in this space, which are boolean combinations of ")#mi("{T^r E}")#text(", where ")#mi("{E}")#text(" is the basic ")#link("http://en.wikipedia.org/wiki/Cylinder_set")[#text("cylinder set")]#text(" ")#mi("{E := \\{ B \\in 2^{\\mathbb Z}: 0 \\in B \\}}")#text(". Each clopen set can be assigned a definable set in ")#mi("{{}^* {\\mathbb Z}}")#text(" by mapping ")#mi("{T^r E}")#text(" to ")#mi("{{}^* A + r}")#text(" and then extending by boolean combinations. The finitely additive probability measure ")#mi("{st(\\mu)}")#text(" on definable sets then pulls back to a finitely additive probability measure ")#mi("{\\nu}")#text(" on clopen sets in ")#mi("{2^{\\mathbb Z}}")#text(". Applying the ")#link("http://en.wikipedia.org/wiki/Carath%C3%A9odory%27s_extension_theorem")[#text("Carathéodory extension theorem")]#text(" (taking advantage of the compactness of ")#mi("{2^{\\mathbb Z}}")#text("), we can extend this finitely additive measure to a countably additive Borel probability measure.")

#text("By construction, ")#mi("{\\nu(E) \\geq \\delta > 0}")#text(". Applying Theorem ")#link(<tao-411195755a2354f96708>)[#text("14")]#text(", we can find ")#mi("{r > 0}")#text(" such that ")#mi("{E \\cap T^r E \\cap \\ldots \\cap T^{(k-1)r} E}")#text(" is non-empty. This implies that ")#mi("{{}^* A \\cap ({}^* A + r) \\cap \\ldots \\cap ({}^* A + (k-1)r)}")#text(" is non-empty, and so ")#mi("{{}^* A}")#text(" contains an arithmetic progression of length ")#mi("{k}")#text(", a contradiction. ")#mi("\\Box")

#text("Note that the above argument is nearly identical to the usual proof of the correspondence principle, which uses ")#link("http://en.wikipedia.org/wiki/Prokhorov's_theorem")[#text("Prokhorov’s theorem")]#text(" instead of ultrafilters. The measure constructed above is essentially the ")#emph[#text("Loeb measure")]#text(" for the ultraproduct.")

#heading(level: 1)[#strong[#text(" — 5. Relationship with nonstandard analysis — ")]]

#text("Ultralimit analysis is extremely close to, but subtly different from, nonstandard analysis, because of a shift of emphasis and philosophy. The relationship can be illustrated by the following table of analogies:")

#table(columns: 3, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Digits")],
table.cell(colspan: 1, rowspan: 1)[#text("Strings of digits")],
table.cell(colspan: 1, rowspan: 1)[#text("Numbers")],
table.cell(colspan: 1, rowspan: 1)[#text("Symbols")],
table.cell(colspan: 1, rowspan: 1)[#text("Strings of symbols")],
table.cell(colspan: 1, rowspan: 1)[#text("Sentences")],
table.cell(colspan: 1, rowspan: 1)[#text("Set theory")],
table.cell(colspan: 1, rowspan: 1)[#text("Finite von Neumann ordinals")],
table.cell(colspan: 1, rowspan: 1)[#text("Peano arithmetic")],
table.cell(colspan: 1, rowspan: 1)[#text("Rational numbers ")#mi("{{\\mathbb Q}}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\overline{{\\mathbb Q}}}")],
table.cell(colspan: 1, rowspan: 1)[#text("Real numbers ")#mi("{{\\mathbb R}}")],
table.cell(colspan: 1, rowspan: 1)[#text("Real analysis")],
table.cell(colspan: 1, rowspan: 1)[#text("Analysis on ")#mi("{\\overline{{\\mathbb R}}}")],
table.cell(colspan: 1, rowspan: 1)[#text("Complex analysis")],
table.cell(colspan: 1, rowspan: 1)[#mi("{{\\mathbb R}}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{{\\mathbb R}^2}")],
table.cell(colspan: 1, rowspan: 1)[#text("Euclidean plane geometry")],
table.cell(colspan: 1, rowspan: 1)[#mi("{{\\mathbb R}}")],
table.cell(colspan: 1, rowspan: 1)[#text("Coordinate chart atlases")],
table.cell(colspan: 1, rowspan: 1)[#text("Manifolds")],
table.cell(colspan: 1, rowspan: 1)[#mi("{{\\mathbb R}}")],
table.cell(colspan: 1, rowspan: 1)[#text("Matrices")],
table.cell(colspan: 1, rowspan: 1)[#text("Linear transformations")],
table.cell(colspan: 1, rowspan: 1)[#text("Algebra")],
table.cell(colspan: 1, rowspan: 1)[#text("Sheaves of rings")],
table.cell(colspan: 1, rowspan: 1)[#text("Schemes")],
table.cell(colspan: 1, rowspan: 1)[#text("Deterministic theory")],
table.cell(colspan: 1, rowspan: 1)[#text("Measure theory")],
table.cell(colspan: 1, rowspan: 1)[#text("Probability theory")],
table.cell(colspan: 1, rowspan: 1)[#text("Probability theory")],
table.cell(colspan: 1, rowspan: 1)[#text("Von Neumann algebras")],
table.cell(colspan: 1, rowspan: 1)[#text("Noncommutative probability theory")],
table.cell(colspan: 1, rowspan: 1)[#text("Classical mechanics")],
table.cell(colspan: 1, rowspan: 1)[#text("Hilbert space mechanics")],
table.cell(colspan: 1, rowspan: 1)[#text("Quantum mechanics")],
table.cell(colspan: 1, rowspan: 1)[#text("Finitary analysis")],
table.cell(colspan: 1, rowspan: 1)[#text("Asymptotic analysis")],
table.cell(colspan: 1, rowspan: 1)[#text("Infinitary analysis")],
table.cell(colspan: 1, rowspan: 1)[#text("Combinatorics")],
table.cell(colspan: 1, rowspan: 1)[#text("Correspondence principle")],
table.cell(colspan: 1, rowspan: 1)[#text("Ergodic theory")],
table.cell(colspan: 1, rowspan: 1)[#text("Quantitative analysis")],
table.cell(colspan: 1, rowspan: 1)[#text("Compactness arguments")],
table.cell(colspan: 1, rowspan: 1)[#text("Qualitative analysis")],
table.cell(colspan: 1, rowspan: 1)[#text("Standard analysis")],
table.cell(colspan: 1, rowspan: 1)[#text("Ultralimit analysis")],
table.cell(colspan: 1, rowspan: 1)[#text("Nonstandard analysis")],
table.cell(colspan: 1, rowspan: 1)[],
table.cell(colspan: 1, rowspan: 1)[],
table.cell(colspan: 1, rowspan: 1)[]
)

#text("(Here ")#mi("{\\overline{{\\mathbb R}}}")#text(" is the algebraic completion of the reals, but ")#mi("{\\overline{{\\mathbb Q}}}")#text(" is the metric completion of the rationals.)")

#text("In the first column one has a “base” theory or concept, which implicitly carries with it a certain ontology and way of thinking, regarding what objects one really cares to study, and what objects really “exist” in some mathematical sense. In the second column one has a fancier theory than the base theory (typically a “limiting case”, a “generalisation”, or a “completion” of the base theory), but one which still shares a close relationship with the base theory, in particular largely retaining the ontological and conceptual mindset of that theory. In the third column one has a new theory, which is ")#emph[#text("modeled")]#text(" by the theories in the middle column, but which is not tied to that model, or to the implicit ontology and viewpoint carried by that model. For instance, one ")#emph[#text("can")]#text(" think of a complex number as an element of the algebraic completion of the reals, but one does not ")#emph[#text("have")]#text(" to, and indeed in many parts of complex analysis or complex geometry one wants to ignore the role of the reals as much as possible. Similarly for other rows of the above table. See for instance these ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("lecture notes of mine")]#text(" for further discussion of the distinction between measure theory and probability theory.")

#text("[The relationship between the second and third columns of the above table is also known as the ")#link("http://en.wikipedia.org/wiki/Map%E2%80%93territory_relation")[#text("map-territory relation")]#text(".]")

#text("Returning to ultralimit analysis, this is a type of analysis which still shares close ties with its base theory, standard analysis, in that all the objects one considers are either standard objects, or ultralimits of such objects (and similarly for all the spaces one considers). But more importantly, one continues to ")#emph[#text("think of")]#text(" nonstandard objects as being ultralimits of standard objects, rather than having an existence which is largely independent of the concept of base theory of standard analysis. This perspective is reversed in nonstandard analysis: one views the nonstandard universe as existing in its own right, and the fact that the standard universe can be embedded inside it is a secondary feature (albeit one which is absolutely essential if one is to use nonstandard analysis in any nontrivial manner to say something new about standard analysis). In nonstandard analysis, ultrafilters are viewed as one tool in which one can construct the nonstandard universe from the standard one, but their role in the subject is otherwise minimised. In contrast, the ultrafilter ")#mi("{\\alpha_\\infty}")#text(" plays a prominent role in ultralimit analysis.")

#text("In my opinion, none of the three columns here are inherently “better” than the other two; but they do work together quite well. In particular, the middle column serves as a very useful bridge to carry results back and forth between the worlds of the left and right columns.")

#heading(level: 1)[#text("Comments (47)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/79a190795d80e8c530d4a698e6be06bac867e32eed945b944b9cc603f8f83754-717d77f039a97e939bab0746ac8ac93e3d6f29dd80ba56d28d6bf76de4a9939f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of solrize")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-43455")[#strong[#text("solrize")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2010")])]

#text("This sounds sort of like a method I’ve heard of called “proof mining” from mathematical logic, though I don’t actually know anything about it. There is a stub wikipedia article about it, if that’s of any interest: ")#link("http://en.wikipedia.org/wiki/Proof_mining")[#text("http://en.wikipedia.org/wiki/Proof_mining")]#text(" .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-43471")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2010")])]

#text("Ultralimit analysis suggests that proof mining is possible, but does not perform any proof mining ")#emph[#text("per se")]#text(". Indeed, ultralimit analysis can take an infinitary qualitative result ")#emph[#text("as a black box")]#text(" (without knowing anything about how such a result is proved), and uses this to obtain a finitary quantitative (but ineffective) analogue of this result. In contrast, proof mining analyses the ")#emph[#text("proof")]#text(" of the infinitary result and uses this to establish an ")#emph[#text("effective")]#text(" quantitative counterpart.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-43456")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2010")])]

#text("Awesome post.")

#text("At the end of the proof of Lemma 5: “But then this forces {A_\\alpha} to be finite for {\\alpha} sufficiently close to {\\alpha_\\infty}.” Do you mean “bounded,” not “finite” here?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-43457")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2010")])]

#text("Also, in the proof of Theorem 9, it would be more accurate to thank me for copying that argument out of Lazarsfeld’s book….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-43492")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2010")])]

#text("anon")

#text("Dear Terry,")

#text("Does the ultralimit depend on the choice of a particular fixed")#linebreak()#text(" nonprinciple ultrafilter?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-43495")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2010")])]

#text("Yes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-43497")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2010")])]

#text("Dear Terry,")

#text("To clarify my earlier question: How does the ultralimit depend on the choice")#linebreak()#text(" of the nonprincipal ultrafilter? For example, is there a huge number of non isomorphic versions of the hyperreals, or nonstandard completions of a given standard universe?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-43578")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2010")])]

#text("This is discussed in the comments of my previous blog post:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("Ultrafilters, nonstandard analysis, and epsilon management")]
]

#text("The short answer is yes, there are a large number of non-isomorphic completions; in general, two different ultrafilters will not be isomorphic to each other. But for the type of ultralimit analysis performed above, it is rare that one needs to know anything more specific about the ultrafilter one is using – they all give elementary limits, and this is usually all one needs. (When doing additive combinatorics via ultrafilters, though, it is often very convenient to use special ultrafilters adapted to the additive structure, such as idempotent ultrafilters.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-43498")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2010")])]

#text("“Again, this argument gives absolutely no clue as to how {C_F} is going to depend on {F}. (Indeed, I would be curious to know what this dependence is exactly.)”")

#text("I think it could be pretty horrible. Suppose for instance that F is monotone nondecreasing. A_1 could be F(1) hyperplanes in k^F(1), i.e. the vanishing of the product of F(1) linear polynomials. Then strip out one of these hyperplanes to get A_2, another to get A_3, and so on, until you get to A_{F(1)}, which is a single hyperplane. Now take A_{F(1)+1} to be the intersection of this hyperplane with the vanishing locus of F(F(1)) linear forms. This is a union of F(F(1)) codimension-2 subspaces; now strip them out one at a time until you get to something around A_{F(F(1))}. And the next variety will be a union of F(F(F(1))) codim-3 subspaces, and so on. So I guess I’m saying that C_F must at least be on order of F(F(F(….F(1)))) where the iteration is itself carried out F(1) times.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-43519")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2010")])]

#text("Thanks Jordan! Actually that’s not too bad – polynomial type bounds on complexity lead to exponential type bounds on length of chain, exponential bounds on complexity lead to tower exponential type bounds on length, and so forth. At least the Ackermann hierarchy or worse (e.g. Goodstein sequences) are not involved…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of misha")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-43518")[#strong[#text("misha")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2010")])]

#text("It seems in the “Definition 1 (Algebraic set) An (affine) algebraic set over an algebraically field” the word _algebraically_ is not correct. Unnecessary?")

#emph[#text("[Oops, the word “closed” was missing. Corrected, thanks. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orr")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-43560")[#strong[#text("Orr")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2010")])]

#text("Dear Terry,")#linebreak()#text(" Apropos “quantitative” algebraic geometry – did you ever think about the following problem:")#linebreak()#text(" Given an ideal ")#mi("I")#text(", we know that there are polynomials ")#mi("f_1, \\ldots, f_k \\in I")#text(" such that every ")#mi("h \\in I")#text(" can be written as ")#mi("h = a_1 f_1 + \\ldots a_k f_k")#text(", where ")#mi("a_i")#text(" are polynomials. Now assume that there is some norm ")#mi("\\| \\cdot \\|")#text(" on the algebra of polynomials. Do there exist polynomials ")#mi("f_1, \\ldots, f_k \\in I")#text(" such that every ")#mi("h \\in I")#text(" can be written as ")#mi("h = a_1 f_1 + \\ldots a_k f_k")#text(", but now with the additional constraint that ")#tao-math("\\sum\\left\\|a_i f_i \\right\\| \\leq C \\left\\|h\\right\\|", block: false)#text(", where ")#mi("C")#text(" is some universal constant?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 1: Equidistribution of polynomial sequences in torii « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-44030")[#strong[#text("254B, Notes 1: Equidistribution of polynomial sequences in torii « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2010")])]

#text("[…] cost of converting the finitary theory to an infinitary one. Ultralimit analysis was discussed in this previous blog post; we give a quick review […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-44032")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2010")])]

#text("In Definition 1, it should be “algebraically closed field”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Lecture Notes 4: Equidistribution of polynomials over finite fields « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-44746")[#strong[#text("254B, Lecture Notes 4: Equidistribution of polynomials over finite fields « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2010")])]

#text("[…] in a finitary setting rather than a nonstandard one, but the two approaches are equivalent; see this blog post for more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Approximate subgroups of linear subgroups « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-44811")[#strong[#text("Approximate subgroups of linear subgroups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2010")])]

#text("[…] analogues of the basic theory of algebraic geometry (which we chose to obtain via ultrafilters, as discussed in this post), we rely on two basic tools. Firstly, we use a version of the pivot argument developed first by […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-45471")[#strong[#text("Symposium “Abel Prize 2010” « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2010")]

#text("[…] to bound the number of elements of the finite set used to generate a given point , it is not effective because, for instance, there is no efficient method (to the best of my knowledge) to find explicit […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31a3f814b4ce3f9613fc9bf695a79a6f792c2f0629bc7e14d11d5840d3f7d743-309dee0d642fa87941549982d0b477a0c57d3958a1e8a9a3153402f98d832952.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-47063")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2010")])]

#text("Dear Terry,")

#text("just a stylistic remark on section 4: the argument is presented as a contradiction, but it’s actually a direct proof (“Let A have positive density, then we find E and conclude that A contains an arithmetic progression.”). I think it would be more pleasant to read in the direct style.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nonstandard analysis as a completion of standard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-48284")[#strong[#text("Nonstandard analysis as a completion of standard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2010")])]

#text("[…] are also discussed in more detail in this previous blog post. A fundamental theorem of Los asserts that the ultrapower is elementarily equivalent to : any […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Concentration compactness via nonstandard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-48329")[#strong[#text("Concentration compactness via nonstandard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2010")])]

#text("[…] basics of nonstandard analysis are reviewed in this previous blog post (and see also this later post on ultralimit analysis, as well as the most recent post on this topic). Very briefly, we will need to fix a non-principal […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-48890")[#strong[#text("Ultrafilters in Ramsey theory « Annoying Precision")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2010")]

#text("[…] for automatically constructing infinitary results to nonconstructive but finitary ones. There is a post by Terence Tao discussing similar applications of ultraproducts as the one above; we will have more to say about […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Higher order Fourier analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-51104")[#strong[#text("Higher order Fourier analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2011")])]

#text("[…] on my graduate course in the topic, though it also contains material from some additional posts related to linear and higher order Fourier analysis on the blog. It is available online here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polynomial bounds via nonstandard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-55010")[#strong[#text("Polynomial bounds via nonstandard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2011")])]

#text("[…] we take ultralimits (see e.g. this previous blog post of a quick review of ultralimit analysis, which we will assume knowledge of in the argument that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 6: Ultraproducts as a bridge between hard analysis and soft analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-93079")[#strong[#text("254A, Notes 6: Ultraproducts as a bridge between hard analysis and soft analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2011")])]

#text("[…] (Logical limit) If the are all distinct spaces (or elements or subsets of distinct spaces), with few morphisms connecting them together, then topological and categorical limits are often unavailable or unhelpful. In such cases, however, one can still tie together such objects using an ultraproduct construction (or similar device) to create a limiting object or limiting space that is a logical limit of the , in the sense that various properties of the (particularly those that can be phrased using the language of first-order logic) are preserved in the limit. As such, logical limits are often very well suited for the task of connecting finitary and infinitary mathematics together. Ultralimit type constructions are of course used extensively in logic (particularly in model theory), but are also popular in metric geometry. They can also be used in many of the previously mentioned areas of mathematics, such as algebraic geometry (as discussed in this previous post). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 5: Product theorems, pivot arguments, and the Larsen-Pink non-concentration inequality « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-126692")[#strong[#text("254B, Notes 5: Product theorems, pivot arguments, and the Larsen-Pink non-concentration inequality « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("[…] subvariety of (here we use the uniform complexity bound). One can also show that ; see Lemma 3 of this blog post. As such, we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A cheap version of nonstandard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-136450")[#strong[#text("A cheap version of nonstandard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2012")])]

#text("[…] Below the fold, I would like to describe this cheap version of nonstandard analysis, which I think can serve as a pedagogical stepping stone towards fully nonstandard analysis, as it is formally similar to (though weaker than) fully nonstandard analysis, but on the other hand is closer in practice to standard analysis. As we shall see below, the relation between cheap nonstandard analysis and standard analysis is analogous in many ways to the relation between probabilistic reasoning and deterministic reasoning; it also resembles somewhat the preference in much of modern mathematics for viewing mathematical objects as belonging to families (or to categories) to be manipulated en masse, rather than treating each object individually. (For instance, nonstandard analysis can be used as a partial substitute for scheme theory in order to obtain uniformly quantitative results in algebraic geometry, as discussed for instance in this previous blog post.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Lang-Weil bound « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-166329")[#strong[#text("The Lang-Weil bound « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2012")])]

#text("[…] one could obtain ineffective bounds on these quantities by an ultralimit argument, as discussed in this previous post, or equivalently by moving everything over to a nonstandard analysis framework; one could also […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Definable subsets over (nonstandard) finite fields, and almost quantifier elimination « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-169853")[#strong[#text("Definable subsets over (nonstandard) finite fields, and almost quantifier elimination « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2012")])]

#text("[…] we have absolutely irreducible with dimension for close to (see Lemma 3 and Lemma 8 of this previous blog post), and so by the Lang-Weil bound (see this previous blog post) we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-185898")[#strong[#text("Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2012")])]

#text("[…] We will assume some familiarity with nonstandard analysis, as covered for instance in these previous blog posts. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Expanding polynomials over finite fields of large characteristic, and a regularity lemma for definable sets « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-192675")[#strong[#text("Expanding polynomials over finite fields of large characteristic, and a regularity lemma for definable sets « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2012")])]

#text("[…] reduce to by an ultraproduct (or nonstandard analysis) construction, similar to that discussed in this previous post), the varieties are generically finite étale covers of , and the fibre product is then […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rectification and the Lefschetz principle | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-219476")[#strong[#text("Rectification and the Lefschetz principle | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2013")])]

#text("[…] be used as a bridge to connect quantitative and qualitative results (as discussed in these previous blog posts), we will deduce Theorem 3 from the following (well-known) qualitative […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An informal version of the Furstenberg correspondence principle | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-221342")[#strong[#text("An informal version of the Furstenberg correspondence principle | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2013")])]

#text("[…] , and leads to the Furstenberg correspondence principle, discussed for instance in these previous blog posts. Such principles allow one to rigorously pass back and forth between the combinatorics of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ramsey theorem and ultrafilters (II) | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-233386")[#strong[#text("Ramsey theorem and ultrafilters (II) | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("[…] motivation is the fact that I don’t get why one has to reason by compactness and contradiction, so I am looking for a direct proof (which is of course still non […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A spectral theory proof of the algebraic regularity lemma | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-249427")[#strong[#text("A spectral theory proof of the algebraic regularity lemma | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2013")])]

#text("[…] We will take this proposition as a black box; a proof can be obtained by combining the description of definable sets over pseudofinite fields (discussed in this previous post) with the Lang-Weil bound (discussed in this previous post). (The former fact is phrased using nonstandard analysis, but one can use standard compactness-and-contradiction arguments to convert such statements to statements in standard analysis, as discussed in this post.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-255858")[#strong[#text("Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2013")])]

#text("[…] notably “Ultraproducts as a bridge between hard analysis and soft analysis” and “Ultralimit analysis and quantitative algebraic geometry“‘. The text here has substantially more details than the talk; one may wish to skip all […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A nonstandard analysis proof of Szemeredi’s theorem | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-457536")[#strong[#text("A nonstandard analysis proof of Szemeredi’s theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2015")])]

#text("[…] routine “compactness and contradiction” arguments (as discussed in this previous post), Theorem 1 can be deduced from the following nonstandard […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6eee5267e0ba94bf52835d85e35950babf3a9bc2925be3f394e65f1ca8a7d23f-f6d8a62917d807f87f4a78a57126f587cfd8879423a147201f1d5af57a6711c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of simingtu")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-467783")[#strong[#text("simingtu")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2016")])]

#text("Dear Prof. Tao,")#linebreak()#text(" In Lemma, I can not see from the argument how one can derive that the quantity ")#mi("C_M")#text(" is independent of the field ")#mi("k")#text(". Would you like to give any hint? Thank you very much.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-467786")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2016")])]

#text("I assume you are referring to Lemma 5. As stated in the blog post, the argument proceeds by contradiction. If, for a given ")#mi("M")#text(", there does ")#strong[#text("not")]#text(" exist a quantity ")#mi("C_M")#text(" independent of ")#mi("k")#text(" for which the statement of Lemma 5 holds, then for each natural number ")#mi("\\alpha")#text(" one can find a field ")#mi("k_\\alpha")#text(" and dimension zero sets ")#mi("A_\\alpha")#text(" of complexity bounded by ")#mi("M")#text(" for which the cardinality of ")#mi("A_\\alpha")#text(" exceeds ")#mi("\\alpha")#text(". Taking ultralimits one obtains a counterexample to Lemma 4. (This is a simple example of the basic “compactness and contradiction” argument that is used frequently when employing ultrafilter or nonstandard methods to establish a finitary result.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/355b7a34448edbc25b48c6d93b464cd99e886a2407b7e06cd1fb9642ac65745c-3ccd155508f869e71c11a6f0709f11b64ce8085bd15789fb8d2a564aeb052e35.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of easy")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-467789")[#strong[#text("easy")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2016")])]

#text("Professor Tao How do you remember what you wrote eons ago?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8276f0954b97549ceff275f57c29082e0589d500a659640812d803d6fbd0c170-0ea9f76c3e76b42cf50f9c9e28b096afd33cf0cef6e93d3b23a1c0acc573910a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of manhtuankhtn")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-481659")[#strong[#text("manhtuankhtn")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2017")])]

#text("Dear Prof. Tao, Could you please explain why every bounded limit real number x has a unique standard part? From the Bolzano-Weierstrass theorem we know that each bounded sequence in R has a convergent subsequence. But how can we guarantee that the index set is in the given ultrafilter? Thank you very much.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-482150")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2017")])]

#text("Hint: a bounded limit real number ")#mi("x")#text(" creates a Dedekind cut of the standard rationals, since every standard rational is either less than ")#mi("x")#text(", or greater than or equal to ")#mi("x")#text(". One can also repeat the _proof_ of the Bolzano-Weierstrass theorem (repeatedly dividing an interval into two subintervals), rather than using the standard Bolzano-Weierstrass theorem as a “black box”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c90dc59d020b6b7ceced9cb4b642f63881a652367b7d1037825a7098af7fd2cf-d2501b8777faf7f4e61e18b393dfa2d08455fda519b704608e5fafdbdb7f9cf8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Κωνσταντίνος Κουρουζίδης")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-533027")[#strong[#text("Κωνσταντίνος Κουρουζίδης")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2019")])]

#text("Would it be correct to think of Marden’s theorem as an early result in the field of algebraic geometry? Since it gives a nice geometric understanding of the roots of a third degree polynomial, with the roots of it’s derivative.. In layman terms, roots (algebra) connected with locus of points (ellipses in this case) reminds us the corresponding field of mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-556335")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2020")])]

#text("In the framework of this article, can the string “0.99…” be interpreted as something different from the real number ")#mi("1")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1647f2039242ded625975aa4e847605b2078ffd71b8c5b4657337e6fb589bfc-9e12eaf3fc9ed2ed714c6b3a8faf4d9769e9a5117969dbf2e8d146c92f80ce85.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Deikun")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-623024")[#strong[#text("James Deikun")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2021")])]

#text("No. A string starting “0.99…” that is different from 1 would differ by at least an infinitesimal; this is a reciprocal of an unbounded number. This unbounded number would have a logarithm L, also unbounded.")

#text("1) up to a few digits before the position L, the digits would all be 9s.")#linebreak()#text(" 2) at most a few digits after the position L, there would stop being a string of 9s.")

#text("The string can end up ‘terminating’ (actually, containing only 0s) after already having (externally) infinitely many 9s, but there must still be a *last* 9 after that ‘…’ …")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-593241")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2020")])]

#text("Sorry for posting the same comment under two your different blogs posts, but both really need to refer to this comment accordingly sound sense:")

#text("Terry,")

#text("Previously I have been written in this comment stream that I “attempt” to construct “noncontinuous” analysis (common generalization of continuous analysis and discrete analysis, as well as analysis of any arbitrary functions (having some topological structure)). I succeeded!!")

#text("I already defined (generalized) limit of an arbitrary (even discontinuous) function. Now I have written a text how to manipulate these limits (e.g. add or multiply them). I even defined what a noncontinuous solution of a differential equation means.")

#text("Need to say that it makes obvious to define derivatives and integrals (as well as infinite sums) for arbitrary functions?")

#text("Hm, probably my generalized limit is equivalent to the limit \\union all the ultralimits on ultrafilters over the given filter (not checked the statement given in this paragraph yet). Quite an obvious idea, but nobody formulated it.")

#text("Here is the text about generalized limit:")#linebreak()#text(" ")#link("https://mathematics21.org/limit-of-discontinuous-function/")[#text("https://mathematics21.org/limit-of-discontinuous-function/")]

#text("Moreover, this generalized limit trivially generalizes further to limits on arbitrary “spaces”. I define the concept of “space” that encompasses all kinds of spaces in topology, including topological, proximity, uniform, metric spaces, locales and frames, etc. in this text:")#linebreak()#text(" ")#link("https://mathematics21.org/the-algebra-of-general-topology/")[#text("https://mathematics21.org/the-algebra-of-general-topology/")]

#text("Nominate me for Abel and Breakthrough prizes for these works! Seriously.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Concentration compactness via nonstandard analysis | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-615280")[#strong[#text("Concentration compactness via nonstandard analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2021")])]

#text("[…] The basics of nonstandard analysis are reviewed in this previous blog post (and see also this later post on ultralimit analysis, as well as the most recent post on this topic). Very briefly, we will need to fix a non-principal […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71201f395df7767381e6f128fb702b6b806f8684a24a9f379cba33ba9c365fbe-44615daa6b4ed9c2ef237f863a907f77c1fe89e219bd8133ad8fcd03956ddad3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christopher David King")]], [#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/#comment-659990")[#strong[#text("Christopher David King")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2022")])]

#text("> Again, this argument gives absolutely no clue as to how {C_F} is going to depend on {F}. (Indeed, I would be curious to know what this dependence is exactly.)")

#text("I believe I have found an upper bound, but it is really quite weak (due to how simple the theory of fields is, maybe it can be strengthened?). I found it when trying to find a proof using IST and noticing that the axiom of choice wasn’t necessary when converting it back to ZFC.")

#text("Let F be a computable function. Then form a recursively enumerable theory T consisting of the field axioms and an infinite sequence of axioms, S_α")

#text("A_α+1 ⊊ A_α")

#text("Where the A_α are formulas corresponding to algebraic sets of complexity ≤ F(α), expressed as polynomials padded out like in your Lemma 2, with fresh constant symbols taking the place of coefficients. A_α ⊊ A_α+1 is first order expressible because “forall x. phi(x) => psi(x)” can express the subset relation between formulas.")

#text("By lemma 6, T has no model, and so by Gödel’s completeness theorem (")#link("https://en.wikipedia.org/wiki/G%C3%B6del%27s_completeness_theorem")[#text("https://en.wikipedia.org/wiki/G%C3%B6del%27s_completeness_theorem")]#text(") it syntactically implies a contradiction. Therefore, we can construct a Turing machine that looks for a proof of said contradiction and returns the largest α where S_α was used in the proof. The returned α is then bounded by the busy beaver function. This proves:")

#text("Theorem: in your lemma 7, if F is computable with a turing machine with up to L states and L tape symbols, then R is BB(O(L)), with the implied constant effective and where BB is the busy beaver function. Q.E.D.")

#text("I suspect this can be strengthened to something primitive recursive (fields are a simple theory), but I’m not sure.")
]
