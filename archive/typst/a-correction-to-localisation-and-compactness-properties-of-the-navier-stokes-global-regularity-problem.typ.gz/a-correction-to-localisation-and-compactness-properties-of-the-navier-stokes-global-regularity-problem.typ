// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/
// Converted to Typst by tao2typ: "2026-10-14T09:13:07.332704+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A correction to “Localisation and compactness properties of the Navier-Stokes global regularity problem”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A correction to “Localisation and compactness properties of the Navier-Stokes global regularity problem”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 August 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/")[#text("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A few days ago, I released a preprint entitled “")#link("http://arxiv.org/abs/1108.1165")[#text("Localisation and compactness properties of the Navier-Stokes global regularity problem")]#text("“, discussed in ")#link("https://terrytao.wordpress.com/2011/08/04/localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/")[#text("this previous blog post")]#text(". As it turns out, I was somewhat impatient to finalise the paper and move on to other things, and the original preprint was still somewhat rough in places (contradicting ")#link("https://terrytao.wordpress.com/advice-on-writing-papers/submit-a-final-draft-not-a-first-draft/")[#text("my own advice on this matter")]#text("), with a number of typos of minor to moderate severity. But a bit more seriously, I discovered on a further proofreading that there was a subtle error in a component of the argument that I had believed to be routine – namely the persistence of higher regularity for mild solutions. As a consequence, some of the implications stated in the first version were not exactly correct as stated; but they can be repaired by replacing a “bad” notion of global regularity for a certain class of data with a “good” notion. I have completed (and proofread) an updated version of the ms, which should appear at the ")#link("http://arxiv.org/abs/1108.1165")[#text("arXiv link of the paper")]#text(" in a day or two (and which I have also placed ")#link("https://terrytao.wordpress.com/wp-content/uploads/2011/08/local_ns.pdf")[#text("at this link")]#text("). (In the meantime, it is probably best not to read the original ms too carefully, as this could lead to some confusion.) I’ve also added a new section that shows that, due to this technicality, one can exhibit smooth ")#mi("H^1")#text(" initial data to the Navier-Stokes equation for which there are no smooth solutions, which superficially sounds very close to a negative solution to the global regularity problem, but is actually nothing of the sort.")

#text("Let me now describe the issue in more detail (and also to explain why I missed it previously). A standard principle in the theory of evolutionary partial differentiation equations is that ")#emph[#text("regularity in space can be used to imply regularity in time")]#text(". To illustrate this, consider a solution ")#mi("u")#text(" to the supercritical nonlinear wave equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("-\\partial_{tt} u + \\Delta u = u^7")]]

#text("for some field ")#mi("u: {\\bf R} \\times {\\bf R}^3 \\to {\\bf R}")#text(". Suppose one already knew that ")#mi("u")#text(" had some regularity in space, and in particular the ")#mi("C^0_t C^2_x \\cap C^1_t C^1_x")#text(" norm of ")#mi("u")#text(" was bounded (thus ")#mi("u")#text(" and up to two spatial derivatives of ")#mi("u")#text(" were bounded). Then, by (1), we see that two ")#emph[#text("time")]#text(" derivatives of ")#mi("u")#text(" were also bounded, and one then gets the additional regularity of ")#mi("C^2_t C^0_x")#text(".")

#text("In a similar vein, suppose one initially knew that ")#mi("u")#text(" had the regularity ")#mi("C^0_t C^3_x \\cap C^1_t C^2_x")#text(". Then (1) soon tells us that ")#mi("u")#text(" also has the regularity ")#mi("C^2_t C^1_x")#text("; then, if one differentiates (1) in time to obtain")

#align(center)[#tao-fit-display[#mitex("-\\partial_{ttt} u + \\Delta \\partial_t u = 7 u^6 \\partial_t u")]]

#text("one can conclude that ")#mi("u")#text(" also has the regularity of ")#mi("C^3_t C^0_x")#text(". One can continue this process indefinitely; in particular, if one knew that ")#mi("u \\in C^0_t C^\\infty_x \\cap C^1_t C^\\infty_x")#text(", then these sorts of manipulations show that ")#mi("u")#text(" is infinitely smooth in both space and time.")

#text("The issue that caught me by surprise is that for the Navier-Stokes equations")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u + (u \\cdot \\nabla) u  & =\\Delta u -\\nabla p", block: true, numbering: n => [#text("(2)")])



#tao-math("\\nabla \\cdot u  & = 0", block: true)
]

#text("(setting the forcing term ")#mi("f")#text(" equal to zero for simplicity), infinite regularity in space does ")#emph[#text("not")]#text(" automatically imply infinite regularity in time, even if one assumes the initial data lies in a standard function space such as the Sobolev space ")#mi("H^1_x({\\bf R}^3)")#text(". The problem lies with the pressure term ")#mi("p")#text(", which is recovered from the velocity via the elliptic equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\Delta p = -\\nabla^2 \\cdot (u \\otimes u)")]]

#text("that can be obtained by taking the divergence of (2). This equation is solved by a non-local integral operator:")

#align(center)[#tao-fit-display[#tao-math("p(t,x) = \\int_{{\\bf R}^3} \\frac{\\nabla^2 \\cdot (u \\otimes u)(t,y)}{4\\pi \\left|x-y\\right|}\\ dy.", block: true)]]

#text("If, say, ")#mi("u")#text(" lies in ")#mi("H^1_x({\\bf R}^3)")#text(", then there is no difficulty establishing a bound on ")#mi("p")#text(" in terms of ")#mi("u")#text(" (for instance, one can use singular integral theory and Sobolev embedding to place ")#mi("p")#text(" in ")#mi("L^3_x({\\bf R}^3)")#text(". However, one runs into difficulty when trying to compute time derivatives of ")#mi("p")#text(". Differentiating (3) once, one gets")

#align(center)[#mi("\\Delta \\partial_t p = -2\\nabla^2 \\cdot (u \\otimes \\partial_t u)")#text(".")]

#text("At the regularity of ")#mi("H^1")#text(", one can still (barely) control this quantity by using (2) to expand out ")#mi("\\partial_t u")#text(" and using some integration by parts. But when one wishes to compute a second time derivative of the pressure, one obtains (after integration by parts) an expansion of the form")

#align(center)[#tao-fit-display[#mitex("\\Delta \\partial_{tt} p = -4\\nabla^2 \\cdot (\\Delta u \\otimes \\Delta u) + \\ldots")]]

#text("and now there is not enough regularity on ")#mi("u")#text(" available to get any control on ")#mi("\\partial_{tt} p")#text(", even if one assumes that ")#mi("u")#text(" is smooth. Indeed, following this observation, I was able to show that given generic smooth ")#mi("H^1")#text(" data, the pressure ")#mi("p")#text(" will instantaneously fail to be ")#mi("C^2")#text(" in time, and thence (by (2)) the velocity will instantaneously fail to be ")#mi("C^3")#text(" in time. (Switching to the vorticity formulation buys one further degree of time differentiability, but does not fully eliminate the problem; the vorticity ")#mi("\\omega")#text(" will fail to be ")#mi("C^4")#text(" in time. Switching to material coordinates seems to makes things very slightly better, but I believe there is still a breakdown of time regularity in these coordinates also.)")

#text("For later times t>0 (and assuming homogeneous data f=0 for simplicity), this issue no longer arises, because of the instantaneous smoothing effect of the Navier-Stokes flow, which for instance will upgrade ")#mi("H^1_x")#text(" regularity to ")#mi("H^\\infty_x")#text(" regularity instantaneously. It is only the initial time at which some time irregularity can occur.")

#text("This breakdown of regularity does not actually impact the original formulation of the Clay Millennium Prize problem, though, because in that problem the initial velocity is required to be Schwartz class (so all derivatives are rapidly decreasing). In this class, the regularity theory works as expected; if one has a solution which already has some reasonable regularity (e.g. a mild ")#mi("H^1")#text(" solution) and the data is Schwartz, then the solution will be smooth in spacetime. (Another class where things work as expected is when the ")#emph[#text("vorticity")]#text(" is Schwartz; in such cases, the solution remains smooth in both space and time (for short times, at least), and the Schwartz nature of the vorticity is preserved (because the vorticity is subject to fewer non-local effects than the velocity, as it is not directly affected by the pressure).)")

#text("This issue means that one of the implications in the original paper (roughly speaking, that global regularity for Schwartz data implies global regularity for smooth ")#mi("H^1")#text(" data) is not correct as stated. But this can be fixed by weakening the notion of global regularity in the latter setting, by limiting the amount of time differentiability available at the initial time. More precisely, call a solution ")#mi("u: [0,T] \\times {\\bf R}^3 \\to {\\bf R}^3")#text(" and ")#mi("p: [0,T] \\times {\\bf R}^3 \\to {\\bf R}")#text(" ")#emph[#text("almost smooth")]#text(" if")

#list(
[#mi("u")#text(" and ")#mi("p")#text(" are smooth on the half-open slab ")#mi("(0,T] \\times {\\bf R}^3")#text("; and")],
[#text("For every ")#mi("k \\geq 0")#text(", ")#mi("\\nabla^k_x u, \\nabla^k_x p, \\nabla^x_u \\partial_t u")#text(" exist and are continuous on the full slab ")#mi("[0,T] \\times {\\bf R}^3")#text(".")]
)

#text("Thus, an almost smooth solution is the same concept as a smooth solution, except that at time zero, the velocity field is only ")#mi("C^1_t C^\\infty_x")#text(", and the pressure field is only ")#mi("C^0_t C^\\infty_x")#text(". This is still enough regularity to interpret the Navier-Stokes equation (2) in a classical manner, but falls slightly short of full smoothness.")

#text("(I had already introduced this notion of almost smoothness in the more general setting of smooth finite energy solutions in the first draft of this paper, but had failed to realise that it was also necessary in the smooth ")#mi("H^1")#text(" setting also.)")

#text("One can now “fix” the global regularity conjectures for Navier-Stokes in the smooth ")#mi("H^1")#text(" or smooth finite energy setting by requiring the solutions to merely be almost smooth instead of smooth. Once one does so, the results in my paper then work as before: roughly speaking, if one knows that Schwartz data produces smooth solutions, one can conclude that smooth ")#mi("H^1")#text(" or smooth finite energy data produces almost smooth solutions (and the paper now contains counterexamples to show that one does not always have smooth solutions in this category).")

#text("The diagram of implications between conjectures has been adjusted to reflect this issue, and now reads as follows:")

#link("https://terrytao.wordpress.com/wp-content/uploads/2011/08/implications1.png")[#image("../assets/c1135fe4df883d7edd7510465a50859a6c14a9e58bd390ad53e8f757e3ef1d82-f7e609c3dea5499e3511a46339878d1ab0db54cd720f1d14c045f98029429d35.png", width: 90%)]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (23)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8442ab05981b5f2944ef3387ce95faae79fbbcab0252627380eb6bfff76e97bd-386a3fdbcc0a12b60077e9dd23e718db90aed0b2988d3cbcebaf044b057408f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Coulter")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-64431")[#strong[#text("Robert Coulter")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2011")])]

#text("A global discontinuity, in time, at T, of the pressure would have no effect on u(x,T) (that is create no discontinuity). This is one of the peculiar natures of incompressibility. The system actually only “sees” the grad of the pressure.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-64444")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2011")])]

#text("I had hoped for this, but unfortunately, the discontinuity in pressure is not constant in space, and so it also shows up in the gradient of the pressure as well (and hence in the velocity). Even the vorticity appears to be somewhat affected by this problem, though less so than the velocity (which in turn is less singular in time than the pressure).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-64814")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2011")])]

#text("I think in the derivation of the pressure Poisson equation the time derivatives are eliminated leaving one with a relationship, at a particular time instance, of the pressure and velocity fields. Alas, there is no temporal information about the pressure time evolution per my understanding of the Poisson equation. It would give the pressure, for any point in the field, once one pre-declares a pressure value at some reference point — say the origin. If one had the temporal pressure information at the standard point (say the origin) then the entire p(x.t) curve can be regenerated.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-64972")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2011")])]

#text("There are some non-rendered ‘H^1’s in the last couple of paragraphs.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-64985")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2011")])]

#text("Congrats on your 1 million bucks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-65032")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2011")])]

#text("Hi Terry Tao,")#linebreak()#text(" I refer to your blog")#linebreak()#text(" “Localisation and compactness properties of the Navier-Stokes global regularity problem”, posted on 4 August, 2011.")#linebreak()#text(" …")#linebreak()#text(" 3. Finally, one can ask the extent to which the conjecture depends on the category of data. For instance, could it be that global regularity is true for smooth periodic data but false for Schwartz data? True for Schwartz data but false for smooth H^1 data? … If u(t) is Schwartz, then from Stokes’ theorem we necessarily have zero mean vorticity. …")

#text("Can you concoct one explicit example so that we see how the vorticity invariance breaks down? Many thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-65176")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2011")])]

#text("Oops, on closer inspection I see that mean zero vorticity in ")#mi("{\\bf R}^3")#text(" is preserved after all… but one can instead work with higher moments, such as ")#mi("\\int_{{\\bf R}^3} \\omega_3 (x_1^2-x_2^2)")#text(", which still need to vanish for Schwartz velocities but are not preserved (the time derivative of this expression works out to something like ")#mi("\\int_{{\\bf R}^3} u_1 u_2")#text(" up to constants, which usually does not vanish at time zero).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8442ab05981b5f2944ef3387ce95faae79fbbcab0252627380eb6bfff76e97bd-386a3fdbcc0a12b60077e9dd23e718db90aed0b2988d3cbcebaf044b057408f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Coulter")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-65401")[#strong[#text("Robert Coulter")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2011")])]

#text("Equation (2) appears to be missing the term representing the energy loss to viscosity (on the right side). Or otherwise please explain, I just don’t follow this energy balance. The energy at time T would be equal to the initial energy field plus the force integral minus the energy lost to viscosity.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8442ab05981b5f2944ef3387ce95faae79fbbcab0252627380eb6bfff76e97bd-386a3fdbcc0a12b60077e9dd23e718db90aed0b2988d3cbcebaf044b057408f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Coulter")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-65754")[#strong[#text("Robert Coulter")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2011")])]

#text("I was referring to equation (2) in the upload at arxiv, not (2) at this post here which appears to be correct if viscosity = 1.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-65772")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2011")])]

#text("The quantity ")#mi("E(u_0,f,T)")#text(" defined in the paper represents the total energy added to the system by time T. The actual energy at time T will indeed be less than this quantity due to energy dissipation.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/426f2cb69fd02a44e69e661c408f10a7c67c05bb58360968fd8a4c099e425d97-4f19d6a34ca280c54b9e713f8bbe204d19998a236e3996b8fa06dfbe1d193b38.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of crusher")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-65393")[#strong[#text("crusher")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2011")])]

#text("This is one of the peculiar natures of incompressibility. The system actually only “sees” the grad of the pressure.One can now “fix” the global regularity conjectures for Navier-Stokes in the smooth or smooth finite energy setting by requiring the solutions to merely be almost smooth instead of smooth.I agree with it !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/707f7e25d562b7a9f764b57b8ca4990cd9a9e71c358a1b369e5cf2dea4e2a20d-efd6a87667c87b3658401f2b9e3faa298be527befdc53b1e9a6f483986902e2a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of NICO VENGEANCE")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-65461")[#strong[#text("NICO VENGEANCE")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2011")])]

#text("I think maybe you are a lecturer. Whether mathematics like what you learn out there. It is quite different in Indonesia. I think it is pure mathematics and mathematics education instead. Kind of mathematics that refers to a study of a science. I’m interested. but I do not have enough help in the study.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/704b81e58ca29743b47850bb62f82d988587af8aa950d2d86ccec5d2d2505f3a-ae78c7c51eb8b92e65e74b0790dfb510525c2923707a533c2fcc07a150e39602.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of plm")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-65520")[#strong[#text("plm")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2011")])]

#text("Was it known or suspected that non-Schwartz class smooth H^1 initial velocity can yield nonsmooth solutions?")

#text("Is Schwartz class necessary? If not what could be weaker conditions that imply smoothness of solutions? (What are the relevant “physical” intuitions? -not that I know much physics)")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-65545")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2011")])]

#text("I’m not sure if the question had ever been explicitly considered in previous literature, though once it is posed, resolving it is not too difficult. (There is plenty of work on asymptotic behaviour of Navier-Stokes as ")#mi("t \\to \\infty")#text(" from slowly decaying data, but that is sort of orthogonal to the issue here, which only occurs at the initial time ")#mi("t=0")#text(".)")

#text("If the initial velocity is in ")#mi("H^\\infty")#text(" (i.e. all spatial derivatives of the velocity are square-integrable), then one can show that the solution remains smooth for a short time at least. If the initial velocity is merely in ")#mi("H^1")#text(", then the dissipative effects place it instantaneously in ")#mi("H^\\infty")#text(", so the only place where this type of lack of smoothness can occur is when ")#mi("t=0")#text(".")

#text("If the vorticity is Schwartz, then by the Biot-Savart law, the initial velocity will be in ")#mi("H^\\infty")#text(", so this is another case in which no singularity at initial time occurs.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-65825")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2011")])]

#text("Minor typo. I believe")#linebreak()#text(" “and the pressure field is only C^0_x C^\\infty_x”")#linebreak()#text(" should read")#linebreak()#text(" “and the pressure field is only C^0_t C^\\infty_x”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-66263")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2011")])]

#text("Hi Terry Tao,")

#text("Comments on C-infty (smooth) regularity at t=0.")

#text("Since your eqn (1) is a hyperbolic PDE, one can of course deduce time smooth regularity at t=0.")

#text("Unless one ASSUMES certain time-regularity for the initial data (eg in H^1 setting), it is generally impossible to achieve time smooth solutions for")#linebreak()#text(" t in [0,T], T>0 (ie it is ok for t in (0,T]) for the NS (a parabolic system).")#linebreak()#text(" Otherwise, it is known that extra compatibility conditions are required to extrapolate any smooth solutions back to t=0 (eg Rautmann, Math Zeit, 1983 and the references).")#linebreak()#text(" Your idea of almost smooth solutions is helpful and has precedence in the well-estabished theory for local smooth solutions (eg Theorems 2-5 of Heywood, Indiana Math J, 1980).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-66894")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2011")])]

#text("It is confirmed again that, given the number of conjectures listed, the NS global regularity is a very hard problem. Nevertheless, a number of papers")#linebreak()#text(" (by Smith (withdrawn), Kozachok, Wang etc) contain claims/conjectures that the problem may be solved by transforming the NS into an equivalent system.")#linebreak()#text(" Promising strategy?! Any thoughts?!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/06ca176c2a5464f2186dfa94ec79a02e112985047ae33dcd4b5eddcacc0ee95f-991fd68827cc5cd7d3eb4023228d7b9aecaf280c489240cc464f2ab79f1b253f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KY")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-95752")[#strong[#text("KY")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2011")])]

#text("I was only able to read the sketch of the proof rather than detail. A few things I noticed and a naive question.")

#text("1. On draft 2 page 26, you take an equation that is at 5th line from the top, multiply by a specific function denoted by $\\chi$, then you integrate by parts on a few terms but not all. It seems like you are indeed integrating by parts on the third term which is the nonlinear term $u\\cdot\\nabla u$. If so, the negative power of R should become 4 instead of 3, right?")

#text("2. On Theorem 5.4 (ii), you have a second equation after (46), by its upper bound, I believe you meant a constant that depends on many things below and hence I think you meant")

#text("$k, \\lVert u_{0}\\rVert_{H_{x}^{k}(\\mathbb{R}^{3}), \\lVert f\\rVert_{L_{t}^{1}H_{x}^{k}(\\mathbb{R}^{3})} 1$")

#text("But you included “,1$ in its subscript")

#text("$k, \\lVert u_{0}\\rVert_{H_{x}^{k}(\\mathbb{R}^{3}), \\lVert f\\rVert_{L_{t}^{1}H_{x}^{k}(\\mathbb{R}^{3}), 1}$")

#text("3. In the statement of Conjecture 7.3 on page 41, you are missing one $\\mathbb{R}^{+}$.")

#text("4. The sentence on page 42")

#text("“In [37, Theorem 1.4] it was shown that Conjectures 1.4, 7.2, 7.3.”")

#text("does not make sense grammatically. You meant like Conjectures 1.4, 7.2 and 7.3 are equivalent?")

#text("5. On equation (100) pg. 65, I recognize that as regularized NSE with mollifier; (cf. “Vorticity and Incompressible Flow” by Bertozzi and Majda). Yet, your footnote 20 on page 70 says")

#text("“It may also be possible to use other regularization methods here, such as velocity regularization.”")

#text("Is that not what you did? I am sorry I am confused.")

#text("In this regard, I was wondering. Does this mollifier method work in n-dimensional torus? (because many of your proofs treat both the whole space and torus cases) Does it work in arbitrarily bounded domain?")

#text("6. On page 72, 7th line states “signularity” which must by “singularity.”")

#text("7. On page 76, the last line at bottom says “t=0,1” which I think you mean “i=0,1.”")

#text("8. On page 78, 8th lines has “Lisp-chitz.")

#text("9. On page 79, lines 9-10 states “can thus be extended to single a global smooth…” which you mean “can thus be extended to a single global”")

#text("10. On page 85, third line from bottom has")

#text("“with each $\\epsilon^{(1)}$ sufficiently small depending on the previous $\\epsilon^{(1)}, …, \\epsilon^{(n-1)}$.”")

#text("You mean $\\epsilon^{(n)}$ sufficiently small?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-95802")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2011")])]

#text("Thanks for the corrections!")

#text("By velocity regularisation, I refer to the version of the Navier-Stokes equation in which the transport term ")#mi("(u \\cdot \\nabla) u")#text(" is replaced by ")#mi("((u * \\phi_\\varepsilon) \\cdot \\nabla) u")#text(" for some mollifier ")#mi("\\phi_\\varepsilon")#text(", which is for instance the regularisation used by Caffarelli, Kohn, and Nirenberg. This is a bit different from the hyperdissipation regularisation mentioned in the paper.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08cad85402a66aebdf2f504f1b30de96129fd9ae7a275913af671b67e6378ccf-c8e1820688aec52dd562d1afce8e02d99af4b46af878ba39455ae6fffcf669a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-112516")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2011")])]

#text("Um, this isn’t a solution to the Clay problem. Sorry, and good luck!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cb3280d4a3ac59b59c4cf2c33043f35c9d5c9f277083c51cc4b2e3163aa25a7-6a9cd9f58b7183b2038ce7a394dc5461cc80a5a1b8a2711b65195916592b725c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo de Almeida")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-206837")[#strong[#text("Marcelo de Almeida")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2012")])]

#text("Reblogged this on ")#link("http://nucaltiado.wordpress.com/2012/12/17/372/")[#text("Being simple")]#text(" and commented:")#linebreak()#text(" Good luck, Terry, this is a hard problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cb3280d4a3ac59b59c4cf2c33043f35c9d5c9f277083c51cc4b2e3163aa25a7-6a9cd9f58b7183b2038ce7a394dc5461cc80a5a1b8a2711b65195916592b725c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo de Almeida")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-206838")[#strong[#text("Marcelo de Almeida")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2012")])]

#text("This is a hard problem, good luck Terry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/#comment-480863")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2017")])]

#text("This passage caught my attention: “…if one has a solution which already has some reasonable regularity (e.g. a mild H^1 solution) and the data is Schwartz, then the solution will be smooth in spacetime. (Another class where things work as expected is when the vorticity is Schwartz; in such cases, the solution remains smooth in both space and time (for short times, at least), and the Schwartz nature of the vorticity is preserved…”")

#text("Working out the local existence and regularity in Fourier-domain one finds out that given ")#mi("\\widehat u_0 \\in \\mathcal S(\\mathbb R^3,\\mathbb C^3)")#text(" one has short-time solutions with ")#mi("J^s \\widehat u(t) \\in  C_b^1(\\mathbb R^3\\setminus 0,\\mathbb C^3)")#text(" for arbitrary ")#mi("s \\geq 0")#text(", where ")#tao-math("J(\\xi) = (1+\\left|\\xi\\right|^2)^\\frac{1}{2}", block: false)#text(". Supposedly one can work this out for the vorticity as well but with any ")#mi("C_b^k(\\mathbb R^3,\\mathbb C^3)")#text(" in place of ")#mi("C_b^1(\\mathbb R^3\\setminus 0,\\mathbb C^3)")#text(" as suggested in the passage, but I have not done it nor found a reference in a quick search. It would be nice to see one.")

#text("What bothers me is the lack of derivative at the origin. It seems that the bilinear part of Fourier-transformed NSE does not map Schwartz-class vector fields into vector fields continuously differentiable at the origin. Now, for suitably regular solenoidal vector fields the only components of ")#mi("D\\widehat u(0)")#text(" that are non-zero are the components of $latex\\nabla\\times \\widehat u(0)$, which (up to an imaginary constant ")#mi("i\\rho")#text(") are the components of the total angular momentum of ")#mi("u")#text(". Can it really be so that the conservation of angular momentum breaks up immediately even for Schwartz-class velocity fields?")
]
