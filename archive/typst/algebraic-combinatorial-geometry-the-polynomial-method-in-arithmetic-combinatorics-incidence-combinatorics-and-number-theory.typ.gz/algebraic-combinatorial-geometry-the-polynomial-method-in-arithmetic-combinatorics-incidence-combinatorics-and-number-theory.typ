// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/
// Converted to Typst by tao2typ: "2026-10-14T09:59:57.079465+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Algebraic combinatorial geometry: the polynomial method in arithmetic combinatorics, incidence combinatorics, and number theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Algebraic combinatorial geometry: the polynomial method in arithmetic combinatorics, incidence combinatorics, and number theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 October 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/")[#text("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’ve just uploaded to the arXiv my article “")#link("http://arxiv.org/abs/1310.6482")[#text("Algebraic combinatorial geometry: the polynomial method in arithmetic combinatorics, incidence combinatorics, and number theory")]#text("“, submitted to the new journal “")#link("http://www.ems-ph.org/journals/journal.php?jrn=emss")[#text("EMS surveys in the mathematical sciences")]#text("“. This is the first draft of a survey article on the polynomial method – a technique in combinatorics and number theory for controlling a relevant set of points by comparing it with the zero set of a suitably chosen polynomial, and then using tools from algebraic geometry (e.g. Bezout’s theorem) on that zero set. As such, the method combines algebraic geometry with combinatorial geometry, and could be viewed as the philosophy of a combined field which I dub “algebraic combinatorial geometry”. There is also an important extension of this method when one is working overthe reals, in which methods from algebraic topology (e.g. the ham sandwich theorem and its generalisation to polynomials), and not just algebraic geometry, come into play also.")

#text("The polynomial method has been used independently many times in mathematics; for instance, it plays a key role in the proof of ")#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/")[#text("Baker’s theorem in transcendence theory")]#text(", or ")#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/")[#text("Stepanov’s method in giving an elementary proof of the Riemann hypothesis for finite fields over curves")]#text("; in combinatorics, the ")#link("http://www.ams.org/mathscinet-getitem?mr=1684621")[#text("nullstellenatz of Alon")]#text(" is also another relatively early use of the polynomial method. More recently, it underlies ")#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/")[#text("Dvir’s proof of the Kakeya conjecture over finite fields")]#text(" and ")#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/")[#text("Guth and Katz’s near-complete solution to the Erdos distance problem in the plane")]#text(", and can be used to give a ")#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/")[#text("short proof of the Szemeredi-Trotter theorem")]#text(". One of the aims of this survey is to try to present all of these disparate applications of the polynomial method in a somewhat unified context; my hope is that there will eventually be a systematic foundation for algebraic combinatorial geometry which naturally contains all of these different instances the polynomial method (and also suggests new instances to explore); but the field is unfortunately not at that stage of maturity yet.")

#text("This is something of a first draft, so comments and suggestions are even more welcome than usual. (For instance, I have already had my attention drawn to some additional uses of the polynomial method in the literature that I was not previously aware of.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (22)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-249028")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2013")])]

#text("References:")

#text("* [1], [4]–[5], [7]–[9], [11]–[16], [18], [21]–[23], [30]–[31], [39]–[44], [50]–[51], [53], [57]–[63], [65]–[66], [73]–[75], [78]: An n-dash instead of a hyphen in page range")#linebreak()#text(" * [25], [27], [36], [45], [48], [52], [64], [68], [70], []: The title should be in italic")#linebreak()#text(" * [6]: “T.Tao” –> “T. Tao”")#linebreak()#text(" * [6]: “")#mi("196(2)")#text(" ")#mi("261")#text("—")#mi("302")#text(" ")#mi("(2006)")#text(".” –> “")#mi("\\mathbf{196} (2006)")#text("”, no. ")#mi("2")#text(", ")#mi("261")#text("—")#mi("302")#text(".”")#linebreak()#text(" * [7], [34]: Remove “p.p.”")#linebreak()#text(" * [13]: “R.Seidel” –> “R. Seidel”")#linebreak()#text(" * [13]: “Applications, ")#mi("1(6)")#text(" ")#mi("305")#text("–")#mi("323")#text(" ")#mi("(1992)")#text("” –> “Applications ")#mi("\\mathbf{1} (1992)")#text(", no. ")#mi("6")#text(", ")#mi("305")#text("—")#mi("323")#text(".”")#linebreak()#text(" * [13], [57]: A full stop at the end of the reference")#linebreak()#text(" * [14]: “Universitt” –> “Universit{\\”a}t”")#linebreak()#text(" * [16]: “Dias” –> “D.”")#linebreak()#text(" * [16]: “Soc. ")#mi("26")#text("” –> “Soc. ")#mi("\\mathbf{26}")#text("”")#linebreak()#text(" * [19]: “")#mi("257393")#text("” –> ")#mi("257")#text("—")#mi("393")#linebreak()#text(" * [19]: Is “")#mi("(2012)")#text("” supposed to be there?")#linebreak()#text(" * [20]: “")#mi("181190")#text("” –> “")#mi("181")#text("—")#mi("190")#text("”")#linebreak()#text(" * [33]: “")#mi("1936")#text("” –> “")#mi("(1936)")#text("”")#linebreak()#text(" * [36]: “Publications, ")#mi("53")#text("” –> “Publications ")#mi("\\mathbf{53}")#text("”")#linebreak()#text(" * [43]: The “Gza;” looks `wierd’")#linebreak()#text(" * [50]: “")#mi("(2009/10)")#text("” –> “")#mi("(2009/2010)")#text("”")#linebreak()#text(" * [54]: “")#mi("1969")#text("—")#mi("1970")#text("” –> “")#mi("(1969/1970)")#text("”")#linebreak()#text(" * [56]: “Series A ")#mi("67(1)")#text(" ")#mi("89")#text("—")#mi("99")#text(" ")#mi("(1994)")#text(".” –> “Series A ")#mi("\\mathbf{67} (1994)")#text("”, no. ")#mi("1")#text(", ")#mi("89")#text("—")#mi("99")#text(".”")#linebreak()#text(" * [57]: “Computing ")#mi("13(2)")#text(" ")#mi("203")#text("–")#mi("220")#text(" ")#mi("(2004)")#text("” –> “Computing ")#mi("\\mathbf{13} (2004)")#text("”, no. ")#mi("2")#text(", ")#mi("203")#text("—")#mi("220")#text(".”")#linebreak()#text(" * [74]: “ Soc. ")#mi("55")#text(", ")#mi("(1949)")#text(".” –> “Soc. ")#mi("\\mathbf{55}")#text(" ")#mi("1949")#text(",”")#linebreak()#text(" * [75]: “ pages ")#mi("129")#text("–")#mi("162")#text(", ")#mi("1999")#text("” –> “")#mi("129")#text("—")#mi("162")#text(" ")#mi("(1999)")#text("”")#linebreak()#text(" * [78]: “ pages ")#mi("216")#text("–")#mi("226")#text(", ")#mi("1979")#text("” –> “")#mi("216")#text("—")#mi("226")#text(" ")#mi("(1979)")#text("”")

#text("P.S. I’m not sure it is all correct and that I haven’t missed something.")

#emph[#text("[Thanks! It turns out there were a lot of junk characters in the bibliography which had messed things up, this will be cleaned up in the next revision of the ms. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-249035")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2013")])]

#text("On another note: I normally put")

#text("\\usepackage[bottom,hang,stable]{footmisc}")#linebreak()#text(" \\setlength\\footnotemargin{6pt}")

#text("In the preamble. This givesd a better formatting of the footnotes, I think.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-249038")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2013")])]

#text("* Section 1, l. 5–6: “overlays … on top”. Isn’t this superfluous? (English is not my native language.)")#linebreak()#text(" * P. 2, One line after the first emphasized math expression: “of coeﬃcients” –> “of the coeﬃcients”.")#linebreak()#text(" * P. 2, l. -3: Use “\\colon” instead of “:” for maps. [Two times.]")#linebreak()#text(" * Footnote 3, l. -3: Use “\\colon” instead of “:” for maps. [Two times.]")#linebreak()#text(" * P. 3, l. 9: Should ")#mi("\\overline{F}")#text(" be ")#mi("F")#text("?")#linebreak()#text(" * P. 5, l. -4: Have you used “\\setminus” instead of a backslash? (The spacing indicates that you haven’t but I’m not entirely sure.)")#linebreak()#text(" * P. 6, l. 2: “see e.g.” –> “see, e.g.,”.")#linebreak()#text(" * Proof of Theorem 8, l. 2: Use “\\setminus” instead of a backslash.")#linebreak()#text(" * P. 6, l. -5: Use “\\setminus” instead of a backslash.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-249041")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2013")])]

#text("An idea for typesetting maps is to define a macro, e.g.,")

#text("\\newcommand*\\map[3]{#1 \\colon #2 \\to #3}")

#text("and then use, say,")

#text("\\map{P}{F^n}{F}")

#text("This gives consistency.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-249048")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2013")])]

#text("Section 2:")

#text("* P. 7, one line under (1): “")#mi("i^{th}")#text("” –> “")#mi("i{{}^{\\text{th}}}")#text("”")#linebreak()#text(" * P. 9, Lemma 12, l. 3: “")#mi("+\\cdot")#text("” –> “")#mi("+")#text("” or “")#mi("\\cdot")#text("”")#linebreak()#text(" * Section 2, l. -3: “two: see” –> “two; see”")

#text("P.S. In ")#text("Section 4.6 of “Short Math Guide for ")#mi("\\LaTeX")#text("”")#text(", it is shown how to typeset different types of dots the correct way.")

#emph[#text("[Thanks, this will be corrected in the next revision of the MS- T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-251637")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2013")])]

#text("I just learned of “")#mi("i{{}^{\\text{th}}}")#text(" ($i\\textsuperscript{th}$)” (remember not to use “")#mi("i^{{}^{\\text{th}}}")#text("” ($i^\\textsuperscript{th}$) —that gives double superscript); use this instead.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-249057")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2013")])]

#text("Section 3:")

#text("* P. 12, l. 12: “taht” –> “that”")

#text("Section 4:")

#text("* Proof of Theorem 17, l. -2: Reformulate this sentence to avoid the expression overlapping the margin")#linebreak()#text(" * Proof of Theorem 18, l. -3: Use “\\setminus” instead of a backslash")#linebreak()#text(" * Theorem 19, l. 2: “integers, and” –> “integers and”")#linebreak()#text(" * Theorem 19, l. 2: “")#mi("d_2")#text(" respectively with” –> “`")#mi("d_2")#text(", respectively, with”")#linebreak()#text(" * Proof of Theorem 19, l. 5: “")#mi("d_2")#text(" respectively” –> “`")#mi("d_2")#text(", respectively”")#linebreak()#text(" * P. 16, l. 27: Use “\\colon” instead of a colon")#linebreak()#text(" * Proof of Proposition 21, l. 6: “")#mi("x^{\\prime}-p_2")#text("” –> “")#mi("y^{\\prime}-p_2")#text("”")#linebreak()#text(" * P. 18, l. 9–10: “see e.g.” –> “see, e.g.,”")#linebreak()#text(" * Proof of Lemma 23, l. -5: “most ")#mi("10m")#text(" (say)” –> “most, say, ")#mi("10m")#text("”")#linebreak()#text(" * P. 19, l. 9: “see e.g.” –> “see, e.g.,”")#linebreak()#text(" * P. 19, l. 29 (displayed formula): Use “\\setminus” instead of a backslash")

#text("P.S. As before, I’m not sure it is all correct.")

#emph[#text("[Thanks, these will be corrected in the next revision of the MS- T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bbe9db0ab14b3e57445c86f95bd70cd2ac61995db2ec16890ad224abb5eb4098-f0baaf906845f102349bcd3b927ee61dbd55ae76d90eb0cdbe136986ba3cedbd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-249058")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2013")])]

#text("finite fields over curves …")

#emph[#text("[Thanks, this will be corrected in the next revision of the MS- T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5081916741e2b636195d0f2044e435626baea74a2107b1237975cdd5fdde8564-60b5d99032c0369170389fa96c081c93265fe3506af6e785980d6264748b5c65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-249060")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2013")])]

#text("In Lemma 11 \\sum_{p \\in F^n} {n+p-1\\choose n} —> \\sum_{p \\in F^n} {n+c_p-1\\choose n}")

#emph[#text("[Thanks, this will be corrected in the next revision of the MS- T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66b1a3b5814de2214b88519eabbcee0ba7efe82a4a5ade4acaf62081500b091b-2e21bd0993efcca1c4c5404e8ab3d4b967aecc826e6ee5c9f3721d62fdfd8512.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of NG")]], [#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-249087")[#strong[#text("NG")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2013")])]

#text("It will be very nice to see some open problems/directions in your survey.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed7fe480a3961266e21303169a56485024d3761fdd7df6313fdb8a9c1d61f7a0-75a66dce3db0742badf7bb3b53131cb1c0febb8c669081d6c1961ecdd8c48a16.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felipe Voloch")]], [#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-249156")[#strong[#text("Felipe Voloch")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2013")])]

#text("Have you looked at S. Ball’s proof of the main conjecture for MDS codes over prime fields (J. Eur. Math. Soc., 14 (2012) 733–748. )?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-249278")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2013")])]

#text("Thanks for the link! It is an interesting variant of the polynomial method, being much more algebraic in nature than geometric (one creates various polynomials related to the initial combinatorial structure, by explicitly multiplying together various linear forms, and then performs some algebraic manipulations involving determinants until one arrives at a useful identity, namely that a product of various simple expressions is equal to zero mod p). I wonder if there is a more geometric motivation for Ball’s argument (which I found at ")#link("http://www-ma4.upc.es/~simeon/jems-mds-conj-revised.pdf")[#text("http://www-ma4.upc.es/~simeon/jems-mds-conj-revised.pdf")]#text(" ), which would tie it more closely to the types of polynomial method applications in the survey.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed7fe480a3961266e21303169a56485024d3761fdd7df6313fdb8a9c1d61f7a0-75a66dce3db0742badf7bb3b53131cb1c0febb8c669081d6c1961ecdd8c48a16.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felipe Voloch")]], [#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-249293")[#strong[#text("Felipe Voloch")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2013")])]

#text("Ball’s argument has its origin in Segre’s lemma of tangents, which he used to show that an oval in a plane over a finite field of odd order is a conic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-249380")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2013")])]

#text("That’s a really nice argument (and I’m surprised I didn’t know about it before…). I’m sketching a proof of Segre’s theorem (extracted from the text of Ball and Weiner) here, mostly for my own benefit. The claim that is if F is a field of odd order q, and O is an oval (a set of q+1 points in the projective plane ")#mi("PF^2")#text(" such that no three points are collinear), then O is a conic. The first observation is that for every point A on O, there is exactly one “tangent line” ")#mi("l_A")#text(" through A that does not meet any other point of O; the other q lines through A meet exactly one other point of O. Now, if O were a conic, and A,B,C were distinct points on O, then there would be a non-trivial algebraic constraint (depending on A,B,C) connecting the slopes of the lines l_A, l_B, l_C (because the space of conics is five-dimensional, so the space of conics passing through A,B,C is two-dimensional, whereas the space of slopes of l_A,l_B,l_C is three-dimensional if unconstrained). Call this constraint (*). Segre’s lemma of tangents is the assertion that the constraint (*) holds for any oval O. If A,B,C,D are four points in O, one can apply (*) to the triples (A,B,D), (A,C,D), and (B,C,D), and end up (after some linear algebra) constraining D (and l_D) in terms of A,B,C, l_A, l_B, l_C, which ends up placing D on a conic as required.")

#text("It remains to prove (*). For every point D on O not equal to A,B,C, the lines AD, BD, CD are concurrent; applying Ceva’s theorem, one obtains a constraint of the form f(AD) g(BD) h(CD) = 1. Multiplying this over all possible D, and comparing to the product of all possible values of f,g,h, one ends up with a constraint on f(l_A) g(l_B) h(l_C) which ends up being exactly (*) (as it must, since conics are ovals).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6def420a06fd003a9920717079f6c46bf7c0e7ef4e32038aee8d7cd9e725d256-d4be4d5b498d24884b0a2d9ffceae8db9e1f471279e0383dba37bb9dda8dd0b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anurag Bishnoi")]], [#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-460847")[#strong[#text("Anurag Bishnoi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2015")])]

#text("Dear Terence Tao,")

#text("On page 9 of the final published version of your survey, you have mentioned “See [5] for some of the recent developments associated to Segre’s theorem.”, but the reference [5] is to the notes of Ball and Weiner. Shouldn’t it be to the paper of Ball on MDS conjecture?")

#text("S. Ball, On sets of vectors of a finite vector space in which every subset of basis size is a basis. J. Eur. Math. Soc. 14(3) (2012), 733–748.")

#emph[#text("[The lecture notes of Ball and Weiner covers this result as well as other aspects of Segre’s theorem. -T.]")]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-251299")[#strong[#text("About this blog and its author – Andreea's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2013")]

#text("[…] Algebraic combinatorial geometry: the polynomial method in arithmetic combinatorics, incidence combi… (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/07a7ff91b522bd7e3d602d732862da024ca4139da9b2c9c501209e58c172fe3f-3d62c9479bfbdbb2f0dea100b15ffb0ef7ef841b2b446f14120e79e1bc868c13.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Combinatorial Nullstellensatz | Eventually Almost Everywhere")]], [#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-253015")[#strong[#text("The Combinatorial Nullstellensatz | Eventually Almost Everywhere")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("[…] Algebraic combinatorial geometry: the polynomial method in arithmetic combinatorics, incidence combi… (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stickiness, graininess, planiness, and a sum-product approach to the Kakeya problem | What's new")]], [#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-327190")[#strong[#text("Stickiness, graininess, planiness, and a sum-product approach to the Kakeya problem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2014")])]

#text("[…] Finally, in 2009, Dvir used route (a) and introduced the polynomial method (as discussed previously here) to completely settle the Kakeya conjecture in finite […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The subspace theorem approach to Siegel’s theorem on integral points on curves via nonstandard analysis | What's new")]], [#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-388662")[#strong[#text("The subspace theorem approach to Siegel’s theorem on integral points on curves via nonstandard analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2014")])]

#text("[…] now use a version of the polynomial method, to find some polynomials of controlled degree that vanish to high order on the “arm” […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6def420a06fd003a9920717079f6c46bf7c0e7ef4e32038aee8d7cd9e725d256-d4be4d5b498d24884b0a2d9ffceae8db9e1f471279e0383dba37bb9dda8dd0b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anurag Bishnoi")]], [#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-451030")[#strong[#text("Anurag Bishnoi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2015")])]

#text("Another example of the polynomial method that you might have missed: ")#link("http://www-ma4.upc.es/~simeon/lacunary4.pdf")[#text("http://www-ma4.upc.es/~simeon/lacunary4.pdf")]

#text("I am no expert on blocking sets and I haven’t gone through the full paper. So, you might want to get in touch with Simeon Ball for such applications of the polynomial method in finite geometry.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6def420a06fd003a9920717079f6c46bf7c0e7ef4e32038aee8d7cd9e725d256-d4be4d5b498d24884b0a2d9ffceae8db9e1f471279e0383dba37bb9dda8dd0b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anurag Bishnoi")]], [#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-451031")[#strong[#text("Anurag Bishnoi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2015")])]

#text("Here’s a survey on direction problems in finite affine spaces and the use of polynomial method to solve them: ")#link("http://arxiv.org/abs/1409.6960")[#text("http://arxiv.org/abs/1409.6960")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6def420a06fd003a9920717079f6c46bf7c0e7ef4e32038aee8d7cd9e725d256-d4be4d5b498d24884b0a2d9ffceae8db9e1f471279e0383dba37bb9dda8dd0b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anurag Bishnoi")]], [#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/#comment-453300")[#strong[#text("Anurag Bishnoi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2015")])]

#text("Probably one of the oldest use of polynomial methods in incidence problems is in these papers “The blocking number of an affine space” by Brouwer and Schrijver (1978), and “Covering finite fields with cosets of subspaces” by R. E. Jamison (1977). In fact, one can prove Chevalley’s theorem from this result in the Brouwer-Schriver paper: Let $P$ be a polynomial with $P(0) \\neq 0$ and $P(a) = 0$ for every other $a$ in $F^n$, then the degree of $P$ is at least $n(|F| – 1)$.")
]
