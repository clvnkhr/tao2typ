// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/
// Converted to Typst by tao2typ: "2026-10-14T11:06:52.084419+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Registration for the virtual ICM is now open", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Registration for the virtual ICM is now open")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 June 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/")[#text("https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The (now virtual) ")#link("https://www.mathunion.org/icm/virtual-icm-2022")[#text("2022 International Congress of Mathematicians")]#text(", which will be held on July 6-14, now has ")#link("https://react.regasus.de/portal/init?mnemonic=ICM22Profile")[#text("open registration")]#text(" (free of charge).")

#text("I’ll also take this opportunity to mention that there are a large number of supporting satellite events for the virtual ICM, which are listed on ")#link("https://www.hairer.org/ICMSCG/")[#text("this web page")]#text(". I’d like to draw particular attention to the public lecture satellite event, now hosted by the London Mathematical Society, that will feature three speakers:")

#list(
[#text("Friday 8 July: ")#link("https://www.lms.ac.uk/events/vICM-Satellite-Event-Public-Lecture-by-Geordie-Williamson-%28Sydney%29")[#text("Geordie Williamson")]],
[#text("Monday 11 July: ")#link("https://www.lms.ac.uk/events/vICM-Satellite-Event-Public-Lecture-by-Eleni-Giorgi-Colombia")[#text("Elena Giorgi")]],
[#text("Wednesday 13 July:")#link("https://www.lms.ac.uk/events/vICM-Satellite-Event-Public-Lecture-by-Tadashi-Tokieda-Stanford")[#text(" Tadashi Tokieda")]]
)

#text("(As with many other of the satellite events, these public lectures will require a separate registration from that of the main ICM.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7fc5c663d4b450e76bbaad5d3884a418adf7b7cc59f790ed7c57469c0264238d-2918cc67bf124684786b80e999459f090e4a1fb08a3334eb138ce89f3e2fc993.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of niuhufeng")]], [#link("https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/#comment-644287")[#strong[#text("niuhufeng")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2022")])]

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/874f78e0ba91b573de7f3df2cc5c948f745d27bbe35213e2796f97988db9e856-b4505615d30499a0c0cfaf58fe50dc8496a525bfc17ef7e3a6a0d4c008ce9f78.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mooeamonn")]], [#link("https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/#comment-644290")[#strong[#text("mooeamonn")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2022")])]

#text("The link to the Tadashi Tokieda talk is incorrect (it is pointing at the Elena Giorgi talk)")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb7d193d364460249f1de7e0091db38263701aed680df68e429eb57bdaa3adc5-51a01dc3aba9d5b6664da7f8266cbc44e9ff7242a2bb726df7d3cc20be9478c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vishal Mudgal")]], [#link("https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/#comment-645405")[#strong[#text("Vishal Mudgal")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2022")])]

#text("Prof. Tao,")

#text("Any chance for the non-academicians to present their research during ICM? Wanted to present the method of factorizing integers by addition, a.k.a deltasieve, also available at ")#link("https://deltasieve.org")[#text("https://deltasieve.org")]

#text("Regards,")#linebreak()#text(" Vishal")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/#comment-644291")[#strong[#text("Registration for the virtual ICM is now open – Marxist Statistics")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2022")]

#text("[…] Registration for the virtual ICM is now open […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/#comment-644311")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2022")])]

#text("I’m curious to know if there are abstracts for at least the plenary talks. I cannot see an obvious link to this information, nor even the titles of their talks. I have a vague memory this was on the icm2022 website, which seems to have gone away (or at least, Google doesn’t show it to me in the first few pages of results).")

#emph[#text("[These will most likely become available as one gets closer to the actual event. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/#comment-644314")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2022")])]

#text("I love math! I love QED!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/#comment-644315")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2022")])]

#text("So do I!!!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/#comment-644323")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2022")])]

#text("Haven’t watched Tadashi’s referenced talk yet, but I viewed other talks your link led me to. He is wonderful at communicating his infectious curiosity. Thanks for the pointer!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/#comment-644646")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2022")])]

#text("Does anyone know where the broadcast this year is?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/#comment-644692")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2022")])]

#text("Dr. Tao:")

#text("Are there any satellite/regional events that are in the pacific time zone? There seems to be none listed.")

#emph[#text("[The list at ")#link("https://www.hairer.org/ICMSCG/")[#text("https://www.hairer.org/ICMSCG/")]#text(" will contain the most up to date information of all events that we are aware of. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/#comment-644870")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2022")])]

#text("Dear, dear and dear pro.Tao,")#linebreak()#text(" Today, I sincerely apologize for going to your post to send a few words. A few months ago, you posted ” a math rave” , but honestly I am the most passionate about math in the world eventhough I am not a mathematician. This year, your math speed has slowed down because you are too busy with big tasks. When I was a child, I admired Einstein and Newton, but now I not only admire you")#linebreak()#text(" but also like you. If compare talent, 3 people are the same. But you have something special that other two greats never had. For this reason, I was moved and cried when I saw a song about you of Thomas Conway on youtube. Because it was true to my prediction a few years ago. By the way, I want to add that I also accurately predict many other things such as weather forecasts,human epidemics, sports, lottery, exam, soccer and countless other thing. I am not proud of myself, but I am still better than wizards and prophets. All mankind noone knows you except me. I know you have two big projects of the world and you are about to succeed 99,99%. Believe in yourself and I trust you to succeed. I never say anything wrong, only I understand you. If that does not happen, then your name will be meaningless. And for me if this is true, then I am nolonger me, and you are nolonger you.")#linebreak()#text(" ” A sudden breeze blew through”")#linebreak()#text(" Bye,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/169dddd274a21332916d51063a019c351949e0c3458fda11a2edf595e3d44f4f-6ecf536adcf22125b895eb1be4d39c722c9f33a6d4afedbd65ace37c327a3333.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anya Nordskova")]], [#link("https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/#comment-645329")[#strong[#text("Anya Nordskova")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2022")])]

#text("Dear Professor Tao,")

#text("It’s a pity that whoever manages the website cannot spell the names of the plenary speakers correctly. Maybe you know who to contact regarding this. E.g. should be “Van den Bergh” instead of “van den Berg” here. ")#link("https://icm2022.abstractserver.com/program/#/details/sessions/39")[#text("https://icm2022.abstractserver.com/program/#/details/sessions/39")]#text(" Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/#comment-645338")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2022")])]

#text("Dear Prof. Tao:")#linebreak()#text(" 1) Will all the presentations be posted on line later, or one has to attend in real time?")#linebreak()#text(" 2) How would graduate students attend the Virtual ICM? There are too many talks to choose, any suggestions?")#linebreak()#text(" 3) Why does ICM have such a bad reputation? I am not familiar with the history, but there are lots of criticism of the ICM on line.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/#comment-645385")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2022")])]

#text("Dr. Tao:")#linebreak()#text(" A question comes to mind about presentations by young researchers (grad. students and PDFs). How many times can the person present his/her work at a conference? Does it have an expiration date? It seems reasonable to present the same work at different conferences in a year, as long as it is accepted. But can or should someone present the work that is kind of old?")#linebreak()#text(" Since the ICM will go virtual this year, there is no need for students to apply for funding to attend, thus no need to present their work either. Can they present their work next time, like 4 years later?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/744af6de8cc8d5fa42cf0dbd096e88eef82f4b51081b78514bff85bf909eab07-d4d0b110ce3d5330716c189c6d455c2cd768a34ab962b2a8c3755b79505fb788.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of grpaseman")]], [#link("https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/#comment-645451")[#strong[#text("grpaseman")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2022")])]

#text("As co-organizer of the SCS 2022, we would welcome recent work in the form of short communications. I invite you to visit the virtual poster room during the vICM (no need to register to look). If you want to support such efforts, give feedback and consider becoming a member of the next satellite (Registration for this satellite is closed.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa64c9c253f65a7d9cc17341c4b22ebef482e1440374dcc9f37da48992a6c01-adae0e3099b1eca8bd0752161d24380b97aab9790b1fa32b2687d7d9e5d3dd74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Asimov")]], [#link("https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/#comment-645448")[#strong[#text("Dan Asimov")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2022")])]

#text("The ICM 2022 website now says there are no more spots for virtual registration available.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c4e6eedfb5a83ec41e37056f0d97f3d3ca44e4fbab5e7916bc6f537ce7758fc-6f6d9683c4eea1a2cc9006791c56eaf659f1f426fa2df727faa455f5abb46bb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Silverman")]], [#link("https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/#comment-645468")[#strong[#text("Robert Silverman")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2022")])]

#text("Query: Did the organizers consider that a DOS attack might be possible?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ICM and IMU award ceremony begins tomorrow | What's new")]], [#link("https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/#comment-645889")[#strong[#text("ICM and IMU award ceremony begins tomorrow | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2022")])]

#text("[…] We have an unofficial ICM Discord server set up to follow the virtual ICM as it happens, with events set up for the prize ceremony and individual days of the congress, as well as for individual sections, as well as more recreational channels, such as a speculation page for the IMU prize winners. There are also a number of other virtual ICM satellite events that are being held either simultaneously with, or close to, the virtual ICM; I would like to draw particular attention to the satellite public lectures by Williamson (July 8), Giorgi (July 11), and Tokieda (July 13), which was also highlighted in my previous blog post. […]")
]
