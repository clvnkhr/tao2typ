// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/
// Converted to Typst by tao2typ: "2026-10-14T15:18:33.044818+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Harish-Chandra-Itzykson-Zuber integral formula", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Harish-Chandra-Itzykson-Zuber integral formula")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 February 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/")[#text("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{A, B}")#text(" be ")#mi("{n \\times n}")#text(" Hermitian matrices, with eigenvalues ")#mi("{\\lambda_1(A) \\leq \\ldots \\leq \\lambda_n(A)}")#text(" and ")#mi("{\\lambda_1(B) \\leq \\ldots\\leq \\lambda_n(B)}")#text(". The ")#link("http://www.ams.org/mathscinet-getitem?mr=84104")[#text("Harish-Chandra")]#text("–")#link("http://www.ams.org/mathscinet-getitem?mr=562985")[#text("Itzykson-Zuber")]#text(" integral formula exactly computes the integral")

#align(center)[#tao-fit-display[#mitex("\\int_{U(n)} \\exp( t \\text{tr}( A U B U^* ) )\\ dU")]]

#text("where ")#mi("{U}")#text(" is integrated over the Haar probability measure of the unitary group ")#mi("{U(n)}")#text(" and ")#mi("{t}")#text(" is a non-zero complex parameter, as the expression")

#align(center)[#tao-fit-display[#mitex("c_n \\frac{ \\det( \\exp( t \\lambda_i(A) \\lambda_j(B) ) )_{1 \\leq i,j \\leq n} }{t^{(n^2-n)/2} \\Delta(\\lambda(A)) \\Delta(\\lambda(B))}")]]

#text("when the eigenvalues of ")#mi("{A,B}")#text(" are simple, where ")#mi("{\\Delta}")#text(" denotes the Vandermonde determinant")

#align(center)[#tao-fit-display[#mitex("\\Delta(\\lambda(A)) := \\prod_{1 \\leq i<j \\leq n} (\\lambda_j(A) - \\lambda_i(A))")]]

#text("and ")#mi("{c_n}")#text(" is the constant")

#align(center)[#tao-fit-display[#mitex("c_n := \\prod_{i=1}^{n-1} i!.")]]

#text("There are at least two standard ways to prove this formula in the literature. One way is by applying the ")#link("http://en.wikipedia.org/wiki/Duistermaat%E2%80%93Heckman_formula")[#text("Duistermaat-Heckman theorem")]#text(" to the pushforward of ")#link("http://en.wikipedia.org/wiki/Liouville_measure")[#text("Liouville measure")]#text(" on the coadjoint orbit ")#mi("{{\\mathcal O}_B := \\{ UBU^*: U \\in U(n) \\}}")#text(" (or more precisely, a rotation of such an orbit by ")#mi("{i}")#text(") under the ")#link("http://en.wikipedia.org/wiki/Moment_map")[#text("moment map")]#text(" ")#mi("{M \\mapsto \\text{diag}(M)}")#text(", and then using a stationary phase expansion. Another way, which I only learned about recently, is to use the formulae for evolution of eigenvalues under Dyson Brownian motion (as well as the closely related formulae for the GUE ensemble), which were derived in ")#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/")[#text("this previous blog post")]#text(". Both of these approaches can be found in several places in the literature (the former being observed in the ")#link("http://www.ams.org/mathscinet-getitem?mr=674406")[#text("original paper of Duistermaat and Heckman")]#text(", and the latter observed in ")#link("http://www.ams.org/mathscinet-getitem?mr=562985")[#text("the paper of Itzykson and Zuber")]#text(" as well as in ")#link("http://www.ams.org/mathscinet-getitem?mr=1810949")[#text("this later paper of Johansson")]#text("), but I thought I would record both of these here for my own benefit.")

#text("The Harish-Chandra-Itzykson-Zuber formula can be extended to other compact Lie groups than ")#mi("{U(n)}")#text(". At first glance, this might suggest that these formulae could be of use in the study of the GOE ensemble, but unfortunately the Lie algebra associated to ")#mi("{O(n)}")#text(" corresponds to real ")#emph[#text("anti-symmetric")]#text(" matrices rather than real symmetric matrices. This also occurs in the ")#mi("{U(n)}")#text(" case, but there one can simply multiply by ")#mi("{i}")#text(" to rotate a complex skew-Hermitian matrix into a complex Hermitian matrix. This is consistent, though, with the fact that the (somewhat rarely studied) anti-symmetric GOE ensemble has cleaner formulae (in particular, having a determinantal structure similar to GUE) than the (much more commonly studied) symmetric GOE ensemble.")

#metadata(none) <tao-0108e600637dd723e48f>

#heading(level: 1)[#strong[#text(" — 1. Dyson Brownian motion argument — ")]]

#text("Let ")#mi("{V_n}")#text(" denote the space of ")#mi("{n \\times n}")#text(" Hermitian matrices. We place a Haar measure ")#mi("{dM_n}")#text(" on this space; the exact normalisation of this measure will ultimately not be relevant (it will create a number of factors which will eventually cancel each other out). Define an ")#emph[#text("invariant function")]#text(" on ")#mi("{V_n}")#text(" to be a function ")#mi("{F: V_n \\rightarrow {\\bf C}}")#text(" which is invariant with respect to conjugations, thus ")#mi("{f( UAU^* ) = f(A)}")#text(" for all ")#mi("{A \\in V_n}")#text(" and ")#mi("{U \\in U(n)}")#text(". Thus the value ")#mi("{f(A)}")#text(" of an invariant function at a Hermitian matrix ")#mi("{A \\in V_n}")#text(" depends only on the eigenvalues ")#mi("{\\lambda_1(A) \\leq \\ldots \\leq \\lambda_n(A)}")#text(", and so by abuse of notation we may write")

#align(center)[#tao-fit-display[#mitex("f(A) = f( \\lambda(A) )")]]

#text("where ")#mi("{f: {\\bf R}^n_{\\leq} \\rightarrow {\\bf C}}")#text(" is now a function on the ")#emph[#text("Weyl chamber")]

#align(center)[#tao-fit-display[#mitex("{\\bf R}^n_\\leq := \\{ (\\lambda_1,\\ldots,\\lambda_n) \\in {\\bf R}^n: \\lambda_1 \\leq \\ldots\\leq\\lambda_n \\}.")]]

#text("By the Riesz representation theorem, there must be some density function ")#mi("{w: {\\bf R}^n_{\\leq} \\rightarrow {\\bf R}^+}")#text(" with the property that")

#align(center)[#tao-fit-display[#mitex("\\int_{V_n} f(M_n)\\ dM_n = \\int_{{\\bf R}^n_\\leq} f(\\lambda) w(\\lambda)\\ d\\lambda")]]

#text("where ")#mi("{d\\lambda}")#text(" is Lebesgue measure on ")#mi("{{\\bf R}^n_\\leq}")#text(", and ")#mi("{f}")#text(" is an invariant function with sufficient regularity and decay (e.g. smooth and exponentially decaying will certainly suffice). To compute this density function, we can exploit the explicit formulae for the GUE ensemble. As discussed in ")#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/")[#text("this previous blog post")]#text(", the GUE ensemble is a probability measure on ")#mi("{V_n}")#text(" with probability density")

#align(center)[#tao-fit-display[#mitex("C_n \\exp( - \\text{tr}(M_n^2)/2 )\\ dM_n")]]

#text("for some normalisation constant ")#mi("{C_n>0}")#text(" (the exact choice of which depends on how one normalised ")#mi("{dM_n}")#text("), and the eigenvalues of GUE have the probability density")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{(2\\pi)^{n/2} c_n} \\Delta_n(\\lambda)^2 \\exp( - \\left|\\lambda\\right|^2/2 )\\ d\\lambda.", block: true)]]

#text("Computing the expectation of ")#mi("{f(M_n)}")#text(" for a GUE matrix ")#mi("{M_n}")#text(" using these formulae for an invariant function ")#mi("{f}")#text(" with sufficient regularity and decay, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_{V_n} f(M_n) C_n \\exp( - \\text{tr}(M_n^2)/2 )\\ dM_n")]]

#align(center)[#tao-fit-display[#tao-math("= \\int_{{\\bf R}^n_\\leq} f(\\lambda) \\frac{1}{(2\\pi)^{n/2} c_n} \\Delta_n(\\lambda)^2 \\exp( - \\left|\\lambda\\right|^2/2 )\\ d\\lambda,", block: true)]]

#text("and hence (since ")#tao-math("{\\text{tr}(M_n^2) = \\left|\\lambda(M_n)\\right|^2}", block: false)#text(")")

#align(center)[#tao-fit-display[#mitex("w(\\lambda) = \\frac{1}{C_n (2\\pi)^{n/2} c_n} \\Delta_n(\\lambda)^2")]]

#text("and so ")#metadata(none) <tao-5e0cf7bd1dfa3831788b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\int_{V_n} f(M_n)\\ dM_n = \\frac{1}{C_n (2\\pi)^{n/2} c_n} \\int_{{\\bf R}^n_\\leq} f(\\lambda) \\Delta_n(\\lambda)^2\\ d\\lambda")]]



#text(" for any invariant function ")#mi("{f}")#text(" with sufficient regularity and decay.")

#text("Now let ")#mi("{f, g}")#text(" be two invariant functions with sufficient regularity and decay to justify all the computations that follow, let ")#mi("{t}")#text(" be a positive real number, and consider the integral ")#metadata(none) <tao-c08c0d279a7fc15dcb16>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\int_{V_n} \\int_{V_n} f(A) g(B) \\frac{C_n}{t^{n^2/2}} \\exp( - \\text{tr}( (A-B)^2/2t ) )\\ dA dB")]]



#text(" which is the bilinear form associated to the heat flow on ")#mi("{V_n}")#text(" for time ")#mi("{t}")#text(". We will evaluate this integral in two different ways. On the one hand, we can expand the integral as")

#align(center)[#tao-fit-display[#mitex("\\frac{C_n}{t^{n^2/2}} \\int_{V_n} \\int_{V_n} f_t(A) g_t(B) \\exp( \\text{tr}(AB)/t) \\ dA dB")]]

#text("where ")#mi("{f_t(A) := \\exp(-\\text{tr}(A^2)/2t) f(A)}")#text(" and ")#mi("{g_t(B) := \\exp(-\\text{tr}(B^2)/2t) g(B)}")#text(". Next, conjugating ")#mi("{B}")#text(" by an arbitrary unitary matrix ")#mi("{U}")#text(" and then integrating over Haar measure on ")#mi("{U(n)}")#text(", we can rewrite this as")

#align(center)[#tao-fit-display[#mitex("\\frac{C_n}{t^{n^2/2}} \\int_{V_n} \\int_{V_n} f_t(A) g_t(B) K_t(A,B) \\ dA dB")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("K_t(A,B) := \\int_{U(n)} \\exp( \\text{tr}(AUBU^*)/t)\\ dU.")]]

#text("The expression ")#mi("{K_t}")#text(" invariant in both ")#mi("{A}")#text(" and ")#mi("{B}")#text(", so by two applications of ")#link(<tao-5e0cf7bd1dfa3831788b>)[#text("(1)")]#text(" we can thus write ")#link(<tao-c08c0d279a7fc15dcb16>)[#text("(2)")]#text(" as ")#metadata(none) <tao-46d041b5eaeaf9c5723e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\frac{1}{C_n (2\\pi)^n c_n^2 t^{n^2/2}} \\int_{{\\bf R}^n_\\leq} \\int_{{\\bf R}^n_\\leq} f_t(\\lambda) g_t(\\nu) K_t(\\lambda,\\nu) \\Delta_n(\\lambda)^2 \\Delta_n(\\nu)^2\\ d\\lambda d\\nu.")]]



#text(" Now we compute ")#link(<tao-c08c0d279a7fc15dcb16>)[#text("(2)")]#text(" another way. For fixed ")#mi("{B}")#text(", the integral")

#align(center)[#tao-fit-display[#mitex("\\int_{V_n} f(A) \\frac{C_n}{t^{n^2/2}} \\exp( - \\text{tr}( (A-B)^2/2t ) )\\ dA")]]

#text("can be interpreted as the expectation of ")#mi("{f( B + t^{1/2} G )}")#text(" where ")#mi("{G}")#text(" is a copy of GUE. By the Brezin-Hikami-Johansson formula (see Theorem 7 of ")#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/")[#text("these notes")]#text("), the eigenvalues of ")#mi("{B+t^{1/2} G}")#text(" are distributed according to the density")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{(2\\pi t)^{n/2}} \\frac{\\Delta_n(\\lambda)}{\\Delta_n(\\lambda(B))} \\det( \\exp( - (\\lambda_i - \\lambda_j(B))^2/2t )_{1 \\leq i,j \\leq n}\\ d\\lambda")]]

#text("and so the previous integral can be written as")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n_\\leq} f(\\lambda) \\frac{1}{(2\\pi t)^{n/2}} \\frac{\\Delta_n(\\lambda)}{\\Delta_n(\\lambda(B))} \\det( \\exp( - (\\lambda_i - \\lambda_j(B))^2/2t )_{1 \\leq i,j \\leq n}\\ d\\lambda.")]]

#text("(Note: in ")#link("http://www.ams.org/mathscinet-getitem?mr=1810949")[#text("the paper of Johansson")]#text(", two proofs of the Brezin-Hikami-Johansson formula were given; one via the Harish-Chandra-Itzykson-Zuber formula discussed in this post, and the other via solving the equations of Dyson Brownian motion. The former proof of course cannot be invoked here as it would be circular, but the latter proof, which is the one used in the notes linked to above, can be used without risk of circularity.)")

#text("Integrating the above formula against ")#mi("{g(B)}")#text(" and then using ")#link(<tao-5e0cf7bd1dfa3831788b>)[#text("(1)")]#text(", we may thus write ")#link(<tao-c08c0d279a7fc15dcb16>)[#text("(2)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n_\\leq} \\int_{{\\bf R}^n_\\leq} f(\\lambda) g(\\nu) \\frac{1}{(2\\pi t)^{n/2}} \\frac{\\Delta_n(\\lambda)}{\\Delta_n(\\nu)} \\det( \\exp( - (\\lambda_i - \\nu_j)^2/2t )_{1 \\leq i,j \\leq n}")]]

#align(center)[#tao-fit-display[#mitex("\\frac{1}{C_n (2\\pi)^{n/2}c_n} \\Delta_n(\\nu)^2\\ d\\lambda d\\nu.")]]

#text("Comparing this against ")#link(<tao-46d041b5eaeaf9c5723e>)[#text("(3)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\exp(-\\lambda^2/2t - \\nu^2/2t) K_t(\\lambda,\\nu) = c_n t^{(n^2-n)/2} \\frac{\\det( \\exp( - (\\lambda_i - \\nu_j)^2/2t )_{1 \\leq i,j \\leq n}}{\\Delta_n(\\lambda)\\Delta_n(\\nu)}")]]

#text("and so")

#align(center)[#tao-fit-display[#mitex("\\int_{U(n)} \\exp( \\text{tr}(AUBU^*)/t)\\ dU = c_n t^{(n^2-n)/2} \\frac{\\det( \\exp( \\lambda_i \\nu_j/t )_{1 \\leq i,j \\leq n}}{\\Delta_n(\\lambda)\\Delta_n(\\nu)}.")]]

#text("This equation was derived for all positive real ")#mi("{t}")#text(", but by analytic continuation it is then true for all non-zero complex ")#mi("{t}")#text(". Replacing ")#mi("{t}")#text(" by ")#mi("{1/t}")#text(" we obtain the Harish-Chandra-Itzykson-Zuber integral formula.")

#heading(level: 1)[#strong[#text(" — 2. The Duistermaat-Heckman theorem — ")]]

#text("The Duistermaat-Heckman theorem concerns a significantly more general situation than the one appearing in the Harish-Chandra-Itzykson-Zuber integral formula, namely that of a symplectic manifold with a torus action that is associated to a moment map. To describe this theorem, it is simplest to begin with the one-dimensional setting of Hamiltonian circle actions on a symplectic manifold. (I will assume here some familiarity with differential forms on smooth manifolds, and also freely use infinitesimals in place of more traditional calculus notation at times.)")

#text("Recall that a ")#link("http://en.wikipedia.org/wiki/Symplectic_manifold")[#text("symplectic manifold")]#text(" ")#mi("{M = (M,\\omega)}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Smooth_manifold")[#text("smooth manifold")]#text(" ")#mi("{M}")#text(" equipped with a ")#link("http://en.wikipedia.org/wiki/Symplectic_form")[#text("symplectic form")]#text(" ")#mi("{\\omega}")#text(", that is to say a smooth anti-symmetric two-form ")#mi("{\\omega \\in \\Gamma(\\bigwedge^2 TM^*)}")#text(" on ")#mi("{M}")#text(" which is both non-degenerate (thus ")#mi("{\\iota_X \\omega(x) \\neq 0}")#text(" whenever ")#mi("{X}")#text(" is a vector field that is non-vanishing at ")#mi("{x}")#text(") and closed (thus ")#mi("{d\\omega = 0}")#text("). Symplectic manifolds are necessarily even dimensional (because odd-dimensional anti-symmetric real matrices automatically have a zero eigenvalue and are thus degenerate). If ")#mi("{(M,\\omega)}")#text(" is a ")#mi("{2n}")#text("-dimensional manifold, the ")#link("http://en.wikipedia.org/wiki/Liouville_measure")[#text("Liouville measure")]#text(" on that manifold is defined as the ")#link("http://en.wikipedia.org/wiki/Volume_form")[#text("volume form")]#text(" ")#mi("{\\omega^n/n!}")#text(", where we use ")#mi("{\\omega^n}")#text(" to denote the ")#mi("{n}")#text("-fold wedge product of ")#mi("{\\omega}")#text(" with itself, and (by abuse of notation) we identify volume forms with measures. (Note that wedge product is a commutative operation on even-order forms such as ")#mi("{\\omega}")#text(".)")

#text("Given a smooth function ")#mi("{H: M \\rightarrow {\\bf R}}")#text(" on a symplectic manifold (called the ")#link("http://en.wikipedia.org/wiki/Hamiltonian_function#Mathematical_formalism")[#text("Hamiltonian")]#text("), one can associate the ")#link("http://en.wikipedia.org/wiki/Hamiltonian_vector_field")[#text("Hamiltonian vector field")]#text(" ")#mi("{X = X_H \\in \\Gamma(TM)}")#text(", defined by requiring that")

#align(center)[#tao-fit-display[#mitex("\\iota_X \\omega = dH")]]

#text("or in other words that ")#metadata(none) <tao-2e37c8a01fb4b41fc028>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\omega(X,Y) = dH(Y) = \\nabla_Y H")]]



#text(" for all smooth vector fields ")#mi("{Y}")#text(". From the non-degeneracy of ")#mi("{\\omega}")#text(", we see that ")#mi("{X}")#text(" vanishes precisely at the critical (or stationary) points of the Hamiltonian ")#mi("{H}")#text(".")

#text("From the ")#link("http://en.wikipedia.org/wiki/Lie_derivative#The_Lie_derivative_of_differential_forms")[#text("Cartan formula")]#text(" ")#metadata(none) <tao-9b3fea8ad52e1f62033b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("{\\mathcal L}_X \\omega = \\iota_X d\\omega + d(\\iota_X \\omega)")]]



#text(" for the ")#link("http://en.wikipedia.org/wiki/Lie_derivative")[#text("Lie derivative")]#text(" of a form ")#mi("{\\omega}")#text(" along a vector field ")#mi("{X}")#text(", we see in the case of the symplectic form ")#mi("{\\omega}")#text(" and Hamiltonian vector field ")#mi("{H}")#text(" that")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L}_X \\omega = \\iota_X 0 + d( dH ) = 0")]]

#text("and so the symplectic form ")#mi("{\\omega}")#text(" is preserved by the vector field ")#mi("{X}")#text(". From the product rule we conclude that Liouville measure is also preserved, a fact known as ")#link("http://en.wikipedia.org/wiki/Liouville%27s_theorem_(Hamiltonian)")[#text("Liouville’s theorem")]#text(" in Hamiltonian mechanics:")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L}_X \\frac{\\omega^n}{n!} = 0.")]]

#text("We can ")#link("http://en.wikipedia.org/wiki/Exponential_map")[#text("exponentiate")]#text(" the Hamiltonian vector field to obtain a one-parameter group ")#mi("{\\rho(t): M \\rightarrow M}")#text(" of smooth maps for ")#mi("{t \\in {\\bf R}}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\rho(t) x := e^{tX} x.")]]

#text("This is a smooth action of the additive group ")#mi("{{\\bf R}}")#text(", and by the preceding discussion, these maps are ")#link("http://en.wikipedia.org/wiki/Symplectomorphism")[#text("symplectomorphisms")]#text(" and in particular preserve Liouville measure, thus one can think of ")#mi("{\\rho}")#text(" as a homomorphism from ")#mi("{{\\bf R}}")#text(" to the symplectomorphism group ")#mi("{Symp(M)}")#text(" of ")#mi("{M}")#text(".")

#text("Now suppose that ")#mi("{M}")#text(" is compact, so that the Liouville measure is finite. We can then ")#link("http://en.wikipedia.org/wiki/Pushforward_measure")[#text("pushforward")]#text(" Liouville measure ")#mi("{\\frac{\\omega^n}{n!}}")#text(" by the Hamiltonian to create a measure ")#mi("{H_* \\frac{\\omega^n}{n!}}")#text(" on ")#mi("{{\\bf R}}")#text(", which we will call the ")#emph[#text("Duistermaat-Heckman measure")]#text(" associated to this Hamiltonian. At present, the Hamiltonian can be an arbitrary smooth function, and so the Duistermaat-Heckman measure is also more or less completely arbitrary. However, we do at least have ")#link("http://en.wikipedia.org/wiki/Sard%27s_theorem")[#text("Sard’s theorem")]#text(", which asserts that almost every (in the sense of Lebesgue measure) point ")#mi("{p}")#text(" in ")#mi("{{\\bf R}}")#text(" is a ")#emph[#text("regular value")]#text(" for ")#mi("{H}")#text(" in the sense that it is not the image ")#mi("{H(x)}")#text(" of a critical point ")#mi("{x}")#text(" of ")#mi("{H}")#text(". In the neighbourhood of each regular point, an application of the inverse function theorem shows that the Duistermaat-Heckman measure is smooth (or more precisely, a smooth multple of Lebesgue.")

#text("However, if we make the additional assumption that the Hamiltonian action ")#mi("{\\rho}")#text(" is periodic (thus it is an action of ")#mi("{{\\bf R}/L{\\bf Z}}")#text(" and not just of ")#mi("{{\\bf R}}")#text(" for some period ")#mi("{L}")#text("), we can say much more about the Duistermaat-Heckman measure at regular points:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Duistermaat-Heckman theorem for circle actions)")]#text(" ")#metadata(none) <tao-0a42f62edb77e8f3021d>#text(" Let ")#mi("{(M,\\omega)}")#text(" be a ")#mi("{2n}")#text("-dimensional compact symplectic manifold for some ")#mi("{n>0}")#text(", and let ")#mi("{H}")#text(" be a Hamiltonian associated to a periodic action ")#mi("{\\rho: {\\bf R}/L{\\bf Z} \\rightarrow Symp(M)}")#text(" of ")#mi("{M}")#text(" for some period ")#mi("{L>0}")#text(". Then, in a sufficiently small neighbourhood of any given regular value of ")#mi("{H}")#text(" the Duistermaat-Heckman measure ")#mi("{H_* \\frac{\\omega^n}{n!}}")#text(" is a polynomial multiple of Lebesgue measure, with the polynomial being of degree at most ")#mi("{n-1}")#text(".")
]

#text("In particular, if ")#mi("{H}")#text(" has only finitely many critical points, then the Duistermaat-Heckman measure is a piecewise polynomial multiple of Lebesgue measure on ")#mi("{{\\bf R}}")#text(".")

#text("Let us illustrate this theorem with some key examples. We begin with a near-example, in which the compactness hypothesis is dropped.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" Let ")#mi("{M = {\\bf R}^2 = \\{(x,y): x,y \\in {\\bf R}\\}}")#text(" with the standard symplectic form ")#mi("{\\omega := dx \\wedge dy}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\omega((x_1,y_1),(x_2,y_2)) := x_1 y_2 - x_2 y_1")]]

#text("and Liouville measure is just Lebesgue measure ")#mi("{dx dy}")#text(" (using the standard orientation of ")#mi("{{\\bf R}^2}")#text("). Let ")#mi("{H}")#text(" be the Hamiltonian")

#align(center)[#tao-fit-display[#mitex("H(x,y) = H_0 + \\frac{1}{2} \\alpha (x^2+y^2)")]]

#text("for some ")#mi("{H_0 \\in {\\bf R}}")#text(" and ")#mi("{\\alpha > 0}")#text(". The only critical point of ")#mi("{H}")#text(" is at the origin. Then the associated Hamiltonian vector field ")#mi("{X}")#text(" is")

#align(center)[#tao-fit-display[#mitex("X = \\alpha (y \\frac{\\partial}{\\partial x} - x \\frac{\\partial}{\\partial y})")]]

#text("and so (using complex notation ")#mi("{z := x+iy}")#text(")")

#align(center)[#tao-fit-display[#mitex("e^{tX} z = e^{-i\\alpha t} z.")]]

#text("In particular, the Hamiltonian action is periodic with period ")#mi("{2\\pi/\\alpha}")#text(". The Duistermaat-Heckman measure is supported on the half-line ")#mi("{[H_0,+\\infty)}")#text(", with ")#mi("{H_0}")#text(" being the only non-regular value, and one can compute that it is ")#mi("{2\\pi/\\alpha}")#text(" times Lebesgue measure on this half-line, or equivalently it is the pushforward of Lebesgue measure on ")#mi("{[0,+\\infty)}")#text(" under the map ")#mi("{t \\mapsto H_0 + \\frac{\\alpha}{2\\pi} t}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" We can make a higher-dimensional (but still non-compact) version of the above example. Let ")#mi("{n \\geq 1}")#text(", and let ")#mi("{M = {\\bf R}^{2n} = \\{(x_1,y_1,\\ldots,x_n,y_n): x_1,\\ldots,y_n \\in {\\bf R}}")#text(" be given the standard symplectic form")

#align(center)[#tao-fit-display[#mitex("\\omega := \\sum_{j=1}^n dx_j \\wedge dy_j,")]]

#text("so that Liouville measure is again Lebesgue measure. If we let ")#mi("{H}")#text(" be the Hamiltonian")

#align(center)[#tao-fit-display[#mitex("H(x_1,\\ldots,y_n) = H_0 + \\frac{1}{2} \\sum_{j=1}^n \\alpha_j (x_j^2+y_j^2)")]]

#text("then the only critical point is at the origin, and the associated Hamiltonian vector field is")

#align(center)[#tao-fit-display[#mitex("X = \\sum_{j=1}^n \\alpha (y_j \\frac{\\partial}{\\partial x_j} - x_j \\frac{\\partial}{\\partial y_j})")]]

#text("and so (using the complex notation ")#mi("{z_j :=x_j+iy_j}")#text(") we have")

#align(center)[#tao-fit-display[#mitex("e^{tX} (z_1,\\ldots,z_n) = (e^{i\\alpha_1 t} z_1,\\ldots,e^{i\\alpha_n t}z_n).")]]

#text("We thus see that this flow will also be periodic if the ")#mi("{\\alpha_1,\\ldots,\\alpha_n}")#text(" are commensurate (i.e. linear multiples of each other), and that ")#mi("{H_0}")#text(" is the only non-regular value. As for the Duistermaat-Heckman measure, it is the pushforward of Lebesgue measure on the orthant ")#mi("{[0,+\\infty)^n}")#text(" by the map ")#mi("{(t_1,\\ldots,t_n) \\mapsto H_0 + \\sum_{j=1}^n \\frac{\\alpha_j}{2\\pi} t_j}")#text(", which one easily verifies to be a polynomial multiple of Lebesgue measure on ")#mi("{[H_0,+\\infty)}")#text(", with the polynomial being of degree ")#mi("{n-1}")#text(".")
]

#text("Now we give an example that ")#link("http://en.wikipedia.org/wiki/On_the_Sphere_and_Cylinder")[#text("dates back to Archimedes")]#text(" (two millennia before the formal development of symplectic geometry!).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3 (Archimedes sphere and cylinder)")]#text(" Let ")#mi("{S^2}")#text(" be the unit sphere, which we can coordinatise using the usual spherical coordinates ")#mi("{\\theta \\in [0,2\\pi]}")#text(", ")#mi("{\\phi \\in [0,\\pi]}")#text(" as")

#align(center)[#tao-fit-display[#mitex("S^2 = \\{ (\\sin \\phi \\cos \\theta, \\sin \\phi \\sin \\theta, \\cos \\phi): \\theta \\in [0,2\\pi], \\phi \\in [0,\\pi] \\}")]]

#text("with the Riemannian metric")

#align(center)[#tao-fit-display[#mitex("(\\sin^2 \\phi) d\\theta^2 + d\\phi^2")]]

#text("and a symplectic form")

#align(center)[#tao-fit-display[#mitex("\\omega := \\sin\\phi d\\theta \\wedge d\\phi")]]

#text("and associated Liouville measure ")#mi("{\\sin \\phi d \\theta d \\phi}")#text(". We take the Hamiltonian ")#mi("{H: S^2 \\rightarrow {\\bf R}}")#text(" to be the vertical coordinate function")

#align(center)[#tao-fit-display[#mitex("H(\\sin \\phi \\cos \\theta, \\sin \\phi \\sin \\theta, \\cos \\phi) = \\cos \\phi")]]

#text("and the Hamiltonian vector field ")#mi("{X}")#text(" is then the rotation vector field around the vertical axis:")

#align(center)[#tao-fit-display[#mitex("X = \\frac{\\partial}{\\partial \\theta}.")]]

#text("As such, the exponential map ")#mi("{e^{tX}}")#text(" is the anti-clockwise rotation by ")#mi("{t}")#text(" radians around the vertical axis:")

#align(center)[#tao-fit-display[#mitex("e^{tX} (\\sin \\phi \\cos \\theta, \\sin \\phi \\sin \\theta, \\cos \\phi)")]]

#align(center)[#tao-fit-display[#mitex("= (\\sin \\phi \\cos(\\theta+t), \\sin \\phi \\sin(\\theta+t), \\cos \\phi),")]]

#text("which is periodic with period ")#mi("{2\\pi}")#text(", and the only stationary points are at the north and south poles (so the only non-regular values of ")#mi("{H}")#text(" are ")#mi("{+1}")#text(" and ")#mi("{-1}")#text("), and the Duistermaat-Heckman measure is ")#mi("{2\\pi}")#text(" times Lebesgue measure on ")#mi("{[-1,1]}")#text(". This latter fact is equivalent to ")#link("http://en.wikipedia.org/wiki/On_the_Sphere_and_Cylinder")[#text("the famous theorem of Archimedes")]#text(" that a sphere and its circumscribing cylinder have the same surface area on horizontal slices.")
]

#text("Now we prove Proposition ")#link(<tao-0a42f62edb77e8f3021d>)[#text("1")]#text(". Let ")#mi("{p_0}")#text(" be a regular value of ")#mi("{H}")#text(". Then, for all ")#mi("{p}")#text(" sufficiently close to ")#mi("{p_0}")#text(", ")#mi("{p}")#text(" is also regular, and ")#mi("{H^{-1}(\\{p\\})}")#text(" is a ")#mi("{2n-1}")#text("-dimensional manifold on which ")#mi("{{\\bf R}/L{\\bf Z}}")#text(" acts freely, thus one can view ")#mi("{H^{-1}(\\{p\\})}")#text(" as a circle bundle, with the circles being the actions of ")#mi("{{\\bf R}/L{\\bf Z}}")#text(". By ")#link(<tao-2e37c8a01fb4b41fc028>)[#text("(4)")]#text(", the Hamiltonian vector field, which is tangent to these circles, is symplectically orthogonal to the tangent bundle of ")#mi("{H^{-1}(\\{p\\})}")#text(". Thus, if we quotient out ")#mi("{H^{-1}(\\{p\\})}")#text(" by the circle action, we obtain a ")#mi("{2n-2}")#text("-dimensional manifold ")#mi("{M_p}")#text(", and the symplectic form ")#mi("{\\omega}")#text(" restriced to ")#mi("{H^{-1}(\\{p\\})}")#text(" descends to a smooth anti-symmetric form ")#mi("{\\omega_p}")#text(" on ")#mi("{M_p}")#text(", which is non-degenerate because ")#mi("{\\omega}")#text(" is non-degenerate. The integral of ")#mi("{\\omega_p}")#text(" on any small closed two-dimensional surface lifts up to equal the integral on ")#mi("{\\omega}")#text(" on a lifted version of that surface; as ")#mi("{\\omega}")#text(" is closed, we conclude that ")#mi("{\\omega_p}")#text(" is also closed. Thus ")#mi("{(M_p,\\omega_p)}")#text(" is a ")#mi("{2n-2}")#text("-dimensional symplectic manifold, known as the ")#link("http://en.wikipedia.org/wiki/Symplectic_quotient")[#text("symplectic reduction")]#text(" (or Marsden-Weinstein symplectic quotient) of ")#mi("{(M,\\omega)}")#text(" by ")#mi("{H}")#text(" at the value ")#mi("{p}")#text(".")

#text("Now consider an infinitesimal ")#mi("{2n-2}")#text("-dimensional parallelepiped ")#mi("{P}")#text(" in ")#mi("{M_p}")#text(". This can be lifted up (non-uniquely, and modulo higher order corrections) to an infinitesimal ")#mi("{2n-2}")#text("-dimensional parallelepiped in ")#mi("{H^{-1}(\\{p\\})}")#text("; applying the action of the Hamiltonian vector field for an infinitesimal time ")#mi("{dt}")#text(", and also letting ")#mi("{p}")#text(" vary in an infinitesimal interval ")#mi("{[p,p+dp]}")#text(" (using some arbitrary smooth connection to identify together different fibres of ")#mi("{H}")#text(" arising fromthis interval), we obtain (modulo higher order corrections) a ")#mi("{2n}")#text("-dimensional parallelepiped ")#mi("{P^{\\prime}}")#text(" in ")#mi("{M}")#text(". Applying the Liouville measure ")#mi("{\\omega^n/n!}")#text(" to this parallelepiped, we see that the volume of this parallelepiped is (modulo higher order corrections) equal to ")#mi("{dp dt}")#text(" times the volume of the original parallelepiped ")#mi("{P}")#text(" with respect to the Liouville measure ")#mi("{\\omega_p^{n-1}/(n-1)!}")#text(" on ")#mi("{M_p}")#text(". (Indeed, in a suitable coordinate system, ")#mi("{\\omega}")#text(" is equal to ")#mi("{\\omega_p + dt \\wedge dp}")#text(" modulo higher order terms, and ")#mi("{P^{\\prime}}")#text(" is equal to ")#mi("{P \\times [0,dt] \\times [p,p+dp]}")#text(" modulo higher order terms in this system). Integrating over the action of ")#mi("{{\\bf R}/L{\\bf Z}}")#text(", and then dividing out by ")#mi("{dp}")#text(", we conclude that the Radon-Nikodym derivative of the Duistermaat-Heckman measure at ")#mi("{p}")#text(" with respect to Lebesgue measure, is equal to ")#mi("{L}")#text(" times the volume ")#mi("{\\int_{M_p} \\frac{\\omega_p^{n-1}}{(n-1)!}}")#text(" of the symplectic reduction ")#mi("{M_p}")#text(". It thus suffices to show that for ")#mi("{p}")#text(" near ")#mi("{p_0}")#text(", this volume ")#mi("{\\int_{M_p} \\frac{\\omega_p^{n-1}}{(n-1)!}}")#text(" is a polynomial of degree at most ")#mi("{n-1}")#text(" in ")#mi("{p}")#text(".")

#text("We now use a little bit of ")#link("http://en.wikipedia.org/wiki/De_rham_cohomology")[#text("de Rham cohomology")]#text(". Recall the product rule")

#align(center)[#tao-fit-display[#mitex("d(\\omega \\wedge \\eta) = d\\omega \\wedge \\eta + (-1)^k \\omega \\wedge d\\eta")]]

#text("for smooth differential forms ")#mi("{\\omega, \\eta}")#text(" of order ")#mi("{k,l}")#text(" respectively. One corollary of this is that the wedge product of a closed form and an exact form is exact. Indeed, if ")#mi("{d\\omega = 0}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\omega \\wedge d\\eta = (-1)^k d( \\omega \\wedge \\eta )")]]

#text("and so ")#mi("{\\omega \\wedge d\\eta}")#text(" is exact. In particular, if one modifies the closed form ")#mi("{\\omega_p}")#text(" by an exact form ")#mi("{d\\theta}")#text(" (for some ")#mi("{1}")#text("-form ")#mi("{\\theta}")#text("), then ")#mi("{\\frac{\\omega_p^{n-1}}{(n-1)!}}")#text(" is modified by an exact volume form, and so ")#mi("{\\int_{M_p} \\frac{\\omega_p^{n-1}}{(n-1)!}}")#text(" is unchanged. Thus, this integral only depends on the cohomology class ")#mi("{[\\omega_p] \\in H^2(M_p)}")#text(" of ")#mi("{\\omega_p}")#text(", and so by abuse of notation it can be written as")

#align(center)[#tao-fit-display[#mitex("\\int_{M_p} \\frac{[\\omega_p]^{n-1}}{(n-1)!},")]]

#text("where we are now implicitly using the product structure on the de Rham cohomology ring ")#mi("{H(M_p)}")#text(" arising from the above observation.")

#text("From Cartan’s formula ")#link(<tao-9b3fea8ad52e1f62033b>)[#text("(5)")]#text(" we see that the Lie derivative ")#mi("{{\\mathcal L}_X \\omega}")#text(" of a closed form ")#mi("{\\omega}")#text(" is exact, and so the cohomology class ")#mi("{[\\omega]}")#text(" of ")#mi("{\\omega}")#text(" is unaffected by perturbative diffeomorphisms. By the inverse function theorem, ")#mi("{M_p}")#text(" is diffeomorphic to ")#mi("{M_{p_0}}")#text(" for ")#mi("{p}")#text(" sufficiently close to ")#mi("{p_0}")#text(", and so by further abuse of notation we can identify all such ")#mi("{M_p}")#text(" with ")#mi("{p_0}")#text(" (and now view ")#mi("{[\\omega_p]}")#text(" as an element of ")#mi("{H^2(M_{p_0})}")#text(") and write the preceding integral as")

#align(center)[#tao-fit-display[#mitex("\\int_{M_{p_0}} \\frac{[\\omega_p]^{n-1}}{(n-1)!}.")]]

#text("To show that this expression is polynomial in ")#mi("{p}")#text(" of degree at most ")#mi("{n-1}")#text(", it thus suffices to show that the cohomology class ")#mi("{[\\omega_p]}")#text(" varies linearly in ")#mi("{p}")#text(" for ")#mi("{p}")#text(" sufficiently close to ")#mi("{p_0}")#text(".")

#text("We now work in a tubular neighbourhood ")#mi("{N := H^{-1}((p_0-\\epsilon,p_0+\\epsilon))}")#text(" of ")#mi("{H^{-1}(\\{p_0\\})}")#text(" for some small ")#mi("{\\epsilon}")#text(". This is a smooth circle bundle, and so we can place a smooth connection on this bundle, which we can represent as a ")#link("http://en.wikipedia.org/wiki/Connection_form")[#text("connection one-form")]#text(" ")#mi("{\\theta \\in \\Gamma(TN^*)}")#text(" on ")#mi("{N}")#text(", that is to say a smooth one-form on ")#mi("{N}")#text(" which is invariant with respect to the circle action (thus ")#mi("{{\\mathcal L}_X \\theta = 0}")#text(") and such that ")#mi("{\\iota_X \\theta = 1}")#text(". Indeed, one can build such a horizontal connection locally around the neighbourhood of any given circle orbit, and then patch such connections together using a smooth partition of unity. Geometrically, the level sets of this form identify infinitesimally adjacent circle orbits together.")

#text("Using the non-degenerate form ")#mi("{\\omega}")#text(", we can build the dual vector field ")#mi("{Y}")#text(" to the connection one-form ")#mi("{\\theta}")#text(", so that ")#mi("{\\iota_Y \\omega = \\theta}")#text(". As ")#mi("{\\omega}")#text(" and ")#mi("{\\theta}")#text(" are both invariant with respect to the circle action, then ")#mi("{Y}")#text(" is too:")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L}_X Y = 0.")]]

#text("Also, we have")

#tao-aligned(keep: true)[


#tao-math("1  & = \\iota_X \\theta = \\iota_X \\iota_Y \\omega = \\omega(Y,X)", block: true)



#tao-math(" & = - \\omega(X,Y) = - dH(Y)", block: true)
]

#text("and so ")#mi("{Y}")#text(" is uniformly transverse to ")#mi("{H}")#text(":")

#align(center)[#tao-fit-display[#mitex("dH(Y) = -1.")]]

#text("In particular, a flow ")#mi("{e^{tY}}")#text(" along ")#mi("{Y}")#text(" for a sufficiently small time ")#mi("{t}")#text(" will identify ")#mi("{H^{-1}(\\{p_0\\})}")#text(" with ")#mi("{H^{-1}(\\{p_0-t\\})}")#text(".")

#text("We can use the Cartan formula ")#link(<tao-9b3fea8ad52e1f62033b>)[#text("(5)")]#text(" to compute how the flow along the vector field ")#mi("{Y}")#text(" transforms the symplectic form ")#mi("{\\omega}")#text(":")

#tao-aligned(keep: true)[


#tao-math("{\\mathcal L}_Y \\omega  & = \\iota_Y d\\omega + d(\\iota_Y \\omega)", block: true)



#tao-math(" & = 0 + d \\theta.", block: true)
]

#text("Thus, if we let ")#mi("{\\tilde \\omega_{p_0-t}}")#text(" be the restriction of ")#mi("{\\omega}")#text(" to ")#mi("{H^{-1}(\\{p_0-t\\})}")#text(", pulled back to ")#mi("{H^{-1}(\\{p_0\\})}")#text(" by ")#mi("{e^{tY}}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\tilde \\omega_{p_0-t} = d(\\theta_{p_0-t})")]]

#text("where ")#mi("{\\theta_{p_0-t}}")#text(" is the restriction of the connection one-form ")#mi("{\\theta}")#text(" to ")#mi("{H^{-1}(\\{p_0-t\\})}")#text(", pulled back to ")#mi("{H^{-1}(\\{p_0\\})}")#text(".")

#text("By construction, ")#mi("{\\tilde \\omega_{p_0-t}}")#text(" is the pullback of ")#mi("{\\omega_{p_0-t}}")#text(" from ")#mi("{M_{p_0-t}}")#text(" to ")#mi("{H^{-1}(\\{p_0\\})}")#text(". The connection one-form ")#mi("{\\theta_{p_0-t}}")#text(" is not such a pullback, because it has a non-zero contraction with ")#mi("{X}")#text(". However, ")#mi("{\\theta_{p_0-t}-\\theta_{p_0}}")#text(" annihilates ")#mi("{X}")#text(" and so is the pullback of a ")#mi("{1}")#text("-form ")#mi("{\\alpha_t}")#text(" on ")#mi("{M_{p_0}}")#text(". As")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\tilde \\omega_{p_0-t} - (\\partial_t \\tilde \\omega_{p_0-t}|_{t=0}) = d(\\theta_{p_0-t} - \\theta_{p_0})")]]

#text("we conclude on quotienting out by the circle action that")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\omega_{p_0-t} - (\\partial_t \\omega_{p_0-t}|_{t=0}) = d\\alpha_t;")]]

#text("as the right-hand side is an exact form on ")#mi("{M_{p_0}}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\partial_t [\\omega_{p_0-t}] - \\partial_t [\\omega_{p_0-t}]|_{t=0} = 0.")]]

#text("In other words, ")#mi("{\\partial_t [\\omega_{p_0-t}]}")#text(" is independent of ")#mi("{t}")#text(" for sufficiently small ")#mi("{t}")#text(", and so ")#mi("{[\\omega_p]}")#text(" varies linearly in ")#mi("{p}")#text(" near ")#mi("{p_0}")#text(" as required. This completes the proof of Proposition ")#link(<tao-0a42f62edb77e8f3021d>)[#text("1")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The above argument in fact shows that ")#mi("{\\partial_p [\\omega_p]}")#text(" is the (negative of the) ")#link("http://en.wikipedia.org/wiki/Chern_class#The_Chern_class_of_line_bundles")[#text("Chern class")]#text(" of ")#mi("{H^{-1}(\\{p\\})}")#text(", viewed as a circle bundle over ")#mi("{M_p}")#text(".")
]

#text("The above arguments can be extended to higher-dimensional actions than circle actions. Given a torus ")#mi("{T}")#text(" acting smoothly on a compact symplectic manifold ")#mi("{M}")#text(", each tangent vector ")#mi("{t \\in {\\mathfrak t}}")#text(" of the torus gives rise to a vector field ")#mi("{X_t}")#text(" on ")#mi("{M}")#text(". We say that this torus is associated to a ")#link("http://en.wikipedia.org/wiki/Moment_map")[#text("moment map")]#text(" ")#mi("{\\Phi: M \\rightarrow {\\mathfrak t}^*}")#text(" taking values in the dual Lie algebra ")#mi("{{\\mathfrak t}^*}")#text(" of the torus if ")#mi("{\\Phi}")#text(" is smooth and one has")

#align(center)[#tao-fit-display[#mitex("\\iota_{X_t} \\omega = \\langle d \\Phi, t \\rangle")]]

#text("for all ")#mi("{t \\in {\\mathfrak t}}")#text(". The Duistermaat-Heckman measure associated to ")#mi("{\\Phi}")#text(" is the finite measure on ")#mi("{{\\mathfrak t}^*}")#text(" obtained by pushing forward Liouville measure ")#mi("{\\frac{\\omega^n}{n!}}")#text(" by ")#mi("{\\Phi}")#text(". A point ")#mi("{x}")#text(" in ")#mi("{M}")#text(" is said to be a ")#emph[#text("critical point")]#text(" if ")#mi("{d\\Phi(x)}")#text(" is not of full rank, and a point ")#mi("{p}")#text(" in ")#mi("{{\\mathfrak t}^*}")#text(" is a ")#emph[#text("regular value")]#text(" if it is not the image of a critical point under ")#mi("{\\Phi}")#text(". Again, Sard’s theorem guarantees that almost every point in ")#mi("{{\\mathfrak t}^*}")#text(" is regular. We then have the higher-dimensional version of Proposition ")#link(<tao-0a42f62edb77e8f3021d>)[#text("1")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Duistermaat-Heckman theorem, general case)")]#text(" ")#metadata(none) <tao-536637b9480de15832b0>#text(" Let ")#mi("{(M,\\omega)}")#text(" be a ")#mi("{2n}")#text("-dimensional compact symplectic manifold for some ")#mi("{n>0}")#text(", and ")#mi("{T}")#text(" be a ")#mi("{d}")#text("-dimensional torus acting on ")#mi("{M}")#text(" with an associated moment map ")#mi("{\\Phi: M \\rightarrow {\\mathfrak t}^*}")#text(". Then, in a sufficiently small neighbourhood of any given regular value of ")#mi("{\\Phi}")#text(", the Duistermaat-Heckman measure ")#mi("{\\Phi_* \\frac{\\omega^n}{n!}}")#text(" is a polynomial multiple of Haar measure on ")#mi("{{\\mathfrak t}^*}")#text(", with the polynomial being of degree at most ")#mi("{n-d}")#text(".")
]

#text("This theorem can be proven by a modification of the techniques used to prove Proposition ")#link(<tao-0a42f62edb77e8f3021d>)[#text("1")]#text("; we sketch the details here. As before, we can form the symplectic reduction ")#mi("{(M_p,\\omega_p)}")#text(" of ")#mi("{M}")#text(" at any regular value ")#mi("{p}")#text(" of ")#mi("{{\\mathfrak t}^*}")#text(" by quotienting out ")#mi("{\\Phi^{-1}(\\{p\\})}")#text(" by the torus action, obtaining a ")#mi("{2(n-k)}")#text("-dimensional symplectic manifold. If one selects a Haar measure on ")#mi("{{\\mathfrak t}^*}")#text(" (and thus on ")#mi("{{\\mathfrak t}}")#text(" and ")#mi("{T}")#text("), we then see as before that the Radon-Nikodym derivative of Duistermaat-Heckman measure at a regular value ")#mi("{p}")#text(" with respect to Haar measure of ")#mi("{{\\mathfrak t}^*}")#text(" is equal to the volume ")#mi("{\\int_{M_p} \\frac{\\omega_p^{n-k}}{(n-k)!}}")#text(" of the symplectic manifold ")#mi("{M_p}")#text(", times the volume of the torus ")#mi("{T}")#text(" with respect to the Haar measure on ")#mi("{{\\mathfrak t}}")#text(". Arguing as before, it then suffices to show that ")#mi("{[\\omega_p]}")#text(" varies linearly in ")#mi("{p}")#text(" for ")#mi("{p}")#text(" sufficiently close to a regular value ")#mi("{p_0}")#text(". As before, we can view ")#mi("{N := \\Phi^{-1}(U)}")#text(" for some sufficiently small open neighbourhood ")#mi("{U}")#text(" of ")#mi("{p_0}")#text(" as a torus bundle, and so one can again create a connection one-form ")#mi("{\\theta \\in \\Gamma(TN^*) \\otimes {\\mathfrak t}}")#text(" on ")#mi("{N}")#text("; but now it is no longer a scalar one-form, but takes values in ")#mi("{{\\mathfrak t}}")#text("; it is invariant with respect to the action of the torus, and obeys the identity")

#align(center)[#tao-fit-display[#mitex("\\iota_{X_t} \\theta = t")]]

#text("for all ")#mi("{t \\in {\\mathfrak t}}")#text(". This generates a ")#mi("{{\\mathfrak t}}")#text("-valued vector field ")#mi("{Y \\in \\Gamma(TN) \\otimes {\\mathfrak t}}")#text(" that is symplectically dual to ")#mi("{\\theta}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\iota_{\\langle \\xi, Y\\rangle} \\omega = \\langle \\xi,\\theta\\rangle")]]

#text("for all ")#mi("{\\xi \\in {\\mathfrak t}^*}")#text(". As before, ")#mi("{Y}")#text(" is preserved by the torus action, and we have")

#align(center)[#tao-fit-display[#mitex("\\langle d\\Phi(\\langle \\xi, Y\\rangle), t \\rangle = - \\langle \\xi, t \\rangle")]]

#text("for all ")#mi("{t \\in {\\mathfrak t}}")#text(" and ")#mi("{\\xi \\in {\\mathfrak t}^*}")#text(". In particular, we see that ")#mi("{\\exp(\\langle \\xi,Y\\rangle)}")#text(" maps ")#mi("{\\Phi^{-1}(p_0)}")#text(" to ")#mi("{\\Phi^{-1}(p_0-\\xi)}")#text(" for any sufficiently small ")#mi("{\\xi \\in {\\mathfrak t}^*}")#text(". As before, Cartan’s formula yields that")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L}_{\\langle \\xi,Y \\rangle} \\omega = -d \\langle \\xi, \\theta \\rangle")]]

#text("and repeating the previous arguments then shows that ")#mi("{\\nabla_\\xi [\\omega_p]}")#text(" is independent of ")#mi("{p}")#text(" for ")#mi("{p}")#text(" sufficiently close to ")#mi("{p_0}")#text(" and any fixed ")#mi("{\\xi \\in {\\mathfrak t}^*}")#text(", where ")#mi("{\\nabla_\\xi}")#text(" denotes the directional derivative in the ")#mi("{p}")#text(" variable along the ")#mi("{\\xi}")#text(" direction. This gives the desired local linearity of ")#mi("{[\\omega_p]}")#text(", giving Theorem ")#link(<tao-536637b9480de15832b0>)[#text("2")]#text(".")

#heading(level: 1)[#strong[#text(" — 3. Stationary phase — ")]]

#text("We now apply the Duistermaat-Heckman theorem to the task of proving the Harish-Chandra-Itzykson-Zuber integral formula. We first observe that it will suffice to establish the weaker formula ")#metadata(none) <tao-203d2b8bb76ee0b26444>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\int_{U(n)} \\exp( t \\text{tr}( A U B U^* ) )\\ dU")]]





#align(center)[#tao-fit-display[#mitex("= C_{A,B} \\det( \\exp( t \\lambda_i(A) \\lambda_j(B) ) )_{1 \\leq i,j \\leq n} t^{-(n^2-n)/2}")]]

#text("for any Hermitian ")#mi("{A,B}")#text(", all complex ")#mi("{t}")#text(", and some ")#mi("{C_{A,B}}")#text(" depending only on ")#mi("{n,A,B}")#text(". For, if this identity held, then by sending ")#mi("{t \\rightarrow 0}")#text(" we see that the ")#mi("{t^{(n^2-n)/2}}")#text(" coefficient of the Taylor series of ")#mi("{\\det( \\exp( t \\lambda_i(A) \\lambda_j(B) ) )_{1 \\leq i,j \\leq n}}")#text(" would equal ")#mi("{1/C_{A,B}}")#text(". But we may expand this determinant as")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\sigma \\in S_n} \\text{sgn}(\\sigma) \\prod_{i=1}^n \\exp( t \\lambda_i(A) \\lambda_{\\sigma(i)}(B) ),")]]

#text("so by Taylor expansion the ")#mi("{t^{(n^2-n)/2}}")#text(" coefficient is")

#align(center)[#tao-fit-display[#mitex("\\sum_{k_1+\\ldots+k_n = (n^2-n)/2} \\sum_{\\sigma \\in S_n} \\text{sgn}(\\sigma) \\prod_{i=1}^n \\frac{1}{k_i!} \\lambda_i(A)^{k_i} \\lambda_{\\sigma(i)}(B)^{k_i}")]]

#text("where the outer summation is over all natural numbers ")#mi("{k_1,\\ldots,k_n}")#text(" that sum to ")#mi("{(n^2-n)/2}")#text(".")

#text("Consider a summand in which ")#mi("{k_i = k_j}")#text(" for some ")#mi("{1 \\leq i < j \\leq n}")#text(". Then we see that this summand changes sign if we swap ")#mi("{\\sigma(i)}")#text(" and ")#mi("{\\sigma(j)}")#text(". For this reason we see that we may restrict attention to the case when the ")#mi("{k_i}")#text(" are all distinct; as the ")#mi("{k_i}")#text(" sum to ")#mi("{(n^2-n)/2 = 0 +1+ \\ldots+(n-1)}")#text(", we conclude that ")#mi("{k_1,\\ldots,k_n}")#text(" is a permutation of ")#mi("{0,\\ldots,n-1}")#text(". We can then rearrange the above sum as")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\alpha,\\beta \\in S_n} \\text{sgn}(\\alpha) \\text{sgn}(\\beta) \\prod_{j=1}^n \\frac{1}{(j-1)!} \\lambda_{\\alpha(j)}(A)^{j-1} \\lambda_{\\beta(j)}(B)^{j-1}")]]

#text("which factorises as ")#mi("{\\Delta_n(\\lambda(A)) \\Delta_n(\\lambda(B)) / 1! \\ldots n!}")#text(", yielding the Harish-Chandra-Itzykson-Zuber integral formula.")

#text("It remains to prove ")#link(<tao-203d2b8bb76ee0b26444>)[#text("(12)")]#text(". By unitary invariance we may take ")#mi("{A,B}")#text(" to be diagonal; by perturbation we may take the eigenvalues of ")#mi("{A,B}")#text(" to be generic (in, say, the Zariski sense), thus")

#align(center)[#tao-fit-display[#mitex("A = \\text{diag}(a_1,\\ldots,a_n)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("B = \\text{diag}(b_1,\\ldots,b_n)")]]

#text("for some ")#mi("{a_1, \\ldots, a_n}")#text(" and ")#mi("{b_1,\\ldots,b_n}")#text(" generic. By analytic continuation we may take ")#mi("{t}")#text(" to be imaginary. It will then suffice to show that")

#align(center)[#tao-fit-display[#mitex("\\int_{U(n)} \\exp( i t \\text{tr}( A U B U^* ) )\\ dU = C_{a,b} \\det( \\exp( i t a_j b_k ) )_{1 \\leq j,k \\leq n} t^{-(n^2-n)/2}")]]

#text("where ")#mi("{a = (a_1,\\ldots,a_n)}")#text(" and ")#mi("{b = (b_1,\\ldots,b_n)}")#text(" with distinct entries and all non-zero real ")#mi("{t}")#text(", where ")#mi("{C_{a,b}}")#text(" depends only on ")#mi("{a,b,n}")#text(". By subtracting a constant from ")#mi("{B}")#text(" we may take ")#mi("{B}")#text(" to be trace zero, and similarly for ")#mi("{A}")#text(" (and then generic relative to this constraint). The right-hand side can be expanded as")

#align(center)[#tao-fit-display[#mitex("C_{a,b} \\sum_{\\sigma \\in S_n} \\text{sgn}(\\sigma) \\exp( i t a \\cdot \\sigma(b) ) t^{-(n^2-n)/2}.")]]

#text("As for the left side, we introduce the ")#link("http://en.wikipedia.org/wiki/Coadjoint_representation")[#text("coadjoint orbit")]

#align(center)[#tao-fit-display[#mitex("M := \\{ UBU^*: U \\in U(n) \\}")]]

#text("which, as the eigenvalues of ")#mi("{B}")#text(" are generic, is a smooth manifold of dimension ")#mi("{n^2-n}")#text(", which has a transitive action of ")#mi("{U(n)}")#text(" on it. (Strictly speaking, ")#mi("{M}")#text(" is actually the rotation of a coadjoint orbit by ")#mi("{i}")#text(", because the Lie algebra of ")#mi("{U(n)}")#text(" is given by skew-Hermitian matrices rather than Hermitian matrices, but we will abuse notation by ignoring this distinction in the arguments that follow.) If we let ")#mi("{\\Phi: M \\rightarrow {\\bf R}^n}")#text(" be the diagonal map")

#align(center)[#tao-fit-display[#mitex("\\Phi( (c_{ij})_{1 \\leq i,j \\leq n} ) := (c_1,\\ldots,c_n)")]]

#text("then it thus suffices to show that ")#metadata(none) <tao-b3484e21eafaa3595438>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\int_M \\exp( i t a \\cdot \\Phi(x) )\\ d\\mu(x) = C_{a,\\mu} t^{-(n^2-n)/2} \\sum_{\\sigma \\in S_n} \\text{sgn}(\\sigma) \\exp( i t a \\cdot \\sigma(b) )")]]



#text(" for all generic vectors ")#mi("{a}")#text(" of trace zero, all non-zero ")#mi("{t}")#text(", and some Haar measure ")#mi("{\\mu}")#text(" on ")#mi("{M}")#text(" (i.e. a non-zero ")#mi("{U(n)}")#text("-invariant Radon measure), and some constant ")#mi("{C_\\mu}")#text(" depending only on ")#mi("{\\mu}")#text(". Note that ")#link(<tao-b3484e21eafaa3595438>)[#text("(7)")]#text(" is asserting an exact formula for the Fourier transform of the pushforward measure ")#mi("{\\Phi_* \\mu}")#text(" (or of its one-dimensional projection ")#mi("{(a \\cdot \\Phi)_* \\mu}")#text(").")

#text("Note that as ")#mi("{B}")#text(" is assumed to have trace zero, all elements of ")#mi("{M}")#text(" have trace zero as well, so ")#mi("{\\Phi}")#text(" actually takes values in the hyperplane ")#mi("{{\\bf R}^n_0 := \\{ (x_1,\\ldots,x_n) \\in {\\bf R}^n: x_1+\\ldots+x_n=0\\}}")#text(".")

#text("We now seek to interpret ")#mi("{M}")#text(" as a symplectic manifold and ")#mi("{\\Phi}")#text(" as a moment map for a torus action, in order to view ")#mi("{\\Phi_* \\mu}")#text(" as a Duistermmat-Heckman measure. We first need to construct a symplectic form ")#mi("{\\omega}")#text(" on the coadjoint orbit ")#mi("{M}")#text(", known as the ")#emph[#link("http://www.ams.org/mathscinet-getitem?mr=721448")[#text("Kirrilov-Kostant")]#text("–")#link("http://www.ams.org/mathscinet-getitem?mr=260238")[#text("Souriau")]#text(" form")]#text(", as follows. Note that at any element ")#mi("{P}")#text(" of ")#mi("{M}")#text(", the tangent vectors to ")#mi("{M}")#text(" at ")#mi("{P}")#text(" (which can be viewed as Hermitian matrices) take the form ")#mi("{[P,S]}")#text(" for some skew-Hermitian matrix ")#mi("{S}")#text(". The symplectic form ")#mi("{\\omega(P)}")#text(" at ")#mi("{P}")#text(" is then defined by the formula ")#metadata(none) <tao-15f3b852d2465ae56ff5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\omega(P)([P,S],[P,T]) := \\text{tr}( i P [S,T] ).")]]



#text(" (The sign conventions are sometimes reversed in the literature; note that ")#mi("{P}")#text(" and ")#mi("{i[S,T]}")#text(" are Hermitian and so this expression is real-valued.) Using the cyclic properties of trace, we have the identity")

#align(center)[#tao-fit-display[#mitex("\\text{tr}(i P [S,T] ) = \\text{tr}( i [P,S] T ) = - \\text{tr}( i [P,T] S )")]]

#text("whence we see that the above form is well-defined (the dependence of ")#mi("{\\text{tr}(iP[S,T])}")#text(" on ")#mi("{S}")#text(" factors through ")#mi("{[P,S]}")#text(", and similarly for ")#mi("{T}")#text("). It is clearly a smooth anti-symmetric form, and is also invariant with respect to the ")#mi("{U(n)}")#text(" conjugation action. By working with explicit matrix coefficients at ")#mi("{P=B}")#text(" and using the hypotheses that the ")#mi("{b_1,\\ldots,b_n}")#text(" are distinct, one can soon verify that ")#mi("{\\omega}")#text(" is non-degenerate at ")#mi("{B}")#text(", and hence non-degenerate everywhere by the ")#mi("{U(n)}")#text(" invariance. To verify that ")#mi("{\\omega}")#text(" is a symplectic form, it remains to establish that ")#mi("{\\omega}")#text(" is closed. This can be done by direct computation, but it turns out to be slicker to delay the verification of the symplectic nature of ")#mi("{\\phi}")#text(" until some further facts about ")#mi("{M}")#text(" and ")#mi("{\\Phi}")#text(" have been established.")

#text("Now we express ")#mi("{\\Phi}")#text(" as a moment map (and, as a byproduct, conclude the closed nature of ")#mi("{\\omega}")#text("). For any ")#mi("{a \\in {\\bf R}^n_0}")#text(", we consider the scalar map ")#mi("{a \\cdot \\Phi: M \\rightarrow {\\bf R}}")#text(", which can be written as")

#align(center)[#tao-fit-display[#mitex("a \\cdot \\Phi(P) = \\text{tr}( \\text{diag}(a) P ).")]]

#text("Differentiating this along an arbitrary vector field ")#mi("{Y(P) = [P,S]}")#text(" we see that")

#tao-aligned(keep: true)[


#tao-math("d(a \\cdot \\Phi)(P)(Y)  & = \\text{tr}( \\text{diag}(a) [P,S] )", block: true)



#tao-math(" & = \\omega( X_a(P), Y(P) )", block: true)
]

#text("where ")#mi("{X_a(P)}")#text(" is the vector field ")#mi("{X_a(P) := [P, i \\text{diag}(a)]}")#text(". As ")#mi("{X}")#text(" was arbitrary, we conclude that ")#metadata(none) <tao-06387d58112d94ec53e8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\iota_{X_a} \\omega = d(a \\cdot \\Phi).")]]



#text(" In particular, ")#mi("{\\iota_{X_a} \\omega}")#text(" is closed:")

#align(center)[#tao-fit-display[#mitex("d( \\iota_{X_a} \\omega ) = 0.")]]

#text("On the other hand, as ")#mi("{\\omega}")#text(" is preserved by the ")#mi("{U(n)}")#text(" action, and ")#mi("{X_a}")#text(" is the vector field for the infinitesimal generator conjugation with respect to the unitary diagonal matrix ")#mi("{\\exp( i \\epsilon \\text{diag}(a) )}")#text(" for infinitesimal ")#mi("{\\epsilon}")#text(", we see that ")#mi("{X_a}")#text(" preserves ")#mi("{\\omega}")#text(":")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L}_{X_a} \\omega = 0.")]]

#text("Applying Cartan’s formula ")#link(<tao-9b3fea8ad52e1f62033b>)[#text("(5)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("\\iota_{X_a} d\\omega = 0")]]

#text("for all ")#mi("{a}")#text(". By unitary invariance again we conclude that ")#mi("{\\iota_{X_A} d\\omega = 0}")#text(" for any skew-Hermitian ")#mi("{A}")#text(", where ")#mi("{X_A(P) := [P,A]}")#text(". As the ")#mi("{X_A}")#text(" span the tangent space, we obtain ")#mi("{d\\omega = 0}")#text(", and so ")#mi("{\\omega}")#text(" is closed and thus symplectic as required.")

#text("Now that ")#mi("{(M,\\omega)}")#text(" is known to be a symplectic manifold, we may form the Liouville measure ")#mi("{\\mu := \\omega^{(n^2-n)/2}{((n^2-n)/2)!}}")#text("; as ")#mi("{\\omega}")#text(" is invariant under the ")#mi("{U(n)}")#text(" conjugation action, ")#mi("{\\mu}")#text(" is also, so this is a Haar measure. From ")#link(<tao-06387d58112d94ec53e8>)[#text("(9)")]#text(" we From this we see that ")#mi("{\\Phi}")#text(" is the moment map for the conjugation action of the ")#mi("{n-1}")#text("-dimensional torus ")#mi("{T}")#text(" of unitary diagonal matrices of determinant ")#mi("{1}")#text(", after identifying ")#mi("{{\\mathfrak t}^*}")#text(" with ")#mi("{{\\bf R}^n_0}")#text(" by taking the diagonal matrix entries and dividing by ")#mi("{i}")#text(". This makes ")#mi("{\\Phi_* \\mu}")#text(" a Duistermaat-Heckman measure, and thus a multiple of Lebesgue measure on ")#mi("{{\\bf R}^n_0}")#text(" by polynomial of degree at most ")#mi("{(n-1)(n-2)/2}")#text(" at every regular value of ")#mi("{\\Phi}")#text(".")

#text("Now we work out what the regular values of ")#mi("{\\Phi}")#text(" are. If ")#mi("{P}")#text(" is a critical point of ")#mi("{\\Phi}")#text(", then by the above calculations we must have ")#mi("{[P, i\\text{diag}(a)] = 0}")#text(" for some non-trivial ")#mi("{a \\in {\\bf R}^n_0}")#text(". The centraliser of a non-constant diagonal matrix consists of block diagonal matrices, so this only occurs when ")#mi("{P}")#text(" is block-diagonal. As ")#mi("{P}")#text(" has the same eigenvalues as ")#mi("{B}")#text(", each block of ")#mi("{P}")#text(" then has eigenvalues that are a subset of ")#mi("{\\{b_1,\\ldots,b_n\\}}")#text(". Taking partial traces, we then conclude that ")#mi("{\\Phi(P) = (x_1,\\ldots,x_n)}")#text(" lies on a hyperplane of the form ")#metadata(none) <tao-91e235e3f8168853b4d9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\{ (x_1,\\ldots,x_n): x_{i_1} + \\ldots + x_{i_k} = b_{j_1} + \\ldots + b_{j_k} \\}")]]



#text(" for some ")#mi("{1 \\leq k \\leq n-1}")#text(" and some ")#mi("{1 \\leq i_1 < \\ldots < i_k \\leq n}")#text(" and ")#mi("{1 \\leq j_1 < \\ldots < j_k \\leq n}")#text(". Outside of these hyperplanes, we have regular points. The set of block diagonal matrices in ")#mi("{M}")#text(" can easily be verified to have zero measure (it has strictly lower dimension than ")#mi("{M}")#text("), so the Duistermaat-Heckman measure ")#mi("{\\Phi_* d\\mu}")#text(" is thus a piecewise polynomial multiple of Lebesgue measure on ")#mi("{{\\bf R}^n_0}")#text(" which is smooth everywhere except at the hyperplanes ")#link(<tao-91e235e3f8168853b4d9>)[#text("(10)")]#text(". Note that these hyperplanes ")#link(<tao-91e235e3f8168853b4d9>)[#text("(10)")]#text(" partition ")#mi("{{\\bf R}^n_0}")#text(" into a finite number of polytopes. After performing a sequence of ")#mi("{n-2}")#text(" projections to spaces of one lower dimension, we conclude that (for generic ")#mi("{a}")#text(") the one-dimensional measure ")#mi("{(a \\cdot \\Phi)_* d\\mu}")#text(" is also piecewise polynomial, with a finite number of pieces (supported on intervals) and the polynomial being of degree at most ")#mi("{(n-1)(n-2)/2 + (n-2)}")#text(" on each piece. (This fact can also be established directly from Proposition ")#link(<tao-0a42f62edb77e8f3021d>)[#text("1")]#text(" in the case when ")#mi("{a}")#text(" is commensurate as well as generic.) In particular, if one differentiates (in the distributional sense) this one-dimensional measure ")#mi("{(n-1)(n-2)/2 + (n-1) = (n^2-n)/2}")#text(" times, one obtains a distribution that is supported on a finite number of points ")#mi("{\\alpha_{a,1},\\ldots,\\alpha_{a,k} \\in {\\bf R}}")#text(" (depending on ")#mi("{a}")#text("), and so its Fourier transform takes the form ")#mi("{t \\mapsto \\sum_{j=1}^k P_{a,j}(t) e^{i \\alpha_{a,j} t}}")#text(" for some polynomials ")#mi("{P_{a,1},\\ldots,P_{a,k}}")#text(". Undoing the differentiation, we thus conclude that ")#metadata(none) <tao-b49b6976120c927c29fd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\int_M \\exp( i t a \\cdot \\Phi(x) )\\ d\\mu(x) = t^{-(n^2-n)/2} \\sum_{j=1}^k \\tilde P_{a,j}(t) e^{i\\alpha_{a,j} t}")]]



#text(" for some polynomials ")#mi("{\\tilde P_{a,1},\\ldots,\\tilde P_{a,k}}")#text(" and some distinct reals ")#mi("{\\alpha_{a,1},\\ldots,\\alpha_{a,k}}")#text(". This is already some way towards what our goal ")#link(<tao-b3484e21eafaa3595438>)[#text("(7)")]#text(", but we still need to sort out exactly what the ")#mi("{\\tilde P_{a,j}}")#text(" and ")#mi("{\\alpha_{a,j}}")#text(" are. There are a number of ways to do this (e.g. one can use the ")#link("http://www.ams.org/mathscinet-getitem?mr=721448")[#text("Atiyah-Bott")]#text("–")#link("http://www.ams.org/mathscinet-getitem?mr=733806")[#text("Berline-Vergne")]#text(" localization theorem, or the machinery of symplectic ")#link("http://en.wikipedia.org/wiki/Cobordism")[#text("cobordism")]#text("), but we will use the ")#link("http://en.wikipedia.org/wiki/Stationary_phase_approximation")[#text("method of stationary phase")]#text(" instead. The idea is to obtain an asympotic of the form ")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\int_M \\exp( i t a \\cdot \\Phi(x) )\\ d\\mu(x)")]]





#align(center)[#tao-fit-display[#mitex("= C_{a,\\mu} t^{-(n^2-n)/2} (\\sum_{\\sigma \\in S_n} \\text{sgn}(\\sigma) \\exp( i t a \\cdot \\sigma(b) ) + o(1))")]]

#text("when ")#mi("{t \\rightarrow + \\infty}")#text(" (keeping ")#mi("{a,b}")#text(" fixed); this asymptotic with the correct main term, combined with the expression ")#link(<tao-b49b6976120c927c29fd>)[#text("(11)")]#text(" with a general main term but no error term, gives the formula ")#link(<tao-b3484e21eafaa3595438>)[#text("(7)")]#text(" with the correct main term and no error term (the point being that it is not possible for an expression of the form ")#mi("{\\sum_{j=1}^k \\tilde P_{a,j}(t) e^{i\\alpha_{a,j} t}}")#text(" to decay to zero at infinity without actually vanishing identically, as can be seen for instance by using frequency localisation operators to separate the contribution of each of the frequencies ")#mi("{\\alpha_{a,j}}")#text(").")

#text("It remains to establish ")#link(<tao-203d2b8bb76ee0b26444>)[#text("(12)")]#text(". Up to a scalar multiple depending on ")#mi("{\\mu}")#text(", the left-hand side of ")#link(<tao-203d2b8bb76ee0b26444>)[#text("(12)")]#text(" is equal to")

#align(center)[#tao-fit-display[#mitex("\\int_{U(n)} \\exp( i t \\phi(U) )\\ dU")]]

#text("where ")#mi("{\\phi(U)}")#text(" is the phase")

#align(center)[#tao-fit-display[#mitex("\\phi(U) := \\text{tr}( A U B U^* ).")]]

#text("Following the method of statinonary phase, we now study how the stationary points of ")#mi("{\\phi}")#text(". Given a unitary matrix ")#mi("{U}")#text(", an infinitesimal perturbation of it takes the form ")#mi("{U(1+\\epsilon X + O(\\epsilon^2))}")#text(" for some skew-Hermitian matrix ")#mi("{X}")#text(", and so the first variation of ")#mi("{\\phi(U)}")#text(" in this direction is")

#align(center)[#tao-fit-display[#mitex("\\text{tr}( A U [X,B] U^* ) = \\text{tr}( U^* A U [X,B] ).")]]

#text("As ")#mi("{B}")#text(" is diagonal with generic entries, ")#mi("{[X,B]}")#text(" ranges over the Hermitian matrices with zero diagonal, or equivalently the orthogonal complement of the diagonal Hermitian matrices with respect to the Hilbert-Schmidt inner product ")#mi("{\\langle X, Y \\rangle := \\text{tr}(XY)}")#text(". In order for ")#mi("{\\phi}")#text(" to be stationary at ")#mi("{U}")#text(", it is thus necessary and sufficient for ")#mi("{U^* A U}")#text(" to be diagonal, which (as ")#mi("{A}")#text(" is a generic diagonal matrix) only occurs when ")#mi("{U}")#text(" is a diagonal matrix. Thus we see that ")#mi("{\\phi}")#text(" is only stationary at the permutation matrices ")#mi("{\\sigma \\in S_n}")#text(", at which point it takes the value of ")#mi("{a \\cdot \\sigma(b)}")#text(".")

#text("Next, we expand ")#mi("{\\phi}")#text(" to second order at each of its stationary points. We begin with an expansion near the identity matrix ")#mi("{U=1}")#text(". We use exponential coordinates ")#mi("{U = \\exp(X)}")#text(", where ")#mi("{X}")#text(" is a small skew-Hermitian matrix, so that")

#align(center)[#tao-fit-display[#mitex("\\phi(U) = \\text{tr}( A \\exp(X) B \\exp(-X) ).")]]

#text("Taylor expanding the exponential, we obtain")

#align(center)[#tao-fit-display[#tao-math("\\phi(U) = a \\cdot b + \\text{tr}( AXB - ABX ) + \\frac{1}{2} \\text{tr}( A X^2 B - AXBX + ABX^2 ) + O(\\left\\|X\\right\\|^3).", block: true)]]

#text("Writing ")#mi("{X = (x_{ij})_{1 \\leq i,j \\leq n}}")#text(", this becomes")

#align(center)[#tao-fit-display[#tao-math("\\phi(U) = a \\cdot b + \\frac{1}{2} \\sum_{i=1}^n \\sum_{j=1}^n (a_i-a_j) (b_i-b_j) x_{ij} x_{ji} + O( \\left\\|x\\right\\|^3)", block: true)]]

#text("and hence by the skew-Hermitian nature of ")#mi("{X}")

#align(center)[#tao-fit-display[#tao-math("\\phi(U) = a \\cdot b - \\sum_{1 \\leq i < j \\leq n} (a_i-a_j) (b_i-b_j) \\left|x_{ij}\\right|^2 + O( \\left\\|x\\right\\|^3).", block: true)]]

#text("We thus see that the Hessian of ")#mi("{\\phi}")#text(" at ")#mi("{1}")#text(" in exponential coordinates has a determinant square root (using the branch in the upper half-plane, which is what is needed for the ")#mi("{t \\rightarrow +\\infty}")#text(" asymptotics) which is ")#mi("{C \\Delta_n(a) \\Delta_n(b)}")#text(" for some absolute constant ")#mi("{C}")#text(". Similarly, the determinant square root of the Hessian of ")#mi("{\\phi}")#text(" at any other permutation matrix ")#mi("{\\sigma}")#text(" can be computed to be ")#mi("{C \\Delta_n(a) \\Delta_n(\\sigma(b)) = \\text{sgn}(\\sigma) C \\Delta_n(a) \\Delta_n(b)}")#text(". Using stationary phase expansions (see e.g. Chapter IX of Stein’s “")#link("http://www.ams.org/mathscinet-getitem?mr=1232192")[#text("Harmonic analysis")]#text("“) we obtain the desired expansion ")#link(<tao-203d2b8bb76ee0b26444>)[#text("(12)")]#text(".")

#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of very small typo")]], [#link("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/#comment-216361")[#strong[#text("very small typo")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2013")])]

#text("I don’t understand this post at all,maybe I will never understand it .But I find a typo.In the first paragraph,")

#text("Let {A, B} be {n \\times n} Hermitian matrices, with eigenvalues {\\lambda_1(A) \\leq \\ldots \\leq \\lambda_n(A)} and {\\lambda_1(B) \\leq \\ldots\\leq \\lambda_n(B)}.")

#text("“}” should be deleted……")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf439e996e29d20cb552d68ffe9f964d8919f4f9773b9c41c886fb326a5a9695-66573747b7b50dc2532a1c1acd7e23c9482f9aeb4a00f437399c08ade2278ee3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/#comment-216394")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2013")])]

#text("Dear terry,")#linebreak()#text(" It’s really nice to see duistermaat Heckman formula explained in such simple terms and with great elementary examples, and even a remarkable application. My only technical question concerns the formula partial_t[omega_p] – partial_t[omega_(p-t)] =0. How does that follow from the previous equation that the formula without square bracket is closed? Also want to mention that I learned the proof of HCIZ formula first from johansson’s paper on Gaussian divisible matrices.")#linebreak()#text(" John")

#emph[#text("[Oops, “closed” should be “exact” in that sentence; I’ve edited accordingly. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf439e996e29d20cb552d68ffe9f964d8919f4f9773b9c41c886fb326a5a9695-66573747b7b50dc2532a1c1acd7e23c9482f9aeb4a00f437399c08ade2278ee3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/#comment-216479")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2013")])]

#text("Thanks! I was worried that the exactness does not hold after quotient. But that seems to be the point of showing theta difference quantity is a pullback under the inclusion map.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e147fe7e8dc936d944937a3f47efe38550f1c75b3a97d2e913730c503b13ef7-4b2596fa5c254f2b75d80954a40f4a309e0551f5792de3d8566186c426cead43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jean-Bernard Zuber")]], [#link("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/#comment-216570")[#strong[#text("Jean-Bernard Zuber")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2013")])]

#text("The presentation of Duistermaat-Heckman formula and its application to")#linebreak()#text(" HCIZ is very nice.")#linebreak()#text(" But I’m slightly puzzled by the other derivation, “Dyson Brownian")#linebreak()#text(" motion”. It seems to rely on Brezin-Hikami-Johansson formula,")#linebreak()#text(" which is itself using … HCIZ formula! Is the argument not circular ?")#linebreak()#text(" There is a slight variant, also starting from the group average of the")#linebreak()#text(" heat kernel on V_n, for which one derives after multiplication by")#linebreak()#text(" the Vandermonde determinant a heat equation in flat coordinates.")

#text("This is the method originally used by C. Itzykson and myself,")#linebreak()#text(" in J. Math. Phys. 21 (1980) 411-421. In that paper yet another")#linebreak()#text(" method, based on a character expansion and the Binet-Cauchy formula,")#linebreak()#text(" is given. And of course, there is a fourth derivation,")#linebreak()#text(" which is Harish-Chandra’s ! (a simple presentation of which I would")#linebreak()#text(" love to see …)")#linebreak()#text(" For the anecdote, we had already observed in 1979 that an")#linebreak()#text(" a priori totally unjustified")#linebreak()#text(" stationary phase approximation of the integral over the unitary")#linebreak()#text(" group was giving the right answer for small values of n ! This is what")#linebreak()#text(" prompted us to look for more robust derivations of that formula.")#linebreak()#text(" And the exactness of our stationary phase approximation was justified a")#linebreak()#text(" few years later, thanks to the D-H formula.")

#text("The Harish-Chandra formula is mentioned in DH’s paper. The application of")#linebreak()#text(" DH’s formula to HCIZ was later discussed in detail by Szabo,")#linebreak()#text(" arXiv:hep-th/9608068, and by many others.")

#text("Jean-Bernard Zuber")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/#comment-216573")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2013")])]

#text("Thanks for the references and early history of this result! I have adjusted the text accordingly.")

#text("Regarding the Brezin-Hikami-Johansson formula, in ")#link("http://link.springer.com/article/10.1007%2Fs002200000328")[#text("Johansson’s paper")]#text(", two proofs of this formula are given. The first, as you say, uses the HCIZ formula and would thus of course be unusable for the purposes of this blog post. But the second proof (given in page 689 of that paper) proceeds by an analysis of Dyson Brownian Motion instead of HCIZ, and Johansson comments in that paper that one can use that proof to give a non-circular proof of HCIZ, basically along the lines given in this post. Of course, this is more or less what you do in your paper with Itzykson (the heat equation weighted by the Vandermonde determinant being essentially the Fokker-Planck equation for the Dyson Brownian motion), and is also the approach I took in ")#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/")[#text("this previous blog post")]#text(" about three years ago. So I guess the summary of the situation is that the HCIZ and Brezis-Hikami-Johansson formulae are logically equivalent to each other, and either formula can be proven by solving the relevant heat equation or Brownian motion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e147fe7e8dc936d944937a3f47efe38550f1c75b3a97d2e913730c503b13ef7-4b2596fa5c254f2b75d80954a40f4a309e0551f5792de3d8566186c426cead43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jean-Bernard Zuber")]], [#link("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/#comment-216609")[#strong[#text("Jean-Bernard Zuber")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2013")])]

#text("Thanks a lot for this clarification. Incidentally, do not confuse Brezis, the")#linebreak()#text(" mathematician, and Brezin, the physicist. Here we are talking about")#linebreak()#text(" Edouard Brezin…")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e8372d4acea45f1c991fd7a855d38f48718ccdfcfc6e03e38206782203da2c8f-01b13ea1ae5740a5371f3b2faeef401a7d15df73c9316f38ae12764366931690.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Bubenzer")]], [#link("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/#comment-216786")[#strong[#text("Paul Bubenzer")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2013")])]

#text("A more conceptual proof that ")#mi("\\omega")#text(" is closed can be found in the proof of Lemma 7.22 of Berline/Getzler/Vergne’s “Heat Kernels and Dirac Operators”:")#linebreak()#text(" First, you need to establish that ")#mi("\\omega")#text(" is ")#mi("U(n)")#text("-invariant.")#linebreak()#text(" Second, observe that the fundamental vector fields (i.e. the vector fields that arise from the infinitesimal action of an element of the lie algebra) span the tangent space of the coadjoint orbit at each point.")#linebreak()#text(" Third, you need to prove the defining equation of the momentum map, i.e. show that")#linebreak()#text(" ")#mi("d\\Phi(X) = \\iota_{X_M} \\omega")#linebreak()#text(" holds for ")#mi("X \\in \\mathfrak{u}(n)")#text(". Here, ")#mi("X_M")#text(" is the fundamental vector field associated to ")#mi("X")#text(".")

#text("Then we have")#linebreak()#text(" ")#mi("0 = d^2 Phi(X) = d\\iota_{X_M} \\omega = - \\iota_{X_M} d \\omega")#text(".")#linebreak()#text(" The last equal sign follows from ")#mi("L_{X_M} \\omega = 0")#text(" (by ")#mi("U(n)")#text("-invariance) and E. Cartan’s homotopy formula.")#linebreak()#text(" As the fundamental vector fields span the tangent space, we have ")#mi("d\\omega = 0")#text(", as desired.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/#comment-216907")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2013")])]

#text("That’s a nice argument! I hadn’t realised that the moment map equation can be used even before one has fully verified that one has a symplectic structure. I’ve updated the text accordingly in order to incorporate this argument.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ab80d0fdd3657909506d5c45a456741fbda55c43469b40709e69b87af66de2e-743bc2095bd07f0c397ce008669b3e8ee24b852ddd2d93e85f321f384ee49dbe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jefferson alexander vitola")]], [#link("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/#comment-235916")[#strong[#text("jefferson alexander vitola")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("Hi Tao wrote you an email and never answered was more than 3 months ago")#linebreak()#text(" I asked you solve the definite integral of methods oscillatory")#linebreak()#text(" Integrate [(-8796541 * Pi ^ 12) / 322 * Sin [x ^ 4], {x, 74.37, 97.28}] or Integrate [(-8,796,541 * Pi ^ 12) / 322 * Sin [x * x * x * x], {x, 74.37, 97.28}]")#linebreak()#text(" and that your making the approximate with just pencil and paper and a pocket calculator,,,,, I hope do your answer,,,,clarified that the exercise proposed by my above,,, I do not need approximation of the number,,, I need are the procedures and series that you use to solve it, and that these series can be replaced in a pocket calculator,,,thanks")

#text("att")#linebreak()#text(" jefferson alexander vitola")

#text("att")#linebreak()#text(" jefferson alexander vitola")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On the sign patterns of entrywise positivity preservers in fixed dimension | What's new")]], [#link("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/#comment-485091")[#strong[#text("On the sign patterns of entrywise positivity preservers in fixed dimension | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2017")])]

#text("[…] with a geometric miracle, namely the Harish-Chandra-Itzykson-Zuber identity, which I discussed in this previous blog post. This factors the above generalised Vandermonde determinant as the product of the ordinary […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7cba62d846d4e053794d289ad4ef850743932132ca593dfcb56546583afcd7ca-72c6d5dce8a5269bb834577e4cc7b4b9a71bb00d24d7395882417c57e3775f0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pietro rotondo")]], [#link("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/#comment-489874")[#strong[#text("pietro rotondo")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2017")])]

#text("Dear Terence,")

#text("we noticed that the HCIZ formula holds also for degenerate eigenvalues of either matrices A and B. However in this case, both the numerator and the denominator are zero and an implicit cancellation occurs. Do you know whether a close formula exists once the cancellation has been explicitly performed?")

#text("Best Regards")#linebreak()#text(" Pietro Rotondo")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e147fe7e8dc936d944937a3f47efe38550f1c75b3a97d2e913730c503b13ef7-4b2596fa5c254f2b75d80954a40f4a309e0551f5792de3d8566186c426cead43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jean-Bernard Zuber")]], [#link("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/#comment-489886")[#strong[#text("Jean-Bernard Zuber")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2017")])]

#text("Well, you may Taylor expand the rows of the determinant that have coalescing arguments. Suppose that ")#mi("a_2, a_3, ...a_{p+1}")#text(" tend to ")#mi("a_1")#text(", while")#linebreak()#text(" the others and the ")#mi("b")#text("‘s are fixed.")#linebreak()#text(" You’ll get a determinant with rows 1 to ")#mi("p+1")#text(" reading ")#mi("\\exp{a_i b_j} ,    b_j \\exp{a_i b_j} , \\cdots ,  b_j^p /p! \\exp{a_i b_j}")#text(", the other rows as usual,")#linebreak()#text(" divided by the Vandermonde of the ")#mi("b")#text("‘s times the Vandermonde of the non coalescing ")#mi("a")#text("‘s.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9481daba421489911cf16088f4ebde0236a9e7c376d2651ddb70e7780229e857-6016fed50aa7ac3893f2b73fc59ccb70a8159150eca1e372c628fb8e9763cb96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lizhongyangmath")]], [#link("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/#comment-491026")[#strong[#text("lizhongyangmath")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2018")])]

#text("Should there be a ")#mi("c_n")#text(" factor on the right hand side of on the right hand side of the equation below “Comparing this against (3)”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/#comment-492879")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2018")])]

#text("It’s a minor thing, but isn’t there a problem with signs in examples 1 and 2? The flow of the hamiltonian vector field is clockwise, while a complex number will rotate anticlockwise when multiplied by a number like exp(it).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/#comment-642516")[#strong[#text("inequalities - Nonnegativity locus of Schur polynomials Answer - Lord Web")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2022")]

#text("[…] means that some Fourier evaluation could breathe helpful for the common illustration, or maybe the Harish-Chandra-Itzykson-Zuber methodhowever I do not know how you can refer about […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0c6e4e09ab917a6f298ead69244da2506441de032e71a76cf1539e65004817f-39a39e6297232aa4f30b95b6e363fd596ee8eecbb44ef87fca5a2d21842765ff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of heroic02ee58ef0c")]], [#link("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/#comment-686902")[#strong[#text("heroic02ee58ef0c")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2024")])]

#text("I need to evaluate the same integral typographically, but with U being the n-dimensional irrep of SU(2) (and the integral being over SU(2)) – A and B are general n x n hermitian matrices, is there any variant of the HCIZ formula that would apply in this case?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/#comment-686910")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2024")])]

#text("This looks like too low-dimensional of an integral to achieve much simplification. Note for instance that the original integral was invariant with respect to conjugating ")#mi("A,B")#text(" separately by arbitrary unitary matrices, which already tells us from the spectral theorem that the integral can only depend on the eigenvalues of ")#mi("A,B")#text(" but not their eigenvectors. But for this low-dimensional integral one only gets invariance with respect to the ")#mi("SU(2)")#text(" conjugation action which only reduces the degrees of freedom of ")#mi("A,B")#text(" by a tiny amount when ")#mi("N")#text(" is large, and so the relative positioning of the eigenvectors of ")#mi("A")#text(" and ")#mi("B")#text(" with each other must play a key role. Note that in the ")#mi("SU(1)")#text(" case when no integration occurs at all, one is just left with ")#mi("\\exp( t \\mathrm{tr}(AB) )")#text(" which has no further simplification available. In certain asymptotic regimes (e.g., ")#mi("t \\to \\infty")#text(") one might be able to obtain a stationary phase approximation, though. And if ")#mi("A,B")#text(" commute then perhaps some simplification is possible.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0c6e4e09ab917a6f298ead69244da2506441de032e71a76cf1539e65004817f-39a39e6297232aa4f30b95b6e363fd596ee8eecbb44ef87fca5a2d21842765ff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of heroic02ee58ef0c")]], [#link("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/#comment-686911")[#strong[#text("heroic02ee58ef0c")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2024")])]

#text("Indeed, my worst fears come true… too little integration to wipe out complexity. As a last resort, would it help if A was a general hermitian matrix but B a very special one, having B_{11}=1 and all other entries equal to zero? In any case, thank you for a very fine post…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/02/08/the-harish-chandra-itzykson-zuber-integral-formula/#comment-687725")[#strong[#text("Math 289A: Lecture 5 – Jonathan Novak")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2025")]

#text("[…] which means that this integral should localize to a sum over permutations. This turns out to be exactly correct, not just a good approximation, and the reasons for this are rooted in symplectic geometry. The end […]")
]
