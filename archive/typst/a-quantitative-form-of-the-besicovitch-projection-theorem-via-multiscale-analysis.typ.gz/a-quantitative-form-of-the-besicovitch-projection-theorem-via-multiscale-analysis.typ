// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/06/19/a-quantitative-form-of-the-besicovitch-projection-theorem-via-multiscale-analysis/
// Converted to Typst by tao2typ: "2026-10-14T15:16:25.100373+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A quantitative form of the Besicovitch projection theorem via multiscale analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A quantitative form of the Besicovitch projection theorem via multiscale analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 June 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/06/19/a-quantitative-form-of-the-besicovitch-projection-theorem-via-multiscale-analysis/")[#text("https://terrytao.wordpress.com/2007/06/19/a-quantitative-form-of-the-besicovitch-projection-theorem-via-multiscale-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’ve just uploaded a new paper to the ")#link("http://www.arxiv.org/")[#text("arXiv")]#text(" entitled “")#link("http://arxiv.org/abs/0706.2646")[#text("A quantitative form of the Besicovitch projection theorem via multiscale analysis")]#text("“, submitted to the ")#link("http://www.lms.ac.uk/publications/journal/index.html")[#text("Journal of the London Mathematical Society")]#text(". In the spirit of my earlier posts on soft and hard analysis, this paper establishes a quantitative version of a well-known theorem in soft analysis, in this case the Besicovitch projection theorem. This theorem asserts that if a subset E of the plane has finite length (in the ")#link("http://en.wikipedia.org/wiki/Hausdorff_dimension")[#text("Hausdorff sense")]#text(") and is ")#link("http://en.wikipedia.org/wiki/Rectifiable_set")[#text("purely unrectifiable")]#text(" (thus its intersection with any Lipschitz graph has zero length), then almost every linear projection E to a line will have zero measure. (In contrast, if E is a rectifiable set of positive length, then it is easy to show that all but at most one linear projection of E will have positive measure, basically thanks to the ")#link("http://en.wikipedia.org/wiki/Rademacher%27s_theorem")[#text("Rademacher differentiation theorem")]#text(".)")

#text("A concrete special case of this theorem relates to the product Cantor set K, consisting of all points (x,y) in the unit square ")#mi("[0,1]^2")#text(" whose base 4 expansion consists only of 0s and 3s. This is a compact one-dimensional set of finite length, which is purely unrectifiable, and so Besicovitch’s theorem tells us that almost every projection of K has measure zero. (One consequence of this, first observed ")#link("http://www.ams.org/mathscinet-getitem?mr=245734")[#text("by Kahane")]#text(", is that one can construct ")#link("http://en.wikipedia.org/wiki/Kakeya_set")[#text("Kakeya sets")]#text(" in the plane of zero measure by connecting line segments between one Cantor set and another.)")

#metadata(none) <tao-db8473379a2041c2c702>

#text("Now let ")#mi("K_n")#text(" be the ")#mi("n^{th}")#text(" generation of the Cantor set construction of K, thus ")#mi("K_n")#text(" is the union of ")#mi("4^n")#text(" squares of sidelength ")#mi("4^{-n}")#text(", and consists of those pairs (x,y) in the unit square whose first n digits in the base 4 expansion consist of 0s and 1s. Define the ")#emph[#text("Favard length")]#text(" ")#mi("Fav(K_n)")#text(" of this set to be the average measure of a random orthogonal projection of this set to a line; roughly speaking, this quantity measures how likely ")#link("http://en.wikipedia.org/wiki/Buffon%27s_needle")[#text("Buffon’s needle")]#text(" will fall within a distance ")#mi("4^{-n}")#text(" of the original Cantor set K. Besicovitch’s theorem thus tells us that this quantity ")#mi("Fav(K_n)")#text(" goes to zero as n goes to infinity, but does not give an explicit rate of convergence.")

#text("The problem of establishing the correct rate of decay for this Favard length has received some recent attention. It turns out to be non-trivial to get any explicit decay at all; this was first done ")#link("http://www.ams.org/mathscinet-getitem?mr=1907902")[#text("by Peres and Solomyak")]#text(", who obtained a bound of the form ")#mi("Fav(K_n) \\ll \\exp(- c \\log_* n)")#text(", where c > 0 is an absolute constant and ")#mi("\\log_* n")#text(" is the inverse tower exponential function, i.e. it is the number k of logarithms needed in order for the ")#mi("k^{th}")#text(" iterated logarithm of n to drop below 2 (say). This is an incredibly slow rate of decay; it has been recently improved substantially in an unpublished preprint of Nazarov, Peres, and Volberg to ")#mi("O(n^{-1/6})")#text(". (In the converse direction, an old argument essentially due to Córdoba, gives a lower bound of ")#mi("\\gg 1/n")#text(".) These arguments exploit heavily the self-similar structure of K. The appearance of the inverse tower exponential seems to be a consequence of the introduction of multiscale analysis methods (working at several scales simultaneously).")

#text("The focus in my paper is not to improve these results for the Cantor set, but instead to try to do something similar for more general unrectifiable sets by quantifying the projection theorem. To do this, one has to make the concept of “purely unrectifiable” quantitative, but perhaps more surprisingly one also has to make more quantitative the notion of “length”. At first glance, length is already a quantitative notion – it is, after all, a number. But hidden in the Hausdorff definition of length (in which one covers the set by balls and then sums the diameters of all these balls) is another parameter, namely the radii of the balls needed to cover the set. It turns out that these radii play an important role in being able to get a quantitative result. Furthermore, it is not enough to cover the set once by balls; one needs a ")#emph[#text("sequence")]#text(" of ball covers, where each cover uses balls that are very small compared to the preceding ball cover. This is necessary in order to perform certain multiscale analysis arguments, which are similar in spirit to the multiscale arguments used to establish various forms of the Lebesgue differentiation theorem in ")#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/")[#text("my previous post")]#text(" (in particular, the finite convergence principle, in the guise of pigeonholing in scales, plays an important role).")

#text("The notation of unrectifiability also needs to be made quantitative, but this turns out to be straightforward: one asks that the original set E does not have a large intersection with a small neighbourhood of a Lipschitz graph of a specified Lipschitz constant.")

#text("Anyway, the main result of the paper is to give an explicit non-trivial upper bound for the Favard length in terms of the quantitative version of Hausdorff length control, and the quantitative version of pure unrectifiability. The precise formulation is a bit technical to state here, but when this machinery is applied to the Cantor set K (with the unrectifiability control provided either by quantitative versions of the Rademacher differentiation theorem, or by ")#link("http://www.ams.org/mathscinet-getitem?mr=1069238")[#text("Peter Jones’ theory of ")#mi("\\beta")#text("-numbers")]#text(", initially introduced in relation to the ")#link("http://en.wikipedia.org/wiki/Traveling_salesman_problem")[#text("traveling salesman problem")]#text(") one obtains a decay rate of ")#mi("Fav(K_n) \\ll (\\log_* n)^{-c}")#text(" for some absolute constant c > 0, which is within ballpark range of the original Peres-Soloymak result, although it is of course still dreadfully slow (but this is typically what one expects when one quantifies a qualitative argument).")

#text("The proof basically consisted of taking the qualitative proof of the Besicovitch projection theorem in ")#link("http://www.ams.org/mathscinet-getitem?mr=1333890")[#text("Mattila’s book")]#text(" and making every step in the argument quantitative. This turned out to be a little tricky in places, for instance any appeal to the Lebesgue differentiation theorem or Rademacher differentiation theorem had to be replaced with a quantitative counterpart. (There was also some appeals to such “obvious” statements as “every finite set is bounded” which also needed to be made quantitative.) My hope is that this paper will serve as a proof-of-concept of how even somewhat non-trivial soft analysis results can be converted, with some effort, into quantitative hard analysis.")
