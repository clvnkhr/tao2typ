// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/
// Converted to Typst by tao2typ: "2026-10-14T11:15:25.954706+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A crowdsourced repository for optimization constants?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A crowdsourced repository for optimization constants?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 January 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/")[#text("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Thomas Bloom’s ")#link("https://www.erdosproblems.com/")[#text("Erdös problem site")]#text(" has become a real hotbed of activity in recent months, particularly as some of the easiest of the outstanding open problems have turned out ")#link("https://github.com/teorth/erdosproblems/wiki/AI-contributions-to-Erd%C5%91s-problems")[#text("to be amenable to various AI-assisted approaches")]#text("; there is now a lively community in which human contributions, AI contributions, and hybrid contributions are presented, discussed, and in some cases approved as updates to the site.")

#text("One of the lessons I draw from this is that once a well curated database of precise mathematical problems is maintained, it becomes possible for other parties to build upon it in many ways (including both AI-based and human-based approaches), to systematically make progress on some fraction of the problems.")

#text("This makes me wonder what other mathematical databases could be created to stimulate similar activity. One candidate that came to mind are “optimization constants” – constants ")#mi("{C}")#text(" that arise from some mathematical optimization problem of interest, for instance finding the best constant ")#mi("{C}")#text(" for which a certain functional inequality is satisfied.")

#text("I am therefore proposing to create a crowdsourced repository for such constants, to record the best upper and lower bounds known for any given such constant, in order to help encourage efforts (whether they be by professional mathematicians, amateur mathematicians, or research groups at a tech company) to try to improve upon the state of the art.")

#text("There are of course thousands of such constants one could consider, but just to set the discussion going, I set up a ")#link("https://github.com/teorth/optimizationproblems")[#text("very minimal, proof of concept Github repository")]#text(" holding over 20 constants including:")

#enum(start: 1, 
[#link("https://github.com/teorth/optimizationproblems/blob/main/constants/1a.md")[#mi("{C_{1a}}")#text(", the constant in a certain autocorrelation quantity relating to Sidon sets")]#text(". (This constant seems to have a surprisingly nasty optimizer; see ")#link("https://x.com/damekdavis/status/1923031798163857814")[#text("this tweet thread of Damek Davis")]#text(".)")],
[#link("https://github.com/teorth/optimizationproblems/blob/main/constants/1b.md")[#mi("{C_{1b}}")#text(", the constant")]#text(" in ")#link("https://www.erdosproblems.com/36")[#text("Erdös’ minimum overlap problem")]#text(".")]
)

#text("Here, I am taking inspiration from the Erdös problem web site and arbitrarily assigning a number to each constant, for ease of reference.")

#text("Even in this minimal state I think the repository is ready to start ")#link("https://github.com/teorth/optimizationproblems/blob/main/CONTRIBUTING.md")[#text("accepting more contributions")]#text(", in the form of pull requests that add new constants, or improve the known bounds on existing constants. (I am particularly interested in constants that have an extensive literature of incremental improvements in the lower and upper bounds, and which look at least somewhat amenable to computational or AI-assisted approaches.) But I would be interested to hear feedback on how to improve the repository in other ways.")

#text("Update: Paata Ivanisvili and Damek Davis have kindly agreed to help run and expand this repository.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (30)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691622")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2026")])]

#text("It looks like the description of C2 needs updating (it’s currently identical to that of C1).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691623")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2026")])]

#text("union-closed, furstenberg-sarkozy, largest sidon set (the last relating to n^{1/2}+C_5n^{1/4})")

#emph[#text("[Good suggestions! I will add these in due course. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691628")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2026")])]

#text("Would these only be for optimization constants stemming from analysis, or would you include ones from e.g. combinatorics as well?")

#text("For example, would the best C so that there is a sunflower-free family of size C^n, or the best C in Schur’s theorem, or the best C so that R(3,…,3)>C^n, or the best C in the capset problem also be suitable candidates for inclusion?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691630")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2026")])]

#text("I am not intending to restrict to analysis. I am beginning to assemble a list of criteria for inclusion in the repository ")#link("https://github.com/teorth/optimizationproblems/blob/main/CONTRIBUTING.md")[#text("here")]#text(". The current list is that constants")

#list(
[#text("have a significant existing mathematical literature, including incremental improvements on bounds;")],
[#text("are still actively being researched;")],
[#text("are at least somewhat amenable to computational approaches for either upper or lower bounds; and")],
[#text("do not depend on additional parameters (such as dimension, or number of objects in a configuration), or have such parameters set to “canonical” or particularly well studied choices for which significant literature exists.")]
)

#text("I have added the capset constant as #4, but will have to think about whether the others would fit the criteria.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691633")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2026")])]

#text("Another good one is the Shannon capacity of the 7-cycle.")

#text("Is the comment section of this blog the best place to suggest such constants, or would you make an email account the way Thomas Bloom made one for the ErdH{o}s problems website?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691637")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2026")])]

#text("One can use this blog, github issues, or github pull requests.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691629")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2026")])]

#text("Would such a website also have a list of relations between the constants? Maybe it’s known that C_9<=C_10<=(C_9)^2 or something like that.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691632")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2026")])]

#text("Yes, these would be appropriate to put in the comments section of the page.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691631")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2026")])]

#text("A reminder that AI-generated comments will not be approved unless the use of AI is explicitly disclosed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/510c66552aeb522f5cb76b75c478fe636cf66825f909bb6c727daf61b2947f20-6dbbb40e17caf4d3068d1767901bd69105f87b499754457556d5c4ae80051e37.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TheCoherenceCat")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691634")[#strong[#text("TheCoherenceCat")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2026")])]

#text("Noted")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691635")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2026")])]

#text("A few more suggestions to improve it. I am not sure if numbering all of the constants is a great idea. People generally don’t want to refer to C_{283} or whatever. Probably a better idea to name them instead, or at least name them as well. Also a search function would be good (does GitHub have that?).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691636")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2026")])]

#text("Experience with the Erdos problem site has been that a static numbering system, even if arbitrary and not particularly readable to humans, is preferable for any sort of automation; if each Erdos problem only had an English name description and not a number it would be a lot harder to build automation on top of the site, particularly if this name was subject to change over time. But I will make a note when a numbered constant also has another name in the literature (for instance ")#mi("C_8")#text(" is traditionally called ")#mi("R")#text("). However, just from the pigeonhole principle alone, once the repository grows beyond a certain size I am sure many of the traditional names for various constants in the literature will inevitably collide, which is another reason why having a unique number index attached to each constant is important.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a88f186987b0b87303dd8c5226d80db8378c564decf2917efbc097bd4149a7fa-9bc07e0467a5420740d16595d68559df391efc597124410ebda895f641fed7f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicolas Rivera")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691638")[#strong[#text("Nicolas Rivera")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2026")])]

#text("For future improvement: I think the constants can have atags/subtag structure such as")

#text("Probability Theory -> Markov Chains")#linebreak()#text("Abstract Algebra -> Group Theory")

#text("or even some depth 3 tags such as")

#text("Combinatorics -> Random Graphs -> Erdos-Renyi Random Graph")

#text("it would be easier for people to navigate, useful for search engines, and whatnot.")

#text("I think that a simple classification is enough, something like the MSC may be too complicated.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69623196083f26afa246072b678f2188163610710a235f6ef4747a90d1b90066-016052af7856bbb36554760ae0237927e4b948e1db1527d14efaad7a2720c433.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dazzling7f8a74a13f")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691645")[#strong[#text("dazzling7f8a74a13f")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2026")])]

#text("I saw on the GitHub page that you added the irrationality measure of pi. In that vein, irrationality measures for pi^n, ln(n), and zeta(n) for various small n could be added. References and other constants with known bounds on their irrationality measures are available in a table at ")#link("https://en.wikipedia.org/wiki/Irrationality_measure")[#text("https://en.wikipedia.org/wiki/Irrationality_measure")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691658")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2026")])]

#text("I am thinking of aiming for a curated set of particularly well studied and representative constants rather than a comprehensive set of all constants that have appeared in the literature, as including all variants of a single constant would decrease the signal-to-noise ratio, and heavily bias the database in favor of constants that happened to have a large number of variants. In the page for the irrationality measure of pi we link to the Wikipedia page for all the other constants.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60c8e67ac51af50861614918e32824130e76d45c39e1ee9a8e2781ee10c68307-cc0300b48666e89def14b64ad6d9f0c6171f490bf96fec419b660ccc5d343a8b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of boonsuan1")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691655")[#strong[#text("boonsuan1")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2026")])]

#text("would growth rates of combinatorial objects be appropriate for this database? that is, ")#mi("c_n")#text(" counts the number of size-")#mi("n")#text(" objects of some kind, and it has been proven that the ")#emph[#text("growth rate")]#text(" ")#mi("\\lim c_n^{1/n}")#text(" existsexamples: ")#link("https://en.wikipedia.org/wiki/Polyomino#Fixed_polyominoes")[#text("polyominoes")]#text("; permutations avoiding some pattern (a popular one to study being ")#link("https://doi.org/10.1016/j.ejc.2020.103115")[#text("1324")]#text("); self-avoiding walks on some lattice; even possibly cases where we don’t know if the limit exists but nonetheless have some bounds, such as with the diagonal ramsey numbersif so, there are quite a lot of constants of this kind")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691659")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2026")])]

#text("The cap set constant #4 is already of this type. I would say that a particularly well studied representative of such constants would be appropriate to add, particularly if there is some chance that computer-assisted methods could plausibly improve the bounds on such constants. But I would rather have one quintessential example of this type than a family of a dozen similar variants (though the page for the quintessential constant can contain links to all the others).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3945b7809286abba658ee75af873a597740719d68beca61d78cbadb5d7042e9f-6896ba09db6278899bf781123736697877abbcb81ebd9c03118def76a04abd9d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691662")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2026")])]

#text("To clarify the role of such a repository – would it be appropriate to include Euler’s number ")#mi("e")#text("? On the one hand, it’s in some sense the canonical optimization constant (so, including it would make the repository analogous to the OEIS); on the other hand, we don’t attach information like “best known upper- and lower-bounds” to it, so including it would draw the repository away from an Erdös problems sort of site.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691667")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2026")])]

#text("I certainly don’t want to duplicate ")#link("https://en.wikipedia.org/wiki/List_of_mathematical_constants")[#text("https://en.wikipedia.org/wiki/List_of_mathematical_constants")]#text(" , so I will focus on constants where there is both past and currently active research on improving the upper and lower bounds.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691665")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2026")])]

#text("I think this is a moment where, if the mathematical (and adjacent) community(/ies) can act quickly, they could potentially have a lot of impact on the metrics by which large AI companies measure success and show value to investors. I think it would be wonderful if, in order to raise capital, AI companies applied their considerable resources to outstanding mathematics problems of interest to actual working mathematicians. With the obvious caveat about the intellectual burden of refereeing such attempts (which I’m sure you’re feeling currently with this surge of AI interest in Erdos problems).")

#text("Along a similar line of thought, I’ve been ")#link("https://github.com/maxvonhippel/budden-bench")[#text("experimenting in the evenings")]#text(" with extracting problem statements from published “open problems” papers in the mathematical corpus. I’m not a real mathematician so my attempt might be flawed or naive, but I think the idea is approx. correct, and hopefully if my implementation is poor, someone more mathematically savvy will do it better.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691666")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2026")])]

#text("Does the Beardwood-Halton-Hammersley travelling salesman constant count? Its upper bound was improved recently")

#link("https://pubsonline.informs.org/doi/10.1287/ijoc.2024.0538")[#text("https://pubsonline.informs.org/doi/10.1287/ijoc.2024.0538")]

#emph[#text("[Thanks, this is now ")#link("https://teorth.github.io/optimizationproblems/constants/12.html")[#text("constant #12")]#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691674")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2026")])]

#text("I’m not sure is it just me or the latex in the problem subpages are in plain text and very hard to read.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691680")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2026")])]

#text("The matrix-multiplication exponent (commonly denoted ω) seems to fit the rules.")

#text("Regarding the question about appropriateness of e : so if the gap is eventually closed (the lower bound == upper bound), and consequently there is no further research, it will be removed from the site?")

#text("Regarding the question about numbering: another famous example of a numbered database of mathematical objects is OEIS.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691684")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2026")])]

#text("That’s a good suggestion! I will work on adding it.")

#text("I have updated the contributing instructions regarding constants that have managed to close the gap. If this was a recent accomplishment and there is a non-trivial sequence of prior upper and lower bounds in the literature, this would still qualify for this repository, and certainly I would not plan to remove any constant for which the math community had managed to work out exactly! But if, say, the constant was worked out exactly over a century ago (e.g., the isoperimetric constant in two dimensions), I don’t think it would add much value to the site to include it here.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691689")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2026")])]

#text("I guess Steven Finch’s book might provide some additional candidates.")

#link("https://www.cambridge.org/us/universitypress/subjects/mathematics/recreational-mathematics/mathematical-constants?format=HB&isbn=9780521818056#contents")[#text("https://www.cambridge.org/us/universitypress/subjects/mathematics/recreational-mathematics/mathematical-constants?format=HB&isbn=9780521818056#contents")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691691")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2026")])]

#text("As the number of constants in the repository continues to increase, it might be useful to include a list of recently-published papers that improve on one (or more) constants. Something similar to the “Recent Papers” column on the Erdős Problems website. Otherwise it would be quite difficult for someone to keep track of recent progress without having to manually check the pages of specific constants.")

#emph[#text("[This is now implemented – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691719")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2026")])]

#text("how about how many standard deviations suffice?")

#link("https://mathoverflow.net/questions/175826/spencers-six-standard-deviations-theorem-better-constants")[#text("https://mathoverflow.net/questions/175826/spencers-six-standard-deviations-theorem-better-constants")]

#text("A celebrated theorem of Spencer states that for a combinatorial discrepancy problem ( described in the post above), one can let the discrepancy be 6, the question of how many standard deviations suffice is open, with Dan Speilman suggesting perhaps only 2 suffices…")

#emph[#text("[Now added as ")#mi("C_{10c}")#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691768")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2026")])]

#text("I’m cheering you on.")

#text("I’d stepped away from math for quite a while.")

#text("But as I’ve been reviewing all the problems on the Erdos problem site this time around, math has become a hobby again.")

#text("This kind of approach…")

#text("really does seem like a good direction for getting more people interested in math.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-691853")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2026")])]

#text("Since you include other number-theoretic constants, I would add the constant in the Generalied Ramanujan Conjecture: the smallest ")#mi("\\delta_n")#text(" such that the spectral parameters of a ")#mi("\\mathrm{GL}_n")#text(" automorphic form have real parts at most ")#mi("\\delta_n")#text(" (this extends the Ramanujan–Petersson case ")#mi("n=2")#text(" for holomorphic forms, resolved by Deligne as well as Selberg’s ")#mi("\\frac14")#text(" Conjecture for Maass forms).")

#text("This has a classical formulation in terms of Fourier coefficients of Hecke newforms and Hecke–Maass forms on congruence quotients.")

#text("Conjecturally (and follows from the Langlands Conjectures) the value is ")#mi("\\delta_n = 0")#text(". Unitarity give $\\delta \\leq \\frac{n-1}{2}$; the first bound beyond that was Jacquet–PS–Shalika $\\delta \\leq \\frac12$. This is thought of as the “trivial” bounds but is only trivial for ")#mi("n=2")#text(" when it coincides with the bound from unitarity.. The best general bound is Luo–Rudnick–Sarnak ")#mi("\\delta_n \\leq \\frac12 - \\frac{1}{n^2+1}")#text(" (due ot Müller–Speh at ramified places).")

#text("For ")#mi("n=2")#text(" the best bound is ")#mi("\\delta_2 \\leq \\frac{7}{64}")#text(" due to Kim–Sarnak (and Blomer–Brumley over number fields beyond the rational numbers).")

#text("See also ")#link("https://en.wikipedia.org/wiki/Ramanujan%E2%80%93Petersson_conjecture")[#text("Wikipedia")]#text(" and ")#link("https://publications.ias.edu/sites/default/files/FieldNotesCurrent.pdf")[#text("Sarnak’s 2005 survey")]#text(".")

#emph[#text("[")#link("https://teorth.github.io/optimizationproblems/constants/56a.html")[#text("Now added as $C_{54}$")]#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e0d96e12532aa145475ef498b1d7a74a7e5e54bd10fa9c6b04ed0ea9f9130c2-2e4d9dcaf300e3084c7fa20d28f3b01c47bc601ab56d163d695f0ecffcfb842a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sagaistrue")]], [#link("https://terrytao.wordpress.com/2026/01/22/a-crowdsourced-repository-for-optimization-constants/#comment-696576")[#strong[#text("sagaistrue")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("Dear Professor Tao,")

#text("I am an independent researcher (sagaistrue), writing to contribute to the optimization-constants repository concerning C₁b, the constant in Erdős’s minimum overlap problem.")

#text("Using a purely analytic approach based on the intrinsic fissure LX₂ = 6Φ² − 5π between the algebraic number Φ² and the transcendental number π, I derive a dual-extremum interval for the overlap constant:")

#text("sup S₁ ≈ 0.380422678036171, inf S₁ ≈ 0.380422666213373.")

#text("Both values fall strictly inside the current best bound [0.379005, 0.380868] and pin the interval to 10⁻⁸ precision — roughly 158,000 times tighter than existing convex-optimization and AI-search bounds — with no function-space search involved.")

#text("An interpretive analysis links the frozen 10⁻³ shell of single-domain methods to the Gibbs phenomenon: harmonic analysis, whose basis is precisely Euler’s formula, cannot eliminate the symmetric overshoot at the discontinuity (the phase wall), whereas the fissure bypasses it directly.")

#text("The full derivation is available on Zenodo: ")#link("https://doi.org/10.5281/zenodo.22996537")[#text("https://doi.org/10.5281/zenodo.22996537")]

#text("I would be grateful if the bounds could be checked against the repository’s records, and I am happy to provide any further details.")

#text("Best regards, sagaistrue")
]
