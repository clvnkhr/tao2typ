// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/11/16/ucla-math-undergraduate-merit-scholarship-for-2010/
// Converted to Typst by tao2typ: "2026-10-14T15:17:56.379233+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "UCLA Math Undergraduate Merit Scholarship for 2011", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("UCLA Math Undergraduate Merit Scholarship for 2011")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 November 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/11/16/ucla-math-undergraduate-merit-scholarship-for-2010/")[#text("https://terrytao.wordpress.com/2010/11/16/ucla-math-undergraduate-merit-scholarship-for-2010/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[Some advertising on behalf of my department. The inaugural 2009 scholarship was ")#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/")[#text("announced on this blog")]#text(" last year. – T.]")]

#metadata(none) <tao-0630528f8ba94a63efe4>

#metadata(none) <tao-fd06da72a0be46f9a13c>

#text("Last year, the UCLA mathematics department launched a scholarship opportunity for entering freshman students with exceptional background and promise in mathematics. We intend to offer one new scholarship every year.")

#text("The UCLA Math Undergraduate Merit Scholarship provides for full tuition, and a room and board allowance for 4 years. In addition, scholarship recipients follow an individualized accelerated program of study, as determined after consultation with UCLA faculty. ")#emph[#text("[For instance, this year’s scholarship recipient is currently taking my ")#link("http://www.math.ucla.edu/~tao/245a.1.10f")[#text("graduate real analysis class")]#text(" – T.] ")]#text("The program of study leads to a Masters degree in Mathematics in four years.")

#text("More information and an application form for the scholarship can be found on the web at:")

#link("http://www.math.ucla.edu/ugrad/meritscholarship.shtml")[#text("http://www.math.ucla.edu/ugrad/meritscholarship.shtml")]

#text("To be considered for Fall 2011, candidates must apply for the scholarship and also for admission to UCLA on or before November 30, 2010.")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7431878bfd0797a2d7f29b47954794878a280f1b5ec115e32876f2242f41b9b2-c7a06b57fe214b8b15b4dd980586f79d09dd5025e2b71922c0743132f75e1954.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M")]], [#link("https://terrytao.wordpress.com/2010/11/16/ucla-math-undergraduate-merit-scholarship-for-2010/#comment-48152")[#strong[#text("M")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2010")])]

#text("I am not opposed to such scholarships but…. I have some general concerns about any program that tries to specialize people at a very young age. A person who gets a scholarship like above and as a freshman starts taking classes with graduate students and senior, who are all quite committed to mathematics, is probably on a one-way to ticket to become a mathematician. Do you really think it is correct for a person to commit himself or herself so seriously to mathematics as early as this?")

#text("I don’t know anything about this particular program here, maybe the mechanics of the program is designed properly so that the person is not completely absorbed in mathematics, because as we all know it can be quite absorbing, and there is enough time left for him to develop socially and otherwise. But my concern is not about this particular program but such programs in general, contest camps, specialized math school and etc.")

#text("You have heard these things probably so many times that I think and hope that you can easily give me a swift and comforting answer. I really beleive there is some danger in mathematics for young people. A 12 year old can easily become fascinated with math. His brain has the capacity to learn the subject as well as a 22 year old graduate student and it is probably equally fascinating for them. But what a 12 year old lacks, generally, compared to a 22 year old is a vision for his life. ( including familiarity with different disciplines like medicine, law, biology, physics, politics and etc which he might 20 years later on the road realize to be more important discipline than math in a certain sense, and a lot of social skills, and time is not translation invariant for the purpose of developing such skills) So I conclude that it is okay for a 22 year old to commit himself or herself to mathematics, but it might not be okay for younger people. And so, any sort of program that creates an environment for a person to grow one-dimensionally at a young age by pouring mathematics into him and blocking his vision to other aspects of life is dangerous and maybe undesirable.")

#text("Sorry for grammar mistakes and typos, I have no time to proofread.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/16/ucla-math-undergraduate-merit-scholarship-for-2010/#comment-48166")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2010")])]

#text("A couple points:")

#text("1. With regards to this specific scholarship, the applicants will be incoming undergraduates, whose ages would be closer to 16 than to 12. Not every class in the individualized program of study will necessarily be a graduate course, or even a mathematics course; the appropriate level and number of courses to take is worked out after consultation between the student and the faculty, and will of course depend heavily on what the student will be capable of, is interested in, and is comfortable with.")

#text("2. More generally, I don’t see that increased exposure to, say, higher mathematics is necessarily a “one-way ticket” to becoming a mathematician, though it obviously is a useful preparation for such a possible career goal. Like many other academic disciplines, the real value of an education in higher mathematics does not primarily come from the actual material being taught, but by the broader skills one picks up, which in the case of mathematics includes the ability to think abstractly, rigorously, and analytically when faced with complex problems, and as such the training given by a higher mathematics degree can be valuable in many careers outside of academic mathematics, such as in IT, finance, or the sciences (and indeed, many students with this training end up with successful careers of this type, or in careers that in fact ostensibly have very little to do with higher mathematics).")

#text("3. While it is true that the difficulty of learning a skill is not time translation invariant, it seems to me that this lack of invariance largely disappears when one integrates over time. In my own accelerated education, for instance, I was too young to really appreciate the humanities during my primary and secondary education, or to be ready for much of the social activity there, but conversely, once I was a graduate student, that same acceleration gave me the time and perspective to return to these things. So, in my case at least, I feel that the net opportunity cost of my own educational path was not as great as one might initially think.")

#text("4. That said, though, I certainly agree that pursuing acceleration for its own sake can be quite counterproductive, especially if done without regard for the broader interests of the student involved. It is perhaps best viewed as the educational equivalent of a time management tool, that allows one to efficiently proceed with one aspect of a student’s education, thus freeing up time later on to devote to the other aspects. As such, knowing when to stop the acceleration is just as important as knowing when it to start it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7431878bfd0797a2d7f29b47954794878a280f1b5ec115e32876f2242f41b9b2-c7a06b57fe214b8b15b4dd980586f79d09dd5025e2b71922c0743132f75e1954.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M")]], [#link("https://terrytao.wordpress.com/2010/11/16/ucla-math-undergraduate-merit-scholarship-for-2010/#comment-48171")[#strong[#text("M")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2010")])]

#text("Prof Tao,")

#text("I am sorry. In all honesty I have to admit that your response didn’t seem to quite address my central concern. It is embarrassing for me to repeat, nonetheless I do.")

#text("My main point was that a 16 year old might lack the necessary vision for his life to put himself into a track that takes him so far into a specialization. He might feel certain about what he wants to become but that determination, like the determination of his somewhat younger version to become an astronaut, is quite premature. These programs provide a lot of incentive for such young people to act on their premature desires. Let me proceed by analogy, the situation of a mathematician allowing a teenager to specialize very early and then justify his own action by mentioning the fact the teenager himself asked him this is similar to the case of the dad who lets his 12-year old drive a car because he asked him to.")

#text("It is true even if the person who has committed himself to math at a young age realizes later on that he has chosen a wrong path, not everything is lost and he can still take a different path. But why specialize first and then go back. The alternative to take a broad view early on and specialize later after careful consideration is more natural. The programs like above break this natural order by providing incentive to specialize early on. By the way, wasn’t it awkward in your own experience to specialize first before achieving a broad view? The alternative looks way more sound.")

#text("About your answer :")#linebreak()#text(" point 3: Your case was an exceptional case. For most people I beleive it might be hard to recover from some deficiencies.")

#text("point 4: Your treatment of accelerated programs as a time management optimizer was rather simplistic to my taste. If the point of life was to at a certain checkpoint , say 30 years old, to have achieved certain goals then a reshuffling of one’s activities, in order to achieve more in less time would be certainly desirable. However, as most people would probably agree, the point of life is not to satisfy a boundary condition, but to have a meaningful time in between. ( Heaven’s sake, For all of us the ultimate boundary conditions are quite boring from both sides.)")

#text("I hope that my directness in writing is not taken as rudeness. I truly admire your work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Séguin")]], [#link("https://terrytao.wordpress.com/2010/11/16/ucla-math-undergraduate-merit-scholarship-for-2010/#comment-48172")[#strong[#text("Richard Séguin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2010")])]

#text("M,")

#text("I think it’s healthy for exceptionally bright kids to focus intensely on whatever they are interested in, and they don’t thrive without it. That kind of focus is partially learned, develops less naturally as we age, and generalizes to other interests later in life. I wonder if you would say the same things about young kids who specialize early in life in music, dance, athletics, etc. Is it terrible for a talented kid to go to a specialized school such as the Juilliard? And certainly, an early specialization in mathematics is more portable and much less risky for the kids’ future.")

#text("Just keep thinking of all those sad kids who wander aimlessly through college and never really develop a true interest in anything. (A lot of those probably go into politics.) I would much rather see a young mathematician with drive.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of San")]], [#link("https://terrytao.wordpress.com/2010/11/16/ucla-math-undergraduate-merit-scholarship-for-2010/#comment-48178")[#strong[#text("San")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2010")])]

#text("M, What works for one person might not work for another person. We have to admit that not everyone becomes the individual they wanted to be, no matter how many different opportunities arise, in the end they can only bet on one, and speaking for myself, I’d be much happier making the wrong decision with full conviction even if that conviction does stem from naivety.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/11/16/ucla-math-undergraduate-merit-scholarship-for-2010/#comment-48219")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2010")])]

#text("prof Tao,id lyk 2 ask y such scolarships aren’t provided to students that thrive academicaly in maths,can’t atleast a few students from Africa be given a chance,after all maths is a universal language.")#linebreak()#text(" Cncerncd")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5adbdbf1bcd3cdf60d296e091a02fd8a5bf6fd84f4075fd68c0be69be3d44b06-4d50c35ed1b8537dea6cc2322f8d00c1465ab9da6b3e7298a0e901becfef3fc9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SQ")]], [#link("https://terrytao.wordpress.com/2010/11/16/ucla-math-undergraduate-merit-scholarship-for-2010/#comment-48224")[#strong[#text("SQ")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2010")])]

#text("bt apprntly englssh isnot a unvrsall langaege")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dick")]], [#link("https://terrytao.wordpress.com/2010/11/16/ucla-math-undergraduate-merit-scholarship-for-2010/#comment-48223")[#strong[#text("Dick")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2010")])]

#text("I hope they are not taking away school funds for this because UCLA")#linebreak()#text(" is already cash-strapped. If anything, they should set aside some funding for socioeconomic disadvantaged students who show potential in math.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/16/ucla-math-undergraduate-merit-scholarship-for-2010/#comment-48229")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2010")])]

#text("UCLA does have over 250 need-based scholarships, see ")#link("http://www.fao.ucla.edu/uclascholarships/need_based.pdf")[#text("http://www.fao.ucla.edu/uclascholarships/need_based.pdf")]

#text("By their nature, need-based scholarships are usually not as tied to a particular department as merit-based scholarships are, and so are usually administered centrally (in this case, by the UCLA financial aid office).")

#text("Both types of scholarships usually rely (at least in part) on donations from private individuals or organisations, rather than from general university funds, so they are not necessarily competing for funds in a zero-sum environment.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/11/16/ucla-math-undergraduate-merit-scholarship-for-2010/#comment-48233")[#strong[#text("AMS Graduate Student Blog » Blog Archive » UCLA Math Undergraduate Merit Scholarship for 2010")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2010")]

#text("[…] recently noticed this offer of a scholarship on Terry Tao’s blog. We intend to offer one new scholarship every […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2010/11/16/ucla-math-undergraduate-merit-scholarship-for-2010/#comment-48245")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2010")])]

#text("It is interesting to note that the need based scholarship is for at most $3000 (for one year) and could be as little as $500. This is very different from the scholarship you’re advertising, which offers a full tuition waiver for 4 years in addition to an allowance for room and board.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/11/16/ucla-math-undergraduate-merit-scholarship-for-2010/#comment-48256")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2010")])]

#text("As I mentioned earlier, there are a number of fundamental differences between need-based assistance and merit-based assistance. For need-based assistance, scholarships are only a small component of a much broader array of financial assistance tools (see e.g. ")#link("http://www.fao.ucla.edu/fao_information_types.htm")[#text("http://www.fao.ucla.edu/fao_information_types.htm")]#text(" for a list), and the primary aim is to spread this assistance to as many people as possible. In contrast, there is a much smaller pool of applicants who are genuinely qualified for merit-based assistance, who are often choosing between several good universities, and so merit-based assistance tends to be much more competitive, giving fewer awards, but offering more assistance in each award.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5adbdbf1bcd3cdf60d296e091a02fd8a5bf6fd84f4075fd68c0be69be3d44b06-4d50c35ed1b8537dea6cc2322f8d00c1465ab9da6b3e7298a0e901becfef3fc9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SQ")]], [#link("https://terrytao.wordpress.com/2010/11/16/ucla-math-undergraduate-merit-scholarship-for-2010/#comment-48294")[#strong[#text("SQ")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2010")])]

#text("I don’t think it’s that unusual for universities to offer a small number of “free rides” to especially promising students. Maybe UCLA should offer better financial aid to their best applicants overall but really this kind of thing is not that unusual.")

#text("One thing though.. since it’s one per year it does place a lot of pressure on the winner. As the officially designated best math undergrad of his class, it would look pretty bad if he was not a truly outstanding student.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of UCLA Math Undergraduate Merit Scholarship for 2011 « What’s new")]], [#link("https://terrytao.wordpress.com/2010/11/16/ucla-math-undergraduate-merit-scholarship-for-2010/#comment-104497")[#strong[#text("UCLA Math Undergraduate Merit Scholarship for 2011 « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2011")])]

#text("[…] again, some advertising on behalf of my department, following on a similar announcement in the previous two years.] Two years ago, the UCLA mathematics department launched a scholarship opportunity for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of UCLA Math Undergraduate Merit Scholarship for 2013 « What’s new")]], [#link("https://terrytao.wordpress.com/2010/11/16/ucla-math-undergraduate-merit-scholarship-for-2010/#comment-192987")[#strong[#text("UCLA Math Undergraduate Merit Scholarship for 2013 « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2012")])]

#text("[…] [Once again, some advertising on behalf of my department, following on a similar announcement in the previous three years.] […]")
]
