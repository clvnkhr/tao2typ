// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/
// Converted to Typst by tao2typ: "2026-10-14T08:49:31.289882+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Displaying maths online, II", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Displaying maths online, II")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 November 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/")[#text("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("As the previous discussion on ")#link("https://terrytao.wordpress.com/2009/10/29/displaying-mathematics-on-the-web/")[#text("displaying mathematics on the web")]#text(" has become quite lengthy, I am opening a fresh post to continue the topic. I’m leaving the previous thread open for those who wish to respond directly to some specific comments in that thread, but otherwise it would be preferable to start afresh on this thread to make it easier to follow the discussion.")

#text("It’s not easy to summarise the discussion so far, but the comments have identified several existing formats for displaying (and marking up) mathematics on the web (")#link("http://en.wikipedia.org/wiki/MathML")[#text("mathML")]#text(", ")#link("http://www.math.union.edu/~dpvc/jsMath/")[#text("jsMath")]#text(", ")#link("http://www.mathjax.com/")[#text("MathJax")]#text(", ")#link("http://en.wikipedia.org/wiki/OpenMath")[#text("OpenMath")]#text("), as well as a surprisingly large number of tools for converting mathematics into web friendly formats (e.g. ")#link("http://www.latex2html.org/")[#text("LaTeX2HTML")]#text(", ")#link("http://math.etsu.edu/LaTeXMathML/")[#text("LaTeXMathML")]#text(", ")#link("http://lucatrevisan.wordpress.com/latex-to-wordpress/")[#text("LaTeX2WP")]#text(", ")#link("http://www.gottabemobile.com/2008/10/29/windows-7-math-input-panel-screenshots")[#text("Windows 7 Math Input")]#text(", ")#link("http://golem.ph.utexas.edu/~distler/blog/itex2MML.html")[#text("itex2MML")]#text(", ")#link("http://ritex.rubyforge.org/")[#text("Ritex")]#text(", ")#link("http://www.albany.edu/~hammond/gellmu/")[#text("Gellmu")]#text(", ")#link("http://www.forkosh.dreamhost.com/source_mathtex.html")[#text("mathTeX")]#text(", ")#link("http://wordpress.org/extend/plugins/wp-latex/")[#text("WP-LaTeX")]#text(", ")#link("http://www.cse.ohio-state.edu/~gurari/TeX4ht/")[#text("TeX4ht")]#text(", ")#link("http://www.blahtex.org/")[#text("blahtex")]#text(", ")#link("http://plastex.sourceforge.net/")[#text("plastex")]#text(", ")#link("http://hutchinson.belmont.ma.us/tth/")[#text("TtH")]#text(", ")#link("http://www.dessci.com/webmath/webeq/")[#text("WebEQ")]#text(", ")#link("http://www.integretechpub.com/techexplorer/")[#text("techexplorer")]#text(", etc.). Some of the formats are not widely supported by current software, and by current browsers in particular, but it seems that the situation will improve with the next generation of these browsers.")

#text("It seems that the tools that already exist are enough to improvise a passable way of displaying mathematics in various formats online, though there are still significant issues with accessibility, browser support, and ease of use. Even if all these issues are resolved, though, I still feel that something is still missing. Currently, if I want to transfer some mathematical content from one location to another (e.g. from a LaTeX file to a blog, or from a wiki to a PDF, or from email to an online document, or whatever), or to input some new piece of mathematics, I have to think about exactly what format I need for the task at hand, and what conversion tool may be needed. In contrast, if one looks at non-mathematical content such as text, links, fonts, non-Latin alphabets, colours, tables, images, or even video, the formats here have been standardised, and one can manipulate this type of content in both online and offline formats more or less seamlessly (in principle, at least – there is still room for improvement), without the need for any particularly advanced technical expertise. It doesn’t look like we’re anywhere near that level currently with regards to mathematical content, though presumably things will improve when a single mathematics presentation standard, such as mathML, becomes universally adopted and supported in browsers, in operating systems, and in other various pieces of auxiliary software.")

#text("Anyway, it has been a very interesting and educational discussion for me, and hopefully for others also; I look forward to any further thoughts that readers have on these topics. (Also, feel free to recapitulate some of the points from the previous thread; the discussion has been far too multifaceted for me to attempt a coherent summary by myself.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (25)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e8565e89081c1ada71ea6a8a6e394aa8e30907039f0fcc6d2b29b3009bc7fff4-6155247b3582cdaec707eb5c5f33d5e291d90cfa10c48fc0e2a204d6baea5cf6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ARS")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-42222")[#strong[#text("ARS")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2009")])]

#text("I had not heard about MathJax, a not yet ready successor to the excellent Mathjs.")#linebreak()#text(" On the Mathjax site it is announced that MathScinet will adopt MathJax, which makes it a serious contender. Also linked on tha site was the following article, which is about Math on the web:")#linebreak()#text(" ")#link("http://www.americanscientist.org/issues/pub/2009/3/writing-math-on-the-web/1")[#text("http://www.americanscientist.org/issues/pub/2009/3/writing-math-on-the-web/1")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-42223")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2009")])]

#text("Much of mathematics is offline. While scans of older papers can be put online, the scans have many of the deficiencies that people have pointed out concerning using images to represent equations.")

#text("For that reason, equation OCR seems to me like it should be part of the puzzle. I recently found a program called ")#link("http://www.inftyproject.org/en/software.html#InftyReader")[#text("INFTYreader")]#text(" which seems to convert scans to LaTeX or MathML. I would be interested to know if there are others.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1d42168f0d29b83519498d6b15cefab628ea4102e81dfab59d17660cf095f12-e51bf28cb5cd6ba395b6e395f3dd9ac80cd20f708c7203de4e889ab0fa7d8a33.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Stacey")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-42227")[#strong[#text("Andrew Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2009")])]

#text("One solution to this issue would be to persuade the reCaptcha people to provide a mathematical variant. For those who don’t know, reCaptcha is one of those ways of testing whether someone filling in a form is a human or robot. It asks the user to type in two words that it displays on the screen. One of these words is already known to the reCaptcha engine and that is used to test the humanity of the user. The other word is unknown and the user’s answer goes towards converting scanned documents.")

#text("At the moment, they’re doing the New York Times. It would be great if we could persuade them to do old mathematical papers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ed2bd4f087488d097ffd7e1360a6f19b1f97225937b5f82d9c1658850337c12-4db2c95ba69597c77c5b811667f537259a25771e02a8d45824d49c61faa3aa7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Nikolov")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-42242")[#strong[#text("Alex Nikolov")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("this will be more complicated. do u suggest adding additional interface to make the entering math content easier (can’t expect users to latex it in i guess)? then both words would have to be a formula, otherwise ppl might just not bother and put in jibberish for the math content, knowing the ‘real’ captcha is other word")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1d42168f0d29b83519498d6b15cefab628ea4102e81dfab59d17660cf095f12-e51bf28cb5cd6ba395b6e395f3dd9ac80cd20f708c7203de4e889ab0fa7d8a33.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Stacey")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-42249")[#strong[#text("Andrew Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("Even if it just did the words then it would be a step in the right direction. I agree that the mathematics might be a little trickier. Again, a first step would be to simply identify the characters, thus a “mathematical word” would be simply a letter. There are enough characters in use in mathematics that this would still be sufficiently tricky for a computer to do!")

#text("But even if the words are all that’s feasible, once the words are right it wouldn’t be too much work for a graduate student to fill in the rest.")

#text("Ideally, if we could get rid of the pesky copyright issues, when reading an old paper and taking notes on it, one should type bits of it in to some central site. But that’s another idea for another day.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43c6e8a8da64cd8d8330e0a17b568edb712ad8e78efffeac790325f83615fb0a-4dfb49c86896fc83cb3dd6340ed6fef67136274d82d04398453780f35237e326.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jonathanfine")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-42240")[#strong[#text("jonathanfine")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("One of the problems is that it’s difficult to keep track of what’s going on in mathematical content. To help here, a couple of months ago I started bookmarking URLs related to technical aspects of mathematical content.")

#text("You can see what I’ve got at")#linebreak()#text(" ")#link("http://delicious.com/mathcontent/")[#text("http://delicious.com/mathcontent/")]

#text("And if you go to")#linebreak()#text(" ")#link("http://delicious.com/mathcontent/survey")[#text("http://delicious.com/mathcontent/survey")]#linebreak()#text(" you’ll see the American Scientist article that has been mentioned a couple of times in comments to the previous post. And you’ll also find a blog post by Jon Udell on WordPress and polymath. (This is a teaser to encourage you to visit the URL.)")

#text("I welcome all offers of help to keep the list of bookmarks up-to-date.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1d42168f0d29b83519498d6b15cefab628ea4102e81dfab59d17660cf095f12-e51bf28cb5cd6ba395b6e395f3dd9ac80cd20f708c7203de4e889ab0fa7d8a33.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Stacey")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-42250")[#strong[#text("Andrew Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("I think that Michael’s comments in the other thread are the real “killer app” for MathML. To display mathematics on the web in a way that is accessible for all, means MathML. Anything else is merely a patch while we wait for others to catch up. If all the maths blog converted to MathML then I’d bet that we’d see things move a lot more quickly in the remaining implementation issues.")

#text("Then there’s the issue of generating the MathML, since who wants to type it directly? Here, the more tools the better! After all, it doesn’t matter what the source is, so long as the output is right. So someone who wants to do dynamic content will use something like itex2MML, which is fast but only a subset of LaTeX (well, not quite a subset), whereas someone who is producing mainly static content and who has one eye on the possibility of publishing that content as a book, will use genuine LaTeX as their source and something like TeX4ht as their converter.")

#text("I’m not sure that the non-mathematical picture is as rosy as you paint, but we’re more familiar with it and step around the potholes without noticing that they are there. Plus there are more people in the text, images, video business than in the mathematics business so they have an unfair advantage. But when I think of the hassles I have to go through when someone emails me a word document, or the irritation at having to download yet another codec to play a DVD, or wonder if it’s legal to view images that are GIFs, then I’m not so sure that everything is “sorted out”.")

#text("And I’m not sure that I want it to be. I want to be able to use Emacs for writing all my documents. I want to be able to use LaTeX to do even invitations to birthday parties (thanks to the magic of tikz). I don’t expect everyone to do the same, but so long as the final format is something that I can read, I don’t really care how it was produced. But the important thing is knowing what formats can be widely read.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43c6e8a8da64cd8d8330e0a17b568edb712ad8e78efffeac790325f83615fb0a-4dfb49c86896fc83cb3dd6340ed6fef67136274d82d04398453780f35237e326.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jonathanfine")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-42257")[#strong[#text("jonathanfine")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("Implicit in latex2wp is a standard for TeX-notation mathematics, and also for the LaTeX markup of the source document.")

#text("A standard for TeX-notation mathematics together with a high-quality translator of standard TeX-notation mathematics to MathML would be a great help. Only by having standards for input can we be sure that we will get decent output from the translator (Garbage In, Garbage Out).")

#text("For me, most or all of the benefits of MathML follow from being a specified language. On the basis of the specification software can be built. Because MathML is specified, MathML to voice software can be developed. The same is not, at present, true of TeX notation mathematics.")

#text("In the long term I’d like to see TeX-notation mathematics and MathML to be something like JSON and XML. Two different ways of representing essentially the same underlying data.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1d42168f0d29b83519498d6b15cefab628ea4102e81dfab59d17660cf095f12-e51bf28cb5cd6ba395b6e395f3dd9ac80cd20f708c7203de4e889ab0fa7d8a33.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Stacey")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-42259")[#strong[#text("Andrew Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("I wouldn’t. I like the flexibility of TeX and I wouldn’t give that up for compatibility with MathML at all. I don’t want to change LaTeX one single bit to get it to work with the web, at least for static stuff. I’m prepared to make sacrifices for dynamic content, but then I want to work with a subset of LaTeX, or as close as possible.")

#text("But LaTeX is a programming language and that’s what makes it bearable. When writing a recent paper, my coauthor and I had absolutely no idea what would make good notation, so we built in a complicated system of macros so that not only could a few commands be changed by a single modification, but that would propagate on down into levels beyond what mere substitution macros can cope with. We basically had Object Oriented LaTeX. At one point, we even had it so that composition and evaluation of functions could be switched from left to right (and everything else would switch as well).")

#text("I think that’s something that hasn’t been remarked on yet. It’s implicit in the dynamic vs static dichotomy. Papers tend to be written over a long scale of time (relatively speaking). Blog posts, even wiki pages, tend to be written over a much shorter scale of time. I put much more time and effort into a paper than into a webpage. I’m not completely sure I could explain why; partly, papers are more “mine” than any webpage (even my own) feel like, papers are, at the end of the day, what will last of my work (even though, I concede, they may be published online and in (X?HT|Math)ML format). So I craft them more carefully, and so what the full power of LaTeX to do so.")

#text("So don’t you dare downgrade LaTeX just to fit in with the rather limited spec of MathML!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43c6e8a8da64cd8d8330e0a17b568edb712ad8e78efffeac790325f83615fb0a-4dfb49c86896fc83cb3dd6340ed6fef67136274d82d04398453780f35237e326.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jonathanfine")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-42271")[#strong[#text("jonathanfine")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("Andrew: You wrote ”When writing a recent paper, my coauthor and I had absolutely no idea what would make good notation, so we built in a complicated system of macros so that not only could a few commands be changed by a single modification, but that would propagate on down into levels beyond what mere substitution macros can cope with.”")

#text("Would that be your paper “Hunting the Hopf ring” (whose source is available on the arXiv)? If so, I’ll take a look at your macros and text, and will then understand better your point.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1d42168f0d29b83519498d6b15cefab628ea4102e81dfab59d17660cf095f12-e51bf28cb5cd6ba395b6e395f3dd9ac80cd20f708c7203de4e889ab0fa7d8a33.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Stacey")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-42275")[#strong[#text("Andrew Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("It would.")

#text("One aspect of the “Object Oriented” approach that has just occurred to me is that it does make it easier to add low-level semantics to the document. The fact that, in that paper, we write delt for an element of an object of a (concrete!) category D and dmor for a morphism in the category D even though these resolve to the same symbol means that from the source code, it is always clear when d means an element and when d means a morphism.")

#text("I’m partially doing this in the lecture notes for my current course. I find it hard to parse a slide full of stark (raving) mathematics, so I can only imagine how my students find it. So to try to help them make the connections, I’ve been adding colour: vectors are one colour, scalars another, matrices a third, and so forth (I won’t claim that I’ve been consistent: what colour should the entries of a matrix be?). I do this by using the code \\type{vector}{x} and so forth. Then I can modify how all the vectors are displayed in a single command.")

#text("Someone made the point about semantics over in the other thread, and I pooh-poohed it a little. The point is that telling people to add semantics to make other people’s lives easier is never going to work: even if people agree that it’s a good idea, it just takes too much time. However, saying that adding “type” macros to your document makes it easier to write papers, and here’s an easy style file that makes it so very easy to do, oh and incidentally you’ll be helping a lot of other people. Well, then people might start doing it.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1da12961d48b93edbe2e3c50283bb92590bf53c1bd2c464b653f1d4e826ce324-07056772fde2381ee62936741974264236a4beefcfb9b82a1cf14eb935c77a8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Krautzberger")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-42272")[#strong[#text("Peter Krautzberger")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("Since it’s not mentioned yet, I wanted to point out the discussion from the first thread regarding PDF/A-1a ")#link("http://www.pdfa.org/doku.php?id=artikel:en:improved_pdfa-1b")[#text("http://www.pdfa.org/doku.php?id=artikel:en:improved_pdfa-1b")]

#text("Since displaying mathematics on the web often involves PDFs (directly or indirectly), wouldn’t it be good to be able to display mathematics using PDF/A-1a?")

#text("Would it be useful to have such standards spill over to the web standards? I’m guessing it would make mathematics both more accessible and searchable. Is that realistic?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e841ba9acf04f70e175b3536d95f6fec1758020e90dcb65aa9b103d729f5d7c7-b0d4f8ffdf841d709a4914db222473d30c6b32769dd9c1381764a487a4b1a9cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pacha Nambi")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-42367")[#strong[#text("Pacha Nambi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2009")])]

#text("I would like to point out chemists and others who also write papers with equations/math symbols in them do not use LaTex. What is needed is a universal language that all scientists who write articles with math equations in them can use – and such a language should be flexible enough to accommodate ever growing need for interconversion between different flavors of these Math languages. It is hard enough time wise to do research what is not needed is Baskin Robbin flavors of mark up languages. Why not math community embrace articles published in PDF format more? I know of some math journals that will not accept papers – with mathematical equations – submitted in PDF format only. Many word processing programs now permit creating documents with math equations and most of them can produce decent PDF files but many math journals will not accept papers submitted in PDF format only. Why?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1d42168f0d29b83519498d6b15cefab628ea4102e81dfab59d17660cf095f12-e51bf28cb5cd6ba395b6e395f3dd9ac80cd20f708c7203de4e889ab0fa7d8a33.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Stacey")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-42372")[#strong[#text("Andrew Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2009")])]

#text("In addition, the PDF produced may not be fully accessible. In particular, the PDF produced by pdftex is not.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-42369")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2009")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("many math journals will not accept papers submitted in PDF format only. Why?")
]

#text("Because the journals are going to replace your style files with their own style file before rerendering the paper. If you send them your own PDF then they’re stuck with using your style, which may not be theirs (including headers, footers, pagination, etc.).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e841ba9acf04f70e175b3536d95f6fec1758020e90dcb65aa9b103d729f5d7c7-b0d4f8ffdf841d709a4914db222473d30c6b32769dd9c1381764a487a4b1a9cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pacha Nambi")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-42371")[#strong[#text("Pacha Nambi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2009")])]

#text("I see your point and appreciate your comments, I checked to see what ACS does with regard to styles. It turns out each journal published by ACS has its own style – especially with respect to literature citations – even though there is some commonality among them. So, it appears we are left with using a number of interconversion tools for format exchange. What a waste of time!.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6fcb8d30c738ff426666c822fa860421cae85519b5e5a7ca833529b178b70f-1baf45cb7c9d247cddb852eb5afc1544fd649a6a89d1f5eaa22aa3084392aa95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques Distler")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-42374")[#strong[#text("Jacques Distler")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2009")])]

#emph[#text("“So, it appears we are left with using a number of interconversion tools for format exchange. What a waste of time!.”")]

#text("You have drawn precisely the ")#emph[#text("wrong")]#text(" conclusion from the available data.")

#text("Because each journal has its own style and citation format, what you want is a submission format which ")#emph[#text("separates")]#text(" style from content. PDF bakes stylistic decisions (right down to the fonts used, and the precise placement of glyphs on the page) into the file, which makes it ")#emph[#text("utterly unsuitable")]#text(" as a submission format.")

#text("A LaTeX source file, with citations in Bibtex format, presents the content, but leaves the stylistic decisions to the Journal’s choice of LaTeX document class and Bibtex style.")

#text("And, indeed, the ACS does have its own LaTeX document class (and Bibtex style) for preparing manuscripts. It’s available from the their website, and is included in most contemporary TeX distributions (e.g. texlive2009).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6fcb8d30c738ff426666c822fa860421cae85519b5e5a7ca833529b178b70f-1baf45cb7c9d247cddb852eb5afc1544fd649a6a89d1f5eaa22aa3084392aa95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques Distler")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-42375")[#strong[#text("Jacques Distler")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2009")])]

#text("Thirty-seve different journals are supported with the same document class:")

#text("\\documentclass[journal=ancham,manuscript=review]{achemso}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1da12961d48b93edbe2e3c50283bb92590bf53c1bd2c464b653f1d4e826ce324-07056772fde2381ee62936741974264236a4beefcfb9b82a1cf14eb935c77a8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Krautzberger")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-42477")[#strong[#text("Peter Krautzberger")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2009")])]

#text("I know it is a bit late in the thread, but does anybody know what ")#link("http://www.mathjax.com/")[#text("http://www.mathjax.com/")]#text(" is about? It sounds very promising, but also like vaporware.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e329c5e1ddf81edef4ae1e5233cb0567c93aa52df7ad4839c2f0f02fbd79c07d-2e10e6fbd5885b4c2b6efc3fa9d8da39bfd9bf7869a2afdfc98cb049d4863eb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Topping")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-42821")[#strong[#text("Paul Topping")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2009")])]

#text("We are gradually getting the MathJax site and s/w up and running. There is now a sample page up. There is a lot of fine-tuning and debugging left to do so try not to be too hard on it yet. We are also putting the final touches on the license, which is a process of trying to please multiple parties. Formal announcements will be out soon.")

#text("Paul Topping")#linebreak()#text(" Design Science, Inc.")#linebreak()#text(" one of the founding MathJax parties")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dcf67163acabbc85ec4bdc69408d6e6da41ba42ef3b9c44b29e1bbf640e6de7a-826164bf683066da1d36ddcb030f1dc9f52b35c5ce2a8880340749958547ef6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ateixeira")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-43115")[#strong[#text("ateixeira")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2010")])]

#link("http://watchmath.com/vlog/?cat=72")[#text("http://watchmath.com/vlog/?cat=72")]#linebreak()#text(" ")#link("http://www.watchmath.blogspot.com/")[#text("http://www.watchmath.blogspot.com/")]

#text("Seems to be a very good tool for right now. It allows a lot more from LateX than wordpress.com and when together with Luca Trevisan’s script (with a few changes so that it can work in blogspot) seems to be a real terrific tool.")

#text("Other than that I reall can’t say much about this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-46535")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2010")])]

#text("Just wanted to point out that the latest build of webkit now incorporates MathML:")

#link("http://webkit.org/blog/1366/announcing%E2%80%A6mathml/")[#text("http://webkit.org/blog/1366/announcing%E2%80%A6mathml/")]

#text("This matters because webkit is behind Safari, Chrome, the Android and Blackberry browsers, and many others. So in the future it looks very likely that those browsers will support MathML.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-46536")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2010")])]

#text("I forgot to mention: Firefox also supports MathML natively, leaving IE as the only major browser which does not.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6fcb8d30c738ff426666c822fa860421cae85519b5e5a7ca833529b178b70f-1baf45cb7c9d247cddb852eb5afc1544fd649a6a89d1f5eaa22aa3084392aa95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques Distler")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-46541")[#strong[#text("Jacques Distler")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2010")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("This matters because webkit is behind Safari, Chrome, the Android and Blackberry browsers, and many others. So in the future it looks very likely that those browsers will support MathML.")
]

#text("This is, indeed, big news.")

#text("Another important one is Firefox’s support for MathML-in-HTML5.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("…leaving IE as the only major browser which does not.")
]

#text("But it does support MathML through a (very nice) plugin.")

#text("And that plugin provides accessibility features to the visually impaired (reading equations aloud, or converting them to Braille).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90be308eed25ee97422b84bb02b87e52566d4e296322a811776b8ebbfeb5cf46-92174fba00f66eede65dbb894aba8b12eabf1776e9882fcc866f44f1799e58b2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathtuition88")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/#comment-236198")[#strong[#text("mathtuition88")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("Reblogged this on ")#link("http://mathtuition88.com/2013/06/26/displaying-maths-online-ii/")[#text("Singapore Maths Tuition")]#text(".")
]
