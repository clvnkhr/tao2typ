// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/
// Converted to Typst by tao2typ: "2026-11-04T14:45:28.426438+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Displaying maths online, II", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Displaying maths online, II")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 November 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/")[#text("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-04 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("As the previous discussion on ")#link("https://terrytao.wordpress.com/2009/10/29/displaying-mathematics-on-the-web/")[#text("displaying mathematics on the web")]#text(" has become quite lengthy, I am opening a fresh post to continue the topic. I’m leaving the previous thread open for those who wish to respond directly to some specific comments in that thread, but otherwise it would be preferable to start afresh on this thread to make it easier to follow the discussion.")

#text("It’s not easy to summarise the discussion so far, but the comments have identified several existing formats for displaying (and marking up) mathematics on the web (")#link("http://en.wikipedia.org/wiki/MathML")[#text("mathML")]#text(", ")#link("http://www.math.union.edu/~dpvc/jsMath/")[#text("jsMath")]#text(", ")#link("http://www.mathjax.com/")[#text("MathJax")]#text(", ")#link("http://en.wikipedia.org/wiki/OpenMath")[#text("OpenMath")]#text("), as well as a surprisingly large number of tools for converting mathematics into web friendly formats (e.g. ")#link("http://www.latex2html.org/")[#text("LaTeX2HTML")]#text(", ")#link("http://math.etsu.edu/LaTeXMathML/")[#text("LaTeXMathML")]#text(", ")#link("http://lucatrevisan.wordpress.com/latex-to-wordpress/")[#text("LaTeX2WP")]#text(", ")#link("http://www.gottabemobile.com/2008/10/29/windows-7-math-input-panel-screenshots")[#text("Windows 7 Math Input")]#text(", ")#link("http://golem.ph.utexas.edu/~distler/blog/itex2MML.html")[#text("itex2MML")]#text(", ")#link("http://ritex.rubyforge.org/")[#text("Ritex")]#text(", ")#link("http://www.albany.edu/~hammond/gellmu/")[#text("Gellmu")]#text(", ")#link("http://www.forkosh.dreamhost.com/source_mathtex.html")[#text("mathTeX")]#text(", ")#link("http://wordpress.org/extend/plugins/wp-latex/")[#text("WP-LaTeX")]#text(", ")#link("http://www.cse.ohio-state.edu/~gurari/TeX4ht/")[#text("TeX4ht")]#text(", ")#link("http://www.blahtex.org/")[#text("blahtex")]#text(", ")#link("http://plastex.sourceforge.net/")[#text("plastex")]#text(", ")#link("http://hutchinson.belmont.ma.us/tth/")[#text("TtH")]#text(", ")#link("http://www.dessci.com/webmath/webeq/")[#text("WebEQ")]#text(", ")#link("http://www.integretechpub.com/techexplorer/")[#text("techexplorer")]#text(", etc.). Some of the formats are not widely supported by current software, and by current browsers in particular, but it seems that the situation will improve with the next generation of these browsers.")

#text("It seems that the tools that already exist are enough to improvise a passable way of displaying mathematics in various formats online, though there are still significant issues with accessibility, browser support, and ease of use. Even if all these issues are resolved, though, I still feel that something is still missing. Currently, if I want to transfer some mathematical content from one location to another (e.g. from a LaTeX file to a blog, or from a wiki to a PDF, or from email to an online document, or whatever), or to input some new piece of mathematics, I have to think about exactly what format I need for the task at hand, and what conversion tool may be needed. In contrast, if one looks at non-mathematical content such as text, links, fonts, non-Latin alphabets, colours, tables, images, or even video, the formats here have been standardised, and one can manipulate this type of content in both online and offline formats more or less seamlessly (in principle, at least – there is still room for improvement), without the need for any particularly advanced technical expertise. It doesn’t look like we’re anywhere near that level currently with regards to mathematical content, though presumably things will improve when a single mathematics presentation standard, such as mathML, becomes universally adopted and supported in browsers, in operating systems, and in other various pieces of auxiliary software.")

#text("Anyway, it has been a very interesting and educational discussion for me, and hopefully for others also; I look forward to any further thoughts that readers have on these topics. (Also, feel free to recapitulate some of the points from the previous thread; the discussion has been far too multifaceted for me to attempt a coherent summary by myself.)")

#heading(level: 1)[#text("Comments (25)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb5cc31dc42d50809703604e3d8b3edd53902324bc5002276e2a102c38e9f123-6220940cf9d40374bf41026115b28876f1824016f9bcb46d35557eebec834de0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ARS")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-42222")[#strong[#text("ARS")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2009")])]

#text("I had not heard about MathJax, a not yet ready successor to the excellent Mathjs.")#linebreak()#text(" On the Mathjax site it is announced that MathScinet will adopt MathJax, which makes it a serious contender. Also linked on tha site was the following article, which is about Math on the web:")#linebreak()#text(" ")#link("http://www.americanscientist.org/issues/pub/2009/3/writing-math-on-the-web/1")[#text("http://www.americanscientist.org/issues/pub/2009/3/writing-math-on-the-web/1")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/195d4171697dc9e94148580f1883c193731040fd4ad965fbb8681da456483978-ff016f013f782e9f53775442369843721590f77f043b792688d5702a55ab39f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-42223")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2009")])]

#text("Much of mathematics is offline. While scans of older papers can be put online, the scans have many of the deficiencies that people have pointed out concerning using images to represent equations.")

#text("For that reason, equation OCR seems to me like it should be part of the puzzle. I recently found a program called ")#link("http://www.inftyproject.org/en/software.html#InftyReader")[#text("INFTYreader")]#text(" which seems to convert scans to LaTeX or MathML. I would be interested to know if there are others.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e90d174cd5092feaa77609322b7e1400fced75c330c37c0fd40958dc58529235-b032e0bc2c98719ec74e6936e90894190de7db045fc896bd809915837f0dc4f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Stacey")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-42227")[#strong[#text("Andrew Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2009")])]

#text("One solution to this issue would be to persuade the reCaptcha people to provide a mathematical variant. For those who don’t know, reCaptcha is one of those ways of testing whether someone filling in a form is a human or robot. It asks the user to type in two words that it displays on the screen. One of these words is already known to the reCaptcha engine and that is used to test the humanity of the user. The other word is unknown and the user’s answer goes towards converting scanned documents.")

#text("At the moment, they’re doing the New York Times. It would be great if we could persuade them to do old mathematical papers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6095264314d85d5eb0d00af80baf05c9187e6391617bfa2de7dc898490bea5a7-86b691fecb66c1ce778fe9473f7eb0514863d7ce74776c619253e546c8a8a8d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Nikolov")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-42242")[#strong[#text("Alex Nikolov")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("this will be more complicated. do u suggest adding additional interface to make the entering math content easier (can’t expect users to latex it in i guess)? then both words would have to be a formula, otherwise ppl might just not bother and put in jibberish for the math content, knowing the ‘real’ captcha is other word")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e90d174cd5092feaa77609322b7e1400fced75c330c37c0fd40958dc58529235-b032e0bc2c98719ec74e6936e90894190de7db045fc896bd809915837f0dc4f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Stacey")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-42249")[#strong[#text("Andrew Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("Even if it just did the words then it would be a step in the right direction. I agree that the mathematics might be a little trickier. Again, a first step would be to simply identify the characters, thus a “mathematical word” would be simply a letter. There are enough characters in use in mathematics that this would still be sufficiently tricky for a computer to do!")

#text("But even if the words are all that’s feasible, once the words are right it wouldn’t be too much work for a graduate student to fill in the rest.")

#text("Ideally, if we could get rid of the pesky copyright issues, when reading an old paper and taking notes on it, one should type bits of it in to some central site. But that’s another idea for another day.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69c936effe32b1c8f4c15a3f2a2c57c6363ddb9a69cfb7465ec67d59d44b9075-aa9f83fb5941ebfa2af356976e7af2279952d390d20bc802c63fbc9d106cab40.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jonathanfine")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-42240")[#strong[#text("jonathanfine")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("One of the problems is that it’s difficult to keep track of what’s going on in mathematical content. To help here, a couple of months ago I started bookmarking URLs related to technical aspects of mathematical content.")

#text("You can see what I’ve got at")#linebreak()#text(" ")#link("http://delicious.com/mathcontent/")[#text("http://delicious.com/mathcontent/")]

#text("And if you go to")#linebreak()#text(" ")#link("http://delicious.com/mathcontent/survey")[#text("http://delicious.com/mathcontent/survey")]#linebreak()#text(" you’ll see the American Scientist article that has been mentioned a couple of times in comments to the previous post. And you’ll also find a blog post by Jon Udell on WordPress and polymath. (This is a teaser to encourage you to visit the URL.)")

#text("I welcome all offers of help to keep the list of bookmarks up-to-date.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e90d174cd5092feaa77609322b7e1400fced75c330c37c0fd40958dc58529235-b032e0bc2c98719ec74e6936e90894190de7db045fc896bd809915837f0dc4f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Stacey")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-42250")[#strong[#text("Andrew Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("I think that Michael’s comments in the other thread are the real “killer app” for MathML. To display mathematics on the web in a way that is accessible for all, means MathML. Anything else is merely a patch while we wait for others to catch up. If all the maths blog converted to MathML then I’d bet that we’d see things move a lot more quickly in the remaining implementation issues.")

#text("Then there’s the issue of generating the MathML, since who wants to type it directly? Here, the more tools the better! After all, it doesn’t matter what the source is, so long as the output is right. So someone who wants to do dynamic content will use something like itex2MML, which is fast but only a subset of LaTeX (well, not quite a subset), whereas someone who is producing mainly static content and who has one eye on the possibility of publishing that content as a book, will use genuine LaTeX as their source and something like TeX4ht as their converter.")

#text("I’m not sure that the non-mathematical picture is as rosy as you paint, but we’re more familiar with it and step around the potholes without noticing that they are there. Plus there are more people in the text, images, video business than in the mathematics business so they have an unfair advantage. But when I think of the hassles I have to go through when someone emails me a word document, or the irritation at having to download yet another codec to play a DVD, or wonder if it’s legal to view images that are GIFs, then I’m not so sure that everything is “sorted out”.")

#text("And I’m not sure that I want it to be. I want to be able to use Emacs for writing all my documents. I want to be able to use LaTeX to do even invitations to birthday parties (thanks to the magic of tikz). I don’t expect everyone to do the same, but so long as the final format is something that I can read, I don’t really care how it was produced. But the important thing is knowing what formats can be widely read.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69c936effe32b1c8f4c15a3f2a2c57c6363ddb9a69cfb7465ec67d59d44b9075-aa9f83fb5941ebfa2af356976e7af2279952d390d20bc802c63fbc9d106cab40.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jonathanfine")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-42257")[#strong[#text("jonathanfine")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("Implicit in latex2wp is a standard for TeX-notation mathematics, and also for the LaTeX markup of the source document.")

#text("A standard for TeX-notation mathematics together with a high-quality translator of standard TeX-notation mathematics to MathML would be a great help. Only by having standards for input can we be sure that we will get decent output from the translator (Garbage In, Garbage Out).")

#text("For me, most or all of the benefits of MathML follow from being a specified language. On the basis of the specification software can be built. Because MathML is specified, MathML to voice software can be developed. The same is not, at present, true of TeX notation mathematics.")

#text("In the long term I’d like to see TeX-notation mathematics and MathML to be something like JSON and XML. Two different ways of representing essentially the same underlying data.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e90d174cd5092feaa77609322b7e1400fced75c330c37c0fd40958dc58529235-b032e0bc2c98719ec74e6936e90894190de7db045fc896bd809915837f0dc4f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Stacey")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-42259")[#strong[#text("Andrew Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("I wouldn’t. I like the flexibility of TeX and I wouldn’t give that up for compatibility with MathML at all. I don’t want to change LaTeX one single bit to get it to work with the web, at least for static stuff. I’m prepared to make sacrifices for dynamic content, but then I want to work with a subset of LaTeX, or as close as possible.")

#text("But LaTeX is a programming language and that’s what makes it bearable. When writing a recent paper, my coauthor and I had absolutely no idea what would make good notation, so we built in a complicated system of macros so that not only could a few commands be changed by a single modification, but that would propagate on down into levels beyond what mere substitution macros can cope with. We basically had Object Oriented LaTeX. At one point, we even had it so that composition and evaluation of functions could be switched from left to right (and everything else would switch as well).")

#text("I think that’s something that hasn’t been remarked on yet. It’s implicit in the dynamic vs static dichotomy. Papers tend to be written over a long scale of time (relatively speaking). Blog posts, even wiki pages, tend to be written over a much shorter scale of time. I put much more time and effort into a paper than into a webpage. I’m not completely sure I could explain why; partly, papers are more “mine” than any webpage (even my own) feel like, papers are, at the end of the day, what will last of my work (even though, I concede, they may be published online and in (X?HT|Math)ML format). So I craft them more carefully, and so what the full power of LaTeX to do so.")

#text("So don’t you dare downgrade LaTeX just to fit in with the rather limited spec of MathML!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69c936effe32b1c8f4c15a3f2a2c57c6363ddb9a69cfb7465ec67d59d44b9075-aa9f83fb5941ebfa2af356976e7af2279952d390d20bc802c63fbc9d106cab40.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jonathanfine")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-42271")[#strong[#text("jonathanfine")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("Andrew: You wrote ”When writing a recent paper, my coauthor and I had absolutely no idea what would make good notation, so we built in a complicated system of macros so that not only could a few commands be changed by a single modification, but that would propagate on down into levels beyond what mere substitution macros can cope with.”")

#text("Would that be your paper “Hunting the Hopf ring” (whose source is available on the arXiv)? If so, I’ll take a look at your macros and text, and will then understand better your point.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e90d174cd5092feaa77609322b7e1400fced75c330c37c0fd40958dc58529235-b032e0bc2c98719ec74e6936e90894190de7db045fc896bd809915837f0dc4f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Stacey")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-42275")[#strong[#text("Andrew Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("It would.")

#text("One aspect of the “Object Oriented” approach that has just occurred to me is that it does make it easier to add low-level semantics to the document. The fact that, in that paper, we write delt for an element of an object of a (concrete!) category D and dmor for a morphism in the category D even though these resolve to the same symbol means that from the source code, it is always clear when d means an element and when d means a morphism.")

#text("I’m partially doing this in the lecture notes for my current course. I find it hard to parse a slide full of stark (raving) mathematics, so I can only imagine how my students find it. So to try to help them make the connections, I’ve been adding colour: vectors are one colour, scalars another, matrices a third, and so forth (I won’t claim that I’ve been consistent: what colour should the entries of a matrix be?). I do this by using the code \\type{vector}{x} and so forth. Then I can modify how all the vectors are displayed in a single command.")

#text("Someone made the point about semantics over in the other thread, and I pooh-poohed it a little. The point is that telling people to add semantics to make other people’s lives easier is never going to work: even if people agree that it’s a good idea, it just takes too much time. However, saying that adding “type” macros to your document makes it easier to write papers, and here’s an easy style file that makes it so very easy to do, oh and incidentally you’ll be helping a lot of other people. Well, then people might start doing it.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7704426465414d8470436259b624bfe3fc19b0107b2f17c6351b5d7fb6103b47-06b2ce421bea448357aecee7a0dcdd470c0b3a5ec347cb80b1420da87f00473e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Krautzberger")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-42272")[#strong[#text("Peter Krautzberger")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("Since it’s not mentioned yet, I wanted to point out the discussion from the first thread regarding PDF/A-1a ")#link("http://www.pdfa.org/doku.php?id=artikel:en:improved_pdfa-1b")[#text("http://www.pdfa.org/doku.php?id=artikel:en:improved_pdfa-1b")]

#text("Since displaying mathematics on the web often involves PDFs (directly or indirectly), wouldn’t it be good to be able to display mathematics using PDF/A-1a?")

#text("Would it be useful to have such standards spill over to the web standards? I’m guessing it would make mathematics both more accessible and searchable. Is that realistic?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dccd4b2eda5f2d38747ed817c4d82c39b6ff7765f4872fb3460df7ee96fff210-441e5996641cc2195b221999bce2ee88bc42ab304d02870688bac4030fcc9638.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pacha Nambi")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-42367")[#strong[#text("Pacha Nambi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2009")])]

#text("I would like to point out chemists and others who also write papers with equations/math symbols in them do not use LaTex. What is needed is a universal language that all scientists who write articles with math equations in them can use – and such a language should be flexible enough to accommodate ever growing need for interconversion between different flavors of these Math languages. It is hard enough time wise to do research what is not needed is Baskin Robbin flavors of mark up languages. Why not math community embrace articles published in PDF format more? I know of some math journals that will not accept papers – with mathematical equations – submitted in PDF format only. Many word processing programs now permit creating documents with math equations and most of them can produce decent PDF files but many math journals will not accept papers submitted in PDF format only. Why?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e90d174cd5092feaa77609322b7e1400fced75c330c37c0fd40958dc58529235-b032e0bc2c98719ec74e6936e90894190de7db045fc896bd809915837f0dc4f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Stacey")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-42372")[#strong[#text("Andrew Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2009")])]

#text("In addition, the PDF produced may not be fully accessible. In particular, the PDF produced by pdftex is not.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/05307d96b27beeb0f822ca53a149d53522d1cc46f53bada0d2bf178d6e528c16-4e4a71d9f5170bbb87027e1abeb70861782075ed3820f7187173e374f7b2b379.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-42369")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2009")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("many math journals will not accept papers submitted in PDF format only. Why?")
]

#text("Because the journals are going to replace your style files with their own style file before rerendering the paper. If you send them your own PDF then they’re stuck with using your style, which may not be theirs (including headers, footers, pagination, etc.).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dccd4b2eda5f2d38747ed817c4d82c39b6ff7765f4872fb3460df7ee96fff210-441e5996641cc2195b221999bce2ee88bc42ab304d02870688bac4030fcc9638.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pacha Nambi")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-42371")[#strong[#text("Pacha Nambi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2009")])]

#text("I see your point and appreciate your comments, I checked to see what ACS does with regard to styles. It turns out each journal published by ACS has its own style – especially with respect to literature citations – even though there is some commonality among them. So, it appears we are left with using a number of interconversion tools for format exchange. What a waste of time!.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d1ccd73041eada1993912ef5c885ac4c1f4929ff67c35f1c0836c1b599c8d9c-47c59e9ec953072b4beeba263de9e4c17771dbfe7a330639728fdb509befc224.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques Distler")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-42374")[#strong[#text("Jacques Distler")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2009")])]

#emph[#text("“So, it appears we are left with using a number of interconversion tools for format exchange. What a waste of time!.”")]

#text("You have drawn precisely the ")#emph[#text("wrong")]#text(" conclusion from the available data.")

#text("Because each journal has its own style and citation format, what you want is a submission format which ")#emph[#text("separates")]#text(" style from content. PDF bakes stylistic decisions (right down to the fonts used, and the precise placement of glyphs on the page) into the file, which makes it ")#emph[#text("utterly unsuitable")]#text(" as a submission format.")

#text("A LaTeX source file, with citations in Bibtex format, presents the content, but leaves the stylistic decisions to the Journal’s choice of LaTeX document class and Bibtex style.")

#text("And, indeed, the ACS does have its own LaTeX document class (and Bibtex style) for preparing manuscripts. It’s available from the their website, and is included in most contemporary TeX distributions (e.g. texlive2009).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d1ccd73041eada1993912ef5c885ac4c1f4929ff67c35f1c0836c1b599c8d9c-47c59e9ec953072b4beeba263de9e4c17771dbfe7a330639728fdb509befc224.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques Distler")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-42375")[#strong[#text("Jacques Distler")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2009")])]

#text("Thirty-seve different journals are supported with the same document class:")

#text("\\documentclass[journal=ancham,manuscript=review]{achemso}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7704426465414d8470436259b624bfe3fc19b0107b2f17c6351b5d7fb6103b47-06b2ce421bea448357aecee7a0dcdd470c0b3a5ec347cb80b1420da87f00473e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Krautzberger")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-42477")[#strong[#text("Peter Krautzberger")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2009")])]

#text("I know it is a bit late in the thread, but does anybody know what ")#link("http://www.mathjax.com/")[#text("http://www.mathjax.com/")]#text(" is about? It sounds very promising, but also like vaporware.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cbf7167d88ad0fa3b7a3ee829b8896f79d9722c5a0f78b9e250d0b57f578cd7a-451ad50f1e5d0d2eacf83b894e1833f684418fa98d544bcc0529afc9065b54c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Topping")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-42821")[#strong[#text("Paul Topping")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2009")])]

#text("We are gradually getting the MathJax site and s/w up and running. There is now a sample page up. There is a lot of fine-tuning and debugging left to do so try not to be too hard on it yet. We are also putting the final touches on the license, which is a process of trying to please multiple parties. Formal announcements will be out soon.")

#text("Paul Topping")#linebreak()#text(" Design Science, Inc.")#linebreak()#text(" one of the founding MathJax parties")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/454f5c31bfcc6a672d601aee7912313dfe773a3b402494304d1981d644b19fcd-076027e86ddd19afbbbbb2bb0c554f1f40ae26d042d44b44bac3c6b6dc332751.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ateixeira")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-43115")[#strong[#text("ateixeira")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2010")])]

#link("http://watchmath.com/vlog/?cat=72")[#text("http://watchmath.com/vlog/?cat=72")]#linebreak()#text(" ")#link("http://www.watchmath.blogspot.com/")[#text("http://www.watchmath.blogspot.com/")]

#text("Seems to be a very good tool for right now. It allows a lot more from LateX than wordpress.com and when together with Luca Trevisan’s script (with a few changes so that it can work in blogspot) seems to be a real terrific tool.")

#text("Other than that I reall can’t say much about this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c31e5139f40068481cc1a49fdbd92c331e378814646ce254d4cc065c9364ae8d-7ed01f86b57c1a3bc2e74c6689a160d8c501534189da174b76931c33069a3b79.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-46535")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2010")])]

#text("Just wanted to point out that the latest build of webkit now incorporates MathML:")

#link("http://webkit.org/blog/1366/announcing%E2%80%A6mathml/")[#text("http://webkit.org/blog/1366/announcing%E2%80%A6mathml/")]

#text("This matters because webkit is behind Safari, Chrome, the Android and Blackberry browsers, and many others. So in the future it looks very likely that those browsers will support MathML.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c31e5139f40068481cc1a49fdbd92c331e378814646ce254d4cc065c9364ae8d-7ed01f86b57c1a3bc2e74c6689a160d8c501534189da174b76931c33069a3b79.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-46536")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2010")])]

#text("I forgot to mention: Firefox also supports MathML natively, leaving IE as the only major browser which does not.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d1ccd73041eada1993912ef5c885ac4c1f4929ff67c35f1c0836c1b599c8d9c-47c59e9ec953072b4beeba263de9e4c17771dbfe7a330639728fdb509befc224.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques Distler")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-46541")[#strong[#text("Jacques Distler")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2010")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("This matters because webkit is behind Safari, Chrome, the Android and Blackberry browsers, and many others. So in the future it looks very likely that those browsers will support MathML.")
]

#text("This is, indeed, big news.")

#text("Another important one is Firefox’s support for MathML-in-HTML5.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("…leaving IE as the only major browser which does not.")
]

#text("But it does support MathML through a (very nice) plugin.")

#text("And that plugin provides accessibility features to the visually impaired (reading equations aloud, or converting them to Braille).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/30555a917e46756b70aede82747112046d59740c557e4297439d3418862738f2-9ad656437e342116680e2ca67bad889fc9ab5d2d7e8fcb138326d9bcc9ad6677.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathtuition88")]], [#link("https://terrytao.wordpress.com/2009/11/04/displaying-maths-online-ii/comment-page-1/#comment-236198")[#strong[#text("mathtuition88")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("Reblogged this on ")#link("http://mathtuition88.com/2013/06/26/displaying-maths-online-ii/")[#text("Singapore Maths Tuition")]#text(".")
]
