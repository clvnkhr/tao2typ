// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/
// Converted to Typst by tao2typ: "2026-10-14T16:35:50.373612+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Moser’s entropy compression argument", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Moser’s entropy compression argument")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 August 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/")[#text("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("There are many situations in combinatorics in which one is running some sort of iteration algorithm to continually “improve” some object ")#mi("{A}")#text("; each loop of the algorithm replaces ")#mi("{A}")#text(" with some better version ")#mi("{A^{\\prime}}")#text(" of itself, until some desired property of ")#mi("{A}")#text(" is attained and the algorithm halts. In order for such arguments to yield a useful conclusion, it is often necessary that the algorithm halts in a finite amount of time, or (even better), in a bounded amount of time. (In general, one cannot use infinitary iteration tools, such as ")#link("http://en.wikipedia.org/wiki/Transfinite_induction")[#text("transfinite induction")]#text(" or ")#link("http://en.wikipedia.org/wiki/Zorn%27s_lemma")[#text("Zorn’s lemma")]#text(", in combinatorial settings, because the iteration processes used to improve some target object ")#mi("{A}")#text(" often degrade some other finitary quantity ")#mi("{B}")#text(" in the process, and an infinite iteration would then have the undesirable effect of making ")#mi("{B}")#text(" infinite.)")

#text("A basic strategy to ensure termination of an algorithm is to exploit a ")#emph[#text("monotonicity property")]#text(", or more precisely to show that some key quantity keeps increasing (or keeps decreasing) with each loop of the algorithm, while simultaneously staying bounded. (Or, as the economist ")#link("http://en.wikipedia.org/wiki/Herbert_Stein")[#text("Herbert Stein")]#text(" was fond of saying, “If something cannot go on forever, it must stop.”)")

#text("Here are four common flavours of this monotonicity strategy:")

#list(
[#text("The ")#emph[#text("mass increment argument")]#text(". This is perhaps the most familiar way to ensure termination: make each improved object ")#mi("{A^{\\prime}}")#text(" “heavier” than the previous one ")#mi("{A}")#text(" by some non-trivial amount (e.g. by ensuring that the cardinality of ")#mi("{A^{\\prime}}")#text(" is strictly greater than that of ")#mi("{A}")#text(", thus ")#tao-math("{\\left|A^{\\prime}\\right| \\geq \\left|A\\right|+1}", block: false)#text("). Dually, one can try to force the amount of “mass” remaining “outside” of ")#mi("{A}")#text(" in some sense to decrease at every stage of the iteration. If there is a good upper bound on the “mass” of ")#mi("{A}")#text(" that stays essentially fixed throughout the iteration process, and a lower bound on the mass increment at each stage, then the argument terminates. Many “greedy algorithm” arguments are of this type. The proof of the ")#link("http://en.wikipedia.org/wiki/Hahn_decomposition_theorem")[#text("Hahn decomposition theorem")]#text(" in measure theory also falls into this category. The general strategy here is to keep looking for useful pieces of mass outside of ")#mi("{A}")#text(", and add them to ")#mi("{A}")#text(" to form ")#mi("{A^{\\prime}}")#text(", thus exploiting the additivity properties of mass. Eventually no further usable mass remains to be added (i.e. ")#mi("{A}")#text(" is ")#emph[#text("maximal")]#text(" in some ")#mi("{L^1}")#text(" sense), and this should force some desirable property on ")#mi("{A}")#text(".")],
[#text("The ")#emph[#text("density increment argument")]#text(". This is a variant of the mass increment argument, in which one increments the “density” of ")#mi("{A}")#text(" rather than the “mass”. For instance, ")#mi("{A}")#text(" might be contained in some ambient space ")#mi("{P}")#text(", and one seeks to improve ")#mi("{A}")#text(" to ")#mi("{A^{\\prime}}")#text(" (and ")#mi("{P}")#text(" to ")#mi("{P^{\\prime}}")#text(") in such a way that the density of the new object in the new ambient space is better than that of the previous object (e.g. ")#tao-math("{\\left|A^{\\prime}\\right|/\\left|P^{\\prime}\\right| \\geq \\left|A\\right|/\\left|P\\right| + c}", block: false)#text(" for some ")#mi("{c>0}")#text("). On the other hand, the density of ")#mi("{A}")#text(" is clearly bounded above by ")#mi("{1}")#text(". As long as one has a sufficiently good lower bound on the density increment at each stage, one can conclude an upper bound on the number of iterations in the algorithm. The prototypical example of this is Roth’s proof of his theorem that every set of integers of positive upper density contains an arithmetic progression of length three. The general strategy here is to keep looking for useful density fluctuations inside ")#mi("{A}")#text(", and then “zoom in” to a region of increased density by reducing ")#mi("{A}")#text(" and ")#mi("{P}")#text(" appropriately. Eventually no further usable density fluctuation remains (i.e. ")#mi("{A}")#text(" is ")#emph[#text("uniformly distributed")]#text("), and this should force some desirable property on ")#mi("{A}")#text(".")],
[#text("The ")#emph[#text("energy increment argument")]#text(". This is an “")#mi("{L^2}")#text("” analogue of the “")#mi("{L^1}")#text("“-based mass increment argument (or the “")#mi("{L^\\infty}")#text("“-based density increment argument), in which one seeks to increments the amount of “energy” that ")#mi("{A}")#text(" captures from some reference object ")#mi("{X}")#text(", or (equivalently) to decrement the amount of energy of ")#mi("{X}")#text(" which is still “orthogonal” to ")#mi("{A}")#text(". Here ")#mi("{A}")#text(" and ")#mi("{X}")#text(" are related somehow to a Hilbert space, and the energy involves the norm on that space. A classic example of this type of argument is the existence of orthogonal projections onto closed subspaces of a Hilbert space; this leads among other things to the construction of ")#link("http://en.wikipedia.org/wiki/Conditional_expectation")[#text("conditional expectation")]#text(" in measure theory, which then underlies a number of arguments in ergodic theory, as discussed for instance in ")#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("this earlier blog post")]#text(". Another basic example is the standard proof of the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(" (where the “energy” is often referred to as the “index”). These examples are related; see ")#link("https://terrytao.wordpress.com/2009/04/26/szemeredis-regularity-lemma-via-random-partitions/")[#text("this blog post")]#text(" for further discussion. The general strategy here is to keep looking for useful pieces of energy orthogonal to ")#mi("{A}")#text(", and add them to ")#mi("{A}")#text(" to form ")#mi("{A^{\\prime}}")#text(", thus exploiting square-additivity properties of energy, such as Pythagoras’ theorem. Eventually, no further usable energy outside of ")#mi("{A}")#text(" remains to be added (i.e. ")#mi("{A}")#text(" is ")#emph[#text("maximal")]#text(" in some ")#mi("{L^2}")#text(" sense), and this should force some desirable property on ")#mi("{A}")#text(".")],
[#text("The ")#emph[#text("rank reduction argument")]#text(". Here, one seeks to make each new object ")#mi("{A^{\\prime}}")#text(" to have a lower “rank”, “dimension”, or “order” than the previous one. A classic example here is the proof of the linear algebra fact that given any finite set of vectors, there exists a linearly independent subset which spans the same subspace; the proof of the more general ")#link("http://en.wikipedia.org/wiki/Exchange_lemma")[#text("Steinitz exchange lemma")]#text(" is in the same spirit. The general strategy here is to keep looking for “collisions” or “dependencies” within ")#mi("{A}")#text(", and use them to collapse ")#mi("{A}")#text(" to an object ")#mi("{A^{\\prime}}")#text(" of lower rank. Eventually, no further usable collisions within ")#mi("{A}")#text(" remain, and this should force some desirable property on ")#mi("{A}")#text(".")]
)

#text("Much of my own work in additive combinatorics relies heavily on at least one of these types of arguments (and, in some cases, on a nested combination of two or more of them). Many arguments in nonlinear partial differential equations also have a similar flavour, relying on various ")#emph[#text("monotonicity formulae")]#text(" for solutions to such equations, though the objective in PDE is usually slightly different, in that one wants to keep control of a solution as one approaches a singularity (or as some time or space coordinate goes off to infinity), rather than to ensure termination of an algorithm. (On the other hand, many arguments in the theory of ")#emph[#text("concentration compactness")]#text(", which is used heavily in PDE, does have the same algorithm-terminating flavour as the combinatorial arguments; see ")#link("https://terrytao.wordpress.com/2007/04/08/simons-lecture-iii-structure-and-randomness-in-pde/")[#text("this earlier blog post")]#text(" for more discussion.)")

#text("Recently, a new species of monotonicity argument was introduced ")#link("http://doi.acm.org/10.1145/1536414.1536462")[#text("by Moser")]#text(", as the primary tool in his elegant new proof of the ")#link("http://en.wikipedia.org/wiki/Lov%C3%A1sz_local_lemma")[#text("Lovász local lemma")]#text(". This argument could be dubbed an ")#emph[#text("entropy compression argument")]#text(", and only applies to ")#link("http://en.wikipedia.org/wiki/Probabilistic_algorithm")[#text("probabilistic algorithms")]#text(" which require a certain collection ")#mi("{R}")#text(" of random “bits” or other random choices as part of the input, thus each loop of the algorithm takes an object ")#mi("{A}")#text(" (which may also have been generated randomly) and some portion of the random string ")#mi("{R}")#text(" to (deterministically) create a better object ")#mi("{A^{\\prime}}")#text(" (and a shorter random string ")#mi("{R^{\\prime}}")#text(", formed by throwing away those bits of ")#mi("{R}")#text(" that were used in the loop). The key point is to design the algorithm to be partially ")#emph[#text("reversible")]#text(", in the sense that given ")#mi("{A^{\\prime}}")#text(" and ")#mi("{R^{\\prime}}")#text(" and some additional data ")#mi("{H^{\\prime}}")#text(" that logs the cumulative ")#emph[#text("history")]#text(" of the algorithm up to this point, one can reconstruct ")#mi("{A}")#text(" together with the remaining portion ")#mi("{R}")#text(" not already contained in ")#mi("{R^{\\prime}}")#text(". Thus, each stage of the argument ")#emph[#text("compresses")]#text(" the information-theoretic content of the string ")#mi("{A+R}")#text(" into the string ")#mi("{A^{\\prime}+R^{\\prime}+H^{\\prime}}")#text(" in a lossless fashion. However, a random variable such as ")#mi("{A+R}")#text(" cannot be compressed losslessly into a string of expected size smaller than the ")#link("http://en.wikipedia.org/wiki/Entropy_(information_theory)")[#text("Shannon entropy")]#text(" of that variable. Thus, if one has a good lower bound on the entropy of ")#mi("{A+R}")#text(", and if the length of ")#mi("{A^{\\prime}+R^{\\prime}+H^{\\prime}}")#text(" is significantly less than that of ")#mi("{A+R}")#text(" (i.e. we need the marginal growth in the length of the history file ")#mi("{H^{\\prime}}")#text(" per iteration to be less than the marginal amount of randomness used per iteration), then there is a limit as to how many times the algorithm can be run, much as there is a limit as to how many times a random data file can be compressed before no further length reduction occurs.")

#text("It is interesting to compare this method with the ones discussed earlier. In the previous methods, the failure of the algorithm to halt led to a new iteration of the object ")#mi("{A}")#text(" which was “heavier”, “denser”, captured more “energy”, or “lower rank” than the previous instance of ")#mi("{A}")#text(". Here, the failure of the algorithm to halt leads to new information that can be used to “compress” ")#mi("{A}")#text(" (or more precisely, the full state ")#mi("{A+R}")#text(") into a smaller amount of space. I don’t know yet of any application of this new type of termination strategy to the fields I work in, but one could imagine that it could eventually be of use (perhaps to show that solutions to PDE with sufficiently “random” initial data can avoid singularity formation?), so I thought I would discuss it here.")

#text("Below the fold I give a special case of Moser’s argument, based on a ")#link("http://blog.computationalcomplexity.org/2009/06/kolmogorov-complexity-proof-of-lov.html")[#text("blog post of Lance Fortnow")]#text(" on this topic.")

#metadata(none) <tao-dfb05ede3481cc32c637>

#text("Rather than deal with the Lovász local lemma in full generality, I will follow Fortnow and work with a special case of this lemma involving the ")#link("http://en.wikipedia.org/wiki/Boolean_satisfiability_problem")[#mi("{k}")#text("-satisfiability problem")]#text(" (in ")#link("http://en.wikipedia.org/wiki/Conjunctive_normal_form")[#text("conjunctive normal form")]#text("). Here, one is given a set of ")#emph[#text("boolean variables")]#text(" ")#mi("{x_1,\\ldots,x_n}")#text(" together with their negations ")#mi("{\\neg x_1, \\ldots, \\neg x_n}")#text("; we refer to the ")#mi("{2n}")#text(" variables and their negations collectively as ")#emph[#text("literals")]#text(". We fix an integer ")#mi("{k \\geq 2}")#text(", and define a (length ")#mi("{k}")#text(") ")#emph[#text("clause")]#text(" to be a ")#link("http://en.wikipedia.org/wiki/Disjunction")[#text("disjunction")]#text(" of ")#mi("{k}")#text(" literals, for instance")

#align(center)[#tao-fit-display[#mitex("x_3 \\vee \\neg x_5 \\vee x_9")]]

#text("is a clause of length three, which is true unless ")#mi("{x_3}")#text(" is false, ")#mi("{x_5}")#text(" is true, and ")#mi("{x_9}")#text(" is false. We define the ")#emph[#text("support")]#text(" of a clause to be the set of variables that are involved in the clause, thus for instance ")#mi("{x_3 \\vee \\neg x_5 \\vee x_9}")#text(" has support ")#mi("{\\{x_3,x_5,x_9\\}}")#text(". To avoid degeneracy we assume that no clause uses a variable more than once (or equivalently, all supports have cardinality exactly ")#mi("{k}")#text("), thus for instance we do not consider ")#mi("{x_3 \\vee x_3 \\vee x_9}")#text(" or ")#mi("{x_3 \\vee \\neg x_3 \\vee x_9}")#text(" to be clauses.")

#text("Note that the failure of a clause reveals complete information about all ")#mi("{k}")#text(" of the boolean variables in the support; this will be an important fact later on.")

#text("The ")#emph[#mi("{k}")#text("-satisfiability problem")]#text(" is the following: given a set ")#mi("{S}")#text(" of clauses of length ")#mi("{k}")#text(" involving ")#mi("{n}")#text(" boolean variables ")#mi("{x_1,\\ldots,x_n}")#text(", is there a way to assign truth values to each of the ")#mi("{x_1,\\ldots,x_n}")#text(", so that all of the clauses are simultaneously satisfied?")

#text("For general ")#mi("{S}")#text(", this problem is easy for ")#mi("{k=2}")#text(" (essentially equivalent to the problem of ")#mi("{2}")#text("-colouring a graph), but NP-complete for ")#mi("{k \\geq 3}")#text(" (this is the famous ")#link("http://en.wikipedia.org/wiki/Cook%E2%80%93Levin_theorem")[#text("Cook-Levin theorem")]#text("). But the problem becomes simpler if one makes some more assumptions on the set ")#mi("{S}")#text(" of clauses. For instance, if the clauses in ")#mi("{S}")#text(" have disjoint supports, then they can be satisfied independently of each other, and so one easily has a positive answer to the satisfiability problem in this case. (Indeed, one only needs each clause in ")#mi("{S}")#text(" to have ")#emph[#text("one")]#text(" variable in its support that is disjoint from all the other supports in order to make this argument work.)")

#text("Now suppose that the clauses ")#mi("{S}")#text(" are not completely disjoint, but have a limited amount of overlap; thus ")#emph[#text("most")]#text(" clauses in ")#mi("{S}")#text(" have disjoint supports, but not all. With too much overlap, of course, one expects satisfability to fail (e.g. if ")#mi("{S}")#text(" is the set of ")#emph[#text("all")]#text(" length ")#mi("{k}")#text(" clauses). But with a sufficiently small amount of overlap, one still has satisfiability:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Lovász local lemma, special case)")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" Suppose that ")#mi("{S}")#text(" is a set of length ")#mi("{k}")#text(" clauses, such that the support of each clause ")#mi("{s}")#text(" in ")#mi("{S}")#text(" intersects at most ")#mi("{2^{k-C}}")#text(" supports of clauses in ")#mi("{S}")#text(" (including ")#mi("{s}")#text(" itself), where ")#mi("{C}")#text(" is a sufficiently large absolute constant. Then the clauses in ")#mi("{S}")#text(" are simultaneously satisfiable.")
]

#text("One of the reasons that this result is powerful is that the bounds here are uniform in the number ")#mi("{n}")#text(" of variables. Apart from the loss of ")#mi("{C}")#text(", this result is sharp; consider for instance the set ")#mi("{S}")#text(" of all ")#mi("{2^k}")#text(" clauses with support ")#mi("{\\{x_1,\\ldots,x_k\\}}")#text(", which is clearly unsatisfiable.")

#text("The standard proof of this theorem proceeds by assigning each of the ")#mi("{n}")#text(" boolean variables ")#mi("{x_1,\\ldots,x_n}")#text(" a truth value ")#mi("{a_1,\\ldots,a_n \\in \\{ \\text{true}, \\text{false} \\}}")#text(" independently at random (with each truth value occurring with an equal probability of ")#mi("{1/2}")#text("); then each of the clauses in ")#mi("{S}")#text(" has a positive zero probability of holding (in fact, the probability is ")#mi("{1-2^{-k}}")#text("). Furthermore, if ")#mi("{E_s}")#text(" denotes the event that a clause ")#mi("{s \\in S}")#text(" is satisfied, then the ")#mi("{E_s}")#text(" are mostly independent of each other; indeed, each event ")#mi("{E_s}")#text(" is independent of all but most ")#mi("{2^{k-C}}")#text(" other events ")#mi("{E_{s^{\\prime}}}")#text(". Applying the ")#link("http://en.wikipedia.org/wiki/Lov%C3%A1sz_local_lemma")[#text("Lovász local lemma")]#text(", one concludes that the ")#mi("{E_s}")#text(" simultaneously hold with positive probability (if ")#mi("{C}")#text(" is a little bit larger than ")#mi("{\\log_2 e}")#text("), and the claim follows.")

#text("The textbook proof of the Lovász local lemma is short but nonconstructive; in particular, it does not easily offer any quick way to compute an actual satisfying assignment for ")#mi("{x_1,\\ldots,x_n}")#text(", only saying that such an assignment exists. Moser’s argument, by contrast, gives a simple and natural algorithm to locate such an assignment (and thus prove Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text("). (The constant ")#mi("{C}")#text(" becomes ")#mi("{3}")#text(" rather than ")#mi("{\\log_2 e}")#text(", although the ")#mi("{\\log_2 e}")#text(" bound has since been recovered in a paper of Moser and Tardos.)")

#text("As with the usual proof, one begins by randomly assigning truth values ")#mi("{a_1,\\ldots,a_n \\in \\{ \\text{true}, \\text{false} \\}}")#text(" to ")#mi("{x_1,\\ldots,x_n}")#text("; call this random assignment ")#mi("{A = (a_1,\\ldots,a_n)}")#text(". If ")#mi("{A}")#text(" satisfied all the clauses in ")#mi("{S}")#text(", we would be done. However, it is likely that there will be some non-empty subset ")#mi("{T}")#text(" of clauses in ")#mi("{S}")#text(" which are not satisfied by ")#mi("{A}")#text(".")

#text("We would now like to modify ")#mi("{A}")#text(" in such a manner to reduce the number ")#tao-math("{\\left|T\\right|}", block: false)#text(" of violated clauses. If, for instance, we could always find a modification ")#mi("{A^{\\prime}}")#text(" of ")#mi("{A}")#text(" whose set ")#mi("{T^{\\prime}}")#text(" of violated clauses was strictly smaller than ")#mi("{T}")#text(" (assuming of course that ")#mi("{T}")#text(" is non-empty), then we could iterate and be done (this is basically a mass decrement argument). One obvious way to try to achieve this is to pick a clause ")#mi("{s}")#text(" in ")#mi("{T}")#text(" that is violated by ")#mi("{A}")#text(", and modify the values of ")#mi("{A}")#text(" on the support of ")#mi("{s}")#text(" to create a modified set ")#mi("{A^{\\prime}}")#text(" that satisfies ")#mi("{s}")#text(", which is easily accomplished; in fact, any non-trivial modification of ")#mi("{A}")#text(" on the support will work here. In order to maximize the amount of entropy in the system (which is what one wants to do for an entropy compression argument), we will choose this modification of ")#mi("{A^{\\prime}}")#text(" ")#emph[#text("randomly")]#text("; in particular, we will use ")#mi("{k}")#text(" fresh random bits to replace the ")#mi("{k}")#text(" bits of ")#mi("{A}")#text(" in the support of ")#mi("{s}")#text(". (By doing so, there is a small probability (")#mi("{2^{-k}}")#text(") that we in fact do not change ")#mi("{A}")#text(" at all, but the argument is (very) slightly simpler if we do not bother to try to eliminate this case.)")

#text("If all the clauses had disjoint supports, then this strategy would work without difficulty. But when the supports are not disjoint, one has a problem: every time one modifies ")#mi("{A}")#text(" to “fix” a clause ")#mi("{s}")#text(" by modifying the variables on the support of ")#mi("{s}")#text(", one may cause other clauses ")#mi("{s^{\\prime}}")#text(" whose supports overlap those of ")#mi("{s}")#text(" to fail, thus potentially increasing the size of ")#mi("{T}")#text(" by as much as ")#mi("{2^{k-C}-1}")#text(". One could then try fixing all the clauses which were broken by the first fix, but it appears that the number of clauses needed to repair could grow indefinitely with this procedure, and one might never terminate in a state in which all clauses are simultaneously satisfied.")

#text("The key observation of Moser, as alluded earlier, is that each failure of a clause ")#mi("{s}")#text(" for an assignment ")#mi("{A}")#text(" reveals ")#mi("{k}")#text(" bits of information about ")#mi("{A}")#text(", namely that the exact values that ")#mi("{A}")#text(" assigns to the support of ")#mi("{s}")#text(". The plan is then to use each failure of a clause as a part of a ")#emph[#text("compression protocol")]#text(" that compresses ")#mi("{A}")#text(" (plus some other data) losslessly into a smaller amount of space. A crucial point is that at each stage of the process, the clause one is trying to fix is almost always going to be one that overlapped the clause that one had just previously fixed. Thus the total number of possibilities for each clause, given the previous clauses, is basically ")#mi("{2^{k-C}}")#text(", which requires only ")#mi("{k-C}")#text(" bits of storage, compared with the ")#mi("{k}")#text(" bits of entropy that have been eliminated. This is what is going to force the algorithm to terminate in finite time (with positive probability).")

#text("Let’s make the details more precise. We will need the following objects:")

#list(
[#text("A truth assignment ")#mi("{A}")#text(" of ")#mi("{n}")#text(" truth values ")#mi("{a_1,\\ldots,a_n}")#text(", which is initially assigned randomly, but which will be modified as the algorithm progresses;")],
[#text("A long random string ")#mi("{R}")#text(" of bits, from which we will make future random choices, with each random bit being removed from ")#mi("{R}")#text(" as it is read.")]
)

#text("We also need a recursive algorithm ")#mi("{Fix(s)}")#text(", which modifies the string ")#mi("{A}")#text(" to satisfy a clause ")#mi("{s}")#text(" in ")#mi("{S}")#text(" (and, as a bonus, may also make ")#mi("{A}")#text(" obey some other clauses in ")#mi("{S}")#text(" that it did not previously satisfy). It is defined recursively:")

#list(
[#text("Step 1. If ")#mi("{A}")#text(" already satisfies ")#mi("{s}")#text(", do nothing (i.e. leave ")#mi("{A}")#text(" unchanged).")],
[#text("Step 2. Otherwise, read off ")#mi("{k}")#text(" random bits from ")#mi("{R}")#text(" (thus shortening ")#mi("{R}")#text(" by ")#mi("{k}")#text(" bits), and use these to replace the ")#mi("{k}")#text(" bits of ")#mi("{A}")#text(" on the support of ")#mi("{s}")#text(" in the obvious manner (ordering the support of ")#mi("{s}")#text(" by some fixed ordering, and assigning the ")#mi("{j^{th}}")#text(" bit from ")#mi("{R}")#text(" to the ")#mi("{j^{th}}")#text(" variable in the support for ")#mi("{1 \\leq j \\leq k}")#text(").")],
[#text("Step 3. Next, find all the clauses ")#mi("{s^{\\prime}}")#text(" in ")#mi("{S}")#text(" whose supports intersect ")#mi("{s}")#text(", and which ")#mi("{A}")#text(" now violates; this is a collection of at most ")#mi("{2^{k-C}}")#text(" clauses, possibly including ")#mi("{s}")#text(" itself. Order these clauses ")#mi("{s^{\\prime}}")#text(" in some arbitrary fashion, and then apply ")#mi("{Fix(s^{\\prime})}")#text(" to each such clause in turn. (Thus the original algorithm ")#mi("{Fix(s)}")#text(" is put “on hold” on some CPU stack while all the child processes ")#mi("{Fix(s^{\\prime})}")#text(" are executed; once all of the child processes are complete, ")#mi("{Fix(s)}")#text(" then terminates also.)")]
)

#text("An easy induction shows that if ")#mi("{Fix(s)}")#text(" terminates, then the resulting modification of ")#mi("{A}")#text(" will satisfy ")#mi("{s}")#text("; and furthermore, any other clause ")#mi("{s^{\\prime}}")#text(" in ")#mi("{S}")#text(" which was already satisfied by ")#mi("{A}")#text(" before ")#mi("{Fix(s)}")#text(" was called, will continue to be satisfied by ")#mi("{A}")#text(" after ")#mi("{Fix(s)}")#text(" is called. Thus, ")#mi("{Fix(s)}")#text(" can only serve to decrease the number of unsatisfied clauses ")#mi("{T}")#text(" in ")#mi("{S}")#text(", and so one can fix all the clauses by calling ")#mi("{Fix(s)}")#text(" once for each clause in ")#mi("{T}")#text(" – provided that these algorithms all terminate.")

#text("Each time Step 2 of the Fix algorithm is called, the assignment ")#mi("{A}")#text(" changes to a new assignment ")#mi("{A^{\\prime}}")#text(", and the random string ")#mi("{R}")#text(" changes to a shorter string ")#mi("{R^{\\prime}}")#text(". Is this process reversible? Yes – provided that one knows what clause ")#mi("{s}")#text(" was being fixed by this instance of the algorithm. Indeed, if ")#mi("{s, A^{\\prime}, R^{\\prime}}")#text(" are known, then ")#mi("{A}")#text(" can be recovered by changing the assignment of ")#mi("{A^{\\prime}}")#text(" on the support of ")#mi("{s}")#text(" to the only set of choices that violates ")#mi("{s}")#text(", while ")#mi("{R}")#text(" can be recovered from ")#mi("{R^{\\prime}}")#text(" by appending to ")#mi("{R^{\\prime}}")#text(" the bits of ")#mi("{A^{\\prime}}")#text(" on the support of ")#mi("{s}")#text(".")

#text("This type of reversibility does not seem very useful for an entropy compression argument, because while ")#mi("{R^{\\prime}}")#text(" is shorter than ")#mi("{R}")#text(" by ")#mi("{k}")#text(" bits, it requires about ")#tao-math("{\\log \\left|S\\right|}", block: false)#text(" bits to store the clause ")#mi("{s}")#text(". So the map ")#mi("{A+R \\mapsto A^{\\prime}+R^{\\prime}+s}")#text(" is only a compression if ")#tao-math("{\\log \\left|S\\right| < k}", block: false)#text(", which is not what is being assumed here (and in any case the satisfiability of ")#mi("{S}")#text(" in the case ")#tao-math("{\\log \\left|S\\right| < k}", block: false)#text(" is trivial from the union bound).")

#text("The key trick is that while it does indeed take ")#tao-math("{\\log \\left|S\\right|}", block: false)#text(" bits to store any given clause ")#mi("{s}")#text(", there is an economy of scale: after many recursive applications of the fix algorithm, the ")#emph[#text("marginal")]#text(" amount of bits needed to store ")#mi("{s}")#text(" drops to merely ")#mi("{k-C+O(1)}")#text(", which is less than ")#mi("{k}")#text(" if ")#mi("{C}")#text(" is large enough, and which will therefore make the entropy compression argument work.")

#text("Let’s see why this is the case. Observe that the clauses ")#mi("{s}")#text(" for which the above algorithm ")#mi("{Fix(s)}")#text(" is called come in two categories. Firstly, there are those ")#mi("{s}")#text(" which came from the original list ")#mi("{T}")#text(" of failed clauses. Each of these will require ")#tao-math("{O(\\log \\left|S\\right|)}", block: false)#text(" bits to store – but there are only ")#tao-math("{\\left|T\\right|}", block: false)#text(" of them. Since ")#tao-math("{\\left|T\\right| \\leq \\left|S\\right|}", block: false)#text(", the net amount of storage space required for these clauses is ")#tao-math("{O(\\left|S\\right| \\log \\left|S\\right|)}", block: false)#text(" at most. Actually, one can just store the subset ")#mi("{T}")#text(" of ")#mi("{S}")#text(" using ")#tao-math("{\\left|S\\right|}", block: false)#text(" bits (one for each element of ")#mi("{S}")#text(", to record whether it lies in ")#mi("{T}")#text(" or not).")

#text("Of more interest is the other category of clauses ")#mi("{s}")#text(", in which ")#mi("{Fix(s)}")#text(" is called recursively from some previously invoked call ")#mi("{Fix(s^{\\prime})}")#text(" to the fix algorithm. But then ")#mi("{s}")#text(" is one of the at most ")#mi("{2^{k-C}}")#text(" clauses in ")#mi("{S}")#text(" whose support intersects that of ")#mi("{s^{\\prime}}")#text(". Thus one can encode ")#mi("{s}")#text(" using ")#mi("{s^{\\prime}}")#text(" and a number between ")#mi("{1}")#text(" and ")#mi("{2^{k-C}}")#text(", representing the position of ")#mi("{s}")#text(" (with respect to some arbitrarily chosen fixed ordering of ")#mi("{S}")#text(") in the list of all clauses in ")#mi("{S}")#text(" whose supports intersect that of ")#mi("{s^{\\prime}}")#text(". Let us call this number the ")#emph[#text("index")]#text(" of the call ")#mi("{Fix(s)}")#text(".")

#text("Now imagine that while the Fix routine is called, a running ")#emph[#text("log file")]#text(" (or history) ")#mi("{H}")#text(" of the routine is kept, which records ")#mi("{s}")#text(" each time one of the original ")#tao-math("{\\left|T\\right|}", block: false)#text(" calls ")#mi("{Fix(s)}")#text(" with ")#mi("{s \\in T}")#text(" is invoked, and also records the index of any other call ")#mi("{Fix(s)}")#text(" made during the recursive procedure. Finally, we assume that this log file records a termination symbol whenever a ")#mi("{Fix}")#text(" routine terminates. By performing a ")#link("http://en.wikipedia.org/wiki/Stack_trace")[#text("stack trace")]#text(", one sees that whenever a Fix routine is called, the clause ")#mi("{s}")#text(" that is being repaired by that routine can be deduced from an inspection of the log file ")#mi("{H}")#text(" up to that point.")

#text("As a consequence, at any intermediate stage in the process of all these fix calls, the original state ")#mi("{A+R}")#text(" of the assignment and the random string of bits can be deduced from the current state ")#mi("{A^{\\prime}+R^{\\prime}}")#text(" of these objects, plus the history ")#mi("{H^{\\prime}}")#text(" up to that point.")

#text("Now suppose for contradiction that ")#mi("{S}")#text(" is not satisfiable; thus the stack of fix calls can never completely terminate. We trace through this stack for ")#mi("{M}")#text(" steps, where ")#mi("{M}")#text(" is some large number to be chosen later. After these steps, the random string ")#mi("{R}")#text(" has shortened by an amount of ")#mi("{Mk}")#text("; if we set ")#mi("{R}")#text(" to initially have length ")#mi("{Mk}")#text(", then the string is now completely empty, ")#mi("{R^{\\prime} = \\emptyset}")#text(". On the other hand, the history ")#mi("{H^{\\prime}}")#text(" has size at most ")#tao-math("{O(\\left|S\\right|) + M(k-C+O(1))}", block: false)#text(", since it takes ")#tao-math("{\\left|S\\right|}", block: false)#text(" bits to store the initial clauses in ")#mi("{T}")#text(", ")#tao-math("{O(\\left|S\\right|)+O(M)}", block: false)#text(" bits to record all the instances when Step 1 occurs, and every subsequent call to Fix generates a ")#mi("{k-C}")#text("-bit number, plus possibly a termination symbol of size ")#mi("{O(1)}")#text(". Thus we have a lossless compression algorithm ")#mi("{A+R \\mapsto A^{\\prime}+H^{\\prime}}")#text(" from ")#mi("{n+Mk}")#text(" completely random bits to ")#tao-math("{n+O(\\left|S\\right|) + M(k-C+O(1))}", block: false)#text(" bits (recall that ")#mi("{A}")#text(" and ")#mi("{R}")#text(" were chosen randomly, and independently of each other). But since ")#mi("{n+Mk}")#text(" random bits cannot be compressed losslessly into any smaller space, we have the entropy bound ")#metadata(none) <tao-5ac2f6288df5e51e35ab>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("n+O(\\left|S\\right|) + M(k-C+O(1)) \\geq n+Mk", block: true)]]

#text(" which leads to a contradiction if ")#mi("{M}")#text(" is large enough (and if ")#mi("{C}")#text(" is larger than an absolute constant). This proves Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Observe that the above argument in fact gives an explicit bound on ")#mi("{M}")#text(", and with a small bit of additional effort, it can be converted into a probabilistic algorithm that (with high probability) computes a satisfying assignment for ")#mi("{S}")#text(" in time polynomial in ")#tao-math("{\\left|S\\right|}", block: false)#text(" and ")#mi("{n}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One can replace the usage of randomness and Shannon entropy in the above argument with ")#link("http://en.wikipedia.org/wiki/Kolmogorov_complexity")[#text("Kolmogorov complexity")]#text(" instead; thus, one sets ")#mi("{A+R}")#text(" to be a string of ")#mi("{n+Mk}")#text(" bits which cannot be computed by any algorithm of length ")#tao-math("{n+O(\\left|S\\right| \\log \\left|S\\right|) + M(k-C+O(1))}", block: false)#text(", the existence of which is guaranteed as soon as ")#link(<tao-5ac2f6288df5e51e35ab>)[#text("(1)")]#text(" is violated; the proof now becomes deterministic, except of course for the problem of building the high-complexity string, which by their definition can only be constructed quickly by probabilistic methods. This is the approach taken ")#link("http://blog.computationalcomplexity.org/2009/06/kolmogorov-complexity-proof-of-lov.html")[#text("by Fortnow")]#text(".")
]

#heading(level: 1)[#text("Comments (46)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/826a2728424b30ad8cc83000d2bfd8744edcd1bafba060e1c70b63281a0934f6-5e3de4a3d5bde314bee2c1b42ac7f851cee463773970099eaeb046cc61a7dd19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of harrison")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-40842")[#strong[#text("harrison")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2009")])]

#text("The link to the Szemeredi regularity lemma is messed up (and I was just about to point out that it’s probably the most famous energy-increment argument in additive combinatorics, too!) ")#emph[#text("[Corrected, thanks – T.]")]

#text("Apart from that, wonderful exposition! The insight that the failure of an algorithm on X gives you information about X is, of course, nothing new (it underlies the monotonicity arguments as well as many, many others), but Moser’s result is probably the purest use of it I’ve seen.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-40846")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2009")])]

#text("This is very interesting! I can’t help finding some analogy with the problem of constructing large primes, because the application of the Local Lemma seems to have the flavor of a lower-bound sieve argument (getting a probability for the intersection of the complements of events which are close to independent), and we can see the problem of explicit construction of primes as an algorithmic (as opposed to non-constructive) version of sieve…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-40848")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2009")])]

#text("“If something cannot go on forever, it must stop.”")

#text("I think Markov should be referenced. See “Markov Principle” on wiki.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of oguz")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-40851")[#strong[#text("oguz")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2009")])]

#text("Dear All,")

#text("I am doing my Ph.D. in probability theory and planning to deal with theoretical computer science too.")

#text("Could you please recommend me some introductory books, survey papers, web blogs in that field?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d23cc3da033f57b2b1ac053db7960311354c229cc3c84ce68bdbdbfa160ae2c2-c38544dbd633193f1e3915b8ad574de58aee1ac0d275cc74df73464734cc5958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nh")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-40863")[#strong[#text("nh")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2009")])]

#text("Very nice exposition, thank you!")

#text("I believe that you can slightly improve that compression argument when it comes to determining the value of M. In fact, to store the initial set of unsatisfied clauses, you can just store one bit for each clause, for |S| bits, instead of O(|S| log |S|) bits.")

#text("I didn’t thoroughly check it, but I believe this gets you to the expected linear running time (as in Moser’s result) when you turn the compression argument into a probilistic algorithm.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-40872")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2009")])]

#text("Hmm, heuristically this seems plausible, but even after storing the initial set T, I think one would need another ")#tao-math("O(\\left|S\\right| \\log \\left|S\\right|)", block: false)#text(" bits to update that set due to the fact that fixing one clause of T may well “accidentally” fix other clauses that were in the queue to be fixed also. It may be though that if one does this carefully enough, one can keep the total entropy cost down to ")#tao-math("O(\\left|S\\right|)", block: false)#text(", but it would need to be checked.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heinrich")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-40905")[#strong[#text("Heinrich")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2009")])]

#text("The algorithm is “accidentally” fixing many clauses already, namely whenever it reaches Step 1. The ")#mi("O(1)")#text(" token in the history records this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-40912")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2009")])]

#text("Ah yes, you’re right, so we can eliminate the log after all. I’ve amended the text to reflect this.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-40870")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2009")])]

#text("This post is missing an expository tag. ")#emph[#text("[Well spotted! Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b14a08793ead6f06f9db4557eee0271f99e432d06fe3dec339aeb9b565fb3758-819bc8cdf39d530f585f2d28fe35f3e451ac73663bae50a87fd031fe0c6b7fd6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of proaonuiq")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-40874")[#strong[#text("proaonuiq")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2009")])]

#text("In some cases the hard task is to prove that the monotonicity property, observed experimentally in some cases, holds for all the instances of the problem and it is straightforward to convert this property into a step of the searching algorithm…but the Moser argument seems great.")

#text("It is also great how you describe in your posts the hidden mathematical connections: infinite-finite, continuous-discrete, random-structured…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-40879")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2009")]

#text("[…] Moser’s entropy compression argument There are many situations in combinatorics in which one is running some sort of iteration algorithm to continually &#822 […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5650411fbd7a1a7fb7284973bf01ff6c783a2ff037bfe6b41482248c5156ef12-d8f54817b81426f31a6db23146492062f643ba32c750133586310acf51acb174.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Foster Boondoggle")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-40881")[#strong[#text("Foster Boondoggle")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2009")])]

#text("I’m puzzled by the throwaway comment right at the beginning in parentheses, about not being able to use transfinite induction. Isn’t it tautological that an algorithm can’t possibly depend on AC? Any method that essentially uses AC cannot possibly have an algorithm (unless by algorithm one includes waving a wand and saying “presto” at a key point).")

#text("My layman’s understanding of AC is that it plays a role similar to that of an oracle in your previous post – you invoke it to “create” an object (such as a non-principal ultrafilter) that cannot be constructed or exhibited by means involving a finite or countable number of steps – otherwise it would be unnecessary.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-40884")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2009")])]

#text("You seem to be using “algorithm” to mean “terminating algorithm.” This isn’t the case; for example, there are situations in which we can give an algorithm that produces a sequence which one wants to converge to a point with desirable properties, but it can happen that in order to guarantee convergence we need to index the sequence by an ordinal larger than the natural numbers. Transfinite induction and Zorn’s lemma are tools we use to create “extra steps” to guarantee that our algorithm “terminates.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5650411fbd7a1a7fb7284973bf01ff6c783a2ff037bfe6b41482248c5156ef12-d8f54817b81426f31a6db23146492062f643ba32c750133586310acf51acb174.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Foster Boondoggle")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-40885")[#strong[#text("Foster Boondoggle")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2009")])]

#text("I don’t think I mean an algorithm that terminates – e.g., Newton’s method for finding $\\sqrt{2}$ is an instance of an algorithm. But isn’t it essential to what we mean by $\\it algorithm$ that it be amenable to execution? An algorithm that entails AC is, by hypothesis, $\\it not$ executable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-40890")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2009")])]

#text("Algorithms which involve AC are, by definition, valid (or “executable”, if you will) algorithms in any mathematical universe in which AC holds, and in particular in any model of ZFC. (If one wishes to think algorithmically, one can think of AC as providing a ‘choice function’ oracle in one’s transfinite program. Other axioms of ZFC, such as the axiom of union, axiom of specification, and axiom of infinity, are also needed to set up the architecture needed to “run” a transfinite algorithm, in particular the theory of ordinals, but this is relatively straightforward; see ")#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/")[#text("these notes of mine")]#text(".)")

#text("Of course, such an algorithm would not work as stated in the physical universe, but that is not the direct concern of pure mathematics, being instead a topic of computer science (and physics also, to some extent). In particular, transfinite algorithms are not covered by the Church-Turing thesis. (On the other hand, one can convert many (though not all) infinitary algorithms into finitary counterparts which would, in principle, run in the physical universe; see ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("my earlier blog post")]#text(" for further discussion. Furthermore, the independence of AC from the other axioms can often be used to show that a mathematical result obtained using an AC-dependent algorithm, is also necessarily true in the absence of that axiom, even if the algorithm used to prove that result no longer “runs”.)")

#text("Thus, for instance, the standard greedy algorithm to locate a basis for an arbitrary vector space (which may be infinite dimensional) can be proven to succeed in any ZFC universe, thanks to Zorn’s lemma, just as Newton’s algorithm to obtain a root of a smooth function from a sufficiently accurate initial guess can be proven to succeed in any model of the reals which obeys the Dedekind completeness axiom (which is part of the standard axiomatisation of the reals, and holds for the standard model of the reals).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5650411fbd7a1a7fb7284973bf01ff6c783a2ff037bfe6b41482248c5156ef12-d8f54817b81426f31a6db23146492062f643ba32c750133586310acf51acb174.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Foster Boondoggle")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-40892")[#strong[#text("Foster Boondoggle")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2009")])]

#text("Thank you Terry. This has been bothering me ever since I saw a solution (by Stan Wagon) to the infinite version of the prisoners guessing each others’ hat colors which involved using a non-principal ultrafilter. (I still think his “solution” was bogus, since the problem statement didn’t mention that the prisoners had access to this choice-function oracle.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd18c226fb016c7dfa4d375f62ebddcaf7fe33db11a7e9ad9d177f63dad517ff-169994bcbd313dae8ff9a3b82add06b4aef6c90e347a797c3085ab872823ed7e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andreaberdondini")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-632195")[#strong[#text("andreaberdondini")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2021")])]

#text("Terence tao I would like to know your answer to this question.")

#text("If we roll a ten-sided die a thousand times, what is the average entropy of the generated sequence?")

#text("It seems a very easy question, there are 10^1000 possible combinations, each with its own entropy, we just need to take the average.")

#text("We get the following value H(X)med=0.9980.")

#text("For example, if I toss a coin 3 times I have 2^3=8 possible combinations, each with its own entropy, in this case, H(X)med is:")

#text("H(X)med=(H1(X)+H2(X)+H3(X)+H4(X)+H5(X)+H6(X)+H7(X)+H8(X))/8")

#text("But, if now we throw the dice once more and calculate the average entropy of 10% of the combinations with less entropy, we get a set equal to the previous 0.1*10^1001 =10^1000.")

#text("The entropy value thus obtained is H(X)med2=0.9964.")

#text("How can we choose between the two entropy values?")

#text("In practice, there are two points of view with which to observe the outcome of the throwing of the dice.")

#text("A good way may be to choose the entropy value which multiplied by the length of the sequence gives a smaller value.")

#text("0.998*1000=998")#linebreak()#text(" 0.9964*1001=997.4")

#text("Therefore, we should choose the second entropy value.")

#text("If we choose the first entropy value, the encoder will take n outputs i.i.d. of the source and maps them on n(H(X)med), in the case of example n=1000.")

#text("By choosing the second entropy value, the encoder takes n outputs i.i.d. of the source and maps them to n2(H(X)med2) with n2> n. in the case of example n=1000 and n2=1001.")

#text("Starting from an apparently simple question, it is possible to arrive in a not simple situation where we can have different interpretations.")

#text("So, I repeat the starting question: If we roll a ten-sided die a thousand times what is the average entropy of the generated sequence?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heinrich")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-40906")[#strong[#text("Heinrich")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2009")])]

#text("Small typo just below inequality (1), “contradiction of ")#mi("M")#text(" is large enough” should be “.. if ")#mi("M")#text(" is …”.")

#text("I am slightly confused about the wording surrounding (1). I take it you mean that inequality (1) holds when ")#mi("M")#text(" is large enough, but this would mean that we can compress completely random bits, a contradiction. I think the naming (1) an “entropy bound” is slightly misleading, or at least has mislead myself, in that (1) does not a priori estimate the entropy of ")#mi("A+R")#text(" or that of ")#mi("A^{\\prime}+H^{\\prime}")#text(", but compares the two entropy estimates for large ")#mi("M")#text(" a posterior.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-40913")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2009")])]

#text("Oops; I had the inequality (1) the wrong way around. (Both are true, which is where the contradiction comes from, but yes, the attribution was wrong.)")

#text("Thanks for the corrections!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e942430ff1257ac41f2cb8b03de7d52203ef174c36ddbff15f615d8ab4914902-8ddc25447f5bfeef892b40ed87c269f9cb4ec46df0a94ba282313a4ca3c594ec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pietro Poggi-Corradini")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-40916")[#strong[#text("Pietro Poggi-Corradini")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2009")])]

#text("Does the Lovasz local lemma have any connection with the central limit thm?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mer")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-40928")[#strong[#text("Mer")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2009")])]

#text("Hi,")#linebreak()#text(" I have a question some how related to this post. Suppose, we have a monotonically decreasing function and we want to find its fixed point, i.e., we have an iterative process with x_{n+1}=f(x_n). Now what is interesting to me is not the fixed point itself but the number of iteration to reach this fixed point given a specific starting point. Is there any way to guess/approximate the number of iterations needed? Even if there is not a general way of approximating the number of iterations for a general monotonic function, a hint to special cases is also appreciated.")#linebreak()#text(" Thanks")#linebreak()#text(" Mer")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b52ff027d28a845b4575c40cc2293b8e193fd2ebc68df251fecb48c70b1286b-12b044ea34de44b01ef7d7b3851954758e0bf53c02ed2abe6dbcce1318eb4336.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-40983")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("Is it possible to control the $O(1)$ term more precisely and obtain a better bound on $C$, say make it arbitrarily small? Is the LLL argument tight for k-sat, i.e. is there an example of an unsatisfiable instance where each clause intersects at most $2^{k – \\log_2 e}$ others?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-41004")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2009")])]

#text("Dear Prof. Tao,")

#text("in Theorem 1, what do you mean by ” (including s itself)” ?")

#text("thanks ")#emph[#text("[s was supposed to refer to the initial clause; I’ve adjusted the text a little to reflect this. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-41005")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2009")])]

#text("”…it is likely that there will be some non-empty subset T of clauses in S which are not satisfied by S.”")

#text("the last S should be A.")

#text("thanks ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-41022")[#strong[#text("Math World | Moser’s entropy compression argument")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2009")]

#text("[…] Here is the original post: Moser’s entropy compression argument […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67019e3fae1feeb0fc6f4bd4355aa0bc8c9b319ab6a9e7e88c91677bdb55e367-ba0993a576e1ab40345ecc51a7c9d8d0f0e94d7c8ff20d2e42b3db31f480995d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of piotr")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-41742")[#strong[#text("piotr")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2009")])]

#text("Is the LLL argument tight for k-sat, i.e. is there an example of an unsatisfiable instance where each clause intersects at most $2^{k – \\log_2 e}$ others?")

#text("Not exactly tight, but quite close. I think this is the best construction of k-sat instances that are unsatisfied and have have variable occurences:")

#text("@article{hoory:523,")#linebreak()#text(" author = {Shlomo Hoory and Stefan Szeider},")#linebreak()#text(" collaboration = {},")#linebreak()#text(" title = {A Note on Unsatisfiable k-CNF Formulas with Few Occurrences per Variable},")#linebreak()#text(" publisher = {SIAM},")#linebreak()#text(" year = {2006},")#linebreak()#text(" journal = {SIAM Journal on Discrete Mathematics},")#linebreak()#text(" volume = {20},")#linebreak()#text(" number = {2},")#linebreak()#text(" pages = {523-528},")#linebreak()#text(" keywords = {unsatisfiable CNF formulas; NP-completeness; occurrence of variables},")#linebreak()#text(" url = {http://link.aip.org/link/?SJD/20/523/1},")#linebreak()#text(" doi = {10.1137/S0895480104445745}")#linebreak()#text(" }")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Konstantinos Panagiotou")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-43374")[#strong[#text("Konstantinos Panagiotou")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2010")])]

#text("Thanks for the great post.")

#text("Do you think that this approach could be extended to show that any call to FIX terminates after, say, O(log S) recursive calls with high probability? This might not be interesting in the case of the local lemma, but I think it would be great for other applications: think for example of a dynamic data structure in an online setting, where we want to bound the maximum time that a query can take.")

#text("I’m not sure if the original proof of Moser gives this result, but Joel Spencer’s version of it gives it (if I recall correctly).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2e20432100262a5b99ba385d7934d2f9a540464810c38245d92c2d31e65f527-a01929072145909bc5936b8c6a3fc8c387d454c3a7eb745ef2f3e82bd3afe07e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shiva")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-43376")[#strong[#text("Shiva")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2010")])]

#text("The bitmask representing the initially violate clause is precisely |S| long, so can O(|S|) be simplified to |S| in the last paragraph?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJ")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-46083")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2010")])]

#text("Great exposition!!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-50277")[#strong[#text("Seminare SS 2011 « ………. DOT's blog ……….")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2011")]

#text("[…] Lovász Local Lemma: Hier und hier […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-53888")[#strong[#text("Tentative Plans and Belated Updates II | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2011")]

#text("[…] These are also good times for other areas of combinatorics. I described some startling developments (e.g., here and here and here) and there is more. There were a few posts (here and here) on the Cup Set Problem. Recently David Bateman and Nets Katz improved, after many years, the Roth-Meshulam bound. See these two posts on Gowers’s blog (I,II). Very general theorems discovered independently by David Conlon and Tim Gowers and by Matheas Schacht show that many theorems (such as Ramsey’s theorem or Turan’s theorem) continue to hold for substructures of sparse random sets. Louis Esperet, Frantisek Kardos, Andrew King, Daniel Kral, and Serguei Norine proved the Lovasz-Palmer conjecture. They showed that every cubic bridgeless graph G has at least perfect matchings. The concept of flag algebras, discovered by Rasborov, is an extremely useful tool for extremal set theory. It has led to solutions of several problems and seems to bring us close to a solution of Turan’s Conjecture (which we discussed here and here.) For example, it led to the solution by Hamed Hatami, Jan Hladký, Daniel Král, Serguei Norine, and Alexander Razborov of the question on the maximum number of pentagons in triangle-free graphs. Hamed Hatami found a structure theorem for Boolean functions with coarse thresholds w.r.t. small probabilities. This extends and sharpens results by Ehud Friedgut and Jean Bourgain. I finally caught up (thanks to Reshef Meir) with Moser-Tardos result giving a new algorithmic proof for Lovasz local lemma. Amazing! You can read about it here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-126345")[#strong[#text("How to measure a vector’s quality of having less negative entries. | Help me on math , homework, math activities")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2012")]

#text("[…] iterative algorithm which continually improves some vector $mathbf{v}$. Borrowing expressions from Terry Tao’s blog, each loop of my algorithm replaces $mathbf{v}$ with some better version $mathbf{v}'$ of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-128155")[#strong[#text("How to measure a vector's quality of having less negative entries. | Q&A System")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2012")]

#text("[…] iterative algorithm which continually improves some vector $mathbf{v}$. Borrowing expressions from Terry Tao’s blog, every loop of my algorithm replaces $mathbf{v}$ with some an exceptional offer better edition […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8dfbd3d448ea2ff7acbfd98d8b2e05367698adf00f7fbd2823ca86aaaa614f40-75f74e777f02c8363177fde7950d2e410f8ac43fa0db57c690cede07edfd47f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ThankYou")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-140431")[#strong[#text("ThankYou")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2012")])]

#text("Hi,")#linebreak()#text(" could you please check your code for the “entropy bound” again? I cannot see any formula between “…we have the entropy bound” and “which leads to a contradiction…”.")#linebreak()#text(" Thank You!")

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Surya")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-183887")[#strong[#text("Surya")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2012")])]

#text("Dear Prof. Tao")

#text("Is there a way to see why the random improvements are producing an assignment even though the Lovasz Local Lemma seems to be capable of producing occurrence of extremely rare events. Randomised and local choices generally tend to work only when the event of interest occurs with significant probability.")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-183899")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2012")])]

#text("I would classify Moser’s algorithm as a semi-random method rather than a random method; the iterative modifications made are not intended to disperse the solution uniformly across the configuration space, but are deliberately engineered to move the proposed solution closer to a true solution by reducing the number of visible “local errors”. The randomness is mostly present to avoid getting stuck in some sort of local minimum (cf. annealing methods in variational problems), and of course is also crucial in the theoretical guarantee that a solution must eventually be detected with positive probability.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cbc51c325249b54ad6fc71329b897a78abaf24e9d6c6f207e03048d4d361cb78-7bf40ae57853d1fb5f17e6327deefc58a58700c75446ed588f82bb9220b0649d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tap1cse")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-250769")[#strong[#text("tap1cse")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2013")])]

#text("Can you please clarify how that constant term becomes 3?")

#text("Thanks in advance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-446305")[#strong[#text("Quantum Lovasz Local Lemma | Pieces")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2014")]

#text("[…] we sketch the core idea of the termination proof for Algorithm 1, and refer interested readers to Terence Tao’s blog post, which covers more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-456485")[#strong[#text("Quantum Lovasz Local Lemma | Pieces")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2015")]

#text("[…] we sketch the core idea of the termination proof for Algorithm 1, and refer interested readers to Terence Tao’s blog post, which covers more detail. Notice that at each call to FIX, we have as input $latex {(R, A, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-459431")[#strong[#text("The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2015")])]

#text("[…] reminiscent of the “entropy compression argument” of Moser and Tardos, discussed in this previous post). This argument, which is a simple consequence of the Shannon entropy inequalities, can be viewed […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b26ddb73003fe01a672af93995eaa6fd71470981dc7fd6902d71e3ca430f291a-ce093f375f56496103da8646b6a6314fd7281fc1d926dc2c71ed4d2b010d9ff3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D.S.")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-503355")[#strong[#text("D.S.")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2018")])]

#text("There is one additional somewhat critical detail missing in this proof. The encoder and decoder for the lossless compression has the formula (that is, the set S of clauses) “built into” it (for example, it needs to consult this to encode/decode some clause as the t-th neighbor of some other clause during a recursive call to Fix). This is not a problem, however, and can be handled in one of two ways: pay for it in the LHS of the key inequality (1) by throwing in an additional |S| k log n term, which will weaken the bound on M by a tiny bit; or (2) use a stronger version of the entropy compression bound asserting that even if the encoder/decoder has a fixed string of this length hardwired into it, n + Mk bits can’t be compressed to n + O(|S|) + M(k – C + O(1)) bits on average. (In the Fortnow version, this is captured elegantly if opaquely by writing “Fix a Kolmogorov random string x of length n+sk (random relative to φ, k, s, r, m and n) ” [I’m referring to the “relative to φ” part here].")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-531685")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2019")])]

#text("Yes, but no matter how many bits of deterministic information the encoder and decoder have access to, it is still not possible to losslessly encode ")#mi("n")#text(" random bits into ")#mi("m")#text(" bits for any fixed ")#mi("m<n")#text(", simply because the number ")#mi("2^n")#text(" of possible values of the input exceeds the number ")#mi("2^m")#text(" of the number of possible outputs, and no decoder can overcome the collision that is then forced by the pigeonhole principle regardless of how much deterministic information (independent of the input) that the decoder has access to.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The sunflower lemma via Shannon entropy | What's new")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-575966")[#strong[#text("The sunflower lemma via Shannon entropy | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2020")])]

#text("[…] The argument bears some resemblance to the “entropy compression method” discussed in this previous blog post; there may be a way to more explicitly express the argument below in terms of that method. (There […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-587506")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2020")])]

#text("Are there instances where these kind of monotonicity arguments are used to prove lower bounds?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c9d0afd7e80741d26c154be7fedf447a7cfac032e95209918c45d1ef5845352d-a7b7c0c3acee4e3027e89a8cb40753685810505c56a7ce9fbe7830ff1f3be127.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Typo?")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-624777")[#strong[#text("Typo?")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2021")])]

#text("The end of the paragraph starting with “Each time Step 2 of the Fix algorithm…” should be changed to “…bits of A’ on the support of s.”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed997b15b527ebc749c2dd61cbc5fc4270180701e6820eb06c5786ee7fb78d2e-84d34cd3b1f6f2f63a89081b843f472f6b21cf3c533f21760864b8ecd90abe44.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Entropy Estimation via Two Chains: Streamlining the Proof of the Sunflower Lemma – Theory Dish")]], [#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/#comment-626393")[#strong[#text("Entropy Estimation via Two Chains: Streamlining the Proof of the Sunflower Lemma – Theory Dish")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2021")])]

#text("[…] We need the following useful lemmas about Shannon entropy. We omit their proofs here as they can be found in Tao’s blog post, where many basic properties of Shannon entropy are also discussed. (We also highly recommend Tao’s other blog posts about Shannon entropy and the entropy compression argument.) […]")
]
