// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/05/30/van-dantzigs-theorem/
// Converted to Typst by tao2typ: "2026-10-14T09:11:27.441519+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "van Dantzig’s theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("van Dantzig’s theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 May 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/05/30/van-dantzigs-theorem/")[#text("https://terrytao.wordpress.com/2011/05/30/van-dantzigs-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is yet another post in a series on basic ingredients in the structural theory of ")#link("http://en.wikipedia.org/wiki/Locally_compact_group")[#text("locally compact groups")]#text(", which is closely related to ")#link("http://en.wikipedia.org/wiki/Hilbert's_fifth_problem")[#text("Hilbert’s fifth problem")]#text(".")

#text("In order to understand the structure of a topological group ")#mi("{G}")#text(", a basic strategy is to try to ")#emph[#text("split")]#text(" ")#mi("{G}")#text(" into two smaller factor groups ")#mi("{H, K}")#text(" by exhibiting a ")#link("http://en.wikipedia.org/wiki/Exact_sequence")[#text("short exact sequence")]

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow K \\rightarrow G \\rightarrow H \\rightarrow 0.")]]

#text("If one has such a sequence, then ")#mi("{G}")#text(" is an extension of ")#mi("{H}")#text(" by ")#mi("{K}")#text(" (which includes ")#link("http://en.wikipedia.org/wiki/Direct_product_of_groups")[#text("direct products")]#text(" ")#mi("{H \\times K}")#text(" and ")#link("http://en.wikipedia.org/wiki/Semidirect_product")[#text("semidirect products")]#text(" ")#mi("{H \\ltimes K}")#text(" as examples, but can be more general than these situations, as discussed in ")#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/")[#text("this previous blog post")]#text("). In principle, the problem of understanding the structure of ")#mi("{G}")#text(" then splits into three simpler problems:")

#enum(start: 1, 
[#text("(Horizontal structure) Understanding the structure of the “horizontal” group ")#mi("{H}")#text(".")],
[#text("(Vertical structure) Understanding the structure of the “vertical” group ")#mi("{K}")#text(".")],
[#text("(Cohomology) Understanding the ways in which one can extend ")#mi("{H}")#text(" by ")#mi("{K}")#text(".")]
)

#text("The “cohomological” aspect to this program can be nontrivial. However, in principle at least, this strategy reduces the study of the large group ")#mi("{G}")#text(" to the study of the smaller groups ")#mi("{H, K}")#text(". (This type of splitting strategy is not restricted to topological groups, but can also be adapted to many other categories, particularly those of groups or group-like objects.) Typically, splitting alone does not fully kill off a structural classification problem, but it can reduce matters to studying those objects which are somehow “simple” or “irreducible”. For instance, this strategy can often be used to reduce questions about arbitrary finite groups to finite simple groups.")

#text("A simple example of splitting is as follows. Given any topological group ")#mi("{G}")#text(", one can form the ")#link("http://en.wikipedia.org/wiki/Connected_space")[#text("connected component")]#text(" ")#mi("{G^\\circ}")#text(" of the identity – the maximal connected set containing the identity. It is not difficult to show that ")#mi("{G^\\circ}")#text(" is a closed (and thus also locally compact) normal subgroup of ")#mi("{G}")#text(", whose quotient ")#mi("{G/G^\\circ}")#text(" is another locally compact group. Furthermore, due to the maximal connected nature of ")#mi("{G^\\circ}")#text(", ")#mi("{G/G^\\circ}")#text(" is ")#link("http://en.wikipedia.org/wiki/Totally_disconnected_space")[#text("totally disconnected")]#text(" – the only connected sets are the singletons. In particular, ")#mi("{G/G^\\circ}")#text(" is Hausdorff (the identity element is closed). Thus we have obtained a splitting")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow G^\\circ \\rightarrow G \\rightarrow G/G^\\circ \\rightarrow 0")]]

#text("of an arbitrary locally compact group into a connected locally compact group ")#mi("{G^\\circ}")#text(", and a totally disconnected locally compact group ")#mi("{G/G^\\circ}")#text(". In principle at least, the study of locally compact groups thus splits into the study of connected locally compact groups, and the study of totally disconnected locally compact groups (though the cohomological issues are not always trivial).")

#text("In the structural theory of totally disconnected locally compact groups, the first basic theorem in the subject is ")#link("http://www.ams.org/mathscinet-getitem?mr=1556954")[#text("van Dantzig’s theorem")]#text(" (which we prove below the fold):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Van Danztig’s theorem)")]#text(" ")#metadata(none) <tao-ac4df2dd11f78f0db766>#text(" Every totally disconnected locally compact group ")#mi("{G}")#text(" contains a compact open subgroup ")#mi("{H}")#text(" (which will of course still be totally disconnected).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" Let ")#mi("{p}")#text(" be a prime. Then the ")#link("http://en.wikipedia.org/wiki/P-adic_number")[#mi("{p}")#text("-adic field")]#text(" ")#mi("{{\\bf Q}_p}")#text(" (with the usual ")#mi("{p}")#text("-adic valuation) is totally disconnected locally compact, and the ")#mi("{p}")#text("-adic integers ")#mi("{{\\bf Z}_p}")#text(" are a compact open subgroup.")
]

#text("Of course, this situation is the polar opposite of what occurs in the connected case, in which the only open subgroup is the whole group.")

#text("In view of van Dantzig’s theorem, we see that the “local” behaviour of totally disconnected locally compact groups can be modeled by the compact totally disconnected groups, which are better understood (for instance, one can start analysing them using the ")#link("http://en.wikipedia.org/wiki/Peter%E2%80%93Weyl_theorem")[#text("Peter-Weyl theorem")]#text(", as discussed in ")#link("https://terrytao.wordpress.com/2011/01/23/the-peter-weyl-theorem-and-non-abelian-fourier-analysis-on-compact-groups/")[#text("this previous post")]#text("). The global behaviour however remains more complicated, in part because the compact open subgroup given by van Dantzig’s theorem need not be normal, and so does not necessarily induce a splitting of ")#mi("{G}")#text(" into compact and discrete factors.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" ")#metadata(none) <tao-82e4f62b02330f8eb8a7>#text(" Let ")#mi("{p}")#text(" be a prime, and let ")#mi("{G}")#text(" be the semi-direct product ")#mi("{{\\bf Z} \\ltimes {\\bf Q}_p}")#text(", where the integers ")#mi("{{\\bf Z}}")#text(" act on ")#mi("{{\\bf Q}_p}")#text(" by the map ")#mi("{m: x \\mapsto p^m x}")#text(", and we give ")#mi("{G}")#text(" the product of the discrete topology of ")#mi("{{\\bf Z}}")#text(" and the ")#mi("{p}")#text("-adic topology on ")#mi("{{\\bf Q}_p}")#text(". One easily verifies that ")#mi("{G}")#text(" is a totally disconnected locally compact group. It certainly has compact open subgroups, such as ")#mi("{\\{0\\} \\times {\\bf Z}_p}")#text(". However, it is easy to show that ")#mi("{G}")#text(" has no non-trivial compact normal subgroups (the problem is that the conjugation action of ")#mi("{{\\bf Z}}")#text(" on ")#mi("{{\\bf Q}_p}")#text(" has all non-trivial orbits unbounded).")
]

#text("Returning to more general locally compact groups, we obtain an immediate corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2")]#text(" ")#metadata(none) <tao-c330ec504d82c24fcd10>#text(" Every locally compact group ")#mi("{G}")#text(" contains an open subgroup ")#mi("{H}")#text(" which is “compact-by-connected” in the sense that ")#mi("{H/H^\\circ}")#text(" is compact.")
]

#text("Indeed, one applies van Dantzig’s theorem to the totally disconnected group ")#mi("{G/G^\\circ}")#text(", and then pulls back the resulting compact open subgroup.")

#text("Now we mention another application of van Dantzig’s theorem, of more direct relevance to Hilbert’s fifth problem. Define a ")#emph[#text("generalised Lie group")]#text(" to be a topological group ")#mi("{G}")#text(" with the property that given any open neighbourhood ")#mi("{U}")#text(" of the identity, there exists an open subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" and a compact normal subgroup ")#mi("{N}")#text(" of ")#mi("{G^{\\prime}}")#text(" in ")#mi("{U}")#text(" such that ")#mi("{G^{\\prime}/N}")#text(" is isomorphic to a Lie group. It is easy to see that such groups are locally compact. The deep ")#emph[#text("Gleason-Yamabe theorem")]#text(", which among other things establishes a satisfactory solution to Hilbert’s fifth problem (and which we will not prove here), asserts the converse:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Gleason-Yamabe theorem)")]#text(" Every locally compact group is a generalised Lie group.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" We consider the locally compact group ")#mi("{G = {\\bf Z} \\ltimes {\\bf Q}_p}")#text(" from Example ")#link(<tao-82e4f62b02330f8eb8a7>)[#text("2")]#text(". This is of course not a Lie group. However, any open neighbourhood ")#mi("{U}")#text(" of the identity in ")#mi("{G}")#text(" will contain the compact subgroup ")#mi("{N := \\{0\\} \\times p^j {\\bf Z}_p}")#text(" for some integer ")#mi("{j}")#text(". The open subgroup ")#mi("{G^{\\prime} := \\{0\\} \\times {\\bf Z}_p}")#text(" then has ")#mi("{G^{\\prime}/N}")#text(" isomorphic to the discrete finite group ")#mi("{{\\bf Z}/p^j{\\bf Z}}")#text(", which is certainly a Lie group. Thus ")#mi("{G}")#text(" is a generalised Lie group.")
]

#text("One important example of generalised Lie groups are those locally compact groups which are an ")#link("http://en.wikipedia.org/wiki/Inverse_limit")[#text("inverse limit")]#text(" (or ")#emph[#text("projective limit")]#text(") of Lie groups. Indeed, suppose we have a family ")#mi("{(G_i)_{i\\in I}}")#text(" of Lie groups ")#mi("{G_i}")#text(" indexed by partially ordered set ")#mi("{I}")#text(" which is ")#link("http://en.wikipedia.org/wiki/Directed_set")[#text("directed")]#text(" in the sense that every finite subset of ")#mi("{I}")#text(" has an upper bound, together with continuous homomorphisms ")#mi("{\\pi_{i \\rightarrow j}: G_i \\rightarrow G_j}")#text(" for all ")#mi("{i > j}")#text(" which form a category in the sense that ")#mi("{\\pi_{j \\rightarrow k} \\circ \\pi_{i \\rightarrow j} = \\pi_{i \\rightarrow k}}")#text(" for all ")#mi("{i>j>k}")#text(". Then we can form the inverse limit")

#align(center)[#tao-fit-display[#mitex("G := \\lim_{\\stackrel{\\leftarrow}{i \\in I}} G_i,")]]

#text("which is the subgroup of ")#mi("{\\prod_{i \\in I} G_i}")#text(" consisting of all tuples ")#mi("{(g_i)_{i \\in I} \\in \\prod_{i \\in I} G_i}")#text(" which are compatible with the ")#mi("{\\pi_{i \\rightarrow j}}")#text(" in the sense that ")#mi("{\\pi_{i \\rightarrow j}(g_i) = g_j}")#text(" for all ")#mi("{i>j}")#text(". If we endow ")#mi("{\\prod_{i \\in I} G_i}")#text(" with the product topology, then ")#mi("{G}")#text(" is a closed subgroup of ")#mi("{\\prod_{i \\in I} G_i}")#text(", and thus has the structure of a topological group, with continuous homomorphisms ")#mi("{\\pi_i: G \\rightarrow G_i}")#text(" which are compatible with the ")#mi("{\\pi_{i \\rightarrow j}}")#text(" in the sense that ")#mi("{\\pi_{i \\rightarrow j} \\circ \\pi_i = \\pi_j}")#text(" for all ")#mi("{i>j}")#text(". Such an inverse limit need not be locally compact; for instance, the inverse limit")

#align(center)[#tao-fit-display[#mitex("\\lim_{\\stackrel{\\leftarrow}{n \\in {\\bf N}}} {\\bf R}^n")]]

#text("of Euclidean spaces with the usual coordinate projection maps is isomorphic to the infinite product space ")#mi("{{\\bf R}^{\\bf N}}")#text(" with the product topology, which is not locally compact. However, if an inverse limit")

#align(center)[#tao-fit-display[#mitex("G = \\lim_{\\stackrel{\\leftarrow}{i \\in I}} G_i")]]

#text("of Lie groups ")#emph[#text("is")]#text(" locally compact, it can be easily seen to be a generalised Lie group. Indeed, by local compactness, any open neighbourhood ")#mi("{G}")#text(" of the identity will contain an open precompact neighbourhood of the identity; by construction of the product topology (and the directed nature of ")#mi("{I}")#text("), this smaller neighbourhood will in turn will contain the kernel of one of the ")#mi("{\\pi_i}")#text(", which will be compact since the preceding neighbourhood was precompact. Quotienting out by this ")#mi("{\\pi_i}")#text(" we obtain a locally compact subgroup of the Lie group ")#mi("{G_i}")#text(", which is necessarily again a Lie group by Cartan’s theorem, and the claim follows.")

#text("In the converse direction, it is possible to use Corollary ")#link(<tao-c330ec504d82c24fcd10>)[#text("2")]#text(" to obtain the following ")#link("http://www.ams.org/mathscinet-getitem?mr=39730")[#text("observation of Gleason")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4")]#text(" ")#metadata(none) <tao-63bc9e3734391984de9d>#text(" Every Hausdorff generalised Lie group contains an open subgroup that is an inverse limit of Lie groups.")
]

#text("We show Theorem ")#link(<tao-63bc9e3734391984de9d>)[#text("4")]#text(" below the fold. Combining this with the (substantially more difficult) Gleason-Yamabe theorem, we obtain quite a satisfactory description of the local structure of locally compact groups. (The situation is particularly simple for connected groups, which have no non-trivial open subgroups; we then conclude that every connected locally compact Hausdorff group is the inverse limit of Lie groups.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4")]#text(" The locally compact group ")#mi("{G := {\\bf Z} \\ltimes {\\bf Q}_p}")#text(" is not an inverse limit of Lie groups because (as noted earlier) it has no non-trivial compact normal subgroups, which would contradict the preceding analysis that showed that all locally compact inverse limits of Lie groups were generalised Lie groups. On the other hand, ")#mi("{G}")#text(" contains the open subgroup ")#mi("{\\{0\\} \\times {\\bf Q}_p}")#text(", which is the inverse limit of the discrete (and thus Lie) groups ")#mi("{\\{0\\} \\times {\\bf Q}_p/p^j {\\bf Z}_p}")#text(" for ")#mi("{j \\in {\\bf Z}}")#text(" (where we give ")#mi("{{\\bf Z}}")#text(" the usual ordering, and use the obvious projection maps).")
]

#metadata(none) <tao-16f679ca1560ed59af74>

#heading(level: 1)[#strong[#text(" — 1. van Dantzig’s theorem — ")]]

#text("To prove van Dantzig’s theorem, we first need a lemma from point set topology, which shows that totally disconnected spaces contain enough ")#link("http://en.wikipedia.org/wiki/Clopen_set")[#text("clopen sets")]#text(" to separate points:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5")]#text(" ")#metadata(none) <tao-982945308d3682d16636>#text(" Let ")#mi("{X}")#text(" be a totally disconnected compact Hausdorff space, and let ")#mi("{x, y}")#text(" be distinct points in ")#mi("{X}")#text(". Then there exists a clopen set that contains ")#mi("{x}")#text(" but not ")#mi("{y}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{K}")#text(" be the intersection of all the clopen sets that contain ")#mi("{x}")#text(" (note that ")#mi("{X}")#text(" is obviously clopen). Clearly ")#mi("{K}")#text(" is closed and contains ")#mi("{x}")#text(". Our objective is to show that ")#mi("{K}")#text(" consists solely of ")#mi("{\\{x\\}}")#text(". As ")#mi("{X}")#text(" is totally disconnected, it will suffice to show that ")#mi("{K}")#text(" is connected.")

#text("Suppose this is not the case, then we can split ")#mi("{K = K_1 \\cup K_2}")#text(" where ")#mi("{K_1,K_2}")#text(" are disjoint non-empty closed sets; without loss of generality, we may assume that ")#mi("{x}")#text(" lies in ")#mi("{K_1}")#text(". As all compact Hausdorff spaces are ")#link("http://en.wikipedia.org/wiki/Normal_space")[#text("normal")]#text(", we can thus enclose ")#mi("{K_1, K_2}")#text(" in disjoint open subsets ")#mi("{U_1,U_2}")#text(" of ")#mi("{X}")#text(". In particular, the topological boundary ")#mi("{\\partial U_2}")#text(" is compact and lies outside of ")#mi("{K}")#text(". By definition of ")#mi("{K}")#text(", we thus see that for every ")#mi("{y \\in \\partial U_2}")#text(", we can find a clopen neighbourhood of ")#mi("{x}")#text(" that avoids ")#mi("{y}")#text("; by compactness of ")#mi("{\\partial U_2}")#text(" (and the fact that finite intersections of clopen sets are clopen), we can thus find a clopen neighbourhood ")#mi("{L}")#text(" of ")#mi("{x}")#text(" that is disjoint from ")#mi("{\\partial U_2}")#text(". One then verifies that ")#mi("{L \\backslash U_2 = L \\backslash \\overline{U_2}}")#text(" is a clopen neighbourhood of ")#mi("{x}")#text(" that is disjoint from ")#mi("{K_2}")#text(", contradicting the definition of ")#mi("{K}")#text(", and the claim follows. ")#mi("\\Box")

#text("Now we can prove van Dantzig’s theorem. We will use an argument from the ")#link("http://www.ams.org/mathscinet-getitem?mr=551496")[#text("book of Hewitt and Ross")]#text(". Let ")#mi("{G}")#text(" be totally disconnected locally compact (and thus Hausdorff). Then we can find a compact neighbourhood ")#mi("{K}")#text(" of the identity. By Lemma ")#link(<tao-982945308d3682d16636>)[#text("5")]#text(", for every ")#mi("{y \\in \\partial K}")#text(", we can find a clopen neighbourhood of the identity that avoids ")#mi("{y}")#text("; by compactness of ")#mi("{\\partial K}")#text(", we may thus find a clopen neighbourhood of the identity that avoids ")#mi("{\\partial K}")#text(". By intersecting this neighbourhood with ")#mi("{K}")#text(", we may thus find a compact clopen neighbourhood ")#mi("{F}")#text(" of the identity. As ")#mi("{F}")#text(" is both compact and open, we may then the continuity of the group operations find a symmetric neighbourhood ")#mi("{U}")#text(" of the identity such that ")#mi("{U F \\subset F}")#text(". In particular, if we let ")#mi("{G^{\\prime}}")#text(" be the group generated by ")#mi("{U}")#text(", then ")#mi("{G^{\\prime}}")#text(" is an open subgroup of ")#mi("{G}")#text(" contained in ")#mi("{F}")#text(" and is thus compact as required.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The same argument shows that totally disconnected locally compact group contains arbitrarily small compact open subgroups, or in other words the compact open subgroups form a neighbourhood base for the identity.")
]

#heading(level: 1)[#strong[#text(" — 2. Inverse limits — ")]]

#text("Now we prove Theorem ")#link(<tao-63bc9e3734391984de9d>)[#text("4")]#text(". Let ")#mi("{G}")#text(" be a Hausdorff generalised Lie group. By Corollary ")#link(<tao-c330ec504d82c24fcd10>)[#text("2")]#text(", we may find an open subgroup ")#mi("{H}")#text(" such that ")#mi("{H/H^\\circ}")#text(" is compact. An easy application of Cartan’s theorem shows that ")#mi("{H}")#text(" remains a Hausdorff generalised Lie group; we will show that it is in fact an inverse limit of Lie groups. The key fact is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6")]#text(" ")#metadata(none) <tao-9294ab38039f60d2ec53>#text(" Let ")#mi("{U}")#text(" be any open neighbourhood of the identity in ")#mi("{H}")#text(". Then there exists a compact normal subgroup ")#mi("{N}")#text(" of ")#mi("{H}")#text(" in ")#mi("{U}")#text(" such that ")#mi("{H/N}")#text(" is isomorphic to a Lie group.")
]

#emph[#text("Proof:")]#text(" Since ")#mi("{H}")#text(" is a generalised Lie group, we can find an open subgroup ")#mi("{H^{\\prime}}")#text(" of ")#mi("{H}")#text(" and a compact normal subgroup ")#mi("{N^{\\prime}}")#text(" of ")#mi("{H^{\\prime}}")#text(" in ")#mi("{U}")#text(" such that ")#mi("{H^{\\prime}/N^{\\prime}}")#text(" is isomorphic to a Lie group.")

#text("As ")#mi("{H^{\\prime}}")#text(" is an open group, it must be clopen, and in particular contains ")#mi("{H_0}")#text(". We conclude that ")#mi("{H^{\\prime}/H_0}")#text(" is an open subgroup of the compact group ")#mi("{H/H_0}")#text(", and is therefore finite index. In particular, ")#mi("{H^{\\prime}/H_0}")#text(" has only finitely many conjugates in ")#mi("{H/H_0}")#text("; intersecting them together, we obtain an open normal subgroup of ")#mi("{H/H_0}")#text(" inside ")#mi("{H^{\\prime}/H_0}")#text(", which pulls back to an open finite index normal subgroup ")#mi("{H^{\\prime\\prime}}")#text(" of ")#mi("{H}")#text(" of inside ")#mi("{H^{\\prime}}")#text(".")

#text("Let ")#mi("{N := N^{\\prime} \\cap H^{\\prime\\prime}}")#text(", then ")#mi("{N}")#text(" is a compact normal subgroup of ")#mi("{H^{\\prime\\prime}}")#text(". ")#mi("{H^{\\prime\\prime}/N}")#text(" is a locally compact subgroup of ")#mi("{H^{\\prime}/N^{\\prime}}")#text("; since ")#mi("{H^{\\prime}/N^{\\prime}}")#text(" is isomorphic to a Lie group, ")#mi("{H^{\\prime\\prime}/N}")#text(" is also, by Cartan’s theorem. On the other hand, as ")#mi("{H^{\\prime\\prime}}")#text(" is an open normal subgroup, ")#mi("{H/H^{\\prime\\prime}}")#text(" is a discrete group. Using the short exact sequence")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow H^{\\prime\\prime}/N \\rightarrow H/N \\rightarrow H/H^{\\prime\\prime} \\rightarrow 0")]]

#text("and noting that all outer automorphisms on a Lie group are smooth (as remarked on in the ")#link("https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/")[#text("previous post")]#text("), we conclude that ")#mi("{H/N}")#text(" is also isomorphic to a Lie group. The claim follows. ")#mi("\\Box")

#text("We can now let ")#mi("{I}")#text(" be the partially ordered set of compact normal subgroups of ")#mi("{H}")#text(", with the ordering of reverse inclusion (")#mi("{N \\geq N^{\\prime}}")#text(" if ")#mi("{N^{\\prime} \\subset N}")#text("); this is clearly a directed set. This gives a family of Lie groups ")#mi("{(H/N)_{N \\in I}}")#text(" with the obvious projection maps ")#mi("{\\pi_{N \\rightarrow N^{\\prime}}}")#text(". By Lemma ")#link(<tao-9294ab38039f60d2ec53>)[#text("6")]#text(" and the Hausdorff property, the compact normal subgroups of ")#mi("{H}")#text(" have trivial intersection, which shows that as a group, ")#mi("{H}")#text(" is identifiable with the inverse limit")

#align(center)[#tao-fit-display[#mitex("\\lim_{\\stackrel{\\leftarrow}{N \\in I}} H/N.")]]

#text("From Lemma ")#link(<tao-9294ab38039f60d2ec53>)[#text("6")]#text(" again we see that this identification is also a homeomorphism, and the claim follows.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/30/van-dantzigs-theorem/#comment-53246")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2011")])]

#text("Missing expository tag. ")#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0826047d4601a032b887a74efeff06c884ac1a6f1ad551051e3d1ad3edc4d44d-583df98143af9ad68dc37e52b7105285c8d50c4b734ced153f3125d4eb3086f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Florian")]], [#link("https://terrytao.wordpress.com/2011/05/30/van-dantzigs-theorem/#comment-53406")[#strong[#text("Florian")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2011")])]

#text("A couple of typos:")

#text("N should be normal (def. of generalised Lie group).")

#text("The link to “directed” is broken.")

#text("“Indeed, local compactness, any” is missing “by” probably?")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/05/30/van-dantzigs-theorem/#comment-53794")[#strong[#text("Seventh Linkfest")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2011")]

#text("[…] The Cotlar-Stein Lemma, Locally compact groups with faithful finite-dimensional representations, van Dantzig’s Theorem, The Furstenberg multiple recurrence theorem and finite […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brouwer’s fixed point and invariance of domain theorems, and Hilbert’s fifth problem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/05/30/van-dantzigs-theorem/#comment-53849")[#strong[#text("Brouwer’s fixed point and invariance of domain theorems, and Hilbert’s fifth problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2011")])]

#text("[…] There are results closely related to Theorem 4, such as the Gleason-Yamabe theorem mentioned in a recent post, which do not use the notion of being locally Euclidean, and do not require algebraic topological […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/05/30/van-dantzigs-theorem/#comment-53859")[#strong[#text("Laplace算子与表示论 « Fight with Infinity")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2011")]

#text("[…] Tao van Dantzig’s theorem […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a08f0bddf30af3853ec65fbe6409e89295d2c65e1ec106b7973e485f2662da1e-95daa5f6f535dff4b971c88874e905c38f1e40f8e9435ebfd2c5e9a49b6d5d89.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of parça kontor")]], [#link("https://terrytao.wordpress.com/2011/05/30/van-dantzigs-theorem/#comment-54755")[#strong[#text("parça kontor")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2011")])]

#text("The global behaviour however remains more complicated")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3a63381f55770f37c0b079f2aab9008b90e0b693c7adf770c64757092d7f324d-ddac3e19dab3ed8e90e7b46420596ee550ec9ba5730df58ab46c8880d1280d4d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jesse Peterson")]], [#link("https://terrytao.wordpress.com/2011/05/30/van-dantzigs-theorem/#comment-58900")[#strong[#text("Jesse Peterson")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2011")])]

#text("In Lemma 5 you say that all totally disconnected spaces are Hausdorff, but I don’t think this is quite correct. ")#emph[#text("[Ah, right, they’re only T1 in general, though they are Hausdorff in the group case. In any case, I’ve corrected the article, thanks, -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Hilbert-Smith conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2011/05/30/van-dantzigs-theorem/#comment-66750")[#strong[#text("The Hilbert-Smith conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2011")])]

#text("[…] structural theory of locally compact groups (specifically, the Gleason-Yamabe theorem discussed in previous posts) and some results of Newman that sharply restrict the ability of periodic actions on a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b7ac4d8d6b90921bd17857e7d4afbbf8fc4699f6df1a9bfdb59e9f3e95dee15-c53e09183d4cbc3aaddcdd0901e816e8138dcf9c8299aa5577361e563d194cfc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of benbrawn")]], [#link("https://terrytao.wordpress.com/2011/05/30/van-dantzigs-theorem/#comment-197732")[#strong[#text("benbrawn")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2012")])]

#text("Example 3: ” G/N isomorphic to the discrete finite group …”")#linebreak()#text(" I think this should be G’/N based on the definition of generalised Lie group given above the example.")

#text("Great Blog BTW!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcc24ace73a5b60191455a6bf556b52a72211eec18e5e5ae13cd02f9e5993653-cded1b16f2f91676d14cf3b759a33fc633e90ca1705c1251afd4ee411bb2a5d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MahbubAlam231")]], [#link("https://terrytao.wordpress.com/2011/05/30/van-dantzigs-theorem/#comment-487810")[#strong[#text("MahbubAlam231")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2017")])]

#text("In the proof of van Dantzig theorem, the clopen set that is disjoint from the {\\partial K}, isn’t that clopen in {K} (I mean if you use Lemma 5)? How to make that clopen in {G}?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/30/van-dantzigs-theorem/#comment-487856")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2017")])]

#text("A set which is closed in ")#mi("K")#text(" is automatically also closed in ")#mi("G")#text("; and a set which is open in ")#mi("K")#text(" and avoids the boundary of ")#mi("K")#text(" is automatically open in ")#mi("G")#text(".")
]
]
