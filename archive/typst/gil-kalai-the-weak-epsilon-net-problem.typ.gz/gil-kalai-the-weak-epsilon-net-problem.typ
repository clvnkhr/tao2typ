// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/
// Converted to Typst by tao2typ: "2026-10-14T16:34:55.143312+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "(Gil Kalai) The weak epsilon-net problem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("(Gil Kalai) The weak epsilon-net problem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 April 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/")[#text("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("[")#emph[#text("This post is authored by ")#link("http://www.ma.huji.ac.il/~kalai/")[#text("Gil Kalai")]#text(", who has kindly “guest blogged” this week’s “open problem of the week”.")]#text(" – T.]")

#text("This is a problem in discrete and convex geometry. It seeks to quantify the intuitively obvious fact that large convex bodies are so “fat” that they cannot avoid “detection” by a small number of observation points. More precisely, we fix a dimension d and make the following definition (introduced by ")#link("http://www.ams.org/mathscinet-getitem?mr=884223")[#text("Haussler and Welzl")]#text("):")

#list(
[#strong[#text("Definition")]#text(": Let ")#mi("X \\subset {\\Bbb R}^d")#text(" be a finite set of points, and let ")#mi("0 < \\epsilon < 1")#text(". We say that a finite set ")#mi("Y \\subset {\\Bbb R}^d")#text(" is a ")#emph[#text("weak ")#mi("\\epsilon")#text("-net")]#text(" for X (with respect to convex bodies) if, whenever B is a convex body which is large in the sense that ")#tao-math("\\left|B \\cap X\\right| > \\epsilon \\left|X\\right|", block: false)#text(", then B contains at least one point of Y. (If Y is contained in X, we say that Y is a ")#emph[#text("strong ")#mi("\\epsilon")#text("-net")]#text(" for X with respect to convex bodies.)")]
)

#text("For example, in one dimension, if ")#mi("X = \\{1,\\ldots,N\\}")#text(", and ")#mi("Y = \\{ \\epsilon N, 2 \\epsilon N, \\ldots, k \\epsilon N \\}")#text(" where k is the integer part of ")#mi("1/\\epsilon")#text(", then Y is a weak ")#mi("\\epsilon")#text("-net for X with respect to convex bodies. Thus we see that even when the original set X is very large, one can create a ")#mi("\\epsilon")#text("-net of size as small as ")#mi("O(1/\\epsilon)")#text(". Strong ")#mi("\\epsilon")#text("-nets are of importance in ")#link("http://en.wikipedia.org/wiki/Computational_learning_theory")[#text("computational learning theory")]#text(", and are fairly well understood via ")#link("http://en.wikipedia.org/wiki/Vapnik-Chervonenkis_theory")[#text("Vapnik-Chervonenkis (or VC) theory")]#text("; however, the theory of weak ")#mi("\\epsilon")#text("-nets is still not completely satisfactory.")

#text("One can ask what happens in higher dimensions, for instance when X is a discrete cube ")#mi("X = \\{1,\\ldots,N\\}^d")#text(". It is not too hard to cook up ")#mi("\\epsilon")#text("-nets of size ")#mi("O_d(1/\\epsilon^d)")#text(" (by using tools such as ")#link("http://en.wikipedia.org/wiki/Minkowski's_theorem")[#text("Minkowski’s theorem")]#text("), but in fact one can create ")#mi("\\epsilon")#text("-nets of size as small as ")#mi("O( \\frac{1}{\\epsilon} \\log \\frac{1}{\\epsilon} )")#text(" simply by taking a ")#emph[#text("random")]#text(" subset of X of this cardinality and observing that “up to errors of ")#mi("\\epsilon")#text("“, the total number of essentially different ways a convex body can meet X grows at most polynomially in ")#mi("1/\\epsilon")#text(". (This is a very typical application of the ")#link("http://en.wikipedia.org/wiki/Probabilistic_method")[#text("probabilistic method")]#text(".) On the other hand, since X can contain roughly ")#mi("1/\\epsilon")#text(" disjoint convex bodies, each of which contains at least ")#mi("\\epsilon")#text(" of the points in X, we see that no ")#mi("\\epsilon")#text("-net can have size much smaller than ")#mi("1/\\epsilon")#text(".")

#text("Now consider the situation in which X is now an arbitrary finite set, rather than a discrete cube. More precisely, let ")#mi("f(\\epsilon,d)")#text(" be the least number such that ")#emph[#text("every")]#text(" finite set X possesses at least one weak ")#mi("\\epsilon")#text("-net for X with respect to convex bodies of cardinality at most ")#mi("f(\\epsilon,d)")#text(". (One can also replace the finite set X with an arbitrary probability measure; the two formulations are equivalent.) Informally, f is the least number of “guards” one needs to place to prevent a convex body from covering more than ")#mi("\\epsilon")#text(" of any given territory.")

#list(
[#strong[#text("Problem 1")]#text(": For fixed d, what is the correct rate of growth of f as ")#mi("\\epsilon \\to 0")#text("?")]
)

#metadata(none) <tao-145f5137fdc4088c74db>#text(" It is already non-trivial (and somewhat surprising) that ")#mi("f(\\epsilon,d)")#text(" is even finite. This fact was first shown by ")#link("http://www.ams.org/mathscinet-getitem?mr=1208800")[#text("Alon, Bárány, ")#text("Füredi, and Kleitman")]#text(" (the planar case was achieved earlier by ")#link("http://www.ams.org/mathscinet-getitem?mr=1082647")[#text("Bárány, ")#text("Füredi, and Lovász")]#text("), who established a bound of the form ")#mi("f(\\epsilon,d) = O_d( 1/\\epsilon^{d+1})")#text("; this was later improved to ")#mi("O_d(\\frac{1}{\\epsilon^d} \\log^{O_d(1)} \\frac{1}{\\epsilon} )")#text(" by ")#link("http://www.ams.org/mathscinet-getitem?mr=1300506")[#text("Chazelle et al")]#text(". In the other direction, the best lower bound is ")#mi("c(d)/\\epsilon")#text(" for some positive c(d); it was shown ")#link("http://www.ams.org/mathscinet-getitem?mr=1904009")[#text("by Matousek")]#text(" that c(d) grows at least as fast as ")#mi("e^{c\\sqrt{d}}")#text(" for some absolute constant c. Furthermore, many of the upper bound results come with actual (probabilistic) algorithms to locate these nets. Some better upper bounds are known when d=2 (where hyperbolic geometry can be used in a beautiful way) or when special assumptions are made on the set X (here, the bounds can be rather subtle, for instance inverse ")#link("http://en.wikipedia.org/wiki/Ackermann_function")[#text("Ackermann functions")]#text(" show up in some cases!).")

#text("The finiteness of ")#mi("f(\\epsilon,d)")#text(" was an important ingredient in ")#link("http://www.ams.org/mathscinet-getitem?mr=1185788")[#text("a paper of Alon and Kleitman")]#text(" which proved a ")#link("http://www.ams.org/mathscinet-getitem?mr=92987")[#text("Helly-type conjecture of Debrunner and Hadwiger")]#text(". Recall that ")#link("http://en.wikipedia.org/wiki/Helly%27s_theorem")[#text("Helly’s theorem")]#text(" asserts that if a finite collection of convex bodies in ")#mi("{\\Bbb R}^d")#text(" has the property that any d+1 of them have non-empty intersection, then the whole family has non-empty intersection. Helly’s theorem already easily implies that ")#mi("f(\\epsilon,d)=1")#text(" for ")#mi("\\epsilon > 1-\\frac{1}{d+1}")#text(". Alon and Kleitman’s theorem asserts that for every integers ")#mi("p,q")#text(" and ")#mi("d")#text(", ")#mi("p \\ge q \\ge d+1")#text(", there is a function ")#mi("M(p,q;d)")#text(" such that the following is true. Every finite family ")#mi("\\mathcal K")#text(" of convex sets in ")#mi("{\\Bbb R}^d")#text(" with the property that among every ")#mi("p")#text(" sets in the family there are ")#mi("q")#text(" with non empty intersection can be divided to at most ")#mi("M(p,q;d)")#text(" intersecting subfamilies. (Helly’s theorem thus asserts that ")#mi("M(d+1,d+1;d)=1")#text(".)")

#text("If we replaced weak ")#mi("\\epsilon")#text("-nets by strong ")#mi("\\epsilon")#text("-nets then the situation is well understood; the analogue of ")#mi("f(\\epsilon,d)")#text(" would be finite if and only if the collection of convex bodies had finite ")#link("http://en.wikipedia.org/wiki/VC_dimension")[#text("Vapnik-Chervonenkis (or VC) dimension")]#text(". However, it can be shown that the VC dimension of convex bodies is infinite, and so strong ")#mi("\\epsilon")#text("-nets can be required to be arbitrarily large for fixed ")#mi("\\epsilon")#text(". One can however use VC theory to show that, for instance, one can find a strong ")#mi("\\epsilon")#text("-net for any set with respect to, say, convex pentagons in the plane, whose size depends only on ")#mi("\\epsilon")#text(".)")

#text("One can talk about ")#mi("\\epsilon")#text("-nets in the more abstract setting of ")#link("http://en.wikipedia.org/wiki/Hypergraph")[#text("hypergraphs")]#text(" (a.k.a. ")#emph[#text("set systems")]#text("). Indeed, if ")#mi("H = (A, {\\mathcal F})")#text(" is a hypergraph (thus A is a set of vertices, and ")#mi("{\\mathcal F}")#text(" is a collection of subsets (or “edges”) of A), and ")#mi("\\mu")#text(" is any probability measure on A, we define a weak ")#mi("\\epsilon")#text("-net of ")#mi("\\mu")#text(" to be a set ")#mi("Y \\subset A")#text(" which meets every edge of the hypergraph which has ")#mi("\\mu")#text("-measure greater than ")#mi("\\epsilon")#text(". We then define ")#mi("f(\\epsilon,H)")#text(" to be the least number such that every probability measure has a weak ")#mi("\\epsilon")#text("-net of cardinality at most ")#mi("f(\\epsilon,H)")#text(".")

#list(
[#strong[#text("Problem 2")]#text(": Find conditions on the hypergraph H which ensure that ")#mi("f(\\epsilon,H)")#text(" is finite. [It is already known that if H has a finite VC dimension D, then ")#mi("f(\\epsilon,H)")#text(" is finite, and in fact is bounded by ")#mi("O(D \\frac{1}{\\epsilon} \\log \\frac{1}{\\epsilon})")#text("; the more interesting case is when H has infinite VC dimension.]")],
[#strong[#text("Problem 3")]#text(": Is it possible for ")#mi("f(\\epsilon,H)")#text(" to be finite but to be significantly larger than ")#mi("1/\\epsilon")#text("? More precisely, does there exist a hypergraph H and ")#mi("\\tau > 1")#text(" such that ")#mi("1/\\epsilon^\\tau < f(\\epsilon,H) < \\infty")#text(" for all sufficiently small ")#mi("\\epsilon")#text("? It seems very unlikely that this is not the case, but no example of growth faster than ")#mi("\\frac{1}{\\epsilon} \\log \\frac{1}{\\epsilon}")#text(" has been constructed.")]
)

#text("An improved understanding of both strong and weak ")#mi("\\epsilon")#text("-nets will help shed light on the ")#emph[#text("integrality gap")]#text(" between ")#link("http://en.wikipedia.org/wiki/Covering_%28graph_theory%29")[#text("vertex covering numbers")]#text(" (a.k.a. transversal numbers) and fractional vertex covering numbers (a.ka. fractional transversal numbers) of hypergraphs. Roughly speaking, the gap is the phenomenon that it can be more expensive to cover some territory if the amount of resources you can put into any one location is quantized to be an integer. For instance, suppose you want to cover the pentagon graph (i.e. the cycle ")#mi("C_5")#text(" of length 5) by vertices so that each edge is covered by at least one vertex; such a set of vertices is known as a ")#emph[#text("vertex cover")]#text(" or ")#emph[#text("transversal")]#text(". Then one clearly needs at least three vertices to accomplish this. If however one is allowed to assign fractional weights to each vertex, then it becomes more efficient to give each vertex a weight of ")#mi("\\frac{1}{2}")#text(", then again each edge is covered by a total weight of 1 vertex, but now one has only used ")#mi("\\frac{5}{2}")#text(" vertices instead of 3. These problems are of course special cases of ")#link("http://en.wikipedia.org/wiki/Integer_programming")[#text("integer programming")]#text(", which is a much harder problem in general than linear programming (indeed, it can be NP-hard). For further discussion of these issues see ")#link("http://www.ams.org/mathscinet-getitem?mr=1921545")[#text("this paper of Alon et al")]#text(".")

#text("A good reference to much of the above work is ")#link("http://www.ams.org/mathscinet-getitem?mr=1899299")[#text("Matousek’s book")]#text(".")

#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/61a41f9901217a6de1256a8b0d1638ac16eff5dec67bec389f3aa733236aed36-8ecbda28ae40c5f75e88d4d0173384140670cc8b955e99dab9becbec48f125a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Corfield")]], [#link("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/#comment-678")[#strong[#text("David Corfield")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2007")])]

#text("Have weak ")#mi("\\epsilon")#text("-nets found any use in computational learning theory?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/#comment-681")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2007")])]

#text("Dear David, I do not know of such a use and will be happy to learn.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/#comment-688")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2007")])]

#text("Dear David,")

#text("If the VC dimension of a family is finite, so strong ")#mi("\\epsilon")#text("-nets exist, it is possible to PAC-learn for every distribution on the elements of the ground set.")

#text("Let me demonstrate it with the set of planar pentagons: For every probability distribution ")#mi("\\mu")#text(" for points in the plane, and a pentagon ")#mi("A")#text(". Suppose you see sufficiently many examples (")#mi("K (1/\\epsilon) \\log (1/\\epsilon)")#text(" where a point ")#mi("x")#text(" is drawn according to the probability distribution ")#mi("\\mu")#text(" then with high probability you will be able to guess the answers for further questions with high level of success.")

#text("If you replace pentagons by arbitrary convex sets there is no hope for something so strong. If your distribution is concentrated on unit circle, every sequence of questions and answers represents some convex set.")

#text("We are left with a hope that maybe PAC learnability is possible when we restrict the class of probability distributions, or perhaps (more realistically) let the notion of error depends on how well the set is “supported” by ")#mi("\\mu")#text(". It would be nice to explore it. Good question!")

#text("Apropos learnability. I am not aware of a good criterion for the weaker notion of “PAC-testability”. Namely after a long list of questions as above to be able to tell with low chance of failure only if the queries represent some pentagon. (Or, in the general case some edge in your hypergraph.) PAC-learnability implies PAC testability. (So with pentagons we are OK.) But I am not aware of a more general condition that guarantee PAC-testability.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/61a41f9901217a6de1256a8b0d1638ac16eff5dec67bec389f3aa733236aed36-8ecbda28ae40c5f75e88d4d0173384140670cc8b955e99dab9becbec48f125a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Corfield")]], [#link("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/#comment-690")[#strong[#text("David Corfield")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2007")])]

#text("Dear Gil,")

#text("As you probably know, the direction Vapnik moved in was to Support Vector Machines, maximum-margin hyperplane classifiers. Although a VC-dimension could be found for the class of classifiers exceeding a certain margin, see Theorem 1 ")#link("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/www.c3.lanl.gov/~dhush/papers/svm_vcdim.ps")[#text("here")]#text(", a PAC result couldn’t be given since the result was data-dependent.")

#text("However, Shawe-Taylor et al. employed the ")#link("http://eprints.ecs.soton.ac.uk/9793/")[#text("fat-shattering dimension")]#text(" rather than the VC-dimension to yield a PAC result for SVMs.")

#text("It would be interesting to know whther ")#mi("\\epsilon")#text("-nets had anything to say to this result.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/#comment-698")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2007")])]

#text("Dear David, I think the first interesting special case regarding the connection of weak ")#mi("\\epsilon")#text("-net and learnability is this:")

#text("In what sense (if any) can we statistically learn (or statistically test) planar convex sets.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7674f4282f1d74ab6bb0a2be18ac32bde1610992387d596616efda0f3e54d480-dec9e93a42577d424c315c447337184f880d224c62db9b8c5564878d16cc79b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of osias")]], [#link("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/#comment-703")[#strong[#text("osias")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2007")])]

#text("Why I am seeing “formula does not parse” everywhere?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/#comment-3008")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2007")])]

#text("Here, (divided in two parts,) is how the Hadwiger-Debrunner conjecture is proved and the role of the weak ")#mi("\\epsilon")#text("-net theorem in the proof. The original paper of Alon and Kleitman is a very good source, (and looking at original papers may qualify as a good general advice,) but the proof is so nice that I cannot resist the temptation trying to tell you about it. I will also mention some results of similar nature including the recent startling result by J. Fox, J. Pach, and Cs. D. Toth .")

#text("1. The ")#mi("(p,q)")#text("-theorem.")

#text("Theorem (Alon and Kleitman): For every integers ")#mi("p,q")#text(" and ")#mi("d")#text(", ")#mi("p \\ge q \\ge d+1")#text(", there is a function ")#mi("M(p,q;d)")#text(" such that the following is true:")

#text("Every finite family ")#mi("\\cal K")#text(" of convex sets in ")#mi("{\\Bbb R}^d")#text(" with the property that among every ")#mi("p")#text(" sets in the family there are ")#mi("q")#text(" with non empty intersection can be divided to at most ")#mi("M(p,q;d)")#text(" intersecting subfamilies.")

#text("Helly’s theorem thus asserts that ")#mi("M(d+1,d+1;d)=1")#text(".")

#text("Let us look a little bit at this theorem. First consider the case of dimension one. Here, the theorem is valid for ")#mi("M(p,q,d)=p-q+1")#text(". This is a theorem about graphs. Suppose that ")#mi("q=2")#text(". (In every dimension")#linebreak()#text(" the cases where ")#mi("q=d+1")#text(" are the “hardest,” since $M$ is monotone non increasing in the variable ")#mi("q")#text(".)")

#text("2. Interval graphs and perfect graphs.")

#text("Given a collection of intervals in the line their intersection graph ")#mi("G")#text(" is a graph whose vertices correspond to the intervals, and where two vertices are adjacent if the corresponding intervals intersect. (Such a graph is called an interval graph.) The condition of the theorem asserts that the graph contains no independent set of ")#mi("q")#text(" vertices. The conclusion is that the graph can be covered by ")#mi("p-1")#text(" complete graphs. If we consider the complement graph ")#mi("\\bar G")#text(", the condition asserts that the graph contains no complete subgraph of size ")#mi("q")#text(" and the conclusion is that it can be colored by ")#mi("q-1")#text(" colors.")

#text("A complete subgraph of size ")#mi("q")#text(" is an obstacle for coloring a graph in ")#mi("q-1")#text(" colors. But is it the only obstacle? Heavens, no!! There are graphs without triangles which require arbitrary large number of colors to be colored. What make the miracle here is that interval graph are perfect graphs. (Perfect graphs are defined precisely by the property that for every induced subgraph the chromatic number is precisely the maximum size of a complete subgraph.)")

#text("Graphs and hypergraphs arising in geometry behaves well! (in the same sense that the behavior of perfect graph is perfect.)")

#text("3. Proof of the Alon Kleitman ")#mi("(p,q)")#text("-theorem.")

#text("We will consider the case: ")#mi("d=2")#text(", ")#mi("p=4")#text(" and ")#mi("q=3")#text(". Essentially this is the proof of the general case and talking about the (4,3) case in the plane is just in order to make the presentation as concrete as possible.")

#text("We remark that Hadwiger and Debrunner already proved (as a special case of a general result) that ")#mi("M(5,4;2)=2")#text(". (A sort of “perfect behavior” in the plane for ")#mi("q=4,p=5")#text(".).")

#text("Here is the proof in five easy steps:")

#text("Step a: We have ")#mi("n")#text(" convex sets and out of every 4 there are 3 with non empty intersection. Therefore, at least a fraction of ")#mi("\\alpha=1/4")#text(" of all 3-tuples of sets have non empty intersection. This is easy. (But we can wonder if we are not giving up too much information.)")

#text("Step b: If a fraction of ")#mi("\\alpha")#text(" of 3-tuples of sets have non empty intersection then a fraction of ")#mi("\\beta")#text(" of the sets has a point in common!")

#text("This is a result by Katchalski and Liu and it is called a “fractional Helly’s theorem”. The sharp version reads ")#mi("\\beta = 1 - (1-\\alpha)^{1/d+1}")#text(".")

#text("In the case of interest of us the fractional Helly theorem tells us that starting from our family of sets we can find a subfamily consisting of about 1/10 of the original sets with non empty intersection. This is truly a reason for hope and you can imagine that now we will be able to split the original family to 10 or maybe 20 intersecting families.")

#text("But when you see what happens when you delete this large intersecting family and continue you realize that without more ideas you get only a weaker result that the original family can be covered by $\\latex O( \\log n)$ intersecting families. This is not so good because we wanted the number of subfamilies not be a function of the size of the original family.")

#text("Step c: A weighted version of step b.")

#text("We saw that our family contains a large intersecting subfamily. Suppose you give every set a nonnegative weight and you want to find a point in the plane belonging to sets carrying 0.1 or 0.01 of the total weight. (Or, in other words, we want to find anintersecting subfamily which carries 0.1 or 0.01 of the total weight of all sets? )")

#text("Note that this weighted version is a consequence of the theorem we want to prove. (If we can find, say, 100 points in the plane meeting all the sets in the family, one of these points must meet sets carrying 1/100 of the total weight. So it can be a good idea to try to prove this weighted version along the way. (If all weights are the same we are back to step a) )")

#text("Alon and Kleitman observed that such a weighted version can be verified by “multiplying” some of the sets in the family and using again the Katchalski-Liu fractional version of Helly’s theorem.")

#text("We are almost ready to use weak ")#mi("\\epsilon")#text("-nets!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gilkalai")]], [#link("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/#comment-4843")[#strong[#text("gilkalai")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2007")])]

#text("So, where were we? We are describing the proof of Alon and Kleitman’s ")#mi("(p,q)")#text("-theorem. After steps a, b and c, we are almost ready to apply the weak ")#mi("\\epsilon")#text("-net result itself!")

#text("step d: Linear programming duality.")

#text("Let ")#mi("F")#text(" be a hypergraph with ")#mi("n")#text(" vertices. Suppose we want to cover the vertices by edges, namely to find a set of edges so that every vertex belongs to one or more of them.")

#text("In our case, we have a family of convex sets in the plane with the (4,3) property. We consider the following hypergraph:")

#text("The vertices in the hypergraph correspond to the convex sets in the family, and the edges correspond to intersecting subfamilies of convex sets.")

#text("Consider the following two linear programs:")

#text("(OPT1)")

#text("Assign nonnegative weights to vertices in the hypergraph so that")

#text("(1) the sum of weights of vertices in every edge is at most one.")

#text("(2) the sum ")#mi("W_1")#text(" of all weights is maximum.")

#text("(OPT2) (FRACTIONAL COVERING THE VERTICES BY EDGES):")

#text("Assign nonnegative weights for edges in the hypergraph so that:")

#text("(1) The sum of weights of edges containing any vertex is at least one.")

#text("(2) The sum ")#mi("W_2")#text(" of all weights is minimum.")

#text("Linear programming duality asserts that ")#mi("W_1=W_2")#text("!")

#text("Moving to the dual linear programming problem, or juggling between the primal and dual problems is an extremely useful thing to do in combinatorics and I do not really understand why. It is also quite a bit confusing (for me — but I can always consult my colleague Nati Linial). It is probably useful to become fluent in moving to a dual linear programming problem and at the same time not being too blasé about it and not forgetting that this can be very helpful.")

#text("The problem we really want to solve is an integer programming problem:")

#text("(OPT2) (COVERING THE VERTICES BY EDGES):")

#text("Assign 0-1 weights for edges in the hypergraph so that:")

#text("(1) The sum of weights of edges containing any vertex is at least one.")

#text("(2) The sum ")#mi("W_3")#text(" of all weights is minimum.")

#text("The quantity we would like to find is ")#mi("W_3")#text(". We need to pass the “integrality gap “from ")#mi("W_2")#text(" to ")#mi("W_3")#text("?")

#text("Step e: Use the weak ")#mi("\\epsilon-")#text("net theorem.")

#text("The weak ")#mi("\\epsilon")#text("-net theorem is precisely what allows us go from the fractional covering problem to the covering problem.")

#text("Another formulation of the weak ")#mi("\\epsilon")#text("-net theorem (in the plane) is: There is a function ")#mi("g")#text(", so for every hypergraph ")#mi("F")#text(" arising from a family of convex sets in the plane: ")#mi("W_3 \\le g(W_2)")#text(".")

#text("We are done with the description of the proof and continue with little further remarks.")

#text("4. Other theorem of similar nature showing how graphs and hypergraphs arising in geometry are very special.")

#text("There are several cases where the Alon-Kleitman method can be followed to obtain other ")#mi("(p,q)")#text(" theorems. There were quite a few cases where theorems of a similar spirit were obtained by various other methods.")

#text("I will mention three theorems:")

#text("Theorem (D.Larman, J. Matousek, J. Pach, J. Torocsik): For a family of planar convex sets either there is a subfamily of ")#mi("n^{1/5}")#text(" sets which are pairwise intersecting or there is a subfamily of ")#mi("n^{1/5}")#text(" sets which are pairwise disjoint.")

#text("(D. Larman, J. Matousek, J. Pach, J. Torocsik, A Ramsey-type result for convex sets. Bull. London Math. Soc. 26 (1994), no. 2, 132–136.)")

#text("A “")#mi("(p,q)")#text("-theorem” which also directly follows from this paper is:")

#text("For a family of planar convex sets either")

#text("there is a family of ")#mi("p")#text(" which are pairwise disjoint or")

#text("there is a family of ")#mi("c_p \\cdot n")#text(" which are pairwise intersecting.")

#text("(It is not known if it is possible to replace “pairwise disjoint” with “pairwise intersecting” in this last theorem. Fox and Pach have some results in this direction.)")

#text("And (finally) the following beautiful theorem:")

#text("Theorem (J. Fox, J. Pach and Cs. D. Toth):")

#text("Every family of plane convex sets contains two subfamilies of size ")#mi("cn")#text(" such that:")

#text("either each element of the first intersects every element in the second, or")

#text("no element in the first intersects any element of the other.")

#text("5. An example from a different area where weak ")#mi("\\epsilon")#text("-nets (or, equivalently, control of the integrability gap between covering numbers and fractional covering numbers) can be useful.")

#text("J. Bourgain and L. Tzafriri considered the following scenario: Let ")#mi("a > 0")#text(" be a real number. Let ")#mi("A")#text(" be a ")#mi("n \\times n")#text(" matrix with norm 1 and with zeroes on the diagonal. An ")#mi("s")#text(" by ")#mi("s")#text(" principal minor ")#mi("M")#text(" is “good” if the norm of ")#mi("M")#text(" is less than ")#mi("a")#text(".")

#text("Consider the following hypergraph ")#mi("F")#text(":")

#text("The vertices correspond to indices ")#mi("{}[n]=\\{1,2,\\dots,n\\}")#text(". A set ")#mi("S \\subset [n]")#text(" belongs to ")#mi("F")#text(" if the ")#mi("S \\times S")#text(" sub-matrix of ")#mi("M")#text(" is good.")

#text("Bourgain and Tzafriri showed that for every ")#mi("a > 0")#text(" there is ")#mi("C(a) > 0")#text(" so that for every matrix ")#mi("A")#text(" we can find ")#mi("S \\in F")#text(" so that ")#tao-math("\\left|S\\right| \\ge C(a)n", block: false)#text(".")

#text("Moreover, they showed that for every nonnegative weights ")#mi("w_1,w_2,\\dots w_n")#text(" there is ")#mi("S \\in F")#text(" so that the sum of the weights in ")#mi("S")#text(" is at least ")#mi("C(a)")#text(" times the total weight. In other words, (by LP duality, just as we saw above) the vertices of the hypergraph can be fractionally covered by $C(a)$ edges.")

#text("The “big question” is if there a real number ")#mi("C^{\\prime}(a) > 0")#text(" so that for every matrix ")#mi("M,")#text(" ")#mi("{}[n]")#text(" can be covered by ")#mi("C^{\\prime}(a)")#text(" good sets. Or, in other words, if the vertices of ")#mi("F")#text(" can be covered by ")#mi("C^{\\prime}(a)")#text(" edges.")

#text("This question is known to be equivalent to an old conjecture by Kadison and Singer.")

#text("In view of what was already proved by Bourgain and Tzafriri what is needed is to show that the covering number is bounded from above by a function of the fractional covering number or, in other words, a certain weak ")#mi("\\epsilon")#text("-net property.")

#text("Probably the main difficulty in the problem is analytical and not combinatorial. But general conditions that guarantee weak ")#mi("\\epsilon")#text("-net, can suggest what analytical properties one should look for. And vice versa – from a solution to this problem we may be able to extract such conditions which can apply to other problems.")

#text("6. Finding more examples of graphs and hypergraphs where the covering number is not bounded as a function of fractional covering number is also very interesting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/#comment-5198")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2007")])]

#text("The ")#mi("(p,q)")#text(" theorem that follows from Larman’s et als. paper is this")#linebreak()#text(" (I only formulated a weaker version):")

#text("For a family of planar convex sets either")

#text("A) there is a family of ")#mi("p")#text(" which are pairwise disjoint or")

#text("or")

#text("B) the entire family can be divided to ")#mi("C_p")#text(" subfamilies whose members are pairwise intersecting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/#comment-29409")[#strong[#text("Combinatorics, mathematics, academics, polemics, … « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2008")]

#text("[…] One was about the weak epsilon net problem. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/#comment-33789")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2008")])]

#text("Boris Buck, Jiri Matousek, and Gabriel Nivasch proved recently that ")#mi("f(\\epsilon,d) \\ge (1/\\epsilon) (\\log (1/ \\epsilon)^{d-1}")#text(". !!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/#comment-39272")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2009")])]

#text("The link to Buck, Matousek, and Nivasch’s paper is")

#link("http://front.math.ucdavis.edu/0812.5039")[#text("http://front.math.ucdavis.edu/0812.5039")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17b32bc3dd9f7d568f565763f071f712e5388159509ff6248835c50c2524c912-d70e52fd91f08a122fcdc5824ab24231efd2298e7665518bb3e81158e39db7d9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergiu")]], [#link("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/#comment-52189")[#strong[#text("Sergiu")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2011")])]

#text("Is there a list of open problems for (weak) epsilon-nets?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/#comment-384476")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2014")])]

#text("Here are links to a lecture by Noga Alon: 48 minutes on strong and weak epsilon nets: ")#link("https://www.youtube.com/watch?v=LyLC-Jbd2Do")[#text("https://www.youtube.com/watch?v=LyLC-Jbd2Do")]#text(" (Part I) and ")#link("https://www.youtube.com/watch?v=_rF7qQFPX1A")[#text("https://www.youtube.com/watch?v=_rF7qQFPX1A")]#text(" (Part II)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/#comment-489200")[#strong[#text("Basic Notions Seminar is Back! Helly Type Theorems and the Cascade Conjecture | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2017")]

#text("[…] the existence of weak epsilon nets and the basic question about finding bounds for their size. My first ever blog post over Terry Tao’s blog was about weak epsilon nets and since then there were exciting […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/#comment-495270")[#strong[#text("Nathan Rubin Improved the Bound for Planar Weak ε-Nets and Other News From Ein-Gedi | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2018")]

#text("[…] himself announced a great result with new upper bounds for planar weak ε-nets. In 2007 I wrote a guest post (my first ever blog post) on the topic on Terry Tao’s blog. The next section is taken from that old post with reference […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/#comment-504017")[#strong[#text("An Improved Bound for Weak Epsilon-Nets in the Plane, by Nathan Rubin, is on the arXive | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2018")]

#text("[…] The paper An Improved Bound for Weak Epsilon-Nets in the Plane, by Nathan Rubin is now on the arxive. we mentioned the result in this post, and the problem in this post (my very first) over Tao’s blog What’s New. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/#comment-504021")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2018")])]

#text("Here is a link to a paper of Nathan Rubin with a major improvement of the upper bound for weak epsilon-nets in the plane, from ")#mi("O(1/\\epsilon^2)")#text(" to ")#mi("O(1/\\epsilon ^{3/2+\\gamma})")#text(" for every ")#mi("\\gamma >0")#text(". ")#link("https://arxiv.org/abs/1808.02686")[#text("https://arxiv.org/abs/1808.02686")]#text(" .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/22/gil-kalai-the-weak-epsilon-net-problem/#comment-512654")[#strong[#text("Attila Por’s Universality Result for Tverberg Partitions | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2019")]

#text("[…] and Nivasch (Here are links to the paper, and to slides from a talk by Boris Bukh. See also this post and this one of the weak epsilon net problem.) Roughly the idea is this: consider a stretched grid […]")
]
