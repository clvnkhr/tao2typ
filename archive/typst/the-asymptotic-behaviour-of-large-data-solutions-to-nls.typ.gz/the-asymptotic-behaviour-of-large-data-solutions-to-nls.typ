// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/01/14/the-asymptotic-behaviour-of-large-data-solutions-to-nls/
// Converted to Typst by tao2typ: "2026-10-14T16:35:08.893023+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The asymptotic behaviour of large data solutions to NLS", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The asymptotic behaviour of large data solutions to NLS")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 January 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/01/14/the-asymptotic-behaviour-of-large-data-solutions-to-nls/")[#text("https://terrytao.wordpress.com/2008/01/14/the-asymptotic-behaviour-of-large-data-solutions-to-nls/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This weekend I was (once again) in San Diego, this time for the ")#link("http://www.math.ucsd.edu/%7Elindblad/scapde.html")[#text("Southern California Analysis and PDE (SCAPDE)")]#text(" meeting. I gave a talk on “The asymptotic behaviour of large data solutions to NLS”, which is based on ")#link("http://arxiv.org/abs/math.AP/0309428")[#text("two of")]#text(" ")#link("http://arxiv.org/abs/math.AP/0611402")[#text("my previous papers")]#text(" on what solutions to focusing ")#link("http://tosio.math.toronto.edu/wiki/index.php/NLS_equation")[#text("nonlinear Schrödinger equations")]#text(" behave like as time goes to infinity. (Note that this is a specialist conference, and this talk will be a bit more technical than some of the general-audience talks that I have blogged about previously.)")

#metadata(none) <tao-e2ba602ebec3714b33b7>

#text("For this talk, I will focus solutions to the ")#link("http://tosio.math.toronto.edu/wiki/index.php/NLS_equation")[#text("semilinear NLS")]

#align(center)[#tao-fit-display[#tao-math("iu_t + \\Delta u = \\mu \\left|u\\right|^{p-1} u", block: true)]]

#text("where ")#mi("u: I \\times {\\Bbb R}^d \\to {\\Bbb C}")#text(" is a function in one time and d space dimensions, ")#mi("p > 1")#text(" is an exponent, and ")#mi("\\mu = \\pm 1")#text(" is a sign (the sign +1 corresponds to the defocusing NLS, and -1 to the focusing NLS).")

#text("Sufficiently regular solutions to this equation enjoy conservation of mass")

#align(center)[#tao-fit-display[#tao-math("M[u] := \\int_{{\\Bbb R}^d} \\left|u(t,x)\\right|^2\\ dx", block: true)]]

#text("and conservation of energy")

#align(center)[#tao-math("E[u] := \\int_{{\\Bbb R}^d} \\frac{1}{2} \\left|\\nabla u(t,x)\\right|^2 + \\frac{\\mu}{p+1} \\left|u(t,x)\\right|^{p+1}\\ dx", block: false)#text(".")]

#text("For technical reasons (having to do with needing enough decay on the fundamental solution) we shall assume high dimension ")#mi("d \\geq 3")#text(". We are also going to make the assumption that the equation is ")#emph[#text("mass-supercritical")]#text(" (which means that ")#mi("p > 1 + \\frac{4}{d}")#text(") and ")#emph[#text("energy-subcritical")]#text(" (which means that ")#mi("p < 1 + \\frac{4}{d-2}")#text("). (Typical examples of this include the case ")#mi("d=3, p=3")#text(" or ")#mi("d=5, p=2")#text(".)")

#text("From the local well-posedness theory and these assumptions, we also know that solutions can be continued in time so long as the ")#mi("H^1")#text(" norm of the solution remains bounded. So it is natural to make the following additional assumption:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Bounded ")#mi("H^1")]#text(". We have ")#tao-math("\\left\\|u \\right\\|_{L^\\infty_t H^1_x(I \\times {\\Bbb R}^d)} < \\infty", block: false)#text(".")
]

#text("In the defocusing case ")#mi("\\mu=+1")#text(", this condition follows automatically from the conservation laws (and the Gagliardo-Nirenberg inequality) if the initial data has finite ")#mi("H^1")#text(" norm; in the focusing case, one has a similar conclusion so long as the initial data has sufficiently small energy. On the other hand, for sufficiently large ")#mi("H^1")#text(" norm in the focusing case, it is possible for solutions to develop singularities in a finite time.")

#text("Let us consider the case of ")#emph[#text("forward-global")]#text(" solutions (also called ")#emph[#text("immortal")]#text(" solutions) u, in which ")#mi("I = [0,+\\infty)")#text("; from the previous discussion, we see that this includes all finite-")#mi("H^1")#text(" solutions in the defocusing case and all small-")#mi("H^1")#text(" solutions in the focusing case. A natural question is then to understand the asymptotic behaviour of the solution u as ")#mi("t \\to +\\infty")#text(".")

#text("In the defocusing case, or in the focusing small ")#mi("H^1")#text(" case, it is known that one has scattering: the solution approaches a linear solution ")#mi("e^{it\\Delta} u_+")#text(" in the sense that we have a decomposition")

#align(center)[#tao-fit-display[#mitex("u(t) = e^{it\\Delta} u_+(x) + o(1)")]]

#text("as ")#mi("t \\to +\\infty")#text(", where we use o(1) to denote any quantity which goes to zero strongly in the ")#mi("H^1")#text(" topology. In particular, this implies that u(t) decays to zero in many norms (e.g. we have local mass decay ")#tao-math("\\int_F \\left|u(t,x)\\right|^2\\ dx \\to 0", block: false)#text(" for all compact sets F).")

#text("In contrast, we can have very different behaviour for large solutions to the focusing NLS. In particular, if Q is a non-negative Schwartz solution to the ")#emph[#text("ground state equation")]#text(" ")#mi("\\Delta Q + Q^p = EQ")#text(", is forward-global (and also backward-global) and bounded ")#mi("H^1")#text(", but clearly does not scatter to a linear solution. (This example is sharp in the sense that any solution with strictly smaller mass and energy than Q will scatter; this is a recent result ")#link("http://arxiv.org/abs/0710.3630")[#text("of Duyckaerts, Holmer and Roudenko")]#text(".)")

#text("From numerical simulations (and reasoning by analogy with completely integrable equations, such as the 1D cubic NLS (d=1, p=3) it is expected that “generic” forward-global finite ")#mi("H^1")#text(" solutions in the focusing case should resolve into the finite superposition of solitons (or more precisely, solitary waves) diverging from each other, plus a radiation term which decays to zero (much as a linear solution does). This (rather imprecise) conjecture is sometimes known as the ")#emph[#text("soliton resolution conjecture")]#text("; it is also referred to as the ")#emph[#text("grand conjecture")]#text(" ")#link("http://www.icm2006.org/proceedings/Vol_III/contents/ICM_Vol_3_24.pdf")[#text("by Soffer")]#text(". At its most optimistic formulation, it asserts that generic solutions u(t) enjoy some asymptotic decomposition of the form")

#align(center)[#tao-fit-display[#mitex("u(t,x) = \\sum_{j=1}^J e^{i\\theta_j(t)} Q_j( x - x_j(t) ) + e^{it\\Delta} u_+(x) + o(1)")]]

#text("for some bounded J (depending only on the ")#mi("H^1")#text(" bound), some ground states ")#mi("Q_j")#text(" (possibly modulated in frequency to give it some velocity), and $\\theta_j(t)$ and ")#mi("x_j(t)")#text(" are time-varying phases and positions respectively. (To be even more optimistic, one might expect ")#mi("\\theta_j(t)")#text(" and ")#mi("x_j(t)")#text(" to be asymptotically linear in time, and for the ")#mi("x_j(t)")#text(" to diverge from each other.) The situation is expected to simplify substantially when u is spherically symmetric; in that case, we should have ")#mi("J \\leq 1")#text(" and ")#mi("x_1(t) = 0")#text(".")

#text("This conjecture can be settled for various completely integrable systems via the powerful method of inverse scattering to solve these systems exactly, but is well out of reach for any non-integrable system (except for some Klein-Gordon models with spatially localised nonlinearities, as studied by recent ")#link("http://front.math.ucdavis.edu/0711.0041")[#text("work of Komech and Komech")]#text(") due to (a) the wholly non-perturbative nature of the claim, and (b) the fact that the conjecture is expected to fail for some “exceptional” set of data in which more exotic (and unstable) behaviour takes place instead. To date, the vast majority of known PDE techniques cannot usefully exclude small exceptional sets of bad initial data, and so can only prove results which are strong as the worst-case behaviour.")

#text("Nevertheless, it is still possible to say some weaker statements that are consistent with this grand conjecture. The first result is the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Easy decomposition")]#text(". Assume ")#mi("d \\geq 3")#text(", that p is both mass supercritical and energy subcritical, and u is a forward-global bounded-")#mi("H^1")#text(" solution. Then there is a unique decomposition")

#align(center)[#tao-fit-display[#mitex("u(t,x) = e^{it\\Delta} u_+(x) + u_{wb}(t,x)")]]

#text("where ")#mi("u_+ \\in H^1")#text(", and ")#mi("u_{wb}")#text(" is ")#emph[#text("weakly bound")]#text(" in the sense that it is asymptotically orthogonal to all linear states:")

#align(center)[#mi("\\lim_{t \\to \\infty} \\langle u_{wb}(t), e^{it\\Delta} v \\rangle_{H^1} = 0 \\text{ for all } v \\in H^1")#text(".")]
]

#text("This is quite an easy result, based on inspecting the Duhamel formula")

#align(center)[#tao-fit-display[#tao-math("u(t) = e^{it\\Delta} u_0 + i \\int_0^t e^{i(t-t^{\\prime})\\Delta} ( \\left|u\\right|^{p-1} u )(t^{\\prime})\\ dt^{\\prime}", block: true)]]

#text("and then verifying that the improper integral ")#tao-math("\\int_0^\\infty e^{-it \\Delta} ( \\left|u\\right|^{p-1} u )(t)\\ dt", block: false)#text(" is ")#link("http://en.wikipedia.org/wiki/Conditional_convergence")[#text("conditionally convergent")]#text(". It reveals the existence of a canonical asymptotic free state ")#mi("e^{it\\Delta} u_+")#text(", but we do not know much about the weakly bound remainder ")#mi("u_{wb}(t)")#text(", which could potentially also disperse in space, just not in a manner that too closely resembles a free state. Nevertheless, with additional assumptions one can do better. In my ")#link("http://arxiv.org/abs/math.AP/0309428")[#text("first paper on this topic")]#text(", I proved")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem")]#text(". Let d=3 and p=3, and let u be a spherically symmetric forward-global bounded-")#mi("H^1")#text(" solution. Then we have the decomposition")

#align(center)[#tao-fit-display[#mitex("u(t,x) = e^{it\\Delta} u_+(x) + u_b(t,x) + o_{\\dot H^1}(1)")]]

#text("where ")#mi("u_+")#text(" is as before, ")#mi("u_b")#text(" is smooth, with the pointwise bounds ")#mi("\\nabla^k u_b(t,x) = O_{k,\\varepsilon}( \\langle x \\rangle^{-1/2+\\varepsilon} )")#text(" for all ")#mi("k \\geq 0")#text(" and ")#mi("\\varepsilon > 0")#text(", and the error ")#mi("o_{\\dot H^1}(1)")#text(" decays to zero in the homogeneous Sobolev space ")#mi("\\dot H^1({\\Bbb R}^3)")#text(".")
]

#text("This result was proven by using a ")#link("http://en.wikipedia.org/wiki/Pseudo-differential_operator")[#text("pseudodifferential")]#text(" partition of a wave into incoming and outgoing waves, combined with heavy use of the Duhamel formula and harmonic analysis tools.")

#text("In my ")#link("http://arxiv.org/abs/math.AP/0611402")[#text("second paper")]#text(", I was able to show a stronger result in higher dimensions, and in particular uncover a (concentration-)compact ")#link("http://en.wikipedia.org/wiki/Attractor")[#text("attractor")]#text(" for the evolution. This result is easiest to state in the radial case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Radial compact attractor")]#text(". Let ")#mi("d \\geq 5")#text(" and let p be both mass-supercritical and energy-subcritical. Let u be a spherically symmetric forward-global bounded-")#mi("H^1")#text(" solution. Then we have the decomposition")

#align(center)[#tao-fit-display[#mitex("u(t,x) = e^{it\\Delta} u_+(x) + u_b(t,x) + o(1)")]]

#text("where ")#mi("u_b(t)")#text(" takes values in a fixed compact subset K of ")#mi("H^1")#text(" (depending only on d, p, and the ")#mi("H^1")#text(" bound) which is invariant under the NLS flow. In other words, we have the compact attractor property")

#align(center)[#mi("\\text{dist}_{H^1}( u(t) - e^{it\\Delta} u_+, K ) \\to 0")#text(" as ")#mi("{}t \\to \\infty")#text(".")]
]

#text("In principle, this result implies that the “interesting” portion of the bounded-energy spherically symmetric NLS dynamics on the (non-compact) phase space ")#mi("H^1")#text(" collapses to that on a compact phase space K. Unfortunately, the theorem does not then tell us very much about K; I can prove some regularity and decay estimates on K, but what one would really like to know is that K consists entirely of soliton states (as well as the vacuum state 0), and this I have no idea how to prove.")

#text("There is a non-radial version, in which one (necessarily) makes the conclusion translation-invariant:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Non-radial compact attractor")]#text(". Let ")#mi("d \\geq 5")#text(" and let p be both mass-supercritical and energy-subcritical. Let u be a forward-global bounded-")#mi("H^1")#text(" solution. Then we have the decomposition")

#align(center)[#tao-fit-display[#mitex("u(t) = e^{it\\Delta} u_+ + \\sum_{j=1}^J u_{b,j}(t, x - x_j(t)) + o(1)")]]

#text("where ")#mi("u_{b,j}(t)")#text(" takes values in a fixed compact subset K of ")#mi("H^1")#text(" which is invariant under the NLS flow.")
]

#text("One corollary of this decomposition is that we can now prove the “")#link("http://www.icm2006.org/proceedings/Vol_III/contents/ICM_Vol_3_24.pdf")[#text("petite conjecture")]#text("” of Soffer for the equations and solutions covered by the above theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary (petite conjecture)")]#text(". Let u be as in the previous theorem. Suppose also that u is spatially localised in the sense that for every ")#mi("\\varepsilon > 0")#text(" there exists a compact set F such that ")#tao-math("\\int_{{\\Bbb R}^d \\backslash K} \\left|u(t,x)\\right|^2 \\leq \\varepsilon", block: false)#text(" for all times t. Then u is ")#link("http://en.wikipedia.org/wiki/Almost_periodic_function")[#text("almost periodic")]#text(", in the sense that the orbit ")#mi("\\{ u(t): t > 0 \\}")#text(" is ")#link("http://en.wikipedia.org/wiki/Relatively_compact")[#text("precompact")]#text(".")
]

#text("This is analogous to a corresponding claim for bounded energy solutions (similar in spirit to the famous RAGE theorem of Ruelle, Amrein, Georgescu, and Enss) to the linear Schrödinger equation ")#mi("iu_t + \\Delta u = Vu")#text(", with reasonably smooth and localised V: if such a solution is spatially localised in the above sense, then it must be a linear combination of (possibly infinitely many) eigenfunctions and is thus almost periodic.")

#text("The proofs of these theorems are primarily based on the dispersive properties of the fundamental solution, and in particular on a certain “double Duhamel trick” in which one expresses the solution in terms of both its past and future, and exploits the orthogonality between the two. One can illustrate this trick with a time-independent toy version of (say) the spherically symmetric version of the theorem, which would then assert that the set of all spherically symmetric, bounded ")#mi("H^1")#text(" solutions to the ground state equation ")#mi("\\Delta Q + Q^p = EQ")#text(", with E arbitrary, is precompact. One starting point here is to rewrite this equation as")

#align(center)[#tao-fit-display[#mitex("Q = (-\\Delta + E)^{-1} (Q^p)")]]

#text("which can be re-expressed (ignoring convergence issues for now) by representing Q in terms of evolution from the future")

#align(center)[#tao-fit-display[#mitex("Q = -i \\int_0^\\infty e^{-it\\Delta} e^{iEt} Q^p\\ dt")]]

#text("or in terms of evolution from the past")

#align(center)[#mi("Q = i \\int_{-\\infty}^0 e^{-it^{\\prime}\\Delta} e^{iEt^{\\prime}} Q^p\\ dt^{\\prime}")#text(".")]

#text("One can pair these two interactions against each other to express the norm of Q in terms of past-future interactions:")

#align(center)[#tao-math("\\left\\| Q \\right\\|_{L^2}^2 = - \\int_0^\\infty \\int_{-\\infty}^0 e^{iE(t-t^{\\prime})} \\langle e^{-i(t-t^{\\prime})\\Delta} Q^p, Q^p \\rangle\\ dt dt^{\\prime}", block: false)#text(".")]

#text("The double integral looks bad, but standard dispersive inequalities suggest that the right-hand side should decay like ")#mi("(t-t^{\\prime})^{-d/2}")#text(" as t, t’ go to infinity. In dimensions ")#mi("d \\geq 5")#text(", this type of decay is absolutely integrable in t, t’, so the right-hand side is dominated by “local” interactions in which t, t’ are small. It turns out that this is already enough (with a little bit of harmonic analysis) to establish precompactness of the space of all spherically symmetric ground states, and a significantly more complicated version of the above strategy also yields the theorems mentioned above.")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d673d9b3e9ff664b048a243397f1756f4cfaee98f073b4186a1396d6da741ac-38cab0c5d213f9c1aa1f47d8a8c3a19490ed36bd7997a03dda17e6c9535e88b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Carron")]], [#link("https://terrytao.wordpress.com/2008/01/14/the-asymptotic-behaviour-of-large-data-solutions-to-nls/#comment-24655")[#strong[#text("Igor Carron")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2008")])]

#text("Dear Terry,")

#text("Oddly, there are three formulas that do not parse.")

#text("Igor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/14/the-asymptotic-behaviour-of-large-data-solutions-to-nls/#comment-24669")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2008")])]

#text("Strange, it seems that there are some sporadic bugs in WordPress’ LaTeX code, but I’ve managed to fix it for now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A global compact attractor for high-dimensional defocusing non-linear Schrödinger equations with potential « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/14/the-asymptotic-behaviour-of-large-data-solutions-to-nls/#comment-29739")[#strong[#text("A global compact attractor for high-dimensional defocusing non-linear Schrödinger equations with potential « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2008")])]

#text("[…] must increase in size as E increases to accommodate these states. (I discuss these results in a recent talk of […]")
]
